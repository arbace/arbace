//line aot_arbace_box_print.ae:1
package aot_arbace_box_print

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_New() *A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A{}; t.Ctor(); return t }
//line :5:1
func (t *A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A) Ctor() {}
//line :5:1
func (t *A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_box_print_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_box_print_A_const_1); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_5)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :5:1
func A_arbace_box_print_eval1463000008_fn__1463000009_A_New() *A_arbace_box_print_eval1463000008_fn__1463000009_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_eval1463000008_fn__1463000009_A{}; t.Ctor(); return t }
//line :5:1
func (t *A_arbace_box_print_eval1463000008_fn__1463000009_A) Ctor() {}
//line :5:1
func (t *A_arbace_box_print_eval1463000008_fn__1463000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_print_A_const_2.GetRawRoot__O()); var tmp2 any; var root_11 any = A_arbace_box_print_A_const_3.GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_11, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = A_arbace_box_print_A_const_4; if linked_12 == nil { tmp2 = ifn_13.Invoke_O__O(arg_14) } else { tmp2 = linked_12.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_11, arg_14) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_box_print_A_const_5.GetRawRoot__O(), A_arbace_box_print_A_const_6) }














func A_arbace_box_print_tool_A_New() *A_arbace_box_print_tool_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_tool_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_box_print_tool_A) Ctor() {}
//line :20:1
func (t *A_arbace_box_print_tool_A) Invoke_O_O__O(self, sym__0 any) any { var or__1927000174__auto____2 any; var root_15 any = A_arbace_box_print_A_const_7.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_17 lang.IFn; if
									linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = sym__0; if linked_16 == nil { or__1927000174__auto____2 = ifn_17.Invoke_O__O(arg_18) } else { or__1927000174__auto____2 = linked_16.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_15, arg_18) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var tmp1 any; var root_19 any = A_arbace_box_print_A_const_8.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, sym__0)).Ref(); var arg_23 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_20 == nil { tmp1 = ifn_21.Invoke_O_O__O(arg_22, arg_23) } else { tmp1 = linked_20.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_19, arg_22, arg_23) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) } }

func A_arbace_box_print_print_goroot_A_New() *A_arbace_box_print_print_goroot_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_print_goroot_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_box_print_print_goroot_A) Ctor() {}
//line :23:1
func (t *A_arbace_box_print_print_goroot_A) Invoke_O__O(self any) any { { var program__1 any; var root_24 any = A_arbace_box_print_A_const_9.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, A_arbace_box_print_tool_A_fn_class); var ifn_26 lang.IFn







	if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any = A_arbace_box_print_A_const_10; if linked_25 == nil { program__1 = ifn_26.Invoke_O__O(arg_27) } else { program__1 = linked_25.(*A_arbace_box_print_tool_A).Invoke_O_O__O(root_24, arg_27) }
//line :23:1
	var print_module__2 any; var root_28 any = A_arbace_box_print_A_const_9.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, A_arbace_box_print_tool_A_fn_class); var ifn_30 lang.IFn








	if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = A_arbace_box_print_A_const_11; if linked_29 == nil { print_module__2 = ifn_30.Invoke_O__O(arg_31) } else { print_module__2 = linked_29.(*A_arbace_box_print_tool_A).Invoke_O_O__O(root_28, arg_31) }
//line :23:1
	var print_package__3 any; var root_32 any = A_arbace_box_print_A_const_9.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, A_arbace_box_print_tool_A_fn_class); var ifn_34 lang.IFn









	if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = A_arbace_box_print_A_const_12; if linked_33 == nil { print_package__3 = ifn_34.Invoke_O__O(arg_35) } else { print_package__3 = linked_33.(*A_arbace_box_print_tool_A).Invoke_O_O__O(root_32, arg_35) }
//line :23:1
	var goroot__4 any = Lit_6; var p__5 any = lang.IFn_Cast(program__1).Invoke_O_O_O__O(jrt.File_New_String(Lit_7), goroot__4, A_arbace_box_print_A_const_32)












	lang.IFn_Cast(print_module__2).Invoke_O_O_O_O__O(p__5, jrt.File_New_String(Lit_7), jrt.File_New_String(Lit_8), A_arbace_box_print_A_const_33)
//line :23:1
	var p__5_2 any = lang.IFn_Cast(program__1).Invoke_O_O_O__O(jrt.File_New_String(Lit_9), goroot__4, A_arbace_box_print_A_const_34)














	lang.IFn_Cast(print_module__2).Invoke_O_O_O_O__O(p__5_2, jrt.File_New_String(Lit_9), jrt.File_New_String(Lit_10), A_arbace_box_print_A_const_35)
//line :23:1
	var have__5 any; var root_61 any = A_arbace_box_print_A_const_18.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_63 lang.IFn















	if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any; var iter__1927001039__auto____5 any; var tmp1 any = A_arbace_box_print_print_goroot_iter__1463000013__1463000017_A_New(); var tmp2 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_box_print_print_goroot_iter__1463000013__1463000017_A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_box_print_print_goroot_iter__1463000013__1463000017_A_fn_class = fncls__139d; tmp2 = fncls__139d } else { tmp2 = fncls__139 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_64 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(jrt.File_New_String(Lit_12).ListFiles__File1().Ref()); if linked_62 == nil { have__5 = ifn_63.Invoke_O__O(arg_64) } else { have__5 = linked_62.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_61, arg_64) }
//line :23:1
	var want__6 any; var root_140 any = A_arbace_box_print_A_const_5.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_142 lang.IFn



















	if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any; var root_145 any = A_arbace_box_print_A_const_18.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = A_arbace_box_print_A_const_14.GetRawRoot__O(); if linked_146 == nil { arg_143 = ifn_147.Invoke_O__O(arg_148) } else { arg_143 = linked_146.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_145, arg_148) }; var arg_144 any = Lit_13; if linked_141 == nil { want__6 = ifn_142.Invoke_O_O__O(arg_143, arg_144) } else { want__6 = linked_141.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_140, arg_143, arg_144) }
	var tmp3 any; var root_149 any = A_arbace_box_print_A_const_28.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_149, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = have__5; var arg_153 any = want__6; if linked_150 == nil { tmp3 = ifn_151.Invoke_O_O__O(arg_152, arg_153) } else { tmp3 = linked_150.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_149, arg_152, arg_153) }; if jrt.J2g_Truth(tmp3) { var tmp4 any; var root_154 any = A_arbace_box_print_A_const_8.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_156 lang.IFn
		if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_14, nil, Lit_15, nil, Lit_16); var tmp6 any; var root_159 any = A_arbace_box_print_A_const_29.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = have__5; if linked_160 == nil { tmp6 = ifn_161.Invoke_O__O(arg_162) } else { tmp6 = linked_160.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_159, arg_162) }; var tmp7 any = tmp6; var tmp8 any; var root_163 any = A_arbace_box_print_A_const_29.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_165 lang.IFn
		if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = want__6; if linked_164 == nil { tmp8 = ifn_165.Invoke_O__O(arg_166) } else { tmp8 = linked_164.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_163, arg_166) }
//line :45:1
		arg_157 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil, tmp8, nil)).Ref(); var arg_158 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_print_A_const_30, have__5, A_arbace_box_print_A_const_31, want__6)); if linked_155 == nil { tmp4 = ifn_156.Invoke_O_O__O(arg_157, arg_158) } else { tmp4 = linked_155.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_154, arg_157, arg_158) }
//line :44:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp4))) }
//line :23:1
	var seq_1463000023__5 any; var root_36 any = A_arbace_box_print_A_const_13.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_38 lang.IFn
























	if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any; var root_40 any = A_arbace_box_print_A_const_5.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = A_arbace_box_print_A_const_14.GetRawRoot__O(); var arg_44 any = Lit_13; if linked_41 == nil { arg_39 = ifn_42.Invoke_O_O__O(arg_43, arg_44) } else { arg_39 = linked_41.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_40, arg_43, arg_44) }; if linked_37 == nil { seq_1463000023__5 = ifn_38.Invoke_O__O(arg_39) } else { seq_1463000023__5 = linked_37.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_36, arg_39) }
//line :23:1
	var chunk_1463000024__6 any; var count_1463000025__7 int64 = 0; var i_1463000026__8 int64 = 0; L1: for {
























		if lang.Numbers_Lt_J_J__Z_NoInit(i_1463000026__8, count_1463000025__7) { var pkg__9 any = lang.Indexed_Cast(chunk_1463000024__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1463000026__8))
			lang.IFn_Cast(print_package__3).Invoke_O_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil, Lit_18), jrt.RefArrayOf(jrt.Object_class, nil, pkg__9, nil)).Ref(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, pkg__9)).Ref(), A_arbace_box_print_A_const_36)
//line :48:1
			seq_1463000023__5, chunk_1463000024__6, count_1463000025__7, i_1463000026__8 = seq_1463000023__5, chunk_1463000024__6, count_1463000025__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1463000026__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_45 any = A_arbace_box_print_A_const_13.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = seq_1463000023__5; if linked_46 == nil { temp__1927000414__auto____9 = ifn_47.Invoke_O__O(arg_48) } else { temp__1927000414__auto____9 = linked_46.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_45, arg_48) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_1463000023__10 any = temp__1927000414__auto____9; var tmp9 any; var root_49 any = A_arbace_box_print_A_const_15.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = seq_1463000023__10; if linked_50 == nil { tmp9 = ifn_51.Invoke_O__O(arg_52) } else { tmp9 = linked_50.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_49, arg_52) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____11 any; var root_53 any = A_arbace_box_print_A_const_16.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = seq_1463000023__10; if linked_54 == nil { c__1927000678__auto____11 = ifn_55.Invoke_O__O(arg_56) } else { c__1927000678__auto____11 = linked_54.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_53, arg_56) }; var tmp10 any; var root_167 any = A_arbace_box_print_A_const_25.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_169 lang.IFn; if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any = seq_1463000023__10; if linked_168 == nil { tmp10 = ifn_169.Invoke_O__O(arg_170) } else { tmp10 = linked_168.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_167, arg_170) }; seq_1463000023__5, chunk_1463000024__6, count_1463000025__7, i_1463000026__8 = tmp10, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var pkg__11 any; var root_57 any = A_arbace_box_print_A_const_17.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = seq_1463000023__10; if linked_58 == nil { pkg__11 = ifn_59.Invoke_O__O(arg_60) } else { pkg__11 = linked_58.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_57, arg_60) }
				lang.IFn_Cast(print_package__3).Invoke_O_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil, Lit_18), jrt.RefArrayOf(jrt.Object_class, nil, pkg__11, nil)).Ref(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, pkg__11)).Ref(), A_arbace_box_print_A_const_37)
//line :48:1
				var tmp11 any; var root_171 any = A_arbace_box_print_A_const_38.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_173 lang.IFn; if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any = seq_1463000023__10; if linked_172 == nil { tmp11 = ifn_173.Invoke_O__O(arg_174) } else { tmp11 = linked_172.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_171, arg_174) }; seq_1463000023__5, chunk_1463000024__6, count_1463000025__7, i_1463000026__8 = tmp11, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :23:1*/panic("j2g: unreachable") }















func A_arbace_box_print_print_goroot_iter__1463000013__1463000017_A_New() *A_arbace_box_print_print_goroot_iter__1463000013__1463000017_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_print_goroot_iter__1463000013__1463000017_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_box_print_print_goroot_iter__1463000013__1463000017_A) Ctor() {}
//line :39:1
func (t *A_arbace_box_print_print_goroot_iter__1463000013__1463000017_A) Invoke_O_O__O(self, s__1463000014__1 any) any { var tmp1 any = A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_A_New_O_O(s__1463000014__1, self); var tmp2 *jrt.Class; var fncls__138 *jrt.Class = A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_A_fn_class; if fncls__138 == nil { var fncls__138d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_A_fn_class = fncls__138d; tmp2 = fncls__138d } else { tmp2 = fncls__138 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :39:1
func A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_A_New_O_O(p0, p1 any) *A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_A{}; t.Ctor_O_O(p0, p1); return t }
//line :39:1
func (t *A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_A) Ctor_O_O(c__s__1463000014, c__iter__1463000013 any) { t.F_s__1463000014 = c__s__1463000014; t.F_iter__1463000013 = c__iter__1463000013 }
//line :39:1
func (t *A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_A) Invoke_O__O(self any) any { { var s__1463000014__1 any; var t_ any = t.F_s__1463000014; t.F_s__1463000014 = nil; s__1463000014__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_65 any = A_arbace_box_print_A_const_13.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_67 lang.IFn; if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = s__1463000014__1; if linked_66 == nil { temp__1927000414__auto____2 = ifn_67.Invoke_O__O(arg_68) } else { temp__1927000414__auto____2 = linked_66.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_65, arg_68) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1463000014__3 any = temp__1927000414__auto____2; var tmp1 any; var root_69 any = A_arbace_box_print_A_const_15.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = s__1463000014__3; if linked_70 == nil { tmp1 = ifn_71.Invoke_O__O(arg_72) } else { tmp1 = linked_70.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_69, arg_72) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_73 any = A_arbace_box_print_A_const_16.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = s__1463000014__3; if linked_74 == nil { c__1927001037__auto____4 = ifn_75.Invoke_O__O(arg_76) } else { c__1927001037__auto____4 = linked_74.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_73, arg_76) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1463000016__6 any; var root_77 any = A_arbace_box_print_A_const_19.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_78 == nil { b__1463000016__6 = ifn_79.Invoke_O__O(arg_80) } else { b__1463000016__6 = linked_78.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_77, arg_80) }; var tmp2 any = A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_fn__1463000019_A_New_O_I_O(b__1463000016__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__92 *jrt.Class = A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_fn__1463000019_A_fn_class; if fncls__92 == nil { var fncls__92d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_fn__1463000019_A_fn_class = fncls__92d; tmp3 = fncls__92d } else { tmp3 = fncls__92 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_93 any = A_arbace_box_print_A_const_23.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any; var root_98 any = A_arbace_box_print_A_const_24.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = b__1463000016__6; if linked_99 == nil { arg_96 = ifn_100.Invoke_O__O(arg_101) } else { arg_96 = linked_99.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_98, arg_101) }; var arg_97 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1463000013); var tmp5 any; var root_102 any = A_arbace_box_print_A_const_25.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = s__1463000014__3; if linked_103 == nil { tmp5 = ifn_104.Invoke_O__O(arg_105) } else { tmp5 = linked_103.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_102, arg_105) }; arg_97 = tmp4.Invoke_O__O(tmp5); if linked_94 == nil { return ifn_95.Invoke_O_O__O(arg_96, arg_97) } else { return linked_94.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_93, arg_96, arg_97) } } else { var root_106 any = A_arbace_box_print_A_const_23.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any; var root_111 any = A_arbace_box_print_A_const_24.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = b__1463000016__6; if linked_112 == nil { arg_109 = ifn_113.Invoke_O__O(arg_114) } else { arg_109 = linked_112.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_111, arg_114) }; var arg_110 any; if linked_107 == nil { return ifn_108.Invoke_O_O__O(arg_109, arg_110) } else { return linked_107.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_106, arg_109, arg_110) } } } else { var f__4 any; var root_115 any = A_arbace_box_print_A_const_17.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = s__1463000014__3; if linked_116 == nil { f__4 = ifn_117.Invoke_O__O(arg_118) } else { f__4 = linked_116.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_115, arg_118) }; var n__5 any = jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(); var tmp6 bool; var and__1927000168__auto____6 bool = jrt.NN(jrt.File_Cast(f__4)).IsFile__Z()

	if and__1927000168__auto____6 { tmp6 = jrt.NN(jrt.String_Cast(n__5)).EndsWith_String__Z(Lit_18) } else { tmp6 = and__1927000168__auto____6 }
//line :39:1
	if tmp6 { var root_119 any = A_arbace_box_print_A_const_26.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any; var root_124 any = A_arbace_box_print_A_const_21.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_126 lang.IFn


		if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = n__5; var arg_128 any = A_arbace_box_print_A_const_22; var arg_129 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(n__5)), 3)).Ref(); if linked_125 == nil { arg_122 = ifn_126.Invoke_O_O_O__O(arg_127, arg_128, arg_129) } else { arg_122 = linked_125.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_124, arg_127, arg_128, arg_129) }
//line :39:1
		var arg_123 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1463000013); var tmp8 any; var root_130 any = A_arbace_box_print_A_const_27.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = s__1463000014__3; if linked_131 == nil { tmp8 = ifn_132.Invoke_O__O(arg_133) } else { tmp8 = linked_131.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_130, arg_133) }; arg_123 = tmp7.Invoke_O__O(tmp8); if linked_120 == nil { return ifn_121.Invoke_O_O__O(arg_122, arg_123) } else { return linked_120.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_119, arg_122, arg_123) } } else { var tmp9 any; var root_134 any = A_arbace_box_print_A_const_27.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = s__1463000014__3; if linked_135 == nil { tmp9 = ifn_136.Invoke_O__O(arg_137) } else { tmp9 = linked_135.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_134, arg_137) }; s__1463000014__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :39:1
func A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_fn__1463000019_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_fn__1463000019_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_fn__1463000019_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :39:1
func (t *A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_fn__1463000019_A) Ctor_O_I_O(c__b__1463000016 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1463000016 = c__b__1463000016; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :39:1
func (t *A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_fn__1463000019_A) Invoke_O__O(self any) any { { var i__1463000015__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1463000015__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1463000015__1)); var n__3 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var tmp2 bool; var and__1927000168__auto____4 bool = jrt.NN(jrt.File_Cast(f__2)).IsFile__Z()

	if and__1927000168__auto____4 { tmp2 = jrt.NN(jrt.String_Cast(n__3)).EndsWith_String__Z(Lit_18) } else { tmp2 = and__1927000168__auto____4 }
//line :39:1
	if tmp2 { var root_81 any = A_arbace_box_print_A_const_20.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = t.F_b__1463000016; var arg_85 any; var root_86 any = A_arbace_box_print_A_const_21.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_88 lang.IFn


		if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any = n__3; var arg_90 any = A_arbace_box_print_A_const_22; var arg_91 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(n__3)), 3)).Ref(); if linked_87 == nil { arg_85 = ifn_88.Invoke_O_O_O__O(arg_89, arg_90, arg_91) } else { arg_85 = linked_87.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_86, arg_89, arg_90, arg_91) }
//line :39:1
		if linked_82 == nil { ifn_83.Invoke_O_O__O(arg_84, arg_85) } else { linked_82.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_81, arg_84, arg_85) }; i__1463000015__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1463000015__1); continue L1 } else { i__1463000015__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1463000015__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }











func A_arbace_box_print_print_program_A_New() *A_arbace_box_print_print_program_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_print_program_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_box_print_print_program_A) Ctor() {}
//line :51:1
func (t *A_arbace_box_print_print_program_A) Invoke_O__O(self any) any { var program__1 any; var root_175 any = A_arbace_box_print_A_const_9.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, A_arbace_box_print_tool_A_fn_class); var ifn_177 lang.IFn; if





	linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = A_arbace_box_print_A_const_39; if linked_176 == nil { program__1 = ifn_177.Invoke_O__O(arg_178) } else { program__1 = linked_176.(*A_arbace_box_print_tool_A).Invoke_O_O__O(root_175, arg_178) }; var print_module__2 any; var root_179 any = /*line :51:1*/A_arbace_box_print_A_const_9.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, A_arbace_box_print_tool_A_fn_class); var ifn_181 lang.IFn; if






	linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = A_arbace_box_print_A_const_40; if linked_180 == nil { print_module__2 = ifn_181.Invoke_O__O(arg_182) } else { print_module__2 = linked_180.(*A_arbace_box_print_tool_A).Invoke_O_O__O(root_179, arg_182) }; var opts__3 any = A_arbace_box_print_A_const_41; var p__4 any = /*line :51:1*/lang.IFn_Cast(program__1).Invoke_O_O_O__O(jrt.File_New_String(Lit_22), Lit_6, opts__3);









	lang.IFn_Cast(print_module__2).Invoke_O_O_O_O__O(p__4, jrt.File_New_String(Lit_22), jrt.File_New_String(Lit_23), opts__3); var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_box_print_A_const_42.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_print_A_const_43.GetRawRoot__O()); var tmp3 any; var tmp4 *lang.Keyword = A_arbace_box_print_A_const_44; var tmp5 *lang.Keyword = A_arbace_box_print_A_const_45; var or__1927000174__auto____5 any = tmp4.Invoke_O__O(tmp5.Invoke_O__O(A_arbace_box_print_A_const_46.Invoke_O__O(p__4))); if jrt.J2g_Truth(or__1927000174__auto____5) { tmp3 = or__1927000174__auto____5 } else { tmp3 = lang.PersistentArrayMap_EMPTY.Ref() }; return tmp1.Invoke_O_O__O(Lit_24, tmp2.Invoke_O__O(tmp3)) }

func A_arbace_box_print__main_A_New() *A_arbace_box_print__main_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print__main_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_box_print__main_A) Ctor() {}
//line :64:1
func (t *A_arbace_box_print__main_A) DoInvoke_O_O__O(self, p__1463000029__0 any) any { var vec__1463000030__2 any = p__1463000029__0; var cmd__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1463000030__2, lang.RT_IntCast_J__I_NoInit(0), nil); var G__1463000033__4_ any = cmd__3; L1:
switch { default: switch lang.Util_Hash_O__I_NoInit(G__1463000033__4_) >> 1 & 1 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1463000033__4_, Lit_1) {

	var root_193 any = A_arbace_box_print_A_const_47.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, A_arbace_box_print_print_program_A_fn_class); var ifn_195 lang.IFn; if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; if linked_194 == nil { ifn_195.Invoke__O() } else { linked_194.(*A_arbace_box_print_print_program_A).Invoke_O__O(root_193) }
//line :65:1
	break L1 }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1463000033__4_, Lit_2) {
		var root_196 any = A_arbace_box_print_A_const_48.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, A_arbace_box_print_print_goroot_A_fn_class); var ifn_198 lang.IFn; if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; if linked_197 == nil { ifn_198.Invoke__O() } else { linked_197.(*A_arbace_box_print_print_goroot_A).Invoke_O__O(root_196) }
//line :65:1
		break L1 }; default:
}

	var root_210 any = A_arbace_box_print_A_const_52.GetRawRoot__O(); var linked_211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_210, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_212 lang.IFn; if linked_211 == nil { ifn_212 = lang.IFn_Cast(root_210) } else { ifn_212 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_print_A_const_53.GetRawRoot__O()); var tmp2 any = A_arbace_box_print_A_const_54; var arg_213 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_box_print_A_const_55.Get__O()); if linked_211 == nil { ifn_212.Invoke_O__O(arg_213) } else { linked_211.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_210, arg_213) }; var tmp3 any = A_arbace_box_print__main_fn__1463000034_A_New(); var tmp4 *jrt.Class; var fncls__209 *jrt.Class = A_arbace_box_print__main_fn__1463000034_A_fn_class; if fncls__209 == nil { var fncls__209d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_box_print__main_fn__1463000034_A_fn_class = fncls__209d; tmp4 = fncls__209d } else { tmp4 = fncls__209 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2))}; var root_199 any =
	A_arbace_box_print_A_const_49.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; if linked_200 == nil { ifn_201.Invoke__O() } else { linked_200.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_199) };
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(0)); return nil }
//line :68:1
func A_arbace_box_print__main_fn__1463000034_A_New() *A_arbace_box_print__main_fn__1463000034_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print__main_fn__1463000034_A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_box_print__main_fn__1463000034_A) Ctor() {}
//line :68:1
func (t *A_arbace_box_print__main_fn__1463000034_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_box_print_A_const_50.GetRawRoot__O()).Invoke_O__O(Lit_4); return nil }(); var root_206 any = A_arbace_box_print_A_const_51.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; if linked_207 == nil { ifn_208.Invoke__O() } else { linked_207.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_206) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }









type A_arbace_box_print_A struct{ jrt.Object }

var A_arbace_box_print_A_const_pool *jrt.RefArray

var A_arbace_box_print_A_const_0 *lang.Var

var A_arbace_box_print_A_const_1 any

var A_arbace_box_print_A_const_2 *lang.Var

var A_arbace_box_print_A_const_3 *lang.Var

var A_arbace_box_print_A_const_4 *lang.Var

var A_arbace_box_print_A_const_5 *lang.Var

var A_arbace_box_print_A_const_6 any

var A_arbace_box_print_A_const_7 *lang.Var

var A_arbace_box_print_A_const_8 *lang.Var

var A_arbace_box_print_A_const_9 *lang.Var

var A_arbace_box_print_A_const_10 any

var A_arbace_box_print_A_const_11 any

var A_arbace_box_print_A_const_12 any

var A_arbace_box_print_A_const_13 *lang.Var

var A_arbace_box_print_A_const_14 *lang.Var

var A_arbace_box_print_A_const_15 *lang.Var

var A_arbace_box_print_A_const_16 *lang.Var

var A_arbace_box_print_A_const_17 *lang.Var

var A_arbace_box_print_A_const_18 *lang.Var

var A_arbace_box_print_A_const_19 *lang.Var

var A_arbace_box_print_A_const_20 *lang.Var

var A_arbace_box_print_A_const_21 *lang.Var

var A_arbace_box_print_A_const_22 any

var A_arbace_box_print_A_const_23 *lang.Var

var A_arbace_box_print_A_const_24 *lang.Var

var A_arbace_box_print_A_const_25 *lang.Var

var A_arbace_box_print_A_const_26 *lang.Var

var A_arbace_box_print_A_const_27 *lang.Var

var A_arbace_box_print_A_const_28 *lang.Var

var A_arbace_box_print_A_const_29 *lang.Var

var A_arbace_box_print_A_const_30 *lang.Keyword

var A_arbace_box_print_A_const_31 *lang.Keyword

var A_arbace_box_print_A_const_32 any

var A_arbace_box_print_A_const_33 any

var A_arbace_box_print_A_const_34 any

var A_arbace_box_print_A_const_35 any

var A_arbace_box_print_A_const_36 any

var A_arbace_box_print_A_const_37 any

var A_arbace_box_print_A_const_38 *lang.Var

var A_arbace_box_print_A_const_39 any

var A_arbace_box_print_A_const_40 any

var A_arbace_box_print_A_const_41 any

var A_arbace_box_print_A_const_42 *lang.Var

var A_arbace_box_print_A_const_43 *lang.Var

var A_arbace_box_print_A_const_44 *lang.Keyword

var A_arbace_box_print_A_const_45 *lang.Keyword

var A_arbace_box_print_A_const_46 *lang.Keyword

var A_arbace_box_print_A_const_47 *lang.Var

var A_arbace_box_print_A_const_48 *lang.Var

var A_arbace_box_print_A_const_49 *lang.Var

var A_arbace_box_print_A_const_50 *lang.Var

var A_arbace_box_print_A_const_51 *lang.Var

var A_arbace_box_print_A_const_52 *lang.Var

var A_arbace_box_print_A_const_53 *lang.Var

var A_arbace_box_print_A_const_54 *lang.Var

var A_arbace_box_print_A_const_55 *lang.Var

var A_arbace_box_print_A_init jrt.ClassInit

func A_arbace_box_print_A_Init() { if !A_arbace_box_print_A_init.Done() { A_arbace_box_print_A_init.Run(A_arbace_box_print_A_clinit) } }

func A_arbace_box_print_A_clinit() { A_arbace_box_print_A_clinit_p0(); A_arbace_box_print_A_clinit_p1(); A_arbace_box_print_A_clinit_p2(); A_arbace_box_print_A_clinit_p3(); A_arbace_box_print_A_clinit_p4() }

func A_arbace_box_print_A_clinit_p0() { jrt.StartCheck(); A_arbace_box_print_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 76); A_arbace_box_print_A_const_0 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[20]); A_arbace_box_print_A_const_1 = A_arbace_box_print_A_const_pool.A[21]; A_arbace_box_print_A_const_2 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[22]); A_arbace_box_print_A_const_3 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[23]); A_arbace_box_print_A_const_4 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[24]); A_arbace_box_print_A_const_5 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[25]); A_arbace_box_print_A_const_6 = A_arbace_box_print_A_const_pool.A[26]; A_arbace_box_print_A_const_7 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[27]); A_arbace_box_print_A_const_8 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[28]); A_arbace_box_print_A_const_9 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[29]); A_arbace_box_print_A_const_10 = A_arbace_box_print_A_const_pool.A[30]; A_arbace_box_print_A_const_11 = A_arbace_box_print_A_const_pool.A[31] }

func A_arbace_box_print_A_clinit_p1() { A_arbace_box_print_A_const_12 = A_arbace_box_print_A_const_pool.A[32]; A_arbace_box_print_A_const_13 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[33]); A_arbace_box_print_A_const_14 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[34]); A_arbace_box_print_A_const_15 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[35]); A_arbace_box_print_A_const_16 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[36]); A_arbace_box_print_A_const_17 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[37]); A_arbace_box_print_A_const_18 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[38]); A_arbace_box_print_A_const_19 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[39]); A_arbace_box_print_A_const_20 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[40]); A_arbace_box_print_A_const_21 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[41]); A_arbace_box_print_A_const_22 = A_arbace_box_print_A_const_pool.A[42]; A_arbace_box_print_A_const_23 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[43]) }

func A_arbace_box_print_A_clinit_p2() { A_arbace_box_print_A_const_24 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[44]); A_arbace_box_print_A_const_25 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[45]); A_arbace_box_print_A_const_26 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[46]); A_arbace_box_print_A_const_27 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[47]); A_arbace_box_print_A_const_28 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[48]); A_arbace_box_print_A_const_29 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[49]); A_arbace_box_print_A_const_30 = lang.Keyword_Cast(A_arbace_box_print_A_const_pool.A[50]); A_arbace_box_print_A_const_31 = lang.Keyword_Cast(A_arbace_box_print_A_const_pool.A[51]); A_arbace_box_print_A_const_32 = A_arbace_box_print_A_const_pool.A[52]; A_arbace_box_print_A_const_33 = A_arbace_box_print_A_const_pool.A[53]; A_arbace_box_print_A_const_34 = A_arbace_box_print_A_const_pool.A[54]; A_arbace_box_print_A_const_35 = A_arbace_box_print_A_const_pool.A[55]; A_arbace_box_print_A_const_36 = A_arbace_box_print_A_const_pool.A[56] }

func A_arbace_box_print_A_clinit_p3() { A_arbace_box_print_A_const_37 = A_arbace_box_print_A_const_pool.A[57]; A_arbace_box_print_A_const_38 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[58]); A_arbace_box_print_A_const_39 = A_arbace_box_print_A_const_pool.A[59]; A_arbace_box_print_A_const_40 = A_arbace_box_print_A_const_pool.A[60]; A_arbace_box_print_A_const_41 = A_arbace_box_print_A_const_pool.A[61]; A_arbace_box_print_A_const_42 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[62]); A_arbace_box_print_A_const_43 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[63]); A_arbace_box_print_A_const_44 = lang.Keyword_Cast(A_arbace_box_print_A_const_pool.A[64]); A_arbace_box_print_A_const_45 = lang.Keyword_Cast(A_arbace_box_print_A_const_pool.A[65]); A_arbace_box_print_A_const_46 = lang.Keyword_Cast(A_arbace_box_print_A_const_pool.A[66]); A_arbace_box_print_A_const_47 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[67]); A_arbace_box_print_A_const_48 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[68]); A_arbace_box_print_A_const_49 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[69]) }

func A_arbace_box_print_A_clinit_p4() { A_arbace_box_print_A_const_50 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[70]); A_arbace_box_print_A_const_51 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[71]); A_arbace_box_print_A_const_52 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[72]); A_arbace_box_print_A_const_53 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[73]); A_arbace_box_print_A_const_54 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[74]); A_arbace_box_print_A_const_55 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[75]) }

func A_arbace_box_print_A_New() *A_arbace_box_print_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_A{}; t.Ctor(); return t }

func (t *A_arbace_box_print_A) Ctor() {}

func (t *A_arbace_box_print_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_print_A) GetClass__Class() *jrt.Class { return A_arbace_box_print_A_class }

func (t *A_arbace_box_print_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_print_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_print_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_print_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_print_A); return ok }

func A_arbace_box_print_A_Cast(x any) *A_arbace_box_print_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_print_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_print_A_class)) }; return v }



type A_arbace_box_print__main_A struct{ j2g_header uint64 }

var A_arbace_box_print__main_A_fn_class *jrt.Class



type A_arbace_box_print__main_fn__1463000034_A struct{ j2g_header uint64 }

var A_arbace_box_print__main_fn__1463000034_A_fn_class *jrt.Class



type A_arbace_box_print_eval1463000004_A struct{ jrt.Object }

func A_arbace_box_print_eval1463000004_A_New() *A_arbace_box_print_eval1463000004_A { t := &A_arbace_box_print_eval1463000004_A{}; t.Ctor(); return t }

func (t *A_arbace_box_print_eval1463000004_A) Ctor() {}

func (t *A_arbace_box_print_eval1463000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_print_eval1463000004_A) GetClass__Class() *jrt.Class { return A_arbace_box_print_eval1463000004_A_class }

func (t *A_arbace_box_print_eval1463000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_print_eval1463000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_print_eval1463000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_print_eval1463000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_print_eval1463000004_A); return ok }

func A_arbace_box_print_eval1463000004_A_Cast(x any) *A_arbace_box_print_eval1463000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_print_eval1463000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_print_eval1463000004_A_class)) }; return v }



type A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A struct{ j2g_header uint64 }

var A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_fn_class *jrt.Class



type A_arbace_box_print_eval1463000008_A struct{ jrt.Object }

func A_arbace_box_print_eval1463000008_A_New() *A_arbace_box_print_eval1463000008_A { t := &A_arbace_box_print_eval1463000008_A{}; t.Ctor(); return t }

func (t *A_arbace_box_print_eval1463000008_A) Ctor() {}

func (t *A_arbace_box_print_eval1463000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_print_eval1463000008_A) GetClass__Class() *jrt.Class { return A_arbace_box_print_eval1463000008_A_class }

func (t *A_arbace_box_print_eval1463000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_print_eval1463000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_print_eval1463000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_print_eval1463000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_print_eval1463000008_A); return ok }

func A_arbace_box_print_eval1463000008_A_Cast(x any) *A_arbace_box_print_eval1463000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_print_eval1463000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_print_eval1463000008_A_class)) }; return v }



type A_arbace_box_print_eval1463000008_fn__1463000009_A struct{ j2g_header uint64 }

var A_arbace_box_print_eval1463000008_fn__1463000009_A_fn_class *jrt.Class



type A_arbace_box_print_print_goroot_A struct{ j2g_header uint64 }

var A_arbace_box_print_print_goroot_A_fn_class *jrt.Class



type A_arbace_box_print_print_goroot_iter__1463000013__1463000017_A struct{ j2g_header uint64 }

var A_arbace_box_print_print_goroot_iter__1463000013__1463000017_A_fn_class *jrt.Class



type A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_A struct{ j2g_header uint64; F_s__1463000014, F_iter__1463000013 any }

var A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_A_fn_class *jrt.Class



type A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_fn__1463000019_A struct{ j2g_header uint64; F_b__1463000016 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_fn__1463000019_A_fn_class *jrt.Class



type A_arbace_box_print_print_program_A struct{ j2g_header uint64 }

var A_arbace_box_print_print_program_A_fn_class *jrt.Class



type A_arbace_box_print_tool_A struct{ j2g_header uint64 }

var A_arbace_box_print_tool_A_fn_class *jrt.Class
