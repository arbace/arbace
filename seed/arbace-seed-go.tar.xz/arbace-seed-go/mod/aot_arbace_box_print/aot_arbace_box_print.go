//line aot_arbace_box_print.ae:1
package aot_arbace_box_print

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_New() *A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A{}; t.Ctor(); return t }
//line :5:1
func (t *A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A) Ctor() {}
//line :5:1
func (t *A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_box_print_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_box_print_A_const_1); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_5)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :5:1
func A_arbace_box_print_eval1463000008_fn__1463000009_A_New() *A_arbace_box_print_eval1463000008_fn__1463000009_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_eval1463000008_fn__1463000009_A{}; t.Ctor(); return t }
//line :5:1
func (t *A_arbace_box_print_eval1463000008_fn__1463000009_A) Ctor() {}
//line :5:1
func (t *A_arbace_box_print_eval1463000008_fn__1463000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_print_A_const_2.GetRawRoot__O()); var tmp2 any; var root_11 any = A_arbace_box_print_A_const_3.GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_11, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = A_arbace_box_print_A_const_4; if linked_12 == nil { tmp2 = ifn_13.Invoke_O__O(arg_14) } else { tmp2 = linked_12.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_11, arg_14) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_box_print_A_const_5.GetRawRoot__O(), A_arbace_box_print_A_const_6) }














func A_arbace_box_print_tool_A_New() *A_arbace_box_print_tool_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_tool_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_box_print_tool_A) Ctor() {}
//line :20:1
func (t *A_arbace_box_print_tool_A) Invoke_O_O__O(self, sym__0 any) any { var or__1927000174__auto____2 any; var root_15 any = A_arbace_box_print_A_const_7.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_17 lang.IFn; if
									linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = sym__0; if linked_16 == nil { or__1927000174__auto____2 = ifn_17.Invoke_O__O(arg_18) } else { or__1927000174__auto____2 = linked_16.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_15, arg_18) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var tmp1 any; var root_19 any = A_arbace_box_print_A_const_8.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, sym__0)).Ref(); var arg_23 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_20 == nil { tmp1 = ifn_21.Invoke_O_O__O(arg_22, arg_23) } else { tmp1 = linked_20.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_19, arg_22, arg_23) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) } }

func A_arbace_box_print_print_goroot_A_New() *A_arbace_box_print_print_goroot_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_print_goroot_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_box_print_print_goroot_A) Ctor() {}
//line :23:1
func (t *A_arbace_box_print_print_goroot_A) Invoke_O__O(self any) any { { var program__1 any; var root_24 any = A_arbace_box_print_A_const_9.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, A_arbace_box_print_tool_A_fn_class); var ifn_26 lang.IFn







	if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any = A_arbace_box_print_A_const_10; if linked_25 == nil { program__1 = ifn_26.Invoke_O__O(arg_27) } else { program__1 = linked_25.(*A_arbace_box_print_tool_A).Invoke_O_O__O(root_24, arg_27) }
//line :23:1
	var print_module__2 any; var root_28 any = A_arbace_box_print_A_const_9.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, A_arbace_box_print_tool_A_fn_class); var ifn_30 lang.IFn








	if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = A_arbace_box_print_A_const_11; if linked_29 == nil { print_module__2 = ifn_30.Invoke_O__O(arg_31) } else { print_module__2 = linked_29.(*A_arbace_box_print_tool_A).Invoke_O_O__O(root_28, arg_31) }
//line :23:1
	var print_package__3 any; var root_32 any = A_arbace_box_print_A_const_9.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, A_arbace_box_print_tool_A_fn_class); var ifn_34 lang.IFn









	if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = A_arbace_box_print_A_const_12; if linked_33 == nil { print_package__3 = ifn_34.Invoke_O__O(arg_35) } else { print_package__3 = linked_33.(*A_arbace_box_print_tool_A).Invoke_O_O__O(root_32, arg_35) }
//line :23:1
	var goroot__4 any = Lit_6; var p__5 any = lang.IFn_Cast(program__1).Invoke_O_O_O__O(jrt.File_New_String(Lit_7), goroot__4, A_arbace_box_print_A_const_32)












	lang.IFn_Cast(print_module__2).Invoke_O_O_O_O__O(p__5, jrt.File_New_String(Lit_7), jrt.File_New_String(Lit_8), A_arbace_box_print_A_const_33)
//line :23:1
	var p__5_2 any = lang.IFn_Cast(program__1).Invoke_O_O_O__O(jrt.File_New_String(Lit_9), goroot__4, A_arbace_box_print_A_const_34)














	lang.IFn_Cast(print_module__2).Invoke_O_O_O_O__O(p__5_2, jrt.File_New_String(Lit_9), jrt.File_New_String(Lit_10), A_arbace_box_print_A_const_35)
//line :23:1
	var have__5 any; var root_61 any = A_arbace_box_print_A_const_18.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_63 lang.IFn















	if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any; var iter__1927001039__auto____5 any; var fnbody__142 any = A_arbace_box_print_print_goroot_iter__1463000013__1463000017_A_New(); var tmp1 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_box_print_print_goroot_iter__1463000013__1463000017_A_fn_class; if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, nil); A_arbace_box_print_print_goroot_iter__1463000013__1463000017_A_fn_class = fncls__141d; tmp1 = fncls__141d } else { tmp1 = fncls__141 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__142, tmp1, nil); arg_64 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(jrt.File_New_String(Lit_12).ListFiles__File1().Ref()); if linked_62 == nil { have__5 = ifn_63.Invoke_O__O(arg_64) } else { have__5 = linked_62.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_61, arg_64) }
//line :23:1
	var want__6 any; var root_143 any = A_arbace_box_print_A_const_5.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_143, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_145 lang.IFn



















	if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any; var root_148 any = A_arbace_box_print_A_const_18.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = A_arbace_box_print_A_const_14.GetRawRoot__O(); if linked_149 == nil { arg_146 = ifn_150.Invoke_O__O(arg_151) } else { arg_146 = linked_149.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_148, arg_151) }; var arg_147 any = Lit_13; if linked_144 == nil { want__6 = ifn_145.Invoke_O_O__O(arg_146, arg_147) } else { want__6 = linked_144.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_143, arg_146, arg_147) }
	var tmp2 any; var root_152 any = A_arbace_box_print_A_const_28.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = have__5; var arg_156 any = want__6; if linked_153 == nil { tmp2 = ifn_154.Invoke_O_O__O(arg_155, arg_156) } else { tmp2 = linked_153.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_152, arg_155, arg_156) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_157 any = A_arbace_box_print_A_const_8.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_159 lang.IFn
		if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_14, nil, Lit_15, nil, Lit_16); var tmp5 any; var root_162 any = A_arbace_box_print_A_const_29.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = have__5; if linked_163 == nil { tmp5 = ifn_164.Invoke_O__O(arg_165) } else { tmp5 = linked_163.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_162, arg_165) }; var tmp6 any = tmp5; var tmp7 any; var root_166 any = A_arbace_box_print_A_const_29.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_168 lang.IFn
		if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = want__6; if linked_167 == nil { tmp7 = ifn_168.Invoke_O__O(arg_169) } else { tmp7 = linked_167.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_166, arg_169) }
//line :45:1
		arg_160 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp6, nil, tmp7, nil)).Ref(); var arg_161 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_print_A_const_30, have__5, A_arbace_box_print_A_const_31, want__6)); if linked_158 == nil { tmp3 = ifn_159.Invoke_O_O__O(arg_160, arg_161) } else { tmp3 = linked_158.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_157, arg_160, arg_161) }
//line :44:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp3))) }
//line :23:1
	var seq_1463000023__5 any; var root_36 any = A_arbace_box_print_A_const_13.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_38 lang.IFn
























	if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any; var root_40 any = A_arbace_box_print_A_const_5.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = A_arbace_box_print_A_const_14.GetRawRoot__O(); var arg_44 any = Lit_13; if linked_41 == nil { arg_39 = ifn_42.Invoke_O_O__O(arg_43, arg_44) } else { arg_39 = linked_41.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_40, arg_43, arg_44) }; if linked_37 == nil { seq_1463000023__5 = ifn_38.Invoke_O__O(arg_39) } else { seq_1463000023__5 = linked_37.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_36, arg_39) }
//line :23:1
	var chunk_1463000024__6 any; var count_1463000025__7 int64 = 0; var i_1463000026__8 int64 = 0; L1: for {
























		if lang.Numbers_Lt_J_J__Z_NoInit(i_1463000026__8, count_1463000025__7) { var pkg__9 any = lang.Indexed_Cast(chunk_1463000024__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1463000026__8))
			lang.IFn_Cast(print_package__3).Invoke_O_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil, Lit_18), jrt.RefArrayOf(jrt.Object_class, nil, pkg__9, nil)).Ref(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, pkg__9)).Ref(), A_arbace_box_print_A_const_36)
//line :48:1
			seq_1463000023__5, chunk_1463000024__6, count_1463000025__7, i_1463000026__8 = seq_1463000023__5, chunk_1463000024__6, count_1463000025__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1463000026__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_45 any = A_arbace_box_print_A_const_13.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = seq_1463000023__5; if linked_46 == nil { temp__1927000414__auto____9 = ifn_47.Invoke_O__O(arg_48) } else { temp__1927000414__auto____9 = linked_46.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_45, arg_48) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_1463000023__10 any = temp__1927000414__auto____9; var tmp8 any; var root_49 any = A_arbace_box_print_A_const_15.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = seq_1463000023__10; if linked_50 == nil { tmp8 = ifn_51.Invoke_O__O(arg_52) } else { tmp8 = linked_50.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_49, arg_52) }; if jrt.J2g_Truth(tmp8) { var c__1927000678__auto____11 any; var root_53 any = A_arbace_box_print_A_const_16.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = seq_1463000023__10; if linked_54 == nil { c__1927000678__auto____11 = ifn_55.Invoke_O__O(arg_56) } else { c__1927000678__auto____11 = linked_54.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_53, arg_56) }; var tmp9 any; var root_170 any = A_arbace_box_print_A_const_25.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = seq_1463000023__10; if linked_171 == nil { tmp9 = ifn_172.Invoke_O__O(arg_173) } else { tmp9 = linked_171.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_170, arg_173) }; seq_1463000023__5, chunk_1463000024__6, count_1463000025__7, i_1463000026__8 = tmp9, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var pkg__11 any; var root_57 any = A_arbace_box_print_A_const_17.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = seq_1463000023__10; if linked_58 == nil { pkg__11 = ifn_59.Invoke_O__O(arg_60) } else { pkg__11 = linked_58.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_57, arg_60) }
				lang.IFn_Cast(print_package__3).Invoke_O_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil, Lit_18), jrt.RefArrayOf(jrt.Object_class, nil, pkg__11, nil)).Ref(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, pkg__11)).Ref(), A_arbace_box_print_A_const_37)
//line :48:1
				var tmp10 any; var root_174 any = A_arbace_box_print_A_const_38.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = seq_1463000023__10; if linked_175 == nil { tmp10 = ifn_176.Invoke_O__O(arg_177) } else { tmp10 = linked_175.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_174, arg_177) }; seq_1463000023__5, chunk_1463000024__6, count_1463000025__7, i_1463000026__8 = tmp10, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :23:1*/panic("j2g: unreachable") }















func A_arbace_box_print_print_goroot_iter__1463000013__1463000017_A_New() *A_arbace_box_print_print_goroot_iter__1463000013__1463000017_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_print_goroot_iter__1463000013__1463000017_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_box_print_print_goroot_iter__1463000013__1463000017_A) Ctor() {}
//line :39:1
func (t *A_arbace_box_print_print_goroot_iter__1463000013__1463000017_A) Invoke_O_O__O(self, s__1463000014__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__140 any = A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_A_New_O_O(s__1463000014__1, self); var tmp2 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, fnbody__140); A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_A_fn_class = fncls__139d; tmp2 = fncls__139d } else { tmp2 = fncls__139 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__140, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :39:1
func A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_A_New_O_O(p0, p1 any) *A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_A{}; t.Ctor_O_O(p0, p1); return t }
//line :39:1
func (t *A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_A) Ctor_O_O(c__s__1463000014, c__iter__1463000013 any) { t.F_s__1463000014 = c__s__1463000014; t.F_iter__1463000013 = c__iter__1463000013 }
//line :39:1
func (t *A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_A) Invoke_O__O(self any) any { { var s__1463000014__1 any; var t_ any = t.F_s__1463000014; t.F_s__1463000014 = nil; s__1463000014__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_65 any = A_arbace_box_print_A_const_13.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_67 lang.IFn; if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = s__1463000014__1; if linked_66 == nil { temp__1927000414__auto____2 = ifn_67.Invoke_O__O(arg_68) } else { temp__1927000414__auto____2 = linked_66.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_65, arg_68) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1463000014__3 any = temp__1927000414__auto____2; var tmp1 any; var root_69 any = A_arbace_box_print_A_const_15.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = s__1463000014__3; if linked_70 == nil { tmp1 = ifn_71.Invoke_O__O(arg_72) } else { tmp1 = linked_70.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_69, arg_72) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_73 any = A_arbace_box_print_A_const_16.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = s__1463000014__3; if linked_74 == nil { c__1927001037__auto____4 = ifn_75.Invoke_O__O(arg_76) } else { c__1927001037__auto____4 = linked_74.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_73, arg_76) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1463000016__6 any; var root_77 any = A_arbace_box_print_A_const_19.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_78 == nil { b__1463000016__6 = ifn_79.Invoke_O__O(arg_80) } else { b__1463000016__6 = linked_78.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_77, arg_80) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__93 any = A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_fn__1463000019_A_New_O_I_O(b__1463000016__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__92 *jrt.Class = A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_fn__1463000019_A_fn_class; if fncls__92 == nil { var fncls__92d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__93); A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_fn__1463000019_A_fn_class = fncls__92d; tmp3 = fncls__92d } else { tmp3 = fncls__92 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__93, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_94 any = A_arbace_box_print_A_const_23.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any; var root_99 any = A_arbace_box_print_A_const_24.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = b__1463000016__6; if linked_100 == nil { arg_97 = ifn_101.Invoke_O__O(arg_102) } else { arg_97 = linked_100.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_99, arg_102) }; var arg_98 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1463000013); var tmp5 any; var root_103 any = A_arbace_box_print_A_const_25.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = s__1463000014__3; if linked_104 == nil { tmp5 = ifn_105.Invoke_O__O(arg_106) } else { tmp5 = linked_104.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_103, arg_106) }; arg_98 = tmp4.Invoke_O__O(tmp5); if linked_95 == nil { return ifn_96.Invoke_O_O__O(arg_97, arg_98) } else { return linked_95.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_94, arg_97, arg_98) } } else { var root_107 any = A_arbace_box_print_A_const_23.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any; var root_112 any = A_arbace_box_print_A_const_24.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = b__1463000016__6; if linked_113 == nil { arg_110 = ifn_114.Invoke_O__O(arg_115) } else { arg_110 = linked_113.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_112, arg_115) }; var arg_111 any; if linked_108 == nil { return ifn_109.Invoke_O_O__O(arg_110, arg_111) } else { return linked_108.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_107, arg_110, arg_111) } } } else { var f__4 any; var root_116 any = A_arbace_box_print_A_const_17.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = s__1463000014__3; if linked_117 == nil { f__4 = ifn_118.Invoke_O__O(arg_119) } else { f__4 = linked_117.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_116, arg_119) }; var n__5 any = jrt.File_Cast(f__4).GetName__String().Ref(); var tmp6 bool; var and__1927000168__auto____6 bool = jrt.File_Cast(f__4).IsFile__Z()

	if and__1927000168__auto____6 { tmp6 = jrt.NN(jrt.String_Cast(n__5)).EndsWith_String__Z(Lit_18) } else { tmp6 = and__1927000168__auto____6 }
//line :39:1
	if tmp6 { var root_120 any = A_arbace_box_print_A_const_26.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any; var root_125 any = A_arbace_box_print_A_const_21.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_127 lang.IFn


		if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = n__5; var arg_129 any = A_arbace_box_print_A_const_22; var arg_130 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(n__5)), 3)).Ref(); if linked_126 == nil { arg_123 = ifn_127.Invoke_O_O_O__O(arg_128, arg_129, arg_130) } else { arg_123 = linked_126.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_125, arg_128, arg_129, arg_130) }
//line :39:1
		var arg_124 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1463000013); var tmp8 any; var root_131 any = A_arbace_box_print_A_const_27.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_133 lang.IFn; if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any = s__1463000014__3; if linked_132 == nil { tmp8 = ifn_133.Invoke_O__O(arg_134) } else { tmp8 = linked_132.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_131, arg_134) }; arg_124 = tmp7.Invoke_O__O(tmp8); if linked_121 == nil { return ifn_122.Invoke_O_O__O(arg_123, arg_124) } else { return linked_121.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_120, arg_123, arg_124) } } else { var tmp9 any; var root_135 any = A_arbace_box_print_A_const_27.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = s__1463000014__3; if linked_136 == nil { tmp9 = ifn_137.Invoke_O__O(arg_138) } else { tmp9 = linked_136.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_135, arg_138) }; s__1463000014__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :39:1
func A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_fn__1463000019_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_fn__1463000019_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_fn__1463000019_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :39:1
func (t *A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_fn__1463000019_A) Ctor_O_I_O(c__b__1463000016 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1463000016 = c__b__1463000016; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :39:1
func (t *A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_fn__1463000019_A) Invoke_O__O(self any) any { { var i__1463000015__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1463000015__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1463000015__1)); var n__3 any = jrt.File_Cast(f__2).GetName__String().Ref(); var tmp2 bool; var and__1927000168__auto____4 bool = jrt.File_Cast(f__2).IsFile__Z()

	if and__1927000168__auto____4 { tmp2 = jrt.NN(jrt.String_Cast(n__3)).EndsWith_String__Z(Lit_18) } else { tmp2 = and__1927000168__auto____4 }
//line :39:1
	if tmp2 { var root_81 any = A_arbace_box_print_A_const_20.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = t.F_b__1463000016; var arg_85 any; var root_86 any = A_arbace_box_print_A_const_21.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_88 lang.IFn


		if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any = n__3; var arg_90 any = A_arbace_box_print_A_const_22; var arg_91 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(n__3)), 3)).Ref(); if linked_87 == nil { arg_85 = ifn_88.Invoke_O_O_O__O(arg_89, arg_90, arg_91) } else { arg_85 = linked_87.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_86, arg_89, arg_90, arg_91) }
//line :39:1
		if linked_82 == nil { ifn_83.Invoke_O_O__O(arg_84, arg_85) } else { linked_82.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_81, arg_84, arg_85) }; i__1463000015__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1463000015__1); continue L1 } else { i__1463000015__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1463000015__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }











func A_arbace_box_print_print_program_A_New() *A_arbace_box_print_print_program_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_print_program_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_box_print_print_program_A) Ctor() {}
//line :51:1
func (t *A_arbace_box_print_print_program_A) Invoke_O__O(self any) any { var program__1 any; var root_178 any = A_arbace_box_print_A_const_9.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, A_arbace_box_print_tool_A_fn_class); var ifn_180 lang.IFn; if





	linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = A_arbace_box_print_A_const_39; if linked_179 == nil { program__1 = ifn_180.Invoke_O__O(arg_181) } else { program__1 = linked_179.(*A_arbace_box_print_tool_A).Invoke_O_O__O(root_178, arg_181) }; var print_module__2 any; var root_182 any = /*line :51:1*/A_arbace_box_print_A_const_9.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, A_arbace_box_print_tool_A_fn_class); var ifn_184 lang.IFn; if






	linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = A_arbace_box_print_A_const_40; if linked_183 == nil { print_module__2 = ifn_184.Invoke_O__O(arg_185) } else { print_module__2 = linked_183.(*A_arbace_box_print_tool_A).Invoke_O_O__O(root_182, arg_185) }; var opts__3 any = A_arbace_box_print_A_const_41; var p__4 any = /*line :51:1*/lang.IFn_Cast(program__1).Invoke_O_O_O__O(jrt.File_New_String(Lit_22), Lit_6, opts__3);









	lang.IFn_Cast(print_module__2).Invoke_O_O_O_O__O(p__4, jrt.File_New_String(Lit_22), jrt.File_New_String(Lit_23), opts__3); var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_box_print_A_const_42.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_print_A_const_43.GetRawRoot__O()); var tmp3 any; var tmp4 *lang.Keyword = A_arbace_box_print_A_const_44; var tmp5 *lang.Keyword = A_arbace_box_print_A_const_45; var or__1927000174__auto____5 any = tmp4.Invoke_O__O(tmp5.Invoke_O__O(A_arbace_box_print_A_const_46.Invoke_O__O(p__4))); if jrt.J2g_Truth(or__1927000174__auto____5) { tmp3 = or__1927000174__auto____5 } else { tmp3 = lang.PersistentArrayMap_EMPTY.Ref() }; return tmp1.Invoke_O_O__O(Lit_24, tmp2.Invoke_O__O(tmp3)) }

func A_arbace_box_print__main_A_New() *A_arbace_box_print__main_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print__main_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_box_print__main_A) Ctor() {}
//line :64:1
func (t *A_arbace_box_print__main_A) DoInvoke_O_O__O(self, p__1463000029__0 any) any { var vec__1463000030__2 any = p__1463000029__0; var cmd__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1463000030__2, lang.RT_IntCast_J__I_NoInit(0), nil); var G__1463000033__4_ any = cmd__3; L1:
switch { default: switch lang.Util_Hash_O__I_NoInit(G__1463000033__4_) >> 1 & 1 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1463000033__4_, Lit_1) {

	var root_196 any = A_arbace_box_print_A_const_47.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, A_arbace_box_print_print_program_A_fn_class); var ifn_198 lang.IFn; if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; if linked_197 == nil { ifn_198.Invoke__O() } else { linked_197.(*A_arbace_box_print_print_program_A).Invoke_O__O(root_196) }
//line :65:1
	break L1 }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1463000033__4_, Lit_2) {
		var root_199 any = A_arbace_box_print_A_const_48.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, A_arbace_box_print_print_goroot_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; if linked_200 == nil { ifn_201.Invoke__O() } else { linked_200.(*A_arbace_box_print_print_goroot_A).Invoke_O__O(root_199) }
//line :65:1
		break L1 }; default:
}

	var root_214 any = A_arbace_box_print_A_const_52.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_print_A_const_53.GetRawRoot__O()); var tmp2 any = A_arbace_box_print_A_const_54; var arg_217 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_box_print_A_const_55.Get__O()); if linked_215 == nil { ifn_216.Invoke_O__O(arg_217) } else { linked_215.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_214, arg_217) }; var tmp3 *lang.Compiler_AOTFn; var fnbody__213 any = A_arbace_box_print__main_fn__1463000034_A_New(); var tmp4 *jrt.Class; var fncls__212 *jrt.Class = A_arbace_box_print__main_fn__1463000034_A_fn_class; if fncls__212 == nil { var fncls__212d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, nil); A_arbace_box_print__main_fn__1463000034_A_fn_class = fncls__212d; tmp4 = fncls__212d } else { tmp4 = fncls__212 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__213, tmp4, nil); Up_Compiler_AOTFn_IFn(tmp3).Invoke__O()
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2))}; var root_202 any =
	A_arbace_box_print_A_const_49.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; if linked_203 == nil { ifn_204.Invoke__O() } else { linked_203.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_202) };
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(0)); return nil }
//line :68:1
func A_arbace_box_print__main_fn__1463000034_A_New() *A_arbace_box_print__main_fn__1463000034_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print__main_fn__1463000034_A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_box_print__main_fn__1463000034_A) Ctor() {}
//line :68:1
func (t *A_arbace_box_print__main_fn__1463000034_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_box_print_A_const_50.GetRawRoot__O()).Invoke_O__O(Lit_4); return nil }(); var root_209 any = A_arbace_box_print_A_const_51.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; if linked_210 == nil { ifn_211.Invoke__O() } else { linked_210.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_209) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }









type A_arbace_box_print_A struct{ jrt.Object }

var A_arbace_box_print_A_const_pool *jrt.RefArray

var A_arbace_box_print_A_const_0 *lang.Var

var A_arbace_box_print_A_const_1 any

var A_arbace_box_print_A_const_2 *lang.Var

var A_arbace_box_print_A_const_3 *lang.Var

var A_arbace_box_print_A_const_4 *lang.Var

var A_arbace_box_print_A_const_5 *lang.Var

var A_arbace_box_print_A_const_6 any

var A_arbace_box_print_A_const_7 *lang.Var

var A_arbace_box_print_A_const_8 *lang.Var

var A_arbace_box_print_A_const_9 *lang.Var

var A_arbace_box_print_A_const_10 any

var A_arbace_box_print_A_const_11 any

var A_arbace_box_print_A_const_12 any

var A_arbace_box_print_A_const_13 *lang.Var

var A_arbace_box_print_A_const_14 *lang.Var

var A_arbace_box_print_A_const_15 *lang.Var

var A_arbace_box_print_A_const_16 *lang.Var

var A_arbace_box_print_A_const_17 *lang.Var

var A_arbace_box_print_A_const_18 *lang.Var

var A_arbace_box_print_A_const_19 *lang.Var

var A_arbace_box_print_A_const_20 *lang.Var

var A_arbace_box_print_A_const_21 *lang.Var

var A_arbace_box_print_A_const_22 any

var A_arbace_box_print_A_const_23 *lang.Var

var A_arbace_box_print_A_const_24 *lang.Var

var A_arbace_box_print_A_const_25 *lang.Var

var A_arbace_box_print_A_const_26 *lang.Var

var A_arbace_box_print_A_const_27 *lang.Var

var A_arbace_box_print_A_const_28 *lang.Var

var A_arbace_box_print_A_const_29 *lang.Var

var A_arbace_box_print_A_const_30 *lang.Keyword

var A_arbace_box_print_A_const_31 *lang.Keyword

var A_arbace_box_print_A_const_32 any

var A_arbace_box_print_A_const_33 any

var A_arbace_box_print_A_const_34 any

var A_arbace_box_print_A_const_35 any

var A_arbace_box_print_A_const_36 any

var A_arbace_box_print_A_const_37 any

var A_arbace_box_print_A_const_38 *lang.Var

var A_arbace_box_print_A_const_39 any

var A_arbace_box_print_A_const_40 any

var A_arbace_box_print_A_const_41 any

var A_arbace_box_print_A_const_42 *lang.Var

var A_arbace_box_print_A_const_43 *lang.Var

var A_arbace_box_print_A_const_44 *lang.Keyword

var A_arbace_box_print_A_const_45 *lang.Keyword

var A_arbace_box_print_A_const_46 *lang.Keyword

var A_arbace_box_print_A_const_47 *lang.Var

var A_arbace_box_print_A_const_48 *lang.Var

var A_arbace_box_print_A_const_49 *lang.Var

var A_arbace_box_print_A_const_50 *lang.Var

var A_arbace_box_print_A_const_51 *lang.Var

var A_arbace_box_print_A_const_52 *lang.Var

var A_arbace_box_print_A_const_53 *lang.Var

var A_arbace_box_print_A_const_54 *lang.Var

var A_arbace_box_print_A_const_55 *lang.Var

var A_arbace_box_print_A_init jrt.ClassInit

func A_arbace_box_print_A_Init() { if !A_arbace_box_print_A_init.Done() { A_arbace_box_print_A_init.Run(A_arbace_box_print_A_clinit) } }

func A_arbace_box_print_A_clinit() { A_arbace_box_print_A_clinit_p0(); A_arbace_box_print_A_clinit_p1(); A_arbace_box_print_A_clinit_p2(); A_arbace_box_print_A_clinit_p3(); A_arbace_box_print_A_clinit_p4() }

func A_arbace_box_print_A_clinit_p0() { jrt.StartCheck(); A_arbace_box_print_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 76); A_arbace_box_print_A_const_0 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[20]); A_arbace_box_print_A_const_1 = A_arbace_box_print_A_const_pool.A[21]; A_arbace_box_print_A_const_2 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[22]); A_arbace_box_print_A_const_3 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[23]); A_arbace_box_print_A_const_4 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[24]); A_arbace_box_print_A_const_5 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[25]); A_arbace_box_print_A_const_6 = A_arbace_box_print_A_const_pool.A[26]; A_arbace_box_print_A_const_7 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[27]); A_arbace_box_print_A_const_8 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[28]); A_arbace_box_print_A_const_9 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[29]); A_arbace_box_print_A_const_10 = A_arbace_box_print_A_const_pool.A[30]; A_arbace_box_print_A_const_11 = A_arbace_box_print_A_const_pool.A[31] }

func A_arbace_box_print_A_clinit_p1() { A_arbace_box_print_A_const_12 = A_arbace_box_print_A_const_pool.A[32]; A_arbace_box_print_A_const_13 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[33]); A_arbace_box_print_A_const_14 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[34]); A_arbace_box_print_A_const_15 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[35]); A_arbace_box_print_A_const_16 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[36]); A_arbace_box_print_A_const_17 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[37]); A_arbace_box_print_A_const_18 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[38]); A_arbace_box_print_A_const_19 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[39]); A_arbace_box_print_A_const_20 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[40]); A_arbace_box_print_A_const_21 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[41]); A_arbace_box_print_A_const_22 = A_arbace_box_print_A_const_pool.A[42]; A_arbace_box_print_A_const_23 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[43]) }

func A_arbace_box_print_A_clinit_p2() { A_arbace_box_print_A_const_24 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[44]); A_arbace_box_print_A_const_25 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[45]); A_arbace_box_print_A_const_26 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[46]); A_arbace_box_print_A_const_27 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[47]); A_arbace_box_print_A_const_28 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[48]); A_arbace_box_print_A_const_29 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[49]); A_arbace_box_print_A_const_30 = lang.Keyword_Cast(A_arbace_box_print_A_const_pool.A[50]); A_arbace_box_print_A_const_31 = lang.Keyword_Cast(A_arbace_box_print_A_const_pool.A[51]); A_arbace_box_print_A_const_32 = A_arbace_box_print_A_const_pool.A[52]; A_arbace_box_print_A_const_33 = A_arbace_box_print_A_const_pool.A[53]; A_arbace_box_print_A_const_34 = A_arbace_box_print_A_const_pool.A[54]; A_arbace_box_print_A_const_35 = A_arbace_box_print_A_const_pool.A[55]; A_arbace_box_print_A_const_36 = A_arbace_box_print_A_const_pool.A[56] }

func A_arbace_box_print_A_clinit_p3() { A_arbace_box_print_A_const_37 = A_arbace_box_print_A_const_pool.A[57]; A_arbace_box_print_A_const_38 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[58]); A_arbace_box_print_A_const_39 = A_arbace_box_print_A_const_pool.A[59]; A_arbace_box_print_A_const_40 = A_arbace_box_print_A_const_pool.A[60]; A_arbace_box_print_A_const_41 = A_arbace_box_print_A_const_pool.A[61]; A_arbace_box_print_A_const_42 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[62]); A_arbace_box_print_A_const_43 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[63]); A_arbace_box_print_A_const_44 = lang.Keyword_Cast(A_arbace_box_print_A_const_pool.A[64]); A_arbace_box_print_A_const_45 = lang.Keyword_Cast(A_arbace_box_print_A_const_pool.A[65]); A_arbace_box_print_A_const_46 = lang.Keyword_Cast(A_arbace_box_print_A_const_pool.A[66]); A_arbace_box_print_A_const_47 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[67]); A_arbace_box_print_A_const_48 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[68]); A_arbace_box_print_A_const_49 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[69]) }

func A_arbace_box_print_A_clinit_p4() { A_arbace_box_print_A_const_50 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[70]); A_arbace_box_print_A_const_51 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[71]); A_arbace_box_print_A_const_52 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[72]); A_arbace_box_print_A_const_53 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[73]); A_arbace_box_print_A_const_54 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[74]); A_arbace_box_print_A_const_55 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[75]) }

func A_arbace_box_print_A_New() *A_arbace_box_print_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_A{}; t.Ctor(); return t }

func (t *A_arbace_box_print_A) Ctor() {}

func (t *A_arbace_box_print_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_print_A) GetClass__Class() *jrt.Class { return A_arbace_box_print_A_class }

func (t *A_arbace_box_print_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_print_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_print_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_print_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_print_A); return ok }

func A_arbace_box_print_A_Cast(x any) *A_arbace_box_print_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_print_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_print_A_class)) }; return v }



type A_arbace_box_print__main_A struct{ j2g_header uint64 }

var A_arbace_box_print__main_A_fn_class *jrt.Class



type A_arbace_box_print__main_fn__1463000034_A struct{ j2g_header uint64 }

var A_arbace_box_print__main_fn__1463000034_A_fn_class *jrt.Class



type A_arbace_box_print_eval1463000004_A struct{ jrt.Object }

func A_arbace_box_print_eval1463000004_A_New() *A_arbace_box_print_eval1463000004_A { t := &A_arbace_box_print_eval1463000004_A{}; t.Ctor(); return t }

func (t *A_arbace_box_print_eval1463000004_A) Ctor() {}

func (t *A_arbace_box_print_eval1463000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_print_eval1463000004_A) GetClass__Class() *jrt.Class { return A_arbace_box_print_eval1463000004_A_class }

func (t *A_arbace_box_print_eval1463000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_print_eval1463000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_print_eval1463000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_print_eval1463000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_print_eval1463000004_A); return ok }

func A_arbace_box_print_eval1463000004_A_Cast(x any) *A_arbace_box_print_eval1463000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_print_eval1463000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_print_eval1463000004_A_class)) }; return v }



type A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A struct{ j2g_header uint64 }

var A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_fn_class *jrt.Class



type A_arbace_box_print_eval1463000008_A struct{ jrt.Object }

func A_arbace_box_print_eval1463000008_A_New() *A_arbace_box_print_eval1463000008_A { t := &A_arbace_box_print_eval1463000008_A{}; t.Ctor(); return t }

func (t *A_arbace_box_print_eval1463000008_A) Ctor() {}

func (t *A_arbace_box_print_eval1463000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_print_eval1463000008_A) GetClass__Class() *jrt.Class { return A_arbace_box_print_eval1463000008_A_class }

func (t *A_arbace_box_print_eval1463000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_print_eval1463000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_print_eval1463000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_print_eval1463000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_print_eval1463000008_A); return ok }

func A_arbace_box_print_eval1463000008_A_Cast(x any) *A_arbace_box_print_eval1463000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_print_eval1463000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_print_eval1463000008_A_class)) }; return v }



type A_arbace_box_print_eval1463000008_fn__1463000009_A struct{ j2g_header uint64 }

var A_arbace_box_print_eval1463000008_fn__1463000009_A_fn_class *jrt.Class



type A_arbace_box_print_print_goroot_A struct{ j2g_header uint64 }

var A_arbace_box_print_print_goroot_A_fn_class *jrt.Class



type A_arbace_box_print_print_goroot_iter__1463000013__1463000017_A struct{ j2g_header uint64 }

var A_arbace_box_print_print_goroot_iter__1463000013__1463000017_A_fn_class *jrt.Class



type A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_A struct{ j2g_header uint64; F_s__1463000014, F_iter__1463000013 any }

var A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_A_fn_class *jrt.Class



type A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_fn__1463000019_A struct{ j2g_header uint64; F_b__1463000016 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_print_print_goroot_iter__1463000013__1463000017_fn__1463000018_fn__1463000019_A_fn_class *jrt.Class



type A_arbace_box_print_print_program_A struct{ j2g_header uint64 }

var A_arbace_box_print_print_program_A_fn_class *jrt.Class



type A_arbace_box_print_tool_A struct{ j2g_header uint64 }

var A_arbace_box_print_tool_A_fn_class *jrt.Class
