//line aot_arbace_box_print.ae:1
package aot_arbace_box_print

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_New() *A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A{}; t.Ctor(); return t }
//line :5:1
func (t *A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A) Ctor() {}
//line :5:1
func (t *A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_box_print_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_box_print_A_const_1); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_5)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :5:1
func A_arbace_box_print_eval1463000008_fn__1463000009_A_New() *A_arbace_box_print_eval1463000008_fn__1463000009_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_eval1463000008_fn__1463000009_A{}; t.Ctor(); return t }
//line :5:1
func (t *A_arbace_box_print_eval1463000008_fn__1463000009_A) Ctor() {}
//line :5:1
func (t *A_arbace_box_print_eval1463000008_fn__1463000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_print_A_const_2.GetRawRoot__O()); var tmp2 any; var root_5 any = A_arbace_box_print_A_const_3.GetRawRoot__O(); var linked_6 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_7 lang.IFn; if linked_6 == nil { ifn_7 = lang.IFn_Cast(root_5) } else { ifn_7 = nil }; var arg_8 any = A_arbace_box_print_A_const_4; if linked_6 == nil { tmp2 = ifn_7.Invoke_O__O(arg_8) } else { tmp2 = linked_6.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_5, arg_8) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_box_print_A_const_5.GetRawRoot__O(), A_arbace_box_print_A_const_6) }







func A_arbace_box_print_tool_A_New() *A_arbace_box_print_tool_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_tool_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_box_print_tool_A) Ctor() {}
//line :13:1
func (t *A_arbace_box_print_tool_A) Invoke_O_O__O(self, sym__0 any) any { var or__1927000174__auto____2 any; var root_15 any = A_arbace_box_print_A_const_7.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_17 lang.IFn; if
									linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = sym__0; if linked_16 == nil { or__1927000174__auto____2 = ifn_17.Invoke_O__O(arg_18) } else { or__1927000174__auto____2 = linked_16.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_15, arg_18) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var tmp1 any; var root_19 any = A_arbace_box_print_A_const_8.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_18, nil), jrt.RefArrayOf(jrt.Object_class, nil, sym__0)).Ref(); var arg_23 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_20 == nil { tmp1 = ifn_21.Invoke_O_O__O(arg_22, arg_23) } else { tmp1 = linked_20.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_19, arg_22, arg_23) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) } }

func A_arbace_box_print_print_goroot_A_New() *A_arbace_box_print_print_goroot_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_print_goroot_A{}; t.Ctor(); return t }
//line :16:1
func (t *A_arbace_box_print_print_goroot_A) Ctor() {}
//line :16:1
func (t *A_arbace_box_print_print_goroot_A) Invoke_O__O(self any) any { var program__1 any; var root_24 any = A_arbace_box_print_A_const_9.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, A_arbace_box_print_tool_A_fn_class); var ifn_26 lang.IFn; if






	linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any = A_arbace_box_print_A_const_10; if linked_25 == nil { program__1 = ifn_26.Invoke_O__O(arg_27) } else { program__1 = linked_25.(*A_arbace_box_print_tool_A).Invoke_O_O__O(root_24, arg_27) }; var print_module__2 any; var root_28 any = /*line :16:1*/A_arbace_box_print_A_const_9.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, A_arbace_box_print_tool_A_fn_class); var ifn_30 lang.IFn; if







	linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = A_arbace_box_print_A_const_11; if linked_29 == nil { print_module__2 = ifn_30.Invoke_O__O(arg_31) } else { print_module__2 = linked_29.(*A_arbace_box_print_tool_A).Invoke_O_O__O(root_28, arg_31) }; var print_package__3 any; var root_32 any = /*line :16:1*/A_arbace_box_print_A_const_9.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, A_arbace_box_print_tool_A_fn_class); var ifn_34 lang.IFn; if








	linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = A_arbace_box_print_A_const_12; if linked_33 == nil { print_package__3 = ifn_34.Invoke_O__O(arg_35) } else { print_package__3 = linked_33.(*A_arbace_box_print_tool_A).Invoke_O_O__O(root_32, arg_35) }; var goroot__4 any = Lit_6; var p__5 any = /*line :16:1*/lang.IFn_Cast(program__1).Invoke_O_O_O__O(jrt.File_New_String(Lit_7), goroot__4, A_arbace_box_print_A_const_13);











	lang.IFn_Cast(print_module__2).Invoke_O_O_O_O__O(p__5, jrt.File_New_String(Lit_7), jrt.File_New_String(Lit_8), A_arbace_box_print_A_const_14); var p__5_2 any = /*line :16:1*/lang.IFn_Cast(program__1).Invoke_O_O_O__O(jrt.File_New_String(Lit_9), goroot__4, A_arbace_box_print_A_const_15);













	lang.IFn_Cast(print_module__2).Invoke_O_O_O_O__O(p__5_2, jrt.File_New_String(Lit_9), jrt.File_New_String(Lit_10), A_arbace_box_print_A_const_16);
	lang.IFn_Cast(print_package__3).Invoke_O_O_O__O(Lit_11, Lit_12, A_arbace_box_print_A_const_17); return /*line :32:1*/ lang.IFn_Cast(print_package__3).Invoke_O_O_O__O(Lit_13, Lit_14, A_arbace_box_print_A_const_18) }

func A_arbace_box_print_print_program_A_New() *A_arbace_box_print_print_program_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_print_program_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_box_print_print_program_A) Ctor() {}
//line :34:1
func (t *A_arbace_box_print_print_program_A) Invoke_O__O(self any) any { var program__1 any; var root_36 any = A_arbace_box_print_A_const_9.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, A_arbace_box_print_tool_A_fn_class); var ifn_38 lang.IFn; if





	linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = A_arbace_box_print_A_const_19; if linked_37 == nil { program__1 = ifn_38.Invoke_O__O(arg_39) } else { program__1 = linked_37.(*A_arbace_box_print_tool_A).Invoke_O_O__O(root_36, arg_39) }; var print_module__2 any; var root_40 any = /*line :34:1*/A_arbace_box_print_A_const_9.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_40, A_arbace_box_print_tool_A_fn_class); var ifn_42 lang.IFn; if






	linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = A_arbace_box_print_A_const_20; if linked_41 == nil { print_module__2 = ifn_42.Invoke_O__O(arg_43) } else { print_module__2 = linked_41.(*A_arbace_box_print_tool_A).Invoke_O_O__O(root_40, arg_43) }; var opts__3 any = A_arbace_box_print_A_const_21; var p__4 any = /*line :34:1*/lang.IFn_Cast(program__1).Invoke_O_O_O__O(jrt.File_New_String(Lit_15), Lit_6, opts__3);









	lang.IFn_Cast(print_module__2).Invoke_O_O_O_O__O(p__4, jrt.File_New_String(Lit_15), jrt.File_New_String(Lit_16), opts__3); var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_box_print_A_const_22.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_print_A_const_23.GetRawRoot__O()); var tmp3 any; var tmp4 *lang.Keyword = A_arbace_box_print_A_const_24; var tmp5 *lang.Keyword = A_arbace_box_print_A_const_25; var or__1927000174__auto____5 any = tmp4.Invoke_O__O(tmp5.Invoke_O__O(A_arbace_box_print_A_const_26.Invoke_O__O(p__4))); if jrt.J2g_Truth(or__1927000174__auto____5) { tmp3 = or__1927000174__auto____5 } else { tmp3 = lang.PersistentArrayMap_EMPTY.Ref() }; return tmp1.Invoke_O_O__O(Lit_17, tmp2.Invoke_O__O(tmp3)) }

func A_arbace_box_print__main_A_New() *A_arbace_box_print__main_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print__main_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_box_print__main_A) Ctor() {}
//line :47:1
func (t *A_arbace_box_print__main_A) DoInvoke_O_O__O(self, p__1463000015__0 any) any { var vec__1463000016__2 any = p__1463000015__0; var cmd__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1463000016__2, lang.RT_IntCast_J__I_NoInit(0), nil); var G__1463000019__4_ any = cmd__3; L1:
switch { default: switch lang.Util_Hash_O__I_NoInit(G__1463000019__4_) >> 1 & 1 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1463000019__4_, Lit_1) {

	var root_54 any = A_arbace_box_print_A_const_27.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, A_arbace_box_print_print_program_A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; if linked_55 == nil { ifn_56.Invoke__O() } else { linked_55.(*A_arbace_box_print_print_program_A).Invoke_O__O(root_54) }
//line :48:1
	break L1 }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1463000019__4_, Lit_2) {
		var root_57 any = A_arbace_box_print_A_const_28.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, A_arbace_box_print_print_goroot_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; if linked_58 == nil { ifn_59.Invoke__O() } else { linked_58.(*A_arbace_box_print_print_goroot_A).Invoke_O__O(root_57) }
//line :48:1
		break L1 }; default:
}

	var root_76 any = A_arbace_box_print_A_const_32.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_print_A_const_33.GetRawRoot__O()); var tmp2 any = A_arbace_box_print_A_const_34; var arg_79 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_box_print_A_const_35.Get__O()); if linked_77 == nil { ifn_78.Invoke_O__O(arg_79) } else { linked_77.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_76, arg_79) }; var tmp3 any = A_arbace_box_print__main_fn__1463000020_A_New(); var tmp4 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_box_print__main_fn__1463000020_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_box_print__main_fn__1463000020_A_fn_class = fncls__70d; tmp4 = fncls__70d } else { tmp4 = fncls__70 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2))}; var root_60 any =
	A_arbace_box_print_A_const_29.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_62 lang.IFn; if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; if linked_61 == nil { ifn_62.Invoke__O() } else { linked_61.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_60) };
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(0)); return nil }
//line :51:1
func A_arbace_box_print__main_fn__1463000020_A_New() *A_arbace_box_print__main_fn__1463000020_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print__main_fn__1463000020_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_box_print__main_fn__1463000020_A) Ctor() {}
//line :51:1
func (t *A_arbace_box_print__main_fn__1463000020_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_box_print_A_const_30.GetRawRoot__O()).Invoke_O__O(Lit_4); return nil }(); var root_67 any = A_arbace_box_print_A_const_31.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_69 lang.IFn; if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; if linked_68 == nil { ifn_69.Invoke__O() } else { linked_68.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_67) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }









type A_arbace_box_print_A struct{ jrt.Object }

var A_arbace_box_print_A_const_pool *jrt.RefArray

var A_arbace_box_print_A_const_0 *lang.Var

var A_arbace_box_print_A_const_1 any

var A_arbace_box_print_A_const_2 *lang.Var

var A_arbace_box_print_A_const_3 *lang.Var

var A_arbace_box_print_A_const_4 *lang.Var

var A_arbace_box_print_A_const_5 *lang.Var

var A_arbace_box_print_A_const_6 any

var A_arbace_box_print_A_const_7 *lang.Var

var A_arbace_box_print_A_const_8 *lang.Var

var A_arbace_box_print_A_const_9 *lang.Var

var A_arbace_box_print_A_const_10 any

var A_arbace_box_print_A_const_11 any

var A_arbace_box_print_A_const_12 any

var A_arbace_box_print_A_const_13 any

var A_arbace_box_print_A_const_14 any

var A_arbace_box_print_A_const_15 any

var A_arbace_box_print_A_const_16 any

var A_arbace_box_print_A_const_17 any

var A_arbace_box_print_A_const_18 any

var A_arbace_box_print_A_const_19 any

var A_arbace_box_print_A_const_20 any

var A_arbace_box_print_A_const_21 any

var A_arbace_box_print_A_const_22 *lang.Var

var A_arbace_box_print_A_const_23 *lang.Var

var A_arbace_box_print_A_const_24 *lang.Keyword

var A_arbace_box_print_A_const_25 *lang.Keyword

var A_arbace_box_print_A_const_26 *lang.Keyword

var A_arbace_box_print_A_const_27 *lang.Var

var A_arbace_box_print_A_const_28 *lang.Var

var A_arbace_box_print_A_const_29 *lang.Var

var A_arbace_box_print_A_const_30 *lang.Var

var A_arbace_box_print_A_const_31 *lang.Var

var A_arbace_box_print_A_const_32 *lang.Var

var A_arbace_box_print_A_const_33 *lang.Var

var A_arbace_box_print_A_const_34 *lang.Var

var A_arbace_box_print_A_const_35 *lang.Var

var A_arbace_box_print_A_init jrt.ClassInit

func A_arbace_box_print_A_Init() { if !A_arbace_box_print_A_init.Done() { A_arbace_box_print_A_init.Run(A_arbace_box_print_A_clinit) } }

func A_arbace_box_print_A_clinit() { A_arbace_box_print_A_clinit_p0(); A_arbace_box_print_A_clinit_p1(); A_arbace_box_print_A_clinit_p2() }

func A_arbace_box_print_A_clinit_p0() { jrt.StartCheck(); A_arbace_box_print_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 54); A_arbace_box_print_A_const_0 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[18]); A_arbace_box_print_A_const_1 = A_arbace_box_print_A_const_pool.A[19]; A_arbace_box_print_A_const_2 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[20]); A_arbace_box_print_A_const_3 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[21]); A_arbace_box_print_A_const_4 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[22]); A_arbace_box_print_A_const_5 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[23]); A_arbace_box_print_A_const_6 = A_arbace_box_print_A_const_pool.A[24]; A_arbace_box_print_A_const_7 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[25]); A_arbace_box_print_A_const_8 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[26]); A_arbace_box_print_A_const_9 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[27]); A_arbace_box_print_A_const_10 = A_arbace_box_print_A_const_pool.A[28]; A_arbace_box_print_A_const_11 = A_arbace_box_print_A_const_pool.A[29] }

func A_arbace_box_print_A_clinit_p1() { A_arbace_box_print_A_const_12 = A_arbace_box_print_A_const_pool.A[30]; A_arbace_box_print_A_const_13 = A_arbace_box_print_A_const_pool.A[31]; A_arbace_box_print_A_const_14 = A_arbace_box_print_A_const_pool.A[32]; A_arbace_box_print_A_const_15 = A_arbace_box_print_A_const_pool.A[33]; A_arbace_box_print_A_const_16 = A_arbace_box_print_A_const_pool.A[34]; A_arbace_box_print_A_const_17 = A_arbace_box_print_A_const_pool.A[35]; A_arbace_box_print_A_const_18 = A_arbace_box_print_A_const_pool.A[36]; A_arbace_box_print_A_const_19 = A_arbace_box_print_A_const_pool.A[37]; A_arbace_box_print_A_const_20 = A_arbace_box_print_A_const_pool.A[38]; A_arbace_box_print_A_const_21 = A_arbace_box_print_A_const_pool.A[39]; A_arbace_box_print_A_const_22 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[40]); A_arbace_box_print_A_const_23 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[41]); A_arbace_box_print_A_const_24 = lang.Keyword_Cast(A_arbace_box_print_A_const_pool.A[42]); A_arbace_box_print_A_const_25 = lang.Keyword_Cast(A_arbace_box_print_A_const_pool.A[43]) }

func A_arbace_box_print_A_clinit_p2() { A_arbace_box_print_A_const_26 = lang.Keyword_Cast(A_arbace_box_print_A_const_pool.A[44]); A_arbace_box_print_A_const_27 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[45]); A_arbace_box_print_A_const_28 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[46]); A_arbace_box_print_A_const_29 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[47]); A_arbace_box_print_A_const_30 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[48]); A_arbace_box_print_A_const_31 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[49]); A_arbace_box_print_A_const_32 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[50]); A_arbace_box_print_A_const_33 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[51]); A_arbace_box_print_A_const_34 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[52]); A_arbace_box_print_A_const_35 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[53]) }

func A_arbace_box_print_A_New() *A_arbace_box_print_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_A{}; t.Ctor(); return t }

func (t *A_arbace_box_print_A) Ctor() {}

func (t *A_arbace_box_print_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_print_A) GetClass__Class() *jrt.Class { return A_arbace_box_print_A_class }

func (t *A_arbace_box_print_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_print_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_print_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_print_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_print_A); return ok }

func A_arbace_box_print_A_Cast(x any) *A_arbace_box_print_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_print_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_print_A_class)) }; return v }



type A_arbace_box_print__main_A struct{ j2g_header uint64 }

var A_arbace_box_print__main_A_fn_class *jrt.Class



type A_arbace_box_print__main_fn__1463000020_A struct{ j2g_header uint64 }

var A_arbace_box_print__main_fn__1463000020_A_fn_class *jrt.Class



type A_arbace_box_print_eval1463000004_A struct{ jrt.Object }

func A_arbace_box_print_eval1463000004_A_New() *A_arbace_box_print_eval1463000004_A { t := &A_arbace_box_print_eval1463000004_A{}; t.Ctor(); return t }

func (t *A_arbace_box_print_eval1463000004_A) Ctor() {}

func (t *A_arbace_box_print_eval1463000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_print_eval1463000004_A) GetClass__Class() *jrt.Class { return A_arbace_box_print_eval1463000004_A_class }

func (t *A_arbace_box_print_eval1463000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_print_eval1463000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_print_eval1463000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_print_eval1463000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_print_eval1463000004_A); return ok }

func A_arbace_box_print_eval1463000004_A_Cast(x any) *A_arbace_box_print_eval1463000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_print_eval1463000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_print_eval1463000004_A_class)) }; return v }



type A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A struct{ j2g_header uint64 }

var A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_fn_class *jrt.Class



type A_arbace_box_print_eval1463000008_A struct{ jrt.Object }

func A_arbace_box_print_eval1463000008_A_New() *A_arbace_box_print_eval1463000008_A { t := &A_arbace_box_print_eval1463000008_A{}; t.Ctor(); return t }

func (t *A_arbace_box_print_eval1463000008_A) Ctor() {}

func (t *A_arbace_box_print_eval1463000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_print_eval1463000008_A) GetClass__Class() *jrt.Class { return A_arbace_box_print_eval1463000008_A_class }

func (t *A_arbace_box_print_eval1463000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_print_eval1463000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_print_eval1463000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_print_eval1463000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_print_eval1463000008_A); return ok }

func A_arbace_box_print_eval1463000008_A_Cast(x any) *A_arbace_box_print_eval1463000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_print_eval1463000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_print_eval1463000008_A_class)) }; return v }



type A_arbace_box_print_eval1463000008_fn__1463000009_A struct{ j2g_header uint64 }

var A_arbace_box_print_eval1463000008_fn__1463000009_A_fn_class *jrt.Class



type A_arbace_box_print_print_goroot_A struct{ j2g_header uint64 }

var A_arbace_box_print_print_goroot_A_fn_class *jrt.Class



type A_arbace_box_print_print_program_A struct{ j2g_header uint64 }

var A_arbace_box_print_print_program_A_fn_class *jrt.Class



type A_arbace_box_print_tool_A struct{ j2g_header uint64 }

var A_arbace_box_print_tool_A_fn_class *jrt.Class
