//line aot_arbace_j2g_names.ae:1
package aot_arbace_j2g_names

import (
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A_New() *A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_names_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_names_A_const_4); tmp2 = lang.IFn_Cast(A_arbace_j2g_names_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_names_A_const_1, A_arbace_j2g_names_A_const_2); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_names_eval1768000008_fn__1768000009_A_New() *A_arbace_j2g_names_eval1768000008_fn__1768000009_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_eval1768000008_fn__1768000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_names_eval1768000008_fn__1768000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_names_eval1768000008_fn__1768000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_names_A_const_5.GetRawRoot__O()); var tmp2 any; var root_16 any = A_arbace_j2g_names_A_const_6.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = A_arbace_j2g_names_A_const_7; if linked_17 == nil { tmp2 = ifn_18.Invoke_O__O(arg_19) } else { tmp2 = linked_17.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_16, arg_19) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_names_A_const_8.GetRawRoot__O(), A_arbace_j2g_names_A_const_9) }















func A_arbace_j2g_names_top_of_A_New() *A_arbace_j2g_names_top_of_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_top_of_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_j2g_names_top_of_A) Ctor() {}
//line :17:1
func (t *A_arbace_j2g_names_top_of_A) Invoke_O_O__O(self, n__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_11); if lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return n__0 } else { var root_20 any = A_arbace_j2g_names_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = n__0; var arg_24 any = A_arbace_j2g_names_A_const_11; var arg_25 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_21 == nil { return ifn_22.Invoke_O_O_O__O(arg_23, arg_24, arg_25) } else { return linked_21.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_20, arg_23, arg_24, arg_25) } } }

func A_arbace_j2g_names_pkg_of_A_New() *A_arbace_j2g_names_pkg_of_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_pkg_of_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_j2g_names_pkg_of_A) Ctor() {}
//line :19:1
func (t *A_arbace_j2g_names_pkg_of_A) Invoke_O_O__O(self, internal__0 any) any {






	var tmp1 any; var or__1927000174__auto____2 any; var root_26 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_28 lang.IFn
	if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = internal__0; var arg_30 any = Lit_27; if linked_27 == nil { or__1927000174__auto____2 = ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { or__1927000174__auto____2 = linked_27.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_26, arg_29, arg_30) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_31 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = internal__0; var arg_35 any = Lit_28; if linked_32 == nil { or__1927000174__auto____3 = ifn_33.Invoke_O_O__O(arg_34, arg_35) } else { or__1927000174__auto____3 = linked_32.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_31, arg_34, arg_35) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var root_36 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_38 lang.IFn
		if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = internal__0; var arg_40 any = Lit_29; if linked_37 == nil { or__1927000174__auto____4 = ifn_38.Invoke_O_O__O(arg_39, arg_40) } else { or__1927000174__auto____4 = linked_37.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_36, arg_39, arg_40) }
//line :27:1
		if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { var or__1927000174__auto____5 any; var root_41 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_43 lang.IFn
			if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = internal__0; var arg_45 any = Lit_30; if linked_42 == nil { or__1927000174__auto____5 = ifn_43.Invoke_O_O__O(arg_44, arg_45) } else { or__1927000174__auto____5 = linked_42.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_41, arg_44, arg_45) }
//line :27:1
			if jrt.J2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any; var root_46 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_48 lang.IFn

				if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = internal__0; var arg_50 any = Lit_31; if linked_47 == nil { or__1927000174__auto____6 = ifn_48.Invoke_O_O__O(arg_49, arg_50) } else { or__1927000174__auto____6 = linked_47.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_46, arg_49, arg_50) }
//line :27:1
				if jrt.J2g_Truth(or__1927000174__auto____6) { tmp1 = or__1927000174__auto____6 } else { var or__1927000174__auto____7 any; var root_51 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_53 lang.IFn

					if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = internal__0; var arg_55 any = Lit_32; if linked_52 == nil { or__1927000174__auto____7 = ifn_53.Invoke_O_O__O(arg_54, arg_55) } else { or__1927000174__auto____7 = linked_52.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_51, arg_54, arg_55) }
//line :27:1
					if jrt.J2g_Truth(or__1927000174__auto____7) { tmp1 = or__1927000174__auto____7 } else { var or__1927000174__auto____8 any; var root_56 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_58 lang.IFn


						if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = internal__0; var arg_60 any = Lit_33; if linked_57 == nil { or__1927000174__auto____8 = ifn_58.Invoke_O_O__O(arg_59, arg_60) } else { or__1927000174__auto____8 = linked_57.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_56, arg_59, arg_60) }
//line :27:1
						if jrt.J2g_Truth(or__1927000174__auto____8) { tmp1 = or__1927000174__auto____8 } else { var or__1927000174__auto____9 any; var root_61 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_63 lang.IFn


							if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = internal__0; var arg_65 any = Lit_34; if linked_62 == nil { or__1927000174__auto____9 = ifn_63.Invoke_O_O__O(arg_64, arg_65) } else { or__1927000174__auto____9 = linked_62.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_61, arg_64, arg_65) }
//line :27:1
							if jrt.J2g_Truth(or__1927000174__auto____9) { tmp1 = or__1927000174__auto____9 } else { var or__1927000174__auto____10 any; var root_66 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_68 lang.IFn



								if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = internal__0; var arg_70 any = Lit_35; if linked_67 == nil { or__1927000174__auto____10 = ifn_68.Invoke_O_O__O(arg_69, arg_70) } else { or__1927000174__auto____10 = linked_67.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_66, arg_69, arg_70) }
//line :27:1
								if jrt.J2g_Truth(or__1927000174__auto____10) { tmp1 = or__1927000174__auto____10 } else {



									var root_71 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_73 lang.IFn; if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = internal__0; var arg_75 any = Lit_36; if linked_72 == nil { tmp1 = ifn_73.Invoke_O_O__O(arg_74, arg_75) } else { tmp1 = linked_72.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_71, arg_74, arg_75) } } } } } } } } } }
//line :26:1
	if jrt.J2g_Truth(tmp1) { return A_arbace_j2g_names_A_const_13 } else { if A_arbace_j2g_names_A_const_14 != nil { var temp__1927000408__auto____2 any; var tmp2 any; var root_76 any = A_arbace_j2g_names_A_const_6.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_78 lang.IFn





		if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = A_arbace_j2g_names_A_const_15.GetRawRoot__O(); if linked_77 == nil { tmp2 = ifn_78.Invoke_O__O(arg_79) } else { tmp2 = linked_77.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_76, arg_79) }; var tmp3 any = tmp2; var tmp4 any; var root_80 any = A_arbace_j2g_names_A_const_16.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, A_arbace_j2g_names_top_of_A_fn_class); var ifn_82 lang.IFn; if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = internal__0; if linked_81 == nil { tmp4 = ifn_82.Invoke_O__O(arg_83) } else { tmp4 = linked_81.(*A_arbace_j2g_names_top_of_A).Invoke_O_O__O(root_80, arg_83) }; temp__1927000408__auto____2 = lang.RT_Get_O_O__O_NoInit(tmp3, tmp4); if jrt.J2g_Truth(temp__1927000408__auto____2) { var p__3 any = temp__1927000408__auto____2; var root_84 any = A_arbace_j2g_names_A_const_17.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = p__3; if linked_85 == nil { return ifn_86.Invoke_O__O(arg_87) } else { return linked_85.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_84, arg_87) } } else { return A_arbace_j2g_names_A_const_18 } } else {
//line :26:1
			return nil
		}
	}
}




func A_arbace_j2g_names_compiled_pkg_QMARK__A_New() *A_arbace_j2g_names_compiled_pkg_QMARK__A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_compiled_pkg_QMARK__A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_j2g_names_compiled_pkg_QMARK__A) Ctor() {}
//line :34:1
func (t *A_arbace_j2g_names_compiled_pkg_QMARK__A) Invoke_O_O__O(self, pkg__0 any) any { var root_88 any = A_arbace_j2g_names_A_const_19.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_90 lang.IFn; if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any = lang.IFn_Cast(A_arbace_j2g_names_A_const_20).Invoke_O__O(pkg__0); if linked_89 == nil { return ifn_90.Invoke_O__O(arg_91) } else { return linked_89.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_88, arg_91) } }

func A_arbace_j2g_names_pkg_name_A_New() *A_arbace_j2g_names_pkg_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_pkg_name_A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_j2g_names_pkg_name_A) Ctor() {}
//line :36:1
func (t *A_arbace_j2g_names_pkg_name_A) Invoke_O_O__O(self, pkg__0 any) any { var root_92 any = A_arbace_j2g_names_A_const_21.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = pkg__0; if linked_93 == nil { return ifn_94.Invoke_O__O(arg_95) } else { return linked_93.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_92, arg_95) } }
func A_arbace_j2g_names_pkg_path_A_New() *A_arbace_j2g_names_pkg_path_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_pkg_path_A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_j2g_names_pkg_path_A) Ctor() {}
//line :37:1
func (t *A_arbace_j2g_names_pkg_path_A) Invoke_O_O__O(self, pkg__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_1, nil); var tmp2 any; var root_96 any = A_arbace_j2g_names_A_const_21.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = pkg__0; if linked_97 == nil { tmp2 = ifn_98.Invoke_O__O(arg_99) } else { tmp2 = linked_97.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_96, arg_99) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }
func A_arbace_j2g_names_pkg_ns_A_New() *A_arbace_j2g_names_pkg_ns_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_pkg_ns_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_j2g_names_pkg_ns_A) Ctor() {}
//line :38:1
func (t *A_arbace_j2g_names_pkg_ns_A) Invoke_O_O__O(self, pkg__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_26, nil); var tmp2 any; var root_100 any = A_arbace_j2g_names_A_const_21.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = pkg__0; if linked_101 == nil { tmp2 = ifn_102.Invoke_O__O(arg_103) } else { tmp2 = linked_101.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_100, arg_103) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }



















func A_arbace_j2g_names_memo_str_A_New() *A_arbace_j2g_names_memo_str_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_memo_str_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_j2g_names_memo_str_A) Ctor() {}
//line :58:1
func (t *A_arbace_j2g_names_memo_str_A) Invoke_O_O__O(self, f__0 any) any { var cache__2 any = jrt.ConcurrentHashMap_New(); var tmp1 any = A_arbace_j2g_names_memo_str_fn__1768000018_A_New_O_O(cache__2, f__0); var tmp2 *jrt.Class; var fncls__104 *jrt.Class = A_arbace_j2g_names_memo_str_fn__1768000018_A_fn_class; if




	fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_j2g_names_memo_str_fn__1768000018_A_fn_class = fncls__104d; tmp2 = fncls__104d } else { tmp2 = fncls__104 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :63:1
func A_arbace_j2g_names_memo_str_fn__1768000018_A_New_O_O(p0, p1 any) *A_arbace_j2g_names_memo_str_fn__1768000018_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_memo_str_fn__1768000018_A{}; t.Ctor_O_O(p0, p1); return t }
//line :63:1
func (t *A_arbace_j2g_names_memo_str_fn__1768000018_A) Ctor_O_O(c__cache, c__f any) { t.F_cache = c__cache; t.F_f = c__f }
//line :63:1
func (t *A_arbace_j2g_names_memo_str_fn__1768000018_A) Invoke_O_O__O(self, k__1 any) any { var or__1927000174__auto____2 any = jrt.NN(jrt.ConcurrentHashMap_Cast(t.F_cache)).Get_O__O(k__1); if
												jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var v__3 any = lang.IFn_Cast(t.F_f).Invoke_O__O(k__1)

		jrt.NN(jrt.ConcurrentHashMap_Cast(t.F_cache)).Put_O_O__O(k__1, v__3)
//line :64:1
		return v__3 } }






func A_arbace_j2g_names_fn__1768000021_A_New() *A_arbace_j2g_names_fn__1768000021_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_fn__1768000021_A{}; t.Ctor(); return t }
//line :71:1
func (t *A_arbace_j2g_names_fn__1768000021_A) Ctor() {}
//line :71:1
func (t *A_arbace_j2g_names_fn__1768000021_A) Invoke_O_O__O(self, s__0 any) any { var m__2 any; var root_105 any = A_arbace_j2g_names_A_const_22.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_107 lang.IFn; if
										linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any; var root_111 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any; var root_115 any = A_arbace_j2g_names_A_const_24.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_munge_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = s__0; if linked_116 == nil { arg_114 = ifn_117.Invoke_O__O(arg_118) } else { arg_114 = linked_116.(*aot_arbace_core.A_arbace_core_munge_A).Invoke_O_O__O(root_115, arg_118) }; if linked_112 == nil { arg_108 = ifn_113.Invoke_O__O(arg_114) } else { arg_108 = linked_112.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_111, arg_114) }; var arg_109 any = Lit_11; var arg_110 any = Lit_7; if linked_106 == nil { m__2 = ifn_107.Invoke_O_O_O__O(arg_108, arg_109, arg_110) } else { m__2 = linked_106.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_105, arg_108, arg_109, arg_110) }; var root_119 any =


	A_arbace_j2g_names_A_const_25.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var arg_123 any; var root_124 any = A_arbace_j2g_names_A_const_26.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any; var tmp1 any = A_arbace_j2g_names_fn__1768000021_fn__1768000022_A_New(); var tmp2 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_j2g_names_fn__1768000021_fn__1768000022_A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_j2g_names_fn__1768000021_fn__1768000022_A_fn_class = fncls__129d; tmp2 = fncls__129d } else { tmp2 = fncls__129 }; arg_127 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_128 any = m__2; if linked_125 == nil { arg_123 = ifn_126.Invoke_O_O__O(arg_127, arg_128) } else { arg_123 = linked_125.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_124, arg_127, arg_128) }; if linked_120 == nil { return ifn_121.Invoke_O_O__O(arg_122, arg_123) } else { return linked_120.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_119, arg_122, arg_123) } }
//line :75:1
func A_arbace_j2g_names_fn__1768000021_fn__1768000022_A_New() *A_arbace_j2g_names_fn__1768000021_fn__1768000022_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_fn__1768000021_fn__1768000022_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_j2g_names_fn__1768000021_fn__1768000022_A) Ctor() {}
//line :75:1
func (t *A_arbace_j2g_names_fn__1768000021_fn__1768000022_A) Invoke_O_O__O(self, c__1 any) any { var tmp1 bool; var or__1927000174__auto____2 bool = jrt.Character_IsLetterOrDigit_C__Z_NoInit(lang.RT_CharCast_O__C_NoInit(c__1)); if or__1927000174__auto____2 { tmp1 = or__1927000174__auto____2 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(c__1, A_arbace_j2g_names_A_const_27) }; if tmp1 { return c__1 } else { return A_arbace_j2g_names_A_const_27 } }

func A_arbace_j2g_names_munge_name_A_New() *A_arbace_j2g_names_munge_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_munge_name_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_j2g_names_munge_name_A) Ctor() {}
//line :77:1
func (t *A_arbace_j2g_names_munge_name_A) Invoke_O_O__O(self, s__0 any) any {


	var root_130 any = A_arbace_j2g_names_A_const_28.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, A_arbace_j2g_names_memo_str_fn__1768000018_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any; var root_134 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = s__0; if linked_135 == nil { arg_133 = ifn_136.Invoke_O__O(arg_137) } else { arg_133 = linked_135.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_134, arg_137) }; if linked_131 == nil { return ifn_132.Invoke_O__O(arg_133) } else { return linked_131.(*A_arbace_j2g_names_memo_str_fn__1768000018_A).Invoke_O_O__O(root_130, arg_133)
	} }
func A_arbace_j2g_names_local_name_A_New() *A_arbace_j2g_names_local_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_local_name_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_j2g_names_local_name_A) Ctor() {}
//line :82:1
func (t *A_arbace_j2g_names_local_name_A) Invoke_O_O__O(self, sym__0 any) any { var s__2 any; var root_138 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_140 lang.IFn; if




	linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any; var root_142 any = A_arbace_j2g_names_A_const_21.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = sym__0; if linked_143 == nil { arg_141 = ifn_144.Invoke_O__O(arg_145) } else { arg_141 = linked_143.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_142, arg_145) }; if linked_139 == nil { s__2 = ifn_140.Invoke_O__O(arg_141) } else { s__2 = linked_139.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_138, arg_141) }; var s__3 any; var tmp1 any; var root_146 any = /*line :82:1*/A_arbace_j2g_names_A_const_30.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_string.A_arbace_string_blank_QMARK__A_fn_class); var ifn_148 lang.IFn; if





	linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = s__2; if linked_147 == nil { tmp1 = ifn_148.Invoke_O__O(arg_149) } else { tmp1 = linked_147.(*aot_arbace_string.A_arbace_string_blank_QMARK__A).Invoke_O_O__O(root_146, arg_149) }; if jrt.J2g_Truth(tmp1) { s__3 = Lit_19 } else { s__3 = s__2 }; var tmp2 any; var or__1927000174__auto____4 any =
	lang.IFn_Cast(A_arbace_j2g_names_A_const_31.GetRawRoot__O()).Invoke_O__O(s__3); if jrt.J2g_Truth(or__1927000174__auto____4) { tmp2 = or__1927000174__auto____4 } else { var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_j2g_names_A_const_32.GetRawRoot__O()).Invoke_O__O(s__3); if jrt.J2g_Truth(or__1927000174__auto____5) { tmp2 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_j2g_names_A_const_33.GetRawRoot__O()).Invoke_O__O(s__3); if jrt.J2g_Truth(or__1927000174__auto____6) { tmp2 = or__1927000174__auto____6 } else { var or__1927000174__auto____7 bool = jrt.Character_IsUpperCase_C__Z_NoInit(jrt.NN(jrt.String_Cast(s__3)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0))); if or__1927000174__auto____7 { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var or__1927000174__auto____8 any; var root_150 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_152 lang.IFn

		if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = s__3; var arg_154 any = Lit_20; if linked_151 == nil { or__1927000174__auto____8 = ifn_152.Invoke_O_O__O(arg_153, arg_154) } else { or__1927000174__auto____8 = linked_151.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_150, arg_153, arg_154) }
//line :89:1
		if jrt.J2g_Truth(or__1927000174__auto____8) { tmp2 = or__1927000174__auto____8 } else { var or__1927000174__auto____9 any; var root_155 any = A_arbace_j2g_names_A_const_34.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_157 lang.IFn

			if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = A_arbace_j2g_names_A_const_35; var arg_159 any = s__3; if linked_156 == nil { or__1927000174__auto____9 = ifn_157.Invoke_O_O__O(arg_158, arg_159) } else { or__1927000174__auto____9 = linked_156.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_155, arg_158, arg_159) }
//line :89:1
			if jrt.J2g_Truth(or__1927000174__auto____9) { tmp2 = or__1927000174__auto____9 } else {

				var root_160 any = A_arbace_j2g_names_A_const_34.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = A_arbace_j2g_names_A_const_36; var arg_164 any = s__3; if linked_161 == nil { tmp2 = ifn_162.Invoke_O_O__O(arg_163, arg_164) } else { tmp2 = linked_161.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_160, arg_163, arg_164) } } } } } } }; if /*line :89:1*/ jrt.J2g_Truth(tmp2) {


					return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, s__3, nil)).Ref() } else {
//line :89:1
						return s__3 } }











































func A_arbace_j2g_names_compiled_class_QMARK__A_New() *A_arbace_j2g_names_compiled_class_QMARK__A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_compiled_class_QMARK__A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_j2g_names_compiled_class_QMARK__A) Ctor() {}
//line :133:1
func (t *A_arbace_j2g_names_compiled_class_QMARK__A) Invoke_O_O__O(self, internal__0 any) any { var or__1927000174__auto____2 any; var and__1927000168__auto____2 any; var root_165 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_167 lang.IFn; if





	linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = internal__0; var arg_169 any = Lit_1; if linked_166 == nil { and__1927000168__auto____2 = ifn_167.Invoke_O_O__O(arg_168, arg_169) } else { and__1927000168__auto____2 = linked_166.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_165, arg_168, arg_169) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_170 any = A_arbace_j2g_names_A_const_19.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any; var root_174 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = internal__0; var arg_178 any = Lit_2; if linked_175 == nil { arg_173 = ifn_176.Invoke_O_O__O(arg_177, arg_178) } else { arg_173 = linked_175.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_174, arg_177, arg_178) }; if linked_171 == nil { and__1927000168__auto____3 = ifn_172.Invoke_O__O(arg_173) } else { and__1927000168__auto____3 = linked_171.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_170, arg_173) }; if jrt.J2g_Truth(and__1927000168__auto____3) {
		var root_179 any = A_arbace_j2g_names_A_const_19.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_181 lang.IFn; if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any; var root_183 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_183, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_185 lang.IFn; if linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any = internal__0; var arg_187 any = Lit_3; if linked_184 == nil { arg_182 = ifn_185.Invoke_O_O__O(arg_186, arg_187) } else { arg_182 = linked_184.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_183, arg_186, arg_187) }; if linked_180 == nil { or__1927000174__auto____2 = ifn_181.Invoke_O__O(arg_182) } else { or__1927000174__auto____2 = linked_180.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_179, arg_182) } } else {
//line :139:1
			or__1927000174__auto____2 = and__1927000168__auto____3 } } else { or__1927000174__auto____2 = and__1927000168__auto____2 }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var temp__1927000414__auto____3 any; var tmp1 any; var root_188 any = A_arbace_j2g_names_A_const_6.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_190 lang.IFn

				if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = A_arbace_j2g_names_A_const_15.GetRawRoot__O(); if linked_189 == nil { tmp1 = ifn_190.Invoke_O__O(arg_191) } else { tmp1 = linked_189.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_188, arg_191) }; var tmp2 any = tmp1; var tmp3 any; var root_192 any = A_arbace_j2g_names_A_const_16.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, A_arbace_j2g_names_top_of_A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = internal__0; if linked_193 == nil { tmp3 = ifn_194.Invoke_O__O(arg_195) } else { tmp3 = linked_193.(*A_arbace_j2g_names_top_of_A).Invoke_O_O__O(root_192, arg_195) }; temp__1927000414__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp2, tmp3); if jrt.J2g_Truth(temp__1927000414__auto____3) { var p__4 any = temp__1927000414__auto____3; var root_196 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_198 lang.IFn
					if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = p__4; var arg_200 any = Lit_4; if linked_197 == nil { return ifn_198.Invoke_O_O__O(arg_199, arg_200) } else { return linked_197.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_196, arg_199, arg_200) } } else {
//line :141:1
						return nil } } }




























func A_arbace_j2g_names_qualified_QMARK__A_New() *A_arbace_j2g_names_qualified_QMARK__A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_qualified_QMARK__A{}; t.Ctor(); return t }
//line :170:1
func (t *A_arbace_j2g_names_qualified_QMARK__A) Ctor() {}
//line :170:1
func (t *A_arbace_j2g_names_qualified_QMARK__A) Invoke_O_O__O(self, internal__0 any) any {


	var tmp1 any; var or__1927000174__auto____2 any; var root_201 any = A_arbace_j2g_names_A_const_37.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_203 lang.IFn; if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any; var tmp2 any = A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A_New_O(internal__0); var tmp3 *jrt.Class; var fncls__211 *jrt.Class = A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A_fn_class; if fncls__211 == nil { var fncls__211d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A_fn_class = fncls__211d; tmp3 = fncls__211d } else { tmp3 = fncls__211 }; arg_204 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_205 any = A_arbace_j2g_names_A_const_38.GetRawRoot__O(); if linked_202 == nil { or__1927000174__auto____2 = ifn_203.Invoke_O_O__O(arg_204, arg_205) } else { or__1927000174__auto____2 = linked_202.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_201, arg_204, arg_205) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else {
		var root_212 any = A_arbace_j2g_names_A_const_37.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any; var tmp4 any = A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A_New_O(internal__0); var tmp5 *jrt.Class; var fncls__222 *jrt.Class = A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A_fn_class; if fncls__222 == nil { var fncls__222d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A_fn_class = fncls__222d; tmp5 = fncls__222d } else { tmp5 = fncls__222 }; arg_215 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_216 any; var root_223 any = A_arbace_j2g_names_A_const_6.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_225 lang.IFn; if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any = A_arbace_j2g_names_A_const_39.GetRawRoot__O(); if linked_224 == nil { arg_216 = ifn_225.Invoke_O__O(arg_226) } else { arg_216 = linked_224.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_223, arg_226) }; if linked_213 == nil { tmp1 = ifn_214.Invoke_O_O__O(arg_215, arg_216) } else { tmp1 = linked_213.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_212, arg_215, arg_216) } }
//line :173:1
	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() }
//line :173:1
func A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A_New_O(p0 any) *A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A{}; t.Ctor_O(p0); return t }
//line :173:1
func (t *A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A) Ctor_O(c__internal any) { t.F_internal = c__internal }
//line :173:1
func (t *A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A) Invoke_O_O__O(self, p1__1768000028_SHARP___1 any) any { var root_206 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = t.F_internal; var arg_210 any = p1__1768000028_SHARP___1; if linked_207 == nil { return ifn_208.Invoke_O_O__O(arg_209, arg_210) } else { return linked_207.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_206, arg_209, arg_210) } }
func A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A_New_O(p0 any) *A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A{}; t.Ctor_O(p0); return t }
//line :174:1
func (t *A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A) Ctor_O(c__internal any) { t.F_internal = c__internal }
//line :174:1
func (t *A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A) Invoke_O_O__O(self, p1__1768000029_SHARP___1 any) any { var root_217 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = t.F_internal; var arg_221 any = p1__1768000029_SHARP___1; if linked_218 == nil { return ifn_219.Invoke_O_O__O(arg_220, arg_221) } else { return linked_218.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_217, arg_220, arg_221) } }



func A_arbace_j2g_names_go_class_name_A_New() *A_arbace_j2g_names_go_class_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_go_class_name_A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_j2g_names_go_class_name_A) Ctor() {}
//line :178:1
func (t *A_arbace_j2g_names_go_class_name_A) Invoke_O_O__O(self, internal__0 any) any {





	var root_227 any = A_arbace_j2g_names_A_const_40.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, A_arbace_j2g_names_memo_str_fn__1768000018_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = internal__0; if linked_228 == nil { return ifn_229.Invoke_O__O(arg_230) } else { return linked_228.(*A_arbace_j2g_names_memo_str_fn__1768000018_A).Invoke_O_O__O(root_227, arg_230)
	} }
func A_arbace_j2g_names_go_class_name_STAR__STAR__A_New() *A_arbace_j2g_names_go_class_name_STAR__STAR__A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_go_class_name_STAR__STAR__A{}; t.Ctor(); return t }
//line :186:1
func (t *A_arbace_j2g_names_go_class_name_STAR__STAR__A) Ctor() {}
//line :186:1
func (t *A_arbace_j2g_names_go_class_name_STAR__STAR__A) Invoke_O_O__O(self, internal__0 any) any { var or__1927000174__auto____2 any = lang.RT_Get_O_O__O_NoInit(A_arbace_j2g_names_A_const_41.GetRawRoot__O(), internal__0); if
													jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var tmp1 any; var root_231 any = A_arbace_j2g_names_A_const_42.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, A_arbace_j2g_names_qualified_QMARK__A_fn_class); var ifn_233 lang.IFn
														if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = internal__0; if linked_232 == nil { tmp1 = ifn_233.Invoke_O__O(arg_234) } else { tmp1 = linked_232.(*A_arbace_j2g_names_qualified_QMARK__A).Invoke_O_O__O(root_231, arg_234) }; if jrt.J2g_Truth(tmp1) {
															var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_13, nil); var tmp3 any; var root_235 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_237 lang.IFn; if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any; var root_239 any = A_arbace_j2g_names_A_const_22.GetRawRoot__O(); var linked_240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_239, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_241 lang.IFn; if linked_240 == nil { ifn_241 = lang.IFn_Cast(root_239) } else { ifn_241 = nil }; var arg_242 any = internal__0; var arg_243 any = Lit_14; var arg_244 any = Lit_7; if linked_240 == nil { arg_238 = ifn_241.Invoke_O_O_O__O(arg_242, arg_243, arg_244) } else { arg_238 = linked_240.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_239, arg_242, arg_243, arg_244) }; if linked_236 == nil { tmp3 = ifn_237.Invoke_O__O(arg_238) } else { tmp3 = linked_236.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_235, arg_238) }; or__1927000174__auto____3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref() } else {
//line :188:1
				or__1927000174__auto____3 = nil }
//line :187:1
		if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var tmp4 any; var root_245 any = A_arbace_j2g_names_A_const_43.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, A_arbace_j2g_names_compiled_class_QMARK__A_fn_class); var ifn_247 lang.IFn


			if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = internal__0; if linked_246 == nil { tmp4 = ifn_247.Invoke_O__O(arg_248) } else { tmp4 = linked_246.(*A_arbace_j2g_names_compiled_class_QMARK__A).Invoke_O_O__O(root_245, arg_248) }; if jrt.J2g_Truth(tmp4) {

				var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_16); var tmp6 any; var root_249 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any; var root_253 any = A_arbace_j2g_names_A_const_22.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = internal__0; var arg_257 any = Lit_14; var arg_258 any = Lit_7; if linked_254 == nil { arg_252 = ifn_255.Invoke_O_O_O__O(arg_256, arg_257, arg_258) } else { arg_252 = linked_254.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_253, arg_256, arg_257, arg_258) }; if linked_250 == nil { tmp6 = ifn_251.Invoke_O__O(arg_252) } else { tmp6 = linked_250.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_249, arg_252) }; or__1927000174__auto____4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6, nil)).Ref() } else {
//line :190:1
					or__1927000174__auto____4 = nil }
//line :187:1
			if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var s__5 any; var root_259 any = A_arbace_j2g_names_A_const_10.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_259, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_261 lang.IFn





				if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var arg_262 any = internal__0; var arg_263 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(internal__0)).LastIndexOf_String__I(Lit_14)))).Ref(); if linked_260 == nil { s__5 = ifn_261.Invoke_O_O__O(arg_262, arg_263) } else { s__5 = linked_260.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_259, arg_262, arg_263) }
//line :187:1
				var s__6 any; var root_264 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_264, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_266 lang.IFn






				if linked_265 == nil { ifn_266 = lang.IFn_Cast(root_264) } else { ifn_266 = nil }; var arg_267 any = s__5; if linked_265 == nil { s__6 = ifn_266.Invoke_O__O(arg_267) } else { s__6 = linked_265.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_264, arg_267) }
				var tmp7 any; var and__1927000168__auto____7 any; var root_268 any = A_arbace_j2g_names_A_const_44.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_268, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_270 lang.IFn; if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any = s__6; if linked_269 == nil { and__1927000168__auto____7 = ifn_270.Invoke_O__O(arg_271) } else { and__1927000168__auto____7 = linked_269.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_268, arg_271) }; if jrt.J2g_Truth(and__1927000168__auto____7) { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Character_IsUpperCase_C__Z_NoInit(jrt.NN(jrt.String_Cast(s__6)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp7 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp7) { return s__6 } else {

					return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, s__6)).Ref() } } } } }



func A_arbace_j2g_names_capitalize_A_New() *A_arbace_j2g_names_capitalize_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_capitalize_A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_j2g_names_capitalize_A) Ctor() {}
//line :201:1
func (t *A_arbace_j2g_names_capitalize_A) Invoke_O_O__O(self, s__0 any) any {
	var tmp1 any; var root_272 any = A_arbace_j2g_names_A_const_45.GetRawRoot__O(); var linked_273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_272, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_274 lang.IFn; if linked_273 == nil { ifn_274 = lang.IFn_Cast(root_272) } else { ifn_274 = nil }; var arg_275 any = s__0; if linked_273 == nil { tmp1 = ifn_274.Invoke_O__O(arg_275) } else { tmp1 = linked_273.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_272, arg_275) }; if jrt.J2g_Truth(tmp1) { return s__0 } else { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 any = jrt.Character_ValueOf_C__Character_NoInit(jrt.Character_ToUpperCase_C__C_NoInit(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0)))).Ref(); var tmp4 any; var root_276 any = A_arbace_j2g_names_A_const_10.GetRawRoot__O(); var linked_277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_276, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_278 lang.IFn; if linked_277 == nil { ifn_278 = lang.IFn_Cast(root_276) } else { ifn_278 = nil }; var arg_279 any = s__0; var arg_280 any = A_arbace_j2g_names_A_const_46; if linked_277 == nil { tmp4 = ifn_278.Invoke_O_O__O(arg_279, arg_280) } else { tmp4 = linked_277.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_276, arg_279, arg_280) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4)).Ref()
	}
}






func A_arbace_j2g_names_desc_code_A_New() *A_arbace_j2g_names_desc_code_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_desc_code_A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_j2g_names_desc_code_A) Ctor() {}
//line :211:1
func (t *A_arbace_j2g_names_desc_code_A) Invoke_O_O__O(self, d__0 any) any {


	var tmp1 any; var root_281 any = A_arbace_j2g_names_A_const_47.GetRawRoot__O(); var linked_282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_281, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_283 lang.IFn
	if linked_282 == nil { ifn_283 = lang.IFn_Cast(root_281) } else { ifn_283 = nil }; var arg_284 any = d__0; if linked_282 == nil { tmp1 = ifn_283.Invoke_O__O(arg_284) } else { tmp1 = linked_282.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_281, arg_284) }
//line :214:1
	if jrt.J2g_Truth(tmp1) { var n__2 any; var root_285 any = A_arbace_j2g_names_A_const_48.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_classes_types.A_arbace_classes_types_array_dims_A_fn_class); var ifn_287 lang.IFn
		if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = d__0; if linked_286 == nil { n__2 = ifn_287.Invoke_O__O(arg_288) } else { n__2 = linked_286.(*aot_arbace_classes_types.A_arbace_classes_types_array_dims_A).Invoke_O_O__O(root_285, arg_288) }
//line :214:1
		var e__3 any; var root_289 any = A_arbace_j2g_names_A_const_10.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_289, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_291 lang.IFn

		if linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any = d__0; var arg_293 any = n__2; if linked_290 == nil { e__3 = ifn_291.Invoke_O_O__O(arg_292, arg_293) } else { e__3 = linked_290.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_289, arg_292, arg_293) }
		var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 any; var root_294 any = A_arbace_j2g_names_A_const_49.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, A_arbace_j2g_names_desc_code_A_fn_class); var ifn_296 lang.IFn; if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any = e__3; if linked_295 == nil { tmp3 = ifn_296.Invoke_O__O(arg_297) } else { tmp3 = linked_295.(*A_arbace_j2g_names_desc_code_A).Invoke_O_O__O(root_294, arg_297) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, n__2)).Ref() } else {
//line :214:1
			if lang.Util_Equiv_O_O__Z_NoInit(d__0, Lit_8) { return Lit_9 } else { var tmp4 any; var root_298 any = A_arbace_j2g_names_A_const_50.GetRawRoot__O(); var linked_299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_298, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_300 lang.IFn




				if linked_299 == nil { ifn_300 = lang.IFn_Cast(root_298) } else { ifn_300 = nil }; var arg_301 any = d__0; if linked_299 == nil { tmp4 = ifn_300.Invoke_O__O(arg_301) } else { tmp4 = linked_299.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_298, arg_301) }
//line :214:1
				if jrt.J2g_Truth(tmp4) {




					var root_302 any = A_arbace_j2g_names_A_const_51.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, A_arbace_j2g_names_go_class_name_A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any; var root_306 any = A_arbace_j2g_names_A_const_52.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_306, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_308 lang.IFn; if linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any = d__0; if linked_307 == nil { arg_305 = ifn_308.Invoke_O__O(arg_309) } else { arg_305 = linked_307.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_306, arg_309) }; if linked_303 == nil { return ifn_304.Invoke_O__O(arg_305) } else { return linked_303.(*A_arbace_j2g_names_go_class_name_A).Invoke_O_O__O(root_302, arg_305) } } else {
//line :214:1
						if A_arbace_j2g_names_A_const_14 != nil { return d__0 } else { return nil
						}
					}
			}
		}
}




func A_arbace_j2g_names_method_base_A_New() *A_arbace_j2g_names_method_base_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_method_base_A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_j2g_names_method_base_A) Ctor() {}
//line :224:1
func (t *A_arbace_j2g_names_method_base_A) Invoke_O_O_O__O(self, name__0, desc__1 any) any { var c__3 any = A_arbace_j2g_names_A_const_53.GetRawRoot__O(); var k__4 any = lang.Tuple_Create_O_O__IPersistentVector(name__0, desc__1); var or__1927000174__auto____5 any = jrt.NN(jrt.ConcurrentHashMap_Cast(c__3)).Get_O__O(k__4); if




	jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { var v__6 any; var root_310 any = A_arbace_j2g_names_A_const_54.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_310, A_arbace_j2g_names_method_base_STAR__A_fn_class); var ifn_312 lang.IFn
		if linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; var arg_313 any = name__0; var arg_314 any = desc__1; if linked_311 == nil { v__6 = ifn_312.Invoke_O_O__O(arg_313, arg_314) } else { v__6 = linked_311.(*A_arbace_j2g_names_method_base_STAR__A).Invoke_O_O_O__O(root_310, arg_313, arg_314) }
		jrt.NN(jrt.ConcurrentHashMap_Cast(c__3)).Put_O_O__O(k__4, v__6)
//line :229:1
		return v__6 } }




func A_arbace_j2g_names_method_base_STAR__A_New() *A_arbace_j2g_names_method_base_STAR__A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_method_base_STAR__A{}; t.Ctor(); return t }
//line :234:1
func (t *A_arbace_j2g_names_method_base_STAR__A) Ctor() {}
//line :234:1
func (t *A_arbace_j2g_names_method_base_STAR__A) Invoke_O_O_O__O(self, name__0, desc__1 any) any { var vec__1768000041__3 any; var root_315 any = A_arbace_j2g_names_A_const_55.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_317 lang.IFn; if
													linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any = desc__1; if linked_316 == nil { vec__1768000041__3 = ifn_317.Invoke_O__O(arg_318) } else { vec__1768000041__3 = linked_316.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_315, arg_318) }; var ps__4 any = /*line :234:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1768000041__3, lang.RT_IntCast_J__I_NoInit(0), nil); var r__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1768000041__3, lang.RT_IntCast_J__I_NoInit(1), nil); var m__6 any; var root_319 any = A_arbace_j2g_names_A_const_56.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_319, A_arbace_j2g_names_capitalize_A_fn_class); var ifn_321 lang.IFn; if

	linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any; var root_323 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_323, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_325 lang.IFn; if linked_324 == nil { ifn_325 = lang.IFn_Cast(root_323) } else { ifn_325 = nil }; var arg_326 any = name__0; if linked_324 == nil { arg_322 = ifn_325.Invoke_O__O(arg_326) } else { arg_322 = linked_324.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_323, arg_326) }; if linked_320 == nil { m__6 = ifn_321.Invoke_O__O(arg_322) } else { m__6 = linked_320.(*A_arbace_j2g_names_capitalize_A).Invoke_O_O__O(root_319, arg_322) }; var m__7 any; var tmp1 any; var root_327 any = /*line :234:1*/A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_327, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_329 lang.IFn; if


	linked_328 == nil { ifn_329 = lang.IFn_Cast(root_327) } else { ifn_329 = nil }; var arg_330 any = m__6; var arg_331 any = Lit_7; if linked_328 == nil { tmp1 = ifn_329.Invoke_O_O__O(arg_330, arg_331) } else { tmp1 = linked_328.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_327, arg_330, arg_331) }; if jrt.J2g_Truth(tmp1) { m__7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, m__6)).Ref() } else { m__7 = m__6 }; var tmp2 /*line :238:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_22, nil); var tmp3 any; var root_332 any = A_arbace_j2g_names_A_const_25.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_332, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_334 lang.IFn; if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var arg_336 any; var root_337 any = A_arbace_j2g_names_A_const_26.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_337, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any; var tmp4 any = A_arbace_j2g_names_method_base_STAR__fn__1768000044_A_New(); var tmp5 *jrt.Class; var fncls__346 *jrt.Class = A_arbace_j2g_names_method_base_STAR__fn__1768000044_A_fn_class; if fncls__346 == nil { var fncls__346d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_j2g_names_method_base_STAR__fn__1768000044_A_fn_class = fncls__346d; tmp5 = fncls__346d } else { tmp5 = fncls__346 }; arg_340 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_341 any = ps__4; if linked_338 == nil { arg_336 = ifn_339.Invoke_O_O__O(arg_340, arg_341) } else { arg_336 = linked_338.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_337, arg_340, arg_341) }; if linked_333 == nil { tmp3 = ifn_334.Invoke_O_O__O(arg_335, arg_336) } else { tmp3 = linked_333.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_332, arg_335, arg_336) }; var tmp6 any = tmp3; var tmp7 any; var root_347 any = A_arbace_j2g_names_A_const_49.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, A_arbace_j2g_names_desc_code_A_fn_class); var ifn_349 lang.IFn; if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any = r__5; if linked_348 == nil { tmp7 = ifn_349.Invoke_O__O(arg_350) } else { tmp7 = linked_348.(*A_arbace_j2g_names_desc_code_A).Invoke_O_O__O(root_347, arg_350) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, m__7, tmp6, nil, tmp7)).Ref() }
//line :238:1
func A_arbace_j2g_names_method_base_STAR__fn__1768000044_A_New() *A_arbace_j2g_names_method_base_STAR__fn__1768000044_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_method_base_STAR__fn__1768000044_A{}; t.Ctor(); return t }
//line :238:1
func (t *A_arbace_j2g_names_method_base_STAR__fn__1768000044_A) Ctor() {}
//line :238:1
func (t *A_arbace_j2g_names_method_base_STAR__fn__1768000044_A) Invoke_O_O__O(self, p1__1768000040_SHARP___1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_7, nil); var tmp2 any; var root_342 any = A_arbace_j2g_names_A_const_49.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, A_arbace_j2g_names_desc_code_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = p1__1768000040_SHARP___1; if linked_343 == nil { tmp2 = ifn_344.Invoke_O__O(arg_345) } else { tmp2 = linked_343.(*A_arbace_j2g_names_desc_code_A).Invoke_O_O__O(root_342, arg_345) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_names_ctor_base_A_New() *A_arbace_j2g_names_ctor_base_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_ctor_base_A{}; t.Ctor(); return t }
//line :240:1
func (t *A_arbace_j2g_names_ctor_base_A) Ctor() {}
//line :240:1
func (t *A_arbace_j2g_names_ctor_base_A) Invoke_O_O__O(self, desc__0 any) any { var vec__1768000048__2 any; var root_351 any = A_arbace_j2g_names_A_const_55.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_351, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_353 lang.IFn; if



	linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; var arg_354 any = desc__0; if linked_352 == nil { vec__1768000048__2 = ifn_353.Invoke_O__O(arg_354) } else { vec__1768000048__2 = linked_352.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_351, arg_354) }; var ps__3 any = /*line :240:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1768000048__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1768000048__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_5, nil); var tmp2 any; var root_355 any = A_arbace_j2g_names_A_const_25.GetRawRoot__O(); var linked_356 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_355, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_357 lang.IFn; _ = ___4; if




	linked_356 == nil { ifn_357 = lang.IFn_Cast(root_355) } else { ifn_357 = nil }; var arg_358 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var arg_359 any; var root_360 any = A_arbace_j2g_names_A_const_26.GetRawRoot__O(); var linked_361 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_360, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_362 lang.IFn; if linked_361 == nil { ifn_362 = lang.IFn_Cast(root_360) } else { ifn_362 = nil }; var arg_363 any; var tmp3 any = A_arbace_j2g_names_ctor_base_fn__1768000051_A_New(); var tmp4 *jrt.Class; var fncls__369 *jrt.Class = A_arbace_j2g_names_ctor_base_fn__1768000051_A_fn_class; if fncls__369 == nil { var fncls__369d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_j2g_names_ctor_base_fn__1768000051_A_fn_class = fncls__369d; tmp4 = fncls__369d } else { tmp4 = fncls__369 }; arg_363 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_364 any = ps__3; if linked_361 == nil { arg_359 = ifn_362.Invoke_O_O__O(arg_363, arg_364) } else { arg_359 = linked_361.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_360, arg_363, arg_364) }; if linked_356 == nil { tmp2 = ifn_357.Invoke_O_O__O(arg_358, arg_359) } else { tmp2 = linked_356.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_355, arg_358, arg_359) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }
//line :245:1
func A_arbace_j2g_names_ctor_base_fn__1768000051_A_New() *A_arbace_j2g_names_ctor_base_fn__1768000051_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_ctor_base_fn__1768000051_A{}; t.Ctor(); return t }
//line :245:1
func (t *A_arbace_j2g_names_ctor_base_fn__1768000051_A) Ctor() {}
//line :245:1
func (t *A_arbace_j2g_names_ctor_base_fn__1768000051_A) Invoke_O_O__O(self, p1__1768000047_SHARP___1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_7, nil); var tmp2 any; var root_365 any = A_arbace_j2g_names_A_const_49.GetRawRoot__O(); var linked_366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_365, A_arbace_j2g_names_desc_code_A_fn_class); var ifn_367 lang.IFn; if linked_366 == nil { ifn_367 = lang.IFn_Cast(root_365) } else { ifn_367 = nil }; var arg_368 any = p1__1768000047_SHARP___1; if linked_366 == nil { tmp2 = ifn_367.Invoke_O__O(arg_368) } else { tmp2 = linked_366.(*A_arbace_j2g_names_desc_code_A).Invoke_O_O__O(root_365, arg_368) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_names_new_name_A_New() *A_arbace_j2g_names_new_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_new_name_A{}; t.Ctor(); return t }
//line :247:1
func (t *A_arbace_j2g_names_new_name_A) Ctor() {}
//line :247:1
func (t *A_arbace_j2g_names_new_name_A) Invoke_O_O_O__O(self, cls_go__0, desc__1 any) any { var vec__1768000055__3 any; var root_370 any = A_arbace_j2g_names_A_const_55.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_372 lang.IFn; if


	linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = desc__1; if linked_371 == nil { vec__1768000055__3 = ifn_372.Invoke_O__O(arg_373) } else { vec__1768000055__3 = linked_371.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_370, arg_373) }; var ps__4 any = /*line :247:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1768000055__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1768000055__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_24, nil); var tmp2 any; var root_374 any = A_arbace_j2g_names_A_const_25.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_376 lang.IFn; _ = ___5; if



	linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var arg_378 any; var root_379 any = A_arbace_j2g_names_A_const_26.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_379, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_381 lang.IFn; if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any; var tmp3 any = A_arbace_j2g_names_new_name_fn__1768000058_A_New(); var tmp4 *jrt.Class; var fncls__388 *jrt.Class = A_arbace_j2g_names_new_name_fn__1768000058_A_fn_class; if fncls__388 == nil { var fncls__388d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_j2g_names_new_name_fn__1768000058_A_fn_class = fncls__388d; tmp4 = fncls__388d } else { tmp4 = fncls__388 }; arg_382 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_383 any = ps__4; if linked_380 == nil { arg_378 = ifn_381.Invoke_O_O__O(arg_382, arg_383) } else { arg_378 = linked_380.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_379, arg_382, arg_383) }; if linked_375 == nil { tmp2 = ifn_376.Invoke_O_O__O(arg_377, arg_378) } else { tmp2 = linked_375.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_374, arg_377, arg_378) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, cls_go__0, nil, tmp2)).Ref() }
//line :251:1
func A_arbace_j2g_names_new_name_fn__1768000058_A_New() *A_arbace_j2g_names_new_name_fn__1768000058_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_new_name_fn__1768000058_A{}; t.Ctor(); return t }
//line :251:1
func (t *A_arbace_j2g_names_new_name_fn__1768000058_A) Ctor() {}
//line :251:1
func (t *A_arbace_j2g_names_new_name_fn__1768000058_A) Invoke_O_O__O(self, p1__1768000054_SHARP___1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_7, nil); var tmp2 any; var root_384 any = A_arbace_j2g_names_A_const_49.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, A_arbace_j2g_names_desc_code_A_fn_class); var ifn_386 lang.IFn; if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any = p1__1768000054_SHARP___1; if linked_385 == nil { tmp2 = ifn_386.Invoke_O__O(arg_387) } else { tmp2 = linked_385.(*A_arbace_j2g_names_desc_code_A).Invoke_O_O__O(root_384, arg_387) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_names_field_name_A_New() *A_arbace_j2g_names_field_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_field_name_A{}; t.Ctor(); return t }
//line :253:1
func (t *A_arbace_j2g_names_field_name_A) Ctor() {}
//line :253:1
func (t *A_arbace_j2g_names_field_name_A) Invoke_O_O__O(self, fname__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_10, nil); var tmp2 any; var root_389 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_389, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_391 lang.IFn; if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any = fname__0; if linked_390 == nil { tmp2 = ifn_391.Invoke_O__O(arg_392) } else { tmp2 = linked_390.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_389, arg_392) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_names_static_field_name_A_New() *A_arbace_j2g_names_static_field_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_static_field_name_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_j2g_names_static_field_name_A) Ctor() {}
//line :255:1
func (t *A_arbace_j2g_names_static_field_name_A) Invoke_O_O_O__O(self, cls_go__0, fname__1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_7, nil); var tmp2 any; var root_393 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_393, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_395 lang.IFn; if linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var arg_396 any = fname__1; if linked_394 == nil { tmp2 = ifn_395.Invoke_O__O(arg_396) } else { tmp2 = linked_394.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_393, arg_396) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, cls_go__0, nil, tmp2)).Ref() }

func A_arbace_j2g_names_static_method_name_A_New() *A_arbace_j2g_names_static_method_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_static_method_name_A{}; t.Ctor(); return t }
//line :257:1
func (t *A_arbace_j2g_names_static_method_name_A) Ctor() {}
//line :257:1
func (t *A_arbace_j2g_names_static_method_name_A) Invoke_O_O_O_O__O(self, cls_go__0, name__1, desc__2 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_7, nil); var tmp2 any; var root_397 any = A_arbace_j2g_names_A_const_57.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, A_arbace_j2g_names_method_base_A_fn_class); var ifn_399 lang.IFn; if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = name__1; var arg_401 any = desc__2; if linked_398 == nil { tmp2 = ifn_399.Invoke_O_O__O(arg_400, arg_401) } else { tmp2 = linked_398.(*A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_397, arg_400, arg_401) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, cls_go__0, nil, tmp2)).Ref() }

func A_arbace_j2g_names_impl_name_A_New() *A_arbace_j2g_names_impl_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_impl_name_A{}; t.Ctor(); return t }
//line :259:1
func (t *A_arbace_j2g_names_impl_name_A) Ctor() {}
//line :259:1
func (t *A_arbace_j2g_names_impl_name_A) Invoke_O_O__O(self, mbase__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_18, nil), jrt.RefArrayOf(jrt.Object_class, nil, mbase__0)).Ref() }




































type A_arbace_j2g_names_A struct{ jrt.Object }

var A_arbace_j2g_names_A_const_pool *jrt.RefArray

var A_arbace_j2g_names_A_const_0 *lang.Var

var A_arbace_j2g_names_A_const_1 any

var A_arbace_j2g_names_A_const_2 any

var A_arbace_j2g_names_A_const_3 *lang.Var

var A_arbace_j2g_names_A_const_4 any

var A_arbace_j2g_names_A_const_5 *lang.Var

var A_arbace_j2g_names_A_const_6 *lang.Var

var A_arbace_j2g_names_A_const_7 *lang.Var

var A_arbace_j2g_names_A_const_8 *lang.Var

var A_arbace_j2g_names_A_const_9 any

var A_arbace_j2g_names_A_const_10 *lang.Var

var A_arbace_j2g_names_A_const_11 any

var A_arbace_j2g_names_A_const_12 *lang.Var

var A_arbace_j2g_names_A_const_13 *lang.Keyword

var A_arbace_j2g_names_A_const_14 *lang.Keyword

var A_arbace_j2g_names_A_const_15 *lang.Var

var A_arbace_j2g_names_A_const_16 *lang.Var

var A_arbace_j2g_names_A_const_17 *lang.Var

var A_arbace_j2g_names_A_const_18 *lang.Keyword

var A_arbace_j2g_names_A_const_19 *lang.Var

var A_arbace_j2g_names_A_const_20 any

var A_arbace_j2g_names_A_const_21 *lang.Var

var A_arbace_j2g_names_A_const_22 *lang.Var

var A_arbace_j2g_names_A_const_23 *lang.Var

var A_arbace_j2g_names_A_const_24 *lang.Var

var A_arbace_j2g_names_A_const_25 *lang.Var

var A_arbace_j2g_names_A_const_26 *lang.Var

var A_arbace_j2g_names_A_const_27 any

var A_arbace_j2g_names_A_const_28 *lang.Var

var A_arbace_j2g_names_A_const_29 *lang.Var

var A_arbace_j2g_names_A_const_30 *lang.Var

var A_arbace_j2g_names_A_const_31 *lang.Var

var A_arbace_j2g_names_A_const_32 *lang.Var

var A_arbace_j2g_names_A_const_33 *lang.Var

var A_arbace_j2g_names_A_const_34 *lang.Var

var A_arbace_j2g_names_A_const_35 any

var A_arbace_j2g_names_A_const_36 any

var A_arbace_j2g_names_A_const_37 *lang.Var

var A_arbace_j2g_names_A_const_38 *lang.Var

var A_arbace_j2g_names_A_const_39 *lang.Var

var A_arbace_j2g_names_A_const_40 *lang.Var

var A_arbace_j2g_names_A_const_41 *lang.Var

var A_arbace_j2g_names_A_const_42 *lang.Var

var A_arbace_j2g_names_A_const_43 *lang.Var

var A_arbace_j2g_names_A_const_44 *lang.Var

var A_arbace_j2g_names_A_const_45 *lang.Var

var A_arbace_j2g_names_A_const_46 any

var A_arbace_j2g_names_A_const_47 *lang.Var

var A_arbace_j2g_names_A_const_48 *lang.Var

var A_arbace_j2g_names_A_const_49 *lang.Var

var A_arbace_j2g_names_A_const_50 *lang.Var

var A_arbace_j2g_names_A_const_51 *lang.Var

var A_arbace_j2g_names_A_const_52 *lang.Var

var A_arbace_j2g_names_A_const_53 *lang.Var

var A_arbace_j2g_names_A_const_54 *lang.Var

var A_arbace_j2g_names_A_const_55 *lang.Var

var A_arbace_j2g_names_A_const_56 *lang.Var

var A_arbace_j2g_names_A_const_57 *lang.Var

var A_arbace_j2g_names_A_init jrt.ClassInit

func A_arbace_j2g_names_A_Init() { if !A_arbace_j2g_names_A_init.Done() { A_arbace_j2g_names_A_init.Run(A_arbace_j2g_names_A_clinit) } }

func A_arbace_j2g_names_A_clinit() { A_arbace_j2g_names_A_clinit_p0(); A_arbace_j2g_names_A_clinit_p1(); A_arbace_j2g_names_A_clinit_p2(); A_arbace_j2g_names_A_clinit_p3(); A_arbace_j2g_names_A_clinit_p4() }

func A_arbace_j2g_names_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_names_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 68); A_arbace_j2g_names_A_const_0 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[10]); A_arbace_j2g_names_A_const_1 = A_arbace_j2g_names_A_const_pool.A[11]; A_arbace_j2g_names_A_const_2 = A_arbace_j2g_names_A_const_pool.A[12]; A_arbace_j2g_names_A_const_3 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[13]); A_arbace_j2g_names_A_const_4 = A_arbace_j2g_names_A_const_pool.A[14]; A_arbace_j2g_names_A_const_5 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[15]); A_arbace_j2g_names_A_const_6 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[16]); A_arbace_j2g_names_A_const_7 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[17]); A_arbace_j2g_names_A_const_8 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[18]); A_arbace_j2g_names_A_const_9 = A_arbace_j2g_names_A_const_pool.A[19]; A_arbace_j2g_names_A_const_10 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[20]); A_arbace_j2g_names_A_const_11 = A_arbace_j2g_names_A_const_pool.A[21] }

func A_arbace_j2g_names_A_clinit_p1() { A_arbace_j2g_names_A_const_12 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[22]); A_arbace_j2g_names_A_const_13 = lang.Keyword_Cast(A_arbace_j2g_names_A_const_pool.A[23]); A_arbace_j2g_names_A_const_14 = lang.Keyword_Cast(A_arbace_j2g_names_A_const_pool.A[24]); A_arbace_j2g_names_A_const_15 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[25]); A_arbace_j2g_names_A_const_16 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[26]); A_arbace_j2g_names_A_const_17 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[27]); A_arbace_j2g_names_A_const_18 = lang.Keyword_Cast(A_arbace_j2g_names_A_const_pool.A[28]); A_arbace_j2g_names_A_const_19 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[29]); A_arbace_j2g_names_A_const_20 = A_arbace_j2g_names_A_const_pool.A[30]; A_arbace_j2g_names_A_const_21 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[31]); A_arbace_j2g_names_A_const_22 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[32]); A_arbace_j2g_names_A_const_23 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[33]) }

func A_arbace_j2g_names_A_clinit_p2() { A_arbace_j2g_names_A_const_24 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[34]); A_arbace_j2g_names_A_const_25 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[35]); A_arbace_j2g_names_A_const_26 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[36]); A_arbace_j2g_names_A_const_27 = A_arbace_j2g_names_A_const_pool.A[37]; A_arbace_j2g_names_A_const_28 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[38]); A_arbace_j2g_names_A_const_29 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[39]); A_arbace_j2g_names_A_const_30 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[40]); A_arbace_j2g_names_A_const_31 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[41]); A_arbace_j2g_names_A_const_32 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[42]); A_arbace_j2g_names_A_const_33 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[43]); A_arbace_j2g_names_A_const_34 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[44]); A_arbace_j2g_names_A_const_35 = A_arbace_j2g_names_A_const_pool.A[45] }

func A_arbace_j2g_names_A_clinit_p3() { A_arbace_j2g_names_A_const_36 = A_arbace_j2g_names_A_const_pool.A[46]; A_arbace_j2g_names_A_const_37 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[47]); A_arbace_j2g_names_A_const_38 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[48]); A_arbace_j2g_names_A_const_39 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[49]); A_arbace_j2g_names_A_const_40 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[50]); A_arbace_j2g_names_A_const_41 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[51]); A_arbace_j2g_names_A_const_42 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[52]); A_arbace_j2g_names_A_const_43 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[53]); A_arbace_j2g_names_A_const_44 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[54]); A_arbace_j2g_names_A_const_45 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[55]); A_arbace_j2g_names_A_const_46 = A_arbace_j2g_names_A_const_pool.A[56]; A_arbace_j2g_names_A_const_47 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[57]) }

func A_arbace_j2g_names_A_clinit_p4() { A_arbace_j2g_names_A_const_48 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[58]); A_arbace_j2g_names_A_const_49 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[59]); A_arbace_j2g_names_A_const_50 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[60]); A_arbace_j2g_names_A_const_51 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[61]); A_arbace_j2g_names_A_const_52 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[62]); A_arbace_j2g_names_A_const_53 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[63]); A_arbace_j2g_names_A_const_54 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[64]); A_arbace_j2g_names_A_const_55 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[65]); A_arbace_j2g_names_A_const_56 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[66]); A_arbace_j2g_names_A_const_57 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[67]) }

func A_arbace_j2g_names_A_New() *A_arbace_j2g_names_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_names_A) Ctor() {}

func (t *A_arbace_j2g_names_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_names_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_names_A_class }

func (t *A_arbace_j2g_names_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_names_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_names_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_names_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_names_A); return ok }

func A_arbace_j2g_names_A_Cast(x any) *A_arbace_j2g_names_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_names_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_names_A_class)) }; return v }



type A_arbace_j2g_names_capitalize_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_capitalize_A_fn_class *jrt.Class



type A_arbace_j2g_names_compiled_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_names_compiled_class_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_names_compiled_pkg_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_names_compiled_pkg_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_names_ctor_base_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_ctor_base_A_fn_class *jrt.Class



type A_arbace_j2g_names_ctor_base_fn__1768000051_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_ctor_base_fn__1768000051_A_fn_class *jrt.Class



type A_arbace_j2g_names_desc_code_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_desc_code_A_fn_class *jrt.Class



type A_arbace_j2g_names_eval1768000004_A struct{ jrt.Object }

func A_arbace_j2g_names_eval1768000004_A_New() *A_arbace_j2g_names_eval1768000004_A { t := &A_arbace_j2g_names_eval1768000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_names_eval1768000004_A) Ctor() {}

func (t *A_arbace_j2g_names_eval1768000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_names_eval1768000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_names_eval1768000004_A_class }

func (t *A_arbace_j2g_names_eval1768000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_names_eval1768000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_names_eval1768000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_names_eval1768000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_names_eval1768000004_A); return ok }

func A_arbace_j2g_names_eval1768000004_A_Cast(x any) *A_arbace_j2g_names_eval1768000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_names_eval1768000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_names_eval1768000004_A_class)) }; return v }



type A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A_fn_class *jrt.Class



type A_arbace_j2g_names_eval1768000008_A struct{ jrt.Object }

func A_arbace_j2g_names_eval1768000008_A_New() *A_arbace_j2g_names_eval1768000008_A { t := &A_arbace_j2g_names_eval1768000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_names_eval1768000008_A) Ctor() {}

func (t *A_arbace_j2g_names_eval1768000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_names_eval1768000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_names_eval1768000008_A_class }

func (t *A_arbace_j2g_names_eval1768000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_names_eval1768000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_names_eval1768000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_names_eval1768000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_names_eval1768000008_A); return ok }

func A_arbace_j2g_names_eval1768000008_A_Cast(x any) *A_arbace_j2g_names_eval1768000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_names_eval1768000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_names_eval1768000008_A_class)) }; return v }



type A_arbace_j2g_names_eval1768000008_fn__1768000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_eval1768000008_fn__1768000009_A_fn_class *jrt.Class



type A_arbace_j2g_names_field_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_field_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_fn__1768000021_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_fn__1768000021_A_fn_class *jrt.Class



type A_arbace_j2g_names_fn__1768000021_fn__1768000022_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_fn__1768000021_fn__1768000022_A_fn_class *jrt.Class



type A_arbace_j2g_names_go_class_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_go_class_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_go_class_name_STAR__STAR__A struct{ j2g_header uint64 }

var A_arbace_j2g_names_go_class_name_STAR__STAR__A_fn_class *jrt.Class



type A_arbace_j2g_names_impl_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_impl_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_local_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_local_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_memo_str_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_memo_str_A_fn_class *jrt.Class



type A_arbace_j2g_names_memo_str_fn__1768000018_A struct{ j2g_header uint64; F_cache, F_f any }

var A_arbace_j2g_names_memo_str_fn__1768000018_A_fn_class *jrt.Class



type A_arbace_j2g_names_method_base_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_method_base_A_fn_class *jrt.Class



type A_arbace_j2g_names_method_base_STAR__A struct{ j2g_header uint64 }

var A_arbace_j2g_names_method_base_STAR__A_fn_class *jrt.Class



type A_arbace_j2g_names_method_base_STAR__fn__1768000044_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_method_base_STAR__fn__1768000044_A_fn_class *jrt.Class



type A_arbace_j2g_names_munge_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_munge_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_new_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_new_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_new_name_fn__1768000058_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_new_name_fn__1768000058_A_fn_class *jrt.Class



type A_arbace_j2g_names_pkg_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_pkg_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_pkg_ns_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_pkg_ns_A_fn_class *jrt.Class



type A_arbace_j2g_names_pkg_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_pkg_of_A_fn_class *jrt.Class



type A_arbace_j2g_names_pkg_path_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_pkg_path_A_fn_class *jrt.Class



type A_arbace_j2g_names_qualified_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_names_qualified_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A struct{ j2g_header uint64; F_internal any }

var A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A_fn_class *jrt.Class



type A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A struct{ j2g_header uint64; F_internal any }

var A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A_fn_class *jrt.Class



type A_arbace_j2g_names_static_field_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_static_field_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_static_method_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_static_method_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_top_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_top_of_A_fn_class *jrt.Class
