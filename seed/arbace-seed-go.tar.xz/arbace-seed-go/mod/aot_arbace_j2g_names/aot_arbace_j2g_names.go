//line aot_arbace_j2g_names.ae:1
package aot_arbace_j2g_names

import (
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A_New() *A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_names_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_names_A_const_4); tmp2 = lang.IFn_Cast(A_arbace_j2g_names_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_names_A_const_1, A_arbace_j2g_names_A_const_2); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_names_eval1768000008_fn__1768000009_A_New() *A_arbace_j2g_names_eval1768000008_fn__1768000009_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_eval1768000008_fn__1768000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_names_eval1768000008_fn__1768000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_names_eval1768000008_fn__1768000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_names_A_const_5.GetRawRoot__O()); var tmp2 any; var root_16 any = A_arbace_j2g_names_A_const_6.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = A_arbace_j2g_names_A_const_7; if linked_17 == nil { tmp2 = ifn_18.Invoke_O__O(arg_19) } else { tmp2 = linked_17.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_16, arg_19) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_names_A_const_8.GetRawRoot__O(), A_arbace_j2g_names_A_const_9) }















func A_arbace_j2g_names_top_of_A_New() *A_arbace_j2g_names_top_of_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_top_of_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_j2g_names_top_of_A) Ctor() {}
//line :17:1
func (t *A_arbace_j2g_names_top_of_A) Invoke_O_O__O(self, n__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_11); if lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return n__0 } else { var root_20 any = A_arbace_j2g_names_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = n__0; var arg_24 any = A_arbace_j2g_names_A_const_11; var arg_25 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_21 == nil { return ifn_22.Invoke_O_O_O__O(arg_23, arg_24, arg_25) } else { return linked_21.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_20, arg_23, arg_24, arg_25) } } }

func A_arbace_j2g_names_pkg_of_A_New() *A_arbace_j2g_names_pkg_of_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_pkg_of_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_j2g_names_pkg_of_A) Ctor() {}
//line :19:1
func (t *A_arbace_j2g_names_pkg_of_A) Invoke_O_O__O(self, internal__0 any) any {







	var tmp1 any; var or__1927000174__auto____2 any; var root_26 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_28 lang.IFn
	if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = internal__0; var arg_30 any = Lit_27; if linked_27 == nil { or__1927000174__auto____2 = ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { or__1927000174__auto____2 = linked_27.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_26, arg_29, arg_30) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_31 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = internal__0; var arg_35 any = Lit_28; if linked_32 == nil { or__1927000174__auto____3 = ifn_33.Invoke_O_O__O(arg_34, arg_35) } else { or__1927000174__auto____3 = linked_32.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_31, arg_34, arg_35) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var root_36 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_38 lang.IFn
		if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = internal__0; var arg_40 any = Lit_29; if linked_37 == nil { or__1927000174__auto____4 = ifn_38.Invoke_O_O__O(arg_39, arg_40) } else { or__1927000174__auto____4 = linked_37.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_36, arg_39, arg_40) }
//line :28:1
		if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { var or__1927000174__auto____5 any; var root_41 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_43 lang.IFn
			if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = internal__0; var arg_45 any = Lit_30; if linked_42 == nil { or__1927000174__auto____5 = ifn_43.Invoke_O_O__O(arg_44, arg_45) } else { or__1927000174__auto____5 = linked_42.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_41, arg_44, arg_45) }
//line :28:1
			if jrt.J2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any; var root_46 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_48 lang.IFn

				if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = internal__0; var arg_50 any = Lit_31; if linked_47 == nil { or__1927000174__auto____6 = ifn_48.Invoke_O_O__O(arg_49, arg_50) } else { or__1927000174__auto____6 = linked_47.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_46, arg_49, arg_50) }
//line :28:1
				if jrt.J2g_Truth(or__1927000174__auto____6) { tmp1 = or__1927000174__auto____6 } else { var or__1927000174__auto____7 any; var root_51 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_53 lang.IFn

					if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = internal__0; var arg_55 any = Lit_32; if linked_52 == nil { or__1927000174__auto____7 = ifn_53.Invoke_O_O__O(arg_54, arg_55) } else { or__1927000174__auto____7 = linked_52.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_51, arg_54, arg_55) }
//line :28:1
					if jrt.J2g_Truth(or__1927000174__auto____7) { tmp1 = or__1927000174__auto____7 } else { var or__1927000174__auto____8 any; var root_56 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_58 lang.IFn


						if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = internal__0; var arg_60 any = Lit_33; if linked_57 == nil { or__1927000174__auto____8 = ifn_58.Invoke_O_O__O(arg_59, arg_60) } else { or__1927000174__auto____8 = linked_57.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_56, arg_59, arg_60) }
//line :28:1
						if jrt.J2g_Truth(or__1927000174__auto____8) { tmp1 = or__1927000174__auto____8 } else { var or__1927000174__auto____9 any; var root_61 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_63 lang.IFn


							if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = internal__0; var arg_65 any = Lit_34; if linked_62 == nil { or__1927000174__auto____9 = ifn_63.Invoke_O_O__O(arg_64, arg_65) } else { or__1927000174__auto____9 = linked_62.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_61, arg_64, arg_65) }
//line :28:1
							if jrt.J2g_Truth(or__1927000174__auto____9) { tmp1 = or__1927000174__auto____9 } else { var or__1927000174__auto____10 any; var root_66 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_68 lang.IFn



								if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = internal__0; var arg_70 any = Lit_35; if linked_67 == nil { or__1927000174__auto____10 = ifn_68.Invoke_O_O__O(arg_69, arg_70) } else { or__1927000174__auto____10 = linked_67.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_66, arg_69, arg_70) }
//line :28:1
								if jrt.J2g_Truth(or__1927000174__auto____10) { tmp1 = or__1927000174__auto____10 } else { var or__1927000174__auto____11 any; var root_71 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_73 lang.IFn



									if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = internal__0; var arg_75 any = Lit_36; if linked_72 == nil { or__1927000174__auto____11 = ifn_73.Invoke_O_O__O(arg_74, arg_75) } else { or__1927000174__auto____11 = linked_72.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_71, arg_74, arg_75) }
//line :28:1
									if jrt.J2g_Truth(or__1927000174__auto____11) { tmp1 = or__1927000174__auto____11 } else {




										var root_76 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = internal__0; var arg_80 any = Lit_37; if linked_77 == nil { tmp1 = ifn_78.Invoke_O_O__O(arg_79, arg_80) } else { tmp1 = linked_77.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_76, arg_79, arg_80) } } } } } } } } } } }
//line :27:1
	if jrt.J2g_Truth(tmp1) { return A_arbace_j2g_names_A_const_13 } else { if A_arbace_j2g_names_A_const_14 != nil { var temp__1927000408__auto____2 any; var tmp2 any; var root_81 any = A_arbace_j2g_names_A_const_6.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_83 lang.IFn






		if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = A_arbace_j2g_names_A_const_15.GetRawRoot__O(); if linked_82 == nil { tmp2 = ifn_83.Invoke_O__O(arg_84) } else { tmp2 = linked_82.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_81, arg_84) }; var tmp3 any = tmp2; var tmp4 any; var root_85 any = A_arbace_j2g_names_A_const_16.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, A_arbace_j2g_names_top_of_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = internal__0; if linked_86 == nil { tmp4 = ifn_87.Invoke_O__O(arg_88) } else { tmp4 = linked_86.(*A_arbace_j2g_names_top_of_A).Invoke_O_O__O(root_85, arg_88) }; temp__1927000408__auto____2 = lang.RT_Get_O_O__O_NoInit(tmp3, tmp4); if jrt.J2g_Truth(temp__1927000408__auto____2) { var p__3 any = temp__1927000408__auto____2; var root_89 any = A_arbace_j2g_names_A_const_17.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = p__3; if linked_90 == nil { return ifn_91.Invoke_O__O(arg_92) } else { return linked_90.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_89, arg_92) } } else { return A_arbace_j2g_names_A_const_18 } } else {
//line :27:1
			return nil
		}
	}
}





func A_arbace_j2g_names_compiled_pkg_QMARK__A_New() *A_arbace_j2g_names_compiled_pkg_QMARK__A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_compiled_pkg_QMARK__A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_j2g_names_compiled_pkg_QMARK__A) Ctor() {}
//line :36:1
func (t *A_arbace_j2g_names_compiled_pkg_QMARK__A) Invoke_O_O__O(self, pkg__0 any) any { var root_93 any = A_arbace_j2g_names_A_const_19.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = lang.IFn_Cast(A_arbace_j2g_names_A_const_20).Invoke_O__O(pkg__0); if linked_94 == nil { return ifn_95.Invoke_O__O(arg_96) } else { return linked_94.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_93, arg_96) } }

func A_arbace_j2g_names_pkg_name_A_New() *A_arbace_j2g_names_pkg_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_pkg_name_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_j2g_names_pkg_name_A) Ctor() {}
//line :38:1
func (t *A_arbace_j2g_names_pkg_name_A) Invoke_O_O__O(self, pkg__0 any) any { var root_97 any = A_arbace_j2g_names_A_const_21.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = pkg__0; if linked_98 == nil { return ifn_99.Invoke_O__O(arg_100) } else { return linked_98.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_97, arg_100) } }
func A_arbace_j2g_names_pkg_path_A_New() *A_arbace_j2g_names_pkg_path_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_pkg_path_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_j2g_names_pkg_path_A) Ctor() {}
//line :39:1
func (t *A_arbace_j2g_names_pkg_path_A) Invoke_O_O__O(self, pkg__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_1, nil); var tmp2 any; var root_101 any = A_arbace_j2g_names_A_const_21.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = pkg__0; if linked_102 == nil { tmp2 = ifn_103.Invoke_O__O(arg_104) } else { tmp2 = linked_102.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_101, arg_104) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }
func A_arbace_j2g_names_pkg_ns_A_New() *A_arbace_j2g_names_pkg_ns_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_pkg_ns_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_j2g_names_pkg_ns_A) Ctor() {}
//line :40:1
func (t *A_arbace_j2g_names_pkg_ns_A) Invoke_O_O__O(self, pkg__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_26, nil); var tmp2 any; var root_105 any = A_arbace_j2g_names_A_const_21.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = pkg__0; if linked_106 == nil { tmp2 = ifn_107.Invoke_O__O(arg_108) } else { tmp2 = linked_106.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_105, arg_108) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }



















func A_arbace_j2g_names_memo_str_A_New() *A_arbace_j2g_names_memo_str_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_memo_str_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_j2g_names_memo_str_A) Ctor() {}
//line :60:1
func (t *A_arbace_j2g_names_memo_str_A) Invoke_O_O__O(self, f__0 any) any { var cache__2 any = jrt.ConcurrentHashMap_New(); var tmp1 any = A_arbace_j2g_names_memo_str_fn__1768000018_A_New_O_O(cache__2, f__0); var tmp2 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_j2g_names_memo_str_fn__1768000018_A_fn_class; if




	fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_j2g_names_memo_str_fn__1768000018_A_fn_class = fncls__109d; tmp2 = fncls__109d } else { tmp2 = fncls__109 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :65:1
func A_arbace_j2g_names_memo_str_fn__1768000018_A_New_O_O(p0, p1 any) *A_arbace_j2g_names_memo_str_fn__1768000018_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_memo_str_fn__1768000018_A{}; t.Ctor_O_O(p0, p1); return t }
//line :65:1
func (t *A_arbace_j2g_names_memo_str_fn__1768000018_A) Ctor_O_O(c__cache, c__f any) { t.F_cache = c__cache; t.F_f = c__f }
//line :65:1
func (t *A_arbace_j2g_names_memo_str_fn__1768000018_A) Invoke_O_O__O(self, k__1 any) any { var or__1927000174__auto____2 any = jrt.NN(jrt.ConcurrentHashMap_Cast(t.F_cache)).Get_O__O(k__1); if
												jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var v__3 any = lang.IFn_Cast(t.F_f).Invoke_O__O(k__1)

		jrt.NN(jrt.ConcurrentHashMap_Cast(t.F_cache)).Put_O_O__O(k__1, v__3)
//line :66:1
		return v__3 } }






func A_arbace_j2g_names_fn__1768000021_A_New() *A_arbace_j2g_names_fn__1768000021_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_fn__1768000021_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_j2g_names_fn__1768000021_A) Ctor() {}
//line :73:1
func (t *A_arbace_j2g_names_fn__1768000021_A) Invoke_O_O__O(self, s__0 any) any { var m__2 any; var root_110 any = A_arbace_j2g_names_A_const_22.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_112 lang.IFn; if
										linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any; var root_116 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any; var root_120 any = A_arbace_j2g_names_A_const_24.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_munge_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = s__0; if linked_121 == nil { arg_119 = ifn_122.Invoke_O__O(arg_123) } else { arg_119 = linked_121.(*aot_arbace_core.A_arbace_core_munge_A).Invoke_O_O__O(root_120, arg_123) }; if linked_117 == nil { arg_113 = ifn_118.Invoke_O__O(arg_119) } else { arg_113 = linked_117.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_116, arg_119) }; var arg_114 any = Lit_11; var arg_115 any = Lit_7; if linked_111 == nil { m__2 = ifn_112.Invoke_O_O_O__O(arg_113, arg_114, arg_115) } else { m__2 = linked_111.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_110, arg_113, arg_114, arg_115) }; var root_124 any =


	A_arbace_j2g_names_A_const_25.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var arg_128 any; var root_129 any = A_arbace_j2g_names_A_const_26.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any; var tmp1 any = A_arbace_j2g_names_fn__1768000021_fn__1768000022_A_New(); var tmp2 *jrt.Class; var fncls__134 *jrt.Class = A_arbace_j2g_names_fn__1768000021_fn__1768000022_A_fn_class; if fncls__134 == nil { var fncls__134d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_j2g_names_fn__1768000021_fn__1768000022_A_fn_class = fncls__134d; tmp2 = fncls__134d } else { tmp2 = fncls__134 }; arg_132 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_133 any = m__2; if linked_130 == nil { arg_128 = ifn_131.Invoke_O_O__O(arg_132, arg_133) } else { arg_128 = linked_130.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_129, arg_132, arg_133) }; if linked_125 == nil { return ifn_126.Invoke_O_O__O(arg_127, arg_128) } else { return linked_125.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_124, arg_127, arg_128) } }
//line :77:1
func A_arbace_j2g_names_fn__1768000021_fn__1768000022_A_New() *A_arbace_j2g_names_fn__1768000021_fn__1768000022_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_fn__1768000021_fn__1768000022_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_j2g_names_fn__1768000021_fn__1768000022_A) Ctor() {}
//line :77:1
func (t *A_arbace_j2g_names_fn__1768000021_fn__1768000022_A) Invoke_O_O__O(self, c__1 any) any { var tmp1 bool; var or__1927000174__auto____2 bool = jrt.Character_IsLetterOrDigit_C__Z_NoInit(lang.RT_CharCast_O__C_NoInit(c__1)); if or__1927000174__auto____2 { tmp1 = or__1927000174__auto____2 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(c__1, A_arbace_j2g_names_A_const_27) }; if tmp1 { return c__1 } else { return A_arbace_j2g_names_A_const_27 } }

func A_arbace_j2g_names_munge_name_A_New() *A_arbace_j2g_names_munge_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_munge_name_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_j2g_names_munge_name_A) Ctor() {}
//line :79:1
func (t *A_arbace_j2g_names_munge_name_A) Invoke_O_O__O(self, s__0 any) any {


	var root_135 any = A_arbace_j2g_names_A_const_28.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, A_arbace_j2g_names_memo_str_fn__1768000018_A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any; var root_139 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_139, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_141 lang.IFn; if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = s__0; if linked_140 == nil { arg_138 = ifn_141.Invoke_O__O(arg_142) } else { arg_138 = linked_140.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_139, arg_142) }; if linked_136 == nil { return ifn_137.Invoke_O__O(arg_138) } else { return linked_136.(*A_arbace_j2g_names_memo_str_fn__1768000018_A).Invoke_O_O__O(root_135, arg_138)
	} }
func A_arbace_j2g_names_local_name_A_New() *A_arbace_j2g_names_local_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_local_name_A{}; t.Ctor(); return t }
//line :84:1
func (t *A_arbace_j2g_names_local_name_A) Ctor() {}
//line :84:1
func (t *A_arbace_j2g_names_local_name_A) Invoke_O_O__O(self, sym__0 any) any { var s__2 any; var root_143 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_145 lang.IFn; if




	linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any; var root_147 any = A_arbace_j2g_names_A_const_21.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = sym__0; if linked_148 == nil { arg_146 = ifn_149.Invoke_O__O(arg_150) } else { arg_146 = linked_148.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_147, arg_150) }; if linked_144 == nil { s__2 = ifn_145.Invoke_O__O(arg_146) } else { s__2 = linked_144.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_143, arg_146) }; var s__3 any; var tmp1 any; var root_151 any = /*line :84:1*/A_arbace_j2g_names_A_const_30.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_string.A_arbace_string_blank_QMARK__A_fn_class); var ifn_153 lang.IFn; if





	linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = s__2; if linked_152 == nil { tmp1 = ifn_153.Invoke_O__O(arg_154) } else { tmp1 = linked_152.(*aot_arbace_string.A_arbace_string_blank_QMARK__A).Invoke_O_O__O(root_151, arg_154) }; if jrt.J2g_Truth(tmp1) { s__3 = Lit_19 } else { s__3 = s__2 }; var tmp2 any; var or__1927000174__auto____4 any =
	lang.IFn_Cast(A_arbace_j2g_names_A_const_31.GetRawRoot__O()).Invoke_O__O(s__3); if jrt.J2g_Truth(or__1927000174__auto____4) { tmp2 = or__1927000174__auto____4 } else { var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_j2g_names_A_const_32.GetRawRoot__O()).Invoke_O__O(s__3); if jrt.J2g_Truth(or__1927000174__auto____5) { tmp2 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_j2g_names_A_const_33.GetRawRoot__O()).Invoke_O__O(s__3); if jrt.J2g_Truth(or__1927000174__auto____6) { tmp2 = or__1927000174__auto____6 } else { var or__1927000174__auto____7 bool = jrt.Character_IsUpperCase_C__Z_NoInit(jrt.NN(jrt.String_Cast(s__3)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0))); if or__1927000174__auto____7 { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var or__1927000174__auto____8 any; var root_155 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_157 lang.IFn

		if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = s__3; var arg_159 any = Lit_20; if linked_156 == nil { or__1927000174__auto____8 = ifn_157.Invoke_O_O__O(arg_158, arg_159) } else { or__1927000174__auto____8 = linked_156.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_155, arg_158, arg_159) }
//line :91:1
		if jrt.J2g_Truth(or__1927000174__auto____8) { tmp2 = or__1927000174__auto____8 } else { var or__1927000174__auto____9 any; var root_160 any = A_arbace_j2g_names_A_const_34.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_162 lang.IFn

			if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = A_arbace_j2g_names_A_const_35; var arg_164 any = s__3; if linked_161 == nil { or__1927000174__auto____9 = ifn_162.Invoke_O_O__O(arg_163, arg_164) } else { or__1927000174__auto____9 = linked_161.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_160, arg_163, arg_164) }
//line :91:1
			if jrt.J2g_Truth(or__1927000174__auto____9) { tmp2 = or__1927000174__auto____9 } else {

				var root_165 any = A_arbace_j2g_names_A_const_34.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = A_arbace_j2g_names_A_const_36; var arg_169 any = s__3; if linked_166 == nil { tmp2 = ifn_167.Invoke_O_O__O(arg_168, arg_169) } else { tmp2 = linked_166.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_165, arg_168, arg_169) } } } } } } }; if /*line :91:1*/ jrt.J2g_Truth(tmp2) {


					return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, s__3, nil)).Ref() } else {
//line :91:1
						return s__3 } }











































func A_arbace_j2g_names_compiled_class_QMARK__A_New() *A_arbace_j2g_names_compiled_class_QMARK__A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_compiled_class_QMARK__A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_j2g_names_compiled_class_QMARK__A) Ctor() {}
//line :135:1
func (t *A_arbace_j2g_names_compiled_class_QMARK__A) Invoke_O_O__O(self, internal__0 any) any { var or__1927000174__auto____2 any; var and__1927000168__auto____2 any; var root_170 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_172 lang.IFn; if





	linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = internal__0; var arg_174 any = Lit_1; if linked_171 == nil { and__1927000168__auto____2 = ifn_172.Invoke_O_O__O(arg_173, arg_174) } else { and__1927000168__auto____2 = linked_171.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_170, arg_173, arg_174) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_175 any = A_arbace_j2g_names_A_const_19.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any; var root_179 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_181 lang.IFn; if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = internal__0; var arg_183 any = Lit_2; if linked_180 == nil { arg_178 = ifn_181.Invoke_O_O__O(arg_182, arg_183) } else { arg_178 = linked_180.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_179, arg_182, arg_183) }; if linked_176 == nil { and__1927000168__auto____3 = ifn_177.Invoke_O__O(arg_178) } else { and__1927000168__auto____3 = linked_176.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_175, arg_178) }; if jrt.J2g_Truth(and__1927000168__auto____3) {
		var root_184 any = A_arbace_j2g_names_A_const_19.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any; var root_188 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = internal__0; var arg_192 any = Lit_3; if linked_189 == nil { arg_187 = ifn_190.Invoke_O_O__O(arg_191, arg_192) } else { arg_187 = linked_189.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_188, arg_191, arg_192) }; if linked_185 == nil { or__1927000174__auto____2 = ifn_186.Invoke_O__O(arg_187) } else { or__1927000174__auto____2 = linked_185.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_184, arg_187) } } else {
//line :141:1
			or__1927000174__auto____2 = and__1927000168__auto____3 } } else { or__1927000174__auto____2 = and__1927000168__auto____2 }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var temp__1927000414__auto____3 any; var tmp1 any; var root_193 any = A_arbace_j2g_names_A_const_6.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_195 lang.IFn

				if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = A_arbace_j2g_names_A_const_15.GetRawRoot__O(); if linked_194 == nil { tmp1 = ifn_195.Invoke_O__O(arg_196) } else { tmp1 = linked_194.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_193, arg_196) }; var tmp2 any = tmp1; var tmp3 any; var root_197 any = A_arbace_j2g_names_A_const_16.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, A_arbace_j2g_names_top_of_A_fn_class); var ifn_199 lang.IFn; if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = internal__0; if linked_198 == nil { tmp3 = ifn_199.Invoke_O__O(arg_200) } else { tmp3 = linked_198.(*A_arbace_j2g_names_top_of_A).Invoke_O_O__O(root_197, arg_200) }; temp__1927000414__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp2, tmp3); if jrt.J2g_Truth(temp__1927000414__auto____3) { var p__4 any = temp__1927000414__auto____3; var root_201 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_203 lang.IFn
					if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = p__4; var arg_205 any = Lit_4; if linked_202 == nil { return ifn_203.Invoke_O_O__O(arg_204, arg_205) } else { return linked_202.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_201, arg_204, arg_205) } } else {
//line :143:1
						return nil } } }





























func A_arbace_j2g_names_qualified_QMARK__A_New() *A_arbace_j2g_names_qualified_QMARK__A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_qualified_QMARK__A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_j2g_names_qualified_QMARK__A) Ctor() {}
//line :173:1
func (t *A_arbace_j2g_names_qualified_QMARK__A) Invoke_O_O__O(self, internal__0 any) any {


	var tmp1 any; var or__1927000174__auto____2 any; var root_206 any = A_arbace_j2g_names_A_const_37.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any; var tmp2 any = A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A_New_O(internal__0); var tmp3 *jrt.Class; var fncls__216 *jrt.Class = A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A_fn_class; if fncls__216 == nil { var fncls__216d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A_fn_class = fncls__216d; tmp3 = fncls__216d } else { tmp3 = fncls__216 }; arg_209 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_210 any = A_arbace_j2g_names_A_const_38.GetRawRoot__O(); if linked_207 == nil { or__1927000174__auto____2 = ifn_208.Invoke_O_O__O(arg_209, arg_210) } else { or__1927000174__auto____2 = linked_207.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_206, arg_209, arg_210) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else {
		var root_217 any = A_arbace_j2g_names_A_const_37.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any; var tmp4 any = A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A_New_O(internal__0); var tmp5 *jrt.Class; var fncls__227 *jrt.Class = A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A_fn_class; if fncls__227 == nil { var fncls__227d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A_fn_class = fncls__227d; tmp5 = fncls__227d } else { tmp5 = fncls__227 }; arg_220 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_221 any; var root_228 any = A_arbace_j2g_names_A_const_6.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_230 lang.IFn; if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = A_arbace_j2g_names_A_const_39.GetRawRoot__O(); if linked_229 == nil { arg_221 = ifn_230.Invoke_O__O(arg_231) } else { arg_221 = linked_229.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_228, arg_231) }; if linked_218 == nil { tmp1 = ifn_219.Invoke_O_O__O(arg_220, arg_221) } else { tmp1 = linked_218.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_217, arg_220, arg_221) } }
//line :176:1
	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() }
//line :176:1
func A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A_New_O(p0 any) *A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A{}; t.Ctor_O(p0); return t }
//line :176:1
func (t *A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A) Ctor_O(c__internal any) { t.F_internal = c__internal }
//line :176:1
func (t *A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A) Invoke_O_O__O(self, p1__1768000028_SHARP___1 any) any { var root_211 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_213 lang.IFn; if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any = t.F_internal; var arg_215 any = p1__1768000028_SHARP___1; if linked_212 == nil { return ifn_213.Invoke_O_O__O(arg_214, arg_215) } else { return linked_212.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_211, arg_214, arg_215) } }
func A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A_New_O(p0 any) *A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A{}; t.Ctor_O(p0); return t }
//line :177:1
func (t *A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A) Ctor_O(c__internal any) { t.F_internal = c__internal }
//line :177:1
func (t *A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A) Invoke_O_O__O(self, p1__1768000029_SHARP___1 any) any { var root_222 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_224 lang.IFn; if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any = t.F_internal; var arg_226 any = p1__1768000029_SHARP___1; if linked_223 == nil { return ifn_224.Invoke_O_O__O(arg_225, arg_226) } else { return linked_223.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_222, arg_225, arg_226) } }



func A_arbace_j2g_names_go_class_name_A_New() *A_arbace_j2g_names_go_class_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_go_class_name_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_j2g_names_go_class_name_A) Ctor() {}
//line :181:1
func (t *A_arbace_j2g_names_go_class_name_A) Invoke_O_O__O(self, internal__0 any) any {





	var root_232 any = A_arbace_j2g_names_A_const_40.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, A_arbace_j2g_names_memo_str_fn__1768000018_A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = internal__0; if linked_233 == nil { return ifn_234.Invoke_O__O(arg_235) } else { return linked_233.(*A_arbace_j2g_names_memo_str_fn__1768000018_A).Invoke_O_O__O(root_232, arg_235)
	} }
func A_arbace_j2g_names_go_class_name_STAR__STAR__A_New() *A_arbace_j2g_names_go_class_name_STAR__STAR__A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_go_class_name_STAR__STAR__A{}; t.Ctor(); return t }
//line :189:1
func (t *A_arbace_j2g_names_go_class_name_STAR__STAR__A) Ctor() {}
//line :189:1
func (t *A_arbace_j2g_names_go_class_name_STAR__STAR__A) Invoke_O_O__O(self, internal__0 any) any { var or__1927000174__auto____2 any = lang.RT_Get_O_O__O_NoInit(A_arbace_j2g_names_A_const_41.GetRawRoot__O(), internal__0); if
													jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var tmp1 any; var root_236 any = A_arbace_j2g_names_A_const_42.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, A_arbace_j2g_names_qualified_QMARK__A_fn_class); var ifn_238 lang.IFn
														if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = internal__0; if linked_237 == nil { tmp1 = ifn_238.Invoke_O__O(arg_239) } else { tmp1 = linked_237.(*A_arbace_j2g_names_qualified_QMARK__A).Invoke_O_O__O(root_236, arg_239) }; if jrt.J2g_Truth(tmp1) {
															var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_13, nil); var tmp3 any; var root_240 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any; var root_244 any = A_arbace_j2g_names_A_const_22.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_246 lang.IFn; if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = internal__0; var arg_248 any = Lit_14; var arg_249 any = Lit_7; if linked_245 == nil { arg_243 = ifn_246.Invoke_O_O_O__O(arg_247, arg_248, arg_249) } else { arg_243 = linked_245.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_244, arg_247, arg_248, arg_249) }; if linked_241 == nil { tmp3 = ifn_242.Invoke_O__O(arg_243) } else { tmp3 = linked_241.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_240, arg_243) }; or__1927000174__auto____3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref() } else {
//line :191:1
				or__1927000174__auto____3 = nil }
//line :190:1
		if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var tmp4 any; var root_250 any = A_arbace_j2g_names_A_const_43.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, A_arbace_j2g_names_compiled_class_QMARK__A_fn_class); var ifn_252 lang.IFn


			if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = internal__0; if linked_251 == nil { tmp4 = ifn_252.Invoke_O__O(arg_253) } else { tmp4 = linked_251.(*A_arbace_j2g_names_compiled_class_QMARK__A).Invoke_O_O__O(root_250, arg_253) }; if jrt.J2g_Truth(tmp4) {

				var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_16); var tmp6 any; var root_254 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any; var root_258 any = A_arbace_j2g_names_A_const_22.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = internal__0; var arg_262 any = Lit_14; var arg_263 any = Lit_7; if linked_259 == nil { arg_257 = ifn_260.Invoke_O_O_O__O(arg_261, arg_262, arg_263) } else { arg_257 = linked_259.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_258, arg_261, arg_262, arg_263) }; if linked_255 == nil { tmp6 = ifn_256.Invoke_O__O(arg_257) } else { tmp6 = linked_255.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_254, arg_257) }; or__1927000174__auto____4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6, nil)).Ref() } else {
//line :193:1
					or__1927000174__auto____4 = nil }
//line :190:1
			if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var s__5 any; var root_264 any = A_arbace_j2g_names_A_const_10.GetRawRoot__O(); var linked_265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_264, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_266 lang.IFn





				if linked_265 == nil { ifn_266 = lang.IFn_Cast(root_264) } else { ifn_266 = nil }; var arg_267 any = internal__0; var arg_268 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(internal__0)).LastIndexOf_String__I(Lit_14)))).Ref(); if linked_265 == nil { s__5 = ifn_266.Invoke_O_O__O(arg_267, arg_268) } else { s__5 = linked_265.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_264, arg_267, arg_268) }
//line :190:1
				var s__6 any; var root_269 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_271 lang.IFn






				if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any = s__5; if linked_270 == nil { s__6 = ifn_271.Invoke_O__O(arg_272) } else { s__6 = linked_270.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_269, arg_272) }
				var tmp7 any; var and__1927000168__auto____7 any; var root_273 any = A_arbace_j2g_names_A_const_44.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = s__6; if linked_274 == nil { and__1927000168__auto____7 = ifn_275.Invoke_O__O(arg_276) } else { and__1927000168__auto____7 = linked_274.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_273, arg_276) }; if jrt.J2g_Truth(and__1927000168__auto____7) { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Character_IsUpperCase_C__Z_NoInit(jrt.NN(jrt.String_Cast(s__6)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp7 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp7) { return s__6 } else {

					return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, s__6)).Ref() } } } } }



func A_arbace_j2g_names_capitalize_A_New() *A_arbace_j2g_names_capitalize_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_capitalize_A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_j2g_names_capitalize_A) Ctor() {}
//line :204:1
func (t *A_arbace_j2g_names_capitalize_A) Invoke_O_O__O(self, s__0 any) any {
	var tmp1 any; var root_277 any = A_arbace_j2g_names_A_const_45.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_279 lang.IFn; if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = s__0; if linked_278 == nil { tmp1 = ifn_279.Invoke_O__O(arg_280) } else { tmp1 = linked_278.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_277, arg_280) }; if jrt.J2g_Truth(tmp1) { return s__0 } else { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 any = jrt.Character_ValueOf_C__Character_NoInit(jrt.Character_ToUpperCase_C__C_NoInit(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0)))).Ref(); var tmp4 any; var root_281 any = A_arbace_j2g_names_A_const_10.GetRawRoot__O(); var linked_282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_281, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_283 lang.IFn; if linked_282 == nil { ifn_283 = lang.IFn_Cast(root_281) } else { ifn_283 = nil }; var arg_284 any = s__0; var arg_285 any = A_arbace_j2g_names_A_const_46; if linked_282 == nil { tmp4 = ifn_283.Invoke_O_O__O(arg_284, arg_285) } else { tmp4 = linked_282.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_281, arg_284, arg_285) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4)).Ref()
	}
}






func A_arbace_j2g_names_desc_code_A_New() *A_arbace_j2g_names_desc_code_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_desc_code_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_j2g_names_desc_code_A) Ctor() {}
//line :214:1
func (t *A_arbace_j2g_names_desc_code_A) Invoke_O_O__O(self, d__0 any) any {


	var tmp1 any; var root_286 any = A_arbace_j2g_names_A_const_47.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_288 lang.IFn
	if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = d__0; if linked_287 == nil { tmp1 = ifn_288.Invoke_O__O(arg_289) } else { tmp1 = linked_287.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_286, arg_289) }
//line :217:1
	if jrt.J2g_Truth(tmp1) { var n__2 any; var root_290 any = A_arbace_j2g_names_A_const_48.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_classes_types.A_arbace_classes_types_array_dims_A_fn_class); var ifn_292 lang.IFn
		if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = d__0; if linked_291 == nil { n__2 = ifn_292.Invoke_O__O(arg_293) } else { n__2 = linked_291.(*aot_arbace_classes_types.A_arbace_classes_types_array_dims_A).Invoke_O_O__O(root_290, arg_293) }
//line :217:1
		var e__3 any; var root_294 any = A_arbace_j2g_names_A_const_10.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_296 lang.IFn

		if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any = d__0; var arg_298 any = n__2; if linked_295 == nil { e__3 = ifn_296.Invoke_O_O__O(arg_297, arg_298) } else { e__3 = linked_295.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_294, arg_297, arg_298) }
		var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 any; var root_299 any = A_arbace_j2g_names_A_const_49.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, A_arbace_j2g_names_desc_code_A_fn_class); var ifn_301 lang.IFn; if linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = e__3; if linked_300 == nil { tmp3 = ifn_301.Invoke_O__O(arg_302) } else { tmp3 = linked_300.(*A_arbace_j2g_names_desc_code_A).Invoke_O_O__O(root_299, arg_302) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, n__2)).Ref() } else {
//line :217:1
			if lang.Util_Equiv_O_O__Z_NoInit(d__0, Lit_8) { return Lit_9 } else { var tmp4 any; var root_303 any = A_arbace_j2g_names_A_const_50.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_303, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_305 lang.IFn




				if linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any = d__0; if linked_304 == nil { tmp4 = ifn_305.Invoke_O__O(arg_306) } else { tmp4 = linked_304.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_303, arg_306) }
//line :217:1
				if jrt.J2g_Truth(tmp4) {




					var root_307 any = A_arbace_j2g_names_A_const_51.GetRawRoot__O(); var linked_308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_307, A_arbace_j2g_names_go_class_name_A_fn_class); var ifn_309 lang.IFn; if linked_308 == nil { ifn_309 = lang.IFn_Cast(root_307) } else { ifn_309 = nil }; var arg_310 any; var root_311 any = A_arbace_j2g_names_A_const_52.GetRawRoot__O(); var linked_312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_311, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_313 lang.IFn; if linked_312 == nil { ifn_313 = lang.IFn_Cast(root_311) } else { ifn_313 = nil }; var arg_314 any = d__0; if linked_312 == nil { arg_310 = ifn_313.Invoke_O__O(arg_314) } else { arg_310 = linked_312.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_311, arg_314) }; if linked_308 == nil { return ifn_309.Invoke_O__O(arg_310) } else { return linked_308.(*A_arbace_j2g_names_go_class_name_A).Invoke_O_O__O(root_307, arg_310) } } else {
//line :217:1
						if A_arbace_j2g_names_A_const_14 != nil { return d__0 } else { return nil
						}
					}
			}
		}
}




func A_arbace_j2g_names_method_base_A_New() *A_arbace_j2g_names_method_base_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_method_base_A{}; t.Ctor(); return t }
//line :227:1
func (t *A_arbace_j2g_names_method_base_A) Ctor() {}
//line :227:1
func (t *A_arbace_j2g_names_method_base_A) Invoke_O_O_O__O(self, name__0, desc__1 any) any { var c__3 any = A_arbace_j2g_names_A_const_53.GetRawRoot__O(); var k__4 any = lang.Tuple_Create_O_O__IPersistentVector(name__0, desc__1); var or__1927000174__auto____5 any = jrt.NN(jrt.ConcurrentHashMap_Cast(c__3)).Get_O__O(k__4); if




	jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { var v__6 any; var root_315 any = A_arbace_j2g_names_A_const_54.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, A_arbace_j2g_names_method_base_STAR__A_fn_class); var ifn_317 lang.IFn
		if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any = name__0; var arg_319 any = desc__1; if linked_316 == nil { v__6 = ifn_317.Invoke_O_O__O(arg_318, arg_319) } else { v__6 = linked_316.(*A_arbace_j2g_names_method_base_STAR__A).Invoke_O_O_O__O(root_315, arg_318, arg_319) }
		jrt.NN(jrt.ConcurrentHashMap_Cast(c__3)).Put_O_O__O(k__4, v__6)
//line :232:1
		return v__6 } }




func A_arbace_j2g_names_method_base_STAR__A_New() *A_arbace_j2g_names_method_base_STAR__A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_method_base_STAR__A{}; t.Ctor(); return t }
//line :237:1
func (t *A_arbace_j2g_names_method_base_STAR__A) Ctor() {}
//line :237:1
func (t *A_arbace_j2g_names_method_base_STAR__A) Invoke_O_O_O__O(self, name__0, desc__1 any) any { var vec__1768000041__3 any; var root_320 any = A_arbace_j2g_names_A_const_55.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_322 lang.IFn; if
													linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = desc__1; if linked_321 == nil { vec__1768000041__3 = ifn_322.Invoke_O__O(arg_323) } else { vec__1768000041__3 = linked_321.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_320, arg_323) }; var ps__4 any = /*line :237:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1768000041__3, lang.RT_IntCast_J__I_NoInit(0), nil); var r__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1768000041__3, lang.RT_IntCast_J__I_NoInit(1), nil); var m__6 any; var root_324 any = A_arbace_j2g_names_A_const_56.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, A_arbace_j2g_names_capitalize_A_fn_class); var ifn_326 lang.IFn; if

	linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any; var root_328 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = name__0; if linked_329 == nil { arg_327 = ifn_330.Invoke_O__O(arg_331) } else { arg_327 = linked_329.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_328, arg_331) }; if linked_325 == nil { m__6 = ifn_326.Invoke_O__O(arg_327) } else { m__6 = linked_325.(*A_arbace_j2g_names_capitalize_A).Invoke_O_O__O(root_324, arg_327) }; var m__7 any; var tmp1 any; var root_332 any = /*line :237:1*/A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_332, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_334 lang.IFn; if


	linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any = m__6; var arg_336 any = Lit_7; if linked_333 == nil { tmp1 = ifn_334.Invoke_O_O__O(arg_335, arg_336) } else { tmp1 = linked_333.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_332, arg_335, arg_336) }; if jrt.J2g_Truth(tmp1) { m__7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, m__6)).Ref() } else { m__7 = m__6 }; var tmp2 /*line :241:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_22, nil); var tmp3 any; var root_337 any = A_arbace_j2g_names_A_const_25.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_337, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var arg_341 any; var root_342 any = A_arbace_j2g_names_A_const_26.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any; var tmp4 any = A_arbace_j2g_names_method_base_STAR__fn__1768000044_A_New(); var tmp5 *jrt.Class; var fncls__351 *jrt.Class = A_arbace_j2g_names_method_base_STAR__fn__1768000044_A_fn_class; if fncls__351 == nil { var fncls__351d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_j2g_names_method_base_STAR__fn__1768000044_A_fn_class = fncls__351d; tmp5 = fncls__351d } else { tmp5 = fncls__351 }; arg_345 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_346 any = ps__4; if linked_343 == nil { arg_341 = ifn_344.Invoke_O_O__O(arg_345, arg_346) } else { arg_341 = linked_343.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_342, arg_345, arg_346) }; if linked_338 == nil { tmp3 = ifn_339.Invoke_O_O__O(arg_340, arg_341) } else { tmp3 = linked_338.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_337, arg_340, arg_341) }; var tmp6 any = tmp3; var tmp7 any; var root_352 any = A_arbace_j2g_names_A_const_49.GetRawRoot__O(); var linked_353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_352, A_arbace_j2g_names_desc_code_A_fn_class); var ifn_354 lang.IFn; if linked_353 == nil { ifn_354 = lang.IFn_Cast(root_352) } else { ifn_354 = nil }; var arg_355 any = r__5; if linked_353 == nil { tmp7 = ifn_354.Invoke_O__O(arg_355) } else { tmp7 = linked_353.(*A_arbace_j2g_names_desc_code_A).Invoke_O_O__O(root_352, arg_355) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, m__7, tmp6, nil, tmp7)).Ref() }
//line :241:1
func A_arbace_j2g_names_method_base_STAR__fn__1768000044_A_New() *A_arbace_j2g_names_method_base_STAR__fn__1768000044_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_method_base_STAR__fn__1768000044_A{}; t.Ctor(); return t }
//line :241:1
func (t *A_arbace_j2g_names_method_base_STAR__fn__1768000044_A) Ctor() {}
//line :241:1
func (t *A_arbace_j2g_names_method_base_STAR__fn__1768000044_A) Invoke_O_O__O(self, p1__1768000040_SHARP___1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_7, nil); var tmp2 any; var root_347 any = A_arbace_j2g_names_A_const_49.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, A_arbace_j2g_names_desc_code_A_fn_class); var ifn_349 lang.IFn; if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any = p1__1768000040_SHARP___1; if linked_348 == nil { tmp2 = ifn_349.Invoke_O__O(arg_350) } else { tmp2 = linked_348.(*A_arbace_j2g_names_desc_code_A).Invoke_O_O__O(root_347, arg_350) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_names_ctor_base_A_New() *A_arbace_j2g_names_ctor_base_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_ctor_base_A{}; t.Ctor(); return t }
//line :243:1
func (t *A_arbace_j2g_names_ctor_base_A) Ctor() {}
//line :243:1
func (t *A_arbace_j2g_names_ctor_base_A) Invoke_O_O__O(self, desc__0 any) any { var vec__1768000048__2 any; var root_356 any = A_arbace_j2g_names_A_const_55.GetRawRoot__O(); var linked_357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_356, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_358 lang.IFn; if



	linked_357 == nil { ifn_358 = lang.IFn_Cast(root_356) } else { ifn_358 = nil }; var arg_359 any = desc__0; if linked_357 == nil { vec__1768000048__2 = ifn_358.Invoke_O__O(arg_359) } else { vec__1768000048__2 = linked_357.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_356, arg_359) }; var ps__3 any = /*line :243:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1768000048__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1768000048__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_5, nil); var tmp2 any; var root_360 any = A_arbace_j2g_names_A_const_25.GetRawRoot__O(); var linked_361 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_360, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_362 lang.IFn; _ = ___4; if




	linked_361 == nil { ifn_362 = lang.IFn_Cast(root_360) } else { ifn_362 = nil }; var arg_363 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var arg_364 any; var root_365 any = A_arbace_j2g_names_A_const_26.GetRawRoot__O(); var linked_366 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_365, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_367 lang.IFn; if linked_366 == nil { ifn_367 = lang.IFn_Cast(root_365) } else { ifn_367 = nil }; var arg_368 any; var tmp3 any = A_arbace_j2g_names_ctor_base_fn__1768000051_A_New(); var tmp4 *jrt.Class; var fncls__374 *jrt.Class = A_arbace_j2g_names_ctor_base_fn__1768000051_A_fn_class; if fncls__374 == nil { var fncls__374d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_j2g_names_ctor_base_fn__1768000051_A_fn_class = fncls__374d; tmp4 = fncls__374d } else { tmp4 = fncls__374 }; arg_368 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_369 any = ps__3; if linked_366 == nil { arg_364 = ifn_367.Invoke_O_O__O(arg_368, arg_369) } else { arg_364 = linked_366.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_365, arg_368, arg_369) }; if linked_361 == nil { tmp2 = ifn_362.Invoke_O_O__O(arg_363, arg_364) } else { tmp2 = linked_361.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_360, arg_363, arg_364) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }
//line :248:1
func A_arbace_j2g_names_ctor_base_fn__1768000051_A_New() *A_arbace_j2g_names_ctor_base_fn__1768000051_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_ctor_base_fn__1768000051_A{}; t.Ctor(); return t }
//line :248:1
func (t *A_arbace_j2g_names_ctor_base_fn__1768000051_A) Ctor() {}
//line :248:1
func (t *A_arbace_j2g_names_ctor_base_fn__1768000051_A) Invoke_O_O__O(self, p1__1768000047_SHARP___1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_7, nil); var tmp2 any; var root_370 any = A_arbace_j2g_names_A_const_49.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, A_arbace_j2g_names_desc_code_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = p1__1768000047_SHARP___1; if linked_371 == nil { tmp2 = ifn_372.Invoke_O__O(arg_373) } else { tmp2 = linked_371.(*A_arbace_j2g_names_desc_code_A).Invoke_O_O__O(root_370, arg_373) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_names_new_name_A_New() *A_arbace_j2g_names_new_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_new_name_A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_j2g_names_new_name_A) Ctor() {}
//line :250:1
func (t *A_arbace_j2g_names_new_name_A) Invoke_O_O_O__O(self, cls_go__0, desc__1 any) any { var vec__1768000055__3 any; var root_375 any = A_arbace_j2g_names_A_const_55.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_377 lang.IFn; if


	linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = desc__1; if linked_376 == nil { vec__1768000055__3 = ifn_377.Invoke_O__O(arg_378) } else { vec__1768000055__3 = linked_376.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_375, arg_378) }; var ps__4 any = /*line :250:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1768000055__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1768000055__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_24, nil); var tmp2 any; var root_379 any = A_arbace_j2g_names_A_const_25.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_379, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_381 lang.IFn; _ = ___5; if



	linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var arg_383 any; var root_384 any = A_arbace_j2g_names_A_const_26.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_384, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_386 lang.IFn; if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any; var tmp3 any = A_arbace_j2g_names_new_name_fn__1768000058_A_New(); var tmp4 *jrt.Class; var fncls__393 *jrt.Class = A_arbace_j2g_names_new_name_fn__1768000058_A_fn_class; if fncls__393 == nil { var fncls__393d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_j2g_names_new_name_fn__1768000058_A_fn_class = fncls__393d; tmp4 = fncls__393d } else { tmp4 = fncls__393 }; arg_387 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_388 any = ps__4; if linked_385 == nil { arg_383 = ifn_386.Invoke_O_O__O(arg_387, arg_388) } else { arg_383 = linked_385.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_384, arg_387, arg_388) }; if linked_380 == nil { tmp2 = ifn_381.Invoke_O_O__O(arg_382, arg_383) } else { tmp2 = linked_380.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_379, arg_382, arg_383) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, cls_go__0, nil, tmp2)).Ref() }
//line :254:1
func A_arbace_j2g_names_new_name_fn__1768000058_A_New() *A_arbace_j2g_names_new_name_fn__1768000058_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_new_name_fn__1768000058_A{}; t.Ctor(); return t }
//line :254:1
func (t *A_arbace_j2g_names_new_name_fn__1768000058_A) Ctor() {}
//line :254:1
func (t *A_arbace_j2g_names_new_name_fn__1768000058_A) Invoke_O_O__O(self, p1__1768000054_SHARP___1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_7, nil); var tmp2 any; var root_389 any = A_arbace_j2g_names_A_const_49.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_389, A_arbace_j2g_names_desc_code_A_fn_class); var ifn_391 lang.IFn; if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any = p1__1768000054_SHARP___1; if linked_390 == nil { tmp2 = ifn_391.Invoke_O__O(arg_392) } else { tmp2 = linked_390.(*A_arbace_j2g_names_desc_code_A).Invoke_O_O__O(root_389, arg_392) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_names_field_name_A_New() *A_arbace_j2g_names_field_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_field_name_A{}; t.Ctor(); return t }
//line :256:1
func (t *A_arbace_j2g_names_field_name_A) Ctor() {}
//line :256:1
func (t *A_arbace_j2g_names_field_name_A) Invoke_O_O__O(self, fname__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_10, nil); var tmp2 any; var root_394 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = fname__0; if linked_395 == nil { tmp2 = ifn_396.Invoke_O__O(arg_397) } else { tmp2 = linked_395.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_394, arg_397) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_names_static_field_name_A_New() *A_arbace_j2g_names_static_field_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_static_field_name_A{}; t.Ctor(); return t }
//line :258:1
func (t *A_arbace_j2g_names_static_field_name_A) Ctor() {}
//line :258:1
func (t *A_arbace_j2g_names_static_field_name_A) Invoke_O_O_O__O(self, cls_go__0, fname__1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_7, nil); var tmp2 any; var root_398 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = fname__1; if linked_399 == nil { tmp2 = ifn_400.Invoke_O__O(arg_401) } else { tmp2 = linked_399.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_398, arg_401) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, cls_go__0, nil, tmp2)).Ref() }

func A_arbace_j2g_names_static_method_name_A_New() *A_arbace_j2g_names_static_method_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_static_method_name_A{}; t.Ctor(); return t }
//line :260:1
func (t *A_arbace_j2g_names_static_method_name_A) Ctor() {}
//line :260:1
func (t *A_arbace_j2g_names_static_method_name_A) Invoke_O_O_O_O__O(self, cls_go__0, name__1, desc__2 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_7, nil); var tmp2 any; var root_402 any = A_arbace_j2g_names_A_const_57.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, A_arbace_j2g_names_method_base_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any = name__1; var arg_406 any = desc__2; if linked_403 == nil { tmp2 = ifn_404.Invoke_O_O__O(arg_405, arg_406) } else { tmp2 = linked_403.(*A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_402, arg_405, arg_406) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, cls_go__0, nil, tmp2)).Ref() }

func A_arbace_j2g_names_impl_name_A_New() *A_arbace_j2g_names_impl_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_impl_name_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_j2g_names_impl_name_A) Ctor() {}
//line :262:1
func (t *A_arbace_j2g_names_impl_name_A) Invoke_O_O__O(self, mbase__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_18, nil), jrt.RefArrayOf(jrt.Object_class, nil, mbase__0)).Ref() }




































type A_arbace_j2g_names_A struct{ jrt.Object }

var A_arbace_j2g_names_A_const_pool *jrt.RefArray

var A_arbace_j2g_names_A_const_0 *lang.Var

var A_arbace_j2g_names_A_const_1 any

var A_arbace_j2g_names_A_const_2 any

var A_arbace_j2g_names_A_const_3 *lang.Var

var A_arbace_j2g_names_A_const_4 any

var A_arbace_j2g_names_A_const_5 *lang.Var

var A_arbace_j2g_names_A_const_6 *lang.Var

var A_arbace_j2g_names_A_const_7 *lang.Var

var A_arbace_j2g_names_A_const_8 *lang.Var

var A_arbace_j2g_names_A_const_9 any

var A_arbace_j2g_names_A_const_10 *lang.Var

var A_arbace_j2g_names_A_const_11 any

var A_arbace_j2g_names_A_const_12 *lang.Var

var A_arbace_j2g_names_A_const_13 *lang.Keyword

var A_arbace_j2g_names_A_const_14 *lang.Keyword

var A_arbace_j2g_names_A_const_15 *lang.Var

var A_arbace_j2g_names_A_const_16 *lang.Var

var A_arbace_j2g_names_A_const_17 *lang.Var

var A_arbace_j2g_names_A_const_18 *lang.Keyword

var A_arbace_j2g_names_A_const_19 *lang.Var

var A_arbace_j2g_names_A_const_20 any

var A_arbace_j2g_names_A_const_21 *lang.Var

var A_arbace_j2g_names_A_const_22 *lang.Var

var A_arbace_j2g_names_A_const_23 *lang.Var

var A_arbace_j2g_names_A_const_24 *lang.Var

var A_arbace_j2g_names_A_const_25 *lang.Var

var A_arbace_j2g_names_A_const_26 *lang.Var

var A_arbace_j2g_names_A_const_27 any

var A_arbace_j2g_names_A_const_28 *lang.Var

var A_arbace_j2g_names_A_const_29 *lang.Var

var A_arbace_j2g_names_A_const_30 *lang.Var

var A_arbace_j2g_names_A_const_31 *lang.Var

var A_arbace_j2g_names_A_const_32 *lang.Var

var A_arbace_j2g_names_A_const_33 *lang.Var

var A_arbace_j2g_names_A_const_34 *lang.Var

var A_arbace_j2g_names_A_const_35 any

var A_arbace_j2g_names_A_const_36 any

var A_arbace_j2g_names_A_const_37 *lang.Var

var A_arbace_j2g_names_A_const_38 *lang.Var

var A_arbace_j2g_names_A_const_39 *lang.Var

var A_arbace_j2g_names_A_const_40 *lang.Var

var A_arbace_j2g_names_A_const_41 *lang.Var

var A_arbace_j2g_names_A_const_42 *lang.Var

var A_arbace_j2g_names_A_const_43 *lang.Var

var A_arbace_j2g_names_A_const_44 *lang.Var

var A_arbace_j2g_names_A_const_45 *lang.Var

var A_arbace_j2g_names_A_const_46 any

var A_arbace_j2g_names_A_const_47 *lang.Var

var A_arbace_j2g_names_A_const_48 *lang.Var

var A_arbace_j2g_names_A_const_49 *lang.Var

var A_arbace_j2g_names_A_const_50 *lang.Var

var A_arbace_j2g_names_A_const_51 *lang.Var

var A_arbace_j2g_names_A_const_52 *lang.Var

var A_arbace_j2g_names_A_const_53 *lang.Var

var A_arbace_j2g_names_A_const_54 *lang.Var

var A_arbace_j2g_names_A_const_55 *lang.Var

var A_arbace_j2g_names_A_const_56 *lang.Var

var A_arbace_j2g_names_A_const_57 *lang.Var

var A_arbace_j2g_names_A_init jrt.ClassInit

func A_arbace_j2g_names_A_Init() { if !A_arbace_j2g_names_A_init.Done() { A_arbace_j2g_names_A_init.Run(A_arbace_j2g_names_A_clinit) } }

func A_arbace_j2g_names_A_clinit() { A_arbace_j2g_names_A_clinit_p0(); A_arbace_j2g_names_A_clinit_p1(); A_arbace_j2g_names_A_clinit_p2(); A_arbace_j2g_names_A_clinit_p3(); A_arbace_j2g_names_A_clinit_p4() }

func A_arbace_j2g_names_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_names_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 68); A_arbace_j2g_names_A_const_0 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[10]); A_arbace_j2g_names_A_const_1 = A_arbace_j2g_names_A_const_pool.A[11]; A_arbace_j2g_names_A_const_2 = A_arbace_j2g_names_A_const_pool.A[12]; A_arbace_j2g_names_A_const_3 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[13]); A_arbace_j2g_names_A_const_4 = A_arbace_j2g_names_A_const_pool.A[14]; A_arbace_j2g_names_A_const_5 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[15]); A_arbace_j2g_names_A_const_6 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[16]); A_arbace_j2g_names_A_const_7 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[17]); A_arbace_j2g_names_A_const_8 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[18]); A_arbace_j2g_names_A_const_9 = A_arbace_j2g_names_A_const_pool.A[19]; A_arbace_j2g_names_A_const_10 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[20]); A_arbace_j2g_names_A_const_11 = A_arbace_j2g_names_A_const_pool.A[21] }

func A_arbace_j2g_names_A_clinit_p1() { A_arbace_j2g_names_A_const_12 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[22]); A_arbace_j2g_names_A_const_13 = lang.Keyword_Cast(A_arbace_j2g_names_A_const_pool.A[23]); A_arbace_j2g_names_A_const_14 = lang.Keyword_Cast(A_arbace_j2g_names_A_const_pool.A[24]); A_arbace_j2g_names_A_const_15 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[25]); A_arbace_j2g_names_A_const_16 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[26]); A_arbace_j2g_names_A_const_17 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[27]); A_arbace_j2g_names_A_const_18 = lang.Keyword_Cast(A_arbace_j2g_names_A_const_pool.A[28]); A_arbace_j2g_names_A_const_19 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[29]); A_arbace_j2g_names_A_const_20 = A_arbace_j2g_names_A_const_pool.A[30]; A_arbace_j2g_names_A_const_21 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[31]); A_arbace_j2g_names_A_const_22 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[32]); A_arbace_j2g_names_A_const_23 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[33]) }

func A_arbace_j2g_names_A_clinit_p2() { A_arbace_j2g_names_A_const_24 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[34]); A_arbace_j2g_names_A_const_25 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[35]); A_arbace_j2g_names_A_const_26 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[36]); A_arbace_j2g_names_A_const_27 = A_arbace_j2g_names_A_const_pool.A[37]; A_arbace_j2g_names_A_const_28 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[38]); A_arbace_j2g_names_A_const_29 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[39]); A_arbace_j2g_names_A_const_30 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[40]); A_arbace_j2g_names_A_const_31 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[41]); A_arbace_j2g_names_A_const_32 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[42]); A_arbace_j2g_names_A_const_33 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[43]); A_arbace_j2g_names_A_const_34 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[44]); A_arbace_j2g_names_A_const_35 = A_arbace_j2g_names_A_const_pool.A[45] }

func A_arbace_j2g_names_A_clinit_p3() { A_arbace_j2g_names_A_const_36 = A_arbace_j2g_names_A_const_pool.A[46]; A_arbace_j2g_names_A_const_37 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[47]); A_arbace_j2g_names_A_const_38 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[48]); A_arbace_j2g_names_A_const_39 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[49]); A_arbace_j2g_names_A_const_40 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[50]); A_arbace_j2g_names_A_const_41 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[51]); A_arbace_j2g_names_A_const_42 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[52]); A_arbace_j2g_names_A_const_43 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[53]); A_arbace_j2g_names_A_const_44 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[54]); A_arbace_j2g_names_A_const_45 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[55]); A_arbace_j2g_names_A_const_46 = A_arbace_j2g_names_A_const_pool.A[56]; A_arbace_j2g_names_A_const_47 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[57]) }

func A_arbace_j2g_names_A_clinit_p4() { A_arbace_j2g_names_A_const_48 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[58]); A_arbace_j2g_names_A_const_49 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[59]); A_arbace_j2g_names_A_const_50 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[60]); A_arbace_j2g_names_A_const_51 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[61]); A_arbace_j2g_names_A_const_52 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[62]); A_arbace_j2g_names_A_const_53 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[63]); A_arbace_j2g_names_A_const_54 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[64]); A_arbace_j2g_names_A_const_55 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[65]); A_arbace_j2g_names_A_const_56 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[66]); A_arbace_j2g_names_A_const_57 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[67]) }

func A_arbace_j2g_names_A_New() *A_arbace_j2g_names_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_names_A) Ctor() {}

func (t *A_arbace_j2g_names_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_names_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_names_A_class }

func (t *A_arbace_j2g_names_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_names_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_names_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_names_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_names_A); return ok }

func A_arbace_j2g_names_A_Cast(x any) *A_arbace_j2g_names_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_names_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_names_A_class)) }; return v }



type A_arbace_j2g_names_capitalize_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_capitalize_A_fn_class *jrt.Class



type A_arbace_j2g_names_compiled_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_names_compiled_class_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_names_compiled_pkg_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_names_compiled_pkg_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_names_ctor_base_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_ctor_base_A_fn_class *jrt.Class



type A_arbace_j2g_names_ctor_base_fn__1768000051_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_ctor_base_fn__1768000051_A_fn_class *jrt.Class



type A_arbace_j2g_names_desc_code_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_desc_code_A_fn_class *jrt.Class



type A_arbace_j2g_names_eval1768000004_A struct{ jrt.Object }

func A_arbace_j2g_names_eval1768000004_A_New() *A_arbace_j2g_names_eval1768000004_A { t := &A_arbace_j2g_names_eval1768000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_names_eval1768000004_A) Ctor() {}

func (t *A_arbace_j2g_names_eval1768000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_names_eval1768000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_names_eval1768000004_A_class }

func (t *A_arbace_j2g_names_eval1768000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_names_eval1768000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_names_eval1768000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_names_eval1768000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_names_eval1768000004_A); return ok }

func A_arbace_j2g_names_eval1768000004_A_Cast(x any) *A_arbace_j2g_names_eval1768000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_names_eval1768000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_names_eval1768000004_A_class)) }; return v }



type A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A_fn_class *jrt.Class



type A_arbace_j2g_names_eval1768000008_A struct{ jrt.Object }

func A_arbace_j2g_names_eval1768000008_A_New() *A_arbace_j2g_names_eval1768000008_A { t := &A_arbace_j2g_names_eval1768000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_names_eval1768000008_A) Ctor() {}

func (t *A_arbace_j2g_names_eval1768000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_names_eval1768000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_names_eval1768000008_A_class }

func (t *A_arbace_j2g_names_eval1768000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_names_eval1768000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_names_eval1768000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_names_eval1768000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_names_eval1768000008_A); return ok }

func A_arbace_j2g_names_eval1768000008_A_Cast(x any) *A_arbace_j2g_names_eval1768000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_names_eval1768000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_names_eval1768000008_A_class)) }; return v }



type A_arbace_j2g_names_eval1768000008_fn__1768000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_eval1768000008_fn__1768000009_A_fn_class *jrt.Class



type A_arbace_j2g_names_field_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_field_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_fn__1768000021_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_fn__1768000021_A_fn_class *jrt.Class



type A_arbace_j2g_names_fn__1768000021_fn__1768000022_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_fn__1768000021_fn__1768000022_A_fn_class *jrt.Class



type A_arbace_j2g_names_go_class_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_go_class_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_go_class_name_STAR__STAR__A struct{ j2g_header uint64 }

var A_arbace_j2g_names_go_class_name_STAR__STAR__A_fn_class *jrt.Class



type A_arbace_j2g_names_impl_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_impl_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_local_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_local_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_memo_str_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_memo_str_A_fn_class *jrt.Class



type A_arbace_j2g_names_memo_str_fn__1768000018_A struct{ j2g_header uint64; F_cache, F_f any }

var A_arbace_j2g_names_memo_str_fn__1768000018_A_fn_class *jrt.Class



type A_arbace_j2g_names_method_base_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_method_base_A_fn_class *jrt.Class



type A_arbace_j2g_names_method_base_STAR__A struct{ j2g_header uint64 }

var A_arbace_j2g_names_method_base_STAR__A_fn_class *jrt.Class



type A_arbace_j2g_names_method_base_STAR__fn__1768000044_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_method_base_STAR__fn__1768000044_A_fn_class *jrt.Class



type A_arbace_j2g_names_munge_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_munge_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_new_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_new_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_new_name_fn__1768000058_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_new_name_fn__1768000058_A_fn_class *jrt.Class



type A_arbace_j2g_names_pkg_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_pkg_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_pkg_ns_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_pkg_ns_A_fn_class *jrt.Class



type A_arbace_j2g_names_pkg_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_pkg_of_A_fn_class *jrt.Class



type A_arbace_j2g_names_pkg_path_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_pkg_path_A_fn_class *jrt.Class



type A_arbace_j2g_names_qualified_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_names_qualified_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A struct{ j2g_header uint64; F_internal any }

var A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A_fn_class *jrt.Class



type A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A struct{ j2g_header uint64; F_internal any }

var A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A_fn_class *jrt.Class



type A_arbace_j2g_names_static_field_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_static_field_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_static_method_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_static_method_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_top_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_top_of_A_fn_class *jrt.Class
