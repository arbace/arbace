//line aot_arbace_j2g_names.ae:1
package aot_arbace_j2g_names

import (
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A_New() *A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_names_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_names_A_const_4); tmp2 = lang.IFn_Cast(A_arbace_j2g_names_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_names_A_const_1, A_arbace_j2g_names_A_const_2); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_names_eval1768000008_fn__1768000009_A_New() *A_arbace_j2g_names_eval1768000008_fn__1768000009_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_eval1768000008_fn__1768000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_names_eval1768000008_fn__1768000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_names_eval1768000008_fn__1768000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_names_A_const_5.GetRawRoot__O()); var tmp2 any; var root_16 any = A_arbace_j2g_names_A_const_6.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = A_arbace_j2g_names_A_const_7; if linked_17 == nil { tmp2 = ifn_18.Invoke_O__O(arg_19) } else { tmp2 = linked_17.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_16, arg_19) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_names_A_const_8.GetRawRoot__O(), A_arbace_j2g_names_A_const_9) }















func A_arbace_j2g_names_top_of_A_New() *A_arbace_j2g_names_top_of_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_top_of_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_j2g_names_top_of_A) Ctor() {}
//line :17:1
func (t *A_arbace_j2g_names_top_of_A) Invoke_O_O__O(self, n__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_11); if lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return n__0 } else { var root_20 any = A_arbace_j2g_names_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = n__0; var arg_24 any = A_arbace_j2g_names_A_const_11; var arg_25 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_21 == nil { return ifn_22.Invoke_O_O_O__O(arg_23, arg_24, arg_25) } else { return linked_21.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_20, arg_23, arg_24, arg_25) } } }

func A_arbace_j2g_names_pkg_of_A_New() *A_arbace_j2g_names_pkg_of_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_pkg_of_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_j2g_names_pkg_of_A) Ctor() {}
//line :19:1
func (t *A_arbace_j2g_names_pkg_of_A) Invoke_O_O__O(self, internal__0 any) any {




	var tmp1 any; var or__1927000174__auto____2 any; var root_26 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_28 lang.IFn
	if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = internal__0; var arg_30 any = Lit_26; if linked_27 == nil { or__1927000174__auto____2 = ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { or__1927000174__auto____2 = linked_27.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_26, arg_29, arg_30) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_31 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = internal__0; var arg_35 any = Lit_27; if linked_32 == nil { or__1927000174__auto____3 = ifn_33.Invoke_O_O__O(arg_34, arg_35) } else { or__1927000174__auto____3 = linked_32.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_31, arg_34, arg_35) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var root_36 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_38 lang.IFn
		if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = internal__0; var arg_40 any = Lit_28; if linked_37 == nil { or__1927000174__auto____4 = ifn_38.Invoke_O_O__O(arg_39, arg_40) } else { or__1927000174__auto____4 = linked_37.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_36, arg_39, arg_40) }
//line :25:1
		if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { var or__1927000174__auto____5 any; var root_41 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_43 lang.IFn
			if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = internal__0; var arg_45 any = Lit_29; if linked_42 == nil { or__1927000174__auto____5 = ifn_43.Invoke_O_O__O(arg_44, arg_45) } else { or__1927000174__auto____5 = linked_42.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_41, arg_44, arg_45) }
//line :25:1
			if jrt.J2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else {

				var root_46 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = internal__0; var arg_50 any = Lit_30; if linked_47 == nil { tmp1 = ifn_48.Invoke_O_O__O(arg_49, arg_50) } else { tmp1 = linked_47.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_46, arg_49, arg_50) } } } } }
//line :24:1
	if jrt.J2g_Truth(tmp1) { return A_arbace_j2g_names_A_const_13 } else { if A_arbace_j2g_names_A_const_14 != nil { var temp__1927000408__auto____2 any; var tmp2 any; var root_51 any = A_arbace_j2g_names_A_const_6.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_53 lang.IFn



		if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = A_arbace_j2g_names_A_const_15.GetRawRoot__O(); if linked_52 == nil { tmp2 = ifn_53.Invoke_O__O(arg_54) } else { tmp2 = linked_52.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_51, arg_54) }; var tmp3 any = tmp2; var tmp4 any; var root_55 any = A_arbace_j2g_names_A_const_16.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, A_arbace_j2g_names_top_of_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = internal__0; if linked_56 == nil { tmp4 = ifn_57.Invoke_O__O(arg_58) } else { tmp4 = linked_56.(*A_arbace_j2g_names_top_of_A).Invoke_O_O__O(root_55, arg_58) }; temp__1927000408__auto____2 = lang.RT_Get_O_O__O_NoInit(tmp3, tmp4); if jrt.J2g_Truth(temp__1927000408__auto____2) { var p__3 any = temp__1927000408__auto____2; var root_59 any = A_arbace_j2g_names_A_const_17.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = p__3; if linked_60 == nil { return ifn_61.Invoke_O__O(arg_62) } else { return linked_60.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_59, arg_62) } } else { return A_arbace_j2g_names_A_const_18 } } else {
//line :24:1
			return nil
		}
	}
}


func A_arbace_j2g_names_compiled_pkg_QMARK__A_New() *A_arbace_j2g_names_compiled_pkg_QMARK__A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_compiled_pkg_QMARK__A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_j2g_names_compiled_pkg_QMARK__A) Ctor() {}
//line :30:1
func (t *A_arbace_j2g_names_compiled_pkg_QMARK__A) Invoke_O_O__O(self, pkg__0 any) any { var root_63 any = A_arbace_j2g_names_A_const_19.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = lang.IFn_Cast(A_arbace_j2g_names_A_const_20).Invoke_O__O(pkg__0); if linked_64 == nil { return ifn_65.Invoke_O__O(arg_66) } else { return linked_64.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_63, arg_66) } }

func A_arbace_j2g_names_pkg_name_A_New() *A_arbace_j2g_names_pkg_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_pkg_name_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_j2g_names_pkg_name_A) Ctor() {}
//line :32:1
func (t *A_arbace_j2g_names_pkg_name_A) Invoke_O_O__O(self, pkg__0 any) any { var root_67 any = A_arbace_j2g_names_A_const_21.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_69 lang.IFn; if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = pkg__0; if linked_68 == nil { return ifn_69.Invoke_O__O(arg_70) } else { return linked_68.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_67, arg_70) } }
func A_arbace_j2g_names_pkg_path_A_New() *A_arbace_j2g_names_pkg_path_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_pkg_path_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_j2g_names_pkg_path_A) Ctor() {}
//line :33:1
func (t *A_arbace_j2g_names_pkg_path_A) Invoke_O_O__O(self, pkg__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_1, nil); var tmp2 any; var root_71 any = A_arbace_j2g_names_A_const_21.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_73 lang.IFn; if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = pkg__0; if linked_72 == nil { tmp2 = ifn_73.Invoke_O__O(arg_74) } else { tmp2 = linked_72.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_71, arg_74) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }
func A_arbace_j2g_names_pkg_ns_A_New() *A_arbace_j2g_names_pkg_ns_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_pkg_ns_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_j2g_names_pkg_ns_A) Ctor() {}
//line :34:1
func (t *A_arbace_j2g_names_pkg_ns_A) Invoke_O_O__O(self, pkg__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_25, nil); var tmp2 any; var root_75 any = A_arbace_j2g_names_A_const_21.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = pkg__0; if linked_76 == nil { tmp2 = ifn_77.Invoke_O__O(arg_78) } else { tmp2 = linked_76.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_75, arg_78) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }



















func A_arbace_j2g_names_memo_str_A_New() *A_arbace_j2g_names_memo_str_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_memo_str_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_j2g_names_memo_str_A) Ctor() {}
//line :54:1
func (t *A_arbace_j2g_names_memo_str_A) Invoke_O_O__O(self, f__0 any) any { var cache__2 any = jrt.ConcurrentHashMap_New(); var tmp1 any = A_arbace_j2g_names_memo_str_fn__1768000018_A_New_O_O(cache__2, f__0); var tmp2 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_j2g_names_memo_str_fn__1768000018_A_fn_class; if




	fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_j2g_names_memo_str_fn__1768000018_A_fn_class = fncls__79d; tmp2 = fncls__79d } else { tmp2 = fncls__79 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :59:1
func A_arbace_j2g_names_memo_str_fn__1768000018_A_New_O_O(p0, p1 any) *A_arbace_j2g_names_memo_str_fn__1768000018_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_memo_str_fn__1768000018_A{}; t.Ctor_O_O(p0, p1); return t }
//line :59:1
func (t *A_arbace_j2g_names_memo_str_fn__1768000018_A) Ctor_O_O(c__cache, c__f any) { t.F_cache = c__cache; t.F_f = c__f }
//line :59:1
func (t *A_arbace_j2g_names_memo_str_fn__1768000018_A) Invoke_O_O__O(self, k__1 any) any { var or__1927000174__auto____2 any = jrt.NN(jrt.ConcurrentHashMap_Cast(t.F_cache)).Get_O__O(k__1); if
												jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var v__3 any = lang.IFn_Cast(t.F_f).Invoke_O__O(k__1)

		jrt.NN(jrt.ConcurrentHashMap_Cast(t.F_cache)).Put_O_O__O(k__1, v__3)
//line :60:1
		return v__3 } }






func A_arbace_j2g_names_fn__1768000021_A_New() *A_arbace_j2g_names_fn__1768000021_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_fn__1768000021_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_j2g_names_fn__1768000021_A) Ctor() {}
//line :67:1
func (t *A_arbace_j2g_names_fn__1768000021_A) Invoke_O_O__O(self, s__0 any) any { var m__2 any; var root_80 any = A_arbace_j2g_names_A_const_22.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_82 lang.IFn; if
										linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any; var root_86 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_88 lang.IFn; if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any; var root_90 any = A_arbace_j2g_names_A_const_24.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_munge_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = s__0; if linked_91 == nil { arg_89 = ifn_92.Invoke_O__O(arg_93) } else { arg_89 = linked_91.(*aot_arbace_core.A_arbace_core_munge_A).Invoke_O_O__O(root_90, arg_93) }; if linked_87 == nil { arg_83 = ifn_88.Invoke_O__O(arg_89) } else { arg_83 = linked_87.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_86, arg_89) }; var arg_84 any = Lit_11; var arg_85 any = Lit_7; if linked_81 == nil { m__2 = ifn_82.Invoke_O_O_O__O(arg_83, arg_84, arg_85) } else { m__2 = linked_81.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_80, arg_83, arg_84, arg_85) }; var root_94 any =


	A_arbace_j2g_names_A_const_25.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var arg_98 any; var root_99 any = A_arbace_j2g_names_A_const_26.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any; var tmp1 any = A_arbace_j2g_names_fn__1768000021_fn__1768000022_A_New(); var tmp2 *jrt.Class; var fncls__104 *jrt.Class = A_arbace_j2g_names_fn__1768000021_fn__1768000022_A_fn_class; if fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_j2g_names_fn__1768000021_fn__1768000022_A_fn_class = fncls__104d; tmp2 = fncls__104d } else { tmp2 = fncls__104 }; arg_102 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_103 any = m__2; if linked_100 == nil { arg_98 = ifn_101.Invoke_O_O__O(arg_102, arg_103) } else { arg_98 = linked_100.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_99, arg_102, arg_103) }; if linked_95 == nil { return ifn_96.Invoke_O_O__O(arg_97, arg_98) } else { return linked_95.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_94, arg_97, arg_98) } }
//line :71:1
func A_arbace_j2g_names_fn__1768000021_fn__1768000022_A_New() *A_arbace_j2g_names_fn__1768000021_fn__1768000022_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_fn__1768000021_fn__1768000022_A{}; t.Ctor(); return t }
//line :71:1
func (t *A_arbace_j2g_names_fn__1768000021_fn__1768000022_A) Ctor() {}
//line :71:1
func (t *A_arbace_j2g_names_fn__1768000021_fn__1768000022_A) Invoke_O_O__O(self, c__1 any) any { var tmp1 bool; var or__1927000174__auto____2 bool = jrt.Character_IsLetterOrDigit_C__Z_NoInit(lang.RT_CharCast_O__C_NoInit(c__1)); if or__1927000174__auto____2 { tmp1 = or__1927000174__auto____2 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(c__1, A_arbace_j2g_names_A_const_27) }; if tmp1 { return c__1 } else { return A_arbace_j2g_names_A_const_27 } }

func A_arbace_j2g_names_munge_name_A_New() *A_arbace_j2g_names_munge_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_munge_name_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_j2g_names_munge_name_A) Ctor() {}
//line :73:1
func (t *A_arbace_j2g_names_munge_name_A) Invoke_O_O__O(self, s__0 any) any {


	var root_105 any = A_arbace_j2g_names_A_const_28.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, A_arbace_j2g_names_memo_str_fn__1768000018_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any; var root_109 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = s__0; if linked_110 == nil { arg_108 = ifn_111.Invoke_O__O(arg_112) } else { arg_108 = linked_110.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_109, arg_112) }; if linked_106 == nil { return ifn_107.Invoke_O__O(arg_108) } else { return linked_106.(*A_arbace_j2g_names_memo_str_fn__1768000018_A).Invoke_O_O__O(root_105, arg_108)
	} }
func A_arbace_j2g_names_local_name_A_New() *A_arbace_j2g_names_local_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_local_name_A{}; t.Ctor(); return t }
//line :78:1
func (t *A_arbace_j2g_names_local_name_A) Ctor() {}
//line :78:1
func (t *A_arbace_j2g_names_local_name_A) Invoke_O_O__O(self, sym__0 any) any { var s__2 any; var root_113 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_115 lang.IFn; if




	linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any; var root_117 any = A_arbace_j2g_names_A_const_21.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = sym__0; if linked_118 == nil { arg_116 = ifn_119.Invoke_O__O(arg_120) } else { arg_116 = linked_118.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_117, arg_120) }; if linked_114 == nil { s__2 = ifn_115.Invoke_O__O(arg_116) } else { s__2 = linked_114.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_113, arg_116) }; var s__3 any; var tmp1 any; var root_121 any = /*line :78:1*/A_arbace_j2g_names_A_const_30.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, aot_arbace_string.A_arbace_string_blank_QMARK__A_fn_class); var ifn_123 lang.IFn; if





	linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = s__2; if linked_122 == nil { tmp1 = ifn_123.Invoke_O__O(arg_124) } else { tmp1 = linked_122.(*aot_arbace_string.A_arbace_string_blank_QMARK__A).Invoke_O_O__O(root_121, arg_124) }; if jrt.J2g_Truth(tmp1) { s__3 = Lit_18 } else { s__3 = s__2 }; var tmp2 any; var or__1927000174__auto____4 any =
	lang.IFn_Cast(A_arbace_j2g_names_A_const_31.GetRawRoot__O()).Invoke_O__O(s__3); if jrt.J2g_Truth(or__1927000174__auto____4) { tmp2 = or__1927000174__auto____4 } else { var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_j2g_names_A_const_32.GetRawRoot__O()).Invoke_O__O(s__3); if jrt.J2g_Truth(or__1927000174__auto____5) { tmp2 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_j2g_names_A_const_33.GetRawRoot__O()).Invoke_O__O(s__3); if jrt.J2g_Truth(or__1927000174__auto____6) { tmp2 = or__1927000174__auto____6 } else { var or__1927000174__auto____7 bool = jrt.Character_IsUpperCase_C__Z_NoInit(jrt.NN(jrt.String_Cast(s__3)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0))); if or__1927000174__auto____7 { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var or__1927000174__auto____8 any; var root_125 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_127 lang.IFn

		if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = s__3; var arg_129 any = Lit_19; if linked_126 == nil { or__1927000174__auto____8 = ifn_127.Invoke_O_O__O(arg_128, arg_129) } else { or__1927000174__auto____8 = linked_126.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_125, arg_128, arg_129) }
//line :85:1
		if jrt.J2g_Truth(or__1927000174__auto____8) { tmp2 = or__1927000174__auto____8 } else { var or__1927000174__auto____9 any; var root_130 any = A_arbace_j2g_names_A_const_34.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_132 lang.IFn

			if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = A_arbace_j2g_names_A_const_35; var arg_134 any = s__3; if linked_131 == nil { or__1927000174__auto____9 = ifn_132.Invoke_O_O__O(arg_133, arg_134) } else { or__1927000174__auto____9 = linked_131.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_130, arg_133, arg_134) }
//line :85:1
			if jrt.J2g_Truth(or__1927000174__auto____9) { tmp2 = or__1927000174__auto____9 } else {

				var root_135 any = A_arbace_j2g_names_A_const_34.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = A_arbace_j2g_names_A_const_36; var arg_139 any = s__3; if linked_136 == nil { tmp2 = ifn_137.Invoke_O_O__O(arg_138, arg_139) } else { tmp2 = linked_136.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_135, arg_138, arg_139) } } } } } } }; if /*line :85:1*/ jrt.J2g_Truth(tmp2) {


					return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, s__3, nil)).Ref() } else {
//line :85:1
						return s__3 } }








































func A_arbace_j2g_names_compiled_class_QMARK__A_New() *A_arbace_j2g_names_compiled_class_QMARK__A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_compiled_class_QMARK__A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_j2g_names_compiled_class_QMARK__A) Ctor() {}
//line :126:1
func (t *A_arbace_j2g_names_compiled_class_QMARK__A) Invoke_O_O__O(self, internal__0 any) any { var or__1927000174__auto____2 any; var and__1927000168__auto____2 any; var root_140 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_142 lang.IFn; if





	linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = internal__0; var arg_144 any = Lit_1; if linked_141 == nil { and__1927000168__auto____2 = ifn_142.Invoke_O_O__O(arg_143, arg_144) } else { and__1927000168__auto____2 = linked_141.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_140, arg_143, arg_144) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_145 any = A_arbace_j2g_names_A_const_19.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any; var root_149 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = internal__0; var arg_153 any = Lit_2; if linked_150 == nil { arg_148 = ifn_151.Invoke_O_O__O(arg_152, arg_153) } else { arg_148 = linked_150.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_149, arg_152, arg_153) }; if linked_146 == nil { and__1927000168__auto____3 = ifn_147.Invoke_O__O(arg_148) } else { and__1927000168__auto____3 = linked_146.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_145, arg_148) }; if jrt.J2g_Truth(and__1927000168__auto____3) {
		var root_154 any = A_arbace_j2g_names_A_const_19.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any; var root_158 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_160 lang.IFn; if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any = internal__0; var arg_162 any = Lit_3; if linked_159 == nil { arg_157 = ifn_160.Invoke_O_O__O(arg_161, arg_162) } else { arg_157 = linked_159.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_158, arg_161, arg_162) }; if linked_155 == nil { or__1927000174__auto____2 = ifn_156.Invoke_O__O(arg_157) } else { or__1927000174__auto____2 = linked_155.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_154, arg_157) } } else {
//line :132:1
			or__1927000174__auto____2 = and__1927000168__auto____3 } } else { or__1927000174__auto____2 = and__1927000168__auto____2 }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var temp__1927000414__auto____3 any; var tmp1 any; var root_163 any = A_arbace_j2g_names_A_const_6.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_165 lang.IFn

				if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = A_arbace_j2g_names_A_const_15.GetRawRoot__O(); if linked_164 == nil { tmp1 = ifn_165.Invoke_O__O(arg_166) } else { tmp1 = linked_164.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_163, arg_166) }; var tmp2 any = tmp1; var tmp3 any; var root_167 any = A_arbace_j2g_names_A_const_16.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, A_arbace_j2g_names_top_of_A_fn_class); var ifn_169 lang.IFn; if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any = internal__0; if linked_168 == nil { tmp3 = ifn_169.Invoke_O__O(arg_170) } else { tmp3 = linked_168.(*A_arbace_j2g_names_top_of_A).Invoke_O_O__O(root_167, arg_170) }; temp__1927000414__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp2, tmp3); if jrt.J2g_Truth(temp__1927000414__auto____3) { var p__4 any = temp__1927000414__auto____3; var root_171 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_173 lang.IFn
					if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any = p__4; var arg_175 any = Lit_4; if linked_172 == nil { return ifn_173.Invoke_O_O__O(arg_174, arg_175) } else { return linked_172.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_171, arg_174, arg_175) } } else {
//line :134:1
						return nil } } }




func A_arbace_j2g_names_go_class_name_A_New() *A_arbace_j2g_names_go_class_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_go_class_name_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_j2g_names_go_class_name_A) Ctor() {}
//line :139:1
func (t *A_arbace_j2g_names_go_class_name_A) Invoke_O_O__O(self, internal__0 any) any {





	var root_176 any = A_arbace_j2g_names_A_const_37.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, A_arbace_j2g_names_memo_str_fn__1768000018_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = internal__0; if linked_177 == nil { return ifn_178.Invoke_O__O(arg_179) } else { return linked_177.(*A_arbace_j2g_names_memo_str_fn__1768000018_A).Invoke_O_O__O(root_176, arg_179)
	} }
func A_arbace_j2g_names_go_class_name_STAR__STAR__A_New() *A_arbace_j2g_names_go_class_name_STAR__STAR__A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_go_class_name_STAR__STAR__A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_j2g_names_go_class_name_STAR__STAR__A) Ctor() {}
//line :147:1
func (t *A_arbace_j2g_names_go_class_name_STAR__STAR__A) Invoke_O_O__O(self, internal__0 any) any { var or__1927000174__auto____2 any = lang.RT_Get_O_O__O_NoInit(A_arbace_j2g_names_A_const_38.GetRawRoot__O(), internal__0); if
													jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var tmp1 any; var root_180 any = A_arbace_j2g_names_A_const_39.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, A_arbace_j2g_names_compiled_class_QMARK__A_fn_class); var ifn_182 lang.IFn
														if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = internal__0; if linked_181 == nil { tmp1 = ifn_182.Invoke_O__O(arg_183) } else { tmp1 = linked_181.(*A_arbace_j2g_names_compiled_class_QMARK__A).Invoke_O_O__O(root_180, arg_183) }; if jrt.J2g_Truth(tmp1) {

			var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_13, nil, Lit_14); var tmp3 any; var root_184 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any; var root_188 any = A_arbace_j2g_names_A_const_22.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = internal__0; var arg_192 any = Lit_15; var arg_193 any = Lit_7; if linked_189 == nil { arg_187 = ifn_190.Invoke_O_O_O__O(arg_191, arg_192, arg_193) } else { arg_187 = linked_189.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_188, arg_191, arg_192, arg_193) }; if linked_185 == nil { tmp3 = ifn_186.Invoke_O__O(arg_187) } else { tmp3 = linked_185.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_184, arg_187) }; or__1927000174__auto____3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil)).Ref() } else {
//line :149:1
				or__1927000174__auto____3 = nil }
//line :148:1
		if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var s__4 any; var root_194 any = A_arbace_j2g_names_A_const_10.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_196 lang.IFn



			if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = internal__0; var arg_198 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(internal__0)).LastIndexOf_String__I(Lit_15)))).Ref(); if linked_195 == nil { s__4 = ifn_196.Invoke_O_O__O(arg_197, arg_198) } else { s__4 = linked_195.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_194, arg_197, arg_198) }
//line :148:1
			var s__5 any; var root_199 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_201 lang.IFn




			if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = s__4; if linked_200 == nil { s__5 = ifn_201.Invoke_O__O(arg_202) } else { s__5 = linked_200.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_199, arg_202) }
			var tmp4 any; var and__1927000168__auto____6 any; var root_203 any = A_arbace_j2g_names_A_const_40.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_205 lang.IFn; if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any = s__5; if linked_204 == nil { and__1927000168__auto____6 = ifn_205.Invoke_O__O(arg_206) } else { and__1927000168__auto____6 = linked_204.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_203, arg_206) }; if jrt.J2g_Truth(and__1927000168__auto____6) { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Character_IsUpperCase_C__Z_NoInit(jrt.NN(jrt.String_Cast(s__5)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp4 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp4) { return s__5 } else {

				return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_16, nil), jrt.RefArrayOf(jrt.Object_class, nil, s__5)).Ref() } } } }



func A_arbace_j2g_names_capitalize_A_New() *A_arbace_j2g_names_capitalize_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_capitalize_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_j2g_names_capitalize_A) Ctor() {}
//line :160:1
func (t *A_arbace_j2g_names_capitalize_A) Invoke_O_O__O(self, s__0 any) any {
	var tmp1 any; var root_207 any = A_arbace_j2g_names_A_const_41.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = s__0; if linked_208 == nil { tmp1 = ifn_209.Invoke_O__O(arg_210) } else { tmp1 = linked_208.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_207, arg_210) }; if jrt.J2g_Truth(tmp1) { return s__0 } else { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 any = jrt.Character_ValueOf_C__Character_NoInit(jrt.Character_ToUpperCase_C__C_NoInit(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0)))).Ref(); var tmp4 any; var root_211 any = A_arbace_j2g_names_A_const_10.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_213 lang.IFn; if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any = s__0; var arg_215 any = A_arbace_j2g_names_A_const_42; if linked_212 == nil { tmp4 = ifn_213.Invoke_O_O__O(arg_214, arg_215) } else { tmp4 = linked_212.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_211, arg_214, arg_215) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4)).Ref()
	}
}






func A_arbace_j2g_names_desc_code_A_New() *A_arbace_j2g_names_desc_code_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_desc_code_A{}; t.Ctor(); return t }
//line :170:1
func (t *A_arbace_j2g_names_desc_code_A) Ctor() {}
//line :170:1
func (t *A_arbace_j2g_names_desc_code_A) Invoke_O_O__O(self, d__0 any) any {


	var tmp1 any; var root_216 any = A_arbace_j2g_names_A_const_43.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_218 lang.IFn
	if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = d__0; if linked_217 == nil { tmp1 = ifn_218.Invoke_O__O(arg_219) } else { tmp1 = linked_217.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_216, arg_219) }
//line :173:1
	if jrt.J2g_Truth(tmp1) { var n__2 any; var root_220 any = A_arbace_j2g_names_A_const_44.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, aot_arbace_classes_types.A_arbace_classes_types_array_dims_A_fn_class); var ifn_222 lang.IFn
		if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any = d__0; if linked_221 == nil { n__2 = ifn_222.Invoke_O__O(arg_223) } else { n__2 = linked_221.(*aot_arbace_classes_types.A_arbace_classes_types_array_dims_A).Invoke_O_O__O(root_220, arg_223) }
//line :173:1
		var e__3 any; var root_224 any = A_arbace_j2g_names_A_const_10.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_226 lang.IFn

		if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = d__0; var arg_228 any = n__2; if linked_225 == nil { e__3 = ifn_226.Invoke_O_O__O(arg_227, arg_228) } else { e__3 = linked_225.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_224, arg_227, arg_228) }
		var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 any; var root_229 any = A_arbace_j2g_names_A_const_45.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_229, A_arbace_j2g_names_desc_code_A_fn_class); var ifn_231 lang.IFn; if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any = e__3; if linked_230 == nil { tmp3 = ifn_231.Invoke_O__O(arg_232) } else { tmp3 = linked_230.(*A_arbace_j2g_names_desc_code_A).Invoke_O_O__O(root_229, arg_232) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, n__2)).Ref() } else {
//line :173:1
			if lang.Util_Equiv_O_O__Z_NoInit(d__0, Lit_8) { return Lit_9 } else { var tmp4 any; var root_233 any = A_arbace_j2g_names_A_const_46.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_235 lang.IFn




				if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any = d__0; if linked_234 == nil { tmp4 = ifn_235.Invoke_O__O(arg_236) } else { tmp4 = linked_234.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_233, arg_236) }
//line :173:1
				if jrt.J2g_Truth(tmp4) {




					var root_237 any = A_arbace_j2g_names_A_const_47.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_237, A_arbace_j2g_names_go_class_name_A_fn_class); var ifn_239 lang.IFn; if linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any; var root_241 any = A_arbace_j2g_names_A_const_48.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_243 lang.IFn; if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any = d__0; if linked_242 == nil { arg_240 = ifn_243.Invoke_O__O(arg_244) } else { arg_240 = linked_242.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_241, arg_244) }; if linked_238 == nil { return ifn_239.Invoke_O__O(arg_240) } else { return linked_238.(*A_arbace_j2g_names_go_class_name_A).Invoke_O_O__O(root_237, arg_240) } } else {
//line :173:1
						if A_arbace_j2g_names_A_const_14 != nil { return d__0 } else { return nil
						}
					}
			}
		}
}




func A_arbace_j2g_names_method_base_A_New() *A_arbace_j2g_names_method_base_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_method_base_A{}; t.Ctor(); return t }
//line :183:1
func (t *A_arbace_j2g_names_method_base_A) Ctor() {}
//line :183:1
func (t *A_arbace_j2g_names_method_base_A) Invoke_O_O_O__O(self, name__0, desc__1 any) any { var c__3 any = A_arbace_j2g_names_A_const_49.GetRawRoot__O(); var k__4 any = lang.Tuple_Create_O_O__IPersistentVector(name__0, desc__1); var or__1927000174__auto____5 any = jrt.NN(jrt.ConcurrentHashMap_Cast(c__3)).Get_O__O(k__4); if




	jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { var v__6 any; var root_245 any = A_arbace_j2g_names_A_const_50.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, A_arbace_j2g_names_method_base_STAR__A_fn_class); var ifn_247 lang.IFn
		if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = name__0; var arg_249 any = desc__1; if linked_246 == nil { v__6 = ifn_247.Invoke_O_O__O(arg_248, arg_249) } else { v__6 = linked_246.(*A_arbace_j2g_names_method_base_STAR__A).Invoke_O_O_O__O(root_245, arg_248, arg_249) }
		jrt.NN(jrt.ConcurrentHashMap_Cast(c__3)).Put_O_O__O(k__4, v__6)
//line :188:1
		return v__6 } }




func A_arbace_j2g_names_method_base_STAR__A_New() *A_arbace_j2g_names_method_base_STAR__A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_method_base_STAR__A{}; t.Ctor(); return t }
//line :193:1
func (t *A_arbace_j2g_names_method_base_STAR__A) Ctor() {}
//line :193:1
func (t *A_arbace_j2g_names_method_base_STAR__A) Invoke_O_O_O__O(self, name__0, desc__1 any) any { var vec__1768000034__3 any; var root_250 any = A_arbace_j2g_names_A_const_51.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_252 lang.IFn; if
													linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = desc__1; if linked_251 == nil { vec__1768000034__3 = ifn_252.Invoke_O__O(arg_253) } else { vec__1768000034__3 = linked_251.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_250, arg_253) }; var ps__4 any = /*line :193:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1768000034__3, lang.RT_IntCast_J__I_NoInit(0), nil); var r__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1768000034__3, lang.RT_IntCast_J__I_NoInit(1), nil); var m__6 any; var root_254 any = A_arbace_j2g_names_A_const_52.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, A_arbace_j2g_names_capitalize_A_fn_class); var ifn_256 lang.IFn; if

	linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any; var root_258 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = name__0; if linked_259 == nil { arg_257 = ifn_260.Invoke_O__O(arg_261) } else { arg_257 = linked_259.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_258, arg_261) }; if linked_255 == nil { m__6 = ifn_256.Invoke_O__O(arg_257) } else { m__6 = linked_255.(*A_arbace_j2g_names_capitalize_A).Invoke_O_O__O(root_254, arg_257) }; var m__7 any; var tmp1 any; var root_262 any = /*line :193:1*/A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_264 lang.IFn; if


	linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = m__6; var arg_266 any = Lit_7; if linked_263 == nil { tmp1 = ifn_264.Invoke_O_O__O(arg_265, arg_266) } else { tmp1 = linked_263.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_262, arg_265, arg_266) }; if jrt.J2g_Truth(tmp1) { m__7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_16, nil), jrt.RefArrayOf(jrt.Object_class, nil, m__6)).Ref() } else { m__7 = m__6 }; var tmp2 /*line :197:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_21, nil); var tmp3 any; var root_267 any = A_arbace_j2g_names_A_const_25.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_267, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var arg_271 any; var root_272 any = A_arbace_j2g_names_A_const_26.GetRawRoot__O(); var linked_273 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_272, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_274 lang.IFn; if linked_273 == nil { ifn_274 = lang.IFn_Cast(root_272) } else { ifn_274 = nil }; var arg_275 any; var tmp4 any = A_arbace_j2g_names_method_base_STAR__fn__1768000037_A_New(); var tmp5 *jrt.Class; var fncls__281 *jrt.Class = A_arbace_j2g_names_method_base_STAR__fn__1768000037_A_fn_class; if fncls__281 == nil { var fncls__281d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_j2g_names_method_base_STAR__fn__1768000037_A_fn_class = fncls__281d; tmp5 = fncls__281d } else { tmp5 = fncls__281 }; arg_275 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_276 any = ps__4; if linked_273 == nil { arg_271 = ifn_274.Invoke_O_O__O(arg_275, arg_276) } else { arg_271 = linked_273.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_272, arg_275, arg_276) }; if linked_268 == nil { tmp3 = ifn_269.Invoke_O_O__O(arg_270, arg_271) } else { tmp3 = linked_268.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_267, arg_270, arg_271) }; var tmp6 any = tmp3; var tmp7 any; var root_282 any = A_arbace_j2g_names_A_const_45.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, A_arbace_j2g_names_desc_code_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = r__5; if linked_283 == nil { tmp7 = ifn_284.Invoke_O__O(arg_285) } else { tmp7 = linked_283.(*A_arbace_j2g_names_desc_code_A).Invoke_O_O__O(root_282, arg_285) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, m__7, tmp6, nil, tmp7)).Ref() }
//line :197:1
func A_arbace_j2g_names_method_base_STAR__fn__1768000037_A_New() *A_arbace_j2g_names_method_base_STAR__fn__1768000037_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_method_base_STAR__fn__1768000037_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_j2g_names_method_base_STAR__fn__1768000037_A) Ctor() {}
//line :197:1
func (t *A_arbace_j2g_names_method_base_STAR__fn__1768000037_A) Invoke_O_O__O(self, p1__1768000033_SHARP___1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_7, nil); var tmp2 any; var root_277 any = A_arbace_j2g_names_A_const_45.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, A_arbace_j2g_names_desc_code_A_fn_class); var ifn_279 lang.IFn; if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = p1__1768000033_SHARP___1; if linked_278 == nil { tmp2 = ifn_279.Invoke_O__O(arg_280) } else { tmp2 = linked_278.(*A_arbace_j2g_names_desc_code_A).Invoke_O_O__O(root_277, arg_280) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_names_ctor_base_A_New() *A_arbace_j2g_names_ctor_base_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_ctor_base_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_j2g_names_ctor_base_A) Ctor() {}
//line :199:1
func (t *A_arbace_j2g_names_ctor_base_A) Invoke_O_O__O(self, desc__0 any) any { var vec__1768000041__2 any; var root_286 any = A_arbace_j2g_names_A_const_51.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_288 lang.IFn; if



	linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = desc__0; if linked_287 == nil { vec__1768000041__2 = ifn_288.Invoke_O__O(arg_289) } else { vec__1768000041__2 = linked_287.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_286, arg_289) }; var ps__3 any = /*line :199:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1768000041__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1768000041__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_5, nil); var tmp2 any; var root_290 any = A_arbace_j2g_names_A_const_25.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_292 lang.IFn; _ = ___4; if




	linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var arg_294 any; var root_295 any = A_arbace_j2g_names_A_const_26.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any; var tmp3 any = A_arbace_j2g_names_ctor_base_fn__1768000044_A_New(); var tmp4 *jrt.Class; var fncls__304 *jrt.Class = A_arbace_j2g_names_ctor_base_fn__1768000044_A_fn_class; if fncls__304 == nil { var fncls__304d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_j2g_names_ctor_base_fn__1768000044_A_fn_class = fncls__304d; tmp4 = fncls__304d } else { tmp4 = fncls__304 }; arg_298 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_299 any = ps__3; if linked_296 == nil { arg_294 = ifn_297.Invoke_O_O__O(arg_298, arg_299) } else { arg_294 = linked_296.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_295, arg_298, arg_299) }; if linked_291 == nil { tmp2 = ifn_292.Invoke_O_O__O(arg_293, arg_294) } else { tmp2 = linked_291.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_290, arg_293, arg_294) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }
//line :204:1
func A_arbace_j2g_names_ctor_base_fn__1768000044_A_New() *A_arbace_j2g_names_ctor_base_fn__1768000044_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_ctor_base_fn__1768000044_A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_j2g_names_ctor_base_fn__1768000044_A) Ctor() {}
//line :204:1
func (t *A_arbace_j2g_names_ctor_base_fn__1768000044_A) Invoke_O_O__O(self, p1__1768000040_SHARP___1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_7, nil); var tmp2 any; var root_300 any = A_arbace_j2g_names_A_const_45.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, A_arbace_j2g_names_desc_code_A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = p1__1768000040_SHARP___1; if linked_301 == nil { tmp2 = ifn_302.Invoke_O__O(arg_303) } else { tmp2 = linked_301.(*A_arbace_j2g_names_desc_code_A).Invoke_O_O__O(root_300, arg_303) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_names_new_name_A_New() *A_arbace_j2g_names_new_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_new_name_A{}; t.Ctor(); return t }
//line :206:1
func (t *A_arbace_j2g_names_new_name_A) Ctor() {}
//line :206:1
func (t *A_arbace_j2g_names_new_name_A) Invoke_O_O_O__O(self, cls_go__0, desc__1 any) any { var vec__1768000048__3 any; var root_305 any = A_arbace_j2g_names_A_const_51.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_305, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_307 lang.IFn; if


	linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any = desc__1; if linked_306 == nil { vec__1768000048__3 = ifn_307.Invoke_O__O(arg_308) } else { vec__1768000048__3 = linked_306.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_305, arg_308) }; var ps__4 any = /*line :206:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1768000048__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1768000048__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_23, nil); var tmp2 any; var root_309 any = A_arbace_j2g_names_A_const_25.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_309, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_311 lang.IFn; _ = ___5; if



	linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var arg_313 any; var root_314 any = A_arbace_j2g_names_A_const_26.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_314, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_316 lang.IFn; if linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any; var tmp3 any = A_arbace_j2g_names_new_name_fn__1768000051_A_New(); var tmp4 *jrt.Class; var fncls__323 *jrt.Class = A_arbace_j2g_names_new_name_fn__1768000051_A_fn_class; if fncls__323 == nil { var fncls__323d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_j2g_names_new_name_fn__1768000051_A_fn_class = fncls__323d; tmp4 = fncls__323d } else { tmp4 = fncls__323 }; arg_317 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_318 any = ps__4; if linked_315 == nil { arg_313 = ifn_316.Invoke_O_O__O(arg_317, arg_318) } else { arg_313 = linked_315.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_314, arg_317, arg_318) }; if linked_310 == nil { tmp2 = ifn_311.Invoke_O_O__O(arg_312, arg_313) } else { tmp2 = linked_310.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_309, arg_312, arg_313) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, cls_go__0, nil, tmp2)).Ref() }
//line :210:1
func A_arbace_j2g_names_new_name_fn__1768000051_A_New() *A_arbace_j2g_names_new_name_fn__1768000051_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_new_name_fn__1768000051_A{}; t.Ctor(); return t }
//line :210:1
func (t *A_arbace_j2g_names_new_name_fn__1768000051_A) Ctor() {}
//line :210:1
func (t *A_arbace_j2g_names_new_name_fn__1768000051_A) Invoke_O_O__O(self, p1__1768000047_SHARP___1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_7, nil); var tmp2 any; var root_319 any = A_arbace_j2g_names_A_const_45.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_319, A_arbace_j2g_names_desc_code_A_fn_class); var ifn_321 lang.IFn; if linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any = p1__1768000047_SHARP___1; if linked_320 == nil { tmp2 = ifn_321.Invoke_O__O(arg_322) } else { tmp2 = linked_320.(*A_arbace_j2g_names_desc_code_A).Invoke_O_O__O(root_319, arg_322) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_names_field_name_A_New() *A_arbace_j2g_names_field_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_field_name_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_j2g_names_field_name_A) Ctor() {}
//line :212:1
func (t *A_arbace_j2g_names_field_name_A) Invoke_O_O__O(self, fname__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_10, nil); var tmp2 any; var root_324 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = fname__0; if linked_325 == nil { tmp2 = ifn_326.Invoke_O__O(arg_327) } else { tmp2 = linked_325.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_324, arg_327) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_names_static_field_name_A_New() *A_arbace_j2g_names_static_field_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_static_field_name_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_j2g_names_static_field_name_A) Ctor() {}
//line :214:1
func (t *A_arbace_j2g_names_static_field_name_A) Invoke_O_O_O__O(self, cls_go__0, fname__1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_7, nil); var tmp2 any; var root_328 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = fname__1; if linked_329 == nil { tmp2 = ifn_330.Invoke_O__O(arg_331) } else { tmp2 = linked_329.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_328, arg_331) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, cls_go__0, nil, tmp2)).Ref() }

func A_arbace_j2g_names_static_method_name_A_New() *A_arbace_j2g_names_static_method_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_static_method_name_A{}; t.Ctor(); return t }
//line :216:1
func (t *A_arbace_j2g_names_static_method_name_A) Ctor() {}
//line :216:1
func (t *A_arbace_j2g_names_static_method_name_A) Invoke_O_O_O_O__O(self, cls_go__0, name__1, desc__2 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_7, nil); var tmp2 any; var root_332 any = A_arbace_j2g_names_A_const_53.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_332, A_arbace_j2g_names_method_base_A_fn_class); var ifn_334 lang.IFn; if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any = name__1; var arg_336 any = desc__2; if linked_333 == nil { tmp2 = ifn_334.Invoke_O_O__O(arg_335, arg_336) } else { tmp2 = linked_333.(*A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_332, arg_335, arg_336) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, cls_go__0, nil, tmp2)).Ref() }

func A_arbace_j2g_names_impl_name_A_New() *A_arbace_j2g_names_impl_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_impl_name_A{}; t.Ctor(); return t }
//line :218:1
func (t *A_arbace_j2g_names_impl_name_A) Ctor() {}
//line :218:1
func (t *A_arbace_j2g_names_impl_name_A) Invoke_O_O__O(self, mbase__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, mbase__0)).Ref() }




































type A_arbace_j2g_names_A struct{ jrt.Object }

var A_arbace_j2g_names_A_const_pool *jrt.RefArray

var A_arbace_j2g_names_A_const_0 *lang.Var

var A_arbace_j2g_names_A_const_1 any

var A_arbace_j2g_names_A_const_2 any

var A_arbace_j2g_names_A_const_3 *lang.Var

var A_arbace_j2g_names_A_const_4 any

var A_arbace_j2g_names_A_const_5 *lang.Var

var A_arbace_j2g_names_A_const_6 *lang.Var

var A_arbace_j2g_names_A_const_7 *lang.Var

var A_arbace_j2g_names_A_const_8 *lang.Var

var A_arbace_j2g_names_A_const_9 any

var A_arbace_j2g_names_A_const_10 *lang.Var

var A_arbace_j2g_names_A_const_11 any

var A_arbace_j2g_names_A_const_12 *lang.Var

var A_arbace_j2g_names_A_const_13 *lang.Keyword

var A_arbace_j2g_names_A_const_14 *lang.Keyword

var A_arbace_j2g_names_A_const_15 *lang.Var

var A_arbace_j2g_names_A_const_16 *lang.Var

var A_arbace_j2g_names_A_const_17 *lang.Var

var A_arbace_j2g_names_A_const_18 *lang.Keyword

var A_arbace_j2g_names_A_const_19 *lang.Var

var A_arbace_j2g_names_A_const_20 any

var A_arbace_j2g_names_A_const_21 *lang.Var

var A_arbace_j2g_names_A_const_22 *lang.Var

var A_arbace_j2g_names_A_const_23 *lang.Var

var A_arbace_j2g_names_A_const_24 *lang.Var

var A_arbace_j2g_names_A_const_25 *lang.Var

var A_arbace_j2g_names_A_const_26 *lang.Var

var A_arbace_j2g_names_A_const_27 any

var A_arbace_j2g_names_A_const_28 *lang.Var

var A_arbace_j2g_names_A_const_29 *lang.Var

var A_arbace_j2g_names_A_const_30 *lang.Var

var A_arbace_j2g_names_A_const_31 *lang.Var

var A_arbace_j2g_names_A_const_32 *lang.Var

var A_arbace_j2g_names_A_const_33 *lang.Var

var A_arbace_j2g_names_A_const_34 *lang.Var

var A_arbace_j2g_names_A_const_35 any

var A_arbace_j2g_names_A_const_36 any

var A_arbace_j2g_names_A_const_37 *lang.Var

var A_arbace_j2g_names_A_const_38 *lang.Var

var A_arbace_j2g_names_A_const_39 *lang.Var

var A_arbace_j2g_names_A_const_40 *lang.Var

var A_arbace_j2g_names_A_const_41 *lang.Var

var A_arbace_j2g_names_A_const_42 any

var A_arbace_j2g_names_A_const_43 *lang.Var

var A_arbace_j2g_names_A_const_44 *lang.Var

var A_arbace_j2g_names_A_const_45 *lang.Var

var A_arbace_j2g_names_A_const_46 *lang.Var

var A_arbace_j2g_names_A_const_47 *lang.Var

var A_arbace_j2g_names_A_const_48 *lang.Var

var A_arbace_j2g_names_A_const_49 *lang.Var

var A_arbace_j2g_names_A_const_50 *lang.Var

var A_arbace_j2g_names_A_const_51 *lang.Var

var A_arbace_j2g_names_A_const_52 *lang.Var

var A_arbace_j2g_names_A_const_53 *lang.Var

var A_arbace_j2g_names_A_init jrt.ClassInit

func A_arbace_j2g_names_A_Init() { if !A_arbace_j2g_names_A_init.Done() { A_arbace_j2g_names_A_init.Run(A_arbace_j2g_names_A_clinit) } }

func A_arbace_j2g_names_A_clinit() { A_arbace_j2g_names_A_clinit_p0(); A_arbace_j2g_names_A_clinit_p1(); A_arbace_j2g_names_A_clinit_p2(); A_arbace_j2g_names_A_clinit_p3(); A_arbace_j2g_names_A_clinit_p4() }

func A_arbace_j2g_names_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_names_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 64); A_arbace_j2g_names_A_const_0 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[10]); A_arbace_j2g_names_A_const_1 = A_arbace_j2g_names_A_const_pool.A[11]; A_arbace_j2g_names_A_const_2 = A_arbace_j2g_names_A_const_pool.A[12]; A_arbace_j2g_names_A_const_3 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[13]); A_arbace_j2g_names_A_const_4 = A_arbace_j2g_names_A_const_pool.A[14]; A_arbace_j2g_names_A_const_5 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[15]); A_arbace_j2g_names_A_const_6 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[16]); A_arbace_j2g_names_A_const_7 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[17]); A_arbace_j2g_names_A_const_8 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[18]); A_arbace_j2g_names_A_const_9 = A_arbace_j2g_names_A_const_pool.A[19]; A_arbace_j2g_names_A_const_10 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[20]); A_arbace_j2g_names_A_const_11 = A_arbace_j2g_names_A_const_pool.A[21] }

func A_arbace_j2g_names_A_clinit_p1() { A_arbace_j2g_names_A_const_12 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[22]); A_arbace_j2g_names_A_const_13 = lang.Keyword_Cast(A_arbace_j2g_names_A_const_pool.A[23]); A_arbace_j2g_names_A_const_14 = lang.Keyword_Cast(A_arbace_j2g_names_A_const_pool.A[24]); A_arbace_j2g_names_A_const_15 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[25]); A_arbace_j2g_names_A_const_16 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[26]); A_arbace_j2g_names_A_const_17 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[27]); A_arbace_j2g_names_A_const_18 = lang.Keyword_Cast(A_arbace_j2g_names_A_const_pool.A[28]); A_arbace_j2g_names_A_const_19 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[29]); A_arbace_j2g_names_A_const_20 = A_arbace_j2g_names_A_const_pool.A[30]; A_arbace_j2g_names_A_const_21 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[31]); A_arbace_j2g_names_A_const_22 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[32]); A_arbace_j2g_names_A_const_23 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[33]) }

func A_arbace_j2g_names_A_clinit_p2() { A_arbace_j2g_names_A_const_24 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[34]); A_arbace_j2g_names_A_const_25 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[35]); A_arbace_j2g_names_A_const_26 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[36]); A_arbace_j2g_names_A_const_27 = A_arbace_j2g_names_A_const_pool.A[37]; A_arbace_j2g_names_A_const_28 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[38]); A_arbace_j2g_names_A_const_29 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[39]); A_arbace_j2g_names_A_const_30 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[40]); A_arbace_j2g_names_A_const_31 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[41]); A_arbace_j2g_names_A_const_32 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[42]); A_arbace_j2g_names_A_const_33 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[43]); A_arbace_j2g_names_A_const_34 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[44]); A_arbace_j2g_names_A_const_35 = A_arbace_j2g_names_A_const_pool.A[45] }

func A_arbace_j2g_names_A_clinit_p3() { A_arbace_j2g_names_A_const_36 = A_arbace_j2g_names_A_const_pool.A[46]; A_arbace_j2g_names_A_const_37 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[47]); A_arbace_j2g_names_A_const_38 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[48]); A_arbace_j2g_names_A_const_39 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[49]); A_arbace_j2g_names_A_const_40 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[50]); A_arbace_j2g_names_A_const_41 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[51]); A_arbace_j2g_names_A_const_42 = A_arbace_j2g_names_A_const_pool.A[52]; A_arbace_j2g_names_A_const_43 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[53]); A_arbace_j2g_names_A_const_44 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[54]); A_arbace_j2g_names_A_const_45 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[55]); A_arbace_j2g_names_A_const_46 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[56]); A_arbace_j2g_names_A_const_47 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[57]) }

func A_arbace_j2g_names_A_clinit_p4() { A_arbace_j2g_names_A_const_48 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[58]); A_arbace_j2g_names_A_const_49 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[59]); A_arbace_j2g_names_A_const_50 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[60]); A_arbace_j2g_names_A_const_51 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[61]); A_arbace_j2g_names_A_const_52 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[62]); A_arbace_j2g_names_A_const_53 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[63]) }

func A_arbace_j2g_names_A_New() *A_arbace_j2g_names_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_names_A) Ctor() {}

func (t *A_arbace_j2g_names_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_names_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_names_A_class }

func (t *A_arbace_j2g_names_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_names_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_names_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_names_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_names_A); return ok }

func A_arbace_j2g_names_A_Cast(x any) *A_arbace_j2g_names_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_names_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_names_A_class)) }; return v }



type A_arbace_j2g_names_capitalize_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_capitalize_A_fn_class *jrt.Class



type A_arbace_j2g_names_compiled_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_names_compiled_class_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_names_compiled_pkg_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_names_compiled_pkg_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_names_ctor_base_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_ctor_base_A_fn_class *jrt.Class



type A_arbace_j2g_names_ctor_base_fn__1768000044_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_ctor_base_fn__1768000044_A_fn_class *jrt.Class



type A_arbace_j2g_names_desc_code_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_desc_code_A_fn_class *jrt.Class



type A_arbace_j2g_names_eval1768000004_A struct{ jrt.Object }

func A_arbace_j2g_names_eval1768000004_A_New() *A_arbace_j2g_names_eval1768000004_A { t := &A_arbace_j2g_names_eval1768000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_names_eval1768000004_A) Ctor() {}

func (t *A_arbace_j2g_names_eval1768000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_names_eval1768000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_names_eval1768000004_A_class }

func (t *A_arbace_j2g_names_eval1768000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_names_eval1768000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_names_eval1768000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_names_eval1768000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_names_eval1768000004_A); return ok }

func A_arbace_j2g_names_eval1768000004_A_Cast(x any) *A_arbace_j2g_names_eval1768000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_names_eval1768000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_names_eval1768000004_A_class)) }; return v }



type A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A_fn_class *jrt.Class



type A_arbace_j2g_names_eval1768000008_A struct{ jrt.Object }

func A_arbace_j2g_names_eval1768000008_A_New() *A_arbace_j2g_names_eval1768000008_A { t := &A_arbace_j2g_names_eval1768000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_names_eval1768000008_A) Ctor() {}

func (t *A_arbace_j2g_names_eval1768000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_names_eval1768000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_names_eval1768000008_A_class }

func (t *A_arbace_j2g_names_eval1768000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_names_eval1768000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_names_eval1768000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_names_eval1768000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_names_eval1768000008_A); return ok }

func A_arbace_j2g_names_eval1768000008_A_Cast(x any) *A_arbace_j2g_names_eval1768000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_names_eval1768000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_names_eval1768000008_A_class)) }; return v }



type A_arbace_j2g_names_eval1768000008_fn__1768000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_eval1768000008_fn__1768000009_A_fn_class *jrt.Class



type A_arbace_j2g_names_field_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_field_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_fn__1768000021_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_fn__1768000021_A_fn_class *jrt.Class



type A_arbace_j2g_names_fn__1768000021_fn__1768000022_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_fn__1768000021_fn__1768000022_A_fn_class *jrt.Class



type A_arbace_j2g_names_go_class_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_go_class_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_go_class_name_STAR__STAR__A struct{ j2g_header uint64 }

var A_arbace_j2g_names_go_class_name_STAR__STAR__A_fn_class *jrt.Class



type A_arbace_j2g_names_impl_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_impl_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_local_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_local_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_memo_str_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_memo_str_A_fn_class *jrt.Class



type A_arbace_j2g_names_memo_str_fn__1768000018_A struct{ j2g_header uint64; F_cache, F_f any }

var A_arbace_j2g_names_memo_str_fn__1768000018_A_fn_class *jrt.Class



type A_arbace_j2g_names_method_base_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_method_base_A_fn_class *jrt.Class



type A_arbace_j2g_names_method_base_STAR__A struct{ j2g_header uint64 }

var A_arbace_j2g_names_method_base_STAR__A_fn_class *jrt.Class



type A_arbace_j2g_names_method_base_STAR__fn__1768000037_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_method_base_STAR__fn__1768000037_A_fn_class *jrt.Class



type A_arbace_j2g_names_munge_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_munge_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_new_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_new_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_new_name_fn__1768000051_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_new_name_fn__1768000051_A_fn_class *jrt.Class



type A_arbace_j2g_names_pkg_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_pkg_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_pkg_ns_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_pkg_ns_A_fn_class *jrt.Class



type A_arbace_j2g_names_pkg_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_pkg_of_A_fn_class *jrt.Class



type A_arbace_j2g_names_pkg_path_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_pkg_path_A_fn_class *jrt.Class



type A_arbace_j2g_names_static_field_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_static_field_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_static_method_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_static_method_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_top_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_top_of_A_fn_class *jrt.Class
