//line aot_arbace_j2g_names.ae:1
package aot_arbace_j2g_names

import (
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A_New() *A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_names_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_names_A_const_4); tmp2 = lang.IFn_Cast(A_arbace_j2g_names_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_names_A_const_1, A_arbace_j2g_names_A_const_2); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_names_eval1768000008_fn__1768000009_A_New() *A_arbace_j2g_names_eval1768000008_fn__1768000009_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_eval1768000008_fn__1768000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_names_eval1768000008_fn__1768000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_names_eval1768000008_fn__1768000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_names_A_const_5.GetRawRoot__O()); var tmp2 any; var root_16 any = A_arbace_j2g_names_A_const_6.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = A_arbace_j2g_names_A_const_7; if linked_17 == nil { tmp2 = ifn_18.Invoke_O__O(arg_19) } else { tmp2 = linked_17.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_16, arg_19) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_names_A_const_8.GetRawRoot__O(), A_arbace_j2g_names_A_const_9) }















func A_arbace_j2g_names_top_of_A_New() *A_arbace_j2g_names_top_of_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_top_of_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_j2g_names_top_of_A) Ctor() {}
//line :17:1
func (t *A_arbace_j2g_names_top_of_A) Invoke_O_O__O(self, n__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_11); if lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return n__0 } else { var root_20 any = A_arbace_j2g_names_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = n__0; var arg_24 any = A_arbace_j2g_names_A_const_11; var arg_25 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_21 == nil { return ifn_22.Invoke_O_O_O__O(arg_23, arg_24, arg_25) } else { return linked_21.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_20, arg_23, arg_24, arg_25) } } }

func A_arbace_j2g_names_pkg_of_A_New() *A_arbace_j2g_names_pkg_of_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_pkg_of_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_j2g_names_pkg_of_A) Ctor() {}
//line :19:1
func (t *A_arbace_j2g_names_pkg_of_A) Invoke_O_O__O(self, internal__0 any) any {







	var tmp1 any; var or__1927000174__auto____2 any; var root_26 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_28 lang.IFn
	if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = internal__0; var arg_30 any = Lit_29; if linked_27 == nil { or__1927000174__auto____2 = ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { or__1927000174__auto____2 = linked_27.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_26, arg_29, arg_30) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_31 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = internal__0; var arg_35 any = Lit_30; if linked_32 == nil { or__1927000174__auto____3 = ifn_33.Invoke_O_O__O(arg_34, arg_35) } else { or__1927000174__auto____3 = linked_32.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_31, arg_34, arg_35) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var root_36 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_38 lang.IFn
		if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = internal__0; var arg_40 any = Lit_31; if linked_37 == nil { or__1927000174__auto____4 = ifn_38.Invoke_O_O__O(arg_39, arg_40) } else { or__1927000174__auto____4 = linked_37.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_36, arg_39, arg_40) }
//line :28:1
		if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { var or__1927000174__auto____5 any; var root_41 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_43 lang.IFn
			if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = internal__0; var arg_45 any = Lit_32; if linked_42 == nil { or__1927000174__auto____5 = ifn_43.Invoke_O_O__O(arg_44, arg_45) } else { or__1927000174__auto____5 = linked_42.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_41, arg_44, arg_45) }
//line :28:1
			if jrt.J2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any; var root_46 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_48 lang.IFn

				if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = internal__0; var arg_50 any = Lit_33; if linked_47 == nil { or__1927000174__auto____6 = ifn_48.Invoke_O_O__O(arg_49, arg_50) } else { or__1927000174__auto____6 = linked_47.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_46, arg_49, arg_50) }
//line :28:1
				if jrt.J2g_Truth(or__1927000174__auto____6) { tmp1 = or__1927000174__auto____6 } else { var or__1927000174__auto____7 any; var root_51 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_53 lang.IFn

					if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = internal__0; var arg_55 any = Lit_34; if linked_52 == nil { or__1927000174__auto____7 = ifn_53.Invoke_O_O__O(arg_54, arg_55) } else { or__1927000174__auto____7 = linked_52.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_51, arg_54, arg_55) }
//line :28:1
					if jrt.J2g_Truth(or__1927000174__auto____7) { tmp1 = or__1927000174__auto____7 } else { var or__1927000174__auto____8 any; var root_56 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_58 lang.IFn


						if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = internal__0; var arg_60 any = Lit_35; if linked_57 == nil { or__1927000174__auto____8 = ifn_58.Invoke_O_O__O(arg_59, arg_60) } else { or__1927000174__auto____8 = linked_57.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_56, arg_59, arg_60) }
//line :28:1
						if jrt.J2g_Truth(or__1927000174__auto____8) { tmp1 = or__1927000174__auto____8 } else { var or__1927000174__auto____9 any; var root_61 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_63 lang.IFn


							if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = internal__0; var arg_65 any = Lit_36; if linked_62 == nil { or__1927000174__auto____9 = ifn_63.Invoke_O_O__O(arg_64, arg_65) } else { or__1927000174__auto____9 = linked_62.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_61, arg_64, arg_65) }
//line :28:1
							if jrt.J2g_Truth(or__1927000174__auto____9) { tmp1 = or__1927000174__auto____9 } else { var or__1927000174__auto____10 any; var root_66 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_68 lang.IFn



								if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = internal__0; var arg_70 any = Lit_37; if linked_67 == nil { or__1927000174__auto____10 = ifn_68.Invoke_O_O__O(arg_69, arg_70) } else { or__1927000174__auto____10 = linked_67.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_66, arg_69, arg_70) }
//line :28:1
								if jrt.J2g_Truth(or__1927000174__auto____10) { tmp1 = or__1927000174__auto____10 } else { var or__1927000174__auto____11 any; var root_71 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_73 lang.IFn



									if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = internal__0; var arg_75 any = Lit_38; if linked_72 == nil { or__1927000174__auto____11 = ifn_73.Invoke_O_O__O(arg_74, arg_75) } else { or__1927000174__auto____11 = linked_72.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_71, arg_74, arg_75) }
//line :28:1
									if jrt.J2g_Truth(or__1927000174__auto____11) { tmp1 = or__1927000174__auto____11 } else {




										var root_76 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = internal__0; var arg_80 any = Lit_39; if linked_77 == nil { tmp1 = ifn_78.Invoke_O_O__O(arg_79, arg_80) } else { tmp1 = linked_77.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_76, arg_79, arg_80) } } } } } } } } } } }
//line :27:1
	if jrt.J2g_Truth(tmp1) { return A_arbace_j2g_names_A_const_13 } else { if A_arbace_j2g_names_A_const_14 != nil { var temp__1927000408__auto____2 any; var tmp2 any; var root_81 any = A_arbace_j2g_names_A_const_6.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_83 lang.IFn






		if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = A_arbace_j2g_names_A_const_15.GetRawRoot__O(); if linked_82 == nil { tmp2 = ifn_83.Invoke_O__O(arg_84) } else { tmp2 = linked_82.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_81, arg_84) }; var tmp3 any = tmp2; var tmp4 any; var root_85 any = A_arbace_j2g_names_A_const_16.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, A_arbace_j2g_names_top_of_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = internal__0; if linked_86 == nil { tmp4 = ifn_87.Invoke_O__O(arg_88) } else { tmp4 = linked_86.(*A_arbace_j2g_names_top_of_A).Invoke_O_O__O(root_85, arg_88) }; temp__1927000408__auto____2 = lang.RT_Get_O_O__O_NoInit(tmp3, tmp4); if jrt.J2g_Truth(temp__1927000408__auto____2) { var p__3 any = temp__1927000408__auto____2; var root_89 any = A_arbace_j2g_names_A_const_17.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = p__3; if linked_90 == nil { return ifn_91.Invoke_O__O(arg_92) } else { return linked_90.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_89, arg_92) } } else { return A_arbace_j2g_names_A_const_18 } } else {
//line :27:1
			return nil
		}
	}
}





func A_arbace_j2g_names_compiled_pkg_QMARK__A_New() *A_arbace_j2g_names_compiled_pkg_QMARK__A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_compiled_pkg_QMARK__A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_j2g_names_compiled_pkg_QMARK__A) Ctor() {}
//line :36:1
func (t *A_arbace_j2g_names_compiled_pkg_QMARK__A) Invoke_O_O__O(self, pkg__0 any) any { var root_93 any = A_arbace_j2g_names_A_const_19.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = lang.IFn_Cast(A_arbace_j2g_names_A_const_20).Invoke_O__O(pkg__0); if linked_94 == nil { return ifn_95.Invoke_O__O(arg_96) } else { return linked_94.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_93, arg_96) } }

func A_arbace_j2g_names_pkg_name_A_New() *A_arbace_j2g_names_pkg_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_pkg_name_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_j2g_names_pkg_name_A) Ctor() {}
//line :38:1
func (t *A_arbace_j2g_names_pkg_name_A) Invoke_O_O__O(self, pkg__0 any) any { var root_97 any = A_arbace_j2g_names_A_const_21.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = pkg__0; if linked_98 == nil { return ifn_99.Invoke_O__O(arg_100) } else { return linked_98.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_97, arg_100) } }
func A_arbace_j2g_names_pkg_path_A_New() *A_arbace_j2g_names_pkg_path_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_pkg_path_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_j2g_names_pkg_path_A) Ctor() {}
//line :39:1
func (t *A_arbace_j2g_names_pkg_path_A) Invoke_O_O__O(self, pkg__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_1, nil); var tmp2 any; var root_101 any = A_arbace_j2g_names_A_const_21.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = pkg__0; if linked_102 == nil { tmp2 = ifn_103.Invoke_O__O(arg_104) } else { tmp2 = linked_102.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_101, arg_104) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }
func A_arbace_j2g_names_pkg_ns_A_New() *A_arbace_j2g_names_pkg_ns_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_pkg_ns_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_j2g_names_pkg_ns_A) Ctor() {}
//line :40:1
func (t *A_arbace_j2g_names_pkg_ns_A) Invoke_O_O__O(self, pkg__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_28, nil); var tmp2 any; var root_105 any = A_arbace_j2g_names_A_const_21.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = pkg__0; if linked_106 == nil { tmp2 = ifn_107.Invoke_O__O(arg_108) } else { tmp2 = linked_106.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_105, arg_108) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }



















func A_arbace_j2g_names_memo_str_A_New() *A_arbace_j2g_names_memo_str_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_memo_str_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_j2g_names_memo_str_A) Ctor() {}
//line :60:1
func (t *A_arbace_j2g_names_memo_str_A) Invoke_O_O__O(self, f__0 any) any { var cache__2 any = jrt.ConcurrentHashMap_New(); var fnbody__110 any = A_arbace_j2g_names_memo_str_fn__1768000018_A_New_O_O(cache__2, f__0); var tmp1 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_j2g_names_memo_str_fn__1768000018_A_fn_class; if




	fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, fnbody__110); A_arbace_j2g_names_memo_str_fn__1768000018_A_fn_class = fncls__109d; tmp1 = fncls__109d } else { tmp1 = fncls__109 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp1, nil) }
//line :65:1
func A_arbace_j2g_names_memo_str_fn__1768000018_A_New_O_O(p0, p1 any) *A_arbace_j2g_names_memo_str_fn__1768000018_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_memo_str_fn__1768000018_A{}; t.Ctor_O_O(p0, p1); return t }
//line :65:1
func (t *A_arbace_j2g_names_memo_str_fn__1768000018_A) Ctor_O_O(c__cache, c__f any) { t.F_cache = c__cache; t.F_f = c__f }
//line :65:1
func (t *A_arbace_j2g_names_memo_str_fn__1768000018_A) Invoke_O_O__O(self, k__1 any) any { var or__1927000174__auto____2 any = jrt.NN(jrt.ConcurrentHashMap_Cast(t.F_cache)).Get_O__O(k__1); if
												jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var v__3 any = lang.IFn_Cast(t.F_f).Invoke_O__O(k__1)

		jrt.NN(jrt.ConcurrentHashMap_Cast(t.F_cache)).Put_O_O__O(k__1, v__3)
//line :66:1
		return v__3 } }






func A_arbace_j2g_names_fn__1768000021_A_New() *A_arbace_j2g_names_fn__1768000021_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_fn__1768000021_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_j2g_names_fn__1768000021_A) Ctor() {}
//line :73:1
func (t *A_arbace_j2g_names_fn__1768000021_A) Invoke_O_O__O(self, s__0 any) any { var m__2 any; var root_111 any = A_arbace_j2g_names_A_const_22.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_113 lang.IFn; if
										linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any; var root_117 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any; var root_121 any = A_arbace_j2g_names_A_const_24.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, aot_arbace_core.A_arbace_core_munge_A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = s__0; if linked_122 == nil { arg_120 = ifn_123.Invoke_O__O(arg_124) } else { arg_120 = linked_122.(*aot_arbace_core.A_arbace_core_munge_A).Invoke_O_O__O(root_121, arg_124) }; if linked_118 == nil { arg_114 = ifn_119.Invoke_O__O(arg_120) } else { arg_114 = linked_118.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_117, arg_120) }; var arg_115 any = Lit_11; var arg_116 any = Lit_7; if linked_112 == nil { m__2 = ifn_113.Invoke_O_O_O__O(arg_114, arg_115, arg_116) } else { m__2 = linked_112.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_111, arg_114, arg_115, arg_116) }; var root_125 any =


	A_arbace_j2g_names_A_const_25.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_125, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_127 lang.IFn; if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var arg_129 any; var root_130 any = A_arbace_j2g_names_A_const_26.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_130, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any; var fnbody__136 any = A_arbace_j2g_names_fn__1768000021_fn__1768000022_A_New(); var tmp1 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_j2g_names_fn__1768000021_fn__1768000022_A_fn_class; if fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, nil); A_arbace_j2g_names_fn__1768000021_fn__1768000022_A_fn_class = fncls__135d; tmp1 = fncls__135d } else { tmp1 = fncls__135 }; arg_133 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__136, tmp1, nil); var arg_134 any = m__2; if linked_131 == nil { arg_129 = ifn_132.Invoke_O_O__O(arg_133, arg_134) } else { arg_129 = linked_131.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_130, arg_133, arg_134) }; if linked_126 == nil { return ifn_127.Invoke_O_O__O(arg_128, arg_129) } else { return linked_126.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_125, arg_128, arg_129) } }
//line :77:1
func A_arbace_j2g_names_fn__1768000021_fn__1768000022_A_New() *A_arbace_j2g_names_fn__1768000021_fn__1768000022_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_fn__1768000021_fn__1768000022_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_j2g_names_fn__1768000021_fn__1768000022_A) Ctor() {}
//line :77:1
func (t *A_arbace_j2g_names_fn__1768000021_fn__1768000022_A) Invoke_O_O__O(self, c__1 any) any { var tmp1 bool; var or__1927000174__auto____2 bool = jrt.Character_IsLetterOrDigit_C__Z_NoInit(lang.RT_CharCast_O__C_NoInit(c__1)); if or__1927000174__auto____2 { tmp1 = or__1927000174__auto____2 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(c__1, A_arbace_j2g_names_A_const_27) }; if tmp1 { return c__1 } else { return A_arbace_j2g_names_A_const_27 } }

func A_arbace_j2g_names_munge_name_A_New() *A_arbace_j2g_names_munge_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_munge_name_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_j2g_names_munge_name_A) Ctor() {}
//line :79:1
func (t *A_arbace_j2g_names_munge_name_A) Invoke_O_O__O(self, s__0 any) any {


	var root_137 any = A_arbace_j2g_names_A_const_28.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, A_arbace_j2g_names_memo_str_fn__1768000018_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any; var root_141 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = s__0; if linked_142 == nil { arg_140 = ifn_143.Invoke_O__O(arg_144) } else { arg_140 = linked_142.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_141, arg_144) }; if linked_138 == nil { return ifn_139.Invoke_O__O(arg_140) } else { return linked_138.(*A_arbace_j2g_names_memo_str_fn__1768000018_A).Invoke_O_O__O(root_137, arg_140)
	} }
func A_arbace_j2g_names_local_name_A_New() *A_arbace_j2g_names_local_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_local_name_A{}; t.Ctor(); return t }
//line :84:1
func (t *A_arbace_j2g_names_local_name_A) Ctor() {}
//line :84:1
func (t *A_arbace_j2g_names_local_name_A) Invoke_O_O__O(self, sym__0 any) any { var s__2 any; var root_145 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_147 lang.IFn; if




	linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any; var root_149 any = A_arbace_j2g_names_A_const_21.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = sym__0; if linked_150 == nil { arg_148 = ifn_151.Invoke_O__O(arg_152) } else { arg_148 = linked_150.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_149, arg_152) }; if linked_146 == nil { s__2 = ifn_147.Invoke_O__O(arg_148) } else { s__2 = linked_146.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_145, arg_148) }; var s__3 any; var tmp1 any; var root_153 any = /*line :84:1*/A_arbace_j2g_names_A_const_30.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, aot_arbace_string.A_arbace_string_blank_QMARK__A_fn_class); var ifn_155 lang.IFn; if





	linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = s__2; if linked_154 == nil { tmp1 = ifn_155.Invoke_O__O(arg_156) } else { tmp1 = linked_154.(*aot_arbace_string.A_arbace_string_blank_QMARK__A).Invoke_O_O__O(root_153, arg_156) }; if jrt.J2g_Truth(tmp1) { s__3 = Lit_21 } else { s__3 = s__2 }; var tmp2 any; var or__1927000174__auto____4 any =
	lang.IFn_Cast(A_arbace_j2g_names_A_const_31.GetRawRoot__O()).Invoke_O__O(s__3); if jrt.J2g_Truth(or__1927000174__auto____4) { tmp2 = or__1927000174__auto____4 } else { var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_j2g_names_A_const_32.GetRawRoot__O()).Invoke_O__O(s__3); if jrt.J2g_Truth(or__1927000174__auto____5) { tmp2 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_j2g_names_A_const_33.GetRawRoot__O()).Invoke_O__O(s__3); if jrt.J2g_Truth(or__1927000174__auto____6) { tmp2 = or__1927000174__auto____6 } else { var or__1927000174__auto____7 bool = jrt.Character_IsUpperCase_C__Z_NoInit(jrt.NN(jrt.String_Cast(s__3)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0))); if or__1927000174__auto____7 { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var or__1927000174__auto____8 any; var root_157 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_159 lang.IFn

		if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any = s__3; var arg_161 any = Lit_22; if linked_158 == nil { or__1927000174__auto____8 = ifn_159.Invoke_O_O__O(arg_160, arg_161) } else { or__1927000174__auto____8 = linked_158.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_157, arg_160, arg_161) }
//line :91:1
		if jrt.J2g_Truth(or__1927000174__auto____8) { tmp2 = or__1927000174__auto____8 } else { var or__1927000174__auto____9 any; var root_162 any = A_arbace_j2g_names_A_const_34.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_164 lang.IFn

			if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = A_arbace_j2g_names_A_const_35; var arg_166 any = s__3; if linked_163 == nil { or__1927000174__auto____9 = ifn_164.Invoke_O_O__O(arg_165, arg_166) } else { or__1927000174__auto____9 = linked_163.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_162, arg_165, arg_166) }
//line :91:1
			if jrt.J2g_Truth(or__1927000174__auto____9) { tmp2 = or__1927000174__auto____9 } else {

				var root_167 any = A_arbace_j2g_names_A_const_34.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_169 lang.IFn; if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any = A_arbace_j2g_names_A_const_36; var arg_171 any = s__3; if linked_168 == nil { tmp2 = ifn_169.Invoke_O_O__O(arg_170, arg_171) } else { tmp2 = linked_168.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_167, arg_170, arg_171) } } } } } } }; if /*line :91:1*/ jrt.J2g_Truth(tmp2) {


					return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, s__3, nil)).Ref() } else {
//line :91:1
						return s__3 } }














































func A_arbace_j2g_names_compiled_class_QMARK__A_New() *A_arbace_j2g_names_compiled_class_QMARK__A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_compiled_class_QMARK__A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_j2g_names_compiled_class_QMARK__A) Ctor() {}
//line :138:1
func (t *A_arbace_j2g_names_compiled_class_QMARK__A) Invoke_O_O__O(self, internal__0 any) any { var or__1927000174__auto____2 any; var and__1927000168__auto____2 any; var root_172 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_174 lang.IFn; if





	linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = internal__0; var arg_176 any = Lit_1; if linked_173 == nil { and__1927000168__auto____2 = ifn_174.Invoke_O_O__O(arg_175, arg_176) } else { and__1927000168__auto____2 = linked_173.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_172, arg_175, arg_176) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_177 any = A_arbace_j2g_names_A_const_19.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any; var root_181 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = internal__0; var arg_185 any = Lit_2; if linked_182 == nil { arg_180 = ifn_183.Invoke_O_O__O(arg_184, arg_185) } else { arg_180 = linked_182.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_181, arg_184, arg_185) }; if linked_178 == nil { and__1927000168__auto____3 = ifn_179.Invoke_O__O(arg_180) } else { and__1927000168__auto____3 = linked_178.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_177, arg_180) }; if jrt.J2g_Truth(and__1927000168__auto____3) {
		var root_186 any = A_arbace_j2g_names_A_const_19.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any; var root_190 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = internal__0; var arg_194 any = Lit_3; if linked_191 == nil { arg_189 = ifn_192.Invoke_O_O__O(arg_193, arg_194) } else { arg_189 = linked_191.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_190, arg_193, arg_194) }; if linked_187 == nil { or__1927000174__auto____2 = ifn_188.Invoke_O__O(arg_189) } else { or__1927000174__auto____2 = linked_187.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_186, arg_189) } } else {
//line :144:1
			or__1927000174__auto____2 = and__1927000168__auto____3 } } else { or__1927000174__auto____2 = and__1927000168__auto____2 }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var temp__1927000414__auto____3 any; var tmp1 any; var root_195 any = A_arbace_j2g_names_A_const_6.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_197 lang.IFn

				if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = A_arbace_j2g_names_A_const_15.GetRawRoot__O(); if linked_196 == nil { tmp1 = ifn_197.Invoke_O__O(arg_198) } else { tmp1 = linked_196.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_195, arg_198) }; var tmp2 any = tmp1; var tmp3 any; var root_199 any = A_arbace_j2g_names_A_const_16.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, A_arbace_j2g_names_top_of_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = internal__0; if linked_200 == nil { tmp3 = ifn_201.Invoke_O__O(arg_202) } else { tmp3 = linked_200.(*A_arbace_j2g_names_top_of_A).Invoke_O_O__O(root_199, arg_202) }; temp__1927000414__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp2, tmp3); if jrt.J2g_Truth(temp__1927000414__auto____3) { var p__4 any = temp__1927000414__auto____3; var root_203 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_205 lang.IFn
					if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any = p__4; var arg_207 any = Lit_4; if linked_204 == nil { return ifn_205.Invoke_O_O__O(arg_206, arg_207) } else { return linked_204.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_203, arg_206, arg_207) } } else {
//line :146:1
						return nil } } }





























func A_arbace_j2g_names_qualified_QMARK__A_New() *A_arbace_j2g_names_qualified_QMARK__A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_qualified_QMARK__A{}; t.Ctor(); return t }
//line :176:1
func (t *A_arbace_j2g_names_qualified_QMARK__A) Ctor() {}
//line :176:1
func (t *A_arbace_j2g_names_qualified_QMARK__A) Invoke_O_O__O(self, internal__0 any) any {


	var tmp1 any; var or__1927000174__auto____2 any; var root_208 any = A_arbace_j2g_names_A_const_37.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any; var fnbody__219 any = A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A_New_O(internal__0); var tmp2 *jrt.Class; var fncls__218 *jrt.Class = A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A_fn_class; if fncls__218 == nil { var fncls__218d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, fnbody__219); A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A_fn_class = fncls__218d; tmp2 = fncls__218d } else { tmp2 = fncls__218 }; arg_211 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__219, tmp2, nil); var arg_212 any = A_arbace_j2g_names_A_const_38.GetRawRoot__O(); if linked_209 == nil { or__1927000174__auto____2 = ifn_210.Invoke_O_O__O(arg_211, arg_212) } else { or__1927000174__auto____2 = linked_209.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_208, arg_211, arg_212) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else {
		var root_220 any = A_arbace_j2g_names_A_const_37.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_222 lang.IFn; if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any; var fnbody__231 any = A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A_New_O(internal__0); var tmp3 *jrt.Class; var fncls__230 *jrt.Class = A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A_fn_class; if fncls__230 == nil { var fncls__230d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, fnbody__231); A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A_fn_class = fncls__230d; tmp3 = fncls__230d } else { tmp3 = fncls__230 }; arg_223 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__231, tmp3, nil); var arg_224 any; var root_232 any = A_arbace_j2g_names_A_const_6.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = A_arbace_j2g_names_A_const_39.GetRawRoot__O(); if linked_233 == nil { arg_224 = ifn_234.Invoke_O__O(arg_235) } else { arg_224 = linked_233.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_232, arg_235) }; if linked_221 == nil { tmp1 = ifn_222.Invoke_O_O__O(arg_223, arg_224) } else { tmp1 = linked_221.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_220, arg_223, arg_224) } }
//line :179:1
	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() }
//line :179:1
func A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A_New_O(p0 any) *A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A{}; t.Ctor_O(p0); return t }
//line :179:1
func (t *A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A) Ctor_O(c__internal any) { t.F_internal = c__internal }
//line :179:1
func (t *A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A) Invoke_O_O__O(self, p1__1768000028_SHARP___1 any) any { var root_213 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = t.F_internal; var arg_217 any = p1__1768000028_SHARP___1; if linked_214 == nil { return ifn_215.Invoke_O_O__O(arg_216, arg_217) } else { return linked_214.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_213, arg_216, arg_217) } }
func A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A_New_O(p0 any) *A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A{}; t.Ctor_O(p0); return t }
//line :180:1
func (t *A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A) Ctor_O(c__internal any) { t.F_internal = c__internal }
//line :180:1
func (t *A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A) Invoke_O_O__O(self, p1__1768000029_SHARP___1 any) any { var root_225 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any = t.F_internal; var arg_229 any = p1__1768000029_SHARP___1; if linked_226 == nil { return ifn_227.Invoke_O_O__O(arg_228, arg_229) } else { return linked_226.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_225, arg_228, arg_229) } }

func A_arbace_j2g_names_user_class_QMARK__A_New() *A_arbace_j2g_names_user_class_QMARK__A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_user_class_QMARK__A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_j2g_names_user_class_QMARK__A) Ctor() {}
//line :182:1
func (t *A_arbace_j2g_names_user_class_QMARK__A) Invoke_O_O__O(self, internal__0 any) any { var and__1927000168__auto____2 bool; var tmp1 any = A_arbace_j2g_names_A_const_18; var tmp2 any; var root_236 any = A_arbace_j2g_names_A_const_40.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, A_arbace_j2g_names_pkg_of_A_fn_class); var ifn_238 lang.IFn; if







	linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = internal__0; if linked_237 == nil { tmp2 = ifn_238.Invoke_O__O(arg_239) } else { tmp2 = linked_237.(*A_arbace_j2g_names_pkg_of_A).Invoke_O_O__O(root_236, arg_239) }; and__1927000168__auto____2 = lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2); if and__1927000168__auto____2 { var root_240 any = A_arbace_j2g_names_A_const_19.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any; var root_244 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_246 lang.IFn; if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = internal__0; var arg_248 any = Lit_1; if linked_245 == nil { arg_243 = ifn_246.Invoke_O_O__O(arg_247, arg_248) } else { arg_243 = linked_245.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_244, arg_247, arg_248) }; if linked_241 == nil { return ifn_242.Invoke_O__O(arg_243) } else { return linked_241.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_240, arg_243) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_j2g_names_own_class_QMARK__A_New() *A_arbace_j2g_names_own_class_QMARK__A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_own_class_QMARK__A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_j2g_names_own_class_QMARK__A) Ctor() {}
//line :192:1
func (t *A_arbace_j2g_names_own_class_QMARK__A) Invoke_O_O__O(self, internal__0 any) any { var and__1927000168__auto____2 any; var root_249 any = A_arbace_j2g_names_A_const_41.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_251 lang.IFn; if





	linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = A_arbace_j2g_names_A_const_13; var arg_253 any; var root_254 any = A_arbace_j2g_names_A_const_40.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, A_arbace_j2g_names_pkg_of_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = internal__0; if linked_255 == nil { arg_253 = ifn_256.Invoke_O__O(arg_257) } else { arg_253 = linked_255.(*A_arbace_j2g_names_pkg_of_A).Invoke_O_O__O(root_254, arg_257) }; if linked_250 == nil { and__1927000168__auto____2 = ifn_251.Invoke_O_O__O(arg_252, arg_253) } else { and__1927000168__auto____2 = linked_250.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_249, arg_252, arg_253) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_258 any = A_arbace_j2g_names_A_const_19.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any; var root_262 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = internal__0; var arg_266 any = Lit_1; if linked_263 == nil { arg_261 = ifn_264.Invoke_O_O__O(arg_265, arg_266) } else { arg_261 = linked_263.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_262, arg_265, arg_266) }; if linked_259 == nil { and__1927000168__auto____3 = ifn_260.Invoke_O__O(arg_261) } else { and__1927000168__auto____3 = linked_259.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_258, arg_261) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_267 any = A_arbace_j2g_names_A_const_19.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_269 lang.IFn
		if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any; var root_271 any = A_arbace_j2g_names_A_const_42.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, A_arbace_j2g_names_compiled_class_QMARK__A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = internal__0; if linked_272 == nil { arg_270 = ifn_273.Invoke_O__O(arg_274) } else { arg_270 = linked_272.(*A_arbace_j2g_names_compiled_class_QMARK__A).Invoke_O_O__O(root_271, arg_274) }; if linked_268 == nil { and__1927000168__auto____4 = ifn_269.Invoke_O__O(arg_270) } else { and__1927000168__auto____4 = linked_268.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_267, arg_270) }
//line :198:1
		if jrt.J2g_Truth(and__1927000168__auto____4) {
			var root_275 any = A_arbace_j2g_names_A_const_19.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any; var root_279 any = A_arbace_j2g_names_A_const_43.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, A_arbace_j2g_names_qualified_QMARK__A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = internal__0; if linked_280 == nil { arg_278 = ifn_281.Invoke_O__O(arg_282) } else { arg_278 = linked_280.(*A_arbace_j2g_names_qualified_QMARK__A).Invoke_O_O__O(root_279, arg_282) }; if linked_276 == nil { return ifn_277.Invoke_O__O(arg_278) } else { return linked_276.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_275, arg_278) } } else {
//line :198:1
				return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }




func A_arbace_j2g_names_go_class_name_A_New() *A_arbace_j2g_names_go_class_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_go_class_name_A{}; t.Ctor(); return t }
//line :203:1
func (t *A_arbace_j2g_names_go_class_name_A) Ctor() {}
//line :203:1
func (t *A_arbace_j2g_names_go_class_name_A) Invoke_O_O__O(self, internal__0 any) any {







	var root_283 any = A_arbace_j2g_names_A_const_44.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, A_arbace_j2g_names_memo_str_fn__1768000018_A_fn_class); var ifn_285 lang.IFn; if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any = internal__0; if linked_284 == nil { return ifn_285.Invoke_O__O(arg_286) } else { return linked_284.(*A_arbace_j2g_names_memo_str_fn__1768000018_A).Invoke_O_O__O(root_283, arg_286)
	} }
func A_arbace_j2g_names_go_class_name_STAR__STAR__A_New() *A_arbace_j2g_names_go_class_name_STAR__STAR__A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_go_class_name_STAR__STAR__A{}; t.Ctor(); return t }
//line :213:1
func (t *A_arbace_j2g_names_go_class_name_STAR__STAR__A) Ctor() {}
//line :213:1
func (t *A_arbace_j2g_names_go_class_name_STAR__STAR__A) Invoke_O_O__O(self, internal__0 any) any { var or__1927000174__auto____2 any = lang.RT_Get_O_O__O_NoInit(A_arbace_j2g_names_A_const_45.GetRawRoot__O(), internal__0); if
													jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var tmp1 any; var root_287 any = A_arbace_j2g_names_A_const_43.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, A_arbace_j2g_names_qualified_QMARK__A_fn_class); var ifn_289 lang.IFn
														if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = internal__0; if linked_288 == nil { tmp1 = ifn_289.Invoke_O__O(arg_290) } else { tmp1 = linked_288.(*A_arbace_j2g_names_qualified_QMARK__A).Invoke_O_O__O(root_287, arg_290) }; if jrt.J2g_Truth(tmp1) {
															var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_13, nil); var tmp3 any; var root_291 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_293 lang.IFn; if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any; var root_295 any = A_arbace_j2g_names_A_const_22.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = internal__0; var arg_299 any = Lit_14; var arg_300 any = Lit_7; if linked_296 == nil { arg_294 = ifn_297.Invoke_O_O_O__O(arg_298, arg_299, arg_300) } else { arg_294 = linked_296.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_295, arg_298, arg_299, arg_300) }; if linked_292 == nil { tmp3 = ifn_293.Invoke_O__O(arg_294) } else { tmp3 = linked_292.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_291, arg_294) }; or__1927000174__auto____3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref() } else {
//line :215:1
				or__1927000174__auto____3 = nil }
//line :214:1
		if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var tmp4 any; var root_301 any = A_arbace_j2g_names_A_const_46.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_301, A_arbace_j2g_names_user_class_QMARK__A_fn_class); var ifn_303 lang.IFn


			if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any = internal__0; if linked_302 == nil { tmp4 = ifn_303.Invoke_O__O(arg_304) } else { tmp4 = linked_302.(*A_arbace_j2g_names_user_class_QMARK__A).Invoke_O_O__O(root_301, arg_304) }; if jrt.J2g_Truth(tmp4) {


				var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_16); var tmp6 any; var root_305 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_305, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_307 lang.IFn; if linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any; var root_309 any = A_arbace_j2g_names_A_const_22.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any = internal__0; var arg_313 any = Lit_14; var arg_314 any = Lit_7; if linked_310 == nil { arg_308 = ifn_311.Invoke_O_O_O__O(arg_312, arg_313, arg_314) } else { arg_308 = linked_310.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_309, arg_312, arg_313, arg_314) }; if linked_306 == nil { tmp6 = ifn_307.Invoke_O__O(arg_308) } else { tmp6 = linked_306.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_305, arg_308) }; or__1927000174__auto____4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6, nil)).Ref() } else {
//line :217:1
					or__1927000174__auto____4 = nil }
//line :214:1
			if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var or__1927000174__auto____5 any; var tmp7 any; var root_315 any = A_arbace_j2g_names_A_const_42.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, A_arbace_j2g_names_compiled_class_QMARK__A_fn_class); var ifn_317 lang.IFn






				if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any = internal__0; if linked_316 == nil { tmp7 = ifn_317.Invoke_O__O(arg_318) } else { tmp7 = linked_316.(*A_arbace_j2g_names_compiled_class_QMARK__A).Invoke_O_O__O(root_315, arg_318) }; if jrt.J2g_Truth(tmp7) {

					var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_17, nil, Lit_18); var tmp9 any; var root_319 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_319, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_321 lang.IFn; if linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any; var root_323 any = A_arbace_j2g_names_A_const_22.GetRawRoot__O(); var linked_324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_323, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_325 lang.IFn; if linked_324 == nil { ifn_325 = lang.IFn_Cast(root_323) } else { ifn_325 = nil }; var arg_326 any = internal__0; var arg_327 any = Lit_14; var arg_328 any = Lit_7; if linked_324 == nil { arg_322 = ifn_325.Invoke_O_O_O__O(arg_326, arg_327, arg_328) } else { arg_322 = linked_324.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_323, arg_326, arg_327, arg_328) }; if linked_320 == nil { tmp9 = ifn_321.Invoke_O__O(arg_322) } else { tmp9 = linked_320.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_319, arg_322) }; or__1927000174__auto____5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp9, nil)).Ref() } else {
//line :221:1
						or__1927000174__auto____5 = nil }
//line :214:1
				if jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { var s__6 any; var root_329 any = A_arbace_j2g_names_A_const_10.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_331 lang.IFn









					if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = internal__0; var arg_333 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(internal__0)).LastIndexOf_String__I(Lit_14)))).Ref(); if linked_330 == nil { s__6 = ifn_331.Invoke_O_O__O(arg_332, arg_333) } else { s__6 = linked_330.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_329, arg_332, arg_333) }
//line :214:1
					var s__7 any; var root_334 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_336 lang.IFn










					if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = s__6; if linked_335 == nil { s__7 = ifn_336.Invoke_O__O(arg_337) } else { s__7 = linked_335.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_334, arg_337) }
					var tmp10 any; var and__1927000168__auto____8 any; var root_338 any = A_arbace_j2g_names_A_const_47.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = s__7; if linked_339 == nil { and__1927000168__auto____8 = ifn_340.Invoke_O__O(arg_341) } else { and__1927000168__auto____8 = linked_339.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_338, arg_341) }; if jrt.J2g_Truth(and__1927000168__auto____8) { tmp10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Character_IsUpperCase_C__Z_NoInit(jrt.NN(jrt.String_Cast(s__7)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp10 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp10) { return s__7 } else {

						return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, s__7)).Ref() } } } } } }



func A_arbace_j2g_names_capitalize_A_New() *A_arbace_j2g_names_capitalize_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_capitalize_A{}; t.Ctor(); return t }
//line :232:1
func (t *A_arbace_j2g_names_capitalize_A) Ctor() {}
//line :232:1
func (t *A_arbace_j2g_names_capitalize_A) Invoke_O_O__O(self, s__0 any) any {
	var tmp1 any; var root_342 any = A_arbace_j2g_names_A_const_48.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = s__0; if linked_343 == nil { tmp1 = ifn_344.Invoke_O__O(arg_345) } else { tmp1 = linked_343.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_342, arg_345) }; if jrt.J2g_Truth(tmp1) { return s__0 } else { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 any = jrt.Character_ValueOf_C__Character_NoInit(jrt.Character_ToUpperCase_C__C_NoInit(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0)))).Ref(); var tmp4 any; var root_346 any = A_arbace_j2g_names_A_const_10.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = s__0; var arg_350 any = A_arbace_j2g_names_A_const_49; if linked_347 == nil { tmp4 = ifn_348.Invoke_O_O__O(arg_349, arg_350) } else { tmp4 = linked_347.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_346, arg_349, arg_350) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4)).Ref()
	}
}






func A_arbace_j2g_names_desc_code_A_New() *A_arbace_j2g_names_desc_code_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_desc_code_A{}; t.Ctor(); return t }
//line :242:1
func (t *A_arbace_j2g_names_desc_code_A) Ctor() {}
//line :242:1
func (t *A_arbace_j2g_names_desc_code_A) Invoke_O_O__O(self, d__0 any) any {


	var tmp1 any; var root_351 any = A_arbace_j2g_names_A_const_50.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_351, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_353 lang.IFn
	if linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; var arg_354 any = d__0; if linked_352 == nil { tmp1 = ifn_353.Invoke_O__O(arg_354) } else { tmp1 = linked_352.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_351, arg_354) }
//line :245:1
	if jrt.J2g_Truth(tmp1) { var n__2 any; var root_355 any = A_arbace_j2g_names_A_const_51.GetRawRoot__O(); var linked_356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_355, aot_arbace_classes_types.A_arbace_classes_types_array_dims_A_fn_class); var ifn_357 lang.IFn
		if linked_356 == nil { ifn_357 = lang.IFn_Cast(root_355) } else { ifn_357 = nil }; var arg_358 any = d__0; if linked_356 == nil { n__2 = ifn_357.Invoke_O__O(arg_358) } else { n__2 = linked_356.(*aot_arbace_classes_types.A_arbace_classes_types_array_dims_A).Invoke_O_O__O(root_355, arg_358) }
//line :245:1
		var e__3 any; var root_359 any = A_arbace_j2g_names_A_const_10.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_361 lang.IFn

		if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = d__0; var arg_363 any = n__2; if linked_360 == nil { e__3 = ifn_361.Invoke_O_O__O(arg_362, arg_363) } else { e__3 = linked_360.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_359, arg_362, arg_363) }
		var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 any; var root_364 any = A_arbace_j2g_names_A_const_52.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_364, A_arbace_j2g_names_desc_code_A_fn_class); var ifn_366 lang.IFn; if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any = e__3; if linked_365 == nil { tmp3 = ifn_366.Invoke_O__O(arg_367) } else { tmp3 = linked_365.(*A_arbace_j2g_names_desc_code_A).Invoke_O_O__O(root_364, arg_367) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, n__2)).Ref() } else {
//line :245:1
			if lang.Util_Equiv_O_O__Z_NoInit(d__0, Lit_8) { return Lit_9 } else { var tmp4 any; var root_368 any = A_arbace_j2g_names_A_const_53.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_368, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_370 lang.IFn




				if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any = d__0; if linked_369 == nil { tmp4 = ifn_370.Invoke_O__O(arg_371) } else { tmp4 = linked_369.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_368, arg_371) }
//line :245:1
				if jrt.J2g_Truth(tmp4) {




					var root_372 any = A_arbace_j2g_names_A_const_54.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, A_arbace_j2g_names_go_class_name_A_fn_class); var ifn_374 lang.IFn; if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any; var root_376 any = A_arbace_j2g_names_A_const_55.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = d__0; if linked_377 == nil { arg_375 = ifn_378.Invoke_O__O(arg_379) } else { arg_375 = linked_377.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_376, arg_379) }; if linked_373 == nil { return ifn_374.Invoke_O__O(arg_375) } else { return linked_373.(*A_arbace_j2g_names_go_class_name_A).Invoke_O_O__O(root_372, arg_375) } } else {
//line :245:1
						if A_arbace_j2g_names_A_const_14 != nil { return d__0 } else { return nil
						}
					}
			}
		}
}




func A_arbace_j2g_names_method_base_A_New() *A_arbace_j2g_names_method_base_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_method_base_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_j2g_names_method_base_A) Ctor() {}
//line :255:1
func (t *A_arbace_j2g_names_method_base_A) Invoke_O_O_O__O(self, name__0, desc__1 any) any { var c__3 any = A_arbace_j2g_names_A_const_56.GetRawRoot__O(); var k__4 any = lang.Tuple_Create_O_O__IPersistentVector(name__0, desc__1); var or__1927000174__auto____5 any = jrt.NN(jrt.ConcurrentHashMap_Cast(c__3)).Get_O__O(k__4); if




	jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { var v__6 any; var root_380 any = A_arbace_j2g_names_A_const_57.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, A_arbace_j2g_names_method_base_STAR__A_fn_class); var ifn_382 lang.IFn
		if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = name__0; var arg_384 any = desc__1; if linked_381 == nil { v__6 = ifn_382.Invoke_O_O__O(arg_383, arg_384) } else { v__6 = linked_381.(*A_arbace_j2g_names_method_base_STAR__A).Invoke_O_O_O__O(root_380, arg_383, arg_384) }
		jrt.NN(jrt.ConcurrentHashMap_Cast(c__3)).Put_O_O__O(k__4, v__6)
//line :260:1
		return v__6 } }




func A_arbace_j2g_names_method_base_STAR__A_New() *A_arbace_j2g_names_method_base_STAR__A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_method_base_STAR__A{}; t.Ctor(); return t }
//line :265:1
func (t *A_arbace_j2g_names_method_base_STAR__A) Ctor() {}
//line :265:1
func (t *A_arbace_j2g_names_method_base_STAR__A) Invoke_O_O_O__O(self, name__0, desc__1 any) any { var vec__1768000043__3 any; var root_385 any = A_arbace_j2g_names_A_const_58.GetRawRoot__O(); var linked_386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_385, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_387 lang.IFn; if
													linked_386 == nil { ifn_387 = lang.IFn_Cast(root_385) } else { ifn_387 = nil }; var arg_388 any = desc__1; if linked_386 == nil { vec__1768000043__3 = ifn_387.Invoke_O__O(arg_388) } else { vec__1768000043__3 = linked_386.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_385, arg_388) }; var ps__4 any = /*line :265:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1768000043__3, lang.RT_IntCast_J__I_NoInit(0), nil); var r__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1768000043__3, lang.RT_IntCast_J__I_NoInit(1), nil); var m__6 any; var root_389 any = A_arbace_j2g_names_A_const_59.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_389, A_arbace_j2g_names_capitalize_A_fn_class); var ifn_391 lang.IFn; if

	linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any; var root_393 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_393, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_395 lang.IFn; if linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var arg_396 any = name__0; if linked_394 == nil { arg_392 = ifn_395.Invoke_O__O(arg_396) } else { arg_392 = linked_394.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_393, arg_396) }; if linked_390 == nil { m__6 = ifn_391.Invoke_O__O(arg_392) } else { m__6 = linked_390.(*A_arbace_j2g_names_capitalize_A).Invoke_O_O__O(root_389, arg_392) }; var m__7 any; var tmp1 any; var root_397 any = /*line :265:1*/A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_399 lang.IFn; if


	linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = m__6; var arg_401 any = Lit_7; if linked_398 == nil { tmp1 = ifn_399.Invoke_O_O__O(arg_400, arg_401) } else { tmp1 = linked_398.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_397, arg_400, arg_401) }; if jrt.J2g_Truth(tmp1) { m__7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, m__6)).Ref() } else { m__7 = m__6 }; var tmp2 /*line :269:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_24, nil); var tmp3 any; var root_402 any = A_arbace_j2g_names_A_const_25.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var arg_406 any; var root_407 any = A_arbace_j2g_names_A_const_26.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any; var fnbody__417 any = A_arbace_j2g_names_method_base_STAR__fn__1768000046_A_New(); var tmp4 *jrt.Class; var fncls__416 *jrt.Class = A_arbace_j2g_names_method_base_STAR__fn__1768000046_A_fn_class; if fncls__416 == nil { var fncls__416d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, nil); A_arbace_j2g_names_method_base_STAR__fn__1768000046_A_fn_class = fncls__416d; tmp4 = fncls__416d } else { tmp4 = fncls__416 }; arg_410 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__417, tmp4, nil); var arg_411 any = ps__4; if linked_408 == nil { arg_406 = ifn_409.Invoke_O_O__O(arg_410, arg_411) } else { arg_406 = linked_408.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_407, arg_410, arg_411) }; if linked_403 == nil { tmp3 = ifn_404.Invoke_O_O__O(arg_405, arg_406) } else { tmp3 = linked_403.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_402, arg_405, arg_406) }; var tmp5 any = tmp3; var tmp6 any; var root_418 any = A_arbace_j2g_names_A_const_52.GetRawRoot__O(); var linked_419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_418, A_arbace_j2g_names_desc_code_A_fn_class); var ifn_420 lang.IFn; if linked_419 == nil { ifn_420 = lang.IFn_Cast(root_418) } else { ifn_420 = nil }; var arg_421 any = r__5; if linked_419 == nil { tmp6 = ifn_420.Invoke_O__O(arg_421) } else { tmp6 = linked_419.(*A_arbace_j2g_names_desc_code_A).Invoke_O_O__O(root_418, arg_421) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, m__7, tmp5, nil, tmp6)).Ref() }
//line :269:1
func A_arbace_j2g_names_method_base_STAR__fn__1768000046_A_New() *A_arbace_j2g_names_method_base_STAR__fn__1768000046_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_method_base_STAR__fn__1768000046_A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_j2g_names_method_base_STAR__fn__1768000046_A) Ctor() {}
//line :269:1
func (t *A_arbace_j2g_names_method_base_STAR__fn__1768000046_A) Invoke_O_O__O(self, p1__1768000042_SHARP___1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_7, nil); var tmp2 any; var root_412 any = A_arbace_j2g_names_A_const_52.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, A_arbace_j2g_names_desc_code_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = p1__1768000042_SHARP___1; if linked_413 == nil { tmp2 = ifn_414.Invoke_O__O(arg_415) } else { tmp2 = linked_413.(*A_arbace_j2g_names_desc_code_A).Invoke_O_O__O(root_412, arg_415) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_names_ctor_base_A_New() *A_arbace_j2g_names_ctor_base_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_ctor_base_A{}; t.Ctor(); return t }
//line :271:1
func (t *A_arbace_j2g_names_ctor_base_A) Ctor() {}
//line :271:1
func (t *A_arbace_j2g_names_ctor_base_A) Invoke_O_O__O(self, desc__0 any) any { var vec__1768000050__2 any; var root_422 any = A_arbace_j2g_names_A_const_58.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_424 lang.IFn; if



	linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = desc__0; if linked_423 == nil { vec__1768000050__2 = ifn_424.Invoke_O__O(arg_425) } else { vec__1768000050__2 = linked_423.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_422, arg_425) }; var ps__3 any = /*line :271:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1768000050__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1768000050__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_5, nil); var tmp2 any; var root_426 any = A_arbace_j2g_names_A_const_25.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_426, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_428 lang.IFn; _ = ___4; if




	linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var arg_430 any; var root_431 any = A_arbace_j2g_names_A_const_26.GetRawRoot__O(); var linked_432 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_431, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_433 lang.IFn; if linked_432 == nil { ifn_433 = lang.IFn_Cast(root_431) } else { ifn_433 = nil }; var arg_434 any; var fnbody__441 any = A_arbace_j2g_names_ctor_base_fn__1768000053_A_New(); var tmp3 *jrt.Class; var fncls__440 *jrt.Class = A_arbace_j2g_names_ctor_base_fn__1768000053_A_fn_class; if fncls__440 == nil { var fncls__440d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, nil); A_arbace_j2g_names_ctor_base_fn__1768000053_A_fn_class = fncls__440d; tmp3 = fncls__440d } else { tmp3 = fncls__440 }; arg_434 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__441, tmp3, nil); var arg_435 any = ps__3; if linked_432 == nil { arg_430 = ifn_433.Invoke_O_O__O(arg_434, arg_435) } else { arg_430 = linked_432.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_431, arg_434, arg_435) }; if linked_427 == nil { tmp2 = ifn_428.Invoke_O_O__O(arg_429, arg_430) } else { tmp2 = linked_427.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_426, arg_429, arg_430) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }
//line :276:1
func A_arbace_j2g_names_ctor_base_fn__1768000053_A_New() *A_arbace_j2g_names_ctor_base_fn__1768000053_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_ctor_base_fn__1768000053_A{}; t.Ctor(); return t }
//line :276:1
func (t *A_arbace_j2g_names_ctor_base_fn__1768000053_A) Ctor() {}
//line :276:1
func (t *A_arbace_j2g_names_ctor_base_fn__1768000053_A) Invoke_O_O__O(self, p1__1768000049_SHARP___1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_7, nil); var tmp2 any; var root_436 any = A_arbace_j2g_names_A_const_52.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_436, A_arbace_j2g_names_desc_code_A_fn_class); var ifn_438 lang.IFn; if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any = p1__1768000049_SHARP___1; if linked_437 == nil { tmp2 = ifn_438.Invoke_O__O(arg_439) } else { tmp2 = linked_437.(*A_arbace_j2g_names_desc_code_A).Invoke_O_O__O(root_436, arg_439) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_names_new_name_A_New() *A_arbace_j2g_names_new_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_new_name_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_j2g_names_new_name_A) Ctor() {}
//line :278:1
func (t *A_arbace_j2g_names_new_name_A) Invoke_O_O_O__O(self, cls_go__0, desc__1 any) any { var vec__1768000057__3 any; var root_442 any = A_arbace_j2g_names_A_const_58.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_444 lang.IFn; if


	linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = desc__1; if linked_443 == nil { vec__1768000057__3 = ifn_444.Invoke_O__O(arg_445) } else { vec__1768000057__3 = linked_443.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_442, arg_445) }; var ps__4 any = /*line :278:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1768000057__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1768000057__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_26, nil); var tmp2 any; var root_446 any = A_arbace_j2g_names_A_const_25.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_448 lang.IFn; _ = ___5; if



	linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var arg_450 any; var root_451 any = A_arbace_j2g_names_A_const_26.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_453 lang.IFn; if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any; var fnbody__461 any = A_arbace_j2g_names_new_name_fn__1768000060_A_New(); var tmp3 *jrt.Class; var fncls__460 *jrt.Class = A_arbace_j2g_names_new_name_fn__1768000060_A_fn_class; if fncls__460 == nil { var fncls__460d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, nil); A_arbace_j2g_names_new_name_fn__1768000060_A_fn_class = fncls__460d; tmp3 = fncls__460d } else { tmp3 = fncls__460 }; arg_454 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__461, tmp3, nil); var arg_455 any = ps__4; if linked_452 == nil { arg_450 = ifn_453.Invoke_O_O__O(arg_454, arg_455) } else { arg_450 = linked_452.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_451, arg_454, arg_455) }; if linked_447 == nil { tmp2 = ifn_448.Invoke_O_O__O(arg_449, arg_450) } else { tmp2 = linked_447.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_446, arg_449, arg_450) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, cls_go__0, nil, tmp2)).Ref() }
//line :282:1
func A_arbace_j2g_names_new_name_fn__1768000060_A_New() *A_arbace_j2g_names_new_name_fn__1768000060_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_new_name_fn__1768000060_A{}; t.Ctor(); return t }
//line :282:1
func (t *A_arbace_j2g_names_new_name_fn__1768000060_A) Ctor() {}
//line :282:1
func (t *A_arbace_j2g_names_new_name_fn__1768000060_A) Invoke_O_O__O(self, p1__1768000056_SHARP___1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_7, nil); var tmp2 any; var root_456 any = A_arbace_j2g_names_A_const_52.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_456, A_arbace_j2g_names_desc_code_A_fn_class); var ifn_458 lang.IFn; if linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; var arg_459 any = p1__1768000056_SHARP___1; if linked_457 == nil { tmp2 = ifn_458.Invoke_O__O(arg_459) } else { tmp2 = linked_457.(*A_arbace_j2g_names_desc_code_A).Invoke_O_O__O(root_456, arg_459) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_names_field_name_A_New() *A_arbace_j2g_names_field_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_field_name_A{}; t.Ctor(); return t }
//line :284:1
func (t *A_arbace_j2g_names_field_name_A) Ctor() {}
//line :284:1
func (t *A_arbace_j2g_names_field_name_A) Invoke_O_O__O(self, fname__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_10, nil); var tmp2 any; var root_462 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = fname__0; if linked_463 == nil { tmp2 = ifn_464.Invoke_O__O(arg_465) } else { tmp2 = linked_463.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_462, arg_465) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }







func A_arbace_j2g_names_reserved_member_A_New() *A_arbace_j2g_names_reserved_member_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_reserved_member_A{}; t.Ctor(); return t }
//line :292:1
func (t *A_arbace_j2g_names_reserved_member_A) Ctor() {}
//line :292:1
func (t *A_arbace_j2g_names_reserved_member_A) Invoke_O_O__O(self, s__0 any) any {






	var tmp1 any; var root_466 any = A_arbace_j2g_names_A_const_34.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = A_arbace_j2g_names_A_const_60.GetRawRoot__O(); var arg_470 any; var root_471 any = A_arbace_j2g_names_A_const_22.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_473 lang.IFn; if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = s__0; var arg_475 any = A_arbace_j2g_names_A_const_61; var arg_476 any = Lit_42; if linked_472 == nil { arg_470 = ifn_473.Invoke_O_O_O__O(arg_474, arg_475, arg_476) } else { arg_470 = linked_472.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_471, arg_474, arg_475, arg_476) }; if linked_467 == nil { tmp1 = ifn_468.Invoke_O_O__O(arg_469, arg_470) } else { tmp1 = linked_467.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_466, arg_469, arg_470) }; if jrt.J2g_Truth(tmp1) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_43), jrt.RefArrayOf(jrt.Object_class, s__0, nil)).Ref() } else { return s__0
	} }
func A_arbace_j2g_names_static_field_name_A_New() *A_arbace_j2g_names_static_field_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_static_field_name_A{}; t.Ctor(); return t }
//line :301:1
func (t *A_arbace_j2g_names_static_field_name_A) Ctor() {}
//line :301:1
func (t *A_arbace_j2g_names_static_field_name_A) Invoke_O_O_O__O(self, cls_go__0, fname__1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_7, nil); var tmp2 any; var root_477 any = A_arbace_j2g_names_A_const_62.GetRawRoot__O(); var linked_478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_477, A_arbace_j2g_names_reserved_member_A_fn_class); var ifn_479 lang.IFn; if linked_478 == nil { ifn_479 = lang.IFn_Cast(root_477) } else { ifn_479 = nil }; var arg_480 any; var root_481 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_481, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_483 lang.IFn; if linked_482 == nil { ifn_483 = lang.IFn_Cast(root_481) } else { ifn_483 = nil }; var arg_484 any = fname__1; if linked_482 == nil { arg_480 = ifn_483.Invoke_O__O(arg_484) } else { arg_480 = linked_482.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_481, arg_484) }; if linked_478 == nil { tmp2 = ifn_479.Invoke_O__O(arg_480) } else { tmp2 = linked_478.(*A_arbace_j2g_names_reserved_member_A).Invoke_O_O__O(root_477, arg_480) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, cls_go__0, nil, tmp2)).Ref() }

func A_arbace_j2g_names_static_method_name_A_New() *A_arbace_j2g_names_static_method_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_static_method_name_A{}; t.Ctor(); return t }
//line :303:1
func (t *A_arbace_j2g_names_static_method_name_A) Ctor() {}
//line :303:1
func (t *A_arbace_j2g_names_static_method_name_A) Invoke_O_O_O_O__O(self, cls_go__0, name__1, desc__2 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_7, nil); var tmp2 any; var root_485 any = A_arbace_j2g_names_A_const_63.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, A_arbace_j2g_names_method_base_A_fn_class); var ifn_487 lang.IFn; if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = name__1; var arg_489 any = desc__2; if linked_486 == nil { tmp2 = ifn_487.Invoke_O_O__O(arg_488, arg_489) } else { tmp2 = linked_486.(*A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_485, arg_488, arg_489) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, cls_go__0, nil, tmp2)).Ref() }

func A_arbace_j2g_names_impl_name_A_New() *A_arbace_j2g_names_impl_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_impl_name_A{}; t.Ctor(); return t }
//line :305:1
func (t *A_arbace_j2g_names_impl_name_A) Ctor() {}
//line :305:1
func (t *A_arbace_j2g_names_impl_name_A) Invoke_O_O__O(self, mbase__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_20, nil), jrt.RefArrayOf(jrt.Object_class, nil, mbase__0)).Ref() }



























type A_arbace_j2g_names_A struct{ jrt.Object }

var A_arbace_j2g_names_A_const_pool *jrt.RefArray

var A_arbace_j2g_names_A_const_0 *lang.Var

var A_arbace_j2g_names_A_const_1 any

var A_arbace_j2g_names_A_const_2 any

var A_arbace_j2g_names_A_const_3 *lang.Var

var A_arbace_j2g_names_A_const_4 any

var A_arbace_j2g_names_A_const_5 *lang.Var

var A_arbace_j2g_names_A_const_6 *lang.Var

var A_arbace_j2g_names_A_const_7 *lang.Var

var A_arbace_j2g_names_A_const_8 *lang.Var

var A_arbace_j2g_names_A_const_9 any

var A_arbace_j2g_names_A_const_10 *lang.Var

var A_arbace_j2g_names_A_const_11 any

var A_arbace_j2g_names_A_const_12 *lang.Var

var A_arbace_j2g_names_A_const_13 *lang.Keyword

var A_arbace_j2g_names_A_const_14 *lang.Keyword

var A_arbace_j2g_names_A_const_15 *lang.Var

var A_arbace_j2g_names_A_const_16 *lang.Var

var A_arbace_j2g_names_A_const_17 *lang.Var

var A_arbace_j2g_names_A_const_18 *lang.Keyword

var A_arbace_j2g_names_A_const_19 *lang.Var

var A_arbace_j2g_names_A_const_20 any

var A_arbace_j2g_names_A_const_21 *lang.Var

var A_arbace_j2g_names_A_const_22 *lang.Var

var A_arbace_j2g_names_A_const_23 *lang.Var

var A_arbace_j2g_names_A_const_24 *lang.Var

var A_arbace_j2g_names_A_const_25 *lang.Var

var A_arbace_j2g_names_A_const_26 *lang.Var

var A_arbace_j2g_names_A_const_27 any

var A_arbace_j2g_names_A_const_28 *lang.Var

var A_arbace_j2g_names_A_const_29 *lang.Var

var A_arbace_j2g_names_A_const_30 *lang.Var

var A_arbace_j2g_names_A_const_31 *lang.Var

var A_arbace_j2g_names_A_const_32 *lang.Var

var A_arbace_j2g_names_A_const_33 *lang.Var

var A_arbace_j2g_names_A_const_34 *lang.Var

var A_arbace_j2g_names_A_const_35 any

var A_arbace_j2g_names_A_const_36 any

var A_arbace_j2g_names_A_const_37 *lang.Var

var A_arbace_j2g_names_A_const_38 *lang.Var

var A_arbace_j2g_names_A_const_39 *lang.Var

var A_arbace_j2g_names_A_const_40 *lang.Var

var A_arbace_j2g_names_A_const_41 *lang.Var

var A_arbace_j2g_names_A_const_42 *lang.Var

var A_arbace_j2g_names_A_const_43 *lang.Var

var A_arbace_j2g_names_A_const_44 *lang.Var

var A_arbace_j2g_names_A_const_45 *lang.Var

var A_arbace_j2g_names_A_const_46 *lang.Var

var A_arbace_j2g_names_A_const_47 *lang.Var

var A_arbace_j2g_names_A_const_48 *lang.Var

var A_arbace_j2g_names_A_const_49 any

var A_arbace_j2g_names_A_const_50 *lang.Var

var A_arbace_j2g_names_A_const_51 *lang.Var

var A_arbace_j2g_names_A_const_52 *lang.Var

var A_arbace_j2g_names_A_const_53 *lang.Var

var A_arbace_j2g_names_A_const_54 *lang.Var

var A_arbace_j2g_names_A_const_55 *lang.Var

var A_arbace_j2g_names_A_const_56 *lang.Var

var A_arbace_j2g_names_A_const_57 *lang.Var

var A_arbace_j2g_names_A_const_58 *lang.Var

var A_arbace_j2g_names_A_const_59 *lang.Var

var A_arbace_j2g_names_A_const_60 *lang.Var

var A_arbace_j2g_names_A_const_61 any

var A_arbace_j2g_names_A_const_62 *lang.Var

var A_arbace_j2g_names_A_const_63 *lang.Var

var A_arbace_j2g_names_A_init jrt.ClassInit

func A_arbace_j2g_names_A_Init() { if !A_arbace_j2g_names_A_init.Done() { A_arbace_j2g_names_A_init.Run(A_arbace_j2g_names_A_clinit) } }

func A_arbace_j2g_names_A_clinit() { A_arbace_j2g_names_A_clinit_p0(); A_arbace_j2g_names_A_clinit_p1(); A_arbace_j2g_names_A_clinit_p2(); A_arbace_j2g_names_A_clinit_p3(); A_arbace_j2g_names_A_clinit_p4(); A_arbace_j2g_names_A_clinit_p5() }

func A_arbace_j2g_names_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_names_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 74); A_arbace_j2g_names_A_const_0 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[10]); A_arbace_j2g_names_A_const_1 = A_arbace_j2g_names_A_const_pool.A[11]; A_arbace_j2g_names_A_const_2 = A_arbace_j2g_names_A_const_pool.A[12]; A_arbace_j2g_names_A_const_3 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[13]); A_arbace_j2g_names_A_const_4 = A_arbace_j2g_names_A_const_pool.A[14]; A_arbace_j2g_names_A_const_5 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[15]); A_arbace_j2g_names_A_const_6 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[16]); A_arbace_j2g_names_A_const_7 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[17]); A_arbace_j2g_names_A_const_8 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[18]); A_arbace_j2g_names_A_const_9 = A_arbace_j2g_names_A_const_pool.A[19]; A_arbace_j2g_names_A_const_10 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[20]); A_arbace_j2g_names_A_const_11 = A_arbace_j2g_names_A_const_pool.A[21] }

func A_arbace_j2g_names_A_clinit_p1() { A_arbace_j2g_names_A_const_12 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[22]); A_arbace_j2g_names_A_const_13 = lang.Keyword_Cast(A_arbace_j2g_names_A_const_pool.A[23]); A_arbace_j2g_names_A_const_14 = lang.Keyword_Cast(A_arbace_j2g_names_A_const_pool.A[24]); A_arbace_j2g_names_A_const_15 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[25]); A_arbace_j2g_names_A_const_16 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[26]); A_arbace_j2g_names_A_const_17 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[27]); A_arbace_j2g_names_A_const_18 = lang.Keyword_Cast(A_arbace_j2g_names_A_const_pool.A[28]); A_arbace_j2g_names_A_const_19 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[29]); A_arbace_j2g_names_A_const_20 = A_arbace_j2g_names_A_const_pool.A[30]; A_arbace_j2g_names_A_const_21 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[31]); A_arbace_j2g_names_A_const_22 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[32]); A_arbace_j2g_names_A_const_23 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[33]) }

func A_arbace_j2g_names_A_clinit_p2() { A_arbace_j2g_names_A_const_24 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[34]); A_arbace_j2g_names_A_const_25 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[35]); A_arbace_j2g_names_A_const_26 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[36]); A_arbace_j2g_names_A_const_27 = A_arbace_j2g_names_A_const_pool.A[37]; A_arbace_j2g_names_A_const_28 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[38]); A_arbace_j2g_names_A_const_29 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[39]); A_arbace_j2g_names_A_const_30 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[40]); A_arbace_j2g_names_A_const_31 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[41]); A_arbace_j2g_names_A_const_32 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[42]); A_arbace_j2g_names_A_const_33 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[43]); A_arbace_j2g_names_A_const_34 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[44]); A_arbace_j2g_names_A_const_35 = A_arbace_j2g_names_A_const_pool.A[45] }

func A_arbace_j2g_names_A_clinit_p3() { A_arbace_j2g_names_A_const_36 = A_arbace_j2g_names_A_const_pool.A[46]; A_arbace_j2g_names_A_const_37 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[47]); A_arbace_j2g_names_A_const_38 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[48]); A_arbace_j2g_names_A_const_39 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[49]); A_arbace_j2g_names_A_const_40 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[50]); A_arbace_j2g_names_A_const_41 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[51]); A_arbace_j2g_names_A_const_42 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[52]); A_arbace_j2g_names_A_const_43 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[53]); A_arbace_j2g_names_A_const_44 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[54]); A_arbace_j2g_names_A_const_45 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[55]); A_arbace_j2g_names_A_const_46 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[56]); A_arbace_j2g_names_A_const_47 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[57]) }

func A_arbace_j2g_names_A_clinit_p4() { A_arbace_j2g_names_A_const_48 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[58]); A_arbace_j2g_names_A_const_49 = A_arbace_j2g_names_A_const_pool.A[59]; A_arbace_j2g_names_A_const_50 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[60]); A_arbace_j2g_names_A_const_51 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[61]); A_arbace_j2g_names_A_const_52 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[62]); A_arbace_j2g_names_A_const_53 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[63]); A_arbace_j2g_names_A_const_54 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[64]); A_arbace_j2g_names_A_const_55 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[65]); A_arbace_j2g_names_A_const_56 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[66]); A_arbace_j2g_names_A_const_57 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[67]); A_arbace_j2g_names_A_const_58 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[68]); A_arbace_j2g_names_A_const_59 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[69]) }

func A_arbace_j2g_names_A_clinit_p5() { A_arbace_j2g_names_A_const_60 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[70]); A_arbace_j2g_names_A_const_61 = A_arbace_j2g_names_A_const_pool.A[71]; A_arbace_j2g_names_A_const_62 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[72]); A_arbace_j2g_names_A_const_63 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[73]) }

func A_arbace_j2g_names_A_New() *A_arbace_j2g_names_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_names_A) Ctor() {}

func (t *A_arbace_j2g_names_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_names_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_names_A_class }

func (t *A_arbace_j2g_names_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_names_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_names_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_names_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_names_A); return ok }

func A_arbace_j2g_names_A_Cast(x any) *A_arbace_j2g_names_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_names_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_names_A_class)) }; return v }



type A_arbace_j2g_names_capitalize_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_capitalize_A_fn_class *jrt.Class



type A_arbace_j2g_names_compiled_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_names_compiled_class_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_names_compiled_pkg_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_names_compiled_pkg_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_names_ctor_base_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_ctor_base_A_fn_class *jrt.Class



type A_arbace_j2g_names_ctor_base_fn__1768000053_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_ctor_base_fn__1768000053_A_fn_class *jrt.Class



type A_arbace_j2g_names_desc_code_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_desc_code_A_fn_class *jrt.Class



type A_arbace_j2g_names_eval1768000004_A struct{ jrt.Object }

func A_arbace_j2g_names_eval1768000004_A_New() *A_arbace_j2g_names_eval1768000004_A { t := &A_arbace_j2g_names_eval1768000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_names_eval1768000004_A) Ctor() {}

func (t *A_arbace_j2g_names_eval1768000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_names_eval1768000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_names_eval1768000004_A_class }

func (t *A_arbace_j2g_names_eval1768000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_names_eval1768000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_names_eval1768000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_names_eval1768000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_names_eval1768000004_A); return ok }

func A_arbace_j2g_names_eval1768000004_A_Cast(x any) *A_arbace_j2g_names_eval1768000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_names_eval1768000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_names_eval1768000004_A_class)) }; return v }



type A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A_fn_class *jrt.Class



type A_arbace_j2g_names_eval1768000008_A struct{ jrt.Object }

func A_arbace_j2g_names_eval1768000008_A_New() *A_arbace_j2g_names_eval1768000008_A { t := &A_arbace_j2g_names_eval1768000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_names_eval1768000008_A) Ctor() {}

func (t *A_arbace_j2g_names_eval1768000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_names_eval1768000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_names_eval1768000008_A_class }

func (t *A_arbace_j2g_names_eval1768000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_names_eval1768000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_names_eval1768000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_names_eval1768000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_names_eval1768000008_A); return ok }

func A_arbace_j2g_names_eval1768000008_A_Cast(x any) *A_arbace_j2g_names_eval1768000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_names_eval1768000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_names_eval1768000008_A_class)) }; return v }



type A_arbace_j2g_names_eval1768000008_fn__1768000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_eval1768000008_fn__1768000009_A_fn_class *jrt.Class



type A_arbace_j2g_names_field_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_field_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_fn__1768000021_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_fn__1768000021_A_fn_class *jrt.Class



type A_arbace_j2g_names_fn__1768000021_fn__1768000022_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_fn__1768000021_fn__1768000022_A_fn_class *jrt.Class



type A_arbace_j2g_names_go_class_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_go_class_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_go_class_name_STAR__STAR__A struct{ j2g_header uint64 }

var A_arbace_j2g_names_go_class_name_STAR__STAR__A_fn_class *jrt.Class



type A_arbace_j2g_names_impl_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_impl_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_local_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_local_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_memo_str_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_memo_str_A_fn_class *jrt.Class



type A_arbace_j2g_names_memo_str_fn__1768000018_A struct{ j2g_header uint64; F_cache, F_f any }

var A_arbace_j2g_names_memo_str_fn__1768000018_A_fn_class *jrt.Class



type A_arbace_j2g_names_method_base_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_method_base_A_fn_class *jrt.Class



type A_arbace_j2g_names_method_base_STAR__A struct{ j2g_header uint64 }

var A_arbace_j2g_names_method_base_STAR__A_fn_class *jrt.Class



type A_arbace_j2g_names_method_base_STAR__fn__1768000046_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_method_base_STAR__fn__1768000046_A_fn_class *jrt.Class



type A_arbace_j2g_names_munge_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_munge_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_new_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_new_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_new_name_fn__1768000060_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_new_name_fn__1768000060_A_fn_class *jrt.Class



type A_arbace_j2g_names_own_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_names_own_class_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_names_pkg_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_pkg_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_pkg_ns_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_pkg_ns_A_fn_class *jrt.Class



type A_arbace_j2g_names_pkg_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_pkg_of_A_fn_class *jrt.Class



type A_arbace_j2g_names_pkg_path_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_pkg_path_A_fn_class *jrt.Class



type A_arbace_j2g_names_qualified_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_names_qualified_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A struct{ j2g_header uint64; F_internal any }

var A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A_fn_class *jrt.Class



type A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A struct{ j2g_header uint64; F_internal any }

var A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A_fn_class *jrt.Class



type A_arbace_j2g_names_reserved_member_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_reserved_member_A_fn_class *jrt.Class



type A_arbace_j2g_names_static_field_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_static_field_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_static_method_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_static_method_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_top_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_top_of_A_fn_class *jrt.Class



type A_arbace_j2g_names_user_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_names_user_class_QMARK__A_fn_class *jrt.Class
