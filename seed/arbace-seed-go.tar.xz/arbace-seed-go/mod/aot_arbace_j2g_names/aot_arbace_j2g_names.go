//line aot_arbace_j2g_names.ae:1
package aot_arbace_j2g_names

import (
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A_New() *A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_names_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_names_A_const_4); tmp2 = lang.IFn_Cast(A_arbace_j2g_names_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_names_A_const_1, A_arbace_j2g_names_A_const_2); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_names_eval1768000008_fn__1768000009_A_New() *A_arbace_j2g_names_eval1768000008_fn__1768000009_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_eval1768000008_fn__1768000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_names_eval1768000008_fn__1768000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_names_eval1768000008_fn__1768000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_names_A_const_5.GetRawRoot__O()); var tmp2 any; var root_16 any = A_arbace_j2g_names_A_const_6.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = A_arbace_j2g_names_A_const_7; if linked_17 == nil { tmp2 = ifn_18.Invoke_O__O(arg_19) } else { tmp2 = linked_17.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_16, arg_19) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_names_A_const_8.GetRawRoot__O(), A_arbace_j2g_names_A_const_9) }















func A_arbace_j2g_names_top_of_A_New() *A_arbace_j2g_names_top_of_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_top_of_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_j2g_names_top_of_A) Ctor() {}
//line :17:1
func (t *A_arbace_j2g_names_top_of_A) Invoke_O_O__O(self, n__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_11); if lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return n__0 } else { var root_20 any = A_arbace_j2g_names_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = n__0; var arg_24 any = A_arbace_j2g_names_A_const_11; var arg_25 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_21 == nil { return ifn_22.Invoke_O_O_O__O(arg_23, arg_24, arg_25) } else { return linked_21.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_20, arg_23, arg_24, arg_25) } } }

func A_arbace_j2g_names_pkg_of_A_New() *A_arbace_j2g_names_pkg_of_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_pkg_of_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_j2g_names_pkg_of_A) Ctor() {}
//line :19:1
func (t *A_arbace_j2g_names_pkg_of_A) Invoke_O_O__O(self, internal__0 any) any {







	var tmp1 any; var or__1927000174__auto____2 any; var root_26 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_28 lang.IFn
	if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = internal__0; var arg_30 any = Lit_29; if linked_27 == nil { or__1927000174__auto____2 = ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { or__1927000174__auto____2 = linked_27.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_26, arg_29, arg_30) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_31 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = internal__0; var arg_35 any = Lit_30; if linked_32 == nil { or__1927000174__auto____3 = ifn_33.Invoke_O_O__O(arg_34, arg_35) } else { or__1927000174__auto____3 = linked_32.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_31, arg_34, arg_35) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var root_36 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_38 lang.IFn
		if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = internal__0; var arg_40 any = Lit_31; if linked_37 == nil { or__1927000174__auto____4 = ifn_38.Invoke_O_O__O(arg_39, arg_40) } else { or__1927000174__auto____4 = linked_37.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_36, arg_39, arg_40) }
//line :28:1
		if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { var or__1927000174__auto____5 any; var root_41 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_43 lang.IFn
			if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = internal__0; var arg_45 any = Lit_32; if linked_42 == nil { or__1927000174__auto____5 = ifn_43.Invoke_O_O__O(arg_44, arg_45) } else { or__1927000174__auto____5 = linked_42.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_41, arg_44, arg_45) }
//line :28:1
			if jrt.J2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any; var root_46 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_48 lang.IFn

				if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = internal__0; var arg_50 any = Lit_33; if linked_47 == nil { or__1927000174__auto____6 = ifn_48.Invoke_O_O__O(arg_49, arg_50) } else { or__1927000174__auto____6 = linked_47.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_46, arg_49, arg_50) }
//line :28:1
				if jrt.J2g_Truth(or__1927000174__auto____6) { tmp1 = or__1927000174__auto____6 } else { var or__1927000174__auto____7 any; var root_51 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_53 lang.IFn

					if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = internal__0; var arg_55 any = Lit_34; if linked_52 == nil { or__1927000174__auto____7 = ifn_53.Invoke_O_O__O(arg_54, arg_55) } else { or__1927000174__auto____7 = linked_52.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_51, arg_54, arg_55) }
//line :28:1
					if jrt.J2g_Truth(or__1927000174__auto____7) { tmp1 = or__1927000174__auto____7 } else { var or__1927000174__auto____8 any; var root_56 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_58 lang.IFn


						if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = internal__0; var arg_60 any = Lit_35; if linked_57 == nil { or__1927000174__auto____8 = ifn_58.Invoke_O_O__O(arg_59, arg_60) } else { or__1927000174__auto____8 = linked_57.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_56, arg_59, arg_60) }
//line :28:1
						if jrt.J2g_Truth(or__1927000174__auto____8) { tmp1 = or__1927000174__auto____8 } else { var or__1927000174__auto____9 any; var root_61 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_63 lang.IFn


							if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = internal__0; var arg_65 any = Lit_36; if linked_62 == nil { or__1927000174__auto____9 = ifn_63.Invoke_O_O__O(arg_64, arg_65) } else { or__1927000174__auto____9 = linked_62.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_61, arg_64, arg_65) }
//line :28:1
							if jrt.J2g_Truth(or__1927000174__auto____9) { tmp1 = or__1927000174__auto____9 } else { var or__1927000174__auto____10 any; var root_66 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_68 lang.IFn



								if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = internal__0; var arg_70 any = Lit_37; if linked_67 == nil { or__1927000174__auto____10 = ifn_68.Invoke_O_O__O(arg_69, arg_70) } else { or__1927000174__auto____10 = linked_67.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_66, arg_69, arg_70) }
//line :28:1
								if jrt.J2g_Truth(or__1927000174__auto____10) { tmp1 = or__1927000174__auto____10 } else { var or__1927000174__auto____11 any; var root_71 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_73 lang.IFn



									if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = internal__0; var arg_75 any = Lit_38; if linked_72 == nil { or__1927000174__auto____11 = ifn_73.Invoke_O_O__O(arg_74, arg_75) } else { or__1927000174__auto____11 = linked_72.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_71, arg_74, arg_75) }
//line :28:1
									if jrt.J2g_Truth(or__1927000174__auto____11) { tmp1 = or__1927000174__auto____11 } else {




										var root_76 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = internal__0; var arg_80 any = Lit_39; if linked_77 == nil { tmp1 = ifn_78.Invoke_O_O__O(arg_79, arg_80) } else { tmp1 = linked_77.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_76, arg_79, arg_80) } } } } } } } } } } }
//line :27:1
	if jrt.J2g_Truth(tmp1) { return A_arbace_j2g_names_A_const_13 } else { if A_arbace_j2g_names_A_const_14 != nil { var temp__1927000408__auto____2 any; var tmp2 any; var root_81 any = A_arbace_j2g_names_A_const_6.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_83 lang.IFn






		if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = A_arbace_j2g_names_A_const_15.GetRawRoot__O(); if linked_82 == nil { tmp2 = ifn_83.Invoke_O__O(arg_84) } else { tmp2 = linked_82.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_81, arg_84) }; var tmp3 any = tmp2; var tmp4 any; var root_85 any = A_arbace_j2g_names_A_const_16.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, A_arbace_j2g_names_top_of_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = internal__0; if linked_86 == nil { tmp4 = ifn_87.Invoke_O__O(arg_88) } else { tmp4 = linked_86.(*A_arbace_j2g_names_top_of_A).Invoke_O_O__O(root_85, arg_88) }; temp__1927000408__auto____2 = lang.RT_Get_O_O__O_NoInit(tmp3, tmp4); if jrt.J2g_Truth(temp__1927000408__auto____2) { var p__3 any = temp__1927000408__auto____2; var root_89 any = A_arbace_j2g_names_A_const_17.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = p__3; if linked_90 == nil { return ifn_91.Invoke_O__O(arg_92) } else { return linked_90.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_89, arg_92) } } else { return A_arbace_j2g_names_A_const_18 } } else {
//line :27:1
			return nil
		}
	}
}





func A_arbace_j2g_names_compiled_pkg_QMARK__A_New() *A_arbace_j2g_names_compiled_pkg_QMARK__A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_compiled_pkg_QMARK__A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_j2g_names_compiled_pkg_QMARK__A) Ctor() {}
//line :36:1
func (t *A_arbace_j2g_names_compiled_pkg_QMARK__A) Invoke_O_O__O(self, pkg__0 any) any { var root_93 any = A_arbace_j2g_names_A_const_19.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = lang.IFn_Cast(A_arbace_j2g_names_A_const_20).Invoke_O__O(pkg__0); if linked_94 == nil { return ifn_95.Invoke_O__O(arg_96) } else { return linked_94.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_93, arg_96) } }

func A_arbace_j2g_names_pkg_name_A_New() *A_arbace_j2g_names_pkg_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_pkg_name_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_j2g_names_pkg_name_A) Ctor() {}
//line :38:1
func (t *A_arbace_j2g_names_pkg_name_A) Invoke_O_O__O(self, pkg__0 any) any { var root_97 any = A_arbace_j2g_names_A_const_21.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = pkg__0; if linked_98 == nil { return ifn_99.Invoke_O__O(arg_100) } else { return linked_98.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_97, arg_100) } }
func A_arbace_j2g_names_pkg_path_A_New() *A_arbace_j2g_names_pkg_path_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_pkg_path_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_j2g_names_pkg_path_A) Ctor() {}
//line :39:1
func (t *A_arbace_j2g_names_pkg_path_A) Invoke_O_O__O(self, pkg__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_1, nil); var tmp2 any; var root_101 any = A_arbace_j2g_names_A_const_21.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = pkg__0; if linked_102 == nil { tmp2 = ifn_103.Invoke_O__O(arg_104) } else { tmp2 = linked_102.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_101, arg_104) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }
func A_arbace_j2g_names_pkg_ns_A_New() *A_arbace_j2g_names_pkg_ns_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_pkg_ns_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_j2g_names_pkg_ns_A) Ctor() {}
//line :40:1
func (t *A_arbace_j2g_names_pkg_ns_A) Invoke_O_O__O(self, pkg__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_28, nil); var tmp2 any; var root_105 any = A_arbace_j2g_names_A_const_21.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = pkg__0; if linked_106 == nil { tmp2 = ifn_107.Invoke_O__O(arg_108) } else { tmp2 = linked_106.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_105, arg_108) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }



















func A_arbace_j2g_names_memo_str_A_New() *A_arbace_j2g_names_memo_str_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_memo_str_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_j2g_names_memo_str_A) Ctor() {}
//line :60:1
func (t *A_arbace_j2g_names_memo_str_A) Invoke_O_O__O(self, f__0 any) any { var cache__2 any = jrt.ConcurrentHashMap_New(); var tmp1 any = A_arbace_j2g_names_memo_str_fn__1768000018_A_New_O_O(cache__2, f__0); var tmp2 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_j2g_names_memo_str_fn__1768000018_A_fn_class; if




	fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_j2g_names_memo_str_fn__1768000018_A_fn_class = fncls__109d; tmp2 = fncls__109d } else { tmp2 = fncls__109 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :65:1
func A_arbace_j2g_names_memo_str_fn__1768000018_A_New_O_O(p0, p1 any) *A_arbace_j2g_names_memo_str_fn__1768000018_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_memo_str_fn__1768000018_A{}; t.Ctor_O_O(p0, p1); return t }
//line :65:1
func (t *A_arbace_j2g_names_memo_str_fn__1768000018_A) Ctor_O_O(c__cache, c__f any) { t.F_cache = c__cache; t.F_f = c__f }
//line :65:1
func (t *A_arbace_j2g_names_memo_str_fn__1768000018_A) Invoke_O_O__O(self, k__1 any) any { var or__1927000174__auto____2 any = jrt.NN(jrt.ConcurrentHashMap_Cast(t.F_cache)).Get_O__O(k__1); if
												jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var v__3 any = lang.IFn_Cast(t.F_f).Invoke_O__O(k__1)

		jrt.NN(jrt.ConcurrentHashMap_Cast(t.F_cache)).Put_O_O__O(k__1, v__3)
//line :66:1
		return v__3 } }






func A_arbace_j2g_names_fn__1768000021_A_New() *A_arbace_j2g_names_fn__1768000021_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_fn__1768000021_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_j2g_names_fn__1768000021_A) Ctor() {}
//line :73:1
func (t *A_arbace_j2g_names_fn__1768000021_A) Invoke_O_O__O(self, s__0 any) any { var m__2 any; var root_110 any = A_arbace_j2g_names_A_const_22.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_112 lang.IFn; if
										linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any; var root_116 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any; var root_120 any = A_arbace_j2g_names_A_const_24.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_munge_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = s__0; if linked_121 == nil { arg_119 = ifn_122.Invoke_O__O(arg_123) } else { arg_119 = linked_121.(*aot_arbace_core.A_arbace_core_munge_A).Invoke_O_O__O(root_120, arg_123) }; if linked_117 == nil { arg_113 = ifn_118.Invoke_O__O(arg_119) } else { arg_113 = linked_117.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_116, arg_119) }; var arg_114 any = Lit_11; var arg_115 any = Lit_7; if linked_111 == nil { m__2 = ifn_112.Invoke_O_O_O__O(arg_113, arg_114, arg_115) } else { m__2 = linked_111.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_110, arg_113, arg_114, arg_115) }; var root_124 any =


	A_arbace_j2g_names_A_const_25.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var arg_128 any; var root_129 any = A_arbace_j2g_names_A_const_26.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any; var tmp1 any = A_arbace_j2g_names_fn__1768000021_fn__1768000022_A_New(); var tmp2 *jrt.Class; var fncls__134 *jrt.Class = A_arbace_j2g_names_fn__1768000021_fn__1768000022_A_fn_class; if fncls__134 == nil { var fncls__134d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_j2g_names_fn__1768000021_fn__1768000022_A_fn_class = fncls__134d; tmp2 = fncls__134d } else { tmp2 = fncls__134 }; arg_132 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_133 any = m__2; if linked_130 == nil { arg_128 = ifn_131.Invoke_O_O__O(arg_132, arg_133) } else { arg_128 = linked_130.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_129, arg_132, arg_133) }; if linked_125 == nil { return ifn_126.Invoke_O_O__O(arg_127, arg_128) } else { return linked_125.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_124, arg_127, arg_128) } }
//line :77:1
func A_arbace_j2g_names_fn__1768000021_fn__1768000022_A_New() *A_arbace_j2g_names_fn__1768000021_fn__1768000022_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_fn__1768000021_fn__1768000022_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_j2g_names_fn__1768000021_fn__1768000022_A) Ctor() {}
//line :77:1
func (t *A_arbace_j2g_names_fn__1768000021_fn__1768000022_A) Invoke_O_O__O(self, c__1 any) any { var tmp1 bool; var or__1927000174__auto____2 bool = jrt.Character_IsLetterOrDigit_C__Z_NoInit(lang.RT_CharCast_O__C_NoInit(c__1)); if or__1927000174__auto____2 { tmp1 = or__1927000174__auto____2 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(c__1, A_arbace_j2g_names_A_const_27) }; if tmp1 { return c__1 } else { return A_arbace_j2g_names_A_const_27 } }

func A_arbace_j2g_names_munge_name_A_New() *A_arbace_j2g_names_munge_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_munge_name_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_j2g_names_munge_name_A) Ctor() {}
//line :79:1
func (t *A_arbace_j2g_names_munge_name_A) Invoke_O_O__O(self, s__0 any) any {


	var root_135 any = A_arbace_j2g_names_A_const_28.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, A_arbace_j2g_names_memo_str_fn__1768000018_A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any; var root_139 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_139, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_141 lang.IFn; if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = s__0; if linked_140 == nil { arg_138 = ifn_141.Invoke_O__O(arg_142) } else { arg_138 = linked_140.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_139, arg_142) }; if linked_136 == nil { return ifn_137.Invoke_O__O(arg_138) } else { return linked_136.(*A_arbace_j2g_names_memo_str_fn__1768000018_A).Invoke_O_O__O(root_135, arg_138)
	} }
func A_arbace_j2g_names_local_name_A_New() *A_arbace_j2g_names_local_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_local_name_A{}; t.Ctor(); return t }
//line :84:1
func (t *A_arbace_j2g_names_local_name_A) Ctor() {}
//line :84:1
func (t *A_arbace_j2g_names_local_name_A) Invoke_O_O__O(self, sym__0 any) any { var s__2 any; var root_143 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_145 lang.IFn; if




	linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any; var root_147 any = A_arbace_j2g_names_A_const_21.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = sym__0; if linked_148 == nil { arg_146 = ifn_149.Invoke_O__O(arg_150) } else { arg_146 = linked_148.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_147, arg_150) }; if linked_144 == nil { s__2 = ifn_145.Invoke_O__O(arg_146) } else { s__2 = linked_144.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_143, arg_146) }; var s__3 any; var tmp1 any; var root_151 any = /*line :84:1*/A_arbace_j2g_names_A_const_30.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_string.A_arbace_string_blank_QMARK__A_fn_class); var ifn_153 lang.IFn; if





	linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = s__2; if linked_152 == nil { tmp1 = ifn_153.Invoke_O__O(arg_154) } else { tmp1 = linked_152.(*aot_arbace_string.A_arbace_string_blank_QMARK__A).Invoke_O_O__O(root_151, arg_154) }; if jrt.J2g_Truth(tmp1) { s__3 = Lit_21 } else { s__3 = s__2 }; var tmp2 any; var or__1927000174__auto____4 any =
	lang.IFn_Cast(A_arbace_j2g_names_A_const_31.GetRawRoot__O()).Invoke_O__O(s__3); if jrt.J2g_Truth(or__1927000174__auto____4) { tmp2 = or__1927000174__auto____4 } else { var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_j2g_names_A_const_32.GetRawRoot__O()).Invoke_O__O(s__3); if jrt.J2g_Truth(or__1927000174__auto____5) { tmp2 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_j2g_names_A_const_33.GetRawRoot__O()).Invoke_O__O(s__3); if jrt.J2g_Truth(or__1927000174__auto____6) { tmp2 = or__1927000174__auto____6 } else { var or__1927000174__auto____7 bool = jrt.Character_IsUpperCase_C__Z_NoInit(jrt.NN(jrt.String_Cast(s__3)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0))); if or__1927000174__auto____7 { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var or__1927000174__auto____8 any; var root_155 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_157 lang.IFn

		if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = s__3; var arg_159 any = Lit_22; if linked_156 == nil { or__1927000174__auto____8 = ifn_157.Invoke_O_O__O(arg_158, arg_159) } else { or__1927000174__auto____8 = linked_156.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_155, arg_158, arg_159) }
//line :91:1
		if jrt.J2g_Truth(or__1927000174__auto____8) { tmp2 = or__1927000174__auto____8 } else { var or__1927000174__auto____9 any; var root_160 any = A_arbace_j2g_names_A_const_34.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_162 lang.IFn

			if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = A_arbace_j2g_names_A_const_35; var arg_164 any = s__3; if linked_161 == nil { or__1927000174__auto____9 = ifn_162.Invoke_O_O__O(arg_163, arg_164) } else { or__1927000174__auto____9 = linked_161.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_160, arg_163, arg_164) }
//line :91:1
			if jrt.J2g_Truth(or__1927000174__auto____9) { tmp2 = or__1927000174__auto____9 } else {

				var root_165 any = A_arbace_j2g_names_A_const_34.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = A_arbace_j2g_names_A_const_36; var arg_169 any = s__3; if linked_166 == nil { tmp2 = ifn_167.Invoke_O_O__O(arg_168, arg_169) } else { tmp2 = linked_166.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_165, arg_168, arg_169) } } } } } } }; if /*line :91:1*/ jrt.J2g_Truth(tmp2) {


					return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, s__3, nil)).Ref() } else {
//line :91:1
						return s__3 } }














































func A_arbace_j2g_names_compiled_class_QMARK__A_New() *A_arbace_j2g_names_compiled_class_QMARK__A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_compiled_class_QMARK__A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_j2g_names_compiled_class_QMARK__A) Ctor() {}
//line :138:1
func (t *A_arbace_j2g_names_compiled_class_QMARK__A) Invoke_O_O__O(self, internal__0 any) any { var or__1927000174__auto____2 any; var and__1927000168__auto____2 any; var root_170 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_172 lang.IFn; if





	linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = internal__0; var arg_174 any = Lit_1; if linked_171 == nil { and__1927000168__auto____2 = ifn_172.Invoke_O_O__O(arg_173, arg_174) } else { and__1927000168__auto____2 = linked_171.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_170, arg_173, arg_174) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_175 any = A_arbace_j2g_names_A_const_19.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any; var root_179 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_181 lang.IFn; if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = internal__0; var arg_183 any = Lit_2; if linked_180 == nil { arg_178 = ifn_181.Invoke_O_O__O(arg_182, arg_183) } else { arg_178 = linked_180.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_179, arg_182, arg_183) }; if linked_176 == nil { and__1927000168__auto____3 = ifn_177.Invoke_O__O(arg_178) } else { and__1927000168__auto____3 = linked_176.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_175, arg_178) }; if jrt.J2g_Truth(and__1927000168__auto____3) {
		var root_184 any = A_arbace_j2g_names_A_const_19.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any; var root_188 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = internal__0; var arg_192 any = Lit_3; if linked_189 == nil { arg_187 = ifn_190.Invoke_O_O__O(arg_191, arg_192) } else { arg_187 = linked_189.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_188, arg_191, arg_192) }; if linked_185 == nil { or__1927000174__auto____2 = ifn_186.Invoke_O__O(arg_187) } else { or__1927000174__auto____2 = linked_185.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_184, arg_187) } } else {
//line :144:1
			or__1927000174__auto____2 = and__1927000168__auto____3 } } else { or__1927000174__auto____2 = and__1927000168__auto____2 }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var temp__1927000414__auto____3 any; var tmp1 any; var root_193 any = A_arbace_j2g_names_A_const_6.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_195 lang.IFn

				if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = A_arbace_j2g_names_A_const_15.GetRawRoot__O(); if linked_194 == nil { tmp1 = ifn_195.Invoke_O__O(arg_196) } else { tmp1 = linked_194.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_193, arg_196) }; var tmp2 any = tmp1; var tmp3 any; var root_197 any = A_arbace_j2g_names_A_const_16.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, A_arbace_j2g_names_top_of_A_fn_class); var ifn_199 lang.IFn; if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = internal__0; if linked_198 == nil { tmp3 = ifn_199.Invoke_O__O(arg_200) } else { tmp3 = linked_198.(*A_arbace_j2g_names_top_of_A).Invoke_O_O__O(root_197, arg_200) }; temp__1927000414__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp2, tmp3); if jrt.J2g_Truth(temp__1927000414__auto____3) { var p__4 any = temp__1927000414__auto____3; var root_201 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_203 lang.IFn
					if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = p__4; var arg_205 any = Lit_4; if linked_202 == nil { return ifn_203.Invoke_O_O__O(arg_204, arg_205) } else { return linked_202.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_201, arg_204, arg_205) } } else {
//line :146:1
						return nil } } }





























func A_arbace_j2g_names_qualified_QMARK__A_New() *A_arbace_j2g_names_qualified_QMARK__A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_qualified_QMARK__A{}; t.Ctor(); return t }
//line :176:1
func (t *A_arbace_j2g_names_qualified_QMARK__A) Ctor() {}
//line :176:1
func (t *A_arbace_j2g_names_qualified_QMARK__A) Invoke_O_O__O(self, internal__0 any) any {


	var tmp1 any; var or__1927000174__auto____2 any; var root_206 any = A_arbace_j2g_names_A_const_37.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any; var tmp2 any = A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A_New_O(internal__0); var tmp3 *jrt.Class; var fncls__216 *jrt.Class = A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A_fn_class; if fncls__216 == nil { var fncls__216d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A_fn_class = fncls__216d; tmp3 = fncls__216d } else { tmp3 = fncls__216 }; arg_209 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_210 any = A_arbace_j2g_names_A_const_38.GetRawRoot__O(); if linked_207 == nil { or__1927000174__auto____2 = ifn_208.Invoke_O_O__O(arg_209, arg_210) } else { or__1927000174__auto____2 = linked_207.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_206, arg_209, arg_210) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else {
		var root_217 any = A_arbace_j2g_names_A_const_37.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any; var tmp4 any = A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A_New_O(internal__0); var tmp5 *jrt.Class; var fncls__227 *jrt.Class = A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A_fn_class; if fncls__227 == nil { var fncls__227d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A_fn_class = fncls__227d; tmp5 = fncls__227d } else { tmp5 = fncls__227 }; arg_220 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_221 any; var root_228 any = A_arbace_j2g_names_A_const_6.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_230 lang.IFn; if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = A_arbace_j2g_names_A_const_39.GetRawRoot__O(); if linked_229 == nil { arg_221 = ifn_230.Invoke_O__O(arg_231) } else { arg_221 = linked_229.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_228, arg_231) }; if linked_218 == nil { tmp1 = ifn_219.Invoke_O_O__O(arg_220, arg_221) } else { tmp1 = linked_218.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_217, arg_220, arg_221) } }
//line :179:1
	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() }
//line :179:1
func A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A_New_O(p0 any) *A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A{}; t.Ctor_O(p0); return t }
//line :179:1
func (t *A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A) Ctor_O(c__internal any) { t.F_internal = c__internal }
//line :179:1
func (t *A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A) Invoke_O_O__O(self, p1__1768000028_SHARP___1 any) any { var root_211 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_213 lang.IFn; if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any = t.F_internal; var arg_215 any = p1__1768000028_SHARP___1; if linked_212 == nil { return ifn_213.Invoke_O_O__O(arg_214, arg_215) } else { return linked_212.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_211, arg_214, arg_215) } }
func A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A_New_O(p0 any) *A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A{}; t.Ctor_O(p0); return t }
//line :180:1
func (t *A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A) Ctor_O(c__internal any) { t.F_internal = c__internal }
//line :180:1
func (t *A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A) Invoke_O_O__O(self, p1__1768000029_SHARP___1 any) any { var root_222 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_224 lang.IFn; if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any = t.F_internal; var arg_226 any = p1__1768000029_SHARP___1; if linked_223 == nil { return ifn_224.Invoke_O_O__O(arg_225, arg_226) } else { return linked_223.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_222, arg_225, arg_226) } }

func A_arbace_j2g_names_user_class_QMARK__A_New() *A_arbace_j2g_names_user_class_QMARK__A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_user_class_QMARK__A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_j2g_names_user_class_QMARK__A) Ctor() {}
//line :182:1
func (t *A_arbace_j2g_names_user_class_QMARK__A) Invoke_O_O__O(self, internal__0 any) any { var and__1927000168__auto____2 bool; var tmp1 any = A_arbace_j2g_names_A_const_18; var tmp2 any; var root_232 any = A_arbace_j2g_names_A_const_40.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, A_arbace_j2g_names_pkg_of_A_fn_class); var ifn_234 lang.IFn; if







	linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = internal__0; if linked_233 == nil { tmp2 = ifn_234.Invoke_O__O(arg_235) } else { tmp2 = linked_233.(*A_arbace_j2g_names_pkg_of_A).Invoke_O_O__O(root_232, arg_235) }; and__1927000168__auto____2 = lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2); if and__1927000168__auto____2 { var root_236 any = A_arbace_j2g_names_A_const_19.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any; var root_240 any = A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = internal__0; var arg_244 any = Lit_1; if linked_241 == nil { arg_239 = ifn_242.Invoke_O_O__O(arg_243, arg_244) } else { arg_239 = linked_241.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_240, arg_243, arg_244) }; if linked_237 == nil { return ifn_238.Invoke_O__O(arg_239) } else { return linked_237.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_236, arg_239) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }



func A_arbace_j2g_names_go_class_name_A_New() *A_arbace_j2g_names_go_class_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_go_class_name_A{}; t.Ctor(); return t }
//line :194:1
func (t *A_arbace_j2g_names_go_class_name_A) Ctor() {}
//line :194:1
func (t *A_arbace_j2g_names_go_class_name_A) Invoke_O_O__O(self, internal__0 any) any {







	var root_245 any = A_arbace_j2g_names_A_const_41.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, A_arbace_j2g_names_memo_str_fn__1768000018_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = internal__0; if linked_246 == nil { return ifn_247.Invoke_O__O(arg_248) } else { return linked_246.(*A_arbace_j2g_names_memo_str_fn__1768000018_A).Invoke_O_O__O(root_245, arg_248)
	} }
func A_arbace_j2g_names_go_class_name_STAR__STAR__A_New() *A_arbace_j2g_names_go_class_name_STAR__STAR__A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_go_class_name_STAR__STAR__A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_j2g_names_go_class_name_STAR__STAR__A) Ctor() {}
//line :204:1
func (t *A_arbace_j2g_names_go_class_name_STAR__STAR__A) Invoke_O_O__O(self, internal__0 any) any { var or__1927000174__auto____2 any = lang.RT_Get_O_O__O_NoInit(A_arbace_j2g_names_A_const_42.GetRawRoot__O(), internal__0); if
													jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var tmp1 any; var root_249 any = A_arbace_j2g_names_A_const_43.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, A_arbace_j2g_names_qualified_QMARK__A_fn_class); var ifn_251 lang.IFn
														if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = internal__0; if linked_250 == nil { tmp1 = ifn_251.Invoke_O__O(arg_252) } else { tmp1 = linked_250.(*A_arbace_j2g_names_qualified_QMARK__A).Invoke_O_O__O(root_249, arg_252) }; if jrt.J2g_Truth(tmp1) {
															var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_13, nil); var tmp3 any; var root_253 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any; var root_257 any = A_arbace_j2g_names_A_const_22.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = internal__0; var arg_261 any = Lit_14; var arg_262 any = Lit_7; if linked_258 == nil { arg_256 = ifn_259.Invoke_O_O_O__O(arg_260, arg_261, arg_262) } else { arg_256 = linked_258.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_257, arg_260, arg_261, arg_262) }; if linked_254 == nil { tmp3 = ifn_255.Invoke_O__O(arg_256) } else { tmp3 = linked_254.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_253, arg_256) }; or__1927000174__auto____3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref() } else {
//line :206:1
				or__1927000174__auto____3 = nil }
//line :205:1
		if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var tmp4 any; var root_263 any = A_arbace_j2g_names_A_const_44.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_263, A_arbace_j2g_names_user_class_QMARK__A_fn_class); var ifn_265 lang.IFn


			if linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var arg_266 any = internal__0; if linked_264 == nil { tmp4 = ifn_265.Invoke_O__O(arg_266) } else { tmp4 = linked_264.(*A_arbace_j2g_names_user_class_QMARK__A).Invoke_O_O__O(root_263, arg_266) }; if jrt.J2g_Truth(tmp4) {


				var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_16); var tmp6 any; var root_267 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any; var root_271 any = A_arbace_j2g_names_A_const_22.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = internal__0; var arg_275 any = Lit_14; var arg_276 any = Lit_7; if linked_272 == nil { arg_270 = ifn_273.Invoke_O_O_O__O(arg_274, arg_275, arg_276) } else { arg_270 = linked_272.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_271, arg_274, arg_275, arg_276) }; if linked_268 == nil { tmp6 = ifn_269.Invoke_O__O(arg_270) } else { tmp6 = linked_268.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_267, arg_270) }; or__1927000174__auto____4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6, nil)).Ref() } else {
//line :208:1
					or__1927000174__auto____4 = nil }
//line :205:1
			if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var or__1927000174__auto____5 any; var tmp7 any; var root_277 any = A_arbace_j2g_names_A_const_45.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, A_arbace_j2g_names_compiled_class_QMARK__A_fn_class); var ifn_279 lang.IFn






				if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = internal__0; if linked_278 == nil { tmp7 = ifn_279.Invoke_O__O(arg_280) } else { tmp7 = linked_278.(*A_arbace_j2g_names_compiled_class_QMARK__A).Invoke_O_O__O(root_277, arg_280) }; if jrt.J2g_Truth(tmp7) {

					var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_17, nil, Lit_18); var tmp9 any; var root_281 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_281, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_283 lang.IFn; if linked_282 == nil { ifn_283 = lang.IFn_Cast(root_281) } else { ifn_283 = nil }; var arg_284 any; var root_285 any = A_arbace_j2g_names_A_const_22.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_287 lang.IFn; if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = internal__0; var arg_289 any = Lit_14; var arg_290 any = Lit_7; if linked_286 == nil { arg_284 = ifn_287.Invoke_O_O_O__O(arg_288, arg_289, arg_290) } else { arg_284 = linked_286.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_285, arg_288, arg_289, arg_290) }; if linked_282 == nil { tmp9 = ifn_283.Invoke_O__O(arg_284) } else { tmp9 = linked_282.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_281, arg_284) }; or__1927000174__auto____5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp9, nil)).Ref() } else {
//line :212:1
						or__1927000174__auto____5 = nil }
//line :205:1
				if jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { var s__6 any; var root_291 any = A_arbace_j2g_names_A_const_10.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_293 lang.IFn









					if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = internal__0; var arg_295 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(internal__0)).LastIndexOf_String__I(Lit_14)))).Ref(); if linked_292 == nil { s__6 = ifn_293.Invoke_O_O__O(arg_294, arg_295) } else { s__6 = linked_292.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_291, arg_294, arg_295) }
//line :205:1
					var s__7 any; var root_296 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_298 lang.IFn










					if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = s__6; if linked_297 == nil { s__7 = ifn_298.Invoke_O__O(arg_299) } else { s__7 = linked_297.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_296, arg_299) }
					var tmp10 any; var and__1927000168__auto____8 any; var root_300 any = A_arbace_j2g_names_A_const_46.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = s__7; if linked_301 == nil { and__1927000168__auto____8 = ifn_302.Invoke_O__O(arg_303) } else { and__1927000168__auto____8 = linked_301.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_300, arg_303) }; if jrt.J2g_Truth(and__1927000168__auto____8) { tmp10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Character_IsUpperCase_C__Z_NoInit(jrt.NN(jrt.String_Cast(s__7)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp10 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp10) { return s__7 } else {

						return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, s__7)).Ref() } } } } } }



func A_arbace_j2g_names_capitalize_A_New() *A_arbace_j2g_names_capitalize_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_capitalize_A{}; t.Ctor(); return t }
//line :223:1
func (t *A_arbace_j2g_names_capitalize_A) Ctor() {}
//line :223:1
func (t *A_arbace_j2g_names_capitalize_A) Invoke_O_O__O(self, s__0 any) any {
	var tmp1 any; var root_304 any = A_arbace_j2g_names_A_const_47.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_306 lang.IFn; if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = s__0; if linked_305 == nil { tmp1 = ifn_306.Invoke_O__O(arg_307) } else { tmp1 = linked_305.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_304, arg_307) }; if jrt.J2g_Truth(tmp1) { return s__0 } else { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 any = jrt.Character_ValueOf_C__Character_NoInit(jrt.Character_ToUpperCase_C__C_NoInit(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0)))).Ref(); var tmp4 any; var root_308 any = A_arbace_j2g_names_A_const_10.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = s__0; var arg_312 any = A_arbace_j2g_names_A_const_48; if linked_309 == nil { tmp4 = ifn_310.Invoke_O_O__O(arg_311, arg_312) } else { tmp4 = linked_309.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_308, arg_311, arg_312) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4)).Ref()
	}
}






func A_arbace_j2g_names_desc_code_A_New() *A_arbace_j2g_names_desc_code_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_desc_code_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_j2g_names_desc_code_A) Ctor() {}
//line :233:1
func (t *A_arbace_j2g_names_desc_code_A) Invoke_O_O__O(self, d__0 any) any {


	var tmp1 any; var root_313 any = A_arbace_j2g_names_A_const_49.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_313, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_315 lang.IFn
	if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any = d__0; if linked_314 == nil { tmp1 = ifn_315.Invoke_O__O(arg_316) } else { tmp1 = linked_314.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_313, arg_316) }
//line :236:1
	if jrt.J2g_Truth(tmp1) { var n__2 any; var root_317 any = A_arbace_j2g_names_A_const_50.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, aot_arbace_classes_types.A_arbace_classes_types_array_dims_A_fn_class); var ifn_319 lang.IFn
		if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any = d__0; if linked_318 == nil { n__2 = ifn_319.Invoke_O__O(arg_320) } else { n__2 = linked_318.(*aot_arbace_classes_types.A_arbace_classes_types_array_dims_A).Invoke_O_O__O(root_317, arg_320) }
//line :236:1
		var e__3 any; var root_321 any = A_arbace_j2g_names_A_const_10.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_323 lang.IFn

		if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any = d__0; var arg_325 any = n__2; if linked_322 == nil { e__3 = ifn_323.Invoke_O_O__O(arg_324, arg_325) } else { e__3 = linked_322.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_321, arg_324, arg_325) }
		var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 any; var root_326 any = A_arbace_j2g_names_A_const_51.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, A_arbace_j2g_names_desc_code_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any = e__3; if linked_327 == nil { tmp3 = ifn_328.Invoke_O__O(arg_329) } else { tmp3 = linked_327.(*A_arbace_j2g_names_desc_code_A).Invoke_O_O__O(root_326, arg_329) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, n__2)).Ref() } else {
//line :236:1
			if lang.Util_Equiv_O_O__Z_NoInit(d__0, Lit_8) { return Lit_9 } else { var tmp4 any; var root_330 any = A_arbace_j2g_names_A_const_52.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_332 lang.IFn




				if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any = d__0; if linked_331 == nil { tmp4 = ifn_332.Invoke_O__O(arg_333) } else { tmp4 = linked_331.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_330, arg_333) }
//line :236:1
				if jrt.J2g_Truth(tmp4) {




					var root_334 any = A_arbace_j2g_names_A_const_53.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, A_arbace_j2g_names_go_class_name_A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any; var root_338 any = A_arbace_j2g_names_A_const_54.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = d__0; if linked_339 == nil { arg_337 = ifn_340.Invoke_O__O(arg_341) } else { arg_337 = linked_339.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_338, arg_341) }; if linked_335 == nil { return ifn_336.Invoke_O__O(arg_337) } else { return linked_335.(*A_arbace_j2g_names_go_class_name_A).Invoke_O_O__O(root_334, arg_337) } } else {
//line :236:1
						if A_arbace_j2g_names_A_const_14 != nil { return d__0 } else { return nil
						}
					}
			}
		}
}




func A_arbace_j2g_names_method_base_A_New() *A_arbace_j2g_names_method_base_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_method_base_A{}; t.Ctor(); return t }
//line :246:1
func (t *A_arbace_j2g_names_method_base_A) Ctor() {}
//line :246:1
func (t *A_arbace_j2g_names_method_base_A) Invoke_O_O_O__O(self, name__0, desc__1 any) any { var c__3 any = A_arbace_j2g_names_A_const_55.GetRawRoot__O(); var k__4 any = lang.Tuple_Create_O_O__IPersistentVector(name__0, desc__1); var or__1927000174__auto____5 any = jrt.NN(jrt.ConcurrentHashMap_Cast(c__3)).Get_O__O(k__4); if




	jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { var v__6 any; var root_342 any = A_arbace_j2g_names_A_const_56.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, A_arbace_j2g_names_method_base_STAR__A_fn_class); var ifn_344 lang.IFn
		if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = name__0; var arg_346 any = desc__1; if linked_343 == nil { v__6 = ifn_344.Invoke_O_O__O(arg_345, arg_346) } else { v__6 = linked_343.(*A_arbace_j2g_names_method_base_STAR__A).Invoke_O_O_O__O(root_342, arg_345, arg_346) }
		jrt.NN(jrt.ConcurrentHashMap_Cast(c__3)).Put_O_O__O(k__4, v__6)
//line :251:1
		return v__6 } }




func A_arbace_j2g_names_method_base_STAR__A_New() *A_arbace_j2g_names_method_base_STAR__A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_method_base_STAR__A{}; t.Ctor(); return t }
//line :256:1
func (t *A_arbace_j2g_names_method_base_STAR__A) Ctor() {}
//line :256:1
func (t *A_arbace_j2g_names_method_base_STAR__A) Invoke_O_O_O__O(self, name__0, desc__1 any) any { var vec__1768000042__3 any; var root_347 any = A_arbace_j2g_names_A_const_57.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_349 lang.IFn; if
													linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any = desc__1; if linked_348 == nil { vec__1768000042__3 = ifn_349.Invoke_O__O(arg_350) } else { vec__1768000042__3 = linked_348.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_347, arg_350) }; var ps__4 any = /*line :256:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1768000042__3, lang.RT_IntCast_J__I_NoInit(0), nil); var r__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1768000042__3, lang.RT_IntCast_J__I_NoInit(1), nil); var m__6 any; var root_351 any = A_arbace_j2g_names_A_const_58.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_351, A_arbace_j2g_names_capitalize_A_fn_class); var ifn_353 lang.IFn; if

	linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; var arg_354 any; var root_355 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_355, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_357 lang.IFn; if linked_356 == nil { ifn_357 = lang.IFn_Cast(root_355) } else { ifn_357 = nil }; var arg_358 any = name__0; if linked_356 == nil { arg_354 = ifn_357.Invoke_O__O(arg_358) } else { arg_354 = linked_356.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_355, arg_358) }; if linked_352 == nil { m__6 = ifn_353.Invoke_O__O(arg_354) } else { m__6 = linked_352.(*A_arbace_j2g_names_capitalize_A).Invoke_O_O__O(root_351, arg_354) }; var m__7 any; var tmp1 any; var root_359 any = /*line :256:1*/A_arbace_j2g_names_A_const_12.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_361 lang.IFn; if


	linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = m__6; var arg_363 any = Lit_7; if linked_360 == nil { tmp1 = ifn_361.Invoke_O_O__O(arg_362, arg_363) } else { tmp1 = linked_360.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_359, arg_362, arg_363) }; if jrt.J2g_Truth(tmp1) { m__7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, m__6)).Ref() } else { m__7 = m__6 }; var tmp2 /*line :260:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_24, nil); var tmp3 any; var root_364 any = A_arbace_j2g_names_A_const_25.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_364, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_366 lang.IFn; if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var arg_368 any; var root_369 any = A_arbace_j2g_names_A_const_26.GetRawRoot__O(); var linked_370 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_369, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_371 lang.IFn; if linked_370 == nil { ifn_371 = lang.IFn_Cast(root_369) } else { ifn_371 = nil }; var arg_372 any; var tmp4 any = A_arbace_j2g_names_method_base_STAR__fn__1768000045_A_New(); var tmp5 *jrt.Class; var fncls__378 *jrt.Class = A_arbace_j2g_names_method_base_STAR__fn__1768000045_A_fn_class; if fncls__378 == nil { var fncls__378d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_j2g_names_method_base_STAR__fn__1768000045_A_fn_class = fncls__378d; tmp5 = fncls__378d } else { tmp5 = fncls__378 }; arg_372 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_373 any = ps__4; if linked_370 == nil { arg_368 = ifn_371.Invoke_O_O__O(arg_372, arg_373) } else { arg_368 = linked_370.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_369, arg_372, arg_373) }; if linked_365 == nil { tmp3 = ifn_366.Invoke_O_O__O(arg_367, arg_368) } else { tmp3 = linked_365.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_364, arg_367, arg_368) }; var tmp6 any = tmp3; var tmp7 any; var root_379 any = A_arbace_j2g_names_A_const_51.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_379, A_arbace_j2g_names_desc_code_A_fn_class); var ifn_381 lang.IFn; if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = r__5; if linked_380 == nil { tmp7 = ifn_381.Invoke_O__O(arg_382) } else { tmp7 = linked_380.(*A_arbace_j2g_names_desc_code_A).Invoke_O_O__O(root_379, arg_382) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, m__7, tmp6, nil, tmp7)).Ref() }
//line :260:1
func A_arbace_j2g_names_method_base_STAR__fn__1768000045_A_New() *A_arbace_j2g_names_method_base_STAR__fn__1768000045_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_method_base_STAR__fn__1768000045_A{}; t.Ctor(); return t }
//line :260:1
func (t *A_arbace_j2g_names_method_base_STAR__fn__1768000045_A) Ctor() {}
//line :260:1
func (t *A_arbace_j2g_names_method_base_STAR__fn__1768000045_A) Invoke_O_O__O(self, p1__1768000041_SHARP___1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_7, nil); var tmp2 any; var root_374 any = A_arbace_j2g_names_A_const_51.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, A_arbace_j2g_names_desc_code_A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = p1__1768000041_SHARP___1; if linked_375 == nil { tmp2 = ifn_376.Invoke_O__O(arg_377) } else { tmp2 = linked_375.(*A_arbace_j2g_names_desc_code_A).Invoke_O_O__O(root_374, arg_377) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_names_ctor_base_A_New() *A_arbace_j2g_names_ctor_base_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_ctor_base_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_j2g_names_ctor_base_A) Ctor() {}
//line :262:1
func (t *A_arbace_j2g_names_ctor_base_A) Invoke_O_O__O(self, desc__0 any) any { var vec__1768000049__2 any; var root_383 any = A_arbace_j2g_names_A_const_57.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_385 lang.IFn; if



	linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any = desc__0; if linked_384 == nil { vec__1768000049__2 = ifn_385.Invoke_O__O(arg_386) } else { vec__1768000049__2 = linked_384.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_383, arg_386) }; var ps__3 any = /*line :262:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1768000049__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1768000049__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_5, nil); var tmp2 any; var root_387 any = A_arbace_j2g_names_A_const_25.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_389 lang.IFn; _ = ___4; if




	linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var arg_391 any; var root_392 any = A_arbace_j2g_names_A_const_26.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_394 lang.IFn; if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any; var tmp3 any = A_arbace_j2g_names_ctor_base_fn__1768000052_A_New(); var tmp4 *jrt.Class; var fncls__401 *jrt.Class = A_arbace_j2g_names_ctor_base_fn__1768000052_A_fn_class; if fncls__401 == nil { var fncls__401d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_j2g_names_ctor_base_fn__1768000052_A_fn_class = fncls__401d; tmp4 = fncls__401d } else { tmp4 = fncls__401 }; arg_395 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_396 any = ps__3; if linked_393 == nil { arg_391 = ifn_394.Invoke_O_O__O(arg_395, arg_396) } else { arg_391 = linked_393.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_392, arg_395, arg_396) }; if linked_388 == nil { tmp2 = ifn_389.Invoke_O_O__O(arg_390, arg_391) } else { tmp2 = linked_388.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_387, arg_390, arg_391) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }
//line :267:1
func A_arbace_j2g_names_ctor_base_fn__1768000052_A_New() *A_arbace_j2g_names_ctor_base_fn__1768000052_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_ctor_base_fn__1768000052_A{}; t.Ctor(); return t }
//line :267:1
func (t *A_arbace_j2g_names_ctor_base_fn__1768000052_A) Ctor() {}
//line :267:1
func (t *A_arbace_j2g_names_ctor_base_fn__1768000052_A) Invoke_O_O__O(self, p1__1768000048_SHARP___1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_7, nil); var tmp2 any; var root_397 any = A_arbace_j2g_names_A_const_51.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, A_arbace_j2g_names_desc_code_A_fn_class); var ifn_399 lang.IFn; if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = p1__1768000048_SHARP___1; if linked_398 == nil { tmp2 = ifn_399.Invoke_O__O(arg_400) } else { tmp2 = linked_398.(*A_arbace_j2g_names_desc_code_A).Invoke_O_O__O(root_397, arg_400) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_names_new_name_A_New() *A_arbace_j2g_names_new_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_new_name_A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_j2g_names_new_name_A) Ctor() {}
//line :269:1
func (t *A_arbace_j2g_names_new_name_A) Invoke_O_O_O__O(self, cls_go__0, desc__1 any) any { var vec__1768000056__3 any; var root_402 any = A_arbace_j2g_names_A_const_57.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_404 lang.IFn; if


	linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any = desc__1; if linked_403 == nil { vec__1768000056__3 = ifn_404.Invoke_O__O(arg_405) } else { vec__1768000056__3 = linked_403.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_402, arg_405) }; var ps__4 any = /*line :269:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1768000056__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1768000056__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_26, nil); var tmp2 any; var root_406 any = A_arbace_j2g_names_A_const_25.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_406, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_408 lang.IFn; _ = ___5; if



	linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = A_arbace_j2g_names_A_const_23.GetRawRoot__O(); var arg_410 any; var root_411 any = A_arbace_j2g_names_A_const_26.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_411, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_413 lang.IFn; if linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any; var tmp3 any = A_arbace_j2g_names_new_name_fn__1768000059_A_New(); var tmp4 *jrt.Class; var fncls__420 *jrt.Class = A_arbace_j2g_names_new_name_fn__1768000059_A_fn_class; if fncls__420 == nil { var fncls__420d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_j2g_names_new_name_fn__1768000059_A_fn_class = fncls__420d; tmp4 = fncls__420d } else { tmp4 = fncls__420 }; arg_414 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_415 any = ps__4; if linked_412 == nil { arg_410 = ifn_413.Invoke_O_O__O(arg_414, arg_415) } else { arg_410 = linked_412.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_411, arg_414, arg_415) }; if linked_407 == nil { tmp2 = ifn_408.Invoke_O_O__O(arg_409, arg_410) } else { tmp2 = linked_407.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_406, arg_409, arg_410) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, cls_go__0, nil, tmp2)).Ref() }
//line :273:1
func A_arbace_j2g_names_new_name_fn__1768000059_A_New() *A_arbace_j2g_names_new_name_fn__1768000059_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_new_name_fn__1768000059_A{}; t.Ctor(); return t }
//line :273:1
func (t *A_arbace_j2g_names_new_name_fn__1768000059_A) Ctor() {}
//line :273:1
func (t *A_arbace_j2g_names_new_name_fn__1768000059_A) Invoke_O_O__O(self, p1__1768000055_SHARP___1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_7, nil); var tmp2 any; var root_416 any = A_arbace_j2g_names_A_const_51.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, A_arbace_j2g_names_desc_code_A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = p1__1768000055_SHARP___1; if linked_417 == nil { tmp2 = ifn_418.Invoke_O__O(arg_419) } else { tmp2 = linked_417.(*A_arbace_j2g_names_desc_code_A).Invoke_O_O__O(root_416, arg_419) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_names_field_name_A_New() *A_arbace_j2g_names_field_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_field_name_A{}; t.Ctor(); return t }
//line :275:1
func (t *A_arbace_j2g_names_field_name_A) Ctor() {}
//line :275:1
func (t *A_arbace_j2g_names_field_name_A) Invoke_O_O__O(self, fname__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_10, nil); var tmp2 any; var root_421 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_423 lang.IFn; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = fname__0; if linked_422 == nil { tmp2 = ifn_423.Invoke_O__O(arg_424) } else { tmp2 = linked_422.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_421, arg_424) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }







func A_arbace_j2g_names_reserved_member_A_New() *A_arbace_j2g_names_reserved_member_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_reserved_member_A{}; t.Ctor(); return t }
//line :283:1
func (t *A_arbace_j2g_names_reserved_member_A) Ctor() {}
//line :283:1
func (t *A_arbace_j2g_names_reserved_member_A) Invoke_O_O__O(self, s__0 any) any {






	var tmp1 any; var root_425 any = A_arbace_j2g_names_A_const_34.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = A_arbace_j2g_names_A_const_59.GetRawRoot__O(); var arg_429 any; var root_430 any = A_arbace_j2g_names_A_const_22.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = s__0; var arg_434 any = A_arbace_j2g_names_A_const_60; var arg_435 any = Lit_42; if linked_431 == nil { arg_429 = ifn_432.Invoke_O_O_O__O(arg_433, arg_434, arg_435) } else { arg_429 = linked_431.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_430, arg_433, arg_434, arg_435) }; if linked_426 == nil { tmp1 = ifn_427.Invoke_O_O__O(arg_428, arg_429) } else { tmp1 = linked_426.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_425, arg_428, arg_429) }; if jrt.J2g_Truth(tmp1) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_43), jrt.RefArrayOf(jrt.Object_class, s__0, nil)).Ref() } else { return s__0
	} }
func A_arbace_j2g_names_static_field_name_A_New() *A_arbace_j2g_names_static_field_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_static_field_name_A{}; t.Ctor(); return t }
//line :292:1
func (t *A_arbace_j2g_names_static_field_name_A) Ctor() {}
//line :292:1
func (t *A_arbace_j2g_names_static_field_name_A) Invoke_O_O_O__O(self, cls_go__0, fname__1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_7, nil); var tmp2 any; var root_436 any = A_arbace_j2g_names_A_const_61.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_436, A_arbace_j2g_names_reserved_member_A_fn_class); var ifn_438 lang.IFn; if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any; var root_440 any = A_arbace_j2g_names_A_const_29.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_440, A_arbace_j2g_names_munge_name_A_fn_class); var ifn_442 lang.IFn; if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = fname__1; if linked_441 == nil { arg_439 = ifn_442.Invoke_O__O(arg_443) } else { arg_439 = linked_441.(*A_arbace_j2g_names_munge_name_A).Invoke_O_O__O(root_440, arg_443) }; if linked_437 == nil { tmp2 = ifn_438.Invoke_O__O(arg_439) } else { tmp2 = linked_437.(*A_arbace_j2g_names_reserved_member_A).Invoke_O_O__O(root_436, arg_439) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, cls_go__0, nil, tmp2)).Ref() }

func A_arbace_j2g_names_static_method_name_A_New() *A_arbace_j2g_names_static_method_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_static_method_name_A{}; t.Ctor(); return t }
//line :294:1
func (t *A_arbace_j2g_names_static_method_name_A) Ctor() {}
//line :294:1
func (t *A_arbace_j2g_names_static_method_name_A) Invoke_O_O_O_O__O(self, cls_go__0, name__1, desc__2 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_7, nil); var tmp2 any; var root_444 any = A_arbace_j2g_names_A_const_62.GetRawRoot__O(); var linked_445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_444, A_arbace_j2g_names_method_base_A_fn_class); var ifn_446 lang.IFn; if linked_445 == nil { ifn_446 = lang.IFn_Cast(root_444) } else { ifn_446 = nil }; var arg_447 any = name__1; var arg_448 any = desc__2; if linked_445 == nil { tmp2 = ifn_446.Invoke_O_O__O(arg_447, arg_448) } else { tmp2 = linked_445.(*A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_444, arg_447, arg_448) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, cls_go__0, nil, tmp2)).Ref() }

func A_arbace_j2g_names_impl_name_A_New() *A_arbace_j2g_names_impl_name_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_impl_name_A{}; t.Ctor(); return t }
//line :296:1
func (t *A_arbace_j2g_names_impl_name_A) Ctor() {}
//line :296:1
func (t *A_arbace_j2g_names_impl_name_A) Invoke_O_O__O(self, mbase__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_20, nil), jrt.RefArrayOf(jrt.Object_class, nil, mbase__0)).Ref() }



























type A_arbace_j2g_names_A struct{ jrt.Object }

var A_arbace_j2g_names_A_const_pool *jrt.RefArray

var A_arbace_j2g_names_A_const_0 *lang.Var

var A_arbace_j2g_names_A_const_1 any

var A_arbace_j2g_names_A_const_2 any

var A_arbace_j2g_names_A_const_3 *lang.Var

var A_arbace_j2g_names_A_const_4 any

var A_arbace_j2g_names_A_const_5 *lang.Var

var A_arbace_j2g_names_A_const_6 *lang.Var

var A_arbace_j2g_names_A_const_7 *lang.Var

var A_arbace_j2g_names_A_const_8 *lang.Var

var A_arbace_j2g_names_A_const_9 any

var A_arbace_j2g_names_A_const_10 *lang.Var

var A_arbace_j2g_names_A_const_11 any

var A_arbace_j2g_names_A_const_12 *lang.Var

var A_arbace_j2g_names_A_const_13 *lang.Keyword

var A_arbace_j2g_names_A_const_14 *lang.Keyword

var A_arbace_j2g_names_A_const_15 *lang.Var

var A_arbace_j2g_names_A_const_16 *lang.Var

var A_arbace_j2g_names_A_const_17 *lang.Var

var A_arbace_j2g_names_A_const_18 *lang.Keyword

var A_arbace_j2g_names_A_const_19 *lang.Var

var A_arbace_j2g_names_A_const_20 any

var A_arbace_j2g_names_A_const_21 *lang.Var

var A_arbace_j2g_names_A_const_22 *lang.Var

var A_arbace_j2g_names_A_const_23 *lang.Var

var A_arbace_j2g_names_A_const_24 *lang.Var

var A_arbace_j2g_names_A_const_25 *lang.Var

var A_arbace_j2g_names_A_const_26 *lang.Var

var A_arbace_j2g_names_A_const_27 any

var A_arbace_j2g_names_A_const_28 *lang.Var

var A_arbace_j2g_names_A_const_29 *lang.Var

var A_arbace_j2g_names_A_const_30 *lang.Var

var A_arbace_j2g_names_A_const_31 *lang.Var

var A_arbace_j2g_names_A_const_32 *lang.Var

var A_arbace_j2g_names_A_const_33 *lang.Var

var A_arbace_j2g_names_A_const_34 *lang.Var

var A_arbace_j2g_names_A_const_35 any

var A_arbace_j2g_names_A_const_36 any

var A_arbace_j2g_names_A_const_37 *lang.Var

var A_arbace_j2g_names_A_const_38 *lang.Var

var A_arbace_j2g_names_A_const_39 *lang.Var

var A_arbace_j2g_names_A_const_40 *lang.Var

var A_arbace_j2g_names_A_const_41 *lang.Var

var A_arbace_j2g_names_A_const_42 *lang.Var

var A_arbace_j2g_names_A_const_43 *lang.Var

var A_arbace_j2g_names_A_const_44 *lang.Var

var A_arbace_j2g_names_A_const_45 *lang.Var

var A_arbace_j2g_names_A_const_46 *lang.Var

var A_arbace_j2g_names_A_const_47 *lang.Var

var A_arbace_j2g_names_A_const_48 any

var A_arbace_j2g_names_A_const_49 *lang.Var

var A_arbace_j2g_names_A_const_50 *lang.Var

var A_arbace_j2g_names_A_const_51 *lang.Var

var A_arbace_j2g_names_A_const_52 *lang.Var

var A_arbace_j2g_names_A_const_53 *lang.Var

var A_arbace_j2g_names_A_const_54 *lang.Var

var A_arbace_j2g_names_A_const_55 *lang.Var

var A_arbace_j2g_names_A_const_56 *lang.Var

var A_arbace_j2g_names_A_const_57 *lang.Var

var A_arbace_j2g_names_A_const_58 *lang.Var

var A_arbace_j2g_names_A_const_59 *lang.Var

var A_arbace_j2g_names_A_const_60 any

var A_arbace_j2g_names_A_const_61 *lang.Var

var A_arbace_j2g_names_A_const_62 *lang.Var

var A_arbace_j2g_names_A_init jrt.ClassInit

func A_arbace_j2g_names_A_Init() { if !A_arbace_j2g_names_A_init.Done() { A_arbace_j2g_names_A_init.Run(A_arbace_j2g_names_A_clinit) } }

func A_arbace_j2g_names_A_clinit() { A_arbace_j2g_names_A_clinit_p0(); A_arbace_j2g_names_A_clinit_p1(); A_arbace_j2g_names_A_clinit_p2(); A_arbace_j2g_names_A_clinit_p3(); A_arbace_j2g_names_A_clinit_p4(); A_arbace_j2g_names_A_clinit_p5() }

func A_arbace_j2g_names_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_names_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 73); A_arbace_j2g_names_A_const_0 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[10]); A_arbace_j2g_names_A_const_1 = A_arbace_j2g_names_A_const_pool.A[11]; A_arbace_j2g_names_A_const_2 = A_arbace_j2g_names_A_const_pool.A[12]; A_arbace_j2g_names_A_const_3 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[13]); A_arbace_j2g_names_A_const_4 = A_arbace_j2g_names_A_const_pool.A[14]; A_arbace_j2g_names_A_const_5 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[15]); A_arbace_j2g_names_A_const_6 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[16]); A_arbace_j2g_names_A_const_7 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[17]); A_arbace_j2g_names_A_const_8 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[18]); A_arbace_j2g_names_A_const_9 = A_arbace_j2g_names_A_const_pool.A[19]; A_arbace_j2g_names_A_const_10 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[20]); A_arbace_j2g_names_A_const_11 = A_arbace_j2g_names_A_const_pool.A[21] }

func A_arbace_j2g_names_A_clinit_p1() { A_arbace_j2g_names_A_const_12 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[22]); A_arbace_j2g_names_A_const_13 = lang.Keyword_Cast(A_arbace_j2g_names_A_const_pool.A[23]); A_arbace_j2g_names_A_const_14 = lang.Keyword_Cast(A_arbace_j2g_names_A_const_pool.A[24]); A_arbace_j2g_names_A_const_15 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[25]); A_arbace_j2g_names_A_const_16 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[26]); A_arbace_j2g_names_A_const_17 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[27]); A_arbace_j2g_names_A_const_18 = lang.Keyword_Cast(A_arbace_j2g_names_A_const_pool.A[28]); A_arbace_j2g_names_A_const_19 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[29]); A_arbace_j2g_names_A_const_20 = A_arbace_j2g_names_A_const_pool.A[30]; A_arbace_j2g_names_A_const_21 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[31]); A_arbace_j2g_names_A_const_22 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[32]); A_arbace_j2g_names_A_const_23 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[33]) }

func A_arbace_j2g_names_A_clinit_p2() { A_arbace_j2g_names_A_const_24 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[34]); A_arbace_j2g_names_A_const_25 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[35]); A_arbace_j2g_names_A_const_26 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[36]); A_arbace_j2g_names_A_const_27 = A_arbace_j2g_names_A_const_pool.A[37]; A_arbace_j2g_names_A_const_28 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[38]); A_arbace_j2g_names_A_const_29 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[39]); A_arbace_j2g_names_A_const_30 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[40]); A_arbace_j2g_names_A_const_31 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[41]); A_arbace_j2g_names_A_const_32 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[42]); A_arbace_j2g_names_A_const_33 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[43]); A_arbace_j2g_names_A_const_34 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[44]); A_arbace_j2g_names_A_const_35 = A_arbace_j2g_names_A_const_pool.A[45] }

func A_arbace_j2g_names_A_clinit_p3() { A_arbace_j2g_names_A_const_36 = A_arbace_j2g_names_A_const_pool.A[46]; A_arbace_j2g_names_A_const_37 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[47]); A_arbace_j2g_names_A_const_38 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[48]); A_arbace_j2g_names_A_const_39 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[49]); A_arbace_j2g_names_A_const_40 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[50]); A_arbace_j2g_names_A_const_41 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[51]); A_arbace_j2g_names_A_const_42 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[52]); A_arbace_j2g_names_A_const_43 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[53]); A_arbace_j2g_names_A_const_44 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[54]); A_arbace_j2g_names_A_const_45 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[55]); A_arbace_j2g_names_A_const_46 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[56]); A_arbace_j2g_names_A_const_47 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[57]) }

func A_arbace_j2g_names_A_clinit_p4() { A_arbace_j2g_names_A_const_48 = A_arbace_j2g_names_A_const_pool.A[58]; A_arbace_j2g_names_A_const_49 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[59]); A_arbace_j2g_names_A_const_50 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[60]); A_arbace_j2g_names_A_const_51 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[61]); A_arbace_j2g_names_A_const_52 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[62]); A_arbace_j2g_names_A_const_53 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[63]); A_arbace_j2g_names_A_const_54 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[64]); A_arbace_j2g_names_A_const_55 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[65]); A_arbace_j2g_names_A_const_56 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[66]); A_arbace_j2g_names_A_const_57 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[67]); A_arbace_j2g_names_A_const_58 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[68]); A_arbace_j2g_names_A_const_59 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[69]) }

func A_arbace_j2g_names_A_clinit_p5() { A_arbace_j2g_names_A_const_60 = A_arbace_j2g_names_A_const_pool.A[70]; A_arbace_j2g_names_A_const_61 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[71]); A_arbace_j2g_names_A_const_62 = lang.Var_Cast(A_arbace_j2g_names_A_const_pool.A[72]) }

func A_arbace_j2g_names_A_New() *A_arbace_j2g_names_A { A_arbace_j2g_names_A_Init(); t := &A_arbace_j2g_names_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_names_A) Ctor() {}

func (t *A_arbace_j2g_names_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_names_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_names_A_class }

func (t *A_arbace_j2g_names_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_names_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_names_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_names_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_names_A); return ok }

func A_arbace_j2g_names_A_Cast(x any) *A_arbace_j2g_names_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_names_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_names_A_class)) }; return v }



type A_arbace_j2g_names_capitalize_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_capitalize_A_fn_class *jrt.Class



type A_arbace_j2g_names_compiled_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_names_compiled_class_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_names_compiled_pkg_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_names_compiled_pkg_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_names_ctor_base_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_ctor_base_A_fn_class *jrt.Class



type A_arbace_j2g_names_ctor_base_fn__1768000052_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_ctor_base_fn__1768000052_A_fn_class *jrt.Class



type A_arbace_j2g_names_desc_code_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_desc_code_A_fn_class *jrt.Class



type A_arbace_j2g_names_eval1768000004_A struct{ jrt.Object }

func A_arbace_j2g_names_eval1768000004_A_New() *A_arbace_j2g_names_eval1768000004_A { t := &A_arbace_j2g_names_eval1768000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_names_eval1768000004_A) Ctor() {}

func (t *A_arbace_j2g_names_eval1768000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_names_eval1768000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_names_eval1768000004_A_class }

func (t *A_arbace_j2g_names_eval1768000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_names_eval1768000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_names_eval1768000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_names_eval1768000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_names_eval1768000004_A); return ok }

func A_arbace_j2g_names_eval1768000004_A_Cast(x any) *A_arbace_j2g_names_eval1768000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_names_eval1768000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_names_eval1768000004_A_class)) }; return v }



type A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A_fn_class *jrt.Class



type A_arbace_j2g_names_eval1768000008_A struct{ jrt.Object }

func A_arbace_j2g_names_eval1768000008_A_New() *A_arbace_j2g_names_eval1768000008_A { t := &A_arbace_j2g_names_eval1768000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_names_eval1768000008_A) Ctor() {}

func (t *A_arbace_j2g_names_eval1768000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_names_eval1768000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_names_eval1768000008_A_class }

func (t *A_arbace_j2g_names_eval1768000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_names_eval1768000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_names_eval1768000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_names_eval1768000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_names_eval1768000008_A); return ok }

func A_arbace_j2g_names_eval1768000008_A_Cast(x any) *A_arbace_j2g_names_eval1768000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_names_eval1768000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_names_eval1768000008_A_class)) }; return v }



type A_arbace_j2g_names_eval1768000008_fn__1768000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_eval1768000008_fn__1768000009_A_fn_class *jrt.Class



type A_arbace_j2g_names_field_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_field_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_fn__1768000021_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_fn__1768000021_A_fn_class *jrt.Class



type A_arbace_j2g_names_fn__1768000021_fn__1768000022_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_fn__1768000021_fn__1768000022_A_fn_class *jrt.Class



type A_arbace_j2g_names_go_class_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_go_class_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_go_class_name_STAR__STAR__A struct{ j2g_header uint64 }

var A_arbace_j2g_names_go_class_name_STAR__STAR__A_fn_class *jrt.Class



type A_arbace_j2g_names_impl_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_impl_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_local_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_local_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_memo_str_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_memo_str_A_fn_class *jrt.Class



type A_arbace_j2g_names_memo_str_fn__1768000018_A struct{ j2g_header uint64; F_cache, F_f any }

var A_arbace_j2g_names_memo_str_fn__1768000018_A_fn_class *jrt.Class



type A_arbace_j2g_names_method_base_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_method_base_A_fn_class *jrt.Class



type A_arbace_j2g_names_method_base_STAR__A struct{ j2g_header uint64 }

var A_arbace_j2g_names_method_base_STAR__A_fn_class *jrt.Class



type A_arbace_j2g_names_method_base_STAR__fn__1768000045_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_method_base_STAR__fn__1768000045_A_fn_class *jrt.Class



type A_arbace_j2g_names_munge_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_munge_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_new_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_new_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_new_name_fn__1768000059_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_new_name_fn__1768000059_A_fn_class *jrt.Class



type A_arbace_j2g_names_pkg_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_pkg_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_pkg_ns_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_pkg_ns_A_fn_class *jrt.Class



type A_arbace_j2g_names_pkg_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_pkg_of_A_fn_class *jrt.Class



type A_arbace_j2g_names_pkg_path_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_pkg_path_A_fn_class *jrt.Class



type A_arbace_j2g_names_qualified_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_names_qualified_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A struct{ j2g_header uint64; F_internal any }

var A_arbace_j2g_names_qualified_QMARK__fn__1768000030_A_fn_class *jrt.Class



type A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A struct{ j2g_header uint64; F_internal any }

var A_arbace_j2g_names_qualified_QMARK__fn__1768000032_A_fn_class *jrt.Class



type A_arbace_j2g_names_reserved_member_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_reserved_member_A_fn_class *jrt.Class



type A_arbace_j2g_names_static_field_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_static_field_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_static_method_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_static_method_name_A_fn_class *jrt.Class



type A_arbace_j2g_names_top_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_names_top_of_A_fn_class *jrt.Class



type A_arbace_j2g_names_user_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_names_user_class_QMARK__A_fn_class *jrt.Class
