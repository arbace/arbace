//line j2g_classes.ae:1
package aot_arbace_j2g_names

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_j2g_names_capitalize_A_class, Name: "arbace.j2g.names$capitalize", Modifiers: 25, Simple: "capitalize", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_capitalize_A", Source: "names.ae", Declaring: &A_arbace_j2g_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_compiled_class_QMARK__A_class, Name: "arbace.j2g.names$compiled_class_QMARK_", Modifiers: 25, Simple: "compiled_class_QMARK_", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_compiled_class_QMARK__A", Source: "names.ae", Declaring: &A_arbace_j2g_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_compiled_pkg_QMARK__A_class, Name: "arbace.j2g.names$compiled_pkg_QMARK_", Modifiers: 25, Simple: "compiled_pkg_QMARK_", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_compiled_pkg_QMARK__A", Source: "names.ae", Declaring: &A_arbace_j2g_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_ctor_base_A_class, Name: "arbace.j2g.names$ctor_base", Modifiers: 25, Simple: "ctor_base", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A", Source: "names.ae", Declaring: &A_arbace_j2g_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_ctor_base_fn__1768000044_A_class, Name: "arbace.j2g.names$ctor_base$fn__1768000044", Modifiers: 25, Simple: "fn__1768000044", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_fn__1768000044_A", Source: "names.ae", Declaring: &A_arbace_j2g_names_ctor_base_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_desc_code_A_class, Name: "arbace.j2g.names$desc_code", Modifiers: 25, Simple: "desc_code", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_desc_code_A", Source: "names.ae", Declaring: &A_arbace_j2g_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A_class, Name: "arbace.j2g.names$eval1768000004$loading__1927001464__auto____1768000005", Modifiers: 25, Simple: "loading__1927001464__auto____1768000005", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A", Source: "names.ae", Declaring: &A_arbace_j2g_names_eval1768000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_eval1768000008_fn__1768000009_A_class, Name: "arbace.j2g.names$eval1768000008$fn__1768000009", Modifiers: 25, Simple: "fn__1768000009", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_eval1768000008_fn__1768000009_A", Source: "names.ae", Declaring: &A_arbace_j2g_names_eval1768000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_field_name_A_class, Name: "arbace.j2g.names$field_name", Modifiers: 25, Simple: "field_name", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_field_name_A", Source: "names.ae", Declaring: &A_arbace_j2g_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_fn__1768000021_A_class, Name: "arbace.j2g.names$fn__1768000021", Modifiers: 25, Simple: "fn__1768000021", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_fn__1768000021_A", Source: "names.ae", Declaring: &A_arbace_j2g_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_fn__1768000021_fn__1768000022_A_class, Name: "arbace.j2g.names$fn__1768000021$fn__1768000022", Modifiers: 25, Simple: "fn__1768000022", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_fn__1768000021_fn__1768000022_A", Source: "names.ae", Declaring: &A_arbace_j2g_names_fn__1768000021_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_go_class_name_A_class, Name: "arbace.j2g.names$go_class_name", Modifiers: 25, Simple: "go_class_name", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_go_class_name_A", Source: "names.ae", Declaring: &A_arbace_j2g_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_go_class_name_STAR__STAR__A_class, Name: "arbace.j2g.names$go_class_name_STAR__STAR_", Modifiers: 25, Simple: "go_class_name_STAR__STAR_", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_go_class_name_STAR__STAR__A", Source: "names.ae", Declaring: &A_arbace_j2g_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_impl_name_A_class, Name: "arbace.j2g.names$impl_name", Modifiers: 25, Simple: "impl_name", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_impl_name_A", Source: "names.ae", Declaring: &A_arbace_j2g_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_local_name_A_class, Name: "arbace.j2g.names$local_name", Modifiers: 25, Simple: "local_name", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_local_name_A", Source: "names.ae", Declaring: &A_arbace_j2g_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_memo_str_A_class, Name: "arbace.j2g.names$memo_str", Modifiers: 25, Simple: "memo_str", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_memo_str_A", Source: "names.ae", Declaring: &A_arbace_j2g_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_memo_str_fn__1768000018_A_class, Name: "arbace.j2g.names$memo_str$fn__1768000018", Modifiers: 25, Simple: "fn__1768000018", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_memo_str_fn__1768000018_A", Source: "names.ae", Declaring: &A_arbace_j2g_names_memo_str_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_method_base_A_class, Name: "arbace.j2g.names$method_base", Modifiers: 25, Simple: "method_base", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A", Source: "names.ae", Declaring: &A_arbace_j2g_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_method_base_STAR__A_class, Name: "arbace.j2g.names$method_base_STAR_", Modifiers: 25, Simple: "method_base_STAR_", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_method_base_STAR__A", Source: "names.ae", Declaring: &A_arbace_j2g_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_method_base_STAR__fn__1768000037_A_class, Name: "arbace.j2g.names$method_base_STAR_$fn__1768000037", Modifiers: 25, Simple: "fn__1768000037", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_method_base_STAR__fn__1768000037_A", Source: "names.ae", Declaring: &A_arbace_j2g_names_method_base_STAR__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_munge_name_A_class, Name: "arbace.j2g.names$munge_name", Modifiers: 25, Simple: "munge_name", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_munge_name_A", Source: "names.ae", Declaring: &A_arbace_j2g_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_new_name_A_class, Name: "arbace.j2g.names$new_name", Modifiers: 25, Simple: "new_name", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_new_name_A", Source: "names.ae", Declaring: &A_arbace_j2g_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_new_name_fn__1768000051_A_class, Name: "arbace.j2g.names$new_name$fn__1768000051", Modifiers: 25, Simple: "fn__1768000051", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_new_name_fn__1768000051_A", Source: "names.ae", Declaring: &A_arbace_j2g_names_new_name_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_pkg_name_A_class, Name: "arbace.j2g.names$pkg_name", Modifiers: 25, Simple: "pkg_name", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_pkg_name_A", Source: "names.ae", Declaring: &A_arbace_j2g_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_pkg_ns_A_class, Name: "arbace.j2g.names$pkg_ns", Modifiers: 25, Simple: "pkg_ns", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_pkg_ns_A", Source: "names.ae", Declaring: &A_arbace_j2g_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_pkg_of_A_class, Name: "arbace.j2g.names$pkg_of", Modifiers: 25, Simple: "pkg_of", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_pkg_of_A", Source: "names.ae", Declaring: &A_arbace_j2g_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_pkg_path_A_class, Name: "arbace.j2g.names$pkg_path", Modifiers: 25, Simple: "pkg_path", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_pkg_path_A", Source: "names.ae", Declaring: &A_arbace_j2g_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_static_field_name_A_class, Name: "arbace.j2g.names$static_field_name", Modifiers: 25, Simple: "static_field_name", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_static_field_name_A", Source: "names.ae", Declaring: &A_arbace_j2g_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_static_method_name_A_class, Name: "arbace.j2g.names$static_method_name", Modifiers: 25, Simple: "static_method_name", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_static_method_name_A", Source: "names.ae", Declaring: &A_arbace_j2g_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_names_top_of_A_class, Name: "arbace.j2g.names$top_of", Modifiers: 25, Simple: "top_of", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_top_of_A", Source: "names.ae", Declaring: &A_arbace_j2g_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_j2g_names_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_names_A_New()}; return nil }

var A_arbace_j2g_names_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_names_A_new}

var A_arbace_j2g_names_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.names", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_A"})

func init() { i := A_arbace_j2g_names_A_class.Info(); i.IsInstance = A_arbace_j2g_names_A_InstanceOf; i.Init = A_arbace_j2g_names_A_Init; i.Table = A_arbace_j2g_names_A_members }

var A_arbace_j2g_names_capitalize_A_class *jrt.Class

var A_arbace_j2g_names_compiled_class_QMARK__A_class *jrt.Class

var A_arbace_j2g_names_compiled_pkg_QMARK__A_class *jrt.Class

var A_arbace_j2g_names_ctor_base_A_class *jrt.Class

var A_arbace_j2g_names_ctor_base_fn__1768000044_A_class *jrt.Class

var A_arbace_j2g_names_desc_code_A_class *jrt.Class

func A_arbace_j2g_names_eval1768000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_names_eval1768000004_A_New()}; return nil }

var A_arbace_j2g_names_eval1768000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_names_eval1768000004_A_new}

var A_arbace_j2g_names_eval1768000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.names$eval1768000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_j2g_names_A_class, Simple: "eval1768000004", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_eval1768000004_A"})

func init() { i := A_arbace_j2g_names_eval1768000004_A_class.Info(); i.IsInstance = A_arbace_j2g_names_eval1768000004_A_InstanceOf; i.Table = A_arbace_j2g_names_eval1768000004_A_members }

var A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A_class *jrt.Class

func A_arbace_j2g_names_eval1768000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_names_eval1768000008_A_New()}; return nil }

var A_arbace_j2g_names_eval1768000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_names_eval1768000008_A_new}

var A_arbace_j2g_names_eval1768000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.names$eval1768000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_j2g_names_A_class, Simple: "eval1768000008", Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names_eval1768000008_A"})

func init() { i := A_arbace_j2g_names_eval1768000008_A_class.Info(); i.IsInstance = A_arbace_j2g_names_eval1768000008_A_InstanceOf; i.Table = A_arbace_j2g_names_eval1768000008_A_members }

var A_arbace_j2g_names_eval1768000008_fn__1768000009_A_class *jrt.Class

var A_arbace_j2g_names_field_name_A_class *jrt.Class

var A_arbace_j2g_names_fn__1768000021_A_class *jrt.Class

var A_arbace_j2g_names_fn__1768000021_fn__1768000022_A_class *jrt.Class

var A_arbace_j2g_names_go_class_name_A_class *jrt.Class

var A_arbace_j2g_names_go_class_name_STAR__STAR__A_class *jrt.Class

var A_arbace_j2g_names_impl_name_A_class *jrt.Class

var A_arbace_j2g_names_local_name_A_class *jrt.Class

var A_arbace_j2g_names_memo_str_A_class *jrt.Class

var A_arbace_j2g_names_memo_str_fn__1768000018_A_class *jrt.Class

var A_arbace_j2g_names_method_base_A_class *jrt.Class

var A_arbace_j2g_names_method_base_STAR__A_class *jrt.Class

var A_arbace_j2g_names_method_base_STAR__fn__1768000037_A_class *jrt.Class

var A_arbace_j2g_names_munge_name_A_class *jrt.Class

var A_arbace_j2g_names_new_name_A_class *jrt.Class

var A_arbace_j2g_names_new_name_fn__1768000051_A_class *jrt.Class

var A_arbace_j2g_names_pkg_name_A_class *jrt.Class

var A_arbace_j2g_names_pkg_ns_A_class *jrt.Class

var A_arbace_j2g_names_pkg_of_A_class *jrt.Class

var A_arbace_j2g_names_pkg_path_A_class *jrt.Class

var A_arbace_j2g_names_static_field_name_A_class *jrt.Class

var A_arbace_j2g_names_static_method_name_A_class *jrt.Class

var A_arbace_j2g_names_top_of_A_class *jrt.Class

func A_arbace_j2g_names__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_j2g_names__init_A_Load__O()}; return nil }

func A_arbace_j2g_names__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_names__init_A_New()}; return nil }

var A_arbace_j2g_names__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_j2g_names__init_A_invoke, New: A_arbace_j2g_names__init_A_new}

var A_arbace_j2g_names__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.names__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_j2g_names.A_arbace_j2g_names__init_A", Source: "names.ae"})

func init() { i := A_arbace_j2g_names__init_A_class.Info(); i.IsInstance = A_arbace_j2g_names__init_A_InstanceOf; i.Init = A_arbace_j2g_names__init_A_Init; i.Table = A_arbace_j2g_names__init_A_members }
