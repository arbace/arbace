//line aot_arbace_j2g_names__init.ae:1
package aot_arbace_j2g_names

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_names__init_A_Unit0__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_j2g_names__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_names__init_A_const_1) }
//line :1:1
func A_arbace_j2g_names__init_A_Unit1__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_j2g_names__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_2)) }
//line :1:1
func A_arbace_j2g_names__init_A_Unit2__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, nil); A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_j2g_names__init_A_Unit3__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_j2g_names__init_A_const_1)).Equals_O__Z(A_arbace_j2g_names__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_j2g_names_eval1768000008_fn__1768000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_j2g_names_eval1768000008_fn__1768000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, nil); A_arbace_j2g_names_eval1768000008_fn__1768000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_j2g_names__init_A_Load__O() any { A_arbace_j2g_names__init_A_Init(); jrt.StartCheck(); A_arbace_j2g_names__init_A_Unit0__O(); A_arbace_j2g_names__init_A_Unit1__O(); A_arbace_j2g_names__init_A_Unit2__O(); A_arbace_j2g_names__init_A_Unit3__O(); A_arbace_j2g_names__init_A_Unit4__O(); A_arbace_j2g_names__init_A_Unit5__O(); A_arbace_j2g_names__init_A_Unit6__O(); A_arbace_j2g_names__init_A_Unit7__O(); A_arbace_j2g_names__init_A_Unit8__O(); A_arbace_j2g_names__init_A_Unit9__O(); A_arbace_j2g_names__init_A_Unit10__O(); A_arbace_j2g_names__init_A_Unit11__O(); A_arbace_j2g_names__init_A_Unit12__O(); A_arbace_j2g_names__init_A_Unit13__O(); A_arbace_j2g_names__init_A_Unit14__O(); A_arbace_j2g_names__init_A_Unit15__O(); A_arbace_j2g_names__init_A_Unit16__O(); A_arbace_j2g_names__init_A_Unit17__O(); A_arbace_j2g_names__init_A_Unit18__O(); A_arbace_j2g_names__init_A_Unit19__O(); A_arbace_j2g_names__init_A_Unit20__O(); A_arbace_j2g_names__init_A_Unit21__O(); A_arbace_j2g_names__init_A_Unit22__O(); A_arbace_j2g_names__init_A_Unit23__O(); A_arbace_j2g_names__init_A_Unit24__O(); A_arbace_j2g_names__init_A_Unit25__O(); A_arbace_j2g_names__init_A_Unit26__O(); A_arbace_j2g_names__init_A_Unit27__O(); A_arbace_j2g_names__init_A_Unit28__O(); A_arbace_j2g_names__init_A_Unit29__O(); A_arbace_j2g_names__init_A_Unit30__O(); A_arbace_j2g_names__init_A_Unit31__O(); A_arbace_j2g_names__init_A_Unit32__O(); A_arbace_j2g_names__init_A_Unit33__O(); A_arbace_j2g_names__init_A_Unit34__O(); A_arbace_j2g_names__init_A_Unit35__O(); A_arbace_j2g_names__init_A_Unit36__O(); A_arbace_j2g_names__init_A_Unit37__O(); A_arbace_j2g_names__init_A_Unit38__O(); A_arbace_j2g_names__init_A_Unit39__O(); A_arbace_j2g_names__init_A_Unit40__O(); A_arbace_j2g_names__init_A_Unit41__O(); A_arbace_j2g_names__init_A_Unit42__O(); return nil }





func A_arbace_j2g_names__init_A_Unit4__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(11, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_4; var tmp2 any; var root_5 any = A_arbace_j2g_names__init_A_const_5.GetRawRoot__O(); var linked_6 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_5, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_7 lang.IFn; if



	linked_6 == nil { ifn_7 = lang.IFn_Cast(root_5) } else { ifn_7 = nil }; var arg_8 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_6 == nil { tmp2 = ifn_7.Invoke_O__O(arg_8) } else { tmp2 = linked_6.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_5, arg_8) }; /*line :11:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_j2g_names__init_A_const_4; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_6)); return A_arbace_j2g_names__init_A_const_4 }





func A_arbace_j2g_names__init_A_Unit5__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_7; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_j2g_names_top_of_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_j2g_names_top_of_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, nil); A_arbace_j2g_names_top_of_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_7; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_8)); return A_arbace_j2g_names__init_A_const_7 }

func A_arbace_j2g_names__init_A_Unit6__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(19, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_9; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_j2g_names_pkg_of_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_j2g_names_pkg_of_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, nil); A_arbace_j2g_names_pkg_of_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_10)); return A_arbace_j2g_names__init_A_const_9 }
















func A_arbace_j2g_names__init_A_Unit7__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(36, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_11; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_j2g_names_compiled_pkg_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_j2g_names_compiled_pkg_QMARK__A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, nil); A_arbace_j2g_names_compiled_pkg_QMARK__A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_12)); return A_arbace_j2g_names__init_A_const_11 }

func A_arbace_j2g_names__init_A_Unit8__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_13; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_j2g_names_pkg_name_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_j2g_names_pkg_name_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, nil); A_arbace_j2g_names_pkg_name_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_14)); return A_arbace_j2g_names__init_A_const_13 }
func A_arbace_j2g_names__init_A_Unit9__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(39, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_15; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_j2g_names_pkg_path_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_j2g_names_pkg_path_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_51, false, nil); A_arbace_j2g_names_pkg_path_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_16)); return A_arbace_j2g_names__init_A_const_15 }
func A_arbace_j2g_names__init_A_Unit10__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(40, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_17; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_j2g_names_pkg_ns_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_j2g_names_pkg_ns_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_52, false, nil); A_arbace_j2g_names_pkg_ns_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_18)); return A_arbace_j2g_names__init_A_const_17 }




func A_arbace_j2g_names__init_A_Unit11__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(45, 1); A_arbace_j2g_names__init_A_const_19.BindRoot_O__V(A_arbace_j2g_names__init_A_const_20); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_19; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_21)); return A_arbace_j2g_names__init_A_const_19 }




func A_arbace_j2g_names__init_A_Unit12__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(50, 1); A_arbace_j2g_names__init_A_const_22.BindRoot_O__V(A_arbace_j2g_names__init_A_const_23); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_22; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_24)); return A_arbace_j2g_names__init_A_const_22 }





func A_arbace_j2g_names__init_A_Unit13__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(56, 1); A_arbace_j2g_names__init_A_const_25.BindRoot_O__V(A_arbace_j2g_names__init_A_const_26); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_25; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_27)); return A_arbace_j2g_names__init_A_const_25 }



func A_arbace_j2g_names__init_A_Unit14__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(60, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_28; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_j2g_names_memo_str_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_j2g_names_memo_str_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, false, nil); A_arbace_j2g_names_memo_str_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_29)); return A_arbace_j2g_names__init_A_const_28 }










func A_arbace_j2g_names__init_A_Unit15__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(71, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_30; var tmp2 any; var root_23 any = A_arbace_j2g_names__init_A_const_28.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, A_arbace_j2g_names_memo_str_A_fn_class); var ifn_25 lang.IFn; if
						linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any; var fnbody__28 any = A_arbace_j2g_names_fn__1768000021_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_j2g_names_fn__1768000021_A_fn_class; if
						fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, nil); A_arbace_j2g_names_fn__1768000021_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; arg_26 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); if /*line :72:1*/ linked_24 == nil { tmp2 = ifn_25.Invoke_O__O(arg_26) } else { tmp2 = linked_24.(*A_arbace_j2g_names_memo_str_A).Invoke_O_O__O(root_23, arg_26) }; /*line :71:1*/tmp1.BindRoot_O__V(tmp2); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_31)); return A_arbace_j2g_names__init_A_const_30 }







func A_arbace_j2g_names__init_A_Unit16__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(79, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_j2g_names_munge_name_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_j2g_names_munge_name_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, nil); A_arbace_j2g_names_munge_name_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_33)); return A_arbace_j2g_names__init_A_const_32 }




func A_arbace_j2g_names__init_A_Unit17__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(84, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_j2g_names_local_name_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_j2g_names_local_name_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, nil); A_arbace_j2g_names_local_name_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_35)); return A_arbace_j2g_names__init_A_const_34 }















func A_arbace_j2g_names__init_A_Unit18__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(100, 1); A_arbace_j2g_names__init_A_const_36.BindRoot_O__V(A_arbace_j2g_names__init_A_const_37); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_36; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_38)); return A_arbace_j2g_names__init_A_const_36 }





































func A_arbace_j2g_names__init_A_Unit19__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(138, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_39; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_j2g_names_compiled_class_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_j2g_names_compiled_class_QMARK__A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, nil); A_arbace_j2g_names_compiled_class_QMARK__A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_40)); return A_arbace_j2g_names__init_A_const_39 }










func A_arbace_j2g_names__init_A_Unit20__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(149, 1); A_arbace_j2g_names__init_A_const_41.BindRoot_O__V(A_arbace_j2g_names__init_A_const_42); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_41; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_43)); return A_arbace_j2g_names__init_A_const_41 }





















func A_arbace_j2g_names__init_A_Unit21__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(171, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_44; var tmp2 any; var root_35 any = A_arbace_j2g_names__init_A_const_5.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_37 lang.IFn; if


	linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = lang.PersistentVector_EMPTY.Ref(); if linked_36 == nil { tmp2 = ifn_37.Invoke_O__O(arg_38) } else { tmp2 = linked_36.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_35, arg_38) }; /*line :171:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_j2g_names__init_A_const_44; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_45)); return A_arbace_j2g_names__init_A_const_44 }




func A_arbace_j2g_names__init_A_Unit22__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(176, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_j2g_names_qualified_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_j2g_names_qualified_QMARK__A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, nil); A_arbace_j2g_names_qualified_QMARK__A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_47)); return A_arbace_j2g_names__init_A_const_46 }





func A_arbace_j2g_names__init_A_Unit23__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(182, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_j2g_names_user_class_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_j2g_names_user_class_QMARK__A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, nil); A_arbace_j2g_names_user_class_QMARK__A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_49)); return A_arbace_j2g_names__init_A_const_48 }









func A_arbace_j2g_names__init_A_Unit24__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(192, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_j2g_names_own_class_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_j2g_names_own_class_QMARK__A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_60, false, nil); A_arbace_j2g_names_own_class_QMARK__A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_51)); return A_arbace_j2g_names__init_A_const_50 }








func A_arbace_j2g_names__init_A_Unit25__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(201, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_52; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_53)); return A_arbace_j2g_names__init_A_const_52 }

func A_arbace_j2g_names__init_A_Unit26__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(203, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_54; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_j2g_names_go_class_name_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_j2g_names_go_class_name_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_61, false, nil); A_arbace_j2g_names_go_class_name_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_55)); return A_arbace_j2g_names__init_A_const_54 }









func A_arbace_j2g_names__init_A_Unit27__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(213, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_56; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_j2g_names_go_class_name_STAR__STAR__A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_j2g_names_go_class_name_STAR__STAR__A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_62, false, nil); A_arbace_j2g_names_go_class_name_STAR__STAR__A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_57)); return A_arbace_j2g_names__init_A_const_56 }
















func A_arbace_j2g_names__init_A_Unit28__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(230, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_52; var tmp2 any; var root_49 any = A_arbace_j2g_names__init_A_const_28.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, A_arbace_j2g_names_memo_str_A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = A_arbace_j2g_names__init_A_const_56.GetRawRoot__O(); if linked_50 == nil { tmp2 = ifn_51.Invoke_O__O(arg_52) } else { tmp2 = linked_50.(*A_arbace_j2g_names_memo_str_A).Invoke_O_O__O(root_49, arg_52) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_j2g_names__init_A_const_52; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_58)); return A_arbace_j2g_names__init_A_const_52 }

func A_arbace_j2g_names__init_A_Unit29__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(232, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_59; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_j2g_names_capitalize_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_j2g_names_capitalize_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, nil); A_arbace_j2g_names_capitalize_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_60)); return A_arbace_j2g_names__init_A_const_59 }





func A_arbace_j2g_names__init_A_Unit30__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(238, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_61; tmp1.BindRoot_O__V(jrt.ConcurrentHashMap_New()); var tmp2 *lang.Var = A_arbace_j2g_names__init_A_const_61; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_62)); return A_arbace_j2g_names__init_A_const_61 }



func A_arbace_j2g_names__init_A_Unit31__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(242, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_63; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_j2g_names_desc_code_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_j2g_names_desc_code_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_64, false, nil); A_arbace_j2g_names_desc_code_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_64)); return A_arbace_j2g_names__init_A_const_63 }










func A_arbace_j2g_names__init_A_Unit32__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(253, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_65; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_66)); return A_arbace_j2g_names__init_A_const_65 }

func A_arbace_j2g_names__init_A_Unit33__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(255, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_67; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_j2g_names_method_base_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_j2g_names_method_base_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_65, false, nil); A_arbace_j2g_names_method_base_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_68)); return A_arbace_j2g_names__init_A_const_67 }









func A_arbace_j2g_names__init_A_Unit34__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(265, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_65; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_j2g_names_method_base_STAR__A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_j2g_names_method_base_STAR__A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_66, false, nil); A_arbace_j2g_names_method_base_STAR__A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_69)); return A_arbace_j2g_names__init_A_const_65 }





func A_arbace_j2g_names__init_A_Unit35__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(271, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_70; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_j2g_names_ctor_base_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_j2g_names_ctor_base_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_67, false, nil); A_arbace_j2g_names_ctor_base_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_71)); return A_arbace_j2g_names__init_A_const_70 }






func A_arbace_j2g_names__init_A_Unit36__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(278, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_72; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_j2g_names_new_name_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_j2g_names_new_name_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, nil); A_arbace_j2g_names_new_name_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_73)); return A_arbace_j2g_names__init_A_const_72 }





func A_arbace_j2g_names__init_A_Unit37__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(284, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_74; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_j2g_names_field_name_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_j2g_names_field_name_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_69, false, nil); A_arbace_j2g_names_field_name_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_75)); return A_arbace_j2g_names__init_A_const_74 }

func A_arbace_j2g_names__init_A_Unit38__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(286, 1); A_arbace_j2g_names__init_A_const_76.BindRoot_O__V(A_arbace_j2g_names__init_A_const_77); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_76; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_78)); return A_arbace_j2g_names__init_A_const_76 }





func A_arbace_j2g_names__init_A_Unit39__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(292, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_79; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_j2g_names_reserved_member_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_j2g_names_reserved_member_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_70, false, nil); A_arbace_j2g_names_reserved_member_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_80)); return A_arbace_j2g_names__init_A_const_79 }








func A_arbace_j2g_names__init_A_Unit40__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(301, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_81; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_j2g_names_static_field_name_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_j2g_names_static_field_name_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, nil); A_arbace_j2g_names_static_field_name_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_82)); return A_arbace_j2g_names__init_A_const_81 }

func A_arbace_j2g_names__init_A_Unit41__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(303, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_83; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_j2g_names_static_method_name_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_j2g_names_static_method_name_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_72, false, nil); A_arbace_j2g_names_static_method_name_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_84)); return A_arbace_j2g_names__init_A_const_83 }

func A_arbace_j2g_names__init_A_Unit42__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(305, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_85; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_j2g_names_impl_name_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_j2g_names_impl_name_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_73, false, nil); A_arbace_j2g_names_impl_name_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_86)); return A_arbace_j2g_names__init_A_const_85 }



type A_arbace_j2g_names__init_A struct{ jrt.Object }

var A_arbace_j2g_names__init_A_const_pool *jrt.RefArray

var A_arbace_j2g_names__init_A_const_0 *lang.Var

var A_arbace_j2g_names__init_A_const_1 any

var A_arbace_j2g_names__init_A_const_2 any

var A_arbace_j2g_names__init_A_const_3 any

var A_arbace_j2g_names__init_A_const_4 *lang.Var

var A_arbace_j2g_names__init_A_const_5 *lang.Var

var A_arbace_j2g_names__init_A_const_6 any

var A_arbace_j2g_names__init_A_const_7 *lang.Var

var A_arbace_j2g_names__init_A_const_8 any

var A_arbace_j2g_names__init_A_const_9 *lang.Var

var A_arbace_j2g_names__init_A_const_10 any

var A_arbace_j2g_names__init_A_const_11 *lang.Var

var A_arbace_j2g_names__init_A_const_12 any

var A_arbace_j2g_names__init_A_const_13 *lang.Var

var A_arbace_j2g_names__init_A_const_14 any

var A_arbace_j2g_names__init_A_const_15 *lang.Var

var A_arbace_j2g_names__init_A_const_16 any

var A_arbace_j2g_names__init_A_const_17 *lang.Var

var A_arbace_j2g_names__init_A_const_18 any

var A_arbace_j2g_names__init_A_const_19 *lang.Var

var A_arbace_j2g_names__init_A_const_20 any

var A_arbace_j2g_names__init_A_const_21 any

var A_arbace_j2g_names__init_A_const_22 *lang.Var

var A_arbace_j2g_names__init_A_const_23 any

var A_arbace_j2g_names__init_A_const_24 any

var A_arbace_j2g_names__init_A_const_25 *lang.Var

var A_arbace_j2g_names__init_A_const_26 any

var A_arbace_j2g_names__init_A_const_27 any

var A_arbace_j2g_names__init_A_const_28 *lang.Var

var A_arbace_j2g_names__init_A_const_29 any

var A_arbace_j2g_names__init_A_const_30 *lang.Var

var A_arbace_j2g_names__init_A_const_31 any

var A_arbace_j2g_names__init_A_const_32 *lang.Var

var A_arbace_j2g_names__init_A_const_33 any

var A_arbace_j2g_names__init_A_const_34 *lang.Var

var A_arbace_j2g_names__init_A_const_35 any

var A_arbace_j2g_names__init_A_const_36 *lang.Var

var A_arbace_j2g_names__init_A_const_37 any

var A_arbace_j2g_names__init_A_const_38 any

var A_arbace_j2g_names__init_A_const_39 *lang.Var

var A_arbace_j2g_names__init_A_const_40 any

var A_arbace_j2g_names__init_A_const_41 *lang.Var

var A_arbace_j2g_names__init_A_const_42 any

var A_arbace_j2g_names__init_A_const_43 any

var A_arbace_j2g_names__init_A_const_44 *lang.Var

var A_arbace_j2g_names__init_A_const_45 any

var A_arbace_j2g_names__init_A_const_46 *lang.Var

var A_arbace_j2g_names__init_A_const_47 any

var A_arbace_j2g_names__init_A_const_48 *lang.Var

var A_arbace_j2g_names__init_A_const_49 any

var A_arbace_j2g_names__init_A_const_50 *lang.Var

var A_arbace_j2g_names__init_A_const_51 any

var A_arbace_j2g_names__init_A_const_52 *lang.Var

var A_arbace_j2g_names__init_A_const_53 any

var A_arbace_j2g_names__init_A_const_54 *lang.Var

var A_arbace_j2g_names__init_A_const_55 any

var A_arbace_j2g_names__init_A_const_56 *lang.Var

var A_arbace_j2g_names__init_A_const_57 any

var A_arbace_j2g_names__init_A_const_58 any

var A_arbace_j2g_names__init_A_const_59 *lang.Var

var A_arbace_j2g_names__init_A_const_60 any

var A_arbace_j2g_names__init_A_const_61 *lang.Var

var A_arbace_j2g_names__init_A_const_62 any

var A_arbace_j2g_names__init_A_const_63 *lang.Var

var A_arbace_j2g_names__init_A_const_64 any

var A_arbace_j2g_names__init_A_const_65 *lang.Var

var A_arbace_j2g_names__init_A_const_66 any

var A_arbace_j2g_names__init_A_const_67 *lang.Var

var A_arbace_j2g_names__init_A_const_68 any

var A_arbace_j2g_names__init_A_const_69 any

var A_arbace_j2g_names__init_A_const_70 *lang.Var

var A_arbace_j2g_names__init_A_const_71 any

var A_arbace_j2g_names__init_A_const_72 *lang.Var

var A_arbace_j2g_names__init_A_const_73 any

var A_arbace_j2g_names__init_A_const_74 *lang.Var

var A_arbace_j2g_names__init_A_const_75 any

var A_arbace_j2g_names__init_A_const_76 *lang.Var

var A_arbace_j2g_names__init_A_const_77 any

var A_arbace_j2g_names__init_A_const_78 any

var A_arbace_j2g_names__init_A_const_79 *lang.Var

var A_arbace_j2g_names__init_A_const_80 any

var A_arbace_j2g_names__init_A_const_81 *lang.Var

var A_arbace_j2g_names__init_A_const_82 any

var A_arbace_j2g_names__init_A_const_83 *lang.Var

var A_arbace_j2g_names__init_A_const_84 any

var A_arbace_j2g_names__init_A_const_85 *lang.Var

var A_arbace_j2g_names__init_A_const_86 any

var A_arbace_j2g_names__init_A_init jrt.ClassInit

func A_arbace_j2g_names__init_A_Init() { if !A_arbace_j2g_names__init_A_init.Done() { A_arbace_j2g_names__init_A_init.Run(A_arbace_j2g_names__init_A_clinit) } }

func A_arbace_j2g_names__init_A_clinit() { A_arbace_j2g_names__init_A_clinit_p0(); A_arbace_j2g_names__init_A_clinit_p1(); A_arbace_j2g_names__init_A_clinit_p2(); A_arbace_j2g_names__init_A_clinit_p3(); A_arbace_j2g_names__init_A_clinit_p4(); A_arbace_j2g_names__init_A_clinit_p5(); A_arbace_j2g_names__init_A_clinit_p6() }

func A_arbace_j2g_names__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_names__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_44, 108); A_arbace_j2g_names__init_A_const_0 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[21]); A_arbace_j2g_names__init_A_const_1 = A_arbace_j2g_names__init_A_const_pool.A[22]; A_arbace_j2g_names__init_A_const_2 = A_arbace_j2g_names__init_A_const_pool.A[23]; A_arbace_j2g_names__init_A_const_3 = A_arbace_j2g_names__init_A_const_pool.A[24]; A_arbace_j2g_names__init_A_const_4 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[25]); A_arbace_j2g_names__init_A_const_5 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[26]); A_arbace_j2g_names__init_A_const_6 = A_arbace_j2g_names__init_A_const_pool.A[27]; A_arbace_j2g_names__init_A_const_7 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[28]); A_arbace_j2g_names__init_A_const_8 = A_arbace_j2g_names__init_A_const_pool.A[29]; A_arbace_j2g_names__init_A_const_9 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[30]); A_arbace_j2g_names__init_A_const_10 = A_arbace_j2g_names__init_A_const_pool.A[31]; A_arbace_j2g_names__init_A_const_11 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[32]); A_arbace_j2g_names__init_A_const_12 = A_arbace_j2g_names__init_A_const_pool.A[33] }

func A_arbace_j2g_names__init_A_clinit_p1() { A_arbace_j2g_names__init_A_const_13 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[34]); A_arbace_j2g_names__init_A_const_14 = A_arbace_j2g_names__init_A_const_pool.A[35]; A_arbace_j2g_names__init_A_const_15 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[36]); A_arbace_j2g_names__init_A_const_16 = A_arbace_j2g_names__init_A_const_pool.A[37]; A_arbace_j2g_names__init_A_const_17 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[38]); A_arbace_j2g_names__init_A_const_18 = A_arbace_j2g_names__init_A_const_pool.A[39]; A_arbace_j2g_names__init_A_const_19 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[40]); A_arbace_j2g_names__init_A_const_20 = A_arbace_j2g_names__init_A_const_pool.A[41]; A_arbace_j2g_names__init_A_const_21 = A_arbace_j2g_names__init_A_const_pool.A[42]; A_arbace_j2g_names__init_A_const_22 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[43]); A_arbace_j2g_names__init_A_const_23 = A_arbace_j2g_names__init_A_const_pool.A[44]; A_arbace_j2g_names__init_A_const_24 = A_arbace_j2g_names__init_A_const_pool.A[45]; A_arbace_j2g_names__init_A_const_25 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[46]); A_arbace_j2g_names__init_A_const_26 = A_arbace_j2g_names__init_A_const_pool.A[47] }

func A_arbace_j2g_names__init_A_clinit_p2() { A_arbace_j2g_names__init_A_const_27 = A_arbace_j2g_names__init_A_const_pool.A[48]; A_arbace_j2g_names__init_A_const_28 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[49]); A_arbace_j2g_names__init_A_const_29 = A_arbace_j2g_names__init_A_const_pool.A[50]; A_arbace_j2g_names__init_A_const_30 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[51]); A_arbace_j2g_names__init_A_const_31 = A_arbace_j2g_names__init_A_const_pool.A[52]; A_arbace_j2g_names__init_A_const_32 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[53]); A_arbace_j2g_names__init_A_const_33 = A_arbace_j2g_names__init_A_const_pool.A[54]; A_arbace_j2g_names__init_A_const_34 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[55]); A_arbace_j2g_names__init_A_const_35 = A_arbace_j2g_names__init_A_const_pool.A[56]; A_arbace_j2g_names__init_A_const_36 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[57]); A_arbace_j2g_names__init_A_const_37 = A_arbace_j2g_names__init_A_const_pool.A[58]; A_arbace_j2g_names__init_A_const_38 = A_arbace_j2g_names__init_A_const_pool.A[59]; A_arbace_j2g_names__init_A_const_39 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[60]); A_arbace_j2g_names__init_A_const_40 = A_arbace_j2g_names__init_A_const_pool.A[61] }

func A_arbace_j2g_names__init_A_clinit_p3() { A_arbace_j2g_names__init_A_const_41 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[62]); A_arbace_j2g_names__init_A_const_42 = A_arbace_j2g_names__init_A_const_pool.A[63]; A_arbace_j2g_names__init_A_const_43 = A_arbace_j2g_names__init_A_const_pool.A[64]; A_arbace_j2g_names__init_A_const_44 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[65]); A_arbace_j2g_names__init_A_const_45 = A_arbace_j2g_names__init_A_const_pool.A[66]; A_arbace_j2g_names__init_A_const_46 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[67]); A_arbace_j2g_names__init_A_const_47 = A_arbace_j2g_names__init_A_const_pool.A[68]; A_arbace_j2g_names__init_A_const_48 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[69]); A_arbace_j2g_names__init_A_const_49 = A_arbace_j2g_names__init_A_const_pool.A[70]; A_arbace_j2g_names__init_A_const_50 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[71]); A_arbace_j2g_names__init_A_const_51 = A_arbace_j2g_names__init_A_const_pool.A[72]; A_arbace_j2g_names__init_A_const_52 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[73]); A_arbace_j2g_names__init_A_const_53 = A_arbace_j2g_names__init_A_const_pool.A[74] }

func A_arbace_j2g_names__init_A_clinit_p4() { A_arbace_j2g_names__init_A_const_54 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[75]); A_arbace_j2g_names__init_A_const_55 = A_arbace_j2g_names__init_A_const_pool.A[76]; A_arbace_j2g_names__init_A_const_56 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[77]); A_arbace_j2g_names__init_A_const_57 = A_arbace_j2g_names__init_A_const_pool.A[78]; A_arbace_j2g_names__init_A_const_58 = A_arbace_j2g_names__init_A_const_pool.A[79]; A_arbace_j2g_names__init_A_const_59 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[80]); A_arbace_j2g_names__init_A_const_60 = A_arbace_j2g_names__init_A_const_pool.A[81]; A_arbace_j2g_names__init_A_const_61 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[82]); A_arbace_j2g_names__init_A_const_62 = A_arbace_j2g_names__init_A_const_pool.A[83]; A_arbace_j2g_names__init_A_const_63 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[84]); A_arbace_j2g_names__init_A_const_64 = A_arbace_j2g_names__init_A_const_pool.A[85]; A_arbace_j2g_names__init_A_const_65 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[86]); A_arbace_j2g_names__init_A_const_66 = A_arbace_j2g_names__init_A_const_pool.A[87] }

func A_arbace_j2g_names__init_A_clinit_p5() { A_arbace_j2g_names__init_A_const_67 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[88]); A_arbace_j2g_names__init_A_const_68 = A_arbace_j2g_names__init_A_const_pool.A[89]; A_arbace_j2g_names__init_A_const_69 = A_arbace_j2g_names__init_A_const_pool.A[90]; A_arbace_j2g_names__init_A_const_70 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[91]); A_arbace_j2g_names__init_A_const_71 = A_arbace_j2g_names__init_A_const_pool.A[92]; A_arbace_j2g_names__init_A_const_72 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[93]); A_arbace_j2g_names__init_A_const_73 = A_arbace_j2g_names__init_A_const_pool.A[94]; A_arbace_j2g_names__init_A_const_74 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[95]); A_arbace_j2g_names__init_A_const_75 = A_arbace_j2g_names__init_A_const_pool.A[96]; A_arbace_j2g_names__init_A_const_76 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[97]); A_arbace_j2g_names__init_A_const_77 = A_arbace_j2g_names__init_A_const_pool.A[98]; A_arbace_j2g_names__init_A_const_78 = A_arbace_j2g_names__init_A_const_pool.A[99]; A_arbace_j2g_names__init_A_const_79 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[100]); A_arbace_j2g_names__init_A_const_80 = A_arbace_j2g_names__init_A_const_pool.A[101] }

func A_arbace_j2g_names__init_A_clinit_p6() { A_arbace_j2g_names__init_A_const_81 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[102]); A_arbace_j2g_names__init_A_const_82 = A_arbace_j2g_names__init_A_const_pool.A[103]; A_arbace_j2g_names__init_A_const_83 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[104]); A_arbace_j2g_names__init_A_const_84 = A_arbace_j2g_names__init_A_const_pool.A[105]; A_arbace_j2g_names__init_A_const_85 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[106]); A_arbace_j2g_names__init_A_const_86 = A_arbace_j2g_names__init_A_const_pool.A[107] }

func A_arbace_j2g_names__init_A_New() *A_arbace_j2g_names__init_A { A_arbace_j2g_names__init_A_Init(); t := &A_arbace_j2g_names__init_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_names__init_A) Ctor() {}

func (t *A_arbace_j2g_names__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_names__init_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_names__init_A_class }

func (t *A_arbace_j2g_names__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_names__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_names__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_names__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_names__init_A); return ok }

func A_arbace_j2g_names__init_A_Cast(x any) *A_arbace_j2g_names__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_names__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_names__init_A_class)) }; return v }
