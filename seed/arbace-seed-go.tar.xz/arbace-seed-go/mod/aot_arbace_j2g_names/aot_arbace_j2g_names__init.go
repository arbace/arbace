//line aot_arbace_j2g_names__init.ae:1
package aot_arbace_j2g_names

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_names__init_A_Unit0__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_j2g_names__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_names__init_A_const_1) }
//line :1:1
func A_arbace_j2g_names__init_A_Unit1__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_j2g_names__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_2)) }
//line :1:1
func A_arbace_j2g_names__init_A_Unit2__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_j2g_names_eval1768000004_loading__1927001464__auto____1768000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_j2g_names__init_A_Unit3__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_j2g_names__init_A_const_1)).Equals_O__Z(A_arbace_j2g_names__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_j2g_names_eval1768000008_fn__1768000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_j2g_names_eval1768000008_fn__1768000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_j2g_names_eval1768000008_fn__1768000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_j2g_names__init_A_Load__O() any { A_arbace_j2g_names__init_A_Init(); jrt.StartCheck(); A_arbace_j2g_names__init_A_Unit0__O(); A_arbace_j2g_names__init_A_Unit1__O(); A_arbace_j2g_names__init_A_Unit2__O(); A_arbace_j2g_names__init_A_Unit3__O(); A_arbace_j2g_names__init_A_Unit4__O(); A_arbace_j2g_names__init_A_Unit5__O(); A_arbace_j2g_names__init_A_Unit6__O(); A_arbace_j2g_names__init_A_Unit7__O(); A_arbace_j2g_names__init_A_Unit8__O(); A_arbace_j2g_names__init_A_Unit9__O(); A_arbace_j2g_names__init_A_Unit10__O(); A_arbace_j2g_names__init_A_Unit11__O(); A_arbace_j2g_names__init_A_Unit12__O(); A_arbace_j2g_names__init_A_Unit13__O(); A_arbace_j2g_names__init_A_Unit14__O(); A_arbace_j2g_names__init_A_Unit15__O(); A_arbace_j2g_names__init_A_Unit16__O(); A_arbace_j2g_names__init_A_Unit17__O(); A_arbace_j2g_names__init_A_Unit18__O(); A_arbace_j2g_names__init_A_Unit19__O(); A_arbace_j2g_names__init_A_Unit20__O(); A_arbace_j2g_names__init_A_Unit21__O(); A_arbace_j2g_names__init_A_Unit22__O(); A_arbace_j2g_names__init_A_Unit23__O(); A_arbace_j2g_names__init_A_Unit24__O(); A_arbace_j2g_names__init_A_Unit25__O(); A_arbace_j2g_names__init_A_Unit26__O(); A_arbace_j2g_names__init_A_Unit27__O(); A_arbace_j2g_names__init_A_Unit28__O(); A_arbace_j2g_names__init_A_Unit29__O(); A_arbace_j2g_names__init_A_Unit30__O(); A_arbace_j2g_names__init_A_Unit31__O(); A_arbace_j2g_names__init_A_Unit32__O(); A_arbace_j2g_names__init_A_Unit33__O(); A_arbace_j2g_names__init_A_Unit34__O(); A_arbace_j2g_names__init_A_Unit35__O(); A_arbace_j2g_names__init_A_Unit36__O(); A_arbace_j2g_names__init_A_Unit37__O(); A_arbace_j2g_names__init_A_Unit38__O(); return nil }





func A_arbace_j2g_names__init_A_Unit4__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(11, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_4; var tmp2 any; var root_3 any = A_arbace_j2g_names__init_A_const_5.GetRawRoot__O(); var linked_4 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_5 lang.IFn; if



	linked_4 == nil { ifn_5 = lang.IFn_Cast(root_3) } else { ifn_5 = nil }; var arg_6 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_4 == nil { tmp2 = ifn_5.Invoke_O__O(arg_6) } else { tmp2 = linked_4.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_3, arg_6) }; /*line :11:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_j2g_names__init_A_const_4; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_6)); return A_arbace_j2g_names__init_A_const_4 }





func A_arbace_j2g_names__init_A_Unit5__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_7; var tmp2 any = A_arbace_j2g_names_top_of_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_j2g_names_top_of_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_j2g_names_top_of_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_7; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_8)); return A_arbace_j2g_names__init_A_const_7 }

func A_arbace_j2g_names__init_A_Unit6__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(19, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_9; var tmp2 any = A_arbace_j2g_names_pkg_of_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_j2g_names_pkg_of_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_j2g_names_pkg_of_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_10)); return A_arbace_j2g_names__init_A_const_9 }










func A_arbace_j2g_names__init_A_Unit7__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(30, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_11; var tmp2 any = A_arbace_j2g_names_compiled_pkg_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_j2g_names_compiled_pkg_QMARK__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_j2g_names_compiled_pkg_QMARK__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_12)); return A_arbace_j2g_names__init_A_const_11 }

func A_arbace_j2g_names__init_A_Unit8__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(32, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_13; var tmp2 any = A_arbace_j2g_names_pkg_name_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_j2g_names_pkg_name_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_j2g_names_pkg_name_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_14)); return A_arbace_j2g_names__init_A_const_13 }
func A_arbace_j2g_names__init_A_Unit9__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_15; var tmp2 any = A_arbace_j2g_names_pkg_path_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_j2g_names_pkg_path_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_j2g_names_pkg_path_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_16)); return A_arbace_j2g_names__init_A_const_15 }
func A_arbace_j2g_names__init_A_Unit10__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(34, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_17; var tmp2 any = A_arbace_j2g_names_pkg_ns_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_j2g_names_pkg_ns_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_j2g_names_pkg_ns_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_18)); return A_arbace_j2g_names__init_A_const_17 }




func A_arbace_j2g_names__init_A_Unit11__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(39, 1); A_arbace_j2g_names__init_A_const_19.BindRoot_O__V(A_arbace_j2g_names__init_A_const_20); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_19; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_21)); return A_arbace_j2g_names__init_A_const_19 }




func A_arbace_j2g_names__init_A_Unit12__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); A_arbace_j2g_names__init_A_const_22.BindRoot_O__V(A_arbace_j2g_names__init_A_const_23); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_22; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_24)); return A_arbace_j2g_names__init_A_const_22 }





func A_arbace_j2g_names__init_A_Unit13__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(50, 1); A_arbace_j2g_names__init_A_const_25.BindRoot_O__V(A_arbace_j2g_names__init_A_const_26); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_25; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_27)); return A_arbace_j2g_names__init_A_const_25 }



func A_arbace_j2g_names__init_A_Unit14__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(54, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_28; var tmp2 any = A_arbace_j2g_names_memo_str_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_j2g_names_memo_str_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_j2g_names_memo_str_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_29)); return A_arbace_j2g_names__init_A_const_28 }










func A_arbace_j2g_names__init_A_Unit15__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(65, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_30; var tmp2 any; var root_14 any = A_arbace_j2g_names__init_A_const_28.GetRawRoot__O(); var linked_15 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_14, A_arbace_j2g_names_memo_str_A_fn_class); var ifn_16 lang.IFn; if
						linked_15 == nil { ifn_16 = lang.IFn_Cast(root_14) } else { ifn_16 = nil }; var arg_17 any; var tmp3 any = A_arbace_j2g_names_fn__1768000021_A_New(); var tmp4 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_j2g_names_fn__1768000021_A_fn_class; if
						fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_j2g_names_fn__1768000021_A_fn_class = fncls__18d; tmp4 = fncls__18d } else { tmp4 = fncls__18 }; arg_17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); if /*line :66:1*/ linked_15 == nil { tmp2 = ifn_16.Invoke_O__O(arg_17) } else { tmp2 = linked_15.(*A_arbace_j2g_names_memo_str_A).Invoke_O_O__O(root_14, arg_17) }; /*line :65:1*/tmp1.BindRoot_O__V(tmp2); var tmp5 *lang.Var = A_arbace_j2g_names__init_A_const_30; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_31)); return A_arbace_j2g_names__init_A_const_30 }







func A_arbace_j2g_names__init_A_Unit16__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(73, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_32; var tmp2 any = A_arbace_j2g_names_munge_name_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_j2g_names_munge_name_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_j2g_names_munge_name_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_33)); return A_arbace_j2g_names__init_A_const_32 }




func A_arbace_j2g_names__init_A_Unit17__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(78, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_34; var tmp2 any = A_arbace_j2g_names_local_name_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_j2g_names_local_name_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_j2g_names_local_name_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_35)); return A_arbace_j2g_names__init_A_const_34 }















func A_arbace_j2g_names__init_A_Unit18__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(94, 1); A_arbace_j2g_names__init_A_const_36.BindRoot_O__V(A_arbace_j2g_names__init_A_const_37); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_36; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_38)); return A_arbace_j2g_names__init_A_const_36 }


































func A_arbace_j2g_names__init_A_Unit19__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(129, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_39; var tmp2 any = A_arbace_j2g_names_compiled_class_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_j2g_names_compiled_class_QMARK__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_j2g_names_compiled_class_QMARK__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_40)); return A_arbace_j2g_names__init_A_const_39 }










func A_arbace_j2g_names__init_A_Unit20__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(140, 1); A_arbace_j2g_names__init_A_const_41.BindRoot_O__V(A_arbace_j2g_names__init_A_const_42); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_41; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_43)); return A_arbace_j2g_names__init_A_const_41 }












func A_arbace_j2g_names__init_A_Unit21__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(153, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_44; var tmp2 any; var root_22 any = A_arbace_j2g_names__init_A_const_5.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_24 lang.IFn; if


	linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = lang.PersistentVector_EMPTY.Ref(); if linked_23 == nil { tmp2 = ifn_24.Invoke_O__O(arg_25) } else { tmp2 = linked_23.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_22, arg_25) }; /*line :153:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_j2g_names__init_A_const_44; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_45)); return A_arbace_j2g_names__init_A_const_44 }




func A_arbace_j2g_names__init_A_Unit22__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(158, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_46; var tmp2 any = A_arbace_j2g_names_qualified_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_j2g_names_qualified_QMARK__A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_j2g_names_qualified_QMARK__A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_47)); return A_arbace_j2g_names__init_A_const_46 }





func A_arbace_j2g_names__init_A_Unit23__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(164, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_48; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_49)); return A_arbace_j2g_names__init_A_const_48 }

func A_arbace_j2g_names__init_A_Unit24__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(166, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_50; var tmp2 any = A_arbace_j2g_names_go_class_name_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_j2g_names_go_class_name_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_j2g_names_go_class_name_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_51)); return A_arbace_j2g_names__init_A_const_50 }







func A_arbace_j2g_names__init_A_Unit25__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(174, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_52; var tmp2 any = A_arbace_j2g_names_go_class_name_STAR__STAR__A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_j2g_names_go_class_name_STAR__STAR__A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_j2g_names_go_class_name_STAR__STAR__A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_53)); return A_arbace_j2g_names__init_A_const_52 }












func A_arbace_j2g_names__init_A_Unit26__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(187, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_48; var tmp2 any; var root_29 any = A_arbace_j2g_names__init_A_const_28.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_29, A_arbace_j2g_names_memo_str_A_fn_class); var ifn_31 lang.IFn; if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any = A_arbace_j2g_names__init_A_const_52.GetRawRoot__O(); if linked_30 == nil { tmp2 = ifn_31.Invoke_O__O(arg_32) } else { tmp2 = linked_30.(*A_arbace_j2g_names_memo_str_A).Invoke_O_O__O(root_29, arg_32) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_j2g_names__init_A_const_48; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_54)); return A_arbace_j2g_names__init_A_const_48 }

func A_arbace_j2g_names__init_A_Unit27__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(189, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_55; var tmp2 any = A_arbace_j2g_names_capitalize_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_j2g_names_capitalize_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_j2g_names_capitalize_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_56)); return A_arbace_j2g_names__init_A_const_55 }





func A_arbace_j2g_names__init_A_Unit28__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(195, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_57; tmp1.BindRoot_O__V(jrt.ConcurrentHashMap_New()); var tmp2 *lang.Var = A_arbace_j2g_names__init_A_const_57; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_58)); return A_arbace_j2g_names__init_A_const_57 }



func A_arbace_j2g_names__init_A_Unit29__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(199, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_59; var tmp2 any = A_arbace_j2g_names_desc_code_A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_j2g_names_desc_code_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_j2g_names_desc_code_A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_60)); return A_arbace_j2g_names__init_A_const_59 }










func A_arbace_j2g_names__init_A_Unit30__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(210, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_61; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_62)); return A_arbace_j2g_names__init_A_const_61 }

func A_arbace_j2g_names__init_A_Unit31__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(212, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_63; var tmp2 any = A_arbace_j2g_names_method_base_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_j2g_names_method_base_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_j2g_names_method_base_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_64)); return A_arbace_j2g_names__init_A_const_63 }









func A_arbace_j2g_names__init_A_Unit32__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(222, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_61; var tmp2 any = A_arbace_j2g_names_method_base_STAR__A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_j2g_names_method_base_STAR__A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_j2g_names_method_base_STAR__A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_65)); return A_arbace_j2g_names__init_A_const_61 }





func A_arbace_j2g_names__init_A_Unit33__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(228, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_66; var tmp2 any = A_arbace_j2g_names_ctor_base_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_j2g_names_ctor_base_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_j2g_names_ctor_base_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_67)); return A_arbace_j2g_names__init_A_const_66 }






func A_arbace_j2g_names__init_A_Unit34__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(235, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_68; var tmp2 any = A_arbace_j2g_names_new_name_A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_j2g_names_new_name_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_j2g_names_new_name_A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_69)); return A_arbace_j2g_names__init_A_const_68 }





func A_arbace_j2g_names__init_A_Unit35__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(241, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_70; var tmp2 any = A_arbace_j2g_names_field_name_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_j2g_names_field_name_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_j2g_names_field_name_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_71)); return A_arbace_j2g_names__init_A_const_70 }

func A_arbace_j2g_names__init_A_Unit36__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(243, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_72; var tmp2 any = A_arbace_j2g_names_static_field_name_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_j2g_names_static_field_name_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_j2g_names_static_field_name_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_73)); return A_arbace_j2g_names__init_A_const_72 }

func A_arbace_j2g_names__init_A_Unit37__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(245, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_74; var tmp2 any = A_arbace_j2g_names_static_method_name_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_j2g_names_static_method_name_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_j2g_names_static_method_name_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_75)); return A_arbace_j2g_names__init_A_const_74 }

func A_arbace_j2g_names__init_A_Unit38__O() any { A_arbace_j2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(247, 1); var tmp1 *lang.Var = A_arbace_j2g_names__init_A_const_76; var tmp2 any = A_arbace_j2g_names_impl_name_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_j2g_names_impl_name_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_j2g_names_impl_name_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_names__init_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_names__init_A_const_77)); return A_arbace_j2g_names__init_A_const_76 }



type A_arbace_j2g_names__init_A struct{ jrt.Object }

var A_arbace_j2g_names__init_A_const_pool *jrt.RefArray

var A_arbace_j2g_names__init_A_const_0 *lang.Var

var A_arbace_j2g_names__init_A_const_1 any

var A_arbace_j2g_names__init_A_const_2 any

var A_arbace_j2g_names__init_A_const_3 any

var A_arbace_j2g_names__init_A_const_4 *lang.Var

var A_arbace_j2g_names__init_A_const_5 *lang.Var

var A_arbace_j2g_names__init_A_const_6 any

var A_arbace_j2g_names__init_A_const_7 *lang.Var

var A_arbace_j2g_names__init_A_const_8 any

var A_arbace_j2g_names__init_A_const_9 *lang.Var

var A_arbace_j2g_names__init_A_const_10 any

var A_arbace_j2g_names__init_A_const_11 *lang.Var

var A_arbace_j2g_names__init_A_const_12 any

var A_arbace_j2g_names__init_A_const_13 *lang.Var

var A_arbace_j2g_names__init_A_const_14 any

var A_arbace_j2g_names__init_A_const_15 *lang.Var

var A_arbace_j2g_names__init_A_const_16 any

var A_arbace_j2g_names__init_A_const_17 *lang.Var

var A_arbace_j2g_names__init_A_const_18 any

var A_arbace_j2g_names__init_A_const_19 *lang.Var

var A_arbace_j2g_names__init_A_const_20 any

var A_arbace_j2g_names__init_A_const_21 any

var A_arbace_j2g_names__init_A_const_22 *lang.Var

var A_arbace_j2g_names__init_A_const_23 any

var A_arbace_j2g_names__init_A_const_24 any

var A_arbace_j2g_names__init_A_const_25 *lang.Var

var A_arbace_j2g_names__init_A_const_26 any

var A_arbace_j2g_names__init_A_const_27 any

var A_arbace_j2g_names__init_A_const_28 *lang.Var

var A_arbace_j2g_names__init_A_const_29 any

var A_arbace_j2g_names__init_A_const_30 *lang.Var

var A_arbace_j2g_names__init_A_const_31 any

var A_arbace_j2g_names__init_A_const_32 *lang.Var

var A_arbace_j2g_names__init_A_const_33 any

var A_arbace_j2g_names__init_A_const_34 *lang.Var

var A_arbace_j2g_names__init_A_const_35 any

var A_arbace_j2g_names__init_A_const_36 *lang.Var

var A_arbace_j2g_names__init_A_const_37 any

var A_arbace_j2g_names__init_A_const_38 any

var A_arbace_j2g_names__init_A_const_39 *lang.Var

var A_arbace_j2g_names__init_A_const_40 any

var A_arbace_j2g_names__init_A_const_41 *lang.Var

var A_arbace_j2g_names__init_A_const_42 any

var A_arbace_j2g_names__init_A_const_43 any

var A_arbace_j2g_names__init_A_const_44 *lang.Var

var A_arbace_j2g_names__init_A_const_45 any

var A_arbace_j2g_names__init_A_const_46 *lang.Var

var A_arbace_j2g_names__init_A_const_47 any

var A_arbace_j2g_names__init_A_const_48 *lang.Var

var A_arbace_j2g_names__init_A_const_49 any

var A_arbace_j2g_names__init_A_const_50 *lang.Var

var A_arbace_j2g_names__init_A_const_51 any

var A_arbace_j2g_names__init_A_const_52 *lang.Var

var A_arbace_j2g_names__init_A_const_53 any

var A_arbace_j2g_names__init_A_const_54 any

var A_arbace_j2g_names__init_A_const_55 *lang.Var

var A_arbace_j2g_names__init_A_const_56 any

var A_arbace_j2g_names__init_A_const_57 *lang.Var

var A_arbace_j2g_names__init_A_const_58 any

var A_arbace_j2g_names__init_A_const_59 *lang.Var

var A_arbace_j2g_names__init_A_const_60 any

var A_arbace_j2g_names__init_A_const_61 *lang.Var

var A_arbace_j2g_names__init_A_const_62 any

var A_arbace_j2g_names__init_A_const_63 *lang.Var

var A_arbace_j2g_names__init_A_const_64 any

var A_arbace_j2g_names__init_A_const_65 any

var A_arbace_j2g_names__init_A_const_66 *lang.Var

var A_arbace_j2g_names__init_A_const_67 any

var A_arbace_j2g_names__init_A_const_68 *lang.Var

var A_arbace_j2g_names__init_A_const_69 any

var A_arbace_j2g_names__init_A_const_70 *lang.Var

var A_arbace_j2g_names__init_A_const_71 any

var A_arbace_j2g_names__init_A_const_72 *lang.Var

var A_arbace_j2g_names__init_A_const_73 any

var A_arbace_j2g_names__init_A_const_74 *lang.Var

var A_arbace_j2g_names__init_A_const_75 any

var A_arbace_j2g_names__init_A_const_76 *lang.Var

var A_arbace_j2g_names__init_A_const_77 any

var A_arbace_j2g_names__init_A_init jrt.ClassInit

func A_arbace_j2g_names__init_A_Init() { if !A_arbace_j2g_names__init_A_init.Done() { A_arbace_j2g_names__init_A_init.Run(A_arbace_j2g_names__init_A_clinit) } }

func A_arbace_j2g_names__init_A_clinit() { A_arbace_j2g_names__init_A_clinit_p0(); A_arbace_j2g_names__init_A_clinit_p1(); A_arbace_j2g_names__init_A_clinit_p2(); A_arbace_j2g_names__init_A_clinit_p3(); A_arbace_j2g_names__init_A_clinit_p4(); A_arbace_j2g_names__init_A_clinit_p5() }

func A_arbace_j2g_names__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_names__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_34, 99); A_arbace_j2g_names__init_A_const_0 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[21]); A_arbace_j2g_names__init_A_const_1 = A_arbace_j2g_names__init_A_const_pool.A[22]; A_arbace_j2g_names__init_A_const_2 = A_arbace_j2g_names__init_A_const_pool.A[23]; A_arbace_j2g_names__init_A_const_3 = A_arbace_j2g_names__init_A_const_pool.A[24]; A_arbace_j2g_names__init_A_const_4 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[25]); A_arbace_j2g_names__init_A_const_5 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[26]); A_arbace_j2g_names__init_A_const_6 = A_arbace_j2g_names__init_A_const_pool.A[27]; A_arbace_j2g_names__init_A_const_7 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[28]); A_arbace_j2g_names__init_A_const_8 = A_arbace_j2g_names__init_A_const_pool.A[29]; A_arbace_j2g_names__init_A_const_9 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[30]); A_arbace_j2g_names__init_A_const_10 = A_arbace_j2g_names__init_A_const_pool.A[31]; A_arbace_j2g_names__init_A_const_11 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[32]); A_arbace_j2g_names__init_A_const_12 = A_arbace_j2g_names__init_A_const_pool.A[33] }

func A_arbace_j2g_names__init_A_clinit_p1() { A_arbace_j2g_names__init_A_const_13 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[34]); A_arbace_j2g_names__init_A_const_14 = A_arbace_j2g_names__init_A_const_pool.A[35]; A_arbace_j2g_names__init_A_const_15 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[36]); A_arbace_j2g_names__init_A_const_16 = A_arbace_j2g_names__init_A_const_pool.A[37]; A_arbace_j2g_names__init_A_const_17 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[38]); A_arbace_j2g_names__init_A_const_18 = A_arbace_j2g_names__init_A_const_pool.A[39]; A_arbace_j2g_names__init_A_const_19 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[40]); A_arbace_j2g_names__init_A_const_20 = A_arbace_j2g_names__init_A_const_pool.A[41]; A_arbace_j2g_names__init_A_const_21 = A_arbace_j2g_names__init_A_const_pool.A[42]; A_arbace_j2g_names__init_A_const_22 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[43]); A_arbace_j2g_names__init_A_const_23 = A_arbace_j2g_names__init_A_const_pool.A[44]; A_arbace_j2g_names__init_A_const_24 = A_arbace_j2g_names__init_A_const_pool.A[45]; A_arbace_j2g_names__init_A_const_25 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[46]); A_arbace_j2g_names__init_A_const_26 = A_arbace_j2g_names__init_A_const_pool.A[47] }

func A_arbace_j2g_names__init_A_clinit_p2() { A_arbace_j2g_names__init_A_const_27 = A_arbace_j2g_names__init_A_const_pool.A[48]; A_arbace_j2g_names__init_A_const_28 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[49]); A_arbace_j2g_names__init_A_const_29 = A_arbace_j2g_names__init_A_const_pool.A[50]; A_arbace_j2g_names__init_A_const_30 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[51]); A_arbace_j2g_names__init_A_const_31 = A_arbace_j2g_names__init_A_const_pool.A[52]; A_arbace_j2g_names__init_A_const_32 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[53]); A_arbace_j2g_names__init_A_const_33 = A_arbace_j2g_names__init_A_const_pool.A[54]; A_arbace_j2g_names__init_A_const_34 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[55]); A_arbace_j2g_names__init_A_const_35 = A_arbace_j2g_names__init_A_const_pool.A[56]; A_arbace_j2g_names__init_A_const_36 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[57]); A_arbace_j2g_names__init_A_const_37 = A_arbace_j2g_names__init_A_const_pool.A[58]; A_arbace_j2g_names__init_A_const_38 = A_arbace_j2g_names__init_A_const_pool.A[59]; A_arbace_j2g_names__init_A_const_39 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[60]); A_arbace_j2g_names__init_A_const_40 = A_arbace_j2g_names__init_A_const_pool.A[61] }

func A_arbace_j2g_names__init_A_clinit_p3() { A_arbace_j2g_names__init_A_const_41 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[62]); A_arbace_j2g_names__init_A_const_42 = A_arbace_j2g_names__init_A_const_pool.A[63]; A_arbace_j2g_names__init_A_const_43 = A_arbace_j2g_names__init_A_const_pool.A[64]; A_arbace_j2g_names__init_A_const_44 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[65]); A_arbace_j2g_names__init_A_const_45 = A_arbace_j2g_names__init_A_const_pool.A[66]; A_arbace_j2g_names__init_A_const_46 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[67]); A_arbace_j2g_names__init_A_const_47 = A_arbace_j2g_names__init_A_const_pool.A[68]; A_arbace_j2g_names__init_A_const_48 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[69]); A_arbace_j2g_names__init_A_const_49 = A_arbace_j2g_names__init_A_const_pool.A[70]; A_arbace_j2g_names__init_A_const_50 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[71]); A_arbace_j2g_names__init_A_const_51 = A_arbace_j2g_names__init_A_const_pool.A[72]; A_arbace_j2g_names__init_A_const_52 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[73]); A_arbace_j2g_names__init_A_const_53 = A_arbace_j2g_names__init_A_const_pool.A[74]; A_arbace_j2g_names__init_A_const_54 = A_arbace_j2g_names__init_A_const_pool.A[75] }

func A_arbace_j2g_names__init_A_clinit_p4() { A_arbace_j2g_names__init_A_const_55 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[76]); A_arbace_j2g_names__init_A_const_56 = A_arbace_j2g_names__init_A_const_pool.A[77]; A_arbace_j2g_names__init_A_const_57 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[78]); A_arbace_j2g_names__init_A_const_58 = A_arbace_j2g_names__init_A_const_pool.A[79]; A_arbace_j2g_names__init_A_const_59 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[80]); A_arbace_j2g_names__init_A_const_60 = A_arbace_j2g_names__init_A_const_pool.A[81]; A_arbace_j2g_names__init_A_const_61 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[82]); A_arbace_j2g_names__init_A_const_62 = A_arbace_j2g_names__init_A_const_pool.A[83]; A_arbace_j2g_names__init_A_const_63 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[84]); A_arbace_j2g_names__init_A_const_64 = A_arbace_j2g_names__init_A_const_pool.A[85]; A_arbace_j2g_names__init_A_const_65 = A_arbace_j2g_names__init_A_const_pool.A[86]; A_arbace_j2g_names__init_A_const_66 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[87]); A_arbace_j2g_names__init_A_const_67 = A_arbace_j2g_names__init_A_const_pool.A[88] }

func A_arbace_j2g_names__init_A_clinit_p5() { A_arbace_j2g_names__init_A_const_68 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[89]); A_arbace_j2g_names__init_A_const_69 = A_arbace_j2g_names__init_A_const_pool.A[90]; A_arbace_j2g_names__init_A_const_70 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[91]); A_arbace_j2g_names__init_A_const_71 = A_arbace_j2g_names__init_A_const_pool.A[92]; A_arbace_j2g_names__init_A_const_72 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[93]); A_arbace_j2g_names__init_A_const_73 = A_arbace_j2g_names__init_A_const_pool.A[94]; A_arbace_j2g_names__init_A_const_74 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[95]); A_arbace_j2g_names__init_A_const_75 = A_arbace_j2g_names__init_A_const_pool.A[96]; A_arbace_j2g_names__init_A_const_76 = lang.Var_Cast(A_arbace_j2g_names__init_A_const_pool.A[97]); A_arbace_j2g_names__init_A_const_77 = A_arbace_j2g_names__init_A_const_pool.A[98] }

func A_arbace_j2g_names__init_A_New() *A_arbace_j2g_names__init_A { A_arbace_j2g_names__init_A_Init(); t := &A_arbace_j2g_names__init_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_names__init_A) Ctor() {}

func (t *A_arbace_j2g_names__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_names__init_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_names__init_A_class }

func (t *A_arbace_j2g_names__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_names__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_names__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_names__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_names__init_A); return ok }

func A_arbace_j2g_names__init_A_Cast(x any) *A_arbace_j2g_names__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_names__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_names__init_A_class)) }; return v }
