//line j2g_strings.ae:1
package aot_arbace_j2g_names

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn20,arbace.classes.typesyn1,tyn11,arbace.corekn3,dockn3,jrtkn4,elsekn4,langv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,v11,arbace.core5,referR5,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn16,arbace.j2g.namesm2,R6,s251,j2g's names (doc/go/J2G-SPEC.md §4.2, §4.4): Go packages of Java classes, Go identifiers of\n  classes, members and locals, the descriptor codes of mangled method names, and the Go type of\n  a Java type (§5.1) given the class facts of the closed world.v11,arbace.core4,subsl0,v13,arbace.string12,starts-with?R7,R8,v16,arbace.j2g.names17,compiled-packagesv16,arbace.j2g.names6,top-ofv11,arbace.core7,keywordR9,v11,arbace.core3,notS2,R7,R9,v11,arbace.core4,namev13,arbace.string7,replacev11,arbace.core3,strv11,arbace.core5,mungev11,arbace.core5,applyv11,arbace.core3,mapc95,v16,arbace.j2g.names11,munge-name*v16,arbace.j2g.names10,munge-namev13,arbace.string6,blank?v16,arbace.j2g.names11,go-keywordsv16,arbace.j2g.names14,go-predeclaredv16,arbace.j2g.names15,reserved-localsv11,arbace.core10,re-matchesp8,tmp\\d+.*p7,[lL]\\d+v11,arbace.core4,somev16,arbace.j2g.names20,tool-module-prefixesv16,arbace.j2g.names18,qualified-prefixesv16,arbace.j2g.names14,go-class-name*v16,arbace.j2g.names7,renamesv16,arbace.j2g.names10,qualified?v16,arbace.j2g.names15,compiled-class?v11,arbace.core3,seqv11,arbace.core6,empty?l1,v20,arbace.classes.types6,array?v20,arbace.classes.types10,array-dimsv16,arbace.j2g.names9,desc-codev20,arbace.classes.types11,class-desc?v16,arbace.j2g.names13,go-class-namev20,arbace.classes.types14,desc->internalv16,arbace.j2g.names12,method-basesv16,arbace.j2g.names12,method-base*v20,arbace.classes.types17,parse-method-descv16,arbace.j2g.names10,capitalizev16,arbace.j2g.names11,method-base")

var Lit_1 *jrt.String = jrt.Intern("arbace/")

var Lit_2 *jrt.String = jrt.Intern("arbace/lang/")

var Lit_3 *jrt.String = jrt.Intern("arbace/java/api/")

var Lit_4 *jrt.String = jrt.Intern("aot_")

var Lit_5 *jrt.String = jrt.Intern("Ctor")

var Lit_6 *jrt.String = jrt.Intern("arbace.j2g.names$ctor_base$fn__1768000051")

var Lit_7 *jrt.String = jrt.Intern("_")

var Lit_8 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_9 *jrt.String = jrt.Intern("O")

var Lit_10 *jrt.String = jrt.Intern("F_")

var Lit_11 *jrt.String = jrt.Intern("$")

var Lit_12 *jrt.String = jrt.Intern("arbace.j2g.names$fn__1768000021$fn__1768000022")

var Lit_13 *jrt.String = jrt.Intern("Jv_")

var Lit_14 *jrt.String = jrt.Intern("/")

var Lit_15 *jrt.String = jrt.Intern("A_")

var Lit_16 *jrt.String = jrt.Intern("_A")

var Lit_17 *jrt.String = jrt.Intern("X")

var Lit_18 *jrt.String = jrt.Intern("Impl_")

var Lit_19 *jrt.String = jrt.Intern("x")

var Lit_20 *jrt.String = jrt.Intern("j2g_")

var Lit_21 *jrt.String = jrt.Intern("arbace.j2g.names$memo_str$fn__1768000018")

var Lit_22 *jrt.String = jrt.Intern("__")

var Lit_23 *jrt.String = jrt.Intern("arbace.j2g.names$method_base_STAR_$fn__1768000044")

var Lit_24 *jrt.String = jrt.Intern("_New")

var Lit_25 *jrt.String = jrt.Intern("arbace.j2g.names$new_name$fn__1768000058")

var Lit_26 *jrt.String = jrt.Intern("go.arbace.")

var Lit_27 *jrt.String = jrt.Intern("java/")

var Lit_28 *jrt.String = jrt.Intern("jdk/")

var Lit_29 *jrt.String = jrt.Intern("sun/")

var Lit_30 *jrt.String = jrt.Intern("javax/")

var Lit_31 *jrt.String = jrt.Intern("com/sun/")

var Lit_32 *jrt.String = jrt.Intern("org/xml/")

var Lit_33 *jrt.String = jrt.Intern("org/w3c/")

var Lit_34 *jrt.String = jrt.Intern("build/tools/")

var Lit_35 *jrt.String = jrt.Intern("compileproperties/")

var Lit_36 *jrt.String = jrt.Intern("propertiesparser/")

var Lit_37 *jrt.String = jrt.Intern("flagsgenerator/")

var Lit_38 *jrt.String = jrt.Intern("arbace.j2g.names$qualified_QMARK_$fn__1768000030")

var Lit_39 *jrt.String = jrt.Intern("arbace.j2g.names$qualified_QMARK_$fn__1768000032")

var Lit_40 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn4,linekn6,columnkn4,filekn7,privatekn8,arglistskn3,tagyn6,Stringyn8,internalyn3,pkgyn1,fyn1,syn3,symkn8,declaredyn1,dyn4,nameyn4,descyn6,cls-goyn5,fnameyn5,mbasev11,arbace.core5,in-nsMyn16,arbace.j2g.namesm2,R0,s251,j2g's names (doc/go/J2G-SPEC.md §4.2, §4.4): Go packages of Java classes, Go identifiers of\n  classes, members and locals, the descriptor codes of mangled method names, and the Go type of\n  a Java type (§5.1) given the class facts of the closed world.m2,R0,s251,j2g's names (doc/go/J2G-SPEC.md §4.2, §4.4): Go packages of Java classes, Go identifiers of\n  classes, members and locals, the descriptor codes of mangled method names, and the Go type of\n  a Java type (§5.1) given the class facts of the closed world.R1,v16,arbace.j2g.names17,compiled-packagesv11,arbace.core4,atomm8,R2,i11,R3,i1,R4,s19,arbace/j2g/names.aeR0,s227,The Go packages of compiled namespaces' classes (standalone S6, SA142): top-level class\n  (internal name) → package name, from the packages.edn of the inputs (arbace.c2j's tree);\n  set once by j2g's run, before any translation.v16,arbace.j2g.names6,top-ofm10,R5,TR6,L1,V1,Myn1,nm2,R7,R8,R2,i17,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names6,pkg-ofm10,R6,L1,V1,R9,R0,s515,The Go package of a class (internal name): :jrt for the JDK's packages (java, javax, jdk,\n  sun, and com.sun since the SunJCE provider: amendment SC3; org.xml and org.w3c, java.xml's, and\n  build.tools, the JDK build's tools, in javac's tool build since JN7; compileproperties and\n  propertiesparser, the JDK build's langtools tools, since JFS48 (b), and flagsgenerator, the third\n  of them, since JFS52 (b)), a compiled namespace's own\n  (compiled-packages: a keyword of its package name), else :lang for Arbace's.R2,i19,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names13,compiled-pkg?m8,R6,L1,V1,R10,R2,i36,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names8,pkg-namem8,R6,L1,V1,R10,R2,i38,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names8,pkg-pathm8,R6,L1,V1,R10,R2,i39,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names6,pkg-nsm8,R6,L1,V1,R10,R2,i40,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names11,go-keywordsS25,s4,elses4,funcs3,maps5,ranges4,chans7,packages9,interfaces5,defers3,vars6,returns3,fors11,fallthroughs2,ifs6,imports2,gos6,switchs5,consts6,selects4,cases5,breaks8,continues4,types6,structs7,defaults4,gotom6,R2,i45,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names14,go-predeclaredS44,s5,int16s7,recovers3,ints3,mins5,panics10,comparables6,strings4,runes7,float32s4,copys7,float64s4,uints5,int32s6,uint16s6,deletes7,uintptrs6,uint32s5,int64s4,iotas3,maxs3,news5,errors4,imags10,complex128s3,anys5,falses4,reals6,uint64s4,makes7,printlns4,bools5,uint8s4,trues5,closes4,int8s6,appends5,prints3,lens5,clears3,nils3,caps7,complexs9,complex64s4,bytem6,R2,i50,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names15,reserved-localsS12,s4,langs4,thiss2,rvs3,jrts7,reflects6,unsafes3,excs4,maths3,ctls1,_s1,ts6,atomicm8,R2,i56,R3,i1,R4,s19,arbace/j2g/names.aeR0,s77,Names j2g's generated code uses for itself (receivers, imports, temporaries).v16,arbace.j2g.names8,memo-strm12,R5,TR6,L1,V1,R11,R0,s120,f of one string argument, its results kept (j2g's names are asked for again and again,\n  from every thread translating).R2,i60,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names11,munge-name*m8,R5,TR2,i71,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names10,munge-namem10,R6,L1,V1,R12,R0,s76,A Java or Clojure name as a Go identifier fragment: Clojure's munge, $ as _.R2,i79,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names10,local-namem10,R6,L1,V1,R13,R0,s224,The Go name of a Java local or parameter (§4.4): munged, with _ appended when it would be a\n  Go keyword, a predeclared or reserved name, or would start with an upper-case letter (which\n  could shadow a type of the package).R2,i84,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names7,renamesm28,s20,java/text/Annotations15,Text_Annotations32,sun/net/www/protocol/jar/Handlers11,Jar_Handlers19,sun/text/Normalizers14,Sun_Normalizers34,sun/net/www/protocol/https/Handlers13,Https_Handlers34,sun/security/provider/SecureRandoms16,Sun_SecureRandoms14,java/net/Proxys9,Net_Proxys24,java/nio/file/FileSystems14,Nio_FileSystems21,sun/util/calendar/Eras12,Calendar_Eras25,java/util/stream/Tripwires15,Stream_Tripwires13,java/sql/Dates8,Sql_Dates25,sun/net/www/URLConnections17,Www_URLConnections33,sun/net/www/protocol/http/Handlers12,Http_Handlers33,sun/net/www/protocol/file/Handlers12,File_Handlers27,jdk/internal/util/ByteArrays13,Jdk_ByteArraym8,R2,i100,R3,i1,R4,s19,arbace/j2g/names.aeR0,s134,The rename table (§4.4, Collisions): classes whose Go name would collide with another of the\n  closed world's or with jrt's own names.v16,arbace.j2g.names15,compiled-class?m10,R6,L1,V1,Myn8,internalm2,R7,R8,R0,s294,Is class `internal` one of a namespace compiled to Java forms (standalone S6, arbace.c2j):\n  Arbace's but not the runtime's (arbace/lang, the Java API), or one in a package of arbace.c2j's\n  tree outside arbace/ (aot_..., compiled-packages: a user's namespace, bin/diffcheck's\n  corpora; F2.6)?R2,i135,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names20,tool-module-prefixesV19,s15,com/sun/source/s22,com/sun/tools/doclint/s20,com/sun/tools/javac/s20,sun/tools/serialver/s28,javax/annotation/processing/s17,javax/lang/model/s12,javax/tools/s17,jdk/internal/opt/s23,jdk/internal/jrt/javac/s12,build/tools/s19,com/sun/org/apache/s21,com/sun/xml/internal/s10,javax/xml/s17,jdk/xml/internal/s12,org/w3c/dom/s12,org/xml/sax/s18,compileproperties/s17,propertiesparser/s15,flagsgenerator/m8,R2,i146,R3,i1,R4,s19,arbace/j2g/names.aeR0,s1197,The packages of the tool's modules (doc/classes/JAVA-FRONTEND-SURVEY.md, JFS13 (a)): javac's\n  jdk.compiler, java.compiler and jdk.internal.opt's CommandLine (jdk/javac/), and javac's\n  command line on Arbace, jrt's own in jdk.compiler (jdk.internal.jrt.javac, JN3); and since JN7 the\n  JDK build's tools bin/jrt-convert runs on the tool (build.tools) with java.xml's SAX parser\n  (com.sun.org.apache.xerces, com.sun.xml.internal, javax.xml, jdk.xml.internal, org.w3c.dom,\n  org.xml.sax: build.tools.tzdb's interim ZoneRules beside java.time.zone's); and since JFS48 (b)\n  the langtools tools bin/javac-vendor runs on the tool (compileproperties, propertiesparser:\n  make/langtools/tools, which generate jdk.compiler's resource bundles; and since JFS52 (b)\n  flagsgenerator, FlagsEnum). Their classes are\n  named by their whole binary name, Jv_...: their simple names collide with java.base's and with\n  each other's (List, Type, Name, Flow, the two ReturnTrees, the two Scopes), in type names and\n  in the descriptor codes of method names. A rule, not a table: the names do not depend on what\n  else the world holds, and the shipped program, which holds none of these packages, keeps its\n  names.v16,arbace.j2g.names18,qualified-prefixesm8,R2,i168,R3,i1,R4,s19,arbace/j2g/names.aeR0,s132,Package prefixes named as the tool's modules are, beside them (j2g --qualify: a driver's\n  package); set before the world is loaded.v16,arbace.j2g.names10,qualified?m10,R6,L1,V1,Myn8,internalm2,R7,R8,R0,s88,Is class `internal` named by its binary name (tool-module-prefixes, qualified-prefixes)?R2,i173,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names14,go-class-name*m8,R14,TR2,i179,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names13,go-class-namem10,R6,L1,V1,R9,R0,s350,The Go type name of a class: its binary name after the package, $ as _; X prepended when it\n  does not start with an upper-case letter. A compiled namespace's class (S6), in package lang\n  with the runtime's, is named by its whole binary name between A_ and _A (arbace.core.Vec is\n  A_arbace_core_Vec_A, the fn arbace.walk$walk A_arbace_walk_walk_A).R2,i181,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names15,go-class-name**m10,R5,TR6,L1,V1,R9,R2,i189,R3,i1,R4,s19,arbace/j2g/names.aem8,R5,TR2,i202,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names10,capitalizem8,R6,L1,V1,Myn1,sm2,R7,R8,R2,i204,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names12,method-basesm10,R5,TR2,i210,R3,i1,R4,s19,arbace/j2g/names.aeR0,s36,[name desc] -> method-base's answer.v16,arbace.j2g.names9,desc-codem10,R6,L1,V1,R15,R0,s63,The code of a parameter or return descriptor in a mangled name.R2,i214,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names12,method-base*m8,R14,TR2,i225,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names11,method-basem10,R6,L1,V2,R16,R17,R0,s63,The mangled method name without a class prefix: M_P1_..._Pn__R.R2,i227,R3,i1,R4,s19,arbace/j2g/names.aem10,R5,TR6,L1,V2,R16,R17,R2,i237,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names9,ctor-basem10,R6,L1,V1,R17,R0,s100,Ctor_P1_..._Pn, or Ctor; desc is the constructor's full descriptor (implicit parameters\n  included).R2,i243,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names8,new-namem10,R6,L1,V2,R18,R17,R0,s26,C_New_P1_..._Pn, or C_New.R2,i250,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names10,field-namem8,R6,L1,V1,R19,R2,i256,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names17,static-field-namem8,R6,L1,V2,R18,R19,R2,i258,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names18,static-method-namem8,R6,L1,V3,R18,R16,R17,R2,i260,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names9,impl-namem8,R6,L1,V1,R20,R2,i262,R3,i1,R4,s19,arbace/j2g/names.ae")

var Lit_41 *jrt.String = jrt.Intern("arbace.j2g.names$eval1768000004$loading__1927001464__auto____1768000005")

var Lit_42 *jrt.String = jrt.Intern("arbace.j2g.names$eval1768000008$fn__1768000009")

var Lit_43 *jrt.String = jrt.Intern("arbace.j2g.names$top_of")

var Lit_44 *jrt.String = jrt.Intern("arbace.j2g.names$pkg_of")

var Lit_45 *jrt.String = jrt.Intern("arbace.j2g.names$compiled_pkg_QMARK_")

var Lit_46 *jrt.String = jrt.Intern("arbace.j2g.names$pkg_name")

var Lit_47 *jrt.String = jrt.Intern("arbace.j2g.names$pkg_path")

var Lit_48 *jrt.String = jrt.Intern("arbace.j2g.names$pkg_ns")

var Lit_49 *jrt.String = jrt.Intern("arbace.j2g.names$memo_str")

var Lit_50 *jrt.String = jrt.Intern("arbace.j2g.names$fn__1768000021")

var Lit_51 *jrt.String = jrt.Intern("arbace.j2g.names$munge_name")

var Lit_52 *jrt.String = jrt.Intern("arbace.j2g.names$local_name")

var Lit_53 *jrt.String = jrt.Intern("arbace.j2g.names$compiled_class_QMARK_")

var Lit_54 *jrt.String = jrt.Intern("arbace.j2g.names$qualified_QMARK_")

var Lit_55 *jrt.String = jrt.Intern("arbace.j2g.names$go_class_name")

var Lit_56 *jrt.String = jrt.Intern("arbace.j2g.names$go_class_name_STAR__STAR_")

var Lit_57 *jrt.String = jrt.Intern("arbace.j2g.names$capitalize")

var Lit_58 *jrt.String = jrt.Intern("arbace.j2g.names$desc_code")

var Lit_59 *jrt.String = jrt.Intern("arbace.j2g.names$method_base")

var Lit_60 *jrt.String = jrt.Intern("arbace.j2g.names$method_base_STAR_")

var Lit_61 *jrt.String = jrt.Intern("arbace.j2g.names$ctor_base")

var Lit_62 *jrt.String = jrt.Intern("arbace.j2g.names$new_name")

var Lit_63 *jrt.String = jrt.Intern("arbace.j2g.names$field_name")

var Lit_64 *jrt.String = jrt.Intern("arbace.j2g.names$static_field_name")

var Lit_65 *jrt.String = jrt.Intern("arbace.j2g.names$static_method_name")

var Lit_66 *jrt.String = jrt.Intern("arbace.j2g.names$impl_name")
