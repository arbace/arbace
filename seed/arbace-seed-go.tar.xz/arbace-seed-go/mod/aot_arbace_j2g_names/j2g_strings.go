//line j2g_strings.ae:1
package aot_arbace_j2g_names

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn20,arbace.classes.typesyn1,tyn11,arbace.corekn3,dockn3,jrtkn4,elsekn4,langv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,v11,arbace.core5,referR5,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn16,arbace.j2g.namesm2,R6,s251,j2g's names (doc/go/J2G-SPEC.md §4.2, §4.4): Go packages of Java classes, Go identifiers of\n  classes, members and locals, the descriptor codes of mangled method names, and the Go type of\n  a Java type (§5.1) given the class facts of the closed world.v11,arbace.core4,subsl0,v13,arbace.string12,starts-with?R7,R8,v16,arbace.j2g.names17,compiled-packagesv16,arbace.j2g.names6,top-ofv11,arbace.core7,keywordR9,v11,arbace.core3,notS2,R7,R9,v11,arbace.core4,namev13,arbace.string7,replacev11,arbace.core3,strv11,arbace.core5,mungev11,arbace.core5,applyv11,arbace.core3,mapc95,v16,arbace.j2g.names11,munge-name*v16,arbace.j2g.names10,munge-namev13,arbace.string6,blank?v16,arbace.j2g.names11,go-keywordsv16,arbace.j2g.names14,go-predeclaredv16,arbace.j2g.names15,reserved-localsv11,arbace.core10,re-matchesp8,tmp\\d+.*p7,[lL]\\d+v11,arbace.core4,somev16,arbace.j2g.names20,tool-module-prefixesv16,arbace.j2g.names18,qualified-prefixesv16,arbace.j2g.names6,pkg-ofv11,arbace.core4,not=v16,arbace.j2g.names15,compiled-class?v16,arbace.j2g.names10,qualified?v16,arbace.j2g.names14,go-class-name*v16,arbace.j2g.names7,renamesv16,arbace.j2g.names11,user-class?v11,arbace.core3,seqv11,arbace.core6,empty?l1,v20,arbace.classes.types6,array?v20,arbace.classes.types10,array-dimsv16,arbace.j2g.names9,desc-codev20,arbace.classes.types11,class-desc?v16,arbace.j2g.names13,go-class-namev20,arbace.classes.types14,desc->internalv16,arbace.j2g.names12,method-basesv16,arbace.j2g.names12,method-base*v20,arbace.classes.types17,parse-method-descv16,arbace.j2g.names10,capitalizev16,arbace.j2g.names14,derived-suffixp6,(_f)+$v16,arbace.j2g.names15,reserved-memberv16,arbace.j2g.names11,method-base")

var Lit_1 *jrt.String = jrt.Intern("arbace/")

var Lit_2 *jrt.String = jrt.Intern("arbace/lang/")

var Lit_3 *jrt.String = jrt.Intern("arbace/java/api/")

var Lit_4 *jrt.String = jrt.Intern("aot_")

var Lit_5 *jrt.String = jrt.Intern("Ctor")

var Lit_6 *jrt.String = jrt.Intern("arbace.j2g.names$ctor_base$fn__1768000053")

var Lit_7 *jrt.String = jrt.Intern("_")

var Lit_8 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_9 *jrt.String = jrt.Intern("O")

var Lit_10 *jrt.String = jrt.Intern("F_")

var Lit_11 *jrt.String = jrt.Intern("$")

var Lit_12 *jrt.String = jrt.Intern("arbace.j2g.names$fn__1768000021$fn__1768000022")

var Lit_13 *jrt.String = jrt.Intern("Jv_")

var Lit_14 *jrt.String = jrt.Intern("/")

var Lit_15 *jrt.String = jrt.Intern("J_")

var Lit_16 *jrt.String = jrt.Intern("_J")

var Lit_17 *jrt.String = jrt.Intern("A_")

var Lit_18 *jrt.String = jrt.Intern("_A")

var Lit_19 *jrt.String = jrt.Intern("X")

var Lit_20 *jrt.String = jrt.Intern("Impl_")

var Lit_21 *jrt.String = jrt.Intern("x")

var Lit_22 *jrt.String = jrt.Intern("j2g_")

var Lit_23 *jrt.String = jrt.Intern("arbace.j2g.names$memo_str$fn__1768000018")

var Lit_24 *jrt.String = jrt.Intern("__")

var Lit_25 *jrt.String = jrt.Intern("arbace.j2g.names$method_base_STAR_$fn__1768000046")

var Lit_26 *jrt.String = jrt.Intern("_New")

var Lit_27 *jrt.String = jrt.Intern("arbace.j2g.names$new_name$fn__1768000060")

var Lit_28 *jrt.String = jrt.Intern("go.arbace.")

var Lit_29 *jrt.String = jrt.Intern("java/")

var Lit_30 *jrt.String = jrt.Intern("jdk/")

var Lit_31 *jrt.String = jrt.Intern("sun/")

var Lit_32 *jrt.String = jrt.Intern("javax/")

var Lit_33 *jrt.String = jrt.Intern("com/sun/")

var Lit_34 *jrt.String = jrt.Intern("org/xml/")

var Lit_35 *jrt.String = jrt.Intern("org/w3c/")

var Lit_36 *jrt.String = jrt.Intern("build/tools/")

var Lit_37 *jrt.String = jrt.Intern("compileproperties/")

var Lit_38 *jrt.String = jrt.Intern("propertiesparser/")

var Lit_39 *jrt.String = jrt.Intern("flagsgenerator/")

var Lit_40 *jrt.String = jrt.Intern("arbace.j2g.names$qualified_QMARK_$fn__1768000030")

var Lit_41 *jrt.String = jrt.Intern("arbace.j2g.names$qualified_QMARK_$fn__1768000032")

var Lit_42 *jrt.String = jrt.Intern("")

var Lit_43 *jrt.String = jrt.Intern("_f")

var Lit_44 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn4,linekn6,columnkn4,filekn7,privatekn8,arglistskn3,tagyn6,Stringyn8,internalyn3,pkgyn1,fyn1,syn3,symkn8,declaredyn1,dyn4,nameyn4,descyn6,cls-goyn5,fnameyn5,mbasev11,arbace.core5,in-nsMyn16,arbace.j2g.namesm2,R0,s251,j2g's names (doc/go/J2G-SPEC.md §4.2, §4.4): Go packages of Java classes, Go identifiers of\n  classes, members and locals, the descriptor codes of mangled method names, and the Go type of\n  a Java type (§5.1) given the class facts of the closed world.m2,R0,s251,j2g's names (doc/go/J2G-SPEC.md §4.2, §4.4): Go packages of Java classes, Go identifiers of\n  classes, members and locals, the descriptor codes of mangled method names, and the Go type of\n  a Java type (§5.1) given the class facts of the closed world.R1,v16,arbace.j2g.names17,compiled-packagesv11,arbace.core4,atomm8,R2,i11,R3,i1,R4,s19,arbace/j2g/names.aeR0,s227,The Go packages of compiled namespaces' classes (standalone S6, SA142): top-level class\n  (internal name) → package name, from the packages.edn of the inputs (arbace.c2j's tree);\n  set once by j2g's run, before any translation.v16,arbace.j2g.names6,top-ofm10,R5,TR6,L1,V1,Myn1,nm2,R7,R8,R2,i17,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names6,pkg-ofm10,R6,L1,V1,R9,R0,s515,The Go package of a class (internal name): :jrt for the JDK's packages (java, javax, jdk,\n  sun, and com.sun since the SunJCE provider: amendment SC3; org.xml and org.w3c, java.xml's, and\n  build.tools, the JDK build's tools, in javac's tool build since JN7; compileproperties and\n  propertiesparser, the JDK build's langtools tools, since JFS48 (b), and flagsgenerator, the third\n  of them, since JFS52 (b)), a compiled namespace's own\n  (compiled-packages: a keyword of its package name), else :lang for Arbace's.R2,i19,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names13,compiled-pkg?m8,R6,L1,V1,R10,R2,i36,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names8,pkg-namem8,R6,L1,V1,R10,R2,i38,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names8,pkg-pathm8,R6,L1,V1,R10,R2,i39,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names6,pkg-nsm8,R6,L1,V1,R10,R2,i40,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names11,go-keywordsS25,s4,elses4,funcs3,maps5,ranges4,chans7,packages9,interfaces5,defers3,vars6,returns3,fors11,fallthroughs2,ifs6,imports2,gos6,switchs5,consts6,selects4,cases5,breaks8,continues4,types6,structs7,defaults4,gotom6,R2,i45,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names14,go-predeclaredS44,s5,int16s7,recovers3,ints3,mins5,panics10,comparables6,strings4,runes7,float32s4,copys7,float64s4,uints5,int32s6,uint16s6,deletes7,uintptrs6,uint32s5,int64s4,iotas3,maxs3,news5,errors4,imags10,complex128s3,anys5,falses4,reals6,uint64s4,makes7,printlns4,bools5,uint8s4,trues5,closes4,int8s6,appends5,prints3,lens5,clears3,nils3,caps7,complexs9,complex64s4,bytem6,R2,i50,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names15,reserved-localsS12,s4,langs4,thiss2,rvs3,jrts7,reflects6,unsafes3,excs4,maths3,ctls1,_s1,ts6,atomicm8,R2,i56,R3,i1,R4,s19,arbace/j2g/names.aeR0,s77,Names j2g's generated code uses for itself (receivers, imports, temporaries).v16,arbace.j2g.names8,memo-strm12,R5,TR6,L1,V1,R11,R0,s120,f of one string argument, its results kept (j2g's names are asked for again and again,\n  from every thread translating).R2,i60,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names11,munge-name*m8,R5,TR2,i71,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names10,munge-namem10,R6,L1,V1,R12,R0,s76,A Java or Clojure name as a Go identifier fragment: Clojure's munge, $ as _.R2,i79,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names10,local-namem10,R6,L1,V1,R13,R0,s224,The Go name of a Java local or parameter (§4.4): munged, with _ appended when it would be a\n  Go keyword, a predeclared or reserved name, or would start with an upper-case letter (which\n  could shadow a type of the package).R2,i84,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names7,renamesm220,s38,sun/net/httpserver/ChunkedOutputStreams22,Hs_ChunkedOutputStreams20,java/text/Annotations15,Text_Annotations25,sun/nio/fs/UnixFileSystems17,Fs_UnixFileSystems24,sun/net/httpserver/Utilss8,Hs_Utilss23,sun/security/util/Events10,Util_Events32,sun/net/www/protocol/jar/Handlers11,Jar_Handlers25,java/security/Certificates20,Security_Certificates45,java/lang/classfile/constantpool/ConstantPools22,Classfile_ConstantPools48,javax/management/loading/DefaultLoaderRepositorys35,Jmx_Loading_DefaultLoaderRepositorys30,java/lang/classfile/Attributess20,Classfile_Attributess22,java/net/Authenticators17,Net_Authenticators38,jdk/internal/classfile/impl/MethodInfos20,Classfile_MethodInfos35,javax/security/cert/X509Certificates25,JavaxCert_X509Certificates38,com/sun/security/sasl/ntlm/FactoryImpls16,Ntlm_FactoryImpls48,javax/security/cert/CertificateEncodingExceptions38,JavaxCert_CertificateEncodingExceptions34,jdk/internal/classfile/impl/Util$1s16,Classfile_Util_1s24,sun/rmi/transport/Targets10,Rmi_Targets26,sun/net/httpserver/Requests10,Hs_Requests37,sun/net/httpserver/ChunkedInputStreams21,Hs_ChunkedInputStreams38,jdk/internal/net/http/hpack/ISO_8859_1s13,Hc_ISO_8859_1s32,jdk/internal/classfile/impl/Utils14,Classfile_Utils19,sun/text/Normalizers14,Sun_Normalizers29,java/rmi/UnknownHostExceptions24,Rmi_UnknownHostExceptions28,sun/rmi/transport/Connections14,Rmi_Connections26,javax/management/Attributes13,Jmx_Attributes51,javax/security/cert/CertificateNotYetValidExceptions41,JavaxCert_CertificateNotYetValidExceptions34,sun/security/provider/DSAPublicKeys16,Sun_DSAPublicKeys47,javax/security/cert/CertificateParsingExceptions37,JavaxCert_CertificateParsingExceptions15,sun/nio/ch/Utils7,Ch_Utils22,javax/naming/References16,Naming_References41,jdk/internal/net/http/websocket/Transports12,Hc_Transports47,com/sun/crypto/provider/EncryptedPrivateKeyInfos27,Jce_EncryptedPrivateKeyInfos29,java/lang/classfile/Signatures19,Classfile_Signatures33,javax/naming/directory/Attributess17,Naming_Attributess29,jdk/net/ExtendedSocketOptionss25,Net_ExtendedSocketOptionss13,java/time/Sers8,Time_Sers34,sun/net/www/protocol/https/Handlers13,Https_Handlers34,sun/security/provider/SecureRandoms16,Sun_SecureRandoms40,jdk/internal/net/http/hpack/StringReaders15,Hc_StringReaders29,java/lang/classfile/Attributes19,Classfile_Attributes37,java/nio/file/attribute/UserPrincipals17,Nio_UserPrincipals40,com/sun/security/sasl/digest/FactoryImpls18,Digest_FactoryImpls36,jdk/internal/net/http/HttpConnections17,Hc_HttpConnections18,sun/nio/ch/Streamss10,Ch_Streamss41,sun/security/pkcs/EncryptedPrivateKeyInfos28,Pkcs_EncryptedPrivateKeyInfos40,jdk/internal/net/http/hpack/StringWriters15,Hc_StringWriters29,com/sun/net/httpserver/Filters9,Hs_Filters36,com/sun/crypto/provider/DHPrivateKeys16,Jce_DHPrivateKeys20,java/time/chrono/Sers10,Chrono_Sers35,com/sun/crypto/provider/DHPublicKeys15,Jce_DHPublicKeys49,jdk/internal/net/http/HeaderParser$ParserIterators30,Hc_HeaderParser_ParserIterators24,sun/net/httpserver/Events8,Hs_Events40,com/sun/management/OperatingSystemMXBeans25,Sun_OperatingSystemMXBeans36,com/sun/crypto/provider/KeyProtectors16,Jce_KeyProtectors40,javax/security/cert/CertificateExceptions30,JavaxCert_CertificateExceptions30,java/lang/classfile/Annotations20,Classfile_Annotations28,javax/management/timer/Timers9,Jmx_Timers25,sun/rmi/transport/Channels11,Rmi_Channels27,java/util/logging/Formatters17,Logging_Formatters27,sun/nio/cs/StandardCharsetss19,Cs_StandardCharsetss47,javax/security/cert/CertificateExpiredExceptions37,JavaxCert_CertificateExpiredExceptions28,java/security/cert/Extensions14,Cert_Extensions14,java/net/Proxys9,Net_Proxys29,sun/security/ssl/RSASignatures16,Ssl_RSASignatures24,java/nio/file/FileSystems14,Nio_FileSystems31,javax/security/cert/Certificates21,JavaxCert_Certificates35,sun/security/provider/DSAPrivateKeys17,Sun_DSAPrivateKeys31,com/sun/management/ThreadMXBeans16,Sun_ThreadMXBeans23,sun/invoke/util/Wrappers14,Invoke_Wrappers36,com/sun/net/httpserver/Authenticators16,Hs_Authenticators21,sun/util/calendar/Eras12,Calendar_Eras29,java/rmi/server/LoaderHandlers17,Rmi_LoaderHandlers25,java/util/stream/Tripwires15,Stream_Tripwires13,java/sql/Dates8,Sql_Dates14,java/awt/Points9,Awt_Points15,sun/nio/fs/Utils7,Fs_Utils25,java/rmi/ConnectExceptions20,Rmi_ConnectExceptions25,sun/net/www/URLConnections17,Www_URLConnections34,jdk/internal/net/http/common/Utilss8,Hc_Utilss35,jdk/internal/net/http/common/Loggers9,Hc_Loggers41,sun/net/www/protocol/jar/JarURLConnections20,Jar_JarURLConnections33,sun/net/www/protocol/http/Handlers12,Http_Handlers32,jdk/internal/net/http/common/Logs6,Hc_Logs30,java/rmi/AlreadyBoundExceptions25,Rmi_AlreadyBoundExceptions34,jdk/internal/net/http/HeaderParsers15,Hc_HeaderParsers34,java/lang/classfile/TypeAnnotations24,Classfile_TypeAnnotations19,sun/rmi/server/Utils8,Rmi_Utils24,java/net/http/HttpClients13,Hc_HttpClients22,sun/nio/cs/StringUTF16s14,Cs_StringUTF16s30,com/sun/security/sasl/Providers13,Sasl_Providers32,sun/net/www/protocol/ftp/Handlers11,Ftp_Handlers33,sun/net/www/protocol/file/Handlers12,File_Handlers27,jdk/internal/util/ByteArrays13,Jdk_ByteArrays38,com/sun/security/auth/login/ConfigFiles15,Auth_ConfigFiles26,sun/net/ftp/impl/FtpClients17,FtpImpl_FtpClients43,sun/net/www/protocol/http/HttpURLConnections22,Http_HttpURLConnections34,jdk/internal/net/http/ExchangeImpls15,Hc_ExchangeImpls40,sun/reflect/generics/tree/ClassSignatures23,Generics_ClassSignatures41,sun/security/provider/DSAKeyPairGenerators23,Sun_DSAKeyPairGenerators23,java/security/Timestamps18,Security_Timestamps14,java/sql/Arrays9,Sql_Arrays23,sun/security/ssl/Records10,Ssl_Records46,javax/management/openmbean/InvalidKeyExceptions23,Jmx_InvalidKeyExceptions35,sun/reflect/generics/tree/Signatures18,Generics_Signatures30,com/sun/crypto/provider/PBEKeys10,Jce_PBEKeys27,sun/security/x509/Extensions14,X509_Extensions28,jdk/internal/net/http/Streams9,Hc_Streams35,sun/net/www/protocol/mailto/Handlers14,Mailto_Handlers28,com/sun/jmx/mbeanserver/Utils8,Jmx_Utils34,javax/crypto/PermissionsEnumerators28,Crypto_PermissionsEnumeratorm8,R2,i100,R3,i1,R4,s19,arbace/j2g/names.aeR0,s134,The rename table (§4.4, Collisions): classes whose Go name would collide with another of the\n  closed world's or with jrt's own names.v16,arbace.j2g.names15,compiled-class?m10,R6,L1,V1,Myn8,internalm2,R7,R8,R0,s294,Is class `internal` one of a namespace compiled to Java forms (standalone S6, arbace.c2j):\n  Arbace's but not the runtime's (arbace/lang, the Java API), or one in a package of arbace.c2j's\n  tree outside arbace/ (aot_..., compiled-packages: a user's namespace, bin/diffcheck's\n  corpora; F2.6)?R2,i294,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names20,tool-module-prefixesV19,s15,com/sun/source/s22,com/sun/tools/doclint/s20,com/sun/tools/javac/s20,sun/tools/serialver/s28,javax/annotation/processing/s17,javax/lang/model/s12,javax/tools/s17,jdk/internal/opt/s23,jdk/internal/jrt/javac/s12,build/tools/s19,com/sun/org/apache/s21,com/sun/xml/internal/s10,javax/xml/s17,jdk/xml/internal/s12,org/w3c/dom/s12,org/xml/sax/s18,compileproperties/s17,propertiesparser/s15,flagsgenerator/m8,R2,i305,R3,i1,R4,s19,arbace/j2g/names.aeR0,s1197,The packages of the tool's modules (doc/classes/JAVA-FRONTEND-SURVEY.md, JFS13 (a)): javac's\n  jdk.compiler, java.compiler and jdk.internal.opt's CommandLine (jdk/javac/), and javac's\n  command line on Arbace, jrt's own in jdk.compiler (jdk.internal.jrt.javac, JN3); and since JN7 the\n  JDK build's tools bin/jrt-convert runs on the tool (build.tools) with java.xml's SAX parser\n  (com.sun.org.apache.xerces, com.sun.xml.internal, javax.xml, jdk.xml.internal, org.w3c.dom,\n  org.xml.sax: build.tools.tzdb's interim ZoneRules beside java.time.zone's); and since JFS48 (b)\n  the langtools tools bin/javac-vendor runs on the tool (compileproperties, propertiesparser:\n  make/langtools/tools, which generate jdk.compiler's resource bundles; and since JFS52 (b)\n  flagsgenerator, FlagsEnum). Their classes are\n  named by their whole binary name, Jv_...: their simple names collide with java.base's and with\n  each other's (List, Type, Name, Flow, the two ReturnTrees, the two Scopes), in type names and\n  in the descriptor codes of method names. A rule, not a table: the names do not depend on what\n  else the world holds, and the shipped program, which holds none of these packages, keeps its\n  names.v16,arbace.j2g.names18,qualified-prefixesm8,R2,i327,R3,i1,R4,s19,arbace/j2g/names.aeR0,s132,Package prefixes named as the tool's modules are, beside them (j2g --qualify: a driver's\n  package); set before the world is loaded.v16,arbace.j2g.names10,qualified?m10,R6,L1,V1,Myn8,internalm2,R7,R8,R0,s88,Is class `internal` named by its binary name (tool-module-prefixes, qualified-prefixes)?R2,i332,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names11,user-class?m10,R6,L1,V1,Myn8,internalm2,R7,R8,R0,s571,Is class `internal` outside Arbace's runtime and the JDK (doc/classes/JAVA-CONFORMANCE-SURVEY.md,\n  JCS15 (a), JC2): a class of package lang (pkg-of) that is not Arbace's (arbace/...): a user's Java\n  forms, the conformance check's tests, diffcheck's corpora, the fixtures. Such classes are named by\n  their binary name between J_ and _J, as compiled classes are between A_ and _A, and so are their Go files\n  (out/go-file-name): two packages' Basics, or SuperClass and Superclass, never meet in lang, in\n  type names, descriptor codes or (case-insensitively) file names.R2,i338,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names10,own-class?m10,R6,L1,V1,Myn8,internalm2,R7,R8,R0,s387,Is class `internal` a program's own Java forms (doc/classes/JAVA-CONFORMANCE-SURVEY.md, JCS117\n  (a), \"As built: JC4c\"): neither the JDK's (pkg-of :jrt), nor Arbace's (arbace/...), nor a namespace's\n  compiled by arbace.c2j (compiled-class?), nor the tool's (qualified?): a user's (user-class?), the\n  conformance check's tests, bin/diffcheck's Java forms in their own packages (jf_...)?R2,i348,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names14,go-class-name*m8,R14,TR2,i357,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names13,go-class-namem10,R6,L1,V1,R9,R0,s545,The Go type name of a class: its binary name after the package, $ as _; X prepended when it\n  does not start with an upper-case letter. A class of the tool's modules (qualified?) is named by\n  its whole binary name after Jv_, one outside the runtime and the JDK (user-class?, JCS15 (a))\n  between J_ and _J (p.Main is J_p_Main_J). A compiled namespace's class (S6), in package lang\n  with the runtime's, is named by its whole binary name between A_ and _A (arbace.core.Vec is\n  A_arbace_core_Vec_A, the fn arbace.walk$walk A_arbace_walk_walk_A).R2,i359,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names15,go-class-name**m10,R5,TR6,L1,V1,R9,R2,i369,R3,i1,R4,s19,arbace/j2g/names.aem8,R5,TR2,i386,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names10,capitalizem8,R6,L1,V1,Myn1,sm2,R7,R8,R2,i388,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names12,method-basesm10,R5,TR2,i394,R3,i1,R4,s19,arbace/j2g/names.aeR0,s36,[name desc] -> method-base's answer.v16,arbace.j2g.names9,desc-codem10,R6,L1,V1,R15,R0,s63,The code of a parameter or return descriptor in a mangled name.R2,i398,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names12,method-base*m8,R14,TR2,i409,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names11,method-basem10,R6,L1,V2,R16,R17,R0,s63,The mangled method name without a class prefix: M_P1_..._Pn__R.R2,i411,R3,i1,R4,s19,arbace/j2g/names.aem10,R5,TR6,L1,V2,R16,R17,R2,i421,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names9,ctor-basem10,R6,L1,V1,R17,R0,s100,Ctor_P1_..._Pn, or Ctor; desc is the constructor's full descriptor (implicit parameters\n  included).R2,i427,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names8,new-namem10,R6,L1,V2,R18,R17,R0,s26,C_New_P1_..._Pn, or C_New.R2,i434,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names10,field-namem8,R6,L1,V1,R19,R2,i440,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names14,derived-suffixp81,class|Init|init|clinit|clinit_p\\d+|I|InstanceOf|Cast|members|New(_\\w*)?|Fn(_\\w*)?m10,R5,TR2,i442,R3,i1,R4,s19,arbace/j2g/names.aeR0,s282,The suffixes j2g derives package members of a class C from (§4.4's package members): C_class,\n  C_Init and its state C_init, C_clinit and its parts C_clinit_pK, C_I, C_InstanceOf, C_Cast,\n  C_members, C_New..., C_Fn... (an enum's C__VALUES is its field $VALUES, not a derived name).v16,arbace.j2g.names15,reserved-memberm10,R6,L1,V1,Myn1,sm2,R7,R8,R0,s458,A static member's munged name as its Go name's suffix: with _f appended when it would be (after\n  any _f marks of its own, which a field init_f has) one j2g derives (derived-suffix), as locals get\n  _ (§4.4; doc/classes/JAVA-CONFORMANCE-SURVEY.md, JCS43 (a), \"As built: JC2b\": a static field\n  init beside the class's initialization state C_init). Methods' names never need it: theirs hold\n  the descriptor's __ and return code, which no derived suffix does.R2,i448,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names17,static-field-namem8,R6,L1,V2,R18,R19,R2,i457,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names18,static-method-namem8,R6,L1,V3,R18,R16,R17,R2,i459,R3,i1,R4,s19,arbace/j2g/names.aev16,arbace.j2g.names9,impl-namem8,R6,L1,V1,R20,R2,i461,R3,i1,R4,s19,arbace/j2g/names.ae")

var Lit_45 *jrt.String = jrt.Intern("arbace.j2g.names$eval1768000004$loading__1927001464__auto____1768000005")

var Lit_46 *jrt.String = jrt.Intern("arbace.j2g.names$eval1768000008$fn__1768000009")

var Lit_47 *jrt.String = jrt.Intern("arbace.j2g.names$top_of")

var Lit_48 *jrt.String = jrt.Intern("arbace.j2g.names$pkg_of")

var Lit_49 *jrt.String = jrt.Intern("arbace.j2g.names$compiled_pkg_QMARK_")

var Lit_50 *jrt.String = jrt.Intern("arbace.j2g.names$pkg_name")

var Lit_51 *jrt.String = jrt.Intern("arbace.j2g.names$pkg_path")

var Lit_52 *jrt.String = jrt.Intern("arbace.j2g.names$pkg_ns")

var Lit_53 *jrt.String = jrt.Intern("arbace.j2g.names$memo_str")

var Lit_54 *jrt.String = jrt.Intern("arbace.j2g.names$fn__1768000021")

var Lit_55 *jrt.String = jrt.Intern("arbace.j2g.names$munge_name")

var Lit_56 *jrt.String = jrt.Intern("arbace.j2g.names$local_name")

var Lit_57 *jrt.String = jrt.Intern("arbace.j2g.names$compiled_class_QMARK_")

var Lit_58 *jrt.String = jrt.Intern("arbace.j2g.names$qualified_QMARK_")

var Lit_59 *jrt.String = jrt.Intern("arbace.j2g.names$user_class_QMARK_")

var Lit_60 *jrt.String = jrt.Intern("arbace.j2g.names$own_class_QMARK_")

var Lit_61 *jrt.String = jrt.Intern("arbace.j2g.names$go_class_name")

var Lit_62 *jrt.String = jrt.Intern("arbace.j2g.names$go_class_name_STAR__STAR_")

var Lit_63 *jrt.String = jrt.Intern("arbace.j2g.names$capitalize")

var Lit_64 *jrt.String = jrt.Intern("arbace.j2g.names$desc_code")

var Lit_65 *jrt.String = jrt.Intern("arbace.j2g.names$method_base")

var Lit_66 *jrt.String = jrt.Intern("arbace.j2g.names$method_base_STAR_")

var Lit_67 *jrt.String = jrt.Intern("arbace.j2g.names$ctor_base")

var Lit_68 *jrt.String = jrt.Intern("arbace.j2g.names$new_name")

var Lit_69 *jrt.String = jrt.Intern("arbace.j2g.names$field_name")

var Lit_70 *jrt.String = jrt.Intern("arbace.j2g.names$reserved_member")

var Lit_71 *jrt.String = jrt.Intern("arbace.j2g.names$static_field_name")

var Lit_72 *jrt.String = jrt.Intern("arbace.j2g.names$static_method_name")

var Lit_73 *jrt.String = jrt.Intern("arbace.j2g.names$impl_name")
