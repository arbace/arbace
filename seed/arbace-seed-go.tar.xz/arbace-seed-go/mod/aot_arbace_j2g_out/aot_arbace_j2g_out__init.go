//line aot_arbace_j2g_out__init.ae:1
package aot_arbace_j2g_out

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_out__init_A_Unit0__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_j2g_out__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_out__init_A_const_1) }
//line :1:1
func A_arbace_j2g_out__init_A_Unit1__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_j2g_out__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_2)) }
//line :1:1
func A_arbace_j2g_out__init_A_Unit2__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_j2g_out_eval34000004_loading__1927001464__auto____34000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_j2g_out_eval34000004_loading__1927001464__auto____34000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_501, false, nil); A_arbace_j2g_out_eval34000004_loading__1927001464__auto____34000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_j2g_out__init_A_Unit3__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_j2g_out__init_A_const_1)).Equals_O__Z(A_arbace_j2g_out__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_j2g_out_eval34000008_fn__34000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_j2g_out_eval34000008_fn__34000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_502, false, nil); A_arbace_j2g_out_eval34000008_fn__34000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_j2g_out__init_A_Load__O() any { A_arbace_j2g_out__init_A_Init(); jrt.StartCheck(); A_arbace_j2g_out__init_A_Unit0__O(); A_arbace_j2g_out__init_A_Unit1__O(); A_arbace_j2g_out__init_A_Unit2__O(); A_arbace_j2g_out__init_A_Unit3__O(); A_arbace_j2g_out__init_A_Unit4__O(); A_arbace_j2g_out__init_A_Unit5__O(); A_arbace_j2g_out__init_A_Unit6__O(); A_arbace_j2g_out__init_A_Unit7__O(); A_arbace_j2g_out__init_A_Unit8__O(); A_arbace_j2g_out__init_A_Unit9__O(); A_arbace_j2g_out__init_A_Unit10__O(); A_arbace_j2g_out__init_A_Unit11__O(); A_arbace_j2g_out__init_A_Unit12__O(); A_arbace_j2g_out__init_A_Unit13__O(); A_arbace_j2g_out__init_A_Unit14__O(); A_arbace_j2g_out__init_A_Unit15__O(); A_arbace_j2g_out__init_A_Unit16__O(); A_arbace_j2g_out__init_A_Unit17__O(); A_arbace_j2g_out__init_A_Unit18__O(); A_arbace_j2g_out__init_A_Unit19__O(); A_arbace_j2g_out__init_A_Unit20__O(); A_arbace_j2g_out__init_A_Unit21__O(); A_arbace_j2g_out__init_A_Unit22__O(); A_arbace_j2g_out__init_A_Unit23__O(); A_arbace_j2g_out__init_A_Unit24__O(); A_arbace_j2g_out__init_A_Unit25__O(); A_arbace_j2g_out__init_A_Unit26__O(); A_arbace_j2g_out__init_A_Unit27__O(); A_arbace_j2g_out__init_A_Unit28__O(); A_arbace_j2g_out__init_A_Unit29__O(); A_arbace_j2g_out__init_A_Unit30__O(); A_arbace_j2g_out__init_A_Unit31__O(); A_arbace_j2g_out__init_A_Unit32__O(); A_arbace_j2g_out__init_A_Unit33__O(); A_arbace_j2g_out__init_A_Unit34__O(); A_arbace_j2g_out__init_A_Unit35__O(); A_arbace_j2g_out__init_A_Unit36__O(); A_arbace_j2g_out__init_A_Unit37__O(); A_arbace_j2g_out__init_A_Unit38__O(); A_arbace_j2g_out__init_A_Unit39__O(); A_arbace_j2g_out__init_A_Unit40__O(); A_arbace_j2g_out__init_A_Unit41__O(); A_arbace_j2g_out__init_A_Unit42__O(); A_arbace_j2g_out__init_A_Unit43__O(); A_arbace_j2g_out__init_A_Unit44__O(); A_arbace_j2g_out__init_A_Unit45__O(); A_arbace_j2g_out__init_A_Unit46__O(); A_arbace_j2g_out__init_A_Unit47__O(); A_arbace_j2g_out__init_A_Unit48__O(); A_arbace_j2g_out__init_A_Unit49__O(); A_arbace_j2g_out__init_A_Unit50__O(); A_arbace_j2g_out__init_A_Unit51__O(); A_arbace_j2g_out__init_A_Unit52__O(); A_arbace_j2g_out__init_A_Unit53__O(); A_arbace_j2g_out__init_A_Unit54__O(); A_arbace_j2g_out__init_A_Unit55__O(); A_arbace_j2g_out__init_A_Unit56__O(); A_arbace_j2g_out__init_A_Unit57__O(); A_arbace_j2g_out__init_A_Unit58__O(); A_arbace_j2g_out__init_A_Unit59__O(); A_arbace_j2g_out__init_A_Unit60__O(); A_arbace_j2g_out__init_A_Unit61__O(); A_arbace_j2g_out__init_A_Unit62__O(); A_arbace_j2g_out__init_A_Unit63__O(); A_arbace_j2g_out__init_A_Unit64__O(); A_arbace_j2g_out__init_A_Unit65__O(); A_arbace_j2g_out__init_A_Unit66__O(); return nil }














func A_arbace_j2g_out__init_A_Unit4__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(20, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_j2g_out_tag_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_j2g_out_tag_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_503, false, nil); A_arbace_j2g_out_tag_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_5)); return A_arbace_j2g_out__init_A_const_4 }




func A_arbace_j2g_out__init_A_Unit5__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(25, 1); A_arbace_j2g_out__init_A_const_6.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_7)); return A_arbace_j2g_out__init_A_const_6.SetDynamic_Z__Var(true).Ref() }





func A_arbace_j2g_out__init_A_Unit6__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(31, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_j2g_out_clean_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_j2g_out_clean_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_504, false, nil); A_arbace_j2g_out_clean_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_9)); return A_arbace_j2g_out__init_A_const_8 }
















func A_arbace_j2g_out__init_A_Unit7__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_11)); return A_arbace_j2g_out__init_A_const_10 }









func A_arbace_j2g_out__init_A_Unit8__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(58, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_j2g_out_newlines_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_j2g_out_newlines_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_505, false, nil); A_arbace_j2g_out_newlines_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_13)); return A_arbace_j2g_out__init_A_const_12 }





func A_arbace_j2g_out__init_A_Unit9__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(64, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_j2g_out_out_BANG__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_j2g_out_out_BANG__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_506, false, nil); A_arbace_j2g_out_out_BANG__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_15)); return A_arbace_j2g_out__init_A_const_14 }





func A_arbace_j2g_out__init_A_Unit10__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(70, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_j2g_out_write_meta_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_j2g_out_write_meta_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_507, false, nil); A_arbace_j2g_out_write_meta_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_17)); return A_arbace_j2g_out__init_A_const_16 }







func A_arbace_j2g_out__init_A_Unit11__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(78, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_j2g_out_write_items_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_j2g_out_write_items_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_508, false, nil); A_arbace_j2g_out_write_items_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_19)); return A_arbace_j2g_out__init_A_const_18 }






func A_arbace_j2g_out__init_A_Unit12__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(85, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_j2g_out_write_list_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_j2g_out_write_list_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_509, false, nil); A_arbace_j2g_out_write_list_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_21)); return A_arbace_j2g_out__init_A_const_20 }















func A_arbace_j2g_out__init_A_Unit13__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_j2g_out_write_form_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_j2g_out_write_form_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_510, false, nil); A_arbace_j2g_out_write_form_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_22)); return A_arbace_j2g_out__init_A_const_10 }


















func A_arbace_j2g_out__init_A_Unit14__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(120, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_23; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_j2g_out_form_text_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_j2g_out_form_text_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_511, false, nil); A_arbace_j2g_out_form_text_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_24)); return A_arbace_j2g_out__init_A_const_23 }




func A_arbace_j2g_out__init_A_Unit15__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(125, 1); A_arbace_j2g_out__init_A_const_25.BindRoot_O__V(A_arbace_j2g_out__init_A_const_26); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_25; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_27)); return A_arbace_j2g_out__init_A_const_25 }




func A_arbace_j2g_out__init_A_Unit16__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(130, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_28; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_j2g_out_used_qualifiers_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_j2g_out_used_qualifiers_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_512, false, nil); A_arbace_j2g_out_used_qualifiers_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_29)); return A_arbace_j2g_out__init_A_const_28 }












func A_arbace_j2g_out__init_A_Unit17__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(143, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_j2g_out_lined_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_j2g_out_lined_QMARK__A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_513, false, nil); A_arbace_j2g_out_lined_QMARK__A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_31)); return A_arbace_j2g_out__init_A_const_30 }










func A_arbace_j2g_out__init_A_Unit18__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(154, 1); A_arbace_j2g_out__init_A_const_32.BindRoot_O__V(A_arbace_j2g_out__init_A_const_33); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_32; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_34)); return A_arbace_j2g_out__init_A_const_32 }




func A_arbace_j2g_out__init_A_Unit19__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(159, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_35; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_j2g_out_unlined_texts_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_j2g_out_unlined_texts_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_514, false, nil); A_arbace_j2g_out_unlined_texts_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_36)); return A_arbace_j2g_out__init_A_const_35 }















func A_arbace_j2g_out__init_A_Unit20__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(175, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_37; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__30 any = A_arbace_j2g_out_file_text_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_j2g_out_file_text_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_515, true, nil); A_arbace_j2g_out_file_text_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__30, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_38)); return A_arbace_j2g_out__init_A_const_37 }






































func A_arbace_j2g_out__init_A_Unit21__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(214, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_39; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_j2g_out_go_file_name_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_j2g_out_go_file_name_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_516, false, nil); A_arbace_j2g_out_go_file_name_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_40)); return A_arbace_j2g_out__init_A_const_39 }




















func A_arbace_j2g_out__init_A_Unit22__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(235, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_41; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_j2g_out_lone_surrogate_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_j2g_out_lone_surrogate_QMARK__A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_517, false, nil); A_arbace_j2g_out_lone_surrogate_QMARK__A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_42)); return A_arbace_j2g_out__init_A_const_41 }













func A_arbace_j2g_out__init_A_Unit23__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(249, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_43; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_j2g_out_strings_forms_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_j2g_out_strings_forms_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_518, false, nil); A_arbace_j2g_out_strings_forms_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_44)); return A_arbace_j2g_out__init_A_const_43 }










func A_arbace_j2g_out__init_A_Unit24__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(260, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_45; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_j2g_out_ups_forms_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_j2g_out_ups_forms_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_519, false, nil); A_arbace_j2g_out_ups_forms_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_46)); return A_arbace_j2g_out__init_A_const_45 }









func A_arbace_j2g_out__init_A_Unit25__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(270, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_47; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_48)); return A_arbace_j2g_out__init_A_const_47 }
//line :270:1
func A_arbace_j2g_out__init_A_Unit26__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(270, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_49; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_50)); return A_arbace_j2g_out__init_A_const_49 }
//line :270:1
func A_arbace_j2g_out__init_A_Unit27__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(270, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_51; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_52)); return A_arbace_j2g_out__init_A_const_51 }
//line :270:1
func A_arbace_j2g_out__init_A_Unit28__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(270, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_53; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_54)); return A_arbace_j2g_out__init_A_const_53 }

func A_arbace_j2g_out__init_A_Unit29__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(272, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_55; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_j2g_out_adapter_forms_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_j2g_out_adapter_forms_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_520, false, nil); A_arbace_j2g_out_adapter_forms_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_56)); return A_arbace_j2g_out__init_A_const_55 }

















































































































func A_arbace_j2g_out__init_A_Unit30__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(386, 1); A_arbace_j2g_out__init_A_const_57.BindRoot_O__V(A_arbace_j2g_out__init_A_const_58); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_57; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_59)); return A_arbace_j2g_out__init_A_const_57 }

























func A_arbace_j2g_out__init_A_Unit31__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(412, 1); A_arbace_j2g_out__init_A_const_60.BindRoot_O__V(A_arbace_j2g_out__init_A_const_61); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_60; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_62)); return A_arbace_j2g_out__init_A_const_60 }




func A_arbace_j2g_out__init_A_Unit32__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(417, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_63; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_j2g_out_java_name_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_j2g_out_java_name_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_521, false, nil); A_arbace_j2g_out_java_name_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_64)); return A_arbace_j2g_out__init_A_const_63 }

func A_arbace_j2g_out__init_A_Unit33__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(419, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_65; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_j2g_out_jrt_default_forwarders_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_j2g_out_jrt_default_forwarders_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_522, false, nil); A_arbace_j2g_out_jrt_default_forwarders_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_66)); return A_arbace_j2g_out__init_A_const_65 }
























func A_arbace_j2g_out__init_A_Unit34__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(444, 1); A_arbace_j2g_out__init_A_const_67.BindRoot_O__V(Lit_523); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_67; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_68)); return A_arbace_j2g_out__init_A_const_67 }

func A_arbace_j2g_out__init_A_Unit35__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(446, 1); A_arbace_j2g_out__init_A_const_69.BindRoot_O__V(A_arbace_j2g_out__init_A_const_70); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_69; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_71)); return A_arbace_j2g_out__init_A_const_69 }









func A_arbace_j2g_out__init_A_Unit36__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(456, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_72; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_j2g_out_fjp_support_key_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_j2g_out_fjp_support_key_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_524, false, nil); A_arbace_j2g_out_fjp_support_key_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_73)); return A_arbace_j2g_out__init_A_const_72 }




func A_arbace_j2g_out__init_A_Unit37__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(461, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_74; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_j2g_out_fjp_support_forms_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_j2g_out_fjp_support_forms_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_525, false, nil); A_arbace_j2g_out_fjp_support_forms_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_75)); return A_arbace_j2g_out__init_A_const_74 }














func A_arbace_j2g_out__init_A_Unit38__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(476, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_76; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_j2g_out_access_flags_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_j2g_out_access_flags_QMARK__A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_526, false, nil); A_arbace_j2g_out_access_flags_QMARK__A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_77)); return A_arbace_j2g_out__init_A_const_76 }





func A_arbace_j2g_out__init_A_Unit39__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(482, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_78; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_j2g_out_parameters_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_j2g_out_parameters_QMARK__A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_527, false, nil); A_arbace_j2g_out_parameters_QMARK__A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_79)); return A_arbace_j2g_out__init_A_const_78 }




func A_arbace_j2g_out__init_A_Unit40__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(487, 1); A_arbace_j2g_out__init_A_const_80.BindRoot_O__V(A_arbace_j2g_out__init_A_const_81); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_80; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_82)); return A_arbace_j2g_out__init_A_const_80 }



func A_arbace_j2g_out__init_A_Unit41__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(491, 1); A_arbace_j2g_out__init_A_const_83.BindRoot_O__V(A_arbace_j2g_out__init_A_const_84); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_83; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_85)); return A_arbace_j2g_out__init_A_const_83 }





func A_arbace_j2g_out__init_A_Unit42__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(497, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_86; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_j2g_out_type_annotations_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_j2g_out_type_annotations_QMARK__A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_528, false, nil); A_arbace_j2g_out_type_annotations_QMARK__A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_87)); return A_arbace_j2g_out__init_A_const_86 }





func A_arbace_j2g_out__init_A_Unit43__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(503, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_88; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_j2g_out_fn__34000423_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_j2g_out_fn__34000423_A_fn_class; if


	fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_529, false, nil); A_arbace_j2g_out_fn__34000423_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); /*line :503:1*/tmp1.BindRoot_O__V(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_89)); return A_arbace_j2g_out__init_A_const_88 }















func A_arbace_j2g_out__init_A_Unit44__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(519, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_90; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_j2g_out_ta_go_name_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_j2g_out_ta_go_name_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_530, false, nil); A_arbace_j2g_out_ta_go_name_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_91)); return A_arbace_j2g_out__init_A_const_90 }

func A_arbace_j2g_out__init_A_Unit45__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(521, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_92; var tmp2 any; var root_59 any = A_arbace_j2g_out__init_A_const_93.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_61 lang.IFn; if

	linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any; var tmp3 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_j2g_out_fn__34000452_A_New(); var tmp4 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_j2g_out_fn__34000452_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_531, false, nil); A_arbace_j2g_out_fn__34000452_A_fn_class = fncls__63d; tmp4 = fncls__63d } else { tmp4 = fncls__63 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp4, nil); arg_62 = Up_Compiler_AOTFn_IFn(tmp3).Invoke__O(); if linked_60 == nil { tmp2 = ifn_61.Invoke_O__O(arg_62) } else { tmp2 = linked_60.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_59, arg_62) }; /*line :521:1*/tmp1.BindRoot_O__V(tmp2); var tmp5 *lang.Var = A_arbace_j2g_out__init_A_const_92; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_94)); return A_arbace_j2g_out__init_A_const_92 }



func A_arbace_j2g_out__init_A_Unit46__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(525, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_95; var tmp2 any; var root_65 any = A_arbace_j2g_out__init_A_const_93.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_67 lang.IFn; if

	linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any; var root_69 any = A_arbace_j2g_out__init_A_const_96.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any; var tmp3 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_j2g_out_fn__34000470_A_New(); var tmp4 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_j2g_out_fn__34000470_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_532, false, nil); A_arbace_j2g_out_fn__34000470_A_fn_class = fncls__73d; tmp4 = fncls__73d } else { tmp4 = fncls__73 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp4, nil); arg_72 = Up_Compiler_AOTFn_IFn(tmp3).Invoke__O(); if linked_70 == nil { arg_68 = ifn_71.Invoke_O__O(arg_72) } else { arg_68 = linked_70.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_69, arg_72) }; if linked_66 == nil { tmp2 = ifn_67.Invoke_O__O(arg_68) } else { tmp2 = linked_66.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_65, arg_68) }; /*line :525:1*/tmp1.BindRoot_O__V(tmp2); var tmp5 *lang.Var = A_arbace_j2g_out__init_A_const_95; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_97)); return A_arbace_j2g_out__init_A_const_95 }



func A_arbace_j2g_out__init_A_Unit47__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(529, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_98; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_j2g_out_ta_support_forms_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_j2g_out_ta_support_forms_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_533, false, nil); A_arbace_j2g_out_ta_support_forms_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_99)); return A_arbace_j2g_out__init_A_const_98 }















func A_arbace_j2g_out__init_A_Unit48__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(545, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_100; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_j2g_out_support_forms_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_j2g_out_support_forms_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_534, false, nil); A_arbace_j2g_out_support_forms_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_101)); return A_arbace_j2g_out__init_A_const_100 }



















































































































































































































































































































































































































































































func A_arbace_j2g_out__init_A_Unit49__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1013, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_102; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_j2g_out_modifiers_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_j2g_out_modifiers_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_535, false, nil); A_arbace_j2g_out_modifiers_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_102; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_103)); return A_arbace_j2g_out__init_A_const_102 }





func A_arbace_j2g_out__init_A_Unit50__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1019, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_104; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_j2g_out_kind_sym_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_j2g_out_kind_sym_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_536, false, nil); A_arbace_j2g_out_kind_sym_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_104; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_105)); return A_arbace_j2g_out__init_A_const_104 }





func A_arbace_j2g_out__init_A_Unit51__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1025, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_47; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_j2g_out_arg_conv_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_j2g_out_arg_conv_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_537, false, nil); A_arbace_j2g_out_arg_conv_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_106)); return A_arbace_j2g_out__init_A_const_47 }




func A_arbace_j2g_out__init_A_Unit52__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1030, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_49; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_j2g_out_result_any_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_j2g_out_result_any_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_538, false, nil); A_arbace_j2g_out_result_any_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_107)); return A_arbace_j2g_out__init_A_const_49 }




func A_arbace_j2g_out__init_A_Unit53__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1035, 1); A_arbace_j2g_out__init_A_const_108.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_108; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_109)); return A_arbace_j2g_out__init_A_const_108.SetDynamic_Z__Var(true).Ref() }



func A_arbace_j2g_out__init_A_Unit54__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1039, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_110; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_j2g_out_method_order_A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_j2g_out_method_order_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_539, false, nil); A_arbace_j2g_out_method_order_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_110; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_111)); return A_arbace_j2g_out__init_A_const_110 }

















func A_arbace_j2g_out__init_A_Unit55__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1057, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_j2g_out_dotted_desc_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_j2g_out_dotted_desc_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_540, false, nil); A_arbace_j2g_out_dotted_desc_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_112)); return A_arbace_j2g_out__init_A_const_51 }




func A_arbace_j2g_out__init_A_Unit56__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1062, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_53; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_j2g_out_member_table_form_A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_j2g_out_member_table_form_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_541, false, nil); A_arbace_j2g_out_member_table_form_A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_113)); return A_arbace_j2g_out__init_A_const_53 }




























func A_arbace_j2g_out__init_A_Unit57__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1091, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_114; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_j2g_out_member_tables_A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_j2g_out_member_tables_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_542, false, nil); A_arbace_j2g_out_member_tables_A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_115)); return A_arbace_j2g_out__init_A_const_114 }








































































































































func A_arbace_j2g_out__init_A_Unit58__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1228, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_116; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_j2g_out_class_registration_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_j2g_out_class_registration_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_543, false, nil); A_arbace_j2g_out_class_registration_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_116; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_117)); return A_arbace_j2g_out__init_A_const_116 }























































































func A_arbace_j2g_out__init_A_Unit59__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1316, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_118; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_j2g_out_cut_forms_A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_j2g_out_cut_forms_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_544, false, nil); A_arbace_j2g_out_cut_forms_A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_118; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_119)); return A_arbace_j2g_out__init_A_const_118 }























func A_arbace_j2g_out__init_A_Unit60__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1340, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_120; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_j2g_out_support_table_forms_A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_j2g_out_support_table_forms_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_545, false, nil); A_arbace_j2g_out_support_table_forms_A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_121)); return A_arbace_j2g_out__init_A_const_120 }















































































































































































































































func A_arbace_j2g_out__init_A_Unit61__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1580, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_122; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_j2g_out_cut_type_expr_A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_j2g_out_cut_type_expr_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_546, false, nil); A_arbace_j2g_out_cut_type_expr_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_122; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_123)); return A_arbace_j2g_out__init_A_const_122 }
















func A_arbace_j2g_out__init_A_Unit62__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1597, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_124; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_j2g_out_cut_constant_A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_j2g_out_cut_constant_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_547, false, nil); A_arbace_j2g_out_cut_constant_A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_124; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_125)); return A_arbace_j2g_out__init_A_const_124 }















func A_arbace_j2g_out__init_A_Unit63__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1613, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_126; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_j2g_out_cut_class_members_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_j2g_out_cut_class_members_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_548, false, nil); A_arbace_j2g_out_cut_class_members_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_126; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_127)); return A_arbace_j2g_out__init_A_const_126 }
































func A_arbace_j2g_out__init_A_Unit64__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1646, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_128; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_j2g_out_cut_table_forms_A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_j2g_out_cut_table_forms_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_549, false, nil); A_arbace_j2g_out_cut_table_forms_A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_129)); return A_arbace_j2g_out__init_A_const_128 }







































func A_arbace_j2g_out__init_A_Unit65__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1686, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_130; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_j2g_out_start_forms_A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_j2g_out_start_forms_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_550, false, nil); A_arbace_j2g_out_start_forms_A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_130; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_131)); return A_arbace_j2g_out__init_A_const_130 }












func A_arbace_j2g_out__init_A_Unit66__O() any { A_arbace_j2g_out__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1699, 1); var tmp1 *lang.Var = A_arbace_j2g_out__init_A_const_132; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_j2g_out_frames_forms_A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_j2g_out_frames_forms_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_551, false, nil); A_arbace_j2g_out_frames_forms_A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_out__init_A_const_132; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_out__init_A_const_133)); return A_arbace_j2g_out__init_A_const_132 }



type A_arbace_j2g_out__init_A struct{ jrt.Object }

var A_arbace_j2g_out__init_A_const_pool *jrt.RefArray

var A_arbace_j2g_out__init_A_const_0 *lang.Var

var A_arbace_j2g_out__init_A_const_1 any

var A_arbace_j2g_out__init_A_const_2 any

var A_arbace_j2g_out__init_A_const_3 any

var A_arbace_j2g_out__init_A_const_4 *lang.Var

var A_arbace_j2g_out__init_A_const_5 any

var A_arbace_j2g_out__init_A_const_6 *lang.Var

var A_arbace_j2g_out__init_A_const_7 any

var A_arbace_j2g_out__init_A_const_8 *lang.Var

var A_arbace_j2g_out__init_A_const_9 any

var A_arbace_j2g_out__init_A_const_10 *lang.Var

var A_arbace_j2g_out__init_A_const_11 any

var A_arbace_j2g_out__init_A_const_12 *lang.Var

var A_arbace_j2g_out__init_A_const_13 any

var A_arbace_j2g_out__init_A_const_14 *lang.Var

var A_arbace_j2g_out__init_A_const_15 any

var A_arbace_j2g_out__init_A_const_16 *lang.Var

var A_arbace_j2g_out__init_A_const_17 any

var A_arbace_j2g_out__init_A_const_18 *lang.Var

var A_arbace_j2g_out__init_A_const_19 any

var A_arbace_j2g_out__init_A_const_20 *lang.Var

var A_arbace_j2g_out__init_A_const_21 any

var A_arbace_j2g_out__init_A_const_22 any

var A_arbace_j2g_out__init_A_const_23 *lang.Var

var A_arbace_j2g_out__init_A_const_24 any

var A_arbace_j2g_out__init_A_const_25 *lang.Var

var A_arbace_j2g_out__init_A_const_26 any

var A_arbace_j2g_out__init_A_const_27 any

var A_arbace_j2g_out__init_A_const_28 *lang.Var

var A_arbace_j2g_out__init_A_const_29 any

var A_arbace_j2g_out__init_A_const_30 *lang.Var

var A_arbace_j2g_out__init_A_const_31 any

var A_arbace_j2g_out__init_A_const_32 *lang.Var

var A_arbace_j2g_out__init_A_const_33 any

var A_arbace_j2g_out__init_A_const_34 any

var A_arbace_j2g_out__init_A_const_35 *lang.Var

var A_arbace_j2g_out__init_A_const_36 any

var A_arbace_j2g_out__init_A_const_37 *lang.Var

var A_arbace_j2g_out__init_A_const_38 any

var A_arbace_j2g_out__init_A_const_39 *lang.Var

var A_arbace_j2g_out__init_A_const_40 any

var A_arbace_j2g_out__init_A_const_41 *lang.Var

var A_arbace_j2g_out__init_A_const_42 any

var A_arbace_j2g_out__init_A_const_43 *lang.Var

var A_arbace_j2g_out__init_A_const_44 any

var A_arbace_j2g_out__init_A_const_45 *lang.Var

var A_arbace_j2g_out__init_A_const_46 any

var A_arbace_j2g_out__init_A_const_47 *lang.Var

var A_arbace_j2g_out__init_A_const_48 any

var A_arbace_j2g_out__init_A_const_49 *lang.Var

var A_arbace_j2g_out__init_A_const_50 any

var A_arbace_j2g_out__init_A_const_51 *lang.Var

var A_arbace_j2g_out__init_A_const_52 any

var A_arbace_j2g_out__init_A_const_53 *lang.Var

var A_arbace_j2g_out__init_A_const_54 any

var A_arbace_j2g_out__init_A_const_55 *lang.Var

var A_arbace_j2g_out__init_A_const_56 any

var A_arbace_j2g_out__init_A_const_57 *lang.Var

var A_arbace_j2g_out__init_A_const_58 any

var A_arbace_j2g_out__init_A_const_59 any

var A_arbace_j2g_out__init_A_const_60 *lang.Var

var A_arbace_j2g_out__init_A_const_61 any

var A_arbace_j2g_out__init_A_const_62 any

var A_arbace_j2g_out__init_A_const_63 *lang.Var

var A_arbace_j2g_out__init_A_const_64 any

var A_arbace_j2g_out__init_A_const_65 *lang.Var

var A_arbace_j2g_out__init_A_const_66 any

var A_arbace_j2g_out__init_A_const_67 *lang.Var

var A_arbace_j2g_out__init_A_const_68 any

var A_arbace_j2g_out__init_A_const_69 *lang.Var

var A_arbace_j2g_out__init_A_const_70 any

var A_arbace_j2g_out__init_A_const_71 any

var A_arbace_j2g_out__init_A_const_72 *lang.Var

var A_arbace_j2g_out__init_A_const_73 any

var A_arbace_j2g_out__init_A_const_74 *lang.Var

var A_arbace_j2g_out__init_A_const_75 any

var A_arbace_j2g_out__init_A_const_76 *lang.Var

var A_arbace_j2g_out__init_A_const_77 any

var A_arbace_j2g_out__init_A_const_78 *lang.Var

var A_arbace_j2g_out__init_A_const_79 any

var A_arbace_j2g_out__init_A_const_80 *lang.Var

var A_arbace_j2g_out__init_A_const_81 any

var A_arbace_j2g_out__init_A_const_82 any

var A_arbace_j2g_out__init_A_const_83 *lang.Var

var A_arbace_j2g_out__init_A_const_84 any

var A_arbace_j2g_out__init_A_const_85 any

var A_arbace_j2g_out__init_A_const_86 *lang.Var

var A_arbace_j2g_out__init_A_const_87 any

var A_arbace_j2g_out__init_A_const_88 *lang.Var

var A_arbace_j2g_out__init_A_const_89 any

var A_arbace_j2g_out__init_A_const_90 *lang.Var

var A_arbace_j2g_out__init_A_const_91 any

var A_arbace_j2g_out__init_A_const_92 *lang.Var

var A_arbace_j2g_out__init_A_const_93 *lang.Var

var A_arbace_j2g_out__init_A_const_94 any

var A_arbace_j2g_out__init_A_const_95 *lang.Var

var A_arbace_j2g_out__init_A_const_96 *lang.Var

var A_arbace_j2g_out__init_A_const_97 any

var A_arbace_j2g_out__init_A_const_98 *lang.Var

var A_arbace_j2g_out__init_A_const_99 any

var A_arbace_j2g_out__init_A_const_100 *lang.Var

var A_arbace_j2g_out__init_A_const_101 any

var A_arbace_j2g_out__init_A_const_102 *lang.Var

var A_arbace_j2g_out__init_A_const_103 any

var A_arbace_j2g_out__init_A_const_104 *lang.Var

var A_arbace_j2g_out__init_A_const_105 any

var A_arbace_j2g_out__init_A_const_106 any

var A_arbace_j2g_out__init_A_const_107 any

var A_arbace_j2g_out__init_A_const_108 *lang.Var

var A_arbace_j2g_out__init_A_const_109 any

var A_arbace_j2g_out__init_A_const_110 *lang.Var

var A_arbace_j2g_out__init_A_const_111 any

var A_arbace_j2g_out__init_A_const_112 any

var A_arbace_j2g_out__init_A_const_113 any

var A_arbace_j2g_out__init_A_const_114 *lang.Var

var A_arbace_j2g_out__init_A_const_115 any

var A_arbace_j2g_out__init_A_const_116 *lang.Var

var A_arbace_j2g_out__init_A_const_117 any

var A_arbace_j2g_out__init_A_const_118 *lang.Var

var A_arbace_j2g_out__init_A_const_119 any

var A_arbace_j2g_out__init_A_const_120 *lang.Var

var A_arbace_j2g_out__init_A_const_121 any

var A_arbace_j2g_out__init_A_const_122 *lang.Var

var A_arbace_j2g_out__init_A_const_123 any

var A_arbace_j2g_out__init_A_const_124 *lang.Var

var A_arbace_j2g_out__init_A_const_125 any

var A_arbace_j2g_out__init_A_const_126 *lang.Var

var A_arbace_j2g_out__init_A_const_127 any

var A_arbace_j2g_out__init_A_const_128 *lang.Var

var A_arbace_j2g_out__init_A_const_129 any

var A_arbace_j2g_out__init_A_const_130 *lang.Var

var A_arbace_j2g_out__init_A_const_131 any

var A_arbace_j2g_out__init_A_const_132 *lang.Var

var A_arbace_j2g_out__init_A_const_133 any

var A_arbace_j2g_out__init_A_init jrt.ClassInit

func A_arbace_j2g_out__init_A_Init() { if !A_arbace_j2g_out__init_A_init.Done() { A_arbace_j2g_out__init_A_init.Run(A_arbace_j2g_out__init_A_clinit) } }

func A_arbace_j2g_out__init_A_clinit() { A_arbace_j2g_out__init_A_clinit_p0(); A_arbace_j2g_out__init_A_clinit_p1(); A_arbace_j2g_out__init_A_clinit_p2(); A_arbace_j2g_out__init_A_clinit_p3(); A_arbace_j2g_out__init_A_clinit_p4(); A_arbace_j2g_out__init_A_clinit_p5(); A_arbace_j2g_out__init_A_clinit_p6(); A_arbace_j2g_out__init_A_clinit_p7(); A_arbace_j2g_out__init_A_clinit_p8(); A_arbace_j2g_out__init_A_clinit_p9() }

func A_arbace_j2g_out__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_out__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_500, 201); A_arbace_j2g_out__init_A_const_0 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[67]); A_arbace_j2g_out__init_A_const_1 = A_arbace_j2g_out__init_A_const_pool.A[68]; A_arbace_j2g_out__init_A_const_2 = A_arbace_j2g_out__init_A_const_pool.A[69]; A_arbace_j2g_out__init_A_const_3 = A_arbace_j2g_out__init_A_const_pool.A[70]; A_arbace_j2g_out__init_A_const_4 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[71]); A_arbace_j2g_out__init_A_const_5 = A_arbace_j2g_out__init_A_const_pool.A[72]; A_arbace_j2g_out__init_A_const_6 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[73]); A_arbace_j2g_out__init_A_const_7 = A_arbace_j2g_out__init_A_const_pool.A[74]; A_arbace_j2g_out__init_A_const_8 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[75]); A_arbace_j2g_out__init_A_const_9 = A_arbace_j2g_out__init_A_const_pool.A[76]; A_arbace_j2g_out__init_A_const_10 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[77]); A_arbace_j2g_out__init_A_const_11 = A_arbace_j2g_out__init_A_const_pool.A[78]; A_arbace_j2g_out__init_A_const_12 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[79]) }

func A_arbace_j2g_out__init_A_clinit_p1() { A_arbace_j2g_out__init_A_const_13 = A_arbace_j2g_out__init_A_const_pool.A[80]; A_arbace_j2g_out__init_A_const_14 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[81]); A_arbace_j2g_out__init_A_const_15 = A_arbace_j2g_out__init_A_const_pool.A[82]; A_arbace_j2g_out__init_A_const_16 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[83]); A_arbace_j2g_out__init_A_const_17 = A_arbace_j2g_out__init_A_const_pool.A[84]; A_arbace_j2g_out__init_A_const_18 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[85]); A_arbace_j2g_out__init_A_const_19 = A_arbace_j2g_out__init_A_const_pool.A[86]; A_arbace_j2g_out__init_A_const_20 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[87]); A_arbace_j2g_out__init_A_const_21 = A_arbace_j2g_out__init_A_const_pool.A[88]; A_arbace_j2g_out__init_A_const_22 = A_arbace_j2g_out__init_A_const_pool.A[89]; A_arbace_j2g_out__init_A_const_23 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[90]); A_arbace_j2g_out__init_A_const_24 = A_arbace_j2g_out__init_A_const_pool.A[91]; A_arbace_j2g_out__init_A_const_25 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[92]); A_arbace_j2g_out__init_A_const_26 = A_arbace_j2g_out__init_A_const_pool.A[93] }

func A_arbace_j2g_out__init_A_clinit_p2() { A_arbace_j2g_out__init_A_const_27 = A_arbace_j2g_out__init_A_const_pool.A[94]; A_arbace_j2g_out__init_A_const_28 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[95]); A_arbace_j2g_out__init_A_const_29 = A_arbace_j2g_out__init_A_const_pool.A[96]; A_arbace_j2g_out__init_A_const_30 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[97]); A_arbace_j2g_out__init_A_const_31 = A_arbace_j2g_out__init_A_const_pool.A[98]; A_arbace_j2g_out__init_A_const_32 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[99]); A_arbace_j2g_out__init_A_const_33 = A_arbace_j2g_out__init_A_const_pool.A[100]; A_arbace_j2g_out__init_A_const_34 = A_arbace_j2g_out__init_A_const_pool.A[101]; A_arbace_j2g_out__init_A_const_35 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[102]); A_arbace_j2g_out__init_A_const_36 = A_arbace_j2g_out__init_A_const_pool.A[103]; A_arbace_j2g_out__init_A_const_37 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[104]); A_arbace_j2g_out__init_A_const_38 = A_arbace_j2g_out__init_A_const_pool.A[105]; A_arbace_j2g_out__init_A_const_39 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[106]); A_arbace_j2g_out__init_A_const_40 = A_arbace_j2g_out__init_A_const_pool.A[107] }

func A_arbace_j2g_out__init_A_clinit_p3() { A_arbace_j2g_out__init_A_const_41 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[108]); A_arbace_j2g_out__init_A_const_42 = A_arbace_j2g_out__init_A_const_pool.A[109]; A_arbace_j2g_out__init_A_const_43 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[110]); A_arbace_j2g_out__init_A_const_44 = A_arbace_j2g_out__init_A_const_pool.A[111]; A_arbace_j2g_out__init_A_const_45 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[112]); A_arbace_j2g_out__init_A_const_46 = A_arbace_j2g_out__init_A_const_pool.A[113]; A_arbace_j2g_out__init_A_const_47 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[114]); A_arbace_j2g_out__init_A_const_48 = A_arbace_j2g_out__init_A_const_pool.A[115]; A_arbace_j2g_out__init_A_const_49 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[116]); A_arbace_j2g_out__init_A_const_50 = A_arbace_j2g_out__init_A_const_pool.A[117]; A_arbace_j2g_out__init_A_const_51 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[118]); A_arbace_j2g_out__init_A_const_52 = A_arbace_j2g_out__init_A_const_pool.A[119]; A_arbace_j2g_out__init_A_const_53 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[120]) }

func A_arbace_j2g_out__init_A_clinit_p4() { A_arbace_j2g_out__init_A_const_54 = A_arbace_j2g_out__init_A_const_pool.A[121]; A_arbace_j2g_out__init_A_const_55 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[122]); A_arbace_j2g_out__init_A_const_56 = A_arbace_j2g_out__init_A_const_pool.A[123]; A_arbace_j2g_out__init_A_const_57 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[124]); A_arbace_j2g_out__init_A_const_58 = A_arbace_j2g_out__init_A_const_pool.A[125]; A_arbace_j2g_out__init_A_const_59 = A_arbace_j2g_out__init_A_const_pool.A[126]; A_arbace_j2g_out__init_A_const_60 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[127]); A_arbace_j2g_out__init_A_const_61 = A_arbace_j2g_out__init_A_const_pool.A[128]; A_arbace_j2g_out__init_A_const_62 = A_arbace_j2g_out__init_A_const_pool.A[129]; A_arbace_j2g_out__init_A_const_63 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[130]); A_arbace_j2g_out__init_A_const_64 = A_arbace_j2g_out__init_A_const_pool.A[131]; A_arbace_j2g_out__init_A_const_65 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[132]); A_arbace_j2g_out__init_A_const_66 = A_arbace_j2g_out__init_A_const_pool.A[133]; A_arbace_j2g_out__init_A_const_67 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[134]) }

func A_arbace_j2g_out__init_A_clinit_p5() { A_arbace_j2g_out__init_A_const_68 = A_arbace_j2g_out__init_A_const_pool.A[135]; A_arbace_j2g_out__init_A_const_69 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[136]); A_arbace_j2g_out__init_A_const_70 = A_arbace_j2g_out__init_A_const_pool.A[137]; A_arbace_j2g_out__init_A_const_71 = A_arbace_j2g_out__init_A_const_pool.A[138]; A_arbace_j2g_out__init_A_const_72 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[139]); A_arbace_j2g_out__init_A_const_73 = A_arbace_j2g_out__init_A_const_pool.A[140]; A_arbace_j2g_out__init_A_const_74 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[141]); A_arbace_j2g_out__init_A_const_75 = A_arbace_j2g_out__init_A_const_pool.A[142]; A_arbace_j2g_out__init_A_const_76 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[143]); A_arbace_j2g_out__init_A_const_77 = A_arbace_j2g_out__init_A_const_pool.A[144]; A_arbace_j2g_out__init_A_const_78 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[145]); A_arbace_j2g_out__init_A_const_79 = A_arbace_j2g_out__init_A_const_pool.A[146]; A_arbace_j2g_out__init_A_const_80 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[147]); A_arbace_j2g_out__init_A_const_81 = A_arbace_j2g_out__init_A_const_pool.A[148] }

func A_arbace_j2g_out__init_A_clinit_p6() { A_arbace_j2g_out__init_A_const_82 = A_arbace_j2g_out__init_A_const_pool.A[149]; A_arbace_j2g_out__init_A_const_83 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[150]); A_arbace_j2g_out__init_A_const_84 = A_arbace_j2g_out__init_A_const_pool.A[151]; A_arbace_j2g_out__init_A_const_85 = A_arbace_j2g_out__init_A_const_pool.A[152]; A_arbace_j2g_out__init_A_const_86 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[153]); A_arbace_j2g_out__init_A_const_87 = A_arbace_j2g_out__init_A_const_pool.A[154]; A_arbace_j2g_out__init_A_const_88 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[155]); A_arbace_j2g_out__init_A_const_89 = A_arbace_j2g_out__init_A_const_pool.A[156]; A_arbace_j2g_out__init_A_const_90 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[157]); A_arbace_j2g_out__init_A_const_91 = A_arbace_j2g_out__init_A_const_pool.A[158]; A_arbace_j2g_out__init_A_const_92 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[159]); A_arbace_j2g_out__init_A_const_93 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[160]); A_arbace_j2g_out__init_A_const_94 = A_arbace_j2g_out__init_A_const_pool.A[161] }

func A_arbace_j2g_out__init_A_clinit_p7() { A_arbace_j2g_out__init_A_const_95 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[162]); A_arbace_j2g_out__init_A_const_96 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[163]); A_arbace_j2g_out__init_A_const_97 = A_arbace_j2g_out__init_A_const_pool.A[164]; A_arbace_j2g_out__init_A_const_98 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[165]); A_arbace_j2g_out__init_A_const_99 = A_arbace_j2g_out__init_A_const_pool.A[166]; A_arbace_j2g_out__init_A_const_100 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[167]); A_arbace_j2g_out__init_A_const_101 = A_arbace_j2g_out__init_A_const_pool.A[168]; A_arbace_j2g_out__init_A_const_102 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[169]); A_arbace_j2g_out__init_A_const_103 = A_arbace_j2g_out__init_A_const_pool.A[170]; A_arbace_j2g_out__init_A_const_104 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[171]); A_arbace_j2g_out__init_A_const_105 = A_arbace_j2g_out__init_A_const_pool.A[172]; A_arbace_j2g_out__init_A_const_106 = A_arbace_j2g_out__init_A_const_pool.A[173]; A_arbace_j2g_out__init_A_const_107 = A_arbace_j2g_out__init_A_const_pool.A[174] }

func A_arbace_j2g_out__init_A_clinit_p8() { A_arbace_j2g_out__init_A_const_108 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[175]); A_arbace_j2g_out__init_A_const_109 = A_arbace_j2g_out__init_A_const_pool.A[176]; A_arbace_j2g_out__init_A_const_110 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[177]); A_arbace_j2g_out__init_A_const_111 = A_arbace_j2g_out__init_A_const_pool.A[178]; A_arbace_j2g_out__init_A_const_112 = A_arbace_j2g_out__init_A_const_pool.A[179]; A_arbace_j2g_out__init_A_const_113 = A_arbace_j2g_out__init_A_const_pool.A[180]; A_arbace_j2g_out__init_A_const_114 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[181]); A_arbace_j2g_out__init_A_const_115 = A_arbace_j2g_out__init_A_const_pool.A[182]; A_arbace_j2g_out__init_A_const_116 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[183]); A_arbace_j2g_out__init_A_const_117 = A_arbace_j2g_out__init_A_const_pool.A[184]; A_arbace_j2g_out__init_A_const_118 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[185]); A_arbace_j2g_out__init_A_const_119 = A_arbace_j2g_out__init_A_const_pool.A[186]; A_arbace_j2g_out__init_A_const_120 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[187]); A_arbace_j2g_out__init_A_const_121 = A_arbace_j2g_out__init_A_const_pool.A[188] }

func A_arbace_j2g_out__init_A_clinit_p9() { A_arbace_j2g_out__init_A_const_122 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[189]); A_arbace_j2g_out__init_A_const_123 = A_arbace_j2g_out__init_A_const_pool.A[190]; A_arbace_j2g_out__init_A_const_124 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[191]); A_arbace_j2g_out__init_A_const_125 = A_arbace_j2g_out__init_A_const_pool.A[192]; A_arbace_j2g_out__init_A_const_126 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[193]); A_arbace_j2g_out__init_A_const_127 = A_arbace_j2g_out__init_A_const_pool.A[194]; A_arbace_j2g_out__init_A_const_128 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[195]); A_arbace_j2g_out__init_A_const_129 = A_arbace_j2g_out__init_A_const_pool.A[196]; A_arbace_j2g_out__init_A_const_130 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[197]); A_arbace_j2g_out__init_A_const_131 = A_arbace_j2g_out__init_A_const_pool.A[198]; A_arbace_j2g_out__init_A_const_132 = lang.Var_Cast(A_arbace_j2g_out__init_A_const_pool.A[199]); A_arbace_j2g_out__init_A_const_133 = A_arbace_j2g_out__init_A_const_pool.A[200] }

func A_arbace_j2g_out__init_A_New() *A_arbace_j2g_out__init_A { A_arbace_j2g_out__init_A_Init(); t := &A_arbace_j2g_out__init_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_out__init_A) Ctor() {}

func (t *A_arbace_j2g_out__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_out__init_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_out__init_A_class }

func (t *A_arbace_j2g_out__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_out__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_out__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_out__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_out__init_A); return ok }

func A_arbace_j2g_out__init_A_Cast(x any) *A_arbace_j2g_out__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_out__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_out__init_A_class)) }; return v }
