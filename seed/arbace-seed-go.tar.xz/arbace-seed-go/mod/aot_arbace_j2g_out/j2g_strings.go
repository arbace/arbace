//line j2g_strings.ae:1
package aot_arbace_j2g_out

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn14,arbace.java.ioyn2,ioyn20,arbace.classes.typesyn1,tyn18,arbace.classes.envyn3,envyn22,arbace.classes.analyzeyn1,ayn16,arbace.j2g.modelyn1,myn16,arbace.j2g.namesyn2,nmyn14,arbace.j2g.jrtyn3,jrtyn15,arbace.j2g.codeyn1,cyn16,arbace.j2g.declsyn1,dyn15,arbace.j2g.edgeyn4,edgeyn20,arbace.classes.annotyn5,annotyn22,arbace.classes.opcodesyn7,Opcodesyn11,arbace.corekn3,dockn3,tagkn4,linekn6,columnkn4,filekn8,end-linekn10,end-columnkn4,elseks3,j2g4,linekn4,metakn6,forcedys3,j2g7,commentys2,go4,filekn7,importskn3,jrtkn4,langys2,go3,varyn1,*yn3,lityn5,sliceyn6,uint16ys2,go4,funcyn1,pyn4,whenyn2,==yn6,returnkn3,pkgkn4,descyn4,.-Fnyn4,instkn4,formys2,go6,methodkn4,nameyn4,agetyn4,argskn4,bodykn7,methodsys2,go4,typeyn6,structyn2,Fnyn3,Seryn3,anykn7,defaultkn4,kindkn5,owneryn5,panicyn3,Refyn15,GetClass__Classyn16,ToString__Stringyn8,Clone__Oyn4,addrkn4,Namekn9,Modifierskn4,Kindkn5,Superkn10,Interfaceskn2,Goyn4,inityn4,set!yn7,.-Tableyn5,.Infoyn4,funckn7,bridgesyn6,assertyn4,thisyn5,.-Serkn5,typeskn11,jrt-classesyn12,ForkJoinPoolyn8,RefArrayyn1,xyn2,rtyn2,NNyn4,nameyn2,clyn13,ClassLoader_Iyn3,NPEyn3,letyn6,valuesyn1,oyn2,okyn9,interfaceyn1,nyn27,DescribeConstable__Optionalyn6,Stringyn8,Optionalyn23,Optional_Of_O__Optionalyn13,Pre__Optionalyn15,Runtime_Versionyn3,notyn8,.-hasPreyn1,vyn24,Optional_Empty__Optionalyn3,Stryn5,.-preyn15,Build__Optionalyn10,.-hasBuildyn26,Integer_ValueOf_I__Integeryn7,.-buildyn18,Optional__Optionalyn8,.-hasOptyn5,.-optyn13,Version__Listyn4,Listyn2,nsyn8,.numbersyn11,NewRefArrayyn13,Integer_classyn4,convyn5,int32yn3,lenyn5,rangeyn1,iyn6,.Storeyn16,List_Of_O1__Listyn13,Lines__Streamyn6,Streamyn1,lyn13,ArrayList_Newyn1,_yn10,splitLinesyn7,.-valueyn9,.Add_O__Zyn14,NewStringUTF16yn15,.Stream__Streamyn25,GetParameters__Parameter1yn1,eyn21,.GetParameterCount__Iyn15,Parameter_classyn3,foryn1,<yn4,inc!yn35,Parameter_New_String_I_Executable_Iyn1,+yn7,.Stringyn8,StrOfIntyn14,j2gSetDateZoneyn4,boolyn14,DateZoneOffsetyn23,DefaultZone_Offset_J__Iyn20,DateZoneOffsetByWallyn29,DefaultZone_OffsetByWall_J__Iyn12,DateZoneNameyn2,fnyn5,int64yn6,stringyn26,DefaultZone_Name_J__Stringyn2,msyn6,accessyn2,doyn14,J2g_UnboxWidenkn11,type-paramsyn1,Tyn5,Classyn5,Unboxyn4,primyn9,ClassCastyn3,boxyn9,J2g_Truthyn12,Boolean_Inityn2,!=yn13,Boolean_FALSEyn8,J2g_RefPkn5,funcsyn31,String_Format_String_O1__Stringyn17,.ToString__Stringyn28,.Format_String_O1__Formatteryn13,Formatter_Newyn6,formatyn20,Formatted_O1__Stringyn41,String_Join_CharSequence_Iterable__Stringyn12,CharSequenceyn8,Iterableyn3,sepyn8,elementsyn2,ityn19,.Iterator__Iteratoryn5,whileyn11,.HasNext__Zyn2,esyn6,appendyn17,CharSequence_Castyn8,.Next__Oyn46,String_Join_CharSequence_CharSequence1__Stringyn10,RefArrayOfyn18,CharSequence_classyn6,spreadyn38,String_Format_Locale_String_O1__Stringyn6,Localeyn20,Formatter_New_Localeyn30,CaseInsensitiveComparator_Inityn29,String_CASE_INSENSITIVE_ORDERyn34,CaseInsensitiveComparator_INSTANCEyn9,System_inyn31,StandardStreams_In__InputStreamyn10,System_outyn32,StandardStreams_Out__PrintStreamyn10,System_erryn32,StandardStreams_Err__PrintStreamyn4,hostyn11,StderrPrintyn16,.Print_String__Vyn1,syn9,.Flush__Vyn11,J2g_ObjHashyn8,HashCodeyn13,J2g_ObjEqualsyn1,byn2,oryn6,Equalsyn14,J2g_DoubleBitsyn7,float64ys4,math5,IsNaNys4,math11,Float64bitsyn12,J2g_BoolHashyn13,J2g_FloatBitsyn7,float32yn1,fys4,math11,Float32bitsyn22,J2g_AssertionsDisabledyn17,J2g_NotTranslatedyn4,whatyn11,Throwable_Iyn40,UnsupportedOperationException_New_Stringyn11,J2g_Missingyn3,whyyn6,Thrownyn11,J2g_NotNullyn18,J2g_RequireNonNullyn27,Objects_RequireNonNull_O__Oyn19,J2g_RequireNonNullPyn11,J2g_Discardyn25,J2g_PrintStackTraceWriteryn1,wyn16,StackTraceStringyn25,J2g_PrintStackTraceStreamyn16,J2g_SystemGetenvyn11,HashMap_Newyn2,kvyn8,.Environyn11,CurrentHostys7,strings9,IndexByteyn1,>yn11,.Put_O_O__Oyn8,subsliceyn36,Collections_UnmodifiableMap_Map__Mapyn23,J2g_SystemGetPropertiesyn14,Properties_Newyn1,kyn13,PropertyNamesyn33,System_GetProperty_String__Stringyn29,.SetProperty_String_String__Oyn32,System_GetProperties__Propertiesyn29,Thread_GetAllStackTraces__Mapyn11,liveThreadsyn6,.-selfyn7,stackOfyn27,System_SetIn_InputStream__Vyn2,inyn28,System_SetOut_PrintStream__Vyn3,outyn28,System_SetErr_PrintStream__Vyn3,erryn9,J2gCloneryn12,CloneShallowyn15,J2g_ObjectCloneyn13,.CloneShallowyn26,J2g_SystemInheritedChannelyn43,SelectorProvider_Provider__SelectorProvideryn26,.InheritedChannel__Channelyn15,J2g_DateInstantyn18,ToInstant__Instantyn17,J2g_DateToInstantyn19,.ToInstant__Instantyn31,Instant_OfEpochMilli_J__Instantyn11,.GetTime__Jyn12,J2g_DateFromyn3,excyn30,ArithmeticException_InstanceOfyn38,IllegalArgumentException_New_Throwablekn7,resultsyn5,deferyn5,Catchyn10,Date_New_Jyn16,.ToEpochMilli__Jyn39,GetResourceAsStream_String__InputStreamyn2,ifys7,strings9,HasPrefixyn11,.IsArray__Zyn24,.GetComponentType__Classyn2,cnyn6,.-Nameys7,strings13,LastIndexByteyn2,>=ys7,strings10,ReplaceAllyn14,ResourceOrPathyn12,NewByteArrayyn4,asetyn3,.-Ayn4,int8yn27,ByteArrayInputStream_New_B1yn23,GetResource_String__URLyn54,ClassPathResources_GetResource_ClassLoader_String__URLyn45,ClassLoader_GetSystemClassLoader__ClassLoaderyn6,Moduleyn16,GetPackages__Setyn11,HashSet_Newyn6,.RLockyn10,registryMuyn8,registryyn18,.GetModule__Moduleyn8,.RUnlockyn2,pmyn13,packageModuleyn16,AccessFlags__Setyn45,AccessFlagSupport_ClassAccessFlags_Class__Setyn6,Methodyn52,AccessFlagSupport_ExecutableAccessFlags_I_Class__Setyn16,.GetModifiers__Iyn25,.GetDeclaringClass__Classyn11,Constructoryn5,Fieldyn47,AccessFlagSupport_FieldAccessFlags_I_Class__Setkn3,topkn7,nestingkn11,inner-flagskn5,flagskn9,interfacekn5,classkn4,enumkn10,annotationkn6,recordkn5,ctorskn6,fieldskn3,cutyn4,caseyn6,switchkn3,getkn3,setkn4,Datakn3,Cutkn6,Invokekn3,Newkn3,Getkn3,Setkn12,method-orderyn1,=yn5,countyn3,mmsyn7,methodskn5,outerkn6,memberkn6,simplekn9,reflectedkn5,superkn10,interfacesks3,c2j4,codekn7,memberskn6,throwskn9,Declaringkn6,Simpleks3,c2j6,sourcekn6,Sourcekn6,Annotsyn12,.-IsInstanceyn6,.-Inityn11,.-SerialNewyn11,.-SerialUIDyn14,.-HasSerialUIDyn6,.-Enumyn8,.-AnnNewys7,reflect7,TypeForys3,j2g9,code-declkn3,Outyn10,MethodInfokn6,Paramskn6,Returnyn2,Asyn12,String_classyn11,.ArrayClassyn12,Object_classyn12,Locale_classyn21,.Formatted_O1__Stringyn12,Stream_classyn14,.Lines__Streamyn14,Optional_classyn28,.DescribeConstable__Optionalyn14,Iterable_classyn12,Prim_booleanyn18,.Matches_String__Zyn33,.ReplaceAll_String_String__Stringyn35,.ReplaceFirst_String_String__Stringyn22,.Split_String__String1yn8,Prim_intyn24,.Split_String_I__String1yn9,.-Methodsyn19,AnnotatedType_classyn9,Set_classyn17,.AccessFlags__Setyn11,Class_classyn12,Method_classyn17,Constructor_classyn11,Field_classyn15,Throwable_classyn17,PrintStream_classyn9,Prim_voidyn16,PrintStream_Castyn17,PrintWriter_classyn16,PrintWriter_Castyn21,Runtime_Version_classyn14,.Pre__Optionalyn16,.Build__Optionalyn19,.Optional__Optionalyn10,List_classyn14,.Version__Listyn12,System_classyn13,Channel_classyn26,.GetParameters__Parameter1yn12,Thread_classyn9,Map_classyn9,File_Castyn13,Runtime_classyn13,Process_classyn32,RuntimeExec_Exec_String__Processyn40,RuntimeExec_Exec_String_String1__Processyn10,File_classyn45,RuntimeExec_Exec_String_String1_File__Processyn33,RuntimeExec_Exec_String1__Processyn41,RuntimeExec_Exec_String1_String1__Processyn46,RuntimeExec_Exec_String1_String1_File__Processyn16,Properties_classyn8,.-Fieldsyn9,FieldInfokn4,Typeyn16,Comparator_classyn17,ClassLoader_classyn17,InputStream_classyn40,.GetResourceAsStream_String__InputStreamyn9,URL_classyn24,.GetResource_String__URLyn17,Enumeration_classyn63,ClassPathResources_GetResources_ClassLoader_String__Enumerationyn41,Collections_EmptyEnumeration__Enumerationyn10,Date_classyn13,Instant_classyn7,Instantyn6,Date_Iyn4,.Refyn16,InputStream_Castkn4,varskn4,typekn5,constyn5,int16kn4,modskn6,paramskn3,retv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,V3,R7,R1,R8,V3,R9,R1,R10,V3,R11,R1,R12,V3,R13,R1,R14,V3,R15,R1,R16,V3,R17,R1,R18,V3,R19,R1,R20,V3,R21,R1,R22,V3,R23,R1,R24,V3,R25,R1,R26,v11,arbace.core5,referR27,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn14,arbace.j2g.outm2,R28,s358,j2g's output (J2G-SPEC §4.3): Go forms files, one per Java forms file, plus the generated\n  files of each package (j2g_classes: registrations and member tables, §5.11; j2g_strings: the\n  literal pool, §7.5; j2g_frames: the frame table, §7.9.6; j2g_support: j2g's helpers), and\n  the merge with jrt's hand-written forms into one program root for bin/build-go.v11,arbace.core9,with-metaR29,v11,arbace.core6,dissocR30,R31,R32,R33,R34,v11,arbace.core9,contains?v11,arbace.core6,updatev14,arbace.j2g.out5,cleanv11,arbace.core6,empty?v11,arbace.core7,symbol?v11,arbace.core4,seq?v11,arbace.core7,vector?v11,arbace.core4,map?v11,arbace.core4,intov11,arbace.core3,mapR35,v14,arbace.j2g.out9,*renames*v11,arbace.core5,applyv11,arbace.core4,listv11,arbace.core4,mapvv14,arbace.j2g.out8,newlinesR36,v11,arbace.core3,seqv11,arbace.core5,assocR37,V1,R29,v11,arbace.core4,keysv14,arbace.j2g.out4,out!v14,arbace.j2g.out10,write-formv11,arbace.core5,firstv11,arbace.core4,nextR38,v11,arbace.core4,not=v11,arbace.core3,strv11,arbace.core6,repeatv14,arbace.j2g.out10,write-metav14,arbace.j2g.out11,write-itemsv14,arbace.j2g.out10,write-listv11,arbace.core6,pr-strv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core12,*print-meta*v11,arbace.core9,volatile!v11,arbace.core4,run!v11,arbace.core4,valsv11,arbace.core9,namespacev11,arbace.core5,some?v14,arbace.j2g.out6,lined?v11,arbace.core4,somev14,arbace.j2g.out9,split-minR39,l1,v11,arbace.core13,partition-allv16,arbace.j2g.model4,jobsv11,arbace.core3,catv16,arbace.j2g.model8,par-mapvv11,arbace.core3,vecv14,arbace.j2g.out13,unlined-textsv14,arbace.j2g.out15,used-qualifiersv11,arbace.core3,setv16,arbace.j2g.names17,compiled-packagesv14,arbace.j2g.out12,import-pathsv16,arbace.j2g.names8,pkg-pathv11,arbace.core7,keywordv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core3,notv16,arbace.j2g.names8,pkg-namev11,arbace.core12,chunk-appendv11,arbace.core6,symbolv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core4,restv11,arbace.core4,sortv11,arbace.core6,filterv11,arbace.core5,rangev11,arbace.core6,concatv11,arbace.core7,sort-byv11,arbace.core6,removev16,arbace.j2g.names6,pkg-nsR40,R41,R39,v11,arbace.core6,secondR42,v13,arbace.string7,replaceR43,v16,arbace.j2g.names11,user-class?v11,arbace.core4,subsv13,arbace.string5,splitp1,_S34,s2,jss7,freebsds7,openbsds4,nacls7,riscv64s6,wasip1s7,ppc64les5,linuxs5,amd64s3,arms3,386s4,mipss6,tamagos6,darwins5,plan9s5,s390xs7,windowss3,aixs5,ppc64s3,zoss7,loong64s7,solariss3,ioss4,hurds5,arm64s4,wasms9,dragonflys8,mips64les7,illumoss6,netbsds7,androids4,tests6,mipsles6,mips64v11,arbace.core4,lastv11,arbace.core3,intv14,arbace.j2g.out15,lone-surrogate?R44,v14,arbace.j2g.out3,tagR45,v16,arbace.j2g.model7,jrt-symR46,ML2,R47,R48,m4,R30,i257,R31,i69,ML2,R47,R48,m4,R30,i257,R31,i69,v11,arbace.core4,compv11,arbace.core4,namel4,v11,arbace.core3,valR49,v16,arbace.j2g.names9,desc-codeR50,v16,arbace.j2g.model7,go-typeR50,R51,R52,R50,R53,v15,arbace.j2g.code3,*f*R54,v16,arbace.j2g.model7,go-namev22,arbace.classes.analyze8,find-samv20,arbace.classes.types17,parse-method-descR55,R6,R45,R56,R6,v16,arbace.j2g.model11,translated?v15,arbace.j2g.code14,serial-lambdasv18,arbace.classes.env11,assignable?S1,s20,java/io/Serializablev20,arbace.classes.types5,prim?v16,arbace.j2g.model13,pointer-desc?R57,v11,arbace.core6,every?R58,R59,v16,arbace.j2g.names11,method-baseR60,v11,arbace.core9,vary-metaR56,R6,R53,v11,arbace.core11,map-indexedv14,arbace.j2g.out8,arg-convR61,R62,v14,arbace.j2g.out11,dotted-descR63,ML2,R53,nm4,R30,i322,R31,i55,R53,v14,arbace.j2g.out10,result-anyv14,arbace.j2g.out17,member-table-formR64,R39,R65,R66,R67,R68,R69,R66,R67,R59,R53,R59,v11,arbace.core8,distinctv16,arbace.j2g.decls17,interface-closurev11,arbace.core6,mapcatR70,R71,v11,arbace.core4,keepv16,arbace.j2g.model7,impl-ofv18,arbace.classes.env9,subclass?R72,R59,v16,arbace.j2g.model9,class-symR6,R73,v11,arbace.core10,sorted-mapv16,arbace.j2g.model8,vmethodsv11,arbace.core7,reversev11,arbace.core4,nil?R59,R74,m2,R29,R69,R6,R51,R52,R6,R53,R59,R75,R45,R59,R76,R45,R6,R59,R77,m2,R29,R69,R73,R6,R44,R78,R46,R79,R80,l4112,R81,R82,R83,R46,R47,R45,R84,R44,R45,R49,R85,R86,R87,R88,R89,R89,R90,R91,R92,R45,R53,R93,v14,arbace.j2g.out10,java-namesv16,arbace.j2g.model13,hand-written?v16,arbace.j2g.model10,interface?v16,arbace.j2g.model9,abstract?v16,arbace.j2g.model5,leaf?v16,arbace.j2g.model3,pkgv14,arbace.j2g.jrt14,struct-methodsv16,arbace.j2g.model3,*w*R94,R6,R59,R6,R45,R53,R95,v14,arbace.j2g.out17,fjp-support-classv14,arbace.j2g.out15,fjp-support-keyR59,R6,ML2,R45,R96,m4,R30,i472,R31,i44,R53,R6,ML2,R45,R96,m4,R30,i472,R31,i44,v14,arbace.j2g.out19,fjp-support-methodsV4,V3,s22,getAnnotatedReturnTypeFs19,annotatedReturnTypeV3,s24,getAnnotatedReceiverTypeFs21,annotatedReceiverTypeV3,s26,getAnnotatedParameterTypesTs23,annotatedParameterTypesV3,s26,getAnnotatedExceptionTypesTs23,annotatedExceptionTypesV2,s6,Methods11,Constructorv13,arbace.string10,upper-casel0,v14,arbace.j2g.out10,ta-go-namev14,arbace.j2g.out21,type-annotation-callsML2,R45,R97,m4,R30,i534,R31,i28,m6,s17,Ljava/lang/Class;s5,Classs30,Ljava/lang/reflect/Executable;s10,Executables25,Ljava/lang/reflect/Field;s5,FieldR59,R98,R45,R98,ML2,R45,R97,m4,R30,i534,R31,i28,m6,s17,Ljava/lang/Class;s5,Classs30,Ljava/lang/reflect/Executable;s10,Executables25,Ljava/lang/reflect/Field;s5,Fieldv16,arbace.j2g.model13,trivial-init?v14,arbace.j2g.out20,string-regex-methodsv14,arbace.j2g.out22,jrt-default-forwardersv14,arbace.j2g.out17,fjp-support-formsR49,R99,ML2,R100,R99,m4,R30,i567,R31,i17,R53,ML2,R100,R99,m4,R30,i567,R31,i17,v16,arbace.j2g.model28,class-loader-resource-ready?v13,arbace.string12,starts-with?v16,arbace.j2g.model28,class-loader-resource-targetR49,R101,R53,R101,R49,R102,R103,R101,ML3,R51,ML3,R52,R102,nm4,R30,i599,R31,i25,ML2,R73,ML1,R104,m4,R30,i599,R31,i44,m4,R30,i599,R31,i37,m4,R30,i599,R31,i19,R105,R106,R107,R108,R91,R102,R109,R110,R51,R108,R53,R107,R101,R53,R102,R101,ML3,R51,ML3,R52,R102,nm4,R30,i599,R31,i25,ML2,R73,ML1,R104,m4,R30,i599,R31,i44,m4,R30,i599,R31,i37,m4,R30,i599,R31,i19,V1,ML5,R59,R111,s76,DescribeConstable__Optional is String.describeConstable: Optional.of(this).\nMV1,Myn1,tm2,R29,ML2,R45,R112,m4,R30,i634,R31,i40,m2,R29,ML2,R45,R113,m4,R30,i634,R31,i18,ML2,R114,R6,m4,R30,i635,R31,i11,m4,R30,i633,R31,i10,V3,ML6,R59,R115,s68,Pre__Optional is Version.pre: the pre-release, or Optional.empty().\nMV1,Myn1,vm2,R29,ML2,R45,R116,m4,R30,i641,R31,i40,m2,R29,ML2,R45,R113,m4,R30,i641,R31,i18,ML3,R51,ML2,R117,ML2,R118,R119,m4,R30,i642,R31,i22,m4,R30,i642,R31,i17,ML2,R53,ML1,R120,m4,R30,i643,R31,i21,m4,R30,i643,R31,i13,m4,R30,i642,R31,i11,ML2,R114,ML2,R121,ML2,R122,R119,m4,R30,i644,R31,i41,m4,R30,i644,R31,i36,m4,R30,i644,R31,i11,m4,R30,i640,R31,i10,ML6,R59,R123,s87,Build__Optional is Version.build: the build number as an Integer, or Optional.empty().\nMV1,Myn1,vm2,R29,ML2,R45,R116,m4,R30,i646,R31,i40,m2,R29,ML2,R45,R113,m4,R30,i646,R31,i18,ML3,R51,ML2,R117,ML2,R124,R119,m4,R30,i647,R31,i22,m4,R30,i647,R31,i17,ML2,R53,ML1,R120,m4,R30,i648,R31,i21,m4,R30,i648,R31,i13,m4,R30,i647,R31,i11,ML2,R114,ML2,R125,ML2,R126,R119,m4,R30,i649,R31,i64,m4,R30,i649,R31,i36,m4,R30,i649,R31,i11,m4,R30,i645,R31,i10,ML6,R59,R127,s80,Optional__Optional is Version.optional: the optional part, or Optional.empty().\nMV1,Myn1,vm2,R29,ML2,R45,R116,m4,R30,i651,R31,i40,m2,R29,ML2,R45,R113,m4,R30,i651,R31,i18,ML3,R51,ML2,R117,ML2,R128,R119,m4,R30,i652,R31,i22,m4,R30,i652,R31,i17,ML2,R53,ML1,R120,m4,R30,i653,R31,i21,m4,R30,i653,R31,i13,m4,R30,i652,R31,i11,ML2,R114,ML2,R121,ML2,R129,R119,m4,R30,i654,R31,i41,m4,R30,i654,R31,i36,m4,R30,i654,R31,i11,m4,R30,i650,R31,i10,V1,ML5,R59,R130,s68,Version__List is Version.version: List.of the numbers, as Integers.\nMV1,Myn1,vm2,R29,ML2,R45,R116,m4,R30,i657,R31,i25,m2,R29,R131,ML4,R105,V4,R132,ML2,R133,R119,m4,R30,i658,R31,i20,R10,ML3,R134,R135,ML3,R136,R137,ML2,R138,R132,m4,R30,i659,R31,i58,m4,R30,i659,R31,i46,m4,R30,i659,R31,i19,ML3,R139,V3,R140,R98,R132,ML4,R141,R10,ML3,R136,R137,R140,m4,R30,i661,R31,i25,ML2,R125,R98,m4,R30,i661,R31,i40,m4,R30,i661,R31,i15,m4,R30,i660,R31,i13,ML2,R142,R10,m4,R30,i662,R31,i13,m4,R30,i658,R31,i11,m4,R30,i656,R31,i10,V1,ML5,R59,R143,s140,Lines__Stream is String.lines: the lines (split at \\n, \\r, \\r\\n) as a\nsequential stream (over an ArrayList: not jdk26u's lazy spliterator).\nMV1,Myn1,tm2,R29,ML2,R45,R112,m4,R30,i666,R31,i27,m2,R29,R144,ML4,R105,V2,R145,ML1,R146,m4,R30,i667,R31,i19,ML3,R139,V3,R147,R98,ML2,R148,ML2,R149,R6,m4,R30,i668,R31,i37,m4,R30,i668,R31,i25,ML3,R150,R145,ML2,R151,R98,m4,R30,i669,R31,i28,m4,R30,i669,R31,i15,m4,R30,i668,R31,i13,ML2,R152,R145,m4,R30,i670,R31,i13,m4,R30,i667,R31,i11,m4,R30,i664,R31,i10,v14,arbace.j2g.out13,access-flags?v14,arbace.j2g.out11,parameters?R59,R153,R154,R45,m2,R29,ML2,R45,R97,m4,R30,i786,R31,i57,ML4,R105,V4,R110,ML2,R155,R154,m4,R30,i787,R31,i25,R10,ML3,R134,R156,R110,m4,R30,i788,R31,i25,ML5,R157,V2,R140,ML3,R136,R137,l0,m4,R30,i789,R31,i27,ML3,R158,R140,R110,m4,R30,i789,R31,i43,ML2,R159,R140,m4,R30,i789,R31,i51,ML4,R141,R10,R140,ML5,R160,ML2,R121,ML3,R161,s3,argML2,R162,ML2,R163,R140,m4,R30,i790,R31,i93,m4,R30,i790,R31,i84,m4,R30,i790,R31,i75,m4,R30,i790,R31,i70,l0,R154,R140,m4,R30,i790,R31,i33,m4,R30,i790,R31,i21,m4,R30,i789,R31,i19,ML2,R53,R10,m4,R30,i791,R31,i19,m4,R30,i787,R31,i17,m2,R29,ML2,R45,R97,m4,R30,i786,R31,i57,ML4,R105,V4,R110,ML2,R155,R154,m4,R30,i787,R31,i25,R10,ML3,R134,R156,R110,m4,R30,i788,R31,i25,ML5,R157,V2,R140,ML3,R136,R137,l0,m4,R30,i789,R31,i27,ML3,R158,R140,R110,m4,R30,i789,R31,i43,ML2,R159,R140,m4,R30,i789,R31,i51,ML4,R141,R10,R140,ML5,R160,ML2,R121,ML3,R161,s3,argML2,R162,ML2,R163,R140,m4,R30,i790,R31,i93,m4,R30,i790,R31,i84,m4,R30,i790,R31,i75,m4,R30,i790,R31,i70,l0,R154,R140,m4,R30,i790,R31,i33,m4,R30,i790,R31,i21,m4,R30,i789,R31,i19,ML2,R53,R10,m4,R30,i791,R31,i19,m4,R30,i787,R31,i17,v14,arbace.j2g.out17,type-annotations?v14,arbace.j2g.out16,ta-support-formsV2,ML8,R49,R164,s67,j2gSetDateZone sets jrt's DateZone hooks to DefaultZone's methods.\nMV0,m2,R29,R165,ML3,R86,R166,R167,m4,R30,i802,R31,i11,ML3,R86,R168,R169,m4,R30,i803,R31,i11,ML3,R86,R170,ML3,R171,MV1,Myn2,msm2,R29,R172,m2,R29,R173,ML2,R53,ML2,R162,ML2,R174,R175,m4,R30,i804,R31,i71,m4,R30,i804,R31,i62,m4,R30,i804,R31,i54,m4,R30,i804,R31,i30,m4,R30,i804,R31,i11,Tm4,R30,i801,R31,i10,ML3,R44,Myn14,j2gDateZoneSetm2,R29,R165,ML1,R164,m4,R30,i806,R31,i39,m4,R30,i806,R31,i10,v16,arbace.j2g.model21,serial-accessor-basesl3,R44,R49,R176,R86,R176,R49,R51,ML1,R177,m4,R30,i828,R31,i26,R52,ML1,R177,m4,R30,i828,R31,i26,v16,arbace.j2g.model16,serial-accessorsML7,R49,R178,R179,V1,R180,MV3,Myn4,primm2,R29,ML2,R45,R181,m4,R30,i841,R31,i59,Myn3,boxm2,R29,ML2,R45,R181,m4,R30,i841,R31,i82,Myn1,xm2,R29,R69,m2,R29,R180,ML3,R51,ML3,R52,R98,nm4,R30,i842,R31,i15,ML2,R73,ML1,R104,m4,R30,i842,R31,i33,m4,R30,i842,R31,i26,m4,R30,i842,R31,i9,ML4,R105,V2,ML3,R106,R119,R108,m4,R30,i843,R31,i15,ML3,R182,R183,R98,m4,R30,i843,R31,i29,ML3,R51,ML2,R117,R108,m4,R30,i844,R31,i17,ML2,R73,ML3,R184,R98,R185,m4,R30,i844,R31,i33,m4,R30,i844,R31,i26,m4,R30,i844,R31,i11,ML3,R91,R180,R119,m4,R30,i845,R31,i11,m4,R30,i843,R31,i9,m4,R30,i841,R31,i7,R49,R186,R98,R69,m2,R29,R165,R51,R52,R98,R53,R187,R53,R188,R98,R136,R69,R189,ML8,R49,R190,s56,J2g_RefP is a pointer as an any, nil-preserving (§5.6).\nR179,V1,R180,MV1,Myn1,pm2,R29,ML2,R45,R180,m4,R30,i863,R31,i39,m2,R29,R69,ML3,R51,ML3,R52,R50,nm4,R30,i864,R31,i15,ML2,R53,nm4,R30,i864,R31,i26,m4,R30,i864,R31,i9,R50,m4,R30,i862,R31,i7,R191,v14,arbace.j2g.jrt9,scan-fileML5,R49,R192,s125,String_Format_String_O1__String is String.format: a new Formatter's format (j2g's, over the\ntranslated java.util.Formatter).\nMV2,Myn6,formatm2,R29,ML2,R45,R112,m4,R30,i871,R31,i38,Myn4,argsm2,R29,ML2,R45,R97,m4,R30,i871,R31,i64,m2,R29,ML2,R45,R112,m4,R30,i871,R31,i18,ML2,R193,ML4,R194,ML1,R195,m4,R30,i872,R31,i60,R196,R62,m4,R30,i872,R31,i30,m4,R30,i872,R31,i11,m4,R30,i868,R31,i9,ML5,R59,R197,s69,Formatted_O1__String is String.formatted: String.format(this, args).\nMV2,Myn1,tm2,R29,ML2,R45,R112,m4,R30,i876,R31,i38,Myn4,argsm2,R29,ML2,R45,R97,m4,R30,i876,R31,i59,m2,R29,ML2,R45,R112,m4,R30,i876,R31,i18,ML2,R193,ML4,R194,ML1,R195,m4,R30,i877,R31,i60,R6,R62,m4,R30,i877,R31,i30,m4,R30,i877,R31,i11,m4,R30,i874,R31,i9,ML7,R49,R198,s185,String_Join_CharSequence_Iterable__String is String.join(CharSequence, Iterable): each\nelement cast to CharSequence (the for loop's checkcast), then joined as the array overload joins.\nMV2,Myn3,sepm2,R29,R199,Myn8,elementsm2,R29,R200,m2,R29,ML2,R45,R112,m4,R30,i883,R31,i18,ML3,R51,ML3,R52,R201,nm4,R30,i884,R31,i17,ML2,R73,ML1,R104,m4,R30,i884,R31,i37,m4,R30,i884,R31,i30,m4,R30,i884,R31,i11,ML3,R51,ML3,R52,R202,nm4,R30,i885,R31,i17,ML2,R73,ML1,R104,m4,R30,i885,R31,i42,m4,R30,i885,R31,i35,m4,R30,i885,R31,i11,ML4,R105,V4,Myn2,esm2,R29,ML2,R47,R69,m4,R30,i886,R31,i24,nR203,ML2,R204,R202,m4,R30,i887,R31,i20,ML3,R205,ML2,R206,R203,m4,R30,i888,R31,i20,ML3,R86,R207,ML3,R208,R207,ML2,R209,ML2,R210,R203,m4,R30,i889,R31,i54,m4,R30,i889,R31,i35,m4,R30,i889,R31,i24,m4,R30,i889,R31,i15,m4,R30,i888,R31,i13,ML3,R211,R201,ML3,R212,R213,ML2,R214,R207,m4,R30,i890,R31,i96,m4,R30,i890,R31,i65,m4,R30,i890,R31,i13,m4,R30,i886,R31,i11,m4,R30,i880,R31,i9,ML5,R49,R215,s70,String_Format_Locale_String_O1__String is String.format(Locale, ...).\nMV3,Myn1,lm2,R29,ML2,R45,R216,m4,R30,i894,R31,i38,Myn6,formatm2,R29,ML2,R45,R112,m4,R30,i894,R31,i59,Myn4,argsm2,R29,ML2,R45,R97,m4,R30,i894,R31,i85,m2,R29,ML2,R45,R112,m4,R30,i894,R31,i18,ML2,R193,ML4,R194,ML2,R217,R145,m4,R30,i895,R31,i60,R196,R62,m4,R30,i895,R31,i30,m4,R30,i895,R31,i11,m4,R30,i892,R31,i9,R49,R85,V1,ML1,R218,m4,R30,i976,R31,i31,V1,ML3,R86,R219,R220,m4,R30,i977,R31,i29,ML3,R86,R221,ML1,R222,m4,R30,i979,R31,i37,m4,R30,i979,R31,i21,ML3,R86,R223,ML1,R224,m4,R30,i980,R31,i38,m4,R30,i980,R31,i21,ML3,R86,R225,ML1,R226,m4,R30,i981,R31,i38,m4,R30,i981,R31,i21,R105,R227,R89,V1,R173,R228,R86,R228,R171,ML3,R229,R225,ML2,R121,R230,m4,R30,i990,R31,i68,m4,R30,i990,R31,i39,ML2,R231,R225,m4,R30,i991,R31,i39,R230,R173,R51,ML2,R227,R230,m4,R30,i988,R31,i45,ML1,R53,m4,R30,i989,R31,i45,R52,R225,ML6,R49,R232,s33,J2g_ObjHash is Objects.hashCode.\nMV1,Myn1,xm2,R29,R69,m2,R29,R137,ML3,R51,ML3,R52,R98,nm4,R30,i994,R31,i15,ML2,R53,l0,m4,R30,i994,R31,i26,m4,R30,i994,R31,i9,ML2,R233,R98,m4,R30,i995,R31,i9,m4,R30,i993,R31,i7,ML7,R49,R234,s33,J2g_ObjEquals is Objects.equals.\nMV2,Myn1,am2,R29,R69,Myn1,bm2,R29,R69,m2,R29,R165,ML3,R51,ML3,R52,R10,R235,m4,R30,i997,R31,i15,ML2,R53,Tm4,R30,i997,R31,i24,m4,R30,i997,R31,i9,ML3,R51,ML3,R236,ML3,R52,R10,nm4,R30,i998,R31,i19,ML3,R52,R235,nm4,R30,i998,R31,i30,m4,R30,i998,R31,i15,ML2,R53,Fm4,R30,i998,R31,i42,m4,R30,i998,R31,i9,ML3,R237,R10,R235,m4,R30,i999,R31,i9,m4,R30,i996,R31,i7,ML6,R49,R238,s53,J2g_DoubleBits is Double.doubleToLongBits (one NaN).\nMV1,Myn1,dm2,R29,R239,m2,R29,R172,ML3,R51,ML2,R240,R20,m4,R30,i1001,R31,i15,ML2,R53,l9221120237041090560,m4,R30,i1001,R31,i30,m4,R30,i1001,R31,i9,ML3,R136,R172,ML2,R241,R20,m4,R30,i1002,R31,i21,m4,R30,i1002,R31,i9,m4,R30,i1000,R31,i7,ML6,R49,R242,s43,J2g_BoolHash is Boolean.hashCode(boolean).\nMV1,Myn1,bm2,R29,R165,m2,R29,R137,ML3,R51,R235,ML2,R53,l1231,m4,R30,i1004,R31,i17,m4,R30,i1004,R31,i9,ML2,R53,l1237,m4,R30,i1005,R31,i9,m4,R30,i1003,R31,i7,ML6,R49,R243,s49,J2g_FloatBits is Float.floatToIntBits (one NaN).\nMV1,Myn1,fm2,R29,R244,m2,R29,R137,ML3,R51,ML3,R188,R245,R245,m4,R30,i1007,R31,i15,ML2,R53,l2143289344,m4,R30,i1007,R31,i24,m4,R30,i1007,R31,i9,ML3,R136,R137,ML2,R246,R245,m4,R30,i1008,R31,i21,m4,R30,i1008,R31,i9,m4,R30,i1006,R31,i7,R44,R247,R165,R49,R248,R249,R173,m2,R29,R250,R251,R121,R161,R249,R49,R252,R179,V1,R180,R253,R173,m2,R29,R180,R73,R254,R251,R121,R161,R253,R49,R255,V1,R180,R98,R180,m2,R29,R180,R98,R51,R52,R136,R69,R98,R73,R104,R49,R256,V1,R180,R98,R180,m2,R29,R180,R98,R51,R52,R136,R69,R98,R257,R49,R258,V1,R180,R50,R45,R180,R45,R180,R50,R51,R52,R50,R257,R49,R259,R98,R69,m2,R29,R165,R49,R260,ML3,R51,ML3,R52,R261,nm4,R30,i904,R31,i21,ML2,R73,ML1,R104,m4,R30,i904,R31,i39,m4,R30,i904,R31,i32,m4,R30,i904,R31,i15,ML3,R229,R261,ML2,R262,R6,m4,R30,i905,R31,i35,m4,R30,i905,R31,i15,R6,R250,R261,R49,R263,ML3,R51,ML3,R52,R230,nm4,R30,i912,R31,i21,ML2,R73,ML1,R104,m4,R30,i912,R31,i39,m4,R30,i912,R31,i32,m4,R30,i912,R31,i15,ML3,R229,R230,ML2,R262,R6,m4,R30,i913,R31,i35,m4,R30,i913,R31,i15,R6,R250,R230,R49,R264,ML4,R105,V2,R12,ML1,R265,m4,R30,i918,R31,i23,ML3,R139,V3,R147,R266,ML2,R267,ML1,R268,m4,R30,i919,R31,i40,m4,R30,i919,R31,i30,ML3,R105,V2,R140,ML3,R269,R266,c61,m4,R30,i920,R31,i27,ML3,R51,ML3,R270,R140,l0,m4,R30,i921,R31,i27,ML4,R271,R12,ML2,R121,ML4,R272,R266,R147,R140,m4,R30,i922,R31,i43,m4,R30,i922,R31,i38,ML2,R121,ML3,R272,R266,ML3,R161,R140,l1,m4,R30,i922,R31,i80,m4,R30,i922,R31,i67,m4,R30,i922,R31,i62,m4,R30,i922,R31,i23,m4,R30,i921,R31,i21,m4,R30,i920,R31,i19,m4,R30,i919,R31,i17,ML2,R273,R12,m4,R30,i923,R31,i17,m4,R30,i918,R31,i15,R49,R274,ML4,R105,V2,R50,ML1,R275,m4,R30,i931,R31,i23,ML3,R139,V3,R147,R276,ML1,R277,m4,R30,i932,R31,i29,ML3,R105,V2,R119,ML2,R278,ML2,R121,R276,m4,R30,i933,R31,i62,m4,R30,i933,R31,i27,ML3,R51,ML3,R188,R119,nm4,R30,i934,R31,i27,ML4,R279,R50,ML2,R121,R276,m4,R30,i935,R31,i56,R119,m4,R30,i935,R31,i23,m4,R30,i934,R31,i21,m4,R30,i933,R31,i19,m4,R30,i932,R31,i17,R50,m4,R30,i931,R31,i15,R49,R280,ML1,R274,m4,R30,i942,R31,i15,R49,R281,ML4,R105,V2,R12,ML1,R265,m4,R30,i951,R31,i23,ML3,R139,V3,R147,R6,ML1,R282,m4,R30,i952,R31,i29,ML4,R271,R12,ML2,R283,R6,m4,R30,i953,R31,i34,ML2,R284,R6,m4,R30,i953,R31,i45,m4,R30,i953,R31,i19,m4,R30,i952,R31,i17,ML2,R53,R12,m4,R30,i954,R31,i17,m4,R30,i951,R31,i15,R44,R221,R223,R225,R49,R285,ML3,R86,R221,R286,m4,R30,i962,R31,i68,R286,R49,R287,ML3,R86,R223,R288,m4,R30,i965,R31,i69,R288,R49,R289,ML3,R86,R225,R290,m4,R30,i968,R31,i69,R290,R44,R219,R65,R291,R109,R292,m2,R29,R69,R49,R293,R98,R69,m2,R29,R69,R294,R91,R291,R98,v16,arbace.j2g.model18,runtime-exec-descsR49,R295,ML4,R105,V2,R50,ML1,R296,m4,R30,i576,R31,i24,ML3,R51,ML3,R52,R50,nm4,R30,i577,R31,i24,ML2,R73,ML1,R104,m4,R30,i577,R31,i42,m4,R30,i577,R31,i35,m4,R30,i577,R31,i18,ML2,R53,ML2,R297,R50,m4,R30,i578,R31,i26,m4,R30,i578,R31,i18,m4,R30,i576,R31,i16,v16,arbace.j2g.model29,class-loader-resource-helpersR65,R298,R109,R299,R49,R300,R20,ML3,R51,ML3,R52,R20,nm4,R30,i611,R31,i22,ML2,R73,ML1,R104,m4,R30,i611,R31,i40,m4,R30,i611,R31,i33,m4,R30,i611,R31,i16,ML3,R105,V2,ML3,R106,R98,R108,m4,R30,i612,R31,i22,ML3,R91,R298,R20,m4,R30,i612,R31,i36,ML3,R51,R108,ML2,R53,ML2,R301,R98,m4,R30,i613,R31,i35,m4,R30,i613,R31,i27,m4,R30,i613,R31,i18,m4,R30,i612,R31,i16,ML2,R53,ML2,R302,ML2,R303,R20,m4,R30,i614,R31,i57,m4,R30,i614,R31,i24,m4,R30,i614,R31,i16,R49,R304,R140,R105,ML4,R51,ML3,R188,R305,nm4,R30,i625,R31,i28,ML3,R51,ML2,R306,R305,m4,R30,i626,R31,i30,ML2,R73,ML2,R307,R305,m4,R30,i627,R31,i33,m4,R30,i627,R31,i26,m4,R30,i626,R31,i24,ML2,R73,R305,m4,R30,i628,R31,i24,m4,R30,i625,R31,i22,ML2,R53,R20,m4,R30,i629,R31,i22,R20,R305,ML1,ML7,R171,V0,R308,V1,Myn3,excm2,R29,R250,ML2,R309,ML2,R310,ML2,R78,R305,m4,R30,i622,R31,i50,m4,R30,i622,R31,i43,m4,R30,i622,R31,i36,ML3,R86,R20,ML2,R311,ML2,R312,ML2,R100,R140,m4,R30,i623,R31,i74,m4,R30,i623,R31,i56,m4,R30,i623,R31,i44,m4,R30,i623,R31,i36,ML2,R53,nm4,R30,i624,R31,i36,m4,R30,i621,R31,i34,m4,R30,i621,R31,i33,R59,R313,R18,ML2,R45,R181,m4,R30,i680,R31,i36,R101,ML2,R45,R112,m4,R30,i680,R31,i59,ML4,R105,V2,R110,ML2,R162,ML2,R100,R101,m4,R30,i681,R31,i33,m4,R30,i681,R31,i24,ML4,R314,ML3,R315,R110,s1,/m4,R30,i682,R31,i22,ML3,R86,R110,ML3,R272,R110,l1,m4,R30,i683,R31,i28,m4,R30,i683,R31,i20,ML4,R105,V2,R154,R18,ML3,R205,ML2,R316,R154,m4,R30,i685,R31,i29,ML3,R86,R154,ML2,R317,R154,m4,R30,i686,R31,i32,m4,R30,i686,R31,i24,m4,R30,i685,R31,i22,ML3,R105,V4,R318,ML2,R319,ML2,R88,R154,m4,R30,i687,R31,i39,m4,R30,i687,R31,i31,R140,ML3,R320,R318,c46,m4,R30,i688,R31,i30,ML3,R51,ML3,R321,R140,l0,m4,R30,i689,R31,i30,ML3,R86,R110,ML4,R161,ML4,R322,ML4,R272,R318,R147,R140,m4,R30,i690,R31,i57,s1,.s1,/m4,R30,i690,R31,i37,s1,/R110,m4,R30,i690,R31,i34,m4,R30,i690,R31,i26,m4,R30,i689,R31,i24,m4,R30,i687,R31,i22,m4,R30,i684,R31,i20,m4,R30,i682,R31,i18,ML4,R105,V2,ML3,R106,R235,R108,m4,R30,i691,R31,i24,ML2,R323,R110,m4,R30,i691,R31,i38,ML3,R51,ML2,R117,R108,m4,R30,i692,R31,i26,ML2,R53,nm4,R30,i693,R31,i22,m4,R30,i692,R31,i20,ML4,R105,V2,R10,ML2,R324,ML3,R136,R137,ML2,R138,R235,m4,R30,i694,R31,i54,m4,R30,i694,R31,i42,m4,R30,i694,R31,i28,ML3,R139,V3,R140,R98,R235,ML4,R325,ML2,R326,R10,m4,R30,i696,R31,i30,R140,ML3,R136,R327,R98,m4,R30,i696,R31,i40,m4,R30,i696,R31,i24,m4,R30,i695,R31,i22,ML2,R53,ML2,R328,R10,m4,R30,i697,R31,i30,m4,R30,i697,R31,i22,m4,R30,i694,R31,i20,m4,R30,i691,R31,i18,m4,R30,i681,R31,i16,R59,R329,R18,ML2,R45,R181,m4,R30,i707,R31,i36,R101,ML2,R45,R112,m4,R30,i707,R31,i59,ML4,R105,V2,R110,ML2,R162,ML2,R100,R101,m4,R30,i708,R31,i33,m4,R30,i708,R31,i24,ML4,R314,ML3,R315,R110,s1,/m4,R30,i709,R31,i22,ML3,R86,R110,ML3,R272,R110,l1,m4,R30,i710,R31,i28,m4,R30,i710,R31,i20,ML4,R105,V2,R154,R18,ML3,R205,ML2,R316,R154,m4,R30,i712,R31,i29,ML3,R86,R154,ML2,R317,R154,m4,R30,i713,R31,i32,m4,R30,i713,R31,i24,m4,R30,i712,R31,i22,ML3,R105,V4,R318,ML2,R319,ML2,R88,R154,m4,R30,i714,R31,i39,m4,R30,i714,R31,i31,R140,ML3,R320,R318,c46,m4,R30,i715,R31,i30,ML3,R51,ML3,R321,R140,l0,m4,R30,i716,R31,i30,ML3,R86,R110,ML4,R161,ML4,R322,ML4,R272,R318,R147,R140,m4,R30,i717,R31,i57,s1,.s1,/m4,R30,i717,R31,i37,s1,/R110,m4,R30,i717,R31,i34,m4,R30,i717,R31,i26,m4,R30,i716,R31,i24,m4,R30,i714,R31,i22,m4,R30,i711,R31,i20,m4,R30,i709,R31,i18,ML2,R53,ML3,R330,ML1,R331,m4,R30,i719,R31,i28,ML2,R121,R110,m4,R30,i719,R31,i76,m4,R30,i718,R31,i26,m4,R30,i718,R31,i18,m4,R30,i708,R31,i16,R59,R313,R12,ML2,R45,R332,m4,R30,i727,R31,i36,R101,ML2,R45,R112,m4,R30,i727,R31,i60,ML4,R105,V2,R110,ML2,R162,ML2,R100,R101,m4,R30,i728,R31,i33,m4,R30,i728,R31,i24,ML3,R51,ML3,R315,R110,s1,/m4,R30,i729,R31,i24,ML3,R86,R110,ML3,R272,R110,l1,m4,R30,i730,R31,i28,m4,R30,i730,R31,i20,m4,R30,i729,R31,i18,ML4,R105,V2,ML3,R106,R235,R108,m4,R30,i731,R31,i24,ML2,R323,R110,m4,R30,i731,R31,i38,ML3,R51,ML2,R117,R108,m4,R30,i732,R31,i26,ML2,R53,nm4,R30,i733,R31,i22,m4,R30,i732,R31,i20,ML4,R105,V2,R10,ML2,R324,ML3,R136,R137,ML2,R138,R235,m4,R30,i734,R31,i54,m4,R30,i734,R31,i42,m4,R30,i734,R31,i28,ML3,R139,V3,R140,R98,R235,ML4,R325,ML2,R326,R10,m4,R30,i736,R31,i30,R140,ML3,R136,R327,R98,m4,R30,i736,R31,i40,m4,R30,i736,R31,i24,m4,R30,i735,R31,i22,ML2,R53,ML2,R328,R10,m4,R30,i737,R31,i30,m4,R30,i737,R31,i22,m4,R30,i734,R31,i20,m4,R30,i731,R31,i18,m4,R30,i728,R31,i16,R59,R333,R12,ML2,R45,R332,m4,R30,i744,R31,i36,ML7,R105,V2,R230,ML1,R334,m4,R30,i745,R31,i24,ML2,R335,R336,m4,R30,i746,R31,i18,ML3,R139,V3,R110,R18,R337,ML3,R105,V2,R140,ML3,R320,R110,c46,m4,R30,i748,R31,i28,ML3,R51,ML3,R270,R140,l0,m4,R30,i749,R31,i28,ML3,R51,ML3,R52,ML2,R338,R18,m4,R30,i750,R31,i34,R12,m4,R30,i750,R31,i30,ML3,R150,R230,ML2,R121,ML4,R272,R110,R147,R140,m4,R30,i751,R31,i44,m4,R30,i751,R31,i39,m4,R30,i751,R31,i26,m4,R30,i750,R31,i24,m4,R30,i749,R31,i22,m4,R30,i748,R31,i20,m4,R30,i747,R31,i18,ML2,R339,R336,m4,R30,i752,R31,i18,ML3,R139,V3,R50,R340,R341,ML3,R51,ML3,R52,R340,R12,m4,R30,i754,R31,i26,ML3,R150,R230,ML2,R121,R50,m4,R30,i755,R31,i35,m4,R30,i755,R31,i22,m4,R30,i754,R31,i20,m4,R30,i753,R31,i18,ML2,R53,R230,m4,R30,i756,R31,i18,m4,R30,i745,R31,i16,R59,R342,R18,ML2,R45,R181,m4,R30,i764,R31,i38,ML2,R343,R18,m4,R30,i765,R31,i18,R59,R342,R154,ML2,R45,R344,m4,R30,i768,R31,i38,ML3,R345,ML2,R346,R154,m4,R30,i769,R31,i72,ML2,R347,R154,m4,R30,i769,R31,i93,m4,R30,i769,R31,i18,R59,R342,R154,ML2,R45,R348,m4,R30,i772,R31,i38,ML3,R345,ML2,R346,R154,m4,R30,i773,R31,i72,ML2,R347,R154,m4,R30,i773,R31,i93,m4,R30,i773,R31,i18,R59,R342,R245,ML2,R45,R349,m4,R30,i776,R31,i38,ML3,R350,ML2,R346,R245,m4,R30,i777,R31,i67,ML2,R347,R245,m4,R30,i777,R31,i88,m4,R30,i777,R31,i18,V2,R344,R348,v22,arbace.classes.analyze4,declR351,R352,R353,R354,v16,arbace.j2g.model4,infoR355,R356,R357,R358,R359,R91,R57,v15,arbace.j2g.edge16,archived-classesv14,arbace.j2g.out9,java-namev11,arbace.core3,keyv11,arbace.core11,frequenciesv11,arbace.core8,to-arrayR360,R361,R362,v11,arbace.core12,keep-indexedR363,v11,arbace.core5,list*R49,R364,R140,V1,ML2,R53,nm4,R30,i1075,R31,i52,R69,R140,R137,R92,R69,R62,ML2,R47,R69,m4,R30,i1076,R31,i80,R69,R140,R137,R62,ML2,R47,R69,m4,R30,i1077,R31,i59,R69,R365,R140,R137,R107,R69,R366,R140,R137,R107,R69,R119,R69,R78,R46,R367,v13,arbace.string4,joinV2,R368,TR369,R370,R371,R372,v16,arbace.j2g.model4,has?i1024,i1,v14,arbace.j2g.out16,*absent-members*v16,arbace.j2g.names10,own-class?v11,arbace.core10,constantlyv16,arbace.j2g.model14,serialization?v16,arbace.j2g.model13,serializable?i4,v16,arbace.j2g.model7,static?v16,arbace.j2g.model12,serial-hook?v15,arbace.j2g.code9,class-valv16,arbace.j2g.model8,private?R61,R62,R91,R92,ML2,R53,nm4,R30,i1134,R31,i53,R53,ML2,R53,nm4,R30,i1134,R31,i53,v11,arbace.core4,juxtv16,arbace.j2g.decls13,class-methodsv20,arbace.classes.types15,prim-desc->namev20,arbace.classes.types6,array?v20,arbace.classes.types14,desc->internalv15,arbace.j2g.edge3,jvmR373,v14,arbace.j2g.out12,method-orderv11,arbace.core6,vectorv22,arbace.classes.analyze14,ctor-real-descR53,v16,arbace.j2g.names8,new-nameR61,R62,v16,arbace.j2g.model13,serial-field?v16,arbace.j2g.names17,static-field-namev15,arbace.j2g.code15,volatile-field?v18,arbace.classes.env11,const-valuei16,v16,arbace.j2g.names10,field-nameR91,R107,R91,R107,R53,v15,arbace.j2g.code13,volatile-readv15,arbace.j2g.code14,volatile-writeR119,R86,R119,R45,ML3,R374,ML2,R375,R376,m4,R30,i1166,R31,i32,ML2,R375,R377,m4,R30,i1166,R31,i44,m4,R30,i1166,R31,i29,v16,arbace.j2g.decls12,class-fieldsR378,R379,R380,v20,arbace.classes.types14,simple-name-ofR381,R382,v16,arbace.j2g.model9,in-world?R383,R384,v14,arbace.j2g.out13,member-tablesv16,arbace.j2g.names13,compiled-pkg?v20,arbace.classes.annot10,class-dataR385,R386,v16,arbace.j2g.model11,code-class?R44,R45,R44,R78,R46,v14,arbace.j2g.out9,modifiersv14,arbace.j2g.out8,kind-symR46,R47,R45,R387,R388,R389,R390,R391,R49,R85,R105,R140,R88,R86,R392,R140,R86,R393,R140,v16,arbace.j2g.model12,serial-superR86,R394,R140,v16,arbace.j2g.model10,serial-uidR86,R395,R140,R86,R396,R140,R86,R171,R45,R397,R140,R86,R87,R140,R86,R398,R140,R57,R399,R44,R45,R400,R46,R401,R78,R78,R46,R47,R45,R45,R78,R44,R78,R46,v18,arbace.classes.env10,interface?v18,arbace.classes.env4,infoR46,R402,R403,R46,ML2,R47,ML2,R45,R181,m4,R30,i1347,R31,i100,m4,R30,i1347,R31,i93,R404,R171,MV2,Myn4,thism2,R29,R69,Myn4,argsm2,R29,ML2,R47,R69,m4,R30,i1349,R31,i63,m2,R29,R69,ML2,ML3,R57,R405,ML2,R45,R112,m4,R30,i1350,R31,i23,m4,R30,i1350,R31,i14,ML3,R61,R62,l0,m4,R30,i1350,R31,i35,m4,R30,i1350,R31,i13,ML2,ML3,R57,R405,ML2,R45,R112,m4,R30,i1351,R31,i23,m4,R30,i1351,R31,i14,ML3,R61,R62,l1,m4,R30,i1351,R31,i35,m4,R30,i1351,R31,i13,V2,R406,ML2,R407,R408,m4,R30,i1354,R31,i50,R406,l137,R192,ML2,ML3,R57,R405,ML2,R45,R97,m4,R30,i1355,R31,i79,m4,R30,i1355,R31,i70,ML3,R61,R62,l1,m4,R30,i1355,R31,i93,m4,R30,i1355,R31,i69,V3,R409,R406,ML2,R407,R408,m4,R30,i1356,R31,i63,R406,l137,R215,ML2,ML3,R57,R405,ML2,R45,R216,m4,R30,i1357,R31,i83,m4,R30,i1357,R31,i74,ML3,R61,R62,l0,m4,R30,i1357,R31,i95,m4,R30,i1357,R31,i73,ML2,ML3,R57,R405,ML2,R45,R97,m4,R30,i1358,R31,i43,m4,R30,i1358,R31,i34,ML3,R61,R62,l2,m4,R30,i1358,R31,i57,m4,R30,i1358,R31,i33,V1,ML2,R407,R408,m4,R30,i1359,R31,i40,R406,l129,R410,ML2,ML3,R57,R405,ML2,R45,R112,m4,R30,i1360,R31,i66,m4,R30,i1360,R31,i57,R92,m4,R30,i1360,R31,i56,ML2,ML3,R57,R405,ML2,R45,R97,m4,R30,i1360,R31,i95,m4,R30,i1360,R31,i86,ML3,R61,R62,l0,m4,R30,i1360,R31,i109,m4,R30,i1360,R31,i85,R411,ML2,R412,ML2,ML3,R57,R405,ML2,R45,R112,m4,R30,i1362,R31,i82,m4,R30,i1362,R31,i73,R92,m4,R30,i1362,R31,i72,m4,R30,i1362,R31,i56,R413,ML2,R414,ML2,ML3,R57,R405,ML2,R45,R112,m4,R30,i1364,R31,i110,m4,R30,i1364,R31,i101,R92,m4,R30,i1364,R31,i100,m4,R30,i1364,R31,i70,V2,R213,R415,R406,l9,R198,ML2,ML3,R57,R405,R199,m4,R30,i1367,R31,i77,ML3,R61,R62,l0,m4,R30,i1367,R31,i100,m4,R30,i1367,R31,i76,ML2,ML3,R57,R405,R200,m4,R30,i1368,R31,i34,ML3,R61,R62,l1,m4,R30,i1368,R31,i53,m4,R30,i1368,R31,i33,V1,R406,R416,R417,ML2,ML3,R57,R405,ML2,R45,R112,m4,R30,i1371,R31,i63,m4,R30,i1371,R31,i54,R92,m4,R30,i1371,R31,i53,V2,R406,R406,R406,R418,ML2,ML3,R57,R405,ML2,R45,R112,m4,R30,i1373,R31,i78,m4,R30,i1373,R31,i69,R92,m4,R30,i1373,R31,i68,V2,R406,R406,R406,R419,ML2,ML3,R57,R405,ML2,R45,R112,m4,R30,i1375,R31,i80,m4,R30,i1375,R31,i71,R92,m4,R30,i1375,R31,i70,V1,R406,ML2,R407,R406,m4,R30,i1376,R31,i51,R420,ML2,ML3,R57,R405,ML2,R45,R112,m4,R30,i1377,R31,i67,m4,R30,i1377,R31,i58,R92,m4,R30,i1377,R31,i57,V2,R406,R421,ML2,R407,R406,m4,R30,i1378,R31,i60,R422,ML2,ML3,R57,R405,ML2,R45,R112,m4,R30,i1379,R31,i69,m4,R30,i1379,R31,i60,R92,m4,R30,i1379,R31,i59,ML3,R91,R137,ML3,R61,R62,l1,m4,R30,i1379,R31,i105,m4,R30,i1379,R31,i91,R49,R85,R86,R423,R88,R208,R423,R88,ML2,R407,R424,m4,R30,i1419,R31,i53,R424,R91,R92,R45,ML2,R407,R424,m4,R30,i1419,R31,i53,R86,R423,R88,R208,R423,R88,R425,R426,R91,R92,V4,V2,R427,ML2,R45,R181,m4,R30,i1422,R31,i46,V2,R428,ML2,R45,R344,m4,R30,i1422,R31,i71,V2,R429,ML2,R45,R348,m4,R30,i1423,R31,i52,V2,R430,ML2,R45,R349,m4,R30,i1423,R31,i82,R86,ML2,R423,ML2,R88,R431,m4,R30,i1429,R31,i50,m4,R30,i1429,R31,i39,R208,ML2,R423,ML2,R88,R431,m4,R30,i1430,R31,i60,m4,R30,i1430,R31,i49,V1,R432,R433,ML3,R177,ML3,R263,ML3,R91,R250,R92,m4,R30,i1434,R31,i77,ML2,R434,ML3,R61,R62,l0,m4,R30,i1434,R31,i121,m4,R30,i1434,R31,i103,m4,R30,i1434,R31,i50,ML2,R53,nm4,R30,i1435,R31,i50,m4,R30,i1434,R31,i46,V1,R435,R433,ML3,R177,ML3,R260,ML3,R91,R250,R92,m4,R30,i1438,R31,i77,ML2,R436,ML3,R61,R62,l0,m4,R30,i1438,R31,i121,m4,R30,i1438,R31,i103,m4,R30,i1438,R31,i50,ML2,R53,nm4,R30,i1439,R31,i50,m4,R30,i1438,R31,i46,R86,ML2,R423,ML2,R88,R437,m4,R30,i1441,R31,i50,m4,R30,i1441,R31,i39,R208,ML2,R423,ML2,R88,R437,m4,R30,i1442,R31,i60,m4,R30,i1442,R31,i49,R413,ML3,R91,ML2,R45,R116,m4,R30,i1446,R31,i90,R92,m4,R30,i1446,R31,i82,ML3,R91,ML2,R45,R116,m4,R30,i1446,R31,i90,R92,m4,R30,i1446,R31,i82,V3,V2,s3,preR438,V2,s5,buildR439,V2,s8,optionalR440,R441,ML2,R442,ML3,R91,ML2,R45,R116,m4,R30,i1448,R31,i99,R92,m4,R30,i1448,R31,i91,m4,R30,i1448,R31,i75,V1,ML3,R86,ML2,R423,ML2,R88,R443,m4,R30,i1450,R31,i38,m4,R30,i1450,R31,i27,ML3,R208,ML2,R423,ML2,R88,R443,m4,R30,i1451,R31,i46,m4,R30,i1451,R31,i35,ML10,R46,R402,R79,s16,inheritedChannelR404,R444,R80,l9,R369,ML3,R171,MV2,Myn4,thism2,R29,R69,Myn4,argsm2,R29,ML2,R47,R69,m4,R30,i1453,R31,i75,m2,R29,R69,ML1,R295,m4,R30,i1453,R31,i94,m4,R30,i1453,R31,i48,m4,R30,i1452,R31,i35,m4,R30,i1451,R31,i27,m4,R30,i1450,R31,i21,R86,R423,R88,R208,R423,R88,ML2,R407,R156,m4,R30,i1458,R31,i58,R445,R91,R92,ML2,R407,R156,m4,R30,i1458,R31,i58,V2,V2,R428,ML2,R45,R344,m4,R30,i1455,R31,i47,V2,R429,ML2,R45,R348,m4,R30,i1455,R31,i78,V1,ML3,R86,ML2,R423,ML2,R88,R446,m4,R30,i1461,R31,i38,m4,R30,i1461,R31,i27,ML3,R208,ML2,R423,ML2,R88,R446,m4,R30,i1462,R31,i46,m4,R30,i1462,R31,i35,ML10,R46,R402,R79,s17,getAllStackTracesR404,R447,R80,l9,R369,ML3,R171,MV2,Myn4,thism2,R29,R69,Myn4,argsm2,R29,ML2,R47,R69,m4,R30,i1464,R31,i75,m2,R29,R69,ML1,R281,m4,R30,i1464,R31,i94,m4,R30,i1464,R31,i48,m4,R30,i1463,R31,i35,m4,R30,i1462,R31,i27,m4,R30,i1461,R31,i21,V1,ML3,R86,ML2,R423,ML2,R88,R443,m4,R30,i1466,R31,i38,m4,R30,i1466,R31,i27,ML3,R208,ML2,R423,ML2,R88,R443,m4,R30,i1467,R31,i46,m4,R30,i1467,R31,i35,ML10,R46,R402,R79,s6,getenvR404,R447,R80,l9,R369,ML3,R171,MV2,Myn4,thism2,R29,R69,Myn4,argsm2,R29,ML2,R47,R69,m4,R30,i1469,R31,i75,m2,R29,R69,ML1,R264,m4,R30,i1469,R31,i94,m4,R30,i1469,R31,i48,m4,R30,i1468,R31,i35,m4,R30,i1467,R31,i27,m4,R30,i1466,R31,i21,ML2,ML3,R57,R405,ML2,R45,R112,m4,R30,i1471,R31,i38,m4,R30,i1471,R31,i29,ML3,R61,R62,l0,m4,R30,i1471,R31,i50,m4,R30,i1471,R31,i28,ML2,ML3,R57,R405,ML2,R45,R97,m4,R30,i1472,R31,i39,m4,R30,i1472,R31,i30,ML3,R61,R62,l0,m4,R30,i1472,R31,i53,m4,R30,i1472,R31,i29,ML2,ML3,R57,R405,ML2,R45,R97,m4,R30,i1473,R31,i39,m4,R30,i1473,R31,i30,ML3,R61,R62,l1,m4,R30,i1473,R31,i53,m4,R30,i1473,R31,i29,ML2,R448,ML3,R61,R62,l2,m4,R30,i1475,R31,i40,m4,R30,i1475,R31,i29,ML2,R407,R406,m4,R30,i1476,R31,i29,R86,ML2,R423,ML2,R88,R449,m4,R30,i1477,R31,i46,m4,R30,i1477,R31,i35,R208,ML2,R423,ML2,R88,R449,m4,R30,i1478,R31,i54,m4,R30,i1478,R31,i43,V1,R406,R450,R451,R450,R406,R452,R450,R406,R453,R454,R450,R455,R450,R456,R450,R453,R457,V1,ML3,R86,ML2,R423,ML2,R88,R443,m4,R30,i1492,R31,i38,m4,R30,i1492,R31,i27,ML3,R208,ML2,R423,ML2,R88,R443,m4,R30,i1493,R31,i46,m4,R30,i1493,R31,i35,ML10,R46,R402,R79,s13,getPropertiesR404,R458,R80,l9,R369,ML3,R171,MV2,Myn4,thism2,R29,R69,Myn4,argsm2,R29,ML2,R47,R69,m4,R30,i1495,R31,i75,m2,R29,R69,ML1,R274,m4,R30,i1495,R31,i94,m4,R30,i1495,R31,i48,m4,R30,i1494,R31,i35,m4,R30,i1493,R31,i27,m4,R30,i1492,R31,i21,V1,ML3,R86,ML2,R459,ML2,R88,R406,m4,R30,i1497,R31,i37,m4,R30,i1497,R31,i27,ML3,R208,ML2,R459,ML2,R88,R406,m4,R30,i1498,R31,i45,m4,R30,i1498,R31,i35,ML10,R46,R460,R79,s22,CASE_INSENSITIVE_ORDERR461,R462,R80,l25,R371,ML3,R171,MV1,Myn1,om2,R29,R69,m2,R29,R69,R219,m4,R30,i1500,R31,i45,m4,R30,i1499,R31,i35,m4,R30,i1498,R31,i27,m4,R30,i1497,R31,i21,R86,ML2,R423,ML2,R88,R446,m4,R30,i1502,R31,i44,m4,R30,i1502,R31,i33,R208,ML2,R423,ML2,R88,R446,m4,R30,i1503,R31,i52,m4,R30,i1503,R31,i41,R463,ML1,R331,m4,R30,i1505,R31,i38,V1,R463,R433,ML2,R53,nm4,R30,i1506,R31,i98,R86,ML2,R423,ML2,R88,R427,m4,R30,i1509,R31,i44,m4,R30,i1509,R31,i33,R208,ML2,R423,ML2,R88,R427,m4,R30,i1510,R31,i58,m4,R30,i1510,R31,i47,V1,R406,R464,R465,ML2,ML3,R57,R405,ML2,R45,R181,m4,R30,i1513,R31,i100,m4,R30,i1513,R31,i91,R92,m4,R30,i1513,R31,i90,V1,R406,R466,R467,ML2,ML3,R57,R405,ML2,R45,R181,m4,R30,i1516,R31,i86,m4,R30,i1516,R31,i77,R92,m4,R30,i1516,R31,i76,R86,ML2,R423,ML2,R88,R463,m4,R30,i1517,R31,i44,m4,R30,i1517,R31,i33,R208,ML2,R423,ML2,R88,R463,m4,R30,i1518,R31,i58,m4,R30,i1518,R31,i47,V1,R406,R466,R330,ML2,ML3,R57,R405,R103,m4,R30,i1525,R31,i50,R92,m4,R30,i1525,R31,i49,V1,R406,R468,R469,ML2,ML3,R57,R405,R103,m4,R30,i1528,R31,i50,R92,m4,R30,i1528,R31,i49,V1,R406,R468,ML1,R470,m4,R30,i1530,R31,i43,V1,R406,R464,ML4,R105,V2,ML3,R106,R235,R108,m4,R30,i1533,R31,i44,ML2,R323,ML2,R162,ML2,R100,ML2,ML3,R57,R405,ML2,R45,R112,m4,R30,i1533,R31,i97,m4,R30,i1533,R31,i88,ML3,R61,R62,l0,m4,R30,i1533,R31,i109,m4,R30,i1533,R31,i87,m4,R30,i1533,R31,i83,m4,R30,i1533,R31,i74,m4,R30,i1533,R31,i58,ML3,R51,ML2,R117,R108,m4,R30,i1534,R31,i46,ML2,R53,nm4,R30,i1534,R31,i55,m4,R30,i1534,R31,i40,ML4,R105,V2,R10,ML2,R324,ML3,R136,R137,ML2,R138,R235,m4,R30,i1535,R31,i74,m4,R30,i1535,R31,i62,m4,R30,i1535,R31,i48,ML3,R139,V3,R140,R98,R235,ML4,R325,ML2,R326,R10,m4,R30,i1536,R31,i63,R140,ML3,R136,R327,R98,m4,R30,i1536,R31,i73,m4,R30,i1536,R31,i57,m4,R30,i1536,R31,i42,ML2,R53,ML2,R328,R10,m4,R30,i1537,R31,i50,m4,R30,i1537,R31,i42,m4,R30,i1535,R31,i40,m4,R30,i1533,R31,i38,R86,ML2,R423,ML2,R88,R471,m4,R30,i1539,R31,i44,m4,R30,i1539,R31,i33,R208,ML2,R423,ML2,R88,R471,m4,R30,i1540,R31,i52,m4,R30,i1540,R31,i41,V1,R472,R471,ML4,R105,V4,Myn1,dm2,R29,R69,nR305,ML1,ML7,R171,V0,R308,V1,Myn3,excm2,R29,R250,ML2,R309,ML2,R310,ML2,R78,R305,m4,R30,i1546,R31,i65,m4,R30,i1546,R31,i58,m4,R30,i1546,R31,i51,ML3,R86,R20,ML2,R311,ML2,R312,ML2,R100,ML2,ML3,R57,R405,ML2,R45,R473,m4,R30,i1547,R31,i103,m4,R30,i1547,R31,i94,ML3,R61,R62,l0,m4,R30,i1547,R31,i116,m4,R30,i1547,R31,i93,m4,R30,i1547,R31,i89,m4,R30,i1547,R31,i71,m4,R30,i1547,R31,i59,m4,R30,i1547,R31,i51,ML2,R53,nm4,R30,i1548,R31,i51,m4,R30,i1545,R31,i49,m4,R30,i1545,R31,i48,ML4,R51,ML3,R188,R305,nm4,R30,i1549,R31,i46,ML3,R51,ML2,R306,R305,m4,R30,i1550,R31,i48,ML2,R73,ML2,R307,R305,m4,R30,i1551,R31,i51,m4,R30,i1551,R31,i44,m4,R30,i1550,R31,i42,ML2,R73,R305,m4,R30,i1552,R31,i42,m4,R30,i1549,R31,i40,ML2,R53,R20,m4,R30,i1553,R31,i40,m4,R30,i1544,R31,i38,R472,ML2,R302,ML2,R303,ML3,R91,R474,R92,m4,R30,i1555,R31,i84,m4,R30,i1555,R31,i71,m4,R30,i1555,R31,i38,R86,ML2,R423,ML2,R88,R406,m4,R30,i1557,R31,i44,m4,R30,i1557,R31,i33,R208,ML2,R423,ML2,R88,R406,m4,R30,i1558,R31,i58,m4,R30,i1558,R31,i47,R475,R86,ML2,R459,ML2,R88,R443,m4,R30,i1563,R31,i45,m4,R30,i1563,R31,i35,R208,ML2,R459,ML2,R88,R443,m4,R30,i1564,R31,i53,m4,R30,i1564,R31,i43,ML10,R46,R460,R79,s2,inR461,R464,R80,l25,R371,ML3,R171,MV1,Myn1,om2,R29,R69,m2,R29,R69,R221,m4,R30,i1568,R31,i45,m4,R30,i1567,R31,i35,R46,R460,R461,R432,l25,R171,V1,Myn1,om2,R29,R69,m2,R29,R69,R225,R46,R460,R432,R171,V1,Myn1,om2,R29,R69,m2,R29,R69,R223,R86,ML2,R423,ML2,R88,R443,m4,R30,i1571,R31,i44,m4,R30,i1571,R31,i33,R208,ML2,R423,ML2,R88,R443,m4,R30,i1572,R31,i52,m4,R30,i1572,R31,i41,V1,R432,R433,ML3,R177,ML2,R289,ML2,R434,ML3,R61,R62,l0,m4,R30,i1574,R31,i90,m4,R30,i1574,R31,i72,m4,R30,i1574,R31,i42,ML2,R53,nm4,R30,i1574,R31,i106,m4,R30,i1574,R31,i38,V1,R464,R433,ML3,R177,ML2,R285,ML2,R476,ML3,R61,R62,l0,m4,R30,i1576,R31,i89,m4,R30,i1576,R31,i71,m4,R30,i1576,R31,i42,ML2,R53,nm4,R30,i1576,R31,i105,m4,R30,i1576,R31,i38,V1,R432,R433,ML3,R177,ML2,R287,ML2,R434,ML3,R61,R62,l0,m4,R30,i1578,R31,i90,m4,R30,i1578,R31,i72,m4,R30,i1578,R31,i42,ML2,R53,nm4,R30,i1578,R31,i106,m4,R30,i1578,R31,i38,v14,arbace.j2g.out13,cut-type-exprR477,R407,R478,R479,R136,R327,R136,R48,R136,R137,R136,R172,R136,R480,R481,R482,R483,C16,java.lang.Stringv11,arbace.core1,=v14,arbace.j2g.out17,cut-class-membersv14,arbace.j2g.out12,cut-constantR53,R44,R45,R49,R85,R86,R87,R88,R49,R85,R46,R47,R45,R78,R46,ML2,R47,ML2,R89,V0,m4,R30,i1696,R31,i43,m4,R30,i1696,R31,i36,R46,ML2,R47,R173,m4,R30,i1697,R31,i36,v16,arbace.j2g.model17,go-qualified-namev11,arbace.core7,re-findp4,[_$]v16,arbace.j2g.model12,start-class?R46,R147,R49,R85,R46,R47,")

var Lit_1 *jrt.String = jrt.Intern("java/lang/reflect/AccessFlag")

var Lit_2 *jrt.String = jrt.Intern("jdk/internal/jrt/AccessFlagSupport")

var Lit_3 *jrt.String = jrt.Intern("_Fn")

var Lit_4 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$fn__34000139")

var Lit_5 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000141__34000145")

var Lit_6 *jrt.String = jrt.Intern("V")

var Lit_7 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$fn__34000151")

var Lit_8 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$fn__34000153")

var Lit_9 *jrt.String = jrt.Intern("L")

var Lit_10 *jrt.String = jrt.Intern(";")

var Lit_11 *jrt.String = jrt.Intern("Ljava/io/Serializable;")

var Lit_12 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$to_any__34000155")

var Lit_13 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$from_any__34000157")

var Lit_14 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$conv__34000159")

var Lit_15 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000161__34000165")

var Lit_16 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000187__34000191")

var Lit_17 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$entry__34000197")

var Lit_18 *jrt.String = jrt.Intern("(Ljava/lang/Object;)Ljava/lang/Object;")

var Lit_19 *jrt.String = jrt.Intern("M18 writeReplace ()Ljava.lang.Object;")

var Lit_20 *jrt.String = jrt.Intern("_")

var Lit_21 *jrt.String = jrt.Intern("replace")

var Lit_22 *jrt.String = jrt.Intern("---- the lambda adapter of ")

var Lit_23 *jrt.String = jrt.Intern("/")

var Lit_24 *jrt.String = jrt.Intern(".")

var Lit_25 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$fn__34000204")

var Lit_26 *jrt.String = jrt.Intern("Object")

var Lit_27 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$fn__34000207")

var Lit_28 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000209__34000213")

var Lit_29 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$fn__34000219")

var Lit_30 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000221__34000225")

var Lit_31 *jrt.String = jrt.Intern("Class")

var Lit_32 *jrt.String = jrt.Intern("_class")

var Lit_33 *jrt.String = jrt.Intern("String")

var Lit_34 *jrt.String = jrt.Intern("Object_toString")

var Lit_35 *jrt.String = jrt.Intern("Clone__O")

var Lit_36 *jrt.String = jrt.Intern("CloneNotSupported")

var Lit_37 *jrt.String = jrt.Intern("Define")

var Lit_38 *jrt.String = jrt.Intern("ClassInfo")

var Lit_39 *jrt.String = jrt.Intern("$$Lambda")

var Lit_40 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$fn__34000291")

var Lit_41 *jrt.String = jrt.Intern("KindClass")

var Lit_42 *jrt.String = jrt.Intern("Object_class")

var Lit_43 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$fn__34000293")

var Lit_44 *jrt.String = jrt.Intern("_members")

var Lit_45 *jrt.String = jrt.Intern("MemberTable")

var Lit_46 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$entry__34000197$fn__34000201")

var Lit_47 *jrt.String = jrt.Intern("M1 ")

var Lit_48 *jrt.String = jrt.Intern(" ")

var Lit_49 *jrt.String = jrt.Intern(" & ")

var Lit_50 *jrt.String = jrt.Intern("$")

var Lit_51 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_52 *jrt.String = jrt.Intern("As")

var Lit_53 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000141__34000145$fn__34000146")

var Lit_54 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000141__34000145$fn__34000146$fn__34000147")

var Lit_55 *jrt.String = jrt.Intern("p")

var Lit_56 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000161__34000165$fn__34000166")

var Lit_57 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000161__34000165$fn__34000166$fn__34000167")

var Lit_58 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000161__34000165$fn__34000166$fn__34000180")

var Lit_59 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000161__34000165$fn__34000166$fn__34000183")

var Lit_60 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000161__34000165$fn__34000166$fn__34000167$fn__34000171")

var Lit_61 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000161__34000165$fn__34000166$fn__34000167$fn__34000174")

var Lit_62 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000187__34000191$fn__34000192")

var Lit_63 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000187__34000191$fn__34000192$fn__34000193")

var Lit_64 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000209__34000213$fn__34000214")

var Lit_65 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000209__34000213$fn__34000214$fn__34000215")

var Lit_66 *jrt.String = jrt.Intern("Is_")

var Lit_67 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000221__34000225$fn__34000226")

var Lit_68 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000221__34000225$fn__34000226$fn__34000227")

var Lit_69 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000221__34000225$fn__34000226$fn__34000268")

var Lit_70 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000221__34000225$fn__34000226$fn__34000270")

var Lit_71 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000221__34000225$fn__34000226$fn__34000272")

var Lit_72 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000221__34000225$fn__34000226$iter__34000276__34000280")

var Lit_73 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000221__34000225$fn__34000226$fn__34000287")

var Lit_74 *jrt.String = jrt.Intern("J2g_NotTranslated")

var Lit_75 *jrt.String = jrt.Intern("abstract ")

var Lit_76 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000221__34000225$fn__34000226$fn__34000227$fn__34000237")

var Lit_77 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000221__34000225$fn__34000226$fn__34000227$fn__34000239")

var Lit_78 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000221__34000225$fn__34000226$fn__34000227$fn__34000241")

var Lit_79 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000221__34000225$fn__34000226$fn__34000227$iter__34000245__34000249")

var Lit_80 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000221__34000225$fn__34000226$fn__34000227$fn__34000256")

var Lit_81 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000221__34000225$fn__34000226$fn__34000227$fn__34000241$fn__34000242")

var Lit_82 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000221__34000225$fn__34000226$fn__34000227$iter__34000245__34000249$fn__34000250")

var Lit_83 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000221__34000225$fn__34000226$fn__34000227$iter__34000245__34000249$fn__34000250$fn__34000251")

var Lit_84 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000221__34000225$fn__34000226$fn__34000272$fn__34000273")

var Lit_85 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000221__34000225$fn__34000226$iter__34000276__34000280$fn__34000281")

var Lit_86 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000221__34000225$fn__34000226$iter__34000276__34000280$fn__34000281$fn__34000282")

var Lit_87 *jrt.String = jrt.Intern("J2g_RefP")

var Lit_88 *jrt.String = jrt.Intern("arbace.j2g.out$class_registration$up__34000809")

var Lit_89 *jrt.String = jrt.Intern("CodeDecl")

var Lit_90 *jrt.String = jrt.Intern("")

var Lit_91 *jrt.String = jrt.Intern("arbace.j2g.out$class_registration$fn__34000811")

var Lit_92 *jrt.String = jrt.Intern("arbace.j2g.out$class_registration$fn__34000816")

var Lit_93 *jrt.String = jrt.Intern("_InstanceOf")

var Lit_94 *jrt.String = jrt.Intern("_Init")

var Lit_95 *jrt.String = jrt.Intern("_SerialNew")

var Lit_96 *jrt.String = jrt.Intern("RefArray")

var Lit_97 *jrt.String = jrt.Intern("__VALUES")

var Lit_98 *jrt.String = jrt.Intern("_AnnNew")

var Lit_99 *jrt.String = jrt.Intern("RegisterGoType")

var Lit_100 *jrt.String = jrt.Intern("arbace.j2g.out$clean$cm__34000013")

var Lit_101 *jrt.String = jrt.Intern("arbace.j2g.out$clean$fn__34000016")

var Lit_102 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$fn__34000912")

var Lit_103 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$desc__34000914")

var Lit_104 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$iter__34000916__34000920")

var Lit_105 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$fn__34000926")

var Lit_106 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$iter__34000928__34000932")

var Lit_107 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$fn__34000958")

var Lit_108 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$iter__34000960__34000964")

var Lit_109 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$fn__34000970")

var Lit_110 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$iter__34000916__34000920$fn__34000921")

var Lit_111 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$iter__34000916__34000920$fn__34000921$fn__34000922")

var Lit_112 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$iter__34000928__34000932$fn__34000933")

var Lit_113 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$iter__34000928__34000932$fn__34000933$fn__34000934")

var Lit_114 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$iter__34000928__34000932$fn__34000933$fn__34000946")

var Lit_115 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$iter__34000928__34000932$fn__34000933$fn__34000934$fn__34000935")

var Lit_116 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$iter__34000960__34000964$fn__34000965")

var Lit_117 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$iter__34000960__34000964$fn__34000965$fn__34000966")

var Lit_118 *jrt.String = jrt.Intern("Ljava/lang/String;")

var Lit_119 *jrt.String = jrt.Intern("Str")

var Lit_120 *jrt.String = jrt.Intern("B")

var Lit_121 *jrt.String = jrt.Intern("C")

var Lit_122 *jrt.String = jrt.Intern("I")

var Lit_123 *jrt.String = jrt.Intern("J")

var Lit_124 *jrt.String = jrt.Intern("S")

var Lit_125 *jrt.String = jrt.Intern("Z")

var Lit_126 *jrt.String = jrt.Intern("arbace.j2g.out$cut_forms$iter__34000819__34000823")

var Lit_127 *jrt.String = jrt.Intern("arbace.j2g.out$cut_forms$iter__34000819__34000823$fn__34000824")

var Lit_128 *jrt.String = jrt.Intern("arbace.j2g.out$cut_forms$iter__34000819__34000823$fn__34000824$fn__34000825")

var Lit_129 *jrt.String = jrt.Intern("KindInterface")

var Lit_130 *jrt.String = jrt.Intern("arbace.j2g.out$cut_forms$iter__34000819__34000823$fn__34000824$fn__34000829")

var Lit_131 *jrt.String = jrt.Intern(" (cut)")

var Lit_132 *jrt.String = jrt.Intern("arbace.j2g.out$cut_forms$iter__34000819__34000823$fn__34000824$fn__34000825$fn__34000826")

var Lit_133 *jrt.String = jrt.Intern("java/lang/Object")

var Lit_134 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$dotted__34000974")

var Lit_135 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$mdesc__34000976")

var Lit_136 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000978__34000982")

var Lit_137 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$fn__34001081")

var Lit_138 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34001089__34001093")

var Lit_139 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000978__34000982$fn__34000983")

var Lit_140 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000978__34000982$fn__34000983$fn__34000984")

var Lit_141 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000978__34000982$fn__34000983$fn__34001032")

var Lit_142 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000978__34000982$fn__34000983$texpr__34001034")

var Lit_143 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000978__34000982$fn__34000983$iter__34001036__34001040")

var Lit_144 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000978__34000982$fn__34000983$iter__34001050__34001054")

var Lit_145 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000978__34000982$fn__34000983$iter__34001064__34001068")

var Lit_146 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000978__34000982$fn__34000983$fn__34000984$fn__34000985")

var Lit_147 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000978__34000982$fn__34000983$fn__34000984$texpr__34000987")

var Lit_148 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000978__34000982$fn__34000983$fn__34000984$iter__34000989__34000993")

var Lit_149 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000978__34000982$fn__34000983$fn__34000984$iter__34001003__34001007")

var Lit_150 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000978__34000982$fn__34000983$fn__34000984$iter__34001017__34001021")

var Lit_151 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000978__34000982$fn__34000983$fn__34000984$iter__34000989__34000993$fn__34000994")

var Lit_152 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000978__34000982$fn__34000983$fn__34000984$iter__34000989__34000993$fn__34000994$fn__34000995")

var Lit_153 *jrt.String = jrt.Intern("m")

var Lit_154 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000978__34000982$fn__34000983$fn__34000984$iter__34001003__34001007$fn__34001008")

var Lit_155 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000978__34000982$fn__34000983$fn__34000984$iter__34001003__34001007$fn__34001008$fn__34001009")

var Lit_156 *jrt.String = jrt.Intern("G")

var Lit_157 *jrt.String = jrt.Intern("f")

var Lit_158 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000978__34000982$fn__34000983$fn__34000984$iter__34001017__34001021$fn__34001022")

var Lit_159 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000978__34000982$fn__34000983$fn__34000984$iter__34001017__34001021$fn__34001022$fn__34001023")

var Lit_160 *jrt.String = jrt.Intern("c")

var Lit_161 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000978__34000982$fn__34000983$iter__34001036__34001040$fn__34001041")

var Lit_162 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000978__34000982$fn__34000983$iter__34001036__34001040$fn__34001041$fn__34001042")

var Lit_163 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000978__34000982$fn__34000983$iter__34001050__34001054$fn__34001055")

var Lit_164 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000978__34000982$fn__34000983$iter__34001050__34001054$fn__34001055$fn__34001056")

var Lit_165 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000978__34000982$fn__34000983$iter__34001064__34001068$fn__34001069")

var Lit_166 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000978__34000982$fn__34000983$iter__34001064__34001068$fn__34001069$fn__34001070")

var Lit_167 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34001089__34001093$fn__34001094")

var Lit_168 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34001089__34001093$fn__34001094$fn__34001095")

var Lit_169 *jrt.String = jrt.Intern("(")

var Lit_170 *jrt.String = jrt.Intern(")")

var Lit_171 *jrt.String = jrt.Intern("Prim_")

var Lit_172 *jrt.String = jrt.Intern("jrt/")

var Lit_173 *jrt.String = jrt.Intern("arbace.j2g.out$file_text$path_of__34000056")

var Lit_174 *jrt.String = jrt.Intern("arbace.j2g.out$file_text$iter__34000058__34000062")

var Lit_175 *jrt.String = jrt.Intern(";; Generated by j2g (arbace/j2g, doc/go/J2G-SPEC.md); do not edit.\n")

var Lit_176 *jrt.String = jrt.Intern("(in-ns '")

var Lit_177 *jrt.String = jrt.Intern(")\n\n")

var Lit_178 *jrt.String = jrt.Intern("\n")

var Lit_179 *jrt.String = jrt.Intern("arbace.j2g.out$file_text$line_of__34000072")

var Lit_180 *jrt.String = jrt.Intern("\n;; ")

var Lit_181 *jrt.String = jrt.Intern("arbace.j2g.out$file_text$iter__34000058__34000062$fn__34000063")

var Lit_182 *jrt.String = jrt.Intern("arbace.j2g.out$file_text$iter__34000058__34000062$fn__34000063$fn__34000064")

var Lit_183 *jrt.String = jrt.Intern("arbace.core")

var Lit_184 *jrt.String = jrt.Intern("java/util/concurrent/ExecutorService")

var Lit_185 *jrt.String = jrt.Intern("java/util/concurrent/ForkJoinPool")

var Lit_186 *jrt.String = jrt.Intern("arbace.j2g.out$fjp_support_forms$iter__34000367__34000371")

var Lit_187 *jrt.String = jrt.Intern("arbace.j2g.out$fjp_support_forms$iter__34000367__34000371$fn__34000372")

var Lit_188 *jrt.String = jrt.Intern("arbace.j2g.out$fjp_support_forms$iter__34000367__34000371$fn__34000372$fn__34000373")

var Lit_189 *jrt.String = jrt.Intern("arbace.j2g.out$fjp_support_forms$iter__34000367__34000371$fn__34000372$iter__34000405__34000409")

var Lit_190 *jrt.String = jrt.Intern("arbace.j2g.out$fjp_support_forms$iter__34000367__34000371$fn__34000372$fn__34000415")

var Lit_191 *jrt.String = jrt.Intern("arbace.j2g.out$fjp_support_forms$iter__34000367__34000371$fn__34000372$fn__34000373$iter__34000383__34000387")

var Lit_192 *jrt.String = jrt.Intern("arbace.j2g.out$fjp_support_forms$iter__34000367__34000371$fn__34000372$fn__34000373$fn__34000393")

var Lit_193 *jrt.String = jrt.Intern("arbace.j2g.out$fjp_support_forms$iter__34000367__34000371$fn__34000372$fn__34000373$iter__34000383__34000387$fn__34000388")

var Lit_194 *jrt.String = jrt.Intern("arbace.j2g.out$fjp_support_forms$iter__34000367__34000371$fn__34000372$fn__34000373$iter__34000383__34000387$fn__34000388$fn__34000389")

var Lit_195 *jrt.String = jrt.Intern("arbace.j2g.out$fjp_support_forms$iter__34000367__34000371$fn__34000372$iter__34000405__34000409$fn__34000410")

var Lit_196 *jrt.String = jrt.Intern("arbace.j2g.out$fjp_support_forms$iter__34000367__34000371$fn__34000372$iter__34000405__34000409$fn__34000410$fn__34000411")

var Lit_197 *jrt.String = jrt.Intern("(Ljava/util/concurrent/ForkJoinPool;")

var Lit_198 *jrt.String = jrt.Intern("Ljava/lang/reflect/AnnotatedType;")

var Lit_199 *jrt.String = jrt.Intern("[Ljava/lang/reflect/AnnotatedType;")

var Lit_200 *jrt.String = jrt.Intern("Ljava/lang/Class;")

var Lit_201 *jrt.String = jrt.Intern("Ljava/lang/reflect/Executable;")

var Lit_202 *jrt.String = jrt.Intern("Ljava/lang/reflect/Field;")

var Lit_203 *jrt.String = jrt.Intern("getAnnotatedSuperclass")

var Lit_204 *jrt.String = jrt.Intern("annotatedSuperclass")

var Lit_205 *jrt.String = jrt.Intern("getAnnotatedInterfaces")

var Lit_206 *jrt.String = jrt.Intern("annotatedInterfaces")

var Lit_207 *jrt.String = jrt.Intern("Field")

var Lit_208 *jrt.String = jrt.Intern("getAnnotatedType")

var Lit_209 *jrt.String = jrt.Intern("annotatedType")

var Lit_210 *jrt.String = jrt.Intern("arbace.j2g.out$fn__34000423$iter__34000424__34000430")

var Lit_211 *jrt.String = jrt.Intern("arbace.j2g.out$fn__34000423$iter__34000424__34000430$fn__34000431")

var Lit_212 *jrt.String = jrt.Intern("arbace.j2g.out$fn__34000423$iter__34000424__34000430$fn__34000431$iter__34000426__34000432")

var Lit_213 *jrt.String = jrt.Intern("arbace.j2g.out$fn__34000423$iter__34000424__34000430$fn__34000431$iter__34000426__34000432$fn__34000433")

var Lit_214 *jrt.String = jrt.Intern("arbace.j2g.out$fn__34000423$iter__34000424__34000430$fn__34000431$iter__34000426__34000432$fn__34000433$fn__34000434")

var Lit_215 *jrt.String = jrt.Intern("arbace.j2g.out$fn__34000452$iter__34000448__34000453")

var Lit_216 *jrt.String = jrt.Intern("arbace.j2g.out$fn__34000452$iter__34000448__34000453$fn__34000454")

var Lit_217 *jrt.String = jrt.Intern("arbace.j2g.out$fn__34000452$iter__34000448__34000453$fn__34000454$fn__34000455")

var Lit_218 *jrt.String = jrt.Intern("arbace.j2g.out$fn__34000470$iter__34000466__34000471")

var Lit_219 *jrt.String = jrt.Intern("arbace.j2g.out$fn__34000470$iter__34000466__34000471$fn__34000472")

var Lit_220 *jrt.String = jrt.Intern("arbace.j2g.out$fn__34000470$iter__34000466__34000471$fn__34000472$fn__34000473")

var Lit_221 *jrt.String = jrt.Intern("jdk/internal/jrt/TypeAnnotationSupport")

var Lit_222 *jrt.String = jrt.Intern("arbace.j2g.out$frames_forms$iter__34001127__34001135")

var Lit_223 *jrt.String = jrt.Intern("RegisterFrames")

var Lit_224 *jrt.String = jrt.Intern("FrameInfo")

var Lit_225 *jrt.String = jrt.Intern("arbace.j2g.out$frames_forms$iter__34001127__34001135$fn__34001136")

var Lit_226 *jrt.String = jrt.Intern("arbace.j2g.out$frames_forms$iter__34001127__34001135$fn__34001136$iter__34001129__34001137")

var Lit_227 *jrt.String = jrt.Intern("arbace.j2g.out$frames_forms$iter__34001127__34001135$fn__34001136$iter__34001129__34001137$fn__34001138")

var Lit_228 *jrt.String = jrt.Intern("<init>")

var Lit_229 *jrt.String = jrt.Intern("(*")

var Lit_230 *jrt.String = jrt.Intern(").")

var Lit_231 *jrt.String = jrt.Intern(").Impl_")

var Lit_232 *jrt.String = jrt.Intern("_NoInit")

var Lit_233 *jrt.String = jrt.Intern("arbace.j2g.out$frames_forms$iter__34001127__34001135$fn__34001136$iter__34001129__34001137$fn__34001138$iter__34001131__34001139")

var Lit_234 *jrt.String = jrt.Intern("arbace.j2g.out$frames_forms$iter__34001127__34001135$fn__34001136$iter__34001129__34001137$fn__34001138$iter__34001131__34001139$fn__34001140")

var Lit_235 *jrt.String = jrt.Intern("arbace.j2g.out$frames_forms$iter__34001127__34001135$fn__34001136$iter__34001129__34001137$fn__34001138$iter__34001131__34001139$fn__34001140$fn__34001141")

var Lit_236 *jrt.String = jrt.Intern("J_")

var Lit_237 *jrt.String = jrt.Intern(".go")

var Lit_238 *jrt.String = jrt.Intern("_j2g")

var Lit_239 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders$iter__34000299__34000305")

var Lit_240 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders$iter__34000299__34000305$fn__34000306")

var Lit_241 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders$iter__34000299__34000305$fn__34000306$iter__34000301__34000307")

var Lit_242 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders$iter__34000299__34000305$fn__34000306$iter__34000301__34000307$fn__34000308")

var Lit_243 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders$iter__34000299__34000305$fn__34000306$iter__34000301__34000307$fn__34000308$fn__34000309")

var Lit_244 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders$iter__34000299__34000305$fn__34000306$iter__34000301__34000307$fn__34000308$iter__34000342__34000346")

var Lit_245 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders$iter__34000299__34000305$fn__34000306$iter__34000301__34000307$fn__34000308$fn__34000353")

var Lit_246 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders$iter__34000299__34000305$fn__34000306$iter__34000301__34000307$fn__34000308$fn__34000309$iter__34000319__34000323")

var Lit_247 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders$iter__34000299__34000305$fn__34000306$iter__34000301__34000307$fn__34000308$fn__34000309$fn__34000330")

var Lit_248 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders$iter__34000299__34000305$fn__34000306$iter__34000301__34000307$fn__34000308$fn__34000309$iter__34000319__34000323$fn__34000324")

var Lit_249 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders$iter__34000299__34000305$fn__34000306$iter__34000301__34000307$fn__34000308$fn__34000309$iter__34000319__34000323$fn__34000324$fn__34000325")

var Lit_250 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders$iter__34000299__34000305$fn__34000306$iter__34000301__34000307$fn__34000308$iter__34000342__34000346$fn__34000347")

var Lit_251 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders$iter__34000299__34000305$fn__34000306$iter__34000301__34000307$fn__34000308$iter__34000342__34000346$fn__34000347$fn__34000348")

var Lit_252 *jrt.String = jrt.Intern("KindEnum")

var Lit_253 *jrt.String = jrt.Intern("KindAnnotation")

var Lit_254 *jrt.String = jrt.Intern("KindRecord")

var Lit_255 *jrt.String = jrt.Intern("arbace.j2g.out$lined_QMARK_$lined_meta_QMARK___34000037")

var Lit_256 *jrt.String = jrt.Intern("arbace.j2g.out$lined_QMARK_$fn__34000040")

var Lit_257 *jrt.String = jrt.Intern("arbace.j2g.out$member_table_form$dispatch__34000646")

var Lit_258 *jrt.String = jrt.Intern("invoke")

var Lit_259 *jrt.String = jrt.Intern("new")

var Lit_260 *jrt.String = jrt.Intern("get")

var Lit_261 *jrt.String = jrt.Intern("set")

var Lit_262 *jrt.String = jrt.Intern("arbace.j2g.out$member_table_form$dispatch__34000646$fn__34000647")

var Lit_263 *jrt.String = jrt.Intern("_I")

var Lit_264 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$public_QMARK___34000654")

var Lit_265 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$listed_QMARK___34000656")

var Lit_266 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$cls__34000658")

var Lit_267 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000660__34000664")

var Lit_268 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000680__34000684")

var Lit_269 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000696__34000700")

var Lit_270 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000706__34000710")

var Lit_271 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$jname__34000716")

var Lit_272 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$jparams__34000718")

var Lit_273 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$fn__34000720")

var Lit_274 *jrt.String = jrt.Intern("Assert failed: ")

var Lit_275 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$fn__34000723")

var Lit_276 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$fn__34000729")

var Lit_277 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$fn__34000736")

var Lit_278 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000738__34000742")

var Lit_279 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000754__34000758")

var Lit_280 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000770__34000774")

var Lit_281 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000796__34000800")

var Lit_282 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$fn__34000729$fn__34000733")

var Lit_283 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000660__34000664$fn__34000665")

var Lit_284 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000660__34000664$fn__34000665$fn__34000666")

var Lit_285 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000660__34000664$fn__34000665$fn__34000676")

var Lit_286 *jrt.String = jrt.Intern(".Impl_")

var Lit_287 *jrt.String = jrt.Intern(".Self_")

var Lit_288 *jrt.String = jrt.Intern("M")

var Lit_289 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000660__34000664$fn__34000665$fn__34000666$fn__34000670")

var Lit_290 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000680__34000684$fn__34000685")

var Lit_291 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000680__34000684$fn__34000685$fn__34000686")

var Lit_292 *jrt.String = jrt.Intern("<clinit>")

var Lit_293 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000696__34000700$fn__34000701")

var Lit_294 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000696__34000700$fn__34000701$fn__34000702")

var Lit_295 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000706__34000710$fn__34000711")

var Lit_296 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000706__34000710$fn__34000711$fn__34000712")

var Lit_297 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000738__34000742$fn__34000743")

var Lit_298 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000738__34000742$fn__34000743$fn__34000744")

var Lit_299 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000754__34000758$fn__34000759")

var Lit_300 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000754__34000758$fn__34000759$fn__34000760")

var Lit_301 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000770__34000774$fn__34000775")

var Lit_302 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000770__34000774$fn__34000775$fn__34000776")

var Lit_303 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000770__34000774$fn__34000775$fn__34000792")

var Lit_304 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000770__34000774$fn__34000775$fn__34000776$fn__34000783")

var Lit_305 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000796__34000800$fn__34000801")

var Lit_306 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000796__34000800$fn__34000801$fn__34000802")

var Lit_307 *jrt.String = jrt.Intern(".-")

var Lit_308 *jrt.String = jrt.Intern("F")

var Lit_309 *jrt.String = jrt.Intern("arbace.j2g.out$method_order$fn__34000605")

var Lit_310 *jrt.String = jrt.Intern("arbace.j2g.out$method_order$fn__34000607")

var Lit_311 *jrt.String = jrt.Intern("arbace.j2g.out$method_order$iter__34000611__34000615")

var Lit_312 *jrt.String = jrt.Intern("arbace.j2g.out$method_order$iter__34000627__34000631")

var Lit_313 *jrt.String = jrt.Intern("arbace.j2g.out$method_order$fn__34000607$fn__34000608")

var Lit_314 *jrt.String = jrt.Intern("arbace.j2g.out$method_order$iter__34000611__34000615$fn__34000616")

var Lit_315 *jrt.String = jrt.Intern("arbace.j2g.out$method_order$iter__34000611__34000615$fn__34000616$fn__34000617")

var Lit_316 *jrt.String = jrt.Intern("arbace.j2g.out$method_order$iter__34000627__34000631$fn__34000632")

var Lit_317 *jrt.String = jrt.Intern("arbace.j2g.out$method_order$iter__34000627__34000631$fn__34000632$fn__34000633")

var Lit_318 *jrt.String = jrt.Intern("arbace.j2g.out$method_order$iter__34000627__34000631$fn__34000632$fn__34000637")

var Lit_319 *jrt.String = jrt.Intern("arbace.j2g.out$method_order$iter__34000627__34000631$fn__34000632$fn__34000633$fn__34000634")

var Lit_320 *jrt.String = jrt.Intern("java/lang/reflect/Parameter")

var Lit_321 *jrt.String = jrt.Intern("RegisterStartClasses")

var Lit_322 *jrt.String = jrt.Intern("ClassInit")

var Lit_323 *jrt.String = jrt.Intern("arbace.j2g.out$start_forms$iter__34001106__34001110")

var Lit_324 *jrt.String = jrt.Intern("arbace.j2g.out$start_forms$iter__34001116__34001120")

var Lit_325 *jrt.String = jrt.Intern("arbace.j2g.out$start_forms$iter__34001106__34001110$fn__34001111")

var Lit_326 *jrt.String = jrt.Intern("arbace.j2g.out$start_forms$iter__34001106__34001110$fn__34001111$fn__34001112")

var Lit_327 *jrt.String = jrt.Intern("_init")

var Lit_328 *jrt.String = jrt.Intern("arbace.j2g.out$start_forms$iter__34001116__34001120$fn__34001121")

var Lit_329 *jrt.String = jrt.Intern("arbace.j2g.out$start_forms$iter__34001116__34001120$fn__34001121$fn__34001122")

var Lit_330 *jrt.String = jrt.Intern("arbace.j2g.out$strings_forms$iter__34000078__34000082")

var Lit_331 *jrt.String = jrt.Intern("arbace.j2g.out$strings_forms$fn__34000094")

var Lit_332 *jrt.String = jrt.Intern("arbace.j2g.out$strings_forms$iter__34000078__34000082$fn__34000083")

var Lit_333 *jrt.String = jrt.Intern("arbace.j2g.out$strings_forms$iter__34000078__34000082$fn__34000083$fn__34000084")

var Lit_334 *jrt.String = jrt.Intern("InternUTF16")

var Lit_335 *jrt.String = jrt.Intern("Intern")

var Lit_336 *jrt.String = jrt.Intern("java/lang/Boolean")

var Lit_337 *jrt.String = jrt.Intern("java/util/regex/Pattern")

var Lit_338 *jrt.String = jrt.Intern("jdk/internal/jrt/RuntimeExec")

var Lit_339 *jrt.String = jrt.Intern("java/lang/Runtime")

var Lit_340 *jrt.String = jrt.Intern("arbace.j2g.out$support_forms$iter__34000503__34000507")

var Lit_341 *jrt.String = jrt.Intern("java/nio/channels/spi/SelectorProvider")

var Lit_342 *jrt.String = jrt.Intern("java/lang/System")

var Lit_343 *jrt.String = jrt.Intern("J2g_SystemInheritedChannel is System.inheritedChannel(): SelectorProvider.provider().inheritedChannel().\n")

var Lit_344 *jrt.String = jrt.Intern("Ljava/nio/channels/Channel;")

var Lit_345 *jrt.String = jrt.Intern("jdk/internal/jrt/ClassPathResources")

var Lit_346 *jrt.String = jrt.Intern("java/lang/ClassLoader")

var Lit_347 *jrt.String = jrt.Intern("arbace.j2g.out$support_forms$iter__34000543__34000547")

var Lit_348 *jrt.String = jrt.Intern("java/time/Instant")

var Lit_349 *jrt.String = jrt.Intern("java/util/Date")

var Lit_350 *jrt.String = jrt.Intern("J2g_DateInstant is a Date subclass's own toInstant (java.sql.Timestamp's).\n")

var Lit_351 *jrt.String = jrt.Intern("Ljava/time/Instant;")

var Lit_352 *jrt.String = jrt.Intern("J2g_DateToInstant is Date.toInstant(): its time as an Instant, or a subclass's own.\n")

var Lit_353 *jrt.String = jrt.Intern("Ljava/util/Date;")

var Lit_354 *jrt.String = jrt.Intern("J2g_DateFrom is Date.from(Instant).\n")

var Lit_355 *jrt.String = jrt.Intern("java/util/Optional")

var Lit_356 *jrt.String = jrt.Intern("java/lang/constant/Constable")

var Lit_357 *jrt.String = jrt.Intern("java/lang/Runtime$Version")

var Lit_358 *jrt.String = jrt.Intern("java/util/List")

var Lit_359 *jrt.String = jrt.Intern("java/util/stream/Stream")

var Lit_360 *jrt.String = jrt.Intern("java/util/ArrayList")

var Lit_361 *jrt.String = jrt.Intern("java/io/ByteArrayInputStream")

var Lit_362 *jrt.String = jrt.Intern("GetResourceAsStream_String__InputStream is Class.getResourceAsStream: the resource name\nresolved as Class.resolveName resolves it (absolute without its /, else in the package of the\nclass or of its arrays' element class), from the host's resources, as a ByteArrayInputStream; null\nwhen there is none.\n")

var Lit_363 *jrt.String = jrt.Intern("Ljava/io/InputStream;")

var Lit_364 *jrt.String = jrt.Intern("GetResource_String__URL is Class.getResource: the resource name resolved as Class.resolveName\nresolves it (absolute without its /, else in the package of the class or of its arrays' element class),\nthen the system loader's getResource (ClassPathResources.getResource); null when there is none.\n")

var Lit_365 *jrt.String = jrt.Intern("Ljava/net/URL;")

var Lit_366 *jrt.String = jrt.Intern("GetResourceAsStream_String__InputStream is Module.getResourceAsStream: the resource name\nfrom the module's root (a leading / dropped), from the host's resources, as a ByteArrayInputStream;\nnull when there is none.\n")

var Lit_367 *jrt.String = jrt.Intern("java/util/HashSet")

var Lit_368 *jrt.String = jrt.Intern("GetPackages__Set is Module.getPackages: the packages of the registered classes whose\nmodule is this one, and the packages of module_table.ae for a named module, as a HashSet.\n")

var Lit_369 *jrt.String = jrt.Intern("Ljava/util/Set;")

var Lit_370 *jrt.String = jrt.Intern("AccessFlags__Set is Class.accessFlags: AccessFlagSupport.classAccessFlags (jdk26u's Class.accessFlags).\n")

var Lit_371 *jrt.String = jrt.Intern("AccessFlags__Set is Method.accessFlags (Executable's): AccessFlagSupport.executableAccessFlags of the modifiers.\n")

var Lit_372 *jrt.String = jrt.Intern("AccessFlags__Set is Constructor.accessFlags (Executable's): AccessFlagSupport.executableAccessFlags of the modifiers.\n")

var Lit_373 *jrt.String = jrt.Intern("AccessFlags__Set is Field.accessFlags: AccessFlagSupport.fieldAccessFlags of the modifiers.\n")

var Lit_374 *jrt.String = jrt.Intern("arbace.j2g.out$support_forms$iter__34000565__34000569")

var Lit_375 *jrt.String = jrt.Intern("jdk/internal/jrt/DefaultZone")

var Lit_376 *jrt.String = jrt.Intern("arbace.j2g.out$support_forms$iter__34000575__34000579")

var Lit_377 *jrt.String = jrt.Intern("j2g: not translated: ")

var Lit_378 *jrt.String = jrt.Intern("j2g: ")

var Lit_379 *jrt.String = jrt.Intern("java/util/Objects")

var Lit_380 *jrt.String = jrt.Intern("java/util/Formatter")

var Lit_381 *jrt.String = jrt.Intern("go/arbace/jrt/string.ae")

var Lit_382 *jrt.String = jrt.Intern("String_Format_String_O1__String")

var Lit_383 *jrt.String = jrt.Intern("java/lang/Iterable")

var Lit_384 *jrt.String = jrt.Intern("java/lang/CharSequence")

var Lit_385 *jrt.String = jrt.Intern("java/io/PrintWriter")

var Lit_386 *jrt.String = jrt.Intern("J2g_PrintStackTraceWriter is Throwable.printStackTrace(PrintWriter): the trace's text printed.\n")

var Lit_387 *jrt.String = jrt.Intern("Ljava/io/PrintWriter;")

var Lit_388 *jrt.String = jrt.Intern("java/io/PrintStream")

var Lit_389 *jrt.String = jrt.Intern("J2g_PrintStackTraceStream is Throwable.printStackTrace(PrintStream).\n")

var Lit_390 *jrt.String = jrt.Intern("Ljava/io/PrintStream;")

var Lit_391 *jrt.String = jrt.Intern("java/util/HashMap")

var Lit_392 *jrt.String = jrt.Intern("java/util/Collections")

var Lit_393 *jrt.String = jrt.Intern("J2g_SystemGetenv is System.getenv(): the host's environment as an unmodifiable map.\n")

var Lit_394 *jrt.String = jrt.Intern("Ljava/util/Map;")

var Lit_395 *jrt.String = jrt.Intern("java/util/Properties")

var Lit_396 *jrt.String = jrt.Intern("J2g_SystemGetProperties is System.getProperties(): a Properties with the system properties\n(a copy: the Go build keeps them in jrt's table, System.setProperty's).\n")

var Lit_397 *jrt.String = jrt.Intern("Ljava/util/Properties;")

var Lit_398 *jrt.String = jrt.Intern("System_GetProperties__Properties is System.getProperties() as translated code calls it\n(m/j2g-static?).\n")

var Lit_399 *jrt.String = jrt.Intern("java/lang/Thread")

var Lit_400 *jrt.String = jrt.Intern("Thread_GetAllStackTraces__Map is Thread.getAllStackTraces(): a HashMap of each live thread to its stack\n(stackOf: the current thread's own, a waiting thread's as it began to wait, an empty array otherwise).\n")

var Lit_401 *jrt.String = jrt.Intern("jdk/internal/jrt/StandardStreams")

var Lit_402 *jrt.String = jrt.Intern("System_SetIn_InputStream__V is System.setIn.\n")

var Lit_403 *jrt.String = jrt.Intern("System_SetOut_PrintStream__V is System.setOut.\n")

var Lit_404 *jrt.String = jrt.Intern("System_SetErr_PrintStream__V is System.setErr.\n")

var Lit_405 *jrt.String = jrt.Intern("jdk/internal/jrt/CaseInsensitiveComparator")

var Lit_406 *jrt.String = jrt.Intern("Ljava/util/Comparator;")

var Lit_407 *jrt.String = jrt.Intern("arbace.j2g.out$support_forms$iter__34000503__34000507$fn__34000508")

var Lit_408 *jrt.String = jrt.Intern("arbace.j2g.out$support_forms$iter__34000503__34000507$fn__34000508$fn__34000509")

var Lit_409 *jrt.String = jrt.Intern("arbace.j2g.out$support_forms$iter__34000503__34000507$fn__34000508$iter__34000529__34000533")

var Lit_410 *jrt.String = jrt.Intern("exec")

var Lit_411 *jrt.String = jrt.Intern("J2g_Runtime")

var Lit_412 *jrt.String = jrt.Intern(" is Runtime.exec")

var Lit_413 *jrt.String = jrt.Intern(": jrt's own Java RuntimeExec's.\n")

var Lit_414 *jrt.String = jrt.Intern("Ljava/lang/Runtime;")

var Lit_415 *jrt.String = jrt.Intern("arbace.j2g.out$support_forms$iter__34000503__34000507$fn__34000508$fn__34000539")

var Lit_416 *jrt.String = jrt.Intern("RuntimeExec_")

var Lit_417 *jrt.String = jrt.Intern("arbace.j2g.out$support_forms$iter__34000503__34000507$fn__34000508$fn__34000509$iter__34000513__34000517")

var Lit_418 *jrt.String = jrt.Intern("arbace.j2g.out$support_forms$iter__34000503__34000507$fn__34000508$fn__34000509$fn__34000523")

var Lit_419 *jrt.String = jrt.Intern("arbace.j2g.out$support_forms$iter__34000503__34000507$fn__34000508$fn__34000509$iter__34000513__34000517$fn__34000518")

var Lit_420 *jrt.String = jrt.Intern("arbace.j2g.out$support_forms$iter__34000503__34000507$fn__34000508$fn__34000509$iter__34000513__34000517$fn__34000518$fn__34000519")

var Lit_421 *jrt.String = jrt.Intern("arbace.j2g.out$support_forms$iter__34000503__34000507$fn__34000508$iter__34000529__34000533$fn__34000534")

var Lit_422 *jrt.String = jrt.Intern("arbace.j2g.out$support_forms$iter__34000503__34000507$fn__34000508$iter__34000529__34000533$fn__34000534$fn__34000535")

var Lit_423 *jrt.String = jrt.Intern("arbace.j2g.out$support_forms$iter__34000543__34000547$fn__34000548")

var Lit_424 *jrt.String = jrt.Intern("arbace.j2g.out$support_forms$iter__34000543__34000547$fn__34000548$fn__34000549")

var Lit_425 *jrt.String = jrt.Intern("getSystem")

var Lit_426 *jrt.String = jrt.Intern("ClassPathResources_")

var Lit_427 *jrt.String = jrt.Intern(" is ClassLoader.")

var Lit_428 *jrt.String = jrt.Intern(": the system loader's, jdk.internal.jrt.ClassPathResources'.\n")

var Lit_429 *jrt.String = jrt.Intern(" of a loader: its own override, else\njdk.internal.jrt.ClassPathResources'.\n")

var Lit_430 *jrt.String = jrt.Intern("arbace.j2g.out$support_forms$iter__34000565__34000569$fn__34000570")

var Lit_431 *jrt.String = jrt.Intern("arbace.j2g.out$support_forms$iter__34000565__34000569$fn__34000570$fn__34000571")

var Lit_432 *jrt.String = jrt.Intern("GetParameters__Parameter1 is ")

var Lit_433 *jrt.String = jrt.Intern(".getParameters (Executable's): the synthesized parameters, arg0 ... with\nmodifiers 0 (jdk26u's synthesizeAllParams: no MethodParameters records in the Go build).\n")

var Lit_434 *jrt.String = jrt.Intern("arbace.j2g.out$support_forms$iter__34000575__34000579$fn__34000580")

var Lit_435 *jrt.String = jrt.Intern("arbace.j2g.out$support_forms$iter__34000575__34000579$fn__34000580$fn__34000581")

var Lit_436 *jrt.String = jrt.Intern("SharedSecrets_")

var Lit_437 *jrt.String = jrt.Intern("__")

var Lit_438 *jrt.String = jrt.Intern(" is SharedSecrets' setter (m/serial-accessors).\n")

var Lit_439 *jrt.String = jrt.Intern(" is SharedSecrets' getter: ")

var Lit_440 *jrt.String = jrt.Intern(" initialized first when the access is not set yet.\n")

var Lit_441 *jrt.String = jrt.Intern("arbace.j2g.out$support_table_forms$sig__34000834")

var Lit_442 *jrt.String = jrt.Intern("format")

var Lit_443 *jrt.String = jrt.Intern("formatted")

var Lit_444 *jrt.String = jrt.Intern("lines")

var Lit_445 *jrt.String = jrt.Intern("describeConstable")

var Lit_446 *jrt.String = jrt.Intern("join")

var Lit_447 *jrt.String = jrt.Intern("matches")

var Lit_448 *jrt.String = jrt.Intern("replaceAll")

var Lit_449 *jrt.String = jrt.Intern("replaceFirst")

var Lit_450 *jrt.String = jrt.Intern("split")

var Lit_451 *jrt.String = jrt.Intern("arbace.j2g.out$support_table_forms$iter__34000836__34000840")

var Lit_452 *jrt.String = jrt.Intern("arbace.j2g.out$support_table_forms$iter__34000852__34000856")

var Lit_453 *jrt.String = jrt.Intern("printStackTrace")

var Lit_454 *jrt.String = jrt.Intern("arbace.j2g.out$support_table_forms$iter__34000868__34000872")

var Lit_455 *jrt.String = jrt.Intern("version")

var Lit_456 *jrt.String = jrt.Intern("arbace.j2g.out$support_table_forms$iter__34000884__34000888")

var Lit_457 *jrt.String = jrt.Intern("getContextClassLoader")

var Lit_458 *jrt.String = jrt.Intern("setContextClassLoader")

var Lit_459 *jrt.String = jrt.Intern("getResourceAsStream")

var Lit_460 *jrt.String = jrt.Intern("getResource")

var Lit_461 *jrt.String = jrt.Intern("getResources")

var Lit_462 *jrt.String = jrt.Intern("from")

var Lit_463 *jrt.String = jrt.Intern("toInstant")

var Lit_464 *jrt.String = jrt.Intern("arbace.j2g.out$support_table_forms$ref__34000900")

var Lit_465 *jrt.String = jrt.Intern("err")

var Lit_466 *jrt.String = jrt.Intern("out")

var Lit_467 *jrt.String = jrt.Intern("setErr")

var Lit_468 *jrt.String = jrt.Intern("setIn")

var Lit_469 *jrt.String = jrt.Intern("setOut")

var Lit_470 *jrt.String = jrt.Intern("arbace.j2g.out$support_table_forms$iter__34000836__34000840$fn__34000841")

var Lit_471 *jrt.String = jrt.Intern("arbace.j2g.out$support_table_forms$iter__34000836__34000840$fn__34000841$fn__34000842")

var Lit_472 *jrt.String = jrt.Intern("arbace.j2g.out$support_table_forms$iter__34000852__34000856$fn__34000857")

var Lit_473 *jrt.String = jrt.Intern("arbace.j2g.out$support_table_forms$iter__34000852__34000856$fn__34000857$fn__34000858")

var Lit_474 *jrt.String = jrt.Intern("accessFlags")

var Lit_475 *jrt.String = jrt.Intern("arbace.j2g.out$support_table_forms$iter__34000868__34000872$fn__34000873")

var Lit_476 *jrt.String = jrt.Intern("arbace.j2g.out$support_table_forms$iter__34000868__34000872$fn__34000873$fn__34000874")

var Lit_477 *jrt.String = jrt.Intern("arbace.j2g.out$support_table_forms$iter__34000884__34000888$fn__34000889")

var Lit_478 *jrt.String = jrt.Intern("arbace.j2g.out$support_table_forms$iter__34000884__34000888$fn__34000889$fn__34000890")

var Lit_479 *jrt.String = jrt.Intern("getParameters")

var Lit_480 *jrt.String = jrt.Intern("__AnnotatedType")

var Lit_481 *jrt.String = jrt.Intern("1")

var Lit_482 *jrt.String = jrt.Intern("arbace.j2g.out$ta_support_forms$iter__34000484__34000488")

var Lit_483 *jrt.String = jrt.Intern("arbace.j2g.out$ta_support_forms$iter__34000484__34000488$fn__34000489")

var Lit_484 *jrt.String = jrt.Intern("arbace.j2g.out$ta_support_forms$iter__34000484__34000488$fn__34000489$fn__34000490")

var Lit_485 *jrt.String = jrt.Intern("TypeAnnotationSupport_")

var Lit_486 *jrt.String = jrt.Intern("sun/reflect/annotation/TypeAnnotationParser")

var Lit_487 *jrt.String = jrt.Intern("arbace.j2g.out$unlined_texts$one__34000046")

var Lit_488 *jrt.String = jrt.Intern("arbace.j2g.out$unlined_texts$fn__34000048")

var Lit_489 *jrt.String = jrt.Intern("arbace.j2g.out$ups_forms$iter__34000097__34000101")

var Lit_490 *jrt.String = jrt.Intern("arbace.j2g.out$ups_forms$iter__34000097__34000101$fn__34000102")

var Lit_491 *jrt.String = jrt.Intern("arbace.j2g.out$ups_forms$iter__34000097__34000101$fn__34000102$fn__34000103")

var Lit_492 *jrt.String = jrt.Intern("Up_")

var Lit_493 *jrt.String = jrt.Intern("arbace.j2g.out$used_qualifiers$w__34000034")

var Lit_494 *jrt.String = jrt.Intern("[")

var Lit_495 *jrt.String = jrt.Intern("]")

var Lit_496 *jrt.String = jrt.Intern("{")

var Lit_497 *jrt.String = jrt.Intern("}")

var Lit_498 *jrt.String = jrt.Intern("arbace.j2g.out$write_form$fn__34000030")

var Lit_499 *jrt.String = jrt.Intern("^")

var Lit_500 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn3,symyn4,typekn4,linekn6,columnkn4,filekn7,dynamicyn1,fkn8,declaredkn3,tagyn6,Stringyn4,longyn13,StringBuilderyn3,layyn2,mtyn2,xsyn5,formsyn3,pkgyn7,go-nameyn1,&yn6,headeryn3,topyn4,litsyn3,upsyn3,keyys2,go6,methodyn21,Split_String__String1yn1,*yn8,RefArrayyn24,.Split_String_I__String1yn1,tyn5,regexyn23,Split_String_I__String1yn5,int32yn30,.Split_CharSequence_I__String1yn31,Pattern_Compile_String__Patternyn5,limityn32,ReplaceAll_String_String__Stringyn26,.ReplaceAll_String__Stringyn30,.Matcher_CharSequence__Matcheryn11,replacementyn34,ReplaceFirst_String_String__Stringyn28,.ReplaceFirst_String__Stringyn17,Matches_String__Zyn4,boolyn38,Pattern_Matches_String_CharSequence__Zyn1,nyn4,nameyn4,descyn2,jmyn3,arryn1,dyn1,xyn4,callyn3,mmsyn1,gkn4,keysyn7,methodsyn5,ctorsyn6,fieldsyn3,cutyn7,classesyn4,cutsyn5,constv11,arbace.core5,in-nsMyn14,arbace.j2g.outm2,R0,s358,j2g's output (J2G-SPEC §4.3): Go forms files, one per Java forms file, plus the generated\n  files of each package (j2g_classes: registrations and member tables, §5.11; j2g_strings: the\n  literal pool, §7.5; j2g_frames: the frame table, §7.9.6; j2g_support: j2g's helpers), and\n  the merge with jrt's hand-written forms into one program root for bin/build-go.m2,R0,s358,j2g's output (J2G-SPEC §4.3): Go forms files, one per Java forms file, plus the generated\n  files of each package (j2g_classes: registrations and member tables, §5.11; j2g_strings: the\n  literal pool, §7.5; j2g_frames: the frame table, §7.9.6; j2g_support: j2g's helpers), and\n  the merge with jrt's hand-written forms into one program root for bin/build-go.R1,v14,arbace.j2g.out3,tagm10,R2,TR3,L1,V2,R4,R5,R6,i20,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out9,*renames*m10,R9,TR6,i25,R7,i1,R8,s17,arbace/j2g/out.aeR0,s256,nil, or a map of symbols to the symbols clean writes in their place: the literals of the\n  classes translated in parallel, named apart (Lit?i_k), to their names in the package's\n  literal pool (Lit_n; arbace.j2g.main; J2G-SPEC §4.1, \"The run in parallel\").v14,arbace.j2g.out5,cleanm10,R3,L1,V1,R10,R0,s117,f without the reader's position metadata (quoted forms in j2g's source carry it), its\n  symbols renamed by *renames*.R6,i31,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out10,write-formm8,R11,TR6,i48,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out8,newlinesm12,R2,TR3,L1,MV1,Myn1,sm2,R12,R13,m2,R12,R14,R0,s28,The number of newlines in s.R6,i58,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out4,out!m10,R2,TR3,L1,V3,Myn2,sbm2,R12,R15,R16,Myn1,sm2,R12,R13,R6,i64,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out10,write-metam10,R2,TR3,L1,V3,Myn2,sbm2,R12,R15,R16,R17,R6,i70,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out11,write-itemsm10,R2,TR3,L1,V3,Myn2,sbm2,R12,R15,R16,R18,R6,i78,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out10,write-listm10,R2,TR3,L1,V4,Myn2,sbm2,R12,R15,R16,R10,R17,R6,i85,R7,i1,R8,s17,arbace/j2g/out.aem10,R2,TR3,L1,V3,Myn2,sbm2,R12,R15,R16,R10,R6,i101,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out9,form-textm8,R3,L1,V1,R10,R6,i120,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out12,import-pathsm22,s4,langs11,arbace/langs7,stringss7,stringss3,gois10,arbace/gois3,jrts10,arbace/jrts7,reflects7,reflects6,unsafes6,unsafes4,maths4,maths4,syncs4,syncs7,cinterps14,arbace/cinterps9,scminterps16,arbace/scminterps6,atomics11,sync/atomicm6,R6,i125,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out15,used-qualifiersm10,R2,TR3,L1,V1,R19,R6,i130,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out6,lined?m12,R2,TR3,L1,V1,R10,R0,s151,Does form f hold a list with a Java forms line (:j2g/line), its tags included? Then its\n  text depends on the line it starts on (write-list); else not.R6,i143,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out9,split-minl256,m10,R2,TR6,i154,R7,i1,R8,s17,arbace/j2g/out.aeR0,s159,A file of this many forms or more has the texts of its forms without lines computed in\n  parallel (j2g_classes.go: 8,000 registrations), before it is laid out.v14,arbace.j2g.out13,unlined-textsm12,R2,TR3,L1,V1,R19,R0,s274,For the forms of a long file (split-min), by index, the text of each form that holds no line\n  (lined?), cleaned and written as file-text writes it (its text does not depend on where it\n  starts), or nil for the others; computed in parallel, by chunks. nil for a short file.R6,i159,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out9,file-textm10,R3,L1,V5,R20,R21,R19,R22,V1,R23,R0,s149,The text of a Go forms file of package pkg named go-name holding forms (a long one's forms\n  without lines written in parallel first, unlined-texts).R6,i175,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out12,go-file-namem10,R3,L1,V2,R20,R24,R0,s424,The Go file of a Java forms file (§4.3): its name for arbace/lang, the Java source path\n  with _ for / in jrt, and J_ and the path with _ for / for a class outside the runtime and the\n  JDK in lang (nm/user-class?, JCS15 (a): two packages' files of one name, or of names equal but\n  for case, do not collide, nor one of the unnamed package with the runtime's);\n  _j2g appended when the name would read as a build constraint.R6,i214,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out15,lone-surrogate?m12,R2,TR3,L1,V1,Myn1,sm2,R12,R13,R0,s58,Does string s hold a surrogate that is not half of a pair?R6,i235,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out13,strings-formsm10,R3,L1,V2,R20,R25,R0,s71,The literal pool (§7.5): Lit_n vars interned at package initialization.R6,i249,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out9,ups-formsm10,R3,L1,V2,R20,R26,R0,s74,The nil-preserving conversions Up_From_To (§5.6) the package's code needs.R6,i260,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out8,arg-convm8,R11,TR6,i270,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out10,result-anym8,R11,TR6,i270,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out11,dotted-descm8,R11,TR6,i270,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out17,member-table-formm8,R11,TR6,i270,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out13,adapter-formsm10,R3,L1,V2,R20,R27,R0,s116,The adapter F_Fn of functional interface fi (§7.11): its SAM calls Fn, default methods\n  forward to their functions.R6,i272,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out20,string-regex-methodsV5,V2,s21,Split_String__String1ML5,R28,R29,s46,Split_String__String1 is String.split(regex).\nMV2,Myn1,tm2,R12,ML2,R30,R13,m4,R6,i393,R7,i37,Myn5,regexm2,R12,ML2,R30,R13,m4,R6,i393,R7,i58,m2,R12,ML2,R30,R31,m4,R6,i393,R7,i15,ML4,R32,R33,R34,l0,m4,R6,i394,R7,i8,m4,R6,i392,R7,i6,V2,s23,Split_String_I__String1ML5,R28,R35,s55,Split_String_I__String1 is String.split(regex, limit).\nMV3,Myn1,tm2,R12,ML2,R30,R13,m4,R6,i397,R7,i37,Myn5,regexm2,R12,ML2,R30,R13,m4,R6,i397,R7,i58,Myn5,limitm2,R12,R36,m2,R12,ML2,R30,R31,m4,R6,i397,R7,i15,ML4,R37,ML2,R38,R34,m4,R6,i398,R7,i40,R33,R39,m4,R6,i398,R7,i8,m4,R6,i396,R7,i6,V2,s32,ReplaceAll_String_String__StringML5,R28,R40,s55,ReplaceAll_String_String__String is String.replaceAll.\nMV3,Myn1,tm2,R12,ML2,R30,R13,m4,R6,i401,R7,i35,Myn5,regexm2,R12,ML2,R30,R13,m4,R6,i401,R7,i56,Myn11,replacementm2,R12,ML2,R30,R13,m4,R6,i401,R7,i81,m2,R12,ML2,R30,R13,m4,R6,i401,R7,i15,ML3,R41,ML3,R42,ML2,R38,R34,m4,R6,i402,R7,i68,R33,m4,R6,i402,R7,i36,R43,m4,R6,i402,R7,i8,m4,R6,i400,R7,i6,V2,s34,ReplaceFirst_String_String__StringML5,R28,R44,s59,ReplaceFirst_String_String__String is String.replaceFirst.\nMV3,Myn1,tm2,R12,ML2,R30,R13,m4,R6,i405,R7,i35,Myn5,regexm2,R12,ML2,R30,R13,m4,R6,i405,R7,i56,Myn11,replacementm2,R12,ML2,R30,R13,m4,R6,i405,R7,i81,m2,R12,ML2,R30,R13,m4,R6,i405,R7,i15,ML3,R45,ML3,R42,ML2,R38,R34,m4,R6,i406,R7,i70,R33,m4,R6,i406,R7,i38,R43,m4,R6,i406,R7,i8,m4,R6,i404,R7,i6,V2,s17,Matches_String__ZML5,R28,R46,s37,Matches_String__Z is String.matches.\nMV2,Myn1,tm2,R12,ML2,R30,R13,m4,R6,i409,R7,i22,Myn5,regexm2,R12,ML2,R30,R13,m4,R6,i409,R7,i43,m2,R12,R47,ML3,R48,R34,R33,m4,R6,i410,R7,i8,m4,R6,i408,R7,i6,m8,R6,i386,R7,i1,R8,s17,arbace/j2g/out.aeR0,s319,String's methods over java.util.regex, which j2g writes into jrt's j2g_support when Pattern is\n  translated (jrt's String is hand-written; JRT-NOTES.md, \"waiting for the regex port\"): Go\n  method name, then its definition as jdk26u's String defines it (split's one-character fast\n  path gives what Pattern.split gives).v14,arbace.j2g.out10,java-namesm2,s42,jdk/internal/jrt/CaseInsensitiveComparators42,java.lang.String$CaseInsensitiveComparatorm8,R6,i412,R7,i1,R8,s17,arbace/j2g/out.aeR0,s170,Classes of jrt's own Java (overlay/jdk) that stand for a JDK class jrt cannot translate (a\n  nested class of a hand-written one): the name Class.getName answers for them.v14,arbace.j2g.out9,java-namem8,R3,L1,V1,R49,R6,i417,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out22,jrt-default-forwardersm10,R3,L1,V0,R0,s343,Forwarders on jrt's hand-written leaf classes to the default methods of translated\n  interfaces they implement and do not define themselves (CharSequence's chars and\n  codePoints on String, StringBuilder and StringBuffer once streams are in the world): Go's\n  interface satisfaction needs the methods, which jrt's own build cannot name (§5.4).R6,i419,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out17,fjp-support-classm6,R6,i444,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out19,fjp-support-methodsV5,V2,s11,shutdownNows18,()Ljava/util/List;V2,s9,invokeAlls40,(Ljava/util/Collection;)Ljava/util/List;V2,s9,invokeAlls72,(Ljava/util/Collection;JLjava/util/concurrent/TimeUnit;)Ljava/util/List;V2,s9,invokeAnys42,(Ljava/util/Collection;)Ljava/lang/Object;V2,s9,invokeAnys74,(Ljava/util/Collection;JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;m8,R6,i446,R7,i1,R8,s17,arbace/j2g/out.aeR0,s245,The methods of ExecutorService jrt's hand-written ForkJoinPool cannot define (their types are\n  translated), as [name desc]: j2g gives ForkJoinPool Go methods calling jrt's own\n  jdk.internal.jrt.ForkJoinPools (JRT-NOTES.md, \"Concurrency\", JC7).v14,arbace.j2g.out15,fjp-support-keym10,R3,L1,V1,V2,R50,R51,R0,s93,The static method of ForkJoinPools behind ExecutorService method [name desc]: the pool first.R6,i456,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out17,fjp-support-formsm10,R3,L1,V0,R0,s133,ForkJoinPool's Go methods for fjp-support-methods, once ExecutorService and ForkJoinPools are\n  translated and ForkJoinPool is jrt's.R6,i461,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out13,access-flags?m10,R3,L1,V0,R0,s132,Whether j2g writes Class, Method, Constructor and Field's accessFlags (JCS273): AccessFlag and jrt's\n  AccessFlagSupport translated.R6,i476,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out11,parameters?m10,R3,L1,V0,R0,s111,Whether j2g writes Method and Constructor's getParameters (JCS280 (a)): java.lang.reflect.Parameter translated.R6,i482,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out16,parameters-rootsV1,V3,s27,java/lang/reflect/Parameters6,<init>s53,(Ljava/lang/String;ILjava/lang/reflect/Executable;I)Vm8,R6,i487,R7,i1,R8,s17,arbace/j2g/out.aeR0,s108,What the getParameters methods j2g writes call (JCS280 (a)): Parameter's constructor, a root of the program.v14,arbace.j2g.out18,access-flags-rootsV3,V3,s34,jdk/internal/jrt/AccessFlagSupports16,classAccessFlagss34,(Ljava/lang/Class;)Ljava/util/Set;V3,s34,jdk/internal/jrt/AccessFlagSupports21,executableAccessFlagss35,(ILjava/lang/Class;)Ljava/util/Set;V3,s34,jdk/internal/jrt/AccessFlagSupports16,fieldAccessFlagss35,(ILjava/lang/Class;)Ljava/util/Set;m8,R6,i491,R7,i1,R8,s17,arbace/j2g/out.aeR0,s111,What the accessFlags methods j2g writes call (JCS273): AccessFlagSupport's three methods, roots of the program.v14,arbace.j2g.out17,type-annotations?m10,R3,L1,V0,R0,s152,Whether j2g writes Class, Method, Constructor and Field's getAnnotated* (JCS271 (b)): TypeAnnotationParser and\n  jrt's TypeAnnotationSupport translated.R6,i497,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out21,type-annotation-callsm8,R6,i503,R7,i1,R8,s17,arbace/j2g/out.aeR0,s153,JCS271 (b): each getAnnotated* j2g writes, [jrt type, the Java method, its Go name, returns an array?,\n  TypeAnnotationSupport's method, its descriptor].v14,arbace.j2g.out10,ta-go-namem10,R2,TR3,L1,V2,R52,R53,R6,i519,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out23,type-annotation-methodsv11,arbace.core3,vecm8,R6,i521,R7,i1,R8,s17,arbace/j2g/out.aeR0,s59,The jrt types' methods the getAnnotated* add (main's scan).v14,arbace.j2g.out21,type-annotation-rootsv11,arbace.core8,distinctm8,R6,i525,R7,i1,R8,s17,arbace/j2g/out.aeR0,s115,What the getAnnotated* methods j2g writes call (JCS271 (b)): TypeAnnotationSupport's methods, roots of the program.v14,arbace.j2g.out16,ta-support-formsm12,R2,TR3,L1,V0,R0,s85,The getAnnotated* methods of jrt's Class, Method, Constructor and Field (JCS271 (b)).R6,i529,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out13,support-formsm10,R3,L1,V0,R0,s89,j2g's helpers in package jrt (j2g_support): what translated code calls besides jrt's API.R6,i545,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out9,modifiersm10,R2,TR3,L1,V1,R49,R6,i1013,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out8,kind-symm10,R2,TR3,L1,V2,R20,R49,R6,i1019,R7,i1,R8,s17,arbace/j2g/out.aem10,R2,TR3,L1,V3,R20,R54,R55,R6,i1025,R7,i1,R8,s17,arbace/j2g/out.aem10,R2,TR3,L1,V3,R20,R54,R56,R6,i1030,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out16,*absent-members*m10,R9,TR6,i1035,R7,i1,R8,s17,arbace/j2g/out.aeR0,s90,Whether member tables list the public methods that do not exist in Go (bin/j2g --program).v14,arbace.j2g.out12,method-orderm12,R2,TR3,L1,V2,R49,R57,R0,s279,The order of the JVM's getDeclaredMethods for the overloads of class n among methods mms, when\n  it is stable (edge/archived-classes): {name [[parameter binary names] ...]} for each name of more\n  than one of mms, the parameter lists in the order of their (last) index; else nil.R6,i1039,R7,i1,R8,s17,arbace/j2g/out.aem12,R2,TR3,L1,V1,R54,R0,s87,A descriptor with binary names (java.util.Map$Entry), as jrt's member tables hold them.R6,i1057,R7,i1,R8,s17,arbace/j2g/out.aem10,R3,L1,V3,R20,R58,m2,R59,V4,R60,R61,R62,R63,R0,s329,The MemberTable of class g's tables {:methods :ctors :fields} (amendment SZ3): the members'\n  lines as data, and per kind one dispatch function, a switch over the member's index among\n  its kind's (a member without a :body has none: jrt throws); [the dispatch functions' forms,\n  the table's form], nil when there are no members.R6,i1062,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out13,member-tablesm10,R3,L1,V2,R20,R49,R0,s209,The member tables (§5.11, amendment R12) of translated class n: its public members, as\n  {:methods :ctors :fields} of {:line (data) :body (the dispatch case's statements; none:\n  absent)} (fields: :get, :set).R6,i1091,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out18,class-registrationm10,R3,L1,V2,R20,R49,R0,s117,C_class (Define, hierarchy only) and the init function setting its function and table\n  fields (§5.11, amendment J1).R6,i1228,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out9,cut-formsm10,R3,L1,V2,R20,R64,R0,s207,Class objects of classes outside the closed world that code names (class literals):\n  registered by name only, so that Class.forName finds them and nothing is their instance\n  (\"cut\" classes, J2G-SPEC §4.1).R6,i1316,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out19,support-table-formsm10,R3,L1,V0,R0,s362,The member table entries of jrt's statics and methods that j2g writes (J2G-NOTES.md, phase\n  2C: String.format, String's regex methods, System.in, out, err and their setters), so that\n  reflection finds them at the REPL (System/out, String/format). In reflect_tables_j2g.go: its\n  init runs after reflect_tables.go's, which sets the hand-written classes' tables.R6,i1340,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out13,cut-type-exprm12,R2,TR3,L1,V3,R20,R65,R54,R0,s228,The Class expression of type descriptor d (a cut class's member names it) from pkg, or nil\n  when the Go build has no Class object for it there (a class outside the world that is not\n  cut, or one of arbace/lang named from jrt).R6,i1580,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out12,cut-constantm12,R2,TR3,L1,V2,R20,m2,R59,V2,R5,R66,R0,s275,The Go value of a cut class's constant (static final, of a primitive type or String: its\n  value, read by reflection when the edge was recorded), else nil: cut classes' constants are\n  readable (ASM's Opcodes in the Java forms compiler's analysis, doc/go/CLASSFORMS-REPL.md).R6,i1597,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out17,cut-class-membersm12,R2,TR3,L1,V1,R49,R0,s262,The public members class n declares on this JVM, as the edge's :cut records them, or nil:\n  {:methods [{:mods :name :params [desc] :ret desc}] :fields [{:mods :name :type desc :const v}]\n  :ctors [{:mods :params [desc]}]}, each in the order of the member tables.R6,i1613,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out15,cut-table-formsm10,R3,L1,V3,R20,R65,R64,R0,s471,The member tables of the cut classes of pkg (J2G-SPEC §4.1, D6; doc/go/EVAL-NOTES.md): their\n  public members as the JVM reports them (the edge's :cut), whose types the Go build can name,\n  each throwing UnsupportedOperationException when called, so that code naming them analyzes\n  (core's annotation support names ASM's Type) and fails only when run. As MemberTables\n  (amendment SZ3) whose functions are nil (jrt throws, MemberTable.Cut) but for a constant's\n  getter.R6,i1646,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out11,start-formsm10,R3,L1,V2,R20,R64,R0,s216,The registration of the classes initialized at start (arbace.j2g.start; Futamura F4), in\n  their order, with jrt.RegisterStartClasses: their initialization states, C_Init functions and\n  Go names, for jrt.StartCheck.R6,i1686,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out12,frames-formsm10,R3,L1,V2,R20,R64,R0,s130,The frame table (§7.9.6, amendment J4): entries for methods whose Java names the demangler\n  cannot read back (names with _ or $).R6,i1699,R7,i1,R8,s17,arbace/j2g/out.ae")

var Lit_501 *jrt.String = jrt.Intern("arbace.j2g.out$eval34000004$loading__1927001464__auto____34000005")

var Lit_502 *jrt.String = jrt.Intern("arbace.j2g.out$eval34000008$fn__34000009")

var Lit_503 *jrt.String = jrt.Intern("arbace.j2g.out$tag")

var Lit_504 *jrt.String = jrt.Intern("arbace.j2g.out$clean")

var Lit_505 *jrt.String = jrt.Intern("arbace.j2g.out$newlines")

var Lit_506 *jrt.String = jrt.Intern("arbace.j2g.out$out_BANG_")

var Lit_507 *jrt.String = jrt.Intern("arbace.j2g.out$write_meta")

var Lit_508 *jrt.String = jrt.Intern("arbace.j2g.out$write_items")

var Lit_509 *jrt.String = jrt.Intern("arbace.j2g.out$write_list")

var Lit_510 *jrt.String = jrt.Intern("arbace.j2g.out$write_form")

var Lit_511 *jrt.String = jrt.Intern("arbace.j2g.out$form_text")

var Lit_512 *jrt.String = jrt.Intern("arbace.j2g.out$used_qualifiers")

var Lit_513 *jrt.String = jrt.Intern("arbace.j2g.out$lined_QMARK_")

var Lit_514 *jrt.String = jrt.Intern("arbace.j2g.out$unlined_texts")

var Lit_515 *jrt.String = jrt.Intern("arbace.j2g.out$file_text")

var Lit_516 *jrt.String = jrt.Intern("arbace.j2g.out$go_file_name")

var Lit_517 *jrt.String = jrt.Intern("arbace.j2g.out$lone_surrogate_QMARK_")

var Lit_518 *jrt.String = jrt.Intern("arbace.j2g.out$strings_forms")

var Lit_519 *jrt.String = jrt.Intern("arbace.j2g.out$ups_forms")

var Lit_520 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms")

var Lit_521 *jrt.String = jrt.Intern("arbace.j2g.out$java_name")

var Lit_522 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders")

var Lit_523 *jrt.String = jrt.Intern("jdk/internal/jrt/ForkJoinPools")

var Lit_524 *jrt.String = jrt.Intern("arbace.j2g.out$fjp_support_key")

var Lit_525 *jrt.String = jrt.Intern("arbace.j2g.out$fjp_support_forms")

var Lit_526 *jrt.String = jrt.Intern("arbace.j2g.out$access_flags_QMARK_")

var Lit_527 *jrt.String = jrt.Intern("arbace.j2g.out$parameters_QMARK_")

var Lit_528 *jrt.String = jrt.Intern("arbace.j2g.out$type_annotations_QMARK_")

var Lit_529 *jrt.String = jrt.Intern("arbace.j2g.out$fn__34000423")

var Lit_530 *jrt.String = jrt.Intern("arbace.j2g.out$ta_go_name")

var Lit_531 *jrt.String = jrt.Intern("arbace.j2g.out$fn__34000452")

var Lit_532 *jrt.String = jrt.Intern("arbace.j2g.out$fn__34000470")

var Lit_533 *jrt.String = jrt.Intern("arbace.j2g.out$ta_support_forms")

var Lit_534 *jrt.String = jrt.Intern("arbace.j2g.out$support_forms")

var Lit_535 *jrt.String = jrt.Intern("arbace.j2g.out$modifiers")

var Lit_536 *jrt.String = jrt.Intern("arbace.j2g.out$kind_sym")

var Lit_537 *jrt.String = jrt.Intern("arbace.j2g.out$arg_conv")

var Lit_538 *jrt.String = jrt.Intern("arbace.j2g.out$result_any")

var Lit_539 *jrt.String = jrt.Intern("arbace.j2g.out$method_order")

var Lit_540 *jrt.String = jrt.Intern("arbace.j2g.out$dotted_desc")

var Lit_541 *jrt.String = jrt.Intern("arbace.j2g.out$member_table_form")

var Lit_542 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables")

var Lit_543 *jrt.String = jrt.Intern("arbace.j2g.out$class_registration")

var Lit_544 *jrt.String = jrt.Intern("arbace.j2g.out$cut_forms")

var Lit_545 *jrt.String = jrt.Intern("arbace.j2g.out$support_table_forms")

var Lit_546 *jrt.String = jrt.Intern("arbace.j2g.out$cut_type_expr")

var Lit_547 *jrt.String = jrt.Intern("arbace.j2g.out$cut_constant")

var Lit_548 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members")

var Lit_549 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms")

var Lit_550 *jrt.String = jrt.Intern("arbace.j2g.out$start_forms")

var Lit_551 *jrt.String = jrt.Intern("arbace.j2g.out$frames_forms")
