//line j2g_strings.ae:1
package aot_arbace_j2g_out

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn14,arbace.java.ioyn2,ioyn20,arbace.classes.typesyn1,tyn18,arbace.classes.envyn3,envyn22,arbace.classes.analyzeyn1,ayn16,arbace.j2g.modelyn1,myn16,arbace.j2g.namesyn2,nmyn14,arbace.j2g.jrtyn3,jrtyn15,arbace.j2g.codeyn1,cyn16,arbace.j2g.declsyn1,dyn15,arbace.j2g.edgeyn4,edgeyn22,arbace.classes.opcodesyn7,Opcodesyn11,arbace.corekn3,dockn3,tagkn4,linekn6,columnkn4,filekn8,end-linekn10,end-columnkn4,elseks3,j2g4,linekn4,metakn6,forcedys3,j2g7,commentys2,go4,filekn7,importskn3,jrtys2,go3,varyn1,*yn3,lityn5,sliceyn6,uint16ys2,go4,funcyn1,pyn4,whenyn2,==yn6,returnkn3,pkgkn4,descyn4,.-Fnys2,go4,typeyn6,structyn2,Fnys2,go6,methodkn4,namekn7,defaultkn4,kindkn5,owneryn5,panicyn3,Refyn3,anyyn15,GetClass__Classyn16,ToString__Stringyn8,Clone__Oyn4,addrkn4,Namekn9,Modifierskn4,Kindkn5,Superkn10,Interfaceskn2,Goyn4,funckn5,typeskn11,jrt-classesyn12,ForkJoinPoolyn27,DescribeConstable__Optionalyn6,Stringyn8,Optionalyn23,Optional_Of_O__Optionalyn13,Lines__Streamyn6,Streamyn3,letyn1,lyn13,ArrayList_Newyn5,rangeyn1,_yn1,xyn10,splitLinesyn7,.-valueyn9,.Add_O__Zyn14,NewStringUTF16yn15,.Stream__Streamyn39,GetResourceAsStream_String__InputStreamyn5,Classyn4,nameyn1,nyn7,.Stringyn2,NNyn2,ifys7,strings9,HasPrefixyn4,set!yn8,subsliceyn1,eyn5,whileyn11,.IsArray__Zyn24,.GetComponentType__Classyn2,cnyn6,.-Nameyn5,.Infoyn1,iys7,strings13,LastIndexByteyn2,>=yn1,+ys7,strings10,ReplaceAllyn6,valuesyn1,byn2,okyn14,ResourceOrPathyn3,notyn12,NewByteArrayyn4,convyn5,int32yn3,lenyn4,asetyn3,.-Ayn4,int8yn27,ByteArrayInputStream_New_B1yn14,j2gSetDateZoneyn4,boolyn14,DateZoneOffsetyn23,DefaultZone_Offset_J__Iyn20,DateZoneOffsetByWallyn29,DefaultZone_OffsetByWall_J__Iyn12,DateZoneNameyn2,fnyn5,int64yn6,stringyn26,DefaultZone_Name_J__Stringyn2,msyn9,J2g_Truthyn12,Boolean_Inityn2,!=yn13,Boolean_FALSEyn8,J2g_RefPkn11,type-paramsyn1,Tkn5,funcsyn31,String_Format_String_O1__Stringyn8,RefArrayyn17,.ToString__Stringyn28,.Format_String_O1__Formatteryn13,Formatter_Newyn6,formatyn4,argsyn20,Formatted_O1__Stringyn41,String_Join_CharSequence_Iterable__Stringyn12,CharSequenceyn8,Iterableyn3,sepyn3,NPEyn8,elementsyn2,ityn19,.Iterator__Iteratoryn11,.HasNext__Zyn2,esyn6,appendyn17,CharSequence_Castyn8,.Next__Oyn46,String_Join_CharSequence_CharSequence1__Stringyn10,RefArrayOfyn18,CharSequence_classyn6,spreadyn38,String_Format_Locale_String_O1__Stringyn6,Localeyn20,Formatter_New_Localeyn4,inityn30,CaseInsensitiveComparator_Inityn29,String_CASE_INSENSITIVE_ORDERyn34,CaseInsensitiveComparator_INSTANCEyn9,System_inyn31,StandardStreams_In__InputStreamyn10,System_outyn32,StandardStreams_Out__PrintStreamyn10,System_erryn32,StandardStreams_Err__PrintStreamyn4,hostyn11,StderrPrintyn16,.Print_String__Vyn3,Stryn1,syn9,.Flush__Vyn11,J2g_ObjHashyn8,HashCodeyn13,J2g_ObjEqualsyn2,oryn6,Equalsyn14,J2g_DoubleBitsyn7,float64ys4,math5,IsNaNys4,math11,Float64bitsyn12,J2g_BoolHashyn13,J2g_FloatBitsyn7,float32yn1,fys4,math11,Float32bitsyn22,J2g_AssertionsDisabledyn17,J2g_NotTranslatedyn4,whatyn11,Throwable_Iyn40,UnsupportedOperationException_New_Stringyn11,J2g_Missingyn3,whyyn6,Thrownyn11,J2g_NotNullyn13,J2g_CastArrayyn3,clsyn1,zyn4,zeroyn16,.IsInstance_O__Zyn9,ClassCastyn6,assertyn11,J2g_Discardyn25,J2g_PrintStackTraceWriteryn1,wyn16,StackTraceStringyn25,J2g_PrintStackTraceStreamyn16,J2g_SystemGetenvyn11,HashMap_Newyn2,kvyn8,.Environyn11,CurrentHostys7,strings9,IndexByteyn1,>yn11,.Put_O_O__Oyn36,Collections_UnmodifiableMap_Map__Mapyn23,J2g_SystemGetPropertiesyn14,Properties_Newyn1,kyn13,PropertyNamesyn1,vyn33,System_GetProperty_String__Stringyn29,.SetProperty_String_String__Oyn32,System_GetProperties__Propertiesyn27,System_SetIn_InputStream__Vyn2,inyn28,System_SetOut_PrintStream__Vyn3,outyn28,System_SetErr_PrintStream__Vyn3,erryn9,J2gCloneryn9,interfaceyn12,CloneShallowyn15,J2g_ObjectCloneyn13,.CloneShallowkn3,topkn7,nestingkn11,inner-flagskn5,flagskn9,interfacekn5,classkn4,enumkn10,annotationkn6,recordyn4,instkn7,methodskn5,ctorskn6,fieldskn3,cutyn4,caseyn6,switchkn4,bodyyn4,thiskn3,getyn1,okn3,setkn4,Datakn3,Cutkn6,Invokekn3,Newkn3,Getkn3,Setyn4,agetkn12,method-orderyn1,=yn5,countyn3,mmsyn7,methodskn5,outerkn6,memberkn6,simplekn9,reflectedkn5,superkn10,interfacesks3,c2j4,codekn9,Declaringkn6,Simpleks3,c2j6,sourcekn6,Sourceyn12,.-IsInstanceyn6,.-Inityn6,.-Enumyn7,.-Tableys7,reflect7,TypeForys3,j2g9,code-declkn3,Outyn10,MethodInfokn6,Paramskn6,Returnyn2,Asyn12,String_classyn11,.ArrayClassyn12,Object_classyn12,Locale_classyn21,.Formatted_O1__Stringyn12,Stream_classyn14,.Lines__Streamyn14,Optional_classyn28,.DescribeConstable__Optionalyn14,Iterable_classyn12,Prim_booleanyn18,.Matches_String__Zyn33,.ReplaceAll_String_String__Stringyn35,.ReplaceFirst_String_String__Stringyn22,.Split_String__String1yn8,Prim_intyn24,.Split_String_I__String1yn9,.-Methodsyn15,Throwable_classyn17,PrintStream_classyn9,Prim_voidyn2,doyn16,PrintStream_Castyn17,PrintWriter_classyn16,PrintWriter_Castyn12,System_classyn9,Map_classyn4,Fileyn13,Runtime_classyn13,Process_classyn32,RuntimeExec_Exec_String__Processyn40,RuntimeExec_Exec_String_String1__Processyn10,File_classyn45,RuntimeExec_Exec_String_String1_File__Processyn33,RuntimeExec_Exec_String1__Processyn41,RuntimeExec_Exec_String1_String1__Processyn46,RuntimeExec_Exec_String1_String1_File__Processyn16,Properties_classyn8,.-Fieldsyn9,FieldInfokn4,Typeyn16,Comparator_classyn12,Thread_classyn17,ClassLoader_classyn45,ClassLoader_GetSystemClassLoader__ClassLoaderyn9,URL_classyn54,ClassPathResources_GetResource_ClassLoader_String__URLyn13,ClassLoader_Iyn17,Enumeration_classyn63,ClassPathResources_GetResources_ClassLoader_String__Enumerationyn41,Collections_EmptyEnumeration__Enumerationyn17,InputStream_classyn10,Date_classyn13,Instant_classyn3,exckn7,resultsyn5,deferyn5,Catchyn10,Date_New_Jyn16,.ToEpochMilli__Jyn7,Instantyn30,ArithmeticException_InstanceOfyn38,IllegalArgumentException_New_Throwableyn31,Instant_OfEpochMilli_J__Instantyn11,.GetTime__Jyn6,Date_Iyn4,.Refyn16,InputStream_Castkn4,langkn4,varskn4,typekn5,constyn5,int16kn4,modskn6,paramskn3,retv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,V3,R7,R1,R8,V3,R9,R1,R10,V3,R11,R1,R12,V3,R13,R1,R14,V3,R15,R1,R16,V3,R17,R1,R18,V3,R19,R1,R20,V3,R21,R1,R22,V3,R23,R1,R24,v11,arbace.core5,referR25,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn14,arbace.j2g.outm2,R26,s358,j2g's output (J2G-SPEC §4.3): Go forms files, one per Java forms file, plus the generated\n  files of each package (j2g_classes: registrations and member tables, §5.11; j2g_strings: the\n  literal pool, §7.5; j2g_frames: the frame table, §7.9.6; j2g_support: j2g's helpers), and\n  the merge with jrt's hand-written forms into one program root for bin/build-go.v11,arbace.core9,with-metaR27,v11,arbace.core6,dissocR28,R29,R30,R31,R32,v11,arbace.core9,contains?v11,arbace.core6,updatev14,arbace.j2g.out5,cleanv11,arbace.core6,empty?v11,arbace.core7,symbol?v11,arbace.core4,seq?v11,arbace.core7,vector?v11,arbace.core4,map?v11,arbace.core4,intov11,arbace.core3,mapR33,v14,arbace.j2g.out9,*renames*v11,arbace.core5,applyv11,arbace.core4,listv11,arbace.core4,mapvv14,arbace.j2g.out8,newlinesR34,v11,arbace.core3,seqv11,arbace.core5,assocR35,V1,R27,v11,arbace.core4,keysv14,arbace.j2g.out4,out!v14,arbace.j2g.out10,write-formv11,arbace.core5,firstv11,arbace.core4,nextR36,v11,arbace.core4,not=v11,arbace.core3,strv11,arbace.core6,repeatv14,arbace.j2g.out10,write-metav14,arbace.j2g.out11,write-itemsv14,arbace.j2g.out10,write-listv11,arbace.core6,pr-strv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core12,*print-meta*v11,arbace.core9,volatile!v11,arbace.core4,run!v11,arbace.core4,valsv11,arbace.core9,namespacev11,arbace.core5,some?v14,arbace.j2g.out6,lined?v11,arbace.core4,somev14,arbace.j2g.out9,split-minR37,l1,v11,arbace.core13,partition-allv16,arbace.j2g.model4,jobsv11,arbace.core3,catv16,arbace.j2g.model8,par-mapvv11,arbace.core3,vecv14,arbace.j2g.out13,unlined-textsv14,arbace.j2g.out15,used-qualifiersv11,arbace.core3,setv16,arbace.j2g.names17,compiled-packagesv14,arbace.j2g.out12,import-pathsv16,arbace.j2g.names8,pkg-pathv11,arbace.core7,keywordv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core3,notv16,arbace.j2g.names8,pkg-namev11,arbace.core12,chunk-appendv11,arbace.core6,symbolv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core4,restv11,arbace.core4,sortv11,arbace.core6,filterv11,arbace.core5,rangev11,arbace.core6,concatv11,arbace.core7,sort-byv11,arbace.core6,removev16,arbace.j2g.names6,pkg-nsR38,R39,R37,v11,arbace.core6,secondR40,v13,arbace.string7,replacev11,arbace.core4,subsv13,arbace.string5,splitp1,_S34,s2,jss7,freebsds7,openbsds4,nacls7,riscv64s6,wasip1s7,ppc64les5,linuxs5,amd64s3,arms3,386s4,mipss6,tamagos6,darwins5,plan9s5,s390xs7,windowss3,aixs5,ppc64s3,zoss7,loong64s7,solariss3,ioss4,hurds5,arm64s4,wasms9,dragonflys8,mips64les7,illumoss6,netbsds7,androids4,tests6,mipsles6,mips64v11,arbace.core4,lastv11,arbace.core3,intv14,arbace.j2g.out15,lone-surrogate?R41,v14,arbace.j2g.out3,tagR42,v16,arbace.j2g.model7,jrt-symR43,ML2,R44,R45,m4,R28,i252,R29,i69,ML2,R44,R45,m4,R28,i252,R29,i69,v11,arbace.core4,compv11,arbace.core4,namel4,v11,arbace.core3,valR46,v16,arbace.j2g.names9,desc-codeR47,v16,arbace.j2g.model7,go-typeR47,R48,R49,R47,R50,v15,arbace.j2g.code3,*f*R51,v16,arbace.j2g.model7,go-namev22,arbace.classes.analyze8,find-samv20,arbace.classes.types17,parse-method-descR52,R6,R42,R53,R6,R37,R54,R55,R56,R57,v16,arbace.j2g.names11,method-baseR58,v11,arbace.core9,vary-metaR50,R57,v11,arbace.core8,distinctv16,arbace.j2g.decls17,interface-closurev11,arbace.core6,mapcatv16,arbace.j2g.model7,impl-ofR57,R59,R60,v16,arbace.j2g.model9,class-symR61,R6,R62,v16,arbace.j2g.model8,vmethodsR57,R63,m2,R27,R64,R6,R48,R49,R6,R50,R57,R65,R42,R57,R66,R42,R6,R57,R67,m2,R27,R64,R62,R6,R41,R68,R43,R69,R70,l4112,R71,R72,R73,R43,R44,R42,R74,R75,R75,v14,arbace.j2g.out10,java-namesv16,arbace.j2g.model13,hand-written?v16,arbace.j2g.model10,interface?v16,arbace.j2g.model9,abstract?v16,arbace.j2g.model5,leaf?v16,arbace.j2g.model3,pkgv14,arbace.j2g.jrt14,struct-methodsv16,arbace.j2g.model3,*w*R76,R6,R57,R6,R42,R50,R77,v14,arbace.j2g.out17,fjp-support-classv16,arbace.j2g.model11,translated?v14,arbace.j2g.out15,fjp-support-keyR57,R6,ML2,R42,R78,m4,R28,i406,R29,i44,R50,R6,ML2,R42,R78,m4,R28,i406,R29,i44,v14,arbace.j2g.out19,fjp-support-methodsv16,arbace.j2g.model13,trivial-init?v14,arbace.j2g.out20,string-regex-methodsv14,arbace.j2g.out22,jrt-default-forwardersv14,arbace.j2g.out17,fjp-support-formsV1,ML5,R57,R79,s76,DescribeConstable__Optional is String.describeConstable: Optional.of(this).\nMV1,Myn1,tm2,R27,ML2,R42,R80,m4,R28,i425,R29,i40,m2,R27,ML2,R42,R81,m4,R28,i425,R29,i18,ML2,R82,R6,m4,R28,i426,R29,i11,m4,R28,i424,R29,i10,V1,ML5,R57,R83,s140,Lines__Stream is String.lines: the lines (split at \\n, \\r, \\r\\n) as a\nsequential stream (over an ArrayList: not jdk26u's lazy spliterator).\nMV1,Myn1,tm2,R27,ML2,R42,R80,m4,R28,i430,R29,i27,m2,R27,R84,ML4,R85,V2,R86,ML1,R87,m4,R28,i431,R29,i19,ML3,R88,V3,R89,R90,ML2,R91,ML2,R92,R6,m4,R28,i432,R29,i37,m4,R28,i432,R29,i25,ML3,R93,R86,ML2,R94,R90,m4,R28,i433,R29,i28,m4,R28,i433,R29,i15,m4,R28,i432,R29,i13,ML2,R95,R86,m4,R28,i434,R29,i13,m4,R28,i431,R29,i11,m4,R28,i428,R29,i10,R57,R96,R18,ML2,R42,R97,m4,R28,i444,R29,i36,R98,ML2,R42,R80,m4,R28,i444,R29,i59,ML4,R85,V2,R99,ML2,R100,ML2,R101,R98,m4,R28,i445,R29,i33,m4,R28,i445,R29,i24,ML4,R102,ML3,R103,R99,s1,/m4,R28,i446,R29,i22,ML3,R104,R99,ML3,R105,R99,l1,m4,R28,i447,R29,i28,m4,R28,i447,R29,i20,ML4,R85,V2,R106,R18,ML3,R107,ML2,R108,R106,m4,R28,i449,R29,i29,ML3,R104,R106,ML2,R109,R106,m4,R28,i450,R29,i32,m4,R28,i450,R29,i24,m4,R28,i449,R29,i22,ML3,R85,V4,R110,ML2,R111,ML2,R112,R106,m4,R28,i451,R29,i39,m4,R28,i451,R29,i31,R113,ML3,R114,R110,c46,m4,R28,i452,R29,i30,ML3,R48,ML3,R115,R113,l0,m4,R28,i453,R29,i30,ML3,R104,R99,ML4,R116,ML4,R117,ML4,R105,R110,R89,R113,m4,R28,i454,R29,i57,s1,.s1,/m4,R28,i454,R29,i37,s1,/R99,m4,R28,i454,R29,i34,m4,R28,i454,R29,i26,m4,R28,i453,R29,i24,m4,R28,i451,R29,i22,m4,R28,i448,R29,i20,m4,R28,i446,R29,i18,ML4,R85,V2,ML3,R118,R119,R120,m4,R28,i455,R29,i24,ML2,R121,R99,m4,R28,i455,R29,i38,ML3,R48,ML2,R122,R120,m4,R28,i456,R29,i26,ML2,R50,nm4,R28,i457,R29,i22,m4,R28,i456,R29,i20,ML4,R85,V2,R10,ML2,R123,ML3,R124,R125,ML2,R126,R119,m4,R28,i458,R29,i54,m4,R28,i458,R29,i42,m4,R28,i458,R29,i28,ML3,R88,V3,R113,R90,R119,ML4,R127,ML2,R128,R10,m4,R28,i460,R29,i30,R113,ML3,R124,R129,R90,m4,R28,i460,R29,i40,m4,R28,i460,R29,i24,m4,R28,i459,R29,i22,ML2,R50,ML2,R130,R10,m4,R28,i461,R29,i30,m4,R28,i461,R29,i22,m4,R28,i458,R29,i20,m4,R28,i455,R29,i18,m4,R28,i445,R29,i16,V2,ML8,R46,R131,s67,j2gSetDateZone sets jrt's DateZone hooks to DefaultZone's methods.\nMV0,m2,R27,R132,ML3,R104,R133,R134,m4,R28,i468,R29,i11,ML3,R104,R135,R136,m4,R28,i469,R29,i11,ML3,R104,R137,ML3,R138,MV1,Myn2,msm2,R27,R139,m2,R27,R140,ML2,R50,ML2,R100,ML2,R141,R142,m4,R28,i470,R29,i71,m4,R28,i470,R29,i62,m4,R28,i470,R29,i54,m4,R28,i470,R29,i30,m4,R28,i470,R29,i11,Tm4,R28,i467,R29,i10,ML3,R41,Myn14,j2gDateZoneSetm2,R27,R132,ML1,R131,m4,R28,i472,R29,i39,m4,R28,i472,R29,i10,v11,arbace.core4,nil?R46,R143,R90,R64,m2,R27,R132,R48,R49,R90,R50,R144,R50,R145,R90,R124,R64,R146,ML8,R46,R147,s56,J2g_RefP is a pointer as an any, nil-preserving (§5.6).\nR148,V1,R149,MV1,Myn1,pm2,R27,ML2,R42,R149,m4,R28,i493,R29,i39,m2,R27,R64,ML3,R48,ML3,R49,R47,nm4,R28,i494,R29,i15,ML2,R50,nm4,R28,i494,R29,i26,m4,R28,i494,R29,i9,R47,m4,R28,i492,R29,i7,R150,v14,arbace.j2g.jrt9,scan-fileML5,R46,R151,s125,String_Format_String_O1__String is String.format: a new Formatter's format (j2g's, over the\ntranslated java.util.Formatter).\nMV2,Myn6,formatm2,R27,ML2,R42,R80,m4,R28,i501,R29,i38,Myn4,argsm2,R27,ML2,R42,R152,m4,R28,i501,R29,i64,m2,R27,ML2,R42,R80,m4,R28,i501,R29,i18,ML2,R153,ML4,R154,ML1,R155,m4,R28,i502,R29,i60,R156,R157,m4,R28,i502,R29,i30,m4,R28,i502,R29,i11,m4,R28,i498,R29,i9,ML5,R57,R158,s69,Formatted_O1__String is String.formatted: String.format(this, args).\nMV2,Myn1,tm2,R27,ML2,R42,R80,m4,R28,i506,R29,i38,Myn4,argsm2,R27,ML2,R42,R152,m4,R28,i506,R29,i59,m2,R27,ML2,R42,R80,m4,R28,i506,R29,i18,ML2,R153,ML4,R154,ML1,R155,m4,R28,i507,R29,i60,R6,R157,m4,R28,i507,R29,i30,m4,R28,i507,R29,i11,m4,R28,i504,R29,i9,ML7,R46,R159,s185,String_Join_CharSequence_Iterable__String is String.join(CharSequence, Iterable): each\nelement cast to CharSequence (the for loop's checkcast), then joined as the array overload joins.\nMV2,Myn3,sepm2,R27,R160,Myn8,elementsm2,R27,R161,m2,R27,ML2,R42,R80,m4,R28,i513,R29,i18,ML3,R48,ML3,R49,R162,nm4,R28,i514,R29,i17,ML2,R62,ML1,R163,m4,R28,i514,R29,i37,m4,R28,i514,R29,i30,m4,R28,i514,R29,i11,ML3,R48,ML3,R49,R164,nm4,R28,i515,R29,i17,ML2,R62,ML1,R163,m4,R28,i515,R29,i42,m4,R28,i515,R29,i35,m4,R28,i515,R29,i11,ML4,R85,V4,Myn2,esm2,R27,ML2,R44,R64,m4,R28,i516,R29,i24,nR165,ML2,R166,R164,m4,R28,i517,R29,i20,ML3,R107,ML2,R167,R165,m4,R28,i518,R29,i20,ML3,R104,R168,ML3,R169,R168,ML2,R170,ML2,R171,R165,m4,R28,i519,R29,i54,m4,R28,i519,R29,i35,m4,R28,i519,R29,i24,m4,R28,i519,R29,i15,m4,R28,i518,R29,i13,ML3,R172,R162,ML3,R173,R174,ML2,R175,R168,m4,R28,i520,R29,i96,m4,R28,i520,R29,i65,m4,R28,i520,R29,i13,m4,R28,i516,R29,i11,m4,R28,i510,R29,i9,ML5,R46,R176,s70,String_Format_Locale_String_O1__String is String.format(Locale, ...).\nMV3,Myn1,lm2,R27,ML2,R42,R177,m4,R28,i524,R29,i38,Myn6,formatm2,R27,ML2,R42,R80,m4,R28,i524,R29,i59,Myn4,argsm2,R27,ML2,R42,R152,m4,R28,i524,R29,i85,m2,R27,ML2,R42,R80,m4,R28,i524,R29,i18,ML2,R153,ML4,R154,ML2,R178,R86,m4,R28,i525,R29,i60,R156,R157,m4,R28,i525,R29,i30,m4,R28,i525,R29,i11,m4,R28,i522,R29,i9,R46,R179,V1,ML1,R180,m4,R28,i588,R29,i31,V1,ML3,R104,R181,R182,m4,R28,i589,R29,i29,ML3,R104,R183,ML1,R184,m4,R28,i591,R29,i37,m4,R28,i591,R29,i21,ML3,R104,R185,ML1,R186,m4,R28,i592,R29,i38,m4,R28,i592,R29,i21,ML3,R104,R187,ML1,R188,m4,R28,i593,R29,i38,m4,R28,i593,R29,i21,R85,R189,R75,V1,R140,R190,R104,R190,R138,ML3,R191,R187,ML2,R192,R193,m4,R28,i602,R29,i68,m4,R28,i602,R29,i39,ML2,R194,R187,m4,R28,i603,R29,i39,R193,R140,R48,ML2,R189,R193,m4,R28,i600,R29,i45,ML1,R50,m4,R28,i601,R29,i45,R49,R187,ML6,R46,R195,s33,J2g_ObjHash is Objects.hashCode.\nMV1,Myn1,xm2,R27,R64,m2,R27,R125,ML3,R48,ML3,R49,R90,nm4,R28,i606,R29,i15,ML2,R50,l0,m4,R28,i606,R29,i26,m4,R28,i606,R29,i9,ML2,R196,R90,m4,R28,i607,R29,i9,m4,R28,i605,R29,i7,ML7,R46,R197,s33,J2g_ObjEquals is Objects.equals.\nMV2,Myn1,am2,R27,R64,Myn1,bm2,R27,R64,m2,R27,R132,ML3,R48,ML3,R49,R10,R119,m4,R28,i609,R29,i15,ML2,R50,Tm4,R28,i609,R29,i24,m4,R28,i609,R29,i9,ML3,R48,ML3,R198,ML3,R49,R10,nm4,R28,i610,R29,i19,ML3,R49,R119,nm4,R28,i610,R29,i30,m4,R28,i610,R29,i15,ML2,R50,Fm4,R28,i610,R29,i42,m4,R28,i610,R29,i9,ML3,R199,R10,R119,m4,R28,i611,R29,i9,m4,R28,i608,R29,i7,ML6,R46,R200,s53,J2g_DoubleBits is Double.doubleToLongBits (one NaN).\nMV1,Myn1,dm2,R27,R201,m2,R27,R139,ML3,R48,ML2,R202,R20,m4,R28,i613,R29,i15,ML2,R50,l9221120237041090560,m4,R28,i613,R29,i30,m4,R28,i613,R29,i9,ML3,R124,R139,ML2,R203,R20,m4,R28,i614,R29,i21,m4,R28,i614,R29,i9,m4,R28,i612,R29,i7,ML6,R46,R204,s43,J2g_BoolHash is Boolean.hashCode(boolean).\nMV1,Myn1,bm2,R27,R132,m2,R27,R125,ML3,R48,R119,ML2,R50,l1231,m4,R28,i616,R29,i17,m4,R28,i616,R29,i9,ML2,R50,l1237,m4,R28,i617,R29,i9,m4,R28,i615,R29,i7,ML6,R46,R205,s49,J2g_FloatBits is Float.floatToIntBits (one NaN).\nMV1,Myn1,fm2,R27,R206,m2,R27,R125,ML3,R48,ML3,R145,R207,R207,m4,R28,i619,R29,i15,ML2,R50,l2143289344,m4,R28,i619,R29,i24,m4,R28,i619,R29,i9,ML3,R124,R125,ML2,R208,R207,m4,R28,i620,R29,i21,m4,R28,i620,R29,i9,m4,R28,i618,R29,i7,R41,R209,R132,R46,R210,R211,R140,m2,R27,R212,R213,R192,R116,R211,R46,R214,R148,V1,R149,R215,R140,m2,R27,R149,R62,R216,R213,R192,R116,R215,R46,R217,V1,R149,R90,R149,m2,R27,R149,R90,R48,R49,R124,R64,R90,R62,R163,R46,R218,V1,R149,R90,R64,R219,ML2,R42,R97,m4,R28,i486,R29,i91,m2,R27,R149,R48,R49,R90,R85,R220,R149,R221,R149,R50,R220,R48,R122,R222,R219,R90,R62,R223,R90,R219,R224,R149,R90,R46,R225,R90,R64,m2,R27,R132,R46,R226,ML3,R191,ML2,R101,R227,m4,R28,i532,R29,i33,ML2,R228,R6,m4,R28,i532,R29,i40,m4,R28,i532,R29,i15,R6,R212,R227,R46,R229,ML3,R191,ML2,R101,R193,m4,R28,i537,R29,i33,ML2,R228,R6,m4,R28,i537,R29,i40,m4,R28,i537,R29,i15,R6,R212,R193,R46,R230,ML4,R85,V2,R12,ML1,R231,m4,R28,i542,R29,i23,ML3,R88,V3,R89,R232,ML2,R233,ML1,R234,m4,R28,i543,R29,i40,m4,R28,i543,R29,i30,ML3,R85,V2,R113,ML3,R235,R232,c61,m4,R28,i544,R29,i27,ML3,R48,ML3,R236,R113,l0,m4,R28,i545,R29,i27,ML4,R237,R12,ML2,R192,ML4,R105,R232,R89,R113,m4,R28,i546,R29,i43,m4,R28,i546,R29,i38,ML2,R192,ML3,R105,R232,ML3,R116,R113,l1,m4,R28,i546,R29,i80,m4,R28,i546,R29,i67,m4,R28,i546,R29,i62,m4,R28,i546,R29,i23,m4,R28,i545,R29,i21,m4,R28,i544,R29,i19,m4,R28,i543,R29,i17,ML2,R238,R12,m4,R28,i547,R29,i17,m4,R28,i542,R29,i15,R46,R239,ML4,R85,V2,R47,ML1,R240,m4,R28,i555,R29,i23,ML3,R88,V3,R89,R241,ML1,R242,m4,R28,i556,R29,i29,ML3,R85,V2,R243,ML2,R244,ML2,R192,R241,m4,R28,i557,R29,i62,m4,R28,i557,R29,i27,ML3,R48,ML3,R145,R243,nm4,R28,i558,R29,i27,ML4,R245,R47,ML2,R192,R241,m4,R28,i559,R29,i56,R243,m4,R28,i559,R29,i23,m4,R28,i558,R29,i21,m4,R28,i557,R29,i19,m4,R28,i556,R29,i17,R47,m4,R28,i555,R29,i15,R46,R246,ML1,R239,m4,R28,i566,R29,i15,R41,R183,R185,R187,R46,R247,ML3,R104,R183,R248,m4,R28,i574,R29,i68,R248,R46,R249,ML3,R104,R185,R250,m4,R28,i577,R29,i69,R250,R46,R251,ML3,R104,R187,R252,m4,R28,i580,R29,i69,R252,R41,R181,R54,R253,R254,R255,m2,R27,R64,R46,R256,R90,R64,m2,R27,R64,R257,R224,R253,R90,v22,arbace.classes.analyze4,declR258,R259,R260,R261,v16,arbace.j2g.model4,infoR262,R263,R264,R265,R266,v20,arbace.classes.types5,prim?R224,R267,v16,arbace.j2g.model13,pointer-desc?v15,arbace.j2g.edge16,archived-classesv14,arbace.j2g.out9,java-namev11,arbace.core11,map-indexedv11,arbace.core3,keyv11,arbace.core11,frequenciesv11,arbace.core8,to-arrayR268,R269,R270,R271,v11,arbace.core12,keep-indexedR272,v11,arbace.core5,list*R46,R273,R113,V1,ML2,R50,nm4,R28,i687,R29,i52,R64,R274,R113,R125,R275,R64,R157,ML2,R44,R64,m4,R28,i688,R29,i80,R64,R113,R125,R157,ML2,R44,R64,m4,R28,i689,R29,i59,R64,R276,R113,R125,R277,R64,R278,R113,R125,R277,R64,R243,R64,v11,arbace.core4,keepR68,R43,R279,v13,arbace.string4,joinV2,R280,TR281,R282,R283,R284,v16,arbace.j2g.model4,has?i1024,i1,v15,arbace.j2g.code9,class-valv16,arbace.j2g.model7,static?v14,arbace.j2g.out8,arg-convR285,R157,R224,R275,v14,arbace.j2g.out11,dotted-descML2,R50,nm4,R28,i727,R29,i53,R50,v14,arbace.j2g.out10,result-anyML2,R50,nm4,R28,i727,R29,i53,v14,arbace.j2g.out16,*absent-members*v11,arbace.core4,juxtv16,arbace.j2g.decls13,class-methodsv20,arbace.classes.types15,prim-desc->namev20,arbace.classes.types6,array?v20,arbace.classes.types14,desc->internalv15,arbace.j2g.edge3,jvmR286,v14,arbace.j2g.out12,method-orderl0,v11,arbace.core6,vectorv22,arbace.classes.analyze14,ctor-real-descR50,v16,arbace.j2g.names8,new-nameR285,R157,v16,arbace.j2g.names17,static-field-namev15,arbace.j2g.code15,volatile-field?v18,arbace.classes.env11,const-valuei16,v16,arbace.j2g.names10,field-nameR224,R277,R224,R277,R50,v15,arbace.j2g.code13,volatile-readv15,arbace.j2g.code14,volatile-writeR243,R104,R243,R42,ML3,R287,ML2,R288,R289,m4,R28,i759,R29,i32,ML2,R288,R290,m4,R28,i759,R29,i44,m4,R28,i759,R29,i29,v16,arbace.j2g.decls12,class-fieldsR291,R292,R293,v20,arbace.classes.types14,simple-name-ofR294,R295,v16,arbace.j2g.model9,in-world?R296,R297,v14,arbace.j2g.out13,member-tablesv16,arbace.j2g.model11,code-class?v14,arbace.j2g.out17,member-table-formR41,R42,R41,R68,R43,v14,arbace.j2g.out9,modifiersv14,arbace.j2g.out8,kind-symR43,R44,R42,R298,R299,R300,R301,R46,R179,R85,R113,R112,R104,R302,R113,R104,R303,R113,R104,R138,R42,R304,R113,R104,R305,R113,v16,arbace.j2g.names13,compiled-pkg?R267,R306,R41,R42,R307,R43,R308,R68,R68,R43,R44,R42,R42,R68,R41,R68,R43,v18,arbace.classes.env10,interface?R43,R309,R310,R43,ML2,R44,ML2,R42,R97,m4,R28,i908,R29,i100,m4,R28,i908,R29,i93,R311,R138,MV2,Myn4,thism2,R27,R64,Myn4,argsm2,R27,ML2,R44,R64,m4,R28,i910,R29,i63,m2,R27,R64,ML2,ML3,R267,R312,ML2,R42,R80,m4,R28,i911,R29,i23,m4,R28,i911,R29,i14,ML3,R285,R157,l0,m4,R28,i911,R29,i35,m4,R28,i911,R29,i13,ML2,ML3,R267,R312,ML2,R42,R80,m4,R28,i912,R29,i23,m4,R28,i912,R29,i14,ML3,R285,R157,l1,m4,R28,i912,R29,i35,m4,R28,i912,R29,i13,V2,R313,ML2,R314,R315,m4,R28,i915,R29,i50,R313,l137,R151,ML2,ML3,R267,R312,ML2,R42,R152,m4,R28,i916,R29,i79,m4,R28,i916,R29,i70,ML3,R285,R157,l1,m4,R28,i916,R29,i93,m4,R28,i916,R29,i69,V3,R316,R313,ML2,R314,R315,m4,R28,i917,R29,i63,R313,l137,R176,ML2,ML3,R267,R312,ML2,R42,R177,m4,R28,i918,R29,i83,m4,R28,i918,R29,i74,ML3,R285,R157,l0,m4,R28,i918,R29,i95,m4,R28,i918,R29,i73,ML2,ML3,R267,R312,ML2,R42,R152,m4,R28,i919,R29,i43,m4,R28,i919,R29,i34,ML3,R285,R157,l2,m4,R28,i919,R29,i57,m4,R28,i919,R29,i33,V1,ML2,R314,R315,m4,R28,i920,R29,i40,R313,l129,R317,ML2,ML3,R267,R312,ML2,R42,R80,m4,R28,i921,R29,i66,m4,R28,i921,R29,i57,R275,m4,R28,i921,R29,i56,ML2,ML3,R267,R312,ML2,R42,R152,m4,R28,i921,R29,i95,m4,R28,i921,R29,i86,ML3,R285,R157,l0,m4,R28,i921,R29,i109,m4,R28,i921,R29,i85,R318,ML2,R319,ML2,ML3,R267,R312,ML2,R42,R80,m4,R28,i923,R29,i82,m4,R28,i923,R29,i73,R275,m4,R28,i923,R29,i72,m4,R28,i923,R29,i56,R320,ML2,R321,ML2,ML3,R267,R312,ML2,R42,R80,m4,R28,i925,R29,i110,m4,R28,i925,R29,i101,R275,m4,R28,i925,R29,i100,m4,R28,i925,R29,i70,V2,R174,R322,R313,l9,R159,ML2,ML3,R267,R312,R160,m4,R28,i928,R29,i77,ML3,R285,R157,l0,m4,R28,i928,R29,i100,m4,R28,i928,R29,i76,ML2,ML3,R267,R312,R161,m4,R28,i929,R29,i34,ML3,R285,R157,l1,m4,R28,i929,R29,i53,m4,R28,i929,R29,i33,V1,R313,R323,R324,ML2,ML3,R267,R312,ML2,R42,R80,m4,R28,i932,R29,i63,m4,R28,i932,R29,i54,R275,m4,R28,i932,R29,i53,V2,R313,R313,R313,R325,ML2,ML3,R267,R312,ML2,R42,R80,m4,R28,i934,R29,i78,m4,R28,i934,R29,i69,R275,m4,R28,i934,R29,i68,V2,R313,R313,R313,R326,ML2,ML3,R267,R312,ML2,R42,R80,m4,R28,i936,R29,i80,m4,R28,i936,R29,i71,R275,m4,R28,i936,R29,i70,V1,R313,ML2,R314,R313,m4,R28,i937,R29,i51,R327,ML2,ML3,R267,R312,ML2,R42,R80,m4,R28,i938,R29,i67,m4,R28,i938,R29,i58,R275,m4,R28,i938,R29,i57,V2,R313,R328,ML2,R314,R313,m4,R28,i939,R29,i60,R329,ML2,ML3,R267,R312,ML2,R42,R80,m4,R28,i940,R29,i69,m4,R28,i940,R29,i60,R275,m4,R28,i940,R29,i59,ML3,R224,R125,ML3,R285,R157,l1,m4,R28,i940,R29,i105,m4,R28,i940,R29,i91,R46,R179,R104,ML2,R330,ML2,R112,R331,m4,R28,i964,R29,i50,m4,R28,i964,R29,i39,R169,ML2,R330,ML2,R112,R331,m4,R28,i965,R29,i60,m4,R28,i965,R29,i49,V1,R332,R333,ML3,R334,ML3,R229,ML3,R224,R212,R275,m4,R28,i969,R29,i77,ML2,R335,ML3,R285,R157,l0,m4,R28,i969,R29,i121,m4,R28,i969,R29,i103,m4,R28,i969,R29,i50,ML2,R50,nm4,R28,i970,R29,i50,m4,R28,i969,R29,i46,V1,R336,R333,ML3,R334,ML3,R226,ML3,R224,R212,R275,m4,R28,i973,R29,i77,ML2,R337,ML3,R285,R157,l0,m4,R28,i973,R29,i121,m4,R28,i973,R29,i103,m4,R28,i973,R29,i50,ML2,R50,nm4,R28,i974,R29,i50,m4,R28,i973,R29,i46,V1,ML3,R104,ML2,R330,ML2,R112,R338,m4,R28,i976,R29,i38,m4,R28,i976,R29,i27,ML3,R169,ML2,R330,ML2,R112,R338,m4,R28,i977,R29,i46,m4,R28,i977,R29,i35,ML10,R43,R309,R69,s6,getenvR311,R339,R70,l9,R281,ML3,R138,MV2,Myn4,thism2,R27,R64,Myn4,argsm2,R27,ML2,R44,R64,m4,R28,i979,R29,i75,m2,R27,R64,ML1,R230,m4,R28,i979,R29,i94,m4,R28,i979,R29,i48,m4,R28,i978,R29,i35,m4,R28,i977,R29,i27,m4,R28,i976,R29,i21,ML2,ML3,R267,R312,ML2,R42,R80,m4,R28,i981,R29,i38,m4,R28,i981,R29,i29,ML3,R285,R157,l0,m4,R28,i981,R29,i50,m4,R28,i981,R29,i28,ML2,ML3,R267,R312,ML2,R42,R152,m4,R28,i982,R29,i39,m4,R28,i982,R29,i30,ML3,R285,R157,l0,m4,R28,i982,R29,i53,m4,R28,i982,R29,i29,ML2,ML3,R267,R312,ML2,R42,R152,m4,R28,i983,R29,i39,m4,R28,i983,R29,i30,ML3,R285,R157,l1,m4,R28,i983,R29,i53,m4,R28,i983,R29,i29,ML2,ML3,R267,R312,ML2,R42,R340,m4,R28,i984,R29,i39,m4,R28,i984,R29,i30,ML3,R285,R157,l2,m4,R28,i984,R29,i49,m4,R28,i984,R29,i29,ML2,R314,R313,m4,R28,i985,R29,i29,R104,ML2,R330,ML2,R112,R341,m4,R28,i986,R29,i46,m4,R28,i986,R29,i35,R169,ML2,R330,ML2,R112,R341,m4,R28,i987,R29,i54,m4,R28,i987,R29,i43,V1,R313,R342,R343,R342,R313,R344,R342,R313,R345,R346,R342,R347,R342,R348,R342,R345,R349,V1,ML3,R104,ML2,R330,ML2,R112,R338,m4,R28,i1001,R29,i38,m4,R28,i1001,R29,i27,ML3,R169,ML2,R330,ML2,R112,R338,m4,R28,i1002,R29,i46,m4,R28,i1002,R29,i35,ML10,R43,R309,R69,s13,getPropertiesR311,R350,R70,l9,R281,ML3,R138,MV2,Myn4,thism2,R27,R64,Myn4,argsm2,R27,ML2,R44,R64,m4,R28,i1004,R29,i75,m2,R27,R64,ML1,R239,m4,R28,i1004,R29,i94,m4,R28,i1004,R29,i48,m4,R28,i1003,R29,i35,m4,R28,i1002,R29,i27,m4,R28,i1001,R29,i21,V1,ML3,R104,ML2,R351,ML2,R112,R313,m4,R28,i1006,R29,i37,m4,R28,i1006,R29,i27,ML3,R169,ML2,R351,ML2,R112,R313,m4,R28,i1007,R29,i45,m4,R28,i1007,R29,i35,ML10,R43,R352,R69,s22,CASE_INSENSITIVE_ORDERR353,R354,R70,l25,R283,ML3,R138,MV1,Myn1,om2,R27,R64,m2,R27,R64,R181,m4,R28,i1009,R29,i45,m4,R28,i1008,R29,i35,m4,R28,i1007,R29,i27,m4,R28,i1006,R29,i21,R104,ML2,R330,ML2,R112,R355,m4,R28,i1011,R29,i44,m4,R28,i1011,R29,i33,R169,ML2,R330,ML2,R112,R355,m4,R28,i1012,R29,i52,m4,R28,i1012,R29,i41,R356,ML1,R357,m4,R28,i1014,R29,i38,V1,R356,R333,ML2,R50,nm4,R28,i1015,R29,i98,R104,ML2,R330,ML2,R112,R356,m4,R28,i1016,R29,i44,m4,R28,i1016,R29,i33,R169,ML2,R330,ML2,R112,R356,m4,R28,i1017,R29,i58,m4,R28,i1017,R29,i47,V1,R313,R358,R359,ML2,ML3,R267,R312,R360,m4,R28,i1024,R29,i50,R275,m4,R28,i1024,R29,i49,V1,R313,R361,R362,ML2,ML3,R267,R312,R360,m4,R28,i1027,R29,i50,R275,m4,R28,i1027,R29,i49,V1,R313,R361,ML1,R363,m4,R28,i1029,R29,i43,V1,R313,R364,ML4,R85,V2,ML3,R118,R119,R120,m4,R28,i1032,R29,i44,ML2,R121,ML2,R100,ML2,R101,ML2,ML3,R267,R312,ML2,R42,R80,m4,R28,i1032,R29,i97,m4,R28,i1032,R29,i88,ML3,R285,R157,l0,m4,R28,i1032,R29,i109,m4,R28,i1032,R29,i87,m4,R28,i1032,R29,i83,m4,R28,i1032,R29,i74,m4,R28,i1032,R29,i58,ML3,R48,ML2,R122,R120,m4,R28,i1033,R29,i46,ML2,R50,nm4,R28,i1033,R29,i55,m4,R28,i1033,R29,i40,ML4,R85,V2,R10,ML2,R123,ML3,R124,R125,ML2,R126,R119,m4,R28,i1034,R29,i74,m4,R28,i1034,R29,i62,m4,R28,i1034,R29,i48,ML3,R88,V3,R113,R90,R119,ML4,R127,ML2,R128,R10,m4,R28,i1035,R29,i63,R113,ML3,R124,R129,R90,m4,R28,i1035,R29,i73,m4,R28,i1035,R29,i57,m4,R28,i1035,R29,i42,ML2,R50,ML2,R130,R10,m4,R28,i1036,R29,i50,m4,R28,i1036,R29,i42,m4,R28,i1034,R29,i40,m4,R28,i1032,R29,i38,R104,ML2,R330,ML2,R112,R365,m4,R28,i1038,R29,i44,m4,R28,i1038,R29,i33,R169,ML2,R330,ML2,R112,R365,m4,R28,i1039,R29,i52,m4,R28,i1039,R29,i41,V1,R366,R365,ML4,R85,V4,Myn1,dm2,R27,R64,nR367,ML1,ML7,R138,V0,R368,V1,Myn3,excm2,R27,R212,ML2,R369,ML2,R370,ML2,R68,R367,m4,R28,i1045,R29,i65,m4,R28,i1045,R29,i58,m4,R28,i1045,R29,i51,ML3,R104,R20,ML2,R371,ML2,R372,ML2,R101,ML2,ML3,R267,R312,ML2,R42,R373,m4,R28,i1046,R29,i103,m4,R28,i1046,R29,i94,ML3,R285,R157,l0,m4,R28,i1046,R29,i116,m4,R28,i1046,R29,i93,m4,R28,i1046,R29,i89,m4,R28,i1046,R29,i71,m4,R28,i1046,R29,i59,m4,R28,i1046,R29,i51,ML2,R50,nm4,R28,i1047,R29,i51,m4,R28,i1044,R29,i49,m4,R28,i1044,R29,i48,ML4,R48,ML3,R145,R367,nm4,R28,i1048,R29,i46,ML3,R48,ML2,R374,R367,m4,R28,i1049,R29,i48,ML2,R62,ML2,R375,R367,m4,R28,i1050,R29,i51,m4,R28,i1050,R29,i44,m4,R28,i1049,R29,i42,ML2,R62,R367,m4,R28,i1051,R29,i42,m4,R28,i1048,R29,i40,ML2,R50,R20,m4,R28,i1052,R29,i40,m4,R28,i1043,R29,i38,R366,ML2,R376,ML2,R377,ML3,R224,R378,R275,m4,R28,i1054,R29,i84,m4,R28,i1054,R29,i71,m4,R28,i1054,R29,i38,R104,ML2,R330,ML2,R112,R313,m4,R28,i1056,R29,i44,m4,R28,i1056,R29,i33,R169,ML2,R330,ML2,R112,R313,m4,R28,i1057,R29,i58,m4,R28,i1057,R29,i47,ML3,R104,ML2,R351,ML2,R112,R338,m4,R28,i1059,R29,i37,m4,R28,i1059,R29,i27,ML5,R169,ML2,R351,ML2,R112,R338,m4,R28,i1060,R29,i45,m4,R28,i1060,R29,i35,ML10,R43,R352,R69,s3,errR353,R332,R70,l25,R283,ML3,R138,MV1,Myn1,om2,R27,R64,m2,R27,R64,ML2,R379,R187,m4,R28,i1062,R29,i63,m4,R28,i1062,R29,i45,m4,R28,i1061,R29,i35,ML10,R43,R352,R69,s2,inR353,R364,R70,l25,R283,ML3,R138,MV1,Myn1,om2,R27,R64,m2,R27,R64,R183,m4,R28,i1064,R29,i45,m4,R28,i1063,R29,i35,ML10,R43,R352,R69,s3,outR353,R332,R70,l25,R283,ML3,R138,MV1,Myn1,om2,R27,R64,m2,R27,R64,ML2,R379,R185,m4,R28,i1066,R29,i63,m4,R28,i1066,R29,i45,m4,R28,i1065,R29,i35,m4,R28,i1060,R29,i27,m4,R28,i1059,R29,i21,R104,ML2,R330,ML2,R112,R338,m4,R28,i1067,R29,i44,m4,R28,i1067,R29,i33,R169,ML2,R330,ML2,R112,R338,m4,R28,i1068,R29,i52,m4,R28,i1068,R29,i41,V1,R332,R333,ML3,R334,ML2,R251,ML2,R335,ML3,R285,R157,l0,m4,R28,i1070,R29,i90,m4,R28,i1070,R29,i72,m4,R28,i1070,R29,i42,ML2,R50,nm4,R28,i1070,R29,i106,m4,R28,i1070,R29,i38,V1,R364,R333,ML3,R334,ML2,R247,ML2,R380,ML3,R285,R157,l0,m4,R28,i1072,R29,i89,m4,R28,i1072,R29,i71,m4,R28,i1072,R29,i42,ML2,R50,nm4,R28,i1072,R29,i105,m4,R28,i1072,R29,i38,V1,R332,R333,ML3,R334,ML2,R249,ML2,R335,ML3,R285,R157,l0,m4,R28,i1074,R29,i90,m4,R28,i1074,R29,i72,m4,R28,i1074,R29,i42,ML2,R50,nm4,R28,i1074,R29,i106,m4,R28,i1074,R29,i38,v14,arbace.j2g.out13,cut-type-exprR381,R382,R314,R383,R384,R124,R129,R124,R45,R124,R125,R124,R139,R124,R385,R386,R387,R388,C16,java.lang.Stringv11,arbace.core1,=v14,arbace.j2g.out17,cut-class-membersv11,arbace.core6,every?v14,arbace.j2g.out12,cut-constantR50,R41,R42,R46,R179,R104,R305,R112,R46,R179,R43,R44,R42,R68,R43,ML2,R44,ML2,R75,V0,m4,R28,i1192,R29,i43,m4,R28,i1192,R29,i36,R43,ML2,R44,R140,m4,R28,i1193,R29,i36,v16,arbace.j2g.model17,go-qualified-namev11,arbace.core7,re-findp4,[_$]v16,arbace.j2g.model12,start-class?R43,R89,R46,R179,R43,R44,")

var Lit_1 *jrt.String = jrt.Intern("_Fn")

var Lit_2 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$fn__34000131")

var Lit_3 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000133__34000137")

var Lit_4 *jrt.String = jrt.Intern("V")

var Lit_5 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$fn__34000143")

var Lit_6 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$fn__34000145")

var Lit_7 *jrt.String = jrt.Intern("---- the lambda adapter of ")

var Lit_8 *jrt.String = jrt.Intern("/")

var Lit_9 *jrt.String = jrt.Intern(".")

var Lit_10 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$fn__34000147")

var Lit_11 *jrt.String = jrt.Intern("Object")

var Lit_12 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$fn__34000150")

var Lit_13 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000152__34000156")

var Lit_14 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$fn__34000162")

var Lit_15 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000164__34000168")

var Lit_16 *jrt.String = jrt.Intern("Class")

var Lit_17 *jrt.String = jrt.Intern("_class")

var Lit_18 *jrt.String = jrt.Intern("String")

var Lit_19 *jrt.String = jrt.Intern("Object_toString")

var Lit_20 *jrt.String = jrt.Intern("CloneNotSupported")

var Lit_21 *jrt.String = jrt.Intern("Define")

var Lit_22 *jrt.String = jrt.Intern("ClassInfo")

var Lit_23 *jrt.String = jrt.Intern("$$Lambda")

var Lit_24 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$fn__34000218")

var Lit_25 *jrt.String = jrt.Intern("KindClass")

var Lit_26 *jrt.String = jrt.Intern("Object_class")

var Lit_27 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$fn__34000220")

var Lit_28 *jrt.String = jrt.Intern("_")

var Lit_29 *jrt.String = jrt.Intern(" & ")

var Lit_30 *jrt.String = jrt.Intern("$")

var Lit_31 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000133__34000137$fn__34000138")

var Lit_32 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000133__34000137$fn__34000138$fn__34000139")

var Lit_33 *jrt.String = jrt.Intern("p")

var Lit_34 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000152__34000156$fn__34000157")

var Lit_35 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000152__34000156$fn__34000157$fn__34000158")

var Lit_36 *jrt.String = jrt.Intern("Is_")

var Lit_37 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000164__34000168$fn__34000169")

var Lit_38 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000164__34000168$fn__34000169$fn__34000170")

var Lit_39 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000164__34000168$fn__34000169$iter__34000203__34000207")

var Lit_40 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000164__34000168$fn__34000169$fn__34000214")

var Lit_41 *jrt.String = jrt.Intern("J2g_NotTranslated")

var Lit_42 *jrt.String = jrt.Intern("abstract ")

var Lit_43 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000164__34000168$fn__34000169$fn__34000170$iter__34000180__34000184")

var Lit_44 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000164__34000168$fn__34000169$fn__34000170$fn__34000191")

var Lit_45 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000164__34000168$fn__34000169$fn__34000170$iter__34000180__34000184$fn__34000185")

var Lit_46 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000164__34000168$fn__34000169$fn__34000170$iter__34000180__34000184$fn__34000185$fn__34000186")

var Lit_47 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000164__34000168$fn__34000169$iter__34000203__34000207$fn__34000208")

var Lit_48 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms$iter__34000164__34000168$fn__34000169$iter__34000203__34000207$fn__34000208$fn__34000209")

var Lit_49 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_50 *jrt.String = jrt.Intern("As")

var Lit_51 *jrt.String = jrt.Intern("arbace.j2g.out$class_registration$up__34000556")

var Lit_52 *jrt.String = jrt.Intern("CodeDecl")

var Lit_53 *jrt.String = jrt.Intern("")

var Lit_54 *jrt.String = jrt.Intern("L")

var Lit_55 *jrt.String = jrt.Intern(";")

var Lit_56 *jrt.String = jrt.Intern("arbace.j2g.out$class_registration$fn__34000558")

var Lit_57 *jrt.String = jrt.Intern("_members")

var Lit_58 *jrt.String = jrt.Intern("MemberTable")

var Lit_59 *jrt.String = jrt.Intern("arbace.j2g.out$class_registration$fn__34000563")

var Lit_60 *jrt.String = jrt.Intern("_InstanceOf")

var Lit_61 *jrt.String = jrt.Intern("_Init")

var Lit_62 *jrt.String = jrt.Intern("RefArray")

var Lit_63 *jrt.String = jrt.Intern("__VALUES")

var Lit_64 *jrt.String = jrt.Intern("RegisterGoType")

var Lit_65 *jrt.String = jrt.Intern("arbace.j2g.out$clean$cm__34000013")

var Lit_66 *jrt.String = jrt.Intern("arbace.j2g.out$clean$fn__34000016")

var Lit_67 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$fn__34000589")

var Lit_68 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$desc__34000591")

var Lit_69 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$iter__34000593__34000597")

var Lit_70 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$fn__34000603")

var Lit_71 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$iter__34000605__34000609")

var Lit_72 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$fn__34000635")

var Lit_73 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$iter__34000637__34000641")

var Lit_74 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$fn__34000647")

var Lit_75 *jrt.String = jrt.Intern(" ")

var Lit_76 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$iter__34000593__34000597$fn__34000598")

var Lit_77 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$iter__34000593__34000597$fn__34000598$fn__34000599")

var Lit_78 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$iter__34000605__34000609$fn__34000610")

var Lit_79 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$iter__34000605__34000609$fn__34000610$fn__34000611")

var Lit_80 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$iter__34000605__34000609$fn__34000610$fn__34000623")

var Lit_81 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$iter__34000605__34000609$fn__34000610$fn__34000611$fn__34000612")

var Lit_82 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$iter__34000637__34000641$fn__34000642")

var Lit_83 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members$iter__34000637__34000641$fn__34000642$fn__34000643")

var Lit_84 *jrt.String = jrt.Intern("Ljava/lang/String;")

var Lit_85 *jrt.String = jrt.Intern("Str")

var Lit_86 *jrt.String = jrt.Intern("B")

var Lit_87 *jrt.String = jrt.Intern("C")

var Lit_88 *jrt.String = jrt.Intern("I")

var Lit_89 *jrt.String = jrt.Intern("J")

var Lit_90 *jrt.String = jrt.Intern("S")

var Lit_91 *jrt.String = jrt.Intern("Z")

var Lit_92 *jrt.String = jrt.Intern("arbace.j2g.out$cut_forms$iter__34000566__34000570")

var Lit_93 *jrt.String = jrt.Intern("arbace.j2g.out$cut_forms$iter__34000566__34000570$fn__34000571")

var Lit_94 *jrt.String = jrt.Intern("arbace.j2g.out$cut_forms$iter__34000566__34000570$fn__34000571$fn__34000572")

var Lit_95 *jrt.String = jrt.Intern("KindInterface")

var Lit_96 *jrt.String = jrt.Intern(" (cut)")

var Lit_97 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$dotted__34000651")

var Lit_98 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$mdesc__34000653")

var Lit_99 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000655__34000659")

var Lit_100 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$fn__34000758")

var Lit_101 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000766__34000770")

var Lit_102 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000655__34000659$fn__34000660")

var Lit_103 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000655__34000659$fn__34000660$fn__34000661")

var Lit_104 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000655__34000659$fn__34000660$fn__34000709")

var Lit_105 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000655__34000659$fn__34000660$texpr__34000711")

var Lit_106 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000655__34000659$fn__34000660$iter__34000713__34000717")

var Lit_107 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000655__34000659$fn__34000660$iter__34000727__34000731")

var Lit_108 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000655__34000659$fn__34000660$iter__34000741__34000745")

var Lit_109 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000655__34000659$fn__34000660$fn__34000661$fn__34000662")

var Lit_110 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000655__34000659$fn__34000660$fn__34000661$texpr__34000664")

var Lit_111 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000655__34000659$fn__34000660$fn__34000661$iter__34000666__34000670")

var Lit_112 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000655__34000659$fn__34000660$fn__34000661$iter__34000680__34000684")

var Lit_113 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000655__34000659$fn__34000660$fn__34000661$iter__34000694__34000698")

var Lit_114 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000655__34000659$fn__34000660$fn__34000661$iter__34000666__34000670$fn__34000671")

var Lit_115 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000655__34000659$fn__34000660$fn__34000661$iter__34000666__34000670$fn__34000671$fn__34000672")

var Lit_116 *jrt.String = jrt.Intern("m")

var Lit_117 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000655__34000659$fn__34000660$fn__34000661$iter__34000680__34000684$fn__34000685")

var Lit_118 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000655__34000659$fn__34000660$fn__34000661$iter__34000680__34000684$fn__34000685$fn__34000686")

var Lit_119 *jrt.String = jrt.Intern("G")

var Lit_120 *jrt.String = jrt.Intern("f")

var Lit_121 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000655__34000659$fn__34000660$fn__34000661$iter__34000694__34000698$fn__34000699")

var Lit_122 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000655__34000659$fn__34000660$fn__34000661$iter__34000694__34000698$fn__34000699$fn__34000700")

var Lit_123 *jrt.String = jrt.Intern("c")

var Lit_124 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000655__34000659$fn__34000660$iter__34000713__34000717$fn__34000718")

var Lit_125 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000655__34000659$fn__34000660$iter__34000713__34000717$fn__34000718$fn__34000719")

var Lit_126 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000655__34000659$fn__34000660$iter__34000727__34000731$fn__34000732")

var Lit_127 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000655__34000659$fn__34000660$iter__34000727__34000731$fn__34000732$fn__34000733")

var Lit_128 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000655__34000659$fn__34000660$iter__34000741__34000745$fn__34000746")

var Lit_129 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000655__34000659$fn__34000660$iter__34000741__34000745$fn__34000746$fn__34000747")

var Lit_130 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000766__34000770$fn__34000771")

var Lit_131 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms$iter__34000766__34000770$fn__34000771$fn__34000772")

var Lit_132 *jrt.String = jrt.Intern("(")

var Lit_133 *jrt.String = jrt.Intern(")")

var Lit_134 *jrt.String = jrt.Intern("Prim_")

var Lit_135 *jrt.String = jrt.Intern("jrt/")

var Lit_136 *jrt.String = jrt.Intern("java/lang/Object")

var Lit_137 *jrt.String = jrt.Intern("arbace.j2g.out$file_text$path_of__34000056")

var Lit_138 *jrt.String = jrt.Intern("arbace.j2g.out$file_text$iter__34000058__34000062")

var Lit_139 *jrt.String = jrt.Intern(";; Generated by j2g (arbace/j2g, doc/go/J2G-SPEC.md); do not edit.\n")

var Lit_140 *jrt.String = jrt.Intern("(in-ns '")

var Lit_141 *jrt.String = jrt.Intern(")\n\n")

var Lit_142 *jrt.String = jrt.Intern("\n")

var Lit_143 *jrt.String = jrt.Intern("arbace.j2g.out$file_text$line_of__34000072")

var Lit_144 *jrt.String = jrt.Intern("\n;; ")

var Lit_145 *jrt.String = jrt.Intern("arbace.j2g.out$file_text$iter__34000058__34000062$fn__34000063")

var Lit_146 *jrt.String = jrt.Intern("arbace.j2g.out$file_text$iter__34000058__34000062$fn__34000063$fn__34000064")

var Lit_147 *jrt.String = jrt.Intern("arbace.core")

var Lit_148 *jrt.String = jrt.Intern("java/util/concurrent/ExecutorService")

var Lit_149 *jrt.String = jrt.Intern("java/util/concurrent/ForkJoinPool")

var Lit_150 *jrt.String = jrt.Intern("arbace.j2g.out$fjp_support_forms$iter__34000294__34000298")

var Lit_151 *jrt.String = jrt.Intern("arbace.j2g.out$fjp_support_forms$iter__34000294__34000298$fn__34000299")

var Lit_152 *jrt.String = jrt.Intern("arbace.j2g.out$fjp_support_forms$iter__34000294__34000298$fn__34000299$fn__34000300")

var Lit_153 *jrt.String = jrt.Intern("arbace.j2g.out$fjp_support_forms$iter__34000294__34000298$fn__34000299$iter__34000332__34000336")

var Lit_154 *jrt.String = jrt.Intern("arbace.j2g.out$fjp_support_forms$iter__34000294__34000298$fn__34000299$fn__34000342")

var Lit_155 *jrt.String = jrt.Intern("arbace.j2g.out$fjp_support_forms$iter__34000294__34000298$fn__34000299$fn__34000300$iter__34000310__34000314")

var Lit_156 *jrt.String = jrt.Intern("arbace.j2g.out$fjp_support_forms$iter__34000294__34000298$fn__34000299$fn__34000300$fn__34000320")

var Lit_157 *jrt.String = jrt.Intern("arbace.j2g.out$fjp_support_forms$iter__34000294__34000298$fn__34000299$fn__34000300$iter__34000310__34000314$fn__34000315")

var Lit_158 *jrt.String = jrt.Intern("arbace.j2g.out$fjp_support_forms$iter__34000294__34000298$fn__34000299$fn__34000300$iter__34000310__34000314$fn__34000315$fn__34000316")

var Lit_159 *jrt.String = jrt.Intern("arbace.j2g.out$fjp_support_forms$iter__34000294__34000298$fn__34000299$iter__34000332__34000336$fn__34000337")

var Lit_160 *jrt.String = jrt.Intern("arbace.j2g.out$fjp_support_forms$iter__34000294__34000298$fn__34000299$iter__34000332__34000336$fn__34000337$fn__34000338")

var Lit_161 *jrt.String = jrt.Intern("(Ljava/util/concurrent/ForkJoinPool;")

var Lit_162 *jrt.String = jrt.Intern("arbace.j2g.out$frames_forms$iter__34000804__34000812")

var Lit_163 *jrt.String = jrt.Intern("RegisterFrames")

var Lit_164 *jrt.String = jrt.Intern("FrameInfo")

var Lit_165 *jrt.String = jrt.Intern("arbace.j2g.out$frames_forms$iter__34000804__34000812$fn__34000813")

var Lit_166 *jrt.String = jrt.Intern("arbace.j2g.out$frames_forms$iter__34000804__34000812$fn__34000813$iter__34000806__34000814")

var Lit_167 *jrt.String = jrt.Intern("arbace.j2g.out$frames_forms$iter__34000804__34000812$fn__34000813$iter__34000806__34000814$fn__34000815")

var Lit_168 *jrt.String = jrt.Intern("<init>")

var Lit_169 *jrt.String = jrt.Intern("(*")

var Lit_170 *jrt.String = jrt.Intern(").")

var Lit_171 *jrt.String = jrt.Intern(").Impl_")

var Lit_172 *jrt.String = jrt.Intern("_NoInit")

var Lit_173 *jrt.String = jrt.Intern("arbace.j2g.out$frames_forms$iter__34000804__34000812$fn__34000813$iter__34000806__34000814$fn__34000815$iter__34000808__34000816")

var Lit_174 *jrt.String = jrt.Intern("arbace.j2g.out$frames_forms$iter__34000804__34000812$fn__34000813$iter__34000806__34000814$fn__34000815$iter__34000808__34000816$fn__34000817")

var Lit_175 *jrt.String = jrt.Intern("arbace.j2g.out$frames_forms$iter__34000804__34000812$fn__34000813$iter__34000806__34000814$fn__34000815$iter__34000808__34000816$fn__34000817$fn__34000818")

var Lit_176 *jrt.String = jrt.Intern(".go")

var Lit_177 *jrt.String = jrt.Intern("_j2g")

var Lit_178 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders$iter__34000226__34000232")

var Lit_179 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders$iter__34000226__34000232$fn__34000233")

var Lit_180 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders$iter__34000226__34000232$fn__34000233$iter__34000228__34000234")

var Lit_181 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders$iter__34000226__34000232$fn__34000233$iter__34000228__34000234$fn__34000235")

var Lit_182 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders$iter__34000226__34000232$fn__34000233$iter__34000228__34000234$fn__34000235$fn__34000236")

var Lit_183 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders$iter__34000226__34000232$fn__34000233$iter__34000228__34000234$fn__34000235$iter__34000269__34000273")

var Lit_184 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders$iter__34000226__34000232$fn__34000233$iter__34000228__34000234$fn__34000235$fn__34000280")

var Lit_185 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders$iter__34000226__34000232$fn__34000233$iter__34000228__34000234$fn__34000235$fn__34000236$iter__34000246__34000250")

var Lit_186 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders$iter__34000226__34000232$fn__34000233$iter__34000228__34000234$fn__34000235$fn__34000236$fn__34000257")

var Lit_187 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders$iter__34000226__34000232$fn__34000233$iter__34000228__34000234$fn__34000235$fn__34000236$iter__34000246__34000250$fn__34000251")

var Lit_188 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders$iter__34000226__34000232$fn__34000233$iter__34000228__34000234$fn__34000235$fn__34000236$iter__34000246__34000250$fn__34000251$fn__34000252")

var Lit_189 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders$iter__34000226__34000232$fn__34000233$iter__34000228__34000234$fn__34000235$iter__34000269__34000273$fn__34000274")

var Lit_190 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders$iter__34000226__34000232$fn__34000233$iter__34000228__34000234$fn__34000235$iter__34000269__34000273$fn__34000274$fn__34000275")

var Lit_191 *jrt.String = jrt.Intern("KindEnum")

var Lit_192 *jrt.String = jrt.Intern("KindAnnotation")

var Lit_193 *jrt.String = jrt.Intern("KindRecord")

var Lit_194 *jrt.String = jrt.Intern("arbace.j2g.out$lined_QMARK_$lined_meta_QMARK___34000037")

var Lit_195 *jrt.String = jrt.Intern("arbace.j2g.out$lined_QMARK_$fn__34000040")

var Lit_196 *jrt.String = jrt.Intern("arbace.j2g.out$member_table_form$dispatch__34000396")

var Lit_197 *jrt.String = jrt.Intern("invoke")

var Lit_198 *jrt.String = jrt.Intern("new")

var Lit_199 *jrt.String = jrt.Intern("get")

var Lit_200 *jrt.String = jrt.Intern("set")

var Lit_201 *jrt.String = jrt.Intern("arbace.j2g.out$member_table_form$dispatch__34000396$fn__34000397")

var Lit_202 *jrt.String = jrt.Intern("_I")

var Lit_203 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$public_QMARK___34000403")

var Lit_204 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$cls__34000405")

var Lit_205 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000407__34000411")

var Lit_206 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000427__34000431")

var Lit_207 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000443__34000447")

var Lit_208 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000453__34000457")

var Lit_209 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$jname__34000463")

var Lit_210 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$jparams__34000465")

var Lit_211 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$fn__34000467")

var Lit_212 *jrt.String = jrt.Intern("Assert failed: ")

var Lit_213 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$fn__34000470")

var Lit_214 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$fn__34000476")

var Lit_215 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$fn__34000483")

var Lit_216 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000485__34000489")

var Lit_217 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000501__34000505")

var Lit_218 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000517__34000521")

var Lit_219 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000543__34000547")

var Lit_220 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$fn__34000476$fn__34000480")

var Lit_221 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000407__34000411$fn__34000412")

var Lit_222 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000407__34000411$fn__34000412$fn__34000413")

var Lit_223 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000407__34000411$fn__34000412$fn__34000423")

var Lit_224 *jrt.String = jrt.Intern("M")

var Lit_225 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000407__34000411$fn__34000412$fn__34000413$fn__34000417")

var Lit_226 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000427__34000431$fn__34000432")

var Lit_227 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000427__34000431$fn__34000432$fn__34000433")

var Lit_228 *jrt.String = jrt.Intern("<clinit>")

var Lit_229 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000443__34000447$fn__34000448")

var Lit_230 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000443__34000447$fn__34000448$fn__34000449")

var Lit_231 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000453__34000457$fn__34000458")

var Lit_232 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000453__34000457$fn__34000458$fn__34000459")

var Lit_233 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000485__34000489$fn__34000490")

var Lit_234 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000485__34000489$fn__34000490$fn__34000491")

var Lit_235 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000501__34000505$fn__34000506")

var Lit_236 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000501__34000505$fn__34000506$fn__34000507")

var Lit_237 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000517__34000521$fn__34000522")

var Lit_238 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000517__34000521$fn__34000522$fn__34000523")

var Lit_239 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000517__34000521$fn__34000522$fn__34000539")

var Lit_240 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000517__34000521$fn__34000522$fn__34000523$fn__34000530")

var Lit_241 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000543__34000547$fn__34000548")

var Lit_242 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables$iter__34000543__34000547$fn__34000548$fn__34000549")

var Lit_243 *jrt.String = jrt.Intern(".-")

var Lit_244 *jrt.String = jrt.Intern(".Self_")

var Lit_245 *jrt.String = jrt.Intern("F")

var Lit_246 *jrt.String = jrt.Intern("arbace.j2g.out$method_order$fn__34000355")

var Lit_247 *jrt.String = jrt.Intern("arbace.j2g.out$method_order$fn__34000357")

var Lit_248 *jrt.String = jrt.Intern("arbace.j2g.out$method_order$iter__34000361__34000365")

var Lit_249 *jrt.String = jrt.Intern("arbace.j2g.out$method_order$iter__34000377__34000381")

var Lit_250 *jrt.String = jrt.Intern("arbace.j2g.out$method_order$fn__34000357$fn__34000358")

var Lit_251 *jrt.String = jrt.Intern("arbace.j2g.out$method_order$iter__34000361__34000365$fn__34000366")

var Lit_252 *jrt.String = jrt.Intern("arbace.j2g.out$method_order$iter__34000361__34000365$fn__34000366$fn__34000367")

var Lit_253 *jrt.String = jrt.Intern("arbace.j2g.out$method_order$iter__34000377__34000381$fn__34000382")

var Lit_254 *jrt.String = jrt.Intern("arbace.j2g.out$method_order$iter__34000377__34000381$fn__34000382$fn__34000383")

var Lit_255 *jrt.String = jrt.Intern("arbace.j2g.out$method_order$iter__34000377__34000381$fn__34000382$fn__34000387")

var Lit_256 *jrt.String = jrt.Intern("arbace.j2g.out$method_order$iter__34000377__34000381$fn__34000382$fn__34000383$fn__34000384")

var Lit_257 *jrt.String = jrt.Intern("J2g_RefP")

var Lit_258 *jrt.String = jrt.Intern("RegisterStartClasses")

var Lit_259 *jrt.String = jrt.Intern("ClassInit")

var Lit_260 *jrt.String = jrt.Intern("arbace.j2g.out$start_forms$iter__34000783__34000787")

var Lit_261 *jrt.String = jrt.Intern("arbace.j2g.out$start_forms$iter__34000793__34000797")

var Lit_262 *jrt.String = jrt.Intern("arbace.j2g.out$start_forms$iter__34000783__34000787$fn__34000788")

var Lit_263 *jrt.String = jrt.Intern("arbace.j2g.out$start_forms$iter__34000783__34000787$fn__34000788$fn__34000789")

var Lit_264 *jrt.String = jrt.Intern("_init")

var Lit_265 *jrt.String = jrt.Intern("arbace.j2g.out$start_forms$iter__34000793__34000797$fn__34000798")

var Lit_266 *jrt.String = jrt.Intern("arbace.j2g.out$start_forms$iter__34000793__34000797$fn__34000798$fn__34000799")

var Lit_267 *jrt.String = jrt.Intern("arbace.j2g.out$strings_forms$iter__34000078__34000082")

var Lit_268 *jrt.String = jrt.Intern("arbace.j2g.out$strings_forms$fn__34000094")

var Lit_269 *jrt.String = jrt.Intern("arbace.j2g.out$strings_forms$iter__34000078__34000082$fn__34000083")

var Lit_270 *jrt.String = jrt.Intern("arbace.j2g.out$strings_forms$iter__34000078__34000082$fn__34000083$fn__34000084")

var Lit_271 *jrt.String = jrt.Intern("InternUTF16")

var Lit_272 *jrt.String = jrt.Intern("Intern")

var Lit_273 *jrt.String = jrt.Intern("java/lang/Boolean")

var Lit_274 *jrt.String = jrt.Intern("java/util/regex/Pattern")

var Lit_275 *jrt.String = jrt.Intern("java/util/Optional")

var Lit_276 *jrt.String = jrt.Intern("java/lang/constant/Constable")

var Lit_277 *jrt.String = jrt.Intern("java/util/stream/Stream")

var Lit_278 *jrt.String = jrt.Intern("java/util/ArrayList")

var Lit_279 *jrt.String = jrt.Intern("java/io/ByteArrayInputStream")

var Lit_280 *jrt.String = jrt.Intern("GetResourceAsStream_String__InputStream is Class.getResourceAsStream: the resource name\nresolved as Class.resolveName resolves it (absolute without its /, else in the package of the\nclass or of its arrays' element class), from the host's resources, as a ByteArrayInputStream; null\nwhen there is none.\n")

var Lit_281 *jrt.String = jrt.Intern("Ljava/io/InputStream;")

var Lit_282 *jrt.String = jrt.Intern("jdk/internal/jrt/DefaultZone")

var Lit_283 *jrt.String = jrt.Intern("j2g: not translated: ")

var Lit_284 *jrt.String = jrt.Intern("j2g: ")

var Lit_285 *jrt.String = jrt.Intern("java/util/Formatter")

var Lit_286 *jrt.String = jrt.Intern("go/arbace/jrt/string.ae")

var Lit_287 *jrt.String = jrt.Intern("String_Format_String_O1__String")

var Lit_288 *jrt.String = jrt.Intern("java/lang/Iterable")

var Lit_289 *jrt.String = jrt.Intern("java/lang/CharSequence")

var Lit_290 *jrt.String = jrt.Intern("java/io/PrintWriter")

var Lit_291 *jrt.String = jrt.Intern("J2g_PrintStackTraceWriter is Throwable.printStackTrace(PrintWriter): the trace's text printed.\n")

var Lit_292 *jrt.String = jrt.Intern("Ljava/io/PrintWriter;")

var Lit_293 *jrt.String = jrt.Intern("java/io/PrintStream")

var Lit_294 *jrt.String = jrt.Intern("J2g_PrintStackTraceStream is Throwable.printStackTrace(PrintStream).\n")

var Lit_295 *jrt.String = jrt.Intern("Ljava/io/PrintStream;")

var Lit_296 *jrt.String = jrt.Intern("java/util/HashMap")

var Lit_297 *jrt.String = jrt.Intern("java/util/Collections")

var Lit_298 *jrt.String = jrt.Intern("J2g_SystemGetenv is System.getenv(): the host's environment as an unmodifiable map.\n")

var Lit_299 *jrt.String = jrt.Intern("Ljava/util/Map;")

var Lit_300 *jrt.String = jrt.Intern("java/util/Properties")

var Lit_301 *jrt.String = jrt.Intern("J2g_SystemGetProperties is System.getProperties(): a Properties with the system properties\n(a copy: the Go build keeps them in jrt's table, System.setProperty's).\n")

var Lit_302 *jrt.String = jrt.Intern("Ljava/util/Properties;")

var Lit_303 *jrt.String = jrt.Intern("System_GetProperties__Properties is System.getProperties() as translated code calls it\n(m/j2g-static?).\n")

var Lit_304 *jrt.String = jrt.Intern("jdk/internal/jrt/StandardStreams")

var Lit_305 *jrt.String = jrt.Intern("System_SetIn_InputStream__V is System.setIn.\n")

var Lit_306 *jrt.String = jrt.Intern("System_SetOut_PrintStream__V is System.setOut.\n")

var Lit_307 *jrt.String = jrt.Intern("System_SetErr_PrintStream__V is System.setErr.\n")

var Lit_308 *jrt.String = jrt.Intern("jdk/internal/jrt/CaseInsensitiveComparator")

var Lit_309 *jrt.String = jrt.Intern("Ljava/util/Comparator;")

var Lit_310 *jrt.String = jrt.Intern("arbace.j2g.out$support_table_forms$sig__34000577")

var Lit_311 *jrt.String = jrt.Intern("format")

var Lit_312 *jrt.String = jrt.Intern("formatted")

var Lit_313 *jrt.String = jrt.Intern("lines")

var Lit_314 *jrt.String = jrt.Intern("describeConstable")

var Lit_315 *jrt.String = jrt.Intern("join")

var Lit_316 *jrt.String = jrt.Intern("matches")

var Lit_317 *jrt.String = jrt.Intern("replaceAll")

var Lit_318 *jrt.String = jrt.Intern("replaceFirst")

var Lit_319 *jrt.String = jrt.Intern("split")

var Lit_320 *jrt.String = jrt.Intern("jdk/internal/jrt/RuntimeExec")

var Lit_321 *jrt.String = jrt.Intern("jdk/internal/jrt/ClassPathResources")

var Lit_322 *jrt.String = jrt.Intern("java/time/Instant")

var Lit_323 *jrt.String = jrt.Intern("printStackTrace")

var Lit_324 *jrt.String = jrt.Intern("exec")

var Lit_325 *jrt.String = jrt.Intern("getContextClassLoader")

var Lit_326 *jrt.String = jrt.Intern("setContextClassLoader")

var Lit_327 *jrt.String = jrt.Intern("getResource")

var Lit_328 *jrt.String = jrt.Intern("getResources")

var Lit_329 *jrt.String = jrt.Intern("getResourceAsStream")

var Lit_330 *jrt.String = jrt.Intern("from")

var Lit_331 *jrt.String = jrt.Intern("toInstant")

var Lit_332 *jrt.String = jrt.Intern("setErr")

var Lit_333 *jrt.String = jrt.Intern("setIn")

var Lit_334 *jrt.String = jrt.Intern("setOut")

var Lit_335 *jrt.String = jrt.Intern("arbace.j2g.out$unlined_texts$one__34000046")

var Lit_336 *jrt.String = jrt.Intern("arbace.j2g.out$unlined_texts$fn__34000048")

var Lit_337 *jrt.String = jrt.Intern("arbace.j2g.out$ups_forms$iter__34000097__34000101")

var Lit_338 *jrt.String = jrt.Intern("arbace.j2g.out$ups_forms$iter__34000097__34000101$fn__34000102")

var Lit_339 *jrt.String = jrt.Intern("arbace.j2g.out$ups_forms$iter__34000097__34000101$fn__34000102$fn__34000103")

var Lit_340 *jrt.String = jrt.Intern("Up_")

var Lit_341 *jrt.String = jrt.Intern("arbace.j2g.out$used_qualifiers$w__34000034")

var Lit_342 *jrt.String = jrt.Intern("[")

var Lit_343 *jrt.String = jrt.Intern("]")

var Lit_344 *jrt.String = jrt.Intern("{")

var Lit_345 *jrt.String = jrt.Intern("}")

var Lit_346 *jrt.String = jrt.Intern("arbace.j2g.out$write_form$fn__34000030")

var Lit_347 *jrt.String = jrt.Intern("^")

var Lit_348 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn3,symyn4,typekn4,linekn6,columnkn4,filekn7,dynamicyn1,fkn8,declaredkn3,tagyn6,Stringyn4,longyn13,StringBuilderyn3,layyn2,mtyn2,xsyn5,formsyn3,pkgyn7,go-nameyn1,&yn6,headeryn3,topyn4,litsyn3,upsyn3,keyys2,go6,methodyn21,Split_String__String1yn1,*yn8,RefArrayyn24,.Split_String_I__String1yn1,tyn5,regexyn23,Split_String_I__String1yn5,int32yn30,.Split_CharSequence_I__String1yn31,Pattern_Compile_String__Patternyn5,limityn32,ReplaceAll_String_String__Stringyn26,.ReplaceAll_String__Stringyn30,.Matcher_CharSequence__Matcheryn11,replacementyn34,ReplaceFirst_String_String__Stringyn28,.ReplaceFirst_String__Stringyn17,Matches_String__Zyn4,boolyn38,Pattern_Matches_String_CharSequence__Zyn1,nyn4,nameyn4,descyn1,dyn1,xyn4,callyn3,mmsyn1,gkn4,keysyn7,methodsyn5,ctorsyn6,fieldsyn3,cutyn7,classesyn4,cutsyn5,constv11,arbace.core5,in-nsMyn14,arbace.j2g.outm2,R0,s358,j2g's output (J2G-SPEC §4.3): Go forms files, one per Java forms file, plus the generated\n  files of each package (j2g_classes: registrations and member tables, §5.11; j2g_strings: the\n  literal pool, §7.5; j2g_frames: the frame table, §7.9.6; j2g_support: j2g's helpers), and\n  the merge with jrt's hand-written forms into one program root for bin/build-go.m2,R0,s358,j2g's output (J2G-SPEC §4.3): Go forms files, one per Java forms file, plus the generated\n  files of each package (j2g_classes: registrations and member tables, §5.11; j2g_strings: the\n  literal pool, §7.5; j2g_frames: the frame table, §7.9.6; j2g_support: j2g's helpers), and\n  the merge with jrt's hand-written forms into one program root for bin/build-go.R1,v14,arbace.j2g.out3,tagm10,R2,TR3,L1,V2,R4,R5,R6,i19,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out9,*renames*m10,R9,TR6,i24,R7,i1,R8,s17,arbace/j2g/out.aeR0,s256,nil, or a map of symbols to the symbols clean writes in their place: the literals of the\n  classes translated in parallel, named apart (Lit?i_k), to their names in the package's\n  literal pool (Lit_n; arbace.j2g.main; J2G-SPEC §4.1, \"The run in parallel\").v14,arbace.j2g.out5,cleanm10,R3,L1,V1,R10,R0,s117,f without the reader's position metadata (quoted forms in j2g's source carry it), its\n  symbols renamed by *renames*.R6,i30,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out10,write-formm8,R11,TR6,i47,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out8,newlinesm12,R2,TR3,L1,MV1,Myn1,sm2,R12,R13,m2,R12,R14,R0,s28,The number of newlines in s.R6,i57,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out4,out!m10,R2,TR3,L1,V3,Myn2,sbm2,R12,R15,R16,Myn1,sm2,R12,R13,R6,i63,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out10,write-metam10,R2,TR3,L1,V3,Myn2,sbm2,R12,R15,R16,R17,R6,i69,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out11,write-itemsm10,R2,TR3,L1,V3,Myn2,sbm2,R12,R15,R16,R18,R6,i77,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out10,write-listm10,R2,TR3,L1,V4,Myn2,sbm2,R12,R15,R16,R10,R17,R6,i84,R7,i1,R8,s17,arbace/j2g/out.aem10,R2,TR3,L1,V3,Myn2,sbm2,R12,R15,R16,R10,R6,i100,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out9,form-textm8,R3,L1,V1,R10,R6,i119,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out12,import-pathsm18,s4,langs11,arbace/langs7,stringss7,stringss3,gois10,arbace/gois3,jrts10,arbace/jrts7,reflects7,reflects6,unsafes6,unsafes4,maths4,maths4,syncs4,syncs6,atomics11,sync/atomicm6,R6,i124,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out15,used-qualifiersm10,R2,TR3,L1,V1,R19,R6,i128,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out6,lined?m12,R2,TR3,L1,V1,R10,R0,s151,Does form f hold a list with a Java forms line (:j2g/line), its tags included? Then its\n  text depends on the line it starts on (write-list); else not.R6,i141,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out9,split-minl256,m10,R2,TR6,i152,R7,i1,R8,s17,arbace/j2g/out.aeR0,s159,A file of this many forms or more has the texts of its forms without lines computed in\n  parallel (j2g_classes.go: 8,000 registrations), before it is laid out.v14,arbace.j2g.out13,unlined-textsm12,R2,TR3,L1,V1,R19,R0,s274,For the forms of a long file (split-min), by index, the text of each form that holds no line\n  (lined?), cleaned and written as file-text writes it (its text does not depend on where it\n  starts), or nil for the others; computed in parallel, by chunks. nil for a short file.R6,i157,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out9,file-textm10,R3,L1,V5,R20,R21,R19,R22,V1,R23,R0,s149,The text of a Go forms file of package pkg named go-name holding forms (a long one's forms\n  without lines written in parallel first, unlined-texts).R6,i173,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out12,go-file-namem10,R3,L1,V2,R20,R24,R0,s172,The Go file of a Java forms file (§4.3): its name for arbace/lang, the Java source path\n  with _ for / in jrt; _j2g appended when the name would read as a build constraint.R6,i212,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out15,lone-surrogate?m12,R2,TR3,L1,V1,Myn1,sm2,R12,R13,R0,s58,Does string s hold a surrogate that is not half of a pair?R6,i230,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out13,strings-formsm10,R3,L1,V2,R20,R25,R0,s71,The literal pool (§7.5): Lit_n vars interned at package initialization.R6,i244,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out9,ups-formsm10,R3,L1,V2,R20,R26,R0,s74,The nil-preserving conversions Up_From_To (§5.6) the package's code needs.R6,i255,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out13,adapter-formsm10,R3,L1,V2,R20,R27,R0,s116,The adapter F_Fn of functional interface fi (§7.11): its SAM calls Fn, default methods\n  forward to their functions.R6,i265,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out20,string-regex-methodsV5,V2,s21,Split_String__String1ML5,R28,R29,s46,Split_String__String1 is String.split(regex).\nMV2,Myn1,tm2,R12,ML2,R30,R13,m4,R6,i327,R7,i37,Myn5,regexm2,R12,ML2,R30,R13,m4,R6,i327,R7,i58,m2,R12,ML2,R30,R31,m4,R6,i327,R7,i15,ML4,R32,R33,R34,l0,m4,R6,i328,R7,i8,m4,R6,i326,R7,i6,V2,s23,Split_String_I__String1ML5,R28,R35,s55,Split_String_I__String1 is String.split(regex, limit).\nMV3,Myn1,tm2,R12,ML2,R30,R13,m4,R6,i331,R7,i37,Myn5,regexm2,R12,ML2,R30,R13,m4,R6,i331,R7,i58,Myn5,limitm2,R12,R36,m2,R12,ML2,R30,R31,m4,R6,i331,R7,i15,ML4,R37,ML2,R38,R34,m4,R6,i332,R7,i40,R33,R39,m4,R6,i332,R7,i8,m4,R6,i330,R7,i6,V2,s32,ReplaceAll_String_String__StringML5,R28,R40,s55,ReplaceAll_String_String__String is String.replaceAll.\nMV3,Myn1,tm2,R12,ML2,R30,R13,m4,R6,i335,R7,i35,Myn5,regexm2,R12,ML2,R30,R13,m4,R6,i335,R7,i56,Myn11,replacementm2,R12,ML2,R30,R13,m4,R6,i335,R7,i81,m2,R12,ML2,R30,R13,m4,R6,i335,R7,i15,ML3,R41,ML3,R42,ML2,R38,R34,m4,R6,i336,R7,i68,R33,m4,R6,i336,R7,i36,R43,m4,R6,i336,R7,i8,m4,R6,i334,R7,i6,V2,s34,ReplaceFirst_String_String__StringML5,R28,R44,s59,ReplaceFirst_String_String__String is String.replaceFirst.\nMV3,Myn1,tm2,R12,ML2,R30,R13,m4,R6,i339,R7,i35,Myn5,regexm2,R12,ML2,R30,R13,m4,R6,i339,R7,i56,Myn11,replacementm2,R12,ML2,R30,R13,m4,R6,i339,R7,i81,m2,R12,ML2,R30,R13,m4,R6,i339,R7,i15,ML3,R45,ML3,R42,ML2,R38,R34,m4,R6,i340,R7,i70,R33,m4,R6,i340,R7,i38,R43,m4,R6,i340,R7,i8,m4,R6,i338,R7,i6,V2,s17,Matches_String__ZML5,R28,R46,s37,Matches_String__Z is String.matches.\nMV2,Myn1,tm2,R12,ML2,R30,R13,m4,R6,i343,R7,i22,Myn5,regexm2,R12,ML2,R30,R13,m4,R6,i343,R7,i43,m2,R12,R47,ML3,R48,R34,R33,m4,R6,i344,R7,i8,m4,R6,i342,R7,i6,m8,R6,i320,R7,i1,R8,s17,arbace/j2g/out.aeR0,s319,String's methods over java.util.regex, which j2g writes into jrt's j2g_support when Pattern is\n  translated (jrt's String is hand-written; JRT-NOTES.md, \"waiting for the regex port\"): Go\n  method name, then its definition as jdk26u's String defines it (split's one-character fast\n  path gives what Pattern.split gives).v14,arbace.j2g.out10,java-namesm2,s42,jdk/internal/jrt/CaseInsensitiveComparators42,java.lang.String$CaseInsensitiveComparatorm8,R6,i346,R7,i1,R8,s17,arbace/j2g/out.aeR0,s170,Classes of jrt's own Java (overlay/jdk) that stand for a JDK class jrt cannot translate (a\n  nested class of a hand-written one): the name Class.getName answers for them.v14,arbace.j2g.out9,java-namem8,R3,L1,V1,R49,R6,i351,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out22,jrt-default-forwardersm10,R3,L1,V0,R0,s343,Forwarders on jrt's hand-written leaf classes to the default methods of translated\n  interfaces they implement and do not define themselves (CharSequence's chars and\n  codePoints on String, StringBuilder and StringBuffer once streams are in the world): Go's\n  interface satisfaction needs the methods, which jrt's own build cannot name (§5.4).R6,i353,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out17,fjp-support-classm6,R6,i378,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out19,fjp-support-methodsV5,V2,s11,shutdownNows18,()Ljava/util/List;V2,s9,invokeAlls40,(Ljava/util/Collection;)Ljava/util/List;V2,s9,invokeAlls72,(Ljava/util/Collection;JLjava/util/concurrent/TimeUnit;)Ljava/util/List;V2,s9,invokeAnys42,(Ljava/util/Collection;)Ljava/lang/Object;V2,s9,invokeAnys74,(Ljava/util/Collection;JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;m8,R6,i380,R7,i1,R8,s17,arbace/j2g/out.aeR0,s245,The methods of ExecutorService jrt's hand-written ForkJoinPool cannot define (their types are\n  translated), as [name desc]: j2g gives ForkJoinPool Go methods calling jrt's own\n  jdk.internal.jrt.ForkJoinPools (JRT-NOTES.md, \"Concurrency\", JC7).v14,arbace.j2g.out15,fjp-support-keym10,R3,L1,V1,V2,R50,R51,R0,s93,The static method of ForkJoinPools behind ExecutorService method [name desc]: the pool first.R6,i390,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out17,fjp-support-formsm10,R3,L1,V0,R0,s133,ForkJoinPool's Go methods for fjp-support-methods, once ExecutorService and ForkJoinPools are\n  translated and ForkJoinPool is jrt's.R6,i395,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out13,support-formsm10,R3,L1,V0,R0,s89,j2g's helpers in package jrt (j2g_support): what translated code calls besides jrt's API.R6,i410,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out9,modifiersm10,R2,TR3,L1,V1,R49,R6,i625,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out8,kind-symm10,R2,TR3,L1,V2,R20,R49,R6,i631,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out8,arg-convm10,R2,TR3,L1,V3,R20,R52,R53,R6,i637,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out10,result-anym10,R2,TR3,L1,V3,R20,R52,R54,R6,i642,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out16,*absent-members*m10,R9,TR6,i647,R7,i1,R8,s17,arbace/j2g/out.aeR0,s90,Whether member tables list the public methods that do not exist in Go (bin/j2g --program).v14,arbace.j2g.out12,method-orderm12,R2,TR3,L1,V2,R49,R55,R0,s279,The order of the JVM's getDeclaredMethods for the overloads of class n among methods mms, when\n  it is stable (edge/archived-classes): {name [[parameter binary names] ...]} for each name of more\n  than one of mms, the parameter lists in the order of their (last) index; else nil.R6,i651,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out11,dotted-descm12,R2,TR3,L1,V1,R52,R0,s87,A descriptor with binary names (java.util.Map$Entry), as jrt's member tables hold them.R6,i669,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out17,member-table-formm10,R3,L1,V3,R20,R56,m2,R57,V4,R58,R59,R60,R61,R0,s329,The MemberTable of class g's tables {:methods :ctors :fields} (amendment SZ3): the members'\n  lines as data, and per kind one dispatch function, a switch over the member's index among\n  its kind's (a member without a :body has none: jrt throws); [the dispatch functions' forms,\n  the table's form], nil when there are no members.R6,i674,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out13,member-tablesm10,R3,L1,V2,R20,R49,R0,s209,The member tables (§5.11, amendment R12) of translated class n: its public members, as\n  {:methods :ctors :fields} of {:line (data) :body (the dispatch case's statements; none:\n  absent)} (fields: :get, :set).R6,i703,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out18,class-registrationm10,R3,L1,V2,R20,R49,R0,s117,C_class (Define, hierarchy only) and the init function setting its function and table\n  fields (§5.11, amendment J1).R6,i816,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out9,cut-formsm10,R3,L1,V2,R20,R62,R0,s207,Class objects of classes outside the closed world that code names (class literals):\n  registered by name only, so that Class.forName finds them and nothing is their instance\n  (\"cut\" classes, J2G-SPEC §4.1).R6,i887,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out19,support-table-formsm10,R3,L1,V0,R0,s362,The member table entries of jrt's statics and methods that j2g writes (J2G-NOTES.md, phase\n  2C: String.format, String's regex methods, System.in, out, err and their setters), so that\n  reflection finds them at the REPL (System/out, String/format). In reflect_tables_j2g.go: its\n  init runs after reflect_tables.go's, which sets the hand-written classes' tables.R6,i901,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out13,cut-type-exprm12,R2,TR3,L1,V3,R20,R63,R52,R0,s228,The Class expression of type descriptor d (a cut class's member names it) from pkg, or nil\n  when the Go build has no Class object for it there (a class outside the world that is not\n  cut, or one of arbace/lang named from jrt).R6,i1076,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out12,cut-constantm12,R2,TR3,L1,V2,R20,m2,R57,V2,R5,R64,R0,s275,The Go value of a cut class's constant (static final, of a primitive type or String: its\n  value, read by reflection when the edge was recorded), else nil: cut classes' constants are\n  readable (ASM's Opcodes in the Java forms compiler's analysis, doc/go/CLASSFORMS-REPL.md).R6,i1093,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out17,cut-class-membersm12,R2,TR3,L1,V1,R49,R0,s262,The public members class n declares on this JVM, as the edge's :cut records them, or nil:\n  {:methods [{:mods :name :params [desc] :ret desc}] :fields [{:mods :name :type desc :const v}]\n  :ctors [{:mods :params [desc]}]}, each in the order of the member tables.R6,i1109,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out15,cut-table-formsm10,R3,L1,V3,R20,R63,R62,R0,s471,The member tables of the cut classes of pkg (J2G-SPEC §4.1, D6; doc/go/EVAL-NOTES.md): their\n  public members as the JVM reports them (the edge's :cut), whose types the Go build can name,\n  each throwing UnsupportedOperationException when called, so that code naming them analyzes\n  (core's annotation support names ASM's Type) and fails only when run. As MemberTables\n  (amendment SZ3) whose functions are nil (jrt throws, MemberTable.Cut) but for a constant's\n  getter.R6,i1142,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out11,start-formsm10,R3,L1,V2,R20,R62,R0,s216,The registration of the classes initialized at start (arbace.j2g.start; Futamura F4), in\n  their order, with jrt.RegisterStartClasses: their initialization states, C_Init functions and\n  Go names, for jrt.StartCheck.R6,i1182,R7,i1,R8,s17,arbace/j2g/out.aev14,arbace.j2g.out12,frames-formsm10,R3,L1,V2,R20,R62,R0,s130,The frame table (§7.9.6, amendment J4): entries for methods whose Java names the demangler\n  cannot read back (names with _ or $).R6,i1195,R7,i1,R8,s17,arbace/j2g/out.ae")

var Lit_349 *jrt.String = jrt.Intern("arbace.j2g.out$eval34000004$loading__1927001464__auto____34000005")

var Lit_350 *jrt.String = jrt.Intern("arbace.j2g.out$eval34000008$fn__34000009")

var Lit_351 *jrt.String = jrt.Intern("arbace.j2g.out$tag")

var Lit_352 *jrt.String = jrt.Intern("arbace.j2g.out$clean")

var Lit_353 *jrt.String = jrt.Intern("arbace.j2g.out$newlines")

var Lit_354 *jrt.String = jrt.Intern("arbace.j2g.out$out_BANG_")

var Lit_355 *jrt.String = jrt.Intern("arbace.j2g.out$write_meta")

var Lit_356 *jrt.String = jrt.Intern("arbace.j2g.out$write_items")

var Lit_357 *jrt.String = jrt.Intern("arbace.j2g.out$write_list")

var Lit_358 *jrt.String = jrt.Intern("arbace.j2g.out$write_form")

var Lit_359 *jrt.String = jrt.Intern("arbace.j2g.out$form_text")

var Lit_360 *jrt.String = jrt.Intern("arbace.j2g.out$used_qualifiers")

var Lit_361 *jrt.String = jrt.Intern("arbace.j2g.out$lined_QMARK_")

var Lit_362 *jrt.String = jrt.Intern("arbace.j2g.out$unlined_texts")

var Lit_363 *jrt.String = jrt.Intern("arbace.j2g.out$file_text")

var Lit_364 *jrt.String = jrt.Intern("arbace.j2g.out$go_file_name")

var Lit_365 *jrt.String = jrt.Intern("arbace.j2g.out$lone_surrogate_QMARK_")

var Lit_366 *jrt.String = jrt.Intern("arbace.j2g.out$strings_forms")

var Lit_367 *jrt.String = jrt.Intern("arbace.j2g.out$ups_forms")

var Lit_368 *jrt.String = jrt.Intern("arbace.j2g.out$adapter_forms")

var Lit_369 *jrt.String = jrt.Intern("arbace.j2g.out$java_name")

var Lit_370 *jrt.String = jrt.Intern("arbace.j2g.out$jrt_default_forwarders")

var Lit_371 *jrt.String = jrt.Intern("jdk/internal/jrt/ForkJoinPools")

var Lit_372 *jrt.String = jrt.Intern("arbace.j2g.out$fjp_support_key")

var Lit_373 *jrt.String = jrt.Intern("arbace.j2g.out$fjp_support_forms")

var Lit_374 *jrt.String = jrt.Intern("arbace.j2g.out$support_forms")

var Lit_375 *jrt.String = jrt.Intern("arbace.j2g.out$modifiers")

var Lit_376 *jrt.String = jrt.Intern("arbace.j2g.out$kind_sym")

var Lit_377 *jrt.String = jrt.Intern("arbace.j2g.out$arg_conv")

var Lit_378 *jrt.String = jrt.Intern("arbace.j2g.out$result_any")

var Lit_379 *jrt.String = jrt.Intern("arbace.j2g.out$method_order")

var Lit_380 *jrt.String = jrt.Intern("arbace.j2g.out$dotted_desc")

var Lit_381 *jrt.String = jrt.Intern("arbace.j2g.out$member_table_form")

var Lit_382 *jrt.String = jrt.Intern("arbace.j2g.out$member_tables")

var Lit_383 *jrt.String = jrt.Intern("arbace.j2g.out$class_registration")

var Lit_384 *jrt.String = jrt.Intern("arbace.j2g.out$cut_forms")

var Lit_385 *jrt.String = jrt.Intern("arbace.j2g.out$support_table_forms")

var Lit_386 *jrt.String = jrt.Intern("arbace.j2g.out$cut_type_expr")

var Lit_387 *jrt.String = jrt.Intern("arbace.j2g.out$cut_constant")

var Lit_388 *jrt.String = jrt.Intern("arbace.j2g.out$cut_class_members")

var Lit_389 *jrt.String = jrt.Intern("arbace.j2g.out$cut_table_forms")

var Lit_390 *jrt.String = jrt.Intern("arbace.j2g.out$start_forms")

var Lit_391 *jrt.String = jrt.Intern("arbace.j2g.out$frames_forms")
