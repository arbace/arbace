//line j2g_classes.ae:1
package aot_arbace_j2g_jrt

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_j2g_jrt_define_name_A_class, Name: "arbace.j2g.jrt$define_name", Modifiers: 25, Simple: "define_name", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_define_name_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_define_name_walk__1716000019_A_class, Name: "arbace.j2g.jrt$define_name$walk__1716000019", Modifiers: 25, Simple: "walk__1716000019", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_define_name_walk__1716000019_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_define_name_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_eval1716000004_loading__1927001464__auto____1716000005_A_class, Name: "arbace.j2g.jrt$eval1716000004$loading__1927001464__auto____1716000005", Modifiers: 25, Simple: "loading__1927001464__auto____1716000005", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_eval1716000004_loading__1927001464__auto____1716000005_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_eval1716000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_eval1716000008_fn__1716000009_A_class, Name: "arbace.j2g.jrt$eval1716000008$fn__1716000009", Modifiers: 25, Simple: "fn__1716000009", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_eval1716000008_fn__1716000009_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_eval1716000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_go_head_A_class, Name: "arbace.j2g.jrt$go_head", Modifiers: 25, Simple: "go_head", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_go_head_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_head_A_class, Name: "arbace.j2g.jrt$head", Modifiers: 25, Simple: "head", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_head_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_iface_methods_A_class, Name: "arbace.j2g.jrt$iface_methods", Modifiers: 25, Simple: "iface_methods", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_iface_methods_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_iface_methods_fn__1716000279_A_class, Name: "arbace.j2g.jrt$iface_methods$fn__1716000279", Modifiers: 25, Simple: "fn__1716000279", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_iface_methods_fn__1716000279_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_iface_methods_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_interface_elems_A_class, Name: "arbace.j2g.jrt$interface_elems", Modifiers: 25, Simple: "interface_elems", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_interface_elems_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A_class, Name: "arbace.j2g.jrt$interface_elems$iter__1716000161__1716000165", Modifiers: 25, Simple: "iter__1716000161__1716000165", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_interface_elems_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A_class, Name: "arbace.j2g.jrt$interface_elems$iter__1716000161__1716000165$fn__1716000166", Modifiers: 25, Simple: "fn__1716000166", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A_class, Name: "arbace.j2g.jrt$interface_elems$iter__1716000161__1716000165$fn__1716000166$fn__1716000167", Modifiers: 25, Simple: "fn__1716000167", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A_class, Name: "arbace.j2g.jrt$interface_elems$iter__1716000171__1716000175", Modifiers: 25, Simple: "iter__1716000171__1716000175", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_interface_elems_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A_class, Name: "arbace.j2g.jrt$interface_elems$iter__1716000171__1716000175$fn__1716000176", Modifiers: 25, Simple: "fn__1716000176", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A_class, Name: "arbace.j2g.jrt$interface_elems$iter__1716000171__1716000175$fn__1716000176$fn__1716000177", Modifiers: 25, Simple: "fn__1716000177", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_not_linux_constraint_QMARK__A_class, Name: "arbace.j2g.jrt$not_linux_constraint_QMARK_", Modifiers: 25, Simple: "not_linux_constraint_QMARK_", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_not_linux_constraint_QMARK__A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_not_linux_constraint_QMARK__fn__1716000185_A_class, Name: "arbace.j2g.jrt$not_linux_constraint_QMARK_$fn__1716000185", Modifiers: 25, Simple: "fn__1716000185", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_not_linux_constraint_QMARK__fn__1716000185_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_not_linux_constraint_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_not_linux_constraint_QMARK__fn__1716000185_fn__1716000186_A_class, Name: "arbace.j2g.jrt$not_linux_constraint_QMARK_$fn__1716000185$fn__1716000186", Modifiers: 25, Simple: "fn__1716000186", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_not_linux_constraint_QMARK__fn__1716000185_fn__1716000186_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_not_linux_constraint_QMARK__fn__1716000185_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_not_linux_constraint_QMARK__fn__1716000185_fn__1716000191_A_class, Name: "arbace.j2g.jrt$not_linux_constraint_QMARK_$fn__1716000185$fn__1716000191", Modifiers: 25, Simple: "fn__1716000191", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_not_linux_constraint_QMARK__fn__1716000185_fn__1716000191_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_not_linux_constraint_QMARK__fn__1716000185_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_other_system_QMARK__A_class, Name: "arbace.j2g.jrt$other_system_QMARK_", Modifiers: 25, Simple: "other_system_QMARK_", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_other_system_QMARK__A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_recv_type_A_class, Name: "arbace.j2g.jrt$recv_type", Modifiers: 25, Simple: "recv_type", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_recv_type_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_recv_type_nm__1716000015_A_class, Name: "arbace.j2g.jrt$recv_type$nm__1716000015", Modifiers: 25, Simple: "nm__1716000015", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_recv_type_nm__1716000015_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_recv_type_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_scan_A_class, Name: "arbace.j2g.jrt$scan", Modifiers: 25, Simple: "scan", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_scan_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_scan_fn__1716000197_A_class, Name: "arbace.j2g.jrt$scan$fn__1716000197", Modifiers: 25, Simple: "fn__1716000197", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_scan_fn__1716000197_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_scan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_scan_fn__1716000199_A_class, Name: "arbace.j2g.jrt$scan$fn__1716000199", Modifiers: 25, Simple: "fn__1716000199", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_scan_fn__1716000199_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_scan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_scan_iter__1716000201__1716000205_A_class, Name: "arbace.j2g.jrt$scan$iter__1716000201__1716000205", Modifiers: 25, Simple: "iter__1716000201__1716000205", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_scan_iter__1716000201__1716000205_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_scan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_scan_iter__1716000201__1716000205_fn__1716000206_A_class, Name: "arbace.j2g.jrt$scan$iter__1716000201__1716000205$fn__1716000206", Modifiers: 25, Simple: "fn__1716000206", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_scan_iter__1716000201__1716000205_fn__1716000206_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_scan_iter__1716000201__1716000205_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_scan_iter__1716000201__1716000205_fn__1716000206_fn__1716000207_A_class, Name: "arbace.j2g.jrt$scan$iter__1716000201__1716000205$fn__1716000206$fn__1716000207", Modifiers: 25, Simple: "fn__1716000207", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_scan_iter__1716000201__1716000205_fn__1716000206_fn__1716000207_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_scan_iter__1716000201__1716000205_fn__1716000206_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_scan_iter__1716000211__1716000217_A_class, Name: "arbace.j2g.jrt$scan$iter__1716000211__1716000217", Modifiers: 25, Simple: "iter__1716000211__1716000217", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_scan_iter__1716000211__1716000217_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_scan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_scan_iter__1716000211__1716000217_fn__1716000218_A_class, Name: "arbace.j2g.jrt$scan$iter__1716000211__1716000217$fn__1716000218", Modifiers: 25, Simple: "fn__1716000218", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_scan_iter__1716000211__1716000217_fn__1716000218_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_scan_iter__1716000211__1716000217_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_scan_iter__1716000211__1716000217_fn__1716000218_iter__1716000213__1716000222_A_class, Name: "arbace.j2g.jrt$scan$iter__1716000211__1716000217$fn__1716000218$iter__1716000213__1716000222", Modifiers: 25, Simple: "iter__1716000213__1716000222", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_scan_iter__1716000211__1716000217_fn__1716000218_iter__1716000213__1716000222_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_scan_iter__1716000211__1716000217_fn__1716000218_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_scan_iter__1716000211__1716000217_fn__1716000218_iter__1716000213__1716000222_fn__1716000223_A_class, Name: "arbace.j2g.jrt$scan$iter__1716000211__1716000217$fn__1716000218$iter__1716000213__1716000222$fn__1716000223", Modifiers: 25, Simple: "fn__1716000223", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_scan_iter__1716000211__1716000217_fn__1716000218_iter__1716000213__1716000222_fn__1716000223_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_scan_iter__1716000211__1716000217_fn__1716000218_iter__1716000213__1716000222_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_scan_iter__1716000211__1716000217_fn__1716000218_iter__1716000213__1716000222_fn__1716000223_fn__1716000224_A_class, Name: "arbace.j2g.jrt$scan$iter__1716000211__1716000217$fn__1716000218$iter__1716000213__1716000222$fn__1716000223$fn__1716000224", Modifiers: 25, Simple: "fn__1716000224", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_scan_iter__1716000211__1716000217_fn__1716000218_iter__1716000213__1716000222_fn__1716000223_fn__1716000224_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_scan_iter__1716000211__1716000217_fn__1716000218_iter__1716000213__1716000222_fn__1716000223_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_scan_iter__1716000236__1716000240_A_class, Name: "arbace.j2g.jrt$scan$iter__1716000236__1716000240", Modifiers: 25, Simple: "iter__1716000236__1716000240", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_scan_iter__1716000236__1716000240_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_scan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_scan_iter__1716000236__1716000240_fn__1716000241_A_class, Name: "arbace.j2g.jrt$scan$iter__1716000236__1716000240$fn__1716000241", Modifiers: 25, Simple: "fn__1716000241", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_scan_iter__1716000236__1716000240_fn__1716000241_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_scan_iter__1716000236__1716000240_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_scan_iter__1716000236__1716000240_fn__1716000241_fn__1716000242_A_class, Name: "arbace.j2g.jrt$scan$iter__1716000236__1716000240$fn__1716000241$fn__1716000242", Modifiers: 25, Simple: "fn__1716000242", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_scan_iter__1716000236__1716000240_fn__1716000241_fn__1716000242_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_scan_iter__1716000236__1716000240_fn__1716000241_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_scan_iter__1716000256__1716000260_A_class, Name: "arbace.j2g.jrt$scan$iter__1716000256__1716000260", Modifiers: 25, Simple: "iter__1716000256__1716000260", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_scan_iter__1716000256__1716000260_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_scan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_scan_iter__1716000256__1716000260_fn__1716000261_A_class, Name: "arbace.j2g.jrt$scan$iter__1716000256__1716000260$fn__1716000261", Modifiers: 25, Simple: "fn__1716000261", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_scan_iter__1716000256__1716000260_fn__1716000261_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_scan_iter__1716000256__1716000260_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_scan_iter__1716000256__1716000260_fn__1716000261_fn__1716000262_A_class, Name: "arbace.j2g.jrt$scan$iter__1716000256__1716000260$fn__1716000261$fn__1716000262", Modifiers: 25, Simple: "fn__1716000262", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_scan_iter__1716000256__1716000260_fn__1716000261_fn__1716000262_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_scan_iter__1716000256__1716000260_fn__1716000261_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_scan_file_A_class, Name: "arbace.j2g.jrt$scan_file", Modifiers: 25, Simple: "scan_file", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_scan_file_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_strip_doc_A_class, Name: "arbace.j2g.jrt$strip_doc", Modifiers: 25, Simple: "strip_doc", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_strip_doc_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_struct_embed_A_class, Name: "arbace.j2g.jrt$struct_embed", Modifiers: 25, Simple: "struct_embed", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_embed_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_struct_methods_A_class, Name: "arbace.j2g.jrt$struct_methods", Modifiers: 25, Simple: "struct_methods", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_jrt_tag_of_A_class, Name: "arbace.j2g.jrt$tag_of", Modifiers: 25, Simple: "tag_of", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_tag_of_A", Source: "jrt.ae", Declaring: &A_arbace_j2g_jrt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_j2g_jrt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_jrt_A_New()}; return nil }

var A_arbace_j2g_jrt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_jrt_A_new}

var A_arbace_j2g_jrt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.jrt", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_A"})

func init() { i := A_arbace_j2g_jrt_A_class.Info(); i.IsInstance = A_arbace_j2g_jrt_A_InstanceOf; i.Init = A_arbace_j2g_jrt_A_Init; i.Table = A_arbace_j2g_jrt_A_members }

var A_arbace_j2g_jrt_define_name_A_class *jrt.Class

var A_arbace_j2g_jrt_define_name_walk__1716000019_A_class *jrt.Class

func A_arbace_j2g_jrt_eval1716000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_jrt_eval1716000004_A_New()}; return nil }

var A_arbace_j2g_jrt_eval1716000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_jrt_eval1716000004_A_new}

var A_arbace_j2g_jrt_eval1716000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.jrt$eval1716000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_j2g_jrt_A_class, Simple: "eval1716000004", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_eval1716000004_A"})

func init() { i := A_arbace_j2g_jrt_eval1716000004_A_class.Info(); i.IsInstance = A_arbace_j2g_jrt_eval1716000004_A_InstanceOf; i.Table = A_arbace_j2g_jrt_eval1716000004_A_members }

var A_arbace_j2g_jrt_eval1716000004_loading__1927001464__auto____1716000005_A_class *jrt.Class

func A_arbace_j2g_jrt_eval1716000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_jrt_eval1716000008_A_New()}; return nil }

var A_arbace_j2g_jrt_eval1716000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_jrt_eval1716000008_A_new}

var A_arbace_j2g_jrt_eval1716000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.jrt$eval1716000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_j2g_jrt_A_class, Simple: "eval1716000008", Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt_eval1716000008_A"})

func init() { i := A_arbace_j2g_jrt_eval1716000008_A_class.Info(); i.IsInstance = A_arbace_j2g_jrt_eval1716000008_A_InstanceOf; i.Table = A_arbace_j2g_jrt_eval1716000008_A_members }

var A_arbace_j2g_jrt_eval1716000008_fn__1716000009_A_class *jrt.Class

var A_arbace_j2g_jrt_go_head_A_class *jrt.Class

var A_arbace_j2g_jrt_head_A_class *jrt.Class

var A_arbace_j2g_jrt_iface_methods_A_class *jrt.Class

var A_arbace_j2g_jrt_iface_methods_fn__1716000279_A_class *jrt.Class

var A_arbace_j2g_jrt_interface_elems_A_class *jrt.Class

var A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A_class *jrt.Class

var A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A_class *jrt.Class

var A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A_class *jrt.Class

var A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A_class *jrt.Class

var A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A_class *jrt.Class

var A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A_class *jrt.Class

var A_arbace_j2g_jrt_not_linux_constraint_QMARK__A_class *jrt.Class

var A_arbace_j2g_jrt_not_linux_constraint_QMARK__fn__1716000185_A_class *jrt.Class

var A_arbace_j2g_jrt_not_linux_constraint_QMARK__fn__1716000185_fn__1716000186_A_class *jrt.Class

var A_arbace_j2g_jrt_not_linux_constraint_QMARK__fn__1716000185_fn__1716000191_A_class *jrt.Class

var A_arbace_j2g_jrt_other_system_QMARK__A_class *jrt.Class

var A_arbace_j2g_jrt_recv_type_A_class *jrt.Class

var A_arbace_j2g_jrt_recv_type_nm__1716000015_A_class *jrt.Class

var A_arbace_j2g_jrt_scan_A_class *jrt.Class

var A_arbace_j2g_jrt_scan_fn__1716000197_A_class *jrt.Class

var A_arbace_j2g_jrt_scan_fn__1716000199_A_class *jrt.Class

var A_arbace_j2g_jrt_scan_iter__1716000201__1716000205_A_class *jrt.Class

var A_arbace_j2g_jrt_scan_iter__1716000201__1716000205_fn__1716000206_A_class *jrt.Class

var A_arbace_j2g_jrt_scan_iter__1716000201__1716000205_fn__1716000206_fn__1716000207_A_class *jrt.Class

var A_arbace_j2g_jrt_scan_iter__1716000211__1716000217_A_class *jrt.Class

var A_arbace_j2g_jrt_scan_iter__1716000211__1716000217_fn__1716000218_A_class *jrt.Class

var A_arbace_j2g_jrt_scan_iter__1716000211__1716000217_fn__1716000218_iter__1716000213__1716000222_A_class *jrt.Class

var A_arbace_j2g_jrt_scan_iter__1716000211__1716000217_fn__1716000218_iter__1716000213__1716000222_fn__1716000223_A_class *jrt.Class

var A_arbace_j2g_jrt_scan_iter__1716000211__1716000217_fn__1716000218_iter__1716000213__1716000222_fn__1716000223_fn__1716000224_A_class *jrt.Class

var A_arbace_j2g_jrt_scan_iter__1716000236__1716000240_A_class *jrt.Class

var A_arbace_j2g_jrt_scan_iter__1716000236__1716000240_fn__1716000241_A_class *jrt.Class

var A_arbace_j2g_jrt_scan_iter__1716000236__1716000240_fn__1716000241_fn__1716000242_A_class *jrt.Class

var A_arbace_j2g_jrt_scan_iter__1716000256__1716000260_A_class *jrt.Class

var A_arbace_j2g_jrt_scan_iter__1716000256__1716000260_fn__1716000261_A_class *jrt.Class

var A_arbace_j2g_jrt_scan_iter__1716000256__1716000260_fn__1716000261_fn__1716000262_A_class *jrt.Class

var A_arbace_j2g_jrt_scan_file_A_class *jrt.Class

var A_arbace_j2g_jrt_strip_doc_A_class *jrt.Class

var A_arbace_j2g_jrt_struct_embed_A_class *jrt.Class

var A_arbace_j2g_jrt_struct_methods_A_class *jrt.Class

var A_arbace_j2g_jrt_tag_of_A_class *jrt.Class

func A_arbace_j2g_jrt__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_j2g_jrt__init_A_Load__O()}; return nil }

func A_arbace_j2g_jrt__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_jrt__init_A_New()}; return nil }

var A_arbace_j2g_jrt__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_j2g_jrt__init_A_invoke, New: A_arbace_j2g_jrt__init_A_new}

var A_arbace_j2g_jrt__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.jrt__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_j2g_jrt.A_arbace_j2g_jrt__init_A", Source: "jrt.ae"})

func init() { i := A_arbace_j2g_jrt__init_A_class.Info(); i.IsInstance = A_arbace_j2g_jrt__init_A_InstanceOf; i.Init = A_arbace_j2g_jrt__init_A_Init; i.Table = A_arbace_j2g_jrt__init_A_members }
