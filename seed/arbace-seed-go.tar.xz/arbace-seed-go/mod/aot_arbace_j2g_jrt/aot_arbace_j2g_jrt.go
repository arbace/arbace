//line aot_arbace_j2g_jrt.ae:1
package aot_arbace_j2g_jrt

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_java_io"
	"arbace/aot_arbace_repr_go_print"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_jrt_eval1716000004_loading__1927001464__auto____1716000005_A_New() *A_arbace_j2g_jrt_eval1716000004_loading__1927001464__auto____1716000005_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_eval1716000004_loading__1927001464__auto____1716000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_jrt_eval1716000004_loading__1927001464__auto____1716000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_jrt_eval1716000004_loading__1927001464__auto____1716000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_jrt_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_jrt_A_const_6); tmp2 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_jrt_A_const_1, A_arbace_j2g_jrt_A_const_2, A_arbace_j2g_jrt_A_const_3, A_arbace_j2g_jrt_A_const_4); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_jrt_eval1716000008_fn__1716000009_A_New() *A_arbace_j2g_jrt_eval1716000008_fn__1716000009_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_eval1716000008_fn__1716000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_jrt_eval1716000008_fn__1716000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_jrt_eval1716000008_fn__1716000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_j2g_jrt_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_j2g_jrt_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(), A_arbace_j2g_jrt_A_const_11) }









func A_arbace_j2g_jrt_head_A_New() *A_arbace_j2g_jrt_head_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_head_A{}; t.Ctor(); return t }
//line :11:1
func (t *A_arbace_j2g_jrt_head_A) Ctor() {}
//line :11:1
func (t *A_arbace_j2g_jrt_head_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_22 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = f__0; if linked_23 == nil { and__1927000168__auto____2 = ifn_24.Invoke_O__O(arg_25) } else { and__1927000168__auto____2 = linked_23.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_22, arg_25) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_26 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any; var root_30 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_32 lang.IFn; if linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any = f__0; if linked_31 == nil { arg_29 = ifn_32.Invoke_O__O(arg_33) } else { arg_29 = linked_31.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_30, arg_33) }; if linked_27 == nil { tmp1 = ifn_28.Invoke_O__O(arg_29) } else { tmp1 = linked_27.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_26, arg_29) } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var root_34 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any; var root_38 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_38, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_40 lang.IFn; if linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any = f__0; if linked_39 == nil { arg_37 = ifn_40.Invoke_O__O(arg_41) } else { arg_37 = linked_39.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_38, arg_41) }; if linked_35 == nil { return ifn_36.Invoke_O__O(arg_37) } else { return linked_35.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_34, arg_37) } } else { return nil } }

func A_arbace_j2g_jrt_go_head_A_New() *A_arbace_j2g_jrt_go_head_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_go_head_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_j2g_jrt_go_head_A) Ctor() {}
//line :13:1
func (t *A_arbace_j2g_jrt_go_head_A) Invoke_O_O__O(self, f__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var root_42 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_42, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any = f__0; if linked_43 == nil { and__1927000168__auto____2 = ifn_44.Invoke_O__O(arg_45) } else { and__1927000168__auto____2 = linked_43.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_42, arg_45) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_46 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any; var root_50 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = f__0; if linked_51 == nil { arg_49 = ifn_52.Invoke_O__O(arg_53) } else { arg_49 = linked_51.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_50, arg_53) }; if linked_47 == nil { and__1927000168__auto____3 = ifn_48.Invoke_O__O(arg_49) } else { and__1927000168__auto____3 = linked_47.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_46, arg_49) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_16); var tmp3 any; var root_62 any = A_arbace_j2g_jrt_A_const_17.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_64 lang.IFn; if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any; var root_66 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = f__0; if linked_67 == nil { arg_65 = ifn_68.Invoke_O__O(arg_69) } else { arg_65 = linked_67.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_66, arg_69) }; if linked_63 == nil { tmp3 = ifn_64.Invoke_O__O(arg_65) } else { tmp3 = linked_63.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_62, arg_65) }; tmp1 = tmp2.Invoke_O__O(tmp3) } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		var root_54 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any; var root_58 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = f__0; if linked_59 == nil { arg_57 = ifn_60.Invoke_O__O(arg_61) } else { arg_57 = linked_59.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_58, arg_61) }; if linked_55 == nil { return ifn_56.Invoke_O__O(arg_57) } else { return linked_55.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_54, arg_57) } } else {
//line :14:1
			return nil
		}
}
func A_arbace_j2g_jrt_tag_of_A_New() *A_arbace_j2g_jrt_tag_of_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_tag_of_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_j2g_jrt_tag_of_A) Ctor() {}
//line :17:1
func (t *A_arbace_j2g_jrt_tag_of_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_jrt_A_const_18; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0)) }

func A_arbace_j2g_jrt_recv_type_A_New() *A_arbace_j2g_jrt_recv_type_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_recv_type_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_j2g_jrt_recv_type_A) Ctor() {}
//line :19:1
func (t *A_arbace_j2g_jrt_recv_type_A) Invoke_O_O__O(self, r__0 any) any { var t__2 any; var tmp1 any; var root_70 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_72 lang.IFn; if


	linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = r__0; if linked_71 == nil { tmp1 = ifn_72.Invoke_O__O(arg_73) } else { tmp1 = linked_71.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_70, arg_73) }; if jrt.J2g_Truth(tmp1) { var root_74 any = A_arbace_j2g_jrt_A_const_19.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, A_arbace_j2g_jrt_tag_of_A_fn_class); var ifn_76 lang.IFn; if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any = r__0; if linked_75 == nil { t__2 = ifn_76.Invoke_O__O(arg_77) } else { t__2 = linked_75.(*A_arbace_j2g_jrt_tag_of_A).Invoke_O_O__O(root_74, arg_77) } } else { t__2 = r__0 }; var body_nm__3 /*line :19:1*/*A_arbace_j2g_jrt_recv_type_nm__1716000015_A = A_arbace_j2g_jrt_recv_type_nm__1716000015_A_New(); var nm__3 any; var fnbody__119 any = any(body_nm__3); var tmp2 *jrt.Class; var fncls__118 *jrt.Class = A_arbace_j2g_jrt_recv_type_nm__1716000015_A_fn_class; if fncls__118 == nil { var fncls__118d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, nil); A_arbace_j2g_jrt_recv_type_nm__1716000015_A_fn_class = fncls__118d; tmp2 = fncls__118d } else { tmp2 = fncls__118 }; nm__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__119, tmp2, nil); return /*line :27:1*/ lang.IFn_Cast(nm__3).Invoke_O__O(t__2) }
//line :23:1
func A_arbace_j2g_jrt_recv_type_nm__1716000015_A_New() *A_arbace_j2g_jrt_recv_type_nm__1716000015_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_recv_type_nm__1716000015_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_j2g_jrt_recv_type_nm__1716000015_A) Ctor() {}
//line :23:1
func (t *A_arbace_j2g_jrt_recv_type_nm__1716000015_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any; var root_78 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = x__1; if linked_79 == nil { tmp1 = ifn_80.Invoke_O__O(arg_81) } else { tmp1 = linked_79.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_78, arg_81) }; if jrt.J2g_Truth(tmp1) { var root_82 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = x__1; if linked_83 == nil { return ifn_84.Invoke_O__O(arg_85) } else { return linked_83.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_82, arg_85) } } else { var tmp2 any; var and__1927000168__auto____2 any; var root_86 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_88 lang.IFn
											if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any = x__1; if linked_87 == nil { and__1927000168__auto____2 = ifn_88.Invoke_O__O(arg_89) } else { and__1927000168__auto____2 = linked_87.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_86, arg_89) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp3 any = A_arbace_j2g_jrt_A_const_20; var tmp4 any; var root_90 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = x__1; if linked_91 == nil { tmp4 = ifn_92.Invoke_O__O(arg_93) } else { tmp4 = linked_91.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_90, arg_93) }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)).Ref() } else { tmp2 = and__1927000168__auto____2 }
//line :23:1
	if jrt.J2g_Truth(tmp2) {
		var tmp5 lang.IFn = lang.IFn_Cast(self); var tmp6 any; var root_114 any = A_arbace_j2g_jrt_A_const_22.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_116 lang.IFn; if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any = x__1; if linked_115 == nil { tmp6 = ifn_116.Invoke_O__O(arg_117) } else { tmp6 = linked_115.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_114, arg_117) }; return tmp5.Invoke_O__O(tmp6) } else {
//line :23:1
			var tmp7 any; var and__1927000168__auto____2_2 any; var root_94 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_96 lang.IFn

			if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = x__1; if linked_95 == nil { and__1927000168__auto____2_2 = ifn_96.Invoke_O__O(arg_97) } else { and__1927000168__auto____2_2 = linked_95.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_94, arg_97) }; if jrt.J2g_Truth(and__1927000168__auto____2_2) { var root_98 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any; var root_102 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = x__1; if linked_103 == nil { arg_101 = ifn_104.Invoke_O__O(arg_105) } else { arg_101 = linked_103.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_102, arg_105) }; if linked_99 == nil { tmp7 = ifn_100.Invoke_O__O(arg_101) } else { tmp7 = linked_99.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_98, arg_101) } } else { tmp7 = and__1927000168__auto____2_2 }
//line :23:1
			if jrt.J2g_Truth(tmp7) {

				var root_106 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any; var root_110 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_112 lang.IFn; if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any = x__1; if linked_111 == nil { arg_109 = ifn_112.Invoke_O__O(arg_113) } else { arg_109 = linked_111.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_110, arg_113) }; if linked_107 == nil { return ifn_108.Invoke_O__O(arg_109) } else { return linked_107.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_106, arg_109) } } else {
//line :23:1
					if A_arbace_j2g_jrt_A_const_21 != nil { return nil } else { return nil } } } } }





func A_arbace_j2g_jrt_strip_doc_A_New() *A_arbace_j2g_jrt_strip_doc_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_strip_doc_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_j2g_jrt_strip_doc_A) Ctor() {}
//line :29:1
func (t *A_arbace_j2g_jrt_strip_doc_A) Invoke_O_O__O(self, xs__0 any) any { var tmp1 any; var root_120 any = A_arbace_j2g_jrt_A_const_23.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any; var root_124 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = xs__0; if linked_125 == nil { arg_123 = ifn_126.Invoke_O__O(arg_127) } else { arg_123 = linked_125.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_124, arg_127) }; if linked_121 == nil { tmp1 = ifn_122.Invoke_O__O(arg_123) } else { tmp1 = linked_121.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_120, arg_123) }; if jrt.J2g_Truth(tmp1) { var root_128 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = xs__0; if linked_129 == nil { return ifn_130.Invoke_O__O(arg_131) } else { return linked_129.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_128, arg_131) } } else { return xs__0 } }

func A_arbace_j2g_jrt_define_name_A_New() *A_arbace_j2g_jrt_define_name_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_define_name_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_j2g_jrt_define_name_A) Ctor() {}
//line :31:1
func (t *A_arbace_j2g_jrt_define_name_A) Invoke_O_O__O(self, init__0 any) any { var found__2 any; var root_132 any = A_arbace_j2g_jrt_A_const_25.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_134 lang.IFn; if


	linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any; if linked_133 == nil { found__2 = ifn_134.Invoke_O__O(arg_135) } else { found__2 = linked_133.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_132, arg_135) }; var body_walk__3 /*line :31:1*/*A_arbace_j2g_jrt_define_name_walk__1716000019_A = A_arbace_j2g_jrt_define_name_walk__1716000019_A_New_O(found__2); var walk__3 any; var fnbody__181 any = any(body_walk__3); var tmp1 *jrt.Class; var fncls__180 *jrt.Class = A_arbace_j2g_jrt_define_name_walk__1716000019_A_fn_class; if fncls__180 == nil { var fncls__180d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1, false, fnbody__181); A_arbace_j2g_jrt_define_name_walk__1716000019_A_fn_class = fncls__180d; tmp1 = fncls__180d } else { tmp1 = fncls__180 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__181, tmp1, nil);










	lang.IFn_Cast(walk__3).Invoke_O__O(init__0); var root_136 any = /*line :34:1*/A_arbace_j2g_jrt_A_const_8.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = found__2; if linked_137 == nil { return ifn_138.Invoke_O__O(arg_139) } else { return linked_137.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_136, arg_139) } }
func A_arbace_j2g_jrt_define_name_walk__1716000019_A_New_O(p0 any) *A_arbace_j2g_jrt_define_name_walk__1716000019_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_define_name_walk__1716000019_A{}; t.Ctor_O(p0); return t }
//line :35:1
func (t *A_arbace_j2g_jrt_define_name_walk__1716000019_A) Ctor_O(c__found any) { t.F_found = c__found }
//line :35:1
func (t *A_arbace_j2g_jrt_define_name_walk__1716000019_A) Invoke_O_O__O(self, x__1 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var root_140 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_142 lang.IFn
	if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = x__1; if linked_141 == nil { and__1927000168__auto____2 = ifn_142.Invoke_O__O(arg_143) } else { and__1927000168__auto____2 = linked_141.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_140, arg_143) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 bool; var tmp2 any; var root_144 any = A_arbace_j2g_jrt_A_const_26.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_144, A_arbace_j2g_jrt_head_A_fn_class); var ifn_146 lang.IFn; if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any = x__1; if linked_145 == nil { tmp2 = ifn_146.Invoke_O__O(arg_147) } else { tmp2 = linked_145.(*A_arbace_j2g_jrt_head_A).Invoke_O_O__O(root_144, arg_147) }; and__1927000168__auto____3 = lang.Util_Equiv_O_O__Z_NoInit(Lit_2, tmp2); if and__1927000168__auto____3 { var tmp3 any = A_arbace_j2g_jrt_A_const_27; var tmp4 any; var root_148 any = A_arbace_j2g_jrt_A_const_22.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = x__1; if linked_149 == nil { tmp4 = ifn_150.Invoke_O__O(arg_151) } else { tmp4 = linked_149.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_148, arg_151) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)).Ref() } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { tmp1 = and__1927000168__auto____2 }
//line :36:1
	if jrt.J2g_Truth(tmp1) { var kvs__2 any; var root_152 any = A_arbace_j2g_jrt_A_const_28.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_154 lang.IFn

		if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = A_arbace_j2g_jrt_A_const_29.GetRawRoot__O(); var arg_156 any; var root_157 any = A_arbace_j2g_jrt_A_const_30.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_157, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_161 any = x__1; if linked_158 == nil { arg_156 = ifn_159.Invoke_O_O__O(A_arbace_j2g_jrt_A_const_31, arg_161) } else { arg_156 = linked_158.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_157, 2, A_arbace_j2g_jrt_A_const_31, arg_161) }; if linked_153 == nil { kvs__2 = ifn_154.Invoke_O_O__O(arg_155, arg_156) } else { kvs__2 = linked_153.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_152, arg_155, arg_156) }
		var tmp5 any; var root_162 any = A_arbace_j2g_jrt_A_const_23.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = A_arbace_j2g_jrt_A_const_32.Invoke_O__O(kvs__2); if linked_163 == nil { tmp5 = ifn_164.Invoke_O__O(arg_165) } else { tmp5 = linked_163.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_162, arg_165) }; if jrt.J2g_Truth(tmp5) { var root_166 any = A_arbace_j2g_jrt_A_const_33.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = t.F_found; var tmp6 any = A_arbace_j2g_jrt_A_const_34; var arg_170 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, A_arbace_j2g_jrt_A_const_32.Invoke_O__O(kvs__2), A_arbace_j2g_jrt_A_const_35, kvs__2)); if linked_167 == nil { return ifn_168.Invoke_O_O__O(arg_169, arg_170) } else { return linked_167.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_166, arg_169, arg_170) } } else { return nil } } else {
//line :36:1
			var tmp7 any; var root_171 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_173 lang.IFn



			if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any = x__1; if linked_172 == nil { tmp7 = ifn_173.Invoke_O__O(arg_174) } else { tmp7 = linked_172.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_171, arg_174) }
//line :36:1
			if jrt.J2g_Truth(tmp7) {



				var root_175 any = A_arbace_j2g_jrt_A_const_36.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = self; var arg_179 any = x__1; if linked_176 == nil { return ifn_177.Invoke_O_O__O(arg_178, arg_179) } else { return linked_176.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_175, arg_178, arg_179) } } else {
//line :36:1
					if A_arbace_j2g_jrt_A_const_21 != nil { return nil } else { return nil
					}
				}
		}
}




func A_arbace_j2g_jrt_scan_file_A_New() *A_arbace_j2g_jrt_scan_file_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_file_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_j2g_jrt_scan_file_A) Ctor() {}
//line :45:1
func (t *A_arbace_j2g_jrt_scan_file_A) Invoke_O_O__O(self, f__0 any) any { var forms__2 any; var root_182 any = A_arbace_j2g_jrt_A_const_37.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A_fn_class); var ifn_184 lang.IFn; if



	linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = f__0; if linked_183 == nil { forms__2 = ifn_184.Invoke_O__O(arg_185) } else { forms__2 = linked_183.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A).Invoke_O_O__O(root_182, arg_185) }; var acc__3 any; var root_186 any = /*line :45:1*/A_arbace_j2g_jrt_A_const_38.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_188 lang.IFn; if




	linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_jrt_A_const_39, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_j2g_jrt_A_const_40, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_j2g_jrt_A_const_41, lang.PersistentHashSet_EMPTY.Ref(), A_arbace_j2g_jrt_A_const_42, lang.PersistentHashSet_EMPTY.Ref(), A_arbace_j2g_jrt_A_const_43, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_j2g_jrt_A_const_44, lang.PersistentHashSet_EMPTY.Ref())); if linked_187 == nil { acc__3 = ifn_188.Invoke_O__O(arg_189) } else { acc__3 = linked_187.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_186, arg_189) }; var seq_1716000022__4 any; var root_194 any = /*line :45:1*/A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_196 lang.IFn; if





	linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = forms__2; if linked_195 == nil { seq_1716000022__4 = ifn_196.Invoke_O__O(arg_197) } else { seq_1716000022__4 = linked_195.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_194, arg_197) }; var chunk_1716000023__5 any; var count_1716000024__6 int64 = 0; var i_1716000025__7 int64 = 0; L1:
//line :45:1
	for {





		if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000025__7, count_1716000024__6) { var fm__8 any = lang.Indexed_Cast(chunk_1716000023__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000025__7)); var h__9 any; var root_198 any = A_arbace_j2g_jrt_A_const_46.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, A_arbace_j2g_jrt_go_head_A_fn_class); var ifn_200 lang.IFn
			if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = fm__8; if linked_199 == nil { h__9 = ifn_200.Invoke_O__O(arg_201) } else { h__9 = linked_199.(*A_arbace_j2g_jrt_go_head_A).Invoke_O_O__O(root_198, arg_201) }
//line :51:1
			if jrt.J2g_Truth(h__9) { var G__1716000026__10_ any = h__9


			L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__1716000026__10_) >> 0 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000026__10_, Lit_31) { var vec__1716000027__11 any = fm__8; var seq__1716000028__12 any; var root_223 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_225 lang.IFn


















				if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any = vec__1716000027__11; if linked_224 == nil { seq__1716000028__12 = ifn_225.Invoke_O__O(arg_226) } else { seq__1716000028__12 = linked_224.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_223, arg_226) }
//line :54:1
				var first__1716000029__13 any; var root_227 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_229 lang.IFn


















				if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = seq__1716000028__12; if linked_228 == nil { first__1716000029__13 = ifn_229.Invoke_O__O(arg_230) } else { first__1716000029__13 = linked_228.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_227, arg_230) }
//line :54:1
				var seq__1716000028__14 any; var root_231 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_233 lang.IFn


















				if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = seq__1716000028__12; if linked_232 == nil { seq__1716000028__14 = ifn_233.Invoke_O__O(arg_234) } else { seq__1716000028__14 = linked_232.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_231, arg_234) }
//line :54:1
				var ___15 any = first__1716000029__13; var first__1716000029__16 any; var root_235 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_237 lang.IFn; _ = ___15


















				if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any = seq__1716000028__14; if linked_236 == nil { first__1716000029__16 = ifn_237.Invoke_O__O(arg_238) } else { first__1716000029__16 = linked_236.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_235, arg_238) }
//line :54:1
				var seq__1716000028__17 any; var root_239 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_239, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_241 lang.IFn


















				if linked_240 == nil { ifn_241 = lang.IFn_Cast(root_239) } else { ifn_241 = nil }; var arg_242 any = seq__1716000028__14; if linked_240 == nil { seq__1716000028__17 = ifn_241.Invoke_O__O(arg_242) } else { seq__1716000028__17 = linked_240.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_239, arg_242) }
//line :54:1
				var nm__18 any = first__1716000029__16; var more__19 any = seq__1716000028__17; var more__20 any; var root_243 any = A_arbace_j2g_jrt_A_const_50.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_243, A_arbace_j2g_jrt_strip_doc_A_fn_class); var ifn_245 lang.IFn



















				if linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any = more__19; if linked_244 == nil { more__20 = ifn_245.Invoke_O__O(arg_246) } else { more__20 = linked_244.(*A_arbace_j2g_jrt_strip_doc_A).Invoke_O_O__O(root_243, arg_246) }
//line :54:1
				var more__21 any; var tmp1 any = A_arbace_j2g_jrt_A_const_51; var tmp2 any; var root_247 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_247, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_249 lang.IFn




















				if linked_248 == nil { ifn_249 = lang.IFn_Cast(root_247) } else { ifn_249 = nil }; var arg_250 any = more__20; if linked_248 == nil { tmp2 = ifn_249.Invoke_O__O(arg_250) } else { tmp2 = linked_248.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_247, arg_250) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2) { var root_251 any = A_arbace_j2g_jrt_A_const_30.GetRawRoot__O(); var linked_252 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_251, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_253 lang.IFn; if linked_252 == nil { ifn_253 = lang.IFn_Cast(root_251) } else { ifn_253 = nil }; var arg_255 any = more__20; if linked_252 == nil { more__21 = ifn_253.Invoke_O_O__O(A_arbace_j2g_jrt_A_const_31, arg_255) } else { more__21 = linked_252.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_251, 2, A_arbace_j2g_jrt_A_const_31, arg_255) } } else { more__21 = more__20 }
//line :54:1
				var params__22 any; var root_256 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_258 lang.IFn





















				if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = more__21; if linked_257 == nil { params__22 = ifn_258.Invoke_O__O(arg_259) } else { params__22 = linked_257.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_256, arg_259) }
//line :54:1
				var rt__23 any; var root_260 any = A_arbace_j2g_jrt_A_const_52.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, A_arbace_j2g_jrt_recv_type_A_fn_class); var ifn_262 lang.IFn






















				if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any; var root_264 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_264, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_266 lang.IFn; if linked_265 == nil { ifn_266 = lang.IFn_Cast(root_264) } else { ifn_266 = nil }; var arg_267 any = params__22; if linked_265 == nil { arg_263 = ifn_266.Invoke_O__O(arg_267) } else { arg_263 = linked_265.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_264, arg_267) }; if linked_261 == nil { rt__23 = ifn_262.Invoke_O__O(arg_263) } else { rt__23 = linked_261.(*A_arbace_j2g_jrt_recv_type_A).Invoke_O_O__O(root_260, arg_263) }
				if jrt.J2g_Truth(rt__23) { var tmp3 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_53.GetRawRoot__O()); var tmp5 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp6 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_jrt_A_const_40, rt__23); var tmp7 any; var root_275 any = A_arbace_j2g_jrt_A_const_54.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_279 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_276 == nil { tmp7 = ifn_277.Invoke_O_O__O(arg_278, arg_279) } else { tmp7 = linked_276.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_275, arg_278, arg_279) }; var tmp8 any = tmp7; var tmp9 any; var root_280 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_282 lang.IFn; if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any = nm__18; if linked_281 == nil { tmp9 = ifn_282.Invoke_O__O(arg_283) } else { tmp9 = linked_281.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_280, arg_283) }; jrt.NN(tmp3).Reset_O__O(tmp4.Invoke_O_O_O_O__O(tmp5, tmp6, tmp8, tmp9)) }
//line :54:1
				break L2 }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000026__10_, Lit_32) { var vec__1716000030__11 any = fm__8; var seq__1716000031__12 any; var root_284 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_284, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_286 lang.IFn
					if linked_285 == nil { ifn_286 = lang.IFn_Cast(root_284) } else { ifn_286 = nil }; var arg_287 any = vec__1716000030__11; if linked_285 == nil { seq__1716000031__12 = ifn_286.Invoke_O__O(arg_287) } else { seq__1716000031__12 = linked_285.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_284, arg_287) }
//line :54:1
					var first__1716000032__13 any; var root_288 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_288, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_290 lang.IFn
					if linked_289 == nil { ifn_290 = lang.IFn_Cast(root_288) } else { ifn_290 = nil }; var arg_291 any = seq__1716000031__12; if linked_289 == nil { first__1716000032__13 = ifn_290.Invoke_O__O(arg_291) } else { first__1716000032__13 = linked_289.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_288, arg_291) }
//line :54:1
					var seq__1716000031__14 any; var root_292 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_294 lang.IFn
					if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = seq__1716000031__12; if linked_293 == nil { seq__1716000031__14 = ifn_294.Invoke_O__O(arg_295) } else { seq__1716000031__14 = linked_293.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_292, arg_295) }
//line :54:1
					var ___15_2 any = first__1716000032__13; var more__16 any = seq__1716000031__14; var more__17 any; var root_296 any = A_arbace_j2g_jrt_A_const_50.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, A_arbace_j2g_jrt_strip_doc_A_fn_class); var ifn_298 lang.IFn; _ = ___15_2

					if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = more__16; if linked_297 == nil { more__17 = ifn_298.Invoke_O__O(arg_299) } else { more__17 = linked_297.(*A_arbace_j2g_jrt_strip_doc_A).Invoke_O_O__O(root_296, arg_299) }
					var tmp10 any; var root_300 any = A_arbace_j2g_jrt_A_const_55.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any; var root_304 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_306 lang.IFn; if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = more__17; if linked_305 == nil { arg_303 = ifn_306.Invoke_O__O(arg_307) } else { arg_303 = linked_305.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_304, arg_307) }; if linked_301 == nil { tmp10 = ifn_302.Invoke_O__O(arg_303) } else { tmp10 = linked_301.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_300, arg_303) }; if jrt.J2g_Truth(tmp10) { var seq_1716000033__18 any; var root_308 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_310 lang.IFn
						if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = more__17; if linked_309 == nil { seq_1716000033__18 = ifn_310.Invoke_O__O(arg_311) } else { seq_1716000033__18 = linked_309.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_308, arg_311) }
//line :57:1
						var chunk_1716000034__19 any; var count_1716000035__20 int64 = 0; var i_1716000036__21 int64 = 0; L3: for {
							if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000036__21, count_1716000035__20) { var vec__1716000037__22 any = lang.Indexed_Cast(chunk_1716000034__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000036__21)); var nm__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000037__22, lang.RT_IntCast_J__I_NoInit(0), nil); var tf__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000037__22, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp11 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp12 any; var root_457 any = A_arbace_j2g_jrt_A_const_56.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_459 lang.IFn
								if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_461 any; var tmp13 any = A_arbace_j2g_jrt_A_const_39; var tmp14 any; var root_463 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = nm__23; if linked_464 == nil { tmp14 = ifn_465.Invoke_O__O(arg_466) } else { tmp14 = linked_464.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_463, arg_466) }; arg_461 = lang.Tuple_Create_O_O__IPersistentVector(tmp13, tmp14); var arg_462 any; var tmp15 any = A_arbace_j2g_jrt_A_const_57; var tmp16 *lang.Keyword; var tmp17 any; var and__1927000168__auto____25 any; var root_467 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_469 lang.IFn
								if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = tf__24; if linked_468 == nil { and__1927000168__auto____25 = ifn_469.Invoke_O__O(arg_470) } else { and__1927000168__auto____25 = linked_468.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_467, arg_470) }; if jrt.J2g_Truth(and__1927000168__auto____25) { var tmp18 any = A_arbace_j2g_jrt_A_const_65; var tmp19 any; var root_471 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_473 lang.IFn; if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = tf__24; if linked_472 == nil { tmp19 = ifn_473.Invoke_O__O(arg_474) } else { tmp19 = linked_472.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_471, arg_474) }; tmp17 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp18, tmp19)).Ref() } else { tmp17 = and__1927000168__auto____25 }; if jrt.J2g_Truth(tmp17) { tmp16 = A_arbace_j2g_jrt_A_const_59 } else { var tmp20 any; var and__1927000168__auto____25_2 any; var root_475 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_477 lang.IFn
									if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = tf__24; if linked_476 == nil { and__1927000168__auto____25_2 = ifn_477.Invoke_O__O(arg_478) } else { and__1927000168__auto____25_2 = linked_476.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_475, arg_478) }; if jrt.J2g_Truth(and__1927000168__auto____25_2) { var tmp21 any = A_arbace_j2g_jrt_A_const_66; var tmp22 any; var root_479 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = tf__24; if linked_480 == nil { tmp22 = ifn_481.Invoke_O__O(arg_482) } else { tmp22 = linked_480.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_479, arg_482) }; tmp20 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp21, tmp22)).Ref() } else { tmp20 = and__1927000168__auto____25_2 }
//line :60:1
									if jrt.J2g_Truth(tmp20) { tmp16 = A_arbace_j2g_jrt_A_const_61 } else { if A_arbace_j2g_jrt_A_const_21 != nil { tmp16 = A_arbace_j2g_jrt_A_const_62 } else { tmp16 = nil } } }
//line :59:1
								arg_462 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp15, tmp16.Ref(), A_arbace_j2g_jrt_A_const_63, tf__24)); if linked_458 == nil { tmp12 = ifn_459.Invoke_O_O_O__O(arg_460, arg_461, arg_462) } else { tmp12 = linked_458.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_457, arg_460, arg_461, arg_462) }; jrt.NN(tmp11).Reset_O__O(tmp12)
//line :58:1
								seq_1716000033__18, chunk_1716000034__19, count_1716000035__20, i_1716000036__21 = seq_1716000033__18, chunk_1716000034__19, count_1716000035__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000036__21); continue L3 } else { var temp__1927000414__auto____22 any; var root_312 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = seq_1716000033__18; if linked_313 == nil { temp__1927000414__auto____22 = ifn_314.Invoke_O__O(arg_315) } else { temp__1927000414__auto____22 = linked_313.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_312, arg_315) }; if jrt.J2g_Truth(temp__1927000414__auto____22) { var seq_1716000033__23 any = temp__1927000414__auto____22; var tmp23 any; var root_316 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = seq_1716000033__23; if linked_317 == nil { tmp23 = ifn_318.Invoke_O__O(arg_319) } else { tmp23 = linked_317.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_316, arg_319) }; if jrt.J2g_Truth(tmp23) { var c__1927000678__auto____24 any; var root_320 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = seq_1716000033__23; if linked_321 == nil { c__1927000678__auto____24 = ifn_322.Invoke_O__O(arg_323) } else { c__1927000678__auto____24 = linked_321.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_320, arg_323) }; var tmp24 any; var root_483 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_485 lang.IFn; if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any = seq_1716000033__23; if linked_484 == nil { tmp24 = ifn_485.Invoke_O__O(arg_486) } else { tmp24 = linked_484.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_483, arg_486) }; seq_1716000033__18, chunk_1716000034__19, count_1716000035__20, i_1716000036__21 = tmp24, c__1927000678__auto____24, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__1716000040__24 any; var root_324 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = seq_1716000033__23; if linked_325 == nil { vec__1716000040__24 = ifn_326.Invoke_O__O(arg_327) } else { vec__1716000040__24 = linked_325.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_324, arg_327) }; var nm__25 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000040__24, lang.RT_IntCast_J__I_NoInit(0), nil); var tf__26 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000040__24, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp25 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp26 any; var root_487 any = A_arbace_j2g_jrt_A_const_56.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_489 lang.IFn
									if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_491 any; var tmp27 any = A_arbace_j2g_jrt_A_const_39; var tmp28 any; var root_493 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_493, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_495 lang.IFn; if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any = nm__25; if linked_494 == nil { tmp28 = ifn_495.Invoke_O__O(arg_496) } else { tmp28 = linked_494.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_493, arg_496) }; arg_491 = lang.Tuple_Create_O_O__IPersistentVector(tmp27, tmp28); var arg_492 any; var tmp29 any = A_arbace_j2g_jrt_A_const_57; var tmp30 *lang.Keyword; var tmp31 any; var and__1927000168__auto____27 any; var root_497 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_499 lang.IFn
									if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = tf__26; if linked_498 == nil { and__1927000168__auto____27 = ifn_499.Invoke_O__O(arg_500) } else { and__1927000168__auto____27 = linked_498.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_497, arg_500) }; if jrt.J2g_Truth(and__1927000168__auto____27) { var tmp32 any = A_arbace_j2g_jrt_A_const_65; var tmp33 any; var root_501 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_501, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_503 lang.IFn; if linked_502 == nil { ifn_503 = lang.IFn_Cast(root_501) } else { ifn_503 = nil }; var arg_504 any = tf__26; if linked_502 == nil { tmp33 = ifn_503.Invoke_O__O(arg_504) } else { tmp33 = linked_502.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_501, arg_504) }; tmp31 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp32, tmp33)).Ref() } else { tmp31 = and__1927000168__auto____27 }; if jrt.J2g_Truth(tmp31) { tmp30 = A_arbace_j2g_jrt_A_const_59 } else { var tmp34 any; var and__1927000168__auto____27_2 any; var root_505 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_505, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_507 lang.IFn
										if linked_506 == nil { ifn_507 = lang.IFn_Cast(root_505) } else { ifn_507 = nil }; var arg_508 any = tf__26; if linked_506 == nil { and__1927000168__auto____27_2 = ifn_507.Invoke_O__O(arg_508) } else { and__1927000168__auto____27_2 = linked_506.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_505, arg_508) }; if jrt.J2g_Truth(and__1927000168__auto____27_2) { var tmp35 any = A_arbace_j2g_jrt_A_const_66; var tmp36 any; var root_509 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_509, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_511 lang.IFn; if linked_510 == nil { ifn_511 = lang.IFn_Cast(root_509) } else { ifn_511 = nil }; var arg_512 any = tf__26; if linked_510 == nil { tmp36 = ifn_511.Invoke_O__O(arg_512) } else { tmp36 = linked_510.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_509, arg_512) }; tmp34 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp35, tmp36)).Ref() } else { tmp34 = and__1927000168__auto____27_2 }
//line :60:1
										if jrt.J2g_Truth(tmp34) { tmp30 = A_arbace_j2g_jrt_A_const_61 } else { if A_arbace_j2g_jrt_A_const_21 != nil { tmp30 = A_arbace_j2g_jrt_A_const_62 } else { tmp30 = nil } } }
//line :59:1
									arg_492 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp29, tmp30.Ref(), A_arbace_j2g_jrt_A_const_63, tf__26)); if linked_488 == nil { tmp26 = ifn_489.Invoke_O_O_O__O(arg_490, arg_491, arg_492) } else { tmp26 = linked_488.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_487, arg_490, arg_491, arg_492) }; jrt.NN(tmp25).Reset_O__O(tmp26)
//line :58:1
									var tmp37 any; var root_513 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_513, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_515 lang.IFn; if linked_514 == nil { ifn_515 = lang.IFn_Cast(root_513) } else { ifn_515 = nil }; var arg_516 any = seq_1716000033__23; if linked_514 == nil { tmp37 = ifn_515.Invoke_O__O(arg_516) } else { tmp37 = linked_514.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_513, arg_516) }; seq_1716000033__18, chunk_1716000034__19, count_1716000035__20, i_1716000036__21 = tmp37, nil, 0, 0; continue L3 } } }
//line :57:1
							break L3 } } else { var nm__18_2 any; var root_328 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_330 lang.IFn






								if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = more__17; if linked_329 == nil { nm__18_2 = ifn_330.Invoke_O__O(arg_331) } else { nm__18_2 = linked_329.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_328, arg_331) }
//line :57:1
								var more__19_2 any; var root_332 any = A_arbace_j2g_jrt_A_const_50.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_332, A_arbace_j2g_jrt_strip_doc_A_fn_class); var ifn_334 lang.IFn







								if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any; var root_336 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_336, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_338 lang.IFn; if linked_337 == nil { ifn_338 = lang.IFn_Cast(root_336) } else { ifn_338 = nil }; var arg_339 any = more__17; if linked_337 == nil { arg_335 = ifn_338.Invoke_O__O(arg_339) } else { arg_335 = linked_337.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_336, arg_339) }; if linked_333 == nil { more__19_2 = ifn_334.Invoke_O__O(arg_335) } else { more__19_2 = linked_333.(*A_arbace_j2g_jrt_strip_doc_A).Invoke_O_O__O(root_332, arg_335) }
//line :57:1
								var more__20_2 any; var tmp38 any = A_arbace_j2g_jrt_A_const_51; var tmp39 any; var root_340 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_340, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_342 lang.IFn








								if linked_341 == nil { ifn_342 = lang.IFn_Cast(root_340) } else { ifn_342 = nil }; var arg_343 any = more__19_2; if linked_341 == nil { tmp39 = ifn_342.Invoke_O__O(arg_343) } else { tmp39 = linked_341.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_340, arg_343) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp38, tmp39) { var root_344 any = A_arbace_j2g_jrt_A_const_30.GetRawRoot__O(); var linked_345 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_344, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_346 lang.IFn; if linked_345 == nil { ifn_346 = lang.IFn_Cast(root_344) } else { ifn_346 = nil }; var arg_348 any = more__19_2; if linked_345 == nil { more__20_2 = ifn_346.Invoke_O_O__O(A_arbace_j2g_jrt_A_const_31, arg_348) } else { more__20_2 = linked_345.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_344, 2, A_arbace_j2g_jrt_A_const_31, arg_348) } } else { more__20_2 = more__19_2 }
//line :57:1
								var tf__21 any; var root_349 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_351 lang.IFn









								if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any = more__20_2; if linked_350 == nil { tf__21 = ifn_351.Invoke_O__O(arg_352) } else { tf__21 = linked_350.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_349, arg_352) }
								var tmp40 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp41 any; var root_353 any = A_arbace_j2g_jrt_A_const_56.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_357 any; var tmp42 any = A_arbace_j2g_jrt_A_const_39; var tmp43 any; var root_359 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = nm__18_2; if linked_360 == nil { tmp43 = ifn_361.Invoke_O__O(arg_362) } else { tmp43 = linked_360.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_359, arg_362) }; arg_357 = lang.Tuple_Create_O_O__IPersistentVector(tmp42, tmp43); var arg_358 any; var tmp44 any = A_arbace_j2g_jrt_A_const_57; var tmp45 *lang.Keyword; var tmp46 any; var and__1927000168__auto____22 any; var root_363 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_365 lang.IFn
								if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = tf__21; if linked_364 == nil { and__1927000168__auto____22 = ifn_365.Invoke_O__O(arg_366) } else { and__1927000168__auto____22 = linked_364.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_363, arg_366) }; if jrt.J2g_Truth(and__1927000168__auto____22) { var tmp47 any = A_arbace_j2g_jrt_A_const_58; var tmp48 any; var root_367 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_369 lang.IFn; if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = tf__21; if linked_368 == nil { tmp48 = ifn_369.Invoke_O__O(arg_370) } else { tmp48 = linked_368.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_367, arg_370) }; tmp46 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp47, tmp48)).Ref() } else { tmp46 = and__1927000168__auto____22 }; if jrt.J2g_Truth(tmp46) { tmp45 = A_arbace_j2g_jrt_A_const_59 } else { var tmp49 any; var and__1927000168__auto____22_2 any; var root_371 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_373 lang.IFn
									if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = tf__21; if linked_372 == nil { and__1927000168__auto____22_2 = ifn_373.Invoke_O__O(arg_374) } else { and__1927000168__auto____22_2 = linked_372.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_371, arg_374) }; if jrt.J2g_Truth(and__1927000168__auto____22_2) { var tmp50 any = A_arbace_j2g_jrt_A_const_60; var tmp51 any; var root_375 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = tf__21; if linked_376 == nil { tmp51 = ifn_377.Invoke_O__O(arg_378) } else { tmp51 = linked_376.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_375, arg_378) }; tmp49 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp50, tmp51)).Ref() } else { tmp49 = and__1927000168__auto____22_2 }
//line :69:1
									if jrt.J2g_Truth(tmp49) { tmp45 = A_arbace_j2g_jrt_A_const_61 } else { if A_arbace_j2g_jrt_A_const_21 != nil { tmp45 = A_arbace_j2g_jrt_A_const_62 } else { tmp45 = nil } } }
//line :68:1
								arg_358 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp44, tmp45.Ref(), A_arbace_j2g_jrt_A_const_63, tf__21)); if linked_354 == nil { tmp41 = ifn_355.Invoke_O_O_O__O(arg_356, arg_357, arg_358) } else { tmp41 = linked_354.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_353, arg_356, arg_357, arg_358) }; jrt.NN(tmp40).Reset_O__O(tmp41) }
//line :54:1
					break L2 }; case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000026__10_, Lit_33) { var vec__1716000043__11 any = fm__8; var seq__1716000044__12 any; var root_379 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_379, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_381 lang.IFn








































						if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = vec__1716000043__11; if linked_380 == nil { seq__1716000044__12 = ifn_381.Invoke_O__O(arg_382) } else { seq__1716000044__12 = linked_380.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_379, arg_382) }
//line :54:1
						var first__1716000045__13 any; var root_383 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_385 lang.IFn








































						if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any = seq__1716000044__12; if linked_384 == nil { first__1716000045__13 = ifn_385.Invoke_O__O(arg_386) } else { first__1716000045__13 = linked_384.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_383, arg_386) }
//line :54:1
						var seq__1716000044__14 any; var root_387 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_389 lang.IFn








































						if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = seq__1716000044__12; if linked_388 == nil { seq__1716000044__14 = ifn_389.Invoke_O__O(arg_390) } else { seq__1716000044__14 = linked_388.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_387, arg_390) }
//line :54:1
						var ___15_3 any = first__1716000045__13; var more__16_2 any = seq__1716000044__14; var more__17_2 any; var root_391 any = A_arbace_j2g_jrt_A_const_50.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_391, A_arbace_j2g_jrt_strip_doc_A_fn_class); var ifn_393 lang.IFn; _ = ___15_3









































						if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = more__16_2; if linked_392 == nil { more__17_2 = ifn_393.Invoke_O__O(arg_394) } else { more__17_2 = linked_392.(*A_arbace_j2g_jrt_strip_doc_A).Invoke_O_O__O(root_391, arg_394) }
						var tmp52 any; var root_395 any = A_arbace_j2g_jrt_A_const_55.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_395, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_397 lang.IFn; if linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any; var root_399 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_401 lang.IFn; if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = more__17_2; if linked_400 == nil { arg_398 = ifn_401.Invoke_O__O(arg_402) } else { arg_398 = linked_400.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_399, arg_402) }; if linked_396 == nil { tmp52 = ifn_397.Invoke_O__O(arg_398) } else { tmp52 = linked_396.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_395, arg_398) }; if jrt.J2g_Truth(tmp52) { var seq_1716000046__18 any; var root_403 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_405 lang.IFn
							if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = more__17_2; if linked_404 == nil { seq_1716000046__18 = ifn_405.Invoke_O__O(arg_406) } else { seq_1716000046__18 = linked_404.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_403, arg_406) }
//line :97:1
							var chunk_1716000047__19 any; var count_1716000048__20 int64 = 0; var i_1716000049__21 int64 = 0; L4: for {
								if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000049__21, count_1716000048__20) { var vec__1716000050__22 any = lang.Indexed_Cast(chunk_1716000047__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000049__21)); var tg__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000050__22, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp53 any; var root_517 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_517, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_519 lang.IFn; if linked_518 == nil { ifn_519 = lang.IFn_Cast(root_517) } else { ifn_519 = nil }; var arg_520 any = tg__23; if linked_518 == nil { tmp53 = ifn_519.Invoke_O__O(arg_520) } else { tmp53 = linked_518.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_517, arg_520) }; if jrt.J2g_Truth(tmp53) { var tmp54 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp55 any; var root_521 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_522 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_521, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_523 lang.IFn; if linked_522 == nil { ifn_523 = lang.IFn_Cast(root_521) } else { ifn_523 = nil }; var arg_524 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_525 any = A_arbace_j2g_jrt_A_const_44; var arg_526 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_527 any; var root_528 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any = tg__23; if linked_529 == nil { arg_527 = ifn_530.Invoke_O__O(arg_531) } else { arg_527 = linked_529.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_528, arg_531) }; if linked_522 == nil { tmp55 = ifn_523.Invoke_O_O_O_O__O(arg_524, arg_525, arg_526, arg_527) } else { tmp55 = linked_522.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_521, arg_524, arg_525, arg_526, arg_527) }; jrt.NN(tmp54).Reset_O__O(tmp55) }; seq_1716000046__18, chunk_1716000047__19, count_1716000048__20, i_1716000049__21 = seq_1716000046__18, chunk_1716000047__19, count_1716000048__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000049__21); continue L4 } else { var temp__1927000414__auto____22_2 any; var root_407 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = seq_1716000046__18; if linked_408 == nil { temp__1927000414__auto____22_2 = ifn_409.Invoke_O__O(arg_410) } else { temp__1927000414__auto____22_2 = linked_408.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_407, arg_410) }; if jrt.J2g_Truth(temp__1927000414__auto____22_2) { var seq_1716000046__23 any = temp__1927000414__auto____22_2; var tmp56 any; var root_411 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_411, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_413 lang.IFn; if linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any = seq_1716000046__23; if linked_412 == nil { tmp56 = ifn_413.Invoke_O__O(arg_414) } else { tmp56 = linked_412.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_411, arg_414) }; if jrt.J2g_Truth(tmp56) { var c__1927000678__auto____24_2 any; var root_415 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any = seq_1716000046__23; if linked_416 == nil { c__1927000678__auto____24_2 = ifn_417.Invoke_O__O(arg_418) } else { c__1927000678__auto____24_2 = linked_416.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_415, arg_418) }; var tmp57 any; var root_532 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any = seq_1716000046__23; if linked_533 == nil { tmp57 = ifn_534.Invoke_O__O(arg_535) } else { tmp57 = linked_533.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_532, arg_535) }; seq_1716000046__18, chunk_1716000047__19, count_1716000048__20, i_1716000049__21 = tmp57, c__1927000678__auto____24_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var vec__1716000053__24 any; var root_419 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_419, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_421 lang.IFn; if linked_420 == nil { ifn_421 = lang.IFn_Cast(root_419) } else { ifn_421 = nil }; var arg_422 any = seq_1716000046__23; if linked_420 == nil { vec__1716000053__24 = ifn_421.Invoke_O__O(arg_422) } else { vec__1716000053__24 = linked_420.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_419, arg_422) }; var tg__25 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000053__24, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp58 any; var root_536 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_536, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_538 lang.IFn; if linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var arg_539 any = tg__25; if linked_537 == nil { tmp58 = ifn_538.Invoke_O__O(arg_539) } else { tmp58 = linked_537.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_536, arg_539) }; if jrt.J2g_Truth(tmp58) { var tmp59 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp60 any; var root_540 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_541 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_540, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_542 lang.IFn; if linked_541 == nil { ifn_542 = lang.IFn_Cast(root_540) } else { ifn_542 = nil }; var arg_543 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_544 any = A_arbace_j2g_jrt_A_const_44; var arg_545 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_546 any; var root_547 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any = tg__25; if linked_548 == nil { arg_546 = ifn_549.Invoke_O__O(arg_550) } else { arg_546 = linked_548.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_547, arg_550) }; if linked_541 == nil { tmp60 = ifn_542.Invoke_O_O_O_O__O(arg_543, arg_544, arg_545, arg_546) } else { tmp60 = linked_541.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_540, arg_543, arg_544, arg_545, arg_546) }; jrt.NN(tmp59).Reset_O__O(tmp60) }; var tmp61 any; var root_551 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_551, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_553 lang.IFn; if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any = seq_1716000046__23; if linked_552 == nil { tmp61 = ifn_553.Invoke_O__O(arg_554) } else { tmp61 = linked_552.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_551, arg_554) }; seq_1716000046__18, chunk_1716000047__19, count_1716000048__20, i_1716000049__21 = tmp61, nil, 0, 0; continue L4 } } }
//line :97:1
								break L4 } } else {

									var tmp62 any; var root_423 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_423, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_425 lang.IFn; if linked_424 == nil { ifn_425 = lang.IFn_Cast(root_423) } else { ifn_425 = nil }; var arg_426 any; var root_427 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_427, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_429 lang.IFn; if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any = more__17_2; if linked_428 == nil { arg_426 = ifn_429.Invoke_O__O(arg_430) } else { arg_426 = linked_428.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_427, arg_430) }; if linked_424 == nil { tmp62 = ifn_425.Invoke_O__O(arg_426) } else { tmp62 = linked_424.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_423, arg_426) }; if jrt.J2g_Truth(tmp62) { var tmp63 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp64 any; var root_431 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_432 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_431, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_433 lang.IFn; if linked_432 == nil { ifn_433 = lang.IFn_Cast(root_431) } else { ifn_433 = nil }; var arg_434 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_435 any = A_arbace_j2g_jrt_A_const_44; var arg_436 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_437 any; var root_438 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any; var root_442 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_444 lang.IFn; if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = more__17_2; if linked_443 == nil { arg_441 = ifn_444.Invoke_O__O(arg_445) } else { arg_441 = linked_443.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_442, arg_445) }; if linked_439 == nil { arg_437 = ifn_440.Invoke_O__O(arg_441) } else { arg_437 = linked_439.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_438, arg_441) }; if linked_432 == nil { tmp64 = ifn_433.Invoke_O_O_O_O__O(arg_434, arg_435, arg_436, arg_437) } else { tmp64 = linked_432.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_431, arg_434, arg_435, arg_436, arg_437) }; jrt.NN(tmp63).Reset_O__O(tmp64) } }
//line :54:1
						break L2 }; case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000026__10_, Lit_34) { var vec__1716000056__11 any = fm__8; var ___12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000056__11, lang.RT_IntCast_J__I_NoInit(0), nil); var nm__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000056__11, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp65 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp66 any; var root_446 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_448 lang.IFn; _ = ___12
























							if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_450 any = A_arbace_j2g_jrt_A_const_41; var arg_451 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_452 any; var root_453 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_453, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_455 lang.IFn; if linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any = nm__13; if linked_454 == nil { arg_452 = ifn_455.Invoke_O__O(arg_456) } else { arg_452 = linked_454.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_453, arg_456) }; if linked_447 == nil { tmp66 = ifn_448.Invoke_O_O_O_O__O(arg_449, arg_450, arg_451, arg_452) } else { tmp66 = linked_447.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_446, arg_449, arg_450, arg_451, arg_452) }; jrt.NN(tmp65).Reset_O__O(tmp66)
//line :54:1
							break L2 }; case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000026__10_, Lit_35) { var vec__1716000059__11 any = fm__8; var seq__1716000060__12 any; var root_555 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_555, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_557 lang.IFn

























								if linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any = vec__1716000059__11; if linked_556 == nil { seq__1716000060__12 = ifn_557.Invoke_O__O(arg_558) } else { seq__1716000060__12 = linked_556.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_555, arg_558) }
//line :54:1
								var first__1716000061__13 any; var root_559 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_559, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_561 lang.IFn

























								if linked_560 == nil { ifn_561 = lang.IFn_Cast(root_559) } else { ifn_561 = nil }; var arg_562 any = seq__1716000060__12; if linked_560 == nil { first__1716000061__13 = ifn_561.Invoke_O__O(arg_562) } else { first__1716000061__13 = linked_560.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_559, arg_562) }
//line :54:1
								var seq__1716000060__14 any; var root_563 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_565 lang.IFn

























								if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = seq__1716000060__12; if linked_564 == nil { seq__1716000060__14 = ifn_565.Invoke_O__O(arg_566) } else { seq__1716000060__14 = linked_564.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_563, arg_566) }
//line :54:1
								var ___15_4 any = first__1716000061__13; var more__16_3 any = seq__1716000060__14; var more__17_3 any; var root_567 any = A_arbace_j2g_jrt_A_const_50.GetRawRoot__O(); var linked_568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_567, A_arbace_j2g_jrt_strip_doc_A_fn_class); var ifn_569 lang.IFn; _ = ___15_4


























								if linked_568 == nil { ifn_569 = lang.IFn_Cast(root_567) } else { ifn_569 = nil }; var arg_570 any = more__16_3; if linked_568 == nil { more__17_3 = ifn_569.Invoke_O__O(arg_570) } else { more__17_3 = linked_568.(*A_arbace_j2g_jrt_strip_doc_A).Invoke_O_O__O(root_567, arg_570) }
								var tmp67 any; var root_571 any = A_arbace_j2g_jrt_A_const_55.GetRawRoot__O(); var linked_572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_571, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_573 lang.IFn; if linked_572 == nil { ifn_573 = lang.IFn_Cast(root_571) } else { ifn_573 = nil }; var arg_574 any; var root_575 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_577 lang.IFn; if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any = more__17_3; if linked_576 == nil { arg_574 = ifn_577.Invoke_O__O(arg_578) } else { arg_574 = linked_576.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_575, arg_578) }; if linked_572 == nil { tmp67 = ifn_573.Invoke_O__O(arg_574) } else { tmp67 = linked_572.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_571, arg_574) }; if jrt.J2g_Truth(tmp67) { var seq_1716000062__18 any; var root_579 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_579, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_581 lang.IFn
									if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = more__17_3; if linked_580 == nil { seq_1716000062__18 = ifn_581.Invoke_O__O(arg_582) } else { seq_1716000062__18 = linked_580.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_579, arg_582) }
//line :82:1
									var chunk_1716000063__19 any; var count_1716000064__20 int64 = 0; var i_1716000065__21 int64 = 0; L5: for {
										if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000065__21, count_1716000064__20) { var vec__1716000066__22 any = lang.Indexed_Cast(chunk_1716000063__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000065__21)); var tg__23_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000066__22, lang.RT_IntCast_J__I_NoInit(0), nil); var init__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000066__22, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp68 any; var and__1927000168__auto____25_3 any; var root_661 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_663 lang.IFn
											if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = tg__23_2; if linked_662 == nil { and__1927000168__auto____25_3 = ifn_663.Invoke_O__O(arg_664) } else { and__1927000168__auto____25_3 = linked_662.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_661, arg_664) }; if jrt.J2g_Truth(and__1927000168__auto____25_3) { var tmp69 any = A_arbace_j2g_jrt_A_const_71; var tmp70 any; var root_665 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = tg__23_2; if linked_666 == nil { tmp70 = ifn_667.Invoke_O__O(arg_668) } else { tmp70 = linked_666.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_665, arg_668) }; tmp68 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp69, tmp70)).Ref() } else { tmp68 = and__1927000168__auto____25_3 }; if jrt.J2g_Truth(tmp68) { var seq_1716000069__25 any; var root_669 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_671 lang.IFn
												if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any; var root_673 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_673, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_675 lang.IFn; if linked_674 == nil { ifn_675 = lang.IFn_Cast(root_673) } else { ifn_675 = nil }; var arg_676 any = tg__23_2; if linked_674 == nil { arg_672 = ifn_675.Invoke_O__O(arg_676) } else { arg_672 = linked_674.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_673, arg_676) }; if linked_670 == nil { seq_1716000069__25 = ifn_671.Invoke_O__O(arg_672) } else { seq_1716000069__25 = linked_670.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_669, arg_672) }
//line :84:1
												var chunk_1716000070__26 any; var count_1716000071__27 int64 = 0; var i_1716000072__28 int64 = 0; L6: for {
													if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000072__28, count_1716000071__27) { var s__29 any = lang.Indexed_Cast(chunk_1716000070__26).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000072__28)); var tmp71 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp72 any; var root_723 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_724 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_723, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_725 lang.IFn; if linked_724 == nil { ifn_725 = lang.IFn_Cast(root_723) } else { ifn_725 = nil }; var arg_726 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_727 any = A_arbace_j2g_jrt_A_const_42; var arg_728 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_729 any; var root_730 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_730, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_732 lang.IFn; if linked_731 == nil { ifn_732 = lang.IFn_Cast(root_730) } else { ifn_732 = nil }; var arg_733 any = s__29; if linked_731 == nil { arg_729 = ifn_732.Invoke_O__O(arg_733) } else { arg_729 = linked_731.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_730, arg_733) }; if linked_724 == nil { tmp72 = ifn_725.Invoke_O_O_O_O__O(arg_726, arg_727, arg_728, arg_729) } else { tmp72 = linked_724.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_723, arg_726, arg_727, arg_728, arg_729) }; jrt.NN(tmp71).Reset_O__O(tmp72); seq_1716000069__25, chunk_1716000070__26, count_1716000071__27, i_1716000072__28 = seq_1716000069__25, chunk_1716000070__26, count_1716000071__27, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000072__28); continue L6 } else { var temp__1927000414__auto____29 any; var root_677 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_677, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_679 lang.IFn; if linked_678 == nil { ifn_679 = lang.IFn_Cast(root_677) } else { ifn_679 = nil }; var arg_680 any = seq_1716000069__25; if linked_678 == nil { temp__1927000414__auto____29 = ifn_679.Invoke_O__O(arg_680) } else { temp__1927000414__auto____29 = linked_678.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_677, arg_680) }; if jrt.J2g_Truth(temp__1927000414__auto____29) { var seq_1716000069__30 any = temp__1927000414__auto____29; var tmp73 any; var root_681 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_681, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_683 lang.IFn; if linked_682 == nil { ifn_683 = lang.IFn_Cast(root_681) } else { ifn_683 = nil }; var arg_684 any = seq_1716000069__30; if linked_682 == nil { tmp73 = ifn_683.Invoke_O__O(arg_684) } else { tmp73 = linked_682.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_681, arg_684) }; if jrt.J2g_Truth(tmp73) { var c__1927000678__auto____31 any; var root_685 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_685, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_687 lang.IFn; if linked_686 == nil { ifn_687 = lang.IFn_Cast(root_685) } else { ifn_687 = nil }; var arg_688 any = seq_1716000069__30; if linked_686 == nil { c__1927000678__auto____31 = ifn_687.Invoke_O__O(arg_688) } else { c__1927000678__auto____31 = linked_686.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_685, arg_688) }; var tmp74 any; var root_734 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_734, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_736 lang.IFn; if linked_735 == nil { ifn_736 = lang.IFn_Cast(root_734) } else { ifn_736 = nil }; var arg_737 any = seq_1716000069__30; if linked_735 == nil { tmp74 = ifn_736.Invoke_O__O(arg_737) } else { tmp74 = linked_735.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_734, arg_737) }; seq_1716000069__25, chunk_1716000070__26, count_1716000071__27, i_1716000072__28 = tmp74, c__1927000678__auto____31, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____31))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L6 } else { var s__31 any; var root_689 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_689, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_691 lang.IFn; if linked_690 == nil { ifn_691 = lang.IFn_Cast(root_689) } else { ifn_691 = nil }; var arg_692 any = seq_1716000069__30; if linked_690 == nil { s__31 = ifn_691.Invoke_O__O(arg_692) } else { s__31 = linked_690.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_689, arg_692) }; var tmp75 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp76 any; var root_738 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_739 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_738, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_740 lang.IFn; if linked_739 == nil { ifn_740 = lang.IFn_Cast(root_738) } else { ifn_740 = nil }; var arg_741 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_742 any = A_arbace_j2g_jrt_A_const_42; var arg_743 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_744 any; var root_745 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_745, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_747 lang.IFn; if linked_746 == nil { ifn_747 = lang.IFn_Cast(root_745) } else { ifn_747 = nil }; var arg_748 any = s__31; if linked_746 == nil { arg_744 = ifn_747.Invoke_O__O(arg_748) } else { arg_744 = linked_746.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_745, arg_748) }; if linked_739 == nil { tmp76 = ifn_740.Invoke_O_O_O_O__O(arg_741, arg_742, arg_743, arg_744) } else { tmp76 = linked_739.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_738, arg_741, arg_742, arg_743, arg_744) }; jrt.NN(tmp75).Reset_O__O(tmp76); var tmp77 any; var root_749 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_749, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_751 lang.IFn; if linked_750 == nil { ifn_751 = lang.IFn_Cast(root_749) } else { ifn_751 = nil }; var arg_752 any = seq_1716000069__30; if linked_750 == nil { tmp77 = ifn_751.Invoke_O__O(arg_752) } else { tmp77 = linked_750.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_749, arg_752) }; seq_1716000069__25, chunk_1716000070__26, count_1716000071__27, i_1716000072__28 = tmp77, nil, 0, 0; continue L6 } } }
//line :84:1
													break L6 } } else {

														var tmp78 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp79 any; var root_753 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_754 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_753, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_755 lang.IFn; if linked_754 == nil { ifn_755 = lang.IFn_Cast(root_753) } else { ifn_755 = nil }; var arg_756 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_757 any = A_arbace_j2g_jrt_A_const_42; var arg_758 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_759 any; var root_760 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_762 lang.IFn; if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any = tg__23_2; if linked_761 == nil { arg_759 = ifn_762.Invoke_O__O(arg_763) } else { arg_759 = linked_761.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_760, arg_763) }; if linked_754 == nil { tmp79 = ifn_755.Invoke_O_O_O_O__O(arg_756, arg_757, arg_758, arg_759) } else { tmp79 = linked_754.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_753, arg_756, arg_757, arg_758, arg_759) }; jrt.NN(tmp78).Reset_O__O(tmp79)
//line :84:1
														var temp__1927000414__auto____25 any; var root_693 any = A_arbace_j2g_jrt_A_const_69.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_693, A_arbace_j2g_jrt_define_name_A_fn_class); var ifn_695 lang.IFn


														if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any = init__24; if linked_694 == nil { temp__1927000414__auto____25 = ifn_695.Invoke_O__O(arg_696) } else { temp__1927000414__auto____25 = linked_694.(*A_arbace_j2g_jrt_define_name_A).Invoke_O_O__O(root_693, arg_696) }; if jrt.J2g_Truth(temp__1927000414__auto____25) { var map__1716000073__26 any = temp__1927000414__auto____25; var map__1716000073__27 any; if lang.ISeq_InstanceOf(map__1716000073__26) { var tmp80 any; var root_697 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_697, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_699 lang.IFn; if linked_698 == nil { ifn_699 = lang.IFn_Cast(root_697) } else { ifn_699 = nil }; var arg_700 any = map__1716000073__26; if linked_698 == nil { tmp80 = ifn_699.Invoke_O__O(arg_700) } else { tmp80 = linked_698.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_697, arg_700) }; if jrt.J2g_Truth(tmp80) { var tmp81 any; var root_701 any = A_arbace_j2g_jrt_A_const_70.GetRawRoot__O(); var linked_702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_701, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_703 lang.IFn; if linked_702 == nil { ifn_703 = lang.IFn_Cast(root_701) } else { ifn_703 = nil }; var arg_704 any = map__1716000073__26; if linked_702 == nil { tmp81 = ifn_703.Invoke_O__O(arg_704) } else { tmp81 = linked_702.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_701, arg_704) }; map__1716000073__27 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp81)).Ref() } else { var tmp82 any; var root_705 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_705, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_707 lang.IFn; if linked_706 == nil { ifn_707 = lang.IFn_Cast(root_705) } else { ifn_707 = nil }; var arg_708 any = map__1716000073__26; if linked_706 == nil { tmp82 = ifn_707.Invoke_O__O(arg_708) } else { tmp82 = linked_706.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_705, arg_708) }; if jrt.J2g_Truth(tmp82) { var root_709 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_709, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_711 lang.IFn; if linked_710 == nil { ifn_711 = lang.IFn_Cast(root_709) } else { ifn_711 = nil }; var arg_712 any = map__1716000073__26; if linked_710 == nil { map__1716000073__27 = ifn_711.Invoke_O__O(arg_712) } else { map__1716000073__27 = linked_710.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_709, arg_712) } } else { map__1716000073__27 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000073__27 = map__1716000073__26 }; var n__28 any = lang.RT_Get_O_O__O_NoInit(map__1716000073__27, A_arbace_j2g_jrt_A_const_34); var tmp83 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp84 any; var root_713 any = A_arbace_j2g_jrt_A_const_56.GetRawRoot__O(); var linked_714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_713, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_715 lang.IFn
															if linked_714 == nil { ifn_715 = lang.IFn_Cast(root_713) } else { ifn_715 = nil }; var arg_716 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_717 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_jrt_A_const_43, n__28); var arg_718 any; var root_719 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_721 lang.IFn; if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = tg__23_2; if linked_720 == nil { arg_718 = ifn_721.Invoke_O__O(arg_722) } else { arg_718 = linked_720.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_719, arg_722) }; if linked_714 == nil { tmp84 = ifn_715.Invoke_O_O_O__O(arg_716, arg_717, arg_718) } else { tmp84 = linked_714.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_713, arg_716, arg_717, arg_718) }; jrt.NN(tmp83).Reset_O__O(tmp84) } }
//line :83:1
											seq_1716000062__18, chunk_1716000063__19, count_1716000064__20, i_1716000065__21 = seq_1716000062__18, chunk_1716000063__19, count_1716000064__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000065__21); continue L5 } else { var temp__1927000414__auto____22_3 any; var root_583 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_585 lang.IFn; if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any = seq_1716000062__18; if linked_584 == nil { temp__1927000414__auto____22_3 = ifn_585.Invoke_O__O(arg_586) } else { temp__1927000414__auto____22_3 = linked_584.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_583, arg_586) }; if jrt.J2g_Truth(temp__1927000414__auto____22_3) { var seq_1716000062__23 any = temp__1927000414__auto____22_3; var tmp85 any; var root_587 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_587, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_589 lang.IFn; if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any = seq_1716000062__23; if linked_588 == nil { tmp85 = ifn_589.Invoke_O__O(arg_590) } else { tmp85 = linked_588.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_587, arg_590) }; if jrt.J2g_Truth(tmp85) { var c__1927000678__auto____24_3 any; var root_591 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_591, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_593 lang.IFn; if linked_592 == nil { ifn_593 = lang.IFn_Cast(root_591) } else { ifn_593 = nil }; var arg_594 any = seq_1716000062__23; if linked_592 == nil { c__1927000678__auto____24_3 = ifn_593.Invoke_O__O(arg_594) } else { c__1927000678__auto____24_3 = linked_592.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_591, arg_594) }; var tmp86 any; var root_764 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_764, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_766 lang.IFn; if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any = seq_1716000062__23; if linked_765 == nil { tmp86 = ifn_766.Invoke_O__O(arg_767) } else { tmp86 = linked_765.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_764, arg_767) }; seq_1716000062__18, chunk_1716000063__19, count_1716000064__20, i_1716000065__21 = tmp86, c__1927000678__auto____24_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var vec__1716000075__24 any; var root_595 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_595, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_597 lang.IFn; if linked_596 == nil { ifn_597 = lang.IFn_Cast(root_595) } else { ifn_597 = nil }; var arg_598 any = seq_1716000062__23; if linked_596 == nil { vec__1716000075__24 = ifn_597.Invoke_O__O(arg_598) } else { vec__1716000075__24 = linked_596.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_595, arg_598) }; var tg__25_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000075__24, lang.RT_IntCast_J__I_NoInit(0), nil); var init__26 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000075__24, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp87 any; var and__1927000168__auto____27_3 any; var root_768 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_768, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_770 lang.IFn
												if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any = tg__25_2; if linked_769 == nil { and__1927000168__auto____27_3 = ifn_770.Invoke_O__O(arg_771) } else { and__1927000168__auto____27_3 = linked_769.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_768, arg_771) }; if jrt.J2g_Truth(and__1927000168__auto____27_3) { var tmp88 any = A_arbace_j2g_jrt_A_const_71; var tmp89 any; var root_772 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_772, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_774 lang.IFn; if linked_773 == nil { ifn_774 = lang.IFn_Cast(root_772) } else { ifn_774 = nil }; var arg_775 any = tg__25_2; if linked_773 == nil { tmp89 = ifn_774.Invoke_O__O(arg_775) } else { tmp89 = linked_773.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_772, arg_775) }; tmp87 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp88, tmp89)).Ref() } else { tmp87 = and__1927000168__auto____27_3 }; if jrt.J2g_Truth(tmp87) { var seq_1716000078__27 any; var root_776 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_776, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_778 lang.IFn
													if linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var arg_779 any; var root_780 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_780, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_782 lang.IFn; if linked_781 == nil { ifn_782 = lang.IFn_Cast(root_780) } else { ifn_782 = nil }; var arg_783 any = tg__25_2; if linked_781 == nil { arg_779 = ifn_782.Invoke_O__O(arg_783) } else { arg_779 = linked_781.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_780, arg_783) }; if linked_777 == nil { seq_1716000078__27 = ifn_778.Invoke_O__O(arg_779) } else { seq_1716000078__27 = linked_777.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_776, arg_779) }
//line :84:1
													var chunk_1716000079__28 any; var count_1716000080__29 int64 = 0; var i_1716000081__30 int64 = 0; L7: for {
														if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000081__30, count_1716000080__29) { var s__31_2 any = lang.Indexed_Cast(chunk_1716000079__28).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000081__30)); var tmp90 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp91 any; var root_830 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_831 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_830, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_832 lang.IFn; if linked_831 == nil { ifn_832 = lang.IFn_Cast(root_830) } else { ifn_832 = nil }; var arg_833 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_834 any = A_arbace_j2g_jrt_A_const_42; var arg_835 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_836 any; var root_837 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_837, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_839 lang.IFn; if linked_838 == nil { ifn_839 = lang.IFn_Cast(root_837) } else { ifn_839 = nil }; var arg_840 any = s__31_2; if linked_838 == nil { arg_836 = ifn_839.Invoke_O__O(arg_840) } else { arg_836 = linked_838.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_837, arg_840) }; if linked_831 == nil { tmp91 = ifn_832.Invoke_O_O_O_O__O(arg_833, arg_834, arg_835, arg_836) } else { tmp91 = linked_831.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_830, arg_833, arg_834, arg_835, arg_836) }; jrt.NN(tmp90).Reset_O__O(tmp91); seq_1716000078__27, chunk_1716000079__28, count_1716000080__29, i_1716000081__30 = seq_1716000078__27, chunk_1716000079__28, count_1716000080__29, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000081__30); continue L7 } else { var temp__1927000414__auto____31 any; var root_784 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_784, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_786 lang.IFn; if linked_785 == nil { ifn_786 = lang.IFn_Cast(root_784) } else { ifn_786 = nil }; var arg_787 any = seq_1716000078__27; if linked_785 == nil { temp__1927000414__auto____31 = ifn_786.Invoke_O__O(arg_787) } else { temp__1927000414__auto____31 = linked_785.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_784, arg_787) }; if jrt.J2g_Truth(temp__1927000414__auto____31) { var seq_1716000078__32 any = temp__1927000414__auto____31; var tmp92 any; var root_788 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_788, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_790 lang.IFn; if linked_789 == nil { ifn_790 = lang.IFn_Cast(root_788) } else { ifn_790 = nil }; var arg_791 any = seq_1716000078__32; if linked_789 == nil { tmp92 = ifn_790.Invoke_O__O(arg_791) } else { tmp92 = linked_789.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_788, arg_791) }; if jrt.J2g_Truth(tmp92) { var c__1927000678__auto____33 any; var root_792 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_792, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_794 lang.IFn; if linked_793 == nil { ifn_794 = lang.IFn_Cast(root_792) } else { ifn_794 = nil }; var arg_795 any = seq_1716000078__32; if linked_793 == nil { c__1927000678__auto____33 = ifn_794.Invoke_O__O(arg_795) } else { c__1927000678__auto____33 = linked_793.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_792, arg_795) }; var tmp93 any; var root_841 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_841, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_843 lang.IFn; if linked_842 == nil { ifn_843 = lang.IFn_Cast(root_841) } else { ifn_843 = nil }; var arg_844 any = seq_1716000078__32; if linked_842 == nil { tmp93 = ifn_843.Invoke_O__O(arg_844) } else { tmp93 = linked_842.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_841, arg_844) }; seq_1716000078__27, chunk_1716000079__28, count_1716000080__29, i_1716000081__30 = tmp93, c__1927000678__auto____33, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____33))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L7 } else { var s__33 any; var root_796 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_796, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_798 lang.IFn; if linked_797 == nil { ifn_798 = lang.IFn_Cast(root_796) } else { ifn_798 = nil }; var arg_799 any = seq_1716000078__32; if linked_797 == nil { s__33 = ifn_798.Invoke_O__O(arg_799) } else { s__33 = linked_797.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_796, arg_799) }; var tmp94 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp95 any; var root_845 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_846 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_845, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_847 lang.IFn; if linked_846 == nil { ifn_847 = lang.IFn_Cast(root_845) } else { ifn_847 = nil }; var arg_848 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_849 any = A_arbace_j2g_jrt_A_const_42; var arg_850 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_851 any; var root_852 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_854 lang.IFn; if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any = s__33; if linked_853 == nil { arg_851 = ifn_854.Invoke_O__O(arg_855) } else { arg_851 = linked_853.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_852, arg_855) }; if linked_846 == nil { tmp95 = ifn_847.Invoke_O_O_O_O__O(arg_848, arg_849, arg_850, arg_851) } else { tmp95 = linked_846.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_845, arg_848, arg_849, arg_850, arg_851) }; jrt.NN(tmp94).Reset_O__O(tmp95); var tmp96 any; var root_856 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_856, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_858 lang.IFn; if linked_857 == nil { ifn_858 = lang.IFn_Cast(root_856) } else { ifn_858 = nil }; var arg_859 any = seq_1716000078__32; if linked_857 == nil { tmp96 = ifn_858.Invoke_O__O(arg_859) } else { tmp96 = linked_857.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_856, arg_859) }; seq_1716000078__27, chunk_1716000079__28, count_1716000080__29, i_1716000081__30 = tmp96, nil, 0, 0; continue L7 } } }
//line :84:1
														break L7 } } else {

															var tmp97 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp98 any; var root_860 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_860, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_862 lang.IFn; if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_864 any = A_arbace_j2g_jrt_A_const_42; var arg_865 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_866 any; var root_867 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_867, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_869 lang.IFn; if linked_868 == nil { ifn_869 = lang.IFn_Cast(root_867) } else { ifn_869 = nil }; var arg_870 any = tg__25_2; if linked_868 == nil { arg_866 = ifn_869.Invoke_O__O(arg_870) } else { arg_866 = linked_868.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_867, arg_870) }; if linked_861 == nil { tmp98 = ifn_862.Invoke_O_O_O_O__O(arg_863, arg_864, arg_865, arg_866) } else { tmp98 = linked_861.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_860, arg_863, arg_864, arg_865, arg_866) }; jrt.NN(tmp97).Reset_O__O(tmp98)
//line :84:1
															var temp__1927000414__auto____27 any; var root_800 any = A_arbace_j2g_jrt_A_const_69.GetRawRoot__O(); var linked_801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_800, A_arbace_j2g_jrt_define_name_A_fn_class); var ifn_802 lang.IFn


															if linked_801 == nil { ifn_802 = lang.IFn_Cast(root_800) } else { ifn_802 = nil }; var arg_803 any = init__26; if linked_801 == nil { temp__1927000414__auto____27 = ifn_802.Invoke_O__O(arg_803) } else { temp__1927000414__auto____27 = linked_801.(*A_arbace_j2g_jrt_define_name_A).Invoke_O_O__O(root_800, arg_803) }; if jrt.J2g_Truth(temp__1927000414__auto____27) { var map__1716000082__28 any = temp__1927000414__auto____27; var map__1716000082__29 any; if lang.ISeq_InstanceOf(map__1716000082__28) { var tmp99 any; var root_804 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_804, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_806 lang.IFn; if linked_805 == nil { ifn_806 = lang.IFn_Cast(root_804) } else { ifn_806 = nil }; var arg_807 any = map__1716000082__28; if linked_805 == nil { tmp99 = ifn_806.Invoke_O__O(arg_807) } else { tmp99 = linked_805.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_804, arg_807) }; if jrt.J2g_Truth(tmp99) { var tmp100 any; var root_808 any = A_arbace_j2g_jrt_A_const_70.GetRawRoot__O(); var linked_809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_808, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_810 lang.IFn; if linked_809 == nil { ifn_810 = lang.IFn_Cast(root_808) } else { ifn_810 = nil }; var arg_811 any = map__1716000082__28; if linked_809 == nil { tmp100 = ifn_810.Invoke_O__O(arg_811) } else { tmp100 = linked_809.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_808, arg_811) }; map__1716000082__29 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp100)).Ref() } else { var tmp101 any; var root_812 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_814 lang.IFn; if linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; var arg_815 any = map__1716000082__28; if linked_813 == nil { tmp101 = ifn_814.Invoke_O__O(arg_815) } else { tmp101 = linked_813.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_812, arg_815) }; if jrt.J2g_Truth(tmp101) { var root_816 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_818 lang.IFn; if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any = map__1716000082__28; if linked_817 == nil { map__1716000082__29 = ifn_818.Invoke_O__O(arg_819) } else { map__1716000082__29 = linked_817.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_816, arg_819) } } else { map__1716000082__29 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000082__29 = map__1716000082__28 }; var n__30 any = lang.RT_Get_O_O__O_NoInit(map__1716000082__29, A_arbace_j2g_jrt_A_const_34); var tmp102 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp103 any; var root_820 any = A_arbace_j2g_jrt_A_const_56.GetRawRoot__O(); var linked_821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_820, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_822 lang.IFn
																if linked_821 == nil { ifn_822 = lang.IFn_Cast(root_820) } else { ifn_822 = nil }; var arg_823 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_824 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_jrt_A_const_43, n__30); var arg_825 any; var root_826 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_826, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_828 lang.IFn; if linked_827 == nil { ifn_828 = lang.IFn_Cast(root_826) } else { ifn_828 = nil }; var arg_829 any = tg__25_2; if linked_827 == nil { arg_825 = ifn_828.Invoke_O__O(arg_829) } else { arg_825 = linked_827.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_826, arg_829) }; if linked_821 == nil { tmp103 = ifn_822.Invoke_O_O_O__O(arg_823, arg_824, arg_825) } else { tmp103 = linked_821.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_820, arg_823, arg_824, arg_825) }; jrt.NN(tmp102).Reset_O__O(tmp103) } }
//line :83:1
												var tmp104 any; var root_871 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_871, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_873 lang.IFn; if linked_872 == nil { ifn_873 = lang.IFn_Cast(root_871) } else { ifn_873 = nil }; var arg_874 any = seq_1716000062__23; if linked_872 == nil { tmp104 = ifn_873.Invoke_O__O(arg_874) } else { tmp104 = linked_872.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_871, arg_874) }; seq_1716000062__18, chunk_1716000063__19, count_1716000064__20, i_1716000065__21 = tmp104, nil, 0, 0; continue L5 } } }
//line :82:1
										break L5 } } else { var vec__1716000084__18 any = more__17_3; var tg__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000084__18, lang.RT_IntCast_J__I_NoInit(0), nil); var init__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000084__18, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp105 any; var and__1927000168__auto____21 any; var root_599 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_599, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_601 lang.IFn







											if linked_600 == nil { ifn_601 = lang.IFn_Cast(root_599) } else { ifn_601 = nil }; var arg_602 any = tg__19; if linked_600 == nil { and__1927000168__auto____21 = ifn_601.Invoke_O__O(arg_602) } else { and__1927000168__auto____21 = linked_600.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_599, arg_602) }; if jrt.J2g_Truth(and__1927000168__auto____21) { var tmp106 any = A_arbace_j2g_jrt_A_const_68; var tmp107 any; var root_603 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_605 lang.IFn; if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any = tg__19; if linked_604 == nil { tmp107 = ifn_605.Invoke_O__O(arg_606) } else { tmp107 = linked_604.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_603, arg_606) }; tmp105 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp106, tmp107)).Ref() } else { tmp105 = and__1927000168__auto____21 }; if jrt.J2g_Truth(tmp105) { var seq_1716000087__21 any; var root_607 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_607, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_609 lang.IFn
												if linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_610 any; var root_611 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_613 lang.IFn; if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = tg__19; if linked_612 == nil { arg_610 = ifn_613.Invoke_O__O(arg_614) } else { arg_610 = linked_612.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_611, arg_614) }; if linked_608 == nil { seq_1716000087__21 = ifn_609.Invoke_O__O(arg_610) } else { seq_1716000087__21 = linked_608.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_607, arg_610) }
//line :90:1
												var chunk_1716000088__22 any; var count_1716000089__23 int64 = 0; var i_1716000090__24 int64 = 0; L8: for {
													if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000090__24, count_1716000089__23) { var s__25 any = lang.Indexed_Cast(chunk_1716000088__22).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000090__24)); var tmp108 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp109 any; var root_875 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_875, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_877 lang.IFn; if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_879 any = A_arbace_j2g_jrt_A_const_42; var arg_880 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_881 any; var root_882 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_882, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_884 lang.IFn; if linked_883 == nil { ifn_884 = lang.IFn_Cast(root_882) } else { ifn_884 = nil }; var arg_885 any = s__25; if linked_883 == nil { arg_881 = ifn_884.Invoke_O__O(arg_885) } else { arg_881 = linked_883.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_882, arg_885) }; if linked_876 == nil { tmp109 = ifn_877.Invoke_O_O_O_O__O(arg_878, arg_879, arg_880, arg_881) } else { tmp109 = linked_876.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_875, arg_878, arg_879, arg_880, arg_881) }; jrt.NN(tmp108).Reset_O__O(tmp109); seq_1716000087__21, chunk_1716000088__22, count_1716000089__23, i_1716000090__24 = seq_1716000087__21, chunk_1716000088__22, count_1716000089__23, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000090__24); continue L8 } else { var temp__1927000414__auto____25_2 any; var root_615 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = seq_1716000087__21; if linked_616 == nil { temp__1927000414__auto____25_2 = ifn_617.Invoke_O__O(arg_618) } else { temp__1927000414__auto____25_2 = linked_616.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_615, arg_618) }; if jrt.J2g_Truth(temp__1927000414__auto____25_2) { var seq_1716000087__26 any = temp__1927000414__auto____25_2; var tmp110 any; var root_619 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = seq_1716000087__26; if linked_620 == nil { tmp110 = ifn_621.Invoke_O__O(arg_622) } else { tmp110 = linked_620.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_619, arg_622) }; if jrt.J2g_Truth(tmp110) { var c__1927000678__auto____27 any; var root_623 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_623, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_625 lang.IFn; if linked_624 == nil { ifn_625 = lang.IFn_Cast(root_623) } else { ifn_625 = nil }; var arg_626 any = seq_1716000087__26; if linked_624 == nil { c__1927000678__auto____27 = ifn_625.Invoke_O__O(arg_626) } else { c__1927000678__auto____27 = linked_624.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_623, arg_626) }; var tmp111 any; var root_886 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_886, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_888 lang.IFn; if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any = seq_1716000087__26; if linked_887 == nil { tmp111 = ifn_888.Invoke_O__O(arg_889) } else { tmp111 = linked_887.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_886, arg_889) }; seq_1716000087__21, chunk_1716000088__22, count_1716000089__23, i_1716000090__24 = tmp111, c__1927000678__auto____27, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____27))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L8 } else { var s__27 any; var root_627 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_627, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_629 lang.IFn; if linked_628 == nil { ifn_629 = lang.IFn_Cast(root_627) } else { ifn_629 = nil }; var arg_630 any = seq_1716000087__26; if linked_628 == nil { s__27 = ifn_629.Invoke_O__O(arg_630) } else { s__27 = linked_628.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_627, arg_630) }; var tmp112 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp113 any; var root_890 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_891 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_890, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_892 lang.IFn; if linked_891 == nil { ifn_892 = lang.IFn_Cast(root_890) } else { ifn_892 = nil }; var arg_893 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_894 any = A_arbace_j2g_jrt_A_const_42; var arg_895 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_896 any; var root_897 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_897, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_899 lang.IFn; if linked_898 == nil { ifn_899 = lang.IFn_Cast(root_897) } else { ifn_899 = nil }; var arg_900 any = s__27; if linked_898 == nil { arg_896 = ifn_899.Invoke_O__O(arg_900) } else { arg_896 = linked_898.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_897, arg_900) }; if linked_891 == nil { tmp113 = ifn_892.Invoke_O_O_O_O__O(arg_893, arg_894, arg_895, arg_896) } else { tmp113 = linked_891.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_890, arg_893, arg_894, arg_895, arg_896) }; jrt.NN(tmp112).Reset_O__O(tmp113); var tmp114 any; var root_901 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_901, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_903 lang.IFn; if linked_902 == nil { ifn_903 = lang.IFn_Cast(root_901) } else { ifn_903 = nil }; var arg_904 any = seq_1716000087__26; if linked_902 == nil { tmp114 = ifn_903.Invoke_O__O(arg_904) } else { tmp114 = linked_902.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_901, arg_904) }; seq_1716000087__21, chunk_1716000088__22, count_1716000089__23, i_1716000090__24 = tmp114, nil, 0, 0; continue L8 } } }
//line :90:1
													break L8 } } else {

														var tmp115 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp116 any; var root_905 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_906 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_905, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_907 lang.IFn; if linked_906 == nil { ifn_907 = lang.IFn_Cast(root_905) } else { ifn_907 = nil }; var arg_908 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_909 any = A_arbace_j2g_jrt_A_const_42; var arg_910 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_911 any; var root_912 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_912, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_914 lang.IFn; if linked_913 == nil { ifn_914 = lang.IFn_Cast(root_912) } else { ifn_914 = nil }; var arg_915 any = tg__19; if linked_913 == nil { arg_911 = ifn_914.Invoke_O__O(arg_915) } else { arg_911 = linked_913.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_912, arg_915) }; if linked_906 == nil { tmp116 = ifn_907.Invoke_O_O_O_O__O(arg_908, arg_909, arg_910, arg_911) } else { tmp116 = linked_906.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_905, arg_908, arg_909, arg_910, arg_911) }; jrt.NN(tmp115).Reset_O__O(tmp116)
//line :90:1
														var temp__1927000414__auto____21 any; var root_631 any = A_arbace_j2g_jrt_A_const_69.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, A_arbace_j2g_jrt_define_name_A_fn_class); var ifn_633 lang.IFn


														if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = init__20; if linked_632 == nil { temp__1927000414__auto____21 = ifn_633.Invoke_O__O(arg_634) } else { temp__1927000414__auto____21 = linked_632.(*A_arbace_j2g_jrt_define_name_A).Invoke_O_O__O(root_631, arg_634) }; if jrt.J2g_Truth(temp__1927000414__auto____21) { var map__1716000091__22 any = temp__1927000414__auto____21; var map__1716000091__23 any; if lang.ISeq_InstanceOf(map__1716000091__22) { var tmp117 any; var root_635 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_635, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_637 lang.IFn; if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any = map__1716000091__22; if linked_636 == nil { tmp117 = ifn_637.Invoke_O__O(arg_638) } else { tmp117 = linked_636.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_635, arg_638) }; if jrt.J2g_Truth(tmp117) { var tmp118 any; var root_639 any = A_arbace_j2g_jrt_A_const_70.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_639, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_641 lang.IFn; if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any = map__1716000091__22; if linked_640 == nil { tmp118 = ifn_641.Invoke_O__O(arg_642) } else { tmp118 = linked_640.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_639, arg_642) }; map__1716000091__23 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp118)).Ref() } else { var tmp119 any; var root_643 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_643, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_645 lang.IFn; if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any = map__1716000091__22; if linked_644 == nil { tmp119 = ifn_645.Invoke_O__O(arg_646) } else { tmp119 = linked_644.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_643, arg_646) }; if jrt.J2g_Truth(tmp119) { var root_647 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_647, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_649 lang.IFn; if linked_648 == nil { ifn_649 = lang.IFn_Cast(root_647) } else { ifn_649 = nil }; var arg_650 any = map__1716000091__22; if linked_648 == nil { map__1716000091__23 = ifn_649.Invoke_O__O(arg_650) } else { map__1716000091__23 = linked_648.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_647, arg_650) } } else { map__1716000091__23 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000091__23 = map__1716000091__22 }; var n__24 any = lang.RT_Get_O_O__O_NoInit(map__1716000091__23, A_arbace_j2g_jrt_A_const_34); var tmp120 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp121 any; var root_651 any = A_arbace_j2g_jrt_A_const_56.GetRawRoot__O(); var linked_652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_651, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_653 lang.IFn
															if linked_652 == nil { ifn_653 = lang.IFn_Cast(root_651) } else { ifn_653 = nil }; var arg_654 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_655 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_jrt_A_const_43, n__24); var arg_656 any; var root_657 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_659 lang.IFn; if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = tg__19; if linked_658 == nil { arg_656 = ifn_659.Invoke_O__O(arg_660) } else { arg_656 = linked_658.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_657, arg_660) }; if linked_652 == nil { tmp121 = ifn_653.Invoke_O_O_O__O(arg_654, arg_655, arg_656) } else { tmp121 = linked_652.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_651, arg_654, arg_655, arg_656) }; jrt.NN(tmp120).Reset_O__O(tmp121) } } }
//line :54:1
								break L2 }; default:}}
//line :51:1
				seq_1716000022__4, chunk_1716000023__5, count_1716000024__6, i_1716000025__7 = seq_1716000022__4, chunk_1716000023__5, count_1716000024__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000025__7); continue L1 } else { seq_1716000022__4, chunk_1716000023__5, count_1716000024__6, i_1716000025__7 = seq_1716000022__4, chunk_1716000023__5, count_1716000024__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000025__7); continue L1 } } else { var temp__1927000414__auto____8 any; var root_202 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = seq_1716000022__4; if linked_203 == nil { temp__1927000414__auto____8 = ifn_204.Invoke_O__O(arg_205) } else { temp__1927000414__auto____8 = linked_203.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_202, arg_205) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1716000022__9 any = temp__1927000414__auto____8; var tmp122 any; var root_206 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = seq_1716000022__9; if linked_207 == nil { tmp122 = ifn_208.Invoke_O__O(arg_209) } else { tmp122 = linked_207.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_206, arg_209) }; if jrt.J2g_Truth(tmp122) { var c__1927000678__auto____10 any; var root_210 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_210, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_212 lang.IFn; if linked_211 == nil { ifn_212 = lang.IFn_Cast(root_210) } else { ifn_212 = nil }; var arg_213 any = seq_1716000022__9; if linked_211 == nil { c__1927000678__auto____10 = ifn_212.Invoke_O__O(arg_213) } else { c__1927000678__auto____10 = linked_211.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_210, arg_213) }; var tmp123 any; var root_916 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_916, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_918 lang.IFn; if linked_917 == nil { ifn_918 = lang.IFn_Cast(root_916) } else { ifn_918 = nil }; var arg_919 any = seq_1716000022__9; if linked_917 == nil { tmp123 = ifn_918.Invoke_O__O(arg_919) } else { tmp123 = linked_917.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_916, arg_919) }; seq_1716000022__4, chunk_1716000023__5, count_1716000024__6, i_1716000025__7 = tmp123, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var fm__10 any; var root_214 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = seq_1716000022__9; if linked_215 == nil { fm__10 = ifn_216.Invoke_O__O(arg_217) } else { fm__10 = linked_215.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_214, arg_217) }; var h__11 any; var root_218 any = A_arbace_j2g_jrt_A_const_46.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, A_arbace_j2g_jrt_go_head_A_fn_class); var ifn_220 lang.IFn
					if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = fm__10; if linked_219 == nil { h__11 = ifn_220.Invoke_O__O(arg_221) } else { h__11 = linked_219.(*A_arbace_j2g_jrt_go_head_A).Invoke_O_O__O(root_218, arg_221) }
//line :51:1
					if jrt.J2g_Truth(h__11) { var G__1716000093__12_ any = h__11


					L9: switch { default: switch lang.Util_Hash_O__I_NoInit(G__1716000093__12_) >> 0 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000093__12_, Lit_31) { var vec__1716000094__13 any = fm__10; var seq__1716000095__14 any; var root_921 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_921, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_923 lang.IFn


















						if linked_922 == nil { ifn_923 = lang.IFn_Cast(root_921) } else { ifn_923 = nil }; var arg_924 any = vec__1716000094__13; if linked_922 == nil { seq__1716000095__14 = ifn_923.Invoke_O__O(arg_924) } else { seq__1716000095__14 = linked_922.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_921, arg_924) }
//line :54:1
						var first__1716000096__15 any; var root_925 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_925, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_927 lang.IFn


















						if linked_926 == nil { ifn_927 = lang.IFn_Cast(root_925) } else { ifn_927 = nil }; var arg_928 any = seq__1716000095__14; if linked_926 == nil { first__1716000096__15 = ifn_927.Invoke_O__O(arg_928) } else { first__1716000096__15 = linked_926.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_925, arg_928) }
//line :54:1
						var seq__1716000095__16 any; var root_929 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_929, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_931 lang.IFn


















						if linked_930 == nil { ifn_931 = lang.IFn_Cast(root_929) } else { ifn_931 = nil }; var arg_932 any = seq__1716000095__14; if linked_930 == nil { seq__1716000095__16 = ifn_931.Invoke_O__O(arg_932) } else { seq__1716000095__16 = linked_930.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_929, arg_932) }
//line :54:1
						var ___17 any = first__1716000096__15; var first__1716000096__18 any; var root_933 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_933, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_935 lang.IFn; _ = ___17


















						if linked_934 == nil { ifn_935 = lang.IFn_Cast(root_933) } else { ifn_935 = nil }; var arg_936 any = seq__1716000095__16; if linked_934 == nil { first__1716000096__18 = ifn_935.Invoke_O__O(arg_936) } else { first__1716000096__18 = linked_934.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_933, arg_936) }
//line :54:1
						var seq__1716000095__19 any; var root_937 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_937, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_939 lang.IFn


















						if linked_938 == nil { ifn_939 = lang.IFn_Cast(root_937) } else { ifn_939 = nil }; var arg_940 any = seq__1716000095__16; if linked_938 == nil { seq__1716000095__19 = ifn_939.Invoke_O__O(arg_940) } else { seq__1716000095__19 = linked_938.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_937, arg_940) }
//line :54:1
						var nm__20 any = first__1716000096__18; var more__21_2 any = seq__1716000095__19; var more__22 any; var root_941 any = A_arbace_j2g_jrt_A_const_50.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_941, A_arbace_j2g_jrt_strip_doc_A_fn_class); var ifn_943 lang.IFn



















						if linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any = more__21_2; if linked_942 == nil { more__22 = ifn_943.Invoke_O__O(arg_944) } else { more__22 = linked_942.(*A_arbace_j2g_jrt_strip_doc_A).Invoke_O_O__O(root_941, arg_944) }
//line :54:1
						var more__23 any; var tmp124 any = A_arbace_j2g_jrt_A_const_51; var tmp125 any; var root_945 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_945, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_947 lang.IFn




















						if linked_946 == nil { ifn_947 = lang.IFn_Cast(root_945) } else { ifn_947 = nil }; var arg_948 any = more__22; if linked_946 == nil { tmp125 = ifn_947.Invoke_O__O(arg_948) } else { tmp125 = linked_946.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_945, arg_948) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp124, tmp125) { var root_949 any = A_arbace_j2g_jrt_A_const_30.GetRawRoot__O(); var linked_950 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_949, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_951 lang.IFn; if linked_950 == nil { ifn_951 = lang.IFn_Cast(root_949) } else { ifn_951 = nil }; var arg_953 any = more__22; if linked_950 == nil { more__23 = ifn_951.Invoke_O_O__O(A_arbace_j2g_jrt_A_const_31, arg_953) } else { more__23 = linked_950.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_949, 2, A_arbace_j2g_jrt_A_const_31, arg_953) } } else { more__23 = more__22 }
//line :54:1
						var params__24 any; var root_954 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_954, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_956 lang.IFn





















						if linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; var arg_957 any = more__23; if linked_955 == nil { params__24 = ifn_956.Invoke_O__O(arg_957) } else { params__24 = linked_955.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_954, arg_957) }
//line :54:1
						var rt__25 any; var root_958 any = A_arbace_j2g_jrt_A_const_52.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_958, A_arbace_j2g_jrt_recv_type_A_fn_class); var ifn_960 lang.IFn






















						if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any; var root_962 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_962, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_964 lang.IFn; if linked_963 == nil { ifn_964 = lang.IFn_Cast(root_962) } else { ifn_964 = nil }; var arg_965 any = params__24; if linked_963 == nil { arg_961 = ifn_964.Invoke_O__O(arg_965) } else { arg_961 = linked_963.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_962, arg_965) }; if linked_959 == nil { rt__25 = ifn_960.Invoke_O__O(arg_961) } else { rt__25 = linked_959.(*A_arbace_j2g_jrt_recv_type_A).Invoke_O_O__O(root_958, arg_961) }
						if jrt.J2g_Truth(rt__25) { var tmp126 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp127 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_53.GetRawRoot__O()); var tmp128 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp129 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_jrt_A_const_40, rt__25); var tmp130 any; var root_973 any = A_arbace_j2g_jrt_A_const_54.GetRawRoot__O(); var linked_974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_973, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_975 lang.IFn; if linked_974 == nil { ifn_975 = lang.IFn_Cast(root_973) } else { ifn_975 = nil }; var arg_976 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_977 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_974 == nil { tmp130 = ifn_975.Invoke_O_O__O(arg_976, arg_977) } else { tmp130 = linked_974.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_973, arg_976, arg_977) }; var tmp131 any = tmp130; var tmp132 any; var root_978 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_978, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_980 lang.IFn; if linked_979 == nil { ifn_980 = lang.IFn_Cast(root_978) } else { ifn_980 = nil }; var arg_981 any = nm__20; if linked_979 == nil { tmp132 = ifn_980.Invoke_O__O(arg_981) } else { tmp132 = linked_979.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_978, arg_981) }; jrt.NN(tmp126).Reset_O__O(tmp127.Invoke_O_O_O_O__O(tmp128, tmp129, tmp131, tmp132)) }
//line :54:1
						break L9 }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000093__12_, Lit_32) { var vec__1716000097__13 any = fm__10; var seq__1716000098__14 any; var root_982 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_982, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_984 lang.IFn
							if linked_983 == nil { ifn_984 = lang.IFn_Cast(root_982) } else { ifn_984 = nil }; var arg_985 any = vec__1716000097__13; if linked_983 == nil { seq__1716000098__14 = ifn_984.Invoke_O__O(arg_985) } else { seq__1716000098__14 = linked_983.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_982, arg_985) }
//line :54:1
							var first__1716000099__15 any; var root_986 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_986, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_988 lang.IFn
							if linked_987 == nil { ifn_988 = lang.IFn_Cast(root_986) } else { ifn_988 = nil }; var arg_989 any = seq__1716000098__14; if linked_987 == nil { first__1716000099__15 = ifn_988.Invoke_O__O(arg_989) } else { first__1716000099__15 = linked_987.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_986, arg_989) }
//line :54:1
							var seq__1716000098__16 any; var root_990 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_990, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_992 lang.IFn
							if linked_991 == nil { ifn_992 = lang.IFn_Cast(root_990) } else { ifn_992 = nil }; var arg_993 any = seq__1716000098__14; if linked_991 == nil { seq__1716000098__16 = ifn_992.Invoke_O__O(arg_993) } else { seq__1716000098__16 = linked_991.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_990, arg_993) }
//line :54:1
							var ___17_2 any = first__1716000099__15; var more__18 any = seq__1716000098__16; var more__19_3 any; var root_994 any = A_arbace_j2g_jrt_A_const_50.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, A_arbace_j2g_jrt_strip_doc_A_fn_class); var ifn_996 lang.IFn; _ = ___17_2

							if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any = more__18; if linked_995 == nil { more__19_3 = ifn_996.Invoke_O__O(arg_997) } else { more__19_3 = linked_995.(*A_arbace_j2g_jrt_strip_doc_A).Invoke_O_O__O(root_994, arg_997) }
							var tmp133 any; var root_998 any = A_arbace_j2g_jrt_A_const_55.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_998, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1000 lang.IFn; if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any; var root_1002 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1004 lang.IFn; if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any = more__19_3; if linked_1003 == nil { arg_1001 = ifn_1004.Invoke_O__O(arg_1005) } else { arg_1001 = linked_1003.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1002, arg_1005) }; if linked_999 == nil { tmp133 = ifn_1000.Invoke_O__O(arg_1001) } else { tmp133 = linked_999.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_998, arg_1001) }; if jrt.J2g_Truth(tmp133) { var seq_1716000100__20 any; var root_1006 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1006, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1008 lang.IFn
								if linked_1007 == nil { ifn_1008 = lang.IFn_Cast(root_1006) } else { ifn_1008 = nil }; var arg_1009 any = more__19_3; if linked_1007 == nil { seq_1716000100__20 = ifn_1008.Invoke_O__O(arg_1009) } else { seq_1716000100__20 = linked_1007.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1006, arg_1009) }
//line :57:1
								var chunk_1716000101__21 any; var count_1716000102__22 int64 = 0; var i_1716000103__23 int64 = 0; L10: for {
									if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000103__23, count_1716000102__22) { var vec__1716000104__24 any = lang.Indexed_Cast(chunk_1716000101__21).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000103__23)); var nm__25_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000104__24, lang.RT_IntCast_J__I_NoInit(0), nil); var tf__26_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000104__24, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp134 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp135 any; var root_1155 any = A_arbace_j2g_jrt_A_const_56.GetRawRoot__O(); var linked_1156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1155, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1157 lang.IFn
										if linked_1156 == nil { ifn_1157 = lang.IFn_Cast(root_1155) } else { ifn_1157 = nil }; var arg_1158 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1159 any; var tmp136 any = A_arbace_j2g_jrt_A_const_39; var tmp137 any; var root_1161 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1161, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1163 lang.IFn; if linked_1162 == nil { ifn_1163 = lang.IFn_Cast(root_1161) } else { ifn_1163 = nil }; var arg_1164 any = nm__25_2; if linked_1162 == nil { tmp137 = ifn_1163.Invoke_O__O(arg_1164) } else { tmp137 = linked_1162.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1161, arg_1164) }; arg_1159 = lang.Tuple_Create_O_O__IPersistentVector(tmp136, tmp137); var arg_1160 any; var tmp138 any = A_arbace_j2g_jrt_A_const_57; var tmp139 *lang.Keyword; var tmp140 any; var and__1927000168__auto____27_4 any; var root_1165 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_1166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1165, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1167 lang.IFn
										if linked_1166 == nil { ifn_1167 = lang.IFn_Cast(root_1165) } else { ifn_1167 = nil }; var arg_1168 any = tf__26_2; if linked_1166 == nil { and__1927000168__auto____27_4 = ifn_1167.Invoke_O__O(arg_1168) } else { and__1927000168__auto____27_4 = linked_1166.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1165, arg_1168) }; if jrt.J2g_Truth(and__1927000168__auto____27_4) { var tmp141 any = A_arbace_j2g_jrt_A_const_65; var tmp142 any; var root_1169 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1169, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1171 lang.IFn; if linked_1170 == nil { ifn_1171 = lang.IFn_Cast(root_1169) } else { ifn_1171 = nil }; var arg_1172 any = tf__26_2; if linked_1170 == nil { tmp142 = ifn_1171.Invoke_O__O(arg_1172) } else { tmp142 = linked_1170.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1169, arg_1172) }; tmp140 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp141, tmp142)).Ref() } else { tmp140 = and__1927000168__auto____27_4 }; if jrt.J2g_Truth(tmp140) { tmp139 = A_arbace_j2g_jrt_A_const_59 } else { var tmp143 any; var and__1927000168__auto____27_5 any; var root_1173 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_1174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1173, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1175 lang.IFn
											if linked_1174 == nil { ifn_1175 = lang.IFn_Cast(root_1173) } else { ifn_1175 = nil }; var arg_1176 any = tf__26_2; if linked_1174 == nil { and__1927000168__auto____27_5 = ifn_1175.Invoke_O__O(arg_1176) } else { and__1927000168__auto____27_5 = linked_1174.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1173, arg_1176) }; if jrt.J2g_Truth(and__1927000168__auto____27_5) { var tmp144 any = A_arbace_j2g_jrt_A_const_66; var tmp145 any; var root_1177 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1177, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1179 lang.IFn; if linked_1178 == nil { ifn_1179 = lang.IFn_Cast(root_1177) } else { ifn_1179 = nil }; var arg_1180 any = tf__26_2; if linked_1178 == nil { tmp145 = ifn_1179.Invoke_O__O(arg_1180) } else { tmp145 = linked_1178.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1177, arg_1180) }; tmp143 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp144, tmp145)).Ref() } else { tmp143 = and__1927000168__auto____27_5 }
//line :60:1
											if jrt.J2g_Truth(tmp143) { tmp139 = A_arbace_j2g_jrt_A_const_61 } else { if A_arbace_j2g_jrt_A_const_21 != nil { tmp139 = A_arbace_j2g_jrt_A_const_62 } else { tmp139 = nil } } }
//line :59:1
										arg_1160 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp138, tmp139.Ref(), A_arbace_j2g_jrt_A_const_63, tf__26_2)); if linked_1156 == nil { tmp135 = ifn_1157.Invoke_O_O_O__O(arg_1158, arg_1159, arg_1160) } else { tmp135 = linked_1156.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1155, arg_1158, arg_1159, arg_1160) }; jrt.NN(tmp134).Reset_O__O(tmp135)
//line :58:1
										seq_1716000100__20, chunk_1716000101__21, count_1716000102__22, i_1716000103__23 = seq_1716000100__20, chunk_1716000101__21, count_1716000102__22, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000103__23); continue L10 } else { var temp__1927000414__auto____24 any; var root_1010 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1010, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1012 lang.IFn; if linked_1011 == nil { ifn_1012 = lang.IFn_Cast(root_1010) } else { ifn_1012 = nil }; var arg_1013 any = seq_1716000100__20; if linked_1011 == nil { temp__1927000414__auto____24 = ifn_1012.Invoke_O__O(arg_1013) } else { temp__1927000414__auto____24 = linked_1011.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1010, arg_1013) }; if jrt.J2g_Truth(temp__1927000414__auto____24) { var seq_1716000100__25 any = temp__1927000414__auto____24; var tmp146 any; var root_1014 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_1015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1014, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1016 lang.IFn; if linked_1015 == nil { ifn_1016 = lang.IFn_Cast(root_1014) } else { ifn_1016 = nil }; var arg_1017 any = seq_1716000100__25; if linked_1015 == nil { tmp146 = ifn_1016.Invoke_O__O(arg_1017) } else { tmp146 = linked_1015.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1014, arg_1017) }; if jrt.J2g_Truth(tmp146) { var c__1927000678__auto____26 any; var root_1018 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_1019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1018, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1020 lang.IFn; if linked_1019 == nil { ifn_1020 = lang.IFn_Cast(root_1018) } else { ifn_1020 = nil }; var arg_1021 any = seq_1716000100__25; if linked_1019 == nil { c__1927000678__auto____26 = ifn_1020.Invoke_O__O(arg_1021) } else { c__1927000678__auto____26 = linked_1019.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1018, arg_1021) }; var tmp147 any; var root_1181 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1181, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1183 lang.IFn; if linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any = seq_1716000100__25; if linked_1182 == nil { tmp147 = ifn_1183.Invoke_O__O(arg_1184) } else { tmp147 = linked_1182.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1181, arg_1184) }; seq_1716000100__20, chunk_1716000101__21, count_1716000102__22, i_1716000103__23 = tmp147, c__1927000678__auto____26, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____26))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L10 } else { var vec__1716000107__26 any; var root_1022 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1022, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1024 lang.IFn; if linked_1023 == nil { ifn_1024 = lang.IFn_Cast(root_1022) } else { ifn_1024 = nil }; var arg_1025 any = seq_1716000100__25; if linked_1023 == nil { vec__1716000107__26 = ifn_1024.Invoke_O__O(arg_1025) } else { vec__1716000107__26 = linked_1023.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1022, arg_1025) }; var nm__27 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000107__26, lang.RT_IntCast_J__I_NoInit(0), nil); var tf__28 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000107__26, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp148 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp149 any; var root_1185 any = A_arbace_j2g_jrt_A_const_56.GetRawRoot__O(); var linked_1186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1185, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1187 lang.IFn
											if linked_1186 == nil { ifn_1187 = lang.IFn_Cast(root_1185) } else { ifn_1187 = nil }; var arg_1188 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1189 any; var tmp150 any = A_arbace_j2g_jrt_A_const_39; var tmp151 any; var root_1191 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1191, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1193 lang.IFn; if linked_1192 == nil { ifn_1193 = lang.IFn_Cast(root_1191) } else { ifn_1193 = nil }; var arg_1194 any = nm__27; if linked_1192 == nil { tmp151 = ifn_1193.Invoke_O__O(arg_1194) } else { tmp151 = linked_1192.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1191, arg_1194) }; arg_1189 = lang.Tuple_Create_O_O__IPersistentVector(tmp150, tmp151); var arg_1190 any; var tmp152 any = A_arbace_j2g_jrt_A_const_57; var tmp153 *lang.Keyword; var tmp154 any; var and__1927000168__auto____29 any; var root_1195 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_1196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1195, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1197 lang.IFn
											if linked_1196 == nil { ifn_1197 = lang.IFn_Cast(root_1195) } else { ifn_1197 = nil }; var arg_1198 any = tf__28; if linked_1196 == nil { and__1927000168__auto____29 = ifn_1197.Invoke_O__O(arg_1198) } else { and__1927000168__auto____29 = linked_1196.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1195, arg_1198) }; if jrt.J2g_Truth(and__1927000168__auto____29) { var tmp155 any = A_arbace_j2g_jrt_A_const_65; var tmp156 any; var root_1199 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1199, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1201 lang.IFn; if linked_1200 == nil { ifn_1201 = lang.IFn_Cast(root_1199) } else { ifn_1201 = nil }; var arg_1202 any = tf__28; if linked_1200 == nil { tmp156 = ifn_1201.Invoke_O__O(arg_1202) } else { tmp156 = linked_1200.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1199, arg_1202) }; tmp154 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp155, tmp156)).Ref() } else { tmp154 = and__1927000168__auto____29 }; if jrt.J2g_Truth(tmp154) { tmp153 = A_arbace_j2g_jrt_A_const_59 } else { var tmp157 any; var and__1927000168__auto____29_2 any; var root_1203 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_1204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1203, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1205 lang.IFn
												if linked_1204 == nil { ifn_1205 = lang.IFn_Cast(root_1203) } else { ifn_1205 = nil }; var arg_1206 any = tf__28; if linked_1204 == nil { and__1927000168__auto____29_2 = ifn_1205.Invoke_O__O(arg_1206) } else { and__1927000168__auto____29_2 = linked_1204.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1203, arg_1206) }; if jrt.J2g_Truth(and__1927000168__auto____29_2) { var tmp158 any = A_arbace_j2g_jrt_A_const_66; var tmp159 any; var root_1207 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1207, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1209 lang.IFn; if linked_1208 == nil { ifn_1209 = lang.IFn_Cast(root_1207) } else { ifn_1209 = nil }; var arg_1210 any = tf__28; if linked_1208 == nil { tmp159 = ifn_1209.Invoke_O__O(arg_1210) } else { tmp159 = linked_1208.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1207, arg_1210) }; tmp157 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp158, tmp159)).Ref() } else { tmp157 = and__1927000168__auto____29_2 }
//line :60:1
												if jrt.J2g_Truth(tmp157) { tmp153 = A_arbace_j2g_jrt_A_const_61 } else { if A_arbace_j2g_jrt_A_const_21 != nil { tmp153 = A_arbace_j2g_jrt_A_const_62 } else { tmp153 = nil } } }
//line :59:1
											arg_1190 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp152, tmp153.Ref(), A_arbace_j2g_jrt_A_const_63, tf__28)); if linked_1186 == nil { tmp149 = ifn_1187.Invoke_O_O_O__O(arg_1188, arg_1189, arg_1190) } else { tmp149 = linked_1186.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1185, arg_1188, arg_1189, arg_1190) }; jrt.NN(tmp148).Reset_O__O(tmp149)
//line :58:1
											var tmp160 any; var root_1211 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_1212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1211, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1213 lang.IFn; if linked_1212 == nil { ifn_1213 = lang.IFn_Cast(root_1211) } else { ifn_1213 = nil }; var arg_1214 any = seq_1716000100__25; if linked_1212 == nil { tmp160 = ifn_1213.Invoke_O__O(arg_1214) } else { tmp160 = linked_1212.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1211, arg_1214) }; seq_1716000100__20, chunk_1716000101__21, count_1716000102__22, i_1716000103__23 = tmp160, nil, 0, 0; continue L10 } } }
//line :57:1
									break L10 } } else { var nm__20_2 any; var root_1026 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1026, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1028 lang.IFn






										if linked_1027 == nil { ifn_1028 = lang.IFn_Cast(root_1026) } else { ifn_1028 = nil }; var arg_1029 any = more__19_3; if linked_1027 == nil { nm__20_2 = ifn_1028.Invoke_O__O(arg_1029) } else { nm__20_2 = linked_1027.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1026, arg_1029) }
//line :57:1
										var more__21_3 any; var root_1030 any = A_arbace_j2g_jrt_A_const_50.GetRawRoot__O(); var linked_1031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1030, A_arbace_j2g_jrt_strip_doc_A_fn_class); var ifn_1032 lang.IFn







										if linked_1031 == nil { ifn_1032 = lang.IFn_Cast(root_1030) } else { ifn_1032 = nil }; var arg_1033 any; var root_1034 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_1035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1034, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1036 lang.IFn; if linked_1035 == nil { ifn_1036 = lang.IFn_Cast(root_1034) } else { ifn_1036 = nil }; var arg_1037 any = more__19_3; if linked_1035 == nil { arg_1033 = ifn_1036.Invoke_O__O(arg_1037) } else { arg_1033 = linked_1035.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1034, arg_1037) }; if linked_1031 == nil { more__21_3 = ifn_1032.Invoke_O__O(arg_1033) } else { more__21_3 = linked_1031.(*A_arbace_j2g_jrt_strip_doc_A).Invoke_O_O__O(root_1030, arg_1033) }
//line :57:1
										var more__22_2 any; var tmp161 any = A_arbace_j2g_jrt_A_const_51; var tmp162 any; var root_1038 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1038, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1040 lang.IFn








										if linked_1039 == nil { ifn_1040 = lang.IFn_Cast(root_1038) } else { ifn_1040 = nil }; var arg_1041 any = more__21_3; if linked_1039 == nil { tmp162 = ifn_1040.Invoke_O__O(arg_1041) } else { tmp162 = linked_1039.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1038, arg_1041) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp161, tmp162) { var root_1042 any = A_arbace_j2g_jrt_A_const_30.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1042, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_1044 lang.IFn; if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1046 any = more__21_3; if linked_1043 == nil { more__22_2 = ifn_1044.Invoke_O_O__O(A_arbace_j2g_jrt_A_const_31, arg_1046) } else { more__22_2 = linked_1043.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_1042, 2, A_arbace_j2g_jrt_A_const_31, arg_1046) } } else { more__22_2 = more__21_3 }
//line :57:1
										var tf__23 any; var root_1047 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1047, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1049 lang.IFn









										if linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any = more__22_2; if linked_1048 == nil { tf__23 = ifn_1049.Invoke_O__O(arg_1050) } else { tf__23 = linked_1048.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1047, arg_1050) }
										var tmp163 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp164 any; var root_1051 any = A_arbace_j2g_jrt_A_const_56.GetRawRoot__O(); var linked_1052 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1051, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1053 lang.IFn; if linked_1052 == nil { ifn_1053 = lang.IFn_Cast(root_1051) } else { ifn_1053 = nil }; var arg_1054 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1055 any; var tmp165 any = A_arbace_j2g_jrt_A_const_39; var tmp166 any; var root_1057 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1057, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1059 lang.IFn; if linked_1058 == nil { ifn_1059 = lang.IFn_Cast(root_1057) } else { ifn_1059 = nil }; var arg_1060 any = nm__20_2; if linked_1058 == nil { tmp166 = ifn_1059.Invoke_O__O(arg_1060) } else { tmp166 = linked_1058.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1057, arg_1060) }; arg_1055 = lang.Tuple_Create_O_O__IPersistentVector(tmp165, tmp166); var arg_1056 any; var tmp167 any = A_arbace_j2g_jrt_A_const_57; var tmp168 *lang.Keyword; var tmp169 any; var and__1927000168__auto____24 any; var root_1061 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1061, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1063 lang.IFn
										if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any = tf__23; if linked_1062 == nil { and__1927000168__auto____24 = ifn_1063.Invoke_O__O(arg_1064) } else { and__1927000168__auto____24 = linked_1062.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1061, arg_1064) }; if jrt.J2g_Truth(and__1927000168__auto____24) { var tmp170 any = A_arbace_j2g_jrt_A_const_58; var tmp171 any; var root_1065 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1065, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1067 lang.IFn; if linked_1066 == nil { ifn_1067 = lang.IFn_Cast(root_1065) } else { ifn_1067 = nil }; var arg_1068 any = tf__23; if linked_1066 == nil { tmp171 = ifn_1067.Invoke_O__O(arg_1068) } else { tmp171 = linked_1066.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1065, arg_1068) }; tmp169 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp170, tmp171)).Ref() } else { tmp169 = and__1927000168__auto____24 }; if jrt.J2g_Truth(tmp169) { tmp168 = A_arbace_j2g_jrt_A_const_59 } else { var tmp172 any; var and__1927000168__auto____24_2 any; var root_1069 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_1070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1069, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1071 lang.IFn
											if linked_1070 == nil { ifn_1071 = lang.IFn_Cast(root_1069) } else { ifn_1071 = nil }; var arg_1072 any = tf__23; if linked_1070 == nil { and__1927000168__auto____24_2 = ifn_1071.Invoke_O__O(arg_1072) } else { and__1927000168__auto____24_2 = linked_1070.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1069, arg_1072) }; if jrt.J2g_Truth(and__1927000168__auto____24_2) { var tmp173 any = A_arbace_j2g_jrt_A_const_60; var tmp174 any; var root_1073 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1073, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1075 lang.IFn; if linked_1074 == nil { ifn_1075 = lang.IFn_Cast(root_1073) } else { ifn_1075 = nil }; var arg_1076 any = tf__23; if linked_1074 == nil { tmp174 = ifn_1075.Invoke_O__O(arg_1076) } else { tmp174 = linked_1074.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1073, arg_1076) }; tmp172 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp173, tmp174)).Ref() } else { tmp172 = and__1927000168__auto____24_2 }
//line :69:1
											if jrt.J2g_Truth(tmp172) { tmp168 = A_arbace_j2g_jrt_A_const_61 } else { if A_arbace_j2g_jrt_A_const_21 != nil { tmp168 = A_arbace_j2g_jrt_A_const_62 } else { tmp168 = nil } } }
//line :68:1
										arg_1056 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp167, tmp168.Ref(), A_arbace_j2g_jrt_A_const_63, tf__23)); if linked_1052 == nil { tmp164 = ifn_1053.Invoke_O_O_O__O(arg_1054, arg_1055, arg_1056) } else { tmp164 = linked_1052.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1051, arg_1054, arg_1055, arg_1056) }; jrt.NN(tmp163).Reset_O__O(tmp164) }
//line :54:1
							break L9 }; case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000093__12_, Lit_33) { var vec__1716000110__13 any = fm__10; var seq__1716000111__14 any; var root_1077 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1077, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1079 lang.IFn








































								if linked_1078 == nil { ifn_1079 = lang.IFn_Cast(root_1077) } else { ifn_1079 = nil }; var arg_1080 any = vec__1716000110__13; if linked_1078 == nil { seq__1716000111__14 = ifn_1079.Invoke_O__O(arg_1080) } else { seq__1716000111__14 = linked_1078.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1077, arg_1080) }
//line :54:1
								var first__1716000112__15 any; var root_1081 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1081, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1083 lang.IFn








































								if linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; var arg_1084 any = seq__1716000111__14; if linked_1082 == nil { first__1716000112__15 = ifn_1083.Invoke_O__O(arg_1084) } else { first__1716000112__15 = linked_1082.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1081, arg_1084) }
//line :54:1
								var seq__1716000111__16 any; var root_1085 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_1086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1085, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1087 lang.IFn








































								if linked_1086 == nil { ifn_1087 = lang.IFn_Cast(root_1085) } else { ifn_1087 = nil }; var arg_1088 any = seq__1716000111__14; if linked_1086 == nil { seq__1716000111__16 = ifn_1087.Invoke_O__O(arg_1088) } else { seq__1716000111__16 = linked_1086.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1085, arg_1088) }
//line :54:1
								var ___17_3 any = first__1716000112__15; var more__18_2 any = seq__1716000111__16; var more__19_4 any; var root_1089 any = A_arbace_j2g_jrt_A_const_50.GetRawRoot__O(); var linked_1090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1089, A_arbace_j2g_jrt_strip_doc_A_fn_class); var ifn_1091 lang.IFn; _ = ___17_3









































								if linked_1090 == nil { ifn_1091 = lang.IFn_Cast(root_1089) } else { ifn_1091 = nil }; var arg_1092 any = more__18_2; if linked_1090 == nil { more__19_4 = ifn_1091.Invoke_O__O(arg_1092) } else { more__19_4 = linked_1090.(*A_arbace_j2g_jrt_strip_doc_A).Invoke_O_O__O(root_1089, arg_1092) }
								var tmp175 any; var root_1093 any = A_arbace_j2g_jrt_A_const_55.GetRawRoot__O(); var linked_1094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1093, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1095 lang.IFn; if linked_1094 == nil { ifn_1095 = lang.IFn_Cast(root_1093) } else { ifn_1095 = nil }; var arg_1096 any; var root_1097 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1098 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1097, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1099 lang.IFn; if linked_1098 == nil { ifn_1099 = lang.IFn_Cast(root_1097) } else { ifn_1099 = nil }; var arg_1100 any = more__19_4; if linked_1098 == nil { arg_1096 = ifn_1099.Invoke_O__O(arg_1100) } else { arg_1096 = linked_1098.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1097, arg_1100) }; if linked_1094 == nil { tmp175 = ifn_1095.Invoke_O__O(arg_1096) } else { tmp175 = linked_1094.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1093, arg_1096) }; if jrt.J2g_Truth(tmp175) { var seq_1716000113__20 any; var root_1101 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1101, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1103 lang.IFn
									if linked_1102 == nil { ifn_1103 = lang.IFn_Cast(root_1101) } else { ifn_1103 = nil }; var arg_1104 any = more__19_4; if linked_1102 == nil { seq_1716000113__20 = ifn_1103.Invoke_O__O(arg_1104) } else { seq_1716000113__20 = linked_1102.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1101, arg_1104) }
//line :97:1
									var chunk_1716000114__21 any; var count_1716000115__22 int64 = 0; var i_1716000116__23 int64 = 0; L11: for {
										if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000116__23, count_1716000115__22) { var vec__1716000117__24 any = lang.Indexed_Cast(chunk_1716000114__21).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000116__23)); var tg__25_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000117__24, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp176 any; var root_1215 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_1216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1215, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1217 lang.IFn; if linked_1216 == nil { ifn_1217 = lang.IFn_Cast(root_1215) } else { ifn_1217 = nil }; var arg_1218 any = tg__25_3; if linked_1216 == nil { tmp176 = ifn_1217.Invoke_O__O(arg_1218) } else { tmp176 = linked_1216.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1215, arg_1218) }; if jrt.J2g_Truth(tmp176) { var tmp177 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp178 any; var root_1219 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_1220 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1219, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1221 lang.IFn; if linked_1220 == nil { ifn_1221 = lang.IFn_Cast(root_1219) } else { ifn_1221 = nil }; var arg_1222 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1223 any = A_arbace_j2g_jrt_A_const_44; var arg_1224 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_1225 any; var root_1226 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1226, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1228 lang.IFn; if linked_1227 == nil { ifn_1228 = lang.IFn_Cast(root_1226) } else { ifn_1228 = nil }; var arg_1229 any = tg__25_3; if linked_1227 == nil { arg_1225 = ifn_1228.Invoke_O__O(arg_1229) } else { arg_1225 = linked_1227.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1226, arg_1229) }; if linked_1220 == nil { tmp178 = ifn_1221.Invoke_O_O_O_O__O(arg_1222, arg_1223, arg_1224, arg_1225) } else { tmp178 = linked_1220.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1219, arg_1222, arg_1223, arg_1224, arg_1225) }; jrt.NN(tmp177).Reset_O__O(tmp178) }; seq_1716000113__20, chunk_1716000114__21, count_1716000115__22, i_1716000116__23 = seq_1716000113__20, chunk_1716000114__21, count_1716000115__22, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000116__23); continue L11 } else { var temp__1927000414__auto____24_2 any; var root_1105 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1105, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1107 lang.IFn; if linked_1106 == nil { ifn_1107 = lang.IFn_Cast(root_1105) } else { ifn_1107 = nil }; var arg_1108 any = seq_1716000113__20; if linked_1106 == nil { temp__1927000414__auto____24_2 = ifn_1107.Invoke_O__O(arg_1108) } else { temp__1927000414__auto____24_2 = linked_1106.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1105, arg_1108) }; if jrt.J2g_Truth(temp__1927000414__auto____24_2) { var seq_1716000113__25 any = temp__1927000414__auto____24_2; var tmp179 any; var root_1109 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_1110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1109, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1111 lang.IFn; if linked_1110 == nil { ifn_1111 = lang.IFn_Cast(root_1109) } else { ifn_1111 = nil }; var arg_1112 any = seq_1716000113__25; if linked_1110 == nil { tmp179 = ifn_1111.Invoke_O__O(arg_1112) } else { tmp179 = linked_1110.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1109, arg_1112) }; if jrt.J2g_Truth(tmp179) { var c__1927000678__auto____26_2 any; var root_1113 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_1114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1113, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1115 lang.IFn; if linked_1114 == nil { ifn_1115 = lang.IFn_Cast(root_1113) } else { ifn_1115 = nil }; var arg_1116 any = seq_1716000113__25; if linked_1114 == nil { c__1927000678__auto____26_2 = ifn_1115.Invoke_O__O(arg_1116) } else { c__1927000678__auto____26_2 = linked_1114.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1113, arg_1116) }; var tmp180 any; var root_1230 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_1231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1230, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1232 lang.IFn; if linked_1231 == nil { ifn_1232 = lang.IFn_Cast(root_1230) } else { ifn_1232 = nil }; var arg_1233 any = seq_1716000113__25; if linked_1231 == nil { tmp180 = ifn_1232.Invoke_O__O(arg_1233) } else { tmp180 = linked_1231.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1230, arg_1233) }; seq_1716000113__20, chunk_1716000114__21, count_1716000115__22, i_1716000116__23 = tmp180, c__1927000678__auto____26_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____26_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L11 } else { var vec__1716000120__26 any; var root_1117 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1117, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1119 lang.IFn; if linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any = seq_1716000113__25; if linked_1118 == nil { vec__1716000120__26 = ifn_1119.Invoke_O__O(arg_1120) } else { vec__1716000120__26 = linked_1118.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1117, arg_1120) }; var tg__27 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000120__26, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp181 any; var root_1234 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_1235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1234, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1236 lang.IFn; if linked_1235 == nil { ifn_1236 = lang.IFn_Cast(root_1234) } else { ifn_1236 = nil }; var arg_1237 any = tg__27; if linked_1235 == nil { tmp181 = ifn_1236.Invoke_O__O(arg_1237) } else { tmp181 = linked_1235.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1234, arg_1237) }; if jrt.J2g_Truth(tmp181) { var tmp182 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp183 any; var root_1238 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_1239 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1238, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1240 lang.IFn; if linked_1239 == nil { ifn_1240 = lang.IFn_Cast(root_1238) } else { ifn_1240 = nil }; var arg_1241 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1242 any = A_arbace_j2g_jrt_A_const_44; var arg_1243 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_1244 any; var root_1245 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1245, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1247 lang.IFn; if linked_1246 == nil { ifn_1247 = lang.IFn_Cast(root_1245) } else { ifn_1247 = nil }; var arg_1248 any = tg__27; if linked_1246 == nil { arg_1244 = ifn_1247.Invoke_O__O(arg_1248) } else { arg_1244 = linked_1246.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1245, arg_1248) }; if linked_1239 == nil { tmp183 = ifn_1240.Invoke_O_O_O_O__O(arg_1241, arg_1242, arg_1243, arg_1244) } else { tmp183 = linked_1239.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1238, arg_1241, arg_1242, arg_1243, arg_1244) }; jrt.NN(tmp182).Reset_O__O(tmp183) }; var tmp184 any; var root_1249 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_1250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1249, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1251 lang.IFn; if linked_1250 == nil { ifn_1251 = lang.IFn_Cast(root_1249) } else { ifn_1251 = nil }; var arg_1252 any = seq_1716000113__25; if linked_1250 == nil { tmp184 = ifn_1251.Invoke_O__O(arg_1252) } else { tmp184 = linked_1250.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1249, arg_1252) }; seq_1716000113__20, chunk_1716000114__21, count_1716000115__22, i_1716000116__23 = tmp184, nil, 0, 0; continue L11 } } }
//line :97:1
										break L11 } } else {

											var tmp185 any; var root_1121 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_1122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1121, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1123 lang.IFn; if linked_1122 == nil { ifn_1123 = lang.IFn_Cast(root_1121) } else { ifn_1123 = nil }; var arg_1124 any; var root_1125 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1125, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1127 lang.IFn; if linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any = more__19_4; if linked_1126 == nil { arg_1124 = ifn_1127.Invoke_O__O(arg_1128) } else { arg_1124 = linked_1126.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1125, arg_1128) }; if linked_1122 == nil { tmp185 = ifn_1123.Invoke_O__O(arg_1124) } else { tmp185 = linked_1122.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1121, arg_1124) }; if jrt.J2g_Truth(tmp185) { var tmp186 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp187 any; var root_1129 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_1130 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1129, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1131 lang.IFn; if linked_1130 == nil { ifn_1131 = lang.IFn_Cast(root_1129) } else { ifn_1131 = nil }; var arg_1132 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1133 any = A_arbace_j2g_jrt_A_const_44; var arg_1134 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_1135 any; var root_1136 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1136, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1138 lang.IFn; if linked_1137 == nil { ifn_1138 = lang.IFn_Cast(root_1136) } else { ifn_1138 = nil }; var arg_1139 any; var root_1140 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1140, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1142 lang.IFn; if linked_1141 == nil { ifn_1142 = lang.IFn_Cast(root_1140) } else { ifn_1142 = nil }; var arg_1143 any = more__19_4; if linked_1141 == nil { arg_1139 = ifn_1142.Invoke_O__O(arg_1143) } else { arg_1139 = linked_1141.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1140, arg_1143) }; if linked_1137 == nil { arg_1135 = ifn_1138.Invoke_O__O(arg_1139) } else { arg_1135 = linked_1137.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1136, arg_1139) }; if linked_1130 == nil { tmp187 = ifn_1131.Invoke_O_O_O_O__O(arg_1132, arg_1133, arg_1134, arg_1135) } else { tmp187 = linked_1130.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1129, arg_1132, arg_1133, arg_1134, arg_1135) }; jrt.NN(tmp186).Reset_O__O(tmp187) } }
//line :54:1
								break L9 }; case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000093__12_, Lit_34) { var vec__1716000123__13 any = fm__10; var ___14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000123__13, lang.RT_IntCast_J__I_NoInit(0), nil); var nm__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000123__13, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp188 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp189 any; var root_1144 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_1145 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1144, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1146 lang.IFn; _ = ___14
























									if linked_1145 == nil { ifn_1146 = lang.IFn_Cast(root_1144) } else { ifn_1146 = nil }; var arg_1147 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1148 any = A_arbace_j2g_jrt_A_const_41; var arg_1149 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_1150 any; var root_1151 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1151, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1153 lang.IFn; if linked_1152 == nil { ifn_1153 = lang.IFn_Cast(root_1151) } else { ifn_1153 = nil }; var arg_1154 any = nm__15; if linked_1152 == nil { arg_1150 = ifn_1153.Invoke_O__O(arg_1154) } else { arg_1150 = linked_1152.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1151, arg_1154) }; if linked_1145 == nil { tmp189 = ifn_1146.Invoke_O_O_O_O__O(arg_1147, arg_1148, arg_1149, arg_1150) } else { tmp189 = linked_1145.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1144, arg_1147, arg_1148, arg_1149, arg_1150) }; jrt.NN(tmp188).Reset_O__O(tmp189)
//line :54:1
									break L9 }; case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000093__12_, Lit_35) { var vec__1716000126__13 any = fm__10; var seq__1716000127__14 any; var root_1253 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1253, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1255 lang.IFn

























										if linked_1254 == nil { ifn_1255 = lang.IFn_Cast(root_1253) } else { ifn_1255 = nil }; var arg_1256 any = vec__1716000126__13; if linked_1254 == nil { seq__1716000127__14 = ifn_1255.Invoke_O__O(arg_1256) } else { seq__1716000127__14 = linked_1254.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1253, arg_1256) }
//line :54:1
										var first__1716000128__15 any; var root_1257 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1257, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1259 lang.IFn

























										if linked_1258 == nil { ifn_1259 = lang.IFn_Cast(root_1257) } else { ifn_1259 = nil }; var arg_1260 any = seq__1716000127__14; if linked_1258 == nil { first__1716000128__15 = ifn_1259.Invoke_O__O(arg_1260) } else { first__1716000128__15 = linked_1258.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1257, arg_1260) }
//line :54:1
										var seq__1716000127__16 any; var root_1261 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_1262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1261, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1263 lang.IFn

























										if linked_1262 == nil { ifn_1263 = lang.IFn_Cast(root_1261) } else { ifn_1263 = nil }; var arg_1264 any = seq__1716000127__14; if linked_1262 == nil { seq__1716000127__16 = ifn_1263.Invoke_O__O(arg_1264) } else { seq__1716000127__16 = linked_1262.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1261, arg_1264) }
//line :54:1
										var ___17_4 any = first__1716000128__15; var more__18_3 any = seq__1716000127__16; var more__19_5 any; var root_1265 any = A_arbace_j2g_jrt_A_const_50.GetRawRoot__O(); var linked_1266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1265, A_arbace_j2g_jrt_strip_doc_A_fn_class); var ifn_1267 lang.IFn; _ = ___17_4


























										if linked_1266 == nil { ifn_1267 = lang.IFn_Cast(root_1265) } else { ifn_1267 = nil }; var arg_1268 any = more__18_3; if linked_1266 == nil { more__19_5 = ifn_1267.Invoke_O__O(arg_1268) } else { more__19_5 = linked_1266.(*A_arbace_j2g_jrt_strip_doc_A).Invoke_O_O__O(root_1265, arg_1268) }
										var tmp190 any; var root_1269 any = A_arbace_j2g_jrt_A_const_55.GetRawRoot__O(); var linked_1270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1269, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1271 lang.IFn; if linked_1270 == nil { ifn_1271 = lang.IFn_Cast(root_1269) } else { ifn_1271 = nil }; var arg_1272 any; var root_1273 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1273, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1275 lang.IFn; if linked_1274 == nil { ifn_1275 = lang.IFn_Cast(root_1273) } else { ifn_1275 = nil }; var arg_1276 any = more__19_5; if linked_1274 == nil { arg_1272 = ifn_1275.Invoke_O__O(arg_1276) } else { arg_1272 = linked_1274.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1273, arg_1276) }; if linked_1270 == nil { tmp190 = ifn_1271.Invoke_O__O(arg_1272) } else { tmp190 = linked_1270.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1269, arg_1272) }; if jrt.J2g_Truth(tmp190) { var seq_1716000129__20 any; var root_1277 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1277, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1279 lang.IFn
											if linked_1278 == nil { ifn_1279 = lang.IFn_Cast(root_1277) } else { ifn_1279 = nil }; var arg_1280 any = more__19_5; if linked_1278 == nil { seq_1716000129__20 = ifn_1279.Invoke_O__O(arg_1280) } else { seq_1716000129__20 = linked_1278.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1277, arg_1280) }
//line :82:1
											var chunk_1716000130__21 any; var count_1716000131__22 int64 = 0; var i_1716000132__23 int64 = 0; L12: for {
												if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000132__23, count_1716000131__22) { var vec__1716000133__24 any = lang.Indexed_Cast(chunk_1716000130__21).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000132__23)); var tg__25_4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000133__24, lang.RT_IntCast_J__I_NoInit(0), nil); var init__26_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000133__24, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp191 any; var and__1927000168__auto____27_6 any; var root_1359 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_1360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1359, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1361 lang.IFn
													if linked_1360 == nil { ifn_1361 = lang.IFn_Cast(root_1359) } else { ifn_1361 = nil }; var arg_1362 any = tg__25_4; if linked_1360 == nil { and__1927000168__auto____27_6 = ifn_1361.Invoke_O__O(arg_1362) } else { and__1927000168__auto____27_6 = linked_1360.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1359, arg_1362) }; if jrt.J2g_Truth(and__1927000168__auto____27_6) { var tmp192 any = A_arbace_j2g_jrt_A_const_71; var tmp193 any; var root_1363 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1363, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1365 lang.IFn; if linked_1364 == nil { ifn_1365 = lang.IFn_Cast(root_1363) } else { ifn_1365 = nil }; var arg_1366 any = tg__25_4; if linked_1364 == nil { tmp193 = ifn_1365.Invoke_O__O(arg_1366) } else { tmp193 = linked_1364.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1363, arg_1366) }; tmp191 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp192, tmp193)).Ref() } else { tmp191 = and__1927000168__auto____27_6 }; if jrt.J2g_Truth(tmp191) { var seq_1716000136__27 any; var root_1367 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1367, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1369 lang.IFn
														if linked_1368 == nil { ifn_1369 = lang.IFn_Cast(root_1367) } else { ifn_1369 = nil }; var arg_1370 any; var root_1371 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_1372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1371, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1373 lang.IFn; if linked_1372 == nil { ifn_1373 = lang.IFn_Cast(root_1371) } else { ifn_1373 = nil }; var arg_1374 any = tg__25_4; if linked_1372 == nil { arg_1370 = ifn_1373.Invoke_O__O(arg_1374) } else { arg_1370 = linked_1372.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1371, arg_1374) }; if linked_1368 == nil { seq_1716000136__27 = ifn_1369.Invoke_O__O(arg_1370) } else { seq_1716000136__27 = linked_1368.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1367, arg_1370) }
//line :84:1
														var chunk_1716000137__28 any; var count_1716000138__29 int64 = 0; var i_1716000139__30 int64 = 0; L13: for {
															if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000139__30, count_1716000138__29) { var s__31_3 any = lang.Indexed_Cast(chunk_1716000137__28).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000139__30)); var tmp194 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp195 any; var root_1421 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_1422 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1421, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1423 lang.IFn; if linked_1422 == nil { ifn_1423 = lang.IFn_Cast(root_1421) } else { ifn_1423 = nil }; var arg_1424 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1425 any = A_arbace_j2g_jrt_A_const_42; var arg_1426 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_1427 any; var root_1428 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1428, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1430 lang.IFn; if linked_1429 == nil { ifn_1430 = lang.IFn_Cast(root_1428) } else { ifn_1430 = nil }; var arg_1431 any = s__31_3; if linked_1429 == nil { arg_1427 = ifn_1430.Invoke_O__O(arg_1431) } else { arg_1427 = linked_1429.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1428, arg_1431) }; if linked_1422 == nil { tmp195 = ifn_1423.Invoke_O_O_O_O__O(arg_1424, arg_1425, arg_1426, arg_1427) } else { tmp195 = linked_1422.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1421, arg_1424, arg_1425, arg_1426, arg_1427) }; jrt.NN(tmp194).Reset_O__O(tmp195); seq_1716000136__27, chunk_1716000137__28, count_1716000138__29, i_1716000139__30 = seq_1716000136__27, chunk_1716000137__28, count_1716000138__29, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000139__30); continue L13 } else { var temp__1927000414__auto____31_2 any; var root_1375 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1375, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1377 lang.IFn; if linked_1376 == nil { ifn_1377 = lang.IFn_Cast(root_1375) } else { ifn_1377 = nil }; var arg_1378 any = seq_1716000136__27; if linked_1376 == nil { temp__1927000414__auto____31_2 = ifn_1377.Invoke_O__O(arg_1378) } else { temp__1927000414__auto____31_2 = linked_1376.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1375, arg_1378) }; if jrt.J2g_Truth(temp__1927000414__auto____31_2) { var seq_1716000136__32 any = temp__1927000414__auto____31_2; var tmp196 any; var root_1379 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_1380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1379, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1381 lang.IFn; if linked_1380 == nil { ifn_1381 = lang.IFn_Cast(root_1379) } else { ifn_1381 = nil }; var arg_1382 any = seq_1716000136__32; if linked_1380 == nil { tmp196 = ifn_1381.Invoke_O__O(arg_1382) } else { tmp196 = linked_1380.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1379, arg_1382) }; if jrt.J2g_Truth(tmp196) { var c__1927000678__auto____33_2 any; var root_1383 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_1384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1383, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1385 lang.IFn; if linked_1384 == nil { ifn_1385 = lang.IFn_Cast(root_1383) } else { ifn_1385 = nil }; var arg_1386 any = seq_1716000136__32; if linked_1384 == nil { c__1927000678__auto____33_2 = ifn_1385.Invoke_O__O(arg_1386) } else { c__1927000678__auto____33_2 = linked_1384.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1383, arg_1386) }; var tmp197 any; var root_1432 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_1433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1432, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1434 lang.IFn; if linked_1433 == nil { ifn_1434 = lang.IFn_Cast(root_1432) } else { ifn_1434 = nil }; var arg_1435 any = seq_1716000136__32; if linked_1433 == nil { tmp197 = ifn_1434.Invoke_O__O(arg_1435) } else { tmp197 = linked_1433.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1432, arg_1435) }; seq_1716000136__27, chunk_1716000137__28, count_1716000138__29, i_1716000139__30 = tmp197, c__1927000678__auto____33_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____33_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L13 } else { var s__33_2 any; var root_1387 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1387, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1389 lang.IFn; if linked_1388 == nil { ifn_1389 = lang.IFn_Cast(root_1387) } else { ifn_1389 = nil }; var arg_1390 any = seq_1716000136__32; if linked_1388 == nil { s__33_2 = ifn_1389.Invoke_O__O(arg_1390) } else { s__33_2 = linked_1388.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1387, arg_1390) }; var tmp198 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp199 any; var root_1436 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_1437 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1436, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1438 lang.IFn; if linked_1437 == nil { ifn_1438 = lang.IFn_Cast(root_1436) } else { ifn_1438 = nil }; var arg_1439 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1440 any = A_arbace_j2g_jrt_A_const_42; var arg_1441 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_1442 any; var root_1443 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1443, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1445 lang.IFn; if linked_1444 == nil { ifn_1445 = lang.IFn_Cast(root_1443) } else { ifn_1445 = nil }; var arg_1446 any = s__33_2; if linked_1444 == nil { arg_1442 = ifn_1445.Invoke_O__O(arg_1446) } else { arg_1442 = linked_1444.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1443, arg_1446) }; if linked_1437 == nil { tmp199 = ifn_1438.Invoke_O_O_O_O__O(arg_1439, arg_1440, arg_1441, arg_1442) } else { tmp199 = linked_1437.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1436, arg_1439, arg_1440, arg_1441, arg_1442) }; jrt.NN(tmp198).Reset_O__O(tmp199); var tmp200 any; var root_1447 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_1448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1447, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1449 lang.IFn; if linked_1448 == nil { ifn_1449 = lang.IFn_Cast(root_1447) } else { ifn_1449 = nil }; var arg_1450 any = seq_1716000136__32; if linked_1448 == nil { tmp200 = ifn_1449.Invoke_O__O(arg_1450) } else { tmp200 = linked_1448.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1447, arg_1450) }; seq_1716000136__27, chunk_1716000137__28, count_1716000138__29, i_1716000139__30 = tmp200, nil, 0, 0; continue L13 } } }
//line :84:1
															break L13 } } else {

																var tmp201 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp202 any; var root_1451 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_1452 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1451, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1453 lang.IFn; if linked_1452 == nil { ifn_1453 = lang.IFn_Cast(root_1451) } else { ifn_1453 = nil }; var arg_1454 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1455 any = A_arbace_j2g_jrt_A_const_42; var arg_1456 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_1457 any; var root_1458 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1458, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1460 lang.IFn; if linked_1459 == nil { ifn_1460 = lang.IFn_Cast(root_1458) } else { ifn_1460 = nil }; var arg_1461 any = tg__25_4; if linked_1459 == nil { arg_1457 = ifn_1460.Invoke_O__O(arg_1461) } else { arg_1457 = linked_1459.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1458, arg_1461) }; if linked_1452 == nil { tmp202 = ifn_1453.Invoke_O_O_O_O__O(arg_1454, arg_1455, arg_1456, arg_1457) } else { tmp202 = linked_1452.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1451, arg_1454, arg_1455, arg_1456, arg_1457) }; jrt.NN(tmp201).Reset_O__O(tmp202)
//line :84:1
																var temp__1927000414__auto____27_2 any; var root_1391 any = A_arbace_j2g_jrt_A_const_69.GetRawRoot__O(); var linked_1392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1391, A_arbace_j2g_jrt_define_name_A_fn_class); var ifn_1393 lang.IFn


																if linked_1392 == nil { ifn_1393 = lang.IFn_Cast(root_1391) } else { ifn_1393 = nil }; var arg_1394 any = init__26_2; if linked_1392 == nil { temp__1927000414__auto____27_2 = ifn_1393.Invoke_O__O(arg_1394) } else { temp__1927000414__auto____27_2 = linked_1392.(*A_arbace_j2g_jrt_define_name_A).Invoke_O_O__O(root_1391, arg_1394) }; if jrt.J2g_Truth(temp__1927000414__auto____27_2) { var map__1716000140__28 any = temp__1927000414__auto____27_2; var map__1716000140__29 any; if lang.ISeq_InstanceOf(map__1716000140__28) { var tmp203 any; var root_1395 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_1396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1395, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1397 lang.IFn; if linked_1396 == nil { ifn_1397 = lang.IFn_Cast(root_1395) } else { ifn_1397 = nil }; var arg_1398 any = map__1716000140__28; if linked_1396 == nil { tmp203 = ifn_1397.Invoke_O__O(arg_1398) } else { tmp203 = linked_1396.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1395, arg_1398) }; if jrt.J2g_Truth(tmp203) { var tmp204 any; var root_1399 any = A_arbace_j2g_jrt_A_const_70.GetRawRoot__O(); var linked_1400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1399, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1401 lang.IFn; if linked_1400 == nil { ifn_1401 = lang.IFn_Cast(root_1399) } else { ifn_1401 = nil }; var arg_1402 any = map__1716000140__28; if linked_1400 == nil { tmp204 = ifn_1401.Invoke_O__O(arg_1402) } else { tmp204 = linked_1400.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1399, arg_1402) }; map__1716000140__29 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp204)).Ref() } else { var tmp205 any; var root_1403 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1403, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1405 lang.IFn; if linked_1404 == nil { ifn_1405 = lang.IFn_Cast(root_1403) } else { ifn_1405 = nil }; var arg_1406 any = map__1716000140__28; if linked_1404 == nil { tmp205 = ifn_1405.Invoke_O__O(arg_1406) } else { tmp205 = linked_1404.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1403, arg_1406) }; if jrt.J2g_Truth(tmp205) { var root_1407 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1407, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1409 lang.IFn; if linked_1408 == nil { ifn_1409 = lang.IFn_Cast(root_1407) } else { ifn_1409 = nil }; var arg_1410 any = map__1716000140__28; if linked_1408 == nil { map__1716000140__29 = ifn_1409.Invoke_O__O(arg_1410) } else { map__1716000140__29 = linked_1408.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1407, arg_1410) } } else { map__1716000140__29 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000140__29 = map__1716000140__28 }; var n__30_2 any = lang.RT_Get_O_O__O_NoInit(map__1716000140__29, A_arbace_j2g_jrt_A_const_34); var tmp206 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp207 any; var root_1411 any = A_arbace_j2g_jrt_A_const_56.GetRawRoot__O(); var linked_1412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1411, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1413 lang.IFn
																	if linked_1412 == nil { ifn_1413 = lang.IFn_Cast(root_1411) } else { ifn_1413 = nil }; var arg_1414 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1415 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_jrt_A_const_43, n__30_2); var arg_1416 any; var root_1417 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1417, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1419 lang.IFn; if linked_1418 == nil { ifn_1419 = lang.IFn_Cast(root_1417) } else { ifn_1419 = nil }; var arg_1420 any = tg__25_4; if linked_1418 == nil { arg_1416 = ifn_1419.Invoke_O__O(arg_1420) } else { arg_1416 = linked_1418.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1417, arg_1420) }; if linked_1412 == nil { tmp207 = ifn_1413.Invoke_O_O_O__O(arg_1414, arg_1415, arg_1416) } else { tmp207 = linked_1412.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1411, arg_1414, arg_1415, arg_1416) }; jrt.NN(tmp206).Reset_O__O(tmp207) } }
//line :83:1
													seq_1716000129__20, chunk_1716000130__21, count_1716000131__22, i_1716000132__23 = seq_1716000129__20, chunk_1716000130__21, count_1716000131__22, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000132__23); continue L12 } else { var temp__1927000414__auto____24_3 any; var root_1281 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1281, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1283 lang.IFn; if linked_1282 == nil { ifn_1283 = lang.IFn_Cast(root_1281) } else { ifn_1283 = nil }; var arg_1284 any = seq_1716000129__20; if linked_1282 == nil { temp__1927000414__auto____24_3 = ifn_1283.Invoke_O__O(arg_1284) } else { temp__1927000414__auto____24_3 = linked_1282.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1281, arg_1284) }; if jrt.J2g_Truth(temp__1927000414__auto____24_3) { var seq_1716000129__25 any = temp__1927000414__auto____24_3; var tmp208 any; var root_1285 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_1286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1285, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1287 lang.IFn; if linked_1286 == nil { ifn_1287 = lang.IFn_Cast(root_1285) } else { ifn_1287 = nil }; var arg_1288 any = seq_1716000129__25; if linked_1286 == nil { tmp208 = ifn_1287.Invoke_O__O(arg_1288) } else { tmp208 = linked_1286.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1285, arg_1288) }; if jrt.J2g_Truth(tmp208) { var c__1927000678__auto____26_3 any; var root_1289 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1291 lang.IFn; if linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = seq_1716000129__25; if linked_1290 == nil { c__1927000678__auto____26_3 = ifn_1291.Invoke_O__O(arg_1292) } else { c__1927000678__auto____26_3 = linked_1290.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1289, arg_1292) }; var tmp209 any; var root_1462 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_1463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1462, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1464 lang.IFn; if linked_1463 == nil { ifn_1464 = lang.IFn_Cast(root_1462) } else { ifn_1464 = nil }; var arg_1465 any = seq_1716000129__25; if linked_1463 == nil { tmp209 = ifn_1464.Invoke_O__O(arg_1465) } else { tmp209 = linked_1463.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1462, arg_1465) }; seq_1716000129__20, chunk_1716000130__21, count_1716000131__22, i_1716000132__23 = tmp209, c__1927000678__auto____26_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____26_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L12 } else { var vec__1716000142__26 any; var root_1293 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1293, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1295 lang.IFn; if linked_1294 == nil { ifn_1295 = lang.IFn_Cast(root_1293) } else { ifn_1295 = nil }; var arg_1296 any = seq_1716000129__25; if linked_1294 == nil { vec__1716000142__26 = ifn_1295.Invoke_O__O(arg_1296) } else { vec__1716000142__26 = linked_1294.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1293, arg_1296) }; var tg__27_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000142__26, lang.RT_IntCast_J__I_NoInit(0), nil); var init__28 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000142__26, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp210 any; var and__1927000168__auto____29_3 any; var root_1466 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_1467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1466, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1468 lang.IFn
														if linked_1467 == nil { ifn_1468 = lang.IFn_Cast(root_1466) } else { ifn_1468 = nil }; var arg_1469 any = tg__27_2; if linked_1467 == nil { and__1927000168__auto____29_3 = ifn_1468.Invoke_O__O(arg_1469) } else { and__1927000168__auto____29_3 = linked_1467.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1466, arg_1469) }; if jrt.J2g_Truth(and__1927000168__auto____29_3) { var tmp211 any = A_arbace_j2g_jrt_A_const_71; var tmp212 any; var root_1470 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1470, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1472 lang.IFn; if linked_1471 == nil { ifn_1472 = lang.IFn_Cast(root_1470) } else { ifn_1472 = nil }; var arg_1473 any = tg__27_2; if linked_1471 == nil { tmp212 = ifn_1472.Invoke_O__O(arg_1473) } else { tmp212 = linked_1471.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1470, arg_1473) }; tmp210 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp211, tmp212)).Ref() } else { tmp210 = and__1927000168__auto____29_3 }; if jrt.J2g_Truth(tmp210) { var seq_1716000145__29 any; var root_1474 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1474, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1476 lang.IFn
															if linked_1475 == nil { ifn_1476 = lang.IFn_Cast(root_1474) } else { ifn_1476 = nil }; var arg_1477 any; var root_1478 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_1479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1478, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1480 lang.IFn; if linked_1479 == nil { ifn_1480 = lang.IFn_Cast(root_1478) } else { ifn_1480 = nil }; var arg_1481 any = tg__27_2; if linked_1479 == nil { arg_1477 = ifn_1480.Invoke_O__O(arg_1481) } else { arg_1477 = linked_1479.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1478, arg_1481) }; if linked_1475 == nil { seq_1716000145__29 = ifn_1476.Invoke_O__O(arg_1477) } else { seq_1716000145__29 = linked_1475.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1474, arg_1477) }
//line :84:1
															var chunk_1716000146__30 any; var count_1716000147__31 int64 = 0; var i_1716000148__32 int64 = 0; L14: for {
																if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000148__32, count_1716000147__31) { var s__33_3 any = lang.Indexed_Cast(chunk_1716000146__30).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000148__32)); var tmp213 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp214 any; var root_1528 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_1529 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1528, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1530 lang.IFn; if linked_1529 == nil { ifn_1530 = lang.IFn_Cast(root_1528) } else { ifn_1530 = nil }; var arg_1531 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1532 any = A_arbace_j2g_jrt_A_const_42; var arg_1533 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_1534 any; var root_1535 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1535, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1537 lang.IFn; if linked_1536 == nil { ifn_1537 = lang.IFn_Cast(root_1535) } else { ifn_1537 = nil }; var arg_1538 any = s__33_3; if linked_1536 == nil { arg_1534 = ifn_1537.Invoke_O__O(arg_1538) } else { arg_1534 = linked_1536.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1535, arg_1538) }; if linked_1529 == nil { tmp214 = ifn_1530.Invoke_O_O_O_O__O(arg_1531, arg_1532, arg_1533, arg_1534) } else { tmp214 = linked_1529.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1528, arg_1531, arg_1532, arg_1533, arg_1534) }; jrt.NN(tmp213).Reset_O__O(tmp214); seq_1716000145__29, chunk_1716000146__30, count_1716000147__31, i_1716000148__32 = seq_1716000145__29, chunk_1716000146__30, count_1716000147__31, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000148__32); continue L14 } else { var temp__1927000414__auto____33 any; var root_1482 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1482, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1484 lang.IFn; if linked_1483 == nil { ifn_1484 = lang.IFn_Cast(root_1482) } else { ifn_1484 = nil }; var arg_1485 any = seq_1716000145__29; if linked_1483 == nil { temp__1927000414__auto____33 = ifn_1484.Invoke_O__O(arg_1485) } else { temp__1927000414__auto____33 = linked_1483.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1482, arg_1485) }; if jrt.J2g_Truth(temp__1927000414__auto____33) { var seq_1716000145__34 any = temp__1927000414__auto____33; var tmp215 any; var root_1486 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_1487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1486, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1488 lang.IFn; if linked_1487 == nil { ifn_1488 = lang.IFn_Cast(root_1486) } else { ifn_1488 = nil }; var arg_1489 any = seq_1716000145__34; if linked_1487 == nil { tmp215 = ifn_1488.Invoke_O__O(arg_1489) } else { tmp215 = linked_1487.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1486, arg_1489) }; if jrt.J2g_Truth(tmp215) { var c__1927000678__auto____35 any; var root_1490 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_1491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1490, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1492 lang.IFn; if linked_1491 == nil { ifn_1492 = lang.IFn_Cast(root_1490) } else { ifn_1492 = nil }; var arg_1493 any = seq_1716000145__34; if linked_1491 == nil { c__1927000678__auto____35 = ifn_1492.Invoke_O__O(arg_1493) } else { c__1927000678__auto____35 = linked_1491.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1490, arg_1493) }; var tmp216 any; var root_1539 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_1540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1539, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1541 lang.IFn; if linked_1540 == nil { ifn_1541 = lang.IFn_Cast(root_1539) } else { ifn_1541 = nil }; var arg_1542 any = seq_1716000145__34; if linked_1540 == nil { tmp216 = ifn_1541.Invoke_O__O(arg_1542) } else { tmp216 = linked_1540.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1539, arg_1542) }; seq_1716000145__29, chunk_1716000146__30, count_1716000147__31, i_1716000148__32 = tmp216, c__1927000678__auto____35, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____35))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L14 } else { var s__35 any; var root_1494 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1494, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1496 lang.IFn; if linked_1495 == nil { ifn_1496 = lang.IFn_Cast(root_1494) } else { ifn_1496 = nil }; var arg_1497 any = seq_1716000145__34; if linked_1495 == nil { s__35 = ifn_1496.Invoke_O__O(arg_1497) } else { s__35 = linked_1495.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1494, arg_1497) }; var tmp217 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp218 any; var root_1543 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_1544 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1543, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1545 lang.IFn; if linked_1544 == nil { ifn_1545 = lang.IFn_Cast(root_1543) } else { ifn_1545 = nil }; var arg_1546 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1547 any = A_arbace_j2g_jrt_A_const_42; var arg_1548 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_1549 any; var root_1550 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1550, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1552 lang.IFn; if linked_1551 == nil { ifn_1552 = lang.IFn_Cast(root_1550) } else { ifn_1552 = nil }; var arg_1553 any = s__35; if linked_1551 == nil { arg_1549 = ifn_1552.Invoke_O__O(arg_1553) } else { arg_1549 = linked_1551.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1550, arg_1553) }; if linked_1544 == nil { tmp218 = ifn_1545.Invoke_O_O_O_O__O(arg_1546, arg_1547, arg_1548, arg_1549) } else { tmp218 = linked_1544.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1543, arg_1546, arg_1547, arg_1548, arg_1549) }; jrt.NN(tmp217).Reset_O__O(tmp218); var tmp219 any; var root_1554 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_1555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1554, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1556 lang.IFn; if linked_1555 == nil { ifn_1556 = lang.IFn_Cast(root_1554) } else { ifn_1556 = nil }; var arg_1557 any = seq_1716000145__34; if linked_1555 == nil { tmp219 = ifn_1556.Invoke_O__O(arg_1557) } else { tmp219 = linked_1555.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1554, arg_1557) }; seq_1716000145__29, chunk_1716000146__30, count_1716000147__31, i_1716000148__32 = tmp219, nil, 0, 0; continue L14 } } }
//line :84:1
																break L14 } } else {

																	var tmp220 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp221 any; var root_1558 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_1559 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1558, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1560 lang.IFn; if linked_1559 == nil { ifn_1560 = lang.IFn_Cast(root_1558) } else { ifn_1560 = nil }; var arg_1561 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1562 any = A_arbace_j2g_jrt_A_const_42; var arg_1563 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_1564 any; var root_1565 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1565, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1567 lang.IFn; if linked_1566 == nil { ifn_1567 = lang.IFn_Cast(root_1565) } else { ifn_1567 = nil }; var arg_1568 any = tg__27_2; if linked_1566 == nil { arg_1564 = ifn_1567.Invoke_O__O(arg_1568) } else { arg_1564 = linked_1566.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1565, arg_1568) }; if linked_1559 == nil { tmp221 = ifn_1560.Invoke_O_O_O_O__O(arg_1561, arg_1562, arg_1563, arg_1564) } else { tmp221 = linked_1559.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1558, arg_1561, arg_1562, arg_1563, arg_1564) }; jrt.NN(tmp220).Reset_O__O(tmp221)
//line :84:1
																	var temp__1927000414__auto____29_2 any; var root_1498 any = A_arbace_j2g_jrt_A_const_69.GetRawRoot__O(); var linked_1499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1498, A_arbace_j2g_jrt_define_name_A_fn_class); var ifn_1500 lang.IFn


																	if linked_1499 == nil { ifn_1500 = lang.IFn_Cast(root_1498) } else { ifn_1500 = nil }; var arg_1501 any = init__28; if linked_1499 == nil { temp__1927000414__auto____29_2 = ifn_1500.Invoke_O__O(arg_1501) } else { temp__1927000414__auto____29_2 = linked_1499.(*A_arbace_j2g_jrt_define_name_A).Invoke_O_O__O(root_1498, arg_1501) }; if jrt.J2g_Truth(temp__1927000414__auto____29_2) { var map__1716000149__30 any = temp__1927000414__auto____29_2; var map__1716000149__31 any; if lang.ISeq_InstanceOf(map__1716000149__30) { var tmp222 any; var root_1502 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_1503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1502, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1504 lang.IFn; if linked_1503 == nil { ifn_1504 = lang.IFn_Cast(root_1502) } else { ifn_1504 = nil }; var arg_1505 any = map__1716000149__30; if linked_1503 == nil { tmp222 = ifn_1504.Invoke_O__O(arg_1505) } else { tmp222 = linked_1503.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1502, arg_1505) }; if jrt.J2g_Truth(tmp222) { var tmp223 any; var root_1506 any = A_arbace_j2g_jrt_A_const_70.GetRawRoot__O(); var linked_1507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1506, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1508 lang.IFn; if linked_1507 == nil { ifn_1508 = lang.IFn_Cast(root_1506) } else { ifn_1508 = nil }; var arg_1509 any = map__1716000149__30; if linked_1507 == nil { tmp223 = ifn_1508.Invoke_O__O(arg_1509) } else { tmp223 = linked_1507.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1506, arg_1509) }; map__1716000149__31 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp223)).Ref() } else { var tmp224 any; var root_1510 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1510, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1512 lang.IFn; if linked_1511 == nil { ifn_1512 = lang.IFn_Cast(root_1510) } else { ifn_1512 = nil }; var arg_1513 any = map__1716000149__30; if linked_1511 == nil { tmp224 = ifn_1512.Invoke_O__O(arg_1513) } else { tmp224 = linked_1511.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1510, arg_1513) }; if jrt.J2g_Truth(tmp224) { var root_1514 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1514, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1516 lang.IFn; if linked_1515 == nil { ifn_1516 = lang.IFn_Cast(root_1514) } else { ifn_1516 = nil }; var arg_1517 any = map__1716000149__30; if linked_1515 == nil { map__1716000149__31 = ifn_1516.Invoke_O__O(arg_1517) } else { map__1716000149__31 = linked_1515.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1514, arg_1517) } } else { map__1716000149__31 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000149__31 = map__1716000149__30 }; var n__32 any = lang.RT_Get_O_O__O_NoInit(map__1716000149__31, A_arbace_j2g_jrt_A_const_34); var tmp225 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp226 any; var root_1518 any = A_arbace_j2g_jrt_A_const_56.GetRawRoot__O(); var linked_1519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1518, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1520 lang.IFn
																		if linked_1519 == nil { ifn_1520 = lang.IFn_Cast(root_1518) } else { ifn_1520 = nil }; var arg_1521 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1522 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_jrt_A_const_43, n__32); var arg_1523 any; var root_1524 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1524, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1526 lang.IFn; if linked_1525 == nil { ifn_1526 = lang.IFn_Cast(root_1524) } else { ifn_1526 = nil }; var arg_1527 any = tg__27_2; if linked_1525 == nil { arg_1523 = ifn_1526.Invoke_O__O(arg_1527) } else { arg_1523 = linked_1525.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1524, arg_1527) }; if linked_1519 == nil { tmp226 = ifn_1520.Invoke_O_O_O__O(arg_1521, arg_1522, arg_1523) } else { tmp226 = linked_1519.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1518, arg_1521, arg_1522, arg_1523) }; jrt.NN(tmp225).Reset_O__O(tmp226) } }
//line :83:1
														var tmp227 any; var root_1569 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_1570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1569, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1571 lang.IFn; if linked_1570 == nil { ifn_1571 = lang.IFn_Cast(root_1569) } else { ifn_1571 = nil }; var arg_1572 any = seq_1716000129__25; if linked_1570 == nil { tmp227 = ifn_1571.Invoke_O__O(arg_1572) } else { tmp227 = linked_1570.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1569, arg_1572) }; seq_1716000129__20, chunk_1716000130__21, count_1716000131__22, i_1716000132__23 = tmp227, nil, 0, 0; continue L12 } } }
//line :82:1
												break L12 } } else { var vec__1716000151__20 any = more__19_5; var tg__21 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000151__20, lang.RT_IntCast_J__I_NoInit(0), nil); var init__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000151__20, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp228 any; var and__1927000168__auto____23 any; var root_1297 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_1298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1297, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1299 lang.IFn







													if linked_1298 == nil { ifn_1299 = lang.IFn_Cast(root_1297) } else { ifn_1299 = nil }; var arg_1300 any = tg__21; if linked_1298 == nil { and__1927000168__auto____23 = ifn_1299.Invoke_O__O(arg_1300) } else { and__1927000168__auto____23 = linked_1298.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1297, arg_1300) }; if jrt.J2g_Truth(and__1927000168__auto____23) { var tmp229 any = A_arbace_j2g_jrt_A_const_68; var tmp230 any; var root_1301 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1301, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1303 lang.IFn; if linked_1302 == nil { ifn_1303 = lang.IFn_Cast(root_1301) } else { ifn_1303 = nil }; var arg_1304 any = tg__21; if linked_1302 == nil { tmp230 = ifn_1303.Invoke_O__O(arg_1304) } else { tmp230 = linked_1302.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1301, arg_1304) }; tmp228 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp229, tmp230)).Ref() } else { tmp228 = and__1927000168__auto____23 }; if jrt.J2g_Truth(tmp228) { var seq_1716000154__23 any; var root_1305 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1305, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1307 lang.IFn
														if linked_1306 == nil { ifn_1307 = lang.IFn_Cast(root_1305) } else { ifn_1307 = nil }; var arg_1308 any; var root_1309 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_1310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1309, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1311 lang.IFn; if linked_1310 == nil { ifn_1311 = lang.IFn_Cast(root_1309) } else { ifn_1311 = nil }; var arg_1312 any = tg__21; if linked_1310 == nil { arg_1308 = ifn_1311.Invoke_O__O(arg_1312) } else { arg_1308 = linked_1310.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1309, arg_1312) }; if linked_1306 == nil { seq_1716000154__23 = ifn_1307.Invoke_O__O(arg_1308) } else { seq_1716000154__23 = linked_1306.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1305, arg_1308) }
//line :90:1
														var chunk_1716000155__24 any; var count_1716000156__25 int64 = 0; var i_1716000157__26 int64 = 0; L15: for {
															if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000157__26, count_1716000156__25) { var s__27_2 any = lang.Indexed_Cast(chunk_1716000155__24).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000157__26)); var tmp231 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp232 any; var root_1573 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_1574 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1573, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1575 lang.IFn; if linked_1574 == nil { ifn_1575 = lang.IFn_Cast(root_1573) } else { ifn_1575 = nil }; var arg_1576 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1577 any = A_arbace_j2g_jrt_A_const_42; var arg_1578 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_1579 any; var root_1580 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1580, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1582 lang.IFn; if linked_1581 == nil { ifn_1582 = lang.IFn_Cast(root_1580) } else { ifn_1582 = nil }; var arg_1583 any = s__27_2; if linked_1581 == nil { arg_1579 = ifn_1582.Invoke_O__O(arg_1583) } else { arg_1579 = linked_1581.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1580, arg_1583) }; if linked_1574 == nil { tmp232 = ifn_1575.Invoke_O_O_O_O__O(arg_1576, arg_1577, arg_1578, arg_1579) } else { tmp232 = linked_1574.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1573, arg_1576, arg_1577, arg_1578, arg_1579) }; jrt.NN(tmp231).Reset_O__O(tmp232); seq_1716000154__23, chunk_1716000155__24, count_1716000156__25, i_1716000157__26 = seq_1716000154__23, chunk_1716000155__24, count_1716000156__25, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000157__26); continue L15 } else { var temp__1927000414__auto____27_3 any; var root_1313 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1313, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1315 lang.IFn; if linked_1314 == nil { ifn_1315 = lang.IFn_Cast(root_1313) } else { ifn_1315 = nil }; var arg_1316 any = seq_1716000154__23; if linked_1314 == nil { temp__1927000414__auto____27_3 = ifn_1315.Invoke_O__O(arg_1316) } else { temp__1927000414__auto____27_3 = linked_1314.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1313, arg_1316) }; if jrt.J2g_Truth(temp__1927000414__auto____27_3) { var seq_1716000154__28 any = temp__1927000414__auto____27_3; var tmp233 any; var root_1317 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_1318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1317, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1319 lang.IFn; if linked_1318 == nil { ifn_1319 = lang.IFn_Cast(root_1317) } else { ifn_1319 = nil }; var arg_1320 any = seq_1716000154__28; if linked_1318 == nil { tmp233 = ifn_1319.Invoke_O__O(arg_1320) } else { tmp233 = linked_1318.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1317, arg_1320) }; if jrt.J2g_Truth(tmp233) { var c__1927000678__auto____29 any; var root_1321 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_1322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1321, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1323 lang.IFn; if linked_1322 == nil { ifn_1323 = lang.IFn_Cast(root_1321) } else { ifn_1323 = nil }; var arg_1324 any = seq_1716000154__28; if linked_1322 == nil { c__1927000678__auto____29 = ifn_1323.Invoke_O__O(arg_1324) } else { c__1927000678__auto____29 = linked_1322.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1321, arg_1324) }; var tmp234 any; var root_1584 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_1585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1584, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1586 lang.IFn; if linked_1585 == nil { ifn_1586 = lang.IFn_Cast(root_1584) } else { ifn_1586 = nil }; var arg_1587 any = seq_1716000154__28; if linked_1585 == nil { tmp234 = ifn_1586.Invoke_O__O(arg_1587) } else { tmp234 = linked_1585.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1584, arg_1587) }; seq_1716000154__23, chunk_1716000155__24, count_1716000156__25, i_1716000157__26 = tmp234, c__1927000678__auto____29, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____29))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L15 } else { var s__29_2 any; var root_1325 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1325, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1327 lang.IFn; if linked_1326 == nil { ifn_1327 = lang.IFn_Cast(root_1325) } else { ifn_1327 = nil }; var arg_1328 any = seq_1716000154__28; if linked_1326 == nil { s__29_2 = ifn_1327.Invoke_O__O(arg_1328) } else { s__29_2 = linked_1326.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1325, arg_1328) }; var tmp235 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp236 any; var root_1588 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_1589 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1588, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1590 lang.IFn; if linked_1589 == nil { ifn_1590 = lang.IFn_Cast(root_1588) } else { ifn_1590 = nil }; var arg_1591 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1592 any = A_arbace_j2g_jrt_A_const_42; var arg_1593 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_1594 any; var root_1595 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1595, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1597 lang.IFn; if linked_1596 == nil { ifn_1597 = lang.IFn_Cast(root_1595) } else { ifn_1597 = nil }; var arg_1598 any = s__29_2; if linked_1596 == nil { arg_1594 = ifn_1597.Invoke_O__O(arg_1598) } else { arg_1594 = linked_1596.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1595, arg_1598) }; if linked_1589 == nil { tmp236 = ifn_1590.Invoke_O_O_O_O__O(arg_1591, arg_1592, arg_1593, arg_1594) } else { tmp236 = linked_1589.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1588, arg_1591, arg_1592, arg_1593, arg_1594) }; jrt.NN(tmp235).Reset_O__O(tmp236); var tmp237 any; var root_1599 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_1600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1599, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1601 lang.IFn; if linked_1600 == nil { ifn_1601 = lang.IFn_Cast(root_1599) } else { ifn_1601 = nil }; var arg_1602 any = seq_1716000154__28; if linked_1600 == nil { tmp237 = ifn_1601.Invoke_O__O(arg_1602) } else { tmp237 = linked_1600.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1599, arg_1602) }; seq_1716000154__23, chunk_1716000155__24, count_1716000156__25, i_1716000157__26 = tmp237, nil, 0, 0; continue L15 } } }
//line :90:1
															break L15 } } else {

																var tmp238 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp239 any; var root_1603 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_1604 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1603, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1605 lang.IFn; if linked_1604 == nil { ifn_1605 = lang.IFn_Cast(root_1603) } else { ifn_1605 = nil }; var arg_1606 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1607 any = A_arbace_j2g_jrt_A_const_42; var arg_1608 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_1609 any; var root_1610 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1610, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1612 lang.IFn; if linked_1611 == nil { ifn_1612 = lang.IFn_Cast(root_1610) } else { ifn_1612 = nil }; var arg_1613 any = tg__21; if linked_1611 == nil { arg_1609 = ifn_1612.Invoke_O__O(arg_1613) } else { arg_1609 = linked_1611.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1610, arg_1613) }; if linked_1604 == nil { tmp239 = ifn_1605.Invoke_O_O_O_O__O(arg_1606, arg_1607, arg_1608, arg_1609) } else { tmp239 = linked_1604.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1603, arg_1606, arg_1607, arg_1608, arg_1609) }; jrt.NN(tmp238).Reset_O__O(tmp239)
//line :90:1
																var temp__1927000414__auto____23 any; var root_1329 any = A_arbace_j2g_jrt_A_const_69.GetRawRoot__O(); var linked_1330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1329, A_arbace_j2g_jrt_define_name_A_fn_class); var ifn_1331 lang.IFn


																if linked_1330 == nil { ifn_1331 = lang.IFn_Cast(root_1329) } else { ifn_1331 = nil }; var arg_1332 any = init__22; if linked_1330 == nil { temp__1927000414__auto____23 = ifn_1331.Invoke_O__O(arg_1332) } else { temp__1927000414__auto____23 = linked_1330.(*A_arbace_j2g_jrt_define_name_A).Invoke_O_O__O(root_1329, arg_1332) }; if jrt.J2g_Truth(temp__1927000414__auto____23) { var map__1716000158__24 any = temp__1927000414__auto____23; var map__1716000158__25 any; if lang.ISeq_InstanceOf(map__1716000158__24) { var tmp240 any; var root_1333 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_1334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1333, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1335 lang.IFn; if linked_1334 == nil { ifn_1335 = lang.IFn_Cast(root_1333) } else { ifn_1335 = nil }; var arg_1336 any = map__1716000158__24; if linked_1334 == nil { tmp240 = ifn_1335.Invoke_O__O(arg_1336) } else { tmp240 = linked_1334.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1333, arg_1336) }; if jrt.J2g_Truth(tmp240) { var tmp241 any; var root_1337 any = A_arbace_j2g_jrt_A_const_70.GetRawRoot__O(); var linked_1338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1337, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1339 lang.IFn; if linked_1338 == nil { ifn_1339 = lang.IFn_Cast(root_1337) } else { ifn_1339 = nil }; var arg_1340 any = map__1716000158__24; if linked_1338 == nil { tmp241 = ifn_1339.Invoke_O__O(arg_1340) } else { tmp241 = linked_1338.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1337, arg_1340) }; map__1716000158__25 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp241)).Ref() } else { var tmp242 any; var root_1341 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1341, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1343 lang.IFn; if linked_1342 == nil { ifn_1343 = lang.IFn_Cast(root_1341) } else { ifn_1343 = nil }; var arg_1344 any = map__1716000158__24; if linked_1342 == nil { tmp242 = ifn_1343.Invoke_O__O(arg_1344) } else { tmp242 = linked_1342.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1341, arg_1344) }; if jrt.J2g_Truth(tmp242) { var root_1345 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1345, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1347 lang.IFn; if linked_1346 == nil { ifn_1347 = lang.IFn_Cast(root_1345) } else { ifn_1347 = nil }; var arg_1348 any = map__1716000158__24; if linked_1346 == nil { map__1716000158__25 = ifn_1347.Invoke_O__O(arg_1348) } else { map__1716000158__25 = linked_1346.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1345, arg_1348) } } else { map__1716000158__25 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000158__25 = map__1716000158__24 }; var n__26 any = lang.RT_Get_O_O__O_NoInit(map__1716000158__25, A_arbace_j2g_jrt_A_const_34); var tmp243 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp244 any; var root_1349 any = A_arbace_j2g_jrt_A_const_56.GetRawRoot__O(); var linked_1350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1349, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1351 lang.IFn
																	if linked_1350 == nil { ifn_1351 = lang.IFn_Cast(root_1349) } else { ifn_1351 = nil }; var arg_1352 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1353 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_jrt_A_const_43, n__26); var arg_1354 any; var root_1355 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1355, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1357 lang.IFn; if linked_1356 == nil { ifn_1357 = lang.IFn_Cast(root_1355) } else { ifn_1357 = nil }; var arg_1358 any = tg__21; if linked_1356 == nil { arg_1354 = ifn_1357.Invoke_O__O(arg_1358) } else { arg_1354 = linked_1356.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1355, arg_1358) }; if linked_1350 == nil { tmp244 = ifn_1351.Invoke_O_O_O__O(arg_1352, arg_1353, arg_1354) } else { tmp244 = linked_1350.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1349, arg_1352, arg_1353, arg_1354) }; jrt.NN(tmp243).Reset_O__O(tmp244) } } }
//line :54:1
										break L9 }; default:}}
//line :51:1
						var tmp245 any; var root_1614 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_1615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1614, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1616 lang.IFn; if linked_1615 == nil { ifn_1616 = lang.IFn_Cast(root_1614) } else { ifn_1616 = nil }; var arg_1617 any = seq_1716000022__9; if linked_1615 == nil { tmp245 = ifn_1616.Invoke_O__O(arg_1617) } else { tmp245 = linked_1615.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1614, arg_1617) }; seq_1716000022__4, chunk_1716000023__5, count_1716000024__6, i_1716000025__7 = tmp245, nil, 0, 0; continue L1 } else { var tmp246 any; var root_1618 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_1619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1618, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1620 lang.IFn; if linked_1619 == nil { ifn_1620 = lang.IFn_Cast(root_1618) } else { ifn_1620 = nil }; var arg_1621 any = seq_1716000022__9; if linked_1619 == nil { tmp246 = ifn_1620.Invoke_O__O(arg_1621) } else { tmp246 = linked_1619.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1618, arg_1621) }; seq_1716000022__4, chunk_1716000023__5, count_1716000024__6, i_1716000025__7 = tmp246, nil, 0, 0; continue L1 } } } }
//line :45:1
		break L1 }; var root_190 any =



	A_arbace_j2g_jrt_A_const_8.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = acc__3; if linked_191 == nil { return ifn_192.Invoke_O__O(arg_193) } else { return linked_191.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_190, arg_193) } }





















































func A_arbace_j2g_jrt_interface_elems_A_New() *A_arbace_j2g_jrt_interface_elems_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_interface_elems_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_j2g_jrt_interface_elems_A) Ctor() {}
//line :103:1
func (t *A_arbace_j2g_jrt_interface_elems_A) Invoke_O_O__O(self, tf__0 any) any { var elems__2 any; var root_1622 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_1623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1622, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1624 lang.IFn; if


	linked_1623 == nil { ifn_1624 = lang.IFn_Cast(root_1622) } else { ifn_1624 = nil }; var arg_1625 any = tf__0; if linked_1623 == nil { elems__2 = ifn_1624.Invoke_O__O(arg_1625) } else { elems__2 = linked_1623.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1622, arg_1625) }; var tmp1 any = A_arbace_j2g_jrt_A_const_40; var tmp2 any; var root_1626 any = /*line :103:1*/A_arbace_j2g_jrt_A_const_72.GetRawRoot__O(); var linked_1627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1626, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1628 lang.IFn; if



	linked_1627 == nil { ifn_1628 = lang.IFn_Cast(root_1626) } else { ifn_1628 = nil }; var arg_1629 any; var iter__1927001039__auto____3 any; var fnbody__1761 any = A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A_New(); var tmp3 *jrt.Class; var fncls__1760 *jrt.Class = A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A_fn_class; if fncls__1760 == nil { var fncls__1760d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, nil); A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A_fn_class = fncls__1760d; tmp3 = fncls__1760d } else { tmp3 = fncls__1760 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1761, tmp3, nil); arg_1629 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(elems__2); if linked_1627 == nil { tmp2 = ifn_1628.Invoke_O__O(arg_1629) } else { tmp2 = linked_1627.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1626, arg_1629) }; var tmp4 any = tmp2; var tmp5 any = A_arbace_j2g_jrt_A_const_79; var tmp6 any; var root_1762 any = /*line :103:1*/A_arbace_j2g_jrt_A_const_80.GetRawRoot__O(); var linked_1763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1762, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1764 lang.IFn; if





	linked_1763 == nil { ifn_1764 = lang.IFn_Cast(root_1762) } else { ifn_1764 = nil }; var arg_1765 any; var iter__1927001039__auto____3_2 any; var fnbody__1847 any = A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A_New(); var tmp7 *jrt.Class; var fncls__1846 *jrt.Class = A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A_fn_class; if fncls__1846 == nil { var fncls__1846d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, nil); A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A_fn_class = fncls__1846d; tmp7 = fncls__1846d } else { tmp7 = fncls__1846 }; iter__1927001039__auto____3_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1847, tmp7, nil); arg_1765 = lang.IFn_Cast(iter__1927001039__auto____3_2).Invoke_O__O(elems__2); if linked_1763 == nil { tmp6 = ifn_1764.Invoke_O__O(arg_1765) } else { tmp6 = linked_1763.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1762, arg_1765) }; return /*line :103:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp4, tmp5, tmp6)) }



func A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A_New() *A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A) Ctor() {}
//line :107:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A) Invoke_O_O__O(self, s__1716000162__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1759 any = A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A_New_O_O(s__1716000162__1, self); var tmp2 *jrt.Class; var fncls__1758 *jrt.Class = A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A_fn_class; if fncls__1758 == nil { var fncls__1758d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, fnbody__1759); A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A_fn_class = fncls__1758d; tmp2 = fncls__1758d } else { tmp2 = fncls__1758 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1759, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :107:1
func A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A_New_O_O(p0, p1 any) *A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A{}; t.Ctor_O_O(p0, p1); return t }
//line :107:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A) Ctor_O_O(c__s__1716000162, c__iter__1716000161 any) { t.F_s__1716000162 = c__s__1716000162; t.F_iter__1716000161 = c__iter__1716000161 }
//line :107:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A) Invoke_O__O(self any) any { { var s__1716000162__1 any; var t_ any = t.F_s__1716000162; t.F_s__1716000162 = nil; s__1716000162__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1630 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1630, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1632 lang.IFn; if linked_1631 == nil { ifn_1632 = lang.IFn_Cast(root_1630) } else { ifn_1632 = nil }; var arg_1633 any = s__1716000162__1; if linked_1631 == nil { temp__1927000414__auto____2 = ifn_1632.Invoke_O__O(arg_1633) } else { temp__1927000414__auto____2 = linked_1631.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1630, arg_1633) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1716000162__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1634 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_1635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1634, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1636 lang.IFn; if linked_1635 == nil { ifn_1636 = lang.IFn_Cast(root_1634) } else { ifn_1636 = nil }; var arg_1637 any = s__1716000162__3; if linked_1635 == nil { tmp1 = ifn_1636.Invoke_O__O(arg_1637) } else { tmp1 = linked_1635.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1634, arg_1637) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1638 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_1639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1638, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1640 lang.IFn; if linked_1639 == nil { ifn_1640 = lang.IFn_Cast(root_1638) } else { ifn_1640 = nil }; var arg_1641 any = s__1716000162__3; if linked_1639 == nil { c__1927001037__auto____4 = ifn_1640.Invoke_O__O(arg_1641) } else { c__1927001037__auto____4 = linked_1639.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1638, arg_1641) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1716000164__6 any; var root_1642 any = A_arbace_j2g_jrt_A_const_73.GetRawRoot__O(); var linked_1643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1642, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1644 lang.IFn; if linked_1643 == nil { ifn_1644 = lang.IFn_Cast(root_1642) } else { ifn_1644 = nil }; var arg_1645 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1643 == nil { b__1716000164__6 = ifn_1644.Invoke_O__O(arg_1645) } else { b__1716000164__6 = linked_1643.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1642, arg_1645) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1685 any = A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A_New_O_I_O(b__1716000164__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1684 *jrt.Class = A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A_fn_class; if fncls__1684 == nil { var fncls__1684d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, fnbody__1685); A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A_fn_class = fncls__1684d; tmp3 = fncls__1684d } else { tmp3 = fncls__1684 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1685, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1686 any = A_arbace_j2g_jrt_A_const_76.GetRawRoot__O(); var linked_1687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1686, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1688 lang.IFn; if linked_1687 == nil { ifn_1688 = lang.IFn_Cast(root_1686) } else { ifn_1688 = nil }; var arg_1689 any; var root_1691 any = A_arbace_j2g_jrt_A_const_77.GetRawRoot__O(); var linked_1692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1691, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1693 lang.IFn; if linked_1692 == nil { ifn_1693 = lang.IFn_Cast(root_1691) } else { ifn_1693 = nil }; var arg_1694 any = b__1716000164__6; if linked_1692 == nil { arg_1689 = ifn_1693.Invoke_O__O(arg_1694) } else { arg_1689 = linked_1692.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1691, arg_1694) }; var arg_1690 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1716000161); var tmp5 any; var root_1695 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_1696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1695, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1697 lang.IFn; if linked_1696 == nil { ifn_1697 = lang.IFn_Cast(root_1695) } else { ifn_1697 = nil }; var arg_1698 any = s__1716000162__3; if linked_1696 == nil { tmp5 = ifn_1697.Invoke_O__O(arg_1698) } else { tmp5 = linked_1696.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1695, arg_1698) }; arg_1690 = tmp4.Invoke_O__O(tmp5); if linked_1687 == nil { return ifn_1688.Invoke_O_O__O(arg_1689, arg_1690) } else { return linked_1687.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1686, arg_1689, arg_1690) } } else { var root_1699 any = A_arbace_j2g_jrt_A_const_76.GetRawRoot__O(); var linked_1700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1699, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1701 lang.IFn; if linked_1700 == nil { ifn_1701 = lang.IFn_Cast(root_1699) } else { ifn_1701 = nil }; var arg_1702 any; var root_1704 any = A_arbace_j2g_jrt_A_const_77.GetRawRoot__O(); var linked_1705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1704, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1706 lang.IFn; if linked_1705 == nil { ifn_1706 = lang.IFn_Cast(root_1704) } else { ifn_1706 = nil }; var arg_1707 any = b__1716000164__6; if linked_1705 == nil { arg_1702 = ifn_1706.Invoke_O__O(arg_1707) } else { arg_1702 = linked_1705.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1704, arg_1707) }; var arg_1703 any; if linked_1700 == nil { return ifn_1701.Invoke_O_O__O(arg_1702, arg_1703) } else { return linked_1700.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1699, arg_1702, arg_1703) } } } else { var e__4 any; var root_1708 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1708, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1710 lang.IFn; if linked_1709 == nil { ifn_1710 = lang.IFn_Cast(root_1708) } else { ifn_1710 = nil }; var arg_1711 any = s__1716000162__3; if linked_1709 == nil { e__4 = ifn_1710.Invoke_O__O(arg_1711) } else { e__4 = linked_1709.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1708, arg_1711) }; var tmp6 any; var and__1927000168__auto____5 any; var root_1712 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_1713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1712, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1714 lang.IFn; if linked_1713 == nil { ifn_1714 = lang.IFn_Cast(root_1712) } else { ifn_1714 = nil }; var arg_1715 any = e__4; if linked_1713 == nil { and__1927000168__auto____5 = ifn_1714.Invoke_O__O(arg_1715) } else { and__1927000168__auto____5 = linked_1713.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1712, arg_1715) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1716 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_1717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1716, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1718 lang.IFn; if linked_1717 == nil { ifn_1718 = lang.IFn_Cast(root_1716) } else { ifn_1718 = nil }; var arg_1719 any; var root_1720 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1720, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1722 lang.IFn; if linked_1721 == nil { ifn_1722 = lang.IFn_Cast(root_1720) } else { ifn_1722 = nil }; var arg_1723 any = e__4; if linked_1721 == nil { arg_1719 = ifn_1722.Invoke_O__O(arg_1723) } else { arg_1719 = linked_1721.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1720, arg_1723) }; if linked_1717 == nil { and__1927000168__auto____6 = ifn_1718.Invoke_O__O(arg_1719) } else { and__1927000168__auto____6 = linked_1717.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1716, arg_1719) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1724 any = A_arbace_j2g_jrt_A_const_55.GetRawRoot__O(); var linked_1725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1724, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1726 lang.IFn; if linked_1725 == nil { ifn_1726 = lang.IFn_Cast(root_1724) } else { ifn_1726 = nil }; var arg_1727 any; var root_1728 any = A_arbace_j2g_jrt_A_const_22.GetRawRoot__O(); var linked_1729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1728, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1730 lang.IFn; if linked_1729 == nil { ifn_1730 = lang.IFn_Cast(root_1728) } else { ifn_1730 = nil }; var arg_1731 any; var root_1732 any = A_arbace_j2g_jrt_A_const_74.GetRawRoot__O(); var linked_1733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1732, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1734 lang.IFn; if linked_1733 == nil { ifn_1734 = lang.IFn_Cast(root_1732) } else { ifn_1734 = nil }; var arg_1735 any = A_arbace_j2g_jrt_A_const_23.GetRawRoot__O(); var arg_1736 any = e__4; if linked_1733 == nil { arg_1731 = ifn_1734.Invoke_O_O__O(arg_1735, arg_1736) } else { arg_1731 = linked_1733.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1732, arg_1735, arg_1736) }; if linked_1729 == nil { arg_1727 = ifn_1730.Invoke_O__O(arg_1731) } else { arg_1727 = linked_1729.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1728, arg_1731) }; if linked_1725 == nil { tmp6 = ifn_1726.Invoke_O__O(arg_1727) } else { tmp6 = linked_1725.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1724, arg_1727) } } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp6) { var root_1737 any = A_arbace_j2g_jrt_A_const_78.GetRawRoot__O(); var linked_1738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1737, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1739 lang.IFn; if linked_1738 == nil { ifn_1739 = lang.IFn_Cast(root_1737) } else { ifn_1739 = nil }; var arg_1740 any; var root_1742 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1742, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1744 lang.IFn
															if linked_1743 == nil { ifn_1744 = lang.IFn_Cast(root_1742) } else { ifn_1744 = nil }; var arg_1745 any; var root_1746 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1746, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1748 lang.IFn; if linked_1747 == nil { ifn_1748 = lang.IFn_Cast(root_1746) } else { ifn_1748 = nil }; var arg_1749 any = e__4; if linked_1747 == nil { arg_1745 = ifn_1748.Invoke_O__O(arg_1749) } else { arg_1745 = linked_1747.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1746, arg_1749) }; if linked_1743 == nil { arg_1740 = ifn_1744.Invoke_O__O(arg_1745) } else { arg_1740 = linked_1743.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1742, arg_1745) }
//line :107:1
	var arg_1741 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1716000161); var tmp8 any; var root_1750 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_1751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1750, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1752 lang.IFn; if linked_1751 == nil { ifn_1752 = lang.IFn_Cast(root_1750) } else { ifn_1752 = nil }; var arg_1753 any = s__1716000162__3; if linked_1751 == nil { tmp8 = ifn_1752.Invoke_O__O(arg_1753) } else { tmp8 = linked_1751.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1750, arg_1753) }; arg_1741 = tmp7.Invoke_O__O(tmp8); if linked_1738 == nil { return ifn_1739.Invoke_O_O__O(arg_1740, arg_1741) } else { return linked_1738.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1737, arg_1740, arg_1741) } } else { var tmp9 any; var root_1754 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1754, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1756 lang.IFn; if linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var arg_1757 any = s__1716000162__3; if linked_1755 == nil { tmp9 = ifn_1756.Invoke_O__O(arg_1757) } else { tmp9 = linked_1755.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1754, arg_1757) }; s__1716000162__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :107:1
func A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :107:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A) Ctor_O_I_O(c__b__1716000164 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1716000164 = c__b__1716000164; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :107:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A) Invoke_O__O(self any) any { { var i__1716000163__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1716000163__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1716000163__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_1646 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_1647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1646, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1648 lang.IFn; if linked_1647 == nil { ifn_1648 = lang.IFn_Cast(root_1646) } else { ifn_1648 = nil }; var arg_1649 any = e__2; if linked_1647 == nil { and__1927000168__auto____3 = ifn_1648.Invoke_O__O(arg_1649) } else { and__1927000168__auto____3 = linked_1647.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1646, arg_1649) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_1650 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_1651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1650, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1652 lang.IFn; if linked_1651 == nil { ifn_1652 = lang.IFn_Cast(root_1650) } else { ifn_1652 = nil }; var arg_1653 any; var root_1654 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1654, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1656 lang.IFn; if linked_1655 == nil { ifn_1656 = lang.IFn_Cast(root_1654) } else { ifn_1656 = nil }; var arg_1657 any = e__2; if linked_1655 == nil { arg_1653 = ifn_1656.Invoke_O__O(arg_1657) } else { arg_1653 = linked_1655.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1654, arg_1657) }; if linked_1651 == nil { and__1927000168__auto____4 = ifn_1652.Invoke_O__O(arg_1653) } else { and__1927000168__auto____4 = linked_1651.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1650, arg_1653) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_1658 any = A_arbace_j2g_jrt_A_const_55.GetRawRoot__O(); var linked_1659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1658, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1660 lang.IFn; if linked_1659 == nil { ifn_1660 = lang.IFn_Cast(root_1658) } else { ifn_1660 = nil }; var arg_1661 any; var root_1662 any = A_arbace_j2g_jrt_A_const_22.GetRawRoot__O(); var linked_1663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1662, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1664 lang.IFn; if linked_1663 == nil { ifn_1664 = lang.IFn_Cast(root_1662) } else { ifn_1664 = nil }; var arg_1665 any; var root_1666 any = A_arbace_j2g_jrt_A_const_74.GetRawRoot__O(); var linked_1667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1666, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1668 lang.IFn; if linked_1667 == nil { ifn_1668 = lang.IFn_Cast(root_1666) } else { ifn_1668 = nil }; var arg_1669 any = A_arbace_j2g_jrt_A_const_23.GetRawRoot__O(); var arg_1670 any = e__2; if linked_1667 == nil { arg_1665 = ifn_1668.Invoke_O_O__O(arg_1669, arg_1670) } else { arg_1665 = linked_1667.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1666, arg_1669, arg_1670) }; if linked_1663 == nil { arg_1661 = ifn_1664.Invoke_O__O(arg_1665) } else { arg_1661 = linked_1663.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1662, arg_1665) }; if linked_1659 == nil { tmp2 = ifn_1660.Invoke_O__O(arg_1661) } else { tmp2 = linked_1659.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1658, arg_1661) } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp2) { var root_1671 any = A_arbace_j2g_jrt_A_const_75.GetRawRoot__O(); var linked_1672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1671, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1673 lang.IFn; if linked_1672 == nil { ifn_1673 = lang.IFn_Cast(root_1671) } else { ifn_1673 = nil }; var arg_1674 any = t.F_b__1716000164; var arg_1675 any; var root_1676 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1676, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1678 lang.IFn
																	if linked_1677 == nil { ifn_1678 = lang.IFn_Cast(root_1676) } else { ifn_1678 = nil }; var arg_1679 any; var root_1680 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1680, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1682 lang.IFn; if linked_1681 == nil { ifn_1682 = lang.IFn_Cast(root_1680) } else { ifn_1682 = nil }; var arg_1683 any = e__2; if linked_1681 == nil { arg_1679 = ifn_1682.Invoke_O__O(arg_1683) } else { arg_1679 = linked_1681.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1680, arg_1683) }; if linked_1677 == nil { arg_1675 = ifn_1678.Invoke_O__O(arg_1679) } else { arg_1675 = linked_1677.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1676, arg_1679) }
//line :107:1
	if linked_1672 == nil { ifn_1673.Invoke_O_O__O(arg_1674, arg_1675) } else { linked_1672.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1671, arg_1674, arg_1675) }; i__1716000163__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000163__1); continue L1 } else { i__1716000163__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000163__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A_New() *A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A) Ctor() {}
//line :109:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A) Invoke_O_O__O(self, s__1716000172__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1845 any = A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A_New_O_O(s__1716000172__1, self); var tmp2 *jrt.Class; var fncls__1844 *jrt.Class = A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A_fn_class; if fncls__1844 == nil { var fncls__1844d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, fnbody__1845); A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A_fn_class = fncls__1844d; tmp2 = fncls__1844d } else { tmp2 = fncls__1844 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1845, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :109:1
func A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A_New_O_O(p0, p1 any) *A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A{}; t.Ctor_O_O(p0, p1); return t }
//line :109:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A) Ctor_O_O(c__s__1716000172, c__iter__1716000171 any) { t.F_s__1716000172 = c__s__1716000172; t.F_iter__1716000171 = c__iter__1716000171 }
//line :109:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A) Invoke_O__O(self any) any { { var s__1716000172__1 any; var t_ any = t.F_s__1716000172; t.F_s__1716000172 = nil; s__1716000172__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1766 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1766, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1768 lang.IFn; if linked_1767 == nil { ifn_1768 = lang.IFn_Cast(root_1766) } else { ifn_1768 = nil }; var arg_1769 any = s__1716000172__1; if linked_1767 == nil { temp__1927000414__auto____2 = ifn_1768.Invoke_O__O(arg_1769) } else { temp__1927000414__auto____2 = linked_1767.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1766, arg_1769) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1716000172__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1770 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_1771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1770, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1772 lang.IFn; if linked_1771 == nil { ifn_1772 = lang.IFn_Cast(root_1770) } else { ifn_1772 = nil }; var arg_1773 any = s__1716000172__3; if linked_1771 == nil { tmp1 = ifn_1772.Invoke_O__O(arg_1773) } else { tmp1 = linked_1771.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1770, arg_1773) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1774 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_1775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1774, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1776 lang.IFn; if linked_1775 == nil { ifn_1776 = lang.IFn_Cast(root_1774) } else { ifn_1776 = nil }; var arg_1777 any = s__1716000172__3; if linked_1775 == nil { c__1927001037__auto____4 = ifn_1776.Invoke_O__O(arg_1777) } else { c__1927001037__auto____4 = linked_1775.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1774, arg_1777) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1716000174__6 any; var root_1778 any = A_arbace_j2g_jrt_A_const_73.GetRawRoot__O(); var linked_1779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1778, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1780 lang.IFn; if linked_1779 == nil { ifn_1780 = lang.IFn_Cast(root_1778) } else { ifn_1780 = nil }; var arg_1781 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1779 == nil { b__1716000174__6 = ifn_1780.Invoke_O__O(arg_1781) } else { b__1716000174__6 = linked_1779.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1778, arg_1781) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1796 any = A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A_New_O_I_O(b__1716000174__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1795 *jrt.Class = A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A_fn_class; if fncls__1795 == nil { var fncls__1795d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, fnbody__1796); A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A_fn_class = fncls__1795d; tmp3 = fncls__1795d } else { tmp3 = fncls__1795 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1796, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1797 any = A_arbace_j2g_jrt_A_const_76.GetRawRoot__O(); var linked_1798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1797, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1799 lang.IFn; if linked_1798 == nil { ifn_1799 = lang.IFn_Cast(root_1797) } else { ifn_1799 = nil }; var arg_1800 any; var root_1802 any = A_arbace_j2g_jrt_A_const_77.GetRawRoot__O(); var linked_1803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1802, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1804 lang.IFn; if linked_1803 == nil { ifn_1804 = lang.IFn_Cast(root_1802) } else { ifn_1804 = nil }; var arg_1805 any = b__1716000174__6; if linked_1803 == nil { arg_1800 = ifn_1804.Invoke_O__O(arg_1805) } else { arg_1800 = linked_1803.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1802, arg_1805) }; var arg_1801 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1716000171); var tmp5 any; var root_1806 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_1807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1806, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1808 lang.IFn; if linked_1807 == nil { ifn_1808 = lang.IFn_Cast(root_1806) } else { ifn_1808 = nil }; var arg_1809 any = s__1716000172__3; if linked_1807 == nil { tmp5 = ifn_1808.Invoke_O__O(arg_1809) } else { tmp5 = linked_1807.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1806, arg_1809) }; arg_1801 = tmp4.Invoke_O__O(tmp5); if linked_1798 == nil { return ifn_1799.Invoke_O_O__O(arg_1800, arg_1801) } else { return linked_1798.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1797, arg_1800, arg_1801) } } else { var root_1810 any = A_arbace_j2g_jrt_A_const_76.GetRawRoot__O(); var linked_1811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1810, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1812 lang.IFn; if linked_1811 == nil { ifn_1812 = lang.IFn_Cast(root_1810) } else { ifn_1812 = nil }; var arg_1813 any; var root_1815 any = A_arbace_j2g_jrt_A_const_77.GetRawRoot__O(); var linked_1816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1815, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1817 lang.IFn; if linked_1816 == nil { ifn_1817 = lang.IFn_Cast(root_1815) } else { ifn_1817 = nil }; var arg_1818 any = b__1716000174__6; if linked_1816 == nil { arg_1813 = ifn_1817.Invoke_O__O(arg_1818) } else { arg_1813 = linked_1816.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1815, arg_1818) }; var arg_1814 any; if linked_1811 == nil { return ifn_1812.Invoke_O_O__O(arg_1813, arg_1814) } else { return linked_1811.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1810, arg_1813, arg_1814) } } } else { var e__4 any; var root_1819 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1819, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1821 lang.IFn; if linked_1820 == nil { ifn_1821 = lang.IFn_Cast(root_1819) } else { ifn_1821 = nil }; var arg_1822 any = s__1716000172__3; if linked_1820 == nil { e__4 = ifn_1821.Invoke_O__O(arg_1822) } else { e__4 = linked_1820.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1819, arg_1822) }; var tmp6 any; var root_1823 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_1824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1823, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1825 lang.IFn; if linked_1824 == nil { ifn_1825 = lang.IFn_Cast(root_1823) } else { ifn_1825 = nil }; var arg_1826 any = e__4; if linked_1824 == nil { tmp6 = ifn_1825.Invoke_O__O(arg_1826) } else { tmp6 = linked_1824.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1823, arg_1826) }; if jrt.J2g_Truth(tmp6) { var root_1827 any = A_arbace_j2g_jrt_A_const_78.GetRawRoot__O(); var linked_1828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1827, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1829 lang.IFn; if linked_1828 == nil { ifn_1829 = lang.IFn_Cast(root_1827) } else { ifn_1829 = nil }; var arg_1830 any; var root_1832 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1832, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1834 lang.IFn; if linked_1833 == nil { ifn_1834 = lang.IFn_Cast(root_1832) } else { ifn_1834 = nil }; var arg_1835 any = e__4; if linked_1833 == nil { arg_1830 = ifn_1834.Invoke_O__O(arg_1835) } else { arg_1830 = linked_1833.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1832, arg_1835) }; var arg_1831 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1716000171); var tmp8 any; var root_1836 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_1837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1836, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1838 lang.IFn; if linked_1837 == nil { ifn_1838 = lang.IFn_Cast(root_1836) } else { ifn_1838 = nil }; var arg_1839 any = s__1716000172__3; if linked_1837 == nil { tmp8 = ifn_1838.Invoke_O__O(arg_1839) } else { tmp8 = linked_1837.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1836, arg_1839) }; arg_1831 = tmp7.Invoke_O__O(tmp8); if linked_1828 == nil { return ifn_1829.Invoke_O_O__O(arg_1830, arg_1831) } else { return linked_1828.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1827, arg_1830, arg_1831) } } else { var tmp9 any; var root_1840 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_1841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1840, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1842 lang.IFn; if linked_1841 == nil { ifn_1842 = lang.IFn_Cast(root_1840) } else { ifn_1842 = nil }; var arg_1843 any = s__1716000172__3; if linked_1841 == nil { tmp9 = ifn_1842.Invoke_O__O(arg_1843) } else { tmp9 = linked_1841.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1840, arg_1843) }; s__1716000172__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :109:1
func A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :109:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A) Ctor_O_I_O(c__b__1716000174 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1716000174 = c__b__1716000174; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :109:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A) Invoke_O__O(self any) any { { var i__1716000173__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1716000173__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1716000173__1)); var tmp2 any; var root_1782 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_1783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1782, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1784 lang.IFn; if linked_1783 == nil { ifn_1784 = lang.IFn_Cast(root_1782) } else { ifn_1784 = nil }; var arg_1785 any = e__2; if linked_1783 == nil { tmp2 = ifn_1784.Invoke_O__O(arg_1785) } else { tmp2 = linked_1783.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1782, arg_1785) }; if jrt.J2g_Truth(tmp2) { var root_1786 any = A_arbace_j2g_jrt_A_const_75.GetRawRoot__O(); var linked_1787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1786, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1788 lang.IFn; if linked_1787 == nil { ifn_1788 = lang.IFn_Cast(root_1786) } else { ifn_1788 = nil }; var arg_1789 any = t.F_b__1716000174; var arg_1790 any; var root_1791 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1791, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1793 lang.IFn; if linked_1792 == nil { ifn_1793 = lang.IFn_Cast(root_1791) } else { ifn_1793 = nil }; var arg_1794 any = e__2; if linked_1792 == nil { arg_1790 = ifn_1793.Invoke_O__O(arg_1794) } else { arg_1790 = linked_1792.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1791, arg_1794) }; if linked_1787 == nil { ifn_1788.Invoke_O_O__O(arg_1789, arg_1790) } else { linked_1787.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1786, arg_1789, arg_1790) }; i__1716000173__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000173__1); continue L1 } else { i__1716000173__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000173__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_jrt_struct_embed_A_New() *A_arbace_j2g_jrt_struct_embed_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_struct_embed_A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_j2g_jrt_struct_embed_A) Ctor() {}
//line :111:1
func (t *A_arbace_j2g_jrt_struct_embed_A) Invoke_O_O__O(self, tf__0 any) any { var f__2 any; var root_1848 any = A_arbace_j2g_jrt_A_const_22.GetRawRoot__O(); var linked_1849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1848, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1850 lang.IFn; if


	linked_1849 == nil { ifn_1850 = lang.IFn_Cast(root_1848) } else { ifn_1850 = nil }; var arg_1851 any = tf__0; if linked_1849 == nil { f__2 = ifn_1850.Invoke_O__O(arg_1851) } else { f__2 = linked_1849.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1848, arg_1851) }; var tmp1 any; var and__1927000168__auto____3 any = f__2; if
	jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_1852 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_1853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1852, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1854 lang.IFn; if linked_1853 == nil { ifn_1854 = lang.IFn_Cast(root_1852) } else { ifn_1854 = nil }; var arg_1855 any = f__2; if linked_1853 == nil { and__1927000168__auto____4 = ifn_1854.Invoke_O__O(arg_1855) } else { and__1927000168__auto____4 = linked_1853.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1852, arg_1855) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp2 any; var root_1856 any = A_arbace_j2g_jrt_A_const_19.GetRawRoot__O(); var linked_1857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1856, A_arbace_j2g_jrt_tag_of_A_fn_class); var ifn_1858 lang.IFn; if linked_1857 == nil { ifn_1858 = lang.IFn_Cast(root_1856) } else { ifn_1858 = nil }; var arg_1859 any = f__2; if linked_1857 == nil { tmp2 = ifn_1858.Invoke_O__O(arg_1859) } else { tmp2 = linked_1857.(*A_arbace_j2g_jrt_tag_of_A).Invoke_O_O__O(root_1856, arg_1859) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp2, nil)).Ref() } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { var root_1860 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1860, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1862 lang.IFn; if linked_1861 == nil { ifn_1862 = lang.IFn_Cast(root_1860) } else { ifn_1862 = nil }; var arg_1863 any = f__2; if linked_1861 == nil { return ifn_1862.Invoke_O__O(arg_1863) } else { return linked_1861.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1860, arg_1863) } } else { return nil } }

func A_arbace_j2g_jrt_other_system_QMARK__A_New() *A_arbace_j2g_jrt_other_system_QMARK__A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_other_system_QMARK__A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_j2g_jrt_other_system_QMARK__A) Ctor() {}
//line :117:1
func (t *A_arbace_j2g_jrt_other_system_QMARK__A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 any; var root_1864 any = A_arbace_j2g_jrt_A_const_81.GetRawRoot__O(); var linked_1865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1864, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1866 lang.IFn; if linked_1865 == nil { ifn_1866 = lang.IFn_Cast(root_1864) } else { ifn_1866 = nil }; var arg_1867 any = A_arbace_j2g_jrt_A_const_82; var arg_1868 any = n__0; if linked_1865 == nil { tmp1 = ifn_1866.Invoke_O_O__O(arg_1867, arg_1868) } else { tmp1 = linked_1865.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1864, arg_1867, arg_1868) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}
func A_arbace_j2g_jrt_scan_A_New() *A_arbace_j2g_jrt_scan_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_A{}; t.Ctor(); return t }
//line :123:1
func (t *A_arbace_j2g_jrt_scan_A) Ctor() {}
//line :123:1
func (t *A_arbace_j2g_jrt_scan_A) Invoke_O_O__O(self, dir__0 any) any { var files__2 any; var root_1869 any = A_arbace_j2g_jrt_A_const_83.GetRawRoot__O(); var linked_1870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1869, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1871 lang.IFn; if










	linked_1870 == nil { ifn_1871 = lang.IFn_Cast(root_1869) } else { ifn_1871 = nil }; var arg_1872 any; var fnbody__1875 any = A_arbace_j2g_jrt_scan_fn__1716000186_A_New(); var tmp1 *jrt.Class; var fncls__1874 *jrt.Class = A_arbace_j2g_jrt_scan_fn__1716000186_A_fn_class; if fncls__1874 == nil { var fncls__1874d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, nil); A_arbace_j2g_jrt_scan_fn__1716000186_A_fn_class = fncls__1874d; tmp1 = fncls__1874d } else { tmp1 = fncls__1874 }; arg_1872 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1875, tmp1, nil); var arg_1873 any; var root_1876 any = A_arbace_j2g_jrt_A_const_84.GetRawRoot__O(); var linked_1877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1876, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1878 lang.IFn; if /*line :131:1*/ linked_1877 == nil { ifn_1878 = lang.IFn_Cast(root_1876) } else { ifn_1878 = nil }; var arg_1879 any; var fnbody__1904 any = A_arbace_j2g_jrt_scan_fn__1716000188_A_New(); var tmp2 *jrt.Class; var fncls__1903 *jrt.Class = A_arbace_j2g_jrt_scan_fn__1716000188_A_fn_class; if fncls__1903 == nil { var fncls__1903d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, nil); A_arbace_j2g_jrt_scan_fn__1716000188_A_fn_class = fncls__1903d; tmp2 = fncls__1903d } else { tmp2 = fncls__1903 }; arg_1879 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1904, tmp2, nil); var arg_1880 any; var tmp3 any; var root_1905 any = A_arbace_j2g_jrt_A_const_88.GetRawRoot__O(); var linked_1906 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1905, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1907 lang.IFn; if /*line :130:1*/ linked_1906 == nil { ifn_1907 = lang.IFn_Cast(root_1905) } else { ifn_1907 = nil }; var arg_1908 any = dir__0; if linked_1906 == nil { tmp3 = ifn_1907.Invoke_O__O(arg_1908) } else { tmp3 = linked_1906.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_1905, arg_1908) }; arg_1880 = jrt.File_Cast(tmp3).ListFiles__File1().Ref(); if
	linked_1877 == nil { arg_1873 = ifn_1878.Invoke_O_O__O(arg_1879, arg_1880) } else { arg_1873 = linked_1877.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1876, arg_1879, arg_1880) }; if


	linked_1870 == nil { files__2 = ifn_1871.Invoke_O_O__O(arg_1872, arg_1873) } else { files__2 = linked_1870.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1869, arg_1872, arg_1873) }; var scans__3 any; var root_1909 any = /*line :123:1*/A_arbace_j2g_jrt_A_const_89.GetRawRoot__O(); var linked_1910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1909, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1911 lang.IFn; if











	linked_1910 == nil { ifn_1911 = lang.IFn_Cast(root_1909) } else { ifn_1911 = nil }; var arg_1912 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_90.GetRawRoot__O()).Invoke__O(); var arg_1913 any; var iter__1927001039__auto____3 any; var fnbody__1986 any = A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A_New(); var tmp4 *jrt.Class; var fncls__1985 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A_fn_class; if fncls__1985 == nil { var fncls__1985d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, nil); A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A_fn_class = fncls__1985d; tmp4 = fncls__1985d } else { tmp4 = fncls__1985 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1986, tmp4, nil); arg_1913 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(files__2); if linked_1910 == nil { scans__3 = ifn_1911.Invoke_O_O__O(arg_1912, arg_1913) } else { scans__3 = linked_1910.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1909, arg_1912, arg_1913) }; var types__4 any; var root_1987 any = /*line :123:1*/A_arbace_j2g_jrt_A_const_28.GetRawRoot__O(); var linked_1988 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1987, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1989 lang.IFn; if












	linked_1988 == nil { ifn_1989 = lang.IFn_Cast(root_1987) } else { ifn_1989 = nil }; var arg_1990 any = A_arbace_j2g_jrt_A_const_92.GetRawRoot__O(); var arg_1991 any; var root_1992 any = A_arbace_j2g_jrt_A_const_93.GetRawRoot__O(); var linked_1993 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1992, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1994 lang.IFn; if linked_1993 == nil { ifn_1994 = lang.IFn_Cast(root_1992) } else { ifn_1994 = nil }; var arg_1995 any = A_arbace_j2g_jrt_A_const_39; var arg_1996 any; var root_1997 any = A_arbace_j2g_jrt_A_const_94.GetRawRoot__O(); var linked_1998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1997, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_1999 lang.IFn; if linked_1998 == nil { ifn_1999 = lang.IFn_Cast(root_1997) } else { ifn_1999 = nil }; var arg_2000 any = scans__3; if linked_1998 == nil { arg_1996 = ifn_1999.Invoke_O__O(arg_2000) } else { arg_1996 = linked_1998.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_1997, arg_2000) }; if linked_1993 == nil { arg_1991 = ifn_1994.Invoke_O_O__O(arg_1995, arg_1996) } else { arg_1991 = linked_1993.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1992, arg_1995, arg_1996) }; if linked_1988 == nil { types__4 = ifn_1989.Invoke_O_O__O(arg_1990, arg_1991) } else { types__4 = linked_1988.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1987, arg_1990, arg_1991) }; var methods__5 any; var root_2001 any = /*line :123:1*/A_arbace_j2g_jrt_A_const_28.GetRawRoot__O(); var linked_2002 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2001, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2003 lang.IFn; if













	linked_2002 == nil { ifn_2003 = lang.IFn_Cast(root_2001) } else { ifn_2003 = nil }; var arg_2004 any = A_arbace_j2g_jrt_A_const_95.GetRawRoot__O(); var arg_2005 any = A_arbace_j2g_jrt_A_const_89.GetRawRoot__O(); var arg_2006 any; var root_2007 any = A_arbace_j2g_jrt_A_const_93.GetRawRoot__O(); var linked_2008 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2007, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2009 lang.IFn; if linked_2008 == nil { ifn_2009 = lang.IFn_Cast(root_2007) } else { ifn_2009 = nil }; var arg_2010 any = A_arbace_j2g_jrt_A_const_40; var arg_2011 any; var root_2012 any = A_arbace_j2g_jrt_A_const_94.GetRawRoot__O(); var linked_2013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2012, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_2014 lang.IFn; if linked_2013 == nil { ifn_2014 = lang.IFn_Cast(root_2012) } else { ifn_2014 = nil }; var arg_2015 any = scans__3; if linked_2013 == nil { arg_2011 = ifn_2014.Invoke_O__O(arg_2015) } else { arg_2011 = linked_2013.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_2012, arg_2015) }; if linked_2008 == nil { arg_2006 = ifn_2009.Invoke_O_O__O(arg_2010, arg_2011) } else { arg_2006 = linked_2008.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2007, arg_2010, arg_2011) }; if linked_2002 == nil { methods__5 = ifn_2003.Invoke_O_O_O__O(arg_2004, arg_2005, arg_2006) } else { methods__5 = linked_2002.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_2001, arg_2004, arg_2005, arg_2006) }; var tmp5 any = A_arbace_j2g_jrt_A_const_96; var tmp6 any = A_arbace_j2g_jrt_A_const_39; var tmp7 any = A_arbace_j2g_jrt_A_const_40; var tmp8 any = A_arbace_j2g_jrt_A_const_41; var tmp9 any; var root_2016 any = /*line :123:1*/A_arbace_j2g_jrt_A_const_28.GetRawRoot__O(); var linked_2017 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2016, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2018 lang.IFn; if

















	linked_2017 == nil { ifn_2018 = lang.IFn_Cast(root_2016) } else { ifn_2018 = nil }; var arg_2019 any = A_arbace_j2g_jrt_A_const_97.GetRawRoot__O(); var arg_2020 any; var root_2021 any = A_arbace_j2g_jrt_A_const_93.GetRawRoot__O(); var linked_2022 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2021, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2023 lang.IFn; if linked_2022 == nil { ifn_2023 = lang.IFn_Cast(root_2021) } else { ifn_2023 = nil }; var arg_2024 any = A_arbace_j2g_jrt_A_const_41; var arg_2025 any; var root_2026 any = A_arbace_j2g_jrt_A_const_94.GetRawRoot__O(); var linked_2027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2026, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_2028 lang.IFn; if linked_2027 == nil { ifn_2028 = lang.IFn_Cast(root_2026) } else { ifn_2028 = nil }; var arg_2029 any = scans__3; if linked_2027 == nil { arg_2025 = ifn_2028.Invoke_O__O(arg_2029) } else { arg_2025 = linked_2027.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_2026, arg_2029) }; if linked_2022 == nil { arg_2020 = ifn_2023.Invoke_O_O__O(arg_2024, arg_2025) } else { arg_2020 = linked_2022.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2021, arg_2024, arg_2025) }; if linked_2017 == nil { tmp9 = ifn_2018.Invoke_O_O__O(arg_2019, arg_2020) } else { tmp9 = linked_2017.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2016, arg_2019, arg_2020) }; var tmp10 any = tmp9; var tmp11 any = A_arbace_j2g_jrt_A_const_42; var tmp12 any; var root_2030 any = /*line :123:1*/A_arbace_j2g_jrt_A_const_28.GetRawRoot__O(); var linked_2031 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2030, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2032 lang.IFn; if


















	linked_2031 == nil { ifn_2032 = lang.IFn_Cast(root_2030) } else { ifn_2032 = nil }; var arg_2033 any = A_arbace_j2g_jrt_A_const_97.GetRawRoot__O(); var arg_2034 any; var root_2035 any = A_arbace_j2g_jrt_A_const_93.GetRawRoot__O(); var linked_2036 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2035, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2037 lang.IFn; if linked_2036 == nil { ifn_2037 = lang.IFn_Cast(root_2035) } else { ifn_2037 = nil }; var arg_2038 any = A_arbace_j2g_jrt_A_const_42; var arg_2039 any; var root_2040 any = A_arbace_j2g_jrt_A_const_94.GetRawRoot__O(); var linked_2041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2040, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_2042 lang.IFn; if linked_2041 == nil { ifn_2042 = lang.IFn_Cast(root_2040) } else { ifn_2042 = nil }; var arg_2043 any = scans__3; if linked_2041 == nil { arg_2039 = ifn_2042.Invoke_O__O(arg_2043) } else { arg_2039 = linked_2041.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_2040, arg_2043) }; if linked_2036 == nil { arg_2034 = ifn_2037.Invoke_O_O__O(arg_2038, arg_2039) } else { arg_2034 = linked_2036.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2035, arg_2038, arg_2039) }; if linked_2031 == nil { tmp12 = ifn_2032.Invoke_O_O__O(arg_2033, arg_2034) } else { tmp12 = linked_2031.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2030, arg_2033, arg_2034) }; var tmp13 any = tmp12; var tmp14 any = A_arbace_j2g_jrt_A_const_44; var tmp15 any; var root_2044 any = /*line :123:1*/A_arbace_j2g_jrt_A_const_28.GetRawRoot__O(); var linked_2045 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2044, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2046 lang.IFn; if



















	linked_2045 == nil { ifn_2046 = lang.IFn_Cast(root_2044) } else { ifn_2046 = nil }; var arg_2047 any = A_arbace_j2g_jrt_A_const_97.GetRawRoot__O(); var arg_2048 any; var root_2049 any = A_arbace_j2g_jrt_A_const_93.GetRawRoot__O(); var linked_2050 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2049, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2051 lang.IFn; if linked_2050 == nil { ifn_2051 = lang.IFn_Cast(root_2049) } else { ifn_2051 = nil }; var arg_2052 any = A_arbace_j2g_jrt_A_const_44; var arg_2053 any; var root_2054 any = A_arbace_j2g_jrt_A_const_94.GetRawRoot__O(); var linked_2055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2054, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_2056 lang.IFn; if linked_2055 == nil { ifn_2056 = lang.IFn_Cast(root_2054) } else { ifn_2056 = nil }; var arg_2057 any = scans__3; if linked_2055 == nil { arg_2053 = ifn_2056.Invoke_O__O(arg_2057) } else { arg_2053 = linked_2055.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_2054, arg_2057) }; if linked_2050 == nil { arg_2048 = ifn_2051.Invoke_O_O__O(arg_2052, arg_2053) } else { arg_2048 = linked_2050.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2049, arg_2052, arg_2053) }; if linked_2045 == nil { tmp15 = ifn_2046.Invoke_O_O__O(arg_2047, arg_2048) } else { tmp15 = linked_2045.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2044, arg_2047, arg_2048) }; var tmp16 any = tmp15; var tmp17 any = A_arbace_j2g_jrt_A_const_43; var tmp18 any; var root_2058 any = /*line :123:1*/A_arbace_j2g_jrt_A_const_89.GetRawRoot__O(); var linked_2059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2058, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2060 lang.IFn; if




















	linked_2059 == nil { ifn_2060 = lang.IFn_Cast(root_2058) } else { ifn_2060 = nil }; var arg_2061 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2062 any; var iter__1927001039__auto____6 any; var fnbody__2175 any = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A_New(); var tmp19 *jrt.Class; var fncls__2174 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A_fn_class; if fncls__2174 == nil { var fncls__2174d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, nil); A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A_fn_class = fncls__2174d; tmp19 = fncls__2174d } else { tmp19 = fncls__2174 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2175, tmp19, nil); arg_2062 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(scans__3); if linked_2059 == nil { tmp18 = ifn_2060.Invoke_O_O__O(arg_2061, arg_2062) } else { tmp18 = linked_2059.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2058, arg_2061, arg_2062) }; var tmp20 any = tmp18; var tmp21 any = A_arbace_j2g_jrt_A_const_106; var tmp22 any; var root_2176 any = /*line :123:1*/A_arbace_j2g_jrt_A_const_89.GetRawRoot__O(); var linked_2177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2176, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2178 lang.IFn; if
























	linked_2177 == nil { ifn_2178 = lang.IFn_Cast(root_2176) } else { ifn_2178 = nil }; var arg_2179 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2180 any; var iter__1927001039__auto____6_2 any; var fnbody__2286 any = A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A_New(); var tmp23 *jrt.Class; var fncls__2285 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A_fn_class; if fncls__2285 == nil { var fncls__2285d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, nil); A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A_fn_class = fncls__2285d; tmp23 = fncls__2285d } else { tmp23 = fncls__2285 }; iter__1927001039__auto____6_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2286, tmp23, nil); arg_2180 = lang.IFn_Cast(iter__1927001039__auto____6_2).Invoke_O__O(types__4); if linked_2177 == nil { tmp22 = ifn_2178.Invoke_O_O__O(arg_2179, arg_2180) } else { tmp22 = linked_2177.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2176, arg_2179, arg_2180) }; var tmp24 any = tmp22; var tmp25 any = A_arbace_j2g_jrt_A_const_79; var tmp26 any; var root_2287 any = /*line :123:1*/A_arbace_j2g_jrt_A_const_89.GetRawRoot__O(); var linked_2288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2287, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2289 lang.IFn; if


























	linked_2288 == nil { ifn_2289 = lang.IFn_Cast(root_2287) } else { ifn_2289 = nil }; var arg_2290 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2291 any; var iter__1927001039__auto____6_3 any; var fnbody__2401 any = A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A_New(); var tmp27 *jrt.Class; var fncls__2400 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A_fn_class; if fncls__2400 == nil { var fncls__2400d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, nil); A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A_fn_class = fncls__2400d; tmp27 = fncls__2400d } else { tmp27 = fncls__2400 }; iter__1927001039__auto____6_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2401, tmp27, nil); arg_2291 = lang.IFn_Cast(iter__1927001039__auto____6_3).Invoke_O__O(types__4); if linked_2288 == nil { tmp26 = ifn_2289.Invoke_O_O__O(arg_2290, arg_2291) } else { tmp26 = linked_2288.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2287, arg_2290, arg_2291) }; return /*line :123:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, scans__3, tmp6, types__4, tmp7, methods__5, tmp8, tmp10, tmp11, tmp13, tmp14, tmp16, tmp17, tmp20, tmp21, tmp24, tmp25, tmp26)) }







func A_arbace_j2g_jrt_scan_fn__1716000188_A_New() *A_arbace_j2g_jrt_scan_fn__1716000188_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_fn__1716000188_A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_j2g_jrt_scan_fn__1716000188_A) Ctor() {}
//line :131:1
func (t *A_arbace_j2g_jrt_scan_fn__1716000188_A) Invoke_O_O__O(self, p1__1716000184_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_1881 any = A_arbace_j2g_jrt_A_const_85.GetRawRoot__O(); var linked_1882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1881, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1883 lang.IFn; if linked_1882 == nil { ifn_1883 = lang.IFn_Cast(root_1881) } else { ifn_1883 = nil }; var arg_1884 any = jrt.File_Cast(p1__1716000184_SHARP___1).GetName__String().Ref(); var arg_1885 any = Lit_17; if linked_1882 == nil { and__1927000168__auto____2 = ifn_1883.Invoke_O_O__O(arg_1884, arg_1885) } else { and__1927000168__auto____2 = linked_1882.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1881, arg_1884, arg_1885) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_1886 any = A_arbace_j2g_jrt_A_const_86.GetRawRoot__O(); var linked_1887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1886, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1888 lang.IFn
													if linked_1887 == nil { ifn_1888 = lang.IFn_Cast(root_1886) } else { ifn_1888 = nil }; var arg_1889 any; var root_1890 any = A_arbace_j2g_jrt_A_const_85.GetRawRoot__O(); var linked_1891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1890, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1892 lang.IFn; if linked_1891 == nil { ifn_1892 = lang.IFn_Cast(root_1890) } else { ifn_1892 = nil }; var arg_1893 any = jrt.File_Cast(p1__1716000184_SHARP___1).GetName__String().Ref(); var arg_1894 any = Lit_18; if linked_1891 == nil { arg_1889 = ifn_1892.Invoke_O_O__O(arg_1893, arg_1894) } else { arg_1889 = linked_1891.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1890, arg_1893, arg_1894) }; if linked_1887 == nil { and__1927000168__auto____3 = ifn_1888.Invoke_O__O(arg_1889) } else { and__1927000168__auto____3 = linked_1887.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1886, arg_1889) }
//line :131:1
	if jrt.J2g_Truth(and__1927000168__auto____3) {

		var root_1895 any = A_arbace_j2g_jrt_A_const_86.GetRawRoot__O(); var linked_1896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1895, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1897 lang.IFn; if linked_1896 == nil { ifn_1897 = lang.IFn_Cast(root_1895) } else { ifn_1897 = nil }; var arg_1898 any; var root_1899 any = A_arbace_j2g_jrt_A_const_87.GetRawRoot__O(); var linked_1900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1899, A_arbace_j2g_jrt_other_system_QMARK__A_fn_class); var ifn_1901 lang.IFn; if linked_1900 == nil { ifn_1901 = lang.IFn_Cast(root_1899) } else { ifn_1901 = nil }; var arg_1902 any = jrt.File_Cast(p1__1716000184_SHARP___1).GetName__String().Ref(); if linked_1900 == nil { arg_1898 = ifn_1901.Invoke_O__O(arg_1902) } else { arg_1898 = linked_1900.(*A_arbace_j2g_jrt_other_system_QMARK__A).Invoke_O_O__O(root_1899, arg_1902) }; if linked_1896 == nil { return ifn_1897.Invoke_O__O(arg_1898) } else { return linked_1896.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1895, arg_1898) } } else {
//line :131:1
			return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }


func A_arbace_j2g_jrt_scan_fn__1716000186_A_New() *A_arbace_j2g_jrt_scan_fn__1716000186_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_fn__1716000186_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_j2g_jrt_scan_fn__1716000186_A) Ctor() {}
//line :134:1
func (t *A_arbace_j2g_jrt_scan_fn__1716000186_A) Invoke_O_O__O(self, p1__1716000185_SHARP___1 any) any { return jrt.File_Cast(p1__1716000185_SHARP___1).GetName__String().Ref() }
func A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A_New() *A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A) Ctor() {}
//line :135:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A) Invoke_O_O__O(self, s__1716000191__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1984 any = A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A_New_O_O(s__1716000191__1, self); var tmp2 *jrt.Class; var fncls__1983 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A_fn_class; if fncls__1983 == nil { var fncls__1983d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, fnbody__1984); A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A_fn_class = fncls__1983d; tmp2 = fncls__1983d } else { tmp2 = fncls__1983 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1984, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :135:1
func A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A_New_O_O(p0, p1 any) *A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A{}; t.Ctor_O_O(p0, p1); return t }
//line :135:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A) Ctor_O_O(c__s__1716000191, c__iter__1716000190 any) { t.F_s__1716000191 = c__s__1716000191; t.F_iter__1716000190 = c__iter__1716000190 }
//line :135:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A) Invoke_O__O(self any) any { { var s__1716000191__1 any; var t_ any = t.F_s__1716000191; t.F_s__1716000191 = nil; s__1716000191__1 = t_; for { var temp__1927000414__auto____2 any; var root_1917 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1917, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1919 lang.IFn; if linked_1918 == nil { ifn_1919 = lang.IFn_Cast(root_1917) } else { ifn_1919 = nil }; var arg_1920 any = s__1716000191__1; if linked_1918 == nil { temp__1927000414__auto____2 = ifn_1919.Invoke_O__O(arg_1920) } else { temp__1927000414__auto____2 = linked_1918.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1917, arg_1920) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1716000191__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1921 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_1922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1921, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1923 lang.IFn; if linked_1922 == nil { ifn_1923 = lang.IFn_Cast(root_1921) } else { ifn_1923 = nil }; var arg_1924 any = s__1716000191__3; if linked_1922 == nil { tmp1 = ifn_1923.Invoke_O__O(arg_1924) } else { tmp1 = linked_1922.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1921, arg_1924) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1925 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_1926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1925, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1927 lang.IFn; if linked_1926 == nil { ifn_1927 = lang.IFn_Cast(root_1925) } else { ifn_1927 = nil }; var arg_1928 any = s__1716000191__3; if linked_1926 == nil { c__1927001037__auto____4 = ifn_1927.Invoke_O__O(arg_1928) } else { c__1927001037__auto____4 = linked_1926.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1925, arg_1928) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1716000193__6 any; var root_1929 any = A_arbace_j2g_jrt_A_const_73.GetRawRoot__O(); var linked_1930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1929, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1931 lang.IFn; if linked_1930 == nil { ifn_1931 = lang.IFn_Cast(root_1929) } else { ifn_1931 = nil }; var arg_1932 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1930 == nil { b__1716000193__6 = ifn_1931.Invoke_O__O(arg_1932) } else { b__1716000193__6 = linked_1930.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1929, arg_1932) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1943 any = A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A_New_O_I_O(b__1716000193__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1942 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A_fn_class; if fncls__1942 == nil { var fncls__1942d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, fnbody__1943); A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A_fn_class = fncls__1942d; tmp3 = fncls__1942d } else { tmp3 = fncls__1942 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1943, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1944 any = A_arbace_j2g_jrt_A_const_76.GetRawRoot__O(); var linked_1945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1944, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1946 lang.IFn; if linked_1945 == nil { ifn_1946 = lang.IFn_Cast(root_1944) } else { ifn_1946 = nil }; var arg_1947 any; var root_1949 any = A_arbace_j2g_jrt_A_const_77.GetRawRoot__O(); var linked_1950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1949, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1951 lang.IFn; if linked_1950 == nil { ifn_1951 = lang.IFn_Cast(root_1949) } else { ifn_1951 = nil }; var arg_1952 any = b__1716000193__6; if linked_1950 == nil { arg_1947 = ifn_1951.Invoke_O__O(arg_1952) } else { arg_1947 = linked_1950.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1949, arg_1952) }; var arg_1948 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1716000190); var tmp5 any; var root_1953 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_1954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1953, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1955 lang.IFn; if linked_1954 == nil { ifn_1955 = lang.IFn_Cast(root_1953) } else { ifn_1955 = nil }; var arg_1956 any = s__1716000191__3; if linked_1954 == nil { tmp5 = ifn_1955.Invoke_O__O(arg_1956) } else { tmp5 = linked_1954.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1953, arg_1956) }; arg_1948 = tmp4.Invoke_O__O(tmp5); if linked_1945 == nil { return ifn_1946.Invoke_O_O__O(arg_1947, arg_1948) } else { return linked_1945.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1944, arg_1947, arg_1948) } } else { var root_1957 any = A_arbace_j2g_jrt_A_const_76.GetRawRoot__O(); var linked_1958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1957, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1959 lang.IFn; if linked_1958 == nil { ifn_1959 = lang.IFn_Cast(root_1957) } else { ifn_1959 = nil }; var arg_1960 any; var root_1962 any = A_arbace_j2g_jrt_A_const_77.GetRawRoot__O(); var linked_1963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1962, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1964 lang.IFn; if linked_1963 == nil { ifn_1964 = lang.IFn_Cast(root_1962) } else { ifn_1964 = nil }; var arg_1965 any = b__1716000193__6; if linked_1963 == nil { arg_1960 = ifn_1964.Invoke_O__O(arg_1965) } else { arg_1960 = linked_1963.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1962, arg_1965) }; var arg_1961 any; if linked_1958 == nil { return ifn_1959.Invoke_O_O__O(arg_1960, arg_1961) } else { return linked_1958.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1957, arg_1960, arg_1961) } } } else { var f__4 any; var root_1966 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1966, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1968 lang.IFn; if linked_1967 == nil { ifn_1968 = lang.IFn_Cast(root_1966) } else { ifn_1968 = nil }; var arg_1969 any = s__1716000191__3; if linked_1967 == nil { f__4 = ifn_1968.Invoke_O__O(arg_1969) } else { f__4 = linked_1967.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1966, arg_1969) }; var root_1970 any = A_arbace_j2g_jrt_A_const_78.GetRawRoot__O(); var linked_1971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1970, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1972 lang.IFn; if linked_1971 == nil { ifn_1972 = lang.IFn_Cast(root_1970) } else { ifn_1972 = nil }; var arg_1973 any; var tmp6 any = jrt.File_Cast(f__4).GetName__String().Ref(); var tmp7 any; var root_1975 any = A_arbace_j2g_jrt_A_const_91.GetRawRoot__O(); var linked_1976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1975, A_arbace_j2g_jrt_scan_file_A_fn_class); var ifn_1977 lang.IFn; if linked_1976 == nil { ifn_1977 = lang.IFn_Cast(root_1975) } else { ifn_1977 = nil }; var arg_1978 any = f__4; if linked_1976 == nil { tmp7 = ifn_1977.Invoke_O__O(arg_1978) } else { tmp7 = linked_1976.(*A_arbace_j2g_jrt_scan_file_A).Invoke_O_O__O(root_1975, arg_1978) }; arg_1973 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7); var arg_1974 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1716000190); var tmp9 any; var root_1979 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_1980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1979, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1981 lang.IFn; if linked_1980 == nil { ifn_1981 = lang.IFn_Cast(root_1979) } else { ifn_1981 = nil }; var arg_1982 any = s__1716000191__3; if linked_1980 == nil { tmp9 = ifn_1981.Invoke_O__O(arg_1982) } else { tmp9 = linked_1980.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1979, arg_1982) }; arg_1974 = tmp8.Invoke_O__O(tmp9); if linked_1971 == nil { return ifn_1972.Invoke_O_O__O(arg_1973, arg_1974) } else { return linked_1971.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1970, arg_1973, arg_1974) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :135:1
func A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :135:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A) Ctor_O_I_O(c__b__1716000193 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1716000193 = c__b__1716000193; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :135:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A) Invoke_O__O(self any) any { { var i__1716000192__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1716000192__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1716000192__1)); var root_1933 any = A_arbace_j2g_jrt_A_const_75.GetRawRoot__O(); var linked_1934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1933, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1935 lang.IFn; if linked_1934 == nil { ifn_1935 = lang.IFn_Cast(root_1933) } else { ifn_1935 = nil }; var arg_1936 any = t.F_b__1716000193; var arg_1937 any; var tmp2 any = jrt.File_Cast(f__2).GetName__String().Ref(); var tmp3 any; var root_1938 any = A_arbace_j2g_jrt_A_const_91.GetRawRoot__O(); var linked_1939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1938, A_arbace_j2g_jrt_scan_file_A_fn_class); var ifn_1940 lang.IFn; if linked_1939 == nil { ifn_1940 = lang.IFn_Cast(root_1938) } else { ifn_1940 = nil }; var arg_1941 any = f__2; if linked_1939 == nil { tmp3 = ifn_1940.Invoke_O__O(arg_1941) } else { tmp3 = linked_1939.(*A_arbace_j2g_jrt_scan_file_A).Invoke_O_O__O(root_1938, arg_1941) }; arg_1937 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3); if linked_1934 == nil { ifn_1935.Invoke_O_O__O(arg_1936, arg_1937) } else { linked_1934.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1933, arg_1936, arg_1937) }; i__1716000192__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000192__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A_New() *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A) Ctor() {}
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A) Invoke_O_O__O(self, s__1716000201__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2173 any = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A_New_O_O(s__1716000201__1, self); var tmp2 *jrt.Class; var fncls__2172 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A_fn_class; if fncls__2172 == nil { var fncls__2172d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__2173); A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A_fn_class = fncls__2172d; tmp2 = fncls__2172d } else { tmp2 = fncls__2172 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2173, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :144:1
func A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A_New_O_O(p0, p1 any) *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A{}; t.Ctor_O_O(p0, p1); return t }
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A) Ctor_O_O(c__s__1716000201, c__iter__1716000200 any) { t.F_s__1716000201 = c__s__1716000201; t.F_iter__1716000200 = c__iter__1716000200 }
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A) Invoke_O__O(self any) any { { var s__1716000201__1 any; var t_ any = t.F_s__1716000201; t.F_s__1716000201 = nil; s__1716000201__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2063 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_2064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2063, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2065 lang.IFn; if linked_2064 == nil { ifn_2065 = lang.IFn_Cast(root_2063) } else { ifn_2065 = nil }; var arg_2066 any = s__1716000201__1; if linked_2064 == nil { temp__1927000414__auto____2 = ifn_2065.Invoke_O__O(arg_2066) } else { temp__1927000414__auto____2 = linked_2064.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2063, arg_2066) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__1716000208__4 any; var root_2067 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_2068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2067, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2069 lang.IFn; if linked_2068 == nil { ifn_2069 = lang.IFn_Cast(root_2067) } else { ifn_2069 = nil }; var arg_2070 any = xs__1927001018__auto____3; if linked_2068 == nil { vec__1716000208__4 = ifn_2069.Invoke_O__O(arg_2070) } else { vec__1716000208__4 = linked_2068.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2067, arg_2070) }; var fname__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000208__4, lang.RT_IntCast_J__I_NoInit(0), nil); var s__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000208__4, lang.RT_IntCast_J__I_NoInit(1), nil); var iterys__1927001035__auto____7 any; var fnbody__2154 any = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A_New_O(fname__5); var tmp1 *jrt.Class; var fncls__2153 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A_fn_class; if fncls__2153 == nil { var fncls__2153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, fnbody__2154); A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A_fn_class = fncls__2153d; tmp1 = fncls__2153d } else { tmp1 = fncls__2153 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2154, tmp1, nil); var fs__1927001036__auto____8 any; var root_2155 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_2156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2155, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2157 lang.IFn; if linked_2156 == nil { ifn_2157 = lang.IFn_Cast(root_2155) } else { ifn_2157 = nil }; var arg_2158 any = lang.IFn_Cast(iterys__1927001035__auto____7).Invoke_O__O(A_arbace_j2g_jrt_A_const_43.Invoke_O__O(s__6)); if linked_2156 == nil { fs__1927001036__auto____8 = ifn_2157.Invoke_O__O(arg_2158) } else { fs__1927001036__auto____8 = linked_2156.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2155, arg_2158) }; if jrt.J2g_Truth(fs__1927001036__auto____8) { var root_2159 any = A_arbace_j2g_jrt_A_const_105.GetRawRoot__O(); var linked_2160 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2159, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2161 lang.IFn; if linked_2160 == nil { ifn_2161 = lang.IFn_Cast(root_2159) } else { ifn_2161 = nil }; var arg_2162 any = fs__1927001036__auto____8; var arg_2163 any; var tmp2 lang.IFn = lang.IFn_Cast(t.F_iter__1716000200); var tmp3 any; var root_2164 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_2165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2164, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2166 lang.IFn; if linked_2165 == nil { ifn_2166 = lang.IFn_Cast(root_2164) } else { ifn_2166 = nil }; var arg_2167 any = s__1716000201__1; if linked_2165 == nil { tmp3 = ifn_2166.Invoke_O__O(arg_2167) } else { tmp3 = linked_2165.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2164, arg_2167) }; arg_2163 = tmp2.Invoke_O__O(tmp3); if linked_2160 == nil { return ifn_2161.Invoke_O_O__O(arg_2162, arg_2163) } else { return linked_2160.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2159, arg_2162, arg_2163) } } else { var tmp4 any; var root_2168 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_2169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2168, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2170 lang.IFn; if linked_2169 == nil { ifn_2170 = lang.IFn_Cast(root_2168) } else { ifn_2170 = nil }; var arg_2171 any = s__1716000201__1; if linked_2169 == nil { tmp4 = ifn_2170.Invoke_O__O(arg_2171) } else { tmp4 = linked_2169.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2168, arg_2171) }; s__1716000201__1 = tmp4; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :144:1
func A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A_New_O(p0 any) *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A{}; t.Ctor_O(p0); return t }
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A) Ctor_O(c__fname any) { t.F_fname = c__fname }
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A) Invoke_O_O__O(self, s__1716000203__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2152 any = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A_New_O_O_O(s__1716000203__1, self, t.F_fname); var tmp2 *jrt.Class; var fncls__2151 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A_fn_class; if fncls__2151 == nil { var fncls__2151d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, fnbody__2152); A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A_fn_class = fncls__2151d; tmp2 = fncls__2151d } else { tmp2 = fncls__2151 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2152, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :144:1
func A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A) Ctor_O_O_O(c__s__1716000203, c__iter__1716000202, c__fname any) { t.F_s__1716000203 = c__s__1716000203; t.F_iter__1716000202 = c__iter__1716000202; t.F_fname = c__fname }
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A) Invoke_O__O(self any) any { { var s__1716000203__1 any; var t_ any = t.F_s__1716000203; t.F_s__1716000203 = nil; s__1716000203__1 = t_; for { var temp__1927000414__auto____2 any; var root_2071 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_2072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2071, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2073 lang.IFn; if linked_2072 == nil { ifn_2073 = lang.IFn_Cast(root_2071) } else { ifn_2073 = nil }; var arg_2074 any = s__1716000203__1; if linked_2072 == nil { temp__1927000414__auto____2 = ifn_2073.Invoke_O__O(arg_2074) } else { temp__1927000414__auto____2 = linked_2072.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2071, arg_2074) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1716000203__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2075 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_2076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2075, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2077 lang.IFn; if linked_2076 == nil { ifn_2077 = lang.IFn_Cast(root_2075) } else { ifn_2077 = nil }; var arg_2078 any = s__1716000203__3; if linked_2076 == nil { tmp1 = ifn_2077.Invoke_O__O(arg_2078) } else { tmp1 = linked_2076.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2075, arg_2078) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2079 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_2080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2079, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2081 lang.IFn; if linked_2080 == nil { ifn_2081 = lang.IFn_Cast(root_2079) } else { ifn_2081 = nil }; var arg_2082 any = s__1716000203__3; if linked_2080 == nil { c__1927001037__auto____4 = ifn_2081.Invoke_O__O(arg_2082) } else { c__1927001037__auto____4 = linked_2080.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2079, arg_2082) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1716000205__6 any; var root_2083 any = A_arbace_j2g_jrt_A_const_73.GetRawRoot__O(); var linked_2084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2083, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2085 lang.IFn; if linked_2084 == nil { ifn_2085 = lang.IFn_Cast(root_2083) } else { ifn_2085 = nil }; var arg_2086 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2084 == nil { b__1716000205__6 = ifn_2085.Invoke_O__O(arg_2086) } else { b__1716000205__6 = linked_2084.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2083, arg_2086) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2104 any = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A_New_O_O_I_O(t.F_fname, b__1716000205__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2103 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A_fn_class; if fncls__2103 == nil { var fncls__2103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, fnbody__2104); A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A_fn_class = fncls__2103d; tmp3 = fncls__2103d } else { tmp3 = fncls__2103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2104, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2105 any = A_arbace_j2g_jrt_A_const_76.GetRawRoot__O(); var linked_2106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2105, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2107 lang.IFn; if linked_2106 == nil { ifn_2107 = lang.IFn_Cast(root_2105) } else { ifn_2107 = nil }; var arg_2108 any; var root_2110 any = A_arbace_j2g_jrt_A_const_77.GetRawRoot__O(); var linked_2111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2110, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2112 lang.IFn; if linked_2111 == nil { ifn_2112 = lang.IFn_Cast(root_2110) } else { ifn_2112 = nil }; var arg_2113 any = b__1716000205__6; if linked_2111 == nil { arg_2108 = ifn_2112.Invoke_O__O(arg_2113) } else { arg_2108 = linked_2111.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2110, arg_2113) }; var arg_2109 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1716000202); var tmp5 any; var root_2114 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_2115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2114, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2116 lang.IFn; if linked_2115 == nil { ifn_2116 = lang.IFn_Cast(root_2114) } else { ifn_2116 = nil }; var arg_2117 any = s__1716000203__3; if linked_2115 == nil { tmp5 = ifn_2116.Invoke_O__O(arg_2117) } else { tmp5 = linked_2115.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2114, arg_2117) }; arg_2109 = tmp4.Invoke_O__O(tmp5); if linked_2106 == nil { return ifn_2107.Invoke_O_O__O(arg_2108, arg_2109) } else { return linked_2106.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2105, arg_2108, arg_2109) } } else { var root_2118 any = A_arbace_j2g_jrt_A_const_76.GetRawRoot__O(); var linked_2119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2118, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2120 lang.IFn; if linked_2119 == nil { ifn_2120 = lang.IFn_Cast(root_2118) } else { ifn_2120 = nil }; var arg_2121 any; var root_2123 any = A_arbace_j2g_jrt_A_const_77.GetRawRoot__O(); var linked_2124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2123, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2125 lang.IFn; if linked_2124 == nil { ifn_2125 = lang.IFn_Cast(root_2123) } else { ifn_2125 = nil }; var arg_2126 any = b__1716000205__6; if linked_2124 == nil { arg_2121 = ifn_2125.Invoke_O__O(arg_2126) } else { arg_2121 = linked_2124.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2123, arg_2126) }; var arg_2122 any; if linked_2119 == nil { return ifn_2120.Invoke_O_O__O(arg_2121, arg_2122) } else { return linked_2119.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2118, arg_2121, arg_2122) } } } else { var vec__1716000218__4 any; var root_2127 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_2128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2127, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2129 lang.IFn; if linked_2128 == nil { ifn_2129 = lang.IFn_Cast(root_2127) } else { ifn_2129 = nil }; var arg_2130 any = s__1716000203__3; if linked_2128 == nil { vec__1716000218__4 = ifn_2129.Invoke_O__O(arg_2130) } else { vec__1716000218__4 = linked_2128.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2127, arg_2130) }; var jn__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000218__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vn__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000218__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2131 any = A_arbace_j2g_jrt_A_const_78.GetRawRoot__O(); var linked_2132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2131, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2133 lang.IFn; if linked_2132 == nil { ifn_2133 = lang.IFn_Cast(root_2131) } else { ifn_2133 = nil }; var arg_2134 any; var tmp6 any = A_arbace_j2g_jrt_A_const_98; var tmp7 any = A_arbace_j2g_jrt_A_const_99; var tmp8 any; var root_2136 any = A_arbace_j2g_jrt_A_const_100.GetRawRoot__O(); var linked_2137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2136, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2138 lang.IFn

	if linked_2137 == nil { ifn_2138 = lang.IFn_Cast(root_2136) } else { ifn_2138 = nil }; var arg_2139 any = vn__6; var arg_2140 any = A_arbace_j2g_jrt_A_const_101; var arg_2141 any = Lit_25; if linked_2137 == nil { tmp8 = ifn_2138.Invoke_O_O_O__O(arg_2139, arg_2140, arg_2141) } else { tmp8 = linked_2137.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2136, arg_2139, arg_2140, arg_2141) }
//line :144:1
	var tmp9 any = tmp8; var tmp10 any = A_arbace_j2g_jrt_A_const_102; var tmp11 any = t.F_fname; var tmp12 any = A_arbace_j2g_jrt_A_const_103; var tmp13 any; var root_2142 any = A_arbace_j2g_jrt_A_const_104.GetRawRoot__O(); var linked_2143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2142, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_2144 lang.IFn


	if linked_2143 == nil { ifn_2144 = lang.IFn_Cast(root_2142) } else { ifn_2144 = nil }; var arg_2145 any = t.F_fname; var arg_2146 any = Lit_26; if linked_2143 == nil { tmp13 = ifn_2144.Invoke_O_O__O(arg_2145, arg_2146) } else { tmp13 = linked_2143.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_2142, arg_2145, arg_2146) }
//line :144:1
	arg_2134 = lang.Tuple_Create_O_O__IPersistentVector(jn__5, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, vn__6, tmp7, tmp9, tmp10, tmp11, tmp12, tmp13))); var arg_2135 any; var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__1716000202); var tmp15 any; var root_2147 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_2148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2147, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2149 lang.IFn; if linked_2148 == nil { ifn_2149 = lang.IFn_Cast(root_2147) } else { ifn_2149 = nil }; var arg_2150 any = s__1716000203__3; if linked_2148 == nil { tmp15 = ifn_2149.Invoke_O__O(arg_2150) } else { tmp15 = linked_2148.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2147, arg_2150) }; arg_2135 = tmp14.Invoke_O__O(tmp15); if linked_2132 == nil { return ifn_2133.Invoke_O_O__O(arg_2134, arg_2135) } else { return linked_2132.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2131, arg_2134, arg_2135) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :144:1
func A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A) Ctor_O_O_I_O(c__fname, c__b__1716000205 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_fname = c__fname; t.F_b__1716000205 = c__b__1716000205; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A) Invoke_O__O(self any) any { { var i__1716000204__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1716000204__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1716000214__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1716000204__1)); var jn__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000214__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vn__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000214__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2087 any = A_arbace_j2g_jrt_A_const_75.GetRawRoot__O(); var linked_2088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2087, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2089 lang.IFn; if linked_2088 == nil { ifn_2089 = lang.IFn_Cast(root_2087) } else { ifn_2089 = nil }; var arg_2090 any = t.F_b__1716000205; var arg_2091 any; var tmp2 any = A_arbace_j2g_jrt_A_const_98; var tmp3 any = A_arbace_j2g_jrt_A_const_99; var tmp4 any; var root_2092 any = A_arbace_j2g_jrt_A_const_100.GetRawRoot__O(); var linked_2093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2092, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2094 lang.IFn

	if linked_2093 == nil { ifn_2094 = lang.IFn_Cast(root_2092) } else { ifn_2094 = nil }; var arg_2095 any = vn__4; var arg_2096 any = A_arbace_j2g_jrt_A_const_101; var arg_2097 any = Lit_25; if linked_2093 == nil { tmp4 = ifn_2094.Invoke_O_O_O__O(arg_2095, arg_2096, arg_2097) } else { tmp4 = linked_2093.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2092, arg_2095, arg_2096, arg_2097) }
//line :144:1
	var tmp5 any = tmp4; var tmp6 any = A_arbace_j2g_jrt_A_const_102; var tmp7 any = t.F_fname; var tmp8 any = A_arbace_j2g_jrt_A_const_103; var tmp9 any; var root_2098 any = A_arbace_j2g_jrt_A_const_104.GetRawRoot__O(); var linked_2099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2098, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_2100 lang.IFn


	if linked_2099 == nil { ifn_2100 = lang.IFn_Cast(root_2098) } else { ifn_2100 = nil }; var arg_2101 any = t.F_fname; var arg_2102 any = Lit_26; if linked_2099 == nil { tmp9 = ifn_2100.Invoke_O_O__O(arg_2101, arg_2102) } else { tmp9 = linked_2099.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_2098, arg_2101, arg_2102) }
//line :144:1
	arg_2091 = lang.Tuple_Create_O_O__IPersistentVector(jn__3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, vn__4, tmp3, tmp5, tmp6, tmp7, tmp8, tmp9))); if linked_2088 == nil { ifn_2089.Invoke_O_O__O(arg_2090, arg_2091) } else { linked_2088.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2087, arg_2090, arg_2091) }; i__1716000204__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000204__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A_New() *A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A) Ctor() {}
//line :148:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A) Invoke_O_O__O(self, s__1716000226__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2284 any = A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A_New_O_O(s__1716000226__1, self); var tmp2 *jrt.Class; var fncls__2283 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A_fn_class; if fncls__2283 == nil { var fncls__2283d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, fnbody__2284); A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A_fn_class = fncls__2283d; tmp2 = fncls__2283d } else { tmp2 = fncls__2283 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2284, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :148:1
func A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A_New_O_O(p0, p1 any) *A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A{}; t.Ctor_O_O(p0, p1); return t }
//line :148:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A) Ctor_O_O(c__s__1716000226, c__iter__1716000225 any) { t.F_s__1716000226 = c__s__1716000226; t.F_iter__1716000225 = c__iter__1716000225 }
//line :148:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A) Invoke_O__O(self any) any { { var s__1716000226__1 any; var t_ any = t.F_s__1716000226; t.F_s__1716000226 = nil; s__1716000226__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2181 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_2182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2181, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2183 lang.IFn; if linked_2182 == nil { ifn_2183 = lang.IFn_Cast(root_2181) } else { ifn_2183 = nil }; var arg_2184 any = s__1716000226__1; if linked_2182 == nil { temp__1927000414__auto____2 = ifn_2183.Invoke_O__O(arg_2184) } else { temp__1927000414__auto____2 = linked_2182.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2181, arg_2184) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1716000226__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2185 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_2186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2185, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2187 lang.IFn; if linked_2186 == nil { ifn_2187 = lang.IFn_Cast(root_2185) } else { ifn_2187 = nil }; var arg_2188 any = s__1716000226__3; if linked_2186 == nil { tmp1 = ifn_2187.Invoke_O__O(arg_2188) } else { tmp1 = linked_2186.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2185, arg_2188) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2189 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_2190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2189, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2191 lang.IFn; if linked_2190 == nil { ifn_2191 = lang.IFn_Cast(root_2189) } else { ifn_2191 = nil }; var arg_2192 any = s__1716000226__3; if linked_2190 == nil { c__1927001037__auto____4 = ifn_2191.Invoke_O__O(arg_2192) } else { c__1927001037__auto____4 = linked_2190.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2189, arg_2192) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1716000228__6 any; var root_2193 any = A_arbace_j2g_jrt_A_const_73.GetRawRoot__O(); var linked_2194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2193, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2195 lang.IFn; if linked_2194 == nil { ifn_2195 = lang.IFn_Cast(root_2193) } else { ifn_2195 = nil }; var arg_2196 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2194 == nil { b__1716000228__6 = ifn_2195.Invoke_O__O(arg_2196) } else { b__1716000228__6 = linked_2194.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2193, arg_2196) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2223 any = A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A_New_O_I_O(b__1716000228__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2222 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A_fn_class; if fncls__2222 == nil { var fncls__2222d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, fnbody__2223); A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A_fn_class = fncls__2222d; tmp3 = fncls__2222d } else { tmp3 = fncls__2222 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2223, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2224 any = A_arbace_j2g_jrt_A_const_76.GetRawRoot__O(); var linked_2225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2224, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2226 lang.IFn; if linked_2225 == nil { ifn_2226 = lang.IFn_Cast(root_2224) } else { ifn_2226 = nil }; var arg_2227 any; var root_2229 any = A_arbace_j2g_jrt_A_const_77.GetRawRoot__O(); var linked_2230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2229, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2231 lang.IFn; if linked_2230 == nil { ifn_2231 = lang.IFn_Cast(root_2229) } else { ifn_2231 = nil }; var arg_2232 any = b__1716000228__6; if linked_2230 == nil { arg_2227 = ifn_2231.Invoke_O__O(arg_2232) } else { arg_2227 = linked_2230.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2229, arg_2232) }; var arg_2228 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1716000225); var tmp5 any; var root_2233 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_2234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2233, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2235 lang.IFn; if linked_2234 == nil { ifn_2235 = lang.IFn_Cast(root_2233) } else { ifn_2235 = nil }; var arg_2236 any = s__1716000226__3; if linked_2234 == nil { tmp5 = ifn_2235.Invoke_O__O(arg_2236) } else { tmp5 = linked_2234.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2233, arg_2236) }; arg_2228 = tmp4.Invoke_O__O(tmp5); if linked_2225 == nil { return ifn_2226.Invoke_O_O__O(arg_2227, arg_2228) } else { return linked_2225.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2224, arg_2227, arg_2228) } } else { var root_2237 any = A_arbace_j2g_jrt_A_const_76.GetRawRoot__O(); var linked_2238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2237, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2239 lang.IFn; if linked_2238 == nil { ifn_2239 = lang.IFn_Cast(root_2237) } else { ifn_2239 = nil }; var arg_2240 any; var root_2242 any = A_arbace_j2g_jrt_A_const_77.GetRawRoot__O(); var linked_2243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2242, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2244 lang.IFn; if linked_2243 == nil { ifn_2244 = lang.IFn_Cast(root_2242) } else { ifn_2244 = nil }; var arg_2245 any = b__1716000228__6; if linked_2243 == nil { arg_2240 = ifn_2244.Invoke_O__O(arg_2245) } else { arg_2240 = linked_2243.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2242, arg_2245) }; var arg_2241 any; if linked_2238 == nil { return ifn_2239.Invoke_O_O__O(arg_2240, arg_2241) } else { return linked_2238.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2237, arg_2240, arg_2241) } } } else { var vec__1716000238__4 any; var root_2246 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_2247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2246, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2248 lang.IFn; if linked_2247 == nil { ifn_2248 = lang.IFn_Cast(root_2246) } else { ifn_2248 = nil }; var arg_2249 any = s__1716000226__3; if linked_2247 == nil { vec__1716000238__4 = ifn_2248.Invoke_O__O(arg_2249) } else { vec__1716000238__4 = linked_2247.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2246, arg_2249) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000238__4, lang.RT_IntCast_J__I_NoInit(0), nil); var map__1716000241__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000238__4, lang.RT_IntCast_J__I_NoInit(1), nil); var map__1716000241__7 any; if lang.ISeq_InstanceOf(map__1716000241__6) { var tmp6 any; var root_2250 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_2251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2250, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2252 lang.IFn; if linked_2251 == nil { ifn_2252 = lang.IFn_Cast(root_2250) } else { ifn_2252 = nil }; var arg_2253 any = map__1716000241__6; if linked_2251 == nil { tmp6 = ifn_2252.Invoke_O__O(arg_2253) } else { tmp6 = linked_2251.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2250, arg_2253) }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_2254 any = A_arbace_j2g_jrt_A_const_70.GetRawRoot__O(); var linked_2255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2254, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2256 lang.IFn; if linked_2255 == nil { ifn_2256 = lang.IFn_Cast(root_2254) } else { ifn_2256 = nil }; var arg_2257 any = map__1716000241__6; if linked_2255 == nil { tmp7 = ifn_2256.Invoke_O__O(arg_2257) } else { tmp7 = linked_2255.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2254, arg_2257) }; map__1716000241__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp7)).Ref() } else { var tmp8 any; var root_2258 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_2259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2258, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2260 lang.IFn; if linked_2259 == nil { ifn_2260 = lang.IFn_Cast(root_2258) } else { ifn_2260 = nil }; var arg_2261 any = map__1716000241__6; if linked_2259 == nil { tmp8 = ifn_2260.Invoke_O__O(arg_2261) } else { tmp8 = linked_2259.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2258, arg_2261) }; if jrt.J2g_Truth(tmp8) { var root_2262 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_2263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2262, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2264 lang.IFn; if linked_2263 == nil { ifn_2264 = lang.IFn_Cast(root_2262) } else { ifn_2264 = nil }; var arg_2265 any = map__1716000241__6; if linked_2263 == nil { map__1716000241__7 = ifn_2264.Invoke_O__O(arg_2265) } else { map__1716000241__7 = linked_2263.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2262, arg_2265) } } else { map__1716000241__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000241__7 = map__1716000241__6 }; var kind__8 any = lang.RT_Get_O_O__O_NoInit(map__1716000241__7, A_arbace_j2g_jrt_A_const_57); var form__9 any = lang.RT_Get_O_O__O_NoInit(map__1716000241__7, A_arbace_j2g_jrt_A_const_63); if lang.Util_Equiv_O_O__Z_NoInit(kind__8, A_arbace_j2g_jrt_A_const_61) { var root_2266 any = A_arbace_j2g_jrt_A_const_78.GetRawRoot__O(); var linked_2267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2266, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2268 lang.IFn; if linked_2267 == nil { ifn_2268 = lang.IFn_Cast(root_2266) } else { ifn_2268 = nil }; var arg_2269 any; var tmp9 any; var root_2271 any = A_arbace_j2g_jrt_A_const_107.GetRawRoot__O(); var linked_2272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2271, A_arbace_j2g_jrt_interface_elems_A_fn_class); var ifn_2273 lang.IFn
													if linked_2272 == nil { ifn_2273 = lang.IFn_Cast(root_2271) } else { ifn_2273 = nil }; var arg_2274 any = form__9; if linked_2272 == nil { tmp9 = ifn_2273.Invoke_O__O(arg_2274) } else { tmp9 = linked_2272.(*A_arbace_j2g_jrt_interface_elems_A).Invoke_O_O__O(root_2271, arg_2274) }
//line :148:1
	arg_2269 = lang.Tuple_Create_O_O__IPersistentVector(n__5, tmp9); var arg_2270 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__1716000225); var tmp11 any; var root_2275 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_2276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2275, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2277 lang.IFn; if linked_2276 == nil { ifn_2277 = lang.IFn_Cast(root_2275) } else { ifn_2277 = nil }; var arg_2278 any = s__1716000226__3; if linked_2276 == nil { tmp11 = ifn_2277.Invoke_O__O(arg_2278) } else { tmp11 = linked_2276.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2275, arg_2278) }; arg_2270 = tmp10.Invoke_O__O(tmp11); if linked_2267 == nil { return ifn_2268.Invoke_O_O__O(arg_2269, arg_2270) } else { return linked_2267.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2266, arg_2269, arg_2270) } } else { var tmp12 any; var root_2279 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_2280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2279, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2281 lang.IFn; if linked_2280 == nil { ifn_2281 = lang.IFn_Cast(root_2279) } else { ifn_2281 = nil }; var arg_2282 any = s__1716000226__3; if linked_2280 == nil { tmp12 = ifn_2281.Invoke_O__O(arg_2282) } else { tmp12 = linked_2280.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2279, arg_2282) }; s__1716000226__1 = tmp12; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :148:1
func A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :148:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A) Ctor_O_I_O(c__b__1716000228 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1716000228 = c__b__1716000228; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :148:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A) Invoke_O__O(self any) any { { var i__1716000227__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1716000227__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1716000232__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1716000227__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000232__2, lang.RT_IntCast_J__I_NoInit(0), nil); var map__1716000235__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000232__2, lang.RT_IntCast_J__I_NoInit(1), nil); var map__1716000235__5 any; if lang.ISeq_InstanceOf(map__1716000235__4) { var tmp2 any; var root_2197 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_2198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2197, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2199 lang.IFn; if linked_2198 == nil { ifn_2199 = lang.IFn_Cast(root_2197) } else { ifn_2199 = nil }; var arg_2200 any = map__1716000235__4; if linked_2198 == nil { tmp2 = ifn_2199.Invoke_O__O(arg_2200) } else { tmp2 = linked_2198.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2197, arg_2200) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_2201 any = A_arbace_j2g_jrt_A_const_70.GetRawRoot__O(); var linked_2202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2201, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2203 lang.IFn; if linked_2202 == nil { ifn_2203 = lang.IFn_Cast(root_2201) } else { ifn_2203 = nil }; var arg_2204 any = map__1716000235__4; if linked_2202 == nil { tmp3 = ifn_2203.Invoke_O__O(arg_2204) } else { tmp3 = linked_2202.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2201, arg_2204) }; map__1716000235__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp3)).Ref() } else { var tmp4 any; var root_2205 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_2206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2205, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2207 lang.IFn; if linked_2206 == nil { ifn_2207 = lang.IFn_Cast(root_2205) } else { ifn_2207 = nil }; var arg_2208 any = map__1716000235__4; if linked_2206 == nil { tmp4 = ifn_2207.Invoke_O__O(arg_2208) } else { tmp4 = linked_2206.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2205, arg_2208) }; if jrt.J2g_Truth(tmp4) { var root_2209 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_2210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2209, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2211 lang.IFn; if linked_2210 == nil { ifn_2211 = lang.IFn_Cast(root_2209) } else { ifn_2211 = nil }; var arg_2212 any = map__1716000235__4; if linked_2210 == nil { map__1716000235__5 = ifn_2211.Invoke_O__O(arg_2212) } else { map__1716000235__5 = linked_2210.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2209, arg_2212) } } else { map__1716000235__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000235__5 = map__1716000235__4 }; var kind__6 any = lang.RT_Get_O_O__O_NoInit(map__1716000235__5, A_arbace_j2g_jrt_A_const_57); var form__7 any = lang.RT_Get_O_O__O_NoInit(map__1716000235__5, A_arbace_j2g_jrt_A_const_63); if lang.Util_Equiv_O_O__Z_NoInit(kind__6, A_arbace_j2g_jrt_A_const_61) { var root_2213 any = A_arbace_j2g_jrt_A_const_75.GetRawRoot__O(); var linked_2214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2213, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2215 lang.IFn; if linked_2214 == nil { ifn_2215 = lang.IFn_Cast(root_2213) } else { ifn_2215 = nil }; var arg_2216 any = t.F_b__1716000228; var arg_2217 any; var tmp5 any; var root_2218 any = A_arbace_j2g_jrt_A_const_107.GetRawRoot__O(); var linked_2219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2218, A_arbace_j2g_jrt_interface_elems_A_fn_class); var ifn_2220 lang.IFn
															if linked_2219 == nil { ifn_2220 = lang.IFn_Cast(root_2218) } else { ifn_2220 = nil }; var arg_2221 any = form__7; if linked_2219 == nil { tmp5 = ifn_2220.Invoke_O__O(arg_2221) } else { tmp5 = linked_2219.(*A_arbace_j2g_jrt_interface_elems_A).Invoke_O_O__O(root_2218, arg_2221) }
//line :148:1
	arg_2217 = lang.Tuple_Create_O_O__IPersistentVector(n__3, tmp5); if linked_2214 == nil { ifn_2215.Invoke_O_O__O(arg_2216, arg_2217) } else { linked_2214.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2213, arg_2216, arg_2217) }; i__1716000227__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000227__1); continue L1 } else { i__1716000227__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000227__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A_New() *A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A) Ctor() {}
//line :150:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A) Invoke_O_O__O(self, s__1716000246__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2399 any = A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A_New_O_O(s__1716000246__1, self); var tmp2 *jrt.Class; var fncls__2398 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A_fn_class; if fncls__2398 == nil { var fncls__2398d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, fnbody__2399); A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A_fn_class = fncls__2398d; tmp2 = fncls__2398d } else { tmp2 = fncls__2398 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2399, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :150:1
func A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A_New_O_O(p0, p1 any) *A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A{}; t.Ctor_O_O(p0, p1); return t }
//line :150:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A) Ctor_O_O(c__s__1716000246, c__iter__1716000245 any) { t.F_s__1716000246 = c__s__1716000246; t.F_iter__1716000245 = c__iter__1716000245 }
//line :150:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A) Invoke_O__O(self any) any { { var s__1716000246__1 any; var t_ any = t.F_s__1716000246; t.F_s__1716000246 = nil; s__1716000246__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2292 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_2293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2292, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2294 lang.IFn; if linked_2293 == nil { ifn_2294 = lang.IFn_Cast(root_2292) } else { ifn_2294 = nil }; var arg_2295 any = s__1716000246__1; if linked_2293 == nil { temp__1927000414__auto____2 = ifn_2294.Invoke_O__O(arg_2295) } else { temp__1927000414__auto____2 = linked_2293.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2292, arg_2295) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1716000246__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2296 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_2297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2296, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2298 lang.IFn; if linked_2297 == nil { ifn_2298 = lang.IFn_Cast(root_2296) } else { ifn_2298 = nil }; var arg_2299 any = s__1716000246__3; if linked_2297 == nil { tmp1 = ifn_2298.Invoke_O__O(arg_2299) } else { tmp1 = linked_2297.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2296, arg_2299) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2300 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_2301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2300, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2302 lang.IFn; if linked_2301 == nil { ifn_2302 = lang.IFn_Cast(root_2300) } else { ifn_2302 = nil }; var arg_2303 any = s__1716000246__3; if linked_2301 == nil { c__1927001037__auto____4 = ifn_2302.Invoke_O__O(arg_2303) } else { c__1927001037__auto____4 = linked_2301.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2300, arg_2303) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1716000248__6 any; var root_2304 any = A_arbace_j2g_jrt_A_const_73.GetRawRoot__O(); var linked_2305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2304, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2306 lang.IFn; if linked_2305 == nil { ifn_2306 = lang.IFn_Cast(root_2304) } else { ifn_2306 = nil }; var arg_2307 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2305 == nil { b__1716000248__6 = ifn_2306.Invoke_O__O(arg_2307) } else { b__1716000248__6 = linked_2305.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2304, arg_2307) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2334 any = A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A_New_O_I_O(b__1716000248__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2333 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A_fn_class; if fncls__2333 == nil { var fncls__2333d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, fnbody__2334); A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A_fn_class = fncls__2333d; tmp3 = fncls__2333d } else { tmp3 = fncls__2333 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2334, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2335 any = A_arbace_j2g_jrt_A_const_76.GetRawRoot__O(); var linked_2336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2335, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2337 lang.IFn; if linked_2336 == nil { ifn_2337 = lang.IFn_Cast(root_2335) } else { ifn_2337 = nil }; var arg_2338 any; var root_2340 any = A_arbace_j2g_jrt_A_const_77.GetRawRoot__O(); var linked_2341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2340, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2342 lang.IFn; if linked_2341 == nil { ifn_2342 = lang.IFn_Cast(root_2340) } else { ifn_2342 = nil }; var arg_2343 any = b__1716000248__6; if linked_2341 == nil { arg_2338 = ifn_2342.Invoke_O__O(arg_2343) } else { arg_2338 = linked_2341.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2340, arg_2343) }; var arg_2339 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1716000245); var tmp5 any; var root_2344 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_2345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2344, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2346 lang.IFn; if linked_2345 == nil { ifn_2346 = lang.IFn_Cast(root_2344) } else { ifn_2346 = nil }; var arg_2347 any = s__1716000246__3; if linked_2345 == nil { tmp5 = ifn_2346.Invoke_O__O(arg_2347) } else { tmp5 = linked_2345.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2344, arg_2347) }; arg_2339 = tmp4.Invoke_O__O(tmp5); if linked_2336 == nil { return ifn_2337.Invoke_O_O__O(arg_2338, arg_2339) } else { return linked_2336.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2335, arg_2338, arg_2339) } } else { var root_2348 any = A_arbace_j2g_jrt_A_const_76.GetRawRoot__O(); var linked_2349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2348, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2350 lang.IFn; if linked_2349 == nil { ifn_2350 = lang.IFn_Cast(root_2348) } else { ifn_2350 = nil }; var arg_2351 any; var root_2353 any = A_arbace_j2g_jrt_A_const_77.GetRawRoot__O(); var linked_2354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2353, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2355 lang.IFn; if linked_2354 == nil { ifn_2355 = lang.IFn_Cast(root_2353) } else { ifn_2355 = nil }; var arg_2356 any = b__1716000248__6; if linked_2354 == nil { arg_2351 = ifn_2355.Invoke_O__O(arg_2356) } else { arg_2351 = linked_2354.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2353, arg_2356) }; var arg_2352 any; if linked_2349 == nil { return ifn_2350.Invoke_O_O__O(arg_2351, arg_2352) } else { return linked_2349.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2348, arg_2351, arg_2352) } } } else { var vec__1716000258__4 any; var root_2357 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_2358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2357, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2359 lang.IFn; if linked_2358 == nil { ifn_2359 = lang.IFn_Cast(root_2357) } else { ifn_2359 = nil }; var arg_2360 any = s__1716000246__3; if linked_2358 == nil { vec__1716000258__4 = ifn_2359.Invoke_O__O(arg_2360) } else { vec__1716000258__4 = linked_2358.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2357, arg_2360) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000258__4, lang.RT_IntCast_J__I_NoInit(0), nil); var map__1716000261__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000258__4, lang.RT_IntCast_J__I_NoInit(1), nil); var map__1716000261__7 any; if lang.ISeq_InstanceOf(map__1716000261__6) { var tmp6 any; var root_2361 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_2362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2361, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2363 lang.IFn; if linked_2362 == nil { ifn_2363 = lang.IFn_Cast(root_2361) } else { ifn_2363 = nil }; var arg_2364 any = map__1716000261__6; if linked_2362 == nil { tmp6 = ifn_2363.Invoke_O__O(arg_2364) } else { tmp6 = linked_2362.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2361, arg_2364) }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_2365 any = A_arbace_j2g_jrt_A_const_70.GetRawRoot__O(); var linked_2366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2365, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2367 lang.IFn; if linked_2366 == nil { ifn_2367 = lang.IFn_Cast(root_2365) } else { ifn_2367 = nil }; var arg_2368 any = map__1716000261__6; if linked_2366 == nil { tmp7 = ifn_2367.Invoke_O__O(arg_2368) } else { tmp7 = linked_2366.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2365, arg_2368) }; map__1716000261__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp7)).Ref() } else { var tmp8 any; var root_2369 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_2370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2369, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2371 lang.IFn; if linked_2370 == nil { ifn_2371 = lang.IFn_Cast(root_2369) } else { ifn_2371 = nil }; var arg_2372 any = map__1716000261__6; if linked_2370 == nil { tmp8 = ifn_2371.Invoke_O__O(arg_2372) } else { tmp8 = linked_2370.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2369, arg_2372) }; if jrt.J2g_Truth(tmp8) { var root_2373 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_2374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2373, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2375 lang.IFn; if linked_2374 == nil { ifn_2375 = lang.IFn_Cast(root_2373) } else { ifn_2375 = nil }; var arg_2376 any = map__1716000261__6; if linked_2374 == nil { map__1716000261__7 = ifn_2375.Invoke_O__O(arg_2376) } else { map__1716000261__7 = linked_2374.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2373, arg_2376) } } else { map__1716000261__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000261__7 = map__1716000261__6 }; var kind__8 any = lang.RT_Get_O_O__O_NoInit(map__1716000261__7, A_arbace_j2g_jrt_A_const_57); var form__9 any = lang.RT_Get_O_O__O_NoInit(map__1716000261__7, A_arbace_j2g_jrt_A_const_63); if lang.Util_Equiv_O_O__Z_NoInit(kind__8, A_arbace_j2g_jrt_A_const_59) { var e__10 any; var root_2377 any = A_arbace_j2g_jrt_A_const_108.GetRawRoot__O(); var linked_2378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2377, A_arbace_j2g_jrt_struct_embed_A_fn_class); var ifn_2379 lang.IFn
													if linked_2378 == nil { ifn_2379 = lang.IFn_Cast(root_2377) } else { ifn_2379 = nil }; var arg_2380 any = form__9; if linked_2378 == nil { e__10 = ifn_2379.Invoke_O__O(arg_2380) } else { e__10 = linked_2378.(*A_arbace_j2g_jrt_struct_embed_A).Invoke_O_O__O(root_2377, arg_2380) }
//line :150:1
	if jrt.J2g_Truth(e__10) { var root_2381 any = A_arbace_j2g_jrt_A_const_78.GetRawRoot__O(); var linked_2382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2381, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2383 lang.IFn; if linked_2382 == nil { ifn_2383 = lang.IFn_Cast(root_2381) } else { ifn_2383 = nil }; var arg_2384 any = lang.Tuple_Create_O_O__IPersistentVector(n__5, e__10); var arg_2385 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1716000245); var tmp10 any; var root_2386 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_2387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2386, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2388 lang.IFn; if linked_2387 == nil { ifn_2388 = lang.IFn_Cast(root_2386) } else { ifn_2388 = nil }; var arg_2389 any = s__1716000246__3; if linked_2387 == nil { tmp10 = ifn_2388.Invoke_O__O(arg_2389) } else { tmp10 = linked_2387.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2386, arg_2389) }; arg_2385 = tmp9.Invoke_O__O(tmp10); if linked_2382 == nil { return ifn_2383.Invoke_O_O__O(arg_2384, arg_2385) } else { return linked_2382.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2381, arg_2384, arg_2385) } } else { var tmp11 any; var root_2390 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_2391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2390, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2392 lang.IFn; if linked_2391 == nil { ifn_2392 = lang.IFn_Cast(root_2390) } else { ifn_2392 = nil }; var arg_2393 any = s__1716000246__3; if linked_2391 == nil { tmp11 = ifn_2392.Invoke_O__O(arg_2393) } else { tmp11 = linked_2391.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2390, arg_2393) }; s__1716000246__1 = tmp11; continue L1 } } else { var tmp12 any; var root_2394 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_2395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2394, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2396 lang.IFn; if linked_2395 == nil { ifn_2396 = lang.IFn_Cast(root_2394) } else { ifn_2396 = nil }; var arg_2397 any = s__1716000246__3; if linked_2395 == nil { tmp12 = ifn_2396.Invoke_O__O(arg_2397) } else { tmp12 = linked_2395.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2394, arg_2397) }; s__1716000246__1 = tmp12; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :150:1
func A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :150:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A) Ctor_O_I_O(c__b__1716000248 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1716000248 = c__b__1716000248; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :150:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A) Invoke_O__O(self any) any { { var i__1716000247__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1716000247__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1716000252__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1716000247__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000252__2, lang.RT_IntCast_J__I_NoInit(0), nil); var map__1716000255__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000252__2, lang.RT_IntCast_J__I_NoInit(1), nil); var map__1716000255__5 any; if lang.ISeq_InstanceOf(map__1716000255__4) { var tmp2 any; var root_2308 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_2309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2308, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2310 lang.IFn; if linked_2309 == nil { ifn_2310 = lang.IFn_Cast(root_2308) } else { ifn_2310 = nil }; var arg_2311 any = map__1716000255__4; if linked_2309 == nil { tmp2 = ifn_2310.Invoke_O__O(arg_2311) } else { tmp2 = linked_2309.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2308, arg_2311) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_2312 any = A_arbace_j2g_jrt_A_const_70.GetRawRoot__O(); var linked_2313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2312, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2314 lang.IFn; if linked_2313 == nil { ifn_2314 = lang.IFn_Cast(root_2312) } else { ifn_2314 = nil }; var arg_2315 any = map__1716000255__4; if linked_2313 == nil { tmp3 = ifn_2314.Invoke_O__O(arg_2315) } else { tmp3 = linked_2313.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2312, arg_2315) }; map__1716000255__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp3)).Ref() } else { var tmp4 any; var root_2316 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_2317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2316, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2318 lang.IFn; if linked_2317 == nil { ifn_2318 = lang.IFn_Cast(root_2316) } else { ifn_2318 = nil }; var arg_2319 any = map__1716000255__4; if linked_2317 == nil { tmp4 = ifn_2318.Invoke_O__O(arg_2319) } else { tmp4 = linked_2317.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2316, arg_2319) }; if jrt.J2g_Truth(tmp4) { var root_2320 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_2321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2320, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2322 lang.IFn; if linked_2321 == nil { ifn_2322 = lang.IFn_Cast(root_2320) } else { ifn_2322 = nil }; var arg_2323 any = map__1716000255__4; if linked_2321 == nil { map__1716000255__5 = ifn_2322.Invoke_O__O(arg_2323) } else { map__1716000255__5 = linked_2321.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2320, arg_2323) } } else { map__1716000255__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000255__5 = map__1716000255__4 }; var kind__6 any = lang.RT_Get_O_O__O_NoInit(map__1716000255__5, A_arbace_j2g_jrt_A_const_57); var form__7 any = lang.RT_Get_O_O__O_NoInit(map__1716000255__5, A_arbace_j2g_jrt_A_const_63); if lang.Util_Equiv_O_O__Z_NoInit(kind__6, A_arbace_j2g_jrt_A_const_59) { var e__8 any; var root_2324 any = A_arbace_j2g_jrt_A_const_108.GetRawRoot__O(); var linked_2325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2324, A_arbace_j2g_jrt_struct_embed_A_fn_class); var ifn_2326 lang.IFn
															if linked_2325 == nil { ifn_2326 = lang.IFn_Cast(root_2324) } else { ifn_2326 = nil }; var arg_2327 any = form__7; if linked_2325 == nil { e__8 = ifn_2326.Invoke_O__O(arg_2327) } else { e__8 = linked_2325.(*A_arbace_j2g_jrt_struct_embed_A).Invoke_O_O__O(root_2324, arg_2327) }
//line :150:1
	if jrt.J2g_Truth(e__8) { var root_2328 any = A_arbace_j2g_jrt_A_const_75.GetRawRoot__O(); var linked_2329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2328, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2330 lang.IFn; if linked_2329 == nil { ifn_2330 = lang.IFn_Cast(root_2328) } else { ifn_2330 = nil }; var arg_2331 any = t.F_b__1716000248; var arg_2332 any = lang.Tuple_Create_O_O__IPersistentVector(n__3, e__8); if linked_2329 == nil { ifn_2330.Invoke_O_O__O(arg_2331, arg_2332) } else { linked_2329.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2328, arg_2331, arg_2332) }; i__1716000247__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000247__1); continue L1 } else { i__1716000247__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000247__1); continue L1 } } else { i__1716000247__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000247__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_jrt_struct_methods_A_New() *A_arbace_j2g_jrt_struct_methods_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_struct_methods_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_j2g_jrt_struct_methods_A) Ctor() {}
//line :154:1
func (t *A_arbace_j2g_jrt_struct_methods_A) Invoke_O_O_O__O(self, scan__0, go_type__1 any) any { { var t__3 any = go_type__1; var acc__4 any = lang.PersistentHashSet_EMPTY.Ref(); L1: for {



	if lang.Util_Identical_O_O__Z_NoInit(t__3, nil) { return acc__4 } else {

		var tmp1 any = lang.RT_Get_O_O__O_NoInit(A_arbace_j2g_jrt_A_const_79.Invoke_O__O(scan__0), t__3); var tmp2 any; var root_2402 any = A_arbace_j2g_jrt_A_const_89.GetRawRoot__O(); var linked_2403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2402, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2404 lang.IFn; if linked_2403 == nil { ifn_2404 = lang.IFn_Cast(root_2402) } else { ifn_2404 = nil }; var arg_2405 any = acc__4; var arg_2406 any = lang.RT_Get_O_O__O_NoInit(A_arbace_j2g_jrt_A_const_40.Invoke_O__O(scan__0), t__3); if linked_2403 == nil { tmp2 = ifn_2404.Invoke_O_O__O(arg_2405, arg_2406) } else { tmp2 = linked_2403.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2402, arg_2405, arg_2406) }; t__3, acc__4 = tmp1, tmp2; continue L1 } } }; /*line :154:1*/panic("j2g: unreachable") }







func A_arbace_j2g_jrt_iface_methods_A_New() *A_arbace_j2g_jrt_iface_methods_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_iface_methods_A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_j2g_jrt_iface_methods_A) Ctor() {}
//line :162:1
func (t *A_arbace_j2g_jrt_iface_methods_A) Invoke_O_O_O__O(self, scan__0, go_type__1 any) any { var i__3 any = lang.RT_Get_O_O__O_NoInit(A_arbace_j2g_jrt_A_const_106.Invoke_O__O(scan__0), go_type__1); var root_2407 any = A_arbace_j2g_jrt_A_const_89.GetRawRoot__O(); var linked_2408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2407, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2409 lang.IFn; if



	linked_2408 == nil { ifn_2409 = lang.IFn_Cast(root_2407) } else { ifn_2409 = nil }; var arg_2410 any; var root_2412 any = A_arbace_j2g_jrt_A_const_72.GetRawRoot__O(); var linked_2413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2412, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2414 lang.IFn; if linked_2413 == nil { ifn_2414 = lang.IFn_Cast(root_2412) } else { ifn_2414 = nil }; var arg_2415 any = A_arbace_j2g_jrt_A_const_40.Invoke_O__O(i__3); if linked_2413 == nil { arg_2410 = ifn_2414.Invoke_O__O(arg_2415) } else { arg_2410 = linked_2413.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2412, arg_2415) }; var arg_2411 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_109.GetRawRoot__O()); var tmp2 *lang.Compiler_AOTFn; var fnbody__2427 any = A_arbace_j2g_jrt_iface_methods_fn__1716000268_A_New_O(scan__0); var tmp3 *jrt.Class; var fncls__2426 *jrt.Class = A_arbace_j2g_jrt_iface_methods_fn__1716000268_A_fn_class; if fncls__2426 == nil { var fncls__2426d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, fnbody__2427); A_arbace_j2g_jrt_iface_methods_fn__1716000268_A_fn_class = fncls__2426d; tmp3 = fncls__2426d } else { tmp3 = fncls__2426 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2427, tmp3, nil); arg_2411 = tmp1.Invoke_O_O__O(tmp2.Ref(), A_arbace_j2g_jrt_A_const_79.Invoke_O__O(i__3)); if linked_2408 == nil { return ifn_2409.Invoke_O_O__O(arg_2410, arg_2411) } else { return linked_2408.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2407, arg_2410, arg_2411) } }
//line :166:1
func A_arbace_j2g_jrt_iface_methods_fn__1716000268_A_New_O(p0 any) *A_arbace_j2g_jrt_iface_methods_fn__1716000268_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_iface_methods_fn__1716000268_A{}; t.Ctor_O(p0); return t }
//line :166:1
func (t *A_arbace_j2g_jrt_iface_methods_fn__1716000268_A) Ctor_O(c__scan any) { t.F_scan = c__scan }
//line :166:1
func (t *A_arbace_j2g_jrt_iface_methods_fn__1716000268_A) Invoke_O_O__O(self, p1__1716000267_SHARP___1 any) any { var root_2421 any = A_arbace_j2g_jrt_A_const_110.GetRawRoot__O(); var linked_2422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2421, A_arbace_j2g_jrt_iface_methods_A_fn_class); var ifn_2423 lang.IFn; if linked_2422 == nil { ifn_2423 = lang.IFn_Cast(root_2421) } else { ifn_2423 = nil }; var arg_2424 any = t.F_scan; var arg_2425 any = p1__1716000267_SHARP___1; if linked_2422 == nil { return ifn_2423.Invoke_O_O__O(arg_2424, arg_2425) } else { return linked_2422.(*A_arbace_j2g_jrt_iface_methods_A).Invoke_O_O_O__O(root_2421, arg_2424, arg_2425) } }
















































































































type A_arbace_j2g_jrt_A struct{ jrt.Object }

var A_arbace_j2g_jrt_A_const_pool *jrt.RefArray

var A_arbace_j2g_jrt_A_const_0 *lang.Var

var A_arbace_j2g_jrt_A_const_1 any

var A_arbace_j2g_jrt_A_const_2 any

var A_arbace_j2g_jrt_A_const_3 any

var A_arbace_j2g_jrt_A_const_4 any

var A_arbace_j2g_jrt_A_const_5 *lang.Var

var A_arbace_j2g_jrt_A_const_6 any

var A_arbace_j2g_jrt_A_const_7 *lang.Var

var A_arbace_j2g_jrt_A_const_8 *lang.Var

var A_arbace_j2g_jrt_A_const_9 *lang.Var

var A_arbace_j2g_jrt_A_const_10 *lang.Var

var A_arbace_j2g_jrt_A_const_11 any

var A_arbace_j2g_jrt_A_const_12 *lang.Var

var A_arbace_j2g_jrt_A_const_13 *lang.Var

var A_arbace_j2g_jrt_A_const_14 *lang.Var

var A_arbace_j2g_jrt_A_const_15 *lang.Var

var A_arbace_j2g_jrt_A_const_16 any

var A_arbace_j2g_jrt_A_const_17 *lang.Var

var A_arbace_j2g_jrt_A_const_18 *lang.Keyword

var A_arbace_j2g_jrt_A_const_19 *lang.Var

var A_arbace_j2g_jrt_A_const_20 any

var A_arbace_j2g_jrt_A_const_21 *lang.Keyword

var A_arbace_j2g_jrt_A_const_22 *lang.Var

var A_arbace_j2g_jrt_A_const_23 *lang.Var

var A_arbace_j2g_jrt_A_const_24 *lang.Var

var A_arbace_j2g_jrt_A_const_25 *lang.Var

var A_arbace_j2g_jrt_A_const_26 *lang.Var

var A_arbace_j2g_jrt_A_const_27 any

var A_arbace_j2g_jrt_A_const_28 *lang.Var

var A_arbace_j2g_jrt_A_const_29 *lang.Var

var A_arbace_j2g_jrt_A_const_30 *lang.Var

var A_arbace_j2g_jrt_A_const_31 any

var A_arbace_j2g_jrt_A_const_32 *lang.Keyword

var A_arbace_j2g_jrt_A_const_33 *lang.Var

var A_arbace_j2g_jrt_A_const_34 *lang.Keyword

var A_arbace_j2g_jrt_A_const_35 *lang.Keyword

var A_arbace_j2g_jrt_A_const_36 *lang.Var

var A_arbace_j2g_jrt_A_const_37 *lang.Var

var A_arbace_j2g_jrt_A_const_38 *lang.Var

var A_arbace_j2g_jrt_A_const_39 *lang.Keyword

var A_arbace_j2g_jrt_A_const_40 *lang.Keyword

var A_arbace_j2g_jrt_A_const_41 *lang.Keyword

var A_arbace_j2g_jrt_A_const_42 *lang.Keyword

var A_arbace_j2g_jrt_A_const_43 *lang.Keyword

var A_arbace_j2g_jrt_A_const_44 *lang.Keyword

var A_arbace_j2g_jrt_A_const_45 *lang.Var

var A_arbace_j2g_jrt_A_const_46 *lang.Var

var A_arbace_j2g_jrt_A_const_47 *lang.Var

var A_arbace_j2g_jrt_A_const_48 *lang.Var

var A_arbace_j2g_jrt_A_const_49 *lang.Var

var A_arbace_j2g_jrt_A_const_50 *lang.Var

var A_arbace_j2g_jrt_A_const_51 *lang.Keyword

var A_arbace_j2g_jrt_A_const_52 *lang.Var

var A_arbace_j2g_jrt_A_const_53 *lang.Var

var A_arbace_j2g_jrt_A_const_54 *lang.Var

var A_arbace_j2g_jrt_A_const_55 *lang.Var

var A_arbace_j2g_jrt_A_const_56 *lang.Var

var A_arbace_j2g_jrt_A_const_57 *lang.Keyword

var A_arbace_j2g_jrt_A_const_58 any

var A_arbace_j2g_jrt_A_const_59 *lang.Keyword

var A_arbace_j2g_jrt_A_const_60 any

var A_arbace_j2g_jrt_A_const_61 *lang.Keyword

var A_arbace_j2g_jrt_A_const_62 *lang.Keyword

var A_arbace_j2g_jrt_A_const_63 *lang.Keyword

var A_arbace_j2g_jrt_A_const_64 *lang.Var

var A_arbace_j2g_jrt_A_const_65 any

var A_arbace_j2g_jrt_A_const_66 any

var A_arbace_j2g_jrt_A_const_67 *lang.Var

var A_arbace_j2g_jrt_A_const_68 any

var A_arbace_j2g_jrt_A_const_69 *lang.Var

var A_arbace_j2g_jrt_A_const_70 *lang.Var

var A_arbace_j2g_jrt_A_const_71 any

var A_arbace_j2g_jrt_A_const_72 *lang.Var

var A_arbace_j2g_jrt_A_const_73 *lang.Var

var A_arbace_j2g_jrt_A_const_74 *lang.Var

var A_arbace_j2g_jrt_A_const_75 *lang.Var

var A_arbace_j2g_jrt_A_const_76 *lang.Var

var A_arbace_j2g_jrt_A_const_77 *lang.Var

var A_arbace_j2g_jrt_A_const_78 *lang.Var

var A_arbace_j2g_jrt_A_const_79 *lang.Keyword

var A_arbace_j2g_jrt_A_const_80 *lang.Var

var A_arbace_j2g_jrt_A_const_81 *lang.Var

var A_arbace_j2g_jrt_A_const_82 any

var A_arbace_j2g_jrt_A_const_83 *lang.Var

var A_arbace_j2g_jrt_A_const_84 *lang.Var

var A_arbace_j2g_jrt_A_const_85 *lang.Var

var A_arbace_j2g_jrt_A_const_86 *lang.Var

var A_arbace_j2g_jrt_A_const_87 *lang.Var

var A_arbace_j2g_jrt_A_const_88 *lang.Var

var A_arbace_j2g_jrt_A_const_89 *lang.Var

var A_arbace_j2g_jrt_A_const_90 *lang.Var

var A_arbace_j2g_jrt_A_const_91 *lang.Var

var A_arbace_j2g_jrt_A_const_92 *lang.Var

var A_arbace_j2g_jrt_A_const_93 *lang.Var

var A_arbace_j2g_jrt_A_const_94 *lang.Var

var A_arbace_j2g_jrt_A_const_95 *lang.Var

var A_arbace_j2g_jrt_A_const_96 *lang.Keyword

var A_arbace_j2g_jrt_A_const_97 *lang.Var

var A_arbace_j2g_jrt_A_const_98 *lang.Keyword

var A_arbace_j2g_jrt_A_const_99 *lang.Keyword

var A_arbace_j2g_jrt_A_const_100 *lang.Var

var A_arbace_j2g_jrt_A_const_101 any

var A_arbace_j2g_jrt_A_const_102 *lang.Keyword

var A_arbace_j2g_jrt_A_const_103 *lang.Keyword

var A_arbace_j2g_jrt_A_const_104 *lang.Var

var A_arbace_j2g_jrt_A_const_105 *lang.Var

var A_arbace_j2g_jrt_A_const_106 *lang.Keyword

var A_arbace_j2g_jrt_A_const_107 *lang.Var

var A_arbace_j2g_jrt_A_const_108 *lang.Var

var A_arbace_j2g_jrt_A_const_109 *lang.Var

var A_arbace_j2g_jrt_A_const_110 *lang.Var

var A_arbace_j2g_jrt_A_init jrt.ClassInit

func A_arbace_j2g_jrt_A_Init() { if !A_arbace_j2g_jrt_A_init.Done() { A_arbace_j2g_jrt_A_init.Run(A_arbace_j2g_jrt_A_clinit) } }

func A_arbace_j2g_jrt_A_clinit() { A_arbace_j2g_jrt_A_clinit_p0(); A_arbace_j2g_jrt_A_clinit_p1(); A_arbace_j2g_jrt_A_clinit_p2(); A_arbace_j2g_jrt_A_clinit_p3(); A_arbace_j2g_jrt_A_clinit_p4(); A_arbace_j2g_jrt_A_clinit_p5(); A_arbace_j2g_jrt_A_clinit_p6(); A_arbace_j2g_jrt_A_clinit_p7(); A_arbace_j2g_jrt_A_clinit_p8(); A_arbace_j2g_jrt_A_clinit_p9() }

func A_arbace_j2g_jrt_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_jrt_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 150); A_arbace_j2g_jrt_A_const_0 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[39]); A_arbace_j2g_jrt_A_const_1 = A_arbace_j2g_jrt_A_const_pool.A[40]; A_arbace_j2g_jrt_A_const_2 = A_arbace_j2g_jrt_A_const_pool.A[41]; A_arbace_j2g_jrt_A_const_3 = A_arbace_j2g_jrt_A_const_pool.A[42]; A_arbace_j2g_jrt_A_const_4 = A_arbace_j2g_jrt_A_const_pool.A[43]; A_arbace_j2g_jrt_A_const_5 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[44]); A_arbace_j2g_jrt_A_const_6 = A_arbace_j2g_jrt_A_const_pool.A[45]; A_arbace_j2g_jrt_A_const_7 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[46]); A_arbace_j2g_jrt_A_const_8 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[47]); A_arbace_j2g_jrt_A_const_9 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[48]); A_arbace_j2g_jrt_A_const_10 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[49]); A_arbace_j2g_jrt_A_const_11 = A_arbace_j2g_jrt_A_const_pool.A[50] }

func A_arbace_j2g_jrt_A_clinit_p1() { A_arbace_j2g_jrt_A_const_12 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[51]); A_arbace_j2g_jrt_A_const_13 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[52]); A_arbace_j2g_jrt_A_const_14 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[53]); A_arbace_j2g_jrt_A_const_15 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[54]); A_arbace_j2g_jrt_A_const_16 = A_arbace_j2g_jrt_A_const_pool.A[55]; A_arbace_j2g_jrt_A_const_17 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[56]); A_arbace_j2g_jrt_A_const_18 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[57]); A_arbace_j2g_jrt_A_const_19 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[58]); A_arbace_j2g_jrt_A_const_20 = A_arbace_j2g_jrt_A_const_pool.A[59]; A_arbace_j2g_jrt_A_const_21 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[60]); A_arbace_j2g_jrt_A_const_22 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[61]); A_arbace_j2g_jrt_A_const_23 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[62]) }

func A_arbace_j2g_jrt_A_clinit_p2() { A_arbace_j2g_jrt_A_const_24 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[63]); A_arbace_j2g_jrt_A_const_25 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[64]); A_arbace_j2g_jrt_A_const_26 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[65]); A_arbace_j2g_jrt_A_const_27 = A_arbace_j2g_jrt_A_const_pool.A[66]; A_arbace_j2g_jrt_A_const_28 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[67]); A_arbace_j2g_jrt_A_const_29 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[68]); A_arbace_j2g_jrt_A_const_30 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[69]); A_arbace_j2g_jrt_A_const_31 = A_arbace_j2g_jrt_A_const_pool.A[70]; A_arbace_j2g_jrt_A_const_32 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[71]); A_arbace_j2g_jrt_A_const_33 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[72]); A_arbace_j2g_jrt_A_const_34 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[73]); A_arbace_j2g_jrt_A_const_35 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[74]) }

func A_arbace_j2g_jrt_A_clinit_p3() { A_arbace_j2g_jrt_A_const_36 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[75]); A_arbace_j2g_jrt_A_const_37 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[76]); A_arbace_j2g_jrt_A_const_38 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[77]); A_arbace_j2g_jrt_A_const_39 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[78]); A_arbace_j2g_jrt_A_const_40 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[79]); A_arbace_j2g_jrt_A_const_41 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[80]); A_arbace_j2g_jrt_A_const_42 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[81]); A_arbace_j2g_jrt_A_const_43 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[82]); A_arbace_j2g_jrt_A_const_44 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[83]); A_arbace_j2g_jrt_A_const_45 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[84]); A_arbace_j2g_jrt_A_const_46 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[85]); A_arbace_j2g_jrt_A_const_47 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[86]) }

func A_arbace_j2g_jrt_A_clinit_p4() { A_arbace_j2g_jrt_A_const_48 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[87]); A_arbace_j2g_jrt_A_const_49 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[88]); A_arbace_j2g_jrt_A_const_50 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[89]); A_arbace_j2g_jrt_A_const_51 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[90]); A_arbace_j2g_jrt_A_const_52 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[91]); A_arbace_j2g_jrt_A_const_53 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[92]); A_arbace_j2g_jrt_A_const_54 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[93]); A_arbace_j2g_jrt_A_const_55 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[94]); A_arbace_j2g_jrt_A_const_56 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[95]); A_arbace_j2g_jrt_A_const_57 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[96]); A_arbace_j2g_jrt_A_const_58 = A_arbace_j2g_jrt_A_const_pool.A[97]; A_arbace_j2g_jrt_A_const_59 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[98]) }

func A_arbace_j2g_jrt_A_clinit_p5() { A_arbace_j2g_jrt_A_const_60 = A_arbace_j2g_jrt_A_const_pool.A[99]; A_arbace_j2g_jrt_A_const_61 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[100]); A_arbace_j2g_jrt_A_const_62 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[101]); A_arbace_j2g_jrt_A_const_63 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[102]); A_arbace_j2g_jrt_A_const_64 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[103]); A_arbace_j2g_jrt_A_const_65 = A_arbace_j2g_jrt_A_const_pool.A[104]; A_arbace_j2g_jrt_A_const_66 = A_arbace_j2g_jrt_A_const_pool.A[105]; A_arbace_j2g_jrt_A_const_67 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[106]); A_arbace_j2g_jrt_A_const_68 = A_arbace_j2g_jrt_A_const_pool.A[107]; A_arbace_j2g_jrt_A_const_69 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[108]); A_arbace_j2g_jrt_A_const_70 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[109]); A_arbace_j2g_jrt_A_const_71 = A_arbace_j2g_jrt_A_const_pool.A[110]; A_arbace_j2g_jrt_A_const_72 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[111]) }

func A_arbace_j2g_jrt_A_clinit_p6() { A_arbace_j2g_jrt_A_const_73 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[112]); A_arbace_j2g_jrt_A_const_74 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[113]); A_arbace_j2g_jrt_A_const_75 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[114]); A_arbace_j2g_jrt_A_const_76 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[115]); A_arbace_j2g_jrt_A_const_77 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[116]); A_arbace_j2g_jrt_A_const_78 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[117]); A_arbace_j2g_jrt_A_const_79 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[118]); A_arbace_j2g_jrt_A_const_80 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[119]); A_arbace_j2g_jrt_A_const_81 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[120]); A_arbace_j2g_jrt_A_const_82 = A_arbace_j2g_jrt_A_const_pool.A[121]; A_arbace_j2g_jrt_A_const_83 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[122]); A_arbace_j2g_jrt_A_const_84 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[123]) }

func A_arbace_j2g_jrt_A_clinit_p7() { A_arbace_j2g_jrt_A_const_85 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[124]); A_arbace_j2g_jrt_A_const_86 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[125]); A_arbace_j2g_jrt_A_const_87 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[126]); A_arbace_j2g_jrt_A_const_88 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[127]); A_arbace_j2g_jrt_A_const_89 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[128]); A_arbace_j2g_jrt_A_const_90 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[129]); A_arbace_j2g_jrt_A_const_91 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[130]); A_arbace_j2g_jrt_A_const_92 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[131]); A_arbace_j2g_jrt_A_const_93 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[132]); A_arbace_j2g_jrt_A_const_94 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[133]); A_arbace_j2g_jrt_A_const_95 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[134]); A_arbace_j2g_jrt_A_const_96 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[135]) }

func A_arbace_j2g_jrt_A_clinit_p8() { A_arbace_j2g_jrt_A_const_97 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[136]); A_arbace_j2g_jrt_A_const_98 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[137]); A_arbace_j2g_jrt_A_const_99 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[138]); A_arbace_j2g_jrt_A_const_100 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[139]); A_arbace_j2g_jrt_A_const_101 = A_arbace_j2g_jrt_A_const_pool.A[140]; A_arbace_j2g_jrt_A_const_102 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[141]); A_arbace_j2g_jrt_A_const_103 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[142]); A_arbace_j2g_jrt_A_const_104 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[143]); A_arbace_j2g_jrt_A_const_105 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[144]); A_arbace_j2g_jrt_A_const_106 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[145]); A_arbace_j2g_jrt_A_const_107 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[146]); A_arbace_j2g_jrt_A_const_108 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[147]) }

func A_arbace_j2g_jrt_A_clinit_p9() { A_arbace_j2g_jrt_A_const_109 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[148]); A_arbace_j2g_jrt_A_const_110 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[149]) }

func A_arbace_j2g_jrt_A_New() *A_arbace_j2g_jrt_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_jrt_A) Ctor() {}

func (t *A_arbace_j2g_jrt_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_jrt_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_jrt_A_class }

func (t *A_arbace_j2g_jrt_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_jrt_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_jrt_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_jrt_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_jrt_A); return ok }

func A_arbace_j2g_jrt_A_Cast(x any) *A_arbace_j2g_jrt_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_jrt_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_jrt_A_class)) }; return v }



type A_arbace_j2g_jrt_define_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_define_name_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_define_name_walk__1716000019_A struct{ j2g_header uint64; F_found any }

var A_arbace_j2g_jrt_define_name_walk__1716000019_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_eval1716000004_A struct{ jrt.Object }

func A_arbace_j2g_jrt_eval1716000004_A_New() *A_arbace_j2g_jrt_eval1716000004_A { t := &A_arbace_j2g_jrt_eval1716000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_jrt_eval1716000004_A) Ctor() {}

func (t *A_arbace_j2g_jrt_eval1716000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_jrt_eval1716000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_jrt_eval1716000004_A_class }

func (t *A_arbace_j2g_jrt_eval1716000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_jrt_eval1716000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_jrt_eval1716000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_jrt_eval1716000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_jrt_eval1716000004_A); return ok }

func A_arbace_j2g_jrt_eval1716000004_A_Cast(x any) *A_arbace_j2g_jrt_eval1716000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_jrt_eval1716000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_jrt_eval1716000004_A_class)) }; return v }



type A_arbace_j2g_jrt_eval1716000004_loading__1927001464__auto____1716000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_eval1716000004_loading__1927001464__auto____1716000005_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_eval1716000008_A struct{ jrt.Object }

func A_arbace_j2g_jrt_eval1716000008_A_New() *A_arbace_j2g_jrt_eval1716000008_A { t := &A_arbace_j2g_jrt_eval1716000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_jrt_eval1716000008_A) Ctor() {}

func (t *A_arbace_j2g_jrt_eval1716000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_jrt_eval1716000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_jrt_eval1716000008_A_class }

func (t *A_arbace_j2g_jrt_eval1716000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_jrt_eval1716000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_jrt_eval1716000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_jrt_eval1716000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_jrt_eval1716000008_A); return ok }

func A_arbace_j2g_jrt_eval1716000008_A_Cast(x any) *A_arbace_j2g_jrt_eval1716000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_jrt_eval1716000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_jrt_eval1716000008_A_class)) }; return v }



type A_arbace_j2g_jrt_eval1716000008_fn__1716000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_eval1716000008_fn__1716000009_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_go_head_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_go_head_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_head_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_head_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_iface_methods_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_iface_methods_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_iface_methods_fn__1716000268_A struct{ j2g_header uint64; F_scan any }

var A_arbace_j2g_jrt_iface_methods_fn__1716000268_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_interface_elems_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_interface_elems_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A struct{ j2g_header uint64; F_s__1716000162, F_iter__1716000161 any }

var A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A struct{ j2g_header uint64; F_b__1716000164 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A struct{ j2g_header uint64; F_s__1716000172, F_iter__1716000171 any }

var A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A struct{ j2g_header uint64; F_b__1716000174 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_other_system_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_other_system_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_jrt_recv_type_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_recv_type_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_recv_type_nm__1716000015_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_recv_type_nm__1716000015_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_scan_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_fn__1716000186_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_scan_fn__1716000186_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_fn__1716000188_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_scan_fn__1716000188_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A struct{ j2g_header uint64; F_s__1716000191, F_iter__1716000190 any }

var A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A struct{ j2g_header uint64; F_b__1716000193 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A struct{ j2g_header uint64; F_s__1716000201, F_iter__1716000200 any }

var A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A struct{ j2g_header uint64; F_fname any }

var A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A struct{ j2g_header uint64; F_s__1716000203, F_iter__1716000202, F_fname any }

var A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A struct{ j2g_header uint64; F_fname, F_b__1716000205 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A struct{ j2g_header uint64; F_s__1716000226, F_iter__1716000225 any }

var A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A struct{ j2g_header uint64; F_b__1716000228 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A struct{ j2g_header uint64; F_s__1716000246, F_iter__1716000245 any }

var A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A struct{ j2g_header uint64; F_b__1716000248 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_file_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_scan_file_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_strip_doc_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_strip_doc_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_struct_embed_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_struct_embed_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_struct_methods_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_struct_methods_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_tag_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_tag_of_A_fn_class *jrt.Class
