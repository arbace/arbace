//line aot_arbace_j2g_jrt.ae:1
package aot_arbace_j2g_jrt

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_jrt_eval1716000004_loading__1927001464__auto____1716000005_A_New() *A_arbace_j2g_jrt_eval1716000004_loading__1927001464__auto____1716000005_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_eval1716000004_loading__1927001464__auto____1716000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_jrt_eval1716000004_loading__1927001464__auto____1716000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_jrt_eval1716000004_loading__1927001464__auto____1716000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_jrt_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_jrt_A_const_2); tmp2 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_jrt_A_const_3, A_arbace_j2g_jrt_A_const_4, A_arbace_j2g_jrt_A_const_5, A_arbace_j2g_jrt_A_const_6); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_jrt_eval1716000008_fn__1716000009_A_New() *A_arbace_j2g_jrt_eval1716000008_fn__1716000009_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_eval1716000008_fn__1716000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_jrt_eval1716000008_fn__1716000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_jrt_eval1716000008_fn__1716000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_8.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_jrt_A_const_11), A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), A_arbace_j2g_jrt_A_const_10) }









func A_arbace_j2g_jrt_head_A_New() *A_arbace_j2g_jrt_head_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_head_A{}; t.Ctor(); return t }
//line :11:1
func (t *A_arbace_j2g_jrt_head_A) Ctor() {}
//line :11:1
func (t *A_arbace_j2g_jrt_head_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_12.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.J2g_Truth(and__1927000168__auto____2) { tmp1 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(f__0)) } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(f__0)) } else { return nil } }

func A_arbace_j2g_jrt_go_head_A_New() *A_arbace_j2g_jrt_go_head_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_go_head_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_j2g_jrt_go_head_A) Ctor() {}
//line :13:1
func (t *A_arbace_j2g_jrt_go_head_A) Invoke_O_O__O(self, f__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_12.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(f__0)); if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_16); tmp1 = tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(f__0))) } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(f__0)) } else {
//line :14:1
			return nil
		}
}
func A_arbace_j2g_jrt_tag_of_A_New() *A_arbace_j2g_jrt_tag_of_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_tag_of_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_j2g_jrt_tag_of_A) Ctor() {}
//line :17:1
func (t *A_arbace_j2g_jrt_tag_of_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_jrt_A_const_18; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0)) }

func A_arbace_j2g_jrt_recv_type_A_New() *A_arbace_j2g_jrt_recv_type_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_recv_type_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_j2g_jrt_recv_type_A) Ctor() {}
//line :19:1
func (t *A_arbace_j2g_jrt_recv_type_A) Invoke_O_O__O(self, r__0 any) any { var t__2 any; if


	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_13.GetRawRoot__O()).Invoke_O__O(r__0)) { t__2 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_19.GetRawRoot__O()).Invoke_O__O(r__0) } else { t__2 = r__0 }; var body_nm__3 /*line :19:1*/*A_arbace_j2g_jrt_recv_type_nm__1716000015_A = A_arbace_j2g_jrt_recv_type_nm__1716000015_A_New(); var nm__3 any; var tmp1 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_j2g_jrt_recv_type_nm__1716000015_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_j2g_jrt_recv_type_nm__1716000015_A_fn_class = fncls__1d; tmp1 = fncls__1d } else { tmp1 = fncls__1 }; nm__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_nm__3), tmp1, nil); return /*line :27:1*/ lang.IFn_Cast(nm__3).Invoke_O__O(t__2) }
//line :23:1
func A_arbace_j2g_jrt_recv_type_nm__1716000015_A_New() *A_arbace_j2g_jrt_recv_type_nm__1716000015_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_recv_type_nm__1716000015_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_j2g_jrt_recv_type_nm__1716000015_A) Ctor() {}
//line :23:1
func (t *A_arbace_j2g_jrt_recv_type_nm__1716000015_A) Invoke_O_O__O(self, x__1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_13.GetRawRoot__O()).Invoke_O__O(x__1)) { return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(x__1) } else { var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_12.GetRawRoot__O()).Invoke_O__O(x__1)
											if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_j2g_jrt_A_const_20; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(x__1))).Ref() } else { tmp1 = and__1927000168__auto____2 }
//line :23:1
	if jrt.J2g_Truth(tmp1) {
		return lang.IFn_Cast(self).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_22.GetRawRoot__O()).Invoke_O__O(x__1)) } else {
//line :23:1
			var tmp3 any; var and__1927000168__auto____2_2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_12.GetRawRoot__O()).Invoke_O__O(x__1)

			if jrt.J2g_Truth(and__1927000168__auto____2_2) { tmp3 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(x__1)) } else { tmp3 = and__1927000168__auto____2_2 }
//line :23:1
			if jrt.J2g_Truth(tmp3) {

				return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(x__1)) } else {
//line :23:1
					if A_arbace_j2g_jrt_A_const_21 != nil { return nil } else { return nil } } } } }





func A_arbace_j2g_jrt_strip_doc_A_New() *A_arbace_j2g_jrt_strip_doc_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_strip_doc_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_j2g_jrt_strip_doc_A) Ctor() {}
//line :29:1
func (t *A_arbace_j2g_jrt_strip_doc_A) Invoke_O_O__O(self, xs__0 any) any { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_23.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(xs__0))) { return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__0) } else { return xs__0 } }

func A_arbace_j2g_jrt_define_name_A_New() *A_arbace_j2g_jrt_define_name_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_define_name_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_j2g_jrt_define_name_A) Ctor() {}
//line :31:1
func (t *A_arbace_j2g_jrt_define_name_A) Invoke_O_O__O(self, init__0 any) any { var found__2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_25.GetRawRoot__O()).Invoke_O__O(nil); var body_walk__3 *A_arbace_j2g_jrt_define_name_walk__1716000019_A = A_arbace_j2g_jrt_define_name_walk__1716000019_A_New_O(found__2); var walk__3 any; var tmp1 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_j2g_jrt_define_name_walk__1716000019_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_j2g_jrt_define_name_walk__1716000019_A_fn_class = fncls__2d; tmp1 = fncls__2d } else { tmp1 = fncls__2 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__3), tmp1, nil);










	lang.IFn_Cast(walk__3).Invoke_O__O(init__0); return /*line :34:1*/ lang.IFn_Cast(A_arbace_j2g_jrt_A_const_8.GetRawRoot__O()).Invoke_O__O(found__2) }
func A_arbace_j2g_jrt_define_name_walk__1716000019_A_New_O(p0 any) *A_arbace_j2g_jrt_define_name_walk__1716000019_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_define_name_walk__1716000019_A{}; t.Ctor_O(p0); return t }
//line :35:1
func (t *A_arbace_j2g_jrt_define_name_walk__1716000019_A) Ctor_O(c__found any) { t.F_found = c__found }
//line :35:1
func (t *A_arbace_j2g_jrt_define_name_walk__1716000019_A) Invoke_O_O__O(self, x__1 any) any {
	var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_12.GetRawRoot__O()).Invoke_O__O(x__1)
	if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_2, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_26.GetRawRoot__O()).Invoke_O__O(x__1)); if and__1927000168__auto____3 { var tmp2 any = A_arbace_j2g_jrt_A_const_27; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_22.GetRawRoot__O()).Invoke_O__O(x__1))).Ref() } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { tmp1 = and__1927000168__auto____2 }
//line :36:1
	if jrt.J2g_Truth(tmp1) { var kvs__2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_28.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_jrt_A_const_31.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_32.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_jrt_A_const_33, x__1))


		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_23.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_jrt_A_const_34.Invoke_O__O(kvs__2))) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_29.GetRawRoot__O()); var tmp4 any = t.F_found; var tmp5 any = A_arbace_j2g_jrt_A_const_35; return tmp3.Invoke_O_O__O(tmp4, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, A_arbace_j2g_jrt_A_const_34.Invoke_O__O(kvs__2), A_arbace_j2g_jrt_A_const_36, kvs__2))) } else { return nil } } else {
//line :36:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_12.GetRawRoot__O()).Invoke_O__O(x__1)) {



				return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_30.GetRawRoot__O()).Invoke_O_O__O(self, x__1) } else {
//line :36:1
					if A_arbace_j2g_jrt_A_const_21 != nil { return nil } else { return nil
					}
				}
		}
}




func A_arbace_j2g_jrt_scan_file_A_New() *A_arbace_j2g_jrt_scan_file_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_file_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_j2g_jrt_scan_file_A) Ctor() {}
//line :45:1
func (t *A_arbace_j2g_jrt_scan_file_A) Invoke_O_O__O(self, f__0 any) any { var forms__2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_37.GetRawRoot__O()).Invoke_O__O(f__0); var acc__3 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_jrt_A_const_39, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_j2g_jrt_A_const_40, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_j2g_jrt_A_const_41, lang.PersistentHashSet_EMPTY.Ref(), A_arbace_j2g_jrt_A_const_42, lang.PersistentHashSet_EMPTY.Ref(), A_arbace_j2g_jrt_A_const_43, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_j2g_jrt_A_const_44, lang.PersistentHashSet_EMPTY.Ref()))); var seq_1716000022__4 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(forms__2); var chunk_1716000023__5 any; var count_1716000024__6 int64 = 0; var i_1716000025__7 int64 = 0; L1: for {





	if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000025__7, count_1716000024__6) { var fm__8 any = lang.Indexed_Cast(chunk_1716000023__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000025__7)); var h__9 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_46.GetRawRoot__O()).Invoke_O__O(fm__8); if jrt.J2g_Truth(h__9) { var G__1716000026__10_ any = h__9


	L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__1716000026__10_) >> 0 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000026__10_, Lit_31) { var vec__1716000027__11 any = fm__8; var seq__1716000028__12 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(vec__1716000027__11); var first__1716000029__13 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(seq__1716000028__12); var seq__1716000028__14 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(seq__1716000028__12); var ___15 any = first__1716000029__13; var first__1716000029__16 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(seq__1716000028__14); var seq__1716000028__17 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(seq__1716000028__14); var nm__18 any = first__1716000029__16; var more__19 any = seq__1716000028__17; var more__20 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_50.GetRawRoot__O()).Invoke_O__O(more__19); var more__21 any; var tmp1 any = A_arbace_j2g_jrt_A_const_51; _ = ___15




















		if lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(more__20)) { more__21 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_32.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_jrt_A_const_33, more__20) } else { more__21 = more__20 }
//line :54:1
		var params__22 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(more__21); var rt__23 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_52.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(params__22))























		if jrt.J2g_Truth(rt__23) { jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_53.GetRawRoot__O()).Invoke_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(), lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_jrt_A_const_40, rt__23), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_57.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.PersistentHashSet_EMPTY.Ref()), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(nm__18))) }
//line :54:1
		break L2 }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000026__10_, Lit_32) { var vec__1716000030__11 any = fm__8; var seq__1716000031__12 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(vec__1716000030__11); var first__1716000032__13 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(seq__1716000031__12); var seq__1716000031__14 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(seq__1716000031__12); var ___15_2 any = first__1716000032__13; var more__16 any = seq__1716000031__14; var more__17 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_50.GetRawRoot__O()).Invoke_O__O(more__16); _ = ___15_2


			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_54.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(more__17))) { var seq_1716000033__18 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(more__17); var chunk_1716000034__19 any; var count_1716000035__20 int64 = 0; var i_1716000036__21 int64 = 0; L3: for {
				if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000036__21, count_1716000035__20) { var vec__1716000037__22 any = lang.Indexed_Cast(chunk_1716000034__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000036__21)); var nm__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000037__22, lang.RT_IntCast_J__I_NoInit(0), nil); var tf__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000037__22, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_55.GetRawRoot__O()); var tmp4 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp5 any = A_arbace_j2g_jrt_A_const_39; var tmp6 any = lang.Tuple_Create_O_O__IPersistentVector(tmp5, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(nm__23)); var tmp7 any = A_arbace_j2g_jrt_A_const_58; var tmp8 *lang.Keyword; var tmp9 any; var and__1927000168__auto____25 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_12.GetRawRoot__O()).Invoke_O__O(tf__24)

					if jrt.J2g_Truth(and__1927000168__auto____25) { var tmp10 any = A_arbace_j2g_jrt_A_const_59; tmp9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp10, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(tf__24))).Ref() } else { tmp9 = and__1927000168__auto____25 }; if jrt.J2g_Truth(tmp9) { tmp8 = A_arbace_j2g_jrt_A_const_60 } else { var tmp11 any; var and__1927000168__auto____25_2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_12.GetRawRoot__O()).Invoke_O__O(tf__24)
						if jrt.J2g_Truth(and__1927000168__auto____25_2) { var tmp12 any = A_arbace_j2g_jrt_A_const_61; tmp11 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp12, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(tf__24))).Ref() } else { tmp11 = and__1927000168__auto____25_2 }
//line :60:1
						if jrt.J2g_Truth(tmp11) { tmp8 = A_arbace_j2g_jrt_A_const_62 } else { if A_arbace_j2g_jrt_A_const_21 != nil { tmp8 = A_arbace_j2g_jrt_A_const_63 } else { tmp8 = nil } } }
//line :59:1
					jrt.NN(tmp2).Reset_O__O(tmp3.Invoke_O_O_O__O(tmp4, tmp6, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8.Ref(), A_arbace_j2g_jrt_A_const_64, tf__24))))
//line :58:1
					seq_1716000033__18, chunk_1716000034__19, count_1716000035__20, i_1716000036__21 = seq_1716000033__18, chunk_1716000034__19, count_1716000035__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000036__21); continue L3 } else { var temp__1927000414__auto____22 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(seq_1716000033__18); if jrt.J2g_Truth(temp__1927000414__auto____22) { var seq_1716000033__23 any = temp__1927000414__auto____22; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1716000033__23)) { var c__1927000678__auto____24 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1716000033__23); seq_1716000033__18, chunk_1716000034__19, count_1716000035__20, i_1716000036__21 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_65.GetRawRoot__O()).Invoke_O__O(seq_1716000033__23), c__1927000678__auto____24, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__1716000040__24 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1716000033__23); var nm__25 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000040__24, lang.RT_IntCast_J__I_NoInit(0), nil); var tf__26 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000040__24, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp13 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_55.GetRawRoot__O()); var tmp15 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp16 any = A_arbace_j2g_jrt_A_const_39; var tmp17 any = lang.Tuple_Create_O_O__IPersistentVector(tmp16, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(nm__25)); var tmp18 any = A_arbace_j2g_jrt_A_const_58; var tmp19 *lang.Keyword; var tmp20 any; var and__1927000168__auto____27 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_12.GetRawRoot__O()).Invoke_O__O(tf__26)

						if jrt.J2g_Truth(and__1927000168__auto____27) { var tmp21 any = A_arbace_j2g_jrt_A_const_59; tmp20 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp21, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(tf__26))).Ref() } else { tmp20 = and__1927000168__auto____27 }; if jrt.J2g_Truth(tmp20) { tmp19 = A_arbace_j2g_jrt_A_const_60 } else { var tmp22 any; var and__1927000168__auto____27_2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_12.GetRawRoot__O()).Invoke_O__O(tf__26)
							if jrt.J2g_Truth(and__1927000168__auto____27_2) { var tmp23 any = A_arbace_j2g_jrt_A_const_61; tmp22 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp23, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(tf__26))).Ref() } else { tmp22 = and__1927000168__auto____27_2 }
//line :60:1
							if jrt.J2g_Truth(tmp22) { tmp19 = A_arbace_j2g_jrt_A_const_62 } else { if A_arbace_j2g_jrt_A_const_21 != nil { tmp19 = A_arbace_j2g_jrt_A_const_63 } else { tmp19 = nil } } }
//line :59:1
						jrt.NN(tmp13).Reset_O__O(tmp14.Invoke_O_O_O__O(tmp15, tmp17, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp18, tmp19.Ref(), A_arbace_j2g_jrt_A_const_64, tf__26))))
//line :58:1
						seq_1716000033__18, chunk_1716000034__19, count_1716000035__20, i_1716000036__21 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(seq_1716000033__23), nil, 0, 0; continue L3 } } }
//line :57:1
				break L3 } } else { var nm__18_2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(more__17); var more__19_2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_50.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_24.GetRawRoot__O()).Invoke_O__O(more__17)); var more__20_2 any
					var tmp24 any = A_arbace_j2g_jrt_A_const_51







					if lang.Util_Equiv_O_O__Z_NoInit(tmp24, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(more__19_2)) { more__20_2 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_32.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_jrt_A_const_33, more__19_2) } else { more__20_2 = more__19_2 }
//line :57:1
					var tf__21 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(more__20_2); var tmp25 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_55.GetRawRoot__O()); var tmp27 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp28 any = A_arbace_j2g_jrt_A_const_39; var tmp29 any = lang.Tuple_Create_O_O__IPersistentVector(tmp28, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(nm__18_2)); var tmp30 any = A_arbace_j2g_jrt_A_const_58; var tmp31 *lang.Keyword; var tmp32 any; var and__1927000168__auto____22 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_12.GetRawRoot__O()).Invoke_O__O(tf__21)











					if jrt.J2g_Truth(and__1927000168__auto____22) { var tmp33 any = A_arbace_j2g_jrt_A_const_66; tmp32 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp33, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(tf__21))).Ref() } else { tmp32 = and__1927000168__auto____22 }; if jrt.J2g_Truth(tmp32) { tmp31 = A_arbace_j2g_jrt_A_const_60 } else { var tmp34 any; var and__1927000168__auto____22_2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_12.GetRawRoot__O()).Invoke_O__O(tf__21)
						if jrt.J2g_Truth(and__1927000168__auto____22_2) { var tmp35 any = A_arbace_j2g_jrt_A_const_67; tmp34 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp35, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(tf__21))).Ref() } else { tmp34 = and__1927000168__auto____22_2 }
//line :69:1
						if jrt.J2g_Truth(tmp34) { tmp31 = A_arbace_j2g_jrt_A_const_62 } else { if A_arbace_j2g_jrt_A_const_21 != nil { tmp31 = A_arbace_j2g_jrt_A_const_63 } else { tmp31 = nil } } }
//line :68:1
					jrt.NN(tmp25).Reset_O__O(tmp26.Invoke_O_O_O__O(tmp27, tmp29, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp30, tmp31.Ref(), A_arbace_j2g_jrt_A_const_64, tf__21)))) }
//line :54:1
			break L2 }; case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000026__10_, Lit_33) { var vec__1716000043__11 any = fm__8; var seq__1716000044__12 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(vec__1716000043__11); var first__1716000045__13 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(seq__1716000044__12); var seq__1716000044__14 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(seq__1716000044__12); var ___15_3 any = first__1716000045__13; var more__16_2 any = seq__1716000044__14; var more__17_2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_50.GetRawRoot__O()).Invoke_O__O(more__16_2); _ = ___15_3










































				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_54.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(more__17_2))) { var seq_1716000046__18 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(more__17_2); var chunk_1716000047__19 any; var count_1716000048__20 int64 = 0; var i_1716000049__21 int64 = 0; L4: for {
					if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000049__21, count_1716000048__20) { var vec__1716000050__22 any = lang.Indexed_Cast(chunk_1716000047__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000049__21)); var tg__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000050__22, lang.RT_IntCast_J__I_NoInit(0), nil); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_13.GetRawRoot__O()).Invoke_O__O(tg__23)) { var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_56.GetRawRoot__O()); var tmp37 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp38 any = A_arbace_j2g_jrt_A_const_44; jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(tmp36.Invoke_O_O_O_O__O(tmp37, tmp38, A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(tg__23))) }; seq_1716000046__18, chunk_1716000047__19, count_1716000048__20, i_1716000049__21 = seq_1716000046__18, chunk_1716000047__19, count_1716000048__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000049__21); continue L4 } else { var temp__1927000414__auto____22_2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(seq_1716000046__18); if jrt.J2g_Truth(temp__1927000414__auto____22_2) { var seq_1716000046__23 any = temp__1927000414__auto____22_2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1716000046__23)) { var c__1927000678__auto____24_2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1716000046__23); seq_1716000046__18, chunk_1716000047__19, count_1716000048__20, i_1716000049__21 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_65.GetRawRoot__O()).Invoke_O__O(seq_1716000046__23), c__1927000678__auto____24_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var vec__1716000053__24 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1716000046__23); var tg__25 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000053__24, lang.RT_IntCast_J__I_NoInit(0), nil); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_13.GetRawRoot__O()).Invoke_O__O(tg__25)) { var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_56.GetRawRoot__O()); var tmp40 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp41 any = A_arbace_j2g_jrt_A_const_44; jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(tmp39.Invoke_O_O_O_O__O(tmp40, tmp41, A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(tg__25))) }; seq_1716000046__18, chunk_1716000047__19, count_1716000048__20, i_1716000049__21 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(seq_1716000046__23), nil, 0, 0; continue L4 } } }
//line :97:1
					break L4 } } else {

						if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(more__17_2))) { var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_56.GetRawRoot__O()); var tmp43 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp44 any = A_arbace_j2g_jrt_A_const_44; jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(tmp42.Invoke_O_O_O_O__O(tmp43, tmp44, A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(more__17_2)))) } }
//line :54:1
				break L2 }; case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000026__10_, Lit_34) { var vec__1716000056__11 any = fm__8; var ___12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000056__11, lang.RT_IntCast_J__I_NoInit(0), nil); var nm__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000056__11, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp45 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_56.GetRawRoot__O()); var tmp46 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp47 any = A_arbace_j2g_jrt_A_const_41; _ = ___12
























					jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(tmp45.Invoke_O_O_O_O__O(tmp46, tmp47, A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(nm__13)))
//line :54:1
					break L2 }; case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000026__10_, Lit_35) { var vec__1716000059__11 any = fm__8; var seq__1716000060__12 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(vec__1716000059__11); var first__1716000061__13 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(seq__1716000060__12); var seq__1716000060__14 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(seq__1716000060__12); var ___15_4 any = first__1716000061__13; var more__16_3 any = seq__1716000060__14; var more__17_3 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_50.GetRawRoot__O()).Invoke_O__O(more__16_3); _ = ___15_4



























						if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_54.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(more__17_3))) { var seq_1716000062__18 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(more__17_3); var chunk_1716000063__19 any; var count_1716000064__20 int64 = 0; var i_1716000065__21 int64 = 0; L5: for {
							if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000065__21, count_1716000064__20) { var vec__1716000066__22 any = lang.Indexed_Cast(chunk_1716000063__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000065__21)); var tg__23_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000066__22, lang.RT_IntCast_J__I_NoInit(0), nil); var init__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000066__22, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp48 any; var and__1927000168__auto____25_3 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_12.GetRawRoot__O()).Invoke_O__O(tg__23_2)
								if jrt.J2g_Truth(and__1927000168__auto____25_3) { var tmp49 any = A_arbace_j2g_jrt_A_const_71; tmp48 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp49, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(tg__23_2))).Ref() } else { tmp48 = and__1927000168__auto____25_3 }; if jrt.J2g_Truth(tmp48) { var seq_1716000069__25 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_24.GetRawRoot__O()).Invoke_O__O(tg__23_2)); var chunk_1716000070__26 any; var count_1716000071__27 int64 = 0; var i_1716000072__28 int64 = 0; L6: for {
									if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000072__28, count_1716000071__27) { var s__29 any = lang.Indexed_Cast(chunk_1716000070__26).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000072__28)); var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_56.GetRawRoot__O()); var tmp51 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp52 any = A_arbace_j2g_jrt_A_const_42; jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(tmp50.Invoke_O_O_O_O__O(tmp51, tmp52, A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(s__29))); seq_1716000069__25, chunk_1716000070__26, count_1716000071__27, i_1716000072__28 = seq_1716000069__25, chunk_1716000070__26, count_1716000071__27, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000072__28); continue L6 } else { var temp__1927000414__auto____29 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(seq_1716000069__25); if jrt.J2g_Truth(temp__1927000414__auto____29) { var seq_1716000069__30 any = temp__1927000414__auto____29; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1716000069__30)) { var c__1927000678__auto____31 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1716000069__30); seq_1716000069__25, chunk_1716000070__26, count_1716000071__27, i_1716000072__28 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_65.GetRawRoot__O()).Invoke_O__O(seq_1716000069__30), c__1927000678__auto____31, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____31))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L6 } else { var s__31 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1716000069__30); var tmp53 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_56.GetRawRoot__O()); var tmp54 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp55 any = A_arbace_j2g_jrt_A_const_42; jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(tmp53.Invoke_O_O_O_O__O(tmp54, tmp55, A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(s__31))); seq_1716000069__25, chunk_1716000070__26, count_1716000071__27, i_1716000072__28 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(seq_1716000069__30), nil, 0, 0; continue L6 } } }
//line :84:1
									break L6 } } else {

										var tmp56 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_56.GetRawRoot__O()); var tmp57 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp58 any = A_arbace_j2g_jrt_A_const_42; jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(tmp56.Invoke_O_O_O_O__O(tmp57, tmp58, A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(tg__23_2)))
//line :84:1
										var temp__1927000414__auto____25 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_69.GetRawRoot__O()).Invoke_O__O(init__24)


										if jrt.J2g_Truth(temp__1927000414__auto____25) { var map__1716000073__26 any = temp__1927000414__auto____25; var map__1716000073__27 any; if lang.ISeq_InstanceOf(map__1716000073__26) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(map__1716000073__26)) { map__1716000073__27 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_j2g_jrt_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1716000073__26), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(map__1716000073__26)) { map__1716000073__27 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(map__1716000073__26) } else { map__1716000073__27 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000073__27 = map__1716000073__26 }; var n__28 any = lang.RT_Get_O_O__O_NoInit(map__1716000073__27, A_arbace_j2g_jrt_A_const_35)
											jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_55.GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(), lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_jrt_A_const_43, n__28), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(tg__23_2))) } }
//line :83:1
								seq_1716000062__18, chunk_1716000063__19, count_1716000064__20, i_1716000065__21 = seq_1716000062__18, chunk_1716000063__19, count_1716000064__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000065__21); continue L5 } else { var temp__1927000414__auto____22_3 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(seq_1716000062__18); if jrt.J2g_Truth(temp__1927000414__auto____22_3) { var seq_1716000062__23 any = temp__1927000414__auto____22_3; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1716000062__23)) { var c__1927000678__auto____24_3 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1716000062__23); seq_1716000062__18, chunk_1716000063__19, count_1716000064__20, i_1716000065__21 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_65.GetRawRoot__O()).Invoke_O__O(seq_1716000062__23), c__1927000678__auto____24_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var vec__1716000075__24 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1716000062__23); var tg__25_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000075__24, lang.RT_IntCast_J__I_NoInit(0), nil); var init__26 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000075__24, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp59 any; var and__1927000168__auto____27_3 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_12.GetRawRoot__O()).Invoke_O__O(tg__25_2)
									if jrt.J2g_Truth(and__1927000168__auto____27_3) { var tmp60 any = A_arbace_j2g_jrt_A_const_71; tmp59 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp60, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(tg__25_2))).Ref() } else { tmp59 = and__1927000168__auto____27_3 }; if jrt.J2g_Truth(tmp59) { var seq_1716000078__27 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_24.GetRawRoot__O()).Invoke_O__O(tg__25_2)); var chunk_1716000079__28 any; var count_1716000080__29 int64 = 0; var i_1716000081__30 int64 = 0; L7: for {
										if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000081__30, count_1716000080__29) { var s__31_2 any = lang.Indexed_Cast(chunk_1716000079__28).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000081__30)); var tmp61 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_56.GetRawRoot__O()); var tmp62 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp63 any = A_arbace_j2g_jrt_A_const_42; jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(tmp61.Invoke_O_O_O_O__O(tmp62, tmp63, A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(s__31_2))); seq_1716000078__27, chunk_1716000079__28, count_1716000080__29, i_1716000081__30 = seq_1716000078__27, chunk_1716000079__28, count_1716000080__29, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000081__30); continue L7 } else { var temp__1927000414__auto____31 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(seq_1716000078__27); if jrt.J2g_Truth(temp__1927000414__auto____31) { var seq_1716000078__32 any = temp__1927000414__auto____31; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1716000078__32)) { var c__1927000678__auto____33 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1716000078__32); seq_1716000078__27, chunk_1716000079__28, count_1716000080__29, i_1716000081__30 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_65.GetRawRoot__O()).Invoke_O__O(seq_1716000078__32), c__1927000678__auto____33, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____33))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L7 } else { var s__33 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1716000078__32); var tmp64 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_56.GetRawRoot__O()); var tmp65 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp66 any = A_arbace_j2g_jrt_A_const_42; jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(tmp64.Invoke_O_O_O_O__O(tmp65, tmp66, A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(s__33))); seq_1716000078__27, chunk_1716000079__28, count_1716000080__29, i_1716000081__30 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(seq_1716000078__32), nil, 0, 0; continue L7 } } }
//line :84:1
										break L7 } } else {

											var tmp67 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_56.GetRawRoot__O()); var tmp68 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp69 any = A_arbace_j2g_jrt_A_const_42; jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(tmp67.Invoke_O_O_O_O__O(tmp68, tmp69, A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(tg__25_2)))
//line :84:1
											var temp__1927000414__auto____27 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_69.GetRawRoot__O()).Invoke_O__O(init__26)


											if jrt.J2g_Truth(temp__1927000414__auto____27) { var map__1716000082__28 any = temp__1927000414__auto____27; var map__1716000082__29 any; if lang.ISeq_InstanceOf(map__1716000082__28) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(map__1716000082__28)) { map__1716000082__29 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_j2g_jrt_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1716000082__28), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(map__1716000082__28)) { map__1716000082__29 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(map__1716000082__28) } else { map__1716000082__29 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000082__29 = map__1716000082__28 }; var n__30 any = lang.RT_Get_O_O__O_NoInit(map__1716000082__29, A_arbace_j2g_jrt_A_const_35)
												jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_55.GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(), lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_jrt_A_const_43, n__30), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(tg__25_2))) } }
//line :83:1
									seq_1716000062__18, chunk_1716000063__19, count_1716000064__20, i_1716000065__21 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(seq_1716000062__23), nil, 0, 0; continue L5 } } }
//line :82:1
							break L5 } } else { var vec__1716000084__18 any = more__17_3; var tg__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000084__18, lang.RT_IntCast_J__I_NoInit(0), nil); var init__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000084__18, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp70 any; var and__1927000168__auto____21 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_12.GetRawRoot__O()).Invoke_O__O(tg__19)







								if jrt.J2g_Truth(and__1927000168__auto____21) { var tmp71 any = A_arbace_j2g_jrt_A_const_68; tmp70 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp71, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(tg__19))).Ref() } else { tmp70 = and__1927000168__auto____21 }; if jrt.J2g_Truth(tmp70) { var seq_1716000087__21 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_24.GetRawRoot__O()).Invoke_O__O(tg__19)); var chunk_1716000088__22 any; var count_1716000089__23 int64 = 0; var i_1716000090__24 int64 = 0; L8: for {
									if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000090__24, count_1716000089__23) { var s__25 any = lang.Indexed_Cast(chunk_1716000088__22).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000090__24)); var tmp72 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_56.GetRawRoot__O()); var tmp73 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp74 any = A_arbace_j2g_jrt_A_const_42; jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(tmp72.Invoke_O_O_O_O__O(tmp73, tmp74, A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(s__25))); seq_1716000087__21, chunk_1716000088__22, count_1716000089__23, i_1716000090__24 = seq_1716000087__21, chunk_1716000088__22, count_1716000089__23, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000090__24); continue L8 } else { var temp__1927000414__auto____25_2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(seq_1716000087__21); if jrt.J2g_Truth(temp__1927000414__auto____25_2) { var seq_1716000087__26 any = temp__1927000414__auto____25_2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1716000087__26)) { var c__1927000678__auto____27 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1716000087__26); seq_1716000087__21, chunk_1716000088__22, count_1716000089__23, i_1716000090__24 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_65.GetRawRoot__O()).Invoke_O__O(seq_1716000087__26), c__1927000678__auto____27, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____27))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L8 } else { var s__27 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1716000087__26); var tmp75 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_56.GetRawRoot__O()); var tmp76 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp77 any = A_arbace_j2g_jrt_A_const_42; jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(tmp75.Invoke_O_O_O_O__O(tmp76, tmp77, A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(s__27))); seq_1716000087__21, chunk_1716000088__22, count_1716000089__23, i_1716000090__24 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(seq_1716000087__26), nil, 0, 0; continue L8 } } }
//line :90:1
									break L8 } } else {

										var tmp78 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_56.GetRawRoot__O()); var tmp79 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp80 any = A_arbace_j2g_jrt_A_const_42; jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(tmp78.Invoke_O_O_O_O__O(tmp79, tmp80, A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(tg__19)))
//line :90:1
										var temp__1927000414__auto____21 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_69.GetRawRoot__O()).Invoke_O__O(init__20)


										if jrt.J2g_Truth(temp__1927000414__auto____21) { var map__1716000091__22 any = temp__1927000414__auto____21; var map__1716000091__23 any; if lang.ISeq_InstanceOf(map__1716000091__22) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(map__1716000091__22)) { map__1716000091__23 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_j2g_jrt_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1716000091__22), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(map__1716000091__22)) { map__1716000091__23 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(map__1716000091__22) } else { map__1716000091__23 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000091__23 = map__1716000091__22 }; var n__24 any = lang.RT_Get_O_O__O_NoInit(map__1716000091__23, A_arbace_j2g_jrt_A_const_35)
											jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_55.GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(), lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_jrt_A_const_43, n__24), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(tg__19))) } } }
//line :54:1
						break L2 }; default:}}
//line :51:1
		seq_1716000022__4, chunk_1716000023__5, count_1716000024__6, i_1716000025__7 = seq_1716000022__4, chunk_1716000023__5, count_1716000024__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000025__7); continue L1 } else { seq_1716000022__4, chunk_1716000023__5, count_1716000024__6, i_1716000025__7 = seq_1716000022__4, chunk_1716000023__5, count_1716000024__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000025__7); continue L1 } } else { var temp__1927000414__auto____8 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(seq_1716000022__4); if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1716000022__9 any = temp__1927000414__auto____8; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1716000022__9)) { var c__1927000678__auto____10 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1716000022__9); seq_1716000022__4, chunk_1716000023__5, count_1716000024__6, i_1716000025__7 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_65.GetRawRoot__O()).Invoke_O__O(seq_1716000022__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var fm__10 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1716000022__9); var h__11 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_46.GetRawRoot__O()).Invoke_O__O(fm__10); if jrt.J2g_Truth(h__11) { var G__1716000093__12_ any = h__11


		L9: switch { default: switch lang.Util_Hash_O__I_NoInit(G__1716000093__12_) >> 0 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000093__12_, Lit_31) { var vec__1716000094__13 any = fm__10; var seq__1716000095__14 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(vec__1716000094__13); var first__1716000096__15 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(seq__1716000095__14); var seq__1716000095__16 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(seq__1716000095__14); var ___17 any = first__1716000096__15; var first__1716000096__18 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(seq__1716000095__16); var seq__1716000095__19 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(seq__1716000095__16); var nm__20 any = first__1716000096__18; var more__21_2 any = seq__1716000095__19; var more__22 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_50.GetRawRoot__O()).Invoke_O__O(more__21_2); var more__23 any; var tmp81 any = A_arbace_j2g_jrt_A_const_51; _ = ___17




















			if lang.Util_Equiv_O_O__Z_NoInit(tmp81, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(more__22)) { more__23 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_32.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_jrt_A_const_33, more__22) } else { more__23 = more__22 }
//line :54:1
			var params__24 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(more__23); var rt__25 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_52.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(params__24))























			if jrt.J2g_Truth(rt__25) { jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_53.GetRawRoot__O()).Invoke_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(), lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_jrt_A_const_40, rt__25), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_57.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.PersistentHashSet_EMPTY.Ref()), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(nm__20))) }
//line :54:1
			break L9 }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000093__12_, Lit_32) { var vec__1716000097__13 any = fm__10; var seq__1716000098__14 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(vec__1716000097__13); var first__1716000099__15 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(seq__1716000098__14); var seq__1716000098__16 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(seq__1716000098__14); var ___17_2 any = first__1716000099__15; var more__18 any = seq__1716000098__16; var more__19_3 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_50.GetRawRoot__O()).Invoke_O__O(more__18); _ = ___17_2


				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_54.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(more__19_3))) { var seq_1716000100__20 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(more__19_3); var chunk_1716000101__21 any; var count_1716000102__22 int64 = 0; var i_1716000103__23 int64 = 0; L10: for {
					if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000103__23, count_1716000102__22) { var vec__1716000104__24 any = lang.Indexed_Cast(chunk_1716000101__21).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000103__23)); var nm__25_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000104__24, lang.RT_IntCast_J__I_NoInit(0), nil); var tf__26_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000104__24, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp82 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp83 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_55.GetRawRoot__O()); var tmp84 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp85 any = A_arbace_j2g_jrt_A_const_39; var tmp86 any = lang.Tuple_Create_O_O__IPersistentVector(tmp85, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(nm__25_2)); var tmp87 any = A_arbace_j2g_jrt_A_const_58; var tmp88 *lang.Keyword; var tmp89 any; var and__1927000168__auto____27_4 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_12.GetRawRoot__O()).Invoke_O__O(tf__26_2)

						if jrt.J2g_Truth(and__1927000168__auto____27_4) { var tmp90 any = A_arbace_j2g_jrt_A_const_59; tmp89 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp90, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(tf__26_2))).Ref() } else { tmp89 = and__1927000168__auto____27_4 }; if jrt.J2g_Truth(tmp89) { tmp88 = A_arbace_j2g_jrt_A_const_60 } else { var tmp91 any; var and__1927000168__auto____27_5 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_12.GetRawRoot__O()).Invoke_O__O(tf__26_2)
							if jrt.J2g_Truth(and__1927000168__auto____27_5) { var tmp92 any = A_arbace_j2g_jrt_A_const_61; tmp91 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp92, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(tf__26_2))).Ref() } else { tmp91 = and__1927000168__auto____27_5 }
//line :60:1
							if jrt.J2g_Truth(tmp91) { tmp88 = A_arbace_j2g_jrt_A_const_62 } else { if A_arbace_j2g_jrt_A_const_21 != nil { tmp88 = A_arbace_j2g_jrt_A_const_63 } else { tmp88 = nil } } }
//line :59:1
						jrt.NN(tmp82).Reset_O__O(tmp83.Invoke_O_O_O__O(tmp84, tmp86, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp87, tmp88.Ref(), A_arbace_j2g_jrt_A_const_64, tf__26_2))))
//line :58:1
						seq_1716000100__20, chunk_1716000101__21, count_1716000102__22, i_1716000103__23 = seq_1716000100__20, chunk_1716000101__21, count_1716000102__22, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000103__23); continue L10 } else { var temp__1927000414__auto____24 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(seq_1716000100__20); if jrt.J2g_Truth(temp__1927000414__auto____24) { var seq_1716000100__25 any = temp__1927000414__auto____24; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1716000100__25)) { var c__1927000678__auto____26 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1716000100__25); seq_1716000100__20, chunk_1716000101__21, count_1716000102__22, i_1716000103__23 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_65.GetRawRoot__O()).Invoke_O__O(seq_1716000100__25), c__1927000678__auto____26, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____26))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L10 } else { var vec__1716000107__26 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1716000100__25); var nm__27 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000107__26, lang.RT_IntCast_J__I_NoInit(0), nil); var tf__28 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000107__26, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp93 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp94 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_55.GetRawRoot__O()); var tmp95 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp96 any = A_arbace_j2g_jrt_A_const_39; var tmp97 any = lang.Tuple_Create_O_O__IPersistentVector(tmp96, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(nm__27)); var tmp98 any = A_arbace_j2g_jrt_A_const_58; var tmp99 *lang.Keyword; var tmp100 any; var and__1927000168__auto____29 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_12.GetRawRoot__O()).Invoke_O__O(tf__28)

							if jrt.J2g_Truth(and__1927000168__auto____29) { var tmp101 any = A_arbace_j2g_jrt_A_const_59; tmp100 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp101, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(tf__28))).Ref() } else { tmp100 = and__1927000168__auto____29 }; if jrt.J2g_Truth(tmp100) { tmp99 = A_arbace_j2g_jrt_A_const_60 } else { var tmp102 any; var and__1927000168__auto____29_2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_12.GetRawRoot__O()).Invoke_O__O(tf__28)
								if jrt.J2g_Truth(and__1927000168__auto____29_2) { var tmp103 any = A_arbace_j2g_jrt_A_const_61; tmp102 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp103, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(tf__28))).Ref() } else { tmp102 = and__1927000168__auto____29_2 }
//line :60:1
								if jrt.J2g_Truth(tmp102) { tmp99 = A_arbace_j2g_jrt_A_const_62 } else { if A_arbace_j2g_jrt_A_const_21 != nil { tmp99 = A_arbace_j2g_jrt_A_const_63 } else { tmp99 = nil } } }
//line :59:1
							jrt.NN(tmp93).Reset_O__O(tmp94.Invoke_O_O_O__O(tmp95, tmp97, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp98, tmp99.Ref(), A_arbace_j2g_jrt_A_const_64, tf__28))))
//line :58:1
							seq_1716000100__20, chunk_1716000101__21, count_1716000102__22, i_1716000103__23 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(seq_1716000100__25), nil, 0, 0; continue L10 } } }
//line :57:1
					break L10 } } else { var nm__20_2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(more__19_3); var more__21_3 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_50.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_24.GetRawRoot__O()).Invoke_O__O(more__19_3)); var more__22_2 any
						var tmp104 any = A_arbace_j2g_jrt_A_const_51







						if lang.Util_Equiv_O_O__Z_NoInit(tmp104, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(more__21_3)) { more__22_2 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_32.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_jrt_A_const_33, more__21_3) } else { more__22_2 = more__21_3 }
//line :57:1
						var tf__23 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(more__22_2); var tmp105 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp106 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_55.GetRawRoot__O()); var tmp107 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp108 any = A_arbace_j2g_jrt_A_const_39; var tmp109 any = lang.Tuple_Create_O_O__IPersistentVector(tmp108, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(nm__20_2)); var tmp110 any = A_arbace_j2g_jrt_A_const_58; var tmp111 *lang.Keyword; var tmp112 any; var and__1927000168__auto____24 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_12.GetRawRoot__O()).Invoke_O__O(tf__23)











						if jrt.J2g_Truth(and__1927000168__auto____24) { var tmp113 any = A_arbace_j2g_jrt_A_const_66; tmp112 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp113, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(tf__23))).Ref() } else { tmp112 = and__1927000168__auto____24 }; if jrt.J2g_Truth(tmp112) { tmp111 = A_arbace_j2g_jrt_A_const_60 } else { var tmp114 any; var and__1927000168__auto____24_2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_12.GetRawRoot__O()).Invoke_O__O(tf__23)
							if jrt.J2g_Truth(and__1927000168__auto____24_2) { var tmp115 any = A_arbace_j2g_jrt_A_const_67; tmp114 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp115, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(tf__23))).Ref() } else { tmp114 = and__1927000168__auto____24_2 }
//line :69:1
							if jrt.J2g_Truth(tmp114) { tmp111 = A_arbace_j2g_jrt_A_const_62 } else { if A_arbace_j2g_jrt_A_const_21 != nil { tmp111 = A_arbace_j2g_jrt_A_const_63 } else { tmp111 = nil } } }
//line :68:1
						jrt.NN(tmp105).Reset_O__O(tmp106.Invoke_O_O_O__O(tmp107, tmp109, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp110, tmp111.Ref(), A_arbace_j2g_jrt_A_const_64, tf__23)))) }
//line :54:1
				break L9 }; case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000093__12_, Lit_33) { var vec__1716000110__13 any = fm__10; var seq__1716000111__14 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(vec__1716000110__13); var first__1716000112__15 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(seq__1716000111__14); var seq__1716000111__16 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(seq__1716000111__14); var ___17_3 any = first__1716000112__15; var more__18_2 any = seq__1716000111__16; var more__19_4 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_50.GetRawRoot__O()).Invoke_O__O(more__18_2); _ = ___17_3










































					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_54.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(more__19_4))) { var seq_1716000113__20 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(more__19_4); var chunk_1716000114__21 any; var count_1716000115__22 int64 = 0; var i_1716000116__23 int64 = 0; L11: for {
						if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000116__23, count_1716000115__22) { var vec__1716000117__24 any = lang.Indexed_Cast(chunk_1716000114__21).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000116__23)); var tg__25_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000117__24, lang.RT_IntCast_J__I_NoInit(0), nil); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_13.GetRawRoot__O()).Invoke_O__O(tg__25_3)) { var tmp116 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_56.GetRawRoot__O()); var tmp117 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp118 any = A_arbace_j2g_jrt_A_const_44; jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(tmp116.Invoke_O_O_O_O__O(tmp117, tmp118, A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(tg__25_3))) }; seq_1716000113__20, chunk_1716000114__21, count_1716000115__22, i_1716000116__23 = seq_1716000113__20, chunk_1716000114__21, count_1716000115__22, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000116__23); continue L11 } else { var temp__1927000414__auto____24_2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(seq_1716000113__20); if jrt.J2g_Truth(temp__1927000414__auto____24_2) { var seq_1716000113__25 any = temp__1927000414__auto____24_2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1716000113__25)) { var c__1927000678__auto____26_2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1716000113__25); seq_1716000113__20, chunk_1716000114__21, count_1716000115__22, i_1716000116__23 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_65.GetRawRoot__O()).Invoke_O__O(seq_1716000113__25), c__1927000678__auto____26_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____26_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L11 } else { var vec__1716000120__26 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1716000113__25); var tg__27 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000120__26, lang.RT_IntCast_J__I_NoInit(0), nil); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_13.GetRawRoot__O()).Invoke_O__O(tg__27)) { var tmp119 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_56.GetRawRoot__O()); var tmp120 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp121 any = A_arbace_j2g_jrt_A_const_44; jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(tmp119.Invoke_O_O_O_O__O(tmp120, tmp121, A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(tg__27))) }; seq_1716000113__20, chunk_1716000114__21, count_1716000115__22, i_1716000116__23 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(seq_1716000113__25), nil, 0, 0; continue L11 } } }
//line :97:1
						break L11 } } else {

							if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(more__19_4))) { var tmp122 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_56.GetRawRoot__O()); var tmp123 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp124 any = A_arbace_j2g_jrt_A_const_44; jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(tmp122.Invoke_O_O_O_O__O(tmp123, tmp124, A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(more__19_4)))) } }
//line :54:1
					break L9 }; case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000093__12_, Lit_34) { var vec__1716000123__13 any = fm__10; var ___14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000123__13, lang.RT_IntCast_J__I_NoInit(0), nil); var nm__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000123__13, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp125 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_56.GetRawRoot__O()); var tmp126 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp127 any = A_arbace_j2g_jrt_A_const_41; _ = ___14
























						jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(tmp125.Invoke_O_O_O_O__O(tmp126, tmp127, A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(nm__15)))
//line :54:1
						break L9 }; case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000093__12_, Lit_35) { var vec__1716000126__13 any = fm__10; var seq__1716000127__14 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(vec__1716000126__13); var first__1716000128__15 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(seq__1716000127__14); var seq__1716000127__16 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(seq__1716000127__14); var ___17_4 any = first__1716000128__15; var more__18_3 any = seq__1716000127__16; var more__19_5 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_50.GetRawRoot__O()).Invoke_O__O(more__18_3); _ = ___17_4



























							if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_54.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(more__19_5))) { var seq_1716000129__20 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(more__19_5); var chunk_1716000130__21 any; var count_1716000131__22 int64 = 0; var i_1716000132__23 int64 = 0; L12: for {
								if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000132__23, count_1716000131__22) { var vec__1716000133__24 any = lang.Indexed_Cast(chunk_1716000130__21).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000132__23)); var tg__25_4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000133__24, lang.RT_IntCast_J__I_NoInit(0), nil); var init__26_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000133__24, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp128 any; var and__1927000168__auto____27_6 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_12.GetRawRoot__O()).Invoke_O__O(tg__25_4)
									if jrt.J2g_Truth(and__1927000168__auto____27_6) { var tmp129 any = A_arbace_j2g_jrt_A_const_71; tmp128 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp129, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(tg__25_4))).Ref() } else { tmp128 = and__1927000168__auto____27_6 }; if jrt.J2g_Truth(tmp128) { var seq_1716000136__27 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_24.GetRawRoot__O()).Invoke_O__O(tg__25_4)); var chunk_1716000137__28 any; var count_1716000138__29 int64 = 0; var i_1716000139__30 int64 = 0; L13: for {
										if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000139__30, count_1716000138__29) { var s__31_3 any = lang.Indexed_Cast(chunk_1716000137__28).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000139__30)); var tmp130 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_56.GetRawRoot__O()); var tmp131 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp132 any = A_arbace_j2g_jrt_A_const_42; jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(tmp130.Invoke_O_O_O_O__O(tmp131, tmp132, A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(s__31_3))); seq_1716000136__27, chunk_1716000137__28, count_1716000138__29, i_1716000139__30 = seq_1716000136__27, chunk_1716000137__28, count_1716000138__29, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000139__30); continue L13 } else { var temp__1927000414__auto____31_2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(seq_1716000136__27); if jrt.J2g_Truth(temp__1927000414__auto____31_2) { var seq_1716000136__32 any = temp__1927000414__auto____31_2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1716000136__32)) { var c__1927000678__auto____33_2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1716000136__32); seq_1716000136__27, chunk_1716000137__28, count_1716000138__29, i_1716000139__30 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_65.GetRawRoot__O()).Invoke_O__O(seq_1716000136__32), c__1927000678__auto____33_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____33_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L13 } else { var s__33_2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1716000136__32); var tmp133 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_56.GetRawRoot__O()); var tmp134 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp135 any = A_arbace_j2g_jrt_A_const_42; jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(tmp133.Invoke_O_O_O_O__O(tmp134, tmp135, A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(s__33_2))); seq_1716000136__27, chunk_1716000137__28, count_1716000138__29, i_1716000139__30 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(seq_1716000136__32), nil, 0, 0; continue L13 } } }
//line :84:1
										break L13 } } else {

											var tmp136 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_56.GetRawRoot__O()); var tmp137 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp138 any = A_arbace_j2g_jrt_A_const_42; jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(tmp136.Invoke_O_O_O_O__O(tmp137, tmp138, A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(tg__25_4)))
//line :84:1
											var temp__1927000414__auto____27_2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_69.GetRawRoot__O()).Invoke_O__O(init__26_2)


											if jrt.J2g_Truth(temp__1927000414__auto____27_2) { var map__1716000140__28 any = temp__1927000414__auto____27_2; var map__1716000140__29 any; if lang.ISeq_InstanceOf(map__1716000140__28) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(map__1716000140__28)) { map__1716000140__29 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_j2g_jrt_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1716000140__28), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(map__1716000140__28)) { map__1716000140__29 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(map__1716000140__28) } else { map__1716000140__29 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000140__29 = map__1716000140__28 }; var n__30_2 any = lang.RT_Get_O_O__O_NoInit(map__1716000140__29, A_arbace_j2g_jrt_A_const_35)
												jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_55.GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(), lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_jrt_A_const_43, n__30_2), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(tg__25_4))) } }
//line :83:1
									seq_1716000129__20, chunk_1716000130__21, count_1716000131__22, i_1716000132__23 = seq_1716000129__20, chunk_1716000130__21, count_1716000131__22, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000132__23); continue L12 } else { var temp__1927000414__auto____24_3 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(seq_1716000129__20); if jrt.J2g_Truth(temp__1927000414__auto____24_3) { var seq_1716000129__25 any = temp__1927000414__auto____24_3; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1716000129__25)) { var c__1927000678__auto____26_3 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1716000129__25); seq_1716000129__20, chunk_1716000130__21, count_1716000131__22, i_1716000132__23 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_65.GetRawRoot__O()).Invoke_O__O(seq_1716000129__25), c__1927000678__auto____26_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____26_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L12 } else { var vec__1716000142__26 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1716000129__25); var tg__27_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000142__26, lang.RT_IntCast_J__I_NoInit(0), nil); var init__28 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000142__26, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp139 any; var and__1927000168__auto____29_3 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_12.GetRawRoot__O()).Invoke_O__O(tg__27_2)
										if jrt.J2g_Truth(and__1927000168__auto____29_3) { var tmp140 any = A_arbace_j2g_jrt_A_const_71; tmp139 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp140, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(tg__27_2))).Ref() } else { tmp139 = and__1927000168__auto____29_3 }; if jrt.J2g_Truth(tmp139) { var seq_1716000145__29 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_24.GetRawRoot__O()).Invoke_O__O(tg__27_2)); var chunk_1716000146__30 any; var count_1716000147__31 int64 = 0; var i_1716000148__32 int64 = 0; L14: for {
											if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000148__32, count_1716000147__31) { var s__33_3 any = lang.Indexed_Cast(chunk_1716000146__30).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000148__32)); var tmp141 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_56.GetRawRoot__O()); var tmp142 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp143 any = A_arbace_j2g_jrt_A_const_42; jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(tmp141.Invoke_O_O_O_O__O(tmp142, tmp143, A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(s__33_3))); seq_1716000145__29, chunk_1716000146__30, count_1716000147__31, i_1716000148__32 = seq_1716000145__29, chunk_1716000146__30, count_1716000147__31, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000148__32); continue L14 } else { var temp__1927000414__auto____33 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(seq_1716000145__29); if jrt.J2g_Truth(temp__1927000414__auto____33) { var seq_1716000145__34 any = temp__1927000414__auto____33; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1716000145__34)) { var c__1927000678__auto____35 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1716000145__34); seq_1716000145__29, chunk_1716000146__30, count_1716000147__31, i_1716000148__32 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_65.GetRawRoot__O()).Invoke_O__O(seq_1716000145__34), c__1927000678__auto____35, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____35))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L14 } else { var s__35 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1716000145__34); var tmp144 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_56.GetRawRoot__O()); var tmp145 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp146 any = A_arbace_j2g_jrt_A_const_42; jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(tmp144.Invoke_O_O_O_O__O(tmp145, tmp146, A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(s__35))); seq_1716000145__29, chunk_1716000146__30, count_1716000147__31, i_1716000148__32 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(seq_1716000145__34), nil, 0, 0; continue L14 } } }
//line :84:1
											break L14 } } else {

												var tmp147 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_56.GetRawRoot__O()); var tmp148 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp149 any = A_arbace_j2g_jrt_A_const_42; jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(tmp147.Invoke_O_O_O_O__O(tmp148, tmp149, A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(tg__27_2)))
//line :84:1
												var temp__1927000414__auto____29_2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_69.GetRawRoot__O()).Invoke_O__O(init__28)


												if jrt.J2g_Truth(temp__1927000414__auto____29_2) { var map__1716000149__30 any = temp__1927000414__auto____29_2; var map__1716000149__31 any; if lang.ISeq_InstanceOf(map__1716000149__30) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(map__1716000149__30)) { map__1716000149__31 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_j2g_jrt_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1716000149__30), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(map__1716000149__30)) { map__1716000149__31 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(map__1716000149__30) } else { map__1716000149__31 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000149__31 = map__1716000149__30 }; var n__32 any = lang.RT_Get_O_O__O_NoInit(map__1716000149__31, A_arbace_j2g_jrt_A_const_35)
													jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_55.GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(), lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_jrt_A_const_43, n__32), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(tg__27_2))) } }
//line :83:1
										seq_1716000129__20, chunk_1716000130__21, count_1716000131__22, i_1716000132__23 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(seq_1716000129__25), nil, 0, 0; continue L12 } } }
//line :82:1
								break L12 } } else { var vec__1716000151__20 any = more__19_5; var tg__21 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000151__20, lang.RT_IntCast_J__I_NoInit(0), nil); var init__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000151__20, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp150 any; var and__1927000168__auto____23 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_12.GetRawRoot__O()).Invoke_O__O(tg__21)







									if jrt.J2g_Truth(and__1927000168__auto____23) { var tmp151 any = A_arbace_j2g_jrt_A_const_68; tmp150 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp151, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(tg__21))).Ref() } else { tmp150 = and__1927000168__auto____23 }; if jrt.J2g_Truth(tmp150) { var seq_1716000154__23 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_24.GetRawRoot__O()).Invoke_O__O(tg__21)); var chunk_1716000155__24 any; var count_1716000156__25 int64 = 0; var i_1716000157__26 int64 = 0; L15: for {
										if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000157__26, count_1716000156__25) { var s__27_2 any = lang.Indexed_Cast(chunk_1716000155__24).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000157__26)); var tmp152 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_56.GetRawRoot__O()); var tmp153 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp154 any = A_arbace_j2g_jrt_A_const_42; jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(tmp152.Invoke_O_O_O_O__O(tmp153, tmp154, A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(s__27_2))); seq_1716000154__23, chunk_1716000155__24, count_1716000156__25, i_1716000157__26 = seq_1716000154__23, chunk_1716000155__24, count_1716000156__25, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000157__26); continue L15 } else { var temp__1927000414__auto____27_3 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(seq_1716000154__23); if jrt.J2g_Truth(temp__1927000414__auto____27_3) { var seq_1716000154__28 any = temp__1927000414__auto____27_3; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1716000154__28)) { var c__1927000678__auto____29 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1716000154__28); seq_1716000154__23, chunk_1716000155__24, count_1716000156__25, i_1716000157__26 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_65.GetRawRoot__O()).Invoke_O__O(seq_1716000154__28), c__1927000678__auto____29, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____29))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L15 } else { var s__29_2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1716000154__28); var tmp155 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_56.GetRawRoot__O()); var tmp156 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp157 any = A_arbace_j2g_jrt_A_const_42; jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(tmp155.Invoke_O_O_O_O__O(tmp156, tmp157, A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(s__29_2))); seq_1716000154__23, chunk_1716000155__24, count_1716000156__25, i_1716000157__26 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(seq_1716000154__28), nil, 0, 0; continue L15 } } }
//line :90:1
										break L15 } } else {

											var tmp158 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_56.GetRawRoot__O()); var tmp159 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp160 any = A_arbace_j2g_jrt_A_const_42; jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(tmp158.Invoke_O_O_O_O__O(tmp159, tmp160, A_arbace_j2g_jrt_A_const_9.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(tg__21)))
//line :90:1
											var temp__1927000414__auto____23 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_69.GetRawRoot__O()).Invoke_O__O(init__22)


											if jrt.J2g_Truth(temp__1927000414__auto____23) { var map__1716000158__24 any = temp__1927000414__auto____23; var map__1716000158__25 any; if lang.ISeq_InstanceOf(map__1716000158__24) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(map__1716000158__24)) { map__1716000158__25 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_j2g_jrt_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1716000158__24), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(map__1716000158__24)) { map__1716000158__25 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(map__1716000158__24) } else { map__1716000158__25 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000158__25 = map__1716000158__24 }; var n__26 any = lang.RT_Get_O_O__O_NoInit(map__1716000158__25, A_arbace_j2g_jrt_A_const_35)
												jrt.NN(lang.Volatile_Cast(acc__3)).Reset_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_55.GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(), lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_jrt_A_const_43, n__26), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(tg__21))) } } }
//line :54:1
							break L9 }; default:}}
//line :51:1
			seq_1716000022__4, chunk_1716000023__5, count_1716000024__6, i_1716000025__7 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(seq_1716000022__9), nil, 0, 0; continue L1 } else { seq_1716000022__4, chunk_1716000023__5, count_1716000024__6, i_1716000025__7 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(seq_1716000022__9), nil, 0, 0; continue L1 } } } }
//line :45:1
	break L1 }; return /*line :49:1*/ lang.IFn_Cast(A_arbace_j2g_jrt_A_const_8.GetRawRoot__O()).Invoke_O__O(acc__3) }





















































func A_arbace_j2g_jrt_interface_elems_A_New() *A_arbace_j2g_jrt_interface_elems_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_interface_elems_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_j2g_jrt_interface_elems_A) Ctor() {}
//line :103:1
func (t *A_arbace_j2g_jrt_interface_elems_A) Invoke_O_O__O(self, tf__0 any) any { var elems__2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_24.GetRawRoot__O()).Invoke_O__O(tf__0); var tmp1 any = A_arbace_j2g_jrt_A_const_40; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_72.GetRawRoot__O()); var tmp3 any; var iter__1927001039__auto____3 any; var tmp4 any = A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A_New(); var tmp5 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A_fn_class; if



	fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A_fn_class = fncls__7d; tmp5 = fncls__7d } else { tmp5 = fncls__7 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); tmp3 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(elems__2); var tmp6 any = /*line :103:1*/tmp2.Invoke_O__O(tmp3); var tmp7 any = A_arbace_j2g_jrt_A_const_73; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_74.GetRawRoot__O()); var tmp9 any; var iter__1927001039__auto____3_2 any; var tmp10 any = A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A_New(); var tmp11 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A_fn_class; if





	fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A_fn_class = fncls__10d; tmp11 = fncls__10d } else { tmp11 = fncls__10 }; iter__1927001039__auto____3_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); tmp9 = lang.IFn_Cast(iter__1927001039__auto____3_2).Invoke_O__O(elems__2); return /*line :103:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp6, tmp7, tmp8.Invoke_O__O(tmp9))) }



func A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A_New() *A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A) Ctor() {}
//line :107:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A) Invoke_O_O__O(self, s__1716000162__1 any) any { var tmp1 any = A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A_New_O_O(s__1716000162__1, self); var tmp2 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A_fn_class = fncls__6d; tmp2 = fncls__6d } else { tmp2 = fncls__6 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :107:1
func A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A_New_O_O(p0, p1 any) *A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A{}; t.Ctor_O_O(p0, p1); return t }
//line :107:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A) Ctor_O_O(c__s__1716000162, c__iter__1716000161 any) { t.F_s__1716000162 = c__s__1716000162; t.F_iter__1716000161 = c__iter__1716000161 }
//line :107:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A) Invoke_O__O(self any) any { { var s__1716000162__1 any; var t_ any = t.F_s__1716000162; t.F_s__1716000162 = nil; s__1716000162__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(s__1716000162__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1716000162__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_47.GetRawRoot__O()).Invoke_O__O(s__1716000162__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_48.GetRawRoot__O()).Invoke_O__O(s__1716000162__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1716000164__6 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_75.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A_New_O_I_O(b__1716000164__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A_fn_class = fncls__5d; tmp2 = fncls__5d } else { tmp2 = fncls__5 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1716000161); return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_78.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_80.GetRawRoot__O()).Invoke_O__O(b__1716000164__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1716000162__3))) } else { return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_78.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_80.GetRawRoot__O()).Invoke_O__O(b__1716000164__6), nil) } } else { var e__4 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1716000162__3); var tmp4 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_12.GetRawRoot__O()).Invoke_O__O(e__4); if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(e__4)); if jrt.J2g_Truth(and__1927000168__auto____6) { tmp4 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_54.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_22.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_76.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_jrt_A_const_23.GetRawRoot__O(), e__4))) } else { tmp4 = and__1927000168__auto____6 } } else { tmp4 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp4) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1716000161); return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_79.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(e__4)), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_24.GetRawRoot__O()).Invoke_O__O(s__1716000162__3))) } else { s__1716000162__1 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_24.GetRawRoot__O()).Invoke_O__O(s__1716000162__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :107:1
func A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :107:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A) Ctor_O_I_O(c__b__1716000164 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1716000164 = c__b__1716000164; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :107:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A) Invoke_O__O(self any) any { { var i__1716000163__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1716000163__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1716000163__1)); var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_12.GetRawRoot__O()).Invoke_O__O(e__2); if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(e__2)); if jrt.J2g_Truth(and__1927000168__auto____4) { tmp2 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_54.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_22.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_76.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_jrt_A_const_23.GetRawRoot__O(), e__2))) } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp2) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_77.GetRawRoot__O()); var tmp4 any = t.F_b__1716000164; tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(e__2))); i__1716000163__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000163__1); continue L1 } else { i__1716000163__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000163__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A_New() *A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A) Ctor() {}
//line :109:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A) Invoke_O_O__O(self, s__1716000172__1 any) any { var tmp1 any = A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A_New_O_O(s__1716000172__1, self); var tmp2 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A_fn_class = fncls__9d; tmp2 = fncls__9d } else { tmp2 = fncls__9 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :109:1
func A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A_New_O_O(p0, p1 any) *A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A{}; t.Ctor_O_O(p0, p1); return t }
//line :109:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A) Ctor_O_O(c__s__1716000172, c__iter__1716000171 any) { t.F_s__1716000172 = c__s__1716000172; t.F_iter__1716000171 = c__iter__1716000171 }
//line :109:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A) Invoke_O__O(self any) any { { var s__1716000172__1 any; var t_ any = t.F_s__1716000172; t.F_s__1716000172 = nil; s__1716000172__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(s__1716000172__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1716000172__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_47.GetRawRoot__O()).Invoke_O__O(s__1716000172__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_48.GetRawRoot__O()).Invoke_O__O(s__1716000172__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1716000174__6 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_75.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A_New_O_I_O(b__1716000174__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A_fn_class = fncls__8d; tmp2 = fncls__8d } else { tmp2 = fncls__8 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1716000171); return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_78.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_80.GetRawRoot__O()).Invoke_O__O(b__1716000174__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1716000172__3))) } else { return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_78.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_80.GetRawRoot__O()).Invoke_O__O(b__1716000174__6), nil) } } else { var e__4 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1716000172__3); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_13.GetRawRoot__O()).Invoke_O__O(e__4)) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1716000171); return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_79.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(e__4), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_24.GetRawRoot__O()).Invoke_O__O(s__1716000172__3))) } else { s__1716000172__1 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_24.GetRawRoot__O()).Invoke_O__O(s__1716000172__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :109:1
func A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :109:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A) Ctor_O_I_O(c__b__1716000174 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1716000174 = c__b__1716000174; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :109:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A) Invoke_O__O(self any) any { { var i__1716000173__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1716000173__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1716000173__1)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_13.GetRawRoot__O()).Invoke_O__O(e__2)) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_77.GetRawRoot__O()); var tmp3 any = t.F_b__1716000174; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(e__2)); i__1716000173__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000173__1); continue L1 } else { i__1716000173__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000173__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_jrt_struct_embed_A_New() *A_arbace_j2g_jrt_struct_embed_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_struct_embed_A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_j2g_jrt_struct_embed_A) Ctor() {}
//line :111:1
func (t *A_arbace_j2g_jrt_struct_embed_A) Invoke_O_O__O(self, tf__0 any) any { var f__2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_22.GetRawRoot__O()).Invoke_O__O(tf__0); var tmp1 any; var and__1927000168__auto____3 any = f__2; if



	jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_13.GetRawRoot__O()).Invoke_O__O(f__2); if jrt.J2g_Truth(and__1927000168__auto____4) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_19.GetRawRoot__O()).Invoke_O__O(f__2), nil)).Ref() } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_14.GetRawRoot__O()).Invoke_O__O(f__2) } else { return nil } }

func A_arbace_j2g_jrt_other_system_QMARK__A_New() *A_arbace_j2g_jrt_other_system_QMARK__A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_other_system_QMARK__A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_j2g_jrt_other_system_QMARK__A) Ctor() {}
//line :117:1
func (t *A_arbace_j2g_jrt_other_system_QMARK__A) Invoke_O_O__O(self, n__0 any) any {



	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_jrt_A_const_82, n__0))).Ref()
}
func A_arbace_j2g_jrt_scan_A_New() *A_arbace_j2g_jrt_scan_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_A{}; t.Ctor(); return t }
//line :123:1
func (t *A_arbace_j2g_jrt_scan_A) Ctor() {}
//line :123:1
func (t *A_arbace_j2g_jrt_scan_A) Invoke_O_O__O(self, dir__0 any) any { var files__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_83.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_jrt_scan_fn__1716000186_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_j2g_jrt_scan_fn__1716000186_A_fn_class; if










	fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_j2g_jrt_scan_fn__1716000186_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_87.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_jrt_scan_fn__1716000188_A_New(); var tmp7 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_j2g_jrt_scan_fn__1716000188_A_fn_class; if /*line :131:1*/ fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_j2g_jrt_scan_fn__1716000188_A_fn_class = fncls__12d; tmp7 = fncls__12d } else { tmp7 = fncls__12 }; files__2 =


	tmp1.Invoke_O_O__O(tmp4, tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), jrt.NN(jrt.File_Cast(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_91.GetRawRoot__O()).Invoke_O__O(dir__0))).ListFiles__File1().Ref())); var scans__3 any; var tmp8 lang.IFn = /*line :123:1*/lang.IFn_Cast(A_arbace_j2g_jrt_A_const_84.GetRawRoot__O()); var tmp9 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_92.GetRawRoot__O()).Invoke__O(); var tmp10 any; var iter__1927001039__auto____3 any; var tmp11 any = A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A_New(); var tmp12 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A_fn_class; if











	fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A_fn_class = fncls__15d; tmp12 = fncls__15d } else { tmp12 = fncls__15 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); tmp10 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(files__2); scans__3 = tmp8.Invoke_O_O__O(tmp9, tmp10); var tmp13 lang.IFn = /*line :123:1*/lang.IFn_Cast(A_arbace_j2g_jrt_A_const_95.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_jrt_A_const_39; var types__4 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_28.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_jrt_A_const_94.GetRawRoot__O(), tmp13.Invoke_O_O__O(tmp14, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_96.GetRawRoot__O()).Invoke_O__O(scans__3))); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_95.GetRawRoot__O()); var tmp16 any = A_arbace_j2g_jrt_A_const_40; var methods__5 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_28.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_jrt_A_const_97.GetRawRoot__O(), A_arbace_j2g_jrt_A_const_84.GetRawRoot__O(), tmp15.Invoke_O_O__O(tmp16, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_96.GetRawRoot__O()).Invoke_O__O(scans__3))); var tmp17 any = A_arbace_j2g_jrt_A_const_85; var tmp18 any = A_arbace_j2g_jrt_A_const_39; var tmp19 any = A_arbace_j2g_jrt_A_const_40; var tmp20 any = A_arbace_j2g_jrt_A_const_41; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_95.GetRawRoot__O()); var tmp22 any = A_arbace_j2g_jrt_A_const_41; var tmp23 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_28.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_jrt_A_const_98.GetRawRoot__O(), tmp21.Invoke_O_O__O(tmp22, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_96.GetRawRoot__O()).Invoke_O__O(scans__3))); var tmp24 any = A_arbace_j2g_jrt_A_const_42; var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_95.GetRawRoot__O()); var tmp26 any = A_arbace_j2g_jrt_A_const_42; var tmp27 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_28.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_jrt_A_const_98.GetRawRoot__O(), tmp25.Invoke_O_O__O(tmp26, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_96.GetRawRoot__O()).Invoke_O__O(scans__3))); var tmp28 any = A_arbace_j2g_jrt_A_const_44; var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_95.GetRawRoot__O()); var tmp30 any = A_arbace_j2g_jrt_A_const_44; var tmp31 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_28.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_jrt_A_const_98.GetRawRoot__O(), tmp29.Invoke_O_O__O(tmp30, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_96.GetRawRoot__O()).Invoke_O__O(scans__3))); var tmp32 any = A_arbace_j2g_jrt_A_const_43; var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_84.GetRawRoot__O()); var tmp34 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp35 any; var iter__1927001039__auto____6 any; var tmp36 any = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A_New(); var tmp37 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A_fn_class; if




















	fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A_fn_class = fncls__20d; tmp37 = fncls__20d } else { tmp37 = fncls__20 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp36, tmp37, nil); tmp35 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(scans__3); var tmp38 any = /*line :123:1*/tmp33.Invoke_O_O__O(tmp34, tmp35); var tmp39 any = A_arbace_j2g_jrt_A_const_86; var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_84.GetRawRoot__O()); var tmp41 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp42 any; var iter__1927001039__auto____6_2 any; var tmp43 any = A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A_New(); var tmp44 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A_fn_class; if
























	fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A_fn_class = fncls__23d; tmp44 = fncls__23d } else { tmp44 = fncls__23 }; iter__1927001039__auto____6_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp43, tmp44, nil); tmp42 = lang.IFn_Cast(iter__1927001039__auto____6_2).Invoke_O__O(types__4); var tmp45 any = /*line :123:1*/tmp40.Invoke_O_O__O(tmp41, tmp42); var tmp46 any = A_arbace_j2g_jrt_A_const_73; var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_84.GetRawRoot__O()); var tmp48 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp49 any; var iter__1927001039__auto____6_3 any; var tmp50 any = A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A_New(); var tmp51 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A_fn_class; if


























	fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A_fn_class = fncls__26d; tmp51 = fncls__26d } else { tmp51 = fncls__26 }; iter__1927001039__auto____6_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp50, tmp51, nil); tmp49 = lang.IFn_Cast(iter__1927001039__auto____6_3).Invoke_O__O(types__4); return /*line :123:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp17, scans__3, tmp18, types__4, tmp19, methods__5, tmp20, tmp23, tmp24, tmp27, tmp28, tmp31, tmp32, tmp38, tmp39, tmp45, tmp46, tmp47.Invoke_O_O__O(tmp48, tmp49))) }







func A_arbace_j2g_jrt_scan_fn__1716000188_A_New() *A_arbace_j2g_jrt_scan_fn__1716000188_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_fn__1716000188_A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_j2g_jrt_scan_fn__1716000188_A) Ctor() {}
//line :131:1
func (t *A_arbace_j2g_jrt_scan_fn__1716000188_A) Invoke_O_O__O(self, p1__1716000184_SHARP___1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_88.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(p1__1716000184_SHARP___1)).GetName__String().Ref(), Lit_17); if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_88.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(p1__1716000184_SHARP___1)).GetName__String().Ref(), Lit_18)); if jrt.J2g_Truth(and__1927000168__auto____3) {

	return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_90.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(p1__1716000184_SHARP___1)).GetName__String().Ref())) } else {
//line :131:1
		return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }


func A_arbace_j2g_jrt_scan_fn__1716000186_A_New() *A_arbace_j2g_jrt_scan_fn__1716000186_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_fn__1716000186_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_j2g_jrt_scan_fn__1716000186_A) Ctor() {}
//line :134:1
func (t *A_arbace_j2g_jrt_scan_fn__1716000186_A) Invoke_O_O__O(self, p1__1716000185_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__1716000185_SHARP___1)).GetName__String().Ref() }
func A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A_New() *A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A) Ctor() {}
//line :135:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A) Invoke_O_O__O(self, s__1716000191__1 any) any { var tmp1 any = A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A_New_O_O(s__1716000191__1, self); var tmp2 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A_fn_class = fncls__14d; tmp2 = fncls__14d } else { tmp2 = fncls__14 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :135:1
func A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A_New_O_O(p0, p1 any) *A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A{}; t.Ctor_O_O(p0, p1); return t }
//line :135:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A) Ctor_O_O(c__s__1716000191, c__iter__1716000190 any) { t.F_s__1716000191 = c__s__1716000191; t.F_iter__1716000190 = c__iter__1716000190 }
//line :135:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A) Invoke_O__O(self any) any { { var s__1716000191__1 any; var t_ any = t.F_s__1716000191; t.F_s__1716000191 = nil; s__1716000191__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(s__1716000191__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1716000191__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_47.GetRawRoot__O()).Invoke_O__O(s__1716000191__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_48.GetRawRoot__O()).Invoke_O__O(s__1716000191__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1716000193__6 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_75.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A_New_O_I_O(b__1716000193__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A_fn_class = fncls__13d; tmp2 = fncls__13d } else { tmp2 = fncls__13 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1716000190); return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_78.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_80.GetRawRoot__O()).Invoke_O__O(b__1716000193__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1716000191__3))) } else { return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_78.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_80.GetRawRoot__O()).Invoke_O__O(b__1716000193__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1716000191__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1716000190); return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_79.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_93.GetRawRoot__O()).Invoke_O__O(f__4)), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_24.GetRawRoot__O()).Invoke_O__O(s__1716000191__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :135:1
func A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :135:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A) Ctor_O_I_O(c__b__1716000193 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1716000193 = c__b__1716000193; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :135:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A) Invoke_O__O(self any) any { { var i__1716000192__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1716000192__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1716000192__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_77.GetRawRoot__O()); var tmp3 any = t.F_b__1716000193; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_93.GetRawRoot__O()).Invoke_O__O(f__2))); i__1716000192__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000192__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A_New() *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A) Ctor() {}
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A) Invoke_O_O__O(self, s__1716000201__1 any) any { var tmp1 any = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A_New_O_O(s__1716000201__1, self); var tmp2 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A_fn_class = fncls__19d; tmp2 = fncls__19d } else { tmp2 = fncls__19 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :144:1
func A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A_New_O_O(p0, p1 any) *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A{}; t.Ctor_O_O(p0, p1); return t }
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A) Ctor_O_O(c__s__1716000201, c__iter__1716000200 any) { t.F_s__1716000201 = c__s__1716000201; t.F_iter__1716000200 = c__iter__1716000200 }
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A) Invoke_O__O(self any) any { { var s__1716000201__1 any; var t_ any = t.F_s__1716000201; t.F_s__1716000201 = nil; s__1716000201__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(s__1716000201__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__1716000208__4 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var fname__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000208__4, lang.RT_IntCast_J__I_NoInit(0), nil); var s__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000208__4, lang.RT_IntCast_J__I_NoInit(1), nil); var iterys__1927001035__auto____7 any; var tmp1 any = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A_New_O(fname__5); var tmp2 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A_fn_class = fncls__18d; tmp2 = fncls__18d } else { tmp2 = fncls__18 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____8 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____7).Invoke_O__O(A_arbace_j2g_jrt_A_const_43.Invoke_O__O(s__6))); if jrt.J2g_Truth(fs__1927001036__auto____8) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1716000200); return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_106.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____8, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_24.GetRawRoot__O()).Invoke_O__O(s__1716000201__1))) } else { s__1716000201__1 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_24.GetRawRoot__O()).Invoke_O__O(s__1716000201__1); continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :144:1
func A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A_New_O(p0 any) *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A{}; t.Ctor_O(p0); return t }
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A) Ctor_O(c__fname any) { t.F_fname = c__fname }
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A) Invoke_O_O__O(self, s__1716000203__1 any) any { var tmp1 any = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A_New_O_O_O(s__1716000203__1, self, t.F_fname); var tmp2 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A_fn_class = fncls__17d; tmp2 = fncls__17d } else { tmp2 = fncls__17 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :144:1
func A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A) Ctor_O_O_O(c__s__1716000203, c__iter__1716000202, c__fname any) { t.F_s__1716000203 = c__s__1716000203; t.F_iter__1716000202 = c__iter__1716000202; t.F_fname = c__fname }
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A) Invoke_O__O(self any) any { { var s__1716000203__1 any; var t_ any = t.F_s__1716000203; t.F_s__1716000203 = nil; s__1716000203__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(s__1716000203__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1716000203__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_47.GetRawRoot__O()).Invoke_O__O(s__1716000203__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_48.GetRawRoot__O()).Invoke_O__O(s__1716000203__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1716000205__6 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_75.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A_New_O_O_I_O(t.F_fname, b__1716000205__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A_fn_class = fncls__16d; tmp2 = fncls__16d } else { tmp2 = fncls__16 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1716000202); return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_78.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_80.GetRawRoot__O()).Invoke_O__O(b__1716000205__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1716000203__3))) } else { return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_78.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_80.GetRawRoot__O()).Invoke_O__O(b__1716000205__6), nil) } } else { var vec__1716000218__4 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1716000203__3); var jn__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000218__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vn__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000218__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp4 any = A_arbace_j2g_jrt_A_const_99; var tmp5 any = A_arbace_j2g_jrt_A_const_100; var tmp6 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_101.GetRawRoot__O()).Invoke_O_O_O__O(vn__6, A_arbace_j2g_jrt_A_const_105, Lit_25); var tmp7 any = A_arbace_j2g_jrt_A_const_102; var tmp8 any = t.F_fname; var tmp9 any = A_arbace_j2g_jrt_A_const_103; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__1716000202); return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_79.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(jn__5, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, vn__6, tmp5, tmp6, tmp7, tmp8, tmp9, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_104.GetRawRoot__O()).Invoke_O_O__O(t.F_fname, Lit_26)))), tmp10.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_24.GetRawRoot__O()).Invoke_O__O(s__1716000203__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :144:1
func A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A) Ctor_O_O_I_O(c__fname, c__b__1716000205 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_fname = c__fname; t.F_b__1716000205 = c__b__1716000205; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A) Invoke_O__O(self any) any { { var i__1716000204__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1716000204__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1716000214__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1716000204__1)); var jn__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000214__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vn__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000214__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_77.GetRawRoot__O()); var tmp3 any = t.F_b__1716000205; var tmp4 any = A_arbace_j2g_jrt_A_const_99; var tmp5 any = A_arbace_j2g_jrt_A_const_100; var tmp6 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_101.GetRawRoot__O()).Invoke_O_O_O__O(vn__4, A_arbace_j2g_jrt_A_const_105, Lit_25); var tmp7 any = A_arbace_j2g_jrt_A_const_102; var tmp8 any = t.F_fname; var tmp9 any = A_arbace_j2g_jrt_A_const_103; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(jn__3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, vn__4, tmp5, tmp6, tmp7, tmp8, tmp9, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_104.GetRawRoot__O()).Invoke_O_O__O(t.F_fname, Lit_26))))); i__1716000204__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000204__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A_New() *A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A) Ctor() {}
//line :148:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A) Invoke_O_O__O(self, s__1716000226__1 any) any { var tmp1 any = A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A_New_O_O(s__1716000226__1, self); var tmp2 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A_fn_class = fncls__22d; tmp2 = fncls__22d } else { tmp2 = fncls__22 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :148:1
func A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A_New_O_O(p0, p1 any) *A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A{}; t.Ctor_O_O(p0, p1); return t }
//line :148:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A) Ctor_O_O(c__s__1716000226, c__iter__1716000225 any) { t.F_s__1716000226 = c__s__1716000226; t.F_iter__1716000225 = c__iter__1716000225 }
//line :148:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A) Invoke_O__O(self any) any { { var s__1716000226__1 any; var t_ any = t.F_s__1716000226; t.F_s__1716000226 = nil; s__1716000226__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(s__1716000226__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1716000226__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_47.GetRawRoot__O()).Invoke_O__O(s__1716000226__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_48.GetRawRoot__O()).Invoke_O__O(s__1716000226__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1716000228__6 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_75.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A_New_O_I_O(b__1716000228__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A_fn_class = fncls__21d; tmp2 = fncls__21d } else { tmp2 = fncls__21 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1716000225); return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_78.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_80.GetRawRoot__O()).Invoke_O__O(b__1716000228__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1716000226__3))) } else { return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_78.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_80.GetRawRoot__O()).Invoke_O__O(b__1716000228__6), nil) } } else { var vec__1716000238__4 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1716000226__3); var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000238__4, lang.RT_IntCast_J__I_NoInit(0), nil); var map__1716000241__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000238__4, lang.RT_IntCast_J__I_NoInit(1), nil); var map__1716000241__7 any; if lang.ISeq_InstanceOf(map__1716000241__6) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(map__1716000241__6)) { map__1716000241__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_j2g_jrt_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1716000241__6), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(map__1716000241__6)) { map__1716000241__7 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(map__1716000241__6) } else { map__1716000241__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000241__7 = map__1716000241__6 }; var kind__8 any = lang.RT_Get_O_O__O_NoInit(map__1716000241__7, A_arbace_j2g_jrt_A_const_58); var form__9 any = lang.RT_Get_O_O__O_NoInit(map__1716000241__7, A_arbace_j2g_jrt_A_const_64); if lang.Util_Equiv_O_O__Z_NoInit(kind__8, A_arbace_j2g_jrt_A_const_62) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1716000225); return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_79.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(n__5, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_107.GetRawRoot__O()).Invoke_O__O(form__9)), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_24.GetRawRoot__O()).Invoke_O__O(s__1716000226__3))) } else { s__1716000226__1 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_24.GetRawRoot__O()).Invoke_O__O(s__1716000226__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :148:1
func A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :148:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A) Ctor_O_I_O(c__b__1716000228 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1716000228 = c__b__1716000228; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :148:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A) Invoke_O__O(self any) any { { var i__1716000227__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1716000227__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1716000232__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1716000227__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000232__2, lang.RT_IntCast_J__I_NoInit(0), nil); var map__1716000235__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000232__2, lang.RT_IntCast_J__I_NoInit(1), nil); var map__1716000235__5 any; if lang.ISeq_InstanceOf(map__1716000235__4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(map__1716000235__4)) { map__1716000235__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_j2g_jrt_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1716000235__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(map__1716000235__4)) { map__1716000235__5 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(map__1716000235__4) } else { map__1716000235__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000235__5 = map__1716000235__4 }; var kind__6 any = lang.RT_Get_O_O__O_NoInit(map__1716000235__5, A_arbace_j2g_jrt_A_const_58); var form__7 any = lang.RT_Get_O_O__O_NoInit(map__1716000235__5, A_arbace_j2g_jrt_A_const_64); if lang.Util_Equiv_O_O__Z_NoInit(kind__6, A_arbace_j2g_jrt_A_const_62) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_77.GetRawRoot__O()); var tmp3 any = t.F_b__1716000228; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(n__3, lang.IFn_Cast(A_arbace_j2g_jrt_A_const_107.GetRawRoot__O()).Invoke_O__O(form__7))); i__1716000227__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000227__1); continue L1 } else { i__1716000227__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000227__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A_New() *A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A) Ctor() {}
//line :150:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A) Invoke_O_O__O(self, s__1716000246__1 any) any { var tmp1 any = A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A_New_O_O(s__1716000246__1, self); var tmp2 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A_fn_class = fncls__25d; tmp2 = fncls__25d } else { tmp2 = fncls__25 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :150:1
func A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A_New_O_O(p0, p1 any) *A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A{}; t.Ctor_O_O(p0, p1); return t }
//line :150:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A) Ctor_O_O(c__s__1716000246, c__iter__1716000245 any) { t.F_s__1716000246 = c__s__1716000246; t.F_iter__1716000245 = c__iter__1716000245 }
//line :150:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A) Invoke_O__O(self any) any { { var s__1716000246__1 any; var t_ any = t.F_s__1716000246; t.F_s__1716000246 = nil; s__1716000246__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(s__1716000246__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1716000246__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_47.GetRawRoot__O()).Invoke_O__O(s__1716000246__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_48.GetRawRoot__O()).Invoke_O__O(s__1716000246__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1716000248__6 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_75.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A_New_O_I_O(b__1716000248__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A_fn_class = fncls__24d; tmp2 = fncls__24d } else { tmp2 = fncls__24 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1716000245); return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_78.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_80.GetRawRoot__O()).Invoke_O__O(b__1716000248__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_65.GetRawRoot__O()).Invoke_O__O(s__1716000246__3))) } else { return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_78.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_80.GetRawRoot__O()).Invoke_O__O(b__1716000248__6), nil) } } else { var vec__1716000258__4 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1716000246__3); var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000258__4, lang.RT_IntCast_J__I_NoInit(0), nil); var map__1716000261__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000258__4, lang.RT_IntCast_J__I_NoInit(1), nil); var map__1716000261__7 any; if lang.ISeq_InstanceOf(map__1716000261__6) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(map__1716000261__6)) { map__1716000261__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_j2g_jrt_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1716000261__6), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(map__1716000261__6)) { map__1716000261__7 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(map__1716000261__6) } else { map__1716000261__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000261__7 = map__1716000261__6 }; var kind__8 any = lang.RT_Get_O_O__O_NoInit(map__1716000261__7, A_arbace_j2g_jrt_A_const_58); var form__9 any = lang.RT_Get_O_O__O_NoInit(map__1716000261__7, A_arbace_j2g_jrt_A_const_64); if lang.Util_Equiv_O_O__Z_NoInit(kind__8, A_arbace_j2g_jrt_A_const_60) { var e__10 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_108.GetRawRoot__O()).Invoke_O__O(form__9); if jrt.J2g_Truth(e__10) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1716000245); return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_79.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(n__5, e__10), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_24.GetRawRoot__O()).Invoke_O__O(s__1716000246__3))) } else { s__1716000246__1 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_24.GetRawRoot__O()).Invoke_O__O(s__1716000246__3); continue L1 } } else { s__1716000246__1 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_24.GetRawRoot__O()).Invoke_O__O(s__1716000246__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :150:1
func A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :150:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A) Ctor_O_I_O(c__b__1716000248 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1716000248 = c__b__1716000248; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :150:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A) Invoke_O__O(self any) any { { var i__1716000247__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1716000247__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1716000252__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1716000247__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000252__2, lang.RT_IntCast_J__I_NoInit(0), nil); var map__1716000255__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000252__2, lang.RT_IntCast_J__I_NoInit(1), nil); var map__1716000255__5 any; if lang.ISeq_InstanceOf(map__1716000255__4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_49.GetRawRoot__O()).Invoke_O__O(map__1716000255__4)) { map__1716000255__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_j2g_jrt_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1716000255__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_jrt_A_const_45.GetRawRoot__O()).Invoke_O__O(map__1716000255__4)) { map__1716000255__5 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_15.GetRawRoot__O()).Invoke_O__O(map__1716000255__4) } else { map__1716000255__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000255__5 = map__1716000255__4 }; var kind__6 any = lang.RT_Get_O_O__O_NoInit(map__1716000255__5, A_arbace_j2g_jrt_A_const_58); var form__7 any = lang.RT_Get_O_O__O_NoInit(map__1716000255__5, A_arbace_j2g_jrt_A_const_64); if lang.Util_Equiv_O_O__Z_NoInit(kind__6, A_arbace_j2g_jrt_A_const_60) { var e__8 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_108.GetRawRoot__O()).Invoke_O__O(form__7); if jrt.J2g_Truth(e__8) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_77.GetRawRoot__O()); var tmp3 any = t.F_b__1716000248; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(n__3, e__8)); i__1716000247__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000247__1); continue L1 } else { i__1716000247__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000247__1); continue L1 } } else { i__1716000247__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000247__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_jrt_struct_methods_A_New() *A_arbace_j2g_jrt_struct_methods_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_struct_methods_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_j2g_jrt_struct_methods_A) Ctor() {}
//line :154:1
func (t *A_arbace_j2g_jrt_struct_methods_A) Invoke_O_O_O__O(self, scan__0, go_type__1 any) any { { var t__3 any = go_type__1; var acc__4 any = lang.PersistentHashSet_EMPTY.Ref(); L1: for {



	if lang.Util_Identical_O_O__Z_NoInit(t__3, nil) { return acc__4 } else {

		t__3, acc__4 = lang.RT_Get_O_O__O_NoInit(A_arbace_j2g_jrt_A_const_73.Invoke_O__O(scan__0), t__3), lang.IFn_Cast(A_arbace_j2g_jrt_A_const_84.GetRawRoot__O()).Invoke_O_O__O(acc__4, lang.RT_Get_O_O__O_NoInit(A_arbace_j2g_jrt_A_const_40.Invoke_O__O(scan__0), t__3)); continue L1 } } }; /*line :154:1*/panic("j2g: unreachable") }







func A_arbace_j2g_jrt_iface_methods_A_New() *A_arbace_j2g_jrt_iface_methods_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_iface_methods_A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_j2g_jrt_iface_methods_A) Ctor() {}
//line :162:1
func (t *A_arbace_j2g_jrt_iface_methods_A) Invoke_O_O_O__O(self, scan__0, go_type__1 any) any { var i__3 any = lang.RT_Get_O_O__O_NoInit(A_arbace_j2g_jrt_A_const_86.Invoke_O__O(scan__0), go_type__1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_84.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_72.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_jrt_A_const_40.Invoke_O__O(i__3)); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_109.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_jrt_iface_methods_fn__1716000268_A_New_O(scan__0); var tmp5 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_j2g_jrt_iface_methods_fn__1716000268_A_fn_class; if



	fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_j2g_jrt_iface_methods_fn__1716000268_A_fn_class = fncls__27d; tmp5 = fncls__27d } else { tmp5 = fncls__27 }; return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), A_arbace_j2g_jrt_A_const_73.Invoke_O__O(i__3))) }
//line :166:1
func A_arbace_j2g_jrt_iface_methods_fn__1716000268_A_New_O(p0 any) *A_arbace_j2g_jrt_iface_methods_fn__1716000268_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_iface_methods_fn__1716000268_A{}; t.Ctor_O(p0); return t }
//line :166:1
func (t *A_arbace_j2g_jrt_iface_methods_fn__1716000268_A) Ctor_O(c__scan any) { t.F_scan = c__scan }
//line :166:1
func (t *A_arbace_j2g_jrt_iface_methods_fn__1716000268_A) Invoke_O_O__O(self, p1__1716000267_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_jrt_A_const_110.GetRawRoot__O()).Invoke_O_O__O(t.F_scan, p1__1716000267_SHARP___1) }
















































































































type A_arbace_j2g_jrt_A struct{ jrt.Object }

var A_arbace_j2g_jrt_A_const_pool *jrt.RefArray

var A_arbace_j2g_jrt_A_const_0 *lang.Var

var A_arbace_j2g_jrt_A_const_1 *lang.Var

var A_arbace_j2g_jrt_A_const_2 any

var A_arbace_j2g_jrt_A_const_3 any

var A_arbace_j2g_jrt_A_const_4 any

var A_arbace_j2g_jrt_A_const_5 any

var A_arbace_j2g_jrt_A_const_6 any

var A_arbace_j2g_jrt_A_const_7 *lang.Var

var A_arbace_j2g_jrt_A_const_8 *lang.Var

var A_arbace_j2g_jrt_A_const_9 *lang.Var

var A_arbace_j2g_jrt_A_const_10 any

var A_arbace_j2g_jrt_A_const_11 *lang.Var

var A_arbace_j2g_jrt_A_const_12 *lang.Var

var A_arbace_j2g_jrt_A_const_13 *lang.Var

var A_arbace_j2g_jrt_A_const_14 *lang.Var

var A_arbace_j2g_jrt_A_const_15 *lang.Var

var A_arbace_j2g_jrt_A_const_16 any

var A_arbace_j2g_jrt_A_const_17 *lang.Var

var A_arbace_j2g_jrt_A_const_18 *lang.Keyword

var A_arbace_j2g_jrt_A_const_19 *lang.Var

var A_arbace_j2g_jrt_A_const_20 any

var A_arbace_j2g_jrt_A_const_21 *lang.Keyword

var A_arbace_j2g_jrt_A_const_22 *lang.Var

var A_arbace_j2g_jrt_A_const_23 *lang.Var

var A_arbace_j2g_jrt_A_const_24 *lang.Var

var A_arbace_j2g_jrt_A_const_25 *lang.Var

var A_arbace_j2g_jrt_A_const_26 *lang.Var

var A_arbace_j2g_jrt_A_const_27 any

var A_arbace_j2g_jrt_A_const_28 *lang.Var

var A_arbace_j2g_jrt_A_const_29 *lang.Var

var A_arbace_j2g_jrt_A_const_30 *lang.Var

var A_arbace_j2g_jrt_A_const_31 *lang.Var

var A_arbace_j2g_jrt_A_const_32 *lang.Var

var A_arbace_j2g_jrt_A_const_33 any

var A_arbace_j2g_jrt_A_const_34 *lang.Keyword

var A_arbace_j2g_jrt_A_const_35 *lang.Keyword

var A_arbace_j2g_jrt_A_const_36 *lang.Keyword

var A_arbace_j2g_jrt_A_const_37 *lang.Var

var A_arbace_j2g_jrt_A_const_38 *lang.Var

var A_arbace_j2g_jrt_A_const_39 *lang.Keyword

var A_arbace_j2g_jrt_A_const_40 *lang.Keyword

var A_arbace_j2g_jrt_A_const_41 *lang.Keyword

var A_arbace_j2g_jrt_A_const_42 *lang.Keyword

var A_arbace_j2g_jrt_A_const_43 *lang.Keyword

var A_arbace_j2g_jrt_A_const_44 *lang.Keyword

var A_arbace_j2g_jrt_A_const_45 *lang.Var

var A_arbace_j2g_jrt_A_const_46 *lang.Var

var A_arbace_j2g_jrt_A_const_47 *lang.Var

var A_arbace_j2g_jrt_A_const_48 *lang.Var

var A_arbace_j2g_jrt_A_const_49 *lang.Var

var A_arbace_j2g_jrt_A_const_50 *lang.Var

var A_arbace_j2g_jrt_A_const_51 *lang.Keyword

var A_arbace_j2g_jrt_A_const_52 *lang.Var

var A_arbace_j2g_jrt_A_const_53 *lang.Var

var A_arbace_j2g_jrt_A_const_54 *lang.Var

var A_arbace_j2g_jrt_A_const_55 *lang.Var

var A_arbace_j2g_jrt_A_const_56 *lang.Var

var A_arbace_j2g_jrt_A_const_57 *lang.Var

var A_arbace_j2g_jrt_A_const_58 *lang.Keyword

var A_arbace_j2g_jrt_A_const_59 any

var A_arbace_j2g_jrt_A_const_60 *lang.Keyword

var A_arbace_j2g_jrt_A_const_61 any

var A_arbace_j2g_jrt_A_const_62 *lang.Keyword

var A_arbace_j2g_jrt_A_const_63 *lang.Keyword

var A_arbace_j2g_jrt_A_const_64 *lang.Keyword

var A_arbace_j2g_jrt_A_const_65 *lang.Var

var A_arbace_j2g_jrt_A_const_66 any

var A_arbace_j2g_jrt_A_const_67 any

var A_arbace_j2g_jrt_A_const_68 any

var A_arbace_j2g_jrt_A_const_69 *lang.Var

var A_arbace_j2g_jrt_A_const_70 *lang.Var

var A_arbace_j2g_jrt_A_const_71 any

var A_arbace_j2g_jrt_A_const_72 *lang.Var

var A_arbace_j2g_jrt_A_const_73 *lang.Keyword

var A_arbace_j2g_jrt_A_const_74 *lang.Var

var A_arbace_j2g_jrt_A_const_75 *lang.Var

var A_arbace_j2g_jrt_A_const_76 *lang.Var

var A_arbace_j2g_jrt_A_const_77 *lang.Var

var A_arbace_j2g_jrt_A_const_78 *lang.Var

var A_arbace_j2g_jrt_A_const_79 *lang.Var

var A_arbace_j2g_jrt_A_const_80 *lang.Var

var A_arbace_j2g_jrt_A_const_81 *lang.Var

var A_arbace_j2g_jrt_A_const_82 any

var A_arbace_j2g_jrt_A_const_83 *lang.Var

var A_arbace_j2g_jrt_A_const_84 *lang.Var

var A_arbace_j2g_jrt_A_const_85 *lang.Keyword

var A_arbace_j2g_jrt_A_const_86 *lang.Keyword

var A_arbace_j2g_jrt_A_const_87 *lang.Var

var A_arbace_j2g_jrt_A_const_88 *lang.Var

var A_arbace_j2g_jrt_A_const_89 *lang.Var

var A_arbace_j2g_jrt_A_const_90 *lang.Var

var A_arbace_j2g_jrt_A_const_91 *lang.Var

var A_arbace_j2g_jrt_A_const_92 *lang.Var

var A_arbace_j2g_jrt_A_const_93 *lang.Var

var A_arbace_j2g_jrt_A_const_94 *lang.Var

var A_arbace_j2g_jrt_A_const_95 *lang.Var

var A_arbace_j2g_jrt_A_const_96 *lang.Var

var A_arbace_j2g_jrt_A_const_97 *lang.Var

var A_arbace_j2g_jrt_A_const_98 *lang.Var

var A_arbace_j2g_jrt_A_const_99 *lang.Keyword

var A_arbace_j2g_jrt_A_const_100 *lang.Keyword

var A_arbace_j2g_jrt_A_const_101 *lang.Var

var A_arbace_j2g_jrt_A_const_102 *lang.Keyword

var A_arbace_j2g_jrt_A_const_103 *lang.Keyword

var A_arbace_j2g_jrt_A_const_104 *lang.Var

var A_arbace_j2g_jrt_A_const_105 any

var A_arbace_j2g_jrt_A_const_106 *lang.Var

var A_arbace_j2g_jrt_A_const_107 *lang.Var

var A_arbace_j2g_jrt_A_const_108 *lang.Var

var A_arbace_j2g_jrt_A_const_109 *lang.Var

var A_arbace_j2g_jrt_A_const_110 *lang.Var

var A_arbace_j2g_jrt_A_init jrt.ClassInit

func A_arbace_j2g_jrt_A_Init() { if !A_arbace_j2g_jrt_A_init.Done() { A_arbace_j2g_jrt_A_init.Run(A_arbace_j2g_jrt_A_clinit) } }

func A_arbace_j2g_jrt_A_clinit() { A_arbace_j2g_jrt_A_clinit_p0(); A_arbace_j2g_jrt_A_clinit_p1(); A_arbace_j2g_jrt_A_clinit_p2(); A_arbace_j2g_jrt_A_clinit_p3(); A_arbace_j2g_jrt_A_clinit_p4(); A_arbace_j2g_jrt_A_clinit_p5(); A_arbace_j2g_jrt_A_clinit_p6(); A_arbace_j2g_jrt_A_clinit_p7(); A_arbace_j2g_jrt_A_clinit_p8(); A_arbace_j2g_jrt_A_clinit_p9() }

func A_arbace_j2g_jrt_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_jrt_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 150); A_arbace_j2g_jrt_A_const_0 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[39]); A_arbace_j2g_jrt_A_const_1 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[40]); A_arbace_j2g_jrt_A_const_2 = A_arbace_j2g_jrt_A_const_pool.A[41]; A_arbace_j2g_jrt_A_const_3 = A_arbace_j2g_jrt_A_const_pool.A[42]; A_arbace_j2g_jrt_A_const_4 = A_arbace_j2g_jrt_A_const_pool.A[43]; A_arbace_j2g_jrt_A_const_5 = A_arbace_j2g_jrt_A_const_pool.A[44]; A_arbace_j2g_jrt_A_const_6 = A_arbace_j2g_jrt_A_const_pool.A[45]; A_arbace_j2g_jrt_A_const_7 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[46]); A_arbace_j2g_jrt_A_const_8 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[47]); A_arbace_j2g_jrt_A_const_9 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[48]); A_arbace_j2g_jrt_A_const_10 = A_arbace_j2g_jrt_A_const_pool.A[49]; A_arbace_j2g_jrt_A_const_11 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[50]) }

func A_arbace_j2g_jrt_A_clinit_p1() { A_arbace_j2g_jrt_A_const_12 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[51]); A_arbace_j2g_jrt_A_const_13 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[52]); A_arbace_j2g_jrt_A_const_14 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[53]); A_arbace_j2g_jrt_A_const_15 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[54]); A_arbace_j2g_jrt_A_const_16 = A_arbace_j2g_jrt_A_const_pool.A[55]; A_arbace_j2g_jrt_A_const_17 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[56]); A_arbace_j2g_jrt_A_const_18 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[57]); A_arbace_j2g_jrt_A_const_19 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[58]); A_arbace_j2g_jrt_A_const_20 = A_arbace_j2g_jrt_A_const_pool.A[59]; A_arbace_j2g_jrt_A_const_21 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[60]); A_arbace_j2g_jrt_A_const_22 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[61]); A_arbace_j2g_jrt_A_const_23 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[62]) }

func A_arbace_j2g_jrt_A_clinit_p2() { A_arbace_j2g_jrt_A_const_24 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[63]); A_arbace_j2g_jrt_A_const_25 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[64]); A_arbace_j2g_jrt_A_const_26 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[65]); A_arbace_j2g_jrt_A_const_27 = A_arbace_j2g_jrt_A_const_pool.A[66]; A_arbace_j2g_jrt_A_const_28 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[67]); A_arbace_j2g_jrt_A_const_29 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[68]); A_arbace_j2g_jrt_A_const_30 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[69]); A_arbace_j2g_jrt_A_const_31 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[70]); A_arbace_j2g_jrt_A_const_32 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[71]); A_arbace_j2g_jrt_A_const_33 = A_arbace_j2g_jrt_A_const_pool.A[72]; A_arbace_j2g_jrt_A_const_34 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[73]); A_arbace_j2g_jrt_A_const_35 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[74]) }

func A_arbace_j2g_jrt_A_clinit_p3() { A_arbace_j2g_jrt_A_const_36 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[75]); A_arbace_j2g_jrt_A_const_37 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[76]); A_arbace_j2g_jrt_A_const_38 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[77]); A_arbace_j2g_jrt_A_const_39 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[78]); A_arbace_j2g_jrt_A_const_40 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[79]); A_arbace_j2g_jrt_A_const_41 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[80]); A_arbace_j2g_jrt_A_const_42 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[81]); A_arbace_j2g_jrt_A_const_43 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[82]); A_arbace_j2g_jrt_A_const_44 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[83]); A_arbace_j2g_jrt_A_const_45 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[84]); A_arbace_j2g_jrt_A_const_46 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[85]); A_arbace_j2g_jrt_A_const_47 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[86]) }

func A_arbace_j2g_jrt_A_clinit_p4() { A_arbace_j2g_jrt_A_const_48 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[87]); A_arbace_j2g_jrt_A_const_49 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[88]); A_arbace_j2g_jrt_A_const_50 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[89]); A_arbace_j2g_jrt_A_const_51 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[90]); A_arbace_j2g_jrt_A_const_52 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[91]); A_arbace_j2g_jrt_A_const_53 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[92]); A_arbace_j2g_jrt_A_const_54 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[93]); A_arbace_j2g_jrt_A_const_55 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[94]); A_arbace_j2g_jrt_A_const_56 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[95]); A_arbace_j2g_jrt_A_const_57 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[96]); A_arbace_j2g_jrt_A_const_58 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[97]); A_arbace_j2g_jrt_A_const_59 = A_arbace_j2g_jrt_A_const_pool.A[98] }

func A_arbace_j2g_jrt_A_clinit_p5() { A_arbace_j2g_jrt_A_const_60 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[99]); A_arbace_j2g_jrt_A_const_61 = A_arbace_j2g_jrt_A_const_pool.A[100]; A_arbace_j2g_jrt_A_const_62 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[101]); A_arbace_j2g_jrt_A_const_63 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[102]); A_arbace_j2g_jrt_A_const_64 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[103]); A_arbace_j2g_jrt_A_const_65 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[104]); A_arbace_j2g_jrt_A_const_66 = A_arbace_j2g_jrt_A_const_pool.A[105]; A_arbace_j2g_jrt_A_const_67 = A_arbace_j2g_jrt_A_const_pool.A[106]; A_arbace_j2g_jrt_A_const_68 = A_arbace_j2g_jrt_A_const_pool.A[107]; A_arbace_j2g_jrt_A_const_69 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[108]); A_arbace_j2g_jrt_A_const_70 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[109]); A_arbace_j2g_jrt_A_const_71 = A_arbace_j2g_jrt_A_const_pool.A[110]; A_arbace_j2g_jrt_A_const_72 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[111]) }

func A_arbace_j2g_jrt_A_clinit_p6() { A_arbace_j2g_jrt_A_const_73 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[112]); A_arbace_j2g_jrt_A_const_74 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[113]); A_arbace_j2g_jrt_A_const_75 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[114]); A_arbace_j2g_jrt_A_const_76 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[115]); A_arbace_j2g_jrt_A_const_77 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[116]); A_arbace_j2g_jrt_A_const_78 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[117]); A_arbace_j2g_jrt_A_const_79 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[118]); A_arbace_j2g_jrt_A_const_80 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[119]); A_arbace_j2g_jrt_A_const_81 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[120]); A_arbace_j2g_jrt_A_const_82 = A_arbace_j2g_jrt_A_const_pool.A[121]; A_arbace_j2g_jrt_A_const_83 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[122]); A_arbace_j2g_jrt_A_const_84 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[123]) }

func A_arbace_j2g_jrt_A_clinit_p7() { A_arbace_j2g_jrt_A_const_85 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[124]); A_arbace_j2g_jrt_A_const_86 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[125]); A_arbace_j2g_jrt_A_const_87 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[126]); A_arbace_j2g_jrt_A_const_88 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[127]); A_arbace_j2g_jrt_A_const_89 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[128]); A_arbace_j2g_jrt_A_const_90 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[129]); A_arbace_j2g_jrt_A_const_91 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[130]); A_arbace_j2g_jrt_A_const_92 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[131]); A_arbace_j2g_jrt_A_const_93 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[132]); A_arbace_j2g_jrt_A_const_94 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[133]); A_arbace_j2g_jrt_A_const_95 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[134]); A_arbace_j2g_jrt_A_const_96 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[135]) }

func A_arbace_j2g_jrt_A_clinit_p8() { A_arbace_j2g_jrt_A_const_97 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[136]); A_arbace_j2g_jrt_A_const_98 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[137]); A_arbace_j2g_jrt_A_const_99 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[138]); A_arbace_j2g_jrt_A_const_100 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[139]); A_arbace_j2g_jrt_A_const_101 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[140]); A_arbace_j2g_jrt_A_const_102 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[141]); A_arbace_j2g_jrt_A_const_103 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[142]); A_arbace_j2g_jrt_A_const_104 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[143]); A_arbace_j2g_jrt_A_const_105 = A_arbace_j2g_jrt_A_const_pool.A[144]; A_arbace_j2g_jrt_A_const_106 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[145]); A_arbace_j2g_jrt_A_const_107 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[146]); A_arbace_j2g_jrt_A_const_108 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[147]) }

func A_arbace_j2g_jrt_A_clinit_p9() { A_arbace_j2g_jrt_A_const_109 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[148]); A_arbace_j2g_jrt_A_const_110 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[149]) }

func A_arbace_j2g_jrt_A_New() *A_arbace_j2g_jrt_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_jrt_A) Ctor() {}

func (t *A_arbace_j2g_jrt_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_jrt_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_jrt_A_class }

func (t *A_arbace_j2g_jrt_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_jrt_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_jrt_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_jrt_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_jrt_A); return ok }

func A_arbace_j2g_jrt_A_Cast(x any) *A_arbace_j2g_jrt_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_jrt_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_jrt_A_class)) }; return v }



type A_arbace_j2g_jrt_define_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_define_name_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_define_name_walk__1716000019_A struct{ j2g_header uint64; F_found any }

var A_arbace_j2g_jrt_define_name_walk__1716000019_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_eval1716000004_A struct{ jrt.Object }

func A_arbace_j2g_jrt_eval1716000004_A_New() *A_arbace_j2g_jrt_eval1716000004_A { t := &A_arbace_j2g_jrt_eval1716000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_jrt_eval1716000004_A) Ctor() {}

func (t *A_arbace_j2g_jrt_eval1716000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_jrt_eval1716000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_jrt_eval1716000004_A_class }

func (t *A_arbace_j2g_jrt_eval1716000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_jrt_eval1716000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_jrt_eval1716000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_jrt_eval1716000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_jrt_eval1716000004_A); return ok }

func A_arbace_j2g_jrt_eval1716000004_A_Cast(x any) *A_arbace_j2g_jrt_eval1716000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_jrt_eval1716000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_jrt_eval1716000004_A_class)) }; return v }



type A_arbace_j2g_jrt_eval1716000004_loading__1927001464__auto____1716000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_eval1716000004_loading__1927001464__auto____1716000005_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_eval1716000008_A struct{ jrt.Object }

func A_arbace_j2g_jrt_eval1716000008_A_New() *A_arbace_j2g_jrt_eval1716000008_A { t := &A_arbace_j2g_jrt_eval1716000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_jrt_eval1716000008_A) Ctor() {}

func (t *A_arbace_j2g_jrt_eval1716000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_jrt_eval1716000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_jrt_eval1716000008_A_class }

func (t *A_arbace_j2g_jrt_eval1716000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_jrt_eval1716000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_jrt_eval1716000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_jrt_eval1716000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_jrt_eval1716000008_A); return ok }

func A_arbace_j2g_jrt_eval1716000008_A_Cast(x any) *A_arbace_j2g_jrt_eval1716000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_jrt_eval1716000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_jrt_eval1716000008_A_class)) }; return v }



type A_arbace_j2g_jrt_eval1716000008_fn__1716000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_eval1716000008_fn__1716000009_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_go_head_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_go_head_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_head_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_head_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_iface_methods_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_iface_methods_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_iface_methods_fn__1716000268_A struct{ j2g_header uint64; F_scan any }

var A_arbace_j2g_jrt_iface_methods_fn__1716000268_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_interface_elems_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_interface_elems_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A struct{ j2g_header uint64; F_s__1716000162, F_iter__1716000161 any }

var A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A struct{ j2g_header uint64; F_b__1716000164 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A struct{ j2g_header uint64; F_s__1716000172, F_iter__1716000171 any }

var A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A struct{ j2g_header uint64; F_b__1716000174 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_other_system_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_other_system_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_jrt_recv_type_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_recv_type_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_recv_type_nm__1716000015_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_recv_type_nm__1716000015_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_scan_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_fn__1716000186_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_scan_fn__1716000186_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_fn__1716000188_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_scan_fn__1716000188_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A struct{ j2g_header uint64; F_s__1716000191, F_iter__1716000190 any }

var A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A struct{ j2g_header uint64; F_b__1716000193 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A struct{ j2g_header uint64; F_s__1716000201, F_iter__1716000200 any }

var A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A struct{ j2g_header uint64; F_fname any }

var A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A struct{ j2g_header uint64; F_s__1716000203, F_iter__1716000202, F_fname any }

var A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A struct{ j2g_header uint64; F_fname, F_b__1716000205 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A struct{ j2g_header uint64; F_s__1716000226, F_iter__1716000225 any }

var A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A struct{ j2g_header uint64; F_b__1716000228 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A struct{ j2g_header uint64; F_s__1716000246, F_iter__1716000245 any }

var A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A struct{ j2g_header uint64; F_b__1716000248 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_file_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_scan_file_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_strip_doc_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_strip_doc_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_struct_embed_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_struct_embed_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_struct_methods_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_struct_methods_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_tag_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_tag_of_A_fn_class *jrt.Class
