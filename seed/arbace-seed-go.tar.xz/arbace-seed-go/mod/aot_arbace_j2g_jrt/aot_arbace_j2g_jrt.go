//line aot_arbace_j2g_jrt.ae:1
package aot_arbace_j2g_jrt

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_java_io"
	"arbace/aot_arbace_repr_go_print"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_jrt_eval1716000004_loading__1927001464__auto____1716000005_A_New() *A_arbace_j2g_jrt_eval1716000004_loading__1927001464__auto____1716000005_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_eval1716000004_loading__1927001464__auto____1716000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_jrt_eval1716000004_loading__1927001464__auto____1716000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_jrt_eval1716000004_loading__1927001464__auto____1716000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_jrt_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_jrt_A_const_6); tmp2 = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_jrt_A_const_1, A_arbace_j2g_jrt_A_const_2, A_arbace_j2g_jrt_A_const_3, A_arbace_j2g_jrt_A_const_4); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_jrt_eval1716000008_fn__1716000009_A_New() *A_arbace_j2g_jrt_eval1716000008_fn__1716000009_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_eval1716000008_fn__1716000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_jrt_eval1716000008_fn__1716000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_jrt_eval1716000008_fn__1716000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_j2g_jrt_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_j2g_jrt_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(), A_arbace_j2g_jrt_A_const_11) }









func A_arbace_j2g_jrt_head_A_New() *A_arbace_j2g_jrt_head_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_head_A{}; t.Ctor(); return t }
//line :11:1
func (t *A_arbace_j2g_jrt_head_A) Ctor() {}
//line :11:1
func (t *A_arbace_j2g_jrt_head_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_22 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = f__0; if linked_23 == nil { and__1927000168__auto____2 = ifn_24.Invoke_O__O(arg_25) } else { and__1927000168__auto____2 = linked_23.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_22, arg_25) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_26 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any; var root_30 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_32 lang.IFn; if linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any = f__0; if linked_31 == nil { arg_29 = ifn_32.Invoke_O__O(arg_33) } else { arg_29 = linked_31.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_30, arg_33) }; if linked_27 == nil { tmp1 = ifn_28.Invoke_O__O(arg_29) } else { tmp1 = linked_27.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_26, arg_29) } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var root_34 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any; var root_38 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_38, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_40 lang.IFn; if linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any = f__0; if linked_39 == nil { arg_37 = ifn_40.Invoke_O__O(arg_41) } else { arg_37 = linked_39.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_38, arg_41) }; if linked_35 == nil { return ifn_36.Invoke_O__O(arg_37) } else { return linked_35.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_34, arg_37) } } else { return nil } }

func A_arbace_j2g_jrt_go_head_A_New() *A_arbace_j2g_jrt_go_head_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_go_head_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_j2g_jrt_go_head_A) Ctor() {}
//line :13:1
func (t *A_arbace_j2g_jrt_go_head_A) Invoke_O_O__O(self, f__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var root_42 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_42, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any = f__0; if linked_43 == nil { and__1927000168__auto____2 = ifn_44.Invoke_O__O(arg_45) } else { and__1927000168__auto____2 = linked_43.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_42, arg_45) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_46 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any; var root_50 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = f__0; if linked_51 == nil { arg_49 = ifn_52.Invoke_O__O(arg_53) } else { arg_49 = linked_51.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_50, arg_53) }; if linked_47 == nil { and__1927000168__auto____3 = ifn_48.Invoke_O__O(arg_49) } else { and__1927000168__auto____3 = linked_47.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_46, arg_49) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_16); var tmp3 any; var root_62 any = A_arbace_j2g_jrt_A_const_17.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_64 lang.IFn; if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any; var root_66 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = f__0; if linked_67 == nil { arg_65 = ifn_68.Invoke_O__O(arg_69) } else { arg_65 = linked_67.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_66, arg_69) }; if linked_63 == nil { tmp3 = ifn_64.Invoke_O__O(arg_65) } else { tmp3 = linked_63.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_62, arg_65) }; tmp1 = tmp2.Invoke_O__O(tmp3) } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		var root_54 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any; var root_58 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = f__0; if linked_59 == nil { arg_57 = ifn_60.Invoke_O__O(arg_61) } else { arg_57 = linked_59.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_58, arg_61) }; if linked_55 == nil { return ifn_56.Invoke_O__O(arg_57) } else { return linked_55.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_54, arg_57) } } else {
//line :14:1
			return nil
		}
}
func A_arbace_j2g_jrt_tag_of_A_New() *A_arbace_j2g_jrt_tag_of_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_tag_of_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_j2g_jrt_tag_of_A) Ctor() {}
//line :17:1
func (t *A_arbace_j2g_jrt_tag_of_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_jrt_A_const_18; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0)) }

func A_arbace_j2g_jrt_recv_type_A_New() *A_arbace_j2g_jrt_recv_type_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_recv_type_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_j2g_jrt_recv_type_A) Ctor() {}
//line :19:1
func (t *A_arbace_j2g_jrt_recv_type_A) Invoke_O_O__O(self, r__0 any) any { var t__2 any; var tmp1 any; var root_70 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_72 lang.IFn; if


	linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = r__0; if linked_71 == nil { tmp1 = ifn_72.Invoke_O__O(arg_73) } else { tmp1 = linked_71.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_70, arg_73) }; if jrt.J2g_Truth(tmp1) { var root_74 any = A_arbace_j2g_jrt_A_const_19.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, A_arbace_j2g_jrt_tag_of_A_fn_class); var ifn_76 lang.IFn; if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any = r__0; if linked_75 == nil { t__2 = ifn_76.Invoke_O__O(arg_77) } else { t__2 = linked_75.(*A_arbace_j2g_jrt_tag_of_A).Invoke_O_O__O(root_74, arg_77) } } else { t__2 = r__0 }; var body_nm__3 /*line :19:1*/*A_arbace_j2g_jrt_recv_type_nm__1716000015_A = A_arbace_j2g_jrt_recv_type_nm__1716000015_A_New(); var nm__3 any; var tmp2 *jrt.Class; var fncls__118 *jrt.Class = A_arbace_j2g_jrt_recv_type_nm__1716000015_A_fn_class; if fncls__118 == nil { var fncls__118d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_j2g_jrt_recv_type_nm__1716000015_A_fn_class = fncls__118d; tmp2 = fncls__118d } else { tmp2 = fncls__118 }; nm__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_nm__3), tmp2, nil); return /*line :27:1*/ lang.IFn_Cast(nm__3).Invoke_O__O(t__2) }
//line :23:1
func A_arbace_j2g_jrt_recv_type_nm__1716000015_A_New() *A_arbace_j2g_jrt_recv_type_nm__1716000015_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_recv_type_nm__1716000015_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_j2g_jrt_recv_type_nm__1716000015_A) Ctor() {}
//line :23:1
func (t *A_arbace_j2g_jrt_recv_type_nm__1716000015_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any; var root_78 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = x__1; if linked_79 == nil { tmp1 = ifn_80.Invoke_O__O(arg_81) } else { tmp1 = linked_79.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_78, arg_81) }; if jrt.J2g_Truth(tmp1) { var root_82 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = x__1; if linked_83 == nil { return ifn_84.Invoke_O__O(arg_85) } else { return linked_83.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_82, arg_85) } } else { var tmp2 any; var and__1927000168__auto____2 any; var root_86 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_88 lang.IFn
											if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any = x__1; if linked_87 == nil { and__1927000168__auto____2 = ifn_88.Invoke_O__O(arg_89) } else { and__1927000168__auto____2 = linked_87.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_86, arg_89) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp3 any = A_arbace_j2g_jrt_A_const_20; var tmp4 any; var root_90 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = x__1; if linked_91 == nil { tmp4 = ifn_92.Invoke_O__O(arg_93) } else { tmp4 = linked_91.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_90, arg_93) }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)).Ref() } else { tmp2 = and__1927000168__auto____2 }
//line :23:1
	if jrt.J2g_Truth(tmp2) {
		var tmp5 lang.IFn = lang.IFn_Cast(self); var tmp6 any; var root_114 any = A_arbace_j2g_jrt_A_const_22.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_116 lang.IFn; if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any = x__1; if linked_115 == nil { tmp6 = ifn_116.Invoke_O__O(arg_117) } else { tmp6 = linked_115.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_114, arg_117) }; return tmp5.Invoke_O__O(tmp6) } else {
//line :23:1
			var tmp7 any; var and__1927000168__auto____2_2 any; var root_94 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_96 lang.IFn

			if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = x__1; if linked_95 == nil { and__1927000168__auto____2_2 = ifn_96.Invoke_O__O(arg_97) } else { and__1927000168__auto____2_2 = linked_95.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_94, arg_97) }; if jrt.J2g_Truth(and__1927000168__auto____2_2) { var root_98 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any; var root_102 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = x__1; if linked_103 == nil { arg_101 = ifn_104.Invoke_O__O(arg_105) } else { arg_101 = linked_103.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_102, arg_105) }; if linked_99 == nil { tmp7 = ifn_100.Invoke_O__O(arg_101) } else { tmp7 = linked_99.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_98, arg_101) } } else { tmp7 = and__1927000168__auto____2_2 }
//line :23:1
			if jrt.J2g_Truth(tmp7) {

				var root_106 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any; var root_110 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_112 lang.IFn; if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any = x__1; if linked_111 == nil { arg_109 = ifn_112.Invoke_O__O(arg_113) } else { arg_109 = linked_111.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_110, arg_113) }; if linked_107 == nil { return ifn_108.Invoke_O__O(arg_109) } else { return linked_107.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_106, arg_109) } } else {
//line :23:1
					if A_arbace_j2g_jrt_A_const_21 != nil { return nil } else { return nil } } } } }





func A_arbace_j2g_jrt_strip_doc_A_New() *A_arbace_j2g_jrt_strip_doc_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_strip_doc_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_j2g_jrt_strip_doc_A) Ctor() {}
//line :29:1
func (t *A_arbace_j2g_jrt_strip_doc_A) Invoke_O_O__O(self, xs__0 any) any { var tmp1 any; var root_119 any = A_arbace_j2g_jrt_A_const_23.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any; var root_123 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = xs__0; if linked_124 == nil { arg_122 = ifn_125.Invoke_O__O(arg_126) } else { arg_122 = linked_124.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_123, arg_126) }; if linked_120 == nil { tmp1 = ifn_121.Invoke_O__O(arg_122) } else { tmp1 = linked_120.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_119, arg_122) }; if jrt.J2g_Truth(tmp1) { var root_127 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = xs__0; if linked_128 == nil { return ifn_129.Invoke_O__O(arg_130) } else { return linked_128.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_127, arg_130) } } else { return xs__0 } }

func A_arbace_j2g_jrt_define_name_A_New() *A_arbace_j2g_jrt_define_name_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_define_name_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_j2g_jrt_define_name_A) Ctor() {}
//line :31:1
func (t *A_arbace_j2g_jrt_define_name_A) Invoke_O_O__O(self, init__0 any) any { var found__2 any; var root_131 any = A_arbace_j2g_jrt_A_const_25.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_131, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_133 lang.IFn; if


	linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any; if linked_132 == nil { found__2 = ifn_133.Invoke_O__O(arg_134) } else { found__2 = linked_132.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_131, arg_134) }; var body_walk__3 /*line :31:1*/*A_arbace_j2g_jrt_define_name_walk__1716000019_A = A_arbace_j2g_jrt_define_name_walk__1716000019_A_New_O(found__2); var walk__3 any; var tmp1 *jrt.Class; var fncls__179 *jrt.Class = A_arbace_j2g_jrt_define_name_walk__1716000019_A_fn_class; if fncls__179 == nil { var fncls__179d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_j2g_jrt_define_name_walk__1716000019_A_fn_class = fncls__179d; tmp1 = fncls__179d } else { tmp1 = fncls__179 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__3), tmp1, nil);










	lang.IFn_Cast(walk__3).Invoke_O__O(init__0); var root_135 any = /*line :34:1*/A_arbace_j2g_jrt_A_const_8.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = found__2; if linked_136 == nil { return ifn_137.Invoke_O__O(arg_138) } else { return linked_136.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_135, arg_138) } }
func A_arbace_j2g_jrt_define_name_walk__1716000019_A_New_O(p0 any) *A_arbace_j2g_jrt_define_name_walk__1716000019_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_define_name_walk__1716000019_A{}; t.Ctor_O(p0); return t }
//line :35:1
func (t *A_arbace_j2g_jrt_define_name_walk__1716000019_A) Ctor_O(c__found any) { t.F_found = c__found }
//line :35:1
func (t *A_arbace_j2g_jrt_define_name_walk__1716000019_A) Invoke_O_O__O(self, x__1 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var root_139 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_139, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_141 lang.IFn
	if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = x__1; if linked_140 == nil { and__1927000168__auto____2 = ifn_141.Invoke_O__O(arg_142) } else { and__1927000168__auto____2 = linked_140.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_139, arg_142) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 bool; var tmp2 any; var root_143 any = A_arbace_j2g_jrt_A_const_26.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, A_arbace_j2g_jrt_head_A_fn_class); var ifn_145 lang.IFn; if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = x__1; if linked_144 == nil { tmp2 = ifn_145.Invoke_O__O(arg_146) } else { tmp2 = linked_144.(*A_arbace_j2g_jrt_head_A).Invoke_O_O__O(root_143, arg_146) }; and__1927000168__auto____3 = lang.Util_Equiv_O_O__Z_NoInit(Lit_2, tmp2); if and__1927000168__auto____3 { var tmp3 any = A_arbace_j2g_jrt_A_const_27; var tmp4 any; var root_147 any = A_arbace_j2g_jrt_A_const_22.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = x__1; if linked_148 == nil { tmp4 = ifn_149.Invoke_O__O(arg_150) } else { tmp4 = linked_148.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_147, arg_150) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)).Ref() } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { tmp1 = and__1927000168__auto____2 }
//line :36:1
	if jrt.J2g_Truth(tmp1) { var kvs__2 any; var root_151 any = A_arbace_j2g_jrt_A_const_28.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_153 lang.IFn

		if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = A_arbace_j2g_jrt_A_const_29.GetRawRoot__O(); var arg_155 any; var root_156 any = A_arbace_j2g_jrt_A_const_30.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_156, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_160 any = x__1; if linked_157 == nil { arg_155 = ifn_158.Invoke_O_O__O(A_arbace_j2g_jrt_A_const_31, arg_160) } else { arg_155 = linked_157.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_156, 2, A_arbace_j2g_jrt_A_const_31, arg_160) }; if linked_152 == nil { kvs__2 = ifn_153.Invoke_O_O__O(arg_154, arg_155) } else { kvs__2 = linked_152.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_151, arg_154, arg_155) }
		var tmp5 any; var root_161 any = A_arbace_j2g_jrt_A_const_23.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_163 lang.IFn; if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = A_arbace_j2g_jrt_A_const_32.Invoke_O__O(kvs__2); if linked_162 == nil { tmp5 = ifn_163.Invoke_O__O(arg_164) } else { tmp5 = linked_162.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_161, arg_164) }; if jrt.J2g_Truth(tmp5) { var root_165 any = A_arbace_j2g_jrt_A_const_33.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = t.F_found; var tmp6 any = A_arbace_j2g_jrt_A_const_34; var arg_169 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, A_arbace_j2g_jrt_A_const_32.Invoke_O__O(kvs__2), A_arbace_j2g_jrt_A_const_35, kvs__2)); if linked_166 == nil { return ifn_167.Invoke_O_O__O(arg_168, arg_169) } else { return linked_166.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_165, arg_168, arg_169) } } else { return nil } } else {
//line :36:1
			var tmp7 any; var root_170 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_172 lang.IFn



			if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = x__1; if linked_171 == nil { tmp7 = ifn_172.Invoke_O__O(arg_173) } else { tmp7 = linked_171.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_170, arg_173) }
//line :36:1
			if jrt.J2g_Truth(tmp7) {



				var root_174 any = A_arbace_j2g_jrt_A_const_36.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = self; var arg_178 any = x__1; if linked_175 == nil { return ifn_176.Invoke_O_O__O(arg_177, arg_178) } else { return linked_175.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_174, arg_177, arg_178) } } else {
//line :36:1
					if A_arbace_j2g_jrt_A_const_21 != nil { return nil } else { return nil
					}
				}
		}
}




func A_arbace_j2g_jrt_scan_file_A_New() *A_arbace_j2g_jrt_scan_file_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_file_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_j2g_jrt_scan_file_A) Ctor() {}
//line :45:1
func (t *A_arbace_j2g_jrt_scan_file_A) Invoke_O_O__O(self, f__0 any) any { var forms__2 any; var root_180 any = A_arbace_j2g_jrt_A_const_37.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A_fn_class); var ifn_182 lang.IFn; if



	linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = f__0; if linked_181 == nil { forms__2 = ifn_182.Invoke_O__O(arg_183) } else { forms__2 = linked_181.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A).Invoke_O_O__O(root_180, arg_183) }; var acc__3 any; var root_184 any = /*line :45:1*/A_arbace_j2g_jrt_A_const_38.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_186 lang.IFn; if




	linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_jrt_A_const_39, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_j2g_jrt_A_const_40, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_j2g_jrt_A_const_41, lang.PersistentHashSet_EMPTY.Ref(), A_arbace_j2g_jrt_A_const_42, lang.PersistentHashSet_EMPTY.Ref(), A_arbace_j2g_jrt_A_const_43, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_j2g_jrt_A_const_44, lang.PersistentHashSet_EMPTY.Ref())); if linked_185 == nil { acc__3 = ifn_186.Invoke_O__O(arg_187) } else { acc__3 = linked_185.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_184, arg_187) }; var seq_1716000022__4 any; var root_192 any = /*line :45:1*/A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_194 lang.IFn; if





	linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = forms__2; if linked_193 == nil { seq_1716000022__4 = ifn_194.Invoke_O__O(arg_195) } else { seq_1716000022__4 = linked_193.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_192, arg_195) }; var chunk_1716000023__5 any; var count_1716000024__6 int64 = 0; var i_1716000025__7 int64 = 0; L1:
//line :45:1
	for {





		if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000025__7, count_1716000024__6) { var fm__8 any = lang.Indexed_Cast(chunk_1716000023__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000025__7)); var h__9 any; var root_196 any = A_arbace_j2g_jrt_A_const_46.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, A_arbace_j2g_jrt_go_head_A_fn_class); var ifn_198 lang.IFn
			if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = fm__8; if linked_197 == nil { h__9 = ifn_198.Invoke_O__O(arg_199) } else { h__9 = linked_197.(*A_arbace_j2g_jrt_go_head_A).Invoke_O_O__O(root_196, arg_199) }
//line :51:1
			if jrt.J2g_Truth(h__9) { var G__1716000026__10_ any = h__9


			L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__1716000026__10_) >> 0 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000026__10_, Lit_31) { var vec__1716000027__11 any = fm__8; var seq__1716000028__12 any; var root_221 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_223 lang.IFn


















				if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = vec__1716000027__11; if linked_222 == nil { seq__1716000028__12 = ifn_223.Invoke_O__O(arg_224) } else { seq__1716000028__12 = linked_222.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_221, arg_224) }
//line :54:1
				var first__1716000029__13 any; var root_225 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_227 lang.IFn


















				if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any = seq__1716000028__12; if linked_226 == nil { first__1716000029__13 = ifn_227.Invoke_O__O(arg_228) } else { first__1716000029__13 = linked_226.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_225, arg_228) }
//line :54:1
				var seq__1716000028__14 any; var root_229 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_229, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_231 lang.IFn


















				if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any = seq__1716000028__12; if linked_230 == nil { seq__1716000028__14 = ifn_231.Invoke_O__O(arg_232) } else { seq__1716000028__14 = linked_230.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_229, arg_232) }
//line :54:1
				var ___15 any = first__1716000029__13; var first__1716000029__16 any; var root_233 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_235 lang.IFn; _ = ___15


















				if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any = seq__1716000028__14; if linked_234 == nil { first__1716000029__16 = ifn_235.Invoke_O__O(arg_236) } else { first__1716000029__16 = linked_234.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_233, arg_236) }
//line :54:1
				var seq__1716000028__17 any; var root_237 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_237, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_239 lang.IFn


















				if linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any = seq__1716000028__14; if linked_238 == nil { seq__1716000028__17 = ifn_239.Invoke_O__O(arg_240) } else { seq__1716000028__17 = linked_238.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_237, arg_240) }
//line :54:1
				var nm__18 any = first__1716000029__16; var more__19 any = seq__1716000028__17; var more__20 any; var root_241 any = A_arbace_j2g_jrt_A_const_50.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, A_arbace_j2g_jrt_strip_doc_A_fn_class); var ifn_243 lang.IFn



















				if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any = more__19; if linked_242 == nil { more__20 = ifn_243.Invoke_O__O(arg_244) } else { more__20 = linked_242.(*A_arbace_j2g_jrt_strip_doc_A).Invoke_O_O__O(root_241, arg_244) }
//line :54:1
				var more__21 any; var tmp1 any = A_arbace_j2g_jrt_A_const_51; var tmp2 any; var root_245 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_247 lang.IFn




















				if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = more__20; if linked_246 == nil { tmp2 = ifn_247.Invoke_O__O(arg_248) } else { tmp2 = linked_246.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_245, arg_248) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2) { var root_249 any = A_arbace_j2g_jrt_A_const_30.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_249, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_253 any = more__20; if linked_250 == nil { more__21 = ifn_251.Invoke_O_O__O(A_arbace_j2g_jrt_A_const_31, arg_253) } else { more__21 = linked_250.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_249, 2, A_arbace_j2g_jrt_A_const_31, arg_253) } } else { more__21 = more__20 }
//line :54:1
				var params__22 any; var root_254 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_256 lang.IFn





















				if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = more__21; if linked_255 == nil { params__22 = ifn_256.Invoke_O__O(arg_257) } else { params__22 = linked_255.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_254, arg_257) }
//line :54:1
				var rt__23 any; var root_258 any = A_arbace_j2g_jrt_A_const_52.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, A_arbace_j2g_jrt_recv_type_A_fn_class); var ifn_260 lang.IFn






















				if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any; var root_262 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = params__22; if linked_263 == nil { arg_261 = ifn_264.Invoke_O__O(arg_265) } else { arg_261 = linked_263.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_262, arg_265) }; if linked_259 == nil { rt__23 = ifn_260.Invoke_O__O(arg_261) } else { rt__23 = linked_259.(*A_arbace_j2g_jrt_recv_type_A).Invoke_O_O__O(root_258, arg_261) }
				if jrt.J2g_Truth(rt__23) { var tmp3 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_53.GetRawRoot__O()); var tmp5 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp6 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_jrt_A_const_40, rt__23); var tmp7 any; var root_273 any = A_arbace_j2g_jrt_A_const_54.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_277 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_274 == nil { tmp7 = ifn_275.Invoke_O_O__O(arg_276, arg_277) } else { tmp7 = linked_274.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_273, arg_276, arg_277) }; var tmp8 any = tmp7; var tmp9 any; var root_278 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_278, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_280 lang.IFn; if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any = nm__18; if linked_279 == nil { tmp9 = ifn_280.Invoke_O__O(arg_281) } else { tmp9 = linked_279.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_278, arg_281) }; jrt.NN(tmp3).Reset_O__O(tmp4.Invoke_O_O_O_O__O(tmp5, tmp6, tmp8, tmp9)) }
//line :54:1
				break L2 }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000026__10_, Lit_32) { var vec__1716000030__11 any = fm__8; var seq__1716000031__12 any; var root_282 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_284 lang.IFn
					if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = vec__1716000030__11; if linked_283 == nil { seq__1716000031__12 = ifn_284.Invoke_O__O(arg_285) } else { seq__1716000031__12 = linked_283.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_282, arg_285) }
//line :54:1
					var first__1716000032__13 any; var root_286 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_288 lang.IFn
					if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = seq__1716000031__12; if linked_287 == nil { first__1716000032__13 = ifn_288.Invoke_O__O(arg_289) } else { first__1716000032__13 = linked_287.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_286, arg_289) }
//line :54:1
					var seq__1716000031__14 any; var root_290 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_292 lang.IFn
					if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = seq__1716000031__12; if linked_291 == nil { seq__1716000031__14 = ifn_292.Invoke_O__O(arg_293) } else { seq__1716000031__14 = linked_291.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_290, arg_293) }
//line :54:1
					var ___15_2 any = first__1716000032__13; var more__16 any = seq__1716000031__14; var more__17 any; var root_294 any = A_arbace_j2g_jrt_A_const_50.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, A_arbace_j2g_jrt_strip_doc_A_fn_class); var ifn_296 lang.IFn; _ = ___15_2

					if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any = more__16; if linked_295 == nil { more__17 = ifn_296.Invoke_O__O(arg_297) } else { more__17 = linked_295.(*A_arbace_j2g_jrt_strip_doc_A).Invoke_O_O__O(root_294, arg_297) }
					var tmp10 any; var root_298 any = A_arbace_j2g_jrt_A_const_55.GetRawRoot__O(); var linked_299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_298, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_300 lang.IFn; if linked_299 == nil { ifn_300 = lang.IFn_Cast(root_298) } else { ifn_300 = nil }; var arg_301 any; var root_302 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any = more__17; if linked_303 == nil { arg_301 = ifn_304.Invoke_O__O(arg_305) } else { arg_301 = linked_303.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_302, arg_305) }; if linked_299 == nil { tmp10 = ifn_300.Invoke_O__O(arg_301) } else { tmp10 = linked_299.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_298, arg_301) }; if jrt.J2g_Truth(tmp10) { var seq_1716000033__18 any; var root_306 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_306, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_308 lang.IFn
						if linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any = more__17; if linked_307 == nil { seq_1716000033__18 = ifn_308.Invoke_O__O(arg_309) } else { seq_1716000033__18 = linked_307.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_306, arg_309) }
//line :57:1
						var chunk_1716000034__19 any; var count_1716000035__20 int64 = 0; var i_1716000036__21 int64 = 0; L3: for {
							if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000036__21, count_1716000035__20) { var vec__1716000037__22 any = lang.Indexed_Cast(chunk_1716000034__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000036__21)); var nm__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000037__22, lang.RT_IntCast_J__I_NoInit(0), nil); var tf__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000037__22, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp11 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp12 any; var root_455 any = A_arbace_j2g_jrt_A_const_56.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_455, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_457 lang.IFn
								if linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_459 any; var tmp13 any = A_arbace_j2g_jrt_A_const_39; var tmp14 any; var root_461 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_461, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_463 lang.IFn; if linked_462 == nil { ifn_463 = lang.IFn_Cast(root_461) } else { ifn_463 = nil }; var arg_464 any = nm__23; if linked_462 == nil { tmp14 = ifn_463.Invoke_O__O(arg_464) } else { tmp14 = linked_462.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_461, arg_464) }; arg_459 = lang.Tuple_Create_O_O__IPersistentVector(tmp13, tmp14); var arg_460 any; var tmp15 any = A_arbace_j2g_jrt_A_const_57; var tmp16 *lang.Keyword; var tmp17 any; var and__1927000168__auto____25 any; var root_465 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_465, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_467 lang.IFn
								if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any = tf__24; if linked_466 == nil { and__1927000168__auto____25 = ifn_467.Invoke_O__O(arg_468) } else { and__1927000168__auto____25 = linked_466.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_465, arg_468) }; if jrt.J2g_Truth(and__1927000168__auto____25) { var tmp18 any = A_arbace_j2g_jrt_A_const_65; var tmp19 any; var root_469 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any = tf__24; if linked_470 == nil { tmp19 = ifn_471.Invoke_O__O(arg_472) } else { tmp19 = linked_470.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_469, arg_472) }; tmp17 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp18, tmp19)).Ref() } else { tmp17 = and__1927000168__auto____25 }; if jrt.J2g_Truth(tmp17) { tmp16 = A_arbace_j2g_jrt_A_const_59 } else { var tmp20 any; var and__1927000168__auto____25_2 any; var root_473 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_473, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_475 lang.IFn
									if linked_474 == nil { ifn_475 = lang.IFn_Cast(root_473) } else { ifn_475 = nil }; var arg_476 any = tf__24; if linked_474 == nil { and__1927000168__auto____25_2 = ifn_475.Invoke_O__O(arg_476) } else { and__1927000168__auto____25_2 = linked_474.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_473, arg_476) }; if jrt.J2g_Truth(and__1927000168__auto____25_2) { var tmp21 any = A_arbace_j2g_jrt_A_const_66; var tmp22 any; var root_477 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_477, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_479 lang.IFn; if linked_478 == nil { ifn_479 = lang.IFn_Cast(root_477) } else { ifn_479 = nil }; var arg_480 any = tf__24; if linked_478 == nil { tmp22 = ifn_479.Invoke_O__O(arg_480) } else { tmp22 = linked_478.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_477, arg_480) }; tmp20 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp21, tmp22)).Ref() } else { tmp20 = and__1927000168__auto____25_2 }
//line :60:1
									if jrt.J2g_Truth(tmp20) { tmp16 = A_arbace_j2g_jrt_A_const_61 } else { if A_arbace_j2g_jrt_A_const_21 != nil { tmp16 = A_arbace_j2g_jrt_A_const_62 } else { tmp16 = nil } } }
//line :59:1
								arg_460 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp15, tmp16.Ref(), A_arbace_j2g_jrt_A_const_63, tf__24)); if linked_456 == nil { tmp12 = ifn_457.Invoke_O_O_O__O(arg_458, arg_459, arg_460) } else { tmp12 = linked_456.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_455, arg_458, arg_459, arg_460) }; jrt.NN(tmp11).Reset_O__O(tmp12)
//line :58:1
								seq_1716000033__18, chunk_1716000034__19, count_1716000035__20, i_1716000036__21 = seq_1716000033__18, chunk_1716000034__19, count_1716000035__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000036__21); continue L3 } else { var temp__1927000414__auto____22 any; var root_310 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_310, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_312 lang.IFn; if linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; var arg_313 any = seq_1716000033__18; if linked_311 == nil { temp__1927000414__auto____22 = ifn_312.Invoke_O__O(arg_313) } else { temp__1927000414__auto____22 = linked_311.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_310, arg_313) }; if jrt.J2g_Truth(temp__1927000414__auto____22) { var seq_1716000033__23 any = temp__1927000414__auto____22; var tmp23 any; var root_314 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_314, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_316 lang.IFn; if linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any = seq_1716000033__23; if linked_315 == nil { tmp23 = ifn_316.Invoke_O__O(arg_317) } else { tmp23 = linked_315.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_314, arg_317) }; if jrt.J2g_Truth(tmp23) { var c__1927000678__auto____24 any; var root_318 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_318, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any = seq_1716000033__23; if linked_319 == nil { c__1927000678__auto____24 = ifn_320.Invoke_O__O(arg_321) } else { c__1927000678__auto____24 = linked_319.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_318, arg_321) }; var tmp24 any; var root_481 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_481, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_483 lang.IFn; if linked_482 == nil { ifn_483 = lang.IFn_Cast(root_481) } else { ifn_483 = nil }; var arg_484 any = seq_1716000033__23; if linked_482 == nil { tmp24 = ifn_483.Invoke_O__O(arg_484) } else { tmp24 = linked_482.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_481, arg_484) }; seq_1716000033__18, chunk_1716000034__19, count_1716000035__20, i_1716000036__21 = tmp24, c__1927000678__auto____24, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__1716000040__24 any; var root_322 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_324 lang.IFn; if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any = seq_1716000033__23; if linked_323 == nil { vec__1716000040__24 = ifn_324.Invoke_O__O(arg_325) } else { vec__1716000040__24 = linked_323.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_322, arg_325) }; var nm__25 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000040__24, lang.RT_IntCast_J__I_NoInit(0), nil); var tf__26 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000040__24, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp25 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp26 any; var root_485 any = A_arbace_j2g_jrt_A_const_56.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_487 lang.IFn
									if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_489 any; var tmp27 any = A_arbace_j2g_jrt_A_const_39; var tmp28 any; var root_491 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_491, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_493 lang.IFn; if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = nm__25; if linked_492 == nil { tmp28 = ifn_493.Invoke_O__O(arg_494) } else { tmp28 = linked_492.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_491, arg_494) }; arg_489 = lang.Tuple_Create_O_O__IPersistentVector(tmp27, tmp28); var arg_490 any; var tmp29 any = A_arbace_j2g_jrt_A_const_57; var tmp30 *lang.Keyword; var tmp31 any; var and__1927000168__auto____27 any; var root_495 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_495, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_497 lang.IFn
									if linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any = tf__26; if linked_496 == nil { and__1927000168__auto____27 = ifn_497.Invoke_O__O(arg_498) } else { and__1927000168__auto____27 = linked_496.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_495, arg_498) }; if jrt.J2g_Truth(and__1927000168__auto____27) { var tmp32 any = A_arbace_j2g_jrt_A_const_65; var tmp33 any; var root_499 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_499, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_501 lang.IFn; if linked_500 == nil { ifn_501 = lang.IFn_Cast(root_499) } else { ifn_501 = nil }; var arg_502 any = tf__26; if linked_500 == nil { tmp33 = ifn_501.Invoke_O__O(arg_502) } else { tmp33 = linked_500.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_499, arg_502) }; tmp31 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp32, tmp33)).Ref() } else { tmp31 = and__1927000168__auto____27 }; if jrt.J2g_Truth(tmp31) { tmp30 = A_arbace_j2g_jrt_A_const_59 } else { var tmp34 any; var and__1927000168__auto____27_2 any; var root_503 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_505 lang.IFn
										if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = tf__26; if linked_504 == nil { and__1927000168__auto____27_2 = ifn_505.Invoke_O__O(arg_506) } else { and__1927000168__auto____27_2 = linked_504.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_503, arg_506) }; if jrt.J2g_Truth(and__1927000168__auto____27_2) { var tmp35 any = A_arbace_j2g_jrt_A_const_66; var tmp36 any; var root_507 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = tf__26; if linked_508 == nil { tmp36 = ifn_509.Invoke_O__O(arg_510) } else { tmp36 = linked_508.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_507, arg_510) }; tmp34 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp35, tmp36)).Ref() } else { tmp34 = and__1927000168__auto____27_2 }
//line :60:1
										if jrt.J2g_Truth(tmp34) { tmp30 = A_arbace_j2g_jrt_A_const_61 } else { if A_arbace_j2g_jrt_A_const_21 != nil { tmp30 = A_arbace_j2g_jrt_A_const_62 } else { tmp30 = nil } } }
//line :59:1
									arg_490 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp29, tmp30.Ref(), A_arbace_j2g_jrt_A_const_63, tf__26)); if linked_486 == nil { tmp26 = ifn_487.Invoke_O_O_O__O(arg_488, arg_489, arg_490) } else { tmp26 = linked_486.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_485, arg_488, arg_489, arg_490) }; jrt.NN(tmp25).Reset_O__O(tmp26)
//line :58:1
									var tmp37 any; var root_511 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any = seq_1716000033__23; if linked_512 == nil { tmp37 = ifn_513.Invoke_O__O(arg_514) } else { tmp37 = linked_512.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_511, arg_514) }; seq_1716000033__18, chunk_1716000034__19, count_1716000035__20, i_1716000036__21 = tmp37, nil, 0, 0; continue L3 } } }
//line :57:1
							break L3 } } else { var nm__18_2 any; var root_326 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_328 lang.IFn






								if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any = more__17; if linked_327 == nil { nm__18_2 = ifn_328.Invoke_O__O(arg_329) } else { nm__18_2 = linked_327.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_326, arg_329) }
//line :57:1
								var more__19_2 any; var root_330 any = A_arbace_j2g_jrt_A_const_50.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, A_arbace_j2g_jrt_strip_doc_A_fn_class); var ifn_332 lang.IFn







								if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any; var root_334 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = more__17; if linked_335 == nil { arg_333 = ifn_336.Invoke_O__O(arg_337) } else { arg_333 = linked_335.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_334, arg_337) }; if linked_331 == nil { more__19_2 = ifn_332.Invoke_O__O(arg_333) } else { more__19_2 = linked_331.(*A_arbace_j2g_jrt_strip_doc_A).Invoke_O_O__O(root_330, arg_333) }
//line :57:1
								var more__20_2 any; var tmp38 any = A_arbace_j2g_jrt_A_const_51; var tmp39 any; var root_338 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_340 lang.IFn








								if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = more__19_2; if linked_339 == nil { tmp39 = ifn_340.Invoke_O__O(arg_341) } else { tmp39 = linked_339.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_338, arg_341) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp38, tmp39) { var root_342 any = A_arbace_j2g_jrt_A_const_30.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_342, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_346 any = more__19_2; if linked_343 == nil { more__20_2 = ifn_344.Invoke_O_O__O(A_arbace_j2g_jrt_A_const_31, arg_346) } else { more__20_2 = linked_343.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_342, 2, A_arbace_j2g_jrt_A_const_31, arg_346) } } else { more__20_2 = more__19_2 }
//line :57:1
								var tf__21 any; var root_347 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_349 lang.IFn









								if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any = more__20_2; if linked_348 == nil { tf__21 = ifn_349.Invoke_O__O(arg_350) } else { tf__21 = linked_348.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_347, arg_350) }
								var tmp40 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp41 any; var root_351 any = A_arbace_j2g_jrt_A_const_56.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_351, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_353 lang.IFn; if linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; var arg_354 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_355 any; var tmp42 any = A_arbace_j2g_jrt_A_const_39; var tmp43 any; var root_357 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_357, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_359 lang.IFn; if linked_358 == nil { ifn_359 = lang.IFn_Cast(root_357) } else { ifn_359 = nil }; var arg_360 any = nm__18_2; if linked_358 == nil { tmp43 = ifn_359.Invoke_O__O(arg_360) } else { tmp43 = linked_358.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_357, arg_360) }; arg_355 = lang.Tuple_Create_O_O__IPersistentVector(tmp42, tmp43); var arg_356 any; var tmp44 any = A_arbace_j2g_jrt_A_const_57; var tmp45 *lang.Keyword; var tmp46 any; var and__1927000168__auto____22 any; var root_361 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_361, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_363 lang.IFn
								if linked_362 == nil { ifn_363 = lang.IFn_Cast(root_361) } else { ifn_363 = nil }; var arg_364 any = tf__21; if linked_362 == nil { and__1927000168__auto____22 = ifn_363.Invoke_O__O(arg_364) } else { and__1927000168__auto____22 = linked_362.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_361, arg_364) }; if jrt.J2g_Truth(and__1927000168__auto____22) { var tmp47 any = A_arbace_j2g_jrt_A_const_58; var tmp48 any; var root_365 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_365, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_367 lang.IFn; if linked_366 == nil { ifn_367 = lang.IFn_Cast(root_365) } else { ifn_367 = nil }; var arg_368 any = tf__21; if linked_366 == nil { tmp48 = ifn_367.Invoke_O__O(arg_368) } else { tmp48 = linked_366.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_365, arg_368) }; tmp46 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp47, tmp48)).Ref() } else { tmp46 = and__1927000168__auto____22 }; if jrt.J2g_Truth(tmp46) { tmp45 = A_arbace_j2g_jrt_A_const_59 } else { var tmp49 any; var and__1927000168__auto____22_2 any; var root_369 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_369, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_371 lang.IFn
									if linked_370 == nil { ifn_371 = lang.IFn_Cast(root_369) } else { ifn_371 = nil }; var arg_372 any = tf__21; if linked_370 == nil { and__1927000168__auto____22_2 = ifn_371.Invoke_O__O(arg_372) } else { and__1927000168__auto____22_2 = linked_370.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_369, arg_372) }; if jrt.J2g_Truth(and__1927000168__auto____22_2) { var tmp50 any = A_arbace_j2g_jrt_A_const_60; var tmp51 any; var root_373 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_373, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_375 lang.IFn; if linked_374 == nil { ifn_375 = lang.IFn_Cast(root_373) } else { ifn_375 = nil }; var arg_376 any = tf__21; if linked_374 == nil { tmp51 = ifn_375.Invoke_O__O(arg_376) } else { tmp51 = linked_374.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_373, arg_376) }; tmp49 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp50, tmp51)).Ref() } else { tmp49 = and__1927000168__auto____22_2 }
//line :69:1
									if jrt.J2g_Truth(tmp49) { tmp45 = A_arbace_j2g_jrt_A_const_61 } else { if A_arbace_j2g_jrt_A_const_21 != nil { tmp45 = A_arbace_j2g_jrt_A_const_62 } else { tmp45 = nil } } }
//line :68:1
								arg_356 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp44, tmp45.Ref(), A_arbace_j2g_jrt_A_const_63, tf__21)); if linked_352 == nil { tmp41 = ifn_353.Invoke_O_O_O__O(arg_354, arg_355, arg_356) } else { tmp41 = linked_352.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_351, arg_354, arg_355, arg_356) }; jrt.NN(tmp40).Reset_O__O(tmp41) }
//line :54:1
					break L2 }; case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000026__10_, Lit_33) { var vec__1716000043__11 any = fm__8; var seq__1716000044__12 any; var root_377 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_377, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_379 lang.IFn








































						if linked_378 == nil { ifn_379 = lang.IFn_Cast(root_377) } else { ifn_379 = nil }; var arg_380 any = vec__1716000043__11; if linked_378 == nil { seq__1716000044__12 = ifn_379.Invoke_O__O(arg_380) } else { seq__1716000044__12 = linked_378.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_377, arg_380) }
//line :54:1
						var first__1716000045__13 any; var root_381 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_381, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_383 lang.IFn








































						if linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var arg_384 any = seq__1716000044__12; if linked_382 == nil { first__1716000045__13 = ifn_383.Invoke_O__O(arg_384) } else { first__1716000045__13 = linked_382.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_381, arg_384) }
//line :54:1
						var seq__1716000044__14 any; var root_385 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_385, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_387 lang.IFn








































						if linked_386 == nil { ifn_387 = lang.IFn_Cast(root_385) } else { ifn_387 = nil }; var arg_388 any = seq__1716000044__12; if linked_386 == nil { seq__1716000044__14 = ifn_387.Invoke_O__O(arg_388) } else { seq__1716000044__14 = linked_386.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_385, arg_388) }
//line :54:1
						var ___15_3 any = first__1716000045__13; var more__16_2 any = seq__1716000044__14; var more__17_2 any; var root_389 any = A_arbace_j2g_jrt_A_const_50.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_389, A_arbace_j2g_jrt_strip_doc_A_fn_class); var ifn_391 lang.IFn; _ = ___15_3









































						if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any = more__16_2; if linked_390 == nil { more__17_2 = ifn_391.Invoke_O__O(arg_392) } else { more__17_2 = linked_390.(*A_arbace_j2g_jrt_strip_doc_A).Invoke_O_O__O(root_389, arg_392) }
						var tmp52 any; var root_393 any = A_arbace_j2g_jrt_A_const_55.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_393, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_395 lang.IFn; if linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var arg_396 any; var root_397 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_399 lang.IFn; if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = more__17_2; if linked_398 == nil { arg_396 = ifn_399.Invoke_O__O(arg_400) } else { arg_396 = linked_398.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_397, arg_400) }; if linked_394 == nil { tmp52 = ifn_395.Invoke_O__O(arg_396) } else { tmp52 = linked_394.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_393, arg_396) }; if jrt.J2g_Truth(tmp52) { var seq_1716000046__18 any; var root_401 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_401, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_403 lang.IFn
							if linked_402 == nil { ifn_403 = lang.IFn_Cast(root_401) } else { ifn_403 = nil }; var arg_404 any = more__17_2; if linked_402 == nil { seq_1716000046__18 = ifn_403.Invoke_O__O(arg_404) } else { seq_1716000046__18 = linked_402.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_401, arg_404) }
//line :97:1
							var chunk_1716000047__19 any; var count_1716000048__20 int64 = 0; var i_1716000049__21 int64 = 0; L4: for {
								if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000049__21, count_1716000048__20) { var vec__1716000050__22 any = lang.Indexed_Cast(chunk_1716000047__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000049__21)); var tg__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000050__22, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp53 any; var root_515 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_517 lang.IFn; if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any = tg__23; if linked_516 == nil { tmp53 = ifn_517.Invoke_O__O(arg_518) } else { tmp53 = linked_516.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_515, arg_518) }; if jrt.J2g_Truth(tmp53) { var tmp54 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp55 any; var root_519 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_523 any = A_arbace_j2g_jrt_A_const_44; var arg_524 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_525 any; var root_526 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_526, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_528 lang.IFn; if linked_527 == nil { ifn_528 = lang.IFn_Cast(root_526) } else { ifn_528 = nil }; var arg_529 any = tg__23; if linked_527 == nil { arg_525 = ifn_528.Invoke_O__O(arg_529) } else { arg_525 = linked_527.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_526, arg_529) }; if linked_520 == nil { tmp55 = ifn_521.Invoke_O_O_O_O__O(arg_522, arg_523, arg_524, arg_525) } else { tmp55 = linked_520.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_519, arg_522, arg_523, arg_524, arg_525) }; jrt.NN(tmp54).Reset_O__O(tmp55) }; seq_1716000046__18, chunk_1716000047__19, count_1716000048__20, i_1716000049__21 = seq_1716000046__18, chunk_1716000047__19, count_1716000048__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000049__21); continue L4 } else { var temp__1927000414__auto____22_2 any; var root_405 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_405, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_407 lang.IFn; if linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; var arg_408 any = seq_1716000046__18; if linked_406 == nil { temp__1927000414__auto____22_2 = ifn_407.Invoke_O__O(arg_408) } else { temp__1927000414__auto____22_2 = linked_406.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_405, arg_408) }; if jrt.J2g_Truth(temp__1927000414__auto____22_2) { var seq_1716000046__23 any = temp__1927000414__auto____22_2; var tmp56 any; var root_409 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_409, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_411 lang.IFn; if linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any = seq_1716000046__23; if linked_410 == nil { tmp56 = ifn_411.Invoke_O__O(arg_412) } else { tmp56 = linked_410.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_409, arg_412) }; if jrt.J2g_Truth(tmp56) { var c__1927000678__auto____24_2 any; var root_413 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_413, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_415 lang.IFn; if linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any = seq_1716000046__23; if linked_414 == nil { c__1927000678__auto____24_2 = ifn_415.Invoke_O__O(arg_416) } else { c__1927000678__auto____24_2 = linked_414.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_413, arg_416) }; var tmp57 any; var root_530 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_530, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_532 lang.IFn; if linked_531 == nil { ifn_532 = lang.IFn_Cast(root_530) } else { ifn_532 = nil }; var arg_533 any = seq_1716000046__23; if linked_531 == nil { tmp57 = ifn_532.Invoke_O__O(arg_533) } else { tmp57 = linked_531.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_530, arg_533) }; seq_1716000046__18, chunk_1716000047__19, count_1716000048__20, i_1716000049__21 = tmp57, c__1927000678__auto____24_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var vec__1716000053__24 any; var root_417 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_419 lang.IFn; if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any = seq_1716000046__23; if linked_418 == nil { vec__1716000053__24 = ifn_419.Invoke_O__O(arg_420) } else { vec__1716000053__24 = linked_418.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_417, arg_420) }; var tg__25 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000053__24, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp58 any; var root_534 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_536 lang.IFn; if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = tg__25; if linked_535 == nil { tmp58 = ifn_536.Invoke_O__O(arg_537) } else { tmp58 = linked_535.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_534, arg_537) }; if jrt.J2g_Truth(tmp58) { var tmp59 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp60 any; var root_538 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_538, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_540 lang.IFn; if linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_542 any = A_arbace_j2g_jrt_A_const_44; var arg_543 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_544 any; var root_545 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_547 lang.IFn; if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any = tg__25; if linked_546 == nil { arg_544 = ifn_547.Invoke_O__O(arg_548) } else { arg_544 = linked_546.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_545, arg_548) }; if linked_539 == nil { tmp60 = ifn_540.Invoke_O_O_O_O__O(arg_541, arg_542, arg_543, arg_544) } else { tmp60 = linked_539.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_538, arg_541, arg_542, arg_543, arg_544) }; jrt.NN(tmp59).Reset_O__O(tmp60) }; var tmp61 any; var root_549 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_551 lang.IFn; if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = seq_1716000046__23; if linked_550 == nil { tmp61 = ifn_551.Invoke_O__O(arg_552) } else { tmp61 = linked_550.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_549, arg_552) }; seq_1716000046__18, chunk_1716000047__19, count_1716000048__20, i_1716000049__21 = tmp61, nil, 0, 0; continue L4 } } }
//line :97:1
								break L4 } } else {

									var tmp62 any; var root_421 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_423 lang.IFn; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any; var root_425 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = more__17_2; if linked_426 == nil { arg_424 = ifn_427.Invoke_O__O(arg_428) } else { arg_424 = linked_426.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_425, arg_428) }; if linked_422 == nil { tmp62 = ifn_423.Invoke_O__O(arg_424) } else { tmp62 = linked_422.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_421, arg_424) }; if jrt.J2g_Truth(tmp62) { var tmp63 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp64 any; var root_429 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_429, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_431 lang.IFn; if linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_433 any = A_arbace_j2g_jrt_A_const_44; var arg_434 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_435 any; var root_436 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_436, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_438 lang.IFn; if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any; var root_440 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_440, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_442 lang.IFn; if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = more__17_2; if linked_441 == nil { arg_439 = ifn_442.Invoke_O__O(arg_443) } else { arg_439 = linked_441.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_440, arg_443) }; if linked_437 == nil { arg_435 = ifn_438.Invoke_O__O(arg_439) } else { arg_435 = linked_437.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_436, arg_439) }; if linked_430 == nil { tmp64 = ifn_431.Invoke_O_O_O_O__O(arg_432, arg_433, arg_434, arg_435) } else { tmp64 = linked_430.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_429, arg_432, arg_433, arg_434, arg_435) }; jrt.NN(tmp63).Reset_O__O(tmp64) } }
//line :54:1
						break L2 }; case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000026__10_, Lit_34) { var vec__1716000056__11 any = fm__8; var ___12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000056__11, lang.RT_IntCast_J__I_NoInit(0), nil); var nm__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000056__11, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp65 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp66 any; var root_444 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_445 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_444, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_446 lang.IFn; _ = ___12
























							if linked_445 == nil { ifn_446 = lang.IFn_Cast(root_444) } else { ifn_446 = nil }; var arg_447 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_448 any = A_arbace_j2g_jrt_A_const_41; var arg_449 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_450 any; var root_451 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_453 lang.IFn; if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = nm__13; if linked_452 == nil { arg_450 = ifn_453.Invoke_O__O(arg_454) } else { arg_450 = linked_452.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_451, arg_454) }; if linked_445 == nil { tmp66 = ifn_446.Invoke_O_O_O_O__O(arg_447, arg_448, arg_449, arg_450) } else { tmp66 = linked_445.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_444, arg_447, arg_448, arg_449, arg_450) }; jrt.NN(tmp65).Reset_O__O(tmp66)
//line :54:1
							break L2 }; case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000026__10_, Lit_35) { var vec__1716000059__11 any = fm__8; var seq__1716000060__12 any; var root_553 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_555 lang.IFn

























								if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = vec__1716000059__11; if linked_554 == nil { seq__1716000060__12 = ifn_555.Invoke_O__O(arg_556) } else { seq__1716000060__12 = linked_554.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_553, arg_556) }
//line :54:1
								var first__1716000061__13 any; var root_557 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_559 lang.IFn

























								if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = seq__1716000060__12; if linked_558 == nil { first__1716000061__13 = ifn_559.Invoke_O__O(arg_560) } else { first__1716000061__13 = linked_558.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_557, arg_560) }
//line :54:1
								var seq__1716000060__14 any; var root_561 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_561, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_563 lang.IFn

























								if linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any = seq__1716000060__12; if linked_562 == nil { seq__1716000060__14 = ifn_563.Invoke_O__O(arg_564) } else { seq__1716000060__14 = linked_562.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_561, arg_564) }
//line :54:1
								var ___15_4 any = first__1716000061__13; var more__16_3 any = seq__1716000060__14; var more__17_3 any; var root_565 any = A_arbace_j2g_jrt_A_const_50.GetRawRoot__O(); var linked_566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_565, A_arbace_j2g_jrt_strip_doc_A_fn_class); var ifn_567 lang.IFn; _ = ___15_4


























								if linked_566 == nil { ifn_567 = lang.IFn_Cast(root_565) } else { ifn_567 = nil }; var arg_568 any = more__16_3; if linked_566 == nil { more__17_3 = ifn_567.Invoke_O__O(arg_568) } else { more__17_3 = linked_566.(*A_arbace_j2g_jrt_strip_doc_A).Invoke_O_O__O(root_565, arg_568) }
								var tmp67 any; var root_569 any = A_arbace_j2g_jrt_A_const_55.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_569, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_571 lang.IFn; if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any; var root_573 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_575 lang.IFn; if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any = more__17_3; if linked_574 == nil { arg_572 = ifn_575.Invoke_O__O(arg_576) } else { arg_572 = linked_574.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_573, arg_576) }; if linked_570 == nil { tmp67 = ifn_571.Invoke_O__O(arg_572) } else { tmp67 = linked_570.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_569, arg_572) }; if jrt.J2g_Truth(tmp67) { var seq_1716000062__18 any; var root_577 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_577, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_579 lang.IFn
									if linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var arg_580 any = more__17_3; if linked_578 == nil { seq_1716000062__18 = ifn_579.Invoke_O__O(arg_580) } else { seq_1716000062__18 = linked_578.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_577, arg_580) }
//line :82:1
									var chunk_1716000063__19 any; var count_1716000064__20 int64 = 0; var i_1716000065__21 int64 = 0; L5: for {
										if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000065__21, count_1716000064__20) { var vec__1716000066__22 any = lang.Indexed_Cast(chunk_1716000063__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000065__21)); var tg__23_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000066__22, lang.RT_IntCast_J__I_NoInit(0), nil); var init__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000066__22, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp68 any; var and__1927000168__auto____25_3 any; var root_659 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_659, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_661 lang.IFn
											if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any = tg__23_2; if linked_660 == nil { and__1927000168__auto____25_3 = ifn_661.Invoke_O__O(arg_662) } else { and__1927000168__auto____25_3 = linked_660.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_659, arg_662) }; if jrt.J2g_Truth(and__1927000168__auto____25_3) { var tmp69 any = A_arbace_j2g_jrt_A_const_71; var tmp70 any; var root_663 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any = tg__23_2; if linked_664 == nil { tmp70 = ifn_665.Invoke_O__O(arg_666) } else { tmp70 = linked_664.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_663, arg_666) }; tmp68 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp69, tmp70)).Ref() } else { tmp68 = and__1927000168__auto____25_3 }; if jrt.J2g_Truth(tmp68) { var seq_1716000069__25 any; var root_667 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_669 lang.IFn
												if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any; var root_671 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_671, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_673 lang.IFn; if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any = tg__23_2; if linked_672 == nil { arg_670 = ifn_673.Invoke_O__O(arg_674) } else { arg_670 = linked_672.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_671, arg_674) }; if linked_668 == nil { seq_1716000069__25 = ifn_669.Invoke_O__O(arg_670) } else { seq_1716000069__25 = linked_668.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_667, arg_670) }
//line :84:1
												var chunk_1716000070__26 any; var count_1716000071__27 int64 = 0; var i_1716000072__28 int64 = 0; L6: for {
													if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000072__28, count_1716000071__27) { var s__29 any = lang.Indexed_Cast(chunk_1716000070__26).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000072__28)); var tmp71 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp72 any; var root_721 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_721, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_723 lang.IFn; if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_725 any = A_arbace_j2g_jrt_A_const_42; var arg_726 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_727 any; var root_728 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_728, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_730 lang.IFn; if linked_729 == nil { ifn_730 = lang.IFn_Cast(root_728) } else { ifn_730 = nil }; var arg_731 any = s__29; if linked_729 == nil { arg_727 = ifn_730.Invoke_O__O(arg_731) } else { arg_727 = linked_729.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_728, arg_731) }; if linked_722 == nil { tmp72 = ifn_723.Invoke_O_O_O_O__O(arg_724, arg_725, arg_726, arg_727) } else { tmp72 = linked_722.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_721, arg_724, arg_725, arg_726, arg_727) }; jrt.NN(tmp71).Reset_O__O(tmp72); seq_1716000069__25, chunk_1716000070__26, count_1716000071__27, i_1716000072__28 = seq_1716000069__25, chunk_1716000070__26, count_1716000071__27, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000072__28); continue L6 } else { var temp__1927000414__auto____29 any; var root_675 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_677 lang.IFn; if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any = seq_1716000069__25; if linked_676 == nil { temp__1927000414__auto____29 = ifn_677.Invoke_O__O(arg_678) } else { temp__1927000414__auto____29 = linked_676.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_675, arg_678) }; if jrt.J2g_Truth(temp__1927000414__auto____29) { var seq_1716000069__30 any = temp__1927000414__auto____29; var tmp73 any; var root_679 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = seq_1716000069__30; if linked_680 == nil { tmp73 = ifn_681.Invoke_O__O(arg_682) } else { tmp73 = linked_680.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_679, arg_682) }; if jrt.J2g_Truth(tmp73) { var c__1927000678__auto____31 any; var root_683 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_685 lang.IFn; if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any = seq_1716000069__30; if linked_684 == nil { c__1927000678__auto____31 = ifn_685.Invoke_O__O(arg_686) } else { c__1927000678__auto____31 = linked_684.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_683, arg_686) }; var tmp74 any; var root_732 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_732, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_734 lang.IFn; if linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = seq_1716000069__30; if linked_733 == nil { tmp74 = ifn_734.Invoke_O__O(arg_735) } else { tmp74 = linked_733.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_732, arg_735) }; seq_1716000069__25, chunk_1716000070__26, count_1716000071__27, i_1716000072__28 = tmp74, c__1927000678__auto____31, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____31))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L6 } else { var s__31 any; var root_687 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_687, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_689 lang.IFn; if linked_688 == nil { ifn_689 = lang.IFn_Cast(root_687) } else { ifn_689 = nil }; var arg_690 any = seq_1716000069__30; if linked_688 == nil { s__31 = ifn_689.Invoke_O__O(arg_690) } else { s__31 = linked_688.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_687, arg_690) }; var tmp75 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp76 any; var root_736 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_737 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_736, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_738 lang.IFn; if linked_737 == nil { ifn_738 = lang.IFn_Cast(root_736) } else { ifn_738 = nil }; var arg_739 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_740 any = A_arbace_j2g_jrt_A_const_42; var arg_741 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_742 any; var root_743 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_743, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_745 lang.IFn; if linked_744 == nil { ifn_745 = lang.IFn_Cast(root_743) } else { ifn_745 = nil }; var arg_746 any = s__31; if linked_744 == nil { arg_742 = ifn_745.Invoke_O__O(arg_746) } else { arg_742 = linked_744.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_743, arg_746) }; if linked_737 == nil { tmp76 = ifn_738.Invoke_O_O_O_O__O(arg_739, arg_740, arg_741, arg_742) } else { tmp76 = linked_737.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_736, arg_739, arg_740, arg_741, arg_742) }; jrt.NN(tmp75).Reset_O__O(tmp76); var tmp77 any; var root_747 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_747, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_749 lang.IFn; if linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; var arg_750 any = seq_1716000069__30; if linked_748 == nil { tmp77 = ifn_749.Invoke_O__O(arg_750) } else { tmp77 = linked_748.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_747, arg_750) }; seq_1716000069__25, chunk_1716000070__26, count_1716000071__27, i_1716000072__28 = tmp77, nil, 0, 0; continue L6 } } }
//line :84:1
													break L6 } } else {

														var tmp78 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp79 any; var root_751 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_751, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_753 lang.IFn; if linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_755 any = A_arbace_j2g_jrt_A_const_42; var arg_756 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_757 any; var root_758 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_758, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_760 lang.IFn; if linked_759 == nil { ifn_760 = lang.IFn_Cast(root_758) } else { ifn_760 = nil }; var arg_761 any = tg__23_2; if linked_759 == nil { arg_757 = ifn_760.Invoke_O__O(arg_761) } else { arg_757 = linked_759.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_758, arg_761) }; if linked_752 == nil { tmp79 = ifn_753.Invoke_O_O_O_O__O(arg_754, arg_755, arg_756, arg_757) } else { tmp79 = linked_752.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_751, arg_754, arg_755, arg_756, arg_757) }; jrt.NN(tmp78).Reset_O__O(tmp79)
//line :84:1
														var temp__1927000414__auto____25 any; var root_691 any = A_arbace_j2g_jrt_A_const_69.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, A_arbace_j2g_jrt_define_name_A_fn_class); var ifn_693 lang.IFn


														if linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any = init__24; if linked_692 == nil { temp__1927000414__auto____25 = ifn_693.Invoke_O__O(arg_694) } else { temp__1927000414__auto____25 = linked_692.(*A_arbace_j2g_jrt_define_name_A).Invoke_O_O__O(root_691, arg_694) }; if jrt.J2g_Truth(temp__1927000414__auto____25) { var map__1716000073__26 any = temp__1927000414__auto____25; var map__1716000073__27 any; if lang.ISeq_InstanceOf(map__1716000073__26) { var tmp80 any; var root_695 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_695, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_697 lang.IFn; if linked_696 == nil { ifn_697 = lang.IFn_Cast(root_695) } else { ifn_697 = nil }; var arg_698 any = map__1716000073__26; if linked_696 == nil { tmp80 = ifn_697.Invoke_O__O(arg_698) } else { tmp80 = linked_696.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_695, arg_698) }; if jrt.J2g_Truth(tmp80) { var tmp81 any; var root_699 any = A_arbace_j2g_jrt_A_const_70.GetRawRoot__O(); var linked_700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_699, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_701 lang.IFn; if linked_700 == nil { ifn_701 = lang.IFn_Cast(root_699) } else { ifn_701 = nil }; var arg_702 any = map__1716000073__26; if linked_700 == nil { tmp81 = ifn_701.Invoke_O__O(arg_702) } else { tmp81 = linked_700.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_699, arg_702) }; map__1716000073__27 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp81)).Ref() } else { var tmp82 any; var root_703 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_703, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_705 lang.IFn; if linked_704 == nil { ifn_705 = lang.IFn_Cast(root_703) } else { ifn_705 = nil }; var arg_706 any = map__1716000073__26; if linked_704 == nil { tmp82 = ifn_705.Invoke_O__O(arg_706) } else { tmp82 = linked_704.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_703, arg_706) }; if jrt.J2g_Truth(tmp82) { var root_707 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_709 lang.IFn; if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any = map__1716000073__26; if linked_708 == nil { map__1716000073__27 = ifn_709.Invoke_O__O(arg_710) } else { map__1716000073__27 = linked_708.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_707, arg_710) } } else { map__1716000073__27 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000073__27 = map__1716000073__26 }; var n__28 any = lang.RT_Get_O_O__O_NoInit(map__1716000073__27, A_arbace_j2g_jrt_A_const_34); var tmp83 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp84 any; var root_711 any = A_arbace_j2g_jrt_A_const_56.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_713 lang.IFn
															if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_715 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_jrt_A_const_43, n__28); var arg_716 any; var root_717 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_717, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_719 lang.IFn; if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any = tg__23_2; if linked_718 == nil { arg_716 = ifn_719.Invoke_O__O(arg_720) } else { arg_716 = linked_718.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_717, arg_720) }; if linked_712 == nil { tmp84 = ifn_713.Invoke_O_O_O__O(arg_714, arg_715, arg_716) } else { tmp84 = linked_712.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_711, arg_714, arg_715, arg_716) }; jrt.NN(tmp83).Reset_O__O(tmp84) } }
//line :83:1
											seq_1716000062__18, chunk_1716000063__19, count_1716000064__20, i_1716000065__21 = seq_1716000062__18, chunk_1716000063__19, count_1716000064__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000065__21); continue L5 } else { var temp__1927000414__auto____22_3 any; var root_581 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_583 lang.IFn; if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = seq_1716000062__18; if linked_582 == nil { temp__1927000414__auto____22_3 = ifn_583.Invoke_O__O(arg_584) } else { temp__1927000414__auto____22_3 = linked_582.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_581, arg_584) }; if jrt.J2g_Truth(temp__1927000414__auto____22_3) { var seq_1716000062__23 any = temp__1927000414__auto____22_3; var tmp85 any; var root_585 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_585, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_587 lang.IFn; if linked_586 == nil { ifn_587 = lang.IFn_Cast(root_585) } else { ifn_587 = nil }; var arg_588 any = seq_1716000062__23; if linked_586 == nil { tmp85 = ifn_587.Invoke_O__O(arg_588) } else { tmp85 = linked_586.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_585, arg_588) }; if jrt.J2g_Truth(tmp85) { var c__1927000678__auto____24_3 any; var root_589 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_589, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_591 lang.IFn; if linked_590 == nil { ifn_591 = lang.IFn_Cast(root_589) } else { ifn_591 = nil }; var arg_592 any = seq_1716000062__23; if linked_590 == nil { c__1927000678__auto____24_3 = ifn_591.Invoke_O__O(arg_592) } else { c__1927000678__auto____24_3 = linked_590.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_589, arg_592) }; var tmp86 any; var root_762 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_762, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_764 lang.IFn; if linked_763 == nil { ifn_764 = lang.IFn_Cast(root_762) } else { ifn_764 = nil }; var arg_765 any = seq_1716000062__23; if linked_763 == nil { tmp86 = ifn_764.Invoke_O__O(arg_765) } else { tmp86 = linked_763.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_762, arg_765) }; seq_1716000062__18, chunk_1716000063__19, count_1716000064__20, i_1716000065__21 = tmp86, c__1927000678__auto____24_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var vec__1716000075__24 any; var root_593 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = seq_1716000062__23; if linked_594 == nil { vec__1716000075__24 = ifn_595.Invoke_O__O(arg_596) } else { vec__1716000075__24 = linked_594.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_593, arg_596) }; var tg__25_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000075__24, lang.RT_IntCast_J__I_NoInit(0), nil); var init__26 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000075__24, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp87 any; var and__1927000168__auto____27_3 any; var root_766 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_766, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_768 lang.IFn
												if linked_767 == nil { ifn_768 = lang.IFn_Cast(root_766) } else { ifn_768 = nil }; var arg_769 any = tg__25_2; if linked_767 == nil { and__1927000168__auto____27_3 = ifn_768.Invoke_O__O(arg_769) } else { and__1927000168__auto____27_3 = linked_767.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_766, arg_769) }; if jrt.J2g_Truth(and__1927000168__auto____27_3) { var tmp88 any = A_arbace_j2g_jrt_A_const_71; var tmp89 any; var root_770 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_772 lang.IFn; if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any = tg__25_2; if linked_771 == nil { tmp89 = ifn_772.Invoke_O__O(arg_773) } else { tmp89 = linked_771.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_770, arg_773) }; tmp87 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp88, tmp89)).Ref() } else { tmp87 = and__1927000168__auto____27_3 }; if jrt.J2g_Truth(tmp87) { var seq_1716000078__27 any; var root_774 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_776 lang.IFn
													if linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any; var root_778 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_778, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_780 lang.IFn; if linked_779 == nil { ifn_780 = lang.IFn_Cast(root_778) } else { ifn_780 = nil }; var arg_781 any = tg__25_2; if linked_779 == nil { arg_777 = ifn_780.Invoke_O__O(arg_781) } else { arg_777 = linked_779.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_778, arg_781) }; if linked_775 == nil { seq_1716000078__27 = ifn_776.Invoke_O__O(arg_777) } else { seq_1716000078__27 = linked_775.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_774, arg_777) }
//line :84:1
													var chunk_1716000079__28 any; var count_1716000080__29 int64 = 0; var i_1716000081__30 int64 = 0; L7: for {
														if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000081__30, count_1716000080__29) { var s__31_2 any = lang.Indexed_Cast(chunk_1716000079__28).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000081__30)); var tmp90 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp91 any; var root_828 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_829 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_828, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_830 lang.IFn; if linked_829 == nil { ifn_830 = lang.IFn_Cast(root_828) } else { ifn_830 = nil }; var arg_831 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_832 any = A_arbace_j2g_jrt_A_const_42; var arg_833 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_834 any; var root_835 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_835, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_837 lang.IFn; if linked_836 == nil { ifn_837 = lang.IFn_Cast(root_835) } else { ifn_837 = nil }; var arg_838 any = s__31_2; if linked_836 == nil { arg_834 = ifn_837.Invoke_O__O(arg_838) } else { arg_834 = linked_836.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_835, arg_838) }; if linked_829 == nil { tmp91 = ifn_830.Invoke_O_O_O_O__O(arg_831, arg_832, arg_833, arg_834) } else { tmp91 = linked_829.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_828, arg_831, arg_832, arg_833, arg_834) }; jrt.NN(tmp90).Reset_O__O(tmp91); seq_1716000078__27, chunk_1716000079__28, count_1716000080__29, i_1716000081__30 = seq_1716000078__27, chunk_1716000079__28, count_1716000080__29, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000081__30); continue L7 } else { var temp__1927000414__auto____31 any; var root_782 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_782, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_784 lang.IFn; if linked_783 == nil { ifn_784 = lang.IFn_Cast(root_782) } else { ifn_784 = nil }; var arg_785 any = seq_1716000078__27; if linked_783 == nil { temp__1927000414__auto____31 = ifn_784.Invoke_O__O(arg_785) } else { temp__1927000414__auto____31 = linked_783.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_782, arg_785) }; if jrt.J2g_Truth(temp__1927000414__auto____31) { var seq_1716000078__32 any = temp__1927000414__auto____31; var tmp92 any; var root_786 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_786, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_788 lang.IFn; if linked_787 == nil { ifn_788 = lang.IFn_Cast(root_786) } else { ifn_788 = nil }; var arg_789 any = seq_1716000078__32; if linked_787 == nil { tmp92 = ifn_788.Invoke_O__O(arg_789) } else { tmp92 = linked_787.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_786, arg_789) }; if jrt.J2g_Truth(tmp92) { var c__1927000678__auto____33 any; var root_790 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_790, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_792 lang.IFn; if linked_791 == nil { ifn_792 = lang.IFn_Cast(root_790) } else { ifn_792 = nil }; var arg_793 any = seq_1716000078__32; if linked_791 == nil { c__1927000678__auto____33 = ifn_792.Invoke_O__O(arg_793) } else { c__1927000678__auto____33 = linked_791.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_790, arg_793) }; var tmp93 any; var root_839 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_840 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_839, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_841 lang.IFn; if linked_840 == nil { ifn_841 = lang.IFn_Cast(root_839) } else { ifn_841 = nil }; var arg_842 any = seq_1716000078__32; if linked_840 == nil { tmp93 = ifn_841.Invoke_O__O(arg_842) } else { tmp93 = linked_840.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_839, arg_842) }; seq_1716000078__27, chunk_1716000079__28, count_1716000080__29, i_1716000081__30 = tmp93, c__1927000678__auto____33, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____33))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L7 } else { var s__33 any; var root_794 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_794, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_796 lang.IFn; if linked_795 == nil { ifn_796 = lang.IFn_Cast(root_794) } else { ifn_796 = nil }; var arg_797 any = seq_1716000078__32; if linked_795 == nil { s__33 = ifn_796.Invoke_O__O(arg_797) } else { s__33 = linked_795.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_794, arg_797) }; var tmp94 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp95 any; var root_843 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_844 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_843, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_845 lang.IFn; if linked_844 == nil { ifn_845 = lang.IFn_Cast(root_843) } else { ifn_845 = nil }; var arg_846 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_847 any = A_arbace_j2g_jrt_A_const_42; var arg_848 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_849 any; var root_850 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_850, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_852 lang.IFn; if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any = s__33; if linked_851 == nil { arg_849 = ifn_852.Invoke_O__O(arg_853) } else { arg_849 = linked_851.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_850, arg_853) }; if linked_844 == nil { tmp95 = ifn_845.Invoke_O_O_O_O__O(arg_846, arg_847, arg_848, arg_849) } else { tmp95 = linked_844.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_843, arg_846, arg_847, arg_848, arg_849) }; jrt.NN(tmp94).Reset_O__O(tmp95); var tmp96 any; var root_854 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_854, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_856 lang.IFn; if linked_855 == nil { ifn_856 = lang.IFn_Cast(root_854) } else { ifn_856 = nil }; var arg_857 any = seq_1716000078__32; if linked_855 == nil { tmp96 = ifn_856.Invoke_O__O(arg_857) } else { tmp96 = linked_855.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_854, arg_857) }; seq_1716000078__27, chunk_1716000079__28, count_1716000080__29, i_1716000081__30 = tmp96, nil, 0, 0; continue L7 } } }
//line :84:1
														break L7 } } else {

															var tmp97 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp98 any; var root_858 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_859 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_858, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_860 lang.IFn; if linked_859 == nil { ifn_860 = lang.IFn_Cast(root_858) } else { ifn_860 = nil }; var arg_861 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_862 any = A_arbace_j2g_jrt_A_const_42; var arg_863 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_864 any; var root_865 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = tg__25_2; if linked_866 == nil { arg_864 = ifn_867.Invoke_O__O(arg_868) } else { arg_864 = linked_866.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_865, arg_868) }; if linked_859 == nil { tmp98 = ifn_860.Invoke_O_O_O_O__O(arg_861, arg_862, arg_863, arg_864) } else { tmp98 = linked_859.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_858, arg_861, arg_862, arg_863, arg_864) }; jrt.NN(tmp97).Reset_O__O(tmp98)
//line :84:1
															var temp__1927000414__auto____27 any; var root_798 any = A_arbace_j2g_jrt_A_const_69.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, A_arbace_j2g_jrt_define_name_A_fn_class); var ifn_800 lang.IFn


															if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any = init__26; if linked_799 == nil { temp__1927000414__auto____27 = ifn_800.Invoke_O__O(arg_801) } else { temp__1927000414__auto____27 = linked_799.(*A_arbace_j2g_jrt_define_name_A).Invoke_O_O__O(root_798, arg_801) }; if jrt.J2g_Truth(temp__1927000414__auto____27) { var map__1716000082__28 any = temp__1927000414__auto____27; var map__1716000082__29 any; if lang.ISeq_InstanceOf(map__1716000082__28) { var tmp99 any; var root_802 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_802, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_804 lang.IFn; if linked_803 == nil { ifn_804 = lang.IFn_Cast(root_802) } else { ifn_804 = nil }; var arg_805 any = map__1716000082__28; if linked_803 == nil { tmp99 = ifn_804.Invoke_O__O(arg_805) } else { tmp99 = linked_803.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_802, arg_805) }; if jrt.J2g_Truth(tmp99) { var tmp100 any; var root_806 any = A_arbace_j2g_jrt_A_const_70.GetRawRoot__O(); var linked_807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_806, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_808 lang.IFn; if linked_807 == nil { ifn_808 = lang.IFn_Cast(root_806) } else { ifn_808 = nil }; var arg_809 any = map__1716000082__28; if linked_807 == nil { tmp100 = ifn_808.Invoke_O__O(arg_809) } else { tmp100 = linked_807.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_806, arg_809) }; map__1716000082__29 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp100)).Ref() } else { var tmp101 any; var root_810 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_810, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_812 lang.IFn; if linked_811 == nil { ifn_812 = lang.IFn_Cast(root_810) } else { ifn_812 = nil }; var arg_813 any = map__1716000082__28; if linked_811 == nil { tmp101 = ifn_812.Invoke_O__O(arg_813) } else { tmp101 = linked_811.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_810, arg_813) }; if jrt.J2g_Truth(tmp101) { var root_814 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_814, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_816 lang.IFn; if linked_815 == nil { ifn_816 = lang.IFn_Cast(root_814) } else { ifn_816 = nil }; var arg_817 any = map__1716000082__28; if linked_815 == nil { map__1716000082__29 = ifn_816.Invoke_O__O(arg_817) } else { map__1716000082__29 = linked_815.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_814, arg_817) } } else { map__1716000082__29 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000082__29 = map__1716000082__28 }; var n__30 any = lang.RT_Get_O_O__O_NoInit(map__1716000082__29, A_arbace_j2g_jrt_A_const_34); var tmp102 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp103 any; var root_818 any = A_arbace_j2g_jrt_A_const_56.GetRawRoot__O(); var linked_819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_818, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_820 lang.IFn
																if linked_819 == nil { ifn_820 = lang.IFn_Cast(root_818) } else { ifn_820 = nil }; var arg_821 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_822 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_jrt_A_const_43, n__30); var arg_823 any; var root_824 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_824, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_826 lang.IFn; if linked_825 == nil { ifn_826 = lang.IFn_Cast(root_824) } else { ifn_826 = nil }; var arg_827 any = tg__25_2; if linked_825 == nil { arg_823 = ifn_826.Invoke_O__O(arg_827) } else { arg_823 = linked_825.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_824, arg_827) }; if linked_819 == nil { tmp103 = ifn_820.Invoke_O_O_O__O(arg_821, arg_822, arg_823) } else { tmp103 = linked_819.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_818, arg_821, arg_822, arg_823) }; jrt.NN(tmp102).Reset_O__O(tmp103) } }
//line :83:1
												var tmp104 any; var root_869 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = seq_1716000062__23; if linked_870 == nil { tmp104 = ifn_871.Invoke_O__O(arg_872) } else { tmp104 = linked_870.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_869, arg_872) }; seq_1716000062__18, chunk_1716000063__19, count_1716000064__20, i_1716000065__21 = tmp104, nil, 0, 0; continue L5 } } }
//line :82:1
										break L5 } } else { var vec__1716000084__18 any = more__17_3; var tg__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000084__18, lang.RT_IntCast_J__I_NoInit(0), nil); var init__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000084__18, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp105 any; var and__1927000168__auto____21 any; var root_597 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_599 lang.IFn







											if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any = tg__19; if linked_598 == nil { and__1927000168__auto____21 = ifn_599.Invoke_O__O(arg_600) } else { and__1927000168__auto____21 = linked_598.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_597, arg_600) }; if jrt.J2g_Truth(and__1927000168__auto____21) { var tmp106 any = A_arbace_j2g_jrt_A_const_68; var tmp107 any; var root_601 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_601, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_603 lang.IFn; if linked_602 == nil { ifn_603 = lang.IFn_Cast(root_601) } else { ifn_603 = nil }; var arg_604 any = tg__19; if linked_602 == nil { tmp107 = ifn_603.Invoke_O__O(arg_604) } else { tmp107 = linked_602.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_601, arg_604) }; tmp105 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp106, tmp107)).Ref() } else { tmp105 = and__1927000168__auto____21 }; if jrt.J2g_Truth(tmp105) { var seq_1716000087__21 any; var root_605 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_605, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_607 lang.IFn
												if linked_606 == nil { ifn_607 = lang.IFn_Cast(root_605) } else { ifn_607 = nil }; var arg_608 any; var root_609 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_609, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_611 lang.IFn; if linked_610 == nil { ifn_611 = lang.IFn_Cast(root_609) } else { ifn_611 = nil }; var arg_612 any = tg__19; if linked_610 == nil { arg_608 = ifn_611.Invoke_O__O(arg_612) } else { arg_608 = linked_610.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_609, arg_612) }; if linked_606 == nil { seq_1716000087__21 = ifn_607.Invoke_O__O(arg_608) } else { seq_1716000087__21 = linked_606.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_605, arg_608) }
//line :90:1
												var chunk_1716000088__22 any; var count_1716000089__23 int64 = 0; var i_1716000090__24 int64 = 0; L8: for {
													if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000090__24, count_1716000089__23) { var s__25 any = lang.Indexed_Cast(chunk_1716000088__22).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000090__24)); var tmp108 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp109 any; var root_873 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_873, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_877 any = A_arbace_j2g_jrt_A_const_42; var arg_878 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_879 any; var root_880 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_880, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_882 lang.IFn; if linked_881 == nil { ifn_882 = lang.IFn_Cast(root_880) } else { ifn_882 = nil }; var arg_883 any = s__25; if linked_881 == nil { arg_879 = ifn_882.Invoke_O__O(arg_883) } else { arg_879 = linked_881.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_880, arg_883) }; if linked_874 == nil { tmp109 = ifn_875.Invoke_O_O_O_O__O(arg_876, arg_877, arg_878, arg_879) } else { tmp109 = linked_874.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_873, arg_876, arg_877, arg_878, arg_879) }; jrt.NN(tmp108).Reset_O__O(tmp109); seq_1716000087__21, chunk_1716000088__22, count_1716000089__23, i_1716000090__24 = seq_1716000087__21, chunk_1716000088__22, count_1716000089__23, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000090__24); continue L8 } else { var temp__1927000414__auto____25_2 any; var root_613 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_613, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_615 lang.IFn; if linked_614 == nil { ifn_615 = lang.IFn_Cast(root_613) } else { ifn_615 = nil }; var arg_616 any = seq_1716000087__21; if linked_614 == nil { temp__1927000414__auto____25_2 = ifn_615.Invoke_O__O(arg_616) } else { temp__1927000414__auto____25_2 = linked_614.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_613, arg_616) }; if jrt.J2g_Truth(temp__1927000414__auto____25_2) { var seq_1716000087__26 any = temp__1927000414__auto____25_2; var tmp110 any; var root_617 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_617, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_619 lang.IFn; if linked_618 == nil { ifn_619 = lang.IFn_Cast(root_617) } else { ifn_619 = nil }; var arg_620 any = seq_1716000087__26; if linked_618 == nil { tmp110 = ifn_619.Invoke_O__O(arg_620) } else { tmp110 = linked_618.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_617, arg_620) }; if jrt.J2g_Truth(tmp110) { var c__1927000678__auto____27 any; var root_621 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any = seq_1716000087__26; if linked_622 == nil { c__1927000678__auto____27 = ifn_623.Invoke_O__O(arg_624) } else { c__1927000678__auto____27 = linked_622.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_621, arg_624) }; var tmp111 any; var root_884 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_884, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_886 lang.IFn; if linked_885 == nil { ifn_886 = lang.IFn_Cast(root_884) } else { ifn_886 = nil }; var arg_887 any = seq_1716000087__26; if linked_885 == nil { tmp111 = ifn_886.Invoke_O__O(arg_887) } else { tmp111 = linked_885.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_884, arg_887) }; seq_1716000087__21, chunk_1716000088__22, count_1716000089__23, i_1716000090__24 = tmp111, c__1927000678__auto____27, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____27))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L8 } else { var s__27 any; var root_625 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = seq_1716000087__26; if linked_626 == nil { s__27 = ifn_627.Invoke_O__O(arg_628) } else { s__27 = linked_626.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_625, arg_628) }; var tmp112 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp113 any; var root_888 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_889 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_888, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_890 lang.IFn; if linked_889 == nil { ifn_890 = lang.IFn_Cast(root_888) } else { ifn_890 = nil }; var arg_891 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_892 any = A_arbace_j2g_jrt_A_const_42; var arg_893 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_894 any; var root_895 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_895, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_897 lang.IFn; if linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any = s__27; if linked_896 == nil { arg_894 = ifn_897.Invoke_O__O(arg_898) } else { arg_894 = linked_896.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_895, arg_898) }; if linked_889 == nil { tmp113 = ifn_890.Invoke_O_O_O_O__O(arg_891, arg_892, arg_893, arg_894) } else { tmp113 = linked_889.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_888, arg_891, arg_892, arg_893, arg_894) }; jrt.NN(tmp112).Reset_O__O(tmp113); var tmp114 any; var root_899 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_899, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_901 lang.IFn; if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var arg_902 any = seq_1716000087__26; if linked_900 == nil { tmp114 = ifn_901.Invoke_O__O(arg_902) } else { tmp114 = linked_900.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_899, arg_902) }; seq_1716000087__21, chunk_1716000088__22, count_1716000089__23, i_1716000090__24 = tmp114, nil, 0, 0; continue L8 } } }
//line :90:1
													break L8 } } else {

														var tmp115 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp116 any; var root_903 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_904 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_903, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_905 lang.IFn; if linked_904 == nil { ifn_905 = lang.IFn_Cast(root_903) } else { ifn_905 = nil }; var arg_906 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_907 any = A_arbace_j2g_jrt_A_const_42; var arg_908 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_909 any; var root_910 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_910, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_912 lang.IFn; if linked_911 == nil { ifn_912 = lang.IFn_Cast(root_910) } else { ifn_912 = nil }; var arg_913 any = tg__19; if linked_911 == nil { arg_909 = ifn_912.Invoke_O__O(arg_913) } else { arg_909 = linked_911.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_910, arg_913) }; if linked_904 == nil { tmp116 = ifn_905.Invoke_O_O_O_O__O(arg_906, arg_907, arg_908, arg_909) } else { tmp116 = linked_904.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_903, arg_906, arg_907, arg_908, arg_909) }; jrt.NN(tmp115).Reset_O__O(tmp116)
//line :90:1
														var temp__1927000414__auto____21 any; var root_629 any = A_arbace_j2g_jrt_A_const_69.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, A_arbace_j2g_jrt_define_name_A_fn_class); var ifn_631 lang.IFn


														if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any = init__20; if linked_630 == nil { temp__1927000414__auto____21 = ifn_631.Invoke_O__O(arg_632) } else { temp__1927000414__auto____21 = linked_630.(*A_arbace_j2g_jrt_define_name_A).Invoke_O_O__O(root_629, arg_632) }; if jrt.J2g_Truth(temp__1927000414__auto____21) { var map__1716000091__22 any = temp__1927000414__auto____21; var map__1716000091__23 any; if lang.ISeq_InstanceOf(map__1716000091__22) { var tmp117 any; var root_633 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_635 lang.IFn; if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any = map__1716000091__22; if linked_634 == nil { tmp117 = ifn_635.Invoke_O__O(arg_636) } else { tmp117 = linked_634.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_633, arg_636) }; if jrt.J2g_Truth(tmp117) { var tmp118 any; var root_637 any = A_arbace_j2g_jrt_A_const_70.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_639 lang.IFn; if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any = map__1716000091__22; if linked_638 == nil { tmp118 = ifn_639.Invoke_O__O(arg_640) } else { tmp118 = linked_638.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_637, arg_640) }; map__1716000091__23 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp118)).Ref() } else { var tmp119 any; var root_641 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_641, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_643 lang.IFn; if linked_642 == nil { ifn_643 = lang.IFn_Cast(root_641) } else { ifn_643 = nil }; var arg_644 any = map__1716000091__22; if linked_642 == nil { tmp119 = ifn_643.Invoke_O__O(arg_644) } else { tmp119 = linked_642.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_641, arg_644) }; if jrt.J2g_Truth(tmp119) { var root_645 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_645, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_647 lang.IFn; if linked_646 == nil { ifn_647 = lang.IFn_Cast(root_645) } else { ifn_647 = nil }; var arg_648 any = map__1716000091__22; if linked_646 == nil { map__1716000091__23 = ifn_647.Invoke_O__O(arg_648) } else { map__1716000091__23 = linked_646.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_645, arg_648) } } else { map__1716000091__23 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000091__23 = map__1716000091__22 }; var n__24 any = lang.RT_Get_O_O__O_NoInit(map__1716000091__23, A_arbace_j2g_jrt_A_const_34); var tmp120 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp121 any; var root_649 any = A_arbace_j2g_jrt_A_const_56.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_649, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_651 lang.IFn
															if linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_653 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_jrt_A_const_43, n__24); var arg_654 any; var root_655 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_655, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_657 lang.IFn; if linked_656 == nil { ifn_657 = lang.IFn_Cast(root_655) } else { ifn_657 = nil }; var arg_658 any = tg__19; if linked_656 == nil { arg_654 = ifn_657.Invoke_O__O(arg_658) } else { arg_654 = linked_656.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_655, arg_658) }; if linked_650 == nil { tmp121 = ifn_651.Invoke_O_O_O__O(arg_652, arg_653, arg_654) } else { tmp121 = linked_650.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_649, arg_652, arg_653, arg_654) }; jrt.NN(tmp120).Reset_O__O(tmp121) } } }
//line :54:1
								break L2 }; default:}}
//line :51:1
				seq_1716000022__4, chunk_1716000023__5, count_1716000024__6, i_1716000025__7 = seq_1716000022__4, chunk_1716000023__5, count_1716000024__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000025__7); continue L1 } else { seq_1716000022__4, chunk_1716000023__5, count_1716000024__6, i_1716000025__7 = seq_1716000022__4, chunk_1716000023__5, count_1716000024__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000025__7); continue L1 } } else { var temp__1927000414__auto____8 any; var root_200 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = seq_1716000022__4; if linked_201 == nil { temp__1927000414__auto____8 = ifn_202.Invoke_O__O(arg_203) } else { temp__1927000414__auto____8 = linked_201.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_200, arg_203) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1716000022__9 any = temp__1927000414__auto____8; var tmp122 any; var root_204 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = seq_1716000022__9; if linked_205 == nil { tmp122 = ifn_206.Invoke_O__O(arg_207) } else { tmp122 = linked_205.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_204, arg_207) }; if jrt.J2g_Truth(tmp122) { var c__1927000678__auto____10 any; var root_208 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = seq_1716000022__9; if linked_209 == nil { c__1927000678__auto____10 = ifn_210.Invoke_O__O(arg_211) } else { c__1927000678__auto____10 = linked_209.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_208, arg_211) }; var tmp123 any; var root_914 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_914, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_916 lang.IFn; if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any = seq_1716000022__9; if linked_915 == nil { tmp123 = ifn_916.Invoke_O__O(arg_917) } else { tmp123 = linked_915.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_914, arg_917) }; seq_1716000022__4, chunk_1716000023__5, count_1716000024__6, i_1716000025__7 = tmp123, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var fm__10 any; var root_212 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = seq_1716000022__9; if linked_213 == nil { fm__10 = ifn_214.Invoke_O__O(arg_215) } else { fm__10 = linked_213.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_212, arg_215) }; var h__11 any; var root_216 any = A_arbace_j2g_jrt_A_const_46.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, A_arbace_j2g_jrt_go_head_A_fn_class); var ifn_218 lang.IFn
					if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = fm__10; if linked_217 == nil { h__11 = ifn_218.Invoke_O__O(arg_219) } else { h__11 = linked_217.(*A_arbace_j2g_jrt_go_head_A).Invoke_O_O__O(root_216, arg_219) }
//line :51:1
					if jrt.J2g_Truth(h__11) { var G__1716000093__12_ any = h__11


					L9: switch { default: switch lang.Util_Hash_O__I_NoInit(G__1716000093__12_) >> 0 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000093__12_, Lit_31) { var vec__1716000094__13 any = fm__10; var seq__1716000095__14 any; var root_919 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_919, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_921 lang.IFn


















						if linked_920 == nil { ifn_921 = lang.IFn_Cast(root_919) } else { ifn_921 = nil }; var arg_922 any = vec__1716000094__13; if linked_920 == nil { seq__1716000095__14 = ifn_921.Invoke_O__O(arg_922) } else { seq__1716000095__14 = linked_920.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_919, arg_922) }
//line :54:1
						var first__1716000096__15 any; var root_923 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_923, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_925 lang.IFn


















						if linked_924 == nil { ifn_925 = lang.IFn_Cast(root_923) } else { ifn_925 = nil }; var arg_926 any = seq__1716000095__14; if linked_924 == nil { first__1716000096__15 = ifn_925.Invoke_O__O(arg_926) } else { first__1716000096__15 = linked_924.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_923, arg_926) }
//line :54:1
						var seq__1716000095__16 any; var root_927 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_927, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_929 lang.IFn


















						if linked_928 == nil { ifn_929 = lang.IFn_Cast(root_927) } else { ifn_929 = nil }; var arg_930 any = seq__1716000095__14; if linked_928 == nil { seq__1716000095__16 = ifn_929.Invoke_O__O(arg_930) } else { seq__1716000095__16 = linked_928.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_927, arg_930) }
//line :54:1
						var ___17 any = first__1716000096__15; var first__1716000096__18 any; var root_931 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_931, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_933 lang.IFn; _ = ___17


















						if linked_932 == nil { ifn_933 = lang.IFn_Cast(root_931) } else { ifn_933 = nil }; var arg_934 any = seq__1716000095__16; if linked_932 == nil { first__1716000096__18 = ifn_933.Invoke_O__O(arg_934) } else { first__1716000096__18 = linked_932.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_931, arg_934) }
//line :54:1
						var seq__1716000095__19 any; var root_935 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_935, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_937 lang.IFn


















						if linked_936 == nil { ifn_937 = lang.IFn_Cast(root_935) } else { ifn_937 = nil }; var arg_938 any = seq__1716000095__16; if linked_936 == nil { seq__1716000095__19 = ifn_937.Invoke_O__O(arg_938) } else { seq__1716000095__19 = linked_936.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_935, arg_938) }
//line :54:1
						var nm__20 any = first__1716000096__18; var more__21_2 any = seq__1716000095__19; var more__22 any; var root_939 any = A_arbace_j2g_jrt_A_const_50.GetRawRoot__O(); var linked_940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_939, A_arbace_j2g_jrt_strip_doc_A_fn_class); var ifn_941 lang.IFn



















						if linked_940 == nil { ifn_941 = lang.IFn_Cast(root_939) } else { ifn_941 = nil }; var arg_942 any = more__21_2; if linked_940 == nil { more__22 = ifn_941.Invoke_O__O(arg_942) } else { more__22 = linked_940.(*A_arbace_j2g_jrt_strip_doc_A).Invoke_O_O__O(root_939, arg_942) }
//line :54:1
						var more__23 any; var tmp124 any = A_arbace_j2g_jrt_A_const_51; var tmp125 any; var root_943 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_943, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_945 lang.IFn




















						if linked_944 == nil { ifn_945 = lang.IFn_Cast(root_943) } else { ifn_945 = nil }; var arg_946 any = more__22; if linked_944 == nil { tmp125 = ifn_945.Invoke_O__O(arg_946) } else { tmp125 = linked_944.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_943, arg_946) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp124, tmp125) { var root_947 any = A_arbace_j2g_jrt_A_const_30.GetRawRoot__O(); var linked_948 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_947, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_949 lang.IFn; if linked_948 == nil { ifn_949 = lang.IFn_Cast(root_947) } else { ifn_949 = nil }; var arg_951 any = more__22; if linked_948 == nil { more__23 = ifn_949.Invoke_O_O__O(A_arbace_j2g_jrt_A_const_31, arg_951) } else { more__23 = linked_948.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_947, 2, A_arbace_j2g_jrt_A_const_31, arg_951) } } else { more__23 = more__22 }
//line :54:1
						var params__24 any; var root_952 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_952, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_954 lang.IFn





















						if linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any = more__23; if linked_953 == nil { params__24 = ifn_954.Invoke_O__O(arg_955) } else { params__24 = linked_953.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_952, arg_955) }
//line :54:1
						var rt__25 any; var root_956 any = A_arbace_j2g_jrt_A_const_52.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_956, A_arbace_j2g_jrt_recv_type_A_fn_class); var ifn_958 lang.IFn






















						if linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any; var root_960 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_960, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_962 lang.IFn; if linked_961 == nil { ifn_962 = lang.IFn_Cast(root_960) } else { ifn_962 = nil }; var arg_963 any = params__24; if linked_961 == nil { arg_959 = ifn_962.Invoke_O__O(arg_963) } else { arg_959 = linked_961.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_960, arg_963) }; if linked_957 == nil { rt__25 = ifn_958.Invoke_O__O(arg_959) } else { rt__25 = linked_957.(*A_arbace_j2g_jrt_recv_type_A).Invoke_O_O__O(root_956, arg_959) }
						if jrt.J2g_Truth(rt__25) { var tmp126 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp127 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_53.GetRawRoot__O()); var tmp128 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp129 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_jrt_A_const_40, rt__25); var tmp130 any; var root_971 any = A_arbace_j2g_jrt_A_const_54.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_973 lang.IFn; if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_975 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_972 == nil { tmp130 = ifn_973.Invoke_O_O__O(arg_974, arg_975) } else { tmp130 = linked_972.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_971, arg_974, arg_975) }; var tmp131 any = tmp130; var tmp132 any; var root_976 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = nm__20; if linked_977 == nil { tmp132 = ifn_978.Invoke_O__O(arg_979) } else { tmp132 = linked_977.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_976, arg_979) }; jrt.NN(tmp126).Reset_O__O(tmp127.Invoke_O_O_O_O__O(tmp128, tmp129, tmp131, tmp132)) }
//line :54:1
						break L9 }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000093__12_, Lit_32) { var vec__1716000097__13 any = fm__10; var seq__1716000098__14 any; var root_980 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_980, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_982 lang.IFn
							if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any = vec__1716000097__13; if linked_981 == nil { seq__1716000098__14 = ifn_982.Invoke_O__O(arg_983) } else { seq__1716000098__14 = linked_981.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_980, arg_983) }
//line :54:1
							var first__1716000099__15 any; var root_984 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_986 lang.IFn
							if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = seq__1716000098__14; if linked_985 == nil { first__1716000099__15 = ifn_986.Invoke_O__O(arg_987) } else { first__1716000099__15 = linked_985.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_984, arg_987) }
//line :54:1
							var seq__1716000098__16 any; var root_988 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_990 lang.IFn
							if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any = seq__1716000098__14; if linked_989 == nil { seq__1716000098__16 = ifn_990.Invoke_O__O(arg_991) } else { seq__1716000098__16 = linked_989.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_988, arg_991) }
//line :54:1
							var ___17_2 any = first__1716000099__15; var more__18 any = seq__1716000098__16; var more__19_3 any; var root_992 any = A_arbace_j2g_jrt_A_const_50.GetRawRoot__O(); var linked_993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_992, A_arbace_j2g_jrt_strip_doc_A_fn_class); var ifn_994 lang.IFn; _ = ___17_2

							if linked_993 == nil { ifn_994 = lang.IFn_Cast(root_992) } else { ifn_994 = nil }; var arg_995 any = more__18; if linked_993 == nil { more__19_3 = ifn_994.Invoke_O__O(arg_995) } else { more__19_3 = linked_993.(*A_arbace_j2g_jrt_strip_doc_A).Invoke_O_O__O(root_992, arg_995) }
							var tmp133 any; var root_996 any = A_arbace_j2g_jrt_A_const_55.GetRawRoot__O(); var linked_997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_996, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_998 lang.IFn; if linked_997 == nil { ifn_998 = lang.IFn_Cast(root_996) } else { ifn_998 = nil }; var arg_999 any; var root_1000 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1000, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1002 lang.IFn; if linked_1001 == nil { ifn_1002 = lang.IFn_Cast(root_1000) } else { ifn_1002 = nil }; var arg_1003 any = more__19_3; if linked_1001 == nil { arg_999 = ifn_1002.Invoke_O__O(arg_1003) } else { arg_999 = linked_1001.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1000, arg_1003) }; if linked_997 == nil { tmp133 = ifn_998.Invoke_O__O(arg_999) } else { tmp133 = linked_997.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_996, arg_999) }; if jrt.J2g_Truth(tmp133) { var seq_1716000100__20 any; var root_1004 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1004, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1006 lang.IFn
								if linked_1005 == nil { ifn_1006 = lang.IFn_Cast(root_1004) } else { ifn_1006 = nil }; var arg_1007 any = more__19_3; if linked_1005 == nil { seq_1716000100__20 = ifn_1006.Invoke_O__O(arg_1007) } else { seq_1716000100__20 = linked_1005.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1004, arg_1007) }
//line :57:1
								var chunk_1716000101__21 any; var count_1716000102__22 int64 = 0; var i_1716000103__23 int64 = 0; L10: for {
									if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000103__23, count_1716000102__22) { var vec__1716000104__24 any = lang.Indexed_Cast(chunk_1716000101__21).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000103__23)); var nm__25_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000104__24, lang.RT_IntCast_J__I_NoInit(0), nil); var tf__26_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000104__24, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp134 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp135 any; var root_1153 any = A_arbace_j2g_jrt_A_const_56.GetRawRoot__O(); var linked_1154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1153, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1155 lang.IFn
										if linked_1154 == nil { ifn_1155 = lang.IFn_Cast(root_1153) } else { ifn_1155 = nil }; var arg_1156 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1157 any; var tmp136 any = A_arbace_j2g_jrt_A_const_39; var tmp137 any; var root_1159 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1159, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1161 lang.IFn; if linked_1160 == nil { ifn_1161 = lang.IFn_Cast(root_1159) } else { ifn_1161 = nil }; var arg_1162 any = nm__25_2; if linked_1160 == nil { tmp137 = ifn_1161.Invoke_O__O(arg_1162) } else { tmp137 = linked_1160.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1159, arg_1162) }; arg_1157 = lang.Tuple_Create_O_O__IPersistentVector(tmp136, tmp137); var arg_1158 any; var tmp138 any = A_arbace_j2g_jrt_A_const_57; var tmp139 *lang.Keyword; var tmp140 any; var and__1927000168__auto____27_4 any; var root_1163 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_1164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1163, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1165 lang.IFn
										if linked_1164 == nil { ifn_1165 = lang.IFn_Cast(root_1163) } else { ifn_1165 = nil }; var arg_1166 any = tf__26_2; if linked_1164 == nil { and__1927000168__auto____27_4 = ifn_1165.Invoke_O__O(arg_1166) } else { and__1927000168__auto____27_4 = linked_1164.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1163, arg_1166) }; if jrt.J2g_Truth(and__1927000168__auto____27_4) { var tmp141 any = A_arbace_j2g_jrt_A_const_65; var tmp142 any; var root_1167 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1167, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1169 lang.IFn; if linked_1168 == nil { ifn_1169 = lang.IFn_Cast(root_1167) } else { ifn_1169 = nil }; var arg_1170 any = tf__26_2; if linked_1168 == nil { tmp142 = ifn_1169.Invoke_O__O(arg_1170) } else { tmp142 = linked_1168.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1167, arg_1170) }; tmp140 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp141, tmp142)).Ref() } else { tmp140 = and__1927000168__auto____27_4 }; if jrt.J2g_Truth(tmp140) { tmp139 = A_arbace_j2g_jrt_A_const_59 } else { var tmp143 any; var and__1927000168__auto____27_5 any; var root_1171 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1171, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1173 lang.IFn
											if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any = tf__26_2; if linked_1172 == nil { and__1927000168__auto____27_5 = ifn_1173.Invoke_O__O(arg_1174) } else { and__1927000168__auto____27_5 = linked_1172.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1171, arg_1174) }; if jrt.J2g_Truth(and__1927000168__auto____27_5) { var tmp144 any = A_arbace_j2g_jrt_A_const_66; var tmp145 any; var root_1175 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1175, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1177 lang.IFn; if linked_1176 == nil { ifn_1177 = lang.IFn_Cast(root_1175) } else { ifn_1177 = nil }; var arg_1178 any = tf__26_2; if linked_1176 == nil { tmp145 = ifn_1177.Invoke_O__O(arg_1178) } else { tmp145 = linked_1176.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1175, arg_1178) }; tmp143 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp144, tmp145)).Ref() } else { tmp143 = and__1927000168__auto____27_5 }
//line :60:1
											if jrt.J2g_Truth(tmp143) { tmp139 = A_arbace_j2g_jrt_A_const_61 } else { if A_arbace_j2g_jrt_A_const_21 != nil { tmp139 = A_arbace_j2g_jrt_A_const_62 } else { tmp139 = nil } } }
//line :59:1
										arg_1158 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp138, tmp139.Ref(), A_arbace_j2g_jrt_A_const_63, tf__26_2)); if linked_1154 == nil { tmp135 = ifn_1155.Invoke_O_O_O__O(arg_1156, arg_1157, arg_1158) } else { tmp135 = linked_1154.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1153, arg_1156, arg_1157, arg_1158) }; jrt.NN(tmp134).Reset_O__O(tmp135)
//line :58:1
										seq_1716000100__20, chunk_1716000101__21, count_1716000102__22, i_1716000103__23 = seq_1716000100__20, chunk_1716000101__21, count_1716000102__22, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000103__23); continue L10 } else { var temp__1927000414__auto____24 any; var root_1008 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1008, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1010 lang.IFn; if linked_1009 == nil { ifn_1010 = lang.IFn_Cast(root_1008) } else { ifn_1010 = nil }; var arg_1011 any = seq_1716000100__20; if linked_1009 == nil { temp__1927000414__auto____24 = ifn_1010.Invoke_O__O(arg_1011) } else { temp__1927000414__auto____24 = linked_1009.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1008, arg_1011) }; if jrt.J2g_Truth(temp__1927000414__auto____24) { var seq_1716000100__25 any = temp__1927000414__auto____24; var tmp146 any; var root_1012 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_1013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1012, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1014 lang.IFn; if linked_1013 == nil { ifn_1014 = lang.IFn_Cast(root_1012) } else { ifn_1014 = nil }; var arg_1015 any = seq_1716000100__25; if linked_1013 == nil { tmp146 = ifn_1014.Invoke_O__O(arg_1015) } else { tmp146 = linked_1013.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1012, arg_1015) }; if jrt.J2g_Truth(tmp146) { var c__1927000678__auto____26 any; var root_1016 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_1017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1016, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1018 lang.IFn; if linked_1017 == nil { ifn_1018 = lang.IFn_Cast(root_1016) } else { ifn_1018 = nil }; var arg_1019 any = seq_1716000100__25; if linked_1017 == nil { c__1927000678__auto____26 = ifn_1018.Invoke_O__O(arg_1019) } else { c__1927000678__auto____26 = linked_1017.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1016, arg_1019) }; var tmp147 any; var root_1179 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_1180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1179, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1181 lang.IFn; if linked_1180 == nil { ifn_1181 = lang.IFn_Cast(root_1179) } else { ifn_1181 = nil }; var arg_1182 any = seq_1716000100__25; if linked_1180 == nil { tmp147 = ifn_1181.Invoke_O__O(arg_1182) } else { tmp147 = linked_1180.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1179, arg_1182) }; seq_1716000100__20, chunk_1716000101__21, count_1716000102__22, i_1716000103__23 = tmp147, c__1927000678__auto____26, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____26))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L10 } else { var vec__1716000107__26 any; var root_1020 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1020, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1022 lang.IFn; if linked_1021 == nil { ifn_1022 = lang.IFn_Cast(root_1020) } else { ifn_1022 = nil }; var arg_1023 any = seq_1716000100__25; if linked_1021 == nil { vec__1716000107__26 = ifn_1022.Invoke_O__O(arg_1023) } else { vec__1716000107__26 = linked_1021.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1020, arg_1023) }; var nm__27 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000107__26, lang.RT_IntCast_J__I_NoInit(0), nil); var tf__28 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000107__26, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp148 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp149 any; var root_1183 any = A_arbace_j2g_jrt_A_const_56.GetRawRoot__O(); var linked_1184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1183, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1185 lang.IFn
											if linked_1184 == nil { ifn_1185 = lang.IFn_Cast(root_1183) } else { ifn_1185 = nil }; var arg_1186 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1187 any; var tmp150 any = A_arbace_j2g_jrt_A_const_39; var tmp151 any; var root_1189 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1189, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1191 lang.IFn; if linked_1190 == nil { ifn_1191 = lang.IFn_Cast(root_1189) } else { ifn_1191 = nil }; var arg_1192 any = nm__27; if linked_1190 == nil { tmp151 = ifn_1191.Invoke_O__O(arg_1192) } else { tmp151 = linked_1190.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1189, arg_1192) }; arg_1187 = lang.Tuple_Create_O_O__IPersistentVector(tmp150, tmp151); var arg_1188 any; var tmp152 any = A_arbace_j2g_jrt_A_const_57; var tmp153 *lang.Keyword; var tmp154 any; var and__1927000168__auto____29 any; var root_1193 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_1194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1193, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1195 lang.IFn
											if linked_1194 == nil { ifn_1195 = lang.IFn_Cast(root_1193) } else { ifn_1195 = nil }; var arg_1196 any = tf__28; if linked_1194 == nil { and__1927000168__auto____29 = ifn_1195.Invoke_O__O(arg_1196) } else { and__1927000168__auto____29 = linked_1194.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1193, arg_1196) }; if jrt.J2g_Truth(and__1927000168__auto____29) { var tmp155 any = A_arbace_j2g_jrt_A_const_65; var tmp156 any; var root_1197 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1197, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1199 lang.IFn; if linked_1198 == nil { ifn_1199 = lang.IFn_Cast(root_1197) } else { ifn_1199 = nil }; var arg_1200 any = tf__28; if linked_1198 == nil { tmp156 = ifn_1199.Invoke_O__O(arg_1200) } else { tmp156 = linked_1198.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1197, arg_1200) }; tmp154 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp155, tmp156)).Ref() } else { tmp154 = and__1927000168__auto____29 }; if jrt.J2g_Truth(tmp154) { tmp153 = A_arbace_j2g_jrt_A_const_59 } else { var tmp157 any; var and__1927000168__auto____29_2 any; var root_1201 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_1202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1201, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1203 lang.IFn
												if linked_1202 == nil { ifn_1203 = lang.IFn_Cast(root_1201) } else { ifn_1203 = nil }; var arg_1204 any = tf__28; if linked_1202 == nil { and__1927000168__auto____29_2 = ifn_1203.Invoke_O__O(arg_1204) } else { and__1927000168__auto____29_2 = linked_1202.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1201, arg_1204) }; if jrt.J2g_Truth(and__1927000168__auto____29_2) { var tmp158 any = A_arbace_j2g_jrt_A_const_66; var tmp159 any; var root_1205 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1205, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1207 lang.IFn; if linked_1206 == nil { ifn_1207 = lang.IFn_Cast(root_1205) } else { ifn_1207 = nil }; var arg_1208 any = tf__28; if linked_1206 == nil { tmp159 = ifn_1207.Invoke_O__O(arg_1208) } else { tmp159 = linked_1206.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1205, arg_1208) }; tmp157 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp158, tmp159)).Ref() } else { tmp157 = and__1927000168__auto____29_2 }
//line :60:1
												if jrt.J2g_Truth(tmp157) { tmp153 = A_arbace_j2g_jrt_A_const_61 } else { if A_arbace_j2g_jrt_A_const_21 != nil { tmp153 = A_arbace_j2g_jrt_A_const_62 } else { tmp153 = nil } } }
//line :59:1
											arg_1188 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp152, tmp153.Ref(), A_arbace_j2g_jrt_A_const_63, tf__28)); if linked_1184 == nil { tmp149 = ifn_1185.Invoke_O_O_O__O(arg_1186, arg_1187, arg_1188) } else { tmp149 = linked_1184.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1183, arg_1186, arg_1187, arg_1188) }; jrt.NN(tmp148).Reset_O__O(tmp149)
//line :58:1
											var tmp160 any; var root_1209 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_1210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1209, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1211 lang.IFn; if linked_1210 == nil { ifn_1211 = lang.IFn_Cast(root_1209) } else { ifn_1211 = nil }; var arg_1212 any = seq_1716000100__25; if linked_1210 == nil { tmp160 = ifn_1211.Invoke_O__O(arg_1212) } else { tmp160 = linked_1210.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1209, arg_1212) }; seq_1716000100__20, chunk_1716000101__21, count_1716000102__22, i_1716000103__23 = tmp160, nil, 0, 0; continue L10 } } }
//line :57:1
									break L10 } } else { var nm__20_2 any; var root_1024 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1024, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1026 lang.IFn






										if linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any = more__19_3; if linked_1025 == nil { nm__20_2 = ifn_1026.Invoke_O__O(arg_1027) } else { nm__20_2 = linked_1025.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1024, arg_1027) }
//line :57:1
										var more__21_3 any; var root_1028 any = A_arbace_j2g_jrt_A_const_50.GetRawRoot__O(); var linked_1029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1028, A_arbace_j2g_jrt_strip_doc_A_fn_class); var ifn_1030 lang.IFn







										if linked_1029 == nil { ifn_1030 = lang.IFn_Cast(root_1028) } else { ifn_1030 = nil }; var arg_1031 any; var root_1032 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_1033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1032, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1034 lang.IFn; if linked_1033 == nil { ifn_1034 = lang.IFn_Cast(root_1032) } else { ifn_1034 = nil }; var arg_1035 any = more__19_3; if linked_1033 == nil { arg_1031 = ifn_1034.Invoke_O__O(arg_1035) } else { arg_1031 = linked_1033.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1032, arg_1035) }; if linked_1029 == nil { more__21_3 = ifn_1030.Invoke_O__O(arg_1031) } else { more__21_3 = linked_1029.(*A_arbace_j2g_jrt_strip_doc_A).Invoke_O_O__O(root_1028, arg_1031) }
//line :57:1
										var more__22_2 any; var tmp161 any = A_arbace_j2g_jrt_A_const_51; var tmp162 any; var root_1036 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1036, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1038 lang.IFn








										if linked_1037 == nil { ifn_1038 = lang.IFn_Cast(root_1036) } else { ifn_1038 = nil }; var arg_1039 any = more__21_3; if linked_1037 == nil { tmp162 = ifn_1038.Invoke_O__O(arg_1039) } else { tmp162 = linked_1037.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1036, arg_1039) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp161, tmp162) { var root_1040 any = A_arbace_j2g_jrt_A_const_30.GetRawRoot__O(); var linked_1041 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1040, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_1042 lang.IFn; if linked_1041 == nil { ifn_1042 = lang.IFn_Cast(root_1040) } else { ifn_1042 = nil }; var arg_1044 any = more__21_3; if linked_1041 == nil { more__22_2 = ifn_1042.Invoke_O_O__O(A_arbace_j2g_jrt_A_const_31, arg_1044) } else { more__22_2 = linked_1041.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_1040, 2, A_arbace_j2g_jrt_A_const_31, arg_1044) } } else { more__22_2 = more__21_3 }
//line :57:1
										var tf__23 any; var root_1045 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1045, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1047 lang.IFn









										if linked_1046 == nil { ifn_1047 = lang.IFn_Cast(root_1045) } else { ifn_1047 = nil }; var arg_1048 any = more__22_2; if linked_1046 == nil { tf__23 = ifn_1047.Invoke_O__O(arg_1048) } else { tf__23 = linked_1046.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1045, arg_1048) }
										var tmp163 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp164 any; var root_1049 any = A_arbace_j2g_jrt_A_const_56.GetRawRoot__O(); var linked_1050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1049, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1051 lang.IFn; if linked_1050 == nil { ifn_1051 = lang.IFn_Cast(root_1049) } else { ifn_1051 = nil }; var arg_1052 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1053 any; var tmp165 any = A_arbace_j2g_jrt_A_const_39; var tmp166 any; var root_1055 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1055, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1057 lang.IFn; if linked_1056 == nil { ifn_1057 = lang.IFn_Cast(root_1055) } else { ifn_1057 = nil }; var arg_1058 any = nm__20_2; if linked_1056 == nil { tmp166 = ifn_1057.Invoke_O__O(arg_1058) } else { tmp166 = linked_1056.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1055, arg_1058) }; arg_1053 = lang.Tuple_Create_O_O__IPersistentVector(tmp165, tmp166); var arg_1054 any; var tmp167 any = A_arbace_j2g_jrt_A_const_57; var tmp168 *lang.Keyword; var tmp169 any; var and__1927000168__auto____24 any; var root_1059 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_1060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1059, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1061 lang.IFn
										if linked_1060 == nil { ifn_1061 = lang.IFn_Cast(root_1059) } else { ifn_1061 = nil }; var arg_1062 any = tf__23; if linked_1060 == nil { and__1927000168__auto____24 = ifn_1061.Invoke_O__O(arg_1062) } else { and__1927000168__auto____24 = linked_1060.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1059, arg_1062) }; if jrt.J2g_Truth(and__1927000168__auto____24) { var tmp170 any = A_arbace_j2g_jrt_A_const_58; var tmp171 any; var root_1063 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1063, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1065 lang.IFn; if linked_1064 == nil { ifn_1065 = lang.IFn_Cast(root_1063) } else { ifn_1065 = nil }; var arg_1066 any = tf__23; if linked_1064 == nil { tmp171 = ifn_1065.Invoke_O__O(arg_1066) } else { tmp171 = linked_1064.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1063, arg_1066) }; tmp169 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp170, tmp171)).Ref() } else { tmp169 = and__1927000168__auto____24 }; if jrt.J2g_Truth(tmp169) { tmp168 = A_arbace_j2g_jrt_A_const_59 } else { var tmp172 any; var and__1927000168__auto____24_2 any; var root_1067 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_1068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1067, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1069 lang.IFn
											if linked_1068 == nil { ifn_1069 = lang.IFn_Cast(root_1067) } else { ifn_1069 = nil }; var arg_1070 any = tf__23; if linked_1068 == nil { and__1927000168__auto____24_2 = ifn_1069.Invoke_O__O(arg_1070) } else { and__1927000168__auto____24_2 = linked_1068.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1067, arg_1070) }; if jrt.J2g_Truth(and__1927000168__auto____24_2) { var tmp173 any = A_arbace_j2g_jrt_A_const_60; var tmp174 any; var root_1071 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1071, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1073 lang.IFn; if linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any = tf__23; if linked_1072 == nil { tmp174 = ifn_1073.Invoke_O__O(arg_1074) } else { tmp174 = linked_1072.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1071, arg_1074) }; tmp172 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp173, tmp174)).Ref() } else { tmp172 = and__1927000168__auto____24_2 }
//line :69:1
											if jrt.J2g_Truth(tmp172) { tmp168 = A_arbace_j2g_jrt_A_const_61 } else { if A_arbace_j2g_jrt_A_const_21 != nil { tmp168 = A_arbace_j2g_jrt_A_const_62 } else { tmp168 = nil } } }
//line :68:1
										arg_1054 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp167, tmp168.Ref(), A_arbace_j2g_jrt_A_const_63, tf__23)); if linked_1050 == nil { tmp164 = ifn_1051.Invoke_O_O_O__O(arg_1052, arg_1053, arg_1054) } else { tmp164 = linked_1050.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1049, arg_1052, arg_1053, arg_1054) }; jrt.NN(tmp163).Reset_O__O(tmp164) }
//line :54:1
							break L9 }; case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000093__12_, Lit_33) { var vec__1716000110__13 any = fm__10; var seq__1716000111__14 any; var root_1075 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1075, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1077 lang.IFn








































								if linked_1076 == nil { ifn_1077 = lang.IFn_Cast(root_1075) } else { ifn_1077 = nil }; var arg_1078 any = vec__1716000110__13; if linked_1076 == nil { seq__1716000111__14 = ifn_1077.Invoke_O__O(arg_1078) } else { seq__1716000111__14 = linked_1076.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1075, arg_1078) }
//line :54:1
								var first__1716000112__15 any; var root_1079 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1079, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1081 lang.IFn








































								if linked_1080 == nil { ifn_1081 = lang.IFn_Cast(root_1079) } else { ifn_1081 = nil }; var arg_1082 any = seq__1716000111__14; if linked_1080 == nil { first__1716000112__15 = ifn_1081.Invoke_O__O(arg_1082) } else { first__1716000112__15 = linked_1080.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1079, arg_1082) }
//line :54:1
								var seq__1716000111__16 any; var root_1083 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_1084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1083, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1085 lang.IFn








































								if linked_1084 == nil { ifn_1085 = lang.IFn_Cast(root_1083) } else { ifn_1085 = nil }; var arg_1086 any = seq__1716000111__14; if linked_1084 == nil { seq__1716000111__16 = ifn_1085.Invoke_O__O(arg_1086) } else { seq__1716000111__16 = linked_1084.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1083, arg_1086) }
//line :54:1
								var ___17_3 any = first__1716000112__15; var more__18_2 any = seq__1716000111__16; var more__19_4 any; var root_1087 any = A_arbace_j2g_jrt_A_const_50.GetRawRoot__O(); var linked_1088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1087, A_arbace_j2g_jrt_strip_doc_A_fn_class); var ifn_1089 lang.IFn; _ = ___17_3









































								if linked_1088 == nil { ifn_1089 = lang.IFn_Cast(root_1087) } else { ifn_1089 = nil }; var arg_1090 any = more__18_2; if linked_1088 == nil { more__19_4 = ifn_1089.Invoke_O__O(arg_1090) } else { more__19_4 = linked_1088.(*A_arbace_j2g_jrt_strip_doc_A).Invoke_O_O__O(root_1087, arg_1090) }
								var tmp175 any; var root_1091 any = A_arbace_j2g_jrt_A_const_55.GetRawRoot__O(); var linked_1092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1091, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1093 lang.IFn; if linked_1092 == nil { ifn_1093 = lang.IFn_Cast(root_1091) } else { ifn_1093 = nil }; var arg_1094 any; var root_1095 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1095, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1097 lang.IFn; if linked_1096 == nil { ifn_1097 = lang.IFn_Cast(root_1095) } else { ifn_1097 = nil }; var arg_1098 any = more__19_4; if linked_1096 == nil { arg_1094 = ifn_1097.Invoke_O__O(arg_1098) } else { arg_1094 = linked_1096.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1095, arg_1098) }; if linked_1092 == nil { tmp175 = ifn_1093.Invoke_O__O(arg_1094) } else { tmp175 = linked_1092.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1091, arg_1094) }; if jrt.J2g_Truth(tmp175) { var seq_1716000113__20 any; var root_1099 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1099, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1101 lang.IFn
									if linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any = more__19_4; if linked_1100 == nil { seq_1716000113__20 = ifn_1101.Invoke_O__O(arg_1102) } else { seq_1716000113__20 = linked_1100.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1099, arg_1102) }
//line :97:1
									var chunk_1716000114__21 any; var count_1716000115__22 int64 = 0; var i_1716000116__23 int64 = 0; L11: for {
										if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000116__23, count_1716000115__22) { var vec__1716000117__24 any = lang.Indexed_Cast(chunk_1716000114__21).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000116__23)); var tg__25_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000117__24, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp176 any; var root_1213 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_1214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1213, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1215 lang.IFn; if linked_1214 == nil { ifn_1215 = lang.IFn_Cast(root_1213) } else { ifn_1215 = nil }; var arg_1216 any = tg__25_3; if linked_1214 == nil { tmp176 = ifn_1215.Invoke_O__O(arg_1216) } else { tmp176 = linked_1214.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1213, arg_1216) }; if jrt.J2g_Truth(tmp176) { var tmp177 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp178 any; var root_1217 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_1218 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1217, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1219 lang.IFn; if linked_1218 == nil { ifn_1219 = lang.IFn_Cast(root_1217) } else { ifn_1219 = nil }; var arg_1220 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1221 any = A_arbace_j2g_jrt_A_const_44; var arg_1222 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_1223 any; var root_1224 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1224, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1226 lang.IFn; if linked_1225 == nil { ifn_1226 = lang.IFn_Cast(root_1224) } else { ifn_1226 = nil }; var arg_1227 any = tg__25_3; if linked_1225 == nil { arg_1223 = ifn_1226.Invoke_O__O(arg_1227) } else { arg_1223 = linked_1225.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1224, arg_1227) }; if linked_1218 == nil { tmp178 = ifn_1219.Invoke_O_O_O_O__O(arg_1220, arg_1221, arg_1222, arg_1223) } else { tmp178 = linked_1218.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1217, arg_1220, arg_1221, arg_1222, arg_1223) }; jrt.NN(tmp177).Reset_O__O(tmp178) }; seq_1716000113__20, chunk_1716000114__21, count_1716000115__22, i_1716000116__23 = seq_1716000113__20, chunk_1716000114__21, count_1716000115__22, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000116__23); continue L11 } else { var temp__1927000414__auto____24_2 any; var root_1103 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1103, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1105 lang.IFn; if linked_1104 == nil { ifn_1105 = lang.IFn_Cast(root_1103) } else { ifn_1105 = nil }; var arg_1106 any = seq_1716000113__20; if linked_1104 == nil { temp__1927000414__auto____24_2 = ifn_1105.Invoke_O__O(arg_1106) } else { temp__1927000414__auto____24_2 = linked_1104.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1103, arg_1106) }; if jrt.J2g_Truth(temp__1927000414__auto____24_2) { var seq_1716000113__25 any = temp__1927000414__auto____24_2; var tmp179 any; var root_1107 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_1108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1107, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1109 lang.IFn; if linked_1108 == nil { ifn_1109 = lang.IFn_Cast(root_1107) } else { ifn_1109 = nil }; var arg_1110 any = seq_1716000113__25; if linked_1108 == nil { tmp179 = ifn_1109.Invoke_O__O(arg_1110) } else { tmp179 = linked_1108.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1107, arg_1110) }; if jrt.J2g_Truth(tmp179) { var c__1927000678__auto____26_2 any; var root_1111 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_1112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1111, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1113 lang.IFn; if linked_1112 == nil { ifn_1113 = lang.IFn_Cast(root_1111) } else { ifn_1113 = nil }; var arg_1114 any = seq_1716000113__25; if linked_1112 == nil { c__1927000678__auto____26_2 = ifn_1113.Invoke_O__O(arg_1114) } else { c__1927000678__auto____26_2 = linked_1112.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1111, arg_1114) }; var tmp180 any; var root_1228 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_1229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1228, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1230 lang.IFn; if linked_1229 == nil { ifn_1230 = lang.IFn_Cast(root_1228) } else { ifn_1230 = nil }; var arg_1231 any = seq_1716000113__25; if linked_1229 == nil { tmp180 = ifn_1230.Invoke_O__O(arg_1231) } else { tmp180 = linked_1229.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1228, arg_1231) }; seq_1716000113__20, chunk_1716000114__21, count_1716000115__22, i_1716000116__23 = tmp180, c__1927000678__auto____26_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____26_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L11 } else { var vec__1716000120__26 any; var root_1115 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1115, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1117 lang.IFn; if linked_1116 == nil { ifn_1117 = lang.IFn_Cast(root_1115) } else { ifn_1117 = nil }; var arg_1118 any = seq_1716000113__25; if linked_1116 == nil { vec__1716000120__26 = ifn_1117.Invoke_O__O(arg_1118) } else { vec__1716000120__26 = linked_1116.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1115, arg_1118) }; var tg__27 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000120__26, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp181 any; var root_1232 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1234 lang.IFn; if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any = tg__27; if linked_1233 == nil { tmp181 = ifn_1234.Invoke_O__O(arg_1235) } else { tmp181 = linked_1233.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1232, arg_1235) }; if jrt.J2g_Truth(tmp181) { var tmp182 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp183 any; var root_1236 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1236, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1238 lang.IFn; if linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1240 any = A_arbace_j2g_jrt_A_const_44; var arg_1241 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_1242 any; var root_1243 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1243, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1245 lang.IFn; if linked_1244 == nil { ifn_1245 = lang.IFn_Cast(root_1243) } else { ifn_1245 = nil }; var arg_1246 any = tg__27; if linked_1244 == nil { arg_1242 = ifn_1245.Invoke_O__O(arg_1246) } else { arg_1242 = linked_1244.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1243, arg_1246) }; if linked_1237 == nil { tmp183 = ifn_1238.Invoke_O_O_O_O__O(arg_1239, arg_1240, arg_1241, arg_1242) } else { tmp183 = linked_1237.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1236, arg_1239, arg_1240, arg_1241, arg_1242) }; jrt.NN(tmp182).Reset_O__O(tmp183) }; var tmp184 any; var root_1247 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_1248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1247, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1249 lang.IFn; if linked_1248 == nil { ifn_1249 = lang.IFn_Cast(root_1247) } else { ifn_1249 = nil }; var arg_1250 any = seq_1716000113__25; if linked_1248 == nil { tmp184 = ifn_1249.Invoke_O__O(arg_1250) } else { tmp184 = linked_1248.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1247, arg_1250) }; seq_1716000113__20, chunk_1716000114__21, count_1716000115__22, i_1716000116__23 = tmp184, nil, 0, 0; continue L11 } } }
//line :97:1
										break L11 } } else {

											var tmp185 any; var root_1119 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_1120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1119, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1121 lang.IFn; if linked_1120 == nil { ifn_1121 = lang.IFn_Cast(root_1119) } else { ifn_1121 = nil }; var arg_1122 any; var root_1123 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1123, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1125 lang.IFn; if linked_1124 == nil { ifn_1125 = lang.IFn_Cast(root_1123) } else { ifn_1125 = nil }; var arg_1126 any = more__19_4; if linked_1124 == nil { arg_1122 = ifn_1125.Invoke_O__O(arg_1126) } else { arg_1122 = linked_1124.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1123, arg_1126) }; if linked_1120 == nil { tmp185 = ifn_1121.Invoke_O__O(arg_1122) } else { tmp185 = linked_1120.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1119, arg_1122) }; if jrt.J2g_Truth(tmp185) { var tmp186 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp187 any; var root_1127 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_1128 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1127, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1129 lang.IFn; if linked_1128 == nil { ifn_1129 = lang.IFn_Cast(root_1127) } else { ifn_1129 = nil }; var arg_1130 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1131 any = A_arbace_j2g_jrt_A_const_44; var arg_1132 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_1133 any; var root_1134 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1136 lang.IFn; if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any; var root_1138 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1138, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1140 lang.IFn; if linked_1139 == nil { ifn_1140 = lang.IFn_Cast(root_1138) } else { ifn_1140 = nil }; var arg_1141 any = more__19_4; if linked_1139 == nil { arg_1137 = ifn_1140.Invoke_O__O(arg_1141) } else { arg_1137 = linked_1139.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1138, arg_1141) }; if linked_1135 == nil { arg_1133 = ifn_1136.Invoke_O__O(arg_1137) } else { arg_1133 = linked_1135.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1134, arg_1137) }; if linked_1128 == nil { tmp187 = ifn_1129.Invoke_O_O_O_O__O(arg_1130, arg_1131, arg_1132, arg_1133) } else { tmp187 = linked_1128.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1127, arg_1130, arg_1131, arg_1132, arg_1133) }; jrt.NN(tmp186).Reset_O__O(tmp187) } }
//line :54:1
								break L9 }; case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000093__12_, Lit_34) { var vec__1716000123__13 any = fm__10; var ___14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000123__13, lang.RT_IntCast_J__I_NoInit(0), nil); var nm__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000123__13, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp188 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp189 any; var root_1142 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_1143 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1142, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1144 lang.IFn; _ = ___14
























									if linked_1143 == nil { ifn_1144 = lang.IFn_Cast(root_1142) } else { ifn_1144 = nil }; var arg_1145 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1146 any = A_arbace_j2g_jrt_A_const_41; var arg_1147 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_1148 any; var root_1149 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1149, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1151 lang.IFn; if linked_1150 == nil { ifn_1151 = lang.IFn_Cast(root_1149) } else { ifn_1151 = nil }; var arg_1152 any = nm__15; if linked_1150 == nil { arg_1148 = ifn_1151.Invoke_O__O(arg_1152) } else { arg_1148 = linked_1150.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1149, arg_1152) }; if linked_1143 == nil { tmp189 = ifn_1144.Invoke_O_O_O_O__O(arg_1145, arg_1146, arg_1147, arg_1148) } else { tmp189 = linked_1143.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1142, arg_1145, arg_1146, arg_1147, arg_1148) }; jrt.NN(tmp188).Reset_O__O(tmp189)
//line :54:1
									break L9 }; case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1716000093__12_, Lit_35) { var vec__1716000126__13 any = fm__10; var seq__1716000127__14 any; var root_1251 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1251, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1253 lang.IFn

























										if linked_1252 == nil { ifn_1253 = lang.IFn_Cast(root_1251) } else { ifn_1253 = nil }; var arg_1254 any = vec__1716000126__13; if linked_1252 == nil { seq__1716000127__14 = ifn_1253.Invoke_O__O(arg_1254) } else { seq__1716000127__14 = linked_1252.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1251, arg_1254) }
//line :54:1
										var first__1716000128__15 any; var root_1255 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1255, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1257 lang.IFn

























										if linked_1256 == nil { ifn_1257 = lang.IFn_Cast(root_1255) } else { ifn_1257 = nil }; var arg_1258 any = seq__1716000127__14; if linked_1256 == nil { first__1716000128__15 = ifn_1257.Invoke_O__O(arg_1258) } else { first__1716000128__15 = linked_1256.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1255, arg_1258) }
//line :54:1
										var seq__1716000127__16 any; var root_1259 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_1260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1259, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1261 lang.IFn

























										if linked_1260 == nil { ifn_1261 = lang.IFn_Cast(root_1259) } else { ifn_1261 = nil }; var arg_1262 any = seq__1716000127__14; if linked_1260 == nil { seq__1716000127__16 = ifn_1261.Invoke_O__O(arg_1262) } else { seq__1716000127__16 = linked_1260.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1259, arg_1262) }
//line :54:1
										var ___17_4 any = first__1716000128__15; var more__18_3 any = seq__1716000127__16; var more__19_5 any; var root_1263 any = A_arbace_j2g_jrt_A_const_50.GetRawRoot__O(); var linked_1264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1263, A_arbace_j2g_jrt_strip_doc_A_fn_class); var ifn_1265 lang.IFn; _ = ___17_4


























										if linked_1264 == nil { ifn_1265 = lang.IFn_Cast(root_1263) } else { ifn_1265 = nil }; var arg_1266 any = more__18_3; if linked_1264 == nil { more__19_5 = ifn_1265.Invoke_O__O(arg_1266) } else { more__19_5 = linked_1264.(*A_arbace_j2g_jrt_strip_doc_A).Invoke_O_O__O(root_1263, arg_1266) }
										var tmp190 any; var root_1267 any = A_arbace_j2g_jrt_A_const_55.GetRawRoot__O(); var linked_1268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1267, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1269 lang.IFn; if linked_1268 == nil { ifn_1269 = lang.IFn_Cast(root_1267) } else { ifn_1269 = nil }; var arg_1270 any; var root_1271 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1271, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1273 lang.IFn; if linked_1272 == nil { ifn_1273 = lang.IFn_Cast(root_1271) } else { ifn_1273 = nil }; var arg_1274 any = more__19_5; if linked_1272 == nil { arg_1270 = ifn_1273.Invoke_O__O(arg_1274) } else { arg_1270 = linked_1272.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1271, arg_1274) }; if linked_1268 == nil { tmp190 = ifn_1269.Invoke_O__O(arg_1270) } else { tmp190 = linked_1268.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1267, arg_1270) }; if jrt.J2g_Truth(tmp190) { var seq_1716000129__20 any; var root_1275 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1275, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1277 lang.IFn
											if linked_1276 == nil { ifn_1277 = lang.IFn_Cast(root_1275) } else { ifn_1277 = nil }; var arg_1278 any = more__19_5; if linked_1276 == nil { seq_1716000129__20 = ifn_1277.Invoke_O__O(arg_1278) } else { seq_1716000129__20 = linked_1276.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1275, arg_1278) }
//line :82:1
											var chunk_1716000130__21 any; var count_1716000131__22 int64 = 0; var i_1716000132__23 int64 = 0; L12: for {
												if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000132__23, count_1716000131__22) { var vec__1716000133__24 any = lang.Indexed_Cast(chunk_1716000130__21).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000132__23)); var tg__25_4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000133__24, lang.RT_IntCast_J__I_NoInit(0), nil); var init__26_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000133__24, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp191 any; var and__1927000168__auto____27_6 any; var root_1357 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_1358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1357, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1359 lang.IFn
													if linked_1358 == nil { ifn_1359 = lang.IFn_Cast(root_1357) } else { ifn_1359 = nil }; var arg_1360 any = tg__25_4; if linked_1358 == nil { and__1927000168__auto____27_6 = ifn_1359.Invoke_O__O(arg_1360) } else { and__1927000168__auto____27_6 = linked_1358.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1357, arg_1360) }; if jrt.J2g_Truth(and__1927000168__auto____27_6) { var tmp192 any = A_arbace_j2g_jrt_A_const_71; var tmp193 any; var root_1361 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1361, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1363 lang.IFn; if linked_1362 == nil { ifn_1363 = lang.IFn_Cast(root_1361) } else { ifn_1363 = nil }; var arg_1364 any = tg__25_4; if linked_1362 == nil { tmp193 = ifn_1363.Invoke_O__O(arg_1364) } else { tmp193 = linked_1362.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1361, arg_1364) }; tmp191 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp192, tmp193)).Ref() } else { tmp191 = and__1927000168__auto____27_6 }; if jrt.J2g_Truth(tmp191) { var seq_1716000136__27 any; var root_1365 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1365, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1367 lang.IFn
														if linked_1366 == nil { ifn_1367 = lang.IFn_Cast(root_1365) } else { ifn_1367 = nil }; var arg_1368 any; var root_1369 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_1370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1369, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1371 lang.IFn; if linked_1370 == nil { ifn_1371 = lang.IFn_Cast(root_1369) } else { ifn_1371 = nil }; var arg_1372 any = tg__25_4; if linked_1370 == nil { arg_1368 = ifn_1371.Invoke_O__O(arg_1372) } else { arg_1368 = linked_1370.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1369, arg_1372) }; if linked_1366 == nil { seq_1716000136__27 = ifn_1367.Invoke_O__O(arg_1368) } else { seq_1716000136__27 = linked_1366.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1365, arg_1368) }
//line :84:1
														var chunk_1716000137__28 any; var count_1716000138__29 int64 = 0; var i_1716000139__30 int64 = 0; L13: for {
															if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000139__30, count_1716000138__29) { var s__31_3 any = lang.Indexed_Cast(chunk_1716000137__28).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000139__30)); var tmp194 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp195 any; var root_1419 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_1420 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1419, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1421 lang.IFn; if linked_1420 == nil { ifn_1421 = lang.IFn_Cast(root_1419) } else { ifn_1421 = nil }; var arg_1422 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1423 any = A_arbace_j2g_jrt_A_const_42; var arg_1424 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_1425 any; var root_1426 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1426, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1428 lang.IFn; if linked_1427 == nil { ifn_1428 = lang.IFn_Cast(root_1426) } else { ifn_1428 = nil }; var arg_1429 any = s__31_3; if linked_1427 == nil { arg_1425 = ifn_1428.Invoke_O__O(arg_1429) } else { arg_1425 = linked_1427.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1426, arg_1429) }; if linked_1420 == nil { tmp195 = ifn_1421.Invoke_O_O_O_O__O(arg_1422, arg_1423, arg_1424, arg_1425) } else { tmp195 = linked_1420.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1419, arg_1422, arg_1423, arg_1424, arg_1425) }; jrt.NN(tmp194).Reset_O__O(tmp195); seq_1716000136__27, chunk_1716000137__28, count_1716000138__29, i_1716000139__30 = seq_1716000136__27, chunk_1716000137__28, count_1716000138__29, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000139__30); continue L13 } else { var temp__1927000414__auto____31_2 any; var root_1373 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1373, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1375 lang.IFn; if linked_1374 == nil { ifn_1375 = lang.IFn_Cast(root_1373) } else { ifn_1375 = nil }; var arg_1376 any = seq_1716000136__27; if linked_1374 == nil { temp__1927000414__auto____31_2 = ifn_1375.Invoke_O__O(arg_1376) } else { temp__1927000414__auto____31_2 = linked_1374.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1373, arg_1376) }; if jrt.J2g_Truth(temp__1927000414__auto____31_2) { var seq_1716000136__32 any = temp__1927000414__auto____31_2; var tmp196 any; var root_1377 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_1378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1377, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1379 lang.IFn; if linked_1378 == nil { ifn_1379 = lang.IFn_Cast(root_1377) } else { ifn_1379 = nil }; var arg_1380 any = seq_1716000136__32; if linked_1378 == nil { tmp196 = ifn_1379.Invoke_O__O(arg_1380) } else { tmp196 = linked_1378.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1377, arg_1380) }; if jrt.J2g_Truth(tmp196) { var c__1927000678__auto____33_2 any; var root_1381 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_1382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1381, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1383 lang.IFn; if linked_1382 == nil { ifn_1383 = lang.IFn_Cast(root_1381) } else { ifn_1383 = nil }; var arg_1384 any = seq_1716000136__32; if linked_1382 == nil { c__1927000678__auto____33_2 = ifn_1383.Invoke_O__O(arg_1384) } else { c__1927000678__auto____33_2 = linked_1382.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1381, arg_1384) }; var tmp197 any; var root_1430 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_1431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1430, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1432 lang.IFn; if linked_1431 == nil { ifn_1432 = lang.IFn_Cast(root_1430) } else { ifn_1432 = nil }; var arg_1433 any = seq_1716000136__32; if linked_1431 == nil { tmp197 = ifn_1432.Invoke_O__O(arg_1433) } else { tmp197 = linked_1431.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1430, arg_1433) }; seq_1716000136__27, chunk_1716000137__28, count_1716000138__29, i_1716000139__30 = tmp197, c__1927000678__auto____33_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____33_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L13 } else { var s__33_2 any; var root_1385 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1385, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1387 lang.IFn; if linked_1386 == nil { ifn_1387 = lang.IFn_Cast(root_1385) } else { ifn_1387 = nil }; var arg_1388 any = seq_1716000136__32; if linked_1386 == nil { s__33_2 = ifn_1387.Invoke_O__O(arg_1388) } else { s__33_2 = linked_1386.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1385, arg_1388) }; var tmp198 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp199 any; var root_1434 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_1435 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1434, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1436 lang.IFn; if linked_1435 == nil { ifn_1436 = lang.IFn_Cast(root_1434) } else { ifn_1436 = nil }; var arg_1437 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1438 any = A_arbace_j2g_jrt_A_const_42; var arg_1439 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_1440 any; var root_1441 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1441, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1443 lang.IFn; if linked_1442 == nil { ifn_1443 = lang.IFn_Cast(root_1441) } else { ifn_1443 = nil }; var arg_1444 any = s__33_2; if linked_1442 == nil { arg_1440 = ifn_1443.Invoke_O__O(arg_1444) } else { arg_1440 = linked_1442.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1441, arg_1444) }; if linked_1435 == nil { tmp199 = ifn_1436.Invoke_O_O_O_O__O(arg_1437, arg_1438, arg_1439, arg_1440) } else { tmp199 = linked_1435.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1434, arg_1437, arg_1438, arg_1439, arg_1440) }; jrt.NN(tmp198).Reset_O__O(tmp199); var tmp200 any; var root_1445 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_1446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1445, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1447 lang.IFn; if linked_1446 == nil { ifn_1447 = lang.IFn_Cast(root_1445) } else { ifn_1447 = nil }; var arg_1448 any = seq_1716000136__32; if linked_1446 == nil { tmp200 = ifn_1447.Invoke_O__O(arg_1448) } else { tmp200 = linked_1446.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1445, arg_1448) }; seq_1716000136__27, chunk_1716000137__28, count_1716000138__29, i_1716000139__30 = tmp200, nil, 0, 0; continue L13 } } }
//line :84:1
															break L13 } } else {

																var tmp201 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp202 any; var root_1449 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_1450 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1449, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1451 lang.IFn; if linked_1450 == nil { ifn_1451 = lang.IFn_Cast(root_1449) } else { ifn_1451 = nil }; var arg_1452 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1453 any = A_arbace_j2g_jrt_A_const_42; var arg_1454 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_1455 any; var root_1456 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1456, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1458 lang.IFn; if linked_1457 == nil { ifn_1458 = lang.IFn_Cast(root_1456) } else { ifn_1458 = nil }; var arg_1459 any = tg__25_4; if linked_1457 == nil { arg_1455 = ifn_1458.Invoke_O__O(arg_1459) } else { arg_1455 = linked_1457.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1456, arg_1459) }; if linked_1450 == nil { tmp202 = ifn_1451.Invoke_O_O_O_O__O(arg_1452, arg_1453, arg_1454, arg_1455) } else { tmp202 = linked_1450.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1449, arg_1452, arg_1453, arg_1454, arg_1455) }; jrt.NN(tmp201).Reset_O__O(tmp202)
//line :84:1
																var temp__1927000414__auto____27_2 any; var root_1389 any = A_arbace_j2g_jrt_A_const_69.GetRawRoot__O(); var linked_1390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1389, A_arbace_j2g_jrt_define_name_A_fn_class); var ifn_1391 lang.IFn


																if linked_1390 == nil { ifn_1391 = lang.IFn_Cast(root_1389) } else { ifn_1391 = nil }; var arg_1392 any = init__26_2; if linked_1390 == nil { temp__1927000414__auto____27_2 = ifn_1391.Invoke_O__O(arg_1392) } else { temp__1927000414__auto____27_2 = linked_1390.(*A_arbace_j2g_jrt_define_name_A).Invoke_O_O__O(root_1389, arg_1392) }; if jrt.J2g_Truth(temp__1927000414__auto____27_2) { var map__1716000140__28 any = temp__1927000414__auto____27_2; var map__1716000140__29 any; if lang.ISeq_InstanceOf(map__1716000140__28) { var tmp203 any; var root_1393 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_1394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1393, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1395 lang.IFn; if linked_1394 == nil { ifn_1395 = lang.IFn_Cast(root_1393) } else { ifn_1395 = nil }; var arg_1396 any = map__1716000140__28; if linked_1394 == nil { tmp203 = ifn_1395.Invoke_O__O(arg_1396) } else { tmp203 = linked_1394.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1393, arg_1396) }; if jrt.J2g_Truth(tmp203) { var tmp204 any; var root_1397 any = A_arbace_j2g_jrt_A_const_70.GetRawRoot__O(); var linked_1398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1397, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1399 lang.IFn; if linked_1398 == nil { ifn_1399 = lang.IFn_Cast(root_1397) } else { ifn_1399 = nil }; var arg_1400 any = map__1716000140__28; if linked_1398 == nil { tmp204 = ifn_1399.Invoke_O__O(arg_1400) } else { tmp204 = linked_1398.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1397, arg_1400) }; map__1716000140__29 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp204)).Ref() } else { var tmp205 any; var root_1401 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1401, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1403 lang.IFn; if linked_1402 == nil { ifn_1403 = lang.IFn_Cast(root_1401) } else { ifn_1403 = nil }; var arg_1404 any = map__1716000140__28; if linked_1402 == nil { tmp205 = ifn_1403.Invoke_O__O(arg_1404) } else { tmp205 = linked_1402.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1401, arg_1404) }; if jrt.J2g_Truth(tmp205) { var root_1405 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1405, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1407 lang.IFn; if linked_1406 == nil { ifn_1407 = lang.IFn_Cast(root_1405) } else { ifn_1407 = nil }; var arg_1408 any = map__1716000140__28; if linked_1406 == nil { map__1716000140__29 = ifn_1407.Invoke_O__O(arg_1408) } else { map__1716000140__29 = linked_1406.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1405, arg_1408) } } else { map__1716000140__29 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000140__29 = map__1716000140__28 }; var n__30_2 any = lang.RT_Get_O_O__O_NoInit(map__1716000140__29, A_arbace_j2g_jrt_A_const_34); var tmp206 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp207 any; var root_1409 any = A_arbace_j2g_jrt_A_const_56.GetRawRoot__O(); var linked_1410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1409, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1411 lang.IFn
																	if linked_1410 == nil { ifn_1411 = lang.IFn_Cast(root_1409) } else { ifn_1411 = nil }; var arg_1412 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1413 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_jrt_A_const_43, n__30_2); var arg_1414 any; var root_1415 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1415, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1417 lang.IFn; if linked_1416 == nil { ifn_1417 = lang.IFn_Cast(root_1415) } else { ifn_1417 = nil }; var arg_1418 any = tg__25_4; if linked_1416 == nil { arg_1414 = ifn_1417.Invoke_O__O(arg_1418) } else { arg_1414 = linked_1416.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1415, arg_1418) }; if linked_1410 == nil { tmp207 = ifn_1411.Invoke_O_O_O__O(arg_1412, arg_1413, arg_1414) } else { tmp207 = linked_1410.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1409, arg_1412, arg_1413, arg_1414) }; jrt.NN(tmp206).Reset_O__O(tmp207) } }
//line :83:1
													seq_1716000129__20, chunk_1716000130__21, count_1716000131__22, i_1716000132__23 = seq_1716000129__20, chunk_1716000130__21, count_1716000131__22, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000132__23); continue L12 } else { var temp__1927000414__auto____24_3 any; var root_1279 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1279, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1281 lang.IFn; if linked_1280 == nil { ifn_1281 = lang.IFn_Cast(root_1279) } else { ifn_1281 = nil }; var arg_1282 any = seq_1716000129__20; if linked_1280 == nil { temp__1927000414__auto____24_3 = ifn_1281.Invoke_O__O(arg_1282) } else { temp__1927000414__auto____24_3 = linked_1280.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1279, arg_1282) }; if jrt.J2g_Truth(temp__1927000414__auto____24_3) { var seq_1716000129__25 any = temp__1927000414__auto____24_3; var tmp208 any; var root_1283 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_1284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1283, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1285 lang.IFn; if linked_1284 == nil { ifn_1285 = lang.IFn_Cast(root_1283) } else { ifn_1285 = nil }; var arg_1286 any = seq_1716000129__25; if linked_1284 == nil { tmp208 = ifn_1285.Invoke_O__O(arg_1286) } else { tmp208 = linked_1284.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1283, arg_1286) }; if jrt.J2g_Truth(tmp208) { var c__1927000678__auto____26_3 any; var root_1287 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_1288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1287, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1289 lang.IFn; if linked_1288 == nil { ifn_1289 = lang.IFn_Cast(root_1287) } else { ifn_1289 = nil }; var arg_1290 any = seq_1716000129__25; if linked_1288 == nil { c__1927000678__auto____26_3 = ifn_1289.Invoke_O__O(arg_1290) } else { c__1927000678__auto____26_3 = linked_1288.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1287, arg_1290) }; var tmp209 any; var root_1460 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_1461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1460, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1462 lang.IFn; if linked_1461 == nil { ifn_1462 = lang.IFn_Cast(root_1460) } else { ifn_1462 = nil }; var arg_1463 any = seq_1716000129__25; if linked_1461 == nil { tmp209 = ifn_1462.Invoke_O__O(arg_1463) } else { tmp209 = linked_1461.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1460, arg_1463) }; seq_1716000129__20, chunk_1716000130__21, count_1716000131__22, i_1716000132__23 = tmp209, c__1927000678__auto____26_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____26_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L12 } else { var vec__1716000142__26 any; var root_1291 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1291, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1293 lang.IFn; if linked_1292 == nil { ifn_1293 = lang.IFn_Cast(root_1291) } else { ifn_1293 = nil }; var arg_1294 any = seq_1716000129__25; if linked_1292 == nil { vec__1716000142__26 = ifn_1293.Invoke_O__O(arg_1294) } else { vec__1716000142__26 = linked_1292.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1291, arg_1294) }; var tg__27_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000142__26, lang.RT_IntCast_J__I_NoInit(0), nil); var init__28 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000142__26, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp210 any; var and__1927000168__auto____29_3 any; var root_1464 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_1465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1464, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1466 lang.IFn
														if linked_1465 == nil { ifn_1466 = lang.IFn_Cast(root_1464) } else { ifn_1466 = nil }; var arg_1467 any = tg__27_2; if linked_1465 == nil { and__1927000168__auto____29_3 = ifn_1466.Invoke_O__O(arg_1467) } else { and__1927000168__auto____29_3 = linked_1465.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1464, arg_1467) }; if jrt.J2g_Truth(and__1927000168__auto____29_3) { var tmp211 any = A_arbace_j2g_jrt_A_const_71; var tmp212 any; var root_1468 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1468, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1470 lang.IFn; if linked_1469 == nil { ifn_1470 = lang.IFn_Cast(root_1468) } else { ifn_1470 = nil }; var arg_1471 any = tg__27_2; if linked_1469 == nil { tmp212 = ifn_1470.Invoke_O__O(arg_1471) } else { tmp212 = linked_1469.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1468, arg_1471) }; tmp210 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp211, tmp212)).Ref() } else { tmp210 = and__1927000168__auto____29_3 }; if jrt.J2g_Truth(tmp210) { var seq_1716000145__29 any; var root_1472 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1472, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1474 lang.IFn
															if linked_1473 == nil { ifn_1474 = lang.IFn_Cast(root_1472) } else { ifn_1474 = nil }; var arg_1475 any; var root_1476 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_1477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1476, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1478 lang.IFn; if linked_1477 == nil { ifn_1478 = lang.IFn_Cast(root_1476) } else { ifn_1478 = nil }; var arg_1479 any = tg__27_2; if linked_1477 == nil { arg_1475 = ifn_1478.Invoke_O__O(arg_1479) } else { arg_1475 = linked_1477.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1476, arg_1479) }; if linked_1473 == nil { seq_1716000145__29 = ifn_1474.Invoke_O__O(arg_1475) } else { seq_1716000145__29 = linked_1473.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1472, arg_1475) }
//line :84:1
															var chunk_1716000146__30 any; var count_1716000147__31 int64 = 0; var i_1716000148__32 int64 = 0; L14: for {
																if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000148__32, count_1716000147__31) { var s__33_3 any = lang.Indexed_Cast(chunk_1716000146__30).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000148__32)); var tmp213 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp214 any; var root_1526 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_1527 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1526, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1528 lang.IFn; if linked_1527 == nil { ifn_1528 = lang.IFn_Cast(root_1526) } else { ifn_1528 = nil }; var arg_1529 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1530 any = A_arbace_j2g_jrt_A_const_42; var arg_1531 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_1532 any; var root_1533 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1533, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1535 lang.IFn; if linked_1534 == nil { ifn_1535 = lang.IFn_Cast(root_1533) } else { ifn_1535 = nil }; var arg_1536 any = s__33_3; if linked_1534 == nil { arg_1532 = ifn_1535.Invoke_O__O(arg_1536) } else { arg_1532 = linked_1534.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1533, arg_1536) }; if linked_1527 == nil { tmp214 = ifn_1528.Invoke_O_O_O_O__O(arg_1529, arg_1530, arg_1531, arg_1532) } else { tmp214 = linked_1527.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1526, arg_1529, arg_1530, arg_1531, arg_1532) }; jrt.NN(tmp213).Reset_O__O(tmp214); seq_1716000145__29, chunk_1716000146__30, count_1716000147__31, i_1716000148__32 = seq_1716000145__29, chunk_1716000146__30, count_1716000147__31, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000148__32); continue L14 } else { var temp__1927000414__auto____33 any; var root_1480 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1480, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1482 lang.IFn; if linked_1481 == nil { ifn_1482 = lang.IFn_Cast(root_1480) } else { ifn_1482 = nil }; var arg_1483 any = seq_1716000145__29; if linked_1481 == nil { temp__1927000414__auto____33 = ifn_1482.Invoke_O__O(arg_1483) } else { temp__1927000414__auto____33 = linked_1481.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1480, arg_1483) }; if jrt.J2g_Truth(temp__1927000414__auto____33) { var seq_1716000145__34 any = temp__1927000414__auto____33; var tmp215 any; var root_1484 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_1485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1484, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1486 lang.IFn; if linked_1485 == nil { ifn_1486 = lang.IFn_Cast(root_1484) } else { ifn_1486 = nil }; var arg_1487 any = seq_1716000145__34; if linked_1485 == nil { tmp215 = ifn_1486.Invoke_O__O(arg_1487) } else { tmp215 = linked_1485.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1484, arg_1487) }; if jrt.J2g_Truth(tmp215) { var c__1927000678__auto____35 any; var root_1488 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_1489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1488, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1490 lang.IFn; if linked_1489 == nil { ifn_1490 = lang.IFn_Cast(root_1488) } else { ifn_1490 = nil }; var arg_1491 any = seq_1716000145__34; if linked_1489 == nil { c__1927000678__auto____35 = ifn_1490.Invoke_O__O(arg_1491) } else { c__1927000678__auto____35 = linked_1489.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1488, arg_1491) }; var tmp216 any; var root_1537 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_1538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1537, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1539 lang.IFn; if linked_1538 == nil { ifn_1539 = lang.IFn_Cast(root_1537) } else { ifn_1539 = nil }; var arg_1540 any = seq_1716000145__34; if linked_1538 == nil { tmp216 = ifn_1539.Invoke_O__O(arg_1540) } else { tmp216 = linked_1538.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1537, arg_1540) }; seq_1716000145__29, chunk_1716000146__30, count_1716000147__31, i_1716000148__32 = tmp216, c__1927000678__auto____35, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____35))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L14 } else { var s__35 any; var root_1492 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1492, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1494 lang.IFn; if linked_1493 == nil { ifn_1494 = lang.IFn_Cast(root_1492) } else { ifn_1494 = nil }; var arg_1495 any = seq_1716000145__34; if linked_1493 == nil { s__35 = ifn_1494.Invoke_O__O(arg_1495) } else { s__35 = linked_1493.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1492, arg_1495) }; var tmp217 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp218 any; var root_1541 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_1542 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1541, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1543 lang.IFn; if linked_1542 == nil { ifn_1543 = lang.IFn_Cast(root_1541) } else { ifn_1543 = nil }; var arg_1544 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1545 any = A_arbace_j2g_jrt_A_const_42; var arg_1546 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_1547 any; var root_1548 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1548, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1550 lang.IFn; if linked_1549 == nil { ifn_1550 = lang.IFn_Cast(root_1548) } else { ifn_1550 = nil }; var arg_1551 any = s__35; if linked_1549 == nil { arg_1547 = ifn_1550.Invoke_O__O(arg_1551) } else { arg_1547 = linked_1549.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1548, arg_1551) }; if linked_1542 == nil { tmp218 = ifn_1543.Invoke_O_O_O_O__O(arg_1544, arg_1545, arg_1546, arg_1547) } else { tmp218 = linked_1542.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1541, arg_1544, arg_1545, arg_1546, arg_1547) }; jrt.NN(tmp217).Reset_O__O(tmp218); var tmp219 any; var root_1552 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_1553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1552, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1554 lang.IFn; if linked_1553 == nil { ifn_1554 = lang.IFn_Cast(root_1552) } else { ifn_1554 = nil }; var arg_1555 any = seq_1716000145__34; if linked_1553 == nil { tmp219 = ifn_1554.Invoke_O__O(arg_1555) } else { tmp219 = linked_1553.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1552, arg_1555) }; seq_1716000145__29, chunk_1716000146__30, count_1716000147__31, i_1716000148__32 = tmp219, nil, 0, 0; continue L14 } } }
//line :84:1
																break L14 } } else {

																	var tmp220 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp221 any; var root_1556 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_1557 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1556, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1558 lang.IFn; if linked_1557 == nil { ifn_1558 = lang.IFn_Cast(root_1556) } else { ifn_1558 = nil }; var arg_1559 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1560 any = A_arbace_j2g_jrt_A_const_42; var arg_1561 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_1562 any; var root_1563 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1563, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1565 lang.IFn; if linked_1564 == nil { ifn_1565 = lang.IFn_Cast(root_1563) } else { ifn_1565 = nil }; var arg_1566 any = tg__27_2; if linked_1564 == nil { arg_1562 = ifn_1565.Invoke_O__O(arg_1566) } else { arg_1562 = linked_1564.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1563, arg_1566) }; if linked_1557 == nil { tmp221 = ifn_1558.Invoke_O_O_O_O__O(arg_1559, arg_1560, arg_1561, arg_1562) } else { tmp221 = linked_1557.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1556, arg_1559, arg_1560, arg_1561, arg_1562) }; jrt.NN(tmp220).Reset_O__O(tmp221)
//line :84:1
																	var temp__1927000414__auto____29_2 any; var root_1496 any = A_arbace_j2g_jrt_A_const_69.GetRawRoot__O(); var linked_1497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1496, A_arbace_j2g_jrt_define_name_A_fn_class); var ifn_1498 lang.IFn


																	if linked_1497 == nil { ifn_1498 = lang.IFn_Cast(root_1496) } else { ifn_1498 = nil }; var arg_1499 any = init__28; if linked_1497 == nil { temp__1927000414__auto____29_2 = ifn_1498.Invoke_O__O(arg_1499) } else { temp__1927000414__auto____29_2 = linked_1497.(*A_arbace_j2g_jrt_define_name_A).Invoke_O_O__O(root_1496, arg_1499) }; if jrt.J2g_Truth(temp__1927000414__auto____29_2) { var map__1716000149__30 any = temp__1927000414__auto____29_2; var map__1716000149__31 any; if lang.ISeq_InstanceOf(map__1716000149__30) { var tmp222 any; var root_1500 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_1501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1500, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1502 lang.IFn; if linked_1501 == nil { ifn_1502 = lang.IFn_Cast(root_1500) } else { ifn_1502 = nil }; var arg_1503 any = map__1716000149__30; if linked_1501 == nil { tmp222 = ifn_1502.Invoke_O__O(arg_1503) } else { tmp222 = linked_1501.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1500, arg_1503) }; if jrt.J2g_Truth(tmp222) { var tmp223 any; var root_1504 any = A_arbace_j2g_jrt_A_const_70.GetRawRoot__O(); var linked_1505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1504, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1506 lang.IFn; if linked_1505 == nil { ifn_1506 = lang.IFn_Cast(root_1504) } else { ifn_1506 = nil }; var arg_1507 any = map__1716000149__30; if linked_1505 == nil { tmp223 = ifn_1506.Invoke_O__O(arg_1507) } else { tmp223 = linked_1505.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1504, arg_1507) }; map__1716000149__31 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp223)).Ref() } else { var tmp224 any; var root_1508 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1508, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1510 lang.IFn; if linked_1509 == nil { ifn_1510 = lang.IFn_Cast(root_1508) } else { ifn_1510 = nil }; var arg_1511 any = map__1716000149__30; if linked_1509 == nil { tmp224 = ifn_1510.Invoke_O__O(arg_1511) } else { tmp224 = linked_1509.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1508, arg_1511) }; if jrt.J2g_Truth(tmp224) { var root_1512 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1512, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1514 lang.IFn; if linked_1513 == nil { ifn_1514 = lang.IFn_Cast(root_1512) } else { ifn_1514 = nil }; var arg_1515 any = map__1716000149__30; if linked_1513 == nil { map__1716000149__31 = ifn_1514.Invoke_O__O(arg_1515) } else { map__1716000149__31 = linked_1513.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1512, arg_1515) } } else { map__1716000149__31 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000149__31 = map__1716000149__30 }; var n__32 any = lang.RT_Get_O_O__O_NoInit(map__1716000149__31, A_arbace_j2g_jrt_A_const_34); var tmp225 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp226 any; var root_1516 any = A_arbace_j2g_jrt_A_const_56.GetRawRoot__O(); var linked_1517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1516, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1518 lang.IFn
																		if linked_1517 == nil { ifn_1518 = lang.IFn_Cast(root_1516) } else { ifn_1518 = nil }; var arg_1519 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1520 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_jrt_A_const_43, n__32); var arg_1521 any; var root_1522 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1522, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1524 lang.IFn; if linked_1523 == nil { ifn_1524 = lang.IFn_Cast(root_1522) } else { ifn_1524 = nil }; var arg_1525 any = tg__27_2; if linked_1523 == nil { arg_1521 = ifn_1524.Invoke_O__O(arg_1525) } else { arg_1521 = linked_1523.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1522, arg_1525) }; if linked_1517 == nil { tmp226 = ifn_1518.Invoke_O_O_O__O(arg_1519, arg_1520, arg_1521) } else { tmp226 = linked_1517.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1516, arg_1519, arg_1520, arg_1521) }; jrt.NN(tmp225).Reset_O__O(tmp226) } }
//line :83:1
														var tmp227 any; var root_1567 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_1568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1567, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1569 lang.IFn; if linked_1568 == nil { ifn_1569 = lang.IFn_Cast(root_1567) } else { ifn_1569 = nil }; var arg_1570 any = seq_1716000129__25; if linked_1568 == nil { tmp227 = ifn_1569.Invoke_O__O(arg_1570) } else { tmp227 = linked_1568.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1567, arg_1570) }; seq_1716000129__20, chunk_1716000130__21, count_1716000131__22, i_1716000132__23 = tmp227, nil, 0, 0; continue L12 } } }
//line :82:1
												break L12 } } else { var vec__1716000151__20 any = more__19_5; var tg__21 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000151__20, lang.RT_IntCast_J__I_NoInit(0), nil); var init__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000151__20, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp228 any; var and__1927000168__auto____23 any; var root_1295 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_1296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1295, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1297 lang.IFn







													if linked_1296 == nil { ifn_1297 = lang.IFn_Cast(root_1295) } else { ifn_1297 = nil }; var arg_1298 any = tg__21; if linked_1296 == nil { and__1927000168__auto____23 = ifn_1297.Invoke_O__O(arg_1298) } else { and__1927000168__auto____23 = linked_1296.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1295, arg_1298) }; if jrt.J2g_Truth(and__1927000168__auto____23) { var tmp229 any = A_arbace_j2g_jrt_A_const_68; var tmp230 any; var root_1299 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1299, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1301 lang.IFn; if linked_1300 == nil { ifn_1301 = lang.IFn_Cast(root_1299) } else { ifn_1301 = nil }; var arg_1302 any = tg__21; if linked_1300 == nil { tmp230 = ifn_1301.Invoke_O__O(arg_1302) } else { tmp230 = linked_1300.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1299, arg_1302) }; tmp228 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp229, tmp230)).Ref() } else { tmp228 = and__1927000168__auto____23 }; if jrt.J2g_Truth(tmp228) { var seq_1716000154__23 any; var root_1303 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1303, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1305 lang.IFn
														if linked_1304 == nil { ifn_1305 = lang.IFn_Cast(root_1303) } else { ifn_1305 = nil }; var arg_1306 any; var root_1307 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_1308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1307, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1309 lang.IFn; if linked_1308 == nil { ifn_1309 = lang.IFn_Cast(root_1307) } else { ifn_1309 = nil }; var arg_1310 any = tg__21; if linked_1308 == nil { arg_1306 = ifn_1309.Invoke_O__O(arg_1310) } else { arg_1306 = linked_1308.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1307, arg_1310) }; if linked_1304 == nil { seq_1716000154__23 = ifn_1305.Invoke_O__O(arg_1306) } else { seq_1716000154__23 = linked_1304.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1303, arg_1306) }
//line :90:1
														var chunk_1716000155__24 any; var count_1716000156__25 int64 = 0; var i_1716000157__26 int64 = 0; L15: for {
															if lang.Numbers_Lt_J_J__Z_NoInit(i_1716000157__26, count_1716000156__25) { var s__27_2 any = lang.Indexed_Cast(chunk_1716000155__24).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1716000157__26)); var tmp231 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp232 any; var root_1571 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_1572 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1571, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1573 lang.IFn; if linked_1572 == nil { ifn_1573 = lang.IFn_Cast(root_1571) } else { ifn_1573 = nil }; var arg_1574 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1575 any = A_arbace_j2g_jrt_A_const_42; var arg_1576 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_1577 any; var root_1578 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1578, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1580 lang.IFn; if linked_1579 == nil { ifn_1580 = lang.IFn_Cast(root_1578) } else { ifn_1580 = nil }; var arg_1581 any = s__27_2; if linked_1579 == nil { arg_1577 = ifn_1580.Invoke_O__O(arg_1581) } else { arg_1577 = linked_1579.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1578, arg_1581) }; if linked_1572 == nil { tmp232 = ifn_1573.Invoke_O_O_O_O__O(arg_1574, arg_1575, arg_1576, arg_1577) } else { tmp232 = linked_1572.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1571, arg_1574, arg_1575, arg_1576, arg_1577) }; jrt.NN(tmp231).Reset_O__O(tmp232); seq_1716000154__23, chunk_1716000155__24, count_1716000156__25, i_1716000157__26 = seq_1716000154__23, chunk_1716000155__24, count_1716000156__25, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1716000157__26); continue L15 } else { var temp__1927000414__auto____27_3 any; var root_1311 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1311, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1313 lang.IFn; if linked_1312 == nil { ifn_1313 = lang.IFn_Cast(root_1311) } else { ifn_1313 = nil }; var arg_1314 any = seq_1716000154__23; if linked_1312 == nil { temp__1927000414__auto____27_3 = ifn_1313.Invoke_O__O(arg_1314) } else { temp__1927000414__auto____27_3 = linked_1312.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1311, arg_1314) }; if jrt.J2g_Truth(temp__1927000414__auto____27_3) { var seq_1716000154__28 any = temp__1927000414__auto____27_3; var tmp233 any; var root_1315 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_1316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1315, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1317 lang.IFn; if linked_1316 == nil { ifn_1317 = lang.IFn_Cast(root_1315) } else { ifn_1317 = nil }; var arg_1318 any = seq_1716000154__28; if linked_1316 == nil { tmp233 = ifn_1317.Invoke_O__O(arg_1318) } else { tmp233 = linked_1316.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1315, arg_1318) }; if jrt.J2g_Truth(tmp233) { var c__1927000678__auto____29 any; var root_1319 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_1320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1319, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1321 lang.IFn; if linked_1320 == nil { ifn_1321 = lang.IFn_Cast(root_1319) } else { ifn_1321 = nil }; var arg_1322 any = seq_1716000154__28; if linked_1320 == nil { c__1927000678__auto____29 = ifn_1321.Invoke_O__O(arg_1322) } else { c__1927000678__auto____29 = linked_1320.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1319, arg_1322) }; var tmp234 any; var root_1582 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_1583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1582, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1584 lang.IFn; if linked_1583 == nil { ifn_1584 = lang.IFn_Cast(root_1582) } else { ifn_1584 = nil }; var arg_1585 any = seq_1716000154__28; if linked_1583 == nil { tmp234 = ifn_1584.Invoke_O__O(arg_1585) } else { tmp234 = linked_1583.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1582, arg_1585) }; seq_1716000154__23, chunk_1716000155__24, count_1716000156__25, i_1716000157__26 = tmp234, c__1927000678__auto____29, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____29))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L15 } else { var s__29_2 any; var root_1323 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1323, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1325 lang.IFn; if linked_1324 == nil { ifn_1325 = lang.IFn_Cast(root_1323) } else { ifn_1325 = nil }; var arg_1326 any = seq_1716000154__28; if linked_1324 == nil { s__29_2 = ifn_1325.Invoke_O__O(arg_1326) } else { s__29_2 = linked_1324.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1323, arg_1326) }; var tmp235 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp236 any; var root_1586 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_1587 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1586, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1588 lang.IFn; if linked_1587 == nil { ifn_1588 = lang.IFn_Cast(root_1586) } else { ifn_1588 = nil }; var arg_1589 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1590 any = A_arbace_j2g_jrt_A_const_42; var arg_1591 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_1592 any; var root_1593 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1593, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1595 lang.IFn; if linked_1594 == nil { ifn_1595 = lang.IFn_Cast(root_1593) } else { ifn_1595 = nil }; var arg_1596 any = s__29_2; if linked_1594 == nil { arg_1592 = ifn_1595.Invoke_O__O(arg_1596) } else { arg_1592 = linked_1594.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1593, arg_1596) }; if linked_1587 == nil { tmp236 = ifn_1588.Invoke_O_O_O_O__O(arg_1589, arg_1590, arg_1591, arg_1592) } else { tmp236 = linked_1587.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1586, arg_1589, arg_1590, arg_1591, arg_1592) }; jrt.NN(tmp235).Reset_O__O(tmp236); var tmp237 any; var root_1597 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_1598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1597, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1599 lang.IFn; if linked_1598 == nil { ifn_1599 = lang.IFn_Cast(root_1597) } else { ifn_1599 = nil }; var arg_1600 any = seq_1716000154__28; if linked_1598 == nil { tmp237 = ifn_1599.Invoke_O__O(arg_1600) } else { tmp237 = linked_1598.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1597, arg_1600) }; seq_1716000154__23, chunk_1716000155__24, count_1716000156__25, i_1716000157__26 = tmp237, nil, 0, 0; continue L15 } } }
//line :90:1
															break L15 } } else {

																var tmp238 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp239 any; var root_1601 any = A_arbace_j2g_jrt_A_const_64.GetRawRoot__O(); var linked_1602 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1601, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1603 lang.IFn; if linked_1602 == nil { ifn_1603 = lang.IFn_Cast(root_1601) } else { ifn_1603 = nil }; var arg_1604 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1605 any = A_arbace_j2g_jrt_A_const_42; var arg_1606 any = A_arbace_j2g_jrt_A_const_10.GetRawRoot__O(); var arg_1607 any; var root_1608 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1608, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1610 lang.IFn; if linked_1609 == nil { ifn_1610 = lang.IFn_Cast(root_1608) } else { ifn_1610 = nil }; var arg_1611 any = tg__21; if linked_1609 == nil { arg_1607 = ifn_1610.Invoke_O__O(arg_1611) } else { arg_1607 = linked_1609.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1608, arg_1611) }; if linked_1602 == nil { tmp239 = ifn_1603.Invoke_O_O_O_O__O(arg_1604, arg_1605, arg_1606, arg_1607) } else { tmp239 = linked_1602.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1601, arg_1604, arg_1605, arg_1606, arg_1607) }; jrt.NN(tmp238).Reset_O__O(tmp239)
//line :90:1
																var temp__1927000414__auto____23 any; var root_1327 any = A_arbace_j2g_jrt_A_const_69.GetRawRoot__O(); var linked_1328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1327, A_arbace_j2g_jrt_define_name_A_fn_class); var ifn_1329 lang.IFn


																if linked_1328 == nil { ifn_1329 = lang.IFn_Cast(root_1327) } else { ifn_1329 = nil }; var arg_1330 any = init__22; if linked_1328 == nil { temp__1927000414__auto____23 = ifn_1329.Invoke_O__O(arg_1330) } else { temp__1927000414__auto____23 = linked_1328.(*A_arbace_j2g_jrt_define_name_A).Invoke_O_O__O(root_1327, arg_1330) }; if jrt.J2g_Truth(temp__1927000414__auto____23) { var map__1716000158__24 any = temp__1927000414__auto____23; var map__1716000158__25 any; if lang.ISeq_InstanceOf(map__1716000158__24) { var tmp240 any; var root_1331 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_1332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1331, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1333 lang.IFn; if linked_1332 == nil { ifn_1333 = lang.IFn_Cast(root_1331) } else { ifn_1333 = nil }; var arg_1334 any = map__1716000158__24; if linked_1332 == nil { tmp240 = ifn_1333.Invoke_O__O(arg_1334) } else { tmp240 = linked_1332.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1331, arg_1334) }; if jrt.J2g_Truth(tmp240) { var tmp241 any; var root_1335 any = A_arbace_j2g_jrt_A_const_70.GetRawRoot__O(); var linked_1336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1335, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1337 lang.IFn; if linked_1336 == nil { ifn_1337 = lang.IFn_Cast(root_1335) } else { ifn_1337 = nil }; var arg_1338 any = map__1716000158__24; if linked_1336 == nil { tmp241 = ifn_1337.Invoke_O__O(arg_1338) } else { tmp241 = linked_1336.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1335, arg_1338) }; map__1716000158__25 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp241)).Ref() } else { var tmp242 any; var root_1339 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1339, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1341 lang.IFn; if linked_1340 == nil { ifn_1341 = lang.IFn_Cast(root_1339) } else { ifn_1341 = nil }; var arg_1342 any = map__1716000158__24; if linked_1340 == nil { tmp242 = ifn_1341.Invoke_O__O(arg_1342) } else { tmp242 = linked_1340.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1339, arg_1342) }; if jrt.J2g_Truth(tmp242) { var root_1343 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1343, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1345 lang.IFn; if linked_1344 == nil { ifn_1345 = lang.IFn_Cast(root_1343) } else { ifn_1345 = nil }; var arg_1346 any = map__1716000158__24; if linked_1344 == nil { map__1716000158__25 = ifn_1345.Invoke_O__O(arg_1346) } else { map__1716000158__25 = linked_1344.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1343, arg_1346) } } else { map__1716000158__25 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000158__25 = map__1716000158__24 }; var n__26 any = lang.RT_Get_O_O__O_NoInit(map__1716000158__25, A_arbace_j2g_jrt_A_const_34); var tmp243 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp244 any; var root_1347 any = A_arbace_j2g_jrt_A_const_56.GetRawRoot__O(); var linked_1348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1347, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1349 lang.IFn
																	if linked_1348 == nil { ifn_1349 = lang.IFn_Cast(root_1347) } else { ifn_1349 = nil }; var arg_1350 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var arg_1351 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_jrt_A_const_43, n__26); var arg_1352 any; var root_1353 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1353, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1355 lang.IFn; if linked_1354 == nil { ifn_1355 = lang.IFn_Cast(root_1353) } else { ifn_1355 = nil }; var arg_1356 any = tg__21; if linked_1354 == nil { arg_1352 = ifn_1355.Invoke_O__O(arg_1356) } else { arg_1352 = linked_1354.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1353, arg_1356) }; if linked_1348 == nil { tmp244 = ifn_1349.Invoke_O_O_O__O(arg_1350, arg_1351, arg_1352) } else { tmp244 = linked_1348.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1347, arg_1350, arg_1351, arg_1352) }; jrt.NN(tmp243).Reset_O__O(tmp244) } } }
//line :54:1
										break L9 }; default:}}
//line :51:1
						var tmp245 any; var root_1612 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_1613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1612, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1614 lang.IFn; if linked_1613 == nil { ifn_1614 = lang.IFn_Cast(root_1612) } else { ifn_1614 = nil }; var arg_1615 any = seq_1716000022__9; if linked_1613 == nil { tmp245 = ifn_1614.Invoke_O__O(arg_1615) } else { tmp245 = linked_1613.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1612, arg_1615) }; seq_1716000022__4, chunk_1716000023__5, count_1716000024__6, i_1716000025__7 = tmp245, nil, 0, 0; continue L1 } else { var tmp246 any; var root_1616 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_1617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1616, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1618 lang.IFn; if linked_1617 == nil { ifn_1618 = lang.IFn_Cast(root_1616) } else { ifn_1618 = nil }; var arg_1619 any = seq_1716000022__9; if linked_1617 == nil { tmp246 = ifn_1618.Invoke_O__O(arg_1619) } else { tmp246 = linked_1617.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1616, arg_1619) }; seq_1716000022__4, chunk_1716000023__5, count_1716000024__6, i_1716000025__7 = tmp246, nil, 0, 0; continue L1 } } } }
//line :45:1
		break L1 }; var root_188 any =



	A_arbace_j2g_jrt_A_const_8.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = acc__3; if linked_189 == nil { return ifn_190.Invoke_O__O(arg_191) } else { return linked_189.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_188, arg_191) } }





















































func A_arbace_j2g_jrt_interface_elems_A_New() *A_arbace_j2g_jrt_interface_elems_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_interface_elems_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_j2g_jrt_interface_elems_A) Ctor() {}
//line :103:1
func (t *A_arbace_j2g_jrt_interface_elems_A) Invoke_O_O__O(self, tf__0 any) any { var elems__2 any; var root_1620 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_1621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1620, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1622 lang.IFn; if


	linked_1621 == nil { ifn_1622 = lang.IFn_Cast(root_1620) } else { ifn_1622 = nil }; var arg_1623 any = tf__0; if linked_1621 == nil { elems__2 = ifn_1622.Invoke_O__O(arg_1623) } else { elems__2 = linked_1621.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1620, arg_1623) }; var tmp1 any = A_arbace_j2g_jrt_A_const_40; var tmp2 any; var root_1624 any = /*line :103:1*/A_arbace_j2g_jrt_A_const_72.GetRawRoot__O(); var linked_1625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1624, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1626 lang.IFn; if



	linked_1625 == nil { ifn_1626 = lang.IFn_Cast(root_1624) } else { ifn_1626 = nil }; var arg_1627 any; var iter__1927001039__auto____3 any; var tmp3 any = A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A_New(); var tmp4 *jrt.Class; var fncls__1756 *jrt.Class = A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A_fn_class; if fncls__1756 == nil { var fncls__1756d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A_fn_class = fncls__1756d; tmp4 = fncls__1756d } else { tmp4 = fncls__1756 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); arg_1627 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(elems__2); if linked_1625 == nil { tmp2 = ifn_1626.Invoke_O__O(arg_1627) } else { tmp2 = linked_1625.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1624, arg_1627) }; var tmp5 any = tmp2; var tmp6 any = A_arbace_j2g_jrt_A_const_79; var tmp7 any; var root_1757 any = /*line :103:1*/A_arbace_j2g_jrt_A_const_80.GetRawRoot__O(); var linked_1758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1757, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1759 lang.IFn; if





	linked_1758 == nil { ifn_1759 = lang.IFn_Cast(root_1757) } else { ifn_1759 = nil }; var arg_1760 any; var iter__1927001039__auto____3_2 any; var tmp8 any = A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A_New(); var tmp9 *jrt.Class; var fncls__1839 *jrt.Class = A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A_fn_class; if fncls__1839 == nil { var fncls__1839d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A_fn_class = fncls__1839d; tmp9 = fncls__1839d } else { tmp9 = fncls__1839 }; iter__1927001039__auto____3_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); arg_1760 = lang.IFn_Cast(iter__1927001039__auto____3_2).Invoke_O__O(elems__2); if linked_1758 == nil { tmp7 = ifn_1759.Invoke_O__O(arg_1760) } else { tmp7 = linked_1758.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1757, arg_1760) }; return /*line :103:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp5, tmp6, tmp7)) }



func A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A_New() *A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A) Ctor() {}
//line :107:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A) Invoke_O_O__O(self, s__1716000162__1 any) any { var tmp1 any = A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A_New_O_O(s__1716000162__1, self); var tmp2 *jrt.Class; var fncls__1755 *jrt.Class = A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A_fn_class; if fncls__1755 == nil { var fncls__1755d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A_fn_class = fncls__1755d; tmp2 = fncls__1755d } else { tmp2 = fncls__1755 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :107:1
func A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A_New_O_O(p0, p1 any) *A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A{}; t.Ctor_O_O(p0, p1); return t }
//line :107:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A) Ctor_O_O(c__s__1716000162, c__iter__1716000161 any) { t.F_s__1716000162 = c__s__1716000162; t.F_iter__1716000161 = c__iter__1716000161 }
//line :107:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A) Invoke_O__O(self any) any { { var s__1716000162__1 any; var t_ any = t.F_s__1716000162; t.F_s__1716000162 = nil; s__1716000162__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1628 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1628, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1630 lang.IFn; if linked_1629 == nil { ifn_1630 = lang.IFn_Cast(root_1628) } else { ifn_1630 = nil }; var arg_1631 any = s__1716000162__1; if linked_1629 == nil { temp__1927000414__auto____2 = ifn_1630.Invoke_O__O(arg_1631) } else { temp__1927000414__auto____2 = linked_1629.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1628, arg_1631) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1716000162__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1632 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_1633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1632, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1634 lang.IFn; if linked_1633 == nil { ifn_1634 = lang.IFn_Cast(root_1632) } else { ifn_1634 = nil }; var arg_1635 any = s__1716000162__3; if linked_1633 == nil { tmp1 = ifn_1634.Invoke_O__O(arg_1635) } else { tmp1 = linked_1633.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1632, arg_1635) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1636 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_1637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1636, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1638 lang.IFn; if linked_1637 == nil { ifn_1638 = lang.IFn_Cast(root_1636) } else { ifn_1638 = nil }; var arg_1639 any = s__1716000162__3; if linked_1637 == nil { c__1927001037__auto____4 = ifn_1638.Invoke_O__O(arg_1639) } else { c__1927001037__auto____4 = linked_1637.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1636, arg_1639) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1716000164__6 any; var root_1640 any = A_arbace_j2g_jrt_A_const_73.GetRawRoot__O(); var linked_1641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1640, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1642 lang.IFn; if linked_1641 == nil { ifn_1642 = lang.IFn_Cast(root_1640) } else { ifn_1642 = nil }; var arg_1643 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1641 == nil { b__1716000164__6 = ifn_1642.Invoke_O__O(arg_1643) } else { b__1716000164__6 = linked_1641.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1640, arg_1643) }; var tmp2 any = A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A_New_O_I_O(b__1716000164__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1682 *jrt.Class = A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A_fn_class; if fncls__1682 == nil { var fncls__1682d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A_fn_class = fncls__1682d; tmp3 = fncls__1682d } else { tmp3 = fncls__1682 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1683 any = A_arbace_j2g_jrt_A_const_76.GetRawRoot__O(); var linked_1684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1683, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1685 lang.IFn; if linked_1684 == nil { ifn_1685 = lang.IFn_Cast(root_1683) } else { ifn_1685 = nil }; var arg_1686 any; var root_1688 any = A_arbace_j2g_jrt_A_const_77.GetRawRoot__O(); var linked_1689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1688, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1690 lang.IFn; if linked_1689 == nil { ifn_1690 = lang.IFn_Cast(root_1688) } else { ifn_1690 = nil }; var arg_1691 any = b__1716000164__6; if linked_1689 == nil { arg_1686 = ifn_1690.Invoke_O__O(arg_1691) } else { arg_1686 = linked_1689.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1688, arg_1691) }; var arg_1687 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1716000161); var tmp5 any; var root_1692 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_1693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1692, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1694 lang.IFn; if linked_1693 == nil { ifn_1694 = lang.IFn_Cast(root_1692) } else { ifn_1694 = nil }; var arg_1695 any = s__1716000162__3; if linked_1693 == nil { tmp5 = ifn_1694.Invoke_O__O(arg_1695) } else { tmp5 = linked_1693.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1692, arg_1695) }; arg_1687 = tmp4.Invoke_O__O(tmp5); if linked_1684 == nil { return ifn_1685.Invoke_O_O__O(arg_1686, arg_1687) } else { return linked_1684.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1683, arg_1686, arg_1687) } } else { var root_1696 any = A_arbace_j2g_jrt_A_const_76.GetRawRoot__O(); var linked_1697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1696, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1698 lang.IFn; if linked_1697 == nil { ifn_1698 = lang.IFn_Cast(root_1696) } else { ifn_1698 = nil }; var arg_1699 any; var root_1701 any = A_arbace_j2g_jrt_A_const_77.GetRawRoot__O(); var linked_1702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1701, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1703 lang.IFn; if linked_1702 == nil { ifn_1703 = lang.IFn_Cast(root_1701) } else { ifn_1703 = nil }; var arg_1704 any = b__1716000164__6; if linked_1702 == nil { arg_1699 = ifn_1703.Invoke_O__O(arg_1704) } else { arg_1699 = linked_1702.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1701, arg_1704) }; var arg_1700 any; if linked_1697 == nil { return ifn_1698.Invoke_O_O__O(arg_1699, arg_1700) } else { return linked_1697.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1696, arg_1699, arg_1700) } } } else { var e__4 any; var root_1705 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1705, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1707 lang.IFn; if linked_1706 == nil { ifn_1707 = lang.IFn_Cast(root_1705) } else { ifn_1707 = nil }; var arg_1708 any = s__1716000162__3; if linked_1706 == nil { e__4 = ifn_1707.Invoke_O__O(arg_1708) } else { e__4 = linked_1706.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1705, arg_1708) }; var tmp6 any; var and__1927000168__auto____5 any; var root_1709 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_1710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1709, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1711 lang.IFn; if linked_1710 == nil { ifn_1711 = lang.IFn_Cast(root_1709) } else { ifn_1711 = nil }; var arg_1712 any = e__4; if linked_1710 == nil { and__1927000168__auto____5 = ifn_1711.Invoke_O__O(arg_1712) } else { and__1927000168__auto____5 = linked_1710.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1709, arg_1712) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1713 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_1714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1713, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1715 lang.IFn; if linked_1714 == nil { ifn_1715 = lang.IFn_Cast(root_1713) } else { ifn_1715 = nil }; var arg_1716 any; var root_1717 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1717, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1719 lang.IFn; if linked_1718 == nil { ifn_1719 = lang.IFn_Cast(root_1717) } else { ifn_1719 = nil }; var arg_1720 any = e__4; if linked_1718 == nil { arg_1716 = ifn_1719.Invoke_O__O(arg_1720) } else { arg_1716 = linked_1718.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1717, arg_1720) }; if linked_1714 == nil { and__1927000168__auto____6 = ifn_1715.Invoke_O__O(arg_1716) } else { and__1927000168__auto____6 = linked_1714.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1713, arg_1716) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1721 any = A_arbace_j2g_jrt_A_const_55.GetRawRoot__O(); var linked_1722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1721, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1723 lang.IFn; if linked_1722 == nil { ifn_1723 = lang.IFn_Cast(root_1721) } else { ifn_1723 = nil }; var arg_1724 any; var root_1725 any = A_arbace_j2g_jrt_A_const_22.GetRawRoot__O(); var linked_1726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1725, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1727 lang.IFn; if linked_1726 == nil { ifn_1727 = lang.IFn_Cast(root_1725) } else { ifn_1727 = nil }; var arg_1728 any; var root_1729 any = A_arbace_j2g_jrt_A_const_74.GetRawRoot__O(); var linked_1730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1729, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1731 lang.IFn; if linked_1730 == nil { ifn_1731 = lang.IFn_Cast(root_1729) } else { ifn_1731 = nil }; var arg_1732 any = A_arbace_j2g_jrt_A_const_23.GetRawRoot__O(); var arg_1733 any = e__4; if linked_1730 == nil { arg_1728 = ifn_1731.Invoke_O_O__O(arg_1732, arg_1733) } else { arg_1728 = linked_1730.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1729, arg_1732, arg_1733) }; if linked_1726 == nil { arg_1724 = ifn_1727.Invoke_O__O(arg_1728) } else { arg_1724 = linked_1726.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1725, arg_1728) }; if linked_1722 == nil { tmp6 = ifn_1723.Invoke_O__O(arg_1724) } else { tmp6 = linked_1722.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1721, arg_1724) } } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp6) { var root_1734 any = A_arbace_j2g_jrt_A_const_78.GetRawRoot__O(); var linked_1735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1734, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1736 lang.IFn; if linked_1735 == nil { ifn_1736 = lang.IFn_Cast(root_1734) } else { ifn_1736 = nil }; var arg_1737 any; var root_1739 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1739, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1741 lang.IFn
															if linked_1740 == nil { ifn_1741 = lang.IFn_Cast(root_1739) } else { ifn_1741 = nil }; var arg_1742 any; var root_1743 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1743, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1745 lang.IFn; if linked_1744 == nil { ifn_1745 = lang.IFn_Cast(root_1743) } else { ifn_1745 = nil }; var arg_1746 any = e__4; if linked_1744 == nil { arg_1742 = ifn_1745.Invoke_O__O(arg_1746) } else { arg_1742 = linked_1744.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1743, arg_1746) }; if linked_1740 == nil { arg_1737 = ifn_1741.Invoke_O__O(arg_1742) } else { arg_1737 = linked_1740.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1739, arg_1742) }
//line :107:1
	var arg_1738 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1716000161); var tmp8 any; var root_1747 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_1748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1747, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1749 lang.IFn; if linked_1748 == nil { ifn_1749 = lang.IFn_Cast(root_1747) } else { ifn_1749 = nil }; var arg_1750 any = s__1716000162__3; if linked_1748 == nil { tmp8 = ifn_1749.Invoke_O__O(arg_1750) } else { tmp8 = linked_1748.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1747, arg_1750) }; arg_1738 = tmp7.Invoke_O__O(tmp8); if linked_1735 == nil { return ifn_1736.Invoke_O_O__O(arg_1737, arg_1738) } else { return linked_1735.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1734, arg_1737, arg_1738) } } else { var tmp9 any; var root_1751 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_1752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1751, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1753 lang.IFn; if linked_1752 == nil { ifn_1753 = lang.IFn_Cast(root_1751) } else { ifn_1753 = nil }; var arg_1754 any = s__1716000162__3; if linked_1752 == nil { tmp9 = ifn_1753.Invoke_O__O(arg_1754) } else { tmp9 = linked_1752.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1751, arg_1754) }; s__1716000162__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :107:1
func A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :107:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A) Ctor_O_I_O(c__b__1716000164 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1716000164 = c__b__1716000164; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :107:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A) Invoke_O__O(self any) any { { var i__1716000163__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1716000163__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1716000163__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_1644 any = A_arbace_j2g_jrt_A_const_12.GetRawRoot__O(); var linked_1645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1644, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1646 lang.IFn; if linked_1645 == nil { ifn_1646 = lang.IFn_Cast(root_1644) } else { ifn_1646 = nil }; var arg_1647 any = e__2; if linked_1645 == nil { and__1927000168__auto____3 = ifn_1646.Invoke_O__O(arg_1647) } else { and__1927000168__auto____3 = linked_1645.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1644, arg_1647) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_1648 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_1649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1648, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1650 lang.IFn; if linked_1649 == nil { ifn_1650 = lang.IFn_Cast(root_1648) } else { ifn_1650 = nil }; var arg_1651 any; var root_1652 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1652, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1654 lang.IFn; if linked_1653 == nil { ifn_1654 = lang.IFn_Cast(root_1652) } else { ifn_1654 = nil }; var arg_1655 any = e__2; if linked_1653 == nil { arg_1651 = ifn_1654.Invoke_O__O(arg_1655) } else { arg_1651 = linked_1653.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1652, arg_1655) }; if linked_1649 == nil { and__1927000168__auto____4 = ifn_1650.Invoke_O__O(arg_1651) } else { and__1927000168__auto____4 = linked_1649.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1648, arg_1651) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_1656 any = A_arbace_j2g_jrt_A_const_55.GetRawRoot__O(); var linked_1657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1656, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1658 lang.IFn; if linked_1657 == nil { ifn_1658 = lang.IFn_Cast(root_1656) } else { ifn_1658 = nil }; var arg_1659 any; var root_1660 any = A_arbace_j2g_jrt_A_const_22.GetRawRoot__O(); var linked_1661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1660, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1662 lang.IFn; if linked_1661 == nil { ifn_1662 = lang.IFn_Cast(root_1660) } else { ifn_1662 = nil }; var arg_1663 any; var root_1664 any = A_arbace_j2g_jrt_A_const_74.GetRawRoot__O(); var linked_1665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1664, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1666 lang.IFn; if linked_1665 == nil { ifn_1666 = lang.IFn_Cast(root_1664) } else { ifn_1666 = nil }; var arg_1667 any = A_arbace_j2g_jrt_A_const_23.GetRawRoot__O(); var arg_1668 any = e__2; if linked_1665 == nil { arg_1663 = ifn_1666.Invoke_O_O__O(arg_1667, arg_1668) } else { arg_1663 = linked_1665.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1664, arg_1667, arg_1668) }; if linked_1661 == nil { arg_1659 = ifn_1662.Invoke_O__O(arg_1663) } else { arg_1659 = linked_1661.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1660, arg_1663) }; if linked_1657 == nil { tmp2 = ifn_1658.Invoke_O__O(arg_1659) } else { tmp2 = linked_1657.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1656, arg_1659) } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp2) { var root_1669 any = A_arbace_j2g_jrt_A_const_75.GetRawRoot__O(); var linked_1670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1669, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1671 lang.IFn; if linked_1670 == nil { ifn_1671 = lang.IFn_Cast(root_1669) } else { ifn_1671 = nil }; var arg_1672 any = t.F_b__1716000164; var arg_1673 any; var root_1674 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1674, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1676 lang.IFn
																	if linked_1675 == nil { ifn_1676 = lang.IFn_Cast(root_1674) } else { ifn_1676 = nil }; var arg_1677 any; var root_1678 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1678, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1680 lang.IFn; if linked_1679 == nil { ifn_1680 = lang.IFn_Cast(root_1678) } else { ifn_1680 = nil }; var arg_1681 any = e__2; if linked_1679 == nil { arg_1677 = ifn_1680.Invoke_O__O(arg_1681) } else { arg_1677 = linked_1679.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1678, arg_1681) }; if linked_1675 == nil { arg_1673 = ifn_1676.Invoke_O__O(arg_1677) } else { arg_1673 = linked_1675.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1674, arg_1677) }
//line :107:1
	if linked_1670 == nil { ifn_1671.Invoke_O_O__O(arg_1672, arg_1673) } else { linked_1670.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1669, arg_1672, arg_1673) }; i__1716000163__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000163__1); continue L1 } else { i__1716000163__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000163__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A_New() *A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A) Ctor() {}
//line :109:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A) Invoke_O_O__O(self, s__1716000172__1 any) any { var tmp1 any = A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A_New_O_O(s__1716000172__1, self); var tmp2 *jrt.Class; var fncls__1838 *jrt.Class = A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A_fn_class; if fncls__1838 == nil { var fncls__1838d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A_fn_class = fncls__1838d; tmp2 = fncls__1838d } else { tmp2 = fncls__1838 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :109:1
func A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A_New_O_O(p0, p1 any) *A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A{}; t.Ctor_O_O(p0, p1); return t }
//line :109:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A) Ctor_O_O(c__s__1716000172, c__iter__1716000171 any) { t.F_s__1716000172 = c__s__1716000172; t.F_iter__1716000171 = c__iter__1716000171 }
//line :109:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A) Invoke_O__O(self any) any { { var s__1716000172__1 any; var t_ any = t.F_s__1716000172; t.F_s__1716000172 = nil; s__1716000172__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1761 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1761, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1763 lang.IFn; if linked_1762 == nil { ifn_1763 = lang.IFn_Cast(root_1761) } else { ifn_1763 = nil }; var arg_1764 any = s__1716000172__1; if linked_1762 == nil { temp__1927000414__auto____2 = ifn_1763.Invoke_O__O(arg_1764) } else { temp__1927000414__auto____2 = linked_1762.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1761, arg_1764) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1716000172__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1765 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_1766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1765, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1767 lang.IFn; if linked_1766 == nil { ifn_1767 = lang.IFn_Cast(root_1765) } else { ifn_1767 = nil }; var arg_1768 any = s__1716000172__3; if linked_1766 == nil { tmp1 = ifn_1767.Invoke_O__O(arg_1768) } else { tmp1 = linked_1766.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1765, arg_1768) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1769 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_1770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1769, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1771 lang.IFn; if linked_1770 == nil { ifn_1771 = lang.IFn_Cast(root_1769) } else { ifn_1771 = nil }; var arg_1772 any = s__1716000172__3; if linked_1770 == nil { c__1927001037__auto____4 = ifn_1771.Invoke_O__O(arg_1772) } else { c__1927001037__auto____4 = linked_1770.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1769, arg_1772) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1716000174__6 any; var root_1773 any = A_arbace_j2g_jrt_A_const_73.GetRawRoot__O(); var linked_1774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1773, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1775 lang.IFn; if linked_1774 == nil { ifn_1775 = lang.IFn_Cast(root_1773) } else { ifn_1775 = nil }; var arg_1776 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1774 == nil { b__1716000174__6 = ifn_1775.Invoke_O__O(arg_1776) } else { b__1716000174__6 = linked_1774.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1773, arg_1776) }; var tmp2 any = A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A_New_O_I_O(b__1716000174__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1790 *jrt.Class = A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A_fn_class; if fncls__1790 == nil { var fncls__1790d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A_fn_class = fncls__1790d; tmp3 = fncls__1790d } else { tmp3 = fncls__1790 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1791 any = A_arbace_j2g_jrt_A_const_76.GetRawRoot__O(); var linked_1792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1791, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1793 lang.IFn; if linked_1792 == nil { ifn_1793 = lang.IFn_Cast(root_1791) } else { ifn_1793 = nil }; var arg_1794 any; var root_1796 any = A_arbace_j2g_jrt_A_const_77.GetRawRoot__O(); var linked_1797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1796, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1798 lang.IFn; if linked_1797 == nil { ifn_1798 = lang.IFn_Cast(root_1796) } else { ifn_1798 = nil }; var arg_1799 any = b__1716000174__6; if linked_1797 == nil { arg_1794 = ifn_1798.Invoke_O__O(arg_1799) } else { arg_1794 = linked_1797.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1796, arg_1799) }; var arg_1795 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1716000171); var tmp5 any; var root_1800 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_1801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1800, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1802 lang.IFn; if linked_1801 == nil { ifn_1802 = lang.IFn_Cast(root_1800) } else { ifn_1802 = nil }; var arg_1803 any = s__1716000172__3; if linked_1801 == nil { tmp5 = ifn_1802.Invoke_O__O(arg_1803) } else { tmp5 = linked_1801.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1800, arg_1803) }; arg_1795 = tmp4.Invoke_O__O(tmp5); if linked_1792 == nil { return ifn_1793.Invoke_O_O__O(arg_1794, arg_1795) } else { return linked_1792.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1791, arg_1794, arg_1795) } } else { var root_1804 any = A_arbace_j2g_jrt_A_const_76.GetRawRoot__O(); var linked_1805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1804, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1806 lang.IFn; if linked_1805 == nil { ifn_1806 = lang.IFn_Cast(root_1804) } else { ifn_1806 = nil }; var arg_1807 any; var root_1809 any = A_arbace_j2g_jrt_A_const_77.GetRawRoot__O(); var linked_1810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1809, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1811 lang.IFn; if linked_1810 == nil { ifn_1811 = lang.IFn_Cast(root_1809) } else { ifn_1811 = nil }; var arg_1812 any = b__1716000174__6; if linked_1810 == nil { arg_1807 = ifn_1811.Invoke_O__O(arg_1812) } else { arg_1807 = linked_1810.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1809, arg_1812) }; var arg_1808 any; if linked_1805 == nil { return ifn_1806.Invoke_O_O__O(arg_1807, arg_1808) } else { return linked_1805.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1804, arg_1807, arg_1808) } } } else { var e__4 any; var root_1813 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1813, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1815 lang.IFn; if linked_1814 == nil { ifn_1815 = lang.IFn_Cast(root_1813) } else { ifn_1815 = nil }; var arg_1816 any = s__1716000172__3; if linked_1814 == nil { e__4 = ifn_1815.Invoke_O__O(arg_1816) } else { e__4 = linked_1814.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1813, arg_1816) }; var tmp6 any; var root_1817 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_1818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1817, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1819 lang.IFn; if linked_1818 == nil { ifn_1819 = lang.IFn_Cast(root_1817) } else { ifn_1819 = nil }; var arg_1820 any = e__4; if linked_1818 == nil { tmp6 = ifn_1819.Invoke_O__O(arg_1820) } else { tmp6 = linked_1818.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1817, arg_1820) }; if jrt.J2g_Truth(tmp6) { var root_1821 any = A_arbace_j2g_jrt_A_const_78.GetRawRoot__O(); var linked_1822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1821, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1823 lang.IFn; if linked_1822 == nil { ifn_1823 = lang.IFn_Cast(root_1821) } else { ifn_1823 = nil }; var arg_1824 any; var root_1826 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1826, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1828 lang.IFn; if linked_1827 == nil { ifn_1828 = lang.IFn_Cast(root_1826) } else { ifn_1828 = nil }; var arg_1829 any = e__4; if linked_1827 == nil { arg_1824 = ifn_1828.Invoke_O__O(arg_1829) } else { arg_1824 = linked_1827.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1826, arg_1829) }; var arg_1825 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1716000171); var tmp8 any; var root_1830 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_1831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1830, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1832 lang.IFn; if linked_1831 == nil { ifn_1832 = lang.IFn_Cast(root_1830) } else { ifn_1832 = nil }; var arg_1833 any = s__1716000172__3; if linked_1831 == nil { tmp8 = ifn_1832.Invoke_O__O(arg_1833) } else { tmp8 = linked_1831.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1830, arg_1833) }; arg_1825 = tmp7.Invoke_O__O(tmp8); if linked_1822 == nil { return ifn_1823.Invoke_O_O__O(arg_1824, arg_1825) } else { return linked_1822.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1821, arg_1824, arg_1825) } } else { var tmp9 any; var root_1834 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_1835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1834, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1836 lang.IFn; if linked_1835 == nil { ifn_1836 = lang.IFn_Cast(root_1834) } else { ifn_1836 = nil }; var arg_1837 any = s__1716000172__3; if linked_1835 == nil { tmp9 = ifn_1836.Invoke_O__O(arg_1837) } else { tmp9 = linked_1835.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1834, arg_1837) }; s__1716000172__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :109:1
func A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :109:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A) Ctor_O_I_O(c__b__1716000174 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1716000174 = c__b__1716000174; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :109:1
func (t *A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A) Invoke_O__O(self any) any { { var i__1716000173__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1716000173__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1716000173__1)); var tmp2 any; var root_1777 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_1778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1777, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1779 lang.IFn; if linked_1778 == nil { ifn_1779 = lang.IFn_Cast(root_1777) } else { ifn_1779 = nil }; var arg_1780 any = e__2; if linked_1778 == nil { tmp2 = ifn_1779.Invoke_O__O(arg_1780) } else { tmp2 = linked_1778.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1777, arg_1780) }; if jrt.J2g_Truth(tmp2) { var root_1781 any = A_arbace_j2g_jrt_A_const_75.GetRawRoot__O(); var linked_1782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1781, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1783 lang.IFn; if linked_1782 == nil { ifn_1783 = lang.IFn_Cast(root_1781) } else { ifn_1783 = nil }; var arg_1784 any = t.F_b__1716000174; var arg_1785 any; var root_1786 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1786, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1788 lang.IFn; if linked_1787 == nil { ifn_1788 = lang.IFn_Cast(root_1786) } else { ifn_1788 = nil }; var arg_1789 any = e__2; if linked_1787 == nil { arg_1785 = ifn_1788.Invoke_O__O(arg_1789) } else { arg_1785 = linked_1787.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1786, arg_1789) }; if linked_1782 == nil { ifn_1783.Invoke_O_O__O(arg_1784, arg_1785) } else { linked_1782.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1781, arg_1784, arg_1785) }; i__1716000173__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000173__1); continue L1 } else { i__1716000173__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000173__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_jrt_struct_embed_A_New() *A_arbace_j2g_jrt_struct_embed_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_struct_embed_A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_j2g_jrt_struct_embed_A) Ctor() {}
//line :111:1
func (t *A_arbace_j2g_jrt_struct_embed_A) Invoke_O_O__O(self, tf__0 any) any { var f__2 any; var root_1840 any = A_arbace_j2g_jrt_A_const_22.GetRawRoot__O(); var linked_1841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1840, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1842 lang.IFn; if


	linked_1841 == nil { ifn_1842 = lang.IFn_Cast(root_1840) } else { ifn_1842 = nil }; var arg_1843 any = tf__0; if linked_1841 == nil { f__2 = ifn_1842.Invoke_O__O(arg_1843) } else { f__2 = linked_1841.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1840, arg_1843) }; var tmp1 any; var and__1927000168__auto____3 any = f__2; if
	jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_1844 any = A_arbace_j2g_jrt_A_const_13.GetRawRoot__O(); var linked_1845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1844, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1846 lang.IFn; if linked_1845 == nil { ifn_1846 = lang.IFn_Cast(root_1844) } else { ifn_1846 = nil }; var arg_1847 any = f__2; if linked_1845 == nil { and__1927000168__auto____4 = ifn_1846.Invoke_O__O(arg_1847) } else { and__1927000168__auto____4 = linked_1845.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1844, arg_1847) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp2 any; var root_1848 any = A_arbace_j2g_jrt_A_const_19.GetRawRoot__O(); var linked_1849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1848, A_arbace_j2g_jrt_tag_of_A_fn_class); var ifn_1850 lang.IFn; if linked_1849 == nil { ifn_1850 = lang.IFn_Cast(root_1848) } else { ifn_1850 = nil }; var arg_1851 any = f__2; if linked_1849 == nil { tmp2 = ifn_1850.Invoke_O__O(arg_1851) } else { tmp2 = linked_1849.(*A_arbace_j2g_jrt_tag_of_A).Invoke_O_O__O(root_1848, arg_1851) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp2, nil)).Ref() } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { var root_1852 any = A_arbace_j2g_jrt_A_const_15.GetRawRoot__O(); var linked_1853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1852, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1854 lang.IFn; if linked_1853 == nil { ifn_1854 = lang.IFn_Cast(root_1852) } else { ifn_1854 = nil }; var arg_1855 any = f__2; if linked_1853 == nil { return ifn_1854.Invoke_O__O(arg_1855) } else { return linked_1853.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1852, arg_1855) } } else { return nil } }

func A_arbace_j2g_jrt_other_system_QMARK__A_New() *A_arbace_j2g_jrt_other_system_QMARK__A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_other_system_QMARK__A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_j2g_jrt_other_system_QMARK__A) Ctor() {}
//line :117:1
func (t *A_arbace_j2g_jrt_other_system_QMARK__A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 any; var root_1856 any = A_arbace_j2g_jrt_A_const_81.GetRawRoot__O(); var linked_1857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1856, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1858 lang.IFn; if linked_1857 == nil { ifn_1858 = lang.IFn_Cast(root_1856) } else { ifn_1858 = nil }; var arg_1859 any = A_arbace_j2g_jrt_A_const_82; var arg_1860 any = n__0; if linked_1857 == nil { tmp1 = ifn_1858.Invoke_O_O__O(arg_1859, arg_1860) } else { tmp1 = linked_1857.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1856, arg_1859, arg_1860) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}
func A_arbace_j2g_jrt_scan_A_New() *A_arbace_j2g_jrt_scan_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_A{}; t.Ctor(); return t }
//line :123:1
func (t *A_arbace_j2g_jrt_scan_A) Ctor() {}
//line :123:1
func (t *A_arbace_j2g_jrt_scan_A) Invoke_O_O__O(self, dir__0 any) any { var files__2 any; var root_1861 any = A_arbace_j2g_jrt_A_const_83.GetRawRoot__O(); var linked_1862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1861, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1863 lang.IFn; if










	linked_1862 == nil { ifn_1863 = lang.IFn_Cast(root_1861) } else { ifn_1863 = nil }; var arg_1864 any; var tmp1 any = A_arbace_j2g_jrt_scan_fn__1716000186_A_New(); var tmp2 *jrt.Class; var fncls__1866 *jrt.Class = A_arbace_j2g_jrt_scan_fn__1716000186_A_fn_class; if fncls__1866 == nil { var fncls__1866d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_j2g_jrt_scan_fn__1716000186_A_fn_class = fncls__1866d; tmp2 = fncls__1866d } else { tmp2 = fncls__1866 }; arg_1864 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1865 any; var root_1867 any = A_arbace_j2g_jrt_A_const_84.GetRawRoot__O(); var linked_1868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1867, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1869 lang.IFn; if /*line :131:1*/ linked_1868 == nil { ifn_1869 = lang.IFn_Cast(root_1867) } else { ifn_1869 = nil }; var arg_1870 any; var tmp3 any = A_arbace_j2g_jrt_scan_fn__1716000188_A_New(); var tmp4 *jrt.Class; var fncls__1894 *jrt.Class = A_arbace_j2g_jrt_scan_fn__1716000188_A_fn_class; if fncls__1894 == nil { var fncls__1894d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_j2g_jrt_scan_fn__1716000188_A_fn_class = fncls__1894d; tmp4 = fncls__1894d } else { tmp4 = fncls__1894 }; arg_1870 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1871 any; var tmp5 any; var root_1895 any = A_arbace_j2g_jrt_A_const_88.GetRawRoot__O(); var linked_1896 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1895, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1897 lang.IFn; if /*line :130:1*/ linked_1896 == nil { ifn_1897 = lang.IFn_Cast(root_1895) } else { ifn_1897 = nil }; var arg_1898 any = dir__0; if linked_1896 == nil { tmp5 = ifn_1897.Invoke_O__O(arg_1898) } else { tmp5 = linked_1896.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_1895, arg_1898) }; arg_1871 = jrt.NN(jrt.File_Cast(tmp5)).ListFiles__File1().Ref(); if
	linked_1868 == nil { arg_1865 = ifn_1869.Invoke_O_O__O(arg_1870, arg_1871) } else { arg_1865 = linked_1868.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1867, arg_1870, arg_1871) }; if


	linked_1862 == nil { files__2 = ifn_1863.Invoke_O_O__O(arg_1864, arg_1865) } else { files__2 = linked_1862.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1861, arg_1864, arg_1865) }; var scans__3 any; var root_1899 any = /*line :123:1*/A_arbace_j2g_jrt_A_const_89.GetRawRoot__O(); var linked_1900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1899, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1901 lang.IFn; if











	linked_1900 == nil { ifn_1901 = lang.IFn_Cast(root_1899) } else { ifn_1901 = nil }; var arg_1902 any = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_90.GetRawRoot__O()).Invoke__O(); var arg_1903 any; var iter__1927001039__auto____3 any; var tmp6 any = A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A_New(); var tmp7 *jrt.Class; var fncls__1973 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A_fn_class; if fncls__1973 == nil { var fncls__1973d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A_fn_class = fncls__1973d; tmp7 = fncls__1973d } else { tmp7 = fncls__1973 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); arg_1903 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(files__2); if linked_1900 == nil { scans__3 = ifn_1901.Invoke_O_O__O(arg_1902, arg_1903) } else { scans__3 = linked_1900.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1899, arg_1902, arg_1903) }; var types__4 any; var root_1974 any = /*line :123:1*/A_arbace_j2g_jrt_A_const_28.GetRawRoot__O(); var linked_1975 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1974, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1976 lang.IFn; if












	linked_1975 == nil { ifn_1976 = lang.IFn_Cast(root_1974) } else { ifn_1976 = nil }; var arg_1977 any = A_arbace_j2g_jrt_A_const_92.GetRawRoot__O(); var arg_1978 any; var root_1979 any = A_arbace_j2g_jrt_A_const_93.GetRawRoot__O(); var linked_1980 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1979, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1981 lang.IFn; if linked_1980 == nil { ifn_1981 = lang.IFn_Cast(root_1979) } else { ifn_1981 = nil }; var arg_1982 any = A_arbace_j2g_jrt_A_const_39; var arg_1983 any; var root_1984 any = A_arbace_j2g_jrt_A_const_94.GetRawRoot__O(); var linked_1985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1984, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_1986 lang.IFn; if linked_1985 == nil { ifn_1986 = lang.IFn_Cast(root_1984) } else { ifn_1986 = nil }; var arg_1987 any = scans__3; if linked_1985 == nil { arg_1983 = ifn_1986.Invoke_O__O(arg_1987) } else { arg_1983 = linked_1985.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_1984, arg_1987) }; if linked_1980 == nil { arg_1978 = ifn_1981.Invoke_O_O__O(arg_1982, arg_1983) } else { arg_1978 = linked_1980.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1979, arg_1982, arg_1983) }; if linked_1975 == nil { types__4 = ifn_1976.Invoke_O_O__O(arg_1977, arg_1978) } else { types__4 = linked_1975.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1974, arg_1977, arg_1978) }; var methods__5 any; var root_1988 any = /*line :123:1*/A_arbace_j2g_jrt_A_const_28.GetRawRoot__O(); var linked_1989 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1988, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1990 lang.IFn; if













	linked_1989 == nil { ifn_1990 = lang.IFn_Cast(root_1988) } else { ifn_1990 = nil }; var arg_1991 any = A_arbace_j2g_jrt_A_const_95.GetRawRoot__O(); var arg_1992 any = A_arbace_j2g_jrt_A_const_89.GetRawRoot__O(); var arg_1993 any; var root_1994 any = A_arbace_j2g_jrt_A_const_93.GetRawRoot__O(); var linked_1995 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1994, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1996 lang.IFn; if linked_1995 == nil { ifn_1996 = lang.IFn_Cast(root_1994) } else { ifn_1996 = nil }; var arg_1997 any = A_arbace_j2g_jrt_A_const_40; var arg_1998 any; var root_1999 any = A_arbace_j2g_jrt_A_const_94.GetRawRoot__O(); var linked_2000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1999, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_2001 lang.IFn; if linked_2000 == nil { ifn_2001 = lang.IFn_Cast(root_1999) } else { ifn_2001 = nil }; var arg_2002 any = scans__3; if linked_2000 == nil { arg_1998 = ifn_2001.Invoke_O__O(arg_2002) } else { arg_1998 = linked_2000.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_1999, arg_2002) }; if linked_1995 == nil { arg_1993 = ifn_1996.Invoke_O_O__O(arg_1997, arg_1998) } else { arg_1993 = linked_1995.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1994, arg_1997, arg_1998) }; if linked_1989 == nil { methods__5 = ifn_1990.Invoke_O_O_O__O(arg_1991, arg_1992, arg_1993) } else { methods__5 = linked_1989.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_1988, arg_1991, arg_1992, arg_1993) }; var tmp8 any = A_arbace_j2g_jrt_A_const_96; var tmp9 any = A_arbace_j2g_jrt_A_const_39; var tmp10 any = A_arbace_j2g_jrt_A_const_40; var tmp11 any = A_arbace_j2g_jrt_A_const_41; var tmp12 any; var root_2003 any = /*line :123:1*/A_arbace_j2g_jrt_A_const_28.GetRawRoot__O(); var linked_2004 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2003, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2005 lang.IFn; if

















	linked_2004 == nil { ifn_2005 = lang.IFn_Cast(root_2003) } else { ifn_2005 = nil }; var arg_2006 any = A_arbace_j2g_jrt_A_const_97.GetRawRoot__O(); var arg_2007 any; var root_2008 any = A_arbace_j2g_jrt_A_const_93.GetRawRoot__O(); var linked_2009 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2008, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2010 lang.IFn; if linked_2009 == nil { ifn_2010 = lang.IFn_Cast(root_2008) } else { ifn_2010 = nil }; var arg_2011 any = A_arbace_j2g_jrt_A_const_41; var arg_2012 any; var root_2013 any = A_arbace_j2g_jrt_A_const_94.GetRawRoot__O(); var linked_2014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2013, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_2015 lang.IFn; if linked_2014 == nil { ifn_2015 = lang.IFn_Cast(root_2013) } else { ifn_2015 = nil }; var arg_2016 any = scans__3; if linked_2014 == nil { arg_2012 = ifn_2015.Invoke_O__O(arg_2016) } else { arg_2012 = linked_2014.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_2013, arg_2016) }; if linked_2009 == nil { arg_2007 = ifn_2010.Invoke_O_O__O(arg_2011, arg_2012) } else { arg_2007 = linked_2009.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2008, arg_2011, arg_2012) }; if linked_2004 == nil { tmp12 = ifn_2005.Invoke_O_O__O(arg_2006, arg_2007) } else { tmp12 = linked_2004.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2003, arg_2006, arg_2007) }; var tmp13 any = tmp12; var tmp14 any = A_arbace_j2g_jrt_A_const_42; var tmp15 any; var root_2017 any = /*line :123:1*/A_arbace_j2g_jrt_A_const_28.GetRawRoot__O(); var linked_2018 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2017, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2019 lang.IFn; if


















	linked_2018 == nil { ifn_2019 = lang.IFn_Cast(root_2017) } else { ifn_2019 = nil }; var arg_2020 any = A_arbace_j2g_jrt_A_const_97.GetRawRoot__O(); var arg_2021 any; var root_2022 any = A_arbace_j2g_jrt_A_const_93.GetRawRoot__O(); var linked_2023 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2022, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2024 lang.IFn; if linked_2023 == nil { ifn_2024 = lang.IFn_Cast(root_2022) } else { ifn_2024 = nil }; var arg_2025 any = A_arbace_j2g_jrt_A_const_42; var arg_2026 any; var root_2027 any = A_arbace_j2g_jrt_A_const_94.GetRawRoot__O(); var linked_2028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2027, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_2029 lang.IFn; if linked_2028 == nil { ifn_2029 = lang.IFn_Cast(root_2027) } else { ifn_2029 = nil }; var arg_2030 any = scans__3; if linked_2028 == nil { arg_2026 = ifn_2029.Invoke_O__O(arg_2030) } else { arg_2026 = linked_2028.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_2027, arg_2030) }; if linked_2023 == nil { arg_2021 = ifn_2024.Invoke_O_O__O(arg_2025, arg_2026) } else { arg_2021 = linked_2023.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2022, arg_2025, arg_2026) }; if linked_2018 == nil { tmp15 = ifn_2019.Invoke_O_O__O(arg_2020, arg_2021) } else { tmp15 = linked_2018.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2017, arg_2020, arg_2021) }; var tmp16 any = tmp15; var tmp17 any = A_arbace_j2g_jrt_A_const_44; var tmp18 any; var root_2031 any = /*line :123:1*/A_arbace_j2g_jrt_A_const_28.GetRawRoot__O(); var linked_2032 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2031, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2033 lang.IFn; if



















	linked_2032 == nil { ifn_2033 = lang.IFn_Cast(root_2031) } else { ifn_2033 = nil }; var arg_2034 any = A_arbace_j2g_jrt_A_const_97.GetRawRoot__O(); var arg_2035 any; var root_2036 any = A_arbace_j2g_jrt_A_const_93.GetRawRoot__O(); var linked_2037 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2036, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2038 lang.IFn; if linked_2037 == nil { ifn_2038 = lang.IFn_Cast(root_2036) } else { ifn_2038 = nil }; var arg_2039 any = A_arbace_j2g_jrt_A_const_44; var arg_2040 any; var root_2041 any = A_arbace_j2g_jrt_A_const_94.GetRawRoot__O(); var linked_2042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2041, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_2043 lang.IFn; if linked_2042 == nil { ifn_2043 = lang.IFn_Cast(root_2041) } else { ifn_2043 = nil }; var arg_2044 any = scans__3; if linked_2042 == nil { arg_2040 = ifn_2043.Invoke_O__O(arg_2044) } else { arg_2040 = linked_2042.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_2041, arg_2044) }; if linked_2037 == nil { arg_2035 = ifn_2038.Invoke_O_O__O(arg_2039, arg_2040) } else { arg_2035 = linked_2037.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2036, arg_2039, arg_2040) }; if linked_2032 == nil { tmp18 = ifn_2033.Invoke_O_O__O(arg_2034, arg_2035) } else { tmp18 = linked_2032.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2031, arg_2034, arg_2035) }; var tmp19 any = tmp18; var tmp20 any = A_arbace_j2g_jrt_A_const_43; var tmp21 any; var root_2045 any = /*line :123:1*/A_arbace_j2g_jrt_A_const_89.GetRawRoot__O(); var linked_2046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2045, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2047 lang.IFn; if




















	linked_2046 == nil { ifn_2047 = lang.IFn_Cast(root_2045) } else { ifn_2047 = nil }; var arg_2048 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2049 any; var iter__1927001039__auto____6 any; var tmp22 any = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A_New(); var tmp23 *jrt.Class; var fncls__2157 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A_fn_class; if fncls__2157 == nil { var fncls__2157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A_fn_class = fncls__2157d; tmp23 = fncls__2157d } else { tmp23 = fncls__2157 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); arg_2049 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(scans__3); if linked_2046 == nil { tmp21 = ifn_2047.Invoke_O_O__O(arg_2048, arg_2049) } else { tmp21 = linked_2046.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2045, arg_2048, arg_2049) }; var tmp24 any = tmp21; var tmp25 any = A_arbace_j2g_jrt_A_const_106; var tmp26 any; var root_2158 any = /*line :123:1*/A_arbace_j2g_jrt_A_const_89.GetRawRoot__O(); var linked_2159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2158, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2160 lang.IFn; if
























	linked_2159 == nil { ifn_2160 = lang.IFn_Cast(root_2158) } else { ifn_2160 = nil }; var arg_2161 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2162 any; var iter__1927001039__auto____6_2 any; var tmp27 any = A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A_New(); var tmp28 *jrt.Class; var fncls__2265 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A_fn_class; if fncls__2265 == nil { var fncls__2265d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A_fn_class = fncls__2265d; tmp28 = fncls__2265d } else { tmp28 = fncls__2265 }; iter__1927001039__auto____6_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil); arg_2162 = lang.IFn_Cast(iter__1927001039__auto____6_2).Invoke_O__O(types__4); if linked_2159 == nil { tmp26 = ifn_2160.Invoke_O_O__O(arg_2161, arg_2162) } else { tmp26 = linked_2159.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2158, arg_2161, arg_2162) }; var tmp29 any = tmp26; var tmp30 any = A_arbace_j2g_jrt_A_const_79; var tmp31 any; var root_2266 any = /*line :123:1*/A_arbace_j2g_jrt_A_const_89.GetRawRoot__O(); var linked_2267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2266, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2268 lang.IFn; if


























	linked_2267 == nil { ifn_2268 = lang.IFn_Cast(root_2266) } else { ifn_2268 = nil }; var arg_2269 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2270 any; var iter__1927001039__auto____6_3 any; var tmp32 any = A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A_New(); var tmp33 *jrt.Class; var fncls__2377 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A_fn_class; if fncls__2377 == nil { var fncls__2377d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A_fn_class = fncls__2377d; tmp33 = fncls__2377d } else { tmp33 = fncls__2377 }; iter__1927001039__auto____6_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp32, tmp33, nil); arg_2270 = lang.IFn_Cast(iter__1927001039__auto____6_3).Invoke_O__O(types__4); if linked_2267 == nil { tmp31 = ifn_2268.Invoke_O_O__O(arg_2269, arg_2270) } else { tmp31 = linked_2267.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2266, arg_2269, arg_2270) }; return /*line :123:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, scans__3, tmp9, types__4, tmp10, methods__5, tmp11, tmp13, tmp14, tmp16, tmp17, tmp19, tmp20, tmp24, tmp25, tmp29, tmp30, tmp31)) }







func A_arbace_j2g_jrt_scan_fn__1716000188_A_New() *A_arbace_j2g_jrt_scan_fn__1716000188_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_fn__1716000188_A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_j2g_jrt_scan_fn__1716000188_A) Ctor() {}
//line :131:1
func (t *A_arbace_j2g_jrt_scan_fn__1716000188_A) Invoke_O_O__O(self, p1__1716000184_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_1872 any = A_arbace_j2g_jrt_A_const_85.GetRawRoot__O(); var linked_1873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1872, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1874 lang.IFn; if linked_1873 == nil { ifn_1874 = lang.IFn_Cast(root_1872) } else { ifn_1874 = nil }; var arg_1875 any = jrt.NN(jrt.File_Cast(p1__1716000184_SHARP___1)).GetName__String().Ref(); var arg_1876 any = Lit_17; if linked_1873 == nil { and__1927000168__auto____2 = ifn_1874.Invoke_O_O__O(arg_1875, arg_1876) } else { and__1927000168__auto____2 = linked_1873.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1872, arg_1875, arg_1876) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_1877 any = A_arbace_j2g_jrt_A_const_86.GetRawRoot__O(); var linked_1878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1877, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1879 lang.IFn
													if linked_1878 == nil { ifn_1879 = lang.IFn_Cast(root_1877) } else { ifn_1879 = nil }; var arg_1880 any; var root_1881 any = A_arbace_j2g_jrt_A_const_85.GetRawRoot__O(); var linked_1882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1881, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1883 lang.IFn; if linked_1882 == nil { ifn_1883 = lang.IFn_Cast(root_1881) } else { ifn_1883 = nil }; var arg_1884 any = jrt.NN(jrt.File_Cast(p1__1716000184_SHARP___1)).GetName__String().Ref(); var arg_1885 any = Lit_18; if linked_1882 == nil { arg_1880 = ifn_1883.Invoke_O_O__O(arg_1884, arg_1885) } else { arg_1880 = linked_1882.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1881, arg_1884, arg_1885) }; if linked_1878 == nil { and__1927000168__auto____3 = ifn_1879.Invoke_O__O(arg_1880) } else { and__1927000168__auto____3 = linked_1878.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1877, arg_1880) }
//line :131:1
	if jrt.J2g_Truth(and__1927000168__auto____3) {

		var root_1886 any = A_arbace_j2g_jrt_A_const_86.GetRawRoot__O(); var linked_1887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1886, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1888 lang.IFn; if linked_1887 == nil { ifn_1888 = lang.IFn_Cast(root_1886) } else { ifn_1888 = nil }; var arg_1889 any; var root_1890 any = A_arbace_j2g_jrt_A_const_87.GetRawRoot__O(); var linked_1891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1890, A_arbace_j2g_jrt_other_system_QMARK__A_fn_class); var ifn_1892 lang.IFn; if linked_1891 == nil { ifn_1892 = lang.IFn_Cast(root_1890) } else { ifn_1892 = nil }; var arg_1893 any = jrt.NN(jrt.File_Cast(p1__1716000184_SHARP___1)).GetName__String().Ref(); if linked_1891 == nil { arg_1889 = ifn_1892.Invoke_O__O(arg_1893) } else { arg_1889 = linked_1891.(*A_arbace_j2g_jrt_other_system_QMARK__A).Invoke_O_O__O(root_1890, arg_1893) }; if linked_1887 == nil { return ifn_1888.Invoke_O__O(arg_1889) } else { return linked_1887.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1886, arg_1889) } } else {
//line :131:1
			return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }


func A_arbace_j2g_jrt_scan_fn__1716000186_A_New() *A_arbace_j2g_jrt_scan_fn__1716000186_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_fn__1716000186_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_j2g_jrt_scan_fn__1716000186_A) Ctor() {}
//line :134:1
func (t *A_arbace_j2g_jrt_scan_fn__1716000186_A) Invoke_O_O__O(self, p1__1716000185_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__1716000185_SHARP___1)).GetName__String().Ref() }
func A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A_New() *A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A) Ctor() {}
//line :135:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A) Invoke_O_O__O(self, s__1716000191__1 any) any { var tmp1 any = A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A_New_O_O(s__1716000191__1, self); var tmp2 *jrt.Class; var fncls__1972 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A_fn_class; if fncls__1972 == nil { var fncls__1972d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A_fn_class = fncls__1972d; tmp2 = fncls__1972d } else { tmp2 = fncls__1972 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :135:1
func A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A_New_O_O(p0, p1 any) *A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A{}; t.Ctor_O_O(p0, p1); return t }
//line :135:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A) Ctor_O_O(c__s__1716000191, c__iter__1716000190 any) { t.F_s__1716000191 = c__s__1716000191; t.F_iter__1716000190 = c__iter__1716000190 }
//line :135:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A) Invoke_O__O(self any) any { { var s__1716000191__1 any; var t_ any = t.F_s__1716000191; t.F_s__1716000191 = nil; s__1716000191__1 = t_; for { var temp__1927000414__auto____2 any; var root_1907 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_1908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1907, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1909 lang.IFn; if linked_1908 == nil { ifn_1909 = lang.IFn_Cast(root_1907) } else { ifn_1909 = nil }; var arg_1910 any = s__1716000191__1; if linked_1908 == nil { temp__1927000414__auto____2 = ifn_1909.Invoke_O__O(arg_1910) } else { temp__1927000414__auto____2 = linked_1908.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1907, arg_1910) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1716000191__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1911 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_1912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1911, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1913 lang.IFn; if linked_1912 == nil { ifn_1913 = lang.IFn_Cast(root_1911) } else { ifn_1913 = nil }; var arg_1914 any = s__1716000191__3; if linked_1912 == nil { tmp1 = ifn_1913.Invoke_O__O(arg_1914) } else { tmp1 = linked_1912.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1911, arg_1914) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1915 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_1916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1915, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1917 lang.IFn; if linked_1916 == nil { ifn_1917 = lang.IFn_Cast(root_1915) } else { ifn_1917 = nil }; var arg_1918 any = s__1716000191__3; if linked_1916 == nil { c__1927001037__auto____4 = ifn_1917.Invoke_O__O(arg_1918) } else { c__1927001037__auto____4 = linked_1916.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1915, arg_1918) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1716000193__6 any; var root_1919 any = A_arbace_j2g_jrt_A_const_73.GetRawRoot__O(); var linked_1920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1919, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1921 lang.IFn; if linked_1920 == nil { ifn_1921 = lang.IFn_Cast(root_1919) } else { ifn_1921 = nil }; var arg_1922 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1920 == nil { b__1716000193__6 = ifn_1921.Invoke_O__O(arg_1922) } else { b__1716000193__6 = linked_1920.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1919, arg_1922) }; var tmp2 any = A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A_New_O_I_O(b__1716000193__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1932 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A_fn_class; if fncls__1932 == nil { var fncls__1932d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A_fn_class = fncls__1932d; tmp3 = fncls__1932d } else { tmp3 = fncls__1932 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1933 any = A_arbace_j2g_jrt_A_const_76.GetRawRoot__O(); var linked_1934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1933, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1935 lang.IFn; if linked_1934 == nil { ifn_1935 = lang.IFn_Cast(root_1933) } else { ifn_1935 = nil }; var arg_1936 any; var root_1938 any = A_arbace_j2g_jrt_A_const_77.GetRawRoot__O(); var linked_1939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1938, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1940 lang.IFn; if linked_1939 == nil { ifn_1940 = lang.IFn_Cast(root_1938) } else { ifn_1940 = nil }; var arg_1941 any = b__1716000193__6; if linked_1939 == nil { arg_1936 = ifn_1940.Invoke_O__O(arg_1941) } else { arg_1936 = linked_1939.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1938, arg_1941) }; var arg_1937 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1716000190); var tmp5 any; var root_1942 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_1943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1942, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1944 lang.IFn; if linked_1943 == nil { ifn_1944 = lang.IFn_Cast(root_1942) } else { ifn_1944 = nil }; var arg_1945 any = s__1716000191__3; if linked_1943 == nil { tmp5 = ifn_1944.Invoke_O__O(arg_1945) } else { tmp5 = linked_1943.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1942, arg_1945) }; arg_1937 = tmp4.Invoke_O__O(tmp5); if linked_1934 == nil { return ifn_1935.Invoke_O_O__O(arg_1936, arg_1937) } else { return linked_1934.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1933, arg_1936, arg_1937) } } else { var root_1946 any = A_arbace_j2g_jrt_A_const_76.GetRawRoot__O(); var linked_1947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1946, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1948 lang.IFn; if linked_1947 == nil { ifn_1948 = lang.IFn_Cast(root_1946) } else { ifn_1948 = nil }; var arg_1949 any; var root_1951 any = A_arbace_j2g_jrt_A_const_77.GetRawRoot__O(); var linked_1952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1951, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1953 lang.IFn; if linked_1952 == nil { ifn_1953 = lang.IFn_Cast(root_1951) } else { ifn_1953 = nil }; var arg_1954 any = b__1716000193__6; if linked_1952 == nil { arg_1949 = ifn_1953.Invoke_O__O(arg_1954) } else { arg_1949 = linked_1952.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1951, arg_1954) }; var arg_1950 any; if linked_1947 == nil { return ifn_1948.Invoke_O_O__O(arg_1949, arg_1950) } else { return linked_1947.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1946, arg_1949, arg_1950) } } } else { var f__4 any; var root_1955 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_1956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1955, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1957 lang.IFn; if linked_1956 == nil { ifn_1957 = lang.IFn_Cast(root_1955) } else { ifn_1957 = nil }; var arg_1958 any = s__1716000191__3; if linked_1956 == nil { f__4 = ifn_1957.Invoke_O__O(arg_1958) } else { f__4 = linked_1956.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1955, arg_1958) }; var root_1959 any = A_arbace_j2g_jrt_A_const_78.GetRawRoot__O(); var linked_1960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1959, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1961 lang.IFn; if linked_1960 == nil { ifn_1961 = lang.IFn_Cast(root_1959) } else { ifn_1961 = nil }; var arg_1962 any; var tmp6 any = jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(); var tmp7 any; var root_1964 any = A_arbace_j2g_jrt_A_const_91.GetRawRoot__O(); var linked_1965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1964, A_arbace_j2g_jrt_scan_file_A_fn_class); var ifn_1966 lang.IFn; if linked_1965 == nil { ifn_1966 = lang.IFn_Cast(root_1964) } else { ifn_1966 = nil }; var arg_1967 any = f__4; if linked_1965 == nil { tmp7 = ifn_1966.Invoke_O__O(arg_1967) } else { tmp7 = linked_1965.(*A_arbace_j2g_jrt_scan_file_A).Invoke_O_O__O(root_1964, arg_1967) }; arg_1962 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7); var arg_1963 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1716000190); var tmp9 any; var root_1968 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_1969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1968, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1970 lang.IFn; if linked_1969 == nil { ifn_1970 = lang.IFn_Cast(root_1968) } else { ifn_1970 = nil }; var arg_1971 any = s__1716000191__3; if linked_1969 == nil { tmp9 = ifn_1970.Invoke_O__O(arg_1971) } else { tmp9 = linked_1969.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1968, arg_1971) }; arg_1963 = tmp8.Invoke_O__O(tmp9); if linked_1960 == nil { return ifn_1961.Invoke_O_O__O(arg_1962, arg_1963) } else { return linked_1960.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1959, arg_1962, arg_1963) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :135:1
func A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :135:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A) Ctor_O_I_O(c__b__1716000193 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1716000193 = c__b__1716000193; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :135:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A) Invoke_O__O(self any) any { { var i__1716000192__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1716000192__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1716000192__1)); var root_1923 any = A_arbace_j2g_jrt_A_const_75.GetRawRoot__O(); var linked_1924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1923, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1925 lang.IFn; if linked_1924 == nil { ifn_1925 = lang.IFn_Cast(root_1923) } else { ifn_1925 = nil }; var arg_1926 any = t.F_b__1716000193; var arg_1927 any; var tmp2 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var tmp3 any; var root_1928 any = A_arbace_j2g_jrt_A_const_91.GetRawRoot__O(); var linked_1929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1928, A_arbace_j2g_jrt_scan_file_A_fn_class); var ifn_1930 lang.IFn; if linked_1929 == nil { ifn_1930 = lang.IFn_Cast(root_1928) } else { ifn_1930 = nil }; var arg_1931 any = f__2; if linked_1929 == nil { tmp3 = ifn_1930.Invoke_O__O(arg_1931) } else { tmp3 = linked_1929.(*A_arbace_j2g_jrt_scan_file_A).Invoke_O_O__O(root_1928, arg_1931) }; arg_1927 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3); if linked_1924 == nil { ifn_1925.Invoke_O_O__O(arg_1926, arg_1927) } else { linked_1924.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1923, arg_1926, arg_1927) }; i__1716000192__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000192__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A_New() *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A) Ctor() {}
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A) Invoke_O_O__O(self, s__1716000201__1 any) any { var tmp1 any = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A_New_O_O(s__1716000201__1, self); var tmp2 *jrt.Class; var fncls__2156 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A_fn_class; if fncls__2156 == nil { var fncls__2156d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A_fn_class = fncls__2156d; tmp2 = fncls__2156d } else { tmp2 = fncls__2156 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :144:1
func A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A_New_O_O(p0, p1 any) *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A{}; t.Ctor_O_O(p0, p1); return t }
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A) Ctor_O_O(c__s__1716000201, c__iter__1716000200 any) { t.F_s__1716000201 = c__s__1716000201; t.F_iter__1716000200 = c__iter__1716000200 }
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A) Invoke_O__O(self any) any { { var s__1716000201__1 any; var t_ any = t.F_s__1716000201; t.F_s__1716000201 = nil; s__1716000201__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2050 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_2051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2050, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2052 lang.IFn; if linked_2051 == nil { ifn_2052 = lang.IFn_Cast(root_2050) } else { ifn_2052 = nil }; var arg_2053 any = s__1716000201__1; if linked_2051 == nil { temp__1927000414__auto____2 = ifn_2052.Invoke_O__O(arg_2053) } else { temp__1927000414__auto____2 = linked_2051.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2050, arg_2053) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__1716000208__4 any; var root_2054 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_2055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2054, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2056 lang.IFn; if linked_2055 == nil { ifn_2056 = lang.IFn_Cast(root_2054) } else { ifn_2056 = nil }; var arg_2057 any = xs__1927001018__auto____3; if linked_2055 == nil { vec__1716000208__4 = ifn_2056.Invoke_O__O(arg_2057) } else { vec__1716000208__4 = linked_2055.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2054, arg_2057) }; var fname__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000208__4, lang.RT_IntCast_J__I_NoInit(0), nil); var s__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000208__4, lang.RT_IntCast_J__I_NoInit(1), nil); var iterys__1927001035__auto____7 any; var tmp1 any = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A_New_O(fname__5); var tmp2 *jrt.Class; var fncls__2138 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A_fn_class; if fncls__2138 == nil { var fncls__2138d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A_fn_class = fncls__2138d; tmp2 = fncls__2138d } else { tmp2 = fncls__2138 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____8 any; var root_2139 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_2140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2139, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2141 lang.IFn; if linked_2140 == nil { ifn_2141 = lang.IFn_Cast(root_2139) } else { ifn_2141 = nil }; var arg_2142 any = lang.IFn_Cast(iterys__1927001035__auto____7).Invoke_O__O(A_arbace_j2g_jrt_A_const_43.Invoke_O__O(s__6)); if linked_2140 == nil { fs__1927001036__auto____8 = ifn_2141.Invoke_O__O(arg_2142) } else { fs__1927001036__auto____8 = linked_2140.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2139, arg_2142) }; if jrt.J2g_Truth(fs__1927001036__auto____8) { var root_2143 any = A_arbace_j2g_jrt_A_const_105.GetRawRoot__O(); var linked_2144 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2143, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2145 lang.IFn; if linked_2144 == nil { ifn_2145 = lang.IFn_Cast(root_2143) } else { ifn_2145 = nil }; var arg_2146 any = fs__1927001036__auto____8; var arg_2147 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1716000200); var tmp4 any; var root_2148 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_2149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2148, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2150 lang.IFn; if linked_2149 == nil { ifn_2150 = lang.IFn_Cast(root_2148) } else { ifn_2150 = nil }; var arg_2151 any = s__1716000201__1; if linked_2149 == nil { tmp4 = ifn_2150.Invoke_O__O(arg_2151) } else { tmp4 = linked_2149.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2148, arg_2151) }; arg_2147 = tmp3.Invoke_O__O(tmp4); if linked_2144 == nil { return ifn_2145.Invoke_O_O__O(arg_2146, arg_2147) } else { return linked_2144.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2143, arg_2146, arg_2147) } } else { var tmp5 any; var root_2152 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_2153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2152, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2154 lang.IFn; if linked_2153 == nil { ifn_2154 = lang.IFn_Cast(root_2152) } else { ifn_2154 = nil }; var arg_2155 any = s__1716000201__1; if linked_2153 == nil { tmp5 = ifn_2154.Invoke_O__O(arg_2155) } else { tmp5 = linked_2153.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2152, arg_2155) }; s__1716000201__1 = tmp5; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :144:1
func A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A_New_O(p0 any) *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A{}; t.Ctor_O(p0); return t }
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A) Ctor_O(c__fname any) { t.F_fname = c__fname }
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A) Invoke_O_O__O(self, s__1716000203__1 any) any { var tmp1 any = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A_New_O_O_O(s__1716000203__1, self, t.F_fname); var tmp2 *jrt.Class; var fncls__2137 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A_fn_class; if fncls__2137 == nil { var fncls__2137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A_fn_class = fncls__2137d; tmp2 = fncls__2137d } else { tmp2 = fncls__2137 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :144:1
func A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A) Ctor_O_O_O(c__s__1716000203, c__iter__1716000202, c__fname any) { t.F_s__1716000203 = c__s__1716000203; t.F_iter__1716000202 = c__iter__1716000202; t.F_fname = c__fname }
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A) Invoke_O__O(self any) any { { var s__1716000203__1 any; var t_ any = t.F_s__1716000203; t.F_s__1716000203 = nil; s__1716000203__1 = t_; for { var temp__1927000414__auto____2 any; var root_2058 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_2059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2058, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2060 lang.IFn; if linked_2059 == nil { ifn_2060 = lang.IFn_Cast(root_2058) } else { ifn_2060 = nil }; var arg_2061 any = s__1716000203__1; if linked_2059 == nil { temp__1927000414__auto____2 = ifn_2060.Invoke_O__O(arg_2061) } else { temp__1927000414__auto____2 = linked_2059.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2058, arg_2061) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1716000203__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2062 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_2063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2062, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2064 lang.IFn; if linked_2063 == nil { ifn_2064 = lang.IFn_Cast(root_2062) } else { ifn_2064 = nil }; var arg_2065 any = s__1716000203__3; if linked_2063 == nil { tmp1 = ifn_2064.Invoke_O__O(arg_2065) } else { tmp1 = linked_2063.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2062, arg_2065) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2066 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_2067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2066, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2068 lang.IFn; if linked_2067 == nil { ifn_2068 = lang.IFn_Cast(root_2066) } else { ifn_2068 = nil }; var arg_2069 any = s__1716000203__3; if linked_2067 == nil { c__1927001037__auto____4 = ifn_2068.Invoke_O__O(arg_2069) } else { c__1927001037__auto____4 = linked_2067.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2066, arg_2069) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1716000205__6 any; var root_2070 any = A_arbace_j2g_jrt_A_const_73.GetRawRoot__O(); var linked_2071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2070, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2072 lang.IFn; if linked_2071 == nil { ifn_2072 = lang.IFn_Cast(root_2070) } else { ifn_2072 = nil }; var arg_2073 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2071 == nil { b__1716000205__6 = ifn_2072.Invoke_O__O(arg_2073) } else { b__1716000205__6 = linked_2071.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2070, arg_2073) }; var tmp2 any = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A_New_O_O_I_O(t.F_fname, b__1716000205__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2090 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A_fn_class; if fncls__2090 == nil { var fncls__2090d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A_fn_class = fncls__2090d; tmp3 = fncls__2090d } else { tmp3 = fncls__2090 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2091 any = A_arbace_j2g_jrt_A_const_76.GetRawRoot__O(); var linked_2092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2091, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2093 lang.IFn; if linked_2092 == nil { ifn_2093 = lang.IFn_Cast(root_2091) } else { ifn_2093 = nil }; var arg_2094 any; var root_2096 any = A_arbace_j2g_jrt_A_const_77.GetRawRoot__O(); var linked_2097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2096, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2098 lang.IFn; if linked_2097 == nil { ifn_2098 = lang.IFn_Cast(root_2096) } else { ifn_2098 = nil }; var arg_2099 any = b__1716000205__6; if linked_2097 == nil { arg_2094 = ifn_2098.Invoke_O__O(arg_2099) } else { arg_2094 = linked_2097.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2096, arg_2099) }; var arg_2095 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1716000202); var tmp5 any; var root_2100 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_2101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2100, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2102 lang.IFn; if linked_2101 == nil { ifn_2102 = lang.IFn_Cast(root_2100) } else { ifn_2102 = nil }; var arg_2103 any = s__1716000203__3; if linked_2101 == nil { tmp5 = ifn_2102.Invoke_O__O(arg_2103) } else { tmp5 = linked_2101.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2100, arg_2103) }; arg_2095 = tmp4.Invoke_O__O(tmp5); if linked_2092 == nil { return ifn_2093.Invoke_O_O__O(arg_2094, arg_2095) } else { return linked_2092.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2091, arg_2094, arg_2095) } } else { var root_2104 any = A_arbace_j2g_jrt_A_const_76.GetRawRoot__O(); var linked_2105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2104, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2106 lang.IFn; if linked_2105 == nil { ifn_2106 = lang.IFn_Cast(root_2104) } else { ifn_2106 = nil }; var arg_2107 any; var root_2109 any = A_arbace_j2g_jrt_A_const_77.GetRawRoot__O(); var linked_2110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2109, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2111 lang.IFn; if linked_2110 == nil { ifn_2111 = lang.IFn_Cast(root_2109) } else { ifn_2111 = nil }; var arg_2112 any = b__1716000205__6; if linked_2110 == nil { arg_2107 = ifn_2111.Invoke_O__O(arg_2112) } else { arg_2107 = linked_2110.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2109, arg_2112) }; var arg_2108 any; if linked_2105 == nil { return ifn_2106.Invoke_O_O__O(arg_2107, arg_2108) } else { return linked_2105.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2104, arg_2107, arg_2108) } } } else { var vec__1716000218__4 any; var root_2113 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_2114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2113, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2115 lang.IFn; if linked_2114 == nil { ifn_2115 = lang.IFn_Cast(root_2113) } else { ifn_2115 = nil }; var arg_2116 any = s__1716000203__3; if linked_2114 == nil { vec__1716000218__4 = ifn_2115.Invoke_O__O(arg_2116) } else { vec__1716000218__4 = linked_2114.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2113, arg_2116) }; var jn__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000218__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vn__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000218__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2117 any = A_arbace_j2g_jrt_A_const_78.GetRawRoot__O(); var linked_2118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2117, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2119 lang.IFn; if linked_2118 == nil { ifn_2119 = lang.IFn_Cast(root_2117) } else { ifn_2119 = nil }; var arg_2120 any; var tmp6 any = A_arbace_j2g_jrt_A_const_98; var tmp7 any = A_arbace_j2g_jrt_A_const_99; var tmp8 any; var root_2122 any = A_arbace_j2g_jrt_A_const_100.GetRawRoot__O(); var linked_2123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2122, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2124 lang.IFn

	if linked_2123 == nil { ifn_2124 = lang.IFn_Cast(root_2122) } else { ifn_2124 = nil }; var arg_2125 any = vn__6; var arg_2126 any = A_arbace_j2g_jrt_A_const_101; var arg_2127 any = Lit_25; if linked_2123 == nil { tmp8 = ifn_2124.Invoke_O_O_O__O(arg_2125, arg_2126, arg_2127) } else { tmp8 = linked_2123.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2122, arg_2125, arg_2126, arg_2127) }
//line :144:1
	var tmp9 any = tmp8; var tmp10 any = A_arbace_j2g_jrt_A_const_102; var tmp11 any = t.F_fname; var tmp12 any = A_arbace_j2g_jrt_A_const_103; var tmp13 any; var root_2128 any = A_arbace_j2g_jrt_A_const_104.GetRawRoot__O(); var linked_2129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2128, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_2130 lang.IFn


	if linked_2129 == nil { ifn_2130 = lang.IFn_Cast(root_2128) } else { ifn_2130 = nil }; var arg_2131 any = t.F_fname; var arg_2132 any = Lit_26; if linked_2129 == nil { tmp13 = ifn_2130.Invoke_O_O__O(arg_2131, arg_2132) } else { tmp13 = linked_2129.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_2128, arg_2131, arg_2132) }
//line :144:1
	arg_2120 = lang.Tuple_Create_O_O__IPersistentVector(jn__5, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, vn__6, tmp7, tmp9, tmp10, tmp11, tmp12, tmp13))); var arg_2121 any; var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__1716000202); var tmp15 any; var root_2133 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_2134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2133, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2135 lang.IFn; if linked_2134 == nil { ifn_2135 = lang.IFn_Cast(root_2133) } else { ifn_2135 = nil }; var arg_2136 any = s__1716000203__3; if linked_2134 == nil { tmp15 = ifn_2135.Invoke_O__O(arg_2136) } else { tmp15 = linked_2134.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2133, arg_2136) }; arg_2121 = tmp14.Invoke_O__O(tmp15); if linked_2118 == nil { return ifn_2119.Invoke_O_O__O(arg_2120, arg_2121) } else { return linked_2118.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2117, arg_2120, arg_2121) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :144:1
func A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A) Ctor_O_O_I_O(c__fname, c__b__1716000205 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_fname = c__fname; t.F_b__1716000205 = c__b__1716000205; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :144:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A) Invoke_O__O(self any) any { { var i__1716000204__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1716000204__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1716000214__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1716000204__1)); var jn__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000214__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vn__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000214__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2074 any = A_arbace_j2g_jrt_A_const_75.GetRawRoot__O(); var linked_2075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2074, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2076 lang.IFn; if linked_2075 == nil { ifn_2076 = lang.IFn_Cast(root_2074) } else { ifn_2076 = nil }; var arg_2077 any = t.F_b__1716000205; var arg_2078 any; var tmp2 any = A_arbace_j2g_jrt_A_const_98; var tmp3 any = A_arbace_j2g_jrt_A_const_99; var tmp4 any; var root_2079 any = A_arbace_j2g_jrt_A_const_100.GetRawRoot__O(); var linked_2080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2079, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2081 lang.IFn

	if linked_2080 == nil { ifn_2081 = lang.IFn_Cast(root_2079) } else { ifn_2081 = nil }; var arg_2082 any = vn__4; var arg_2083 any = A_arbace_j2g_jrt_A_const_101; var arg_2084 any = Lit_25; if linked_2080 == nil { tmp4 = ifn_2081.Invoke_O_O_O__O(arg_2082, arg_2083, arg_2084) } else { tmp4 = linked_2080.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2079, arg_2082, arg_2083, arg_2084) }
//line :144:1
	var tmp5 any = tmp4; var tmp6 any = A_arbace_j2g_jrt_A_const_102; var tmp7 any = t.F_fname; var tmp8 any = A_arbace_j2g_jrt_A_const_103; var tmp9 any; var root_2085 any = A_arbace_j2g_jrt_A_const_104.GetRawRoot__O(); var linked_2086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2085, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_2087 lang.IFn


	if linked_2086 == nil { ifn_2087 = lang.IFn_Cast(root_2085) } else { ifn_2087 = nil }; var arg_2088 any = t.F_fname; var arg_2089 any = Lit_26; if linked_2086 == nil { tmp9 = ifn_2087.Invoke_O_O__O(arg_2088, arg_2089) } else { tmp9 = linked_2086.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_2085, arg_2088, arg_2089) }
//line :144:1
	arg_2078 = lang.Tuple_Create_O_O__IPersistentVector(jn__3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, vn__4, tmp3, tmp5, tmp6, tmp7, tmp8, tmp9))); if linked_2075 == nil { ifn_2076.Invoke_O_O__O(arg_2077, arg_2078) } else { linked_2075.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2074, arg_2077, arg_2078) }; i__1716000204__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000204__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A_New() *A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A) Ctor() {}
//line :148:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A) Invoke_O_O__O(self, s__1716000226__1 any) any { var tmp1 any = A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A_New_O_O(s__1716000226__1, self); var tmp2 *jrt.Class; var fncls__2264 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A_fn_class; if fncls__2264 == nil { var fncls__2264d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A_fn_class = fncls__2264d; tmp2 = fncls__2264d } else { tmp2 = fncls__2264 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :148:1
func A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A_New_O_O(p0, p1 any) *A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A{}; t.Ctor_O_O(p0, p1); return t }
//line :148:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A) Ctor_O_O(c__s__1716000226, c__iter__1716000225 any) { t.F_s__1716000226 = c__s__1716000226; t.F_iter__1716000225 = c__iter__1716000225 }
//line :148:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A) Invoke_O__O(self any) any { { var s__1716000226__1 any; var t_ any = t.F_s__1716000226; t.F_s__1716000226 = nil; s__1716000226__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2163 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_2164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2163, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2165 lang.IFn; if linked_2164 == nil { ifn_2165 = lang.IFn_Cast(root_2163) } else { ifn_2165 = nil }; var arg_2166 any = s__1716000226__1; if linked_2164 == nil { temp__1927000414__auto____2 = ifn_2165.Invoke_O__O(arg_2166) } else { temp__1927000414__auto____2 = linked_2164.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2163, arg_2166) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1716000226__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2167 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_2168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2167, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2169 lang.IFn; if linked_2168 == nil { ifn_2169 = lang.IFn_Cast(root_2167) } else { ifn_2169 = nil }; var arg_2170 any = s__1716000226__3; if linked_2168 == nil { tmp1 = ifn_2169.Invoke_O__O(arg_2170) } else { tmp1 = linked_2168.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2167, arg_2170) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2171 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_2172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2171, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2173 lang.IFn; if linked_2172 == nil { ifn_2173 = lang.IFn_Cast(root_2171) } else { ifn_2173 = nil }; var arg_2174 any = s__1716000226__3; if linked_2172 == nil { c__1927001037__auto____4 = ifn_2173.Invoke_O__O(arg_2174) } else { c__1927001037__auto____4 = linked_2172.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2171, arg_2174) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1716000228__6 any; var root_2175 any = A_arbace_j2g_jrt_A_const_73.GetRawRoot__O(); var linked_2176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2175, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2177 lang.IFn; if linked_2176 == nil { ifn_2177 = lang.IFn_Cast(root_2175) } else { ifn_2177 = nil }; var arg_2178 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2176 == nil { b__1716000228__6 = ifn_2177.Invoke_O__O(arg_2178) } else { b__1716000228__6 = linked_2176.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2175, arg_2178) }; var tmp2 any = A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A_New_O_I_O(b__1716000228__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2204 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A_fn_class; if fncls__2204 == nil { var fncls__2204d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A_fn_class = fncls__2204d; tmp3 = fncls__2204d } else { tmp3 = fncls__2204 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2205 any = A_arbace_j2g_jrt_A_const_76.GetRawRoot__O(); var linked_2206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2205, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2207 lang.IFn; if linked_2206 == nil { ifn_2207 = lang.IFn_Cast(root_2205) } else { ifn_2207 = nil }; var arg_2208 any; var root_2210 any = A_arbace_j2g_jrt_A_const_77.GetRawRoot__O(); var linked_2211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2210, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2212 lang.IFn; if linked_2211 == nil { ifn_2212 = lang.IFn_Cast(root_2210) } else { ifn_2212 = nil }; var arg_2213 any = b__1716000228__6; if linked_2211 == nil { arg_2208 = ifn_2212.Invoke_O__O(arg_2213) } else { arg_2208 = linked_2211.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2210, arg_2213) }; var arg_2209 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1716000225); var tmp5 any; var root_2214 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_2215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2214, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2216 lang.IFn; if linked_2215 == nil { ifn_2216 = lang.IFn_Cast(root_2214) } else { ifn_2216 = nil }; var arg_2217 any = s__1716000226__3; if linked_2215 == nil { tmp5 = ifn_2216.Invoke_O__O(arg_2217) } else { tmp5 = linked_2215.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2214, arg_2217) }; arg_2209 = tmp4.Invoke_O__O(tmp5); if linked_2206 == nil { return ifn_2207.Invoke_O_O__O(arg_2208, arg_2209) } else { return linked_2206.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2205, arg_2208, arg_2209) } } else { var root_2218 any = A_arbace_j2g_jrt_A_const_76.GetRawRoot__O(); var linked_2219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2218, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2220 lang.IFn; if linked_2219 == nil { ifn_2220 = lang.IFn_Cast(root_2218) } else { ifn_2220 = nil }; var arg_2221 any; var root_2223 any = A_arbace_j2g_jrt_A_const_77.GetRawRoot__O(); var linked_2224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2223, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2225 lang.IFn; if linked_2224 == nil { ifn_2225 = lang.IFn_Cast(root_2223) } else { ifn_2225 = nil }; var arg_2226 any = b__1716000228__6; if linked_2224 == nil { arg_2221 = ifn_2225.Invoke_O__O(arg_2226) } else { arg_2221 = linked_2224.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2223, arg_2226) }; var arg_2222 any; if linked_2219 == nil { return ifn_2220.Invoke_O_O__O(arg_2221, arg_2222) } else { return linked_2219.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2218, arg_2221, arg_2222) } } } else { var vec__1716000238__4 any; var root_2227 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_2228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2227, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2229 lang.IFn; if linked_2228 == nil { ifn_2229 = lang.IFn_Cast(root_2227) } else { ifn_2229 = nil }; var arg_2230 any = s__1716000226__3; if linked_2228 == nil { vec__1716000238__4 = ifn_2229.Invoke_O__O(arg_2230) } else { vec__1716000238__4 = linked_2228.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2227, arg_2230) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000238__4, lang.RT_IntCast_J__I_NoInit(0), nil); var map__1716000241__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000238__4, lang.RT_IntCast_J__I_NoInit(1), nil); var map__1716000241__7 any; if lang.ISeq_InstanceOf(map__1716000241__6) { var tmp6 any; var root_2231 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_2232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2231, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2233 lang.IFn; if linked_2232 == nil { ifn_2233 = lang.IFn_Cast(root_2231) } else { ifn_2233 = nil }; var arg_2234 any = map__1716000241__6; if linked_2232 == nil { tmp6 = ifn_2233.Invoke_O__O(arg_2234) } else { tmp6 = linked_2232.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2231, arg_2234) }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_2235 any = A_arbace_j2g_jrt_A_const_70.GetRawRoot__O(); var linked_2236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2235, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2237 lang.IFn; if linked_2236 == nil { ifn_2237 = lang.IFn_Cast(root_2235) } else { ifn_2237 = nil }; var arg_2238 any = map__1716000241__6; if linked_2236 == nil { tmp7 = ifn_2237.Invoke_O__O(arg_2238) } else { tmp7 = linked_2236.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2235, arg_2238) }; map__1716000241__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp7)).Ref() } else { var tmp8 any; var root_2239 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_2240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2239, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2241 lang.IFn; if linked_2240 == nil { ifn_2241 = lang.IFn_Cast(root_2239) } else { ifn_2241 = nil }; var arg_2242 any = map__1716000241__6; if linked_2240 == nil { tmp8 = ifn_2241.Invoke_O__O(arg_2242) } else { tmp8 = linked_2240.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2239, arg_2242) }; if jrt.J2g_Truth(tmp8) { var root_2243 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_2244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2243, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2245 lang.IFn; if linked_2244 == nil { ifn_2245 = lang.IFn_Cast(root_2243) } else { ifn_2245 = nil }; var arg_2246 any = map__1716000241__6; if linked_2244 == nil { map__1716000241__7 = ifn_2245.Invoke_O__O(arg_2246) } else { map__1716000241__7 = linked_2244.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2243, arg_2246) } } else { map__1716000241__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000241__7 = map__1716000241__6 }; var kind__8 any = lang.RT_Get_O_O__O_NoInit(map__1716000241__7, A_arbace_j2g_jrt_A_const_57); var form__9 any = lang.RT_Get_O_O__O_NoInit(map__1716000241__7, A_arbace_j2g_jrt_A_const_63); if lang.Util_Equiv_O_O__Z_NoInit(kind__8, A_arbace_j2g_jrt_A_const_61) { var root_2247 any = A_arbace_j2g_jrt_A_const_78.GetRawRoot__O(); var linked_2248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2247, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2249 lang.IFn; if linked_2248 == nil { ifn_2249 = lang.IFn_Cast(root_2247) } else { ifn_2249 = nil }; var arg_2250 any; var tmp9 any; var root_2252 any = A_arbace_j2g_jrt_A_const_107.GetRawRoot__O(); var linked_2253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2252, A_arbace_j2g_jrt_interface_elems_A_fn_class); var ifn_2254 lang.IFn
													if linked_2253 == nil { ifn_2254 = lang.IFn_Cast(root_2252) } else { ifn_2254 = nil }; var arg_2255 any = form__9; if linked_2253 == nil { tmp9 = ifn_2254.Invoke_O__O(arg_2255) } else { tmp9 = linked_2253.(*A_arbace_j2g_jrt_interface_elems_A).Invoke_O_O__O(root_2252, arg_2255) }
//line :148:1
	arg_2250 = lang.Tuple_Create_O_O__IPersistentVector(n__5, tmp9); var arg_2251 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__1716000225); var tmp11 any; var root_2256 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_2257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2256, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2258 lang.IFn; if linked_2257 == nil { ifn_2258 = lang.IFn_Cast(root_2256) } else { ifn_2258 = nil }; var arg_2259 any = s__1716000226__3; if linked_2257 == nil { tmp11 = ifn_2258.Invoke_O__O(arg_2259) } else { tmp11 = linked_2257.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2256, arg_2259) }; arg_2251 = tmp10.Invoke_O__O(tmp11); if linked_2248 == nil { return ifn_2249.Invoke_O_O__O(arg_2250, arg_2251) } else { return linked_2248.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2247, arg_2250, arg_2251) } } else { var tmp12 any; var root_2260 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_2261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2260, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2262 lang.IFn; if linked_2261 == nil { ifn_2262 = lang.IFn_Cast(root_2260) } else { ifn_2262 = nil }; var arg_2263 any = s__1716000226__3; if linked_2261 == nil { tmp12 = ifn_2262.Invoke_O__O(arg_2263) } else { tmp12 = linked_2261.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2260, arg_2263) }; s__1716000226__1 = tmp12; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :148:1
func A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :148:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A) Ctor_O_I_O(c__b__1716000228 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1716000228 = c__b__1716000228; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :148:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A) Invoke_O__O(self any) any { { var i__1716000227__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1716000227__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1716000232__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1716000227__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000232__2, lang.RT_IntCast_J__I_NoInit(0), nil); var map__1716000235__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000232__2, lang.RT_IntCast_J__I_NoInit(1), nil); var map__1716000235__5 any; if lang.ISeq_InstanceOf(map__1716000235__4) { var tmp2 any; var root_2179 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_2180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2179, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2181 lang.IFn; if linked_2180 == nil { ifn_2181 = lang.IFn_Cast(root_2179) } else { ifn_2181 = nil }; var arg_2182 any = map__1716000235__4; if linked_2180 == nil { tmp2 = ifn_2181.Invoke_O__O(arg_2182) } else { tmp2 = linked_2180.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2179, arg_2182) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_2183 any = A_arbace_j2g_jrt_A_const_70.GetRawRoot__O(); var linked_2184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2183, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2185 lang.IFn; if linked_2184 == nil { ifn_2185 = lang.IFn_Cast(root_2183) } else { ifn_2185 = nil }; var arg_2186 any = map__1716000235__4; if linked_2184 == nil { tmp3 = ifn_2185.Invoke_O__O(arg_2186) } else { tmp3 = linked_2184.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2183, arg_2186) }; map__1716000235__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp3)).Ref() } else { var tmp4 any; var root_2187 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_2188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2187, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2189 lang.IFn; if linked_2188 == nil { ifn_2189 = lang.IFn_Cast(root_2187) } else { ifn_2189 = nil }; var arg_2190 any = map__1716000235__4; if linked_2188 == nil { tmp4 = ifn_2189.Invoke_O__O(arg_2190) } else { tmp4 = linked_2188.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2187, arg_2190) }; if jrt.J2g_Truth(tmp4) { var root_2191 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_2192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2191, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2193 lang.IFn; if linked_2192 == nil { ifn_2193 = lang.IFn_Cast(root_2191) } else { ifn_2193 = nil }; var arg_2194 any = map__1716000235__4; if linked_2192 == nil { map__1716000235__5 = ifn_2193.Invoke_O__O(arg_2194) } else { map__1716000235__5 = linked_2192.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2191, arg_2194) } } else { map__1716000235__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000235__5 = map__1716000235__4 }; var kind__6 any = lang.RT_Get_O_O__O_NoInit(map__1716000235__5, A_arbace_j2g_jrt_A_const_57); var form__7 any = lang.RT_Get_O_O__O_NoInit(map__1716000235__5, A_arbace_j2g_jrt_A_const_63); if lang.Util_Equiv_O_O__Z_NoInit(kind__6, A_arbace_j2g_jrt_A_const_61) { var root_2195 any = A_arbace_j2g_jrt_A_const_75.GetRawRoot__O(); var linked_2196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2195, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2197 lang.IFn; if linked_2196 == nil { ifn_2197 = lang.IFn_Cast(root_2195) } else { ifn_2197 = nil }; var arg_2198 any = t.F_b__1716000228; var arg_2199 any; var tmp5 any; var root_2200 any = A_arbace_j2g_jrt_A_const_107.GetRawRoot__O(); var linked_2201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2200, A_arbace_j2g_jrt_interface_elems_A_fn_class); var ifn_2202 lang.IFn
															if linked_2201 == nil { ifn_2202 = lang.IFn_Cast(root_2200) } else { ifn_2202 = nil }; var arg_2203 any = form__7; if linked_2201 == nil { tmp5 = ifn_2202.Invoke_O__O(arg_2203) } else { tmp5 = linked_2201.(*A_arbace_j2g_jrt_interface_elems_A).Invoke_O_O__O(root_2200, arg_2203) }
//line :148:1
	arg_2199 = lang.Tuple_Create_O_O__IPersistentVector(n__3, tmp5); if linked_2196 == nil { ifn_2197.Invoke_O_O__O(arg_2198, arg_2199) } else { linked_2196.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2195, arg_2198, arg_2199) }; i__1716000227__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000227__1); continue L1 } else { i__1716000227__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000227__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A_New() *A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A) Ctor() {}
//line :150:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A) Invoke_O_O__O(self, s__1716000246__1 any) any { var tmp1 any = A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A_New_O_O(s__1716000246__1, self); var tmp2 *jrt.Class; var fncls__2376 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A_fn_class; if fncls__2376 == nil { var fncls__2376d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A_fn_class = fncls__2376d; tmp2 = fncls__2376d } else { tmp2 = fncls__2376 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :150:1
func A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A_New_O_O(p0, p1 any) *A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A{}; t.Ctor_O_O(p0, p1); return t }
//line :150:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A) Ctor_O_O(c__s__1716000246, c__iter__1716000245 any) { t.F_s__1716000246 = c__s__1716000246; t.F_iter__1716000245 = c__iter__1716000245 }
//line :150:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A) Invoke_O__O(self any) any { { var s__1716000246__1 any; var t_ any = t.F_s__1716000246; t.F_s__1716000246 = nil; s__1716000246__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2271 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_2272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2271, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2273 lang.IFn; if linked_2272 == nil { ifn_2273 = lang.IFn_Cast(root_2271) } else { ifn_2273 = nil }; var arg_2274 any = s__1716000246__1; if linked_2272 == nil { temp__1927000414__auto____2 = ifn_2273.Invoke_O__O(arg_2274) } else { temp__1927000414__auto____2 = linked_2272.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2271, arg_2274) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1716000246__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2275 any = A_arbace_j2g_jrt_A_const_47.GetRawRoot__O(); var linked_2276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2275, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2277 lang.IFn; if linked_2276 == nil { ifn_2277 = lang.IFn_Cast(root_2275) } else { ifn_2277 = nil }; var arg_2278 any = s__1716000246__3; if linked_2276 == nil { tmp1 = ifn_2277.Invoke_O__O(arg_2278) } else { tmp1 = linked_2276.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2275, arg_2278) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2279 any = A_arbace_j2g_jrt_A_const_48.GetRawRoot__O(); var linked_2280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2279, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2281 lang.IFn; if linked_2280 == nil { ifn_2281 = lang.IFn_Cast(root_2279) } else { ifn_2281 = nil }; var arg_2282 any = s__1716000246__3; if linked_2280 == nil { c__1927001037__auto____4 = ifn_2281.Invoke_O__O(arg_2282) } else { c__1927001037__auto____4 = linked_2280.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2279, arg_2282) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1716000248__6 any; var root_2283 any = A_arbace_j2g_jrt_A_const_73.GetRawRoot__O(); var linked_2284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2283, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2285 lang.IFn; if linked_2284 == nil { ifn_2285 = lang.IFn_Cast(root_2283) } else { ifn_2285 = nil }; var arg_2286 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2284 == nil { b__1716000248__6 = ifn_2285.Invoke_O__O(arg_2286) } else { b__1716000248__6 = linked_2284.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2283, arg_2286) }; var tmp2 any = A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A_New_O_I_O(b__1716000248__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2312 *jrt.Class = A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A_fn_class; if fncls__2312 == nil { var fncls__2312d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A_fn_class = fncls__2312d; tmp3 = fncls__2312d } else { tmp3 = fncls__2312 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2313 any = A_arbace_j2g_jrt_A_const_76.GetRawRoot__O(); var linked_2314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2313, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2315 lang.IFn; if linked_2314 == nil { ifn_2315 = lang.IFn_Cast(root_2313) } else { ifn_2315 = nil }; var arg_2316 any; var root_2318 any = A_arbace_j2g_jrt_A_const_77.GetRawRoot__O(); var linked_2319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2318, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2320 lang.IFn; if linked_2319 == nil { ifn_2320 = lang.IFn_Cast(root_2318) } else { ifn_2320 = nil }; var arg_2321 any = b__1716000248__6; if linked_2319 == nil { arg_2316 = ifn_2320.Invoke_O__O(arg_2321) } else { arg_2316 = linked_2319.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2318, arg_2321) }; var arg_2317 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1716000245); var tmp5 any; var root_2322 any = A_arbace_j2g_jrt_A_const_67.GetRawRoot__O(); var linked_2323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2322, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2324 lang.IFn; if linked_2323 == nil { ifn_2324 = lang.IFn_Cast(root_2322) } else { ifn_2324 = nil }; var arg_2325 any = s__1716000246__3; if linked_2323 == nil { tmp5 = ifn_2324.Invoke_O__O(arg_2325) } else { tmp5 = linked_2323.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2322, arg_2325) }; arg_2317 = tmp4.Invoke_O__O(tmp5); if linked_2314 == nil { return ifn_2315.Invoke_O_O__O(arg_2316, arg_2317) } else { return linked_2314.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2313, arg_2316, arg_2317) } } else { var root_2326 any = A_arbace_j2g_jrt_A_const_76.GetRawRoot__O(); var linked_2327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2326, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2328 lang.IFn; if linked_2327 == nil { ifn_2328 = lang.IFn_Cast(root_2326) } else { ifn_2328 = nil }; var arg_2329 any; var root_2331 any = A_arbace_j2g_jrt_A_const_77.GetRawRoot__O(); var linked_2332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2331, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2333 lang.IFn; if linked_2332 == nil { ifn_2333 = lang.IFn_Cast(root_2331) } else { ifn_2333 = nil }; var arg_2334 any = b__1716000248__6; if linked_2332 == nil { arg_2329 = ifn_2333.Invoke_O__O(arg_2334) } else { arg_2329 = linked_2332.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2331, arg_2334) }; var arg_2330 any; if linked_2327 == nil { return ifn_2328.Invoke_O_O__O(arg_2329, arg_2330) } else { return linked_2327.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2326, arg_2329, arg_2330) } } } else { var vec__1716000258__4 any; var root_2335 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_2336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2335, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2337 lang.IFn; if linked_2336 == nil { ifn_2337 = lang.IFn_Cast(root_2335) } else { ifn_2337 = nil }; var arg_2338 any = s__1716000246__3; if linked_2336 == nil { vec__1716000258__4 = ifn_2337.Invoke_O__O(arg_2338) } else { vec__1716000258__4 = linked_2336.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2335, arg_2338) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000258__4, lang.RT_IntCast_J__I_NoInit(0), nil); var map__1716000261__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000258__4, lang.RT_IntCast_J__I_NoInit(1), nil); var map__1716000261__7 any; if lang.ISeq_InstanceOf(map__1716000261__6) { var tmp6 any; var root_2339 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_2340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2339, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2341 lang.IFn; if linked_2340 == nil { ifn_2341 = lang.IFn_Cast(root_2339) } else { ifn_2341 = nil }; var arg_2342 any = map__1716000261__6; if linked_2340 == nil { tmp6 = ifn_2341.Invoke_O__O(arg_2342) } else { tmp6 = linked_2340.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2339, arg_2342) }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_2343 any = A_arbace_j2g_jrt_A_const_70.GetRawRoot__O(); var linked_2344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2343, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2345 lang.IFn; if linked_2344 == nil { ifn_2345 = lang.IFn_Cast(root_2343) } else { ifn_2345 = nil }; var arg_2346 any = map__1716000261__6; if linked_2344 == nil { tmp7 = ifn_2345.Invoke_O__O(arg_2346) } else { tmp7 = linked_2344.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2343, arg_2346) }; map__1716000261__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp7)).Ref() } else { var tmp8 any; var root_2347 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_2348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2347, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2349 lang.IFn; if linked_2348 == nil { ifn_2349 = lang.IFn_Cast(root_2347) } else { ifn_2349 = nil }; var arg_2350 any = map__1716000261__6; if linked_2348 == nil { tmp8 = ifn_2349.Invoke_O__O(arg_2350) } else { tmp8 = linked_2348.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2347, arg_2350) }; if jrt.J2g_Truth(tmp8) { var root_2351 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_2352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2351, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2353 lang.IFn; if linked_2352 == nil { ifn_2353 = lang.IFn_Cast(root_2351) } else { ifn_2353 = nil }; var arg_2354 any = map__1716000261__6; if linked_2352 == nil { map__1716000261__7 = ifn_2353.Invoke_O__O(arg_2354) } else { map__1716000261__7 = linked_2352.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2351, arg_2354) } } else { map__1716000261__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000261__7 = map__1716000261__6 }; var kind__8 any = lang.RT_Get_O_O__O_NoInit(map__1716000261__7, A_arbace_j2g_jrt_A_const_57); var form__9 any = lang.RT_Get_O_O__O_NoInit(map__1716000261__7, A_arbace_j2g_jrt_A_const_63); if lang.Util_Equiv_O_O__Z_NoInit(kind__8, A_arbace_j2g_jrt_A_const_59) { var e__10 any; var root_2355 any = A_arbace_j2g_jrt_A_const_108.GetRawRoot__O(); var linked_2356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2355, A_arbace_j2g_jrt_struct_embed_A_fn_class); var ifn_2357 lang.IFn
													if linked_2356 == nil { ifn_2357 = lang.IFn_Cast(root_2355) } else { ifn_2357 = nil }; var arg_2358 any = form__9; if linked_2356 == nil { e__10 = ifn_2357.Invoke_O__O(arg_2358) } else { e__10 = linked_2356.(*A_arbace_j2g_jrt_struct_embed_A).Invoke_O_O__O(root_2355, arg_2358) }
//line :150:1
	if jrt.J2g_Truth(e__10) { var root_2359 any = A_arbace_j2g_jrt_A_const_78.GetRawRoot__O(); var linked_2360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2359, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2361 lang.IFn; if linked_2360 == nil { ifn_2361 = lang.IFn_Cast(root_2359) } else { ifn_2361 = nil }; var arg_2362 any = lang.Tuple_Create_O_O__IPersistentVector(n__5, e__10); var arg_2363 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1716000245); var tmp10 any; var root_2364 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_2365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2364, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2366 lang.IFn; if linked_2365 == nil { ifn_2366 = lang.IFn_Cast(root_2364) } else { ifn_2366 = nil }; var arg_2367 any = s__1716000246__3; if linked_2365 == nil { tmp10 = ifn_2366.Invoke_O__O(arg_2367) } else { tmp10 = linked_2365.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2364, arg_2367) }; arg_2363 = tmp9.Invoke_O__O(tmp10); if linked_2360 == nil { return ifn_2361.Invoke_O_O__O(arg_2362, arg_2363) } else { return linked_2360.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2359, arg_2362, arg_2363) } } else { var tmp11 any; var root_2368 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_2369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2368, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2370 lang.IFn; if linked_2369 == nil { ifn_2370 = lang.IFn_Cast(root_2368) } else { ifn_2370 = nil }; var arg_2371 any = s__1716000246__3; if linked_2369 == nil { tmp11 = ifn_2370.Invoke_O__O(arg_2371) } else { tmp11 = linked_2369.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2368, arg_2371) }; s__1716000246__1 = tmp11; continue L1 } } else { var tmp12 any; var root_2372 any = A_arbace_j2g_jrt_A_const_24.GetRawRoot__O(); var linked_2373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2372, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2374 lang.IFn; if linked_2373 == nil { ifn_2374 = lang.IFn_Cast(root_2372) } else { ifn_2374 = nil }; var arg_2375 any = s__1716000246__3; if linked_2373 == nil { tmp12 = ifn_2374.Invoke_O__O(arg_2375) } else { tmp12 = linked_2373.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2372, arg_2375) }; s__1716000246__1 = tmp12; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :150:1
func A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :150:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A) Ctor_O_I_O(c__b__1716000248 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1716000248 = c__b__1716000248; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :150:1
func (t *A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A) Invoke_O__O(self any) any { { var i__1716000247__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1716000247__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1716000252__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1716000247__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000252__2, lang.RT_IntCast_J__I_NoInit(0), nil); var map__1716000255__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1716000252__2, lang.RT_IntCast_J__I_NoInit(1), nil); var map__1716000255__5 any; if lang.ISeq_InstanceOf(map__1716000255__4) { var tmp2 any; var root_2287 any = A_arbace_j2g_jrt_A_const_49.GetRawRoot__O(); var linked_2288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2287, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2289 lang.IFn; if linked_2288 == nil { ifn_2289 = lang.IFn_Cast(root_2287) } else { ifn_2289 = nil }; var arg_2290 any = map__1716000255__4; if linked_2288 == nil { tmp2 = ifn_2289.Invoke_O__O(arg_2290) } else { tmp2 = linked_2288.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2287, arg_2290) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_2291 any = A_arbace_j2g_jrt_A_const_70.GetRawRoot__O(); var linked_2292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2291, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2293 lang.IFn; if linked_2292 == nil { ifn_2293 = lang.IFn_Cast(root_2291) } else { ifn_2293 = nil }; var arg_2294 any = map__1716000255__4; if linked_2292 == nil { tmp3 = ifn_2293.Invoke_O__O(arg_2294) } else { tmp3 = linked_2292.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2291, arg_2294) }; map__1716000255__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp3)).Ref() } else { var tmp4 any; var root_2295 any = A_arbace_j2g_jrt_A_const_45.GetRawRoot__O(); var linked_2296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2295, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2297 lang.IFn; if linked_2296 == nil { ifn_2297 = lang.IFn_Cast(root_2295) } else { ifn_2297 = nil }; var arg_2298 any = map__1716000255__4; if linked_2296 == nil { tmp4 = ifn_2297.Invoke_O__O(arg_2298) } else { tmp4 = linked_2296.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2295, arg_2298) }; if jrt.J2g_Truth(tmp4) { var root_2299 any = A_arbace_j2g_jrt_A_const_14.GetRawRoot__O(); var linked_2300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2299, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2301 lang.IFn; if linked_2300 == nil { ifn_2301 = lang.IFn_Cast(root_2299) } else { ifn_2301 = nil }; var arg_2302 any = map__1716000255__4; if linked_2300 == nil { map__1716000255__5 = ifn_2301.Invoke_O__O(arg_2302) } else { map__1716000255__5 = linked_2300.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2299, arg_2302) } } else { map__1716000255__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1716000255__5 = map__1716000255__4 }; var kind__6 any = lang.RT_Get_O_O__O_NoInit(map__1716000255__5, A_arbace_j2g_jrt_A_const_57); var form__7 any = lang.RT_Get_O_O__O_NoInit(map__1716000255__5, A_arbace_j2g_jrt_A_const_63); if lang.Util_Equiv_O_O__Z_NoInit(kind__6, A_arbace_j2g_jrt_A_const_59) { var e__8 any; var root_2303 any = A_arbace_j2g_jrt_A_const_108.GetRawRoot__O(); var linked_2304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2303, A_arbace_j2g_jrt_struct_embed_A_fn_class); var ifn_2305 lang.IFn
															if linked_2304 == nil { ifn_2305 = lang.IFn_Cast(root_2303) } else { ifn_2305 = nil }; var arg_2306 any = form__7; if linked_2304 == nil { e__8 = ifn_2305.Invoke_O__O(arg_2306) } else { e__8 = linked_2304.(*A_arbace_j2g_jrt_struct_embed_A).Invoke_O_O__O(root_2303, arg_2306) }
//line :150:1
	if jrt.J2g_Truth(e__8) { var root_2307 any = A_arbace_j2g_jrt_A_const_75.GetRawRoot__O(); var linked_2308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2307, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2309 lang.IFn; if linked_2308 == nil { ifn_2309 = lang.IFn_Cast(root_2307) } else { ifn_2309 = nil }; var arg_2310 any = t.F_b__1716000248; var arg_2311 any = lang.Tuple_Create_O_O__IPersistentVector(n__3, e__8); if linked_2308 == nil { ifn_2309.Invoke_O_O__O(arg_2310, arg_2311) } else { linked_2308.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2307, arg_2310, arg_2311) }; i__1716000247__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000247__1); continue L1 } else { i__1716000247__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000247__1); continue L1 } } else { i__1716000247__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1716000247__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_jrt_struct_methods_A_New() *A_arbace_j2g_jrt_struct_methods_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_struct_methods_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_j2g_jrt_struct_methods_A) Ctor() {}
//line :154:1
func (t *A_arbace_j2g_jrt_struct_methods_A) Invoke_O_O_O__O(self, scan__0, go_type__1 any) any { { var t__3 any = go_type__1; var acc__4 any = lang.PersistentHashSet_EMPTY.Ref(); L1: for {



	if lang.Util_Identical_O_O__Z_NoInit(t__3, nil) { return acc__4 } else {

		var tmp1 any = lang.RT_Get_O_O__O_NoInit(A_arbace_j2g_jrt_A_const_79.Invoke_O__O(scan__0), t__3); var tmp2 any; var root_2378 any = A_arbace_j2g_jrt_A_const_89.GetRawRoot__O(); var linked_2379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2378, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2380 lang.IFn; if linked_2379 == nil { ifn_2380 = lang.IFn_Cast(root_2378) } else { ifn_2380 = nil }; var arg_2381 any = acc__4; var arg_2382 any = lang.RT_Get_O_O__O_NoInit(A_arbace_j2g_jrt_A_const_40.Invoke_O__O(scan__0), t__3); if linked_2379 == nil { tmp2 = ifn_2380.Invoke_O_O__O(arg_2381, arg_2382) } else { tmp2 = linked_2379.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2378, arg_2381, arg_2382) }; t__3, acc__4 = tmp1, tmp2; continue L1 } } }; /*line :154:1*/panic("j2g: unreachable") }







func A_arbace_j2g_jrt_iface_methods_A_New() *A_arbace_j2g_jrt_iface_methods_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_iface_methods_A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_j2g_jrt_iface_methods_A) Ctor() {}
//line :162:1
func (t *A_arbace_j2g_jrt_iface_methods_A) Invoke_O_O_O__O(self, scan__0, go_type__1 any) any { var i__3 any = lang.RT_Get_O_O__O_NoInit(A_arbace_j2g_jrt_A_const_106.Invoke_O__O(scan__0), go_type__1); var root_2383 any = A_arbace_j2g_jrt_A_const_89.GetRawRoot__O(); var linked_2384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2383, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2385 lang.IFn; if



	linked_2384 == nil { ifn_2385 = lang.IFn_Cast(root_2383) } else { ifn_2385 = nil }; var arg_2386 any; var root_2388 any = A_arbace_j2g_jrt_A_const_72.GetRawRoot__O(); var linked_2389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2388, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2390 lang.IFn; if linked_2389 == nil { ifn_2390 = lang.IFn_Cast(root_2388) } else { ifn_2390 = nil }; var arg_2391 any = A_arbace_j2g_jrt_A_const_40.Invoke_O__O(i__3); if linked_2389 == nil { arg_2386 = ifn_2390.Invoke_O__O(arg_2391) } else { arg_2386 = linked_2389.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2388, arg_2391) }; var arg_2387 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_jrt_A_const_109.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_jrt_iface_methods_fn__1716000268_A_New_O(scan__0); var tmp3 *jrt.Class; var fncls__2402 *jrt.Class = A_arbace_j2g_jrt_iface_methods_fn__1716000268_A_fn_class; if fncls__2402 == nil { var fncls__2402d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_j2g_jrt_iface_methods_fn__1716000268_A_fn_class = fncls__2402d; tmp3 = fncls__2402d } else { tmp3 = fncls__2402 }; arg_2387 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), A_arbace_j2g_jrt_A_const_79.Invoke_O__O(i__3)); if linked_2384 == nil { return ifn_2385.Invoke_O_O__O(arg_2386, arg_2387) } else { return linked_2384.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2383, arg_2386, arg_2387) } }
//line :166:1
func A_arbace_j2g_jrt_iface_methods_fn__1716000268_A_New_O(p0 any) *A_arbace_j2g_jrt_iface_methods_fn__1716000268_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_iface_methods_fn__1716000268_A{}; t.Ctor_O(p0); return t }
//line :166:1
func (t *A_arbace_j2g_jrt_iface_methods_fn__1716000268_A) Ctor_O(c__scan any) { t.F_scan = c__scan }
//line :166:1
func (t *A_arbace_j2g_jrt_iface_methods_fn__1716000268_A) Invoke_O_O__O(self, p1__1716000267_SHARP___1 any) any { var root_2397 any = A_arbace_j2g_jrt_A_const_110.GetRawRoot__O(); var linked_2398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2397, A_arbace_j2g_jrt_iface_methods_A_fn_class); var ifn_2399 lang.IFn; if linked_2398 == nil { ifn_2399 = lang.IFn_Cast(root_2397) } else { ifn_2399 = nil }; var arg_2400 any = t.F_scan; var arg_2401 any = p1__1716000267_SHARP___1; if linked_2398 == nil { return ifn_2399.Invoke_O_O__O(arg_2400, arg_2401) } else { return linked_2398.(*A_arbace_j2g_jrt_iface_methods_A).Invoke_O_O_O__O(root_2397, arg_2400, arg_2401) } }
















































































































type A_arbace_j2g_jrt_A struct{ jrt.Object }

var A_arbace_j2g_jrt_A_const_pool *jrt.RefArray

var A_arbace_j2g_jrt_A_const_0 *lang.Var

var A_arbace_j2g_jrt_A_const_1 any

var A_arbace_j2g_jrt_A_const_2 any

var A_arbace_j2g_jrt_A_const_3 any

var A_arbace_j2g_jrt_A_const_4 any

var A_arbace_j2g_jrt_A_const_5 *lang.Var

var A_arbace_j2g_jrt_A_const_6 any

var A_arbace_j2g_jrt_A_const_7 *lang.Var

var A_arbace_j2g_jrt_A_const_8 *lang.Var

var A_arbace_j2g_jrt_A_const_9 *lang.Var

var A_arbace_j2g_jrt_A_const_10 *lang.Var

var A_arbace_j2g_jrt_A_const_11 any

var A_arbace_j2g_jrt_A_const_12 *lang.Var

var A_arbace_j2g_jrt_A_const_13 *lang.Var

var A_arbace_j2g_jrt_A_const_14 *lang.Var

var A_arbace_j2g_jrt_A_const_15 *lang.Var

var A_arbace_j2g_jrt_A_const_16 any

var A_arbace_j2g_jrt_A_const_17 *lang.Var

var A_arbace_j2g_jrt_A_const_18 *lang.Keyword

var A_arbace_j2g_jrt_A_const_19 *lang.Var

var A_arbace_j2g_jrt_A_const_20 any

var A_arbace_j2g_jrt_A_const_21 *lang.Keyword

var A_arbace_j2g_jrt_A_const_22 *lang.Var

var A_arbace_j2g_jrt_A_const_23 *lang.Var

var A_arbace_j2g_jrt_A_const_24 *lang.Var

var A_arbace_j2g_jrt_A_const_25 *lang.Var

var A_arbace_j2g_jrt_A_const_26 *lang.Var

var A_arbace_j2g_jrt_A_const_27 any

var A_arbace_j2g_jrt_A_const_28 *lang.Var

var A_arbace_j2g_jrt_A_const_29 *lang.Var

var A_arbace_j2g_jrt_A_const_30 *lang.Var

var A_arbace_j2g_jrt_A_const_31 any

var A_arbace_j2g_jrt_A_const_32 *lang.Keyword

var A_arbace_j2g_jrt_A_const_33 *lang.Var

var A_arbace_j2g_jrt_A_const_34 *lang.Keyword

var A_arbace_j2g_jrt_A_const_35 *lang.Keyword

var A_arbace_j2g_jrt_A_const_36 *lang.Var

var A_arbace_j2g_jrt_A_const_37 *lang.Var

var A_arbace_j2g_jrt_A_const_38 *lang.Var

var A_arbace_j2g_jrt_A_const_39 *lang.Keyword

var A_arbace_j2g_jrt_A_const_40 *lang.Keyword

var A_arbace_j2g_jrt_A_const_41 *lang.Keyword

var A_arbace_j2g_jrt_A_const_42 *lang.Keyword

var A_arbace_j2g_jrt_A_const_43 *lang.Keyword

var A_arbace_j2g_jrt_A_const_44 *lang.Keyword

var A_arbace_j2g_jrt_A_const_45 *lang.Var

var A_arbace_j2g_jrt_A_const_46 *lang.Var

var A_arbace_j2g_jrt_A_const_47 *lang.Var

var A_arbace_j2g_jrt_A_const_48 *lang.Var

var A_arbace_j2g_jrt_A_const_49 *lang.Var

var A_arbace_j2g_jrt_A_const_50 *lang.Var

var A_arbace_j2g_jrt_A_const_51 *lang.Keyword

var A_arbace_j2g_jrt_A_const_52 *lang.Var

var A_arbace_j2g_jrt_A_const_53 *lang.Var

var A_arbace_j2g_jrt_A_const_54 *lang.Var

var A_arbace_j2g_jrt_A_const_55 *lang.Var

var A_arbace_j2g_jrt_A_const_56 *lang.Var

var A_arbace_j2g_jrt_A_const_57 *lang.Keyword

var A_arbace_j2g_jrt_A_const_58 any

var A_arbace_j2g_jrt_A_const_59 *lang.Keyword

var A_arbace_j2g_jrt_A_const_60 any

var A_arbace_j2g_jrt_A_const_61 *lang.Keyword

var A_arbace_j2g_jrt_A_const_62 *lang.Keyword

var A_arbace_j2g_jrt_A_const_63 *lang.Keyword

var A_arbace_j2g_jrt_A_const_64 *lang.Var

var A_arbace_j2g_jrt_A_const_65 any

var A_arbace_j2g_jrt_A_const_66 any

var A_arbace_j2g_jrt_A_const_67 *lang.Var

var A_arbace_j2g_jrt_A_const_68 any

var A_arbace_j2g_jrt_A_const_69 *lang.Var

var A_arbace_j2g_jrt_A_const_70 *lang.Var

var A_arbace_j2g_jrt_A_const_71 any

var A_arbace_j2g_jrt_A_const_72 *lang.Var

var A_arbace_j2g_jrt_A_const_73 *lang.Var

var A_arbace_j2g_jrt_A_const_74 *lang.Var

var A_arbace_j2g_jrt_A_const_75 *lang.Var

var A_arbace_j2g_jrt_A_const_76 *lang.Var

var A_arbace_j2g_jrt_A_const_77 *lang.Var

var A_arbace_j2g_jrt_A_const_78 *lang.Var

var A_arbace_j2g_jrt_A_const_79 *lang.Keyword

var A_arbace_j2g_jrt_A_const_80 *lang.Var

var A_arbace_j2g_jrt_A_const_81 *lang.Var

var A_arbace_j2g_jrt_A_const_82 any

var A_arbace_j2g_jrt_A_const_83 *lang.Var

var A_arbace_j2g_jrt_A_const_84 *lang.Var

var A_arbace_j2g_jrt_A_const_85 *lang.Var

var A_arbace_j2g_jrt_A_const_86 *lang.Var

var A_arbace_j2g_jrt_A_const_87 *lang.Var

var A_arbace_j2g_jrt_A_const_88 *lang.Var

var A_arbace_j2g_jrt_A_const_89 *lang.Var

var A_arbace_j2g_jrt_A_const_90 *lang.Var

var A_arbace_j2g_jrt_A_const_91 *lang.Var

var A_arbace_j2g_jrt_A_const_92 *lang.Var

var A_arbace_j2g_jrt_A_const_93 *lang.Var

var A_arbace_j2g_jrt_A_const_94 *lang.Var

var A_arbace_j2g_jrt_A_const_95 *lang.Var

var A_arbace_j2g_jrt_A_const_96 *lang.Keyword

var A_arbace_j2g_jrt_A_const_97 *lang.Var

var A_arbace_j2g_jrt_A_const_98 *lang.Keyword

var A_arbace_j2g_jrt_A_const_99 *lang.Keyword

var A_arbace_j2g_jrt_A_const_100 *lang.Var

var A_arbace_j2g_jrt_A_const_101 any

var A_arbace_j2g_jrt_A_const_102 *lang.Keyword

var A_arbace_j2g_jrt_A_const_103 *lang.Keyword

var A_arbace_j2g_jrt_A_const_104 *lang.Var

var A_arbace_j2g_jrt_A_const_105 *lang.Var

var A_arbace_j2g_jrt_A_const_106 *lang.Keyword

var A_arbace_j2g_jrt_A_const_107 *lang.Var

var A_arbace_j2g_jrt_A_const_108 *lang.Var

var A_arbace_j2g_jrt_A_const_109 *lang.Var

var A_arbace_j2g_jrt_A_const_110 *lang.Var

var A_arbace_j2g_jrt_A_init jrt.ClassInit

func A_arbace_j2g_jrt_A_Init() { if !A_arbace_j2g_jrt_A_init.Done() { A_arbace_j2g_jrt_A_init.Run(A_arbace_j2g_jrt_A_clinit) } }

func A_arbace_j2g_jrt_A_clinit() { A_arbace_j2g_jrt_A_clinit_p0(); A_arbace_j2g_jrt_A_clinit_p1(); A_arbace_j2g_jrt_A_clinit_p2(); A_arbace_j2g_jrt_A_clinit_p3(); A_arbace_j2g_jrt_A_clinit_p4(); A_arbace_j2g_jrt_A_clinit_p5(); A_arbace_j2g_jrt_A_clinit_p6(); A_arbace_j2g_jrt_A_clinit_p7(); A_arbace_j2g_jrt_A_clinit_p8(); A_arbace_j2g_jrt_A_clinit_p9() }

func A_arbace_j2g_jrt_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_jrt_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 150); A_arbace_j2g_jrt_A_const_0 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[39]); A_arbace_j2g_jrt_A_const_1 = A_arbace_j2g_jrt_A_const_pool.A[40]; A_arbace_j2g_jrt_A_const_2 = A_arbace_j2g_jrt_A_const_pool.A[41]; A_arbace_j2g_jrt_A_const_3 = A_arbace_j2g_jrt_A_const_pool.A[42]; A_arbace_j2g_jrt_A_const_4 = A_arbace_j2g_jrt_A_const_pool.A[43]; A_arbace_j2g_jrt_A_const_5 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[44]); A_arbace_j2g_jrt_A_const_6 = A_arbace_j2g_jrt_A_const_pool.A[45]; A_arbace_j2g_jrt_A_const_7 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[46]); A_arbace_j2g_jrt_A_const_8 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[47]); A_arbace_j2g_jrt_A_const_9 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[48]); A_arbace_j2g_jrt_A_const_10 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[49]); A_arbace_j2g_jrt_A_const_11 = A_arbace_j2g_jrt_A_const_pool.A[50] }

func A_arbace_j2g_jrt_A_clinit_p1() { A_arbace_j2g_jrt_A_const_12 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[51]); A_arbace_j2g_jrt_A_const_13 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[52]); A_arbace_j2g_jrt_A_const_14 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[53]); A_arbace_j2g_jrt_A_const_15 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[54]); A_arbace_j2g_jrt_A_const_16 = A_arbace_j2g_jrt_A_const_pool.A[55]; A_arbace_j2g_jrt_A_const_17 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[56]); A_arbace_j2g_jrt_A_const_18 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[57]); A_arbace_j2g_jrt_A_const_19 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[58]); A_arbace_j2g_jrt_A_const_20 = A_arbace_j2g_jrt_A_const_pool.A[59]; A_arbace_j2g_jrt_A_const_21 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[60]); A_arbace_j2g_jrt_A_const_22 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[61]); A_arbace_j2g_jrt_A_const_23 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[62]) }

func A_arbace_j2g_jrt_A_clinit_p2() { A_arbace_j2g_jrt_A_const_24 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[63]); A_arbace_j2g_jrt_A_const_25 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[64]); A_arbace_j2g_jrt_A_const_26 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[65]); A_arbace_j2g_jrt_A_const_27 = A_arbace_j2g_jrt_A_const_pool.A[66]; A_arbace_j2g_jrt_A_const_28 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[67]); A_arbace_j2g_jrt_A_const_29 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[68]); A_arbace_j2g_jrt_A_const_30 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[69]); A_arbace_j2g_jrt_A_const_31 = A_arbace_j2g_jrt_A_const_pool.A[70]; A_arbace_j2g_jrt_A_const_32 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[71]); A_arbace_j2g_jrt_A_const_33 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[72]); A_arbace_j2g_jrt_A_const_34 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[73]); A_arbace_j2g_jrt_A_const_35 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[74]) }

func A_arbace_j2g_jrt_A_clinit_p3() { A_arbace_j2g_jrt_A_const_36 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[75]); A_arbace_j2g_jrt_A_const_37 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[76]); A_arbace_j2g_jrt_A_const_38 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[77]); A_arbace_j2g_jrt_A_const_39 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[78]); A_arbace_j2g_jrt_A_const_40 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[79]); A_arbace_j2g_jrt_A_const_41 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[80]); A_arbace_j2g_jrt_A_const_42 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[81]); A_arbace_j2g_jrt_A_const_43 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[82]); A_arbace_j2g_jrt_A_const_44 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[83]); A_arbace_j2g_jrt_A_const_45 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[84]); A_arbace_j2g_jrt_A_const_46 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[85]); A_arbace_j2g_jrt_A_const_47 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[86]) }

func A_arbace_j2g_jrt_A_clinit_p4() { A_arbace_j2g_jrt_A_const_48 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[87]); A_arbace_j2g_jrt_A_const_49 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[88]); A_arbace_j2g_jrt_A_const_50 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[89]); A_arbace_j2g_jrt_A_const_51 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[90]); A_arbace_j2g_jrt_A_const_52 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[91]); A_arbace_j2g_jrt_A_const_53 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[92]); A_arbace_j2g_jrt_A_const_54 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[93]); A_arbace_j2g_jrt_A_const_55 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[94]); A_arbace_j2g_jrt_A_const_56 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[95]); A_arbace_j2g_jrt_A_const_57 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[96]); A_arbace_j2g_jrt_A_const_58 = A_arbace_j2g_jrt_A_const_pool.A[97]; A_arbace_j2g_jrt_A_const_59 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[98]) }

func A_arbace_j2g_jrt_A_clinit_p5() { A_arbace_j2g_jrt_A_const_60 = A_arbace_j2g_jrt_A_const_pool.A[99]; A_arbace_j2g_jrt_A_const_61 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[100]); A_arbace_j2g_jrt_A_const_62 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[101]); A_arbace_j2g_jrt_A_const_63 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[102]); A_arbace_j2g_jrt_A_const_64 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[103]); A_arbace_j2g_jrt_A_const_65 = A_arbace_j2g_jrt_A_const_pool.A[104]; A_arbace_j2g_jrt_A_const_66 = A_arbace_j2g_jrt_A_const_pool.A[105]; A_arbace_j2g_jrt_A_const_67 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[106]); A_arbace_j2g_jrt_A_const_68 = A_arbace_j2g_jrt_A_const_pool.A[107]; A_arbace_j2g_jrt_A_const_69 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[108]); A_arbace_j2g_jrt_A_const_70 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[109]); A_arbace_j2g_jrt_A_const_71 = A_arbace_j2g_jrt_A_const_pool.A[110]; A_arbace_j2g_jrt_A_const_72 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[111]) }

func A_arbace_j2g_jrt_A_clinit_p6() { A_arbace_j2g_jrt_A_const_73 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[112]); A_arbace_j2g_jrt_A_const_74 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[113]); A_arbace_j2g_jrt_A_const_75 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[114]); A_arbace_j2g_jrt_A_const_76 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[115]); A_arbace_j2g_jrt_A_const_77 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[116]); A_arbace_j2g_jrt_A_const_78 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[117]); A_arbace_j2g_jrt_A_const_79 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[118]); A_arbace_j2g_jrt_A_const_80 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[119]); A_arbace_j2g_jrt_A_const_81 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[120]); A_arbace_j2g_jrt_A_const_82 = A_arbace_j2g_jrt_A_const_pool.A[121]; A_arbace_j2g_jrt_A_const_83 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[122]); A_arbace_j2g_jrt_A_const_84 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[123]) }

func A_arbace_j2g_jrt_A_clinit_p7() { A_arbace_j2g_jrt_A_const_85 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[124]); A_arbace_j2g_jrt_A_const_86 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[125]); A_arbace_j2g_jrt_A_const_87 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[126]); A_arbace_j2g_jrt_A_const_88 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[127]); A_arbace_j2g_jrt_A_const_89 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[128]); A_arbace_j2g_jrt_A_const_90 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[129]); A_arbace_j2g_jrt_A_const_91 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[130]); A_arbace_j2g_jrt_A_const_92 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[131]); A_arbace_j2g_jrt_A_const_93 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[132]); A_arbace_j2g_jrt_A_const_94 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[133]); A_arbace_j2g_jrt_A_const_95 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[134]); A_arbace_j2g_jrt_A_const_96 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[135]) }

func A_arbace_j2g_jrt_A_clinit_p8() { A_arbace_j2g_jrt_A_const_97 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[136]); A_arbace_j2g_jrt_A_const_98 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[137]); A_arbace_j2g_jrt_A_const_99 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[138]); A_arbace_j2g_jrt_A_const_100 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[139]); A_arbace_j2g_jrt_A_const_101 = A_arbace_j2g_jrt_A_const_pool.A[140]; A_arbace_j2g_jrt_A_const_102 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[141]); A_arbace_j2g_jrt_A_const_103 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[142]); A_arbace_j2g_jrt_A_const_104 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[143]); A_arbace_j2g_jrt_A_const_105 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[144]); A_arbace_j2g_jrt_A_const_106 = lang.Keyword_Cast(A_arbace_j2g_jrt_A_const_pool.A[145]); A_arbace_j2g_jrt_A_const_107 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[146]); A_arbace_j2g_jrt_A_const_108 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[147]) }

func A_arbace_j2g_jrt_A_clinit_p9() { A_arbace_j2g_jrt_A_const_109 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[148]); A_arbace_j2g_jrt_A_const_110 = lang.Var_Cast(A_arbace_j2g_jrt_A_const_pool.A[149]) }

func A_arbace_j2g_jrt_A_New() *A_arbace_j2g_jrt_A { A_arbace_j2g_jrt_A_Init(); t := &A_arbace_j2g_jrt_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_jrt_A) Ctor() {}

func (t *A_arbace_j2g_jrt_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_jrt_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_jrt_A_class }

func (t *A_arbace_j2g_jrt_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_jrt_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_jrt_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_jrt_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_jrt_A); return ok }

func A_arbace_j2g_jrt_A_Cast(x any) *A_arbace_j2g_jrt_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_jrt_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_jrt_A_class)) }; return v }



type A_arbace_j2g_jrt_define_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_define_name_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_define_name_walk__1716000019_A struct{ j2g_header uint64; F_found any }

var A_arbace_j2g_jrt_define_name_walk__1716000019_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_eval1716000004_A struct{ jrt.Object }

func A_arbace_j2g_jrt_eval1716000004_A_New() *A_arbace_j2g_jrt_eval1716000004_A { t := &A_arbace_j2g_jrt_eval1716000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_jrt_eval1716000004_A) Ctor() {}

func (t *A_arbace_j2g_jrt_eval1716000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_jrt_eval1716000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_jrt_eval1716000004_A_class }

func (t *A_arbace_j2g_jrt_eval1716000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_jrt_eval1716000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_jrt_eval1716000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_jrt_eval1716000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_jrt_eval1716000004_A); return ok }

func A_arbace_j2g_jrt_eval1716000004_A_Cast(x any) *A_arbace_j2g_jrt_eval1716000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_jrt_eval1716000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_jrt_eval1716000004_A_class)) }; return v }



type A_arbace_j2g_jrt_eval1716000004_loading__1927001464__auto____1716000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_eval1716000004_loading__1927001464__auto____1716000005_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_eval1716000008_A struct{ jrt.Object }

func A_arbace_j2g_jrt_eval1716000008_A_New() *A_arbace_j2g_jrt_eval1716000008_A { t := &A_arbace_j2g_jrt_eval1716000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_jrt_eval1716000008_A) Ctor() {}

func (t *A_arbace_j2g_jrt_eval1716000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_jrt_eval1716000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_jrt_eval1716000008_A_class }

func (t *A_arbace_j2g_jrt_eval1716000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_jrt_eval1716000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_jrt_eval1716000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_jrt_eval1716000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_jrt_eval1716000008_A); return ok }

func A_arbace_j2g_jrt_eval1716000008_A_Cast(x any) *A_arbace_j2g_jrt_eval1716000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_jrt_eval1716000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_jrt_eval1716000008_A_class)) }; return v }



type A_arbace_j2g_jrt_eval1716000008_fn__1716000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_eval1716000008_fn__1716000009_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_go_head_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_go_head_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_head_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_head_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_iface_methods_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_iface_methods_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_iface_methods_fn__1716000268_A struct{ j2g_header uint64; F_scan any }

var A_arbace_j2g_jrt_iface_methods_fn__1716000268_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_interface_elems_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_interface_elems_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A struct{ j2g_header uint64; F_s__1716000162, F_iter__1716000161 any }

var A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A struct{ j2g_header uint64; F_b__1716000164 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_jrt_interface_elems_iter__1716000161__1716000165_fn__1716000166_fn__1716000167_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A struct{ j2g_header uint64; F_s__1716000172, F_iter__1716000171 any }

var A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A struct{ j2g_header uint64; F_b__1716000174 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_jrt_interface_elems_iter__1716000171__1716000175_fn__1716000176_fn__1716000177_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_other_system_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_other_system_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_jrt_recv_type_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_recv_type_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_recv_type_nm__1716000015_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_recv_type_nm__1716000015_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_scan_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_fn__1716000186_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_scan_fn__1716000186_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_fn__1716000188_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_scan_fn__1716000188_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A struct{ j2g_header uint64; F_s__1716000191, F_iter__1716000190 any }

var A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A struct{ j2g_header uint64; F_b__1716000193 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_jrt_scan_iter__1716000190__1716000194_fn__1716000195_fn__1716000196_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A struct{ j2g_header uint64; F_s__1716000201, F_iter__1716000200 any }

var A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A struct{ j2g_header uint64; F_fname any }

var A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A struct{ j2g_header uint64; F_s__1716000203, F_iter__1716000202, F_fname any }

var A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A struct{ j2g_header uint64; F_fname, F_b__1716000205 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_jrt_scan_iter__1716000200__1716000206_fn__1716000207_iter__1716000202__1716000211_fn__1716000212_fn__1716000213_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A struct{ j2g_header uint64; F_s__1716000226, F_iter__1716000225 any }

var A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A struct{ j2g_header uint64; F_b__1716000228 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_jrt_scan_iter__1716000225__1716000229_fn__1716000230_fn__1716000231_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A struct{ j2g_header uint64; F_s__1716000246, F_iter__1716000245 any }

var A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A struct{ j2g_header uint64; F_b__1716000248 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_jrt_scan_iter__1716000245__1716000249_fn__1716000250_fn__1716000251_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_scan_file_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_scan_file_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_strip_doc_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_strip_doc_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_struct_embed_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_struct_embed_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_struct_methods_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_struct_methods_A_fn_class *jrt.Class



type A_arbace_j2g_jrt_tag_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_jrt_tag_of_A_fn_class *jrt.Class
