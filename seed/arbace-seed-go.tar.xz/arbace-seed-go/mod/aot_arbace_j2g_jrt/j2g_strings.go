//line j2g_strings.ae:1
package aot_arbace_j2g_jrt

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn10,arbace.setyn14,arbace.java.ioyn2,ioyn20,arbace.repr.go.printyn2,gpyn11,arbace.corekn3,dockn3,tagyn1,*kn4,elseyn9,ClassInfokn4,Namekn4,namekn4,infokn5,typeskn7,methodskn5,funcskn4,varskn7,classeskn6,constskn11,type-paramskn4,kindyn6,structkn6,structyn9,interfacekn9,interfacekn5,otherkn4,formyn6,valueskn6,embedskn5,fileskn3,varkn2,gokn4,filekn7,standinkn10,interfacesv11,arbace.core7,requireV3,R0,R1,R2,V1,R3,V3,R4,R1,R5,V3,R6,R1,R7,v11,arbace.core5,referR8,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn14,arbace.j2g.jrtm2,R9,s369,What j2g knows of jrt's hand-written Go forms (go/arbace/jrt, doc/go/JRT-NOTES.md): the Go\n  types, methods, functions and variables they declare, the Java classes they define (by their\n  Define registrations) and which of those are stand-ins (J2G-SPEC §4.3, amendment J9), read\n  from the forms themselves so that j2g's output and jrt meet at the names jrt really has.v11,arbace.core4,seq?v11,arbace.core7,symbol?v11,arbace.core5,firstv11,arbace.core4,nameS2,s9,arbace.gos2,gov11,arbace.core9,namespaceR10,v14,arbace.j2g.jrt6,tag-ofR11,R12,v11,arbace.core6,secondv11,arbace.core7,string?v11,arbace.core4,restv11,arbace.core4,atomv14,arbace.j2g.jrt4,headR13,v11,arbace.core5,applyv11,arbace.core8,hash-mapv11,arbace.core4,dropl2,R14,v11,arbace.core6,reset!R15,R16,v11,arbace.core4,run!v20,arbace.repr.go.print10,read-formsv11,arbace.core9,volatile!R17,R18,R19,R20,R21,R22,v11,arbace.core3,seqv14,arbace.j2g.jrt7,go-headv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core4,nextv14,arbace.j2g.jrt9,strip-docR23,v14,arbace.j2g.jrt9,recv-typev11,arbace.core9,update-inv11,arbace.core4,fnilv11,arbace.core7,vector?v11,arbace.core8,assoc-inR24,R25,R26,R27,R28,R29,R30,v11,arbace.core6,updateR25,R27,v11,arbace.core10,chunk-restR31,v14,arbace.j2g.jrt11,define-namev11,arbace.core8,to-arrayR31,v11,arbace.core3,setv11,arbace.core12,chunk-bufferv11,arbace.core6,removev11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core4,consR32,v11,arbace.core3,vecv11,arbace.core7,re-findp110,_(tamago|darwin|windows|freebsd|netbsd|openbsd|dragonfly|solaris|illumos|aix|plan9|js|wasip1|ios|android)\\.ae$v11,arbace.core7,sort-byv11,arbace.core6,filterv13,arbace.string10,ends-with?v11,arbace.core3,notv14,arbace.j2g.jrt13,other-system?v14,arbace.java.io4,filev11,arbace.core4,intov11,arbace.core10,sorted-mapv14,arbace.j2g.jrt9,scan-filev11,arbace.core5,mergev11,arbace.core3,mapv11,arbace.core4,valsv11,arbace.core10,merge-withR33,v10,arbace.set5,unionR34,R35,v13,arbace.string7,replacep7,_class$R36,R37,v13,arbace.string12,starts-with?v11,arbace.core6,concatR38,v14,arbace.j2g.jrt15,interface-elemsv14,arbace.j2g.jrt12,struct-embedv11,arbace.core6,mapcatv14,arbace.j2g.jrt13,iface-methods")

var Lit_1 *jrt.String = jrt.Intern("arbace.j2g.jrt$define_name$walk__1716000019")

var Lit_2 *jrt.String = jrt.Intern("lit")

var Lit_3 *jrt.String = jrt.Intern("arbace.j2g.jrt$iface_methods$fn__1716000268")

var Lit_4 *jrt.String = jrt.Intern("arbace.j2g.jrt$interface_elems$iter__1716000161__1716000165")

var Lit_5 *jrt.String = jrt.Intern("arbace.j2g.jrt$interface_elems$iter__1716000171__1716000175")

var Lit_6 *jrt.String = jrt.Intern("arbace.j2g.jrt$interface_elems$iter__1716000161__1716000165$fn__1716000166")

var Lit_7 *jrt.String = jrt.Intern("arbace.j2g.jrt$interface_elems$iter__1716000161__1716000165$fn__1716000166$fn__1716000167")

var Lit_8 *jrt.String = jrt.Intern("arbace.j2g.jrt$interface_elems$iter__1716000171__1716000175$fn__1716000176")

var Lit_9 *jrt.String = jrt.Intern("arbace.j2g.jrt$interface_elems$iter__1716000171__1716000175$fn__1716000176$fn__1716000177")

var Lit_10 *jrt.String = jrt.Intern("arbace.j2g.jrt$recv_type$nm__1716000015")

var Lit_11 *jrt.String = jrt.Intern("arbace.j2g.jrt$scan$fn__1716000186")

var Lit_12 *jrt.String = jrt.Intern("arbace.j2g.jrt$scan$fn__1716000188")

var Lit_13 *jrt.String = jrt.Intern("arbace.j2g.jrt$scan$iter__1716000190__1716000194")

var Lit_14 *jrt.String = jrt.Intern("arbace.j2g.jrt$scan$iter__1716000200__1716000206")

var Lit_15 *jrt.String = jrt.Intern("arbace.j2g.jrt$scan$iter__1716000225__1716000229")

var Lit_16 *jrt.String = jrt.Intern("arbace.j2g.jrt$scan$iter__1716000245__1716000249")

var Lit_17 *jrt.String = jrt.Intern(".ae")

var Lit_18 *jrt.String = jrt.Intern("_test.ae")

var Lit_19 *jrt.String = jrt.Intern("arbace.j2g.jrt$scan$iter__1716000190__1716000194$fn__1716000195")

var Lit_20 *jrt.String = jrt.Intern("arbace.j2g.jrt$scan$iter__1716000190__1716000194$fn__1716000195$fn__1716000196")

var Lit_21 *jrt.String = jrt.Intern("arbace.j2g.jrt$scan$iter__1716000200__1716000206$fn__1716000207")

var Lit_22 *jrt.String = jrt.Intern("arbace.j2g.jrt$scan$iter__1716000200__1716000206$fn__1716000207$iter__1716000202__1716000211")

var Lit_23 *jrt.String = jrt.Intern("arbace.j2g.jrt$scan$iter__1716000200__1716000206$fn__1716000207$iter__1716000202__1716000211$fn__1716000212")

var Lit_24 *jrt.String = jrt.Intern("arbace.j2g.jrt$scan$iter__1716000200__1716000206$fn__1716000207$iter__1716000202__1716000211$fn__1716000212$fn__1716000213")

var Lit_25 *jrt.String = jrt.Intern("")

var Lit_26 *jrt.String = jrt.Intern("standin_")

var Lit_27 *jrt.String = jrt.Intern("arbace.j2g.jrt$scan$iter__1716000225__1716000229$fn__1716000230")

var Lit_28 *jrt.String = jrt.Intern("arbace.j2g.jrt$scan$iter__1716000225__1716000229$fn__1716000230$fn__1716000231")

var Lit_29 *jrt.String = jrt.Intern("arbace.j2g.jrt$scan$iter__1716000245__1716000249$fn__1716000250")

var Lit_30 *jrt.String = jrt.Intern("arbace.j2g.jrt$scan$iter__1716000245__1716000249$fn__1716000250$fn__1716000251")

var Lit_31 *jrt.String = jrt.Intern("method")

var Lit_32 *jrt.String = jrt.Intern("type")

var Lit_33 *jrt.String = jrt.Intern("const")

var Lit_34 *jrt.String = jrt.Intern("func")

var Lit_35 *jrt.String = jrt.Intern("var")

var Lit_36 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn1,fkn4,linekn6,columnkn4,fileyn1,xyn1,ryn2,xsyn4,inityn2,tfkn3,tagyn6,Stringyn3,diryn4,scanyn7,go-typev11,arbace.core5,in-nsMyn14,arbace.j2g.jrtm2,R0,s369,What j2g knows of jrt's hand-written Go forms (go/arbace/jrt, doc/go/JRT-NOTES.md): the Go\n  types, methods, functions and variables they declare, the Java classes they define (by their\n  Define registrations) and which of those are stand-ins (J2G-SPEC §4.3, amendment J9), read\n  from the forms themselves so that j2g's output and jrt meet at the names jrt really has.m2,R0,s369,What j2g knows of jrt's hand-written Go forms (go/arbace/jrt, doc/go/JRT-NOTES.md): the Go\n  types, methods, functions and variables they declare, the Java classes they define (by their\n  Define registrations) and which of those are stand-ins (J2G-SPEC §4.3, amendment J9), read\n  from the forms themselves so that j2g's output and jrt meet at the names jrt really has.R1,v14,arbace.j2g.jrt4,headm10,R2,TR3,L1,V1,R4,R5,i11,R6,i1,R7,s17,arbace/j2g/jrt.aev14,arbace.j2g.jrt7,go-headm10,R2,TR3,L1,V1,R4,R5,i13,R6,i1,R7,s17,arbace/j2g/jrt.aev14,arbace.j2g.jrt6,tag-ofm10,R2,TR3,L1,V1,R8,R5,i17,R6,i1,R7,s17,arbace/j2g/jrt.aev14,arbace.j2g.jrt9,recv-typem12,R2,TR3,L1,V1,R9,R0,s59,The receiver type name of a go/method's receiver parameter.R5,i19,R6,i1,R7,s17,arbace/j2g/jrt.aev14,arbace.j2g.jrt9,strip-docm10,R2,TR3,L1,V1,R10,R5,i29,R6,i1,R7,s17,arbace/j2g/jrt.aev14,arbace.j2g.jrt11,define-namem12,R2,TR3,L1,V1,R11,R0,s82,The Java name a (Define (addr (lit ClassInfo :Name \"...\" ...))) registers, or nil.R5,i31,R6,i1,R7,s17,arbace/j2g/jrt.aev14,arbace.j2g.jrt9,scan-filem10,R3,L1,V1,R4,R0,s172,Declarations of one jrt forms file: {:types {name {:kind :struct|:interface|:other :form f}}\n  :methods {type #{names}} :funcs #{} :vars #{} :classes {java-name var-name}}.R5,i45,R6,i1,R7,s17,arbace/j2g/jrt.aev14,arbace.j2g.jrt15,interface-elemsm12,R2,TR3,L1,V1,R12,R0,s68,Method names and embedded interface names of an interface type form.R5,i103,R6,i1,R7,s17,arbace/j2g/jrt.aev14,arbace.j2g.jrt12,struct-embedm12,R2,TR3,L1,V1,R12,R0,s69,The embedded type name of a struct's first field, when it embeds one.R5,i111,R6,i1,R7,s17,arbace/j2g/jrt.aev14,arbace.j2g.jrt13,other-system?m12,R2,TR3,L1,V1,Myn1,nm2,R13,R14,R0,s140,Whether a forms file is named for a system other than Linux (Go's file name constraint,\n  NAME_GOOS.ae), so that a Linux build never has it.R5,i117,R6,i1,R7,s17,arbace/j2g/jrt.aev14,arbace.j2g.jrt4,scanm10,R3,L1,V1,R15,R0,s438,Scans jrt's hand-written forms directory (go/arbace/jrt, test files excluded, and the files\n  of other systems than Linux, which j2g translates for: those named for one by Go's file name\n  rule, such as the box's hostbox_tamago.ae, doc/go/BOX-NOTES.md). Returns\n  {:files {file-name scan} :types :methods :funcs :vars :classes {java-name {:var :go :file\n  :standin}} :interfaces {name {:methods :embeds}} :embeds {struct first-embedded}}.R5,i123,R6,i1,R7,s17,arbace/j2g/jrt.aev14,arbace.j2g.jrt14,struct-methodsm10,R3,L1,V2,R16,R17,R0,s86,The method names a struct type has, its embedded ancestors' included (Go's promotion).R5,i154,R6,i1,R7,s17,arbace/j2g/jrt.aev14,arbace.j2g.jrt13,iface-methodsm10,R3,L1,V2,R16,R17,R0,s68,The method names of an interface type, embedded interfaces included.R5,i162,R6,i1,R7,s17,arbace/j2g/jrt.ae")

var Lit_37 *jrt.String = jrt.Intern("arbace.j2g.jrt$eval1716000004$loading__1927001464__auto____1716000005")

var Lit_38 *jrt.String = jrt.Intern("arbace.j2g.jrt$eval1716000008$fn__1716000009")

var Lit_39 *jrt.String = jrt.Intern("arbace.j2g.jrt$head")

var Lit_40 *jrt.String = jrt.Intern("arbace.j2g.jrt$go_head")

var Lit_41 *jrt.String = jrt.Intern("arbace.j2g.jrt$tag_of")

var Lit_42 *jrt.String = jrt.Intern("arbace.j2g.jrt$recv_type")

var Lit_43 *jrt.String = jrt.Intern("arbace.j2g.jrt$strip_doc")

var Lit_44 *jrt.String = jrt.Intern("arbace.j2g.jrt$define_name")

var Lit_45 *jrt.String = jrt.Intern("arbace.j2g.jrt$scan_file")

var Lit_46 *jrt.String = jrt.Intern("arbace.j2g.jrt$interface_elems")

var Lit_47 *jrt.String = jrt.Intern("arbace.j2g.jrt$struct_embed")

var Lit_48 *jrt.String = jrt.Intern("arbace.j2g.jrt$other_system_QMARK_")

var Lit_49 *jrt.String = jrt.Intern("arbace.j2g.jrt$scan")

var Lit_50 *jrt.String = jrt.Intern("arbace.j2g.jrt$struct_methods")

var Lit_51 *jrt.String = jrt.Intern("arbace.j2g.jrt$iface_methods")
