//line aot_arbace_aot_emit__init.ae:1
package aot_arbace_aot_emit

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_aot_emit__init_A_Unit0__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_aot_emit__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit__init_A_const_1) }
//line :1:1
func A_arbace_aot_emit__init_A_Unit1__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_aot_emit__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_2)) }
//line :1:1
func A_arbace_aot_emit__init_A_Unit2__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A_New(); var tmp2 *jrt.Class; A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A_Init(); tmp2 = A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_aot_emit__init_A_Unit3__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_aot_emit__init_A_const_1)).Equals_O__Z(A_arbace_aot_emit__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_aot_emit_eval90000008_fn__90000009_A_New(); var tmp2 *jrt.Class; A_arbace_aot_emit_eval90000008_fn__90000009_A_Init(); tmp2 = A_arbace_aot_emit_eval90000008_fn__90000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_aot_emit__init_A_Load__O() any { A_arbace_aot_emit__init_A_Init(); A_arbace_aot_emit__init_A_Unit0__O(); A_arbace_aot_emit__init_A_Unit1__O(); A_arbace_aot_emit__init_A_Unit2__O(); A_arbace_aot_emit__init_A_Unit3__O(); A_arbace_aot_emit__init_A_Unit4__O(); A_arbace_aot_emit__init_A_Unit5__O(); A_arbace_aot_emit__init_A_Unit6__O(); A_arbace_aot_emit__init_A_Unit7__O(); A_arbace_aot_emit__init_A_Unit8__O(); A_arbace_aot_emit__init_A_Unit9__O(); A_arbace_aot_emit__init_A_Unit10__O(); A_arbace_aot_emit__init_A_Unit11__O(); A_arbace_aot_emit__init_A_Unit12__O(); A_arbace_aot_emit__init_A_Unit13__O(); A_arbace_aot_emit__init_A_Unit14__O(); A_arbace_aot_emit__init_A_Unit15__O(); A_arbace_aot_emit__init_A_Unit16__O(); A_arbace_aot_emit__init_A_Unit17__O(); A_arbace_aot_emit__init_A_Unit18__O(); A_arbace_aot_emit__init_A_Unit19__O(); A_arbace_aot_emit__init_A_Unit20__O(); A_arbace_aot_emit__init_A_Unit21__O(); A_arbace_aot_emit__init_A_Unit22__O(); A_arbace_aot_emit__init_A_Unit23__O(); A_arbace_aot_emit__init_A_Unit24__O(); A_arbace_aot_emit__init_A_Unit25__O(); A_arbace_aot_emit__init_A_Unit26__O(); A_arbace_aot_emit__init_A_Unit27__O(); A_arbace_aot_emit__init_A_Unit28__O(); A_arbace_aot_emit__init_A_Unit29__O(); A_arbace_aot_emit__init_A_Unit30__O(); A_arbace_aot_emit__init_A_Unit31__O(); A_arbace_aot_emit__init_A_Unit32__O(); A_arbace_aot_emit__init_A_Unit33__O(); A_arbace_aot_emit__init_A_Unit34__O(); A_arbace_aot_emit__init_A_Unit35__O(); A_arbace_aot_emit__init_A_Unit36__O(); A_arbace_aot_emit__init_A_Unit37__O(); A_arbace_aot_emit__init_A_Unit38__O(); A_arbace_aot_emit__init_A_Unit39__O(); A_arbace_aot_emit__init_A_Unit40__O(); A_arbace_aot_emit__init_A_Unit41__O(); A_arbace_aot_emit__init_A_Unit42__O(); A_arbace_aot_emit__init_A_Unit43__O(); A_arbace_aot_emit__init_A_Unit44__O(); A_arbace_aot_emit__init_A_Unit45__O(); A_arbace_aot_emit__init_A_Unit46__O(); A_arbace_aot_emit__init_A_Unit47__O(); A_arbace_aot_emit__init_A_Unit48__O(); A_arbace_aot_emit__init_A_Unit49__O(); A_arbace_aot_emit__init_A_Unit50__O(); A_arbace_aot_emit__init_A_Unit51__O(); A_arbace_aot_emit__init_A_Unit52__O(); A_arbace_aot_emit__init_A_Unit53__O(); A_arbace_aot_emit__init_A_Unit54__O(); A_arbace_aot_emit__init_A_Unit55__O(); A_arbace_aot_emit__init_A_Unit56__O(); A_arbace_aot_emit__init_A_Unit57__O(); A_arbace_aot_emit__init_A_Unit58__O(); A_arbace_aot_emit__init_A_Unit59__O(); A_arbace_aot_emit__init_A_Unit60__O(); A_arbace_aot_emit__init_A_Unit61__O(); A_arbace_aot_emit__init_A_Unit62__O(); A_arbace_aot_emit__init_A_Unit63__O(); A_arbace_aot_emit__init_A_Unit64__O(); A_arbace_aot_emit__init_A_Unit65__O(); A_arbace_aot_emit__init_A_Unit66__O(); A_arbace_aot_emit__init_A_Unit67__O(); A_arbace_aot_emit__init_A_Unit68__O(); A_arbace_aot_emit__init_A_Unit69__O(); A_arbace_aot_emit__init_A_Unit70__O(); A_arbace_aot_emit__init_A_Unit71__O(); A_arbace_aot_emit__init_A_Unit72__O(); A_arbace_aot_emit__init_A_Unit73__O(); A_arbace_aot_emit__init_A_Unit74__O(); A_arbace_aot_emit__init_A_Unit75__O(); A_arbace_aot_emit__init_A_Unit76__O(); A_arbace_aot_emit__init_A_Unit77__O(); A_arbace_aot_emit__init_A_Unit78__O(); A_arbace_aot_emit__init_A_Unit79__O(); A_arbace_aot_emit__init_A_Unit80__O(); A_arbace_aot_emit__init_A_Unit81__O(); A_arbace_aot_emit__init_A_Unit82__O(); A_arbace_aot_emit__init_A_Unit83__O(); A_arbace_aot_emit__init_A_Unit84__O(); A_arbace_aot_emit__init_A_Unit85__O(); A_arbace_aot_emit__init_A_Unit86__O(); A_arbace_aot_emit__init_A_Unit87__O(); A_arbace_aot_emit__init_A_Unit88__O(); A_arbace_aot_emit__init_A_Unit89__O(); A_arbace_aot_emit__init_A_Unit90__O(); A_arbace_aot_emit__init_A_Unit91__O(); A_arbace_aot_emit__init_A_Unit92__O(); A_arbace_aot_emit__init_A_Unit93__O(); A_arbace_aot_emit__init_A_Unit94__O(); A_arbace_aot_emit__init_A_Unit95__O(); return nil }




























func A_arbace_aot_emit__init_A_Unit4__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(34, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_4; jrt.NN(tmp1).BindRoot_O__V(jrt.IdentityHashMap_New()); var tmp2 *lang.Var = A_arbace_aot_emit__init_A_const_4; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_5)); return A_arbace_aot_emit__init_A_const_4.Ref() }



func A_arbace_aot_emit__init_A_Unit5__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(38, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_6; var tmp2 any = A_arbace_aot_emit_node_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_node_A_Init(); tmp3 = A_arbace_aot_emit_node_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_7)); return A_arbace_aot_emit__init_A_const_6.Ref() }








func A_arbace_aot_emit__init_A_Unit6__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(47, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_8; var tmp2 any = A_arbace_aot_emit_fail_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_fail_A_Init(); tmp3 = A_arbace_aot_emit_fail_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_9)); return A_arbace_aot_emit__init_A_const_8.Ref() }





func A_arbace_aot_emit__init_A_Unit7__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(53, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_10; var tmp2 any = A_arbace_aot_emit_destub_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_destub_A_Init(); tmp3 = A_arbace_aot_emit_destub_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_11)); return A_arbace_aot_emit__init_A_const_10.Ref() }




func A_arbace_aot_emit__init_A_Unit8__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(58, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_12; var tmp2 any = A_arbace_aot_emit_type_sym_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_type_sym_A_Init(); tmp3 = A_arbace_aot_emit_type_sym_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_13)); return A_arbace_aot_emit__init_A_const_12.Ref() }










func A_arbace_aot_emit__init_A_Unit9__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(69, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_14; var tmp2 *jrt.Class; jrt.Void_Init(); tmp2 = jrt.Void_TYPE; var tmp3 any = tmp2.Ref(); var tmp4 any = A_arbace_aot_emit__init_A_const_15; var tmp5 *jrt.Class; jrt.Double_Init(); tmp5 = jrt.Double_TYPE; var tmp6 any = tmp5.Ref(); var tmp7 any = A_arbace_aot_emit__init_A_const_16; var tmp8 *jrt.Class; jrt.Character_Init(); tmp8 = jrt.Character_TYPE; var tmp9 any = tmp8.Ref(); var tmp10 any = A_arbace_aot_emit__init_A_const_17; var tmp11 *jrt.Class; jrt.Byte_Init(); tmp11 = jrt.Byte_TYPE; var tmp12 any = tmp11.Ref(); var tmp13 any = A_arbace_aot_emit__init_A_const_18; var tmp14 *jrt.Class; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TYPE; var tmp15 any = tmp14.Ref(); var tmp16 any = A_arbace_aot_emit__init_A_const_19; var tmp17 *jrt.Class; jrt.Float_Init(); tmp17 = jrt.Float_TYPE; var tmp18 any = tmp17.Ref(); var tmp19 any = A_arbace_aot_emit__init_A_const_20; var tmp20 *jrt.Class; jrt.Long_Init(); tmp20 = jrt.Long_TYPE; var tmp21 any = tmp20.Ref(); var tmp22 any = A_arbace_aot_emit__init_A_const_21; var tmp23 *jrt.Class; jrt.Short_Init(); tmp23 = jrt.Short_TYPE; var tmp24 any = tmp23.Ref(); var tmp25 any = A_arbace_aot_emit__init_A_const_22; var tmp26 *jrt.Class; jrt.Integer_Init(); tmp26 = jrt.Integer_TYPE; jrt.NN(tmp1).BindRoot_O__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp6, tmp7, tmp9, tmp10, tmp12, tmp13, tmp15, tmp16, tmp18, tmp19, tmp21, tmp22, tmp24, tmp25, tmp26.Ref(), A_arbace_aot_emit__init_A_const_23))); var tmp27 *lang.Var = A_arbace_aot_emit__init_A_const_14; jrt.NN(tmp27).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_24)); return A_arbace_aot_emit__init_A_const_14.Ref() }



func A_arbace_aot_emit__init_A_Unit10__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(73, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_25; var tmp2 any = A_arbace_aot_emit_tagged_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_tagged_A_Init(); tmp3 = A_arbace_aot_emit_tagged_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_25; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_26)); return A_arbace_aot_emit__init_A_const_25.Ref() }








func A_arbace_aot_emit__init_A_Unit11__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(82, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_27; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_aot_emit__init_A_const_28).GetRawRoot__O()); var tmp3 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; jrt.NN(tmp1).BindRoot_O__V(tmp2.Invoke_O__O(tmp3.Ref())); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_27; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_29)); return A_arbace_aot_emit__init_A_const_27.Ref() }



func A_arbace_aot_emit__init_A_Unit12__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(86, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_30; var tmp2 any = A_arbace_aot_emit_registered_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_registered_QMARK__A_Init(); tmp3 = A_arbace_aot_emit_registered_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_30; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_31)); return A_arbace_aot_emit__init_A_const_30.Ref() }
















func A_arbace_aot_emit__init_A_Unit13__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(103, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_32; var tmp2 any = A_arbace_aot_emit_runtime_class_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_runtime_class_QMARK__A_Init(); tmp3 = A_arbace_aot_emit_runtime_class_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_32; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_33)); return A_arbace_aot_emit__init_A_const_32.Ref() }








func A_arbace_aot_emit__init_A_Unit14__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(112, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_34; var tmp2 any = A_arbace_aot_emit_public_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_public_QMARK__A_Init(); tmp3 = A_arbace_aot_emit_public_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_34; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_35)); return A_arbace_aot_emit__init_A_const_34.Ref() }





func A_arbace_aot_emit__init_A_Unit15__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(118, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_36; var tmp2 any = A_arbace_aot_emit_top_name_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_top_name_A_Init(); tmp3 = A_arbace_aot_emit_top_name_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_36; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_37)); return A_arbace_aot_emit__init_A_const_36.Ref() }

func A_arbace_aot_emit__init_A_Unit16__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(120, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_38; var tmp2 any = A_arbace_aot_emit_pool_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_pool_A_Init(); tmp3 = A_arbace_aot_emit_pool_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_38; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_39)); return A_arbace_aot_emit__init_A_const_38.Ref() }









func A_arbace_aot_emit__init_A_Unit17__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(130, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_40; var tmp2 any = A_arbace_aot_emit_const_field_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_const_field_A_Init(); tmp3 = A_arbace_aot_emit_const_field_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_40; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_41)); return A_arbace_aot_emit__init_A_const_40.Ref() }













func A_arbace_aot_emit__init_A_Unit18__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(144, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_42; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_43)); return A_arbace_aot_emit__init_A_const_42.Ref() }

func A_arbace_aot_emit__init_A_Unit19__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(146, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_44; var tmp2 any = A_arbace_aot_emit_emit_list_array_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_emit_list_array_A_Init(); tmp3 = A_arbace_aot_emit_emit_list_array_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_44; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_45)); return A_arbace_aot_emit__init_A_const_44.Ref() }


func A_arbace_aot_emit__init_A_Unit20__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(149, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_46; var tmp2 any = A_arbace_aot_emit_char_form_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_char_form_A_Init(); tmp3 = A_arbace_aot_emit_char_form_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_46; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_47)); return A_arbace_aot_emit__init_A_const_46.Ref() }





func A_arbace_aot_emit__init_A_Unit21__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(155, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_48; var tmp2 any = A_arbace_aot_emit_double_form_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_double_form_A_Init(); tmp3 = A_arbace_aot_emit_double_form_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_48; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_49)); return A_arbace_aot_emit__init_A_const_48.Ref() }




func A_arbace_aot_emit__init_A_Unit22__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(160, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_42; var tmp2 any = A_arbace_aot_emit_emit_value_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_emit_value_A_Init(); tmp3 = A_arbace_aot_emit_emit_value_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_42; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_50)); return A_arbace_aot_emit__init_A_const_42.Ref() }




































































func A_arbace_aot_emit__init_A_Unit23__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(229, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_51; var tmp2 any = A_arbace_aot_emit_const_type_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_const_type_A_Init(); tmp3 = A_arbace_aot_emit_const_type_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_51; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_52)); return A_arbace_aot_emit__init_A_const_51.Ref() }





func A_arbace_aot_emit__init_A_Unit24__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(235, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_53; var tmp2 any = A_arbace_aot_emit_constant_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_constant_A_Init(); tmp3 = A_arbace_aot_emit_constant_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_53; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_54)); return A_arbace_aot_emit__init_A_const_53.Ref() }












func A_arbace_aot_emit__init_A_Unit25__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(248, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_55; var tmp2 any = A_arbace_aot_emit_gsym_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_gsym_A_Init(); tmp3 = A_arbace_aot_emit_gsym_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_55; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_56)); return A_arbace_aot_emit__init_A_const_55.Ref() }







func A_arbace_aot_emit__init_A_Unit26__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(256, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_57; var tmp2 any = A_arbace_aot_emit_local_sym_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_local_sym_A_Init(); tmp3 = A_arbace_aot_emit_local_sym_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_57; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_58)); return A_arbace_aot_emit__init_A_const_57.Ref() }





func A_arbace_aot_emit__init_A_Unit27__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(262, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_59; var tmp2 any = A_arbace_aot_emit_identity_set_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_identity_set_A_Init(); tmp3 = A_arbace_aot_emit_identity_set_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_59; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_60)); return A_arbace_aot_emit__init_A_const_59.Ref() }








func A_arbace_aot_emit__init_A_Unit28__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(271, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_61; var tmp2 any = A_arbace_aot_emit_closed_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_closed_QMARK__A_Init(); tmp3 = A_arbace_aot_emit_closed_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_61; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_62)); return A_arbace_aot_emit__init_A_const_61.Ref() }



func A_arbace_aot_emit__init_A_Unit29__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(275, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_63; var tmp2 any = A_arbace_aot_emit_field_sym_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_field_sym_A_Init(); tmp3 = A_arbace_aot_emit_field_sym_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_63; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_64)); return A_arbace_aot_emit__init_A_const_63.Ref() }

func A_arbace_aot_emit__init_A_Unit30__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(277, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_65; var tmp2 any = A_arbace_aot_emit_field_read_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_field_read_A_Init(); tmp3 = A_arbace_aot_emit_field_read_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_65; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_66)); return A_arbace_aot_emit__init_A_const_65.Ref() }





func A_arbace_aot_emit__init_A_Unit31__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(283, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_67; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_68)); return A_arbace_aot_emit__init_A_const_67.Ref() }
//line :283:1
func A_arbace_aot_emit__init_A_Unit32__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(283, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_69; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_70)); return A_arbace_aot_emit__init_A_const_69.Ref() }
//line :283:1
func A_arbace_aot_emit__init_A_Unit33__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(283, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_71; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_72)); return A_arbace_aot_emit__init_A_const_71.Ref() }
//line :283:1
func A_arbace_aot_emit__init_A_Unit34__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(283, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_73; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_74)); return A_arbace_aot_emit__init_A_const_73.Ref() }
//line :283:1
func A_arbace_aot_emit__init_A_Unit35__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(283, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_75; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_76)); return A_arbace_aot_emit__init_A_const_75.Ref() }

func A_arbace_aot_emit__init_A_Unit36__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(285, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_77; var tmp2 any = A_arbace_aot_emit_prim_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_prim_A_Init(); tmp3 = A_arbace_aot_emit_prim_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_77; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_78)); return A_arbace_aot_emit__init_A_const_77.Ref() }

func A_arbace_aot_emit__init_A_Unit37__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(287, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_79; var tmp2 any = A_arbace_aot_emit_can_prim_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_can_prim_QMARK__A_Init(); tmp3 = A_arbace_aot_emit_can_prim_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_79; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_80)); return A_arbace_aot_emit__init_A_const_79.Ref() }

func A_arbace_aot_emit__init_A_Unit38__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(289, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_81; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_82)); return A_arbace_aot_emit__init_A_const_81.Ref() }

func A_arbace_aot_emit__init_A_Unit39__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(291, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_83; var tmp2 any = A_arbace_aot_emit_box_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_box_A_Init(); tmp3 = A_arbace_aot_emit_box_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_83; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_84)); return A_arbace_aot_emit__init_A_const_83.Ref() }








func A_arbace_aot_emit__init_A_Unit40__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(300, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_85; var tmp2 any = A_arbace_aot_emit_unbox_arg_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_unbox_arg_A_Init(); tmp3 = A_arbace_aot_emit_unbox_arg_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_85; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_86)); return A_arbace_aot_emit__init_A_const_85.Ref() }


















func A_arbace_aot_emit__init_A_Unit41__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(319, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_87; var tmp2 any = A_arbace_aot_emit_fi_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_fi_QMARK__A_Init(); tmp3 = A_arbace_aot_emit_fi_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_87; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_88)); return A_arbace_aot_emit__init_A_const_87.Ref() }






func A_arbace_aot_emit__init_A_Unit42__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(326, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_89; var tmp2 any = A_arbace_aot_emit_typed_args_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_typed_args_A_Init(); tmp3 = A_arbace_aot_emit_typed_args_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_89; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_90)); return A_arbace_aot_emit__init_A_const_89.Ref() }























func A_arbace_aot_emit__init_A_Unit43__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(350, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_91; var tmp2 any = A_arbace_aot_emit_param_tags_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_param_tags_A_Init(); tmp3 = A_arbace_aot_emit_param_tags_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_91; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_92)); return A_arbace_aot_emit__init_A_const_91.Ref() }

func A_arbace_aot_emit__init_A_Unit44__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(352, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_93; var tmp2 any = A_arbace_aot_emit_obj_array_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_obj_array_A_Init(); tmp3 = A_arbace_aot_emit_obj_array_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_93; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_94)); return A_arbace_aot_emit__init_A_const_93.Ref() }


func A_arbace_aot_emit__init_A_Unit45__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(355, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_95; var tmp2 any = A_arbace_aot_emit_var_value_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_var_value_A_Init(); tmp3 = A_arbace_aot_emit_var_value_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_95; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_96)); return A_arbace_aot_emit__init_A_const_95.Ref() }



func A_arbace_aot_emit__init_A_Unit46__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(359, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_97; var tmp2 any = A_arbace_aot_emit_line_meta_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_line_meta_A_Init(); tmp3 = A_arbace_aot_emit_line_meta_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_97; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_98)); return A_arbace_aot_emit__init_A_const_97.Ref() }




func A_arbace_aot_emit__init_A_Unit47__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(364, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_99; var tmp2 any = A_arbace_aot_emit_emit_local_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_emit_local_A_Init(); tmp3 = A_arbace_aot_emit_emit_local_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_99; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_100)); return A_arbace_aot_emit__init_A_const_99.Ref() }











func A_arbace_aot_emit__init_A_Unit48__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(376, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_101; var tmp2 any = A_arbace_aot_emit_emit_invoke_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_emit_invoke_A_Init(); tmp3 = A_arbace_aot_emit_emit_invoke_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_101; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_102)); return A_arbace_aot_emit__init_A_const_101.Ref() }





























func A_arbace_aot_emit__init_A_Unit49__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(406, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_103; var tmp2 any = A_arbace_aot_emit_descriptor_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_descriptor_A_Init(); tmp3 = A_arbace_aot_emit_descriptor_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_103; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_104)); return A_arbace_aot_emit__init_A_const_103.Ref() }







func A_arbace_aot_emit__init_A_Unit50__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(414, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_105; var tmp2 any = A_arbace_aot_emit_fn__90000088_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_fn__90000088_A_Init(); tmp3 = A_arbace_aot_emit_fn__90000088_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_105; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_106)); return A_arbace_aot_emit__init_A_const_105.Ref() }


func A_arbace_aot_emit__init_A_Unit51__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(417, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_107; var tmp2 any = A_arbace_aot_emit_jrt_lacks_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_jrt_lacks_QMARK__A_Init(); tmp3 = A_arbace_aot_emit_jrt_lacks_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_107; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_108)); return A_arbace_aot_emit__init_A_const_107.Ref() }


















func A_arbace_aot_emit__init_A_Unit52__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(436, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_109; var tmp2 any = A_arbace_aot_emit_method_call_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_method_call_A_Init(); tmp3 = A_arbace_aot_emit_method_call_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_109; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_110)); return A_arbace_aot_emit__init_A_const_109.Ref() }












func A_arbace_aot_emit__init_A_Unit53__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(449, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_111; var tmp2 any = A_arbace_aot_emit_compiled_interface_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_compiled_interface_QMARK__A_Init(); tmp3 = A_arbace_aot_emit_compiled_interface_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_111; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_112)); return A_arbace_aot_emit__init_A_const_111.Ref() }




func A_arbace_aot_emit__init_A_Unit54__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(454, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_113; var tmp2 any = A_arbace_aot_emit_emit_instance_method_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_emit_instance_method_A_Init(); tmp3 = A_arbace_aot_emit_emit_instance_method_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_113; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_114)); return A_arbace_aot_emit__init_A_const_113.Ref() }
































func A_arbace_aot_emit__init_A_Unit55__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(487, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_115; var tmp2 any = A_arbace_aot_emit_emit_static_method_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_emit_static_method_A_Init(); tmp3 = A_arbace_aot_emit_emit_static_method_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_115; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_116)); return A_arbace_aot_emit__init_A_const_115.Ref() }













func A_arbace_aot_emit__init_A_Unit56__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(501, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_117; var tmp2 any = A_arbace_aot_emit_field_ok_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_field_ok_QMARK__A_Init(); tmp3 = A_arbace_aot_emit_field_ok_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_117; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_118)); return A_arbace_aot_emit__init_A_const_117.Ref() }


func A_arbace_aot_emit__init_A_Unit57__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(504, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_119; var tmp2 any = A_arbace_aot_emit_emit_instance_field_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_emit_instance_field_A_Init(); tmp3 = A_arbace_aot_emit_emit_instance_field_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_119; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_120)); return A_arbace_aot_emit__init_A_const_119.Ref() }








func A_arbace_aot_emit__init_A_Unit58__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(513, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_121; var tmp2 any = A_arbace_aot_emit_emit_static_field_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_emit_static_field_A_Init(); tmp3 = A_arbace_aot_emit_emit_static_field_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_121; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_122)); return A_arbace_aot_emit__init_A_const_121.Ref() }







func A_arbace_aot_emit__init_A_Unit59__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(521, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_123; var tmp2 any = A_arbace_aot_emit_emit_new_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_emit_new_A_Init(); tmp3 = A_arbace_aot_emit_emit_new_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_123; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_124)); return A_arbace_aot_emit__init_A_const_123.Ref() }








func A_arbace_aot_emit__init_A_Unit60__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(530, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_125; var tmp2 any = A_arbace_aot_emit_emit_def_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_emit_def_A_Init(); tmp3 = A_arbace_aot_emit_emit_def_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_125; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_126)); return A_arbace_aot_emit__init_A_const_125.Ref() }

















func A_arbace_aot_emit__init_A_Unit61__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(548, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_127; var tmp2 any = A_arbace_aot_emit_emit_assign_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_emit_assign_A_Init(); tmp3 = A_arbace_aot_emit_emit_assign_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_127; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_128)); return A_arbace_aot_emit__init_A_const_127.Ref() }





















func A_arbace_aot_emit__init_A_Unit62__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(570, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_129; var tmp2 any = A_arbace_aot_emit_coll_call_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_coll_call_A_Init(); tmp3 = A_arbace_aot_emit_coll_call_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_129; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_130)); return A_arbace_aot_emit__init_A_const_129.Ref() }


func A_arbace_aot_emit__init_A_Unit63__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(573, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_131; var tmp2 any = A_arbace_aot_emit_emit_if_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_emit_if_A_Init(); tmp3 = A_arbace_aot_emit_emit_if_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_131; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_132)); return A_arbace_aot_emit__init_A_const_131.Ref() }








func A_arbace_aot_emit__init_A_Unit64__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(582, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_133; var tmp2 any = A_arbace_aot_emit_emit_binding_init_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_emit_binding_init_A_Init(); tmp3 = A_arbace_aot_emit_emit_binding_init_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_133; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_134)); return A_arbace_aot_emit__init_A_const_133.Ref() }








func A_arbace_aot_emit__init_A_Unit65__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(591, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_135; var tmp2 any = A_arbace_aot_emit_emit_let_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_emit_let_A_Init(); tmp3 = A_arbace_aot_emit_emit_let_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_135; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_136)); return A_arbace_aot_emit__init_A_const_135.Ref() }






func A_arbace_aot_emit__init_A_Unit66__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(598, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_137; var tmp2 any = A_arbace_aot_emit_emit_recur_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_emit_recur_A_Init(); tmp3 = A_arbace_aot_emit_emit_recur_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_137; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_138)); return A_arbace_aot_emit__init_A_const_137.Ref() }




















func A_arbace_aot_emit__init_A_Unit67__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(619, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_139; var tmp2 any = A_arbace_aot_emit_body_instance_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_body_instance_A_Init(); tmp3 = A_arbace_aot_emit_body_instance_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_139; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_140)); return A_arbace_aot_emit__init_A_const_139.Ref() }












func A_arbace_aot_emit__init_A_Unit68__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(632, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_141; var tmp2 any = A_arbace_aot_emit_fn_wrap_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_fn_wrap_A_Init(); tmp3 = A_arbace_aot_emit_fn_wrap_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_141; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_142)); return A_arbace_aot_emit__init_A_const_141.Ref() }










func A_arbace_aot_emit__init_A_Unit69__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(643, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_143; var tmp2 any = A_arbace_aot_emit_fn_instance_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_fn_instance_A_Init(); tmp3 = A_arbace_aot_emit_fn_instance_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_143; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_144)); return A_arbace_aot_emit__init_A_const_143.Ref() }





func A_arbace_aot_emit__init_A_Unit70__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(649, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_145; var tmp2 any = A_arbace_aot_emit_emit_letfn_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_emit_letfn_A_Init(); tmp3 = A_arbace_aot_emit_emit_letfn_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_145; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_146)); return A_arbace_aot_emit__init_A_const_145.Ref() }
















func A_arbace_aot_emit__init_A_Unit71__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(666, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_147; var tmp2 any = A_arbace_aot_emit_emit_try_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_emit_try_A_Init(); tmp3 = A_arbace_aot_emit_emit_try_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_147; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_148)); return A_arbace_aot_emit__init_A_const_147.Ref() }








func A_arbace_aot_emit__init_A_Unit72__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(675, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_149; var tmp2 any = A_arbace_aot_emit_emit_case_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_emit_case_A_Init(); tmp3 = A_arbace_aot_emit_emit_case_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_149; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_150)); return A_arbace_aot_emit__init_A_const_149.Ref() }














































func A_arbace_aot_emit__init_A_Unit73__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(722, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_81; var tmp2 *jrt.Class; jrt.Long_Init(); tmp2 = jrt.Long_TYPE; var tmp3 any = tmp2.Ref(); var tmp4 any = A_arbace_aot_emit__init_A_const_151; var tmp5 *jrt.Class; jrt.Double_Init(); tmp5 = jrt.Double_TYPE; var tmp6 any = tmp5.Ref(); var tmp7 any = A_arbace_aot_emit__init_A_const_152; var tmp8 *jrt.Class; jrt.Integer_Init(); tmp8 = jrt.Integer_TYPE; var tmp9 any = tmp8.Ref(); var tmp10 any = A_arbace_aot_emit__init_A_const_153; var tmp11 *jrt.Class; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TYPE; var tmp12 any = tmp11.Ref(); var tmp13 any = A_arbace_aot_emit__init_A_const_154; var tmp14 *jrt.Class; jrt.Character_Init(); tmp14 = jrt.Character_TYPE; var tmp15 any = tmp14.Ref(); var tmp16 any = A_arbace_aot_emit__init_A_const_155; var tmp17 *jrt.Class; jrt.Float_Init(); tmp17 = jrt.Float_TYPE; var tmp18 any = tmp17.Ref(); var tmp19 any = A_arbace_aot_emit__init_A_const_156; var tmp20 *jrt.Class; jrt.Short_Init(); tmp20 = jrt.Short_TYPE; var tmp21 any = tmp20.Ref(); var tmp22 any = A_arbace_aot_emit__init_A_const_157; var tmp23 *jrt.Class; jrt.Byte_Init(); tmp23 = jrt.Byte_TYPE; jrt.NN(tmp1).BindRoot_O__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp6, tmp7, tmp9, tmp10, tmp12, tmp13, tmp15, tmp16, tmp18, tmp19, tmp21, tmp22, tmp23.Ref(), A_arbace_aot_emit__init_A_const_158))); var tmp24 *lang.Var = A_arbace_aot_emit__init_A_const_81; jrt.NN(tmp24).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_159)); return A_arbace_aot_emit__init_A_const_81.Ref() }





func A_arbace_aot_emit__init_A_Unit74__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(728, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_160; var tmp2 any = A_arbace_aot_emit_box_prim_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_box_prim_A_Init(); tmp3 = A_arbace_aot_emit_box_prim_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_160; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_161)); return A_arbace_aot_emit__init_A_const_160.Ref() }










func A_arbace_aot_emit__init_A_Unit75__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(739, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_67; var tmp2 any = A_arbace_aot_emit_emit_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_emit_A_Init(); tmp3 = A_arbace_aot_emit_emit_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_67; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_162)); return A_arbace_aot_emit__init_A_const_67.Ref() }











































































func A_arbace_aot_emit__init_A_Unit76__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(815, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_69; var tmp2 any = A_arbace_aot_emit_emit_unboxed_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_emit_unboxed_A_Init(); tmp3 = A_arbace_aot_emit_emit_unboxed_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_69; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_163)); return A_arbace_aot_emit__init_A_const_69.Ref() }































func A_arbace_aot_emit__init_A_Unit77__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(847, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_164; var tmp2 any = A_arbace_aot_emit_deep_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_deep_A_Init(); tmp3 = A_arbace_aot_emit_deep_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_164; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_165)); return A_arbace_aot_emit__init_A_const_164.Ref() }








func A_arbace_aot_emit__init_A_Unit78__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(856, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_166; var tmp2 any = A_arbace_aot_emit_simple_name_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_simple_name_A_Init(); tmp3 = A_arbace_aot_emit_simple_name_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_166; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_167)); return A_arbace_aot_emit__init_A_const_166.Ref() }


func A_arbace_aot_emit__init_A_Unit79__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(859, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_168; var tmp2 any = A_arbace_aot_emit_throws_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_throws_QMARK__A_Init(); tmp3 = A_arbace_aot_emit_throws_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_168; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_169)); return A_arbace_aot_emit__init_A_const_168.Ref() }








func A_arbace_aot_emit__init_A_Unit80__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(868, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_170; var tmp2 any = A_arbace_aot_emit_ret_body_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_ret_body_A_Init(); tmp3 = A_arbace_aot_emit_ret_body_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_170; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_171)); return A_arbace_aot_emit__init_A_const_170.Ref() }

























func A_arbace_aot_emit__init_A_Unit81__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(894, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_172; var tmp2 any = A_arbace_aot_emit_method_body_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_method_body_A_Init(); tmp3 = A_arbace_aot_emit_method_body_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_172; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_173)); return A_arbace_aot_emit__init_A_const_172.Ref() }




































func A_arbace_aot_emit__init_A_Unit82__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(931, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_174; var tmp2 any = A_arbace_aot_emit_param_sym_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_param_sym_A_Init(); tmp3 = A_arbace_aot_emit_param_sym_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_174; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_175)); return A_arbace_aot_emit__init_A_const_174.Ref() }





func A_arbace_aot_emit__init_A_Unit83__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(937, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_176; var tmp2 any = A_arbace_aot_emit__init_A_const_177; var tmp3 *jrt.Class; jrt.Long_Init(); tmp3 = jrt.Long_TYPE; var tmp4 any = tmp3.Ref(); var tmp5 any = A_arbace_aot_emit__init_A_const_178; var tmp6 *jrt.Class; jrt.Double_Init(); tmp6 = jrt.Double_TYPE; var tmp7 any = tmp6.Ref(); var tmp8 any = A_arbace_aot_emit__init_A_const_179; var tmp9 *jrt.Class; jrt.Integer_Init(); tmp9 = jrt.Integer_TYPE; var tmp10 any = tmp9.Ref(); var tmp11 any = A_arbace_aot_emit__init_A_const_180; var tmp12 *jrt.Class; jrt.Boolean_Init(); tmp12 = jrt.Boolean_TYPE; var tmp13 any = tmp12.Ref(); var tmp14 any = A_arbace_aot_emit__init_A_const_181; var tmp15 *jrt.Class; jrt.Character_Init(); tmp15 = jrt.Character_TYPE; var tmp16 any = tmp15.Ref(); var tmp17 any = A_arbace_aot_emit__init_A_const_182; var tmp18 *jrt.Class; jrt.Float_Init(); tmp18 = jrt.Float_TYPE; var tmp19 any = tmp18.Ref(); var tmp20 any = A_arbace_aot_emit__init_A_const_183; var tmp21 *jrt.Class; jrt.Short_Init(); tmp21 = jrt.Short_TYPE; var tmp22 any = tmp21.Ref(); var tmp23 any = A_arbace_aot_emit__init_A_const_184; var tmp24 *jrt.Class; jrt.Byte_Init(); tmp24 = jrt.Byte_TYPE; jrt.NN(tmp1).BindRoot_O__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp4, tmp5, tmp7, tmp8, tmp10, tmp11, tmp13, tmp14, tmp16, tmp17, tmp19, tmp20, tmp22, tmp23, tmp24.Ref()))); var tmp25 *lang.Var = A_arbace_aot_emit__init_A_const_176; jrt.NN(tmp25).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_185)); return A_arbace_aot_emit__init_A_const_176.Ref() }



func A_arbace_aot_emit__init_A_Unit84__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(941, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_186; var tmp2 any = A_arbace_aot_emit_tag_class_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_tag_class_A_Init(); tmp3 = A_arbace_aot_emit_tag_class_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_186; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_187)); return A_arbace_aot_emit__init_A_const_186.Ref() }








func A_arbace_aot_emit__init_A_Unit85__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(950, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_188; var tmp2 any = A_arbace_aot_emit_box_class_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_box_class_A_Init(); tmp3 = A_arbace_aot_emit_box_class_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_188; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_189)); return A_arbace_aot_emit__init_A_const_188.Ref() }



func A_arbace_aot_emit__init_A_Unit86__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(954, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_190; var tmp2 any = A_arbace_aot_emit_class_interfaces_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_class_interfaces_A_Init(); tmp3 = A_arbace_aot_emit_class_interfaces_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_190; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_191)); return A_arbace_aot_emit__init_A_const_190.Ref() }










func A_arbace_aot_emit__init_A_Unit87__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(965, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_192; var tmp2 any = A_arbace_aot_emit_field_mods_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_field_mods_A_Init(); tmp3 = A_arbace_aot_emit_field_mods_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_192; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_193)); return A_arbace_aot_emit__init_A_const_192.Ref() }









func A_arbace_aot_emit__init_A_Unit88__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(975, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_73; var tmp2 any = A_arbace_aot_emit_emit_deftype_class_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_emit_deftype_class_BANG__A_Init(); tmp3 = A_arbace_aot_emit_emit_deftype_class_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_73; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_194)); return A_arbace_aot_emit__init_A_const_73.Ref() }


































































func A_arbace_aot_emit__init_A_Unit89__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1042, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_71; var tmp2 any = A_arbace_aot_emit_emit_fn_class_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_emit_fn_class_BANG__A_Init(); tmp3 = A_arbace_aot_emit_emit_fn_class_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_71; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_195)); return A_arbace_aot_emit__init_A_const_71.Ref() }























































































func A_arbace_aot_emit__init_A_Unit90__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1130, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_196; var tmp2 any = A_arbace_aot_emit_unit_method_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_unit_method_A_Init(); tmp3 = A_arbace_aot_emit_unit_method_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_196; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_197)); return A_arbace_aot_emit__init_A_const_196.Ref() }








































func A_arbace_aot_emit__init_A_Unit91__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1171, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_198; var tmp2 any = A_arbace_aot_emit_unit_ns_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_unit_ns_A_Init(); tmp3 = A_arbace_aot_emit_unit_ns_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_198; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_199)); return A_arbace_aot_emit__init_A_const_198.Ref() }










func A_arbace_aot_emit__init_A_Unit92__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1182, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_200; var tmp2 any = A_arbace_aot_emit_emit_source_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_emit_source_A_Init(); tmp3 = A_arbace_aot_emit_emit_source_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_200; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_201)); return A_arbace_aot_emit__init_A_const_200.Ref() }




























func A_arbace_aot_emit__init_A_Unit93__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1211, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_202; var tmp2 any = A_arbace_aot_emit_class_form_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_class_form_A_Init(); tmp3 = A_arbace_aot_emit_class_form_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_202; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_203)); return A_arbace_aot_emit__init_A_const_202.Ref() }































func A_arbace_aot_emit__init_A_Unit94__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1243, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_204; var tmp2 any = A_arbace_aot_emit_class_forms_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_class_forms_A_Init(); tmp3 = A_arbace_aot_emit_class_forms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_204; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_205)); return A_arbace_aot_emit__init_A_const_204.Ref() }





















func A_arbace_aot_emit__init_A_Unit95__O() any { A_arbace_aot_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1265, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_A_const_206; var tmp2 any = A_arbace_aot_emit_interface_record_A_New(); var tmp3 *jrt.Class; A_arbace_aot_emit_interface_record_A_Init(); tmp3 = A_arbace_aot_emit_interface_record_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_A_const_206; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_A_const_207)); return A_arbace_aot_emit__init_A_const_206.Ref() }



type A_arbace_aot_emit__init_A struct{ jrt.Object }

var A_arbace_aot_emit__init_A_const_0 *lang.Var

var A_arbace_aot_emit__init_A_const_1 any

var A_arbace_aot_emit__init_A_const_2 any

var A_arbace_aot_emit__init_A_const_3 any

var A_arbace_aot_emit__init_A_const_4 *lang.Var

var A_arbace_aot_emit__init_A_const_5 any

var A_arbace_aot_emit__init_A_const_6 *lang.Var

var A_arbace_aot_emit__init_A_const_7 any

var A_arbace_aot_emit__init_A_const_8 *lang.Var

var A_arbace_aot_emit__init_A_const_9 any

var A_arbace_aot_emit__init_A_const_10 *lang.Var

var A_arbace_aot_emit__init_A_const_11 any

var A_arbace_aot_emit__init_A_const_12 *lang.Var

var A_arbace_aot_emit__init_A_const_13 any

var A_arbace_aot_emit__init_A_const_14 *lang.Var

var A_arbace_aot_emit__init_A_const_15 any

var A_arbace_aot_emit__init_A_const_16 any

var A_arbace_aot_emit__init_A_const_17 any

var A_arbace_aot_emit__init_A_const_18 any

var A_arbace_aot_emit__init_A_const_19 any

var A_arbace_aot_emit__init_A_const_20 any

var A_arbace_aot_emit__init_A_const_21 any

var A_arbace_aot_emit__init_A_const_22 any

var A_arbace_aot_emit__init_A_const_23 any

var A_arbace_aot_emit__init_A_const_24 any

var A_arbace_aot_emit__init_A_const_25 *lang.Var

var A_arbace_aot_emit__init_A_const_26 any

var A_arbace_aot_emit__init_A_const_27 *lang.Var

var A_arbace_aot_emit__init_A_const_28 *lang.Var

var A_arbace_aot_emit__init_A_const_29 any

var A_arbace_aot_emit__init_A_const_30 *lang.Var

var A_arbace_aot_emit__init_A_const_31 any

var A_arbace_aot_emit__init_A_const_32 *lang.Var

var A_arbace_aot_emit__init_A_const_33 any

var A_arbace_aot_emit__init_A_const_34 *lang.Var

var A_arbace_aot_emit__init_A_const_35 any

var A_arbace_aot_emit__init_A_const_36 *lang.Var

var A_arbace_aot_emit__init_A_const_37 any

var A_arbace_aot_emit__init_A_const_38 *lang.Var

var A_arbace_aot_emit__init_A_const_39 any

var A_arbace_aot_emit__init_A_const_40 *lang.Var

var A_arbace_aot_emit__init_A_const_41 any

var A_arbace_aot_emit__init_A_const_42 *lang.Var

var A_arbace_aot_emit__init_A_const_43 any

var A_arbace_aot_emit__init_A_const_44 *lang.Var

var A_arbace_aot_emit__init_A_const_45 any

var A_arbace_aot_emit__init_A_const_46 *lang.Var

var A_arbace_aot_emit__init_A_const_47 any

var A_arbace_aot_emit__init_A_const_48 *lang.Var

var A_arbace_aot_emit__init_A_const_49 any

var A_arbace_aot_emit__init_A_const_50 any

var A_arbace_aot_emit__init_A_const_51 *lang.Var

var A_arbace_aot_emit__init_A_const_52 any

var A_arbace_aot_emit__init_A_const_53 *lang.Var

var A_arbace_aot_emit__init_A_const_54 any

var A_arbace_aot_emit__init_A_const_55 *lang.Var

var A_arbace_aot_emit__init_A_const_56 any

var A_arbace_aot_emit__init_A_const_57 *lang.Var

var A_arbace_aot_emit__init_A_const_58 any

var A_arbace_aot_emit__init_A_const_59 *lang.Var

var A_arbace_aot_emit__init_A_const_60 any

var A_arbace_aot_emit__init_A_const_61 *lang.Var

var A_arbace_aot_emit__init_A_const_62 any

var A_arbace_aot_emit__init_A_const_63 *lang.Var

var A_arbace_aot_emit__init_A_const_64 any

var A_arbace_aot_emit__init_A_const_65 *lang.Var

var A_arbace_aot_emit__init_A_const_66 any

var A_arbace_aot_emit__init_A_const_67 *lang.Var

var A_arbace_aot_emit__init_A_const_68 any

var A_arbace_aot_emit__init_A_const_69 *lang.Var

var A_arbace_aot_emit__init_A_const_70 any

var A_arbace_aot_emit__init_A_const_71 *lang.Var

var A_arbace_aot_emit__init_A_const_72 any

var A_arbace_aot_emit__init_A_const_73 *lang.Var

var A_arbace_aot_emit__init_A_const_74 any

var A_arbace_aot_emit__init_A_const_75 *lang.Var

var A_arbace_aot_emit__init_A_const_76 any

var A_arbace_aot_emit__init_A_const_77 *lang.Var

var A_arbace_aot_emit__init_A_const_78 any

var A_arbace_aot_emit__init_A_const_79 *lang.Var

var A_arbace_aot_emit__init_A_const_80 any

var A_arbace_aot_emit__init_A_const_81 *lang.Var

var A_arbace_aot_emit__init_A_const_82 any

var A_arbace_aot_emit__init_A_const_83 *lang.Var

var A_arbace_aot_emit__init_A_const_84 any

var A_arbace_aot_emit__init_A_const_85 *lang.Var

var A_arbace_aot_emit__init_A_const_86 any

var A_arbace_aot_emit__init_A_const_87 *lang.Var

var A_arbace_aot_emit__init_A_const_88 any

var A_arbace_aot_emit__init_A_const_89 *lang.Var

var A_arbace_aot_emit__init_A_const_90 any

var A_arbace_aot_emit__init_A_const_91 *lang.Var

var A_arbace_aot_emit__init_A_const_92 any

var A_arbace_aot_emit__init_A_const_93 *lang.Var

var A_arbace_aot_emit__init_A_const_94 any

var A_arbace_aot_emit__init_A_const_95 *lang.Var

var A_arbace_aot_emit__init_A_const_96 any

var A_arbace_aot_emit__init_A_const_97 *lang.Var

var A_arbace_aot_emit__init_A_const_98 any

var A_arbace_aot_emit__init_A_const_99 *lang.Var

var A_arbace_aot_emit__init_A_const_100 any

var A_arbace_aot_emit__init_A_const_101 *lang.Var

var A_arbace_aot_emit__init_A_const_102 any

var A_arbace_aot_emit__init_A_const_103 *lang.Var

var A_arbace_aot_emit__init_A_const_104 any

var A_arbace_aot_emit__init_A_const_105 *lang.Var

var A_arbace_aot_emit__init_A_const_106 any

var A_arbace_aot_emit__init_A_const_107 *lang.Var

var A_arbace_aot_emit__init_A_const_108 any

var A_arbace_aot_emit__init_A_const_109 *lang.Var

var A_arbace_aot_emit__init_A_const_110 any

var A_arbace_aot_emit__init_A_const_111 *lang.Var

var A_arbace_aot_emit__init_A_const_112 any

var A_arbace_aot_emit__init_A_const_113 *lang.Var

var A_arbace_aot_emit__init_A_const_114 any

var A_arbace_aot_emit__init_A_const_115 *lang.Var

var A_arbace_aot_emit__init_A_const_116 any

var A_arbace_aot_emit__init_A_const_117 *lang.Var

var A_arbace_aot_emit__init_A_const_118 any

var A_arbace_aot_emit__init_A_const_119 *lang.Var

var A_arbace_aot_emit__init_A_const_120 any

var A_arbace_aot_emit__init_A_const_121 *lang.Var

var A_arbace_aot_emit__init_A_const_122 any

var A_arbace_aot_emit__init_A_const_123 *lang.Var

var A_arbace_aot_emit__init_A_const_124 any

var A_arbace_aot_emit__init_A_const_125 *lang.Var

var A_arbace_aot_emit__init_A_const_126 any

var A_arbace_aot_emit__init_A_const_127 *lang.Var

var A_arbace_aot_emit__init_A_const_128 any

var A_arbace_aot_emit__init_A_const_129 *lang.Var

var A_arbace_aot_emit__init_A_const_130 any

var A_arbace_aot_emit__init_A_const_131 *lang.Var

var A_arbace_aot_emit__init_A_const_132 any

var A_arbace_aot_emit__init_A_const_133 *lang.Var

var A_arbace_aot_emit__init_A_const_134 any

var A_arbace_aot_emit__init_A_const_135 *lang.Var

var A_arbace_aot_emit__init_A_const_136 any

var A_arbace_aot_emit__init_A_const_137 *lang.Var

var A_arbace_aot_emit__init_A_const_138 any

var A_arbace_aot_emit__init_A_const_139 *lang.Var

var A_arbace_aot_emit__init_A_const_140 any

var A_arbace_aot_emit__init_A_const_141 *lang.Var

var A_arbace_aot_emit__init_A_const_142 any

var A_arbace_aot_emit__init_A_const_143 *lang.Var

var A_arbace_aot_emit__init_A_const_144 any

var A_arbace_aot_emit__init_A_const_145 *lang.Var

var A_arbace_aot_emit__init_A_const_146 any

var A_arbace_aot_emit__init_A_const_147 *lang.Var

var A_arbace_aot_emit__init_A_const_148 any

var A_arbace_aot_emit__init_A_const_149 *lang.Var

var A_arbace_aot_emit__init_A_const_150 any

var A_arbace_aot_emit__init_A_const_151 any

var A_arbace_aot_emit__init_A_const_152 any

var A_arbace_aot_emit__init_A_const_153 any

var A_arbace_aot_emit__init_A_const_154 any

var A_arbace_aot_emit__init_A_const_155 any

var A_arbace_aot_emit__init_A_const_156 any

var A_arbace_aot_emit__init_A_const_157 any

var A_arbace_aot_emit__init_A_const_158 any

var A_arbace_aot_emit__init_A_const_159 any

var A_arbace_aot_emit__init_A_const_160 *lang.Var

var A_arbace_aot_emit__init_A_const_161 any

var A_arbace_aot_emit__init_A_const_162 any

var A_arbace_aot_emit__init_A_const_163 any

var A_arbace_aot_emit__init_A_const_164 *lang.Var

var A_arbace_aot_emit__init_A_const_165 any

var A_arbace_aot_emit__init_A_const_166 *lang.Var

var A_arbace_aot_emit__init_A_const_167 any

var A_arbace_aot_emit__init_A_const_168 *lang.Var

var A_arbace_aot_emit__init_A_const_169 any

var A_arbace_aot_emit__init_A_const_170 *lang.Var

var A_arbace_aot_emit__init_A_const_171 any

var A_arbace_aot_emit__init_A_const_172 *lang.Var

var A_arbace_aot_emit__init_A_const_173 any

var A_arbace_aot_emit__init_A_const_174 *lang.Var

var A_arbace_aot_emit__init_A_const_175 any

var A_arbace_aot_emit__init_A_const_176 *lang.Var

var A_arbace_aot_emit__init_A_const_177 any

var A_arbace_aot_emit__init_A_const_178 any

var A_arbace_aot_emit__init_A_const_179 any

var A_arbace_aot_emit__init_A_const_180 any

var A_arbace_aot_emit__init_A_const_181 any

var A_arbace_aot_emit__init_A_const_182 any

var A_arbace_aot_emit__init_A_const_183 any

var A_arbace_aot_emit__init_A_const_184 any

var A_arbace_aot_emit__init_A_const_185 any

var A_arbace_aot_emit__init_A_const_186 *lang.Var

var A_arbace_aot_emit__init_A_const_187 any

var A_arbace_aot_emit__init_A_const_188 *lang.Var

var A_arbace_aot_emit__init_A_const_189 any

var A_arbace_aot_emit__init_A_const_190 *lang.Var

var A_arbace_aot_emit__init_A_const_191 any

var A_arbace_aot_emit__init_A_const_192 *lang.Var

var A_arbace_aot_emit__init_A_const_193 any

var A_arbace_aot_emit__init_A_const_194 any

var A_arbace_aot_emit__init_A_const_195 any

var A_arbace_aot_emit__init_A_const_196 *lang.Var

var A_arbace_aot_emit__init_A_const_197 any

var A_arbace_aot_emit__init_A_const_198 *lang.Var

var A_arbace_aot_emit__init_A_const_199 any

var A_arbace_aot_emit__init_A_const_200 *lang.Var

var A_arbace_aot_emit__init_A_const_201 any

var A_arbace_aot_emit__init_A_const_202 *lang.Var

var A_arbace_aot_emit__init_A_const_203 any

var A_arbace_aot_emit__init_A_const_204 *lang.Var

var A_arbace_aot_emit__init_A_const_205 any

var A_arbace_aot_emit__init_A_const_206 *lang.Var

var A_arbace_aot_emit__init_A_const_207 any

var A_arbace_aot_emit__init_A_init jrt.ClassInit

func A_arbace_aot_emit__init_A_Init() { if !A_arbace_aot_emit__init_A_init.Done() { A_arbace_aot_emit__init_A_init.Run(A_arbace_aot_emit__init_A_clinit) } }

func A_arbace_aot_emit__init_A_clinit() { A_arbace_aot_emit__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_770); A_arbace_aot_emit__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_13)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15))); A_arbace_aot_emit__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15)); A_arbace_aot_emit__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_aot_emit__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_13, Lit_18); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_aot_emit__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(34).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_774)); A_arbace_aot_emit__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_13, Lit_140); A_arbace_aot_emit__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_776).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_777, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(38).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_13, Lit_59); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_aot_emit__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_778).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_779).Ref(), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_780).Ref()))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(47).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_13, Lit_26); A_arbace_aot_emit__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_337)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_28).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_781).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_782, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(53).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_13, Lit_25); A_arbace_aot_emit__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_228)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_28).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_783).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_784, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(58).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_13, Lit_29); A_arbace_aot_emit__init_A_const_15 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_785).Ref(); A_arbace_aot_emit__init_A_const_16 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_786).Ref(); A_arbace_aot_emit__init_A_const_17 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_787).Ref(); A_arbace_aot_emit__init_A_const_18 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_788).Ref(); A_arbace_aot_emit__init_A_const_19 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_234).Ref(); A_arbace_aot_emit__init_A_const_20 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_789).Ref(); A_arbace_aot_emit__init_A_const_21 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_154).Ref(); A_arbace_aot_emit__init_A_const_22 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_790).Ref(); A_arbace_aot_emit__init_A_const_23 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_297).Ref(); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_aot_emit__init_A_const_24 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(69).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_25 = lang.RT_Var_String_String__Var(Lit_13, Lit_188); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_aot_emit__init_A_const_26 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_791).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_228).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_792, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(73).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_27 = lang.RT_Var_String_String__Var(Lit_13, Lit_31); A_arbace_aot_emit__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_aot_emit__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(82).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_793)); A_arbace_aot_emit__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_13, Lit_35); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_aot_emit__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_228)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_28).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_783).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(86).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_13, Lit_124); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_aot_emit__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_228)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_28).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_783).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_795, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(103).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_13, Lit_147); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_aot_emit__init_A_const_35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_228)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_28).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_783).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(112).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_36 = lang.RT_Var_String_String__Var(Lit_13, Lit_415); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_aot_emit__init_A_const_37 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_337)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_28).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_781).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(118).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_38 = lang.RT_Var_String_String__Var(Lit_13, Lit_379); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_aot_emit__init_A_const_39 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_796).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_797, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(120).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_40 = lang.RT_Var_String_String__Var(Lit_13, Lit_125); var tmp31 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp32 *jrt.Boolean; jrt.Boolean_Init(); tmp32 = jrt.Boolean_TRUE; var tmp33 any = tmp32.Ref(); A_arbace_aot_emit__init_A_const_41 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp33, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_341).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_798).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_799, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(130).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_42 = lang.RT_Var_String_String__Var(Lit_13, Lit_49); var tmp34 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_800).Ref(); var tmp35 *jrt.Boolean; jrt.Boolean_Init(); tmp35 = jrt.Boolean_TRUE; var tmp36 any = tmp35.Ref(); A_arbace_aot_emit__init_A_const_43 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, tmp36, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(144).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_44 = lang.RT_Var_String_String__Var(Lit_13, Lit_93); var tmp37 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; var tmp39 any = tmp38.Ref(); A_arbace_aot_emit__init_A_const_45 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_801).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(146).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_46 = lang.RT_Var_String_String__Var(Lit_13, Lit_76); var tmp40 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp41 *jrt.Boolean; jrt.Boolean_Init(); tmp41 = jrt.Boolean_TRUE; var tmp42 any = tmp41.Ref(); A_arbace_aot_emit__init_A_const_47 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp42, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_228)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_28).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_802).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(149).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_48 = lang.RT_Var_String_String__Var(Lit_13, Lit_74); var tmp43 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp44 *jrt.Boolean; jrt.Boolean_Init(); tmp44 = jrt.Boolean_TRUE; var tmp45 any = tmp44.Ref(); A_arbace_aot_emit__init_A_const_49 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp43, tmp45, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_803)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_28).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_786).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(155).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_50 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_341).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_804, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(160).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_51 = lang.RT_Var_String_String__Var(Lit_13, Lit_126); var tmp46 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp47 *jrt.Boolean; jrt.Boolean_Init(); tmp47 = jrt.Boolean_TRUE; var tmp48 any = tmp47.Ref(); A_arbace_aot_emit__init_A_const_52 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp46, tmp48, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_341).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(229).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_53 = lang.RT_Var_String_String__Var(Lit_13, Lit_158); var tmp49 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp50 *jrt.Boolean; jrt.Boolean_Init(); tmp50 = jrt.Boolean_TRUE; var tmp51 any = tmp50.Ref(); A_arbace_aot_emit__init_A_const_54 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp49, tmp51, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_341).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(235).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_55 = lang.RT_Var_String_String__Var(Lit_13, Lit_186); var tmp52 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp53 *jrt.Boolean; jrt.Boolean_Init(); tmp53 = jrt.Boolean_TRUE; var tmp54 any = tmp53.Ref(); A_arbace_aot_emit__init_A_const_56 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp52, tmp54, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_805).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_806, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(248).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_57 = lang.RT_Var_String_String__Var(Lit_13, Lit_170); var tmp55 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp56 *jrt.Boolean; jrt.Boolean_Init(); tmp56 = jrt.Boolean_TRUE; var tmp57 any = tmp56.Ref(); A_arbace_aot_emit__init_A_const_58 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp55, tmp57, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_163).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_807, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(256).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_59 = lang.RT_Var_String_String__Var(Lit_13, Lit_281); var tmp58 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp59 *jrt.Boolean; jrt.Boolean_Init(); tmp59 = jrt.Boolean_TRUE; var tmp60 any = tmp59.Ref(); A_arbace_aot_emit__init_A_const_60 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp58, tmp60, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_801).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_808, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(262).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_61 = lang.RT_Var_String_String__Var(Lit_13, Lit_164); var tmp61 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp62 *jrt.Boolean; jrt.Boolean_Init(); tmp62 = jrt.Boolean_TRUE; var tmp63 any = tmp62.Ref(); A_arbace_aot_emit__init_A_const_62 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp61, tmp63, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_283).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(271).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_63 = lang.RT_Var_String_String__Var(Lit_13, Lit_137); var tmp64 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp65 *jrt.Boolean; jrt.Boolean_Init(); tmp65 = jrt.Boolean_TRUE; var tmp66 any = tmp65.Ref(); A_arbace_aot_emit__init_A_const_64 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp64, tmp66, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_163).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(275).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_65 = lang.RT_Var_String_String__Var(Lit_13, Lit_165); var tmp67 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp68 *jrt.Boolean; jrt.Boolean_Init(); tmp68 = jrt.Boolean_TRUE; var tmp69 any = tmp68.Ref(); A_arbace_aot_emit__init_A_const_66 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp67, tmp69, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_283).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_163).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(277).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_67 = lang.RT_Var_String_String__Var(Lit_13, Lit_149); var tmp70 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_800).Ref(); var tmp71 *jrt.Boolean; jrt.Boolean_Init(); tmp71 = jrt.Boolean_TRUE; var tmp72 any = tmp71.Ref(); A_arbace_aot_emit__init_A_const_68 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp70, tmp72, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(283).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_69 = lang.RT_Var_String_String__Var(Lit_13, Lit_148); var tmp73 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_800).Ref(); var tmp74 *jrt.Boolean; jrt.Boolean_Init(); tmp74 = jrt.Boolean_TRUE; var tmp75 any = tmp74.Ref(); A_arbace_aot_emit__init_A_const_70 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp73, tmp75, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(283).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_71 = lang.RT_Var_String_String__Var(Lit_13, Lit_267); var tmp76 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_800).Ref(); var tmp77 *jrt.Boolean; jrt.Boolean_Init(); tmp77 = jrt.Boolean_TRUE; var tmp78 any = tmp77.Ref(); A_arbace_aot_emit__init_A_const_72 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp76, tmp78, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(283).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_73 = lang.RT_Var_String_String__Var(Lit_13, Lit_322); var tmp79 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_800).Ref(); var tmp80 *jrt.Boolean; jrt.Boolean_Init(); tmp80 = jrt.Boolean_TRUE; var tmp81 any = tmp80.Ref(); A_arbace_aot_emit__init_A_const_74 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp79, tmp81, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(283).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_75 = lang.RT_Var_String_String__Var(Lit_13, Lit_809); var tmp82 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_800).Ref(); var tmp83 *jrt.Boolean; jrt.Boolean_Init(); tmp83 = jrt.Boolean_TRUE; var tmp84 any = tmp83.Ref(); A_arbace_aot_emit__init_A_const_76 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp82, tmp84, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(283).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_77 = lang.RT_Var_String_String__Var(Lit_13, Lit_139); var tmp85 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp86 *jrt.Boolean; jrt.Boolean_Init(); tmp86 = jrt.Boolean_TRUE; var tmp87 any = tmp86.Ref(); A_arbace_aot_emit__init_A_const_78 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp85, tmp87, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_810).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(285).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_79 = lang.RT_Var_String_String__Var(Lit_13, Lit_251); var tmp88 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp89 *jrt.Boolean; jrt.Boolean_Init(); tmp89 = jrt.Boolean_TRUE; var tmp90 any = tmp89.Ref(); A_arbace_aot_emit__init_A_const_80 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp88, tmp90, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_337).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(287).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_81 = lang.RT_Var_String_String__Var(Lit_13, Lit_143); var tmp91 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_800).Ref(); var tmp92 *jrt.Boolean; jrt.Boolean_Init(); tmp92 = jrt.Boolean_TRUE; var tmp93 any = tmp92.Ref(); A_arbace_aot_emit__init_A_const_82 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp91, tmp93, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(289).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_83 = lang.RT_Var_String_String__Var(Lit_13, Lit_190); var tmp94 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp95 *jrt.Boolean; jrt.Boolean_Init(); tmp95 = jrt.Boolean_TRUE; var tmp96 any = tmp95.Ref(); A_arbace_aot_emit__init_A_const_84 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp94, tmp96, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_811).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_228)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_28).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_783).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_812, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(291).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_85 = lang.RT_Var_String_String__Var(Lit_13, Lit_151); var tmp97 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp98 *jrt.Boolean; jrt.Boolean_Init(); tmp98 = jrt.Boolean_TRUE; var tmp99 any = tmp98.Ref(); A_arbace_aot_emit__init_A_const_86 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp97, tmp99, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_811).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_697)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_28).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_783).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_813, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(300).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_87 = lang.RT_Var_String_String__Var(Lit_13, Lit_150); var tmp100 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp101 *jrt.Boolean; jrt.Boolean_Init(); tmp101 = jrt.Boolean_TRUE; var tmp102 any = tmp101.Ref(); A_arbace_aot_emit__init_A_const_88 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp100, tmp102, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_697)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_28).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_783).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_814, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(319).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_89 = lang.RT_Var_String_String__Var(Lit_13, Lit_195); var tmp103 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp104 *jrt.Boolean; jrt.Boolean_Init(); tmp104 = jrt.Boolean_TRUE; var tmp105 any = tmp104.Ref(); A_arbace_aot_emit__init_A_const_90 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp103, tmp105, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_815).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_816).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_817, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(326).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_91 = lang.RT_Var_String_String__Var(Lit_13, Lit_86); var tmp106 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp107 *jrt.Boolean; jrt.Boolean_Init(); tmp107 = jrt.Boolean_TRUE; var tmp108 any = tmp107.Ref(); A_arbace_aot_emit__init_A_const_92 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp106, tmp108, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_815).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(350).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_93 = lang.RT_Var_String_String__Var(Lit_13, Lit_180); var tmp109 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp110 *jrt.Boolean; jrt.Boolean_Init(); tmp110 = jrt.Boolean_TRUE; var tmp111 any = tmp110.Ref(); A_arbace_aot_emit__init_A_const_94 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp109, tmp111, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_816).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(352).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_95 = lang.RT_Var_String_String__Var(Lit_13, Lit_327); var tmp112 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp113 *jrt.Boolean; jrt.Boolean_Init(); tmp113 = jrt.Boolean_TRUE; var tmp114 any = tmp113.Ref(); A_arbace_aot_emit__init_A_const_96 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp112, tmp114, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_341)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_28).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_818).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(355).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_97 = lang.RT_Var_String_String__Var(Lit_13, Lit_321); var tmp115 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp116 *jrt.Boolean; jrt.Boolean_Init(); tmp116 = jrt.Boolean_TRUE; var tmp117 any = tmp116.Ref(); A_arbace_aot_emit__init_A_const_98 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp115, tmp117, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_811).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_337).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(359).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_99 = lang.RT_Var_String_String__Var(Lit_13, Lit_270); var tmp118 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp119 *jrt.Boolean; jrt.Boolean_Init(); tmp119 = jrt.Boolean_TRUE; var tmp120 any = tmp119.Ref(); A_arbace_aot_emit__init_A_const_100 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp118, tmp120, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_337).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_819).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(364).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_101 = lang.RT_Var_String_String__Var(Lit_13, Lit_320); var tmp121 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp122 *jrt.Boolean; jrt.Boolean_Init(); tmp122 = jrt.Boolean_TRUE; var tmp123 any = tmp122.Ref(); A_arbace_aot_emit__init_A_const_102 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp121, tmp123, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_337).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(376).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_103 = lang.RT_Var_String_String__Var(Lit_13, Lit_201); var tmp124 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp125 *jrt.Boolean; jrt.Boolean_Init(); tmp125 = jrt.Boolean_TRUE; var tmp126 any = tmp125.Ref(); A_arbace_aot_emit__init_A_const_104 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp124, tmp126, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_228)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_28).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_783).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(406).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_105 = lang.RT_Var_String_String__Var(Lit_13, Lit_204); var tmp127 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp128 *jrt.Boolean; jrt.Boolean_Init(); tmp128 = jrt.Boolean_TRUE; var tmp129 any = tmp128.Ref(); A_arbace_aot_emit__init_A_const_106 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp127, tmp129, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(414).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_107 = lang.RT_Var_String_String__Var(Lit_13, Lit_224); var tmp130 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp131 *jrt.Boolean; jrt.Boolean_Init(); tmp131 = jrt.Boolean_TRUE; var tmp132 any = tmp131.Ref(); A_arbace_aot_emit__init_A_const_108 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp130, tmp132, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_424)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_28).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_820).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_821, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(417).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_109 = lang.RT_Var_String_String__Var(Lit_13, Lit_214); var tmp133 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp134 *jrt.Boolean; jrt.Boolean_Init(); tmp134 = jrt.Boolean_TRUE; var tmp135 any = tmp134.Ref(); A_arbace_aot_emit__init_A_const_110 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp133, tmp135, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_424)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_28).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_820).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_822).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_176).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_823, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(436).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_111 = lang.RT_Var_String_String__Var(Lit_13, Lit_213); var tmp136 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp137 *jrt.Boolean; jrt.Boolean_Init(); tmp137 = jrt.Boolean_TRUE; var tmp138 any = tmp137.Ref(); A_arbace_aot_emit__init_A_const_112 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp136, tmp138, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_228)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_28).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_783).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_824, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(449).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_113 = lang.RT_Var_String_String__Var(Lit_13, Lit_215); var tmp139 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp140 *jrt.Boolean; jrt.Boolean_Init(); tmp140 = jrt.Boolean_TRUE; var tmp141 any = tmp140.Ref(); A_arbace_aot_emit__init_A_const_114 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp139, tmp141, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_337).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_819).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(454).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_115 = lang.RT_Var_String_String__Var(Lit_13, Lit_226); var tmp142 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp143 *jrt.Boolean; jrt.Boolean_Init(); tmp143 = jrt.Boolean_TRUE; var tmp144 any = tmp143.Ref(); A_arbace_aot_emit__init_A_const_116 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp142, tmp144, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_337).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_819).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(487).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_117 = lang.RT_Var_String_String__Var(Lit_13, Lit_230); var tmp145 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp146 *jrt.Boolean; jrt.Boolean_Init(); tmp146 = jrt.Boolean_TRUE; var tmp147 any = tmp146.Ref(); A_arbace_aot_emit__init_A_const_118 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp145, tmp147, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_811)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_28).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_825).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(501).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_119 = lang.RT_Var_String_String__Var(Lit_13, Lit_326); var tmp148 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp149 *jrt.Boolean; jrt.Boolean_Init(); tmp149 = jrt.Boolean_TRUE; var tmp150 any = tmp149.Ref(); A_arbace_aot_emit__init_A_const_120 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp148, tmp150, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_337).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_819).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(504).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_121 = lang.RT_Var_String_String__Var(Lit_13, Lit_353); var tmp151 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp152 *jrt.Boolean; jrt.Boolean_Init(); tmp152 = jrt.Boolean_TRUE; var tmp153 any = tmp152.Ref(); A_arbace_aot_emit__init_A_const_122 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp151, tmp153, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_337).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_819).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(513).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_123 = lang.RT_Var_String_String__Var(Lit_13, Lit_344); var tmp154 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp155 *jrt.Boolean; jrt.Boolean_Init(); tmp155 = jrt.Boolean_TRUE; var tmp156 any = tmp155.Ref(); A_arbace_aot_emit__init_A_const_124 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp154, tmp156, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_337).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(521).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_125 = lang.RT_Var_String_String__Var(Lit_13, Lit_319); var tmp157 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp158 *jrt.Boolean; jrt.Boolean_Init(); tmp158 = jrt.Boolean_TRUE; var tmp159 any = tmp158.Ref(); A_arbace_aot_emit__init_A_const_126 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp157, tmp159, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_337).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_826).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(530).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_127 = lang.RT_Var_String_String__Var(Lit_13, Lit_335); var tmp160 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp161 *jrt.Boolean; jrt.Boolean_Init(); tmp161 = jrt.Boolean_TRUE; var tmp162 any = tmp161.Ref(); A_arbace_aot_emit__init_A_const_128 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp160, tmp162, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_337).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(548).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_129 = lang.RT_Var_String_String__Var(Lit_13, Lit_338); var tmp163 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp164 *jrt.Boolean; jrt.Boolean_Init(); tmp164 = jrt.Boolean_TRUE; var tmp165 any = tmp164.Ref(); A_arbace_aot_emit__init_A_const_130 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp163, tmp165, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_373).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_816).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(570).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_131 = lang.RT_Var_String_String__Var(Lit_13, Lit_334); var tmp166 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp167 *jrt.Boolean; jrt.Boolean_Init(); tmp167 = jrt.Boolean_TRUE; var tmp168 any = tmp167.Ref(); A_arbace_aot_emit__init_A_const_132 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp166, tmp168, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_337).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_819).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(573).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_133 = lang.RT_Var_String_String__Var(Lit_13, Lit_258); var tmp169 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp170 *jrt.Boolean; jrt.Boolean_Init(); tmp170 = jrt.Boolean_TRUE; var tmp171 any = tmp170.Ref(); A_arbace_aot_emit__init_A_const_134 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp169, tmp171, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_283).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_241).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_827, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(582).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_135 = lang.RT_Var_String_String__Var(Lit_13, Lit_339); var tmp172 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp173 *jrt.Boolean; jrt.Boolean_Init(); tmp173 = jrt.Boolean_TRUE; var tmp174 any = tmp173.Ref(); A_arbace_aot_emit__init_A_const_136 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp172, tmp174, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_337).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_819).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(591).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_137 = lang.RT_Var_String_String__Var(Lit_13, Lit_340); var tmp175 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp176 *jrt.Boolean; jrt.Boolean_Init(); tmp176 = jrt.Boolean_TRUE; var tmp177 any = tmp176.Ref(); A_arbace_aot_emit__init_A_const_138 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp175, tmp177, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_337).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(598).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_139 = lang.RT_Var_String_String__Var(Lit_13, Lit_279); var tmp178 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp179 *jrt.Boolean; jrt.Boolean_Init(); tmp179 = jrt.Boolean_TRUE; var tmp180 any = tmp179.Ref(); A_arbace_aot_emit__init_A_const_140 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp178, tmp180, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_828).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_829).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_830, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(619).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_141 = lang.RT_Var_String_String__Var(Lit_13, Lit_280); var tmp181 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp182 *jrt.Boolean; jrt.Boolean_Init(); tmp182 = jrt.Boolean_TRUE; var tmp183 any = tmp182.Ref(); A_arbace_aot_emit__init_A_const_142 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp181, tmp183, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_828).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_259).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_831, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(632).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_143 = lang.RT_Var_String_String__Var(Lit_13, Lit_318); var tmp184 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp185 *jrt.Boolean; jrt.Boolean_Init(); tmp185 = jrt.Boolean_TRUE; var tmp186 any = tmp185.Ref(); A_arbace_aot_emit__init_A_const_144 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp184, tmp186, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_828).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_829).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_832, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(643).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_145 = lang.RT_Var_String_String__Var(Lit_13, Lit_336); var tmp187 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp188 *jrt.Boolean; jrt.Boolean_Init(); tmp188 = jrt.Boolean_TRUE; var tmp189 any = tmp188.Ref(); A_arbace_aot_emit__init_A_const_146 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp187, tmp189, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_337).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_819).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(649).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_147 = lang.RT_Var_String_String__Var(Lit_13, Lit_316); var tmp190 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp191 *jrt.Boolean; jrt.Boolean_Init(); tmp191 = jrt.Boolean_TRUE; var tmp192 any = tmp191.Ref(); A_arbace_aot_emit__init_A_const_148 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp190, tmp192, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_337).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_819).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(666).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_149 = lang.RT_Var_String_String__Var(Lit_13, Lit_354); var tmp193 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp194 *jrt.Boolean; jrt.Boolean_Init(); tmp194 = jrt.Boolean_TRUE; var tmp195 any = tmp194.Ref(); A_arbace_aot_emit__init_A_const_150 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp193, tmp195, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_337).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_819).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(675).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_151 = lang.Symbol_Intern_String_String__Symbol(Lit_73, Lit_71).Ref(); A_arbace_aot_emit__init_A_const_152 = lang.Symbol_Intern_String_String__Symbol(Lit_52, Lit_71).Ref(); A_arbace_aot_emit__init_A_const_153 = lang.Symbol_Intern_String_String__Symbol(Lit_70, Lit_71).Ref(); A_arbace_aot_emit__init_A_const_154 = lang.Symbol_Intern_String_String__Symbol(Lit_67, Lit_71).Ref(); A_arbace_aot_emit__init_A_const_155 = lang.Symbol_Intern_String_String__Symbol(Lit_75, Lit_71).Ref(); A_arbace_aot_emit__init_A_const_156 = lang.Symbol_Intern_String_String__Symbol(Lit_78, Lit_71).Ref(); A_arbace_aot_emit__init_A_const_157 = lang.Symbol_Intern_String_String__Symbol(Lit_79, Lit_71).Ref(); A_arbace_aot_emit__init_A_const_158 = lang.Symbol_Intern_String_String__Symbol(Lit_77, Lit_71).Ref(); var tmp196 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp197 *jrt.Boolean; jrt.Boolean_Init(); tmp197 = jrt.Boolean_TRUE; var tmp198 any = tmp197.Ref(); A_arbace_aot_emit__init_A_const_159 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp196, tmp198, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(722).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_160 = lang.RT_Var_String_String__Var(Lit_13, Lit_359); var tmp199 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp200 *jrt.Boolean; jrt.Boolean_Init(); tmp200 = jrt.Boolean_TRUE; var tmp201 any = tmp200.Ref(); A_arbace_aot_emit__init_A_const_161 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp199, tmp201, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_811).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_337).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_833, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(728).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_162 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_810).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_834, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(739).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_163 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_810).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_835, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(815).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_164 = lang.RT_Var_String_String__Var(Lit_13, Lit_360); var tmp202 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp203 *jrt.Boolean; jrt.Boolean_Init(); tmp203 = jrt.Boolean_TRUE; var tmp204 any = tmp203.Ref(); A_arbace_aot_emit__init_A_const_165 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp202, tmp204, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_811).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_836, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(847).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_166 = lang.RT_Var_String_String__Var(Lit_13, Lit_438); var tmp205 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp206 *jrt.Boolean; jrt.Boolean_Init(); tmp206 = jrt.Boolean_TRUE; var tmp207 any = tmp206.Ref(); A_arbace_aot_emit__init_A_const_167 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp205, tmp207, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_837)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_28).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_781).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(856).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_168 = lang.RT_Var_String_String__Var(Lit_13, Lit_361); var tmp208 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp209 *jrt.Boolean; jrt.Boolean_Init(); tmp209 = jrt.Boolean_TRUE; var tmp210 any = tmp209.Ref(); A_arbace_aot_emit__init_A_const_169 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp208, tmp210, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_810).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_838, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(859).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_170 = lang.RT_Var_String_String__Var(Lit_13, Lit_363); var tmp211 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp212 *jrt.Boolean; jrt.Boolean_Init(); tmp212 = jrt.Boolean_TRUE; var tmp213 any = tmp212.Ref(); A_arbace_aot_emit__init_A_const_171 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp211, tmp213, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_259).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_839)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_28).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_783).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_840, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(868).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_172 = lang.RT_Var_String_String__Var(Lit_13, Lit_384); var tmp214 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp215 *jrt.Boolean; jrt.Boolean_Init(); tmp215 = jrt.Boolean_TRUE; var tmp216 any = tmp215.Ref(); A_arbace_aot_emit__init_A_const_173 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp214, tmp216, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_841).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_842).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_843, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(894).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_174 = lang.RT_Var_String_String__Var(Lit_13, Lit_411); var tmp217 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp218 *jrt.Boolean; jrt.Boolean_Init(); tmp218 = jrt.Boolean_TRUE; var tmp219 any = tmp218.Ref(); A_arbace_aot_emit__init_A_const_175 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp217, tmp219, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_283).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(931).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_176 = lang.RT_Var_String_String__Var(Lit_13, Lit_369); A_arbace_aot_emit__init_A_const_177 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_154).Ref(); A_arbace_aot_emit__init_A_const_178 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_786).Ref(); A_arbace_aot_emit__init_A_const_179 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_297).Ref(); A_arbace_aot_emit__init_A_const_180 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_234).Ref(); A_arbace_aot_emit__init_A_const_181 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_787).Ref(); A_arbace_aot_emit__init_A_const_182 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_789).Ref(); A_arbace_aot_emit__init_A_const_183 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_790).Ref(); A_arbace_aot_emit__init_A_const_184 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_788).Ref(); var tmp220 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp221 *jrt.Boolean; jrt.Boolean_Init(); tmp221 = jrt.Boolean_TRUE; var tmp222 any = tmp221.Ref(); A_arbace_aot_emit__init_A_const_185 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp220, tmp222, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(937).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_186 = lang.RT_Var_String_String__Var(Lit_13, Lit_395); var tmp223 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp224 *jrt.Boolean; jrt.Boolean_Init(); tmp224 = jrt.Boolean_TRUE; var tmp225 any = tmp224.Ref(); A_arbace_aot_emit__init_A_const_187 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp223, tmp225, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_28).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_844, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(941).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_188 = lang.RT_Var_String_String__Var(Lit_13, Lit_397); var tmp226 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp227 *jrt.Boolean; jrt.Boolean_Init(); tmp227 = jrt.Boolean_TRUE; var tmp228 any = tmp227.Ref(); A_arbace_aot_emit__init_A_const_189 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp226, tmp228, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_228)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_28).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_783).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(950).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_190 = lang.RT_Var_String_String__Var(Lit_13, Lit_406); var tmp229 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp230 *jrt.Boolean; jrt.Boolean_Init(); tmp230 = jrt.Boolean_TRUE; var tmp231 any = tmp230.Ref(); A_arbace_aot_emit__init_A_const_191 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp229, tmp231, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_828).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_845, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(954).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_192 = lang.RT_Var_String_String__Var(Lit_13, Lit_385); var tmp232 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp233 *jrt.Boolean; jrt.Boolean_Init(); tmp233 = jrt.Boolean_TRUE; var tmp234 any = tmp233.Ref(); A_arbace_aot_emit__init_A_const_193 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp232, tmp234, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_828).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_283).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_846, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(965).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_194 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_828).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_847, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(975).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_195 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_828).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_848, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(1042).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_196 = lang.RT_Var_String_String__Var(Lit_13, Lit_432); var tmp235 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp236 *jrt.Boolean; jrt.Boolean_Init(); tmp236 = jrt.Boolean_TRUE; var tmp237 any = tmp236.Ref(); A_arbace_aot_emit__init_A_const_197 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp235, tmp237, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_794).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_329).Ref(), lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_211).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_161).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_390).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_702).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_702).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_290).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_849).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_850, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(1130).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_198 = lang.RT_Var_String_String__Var(Lit_13, Lit_431); var tmp238 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp239 *jrt.Boolean; jrt.Boolean_Init(); tmp239 = jrt.Boolean_TRUE; var tmp240 any = tmp239.Ref(); A_arbace_aot_emit__init_A_const_199 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp238, tmp240, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_211).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_702).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_702).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_702).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_702).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_290).Ref()))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_851, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(1171).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_200 = lang.RT_Var_String_String__Var(Lit_13, Lit_852); A_arbace_aot_emit__init_A_const_201 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_198).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_34).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_409).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_36).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_853).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_854).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_855, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(1182).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_202 = lang.RT_Var_String_String__Var(Lit_13, Lit_437); var tmp241 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_771).Ref(); var tmp242 *jrt.Boolean; jrt.Boolean_Init(); tmp242 = jrt.Boolean_TRUE; var tmp243 any = tmp242.Ref(); A_arbace_aot_emit__init_A_const_203 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp241, tmp243, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_228).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_856).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_826).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_36).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_857, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(1211).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_204 = lang.RT_Var_String_String__Var(Lit_13, Lit_858); A_arbace_aot_emit__init_A_const_205 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_198).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_36).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_859, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(1243).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)); A_arbace_aot_emit__init_A_const_206 = lang.RT_Var_String_String__Var(Lit_13, Lit_860); A_arbace_aot_emit__init_A_const_207 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_775).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_440).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_402).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_861, lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(1265).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_390).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_772).Ref(), Lit_773)) }

func A_arbace_aot_emit__init_A_New() *A_arbace_aot_emit__init_A { A_arbace_aot_emit__init_A_Init(); t := &A_arbace_aot_emit__init_A{}; t.Ctor(); return t }

func (t *A_arbace_aot_emit__init_A) Ctor() {}

func (t *A_arbace_aot_emit__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_emit__init_A) GetClass__Class() *jrt.Class { return A_arbace_aot_emit__init_A_class }

func (t *A_arbace_aot_emit__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_emit__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_emit__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_emit__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_emit__init_A); return ok }

func A_arbace_aot_emit__init_A_Cast(x any) *A_arbace_aot_emit__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_emit__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_emit__init_A_class)) }; return v }
