//line aot_arbace_aot_emit__init.ae:1
package aot_arbace_aot_emit

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_aot_emit__init_part0_A_Unit0__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(A_arbace_aot_emit__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit__init_part0_A_const_1) }
//line :1:1
func A_arbace_aot_emit__init_part0_A_Unit1__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_aot_emit__init_part0_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_2)) }
//line :1:1
func A_arbace_aot_emit__init_part0_A_Unit2__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_302, false); A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_aot_emit__init_part0_A_Unit3__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_aot_emit__init_part0_A_const_1)).Equals_O__Z(A_arbace_aot_emit__init_part0_A_const_3) { return nil } else { var tmp1 any = A_arbace_aot_emit_eval90000008_fn__90000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_aot_emit_eval90000008_fn__90000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_303, false); A_arbace_aot_emit_eval90000008_fn__90000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }
//line :1:1
func A_arbace_aot_emit__init_part0_A_Init__O() any { A_arbace_aot_emit__init_part0_A_Init(); return nil }
//line :1:1
func A_arbace_aot_emit__init_part0_A_Load__O() any { A_arbace_aot_emit__init_part0_A_Init(); A_arbace_aot_emit__init_part0_A_Unit0__O(); A_arbace_aot_emit__init_part0_A_Unit1__O(); A_arbace_aot_emit__init_part0_A_Unit2__O(); A_arbace_aot_emit__init_part0_A_Unit3__O(); A_arbace_aot_emit__init_part0_A_Unit4__O(); A_arbace_aot_emit__init_part0_A_Unit5__O(); A_arbace_aot_emit__init_part0_A_Unit6__O(); A_arbace_aot_emit__init_part0_A_Unit7__O(); A_arbace_aot_emit__init_part0_A_Unit8__O(); A_arbace_aot_emit__init_part0_A_Unit9__O(); A_arbace_aot_emit__init_part0_A_Unit10__O(); A_arbace_aot_emit__init_part0_A_Unit11__O(); A_arbace_aot_emit__init_part0_A_Unit12__O(); A_arbace_aot_emit__init_part0_A_Unit13__O(); A_arbace_aot_emit__init_part0_A_Unit14__O(); A_arbace_aot_emit__init_part0_A_Unit15__O(); A_arbace_aot_emit__init_part0_A_Unit16__O(); A_arbace_aot_emit__init_part0_A_Unit17__O(); A_arbace_aot_emit__init_part0_A_Unit18__O(); A_arbace_aot_emit__init_part0_A_Unit19__O(); A_arbace_aot_emit__init_part0_A_Unit20__O(); A_arbace_aot_emit__init_part0_A_Unit21__O(); A_arbace_aot_emit__init_part0_A_Unit22__O(); A_arbace_aot_emit__init_part0_A_Unit23__O(); A_arbace_aot_emit__init_part0_A_Unit24__O(); A_arbace_aot_emit__init_part0_A_Unit25__O(); A_arbace_aot_emit__init_part0_A_Unit26__O(); A_arbace_aot_emit__init_part0_A_Unit27__O(); A_arbace_aot_emit__init_part0_A_Unit28__O(); A_arbace_aot_emit__init_part0_A_Unit29__O(); A_arbace_aot_emit__init_part0_A_Unit30__O(); A_arbace_aot_emit__init_part0_A_Unit31__O(); A_arbace_aot_emit__init_part0_A_Unit32__O(); A_arbace_aot_emit__init_part0_A_Unit33__O(); A_arbace_aot_emit__init_part0_A_Unit34__O(); A_arbace_aot_emit__init_part0_A_Unit35__O(); A_arbace_aot_emit__init_part0_A_Unit36__O(); A_arbace_aot_emit__init_part0_A_Unit37__O(); A_arbace_aot_emit__init_part0_A_Unit38__O(); A_arbace_aot_emit__init_part0_A_Unit39__O(); A_arbace_aot_emit__init_part0_A_Unit40__O(); A_arbace_aot_emit__init_part0_A_Unit41__O(); A_arbace_aot_emit__init_part0_A_Unit42__O(); A_arbace_aot_emit__init_part0_A_Unit43__O(); A_arbace_aot_emit__init_part0_A_Unit44__O(); A_arbace_aot_emit__init_part0_A_Unit45__O(); A_arbace_aot_emit__init_part0_A_Unit46__O(); A_arbace_aot_emit__init_part0_A_Unit47__O(); A_arbace_aot_emit__init_part0_A_Unit48__O(); A_arbace_aot_emit__init_part0_A_Unit49__O(); A_arbace_aot_emit__init_part0_A_Unit50__O(); A_arbace_aot_emit__init_part0_A_Unit51__O(); A_arbace_aot_emit__init_part0_A_Unit52__O(); A_arbace_aot_emit__init_part0_A_Unit53__O(); A_arbace_aot_emit__init_part0_A_Unit54__O(); A_arbace_aot_emit__init_part0_A_Unit55__O(); A_arbace_aot_emit__init_part0_A_Unit56__O(); A_arbace_aot_emit__init_part0_A_Unit57__O(); A_arbace_aot_emit__init_part0_A_Unit58__O(); A_arbace_aot_emit__init_part0_A_Unit59__O(); A_arbace_aot_emit__init_part0_A_Unit60__O(); A_arbace_aot_emit__init_part0_A_Unit61__O(); A_arbace_aot_emit__init_part0_A_Unit62__O(); A_arbace_aot_emit__init_part0_A_Unit63__O(); A_arbace_aot_emit__init_part0_A_Unit64__O(); A_arbace_aot_emit__init_part0_A_Unit65__O(); A_arbace_aot_emit__init_part0_A_Unit66__O(); A_arbace_aot_emit__init_part0_A_Unit67__O(); A_arbace_aot_emit__init_part0_A_Unit68__O(); A_arbace_aot_emit__init_part0_A_Unit69__O(); A_arbace_aot_emit__init_part0_A_Unit70__O(); A_arbace_aot_emit__init_part0_A_Unit71__O(); A_arbace_aot_emit__init_part0_A_Unit72__O(); A_arbace_aot_emit__init_part0_A_Unit73__O(); A_arbace_aot_emit__init_part0_A_Unit74__O(); A_arbace_aot_emit__init_part0_A_Unit75__O(); A_arbace_aot_emit__init_part0_A_Unit76__O(); A_arbace_aot_emit__init_part0_A_Unit77__O(); A_arbace_aot_emit__init_part0_A_Unit78__O(); A_arbace_aot_emit__init_part0_A_Unit79__O(); A_arbace_aot_emit__init_part0_A_Unit80__O(); A_arbace_aot_emit__init_part0_A_Unit81__O(); A_arbace_aot_emit__init_part0_A_Unit82__O(); A_arbace_aot_emit__init_part0_A_Unit83__O(); A_arbace_aot_emit__init_part0_A_Unit84__O(); A_arbace_aot_emit__init_part0_A_Unit85__O(); A_arbace_aot_emit__init_part0_A_Unit86__O(); A_arbace_aot_emit__init_part0_A_Unit87__O(); A_arbace_aot_emit__init_part0_A_Unit88__O(); A_arbace_aot_emit__init_part0_A_Unit89__O(); A_arbace_aot_emit__init_part0_A_Unit90__O(); A_arbace_aot_emit__init_part0_A_Unit91__O(); A_arbace_aot_emit__init_part0_A_Unit92__O(); A_arbace_aot_emit__init_part0_A_Unit93__O(); A_arbace_aot_emit__init_part0_A_Unit94__O(); A_arbace_aot_emit__init_part0_A_Unit95__O(); A_arbace_aot_emit__init_part0_A_Unit96__O(); A_arbace_aot_emit__init_part0_A_Unit97__O(); A_arbace_aot_emit__init_part0_A_Unit98__O(); A_arbace_aot_emit__init_part0_A_Unit99__O(); return nil }



func A_arbace_aot_emit__init_A_Load__O() any { A_arbace_aot_emit__init_part0_A_Init__O(); A_arbace_aot_emit__init_part1_A_Init__O(); A_arbace_aot_emit__init_part0_A_Load__O(); A_arbace_aot_emit__init_part1_A_Load__O(); return nil }





























func A_arbace_aot_emit__init_part0_A_Unit4__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(35, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_4; tmp1.BindRoot_O__V(jrt.IdentityHashMap_New()); var tmp2 *lang.Var = A_arbace_aot_emit__init_part0_A_const_4; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_5)); return A_arbace_aot_emit__init_part0_A_const_4 }



func A_arbace_aot_emit__init_part0_A_Unit5__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_6; var tmp2 any = A_arbace_aot_emit_node_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_aot_emit_node_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_304, false); A_arbace_aot_emit_node_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_7)); return A_arbace_aot_emit__init_part0_A_const_6 }








func A_arbace_aot_emit__init_part0_A_Unit6__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_8; var tmp2 any = A_arbace_aot_emit_fail_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_aot_emit_fail_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_305, true); A_arbace_aot_emit_fail_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_9)); return A_arbace_aot_emit__init_part0_A_const_8 }





func A_arbace_aot_emit__init_part0_A_Unit7__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(54, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_10; var tmp2 any = A_arbace_aot_emit_destub_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_aot_emit_destub_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_306, false); A_arbace_aot_emit_destub_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_11)); return A_arbace_aot_emit__init_part0_A_const_10 }




func A_arbace_aot_emit__init_part0_A_Unit8__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(59, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_12; var tmp2 any = A_arbace_aot_emit_type_sym_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_aot_emit_type_sym_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_307, false); A_arbace_aot_emit_type_sym_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_13)); return A_arbace_aot_emit__init_part0_A_const_12 }










func A_arbace_aot_emit__init_part0_A_Unit9__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(70, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_14; var tmp2 *jrt.Class; jrt.Void_Init(); tmp2 = jrt.Void_TYPE; var tmp3 any = tmp2.Ref(); var tmp4 any = A_arbace_aot_emit__init_part0_A_const_15; var tmp5 *jrt.Class; jrt.Double_Init(); tmp5 = jrt.Double_TYPE; var tmp6 any = tmp5.Ref(); var tmp7 any = A_arbace_aot_emit__init_part0_A_const_16; var tmp8 *jrt.Class; jrt.Character_Init(); tmp8 = jrt.Character_TYPE; var tmp9 any = tmp8.Ref(); var tmp10 any = A_arbace_aot_emit__init_part0_A_const_17; var tmp11 *jrt.Class; jrt.Byte_Init(); tmp11 = jrt.Byte_TYPE; var tmp12 any = tmp11.Ref(); var tmp13 any = A_arbace_aot_emit__init_part0_A_const_18; var tmp14 *jrt.Class; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TYPE; var tmp15 any = tmp14.Ref(); var tmp16 any = A_arbace_aot_emit__init_part0_A_const_19; var tmp17 *jrt.Class; jrt.Float_Init(); tmp17 = jrt.Float_TYPE; var tmp18 any = tmp17.Ref(); var tmp19 any = A_arbace_aot_emit__init_part0_A_const_20; var tmp20 *jrt.Class; jrt.Long_Init(); tmp20 = jrt.Long_TYPE; var tmp21 any = tmp20.Ref(); var tmp22 any = A_arbace_aot_emit__init_part0_A_const_21; var tmp23 *jrt.Class; jrt.Short_Init(); tmp23 = jrt.Short_TYPE; var tmp24 any = tmp23.Ref(); var tmp25 any = A_arbace_aot_emit__init_part0_A_const_22; var tmp26 *jrt.Class; jrt.Integer_Init(); tmp26 = jrt.Integer_TYPE; tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp6, tmp7, tmp9, tmp10, tmp12, tmp13, tmp15, tmp16, tmp18, tmp19, tmp21, tmp22, tmp24, tmp25, tmp26.Ref(), A_arbace_aot_emit__init_part0_A_const_23))); var tmp27 *lang.Var = A_arbace_aot_emit__init_part0_A_const_14; tmp27.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_24)); return A_arbace_aot_emit__init_part0_A_const_14 }



func A_arbace_aot_emit__init_part0_A_Unit10__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(74, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_25; var tmp2 any = A_arbace_aot_emit_tagged_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_aot_emit_tagged_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_308, false); A_arbace_aot_emit_tagged_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_26)); return A_arbace_aot_emit__init_part0_A_const_25 }








func A_arbace_aot_emit__init_part0_A_Unit11__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(83, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_27; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit__init_part0_A_const_28.GetRawRoot__O()); var tmp3 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; tmp1.BindRoot_O__V(tmp2.Invoke_O__O(tmp3.Ref())); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_29)); return A_arbace_aot_emit__init_part0_A_const_27 }



func A_arbace_aot_emit__init_part0_A_Unit12__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(87, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_30; var tmp2 any = A_arbace_aot_emit_registered_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_aot_emit_registered_QMARK__A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_309, false); A_arbace_aot_emit_registered_QMARK__A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_31)); return A_arbace_aot_emit__init_part0_A_const_30 }
















func A_arbace_aot_emit__init_part0_A_Unit13__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(104, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_32; var tmp2 any = A_arbace_aot_emit_runtime_class_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_aot_emit_runtime_class_QMARK__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_310, false); A_arbace_aot_emit_runtime_class_QMARK__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_33)); return A_arbace_aot_emit__init_part0_A_const_32 }








func A_arbace_aot_emit__init_part0_A_Unit14__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(113, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_34; var tmp2 any = A_arbace_aot_emit_public_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_aot_emit_public_QMARK__A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_311, false); A_arbace_aot_emit_public_QMARK__A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_35)); return A_arbace_aot_emit__init_part0_A_const_34 }





func A_arbace_aot_emit__init_part0_A_Unit15__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(119, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_36; var tmp2 any = A_arbace_aot_emit_top_name_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_aot_emit_top_name_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_312, false); A_arbace_aot_emit_top_name_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_37)); return A_arbace_aot_emit__init_part0_A_const_36 }

func A_arbace_aot_emit__init_part0_A_Unit16__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(121, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_38; var tmp2 any = A_arbace_aot_emit_pool_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_aot_emit_pool_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_313, false); A_arbace_aot_emit_pool_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_39)); return A_arbace_aot_emit__init_part0_A_const_38 }









func A_arbace_aot_emit__init_part0_A_Unit17__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(131, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_40; var tmp2 any = A_arbace_aot_emit_const_field_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_aot_emit_const_field_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_314, false); A_arbace_aot_emit_const_field_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_41)); return A_arbace_aot_emit__init_part0_A_const_40 }




















func A_arbace_aot_emit__init_part0_A_Unit18__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(152, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_42; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_43)); return A_arbace_aot_emit__init_part0_A_const_42 }

func A_arbace_aot_emit__init_part0_A_Unit19__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(154, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_44; var tmp2 any = A_arbace_aot_emit_emit_list_array_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_aot_emit_emit_list_array_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_315, false); A_arbace_aot_emit_emit_list_array_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_45)); return A_arbace_aot_emit__init_part0_A_const_44 }


func A_arbace_aot_emit__init_part0_A_Unit20__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(157, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_46; var tmp2 any = A_arbace_aot_emit_char_form_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_aot_emit_char_form_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_316, false); A_arbace_aot_emit_char_form_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_47)); return A_arbace_aot_emit__init_part0_A_const_46 }





func A_arbace_aot_emit__init_part0_A_Unit21__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(163, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_48; var tmp2 any = A_arbace_aot_emit_double_form_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_aot_emit_double_form_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_317, false); A_arbace_aot_emit_double_form_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_49)); return A_arbace_aot_emit__init_part0_A_const_48 }




func A_arbace_aot_emit__init_part0_A_Unit22__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(168, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_42; var tmp2 any = A_arbace_aot_emit_emit_value_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_aot_emit_emit_value_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_318, false); A_arbace_aot_emit_emit_value_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_50)); return A_arbace_aot_emit__init_part0_A_const_42 }











































































func A_arbace_aot_emit__init_part0_A_Unit23__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(244, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_51; var tmp2 any = A_arbace_aot_emit_pool_kind_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_aot_emit_pool_kind_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_319, false); A_arbace_aot_emit_pool_kind_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_52)); return A_arbace_aot_emit__init_part0_A_const_51 }
























func A_arbace_aot_emit__init_part0_A_Unit24__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(269, 1); A_arbace_aot_emit__init_part0_A_const_53.BindRoot_O__V(A_arbace_aot_emit__init_part0_A_const_54); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_53; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_55)); return A_arbace_aot_emit__init_part0_A_const_53 }



func A_arbace_aot_emit__init_part0_A_Unit25__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(273, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_56; var tmp2 any = A_arbace_aot_emit_pool_shared_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_aot_emit_pool_shared_QMARK__A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_320, false); A_arbace_aot_emit_pool_shared_QMARK__A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_57)); return A_arbace_aot_emit__init_part0_A_const_56 }




func A_arbace_aot_emit__init_part0_A_Unit26__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(278, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_58; var tmp2 any = A_arbace_aot_emit_pool_parts_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_aot_emit_pool_parts_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_321, false); A_arbace_aot_emit_pool_parts_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_59)); return A_arbace_aot_emit__init_part0_A_const_58 }










func A_arbace_aot_emit__init_part0_A_Unit27__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(289, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_60; var tmp2 any = A_arbace_aot_emit_pool_str_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_aot_emit_pool_str_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_322, false); A_arbace_aot_emit_pool_str_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_61)); return A_arbace_aot_emit__init_part0_A_const_60 }


func A_arbace_aot_emit__init_part0_A_Unit28__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(292, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_62; var tmp2 any = A_arbace_aot_emit_pool_encode_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_aot_emit_pool_encode_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_323, false); A_arbace_aot_emit_pool_encode_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_63)); return A_arbace_aot_emit__init_part0_A_const_62 }















































func A_arbace_aot_emit__init_part0_A_Unit29__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(340, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_64; var tmp2 any = A_arbace_aot_emit_pool_fields_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_aot_emit_pool_fields_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_324, false); A_arbace_aot_emit_pool_fields_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_65)); return A_arbace_aot_emit__init_part0_A_const_64 }
































func A_arbace_aot_emit__init_part0_A_Unit30__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(373, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_66; var tmp2 any = A_arbace_aot_emit_const_type_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_aot_emit_const_type_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_325, false); A_arbace_aot_emit_const_type_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_67)); return A_arbace_aot_emit__init_part0_A_const_66 }





func A_arbace_aot_emit__init_part0_A_Unit31__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(379, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_68; var tmp2 any = A_arbace_aot_emit_constant_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_aot_emit_constant_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_326, false); A_arbace_aot_emit_constant_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_69)); return A_arbace_aot_emit__init_part0_A_const_68 }












func A_arbace_aot_emit__init_part0_A_Unit32__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(392, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_70; var tmp2 any = A_arbace_aot_emit_gsym_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_aot_emit_gsym_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_327, false); A_arbace_aot_emit_gsym_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_71)); return A_arbace_aot_emit__init_part0_A_const_70 }







func A_arbace_aot_emit__init_part0_A_Unit33__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(400, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_72; var tmp2 any = A_arbace_aot_emit_local_sym_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_aot_emit_local_sym_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_328, false); A_arbace_aot_emit_local_sym_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_73)); return A_arbace_aot_emit__init_part0_A_const_72 }





func A_arbace_aot_emit__init_part0_A_Unit34__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(406, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_74; var tmp2 any = A_arbace_aot_emit_identity_set_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_aot_emit_identity_set_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_329, false); A_arbace_aot_emit_identity_set_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_75)); return A_arbace_aot_emit__init_part0_A_const_74 }








func A_arbace_aot_emit__init_part0_A_Unit35__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(415, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_76; var tmp2 any = A_arbace_aot_emit_closed_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_aot_emit_closed_QMARK__A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_330, false); A_arbace_aot_emit_closed_QMARK__A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_77)); return A_arbace_aot_emit__init_part0_A_const_76 }



func A_arbace_aot_emit__init_part0_A_Unit36__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(419, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_78; var tmp2 any = A_arbace_aot_emit_field_sym_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_aot_emit_field_sym_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_331, false); A_arbace_aot_emit_field_sym_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_79)); return A_arbace_aot_emit__init_part0_A_const_78 }

func A_arbace_aot_emit__init_part0_A_Unit37__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(421, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_80; var tmp2 any = A_arbace_aot_emit_field_read_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_aot_emit_field_read_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_332, false); A_arbace_aot_emit_field_read_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_81)); return A_arbace_aot_emit__init_part0_A_const_80 }





func A_arbace_aot_emit__init_part0_A_Unit38__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(427, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_82; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_83)); return A_arbace_aot_emit__init_part0_A_const_82 }
//line :427:1
func A_arbace_aot_emit__init_part0_A_Unit39__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(427, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_84; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_85)); return A_arbace_aot_emit__init_part0_A_const_84 }
//line :427:1
func A_arbace_aot_emit__init_part0_A_Unit40__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(427, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_86; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_87)); return A_arbace_aot_emit__init_part0_A_const_86 }
//line :427:1
func A_arbace_aot_emit__init_part0_A_Unit41__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(427, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_88; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_89)); return A_arbace_aot_emit__init_part0_A_const_88 }
//line :427:1
func A_arbace_aot_emit__init_part0_A_Unit42__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(427, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_90; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_91)); return A_arbace_aot_emit__init_part0_A_const_90 }

func A_arbace_aot_emit__init_part0_A_Unit43__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(429, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_92; var tmp2 any = A_arbace_aot_emit_prim_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_aot_emit_prim_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_333, false); A_arbace_aot_emit_prim_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_93)); return A_arbace_aot_emit__init_part0_A_const_92 }

func A_arbace_aot_emit__init_part0_A_Unit44__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(431, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_94; var tmp2 any = A_arbace_aot_emit_can_prim_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_aot_emit_can_prim_QMARK__A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_334, false); A_arbace_aot_emit_can_prim_QMARK__A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_94; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_95)); return A_arbace_aot_emit__init_part0_A_const_94 }

func A_arbace_aot_emit__init_part0_A_Unit45__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(433, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_96; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_97)); return A_arbace_aot_emit__init_part0_A_const_96 }

func A_arbace_aot_emit__init_part0_A_Unit46__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(435, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_98; var tmp2 any = A_arbace_aot_emit_box_A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_aot_emit_box_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_335, false); A_arbace_aot_emit_box_A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_99)); return A_arbace_aot_emit__init_part0_A_const_98 }








func A_arbace_aot_emit__init_part0_A_Unit47__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(444, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_100; var tmp2 any = A_arbace_aot_emit_unbox_arg_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_aot_emit_unbox_arg_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_336, false); A_arbace_aot_emit_unbox_arg_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_101)); return A_arbace_aot_emit__init_part0_A_const_100 }


















func A_arbace_aot_emit__init_part0_A_Unit48__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(463, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_102; var tmp2 any = A_arbace_aot_emit_fi_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_aot_emit_fi_QMARK__A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_337, false); A_arbace_aot_emit_fi_QMARK__A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_102; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_103)); return A_arbace_aot_emit__init_part0_A_const_102 }






func A_arbace_aot_emit__init_part0_A_Unit49__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(470, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_104; var tmp2 any = A_arbace_aot_emit_typed_args_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_aot_emit_typed_args_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_338, false); A_arbace_aot_emit_typed_args_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_104; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_105)); return A_arbace_aot_emit__init_part0_A_const_104 }























func A_arbace_aot_emit__init_part0_A_Unit50__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(494, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_106; var tmp2 any = A_arbace_aot_emit_param_tags_A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_aot_emit_param_tags_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_339, false); A_arbace_aot_emit_param_tags_A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_106; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_107)); return A_arbace_aot_emit__init_part0_A_const_106 }

func A_arbace_aot_emit__init_part0_A_Unit51__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(496, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_108; var tmp2 any = A_arbace_aot_emit_obj_array_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_aot_emit_obj_array_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_340, false); A_arbace_aot_emit_obj_array_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_108; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_109)); return A_arbace_aot_emit__init_part0_A_const_108 }


func A_arbace_aot_emit__init_part0_A_Unit52__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(499, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_110; var tmp2 any = A_arbace_aot_emit_var_value_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_aot_emit_var_value_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_341, false); A_arbace_aot_emit_var_value_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_110; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_111)); return A_arbace_aot_emit__init_part0_A_const_110 }



func A_arbace_aot_emit__init_part0_A_Unit53__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(503, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_112; var tmp2 any = A_arbace_aot_emit_line_meta_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_aot_emit_line_meta_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_342, false); A_arbace_aot_emit_line_meta_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_112; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_113)); return A_arbace_aot_emit__init_part0_A_const_112 }




func A_arbace_aot_emit__init_part0_A_Unit54__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(508, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_114; var tmp2 any = A_arbace_aot_emit_emit_local_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_aot_emit_emit_local_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_343, false); A_arbace_aot_emit_emit_local_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_115)); return A_arbace_aot_emit__init_part0_A_const_114 }











func A_arbace_aot_emit__init_part0_A_Unit55__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(520, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_116; var tmp2 any = A_arbace_aot_emit_emit_invoke_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_aot_emit_emit_invoke_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_344, false); A_arbace_aot_emit_emit_invoke_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_116; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_117)); return A_arbace_aot_emit__init_part0_A_const_116 }





























func A_arbace_aot_emit__init_part0_A_Unit56__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(550, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_118; var tmp2 any = A_arbace_aot_emit_descriptor_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_aot_emit_descriptor_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_345, false); A_arbace_aot_emit_descriptor_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_118; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_119)); return A_arbace_aot_emit__init_part0_A_const_118 }







func A_arbace_aot_emit__init_part0_A_Unit57__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(558, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_120; var tmp2 any = A_arbace_aot_emit_fn__90000165_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_aot_emit_fn__90000165_A_fn_class; if
							fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_346, false); A_arbace_aot_emit_fn__90000165_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; /*line :558:1*/tmp1.BindRoot_O__V(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_121)); return A_arbace_aot_emit__init_part0_A_const_120 }


func A_arbace_aot_emit__init_part0_A_Unit58__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(561, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_122; var tmp2 any = A_arbace_aot_emit_jrt_lacks_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_aot_emit_jrt_lacks_QMARK__A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_347, false); A_arbace_aot_emit_jrt_lacks_QMARK__A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_122; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_123)); return A_arbace_aot_emit__init_part0_A_const_122 }


















func A_arbace_aot_emit__init_part0_A_Unit59__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(580, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_124; var tmp2 any = A_arbace_aot_emit_method_call_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_aot_emit_method_call_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_348, false); A_arbace_aot_emit_method_call_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_124; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_125)); return A_arbace_aot_emit__init_part0_A_const_124 }












func A_arbace_aot_emit__init_part0_A_Unit60__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(593, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_126; var tmp2 any = A_arbace_aot_emit_compiled_interface_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_aot_emit_compiled_interface_QMARK__A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_349, false); A_arbace_aot_emit_compiled_interface_QMARK__A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_126; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_127)); return A_arbace_aot_emit__init_part0_A_const_126 }




func A_arbace_aot_emit__init_part0_A_Unit61__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(598, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_128; var tmp2 any = A_arbace_aot_emit_emit_instance_method_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_aot_emit_emit_instance_method_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_350, false); A_arbace_aot_emit_emit_instance_method_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_129)); return A_arbace_aot_emit__init_part0_A_const_128 }
































func A_arbace_aot_emit__init_part0_A_Unit62__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(631, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_130; var tmp2 any = A_arbace_aot_emit_emit_static_method_A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_aot_emit_emit_static_method_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_351, false); A_arbace_aot_emit_emit_static_method_A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_130; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_131)); return A_arbace_aot_emit__init_part0_A_const_130 }













func A_arbace_aot_emit__init_part0_A_Unit63__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(645, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_132; var tmp2 any = A_arbace_aot_emit_field_ok_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_aot_emit_field_ok_QMARK__A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_352, false); A_arbace_aot_emit_field_ok_QMARK__A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_132; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_133)); return A_arbace_aot_emit__init_part0_A_const_132 }


func A_arbace_aot_emit__init_part0_A_Unit64__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(648, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_134; var tmp2 any = A_arbace_aot_emit_emit_instance_field_A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_aot_emit_emit_instance_field_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_353, false); A_arbace_aot_emit_emit_instance_field_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_134; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_135)); return A_arbace_aot_emit__init_part0_A_const_134 }








func A_arbace_aot_emit__init_part0_A_Unit65__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(657, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_136; var tmp2 any = A_arbace_aot_emit_emit_static_field_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_aot_emit_emit_static_field_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_354, false); A_arbace_aot_emit_emit_static_field_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_136; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_137)); return A_arbace_aot_emit__init_part0_A_const_136 }







func A_arbace_aot_emit__init_part0_A_Unit66__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(665, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_138; var tmp2 any = A_arbace_aot_emit_emit_new_A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_aot_emit_emit_new_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_355, false); A_arbace_aot_emit_emit_new_A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_138; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_139)); return A_arbace_aot_emit__init_part0_A_const_138 }








func A_arbace_aot_emit__init_part0_A_Unit67__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(674, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_140; var tmp2 any = A_arbace_aot_emit_emit_def_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_aot_emit_emit_def_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_356, false); A_arbace_aot_emit_emit_def_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_140; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_141)); return A_arbace_aot_emit__init_part0_A_const_140 }

















func A_arbace_aot_emit__init_part0_A_Unit68__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(692, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_142; var tmp2 any = A_arbace_aot_emit_emit_assign_A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_aot_emit_emit_assign_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_357, false); A_arbace_aot_emit_emit_assign_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_142; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_143)); return A_arbace_aot_emit__init_part0_A_const_142 }





















func A_arbace_aot_emit__init_part0_A_Unit69__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(714, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_144; var tmp2 any = A_arbace_aot_emit_coll_call_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_aot_emit_coll_call_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_358, false); A_arbace_aot_emit_coll_call_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_144; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_145)); return A_arbace_aot_emit__init_part0_A_const_144 }


func A_arbace_aot_emit__init_part0_A_Unit70__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(717, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_146; var tmp2 any = A_arbace_aot_emit_emit_if_A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_aot_emit_emit_if_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_359, false); A_arbace_aot_emit_emit_if_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_146; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_147)); return A_arbace_aot_emit__init_part0_A_const_146 }








func A_arbace_aot_emit__init_part0_A_Unit71__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(726, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_148; var tmp2 any = A_arbace_aot_emit_emit_binding_init_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_aot_emit_emit_binding_init_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_360, false); A_arbace_aot_emit_emit_binding_init_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_148; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_149)); return A_arbace_aot_emit__init_part0_A_const_148 }








func A_arbace_aot_emit__init_part0_A_Unit72__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(735, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_150; var tmp2 any = A_arbace_aot_emit_emit_let_A_New(); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_aot_emit_emit_let_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_361, false); A_arbace_aot_emit_emit_let_A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_150; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_151)); return A_arbace_aot_emit__init_part0_A_const_150 }






func A_arbace_aot_emit__init_part0_A_Unit73__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(742, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_152; var tmp2 any = A_arbace_aot_emit_emit_recur_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_aot_emit_emit_recur_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_362, false); A_arbace_aot_emit_emit_recur_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_152; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_153)); return A_arbace_aot_emit__init_part0_A_const_152 }




















func A_arbace_aot_emit__init_part0_A_Unit74__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(763, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_154; var tmp2 any = A_arbace_aot_emit_body_instance_A_New(); var tmp3 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_aot_emit_body_instance_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_363, false); A_arbace_aot_emit_body_instance_A_fn_class = fncls__62d; tmp3 = fncls__62d } else { tmp3 = fncls__62 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_154; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_155)); return A_arbace_aot_emit__init_part0_A_const_154 }












func A_arbace_aot_emit__init_part0_A_Unit75__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(776, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_156; var tmp2 any = A_arbace_aot_emit_fn_wrap_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_aot_emit_fn_wrap_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_364, false); A_arbace_aot_emit_fn_wrap_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_156; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_157)); return A_arbace_aot_emit__init_part0_A_const_156 }






















func A_arbace_aot_emit__init_part0_A_Unit76__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(799, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_158; var tmp2 any = A_arbace_aot_emit_fn_instance_A_New(); var tmp3 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_aot_emit_fn_instance_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_365, false); A_arbace_aot_emit_fn_instance_A_fn_class = fncls__64d; tmp3 = fncls__64d } else { tmp3 = fncls__64 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_158; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_159)); return A_arbace_aot_emit__init_part0_A_const_158 }





func A_arbace_aot_emit__init_part0_A_Unit77__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(805, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_160; var tmp2 any = A_arbace_aot_emit_emit_letfn_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_aot_emit_emit_letfn_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_366, false); A_arbace_aot_emit_emit_letfn_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_160; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_161)); return A_arbace_aot_emit__init_part0_A_const_160 }
















func A_arbace_aot_emit__init_part0_A_Unit78__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(822, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_162; var tmp2 any = A_arbace_aot_emit_emit_try_A_New(); var tmp3 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_aot_emit_emit_try_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_367, false); A_arbace_aot_emit_emit_try_A_fn_class = fncls__66d; tmp3 = fncls__66d } else { tmp3 = fncls__66 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_162; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_163)); return A_arbace_aot_emit__init_part0_A_const_162 }








func A_arbace_aot_emit__init_part0_A_Unit79__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(831, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_164; var tmp2 any = A_arbace_aot_emit_emit_case_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_aot_emit_emit_case_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_368, false); A_arbace_aot_emit_emit_case_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_164; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_165)); return A_arbace_aot_emit__init_part0_A_const_164 }














































func A_arbace_aot_emit__init_part0_A_Unit80__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(878, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_96; var tmp2 *jrt.Class; jrt.Long_Init(); tmp2 = jrt.Long_TYPE; var tmp3 any = tmp2.Ref(); var tmp4 any = A_arbace_aot_emit__init_part0_A_const_166; var tmp5 *jrt.Class; jrt.Double_Init(); tmp5 = jrt.Double_TYPE; var tmp6 any = tmp5.Ref(); var tmp7 any = A_arbace_aot_emit__init_part0_A_const_167; var tmp8 *jrt.Class; jrt.Integer_Init(); tmp8 = jrt.Integer_TYPE; var tmp9 any = tmp8.Ref(); var tmp10 any = A_arbace_aot_emit__init_part0_A_const_168; var tmp11 *jrt.Class; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TYPE; var tmp12 any = tmp11.Ref(); var tmp13 any = A_arbace_aot_emit__init_part0_A_const_169; var tmp14 *jrt.Class; jrt.Character_Init(); tmp14 = jrt.Character_TYPE; var tmp15 any = tmp14.Ref(); var tmp16 any = A_arbace_aot_emit__init_part0_A_const_170; var tmp17 *jrt.Class; jrt.Float_Init(); tmp17 = jrt.Float_TYPE; var tmp18 any = tmp17.Ref(); var tmp19 any = A_arbace_aot_emit__init_part0_A_const_171; var tmp20 *jrt.Class; jrt.Short_Init(); tmp20 = jrt.Short_TYPE; var tmp21 any = tmp20.Ref(); var tmp22 any = A_arbace_aot_emit__init_part0_A_const_172; var tmp23 *jrt.Class; jrt.Byte_Init(); tmp23 = jrt.Byte_TYPE; tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp6, tmp7, tmp9, tmp10, tmp12, tmp13, tmp15, tmp16, tmp18, tmp19, tmp21, tmp22, tmp23.Ref(), A_arbace_aot_emit__init_part0_A_const_173))); var tmp24 *lang.Var = A_arbace_aot_emit__init_part0_A_const_96; tmp24.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_174)); return A_arbace_aot_emit__init_part0_A_const_96 }





func A_arbace_aot_emit__init_part0_A_Unit81__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(884, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_175; var tmp2 any = A_arbace_aot_emit_box_prim_A_New(); var tmp3 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_aot_emit_box_prim_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_369, false); A_arbace_aot_emit_box_prim_A_fn_class = fncls__68d; tmp3 = fncls__68d } else { tmp3 = fncls__68 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_175; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_176)); return A_arbace_aot_emit__init_part0_A_const_175 }










func A_arbace_aot_emit__init_part0_A_Unit82__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(895, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_82; var tmp2 any = A_arbace_aot_emit_emit_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_aot_emit_emit_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_370, false); A_arbace_aot_emit_emit_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_177)); return A_arbace_aot_emit__init_part0_A_const_82 }











































































func A_arbace_aot_emit__init_part0_A_Unit83__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(971, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_84; var tmp2 any = A_arbace_aot_emit_emit_unboxed_A_New(); var tmp3 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_aot_emit_emit_unboxed_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_371, false); A_arbace_aot_emit_emit_unboxed_A_fn_class = fncls__70d; tmp3 = fncls__70d } else { tmp3 = fncls__70 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_178)); return A_arbace_aot_emit__init_part0_A_const_84 }































func A_arbace_aot_emit__init_part0_A_Unit84__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1003, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_179; var tmp2 any = A_arbace_aot_emit_deep_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_aot_emit_deep_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_372, false); A_arbace_aot_emit_deep_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_179; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_180)); return A_arbace_aot_emit__init_part0_A_const_179 }








func A_arbace_aot_emit__init_part0_A_Unit85__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1012, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_181; var tmp2 any = A_arbace_aot_emit_simple_name_A_New(); var tmp3 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_aot_emit_simple_name_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_373, false); A_arbace_aot_emit_simple_name_A_fn_class = fncls__72d; tmp3 = fncls__72d } else { tmp3 = fncls__72 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_181; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_182)); return A_arbace_aot_emit__init_part0_A_const_181 }


func A_arbace_aot_emit__init_part0_A_Unit86__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1015, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_183; var tmp2 any = A_arbace_aot_emit_throws_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_aot_emit_throws_QMARK__A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_374, false); A_arbace_aot_emit_throws_QMARK__A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_183; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_184)); return A_arbace_aot_emit__init_part0_A_const_183 }








func A_arbace_aot_emit__init_part0_A_Unit87__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1024, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_185; var tmp2 any = A_arbace_aot_emit_ret_body_A_New(); var tmp3 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_aot_emit_ret_body_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_375, false); A_arbace_aot_emit_ret_body_A_fn_class = fncls__74d; tmp3 = fncls__74d } else { tmp3 = fncls__74 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_185; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_186)); return A_arbace_aot_emit__init_part0_A_const_185 }

























func A_arbace_aot_emit__init_part0_A_Unit88__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1050, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_187; var tmp2 any = A_arbace_aot_emit_method_body_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_aot_emit_method_body_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_376, false); A_arbace_aot_emit_method_body_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_187; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_188)); return A_arbace_aot_emit__init_part0_A_const_187 }




































func A_arbace_aot_emit__init_part0_A_Unit89__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1087, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_189; var tmp2 any = A_arbace_aot_emit_param_sym_A_New(); var tmp3 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_aot_emit_param_sym_A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_377, false); A_arbace_aot_emit_param_sym_A_fn_class = fncls__76d; tmp3 = fncls__76d } else { tmp3 = fncls__76 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_189; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_190)); return A_arbace_aot_emit__init_part0_A_const_189 }





func A_arbace_aot_emit__init_part0_A_Unit90__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1093, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_191; var tmp2 any = A_arbace_aot_emit__init_part0_A_const_192; var tmp3 *jrt.Class; jrt.Long_Init(); tmp3 = jrt.Long_TYPE; var tmp4 any = tmp3.Ref(); var tmp5 any = A_arbace_aot_emit__init_part0_A_const_193; var tmp6 *jrt.Class; jrt.Double_Init(); tmp6 = jrt.Double_TYPE; var tmp7 any = tmp6.Ref(); var tmp8 any = A_arbace_aot_emit__init_part0_A_const_194; var tmp9 *jrt.Class; jrt.Integer_Init(); tmp9 = jrt.Integer_TYPE; var tmp10 any = tmp9.Ref(); var tmp11 any = A_arbace_aot_emit__init_part0_A_const_195; var tmp12 *jrt.Class; jrt.Boolean_Init(); tmp12 = jrt.Boolean_TYPE; var tmp13 any = tmp12.Ref(); var tmp14 any = A_arbace_aot_emit__init_part0_A_const_196; var tmp15 *jrt.Class; jrt.Character_Init(); tmp15 = jrt.Character_TYPE; var tmp16 any = tmp15.Ref(); var tmp17 any = A_arbace_aot_emit__init_part0_A_const_197; var tmp18 *jrt.Class; jrt.Float_Init(); tmp18 = jrt.Float_TYPE; var tmp19 any = tmp18.Ref(); var tmp20 any = A_arbace_aot_emit__init_part0_A_const_198; var tmp21 *jrt.Class; jrt.Short_Init(); tmp21 = jrt.Short_TYPE; var tmp22 any = tmp21.Ref(); var tmp23 any = A_arbace_aot_emit__init_part0_A_const_199; var tmp24 *jrt.Class; jrt.Byte_Init(); tmp24 = jrt.Byte_TYPE; tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp4, tmp5, tmp7, tmp8, tmp10, tmp11, tmp13, tmp14, tmp16, tmp17, tmp19, tmp20, tmp22, tmp23, tmp24.Ref()))); var tmp25 *lang.Var = A_arbace_aot_emit__init_part0_A_const_191; tmp25.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_200)); return A_arbace_aot_emit__init_part0_A_const_191 }



func A_arbace_aot_emit__init_part0_A_Unit91__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1097, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_201; var tmp2 any = A_arbace_aot_emit_tag_class_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_aot_emit_tag_class_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_378, false); A_arbace_aot_emit_tag_class_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_201; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_202)); return A_arbace_aot_emit__init_part0_A_const_201 }








func A_arbace_aot_emit__init_part0_A_Unit92__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1106, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_203; var tmp2 any = A_arbace_aot_emit_box_class_A_New(); var tmp3 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_aot_emit_box_class_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_379, false); A_arbace_aot_emit_box_class_A_fn_class = fncls__78d; tmp3 = fncls__78d } else { tmp3 = fncls__78 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_203; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_204)); return A_arbace_aot_emit__init_part0_A_const_203 }



func A_arbace_aot_emit__init_part0_A_Unit93__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1110, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_205; var tmp2 any = A_arbace_aot_emit_class_interfaces_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_aot_emit_class_interfaces_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_380, false); A_arbace_aot_emit_class_interfaces_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_205; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_206)); return A_arbace_aot_emit__init_part0_A_const_205 }










func A_arbace_aot_emit__init_part0_A_Unit94__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1121, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_207; var tmp2 any = A_arbace_aot_emit_field_mods_A_New(); var tmp3 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_aot_emit_field_mods_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_381, false); A_arbace_aot_emit_field_mods_A_fn_class = fncls__80d; tmp3 = fncls__80d } else { tmp3 = fncls__80 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_207; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_208)); return A_arbace_aot_emit__init_part0_A_const_207 }









func A_arbace_aot_emit__init_part0_A_Unit95__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1131, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_88; var tmp2 any = A_arbace_aot_emit_emit_deftype_class_BANG__A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_aot_emit_emit_deftype_class_BANG__A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_382, false); A_arbace_aot_emit_emit_deftype_class_BANG__A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_209)); return A_arbace_aot_emit__init_part0_A_const_88 }


































































func A_arbace_aot_emit__init_part0_A_Unit96__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1198, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_86; var tmp2 any = A_arbace_aot_emit_emit_fn_class_BANG__A_New(); var tmp3 *jrt.Class; var fncls__82 *jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_383, false); A_arbace_aot_emit_emit_fn_class_BANG__A_fn_class = fncls__82d; tmp3 = fncls__82d } else { tmp3 = fncls__82 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_210)); return A_arbace_aot_emit__init_part0_A_const_86 }






















































































func A_arbace_aot_emit__init_part0_A_Unit97__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1285, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_211; var tmp2 any = A_arbace_aot_emit_unit_method_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_aot_emit_unit_method_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_384, false); A_arbace_aot_emit_unit_method_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_211; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_212)); return A_arbace_aot_emit__init_part0_A_const_211 }








































func A_arbace_aot_emit__init_part0_A_Unit98__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1326, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_213; var tmp2 any = A_arbace_aot_emit_unit_ns_A_New(); var tmp3 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_aot_emit_unit_ns_A_fn_class; if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_385, false); A_arbace_aot_emit_unit_ns_A_fn_class = fncls__84d; tmp3 = fncls__84d } else { tmp3 = fncls__84 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part0_A_const_213; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_214)); return A_arbace_aot_emit__init_part0_A_const_213 }










func A_arbace_aot_emit__init_part0_A_Unit99__O() any { A_arbace_aot_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1337, 1); A_arbace_aot_emit__init_part0_A_const_215.BindRoot_O__V(A_arbace_aot_emit__init_part0_A_const_216); var tmp1 *lang.Var = A_arbace_aot_emit__init_part0_A_const_215; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part0_A_const_217)); return A_arbace_aot_emit__init_part0_A_const_215 }





func A_arbace_aot_emit__init_part1_A_Unit100__O() any { A_arbace_aot_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1343, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part1_A_const_0; var tmp2 any = A_arbace_aot_emit_emit_source_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_aot_emit_emit_source_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_387, false); A_arbace_aot_emit_emit_source_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part1_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part1_A_const_1)); return A_arbace_aot_emit__init_part1_A_const_0 }
//line :1343:1
func A_arbace_aot_emit__init_part1_A_Init__O() any { A_arbace_aot_emit__init_part1_A_Init(); return nil }
//line :1343:1
func A_arbace_aot_emit__init_part1_A_Load__O() any { A_arbace_aot_emit__init_part1_A_Init(); A_arbace_aot_emit__init_part1_A_Unit100__O(); A_arbace_aot_emit__init_part1_A_Unit101__O(); A_arbace_aot_emit__init_part1_A_Unit102__O(); A_arbace_aot_emit__init_part1_A_Unit103__O(); return nil }































































func A_arbace_aot_emit__init_part1_A_Unit101__O() any { A_arbace_aot_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1407, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part1_A_const_2; var tmp2 any = A_arbace_aot_emit_class_form_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_aot_emit_class_form_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_388, false); A_arbace_aot_emit_class_form_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part1_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part1_A_const_3)); return A_arbace_aot_emit__init_part1_A_const_2 }
































func A_arbace_aot_emit__init_part1_A_Unit102__O() any { A_arbace_aot_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1440, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part1_A_const_4; var tmp2 any = A_arbace_aot_emit_class_forms_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_aot_emit_class_forms_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_389, false); A_arbace_aot_emit_class_forms_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part1_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part1_A_const_5)); return A_arbace_aot_emit__init_part1_A_const_4 }





















func A_arbace_aot_emit__init_part1_A_Unit103__O() any { A_arbace_aot_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1462, 1); var tmp1 *lang.Var = A_arbace_aot_emit__init_part1_A_const_6; var tmp2 any = A_arbace_aot_emit_interface_record_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_aot_emit_interface_record_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_390, false); A_arbace_aot_emit_interface_record_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_emit__init_part1_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_emit__init_part1_A_const_7)); return A_arbace_aot_emit__init_part1_A_const_6 }



type A_arbace_aot_emit__init_A struct{ jrt.Object }

func A_arbace_aot_emit__init_A_New() *A_arbace_aot_emit__init_A { t := &A_arbace_aot_emit__init_A{}; t.Ctor(); return t }

func (t *A_arbace_aot_emit__init_A) Ctor() {}

func (t *A_arbace_aot_emit__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_emit__init_A) GetClass__Class() *jrt.Class { return A_arbace_aot_emit__init_A_class }

func (t *A_arbace_aot_emit__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_emit__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_aot_emit__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_emit__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_emit__init_A); return ok }

func A_arbace_aot_emit__init_A_Cast(x any) *A_arbace_aot_emit__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_emit__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_emit__init_A_class)) }; return v }



type A_arbace_aot_emit__init_part0_A struct{ jrt.Object }

var A_arbace_aot_emit__init_part0_A_const_pool *jrt.RefArray

var A_arbace_aot_emit__init_part0_A_const_0 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_1 any

var A_arbace_aot_emit__init_part0_A_const_2 any

var A_arbace_aot_emit__init_part0_A_const_3 any

var A_arbace_aot_emit__init_part0_A_const_4 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_5 any

var A_arbace_aot_emit__init_part0_A_const_6 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_7 any

var A_arbace_aot_emit__init_part0_A_const_8 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_9 any

var A_arbace_aot_emit__init_part0_A_const_10 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_11 any

var A_arbace_aot_emit__init_part0_A_const_12 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_13 any

var A_arbace_aot_emit__init_part0_A_const_14 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_15 any

var A_arbace_aot_emit__init_part0_A_const_16 any

var A_arbace_aot_emit__init_part0_A_const_17 any

var A_arbace_aot_emit__init_part0_A_const_18 any

var A_arbace_aot_emit__init_part0_A_const_19 any

var A_arbace_aot_emit__init_part0_A_const_20 any

var A_arbace_aot_emit__init_part0_A_const_21 any

var A_arbace_aot_emit__init_part0_A_const_22 any

var A_arbace_aot_emit__init_part0_A_const_23 any

var A_arbace_aot_emit__init_part0_A_const_24 any

var A_arbace_aot_emit__init_part0_A_const_25 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_26 any

var A_arbace_aot_emit__init_part0_A_const_27 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_28 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_29 any

var A_arbace_aot_emit__init_part0_A_const_30 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_31 any

var A_arbace_aot_emit__init_part0_A_const_32 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_33 any

var A_arbace_aot_emit__init_part0_A_const_34 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_35 any

var A_arbace_aot_emit__init_part0_A_const_36 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_37 any

var A_arbace_aot_emit__init_part0_A_const_38 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_39 any

var A_arbace_aot_emit__init_part0_A_const_40 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_41 any

var A_arbace_aot_emit__init_part0_A_const_42 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_43 any

var A_arbace_aot_emit__init_part0_A_const_44 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_45 any

var A_arbace_aot_emit__init_part0_A_const_46 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_47 any

var A_arbace_aot_emit__init_part0_A_const_48 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_49 any

var A_arbace_aot_emit__init_part0_A_const_50 any

var A_arbace_aot_emit__init_part0_A_const_51 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_52 any

var A_arbace_aot_emit__init_part0_A_const_53 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_54 any

var A_arbace_aot_emit__init_part0_A_const_55 any

var A_arbace_aot_emit__init_part0_A_const_56 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_57 any

var A_arbace_aot_emit__init_part0_A_const_58 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_59 any

var A_arbace_aot_emit__init_part0_A_const_60 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_61 any

var A_arbace_aot_emit__init_part0_A_const_62 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_63 any

var A_arbace_aot_emit__init_part0_A_const_64 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_65 any

var A_arbace_aot_emit__init_part0_A_const_66 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_67 any

var A_arbace_aot_emit__init_part0_A_const_68 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_69 any

var A_arbace_aot_emit__init_part0_A_const_70 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_71 any

var A_arbace_aot_emit__init_part0_A_const_72 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_73 any

var A_arbace_aot_emit__init_part0_A_const_74 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_75 any

var A_arbace_aot_emit__init_part0_A_const_76 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_77 any

var A_arbace_aot_emit__init_part0_A_const_78 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_79 any

var A_arbace_aot_emit__init_part0_A_const_80 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_81 any

var A_arbace_aot_emit__init_part0_A_const_82 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_83 any

var A_arbace_aot_emit__init_part0_A_const_84 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_85 any

var A_arbace_aot_emit__init_part0_A_const_86 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_87 any

var A_arbace_aot_emit__init_part0_A_const_88 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_89 any

var A_arbace_aot_emit__init_part0_A_const_90 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_91 any

var A_arbace_aot_emit__init_part0_A_const_92 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_93 any

var A_arbace_aot_emit__init_part0_A_const_94 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_95 any

var A_arbace_aot_emit__init_part0_A_const_96 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_97 any

var A_arbace_aot_emit__init_part0_A_const_98 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_99 any

var A_arbace_aot_emit__init_part0_A_const_100 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_101 any

var A_arbace_aot_emit__init_part0_A_const_102 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_103 any

var A_arbace_aot_emit__init_part0_A_const_104 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_105 any

var A_arbace_aot_emit__init_part0_A_const_106 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_107 any

var A_arbace_aot_emit__init_part0_A_const_108 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_109 any

var A_arbace_aot_emit__init_part0_A_const_110 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_111 any

var A_arbace_aot_emit__init_part0_A_const_112 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_113 any

var A_arbace_aot_emit__init_part0_A_const_114 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_115 any

var A_arbace_aot_emit__init_part0_A_const_116 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_117 any

var A_arbace_aot_emit__init_part0_A_const_118 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_119 any

var A_arbace_aot_emit__init_part0_A_const_120 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_121 any

var A_arbace_aot_emit__init_part0_A_const_122 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_123 any

var A_arbace_aot_emit__init_part0_A_const_124 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_125 any

var A_arbace_aot_emit__init_part0_A_const_126 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_127 any

var A_arbace_aot_emit__init_part0_A_const_128 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_129 any

var A_arbace_aot_emit__init_part0_A_const_130 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_131 any

var A_arbace_aot_emit__init_part0_A_const_132 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_133 any

var A_arbace_aot_emit__init_part0_A_const_134 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_135 any

var A_arbace_aot_emit__init_part0_A_const_136 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_137 any

var A_arbace_aot_emit__init_part0_A_const_138 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_139 any

var A_arbace_aot_emit__init_part0_A_const_140 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_141 any

var A_arbace_aot_emit__init_part0_A_const_142 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_143 any

var A_arbace_aot_emit__init_part0_A_const_144 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_145 any

var A_arbace_aot_emit__init_part0_A_const_146 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_147 any

var A_arbace_aot_emit__init_part0_A_const_148 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_149 any

var A_arbace_aot_emit__init_part0_A_const_150 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_151 any

var A_arbace_aot_emit__init_part0_A_const_152 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_153 any

var A_arbace_aot_emit__init_part0_A_const_154 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_155 any

var A_arbace_aot_emit__init_part0_A_const_156 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_157 any

var A_arbace_aot_emit__init_part0_A_const_158 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_159 any

var A_arbace_aot_emit__init_part0_A_const_160 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_161 any

var A_arbace_aot_emit__init_part0_A_const_162 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_163 any

var A_arbace_aot_emit__init_part0_A_const_164 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_165 any

var A_arbace_aot_emit__init_part0_A_const_166 any

var A_arbace_aot_emit__init_part0_A_const_167 any

var A_arbace_aot_emit__init_part0_A_const_168 any

var A_arbace_aot_emit__init_part0_A_const_169 any

var A_arbace_aot_emit__init_part0_A_const_170 any

var A_arbace_aot_emit__init_part0_A_const_171 any

var A_arbace_aot_emit__init_part0_A_const_172 any

var A_arbace_aot_emit__init_part0_A_const_173 any

var A_arbace_aot_emit__init_part0_A_const_174 any

var A_arbace_aot_emit__init_part0_A_const_175 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_176 any

var A_arbace_aot_emit__init_part0_A_const_177 any

var A_arbace_aot_emit__init_part0_A_const_178 any

var A_arbace_aot_emit__init_part0_A_const_179 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_180 any

var A_arbace_aot_emit__init_part0_A_const_181 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_182 any

var A_arbace_aot_emit__init_part0_A_const_183 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_184 any

var A_arbace_aot_emit__init_part0_A_const_185 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_186 any

var A_arbace_aot_emit__init_part0_A_const_187 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_188 any

var A_arbace_aot_emit__init_part0_A_const_189 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_190 any

var A_arbace_aot_emit__init_part0_A_const_191 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_192 any

var A_arbace_aot_emit__init_part0_A_const_193 any

var A_arbace_aot_emit__init_part0_A_const_194 any

var A_arbace_aot_emit__init_part0_A_const_195 any

var A_arbace_aot_emit__init_part0_A_const_196 any

var A_arbace_aot_emit__init_part0_A_const_197 any

var A_arbace_aot_emit__init_part0_A_const_198 any

var A_arbace_aot_emit__init_part0_A_const_199 any

var A_arbace_aot_emit__init_part0_A_const_200 any

var A_arbace_aot_emit__init_part0_A_const_201 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_202 any

var A_arbace_aot_emit__init_part0_A_const_203 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_204 any

var A_arbace_aot_emit__init_part0_A_const_205 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_206 any

var A_arbace_aot_emit__init_part0_A_const_207 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_208 any

var A_arbace_aot_emit__init_part0_A_const_209 any

var A_arbace_aot_emit__init_part0_A_const_210 any

var A_arbace_aot_emit__init_part0_A_const_211 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_212 any

var A_arbace_aot_emit__init_part0_A_const_213 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_214 any

var A_arbace_aot_emit__init_part0_A_const_215 *lang.Var

var A_arbace_aot_emit__init_part0_A_const_216 any

var A_arbace_aot_emit__init_part0_A_const_217 any

var A_arbace_aot_emit__init_part0_A_init jrt.ClassInit

func A_arbace_aot_emit__init_part0_A_Init() { if !A_arbace_aot_emit__init_part0_A_init.Done() { A_arbace_aot_emit__init_part0_A_init.Run(A_arbace_aot_emit__init_part0_A_clinit) } }

func A_arbace_aot_emit__init_part0_A_clinit() { A_arbace_aot_emit__init_part0_A_clinit_p0(); A_arbace_aot_emit__init_part0_A_clinit_p1(); A_arbace_aot_emit__init_part0_A_clinit_p2(); A_arbace_aot_emit__init_part0_A_clinit_p3(); A_arbace_aot_emit__init_part0_A_clinit_p4(); A_arbace_aot_emit__init_part0_A_clinit_p5(); A_arbace_aot_emit__init_part0_A_clinit_p6(); A_arbace_aot_emit__init_part0_A_clinit_p7(); A_arbace_aot_emit__init_part0_A_clinit_p8(); A_arbace_aot_emit__init_part0_A_clinit_p9(); A_arbace_aot_emit__init_part0_A_clinit_p10(); A_arbace_aot_emit__init_part0_A_clinit_p11(); A_arbace_aot_emit__init_part0_A_clinit_p12(); A_arbace_aot_emit__init_part0_A_clinit_p13(); A_arbace_aot_emit__init_part0_A_clinit_p14(); A_arbace_aot_emit__init_part0_A_clinit_p15(); A_arbace_aot_emit__init_part0_A_clinit_p16() }

func A_arbace_aot_emit__init_part0_A_clinit_p0() { A_arbace_aot_emit__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_301, 307); A_arbace_aot_emit__init_part0_A_const_0 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[89]); A_arbace_aot_emit__init_part0_A_const_1 = A_arbace_aot_emit__init_part0_A_const_pool.A[90]; A_arbace_aot_emit__init_part0_A_const_2 = A_arbace_aot_emit__init_part0_A_const_pool.A[91]; A_arbace_aot_emit__init_part0_A_const_3 = A_arbace_aot_emit__init_part0_A_const_pool.A[92]; A_arbace_aot_emit__init_part0_A_const_4 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[93]); A_arbace_aot_emit__init_part0_A_const_5 = A_arbace_aot_emit__init_part0_A_const_pool.A[94]; A_arbace_aot_emit__init_part0_A_const_6 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[95]); A_arbace_aot_emit__init_part0_A_const_7 = A_arbace_aot_emit__init_part0_A_const_pool.A[96]; A_arbace_aot_emit__init_part0_A_const_8 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[97]); A_arbace_aot_emit__init_part0_A_const_9 = A_arbace_aot_emit__init_part0_A_const_pool.A[98]; A_arbace_aot_emit__init_part0_A_const_10 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[99]); A_arbace_aot_emit__init_part0_A_const_11 = A_arbace_aot_emit__init_part0_A_const_pool.A[100]; A_arbace_aot_emit__init_part0_A_const_12 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[101]) }

func A_arbace_aot_emit__init_part0_A_clinit_p1() { A_arbace_aot_emit__init_part0_A_const_13 = A_arbace_aot_emit__init_part0_A_const_pool.A[102]; A_arbace_aot_emit__init_part0_A_const_14 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[103]); A_arbace_aot_emit__init_part0_A_const_15 = A_arbace_aot_emit__init_part0_A_const_pool.A[104]; A_arbace_aot_emit__init_part0_A_const_16 = A_arbace_aot_emit__init_part0_A_const_pool.A[105]; A_arbace_aot_emit__init_part0_A_const_17 = A_arbace_aot_emit__init_part0_A_const_pool.A[106]; A_arbace_aot_emit__init_part0_A_const_18 = A_arbace_aot_emit__init_part0_A_const_pool.A[107]; A_arbace_aot_emit__init_part0_A_const_19 = A_arbace_aot_emit__init_part0_A_const_pool.A[108]; A_arbace_aot_emit__init_part0_A_const_20 = A_arbace_aot_emit__init_part0_A_const_pool.A[109]; A_arbace_aot_emit__init_part0_A_const_21 = A_arbace_aot_emit__init_part0_A_const_pool.A[110]; A_arbace_aot_emit__init_part0_A_const_22 = A_arbace_aot_emit__init_part0_A_const_pool.A[111]; A_arbace_aot_emit__init_part0_A_const_23 = A_arbace_aot_emit__init_part0_A_const_pool.A[112]; A_arbace_aot_emit__init_part0_A_const_24 = A_arbace_aot_emit__init_part0_A_const_pool.A[113]; A_arbace_aot_emit__init_part0_A_const_25 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[114]); A_arbace_aot_emit__init_part0_A_const_26 = A_arbace_aot_emit__init_part0_A_const_pool.A[115]; A_arbace_aot_emit__init_part0_A_const_27 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[116]) }

func A_arbace_aot_emit__init_part0_A_clinit_p2() { A_arbace_aot_emit__init_part0_A_const_28 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[117]); A_arbace_aot_emit__init_part0_A_const_29 = A_arbace_aot_emit__init_part0_A_const_pool.A[118]; A_arbace_aot_emit__init_part0_A_const_30 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[119]); A_arbace_aot_emit__init_part0_A_const_31 = A_arbace_aot_emit__init_part0_A_const_pool.A[120]; A_arbace_aot_emit__init_part0_A_const_32 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[121]); A_arbace_aot_emit__init_part0_A_const_33 = A_arbace_aot_emit__init_part0_A_const_pool.A[122]; A_arbace_aot_emit__init_part0_A_const_34 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[123]); A_arbace_aot_emit__init_part0_A_const_35 = A_arbace_aot_emit__init_part0_A_const_pool.A[124]; A_arbace_aot_emit__init_part0_A_const_36 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[125]); A_arbace_aot_emit__init_part0_A_const_37 = A_arbace_aot_emit__init_part0_A_const_pool.A[126]; A_arbace_aot_emit__init_part0_A_const_38 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[127]); A_arbace_aot_emit__init_part0_A_const_39 = A_arbace_aot_emit__init_part0_A_const_pool.A[128]; A_arbace_aot_emit__init_part0_A_const_40 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[129]) }

func A_arbace_aot_emit__init_part0_A_clinit_p3() { A_arbace_aot_emit__init_part0_A_const_41 = A_arbace_aot_emit__init_part0_A_const_pool.A[130]; A_arbace_aot_emit__init_part0_A_const_42 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[131]); A_arbace_aot_emit__init_part0_A_const_43 = A_arbace_aot_emit__init_part0_A_const_pool.A[132]; A_arbace_aot_emit__init_part0_A_const_44 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[133]); A_arbace_aot_emit__init_part0_A_const_45 = A_arbace_aot_emit__init_part0_A_const_pool.A[134]; A_arbace_aot_emit__init_part0_A_const_46 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[135]); A_arbace_aot_emit__init_part0_A_const_47 = A_arbace_aot_emit__init_part0_A_const_pool.A[136]; A_arbace_aot_emit__init_part0_A_const_48 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[137]); A_arbace_aot_emit__init_part0_A_const_49 = A_arbace_aot_emit__init_part0_A_const_pool.A[138]; A_arbace_aot_emit__init_part0_A_const_50 = A_arbace_aot_emit__init_part0_A_const_pool.A[139]; A_arbace_aot_emit__init_part0_A_const_51 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[140]); A_arbace_aot_emit__init_part0_A_const_52 = A_arbace_aot_emit__init_part0_A_const_pool.A[141]; A_arbace_aot_emit__init_part0_A_const_53 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[142]); A_arbace_aot_emit__init_part0_A_const_54 = A_arbace_aot_emit__init_part0_A_const_pool.A[143] }

func A_arbace_aot_emit__init_part0_A_clinit_p4() { A_arbace_aot_emit__init_part0_A_const_55 = A_arbace_aot_emit__init_part0_A_const_pool.A[144]; A_arbace_aot_emit__init_part0_A_const_56 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[145]); A_arbace_aot_emit__init_part0_A_const_57 = A_arbace_aot_emit__init_part0_A_const_pool.A[146]; A_arbace_aot_emit__init_part0_A_const_58 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[147]); A_arbace_aot_emit__init_part0_A_const_59 = A_arbace_aot_emit__init_part0_A_const_pool.A[148]; A_arbace_aot_emit__init_part0_A_const_60 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[149]); A_arbace_aot_emit__init_part0_A_const_61 = A_arbace_aot_emit__init_part0_A_const_pool.A[150]; A_arbace_aot_emit__init_part0_A_const_62 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[151]); A_arbace_aot_emit__init_part0_A_const_63 = A_arbace_aot_emit__init_part0_A_const_pool.A[152]; A_arbace_aot_emit__init_part0_A_const_64 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[153]); A_arbace_aot_emit__init_part0_A_const_65 = A_arbace_aot_emit__init_part0_A_const_pool.A[154]; A_arbace_aot_emit__init_part0_A_const_66 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[155]); A_arbace_aot_emit__init_part0_A_const_67 = A_arbace_aot_emit__init_part0_A_const_pool.A[156] }

func A_arbace_aot_emit__init_part0_A_clinit_p5() { A_arbace_aot_emit__init_part0_A_const_68 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[157]); A_arbace_aot_emit__init_part0_A_const_69 = A_arbace_aot_emit__init_part0_A_const_pool.A[158]; A_arbace_aot_emit__init_part0_A_const_70 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[159]); A_arbace_aot_emit__init_part0_A_const_71 = A_arbace_aot_emit__init_part0_A_const_pool.A[160]; A_arbace_aot_emit__init_part0_A_const_72 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[161]); A_arbace_aot_emit__init_part0_A_const_73 = A_arbace_aot_emit__init_part0_A_const_pool.A[162]; A_arbace_aot_emit__init_part0_A_const_74 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[163]); A_arbace_aot_emit__init_part0_A_const_75 = A_arbace_aot_emit__init_part0_A_const_pool.A[164]; A_arbace_aot_emit__init_part0_A_const_76 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[165]); A_arbace_aot_emit__init_part0_A_const_77 = A_arbace_aot_emit__init_part0_A_const_pool.A[166]; A_arbace_aot_emit__init_part0_A_const_78 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[167]); A_arbace_aot_emit__init_part0_A_const_79 = A_arbace_aot_emit__init_part0_A_const_pool.A[168]; A_arbace_aot_emit__init_part0_A_const_80 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[169]) }

func A_arbace_aot_emit__init_part0_A_clinit_p6() { A_arbace_aot_emit__init_part0_A_const_81 = A_arbace_aot_emit__init_part0_A_const_pool.A[170]; A_arbace_aot_emit__init_part0_A_const_82 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[171]); A_arbace_aot_emit__init_part0_A_const_83 = A_arbace_aot_emit__init_part0_A_const_pool.A[172]; A_arbace_aot_emit__init_part0_A_const_84 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[173]); A_arbace_aot_emit__init_part0_A_const_85 = A_arbace_aot_emit__init_part0_A_const_pool.A[174]; A_arbace_aot_emit__init_part0_A_const_86 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[175]); A_arbace_aot_emit__init_part0_A_const_87 = A_arbace_aot_emit__init_part0_A_const_pool.A[176]; A_arbace_aot_emit__init_part0_A_const_88 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[177]); A_arbace_aot_emit__init_part0_A_const_89 = A_arbace_aot_emit__init_part0_A_const_pool.A[178]; A_arbace_aot_emit__init_part0_A_const_90 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[179]); A_arbace_aot_emit__init_part0_A_const_91 = A_arbace_aot_emit__init_part0_A_const_pool.A[180]; A_arbace_aot_emit__init_part0_A_const_92 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[181]); A_arbace_aot_emit__init_part0_A_const_93 = A_arbace_aot_emit__init_part0_A_const_pool.A[182] }

func A_arbace_aot_emit__init_part0_A_clinit_p7() { A_arbace_aot_emit__init_part0_A_const_94 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[183]); A_arbace_aot_emit__init_part0_A_const_95 = A_arbace_aot_emit__init_part0_A_const_pool.A[184]; A_arbace_aot_emit__init_part0_A_const_96 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[185]); A_arbace_aot_emit__init_part0_A_const_97 = A_arbace_aot_emit__init_part0_A_const_pool.A[186]; A_arbace_aot_emit__init_part0_A_const_98 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[187]); A_arbace_aot_emit__init_part0_A_const_99 = A_arbace_aot_emit__init_part0_A_const_pool.A[188]; A_arbace_aot_emit__init_part0_A_const_100 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[189]); A_arbace_aot_emit__init_part0_A_const_101 = A_arbace_aot_emit__init_part0_A_const_pool.A[190]; A_arbace_aot_emit__init_part0_A_const_102 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[191]); A_arbace_aot_emit__init_part0_A_const_103 = A_arbace_aot_emit__init_part0_A_const_pool.A[192]; A_arbace_aot_emit__init_part0_A_const_104 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[193]); A_arbace_aot_emit__init_part0_A_const_105 = A_arbace_aot_emit__init_part0_A_const_pool.A[194]; A_arbace_aot_emit__init_part0_A_const_106 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[195]) }

func A_arbace_aot_emit__init_part0_A_clinit_p8() { A_arbace_aot_emit__init_part0_A_const_107 = A_arbace_aot_emit__init_part0_A_const_pool.A[196]; A_arbace_aot_emit__init_part0_A_const_108 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[197]); A_arbace_aot_emit__init_part0_A_const_109 = A_arbace_aot_emit__init_part0_A_const_pool.A[198]; A_arbace_aot_emit__init_part0_A_const_110 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[199]); A_arbace_aot_emit__init_part0_A_const_111 = A_arbace_aot_emit__init_part0_A_const_pool.A[200]; A_arbace_aot_emit__init_part0_A_const_112 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[201]); A_arbace_aot_emit__init_part0_A_const_113 = A_arbace_aot_emit__init_part0_A_const_pool.A[202]; A_arbace_aot_emit__init_part0_A_const_114 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[203]); A_arbace_aot_emit__init_part0_A_const_115 = A_arbace_aot_emit__init_part0_A_const_pool.A[204]; A_arbace_aot_emit__init_part0_A_const_116 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[205]); A_arbace_aot_emit__init_part0_A_const_117 = A_arbace_aot_emit__init_part0_A_const_pool.A[206]; A_arbace_aot_emit__init_part0_A_const_118 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[207]); A_arbace_aot_emit__init_part0_A_const_119 = A_arbace_aot_emit__init_part0_A_const_pool.A[208] }

func A_arbace_aot_emit__init_part0_A_clinit_p9() { A_arbace_aot_emit__init_part0_A_const_120 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[209]); A_arbace_aot_emit__init_part0_A_const_121 = A_arbace_aot_emit__init_part0_A_const_pool.A[210]; A_arbace_aot_emit__init_part0_A_const_122 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[211]); A_arbace_aot_emit__init_part0_A_const_123 = A_arbace_aot_emit__init_part0_A_const_pool.A[212]; A_arbace_aot_emit__init_part0_A_const_124 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[213]); A_arbace_aot_emit__init_part0_A_const_125 = A_arbace_aot_emit__init_part0_A_const_pool.A[214]; A_arbace_aot_emit__init_part0_A_const_126 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[215]); A_arbace_aot_emit__init_part0_A_const_127 = A_arbace_aot_emit__init_part0_A_const_pool.A[216]; A_arbace_aot_emit__init_part0_A_const_128 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[217]); A_arbace_aot_emit__init_part0_A_const_129 = A_arbace_aot_emit__init_part0_A_const_pool.A[218]; A_arbace_aot_emit__init_part0_A_const_130 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[219]); A_arbace_aot_emit__init_part0_A_const_131 = A_arbace_aot_emit__init_part0_A_const_pool.A[220]; A_arbace_aot_emit__init_part0_A_const_132 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[221]) }

func A_arbace_aot_emit__init_part0_A_clinit_p10() { A_arbace_aot_emit__init_part0_A_const_133 = A_arbace_aot_emit__init_part0_A_const_pool.A[222]; A_arbace_aot_emit__init_part0_A_const_134 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[223]); A_arbace_aot_emit__init_part0_A_const_135 = A_arbace_aot_emit__init_part0_A_const_pool.A[224]; A_arbace_aot_emit__init_part0_A_const_136 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[225]); A_arbace_aot_emit__init_part0_A_const_137 = A_arbace_aot_emit__init_part0_A_const_pool.A[226]; A_arbace_aot_emit__init_part0_A_const_138 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[227]); A_arbace_aot_emit__init_part0_A_const_139 = A_arbace_aot_emit__init_part0_A_const_pool.A[228]; A_arbace_aot_emit__init_part0_A_const_140 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[229]); A_arbace_aot_emit__init_part0_A_const_141 = A_arbace_aot_emit__init_part0_A_const_pool.A[230]; A_arbace_aot_emit__init_part0_A_const_142 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[231]); A_arbace_aot_emit__init_part0_A_const_143 = A_arbace_aot_emit__init_part0_A_const_pool.A[232]; A_arbace_aot_emit__init_part0_A_const_144 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[233]); A_arbace_aot_emit__init_part0_A_const_145 = A_arbace_aot_emit__init_part0_A_const_pool.A[234] }

func A_arbace_aot_emit__init_part0_A_clinit_p11() { A_arbace_aot_emit__init_part0_A_const_146 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[235]); A_arbace_aot_emit__init_part0_A_const_147 = A_arbace_aot_emit__init_part0_A_const_pool.A[236]; A_arbace_aot_emit__init_part0_A_const_148 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[237]); A_arbace_aot_emit__init_part0_A_const_149 = A_arbace_aot_emit__init_part0_A_const_pool.A[238]; A_arbace_aot_emit__init_part0_A_const_150 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[239]); A_arbace_aot_emit__init_part0_A_const_151 = A_arbace_aot_emit__init_part0_A_const_pool.A[240]; A_arbace_aot_emit__init_part0_A_const_152 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[241]); A_arbace_aot_emit__init_part0_A_const_153 = A_arbace_aot_emit__init_part0_A_const_pool.A[242]; A_arbace_aot_emit__init_part0_A_const_154 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[243]); A_arbace_aot_emit__init_part0_A_const_155 = A_arbace_aot_emit__init_part0_A_const_pool.A[244]; A_arbace_aot_emit__init_part0_A_const_156 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[245]); A_arbace_aot_emit__init_part0_A_const_157 = A_arbace_aot_emit__init_part0_A_const_pool.A[246]; A_arbace_aot_emit__init_part0_A_const_158 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[247]) }

func A_arbace_aot_emit__init_part0_A_clinit_p12() { A_arbace_aot_emit__init_part0_A_const_159 = A_arbace_aot_emit__init_part0_A_const_pool.A[248]; A_arbace_aot_emit__init_part0_A_const_160 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[249]); A_arbace_aot_emit__init_part0_A_const_161 = A_arbace_aot_emit__init_part0_A_const_pool.A[250]; A_arbace_aot_emit__init_part0_A_const_162 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[251]); A_arbace_aot_emit__init_part0_A_const_163 = A_arbace_aot_emit__init_part0_A_const_pool.A[252]; A_arbace_aot_emit__init_part0_A_const_164 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[253]); A_arbace_aot_emit__init_part0_A_const_165 = A_arbace_aot_emit__init_part0_A_const_pool.A[254]; A_arbace_aot_emit__init_part0_A_const_166 = A_arbace_aot_emit__init_part0_A_const_pool.A[255]; A_arbace_aot_emit__init_part0_A_const_167 = A_arbace_aot_emit__init_part0_A_const_pool.A[256]; A_arbace_aot_emit__init_part0_A_const_168 = A_arbace_aot_emit__init_part0_A_const_pool.A[257]; A_arbace_aot_emit__init_part0_A_const_169 = A_arbace_aot_emit__init_part0_A_const_pool.A[258]; A_arbace_aot_emit__init_part0_A_const_170 = A_arbace_aot_emit__init_part0_A_const_pool.A[259]; A_arbace_aot_emit__init_part0_A_const_171 = A_arbace_aot_emit__init_part0_A_const_pool.A[260]; A_arbace_aot_emit__init_part0_A_const_172 = A_arbace_aot_emit__init_part0_A_const_pool.A[261]; A_arbace_aot_emit__init_part0_A_const_173 = A_arbace_aot_emit__init_part0_A_const_pool.A[262] }

func A_arbace_aot_emit__init_part0_A_clinit_p13() { A_arbace_aot_emit__init_part0_A_const_174 = A_arbace_aot_emit__init_part0_A_const_pool.A[263]; A_arbace_aot_emit__init_part0_A_const_175 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[264]); A_arbace_aot_emit__init_part0_A_const_176 = A_arbace_aot_emit__init_part0_A_const_pool.A[265]; A_arbace_aot_emit__init_part0_A_const_177 = A_arbace_aot_emit__init_part0_A_const_pool.A[266]; A_arbace_aot_emit__init_part0_A_const_178 = A_arbace_aot_emit__init_part0_A_const_pool.A[267]; A_arbace_aot_emit__init_part0_A_const_179 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[268]); A_arbace_aot_emit__init_part0_A_const_180 = A_arbace_aot_emit__init_part0_A_const_pool.A[269]; A_arbace_aot_emit__init_part0_A_const_181 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[270]); A_arbace_aot_emit__init_part0_A_const_182 = A_arbace_aot_emit__init_part0_A_const_pool.A[271]; A_arbace_aot_emit__init_part0_A_const_183 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[272]); A_arbace_aot_emit__init_part0_A_const_184 = A_arbace_aot_emit__init_part0_A_const_pool.A[273]; A_arbace_aot_emit__init_part0_A_const_185 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[274]); A_arbace_aot_emit__init_part0_A_const_186 = A_arbace_aot_emit__init_part0_A_const_pool.A[275]; A_arbace_aot_emit__init_part0_A_const_187 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[276]) }

func A_arbace_aot_emit__init_part0_A_clinit_p14() { A_arbace_aot_emit__init_part0_A_const_188 = A_arbace_aot_emit__init_part0_A_const_pool.A[277]; A_arbace_aot_emit__init_part0_A_const_189 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[278]); A_arbace_aot_emit__init_part0_A_const_190 = A_arbace_aot_emit__init_part0_A_const_pool.A[279]; A_arbace_aot_emit__init_part0_A_const_191 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[280]); A_arbace_aot_emit__init_part0_A_const_192 = A_arbace_aot_emit__init_part0_A_const_pool.A[281]; A_arbace_aot_emit__init_part0_A_const_193 = A_arbace_aot_emit__init_part0_A_const_pool.A[282]; A_arbace_aot_emit__init_part0_A_const_194 = A_arbace_aot_emit__init_part0_A_const_pool.A[283]; A_arbace_aot_emit__init_part0_A_const_195 = A_arbace_aot_emit__init_part0_A_const_pool.A[284]; A_arbace_aot_emit__init_part0_A_const_196 = A_arbace_aot_emit__init_part0_A_const_pool.A[285]; A_arbace_aot_emit__init_part0_A_const_197 = A_arbace_aot_emit__init_part0_A_const_pool.A[286]; A_arbace_aot_emit__init_part0_A_const_198 = A_arbace_aot_emit__init_part0_A_const_pool.A[287]; A_arbace_aot_emit__init_part0_A_const_199 = A_arbace_aot_emit__init_part0_A_const_pool.A[288]; A_arbace_aot_emit__init_part0_A_const_200 = A_arbace_aot_emit__init_part0_A_const_pool.A[289]; A_arbace_aot_emit__init_part0_A_const_201 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[290]); A_arbace_aot_emit__init_part0_A_const_202 = A_arbace_aot_emit__init_part0_A_const_pool.A[291] }

func A_arbace_aot_emit__init_part0_A_clinit_p15() { A_arbace_aot_emit__init_part0_A_const_203 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[292]); A_arbace_aot_emit__init_part0_A_const_204 = A_arbace_aot_emit__init_part0_A_const_pool.A[293]; A_arbace_aot_emit__init_part0_A_const_205 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[294]); A_arbace_aot_emit__init_part0_A_const_206 = A_arbace_aot_emit__init_part0_A_const_pool.A[295]; A_arbace_aot_emit__init_part0_A_const_207 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[296]); A_arbace_aot_emit__init_part0_A_const_208 = A_arbace_aot_emit__init_part0_A_const_pool.A[297]; A_arbace_aot_emit__init_part0_A_const_209 = A_arbace_aot_emit__init_part0_A_const_pool.A[298]; A_arbace_aot_emit__init_part0_A_const_210 = A_arbace_aot_emit__init_part0_A_const_pool.A[299]; A_arbace_aot_emit__init_part0_A_const_211 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[300]); A_arbace_aot_emit__init_part0_A_const_212 = A_arbace_aot_emit__init_part0_A_const_pool.A[301]; A_arbace_aot_emit__init_part0_A_const_213 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[302]); A_arbace_aot_emit__init_part0_A_const_214 = A_arbace_aot_emit__init_part0_A_const_pool.A[303]; A_arbace_aot_emit__init_part0_A_const_215 = lang.Var_Cast(A_arbace_aot_emit__init_part0_A_const_pool.A[304]); A_arbace_aot_emit__init_part0_A_const_216 = A_arbace_aot_emit__init_part0_A_const_pool.A[305] }

func A_arbace_aot_emit__init_part0_A_clinit_p16() { A_arbace_aot_emit__init_part0_A_const_217 = A_arbace_aot_emit__init_part0_A_const_pool.A[306] }

func A_arbace_aot_emit__init_part0_A_New() *A_arbace_aot_emit__init_part0_A { A_arbace_aot_emit__init_part0_A_Init(); t := &A_arbace_aot_emit__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_aot_emit__init_part0_A) Ctor() {}

func (t *A_arbace_aot_emit__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_emit__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_aot_emit__init_part0_A_class }

func (t *A_arbace_aot_emit__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_emit__init_part0_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_aot_emit__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_emit__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_emit__init_part0_A); return ok }

func A_arbace_aot_emit__init_part0_A_Cast(x any) *A_arbace_aot_emit__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_emit__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_emit__init_part0_A_class)) }; return v }



type A_arbace_aot_emit__init_part1_A struct{ jrt.Object }

var A_arbace_aot_emit__init_part1_A_const_pool *jrt.RefArray

var A_arbace_aot_emit__init_part1_A_const_0 *lang.Var

var A_arbace_aot_emit__init_part1_A_const_1 any

var A_arbace_aot_emit__init_part1_A_const_2 *lang.Var

var A_arbace_aot_emit__init_part1_A_const_3 any

var A_arbace_aot_emit__init_part1_A_const_4 *lang.Var

var A_arbace_aot_emit__init_part1_A_const_5 any

var A_arbace_aot_emit__init_part1_A_const_6 *lang.Var

var A_arbace_aot_emit__init_part1_A_const_7 any

var A_arbace_aot_emit__init_part1_A_init jrt.ClassInit

func A_arbace_aot_emit__init_part1_A_Init() { if !A_arbace_aot_emit__init_part1_A_init.Done() { A_arbace_aot_emit__init_part1_A_init.Run(A_arbace_aot_emit__init_part1_A_clinit) } }

func A_arbace_aot_emit__init_part1_A_clinit() { A_arbace_aot_emit__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_386, 26); A_arbace_aot_emit__init_part1_A_const_0 = lang.Var_Cast(A_arbace_aot_emit__init_part1_A_const_pool.A[18]); A_arbace_aot_emit__init_part1_A_const_1 = A_arbace_aot_emit__init_part1_A_const_pool.A[19]; A_arbace_aot_emit__init_part1_A_const_2 = lang.Var_Cast(A_arbace_aot_emit__init_part1_A_const_pool.A[20]); A_arbace_aot_emit__init_part1_A_const_3 = A_arbace_aot_emit__init_part1_A_const_pool.A[21]; A_arbace_aot_emit__init_part1_A_const_4 = lang.Var_Cast(A_arbace_aot_emit__init_part1_A_const_pool.A[22]); A_arbace_aot_emit__init_part1_A_const_5 = A_arbace_aot_emit__init_part1_A_const_pool.A[23]; A_arbace_aot_emit__init_part1_A_const_6 = lang.Var_Cast(A_arbace_aot_emit__init_part1_A_const_pool.A[24]); A_arbace_aot_emit__init_part1_A_const_7 = A_arbace_aot_emit__init_part1_A_const_pool.A[25] }

func A_arbace_aot_emit__init_part1_A_New() *A_arbace_aot_emit__init_part1_A { A_arbace_aot_emit__init_part1_A_Init(); t := &A_arbace_aot_emit__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_aot_emit__init_part1_A) Ctor() {}

func (t *A_arbace_aot_emit__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_emit__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_aot_emit__init_part1_A_class }

func (t *A_arbace_aot_emit__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_emit__init_part1_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_aot_emit__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_emit__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_emit__init_part1_A); return ok }

func A_arbace_aot_emit__init_part1_A_Cast(x any) *A_arbace_aot_emit__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_emit__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_emit__init_part1_A_class)) }; return v }
