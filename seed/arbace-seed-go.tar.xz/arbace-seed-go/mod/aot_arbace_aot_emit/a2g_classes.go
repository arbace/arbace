//line a2g_classes.ae:1
package aot_arbace_aot_emit

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_aot_emit_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_A_New()}; return nil }

var A_arbace_aot_emit_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_aot_emit_A_new}

var A_arbace_aot_emit_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_A"})

func init() { i := A_arbace_aot_emit_A_class.Info(); i.IsInstance = A_arbace_aot_emit_A_InstanceOf; i.Init = A_arbace_aot_emit_A_Init; i.Table = A_arbace_aot_emit_A_members; jrt.RegisterGoType(A_arbace_aot_emit_A_class, reflect.TypeFor[A_arbace_aot_emit_A]()) }

func A_arbace_aot_emit_body_instance_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_body_instance_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_body_instance_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_body_instance_A_New()}; return nil }

func A_arbace_aot_emit_body_instance_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_body_instance_A_fn_class)}; return nil }

var A_arbace_aot_emit_body_instance_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_body_instance_A_invoke, New: A_arbace_aot_emit_body_instance_A_new, Get: A_arbace_aot_emit_body_instance_A_get}

var A_arbace_aot_emit_body_instance_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$body_instance", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "body_instance", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_body_instance_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_body_instance_A_class.Info(); i.IsInstance = A_arbace_aot_emit_body_instance_A_InstanceOf; i.Init = A_arbace_aot_emit_body_instance_A_Init; i.Table = A_arbace_aot_emit_body_instance_A_members; jrt.RegisterGoType(A_arbace_aot_emit_body_instance_A_class, reflect.TypeFor[A_arbace_aot_emit_body_instance_A]()) }

func A_arbace_aot_emit_body_instance_iter__90000117__90000121_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_body_instance_iter__90000117__90000121_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_body_instance_iter__90000117__90000121_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_body_instance_iter__90000117__90000121_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_body_instance_iter__90000117__90000121_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_body_instance_iter__90000117__90000121_A_fn_class)}; return nil }

var A_arbace_aot_emit_body_instance_iter__90000117__90000121_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_body_instance_iter__90000117__90000121_A_invoke, New: A_arbace_aot_emit_body_instance_iter__90000117__90000121_A_new, Get: A_arbace_aot_emit_body_instance_iter__90000117__90000121_A_get}

var A_arbace_aot_emit_body_instance_iter__90000117__90000121_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$body_instance$iter__90000117__90000121", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_body_instance_A_class, Simple: "iter__90000117__90000121", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_body_instance_iter__90000117__90000121_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_body_instance_iter__90000117__90000121_A_class.Info(); i.IsInstance = A_arbace_aot_emit_body_instance_iter__90000117__90000121_A_InstanceOf; i.Init = A_arbace_aot_emit_body_instance_iter__90000117__90000121_A_Init; i.Table = A_arbace_aot_emit_body_instance_iter__90000117__90000121_A_members; jrt.RegisterGoType(A_arbace_aot_emit_body_instance_iter__90000117__90000121_A_class, reflect.TypeFor[A_arbace_aot_emit_body_instance_iter__90000117__90000121_A]()) }

func A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_A_fn_class)}; return nil }

var A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_A_invoke, New: A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_A_new, Get: A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_A_get}

var A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$body_instance$iter__90000117__90000121$fn__90000122", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_body_instance_iter__90000117__90000121_A_class, Simple: "fn__90000122", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_A_class.Info(); i.IsInstance = A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_A_InstanceOf; i.Init = A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_A_Init; i.Table = A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_A_members; jrt.RegisterGoType(A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_A_class, reflect.TypeFor[A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_A]()) }

func A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_fn__90000123_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_fn__90000123_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_fn__90000123_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_fn__90000123_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_fn__90000123_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_fn__90000123_A_fn_class)}; return nil }

var A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_fn__90000123_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_fn__90000123_A_invoke, New: A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_fn__90000123_A_new, Get: A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_fn__90000123_A_get}

var A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_fn__90000123_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$body_instance$iter__90000117__90000121$fn__90000122$fn__90000123", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_A_class, Simple: "fn__90000123", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_fn__90000123_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_fn__90000123_A_class.Info(); i.IsInstance = A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_fn__90000123_A_InstanceOf; i.Init = A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_fn__90000123_A_Init; i.Table = A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_fn__90000123_A_members; jrt.RegisterGoType(A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_fn__90000123_A_class, reflect.TypeFor[A_arbace_aot_emit_body_instance_iter__90000117__90000121_fn__90000122_fn__90000123_A]()) }

func A_arbace_aot_emit_box_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_box_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_box_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_box_A_New()}; return nil }

func A_arbace_aot_emit_box_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_box_A_fn_class)}; return nil }

var A_arbace_aot_emit_box_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_box_A_invoke, New: A_arbace_aot_emit_box_A_new, Get: A_arbace_aot_emit_box_A_get}

var A_arbace_aot_emit_box_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$box", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "box", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_box_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_box_A_class.Info(); i.IsInstance = A_arbace_aot_emit_box_A_InstanceOf; i.Init = A_arbace_aot_emit_box_A_Init; i.Table = A_arbace_aot_emit_box_A_members; jrt.RegisterGoType(A_arbace_aot_emit_box_A_class, reflect.TypeFor[A_arbace_aot_emit_box_A]()) }

func A_arbace_aot_emit_box_class_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_box_class_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_box_class_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_box_class_A_New()}; return nil }

func A_arbace_aot_emit_box_class_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_box_class_A_fn_class)}; return nil }

var A_arbace_aot_emit_box_class_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_box_class_A_invoke, New: A_arbace_aot_emit_box_class_A_new, Get: A_arbace_aot_emit_box_class_A_get}

var A_arbace_aot_emit_box_class_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$box_class", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "box_class", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_box_class_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_box_class_A_class.Info(); i.IsInstance = A_arbace_aot_emit_box_class_A_InstanceOf; i.Init = A_arbace_aot_emit_box_class_A_Init; i.Table = A_arbace_aot_emit_box_class_A_members; jrt.RegisterGoType(A_arbace_aot_emit_box_class_A_class, reflect.TypeFor[A_arbace_aot_emit_box_class_A]()) }

func A_arbace_aot_emit_box_prim_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_box_prim_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_box_prim_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_box_prim_A_New()}; return nil }

func A_arbace_aot_emit_box_prim_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_box_prim_A_fn_class)}; return nil }

var A_arbace_aot_emit_box_prim_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_box_prim_A_invoke, New: A_arbace_aot_emit_box_prim_A_new, Get: A_arbace_aot_emit_box_prim_A_get}

var A_arbace_aot_emit_box_prim_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$box_prim", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "box_prim", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_box_prim_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_box_prim_A_class.Info(); i.IsInstance = A_arbace_aot_emit_box_prim_A_InstanceOf; i.Init = A_arbace_aot_emit_box_prim_A_Init; i.Table = A_arbace_aot_emit_box_prim_A_members; jrt.RegisterGoType(A_arbace_aot_emit_box_prim_A_class, reflect.TypeFor[A_arbace_aot_emit_box_prim_A]()) }

func A_arbace_aot_emit_can_prim_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_can_prim_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_can_prim_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_can_prim_QMARK__A_New()}; return nil }

func A_arbace_aot_emit_can_prim_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_can_prim_QMARK__A_fn_class)}; return nil }

var A_arbace_aot_emit_can_prim_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_can_prim_QMARK__A_invoke, New: A_arbace_aot_emit_can_prim_QMARK__A_new, Get: A_arbace_aot_emit_can_prim_QMARK__A_get}

var A_arbace_aot_emit_can_prim_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$can_prim_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "can_prim_QMARK_", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_can_prim_QMARK__A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_can_prim_QMARK__A_class.Info(); i.IsInstance = A_arbace_aot_emit_can_prim_QMARK__A_InstanceOf; i.Init = A_arbace_aot_emit_can_prim_QMARK__A_Init; i.Table = A_arbace_aot_emit_can_prim_QMARK__A_members; jrt.RegisterGoType(A_arbace_aot_emit_can_prim_QMARK__A_class, reflect.TypeFor[A_arbace_aot_emit_can_prim_QMARK__A]()) }

func A_arbace_aot_emit_char_form_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_char_form_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_char_form_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_char_form_A_New()}; return nil }

func A_arbace_aot_emit_char_form_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_char_form_A_fn_class)}; return nil }

var A_arbace_aot_emit_char_form_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_char_form_A_invoke, New: A_arbace_aot_emit_char_form_A_new, Get: A_arbace_aot_emit_char_form_A_get}

var A_arbace_aot_emit_char_form_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$char_form", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "char_form", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_char_form_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_char_form_A_class.Info(); i.IsInstance = A_arbace_aot_emit_char_form_A_InstanceOf; i.Init = A_arbace_aot_emit_char_form_A_Init; i.Table = A_arbace_aot_emit_char_form_A_members; jrt.RegisterGoType(A_arbace_aot_emit_char_form_A_class, reflect.TypeFor[A_arbace_aot_emit_char_form_A]()) }

func A_arbace_aot_emit_class_form_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_class_form_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_aot_emit_class_form_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_class_form_A_New()}; return nil }

func A_arbace_aot_emit_class_form_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_class_form_A_fn_class)}; return nil }

var A_arbace_aot_emit_class_form_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_class_form_A_invoke, New: A_arbace_aot_emit_class_form_A_new, Get: A_arbace_aot_emit_class_form_A_get}

var A_arbace_aot_emit_class_form_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$class_form", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "class_form", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_class_form_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_class_form_A_class.Info(); i.IsInstance = A_arbace_aot_emit_class_form_A_InstanceOf; i.Init = A_arbace_aot_emit_class_form_A_Init; i.Table = A_arbace_aot_emit_class_form_A_members; jrt.RegisterGoType(A_arbace_aot_emit_class_form_A_class, reflect.TypeFor[A_arbace_aot_emit_class_form_A]()) }

func A_arbace_aot_emit_class_form_fn__90000488_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_class_form_fn__90000488_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_class_form_fn__90000488_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_class_form_fn__90000488_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_class_form_fn__90000488_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_class_form_fn__90000488_A_fn_class)}; return nil }

var A_arbace_aot_emit_class_form_fn__90000488_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_class_form_fn__90000488_A_invoke, New: A_arbace_aot_emit_class_form_fn__90000488_A_new, Get: A_arbace_aot_emit_class_form_fn__90000488_A_get}

var A_arbace_aot_emit_class_form_fn__90000488_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$class_form$fn__90000488", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_class_form_A_class, Simple: "fn__90000488", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_class_form_fn__90000488_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_class_form_fn__90000488_A_class.Info(); i.IsInstance = A_arbace_aot_emit_class_form_fn__90000488_A_InstanceOf; i.Init = A_arbace_aot_emit_class_form_fn__90000488_A_Init; i.Table = A_arbace_aot_emit_class_form_fn__90000488_A_members; jrt.RegisterGoType(A_arbace_aot_emit_class_form_fn__90000488_A_class, reflect.TypeFor[A_arbace_aot_emit_class_form_fn__90000488_A]()) }

func A_arbace_aot_emit_class_form_iter__90000493__90000497_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_class_form_iter__90000493__90000497_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_class_form_iter__90000493__90000497_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_class_form_iter__90000493__90000497_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_class_form_iter__90000493__90000497_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_class_form_iter__90000493__90000497_A_fn_class)}; return nil }

var A_arbace_aot_emit_class_form_iter__90000493__90000497_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_class_form_iter__90000493__90000497_A_invoke, New: A_arbace_aot_emit_class_form_iter__90000493__90000497_A_new, Get: A_arbace_aot_emit_class_form_iter__90000493__90000497_A_get}

var A_arbace_aot_emit_class_form_iter__90000493__90000497_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$class_form$iter__90000493__90000497", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_class_form_A_class, Simple: "iter__90000493__90000497", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_class_form_iter__90000493__90000497_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_class_form_iter__90000493__90000497_A_class.Info(); i.IsInstance = A_arbace_aot_emit_class_form_iter__90000493__90000497_A_InstanceOf; i.Init = A_arbace_aot_emit_class_form_iter__90000493__90000497_A_Init; i.Table = A_arbace_aot_emit_class_form_iter__90000493__90000497_A_members; jrt.RegisterGoType(A_arbace_aot_emit_class_form_iter__90000493__90000497_A_class, reflect.TypeFor[A_arbace_aot_emit_class_form_iter__90000493__90000497_A]()) }

func A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_A_fn_class)}; return nil }

var A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_A_invoke, New: A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_A_new, Get: A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_A_get}

var A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$class_form$iter__90000493__90000497$fn__90000498", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_class_form_iter__90000493__90000497_A_class, Simple: "fn__90000498", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_A_class.Info(); i.IsInstance = A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_A_InstanceOf; i.Init = A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_A_Init; i.Table = A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_A_members; jrt.RegisterGoType(A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_A_class, reflect.TypeFor[A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_A]()) }

func A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_fn__90000499_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_fn__90000499_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_fn__90000499_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_fn__90000499_A_New_O_I_O_O(args[0], args[1].(int32), args[2], args[3])}; return nil }

func A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_fn__90000499_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_fn__90000499_A_fn_class)}; return nil }

var A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_fn__90000499_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_fn__90000499_A_invoke, New: A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_fn__90000499_A_new, Get: A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_fn__90000499_A_get}

var A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_fn__90000499_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$class_form$iter__90000493__90000497$fn__90000498$fn__90000499", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_A_class, Simple: "fn__90000499", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_fn__90000499_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_fn__90000499_A_class.Info(); i.IsInstance = A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_fn__90000499_A_InstanceOf; i.Init = A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_fn__90000499_A_Init; i.Table = A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_fn__90000499_A_members; jrt.RegisterGoType(A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_fn__90000499_A_class, reflect.TypeFor[A_arbace_aot_emit_class_form_iter__90000493__90000497_fn__90000498_fn__90000499_A]()) }

func A_arbace_aot_emit_class_form_mods__90000490_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_class_form_mods__90000490_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_class_form_mods__90000490_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_class_form_mods__90000490_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_class_form_mods__90000490_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_class_form_mods__90000490_A_fn_class)}; return nil }

var A_arbace_aot_emit_class_form_mods__90000490_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_class_form_mods__90000490_A_invoke, New: A_arbace_aot_emit_class_form_mods__90000490_A_new, Get: A_arbace_aot_emit_class_form_mods__90000490_A_get}

var A_arbace_aot_emit_class_form_mods__90000490_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$class_form$mods__90000490", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_class_form_A_class, Simple: "mods__90000490", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_class_form_mods__90000490_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_class_form_mods__90000490_A_class.Info(); i.IsInstance = A_arbace_aot_emit_class_form_mods__90000490_A_InstanceOf; i.Init = A_arbace_aot_emit_class_form_mods__90000490_A_Init; i.Table = A_arbace_aot_emit_class_form_mods__90000490_A_members; jrt.RegisterGoType(A_arbace_aot_emit_class_form_mods__90000490_A_class, reflect.TypeFor[A_arbace_aot_emit_class_form_mods__90000490_A]()) }

func A_arbace_aot_emit_class_forms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_class_forms_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_class_forms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_class_forms_A_New()}; return nil }

func A_arbace_aot_emit_class_forms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_class_forms_A_fn_class)}; return nil }

var A_arbace_aot_emit_class_forms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_class_forms_A_invoke, New: A_arbace_aot_emit_class_forms_A_new, Get: A_arbace_aot_emit_class_forms_A_get}

var A_arbace_aot_emit_class_forms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$class_forms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "class_forms", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_class_forms_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_class_forms_A_class.Info(); i.IsInstance = A_arbace_aot_emit_class_forms_A_InstanceOf; i.Init = A_arbace_aot_emit_class_forms_A_Init; i.Table = A_arbace_aot_emit_class_forms_A_members; jrt.RegisterGoType(A_arbace_aot_emit_class_forms_A_class, reflect.TypeFor[A_arbace_aot_emit_class_forms_A]()) }

func A_arbace_aot_emit_class_forms_children_of__90000527_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_class_forms_children_of__90000527_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_class_forms_children_of__90000527_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_class_forms_children_of__90000527_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_class_forms_children_of__90000527_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_class_forms_children_of__90000527_A_fn_class)}; return nil }

var A_arbace_aot_emit_class_forms_children_of__90000527_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_class_forms_children_of__90000527_A_invoke, New: A_arbace_aot_emit_class_forms_children_of__90000527_A_new, Get: A_arbace_aot_emit_class_forms_children_of__90000527_A_get}

var A_arbace_aot_emit_class_forms_children_of__90000527_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$class_forms$children_of__90000527", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_class_forms_A_class, Simple: "children_of__90000527", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_class_forms_children_of__90000527_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_class_forms_children_of__90000527_A_class.Info(); i.IsInstance = A_arbace_aot_emit_class_forms_children_of__90000527_A_InstanceOf; i.Init = A_arbace_aot_emit_class_forms_children_of__90000527_A_Init; i.Table = A_arbace_aot_emit_class_forms_children_of__90000527_A_members; jrt.RegisterGoType(A_arbace_aot_emit_class_forms_children_of__90000527_A_class, reflect.TypeFor[A_arbace_aot_emit_class_forms_children_of__90000527_A]()) }

func A_arbace_aot_emit_class_forms_fn__90000513_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_class_forms_fn__90000513_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_class_forms_fn__90000513_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_class_forms_fn__90000513_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_class_forms_fn__90000513_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_class_forms_fn__90000513_A_fn_class)}; return nil }

var A_arbace_aot_emit_class_forms_fn__90000513_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_class_forms_fn__90000513_A_invoke, New: A_arbace_aot_emit_class_forms_fn__90000513_A_new, Get: A_arbace_aot_emit_class_forms_fn__90000513_A_get}

var A_arbace_aot_emit_class_forms_fn__90000513_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$class_forms$fn__90000513", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_class_forms_A_class, Simple: "fn__90000513", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_class_forms_fn__90000513_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_class_forms_fn__90000513_A_class.Info(); i.IsInstance = A_arbace_aot_emit_class_forms_fn__90000513_A_InstanceOf; i.Init = A_arbace_aot_emit_class_forms_fn__90000513_A_Init; i.Table = A_arbace_aot_emit_class_forms_fn__90000513_A_members; jrt.RegisterGoType(A_arbace_aot_emit_class_forms_fn__90000513_A_class, reflect.TypeFor[A_arbace_aot_emit_class_forms_fn__90000513_A]()) }

func A_arbace_aot_emit_class_forms_fn__90000525_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_class_forms_fn__90000525_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_class_forms_fn__90000525_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_class_forms_fn__90000525_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_class_forms_fn__90000525_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_class_forms_fn__90000525_A_fn_class)}; return nil }

var A_arbace_aot_emit_class_forms_fn__90000525_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_class_forms_fn__90000525_A_invoke, New: A_arbace_aot_emit_class_forms_fn__90000525_A_new, Get: A_arbace_aot_emit_class_forms_fn__90000525_A_get}

var A_arbace_aot_emit_class_forms_fn__90000525_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$class_forms$fn__90000525", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_class_forms_A_class, Simple: "fn__90000525", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_class_forms_fn__90000525_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_class_forms_fn__90000525_A_class.Info(); i.IsInstance = A_arbace_aot_emit_class_forms_fn__90000525_A_InstanceOf; i.Init = A_arbace_aot_emit_class_forms_fn__90000525_A_Init; i.Table = A_arbace_aot_emit_class_forms_fn__90000525_A_members; jrt.RegisterGoType(A_arbace_aot_emit_class_forms_fn__90000525_A_class, reflect.TypeFor[A_arbace_aot_emit_class_forms_fn__90000525_A]()) }

func A_arbace_aot_emit_class_forms_iter__90000515__90000519_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_class_forms_iter__90000515__90000519_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_class_forms_iter__90000515__90000519_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_class_forms_iter__90000515__90000519_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_class_forms_iter__90000515__90000519_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_class_forms_iter__90000515__90000519_A_fn_class)}; return nil }

var A_arbace_aot_emit_class_forms_iter__90000515__90000519_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_class_forms_iter__90000515__90000519_A_invoke, New: A_arbace_aot_emit_class_forms_iter__90000515__90000519_A_new, Get: A_arbace_aot_emit_class_forms_iter__90000515__90000519_A_get}

var A_arbace_aot_emit_class_forms_iter__90000515__90000519_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$class_forms$iter__90000515__90000519", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_class_forms_A_class, Simple: "iter__90000515__90000519", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_class_forms_iter__90000515__90000519_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_class_forms_iter__90000515__90000519_A_class.Info(); i.IsInstance = A_arbace_aot_emit_class_forms_iter__90000515__90000519_A_InstanceOf; i.Init = A_arbace_aot_emit_class_forms_iter__90000515__90000519_A_Init; i.Table = A_arbace_aot_emit_class_forms_iter__90000515__90000519_A_members; jrt.RegisterGoType(A_arbace_aot_emit_class_forms_iter__90000515__90000519_A_class, reflect.TypeFor[A_arbace_aot_emit_class_forms_iter__90000515__90000519_A]()) }

func A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_A_fn_class)}; return nil }

var A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_A_invoke, New: A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_A_new, Get: A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_A_get}

var A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$class_forms$iter__90000515__90000519$fn__90000520", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_class_forms_iter__90000515__90000519_A_class, Simple: "fn__90000520", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_A_class.Info(); i.IsInstance = A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_A_InstanceOf; i.Init = A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_A_Init; i.Table = A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_A_members; jrt.RegisterGoType(A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_A_class, reflect.TypeFor[A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_A]()) }

func A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_fn__90000521_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_fn__90000521_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_fn__90000521_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_fn__90000521_A_New_O_I_O_O(args[0], args[1].(int32), args[2], args[3])}; return nil }

func A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_fn__90000521_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_fn__90000521_A_fn_class)}; return nil }

var A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_fn__90000521_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_fn__90000521_A_invoke, New: A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_fn__90000521_A_new, Get: A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_fn__90000521_A_get}

var A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_fn__90000521_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$class_forms$iter__90000515__90000519$fn__90000520$fn__90000521", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_A_class, Simple: "fn__90000521", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_fn__90000521_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_fn__90000521_A_class.Info(); i.IsInstance = A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_fn__90000521_A_InstanceOf; i.Init = A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_fn__90000521_A_Init; i.Table = A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_fn__90000521_A_members; jrt.RegisterGoType(A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_fn__90000521_A_class, reflect.TypeFor[A_arbace_aot_emit_class_forms_iter__90000515__90000519_fn__90000520_fn__90000521_A]()) }

func A_arbace_aot_emit_class_forms_iter__90000529__90000533_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_class_forms_iter__90000529__90000533_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_class_forms_iter__90000529__90000533_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_class_forms_iter__90000529__90000533_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_class_forms_iter__90000529__90000533_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_class_forms_iter__90000529__90000533_A_fn_class)}; return nil }

var A_arbace_aot_emit_class_forms_iter__90000529__90000533_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_class_forms_iter__90000529__90000533_A_invoke, New: A_arbace_aot_emit_class_forms_iter__90000529__90000533_A_new, Get: A_arbace_aot_emit_class_forms_iter__90000529__90000533_A_get}

var A_arbace_aot_emit_class_forms_iter__90000529__90000533_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$class_forms$iter__90000529__90000533", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_class_forms_A_class, Simple: "iter__90000529__90000533", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_class_forms_iter__90000529__90000533_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_class_forms_iter__90000529__90000533_A_class.Info(); i.IsInstance = A_arbace_aot_emit_class_forms_iter__90000529__90000533_A_InstanceOf; i.Init = A_arbace_aot_emit_class_forms_iter__90000529__90000533_A_Init; i.Table = A_arbace_aot_emit_class_forms_iter__90000529__90000533_A_members; jrt.RegisterGoType(A_arbace_aot_emit_class_forms_iter__90000529__90000533_A_class, reflect.TypeFor[A_arbace_aot_emit_class_forms_iter__90000529__90000533_A]()) }

func A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_A_fn_class)}; return nil }

var A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_A_invoke, New: A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_A_new, Get: A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_A_get}

var A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$class_forms$iter__90000529__90000533$fn__90000534", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_class_forms_iter__90000529__90000533_A_class, Simple: "fn__90000534", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_A_class.Info(); i.IsInstance = A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_A_InstanceOf; i.Init = A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_A_Init; i.Table = A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_A_members; jrt.RegisterGoType(A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_A_class, reflect.TypeFor[A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_A]()) }

func A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_fn__90000535_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_fn__90000535_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_fn__90000535_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_fn__90000535_A_New_O_O_O_I_O_O(args[0], args[1], args[2], args[3].(int32), args[4], args[5])}; return nil }

func A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_fn__90000535_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_fn__90000535_A_fn_class)}; return nil }

var A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_fn__90000535_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_fn__90000535_A_invoke, New: A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_fn__90000535_A_new, Get: A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_fn__90000535_A_get}

var A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_fn__90000535_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$class_forms$iter__90000529__90000533$fn__90000534$fn__90000535", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_A_class, Simple: "fn__90000535", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_fn__90000535_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_fn__90000535_A_class.Info(); i.IsInstance = A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_fn__90000535_A_InstanceOf; i.Init = A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_fn__90000535_A_Init; i.Table = A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_fn__90000535_A_members; jrt.RegisterGoType(A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_fn__90000535_A_class, reflect.TypeFor[A_arbace_aot_emit_class_forms_iter__90000529__90000533_fn__90000534_fn__90000535_A]()) }

func A_arbace_aot_emit_class_forms_parent__90000511_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_class_forms_parent__90000511_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_class_forms_parent__90000511_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_class_forms_parent__90000511_A_New()}; return nil }

func A_arbace_aot_emit_class_forms_parent__90000511_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_class_forms_parent__90000511_A_fn_class)}; return nil }

var A_arbace_aot_emit_class_forms_parent__90000511_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_class_forms_parent__90000511_A_invoke, New: A_arbace_aot_emit_class_forms_parent__90000511_A_new, Get: A_arbace_aot_emit_class_forms_parent__90000511_A_get}

var A_arbace_aot_emit_class_forms_parent__90000511_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$class_forms$parent__90000511", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_class_forms_A_class, Simple: "parent__90000511", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_class_forms_parent__90000511_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_class_forms_parent__90000511_A_class.Info(); i.IsInstance = A_arbace_aot_emit_class_forms_parent__90000511_A_InstanceOf; i.Init = A_arbace_aot_emit_class_forms_parent__90000511_A_Init; i.Table = A_arbace_aot_emit_class_forms_parent__90000511_A_members; jrt.RegisterGoType(A_arbace_aot_emit_class_forms_parent__90000511_A_class, reflect.TypeFor[A_arbace_aot_emit_class_forms_parent__90000511_A]()) }

func A_arbace_aot_emit_class_interfaces_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_class_interfaces_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_class_interfaces_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_class_interfaces_A_New()}; return nil }

func A_arbace_aot_emit_class_interfaces_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_class_interfaces_A_fn_class)}; return nil }

var A_arbace_aot_emit_class_interfaces_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_class_interfaces_A_invoke, New: A_arbace_aot_emit_class_interfaces_A_new, Get: A_arbace_aot_emit_class_interfaces_A_get}

var A_arbace_aot_emit_class_interfaces_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$class_interfaces", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "class_interfaces", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_class_interfaces_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_class_interfaces_A_class.Info(); i.IsInstance = A_arbace_aot_emit_class_interfaces_A_InstanceOf; i.Init = A_arbace_aot_emit_class_interfaces_A_Init; i.Table = A_arbace_aot_emit_class_interfaces_A_members; jrt.RegisterGoType(A_arbace_aot_emit_class_interfaces_A_class, reflect.TypeFor[A_arbace_aot_emit_class_interfaces_A]()) }

func A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_A_fn_class)}; return nil }

var A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_A_invoke, New: A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_A_new, Get: A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_A_get}

var A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$class_interfaces$iter__90000240__90000244", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_class_interfaces_A_class, Simple: "iter__90000240__90000244", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_A_class.Info(); i.IsInstance = A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_A_InstanceOf; i.Init = A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_A_Init; i.Table = A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_A_members; jrt.RegisterGoType(A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_A_class, reflect.TypeFor[A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_A]()) }

func A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_A_fn_class)}; return nil }

var A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_A_invoke, New: A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_A_new, Get: A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_A_get}

var A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$class_interfaces$iter__90000240__90000244$fn__90000245", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_A_class, Simple: "fn__90000245", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_A_class.Info(); i.IsInstance = A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_A_InstanceOf; i.Init = A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_A_Init; i.Table = A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_A_members; jrt.RegisterGoType(A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_A_class, reflect.TypeFor[A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_A]()) }

func A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_fn__90000246_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_fn__90000246_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_fn__90000246_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_fn__90000246_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_fn__90000246_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_fn__90000246_A_fn_class)}; return nil }

var A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_fn__90000246_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_fn__90000246_A_invoke, New: A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_fn__90000246_A_new, Get: A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_fn__90000246_A_get}

var A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_fn__90000246_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$class_interfaces$iter__90000240__90000244$fn__90000245$fn__90000246", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_A_class, Simple: "fn__90000246", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_fn__90000246_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_fn__90000246_A_class.Info(); i.IsInstance = A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_fn__90000246_A_InstanceOf; i.Init = A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_fn__90000246_A_Init; i.Table = A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_fn__90000246_A_members; jrt.RegisterGoType(A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_fn__90000246_A_class, reflect.TypeFor[A_arbace_aot_emit_class_interfaces_iter__90000240__90000244_fn__90000245_fn__90000246_A]()) }

func A_arbace_aot_emit_closed_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_closed_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_closed_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_closed_QMARK__A_New()}; return nil }

func A_arbace_aot_emit_closed_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_closed_QMARK__A_fn_class)}; return nil }

var A_arbace_aot_emit_closed_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_closed_QMARK__A_invoke, New: A_arbace_aot_emit_closed_QMARK__A_new, Get: A_arbace_aot_emit_closed_QMARK__A_get}

var A_arbace_aot_emit_closed_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$closed_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "closed_QMARK_", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_closed_QMARK__A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_closed_QMARK__A_class.Info(); i.IsInstance = A_arbace_aot_emit_closed_QMARK__A_InstanceOf; i.Init = A_arbace_aot_emit_closed_QMARK__A_Init; i.Table = A_arbace_aot_emit_closed_QMARK__A_members; jrt.RegisterGoType(A_arbace_aot_emit_closed_QMARK__A_class, reflect.TypeFor[A_arbace_aot_emit_closed_QMARK__A]()) }

func A_arbace_aot_emit_coll_call_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_coll_call_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_coll_call_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_coll_call_A_New()}; return nil }

func A_arbace_aot_emit_coll_call_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_coll_call_A_fn_class)}; return nil }

var A_arbace_aot_emit_coll_call_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_coll_call_A_invoke, New: A_arbace_aot_emit_coll_call_A_new, Get: A_arbace_aot_emit_coll_call_A_get}

var A_arbace_aot_emit_coll_call_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$coll_call", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "coll_call", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_coll_call_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_coll_call_A_class.Info(); i.IsInstance = A_arbace_aot_emit_coll_call_A_InstanceOf; i.Init = A_arbace_aot_emit_coll_call_A_Init; i.Table = A_arbace_aot_emit_coll_call_A_members; jrt.RegisterGoType(A_arbace_aot_emit_coll_call_A_class, reflect.TypeFor[A_arbace_aot_emit_coll_call_A]()) }

func A_arbace_aot_emit_compiled_interface_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_compiled_interface_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_compiled_interface_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_compiled_interface_QMARK__A_New()}; return nil }

func A_arbace_aot_emit_compiled_interface_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_compiled_interface_QMARK__A_fn_class)}; return nil }

var A_arbace_aot_emit_compiled_interface_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_compiled_interface_QMARK__A_invoke, New: A_arbace_aot_emit_compiled_interface_QMARK__A_new, Get: A_arbace_aot_emit_compiled_interface_QMARK__A_get}

var A_arbace_aot_emit_compiled_interface_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$compiled_interface_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "compiled_interface_QMARK_", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_compiled_interface_QMARK__A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_compiled_interface_QMARK__A_class.Info(); i.IsInstance = A_arbace_aot_emit_compiled_interface_QMARK__A_InstanceOf; i.Init = A_arbace_aot_emit_compiled_interface_QMARK__A_Init; i.Table = A_arbace_aot_emit_compiled_interface_QMARK__A_members; jrt.RegisterGoType(A_arbace_aot_emit_compiled_interface_QMARK__A_class, reflect.TypeFor[A_arbace_aot_emit_compiled_interface_QMARK__A]()) }

func A_arbace_aot_emit_const_field_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_const_field_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_const_field_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_const_field_A_New()}; return nil }

func A_arbace_aot_emit_const_field_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_const_field_A_fn_class)}; return nil }

var A_arbace_aot_emit_const_field_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_const_field_A_invoke, New: A_arbace_aot_emit_const_field_A_new, Get: A_arbace_aot_emit_const_field_A_get}

var A_arbace_aot_emit_const_field_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$const_field", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "const_field", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_const_field_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_const_field_A_class.Info(); i.IsInstance = A_arbace_aot_emit_const_field_A_InstanceOf; i.Init = A_arbace_aot_emit_const_field_A_Init; i.Table = A_arbace_aot_emit_const_field_A_members; jrt.RegisterGoType(A_arbace_aot_emit_const_field_A_class, reflect.TypeFor[A_arbace_aot_emit_const_field_A]()) }

func A_arbace_aot_emit_const_type_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_const_type_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_const_type_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_const_type_A_New()}; return nil }

func A_arbace_aot_emit_const_type_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_const_type_A_fn_class)}; return nil }

var A_arbace_aot_emit_const_type_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_const_type_A_invoke, New: A_arbace_aot_emit_const_type_A_new, Get: A_arbace_aot_emit_const_type_A_get}

var A_arbace_aot_emit_const_type_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$const_type", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "const_type", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_const_type_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_const_type_A_class.Info(); i.IsInstance = A_arbace_aot_emit_const_type_A_InstanceOf; i.Init = A_arbace_aot_emit_const_type_A_Init; i.Table = A_arbace_aot_emit_const_type_A_members; jrt.RegisterGoType(A_arbace_aot_emit_const_type_A_class, reflect.TypeFor[A_arbace_aot_emit_const_type_A]()) }

func A_arbace_aot_emit_constant_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_constant_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_constant_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_constant_A_New()}; return nil }

func A_arbace_aot_emit_constant_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_constant_A_fn_class)}; return nil }

var A_arbace_aot_emit_constant_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_constant_A_invoke, New: A_arbace_aot_emit_constant_A_new, Get: A_arbace_aot_emit_constant_A_get}

var A_arbace_aot_emit_constant_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$constant", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "constant", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_constant_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_constant_A_class.Info(); i.IsInstance = A_arbace_aot_emit_constant_A_InstanceOf; i.Init = A_arbace_aot_emit_constant_A_Init; i.Table = A_arbace_aot_emit_constant_A_members; jrt.RegisterGoType(A_arbace_aot_emit_constant_A_class, reflect.TypeFor[A_arbace_aot_emit_constant_A]()) }

func A_arbace_aot_emit_deep_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_deep_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_deep_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_deep_A_New()}; return nil }

func A_arbace_aot_emit_deep_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_deep_A_fn_class)}; return nil }

var A_arbace_aot_emit_deep_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_deep_A_invoke, New: A_arbace_aot_emit_deep_A_new, Get: A_arbace_aot_emit_deep_A_get}

var A_arbace_aot_emit_deep_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$deep", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "deep", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_deep_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_deep_A_class.Info(); i.IsInstance = A_arbace_aot_emit_deep_A_InstanceOf; i.Init = A_arbace_aot_emit_deep_A_Init; i.Table = A_arbace_aot_emit_deep_A_members; jrt.RegisterGoType(A_arbace_aot_emit_deep_A_class, reflect.TypeFor[A_arbace_aot_emit_deep_A]()) }

func A_arbace_aot_emit_descriptor_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_descriptor_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_descriptor_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_descriptor_A_New()}; return nil }

func A_arbace_aot_emit_descriptor_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_descriptor_A_fn_class)}; return nil }

var A_arbace_aot_emit_descriptor_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_descriptor_A_invoke, New: A_arbace_aot_emit_descriptor_A_new, Get: A_arbace_aot_emit_descriptor_A_get}

var A_arbace_aot_emit_descriptor_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$descriptor", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "descriptor", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_descriptor_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_descriptor_A_class.Info(); i.IsInstance = A_arbace_aot_emit_descriptor_A_InstanceOf; i.Init = A_arbace_aot_emit_descriptor_A_Init; i.Table = A_arbace_aot_emit_descriptor_A_members; jrt.RegisterGoType(A_arbace_aot_emit_descriptor_A_class, reflect.TypeFor[A_arbace_aot_emit_descriptor_A]()) }

func A_arbace_aot_emit_destub_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_destub_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_destub_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_destub_A_New()}; return nil }

func A_arbace_aot_emit_destub_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_destub_A_fn_class)}; return nil }

var A_arbace_aot_emit_destub_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_destub_A_invoke, New: A_arbace_aot_emit_destub_A_new, Get: A_arbace_aot_emit_destub_A_get}

var A_arbace_aot_emit_destub_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$destub", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "destub", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_destub_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_destub_A_class.Info(); i.IsInstance = A_arbace_aot_emit_destub_A_InstanceOf; i.Init = A_arbace_aot_emit_destub_A_Init; i.Table = A_arbace_aot_emit_destub_A_members; jrt.RegisterGoType(A_arbace_aot_emit_destub_A_class, reflect.TypeFor[A_arbace_aot_emit_destub_A]()) }

func A_arbace_aot_emit_double_form_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_double_form_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_double_form_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_double_form_A_New()}; return nil }

func A_arbace_aot_emit_double_form_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_double_form_A_fn_class)}; return nil }

var A_arbace_aot_emit_double_form_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_double_form_A_invoke, New: A_arbace_aot_emit_double_form_A_new, Get: A_arbace_aot_emit_double_form_A_get}

var A_arbace_aot_emit_double_form_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$double_form", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "double_form", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_double_form_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_double_form_A_class.Info(); i.IsInstance = A_arbace_aot_emit_double_form_A_InstanceOf; i.Init = A_arbace_aot_emit_double_form_A_Init; i.Table = A_arbace_aot_emit_double_form_A_members; jrt.RegisterGoType(A_arbace_aot_emit_double_form_A_class, reflect.TypeFor[A_arbace_aot_emit_double_form_A]()) }

func A_arbace_aot_emit_emit_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_A_New()}; return nil }

func A_arbace_aot_emit_emit_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_A_invoke, New: A_arbace_aot_emit_emit_A_new, Get: A_arbace_aot_emit_emit_A_get}

var A_arbace_aot_emit_emit_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "emit", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_A_Init; i.Table = A_arbace_aot_emit_emit_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_A]()) }

func A_arbace_aot_emit_emit_fn__90000205_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn__90000205_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_fn__90000205_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn__90000205_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_emit_fn__90000205_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn__90000205_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn__90000205_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn__90000205_A_invoke, New: A_arbace_aot_emit_emit_fn__90000205_A_new, Get: A_arbace_aot_emit_emit_fn__90000205_A_get}

var A_arbace_aot_emit_emit_fn__90000205_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit$fn__90000205", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_A_class, Simple: "fn__90000205", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn__90000205_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn__90000205_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn__90000205_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn__90000205_A_Init; i.Table = A_arbace_aot_emit_emit_fn__90000205_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn__90000205_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn__90000205_A]()) }

func A_arbace_aot_emit_emit_fn__90000207_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn__90000207_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_fn__90000207_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn__90000207_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_emit_fn__90000207_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn__90000207_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn__90000207_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn__90000207_A_invoke, New: A_arbace_aot_emit_emit_fn__90000207_A_new, Get: A_arbace_aot_emit_emit_fn__90000207_A_get}

var A_arbace_aot_emit_emit_fn__90000207_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit$fn__90000207", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_A_class, Simple: "fn__90000207", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn__90000207_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn__90000207_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn__90000207_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn__90000207_A_Init; i.Table = A_arbace_aot_emit_emit_fn__90000207_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn__90000207_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn__90000207_A]()) }

func A_arbace_aot_emit_emit_fn__90000209_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn__90000209_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_fn__90000209_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn__90000209_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_emit_fn__90000209_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn__90000209_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn__90000209_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn__90000209_A_invoke, New: A_arbace_aot_emit_emit_fn__90000209_A_new, Get: A_arbace_aot_emit_emit_fn__90000209_A_get}

var A_arbace_aot_emit_emit_fn__90000209_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit$fn__90000209", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_emit_A_class, Simple: "fn__90000209", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn__90000209_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn__90000209_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn__90000209_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn__90000209_A_Init; i.Table = A_arbace_aot_emit_emit_fn__90000209_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn__90000209_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn__90000209_A]()) }

func A_arbace_aot_emit_emit_assign_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_assign_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_assign_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_assign_A_New()}; return nil }

func A_arbace_aot_emit_emit_assign_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_assign_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_assign_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_assign_A_invoke, New: A_arbace_aot_emit_emit_assign_A_new, Get: A_arbace_aot_emit_emit_assign_A_get}

var A_arbace_aot_emit_emit_assign_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_assign", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "emit_assign", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_assign_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_assign_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_assign_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_assign_A_Init; i.Table = A_arbace_aot_emit_emit_assign_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_assign_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_assign_A]()) }

func A_arbace_aot_emit_emit_binding_init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_binding_init_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_emit_binding_init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_binding_init_A_New()}; return nil }

func A_arbace_aot_emit_emit_binding_init_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_binding_init_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_binding_init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_binding_init_A_invoke, New: A_arbace_aot_emit_emit_binding_init_A_new, Get: A_arbace_aot_emit_emit_binding_init_A_get}

var A_arbace_aot_emit_emit_binding_init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_binding_init", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "emit_binding_init", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_binding_init_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_binding_init_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_binding_init_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_binding_init_A_Init; i.Table = A_arbace_aot_emit_emit_binding_init_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_binding_init_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_binding_init_A]()) }

func A_arbace_aot_emit_emit_case_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_case_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_emit_case_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_case_A_New()}; return nil }

func A_arbace_aot_emit_emit_case_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_case_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_case_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_case_A_invoke, New: A_arbace_aot_emit_emit_case_A_new, Get: A_arbace_aot_emit_emit_case_A_get}

var A_arbace_aot_emit_emit_case_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_case", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "emit_case", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_case_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_case_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_case_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_case_A_Init; i.Table = A_arbace_aot_emit_emit_case_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_case_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_case_A]()) }

func A_arbace_aot_emit_emit_case_arm__90000187_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_case_arm__90000187_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_emit_case_arm__90000187_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_case_arm__90000187_A_New_O_O_O_O_O_O_Z_O_O(args[0], args[1], args[2], args[3], args[4], args[5], args[6].(bool), args[7], args[8])}; return nil }

func A_arbace_aot_emit_emit_case_arm__90000187_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_case_arm__90000187_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_case_arm__90000187_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ZLjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_case_arm__90000187_A_invoke, New: A_arbace_aot_emit_emit_case_arm__90000187_A_new, Get: A_arbace_aot_emit_emit_case_arm__90000187_A_get}

var A_arbace_aot_emit_emit_case_arm__90000187_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_case$arm__90000187", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_emit_emit_case_A_class, Simple: "arm__90000187", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_case_arm__90000187_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_case_arm__90000187_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_case_arm__90000187_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_case_arm__90000187_A_Init; i.Table = A_arbace_aot_emit_emit_case_arm__90000187_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_case_arm__90000187_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_case_arm__90000187_A]()) }

func A_arbace_aot_emit_emit_case_fn__90000190_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_case_fn__90000190_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_case_fn__90000190_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_case_fn__90000190_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_case_fn__90000190_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_case_fn__90000190_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_case_fn__90000190_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_case_fn__90000190_A_invoke, New: A_arbace_aot_emit_emit_case_fn__90000190_A_new, Get: A_arbace_aot_emit_emit_case_fn__90000190_A_get}

var A_arbace_aot_emit_emit_case_fn__90000190_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_case$fn__90000190", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_case_A_class, Simple: "fn__90000190", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_case_fn__90000190_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_case_fn__90000190_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_case_fn__90000190_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_case_fn__90000190_A_Init; i.Table = A_arbace_aot_emit_emit_case_fn__90000190_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_case_fn__90000190_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_case_fn__90000190_A]()) }

func A_arbace_aot_emit_emit_case_fn__90000196_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_case_fn__90000196_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_case_fn__90000196_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_case_fn__90000196_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_case_fn__90000196_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_case_fn__90000196_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_case_fn__90000196_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_case_fn__90000196_A_invoke, New: A_arbace_aot_emit_emit_case_fn__90000196_A_new, Get: A_arbace_aot_emit_emit_case_fn__90000196_A_get}

var A_arbace_aot_emit_emit_case_fn__90000196_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_case$fn__90000196", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_case_A_class, Simple: "fn__90000196", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_case_fn__90000196_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_case_fn__90000196_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_case_fn__90000196_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_case_fn__90000196_A_Init; i.Table = A_arbace_aot_emit_emit_case_fn__90000196_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_case_fn__90000196_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_case_fn__90000196_A]()) }

func A_arbace_aot_emit_emit_case_ret__90000185_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_case_ret__90000185_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_case_ret__90000185_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_case_ret__90000185_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_case_ret__90000185_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_case_ret__90000185_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_case_ret__90000185_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_case_ret__90000185_A_invoke, New: A_arbace_aot_emit_emit_case_ret__90000185_A_new, Get: A_arbace_aot_emit_emit_case_ret__90000185_A_get}

var A_arbace_aot_emit_emit_case_ret__90000185_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_case$ret__90000185", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_case_A_class, Simple: "ret__90000185", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_case_ret__90000185_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_case_ret__90000185_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_case_ret__90000185_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_case_ret__90000185_A_Init; i.Table = A_arbace_aot_emit_emit_case_ret__90000185_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_case_ret__90000185_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_case_ret__90000185_A]()) }

func A_arbace_aot_emit_emit_case_sm__90000183_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_case_sm__90000183_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_case_sm__90000183_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_case_sm__90000183_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_case_sm__90000183_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_case_sm__90000183_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_case_sm__90000183_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_case_sm__90000183_A_invoke, New: A_arbace_aot_emit_emit_case_sm__90000183_A_new, Get: A_arbace_aot_emit_emit_case_sm__90000183_A_get}

var A_arbace_aot_emit_emit_case_sm__90000183_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_case$sm__90000183", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_case_A_class, Simple: "sm__90000183", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_case_sm__90000183_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_case_sm__90000183_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_case_sm__90000183_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_case_sm__90000183_A_Init; i.Table = A_arbace_aot_emit_emit_case_sm__90000183_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_case_sm__90000183_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_case_sm__90000183_A]()) }

func A_arbace_aot_emit_emit_def_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_def_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_emit_def_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_def_A_New()}; return nil }

func A_arbace_aot_emit_emit_def_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_def_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_def_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_def_A_invoke, New: A_arbace_aot_emit_emit_def_A_new, Get: A_arbace_aot_emit_emit_def_A_get}

var A_arbace_aot_emit_emit_def_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_def", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "emit_def", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_def_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_def_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_def_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_def_A_Init; i.Table = A_arbace_aot_emit_emit_def_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_def_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_def_A]()) }

func A_arbace_aot_emit_emit_deftype_class_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_deftype_class_BANG__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_deftype_class_BANG__A_New()}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_deftype_class_BANG__A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_deftype_class_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_deftype_class_BANG__A_invoke, New: A_arbace_aot_emit_emit_deftype_class_BANG__A_new, Get: A_arbace_aot_emit_emit_deftype_class_BANG__A_get}

var A_arbace_aot_emit_emit_deftype_class_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_deftype_class_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "emit_deftype_class_BANG_", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_deftype_class_BANG__A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_deftype_class_BANG__A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_deftype_class_BANG__A_InstanceOf; i.Init = A_arbace_aot_emit_emit_deftype_class_BANG__A_Init; i.Table = A_arbace_aot_emit_emit_deftype_class_BANG__A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_deftype_class_BANG__A_class, reflect.TypeFor[A_arbace_aot_emit_emit_deftype_class_BANG__A]()) }

func A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000259_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000259_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000259_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000259_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000259_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000259_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000259_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000259_A_invoke, New: A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000259_A_new, Get: A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000259_A_get}

var A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000259_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_deftype_class_BANG_$fn__90000259", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_deftype_class_BANG__A_class, Simple: "fn__90000259", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000259_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000259_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000259_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000259_A_Init; i.Table = A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000259_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000259_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000259_A]()) }

func A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000292_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000292_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000292_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000292_A_New()}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000292_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000292_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000292_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000292_A_invoke, New: A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000292_A_new, Get: A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000292_A_get}

var A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000292_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_deftype_class_BANG_$fn__90000292", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_deftype_class_BANG__A_class, Simple: "fn__90000292", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000292_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000292_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000292_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000292_A_Init; i.Table = A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000292_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000292_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000292_A]()) }

func A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000257_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000257_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000257_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000257_A_New()}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000257_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000257_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000257_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000257_A_invoke, New: A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000257_A_new, Get: A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000257_A_get}

var A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000257_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_deftype_class_BANG_$fsym__90000257", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_deftype_class_BANG__A_class, Simple: "fsym__90000257", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000257_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000257_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000257_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000257_A_Init; i.Table = A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000257_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000257_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000257_A]()) }

func A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000255_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000255_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000255_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000255_A_New()}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000255_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000255_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000255_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000255_A_invoke, New: A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000255_A_new, Get: A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000255_A_get}

var A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000255_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_deftype_class_BANG_$ftype__90000255", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_deftype_class_BANG__A_class, Simple: "ftype__90000255", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000255_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000255_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000255_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000255_A_Init; i.Table = A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000255_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000255_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000255_A]()) }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_A_invoke, New: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_A_new, Get: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_A_get}

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_deftype_class_BANG_$iter__90000261__90000265", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_deftype_class_BANG__A_class, Simple: "iter__90000261__90000265", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_A_Init; i.Table = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_A]()) }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_A_invoke, New: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_A_new, Get: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_A_get}

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_deftype_class_BANG_$iter__90000261__90000265$fn__90000266", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_A_class, Simple: "fn__90000266", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_A_Init; i.Table = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_A]()) }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_fn__90000267_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_fn__90000267_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_fn__90000267_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_fn__90000267_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_fn__90000267_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_fn__90000267_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_fn__90000267_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_fn__90000267_A_invoke, New: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_fn__90000267_A_new, Get: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_fn__90000267_A_get}

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_fn__90000267_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_deftype_class_BANG_$iter__90000261__90000265$fn__90000266$fn__90000267", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_A_class, Simple: "fn__90000267", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_fn__90000267_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_fn__90000267_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_fn__90000267_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_fn__90000267_A_Init; i.Table = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_fn__90000267_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_fn__90000267_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000261__90000265_fn__90000266_fn__90000267_A]()) }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_A_invoke, New: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_A_new, Get: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_A_get}

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_deftype_class_BANG_$iter__90000275__90000279", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_deftype_class_BANG__A_class, Simple: "iter__90000275__90000279", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_A_Init; i.Table = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_A]()) }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_A_invoke, New: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_A_new, Get: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_A_get}

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_deftype_class_BANG_$iter__90000275__90000279$fn__90000280", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_A_class, Simple: "fn__90000280", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_A_Init; i.Table = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_A]()) }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_fn__90000281_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_fn__90000281_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_fn__90000281_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_fn__90000281_A_New_O_I_O_O(args[0], args[1].(int32), args[2], args[3])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_fn__90000281_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_fn__90000281_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_fn__90000281_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_fn__90000281_A_invoke, New: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_fn__90000281_A_new, Get: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_fn__90000281_A_get}

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_fn__90000281_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_deftype_class_BANG_$iter__90000275__90000279$fn__90000280$fn__90000281", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_A_class, Simple: "fn__90000281", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_fn__90000281_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_fn__90000281_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_fn__90000281_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_fn__90000281_A_Init; i.Table = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_fn__90000281_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_fn__90000281_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000275__90000279_fn__90000280_fn__90000281_A]()) }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_A_invoke, New: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_A_new, Get: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_A_get}

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_deftype_class_BANG_$iter__90000297__90000301", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_deftype_class_BANG__A_class, Simple: "iter__90000297__90000301", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_A_Init; i.Table = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_A]()) }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_A_invoke, New: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_A_new, Get: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_A_get}

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_deftype_class_BANG_$iter__90000297__90000301$fn__90000302", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_A_class, Simple: "fn__90000302", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_A_Init; i.Table = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_A]()) }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_fn__90000303_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_fn__90000303_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_fn__90000303_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_fn__90000303_A_New_O_I_O_O(args[0], args[1].(int32), args[2], args[3])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_fn__90000303_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_fn__90000303_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_fn__90000303_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_fn__90000303_A_invoke, New: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_fn__90000303_A_new, Get: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_fn__90000303_A_get}

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_fn__90000303_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_deftype_class_BANG_$iter__90000297__90000301$fn__90000302$fn__90000303", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_A_class, Simple: "fn__90000303", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_fn__90000303_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_fn__90000303_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_fn__90000303_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_fn__90000303_A_Init; i.Table = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_fn__90000303_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_fn__90000303_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000297__90000301_fn__90000302_fn__90000303_A]()) }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_A_invoke, New: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_A_new, Get: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_A_get}

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_deftype_class_BANG_$iter__90000313__90000317", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_deftype_class_BANG__A_class, Simple: "iter__90000313__90000317", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_A_Init; i.Table = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_A]()) }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_A_invoke, New: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_A_new, Get: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_A_get}

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_deftype_class_BANG_$iter__90000313__90000317$fn__90000318", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_A_class, Simple: "fn__90000318", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_A_Init; i.Table = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_A]()) }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_A_New_O_I_O_O(args[0], args[1].(int32), args[2], args[3])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_A_invoke, New: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_A_new, Get: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_A_get}

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_deftype_class_BANG_$iter__90000313__90000317$fn__90000318$fn__90000319", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_A_class, Simple: "fn__90000319", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_A_Init; i.Table = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_A]()) }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000320_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000320_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000320_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000320_A_New()}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000320_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000320_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000320_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000320_A_invoke, New: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000320_A_new, Get: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000320_A_get}

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000320_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_deftype_class_BANG_$iter__90000313__90000317$fn__90000318$fn__90000319$fn__90000320", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_A_class, Simple: "fn__90000320", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000320_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000320_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000320_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000320_A_Init; i.Table = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000320_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000320_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000320_A]()) }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000322_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000322_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000322_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000322_A_New()}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000322_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000322_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000322_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000322_A_invoke, New: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000322_A_new, Get: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000322_A_get}

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000322_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_deftype_class_BANG_$iter__90000313__90000317$fn__90000318$fn__90000319$fn__90000322", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_A_class, Simple: "fn__90000322", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000322_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000322_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000322_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000322_A_Init; i.Table = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000322_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000322_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000319_fn__90000322_A]()) }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000325_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000325_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000325_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000325_A_New()}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000325_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000325_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000325_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000325_A_invoke, New: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000325_A_new, Get: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000325_A_get}

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000325_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_deftype_class_BANG_$iter__90000313__90000317$fn__90000318$fn__90000325", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_A_class, Simple: "fn__90000325", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000325_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000325_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000325_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000325_A_Init; i.Table = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000325_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000325_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000325_A]()) }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000327_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000327_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000327_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000327_A_New()}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000327_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000327_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000327_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000327_A_invoke, New: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000327_A_new, Get: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000327_A_get}

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000327_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_deftype_class_BANG_$iter__90000313__90000317$fn__90000318$fn__90000327", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_A_class, Simple: "fn__90000327", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000327_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000327_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000327_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000327_A_Init; i.Table = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000327_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000327_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000313__90000317_fn__90000318_fn__90000327_A]()) }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_A_invoke, New: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_A_new, Get: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_A_get}

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_deftype_class_BANG_$iter__90000331__90000335", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_deftype_class_BANG__A_class, Simple: "iter__90000331__90000335", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_A_Init; i.Table = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_A]()) }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_A_invoke, New: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_A_new, Get: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_A_get}

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_deftype_class_BANG_$iter__90000331__90000335$fn__90000336", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_A_class, Simple: "fn__90000336", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_A_Init; i.Table = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_A]()) }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_fn__90000337_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_fn__90000337_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_fn__90000337_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_fn__90000337_A_New_O_O_O_O_I_O(args[0], args[1], args[2], args[3], args[4].(int32), args[5])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_fn__90000337_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_fn__90000337_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_fn__90000337_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_fn__90000337_A_invoke, New: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_fn__90000337_A_new, Get: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_fn__90000337_A_get}

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_fn__90000337_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_deftype_class_BANG_$iter__90000331__90000335$fn__90000336$fn__90000337", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_A_class, Simple: "fn__90000337", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_fn__90000337_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_fn__90000337_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_fn__90000337_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_fn__90000337_A_Init; i.Table = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_fn__90000337_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_fn__90000337_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000331__90000335_fn__90000336_fn__90000337_A]()) }

func A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_A_invoke, New: A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_A_new, Get: A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_A_get}

var A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_deftype_class_BANG_$ps__90000271", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_deftype_class_BANG__A_class, Simple: "ps__90000271", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_A_Init; i.Table = A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_A]()) }

func A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_fn__90000272_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_fn__90000272_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_fn__90000272_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_fn__90000272_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_fn__90000272_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_fn__90000272_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_fn__90000272_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_fn__90000272_A_invoke, New: A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_fn__90000272_A_new, Get: A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_fn__90000272_A_get}

var A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_fn__90000272_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_deftype_class_BANG_$ps__90000271$fn__90000272", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_A_class, Simple: "fn__90000272", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_fn__90000272_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_fn__90000272_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_fn__90000272_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_fn__90000272_A_Init; i.Table = A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_fn__90000272_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_fn__90000272_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000271_fn__90000272_A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__A_New()}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "emit_fn_class_BANG_", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__fn__90000344_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__fn__90000344_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__fn__90000344_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__fn__90000344_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__fn__90000344_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__fn__90000344_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__fn__90000344_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__fn__90000344_A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__fn__90000344_A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__fn__90000344_A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__fn__90000344_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_$fn__90000344", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_fn_class_BANG__A_class, Simple: "fn__90000344", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__fn__90000344_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__fn__90000344_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__fn__90000344_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__fn__90000344_A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__fn__90000344_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__fn__90000344_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__fn__90000344_A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__fn__90000376_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__fn__90000376_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__fn__90000376_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__fn__90000376_A_New()}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__fn__90000376_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__fn__90000376_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__fn__90000376_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__fn__90000376_A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__fn__90000376_A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__fn__90000376_A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__fn__90000376_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_$fn__90000376", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_fn_class_BANG__A_class, Simple: "fn__90000376", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__fn__90000376_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__fn__90000376_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__fn__90000376_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__fn__90000376_A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__fn__90000376_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__fn__90000376_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__fn__90000376_A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_A_New()}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_$iter__90000346__90000350", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_fn_class_BANG__A_class, Simple: "iter__90000346__90000350", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_$iter__90000346__90000350$fn__90000351", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_A_class, Simple: "fn__90000351", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_fn__90000352_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_fn__90000352_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_fn__90000352_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_fn__90000352_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_fn__90000352_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_fn__90000352_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_fn__90000352_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_fn__90000352_A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_fn__90000352_A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_fn__90000352_A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_fn__90000352_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_$iter__90000346__90000350$fn__90000351$fn__90000352", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_A_class, Simple: "fn__90000352", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_fn__90000352_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_fn__90000352_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_fn__90000352_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_fn__90000352_A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_fn__90000352_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_fn__90000352_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__iter__90000346__90000350_fn__90000351_fn__90000352_A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_A_New()}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_$iter__90000356__90000360", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_fn_class_BANG__A_class, Simple: "iter__90000356__90000360", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_$iter__90000356__90000360$fn__90000361", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_A_class, Simple: "fn__90000361", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_fn__90000362_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_fn__90000362_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_fn__90000362_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_fn__90000362_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_fn__90000362_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_fn__90000362_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_fn__90000362_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_fn__90000362_A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_fn__90000362_A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_fn__90000362_A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_fn__90000362_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_$iter__90000356__90000360$fn__90000361$fn__90000362", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_A_class, Simple: "fn__90000362", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_fn__90000362_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_fn__90000362_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_fn__90000362_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_fn__90000362_A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_fn__90000362_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_fn__90000362_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__iter__90000356__90000360_fn__90000361_fn__90000362_A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_A_New()}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_$iter__90000366__90000370", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_fn_class_BANG__A_class, Simple: "iter__90000366__90000370", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_$iter__90000366__90000370$fn__90000371", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_A_class, Simple: "fn__90000371", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_fn__90000372_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_fn__90000372_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_fn__90000372_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_fn__90000372_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_fn__90000372_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_fn__90000372_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_fn__90000372_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_fn__90000372_A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_fn__90000372_A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_fn__90000372_A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_fn__90000372_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_$iter__90000366__90000370$fn__90000371$fn__90000372", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_A_class, Simple: "fn__90000372", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_fn__90000372_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_fn__90000372_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_fn__90000372_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_fn__90000372_A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_fn__90000372_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_fn__90000372_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__iter__90000366__90000370_fn__90000371_fn__90000372_A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_$iter__90000378__90000382", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_fn_class_BANG__A_class, Simple: "iter__90000378__90000382", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_$iter__90000378__90000382$fn__90000383", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_A_class, Simple: "fn__90000383", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_fn__90000384_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_fn__90000384_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_fn__90000384_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_fn__90000384_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_fn__90000384_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_fn__90000384_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_fn__90000384_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_fn__90000384_A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_fn__90000384_A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_fn__90000384_A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_fn__90000384_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_$iter__90000378__90000382$fn__90000383$fn__90000384", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_A_class, Simple: "fn__90000384", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_fn__90000384_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_fn__90000384_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_fn__90000384_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_fn__90000384_A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_fn__90000384_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_fn__90000384_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__iter__90000378__90000382_fn__90000383_fn__90000384_A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_$iter__90000388__90000392", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_fn_class_BANG__A_class, Simple: "iter__90000388__90000392", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_$iter__90000388__90000392$fn__90000393", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_A_class, Simple: "fn__90000393", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_$iter__90000388__90000392$fn__90000393$fn__90000394", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_A_class, Simple: "fn__90000394", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000395_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000395_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000395_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000395_A_New()}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000395_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000395_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000395_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000395_A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000395_A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000395_A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000395_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_$iter__90000388__90000392$fn__90000393$fn__90000394$fn__90000395", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_A_class, Simple: "fn__90000395", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000395_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000395_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000395_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000395_A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000395_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000395_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000395_A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000397_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000397_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000397_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000397_A_New()}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000397_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000397_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000397_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000397_A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000397_A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000397_A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000397_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_$iter__90000388__90000392$fn__90000393$fn__90000394$fn__90000397", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_A_class, Simple: "fn__90000397", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000397_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000397_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000397_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000397_A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000397_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000397_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000394_fn__90000397_A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000400_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000400_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000400_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000400_A_New()}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000400_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000400_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000400_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000400_A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000400_A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000400_A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000400_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_$iter__90000388__90000392$fn__90000393$fn__90000400", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_A_class, Simple: "fn__90000400", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000400_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000400_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000400_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000400_A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000400_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000400_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000400_A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000402_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000402_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000402_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000402_A_New()}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000402_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000402_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000402_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000402_A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000402_A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000402_A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000402_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_$iter__90000388__90000392$fn__90000393$fn__90000402", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_A_class, Simple: "fn__90000402", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000402_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000402_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000402_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000402_A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000402_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000402_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__iter__90000388__90000392_fn__90000393_fn__90000402_A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_A_New()}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_$iter__90000406__90000410", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_fn_class_BANG__A_class, Simple: "iter__90000406__90000410", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_$iter__90000406__90000410$fn__90000411", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_A_class, Simple: "fn__90000411", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_fn__90000412_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_fn__90000412_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_fn__90000412_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_fn__90000412_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_fn__90000412_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_fn__90000412_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_fn__90000412_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_fn__90000412_A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_fn__90000412_A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_fn__90000412_A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_fn__90000412_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_$iter__90000406__90000410$fn__90000411$fn__90000412", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_A_class, Simple: "fn__90000412", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_fn__90000412_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_fn__90000412_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_fn__90000412_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_fn__90000412_A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_fn__90000412_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_fn__90000412_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__iter__90000406__90000410_fn__90000411_fn__90000412_A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_A_New()}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_$iter__90000416__90000420", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_fn_class_BANG__A_class, Simple: "iter__90000416__90000420", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_$iter__90000416__90000420$fn__90000421", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_A_class, Simple: "fn__90000421", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_A]()) }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_fn__90000422_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_fn__90000422_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_fn__90000422_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_fn__90000422_A_New_I_O_O(args[0].(int32), args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_fn__90000422_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_fn__90000422_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_fn__90000422_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_fn__90000422_A_invoke, New: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_fn__90000422_A_new, Get: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_fn__90000422_A_get}

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_fn__90000422_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_fn_class_BANG_$iter__90000416__90000420$fn__90000421$fn__90000422", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_A_class, Simple: "fn__90000422", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_fn__90000422_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_fn__90000422_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_fn__90000422_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_fn__90000422_A_Init; i.Table = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_fn__90000422_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_fn__90000422_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_fn_class_BANG__iter__90000416__90000420_fn__90000421_fn__90000422_A]()) }

func A_arbace_aot_emit_emit_if_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_if_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_emit_if_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_if_A_New()}; return nil }

func A_arbace_aot_emit_emit_if_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_if_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_if_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_if_A_invoke, New: A_arbace_aot_emit_emit_if_A_new, Get: A_arbace_aot_emit_emit_if_A_get}

var A_arbace_aot_emit_emit_if_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_if", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "emit_if", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_if_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_if_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_if_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_if_A_Init; i.Table = A_arbace_aot_emit_emit_if_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_if_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_if_A]()) }

func A_arbace_aot_emit_emit_if_br__90000106_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_if_br__90000106_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_if_br__90000106_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_if_br__90000106_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_if_br__90000106_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_if_br__90000106_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_if_br__90000106_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_if_br__90000106_A_invoke, New: A_arbace_aot_emit_emit_if_br__90000106_A_new, Get: A_arbace_aot_emit_emit_if_br__90000106_A_get}

var A_arbace_aot_emit_emit_if_br__90000106_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_if$br__90000106", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_if_A_class, Simple: "br__90000106", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_if_br__90000106_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_if_br__90000106_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_if_br__90000106_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_if_br__90000106_A_Init; i.Table = A_arbace_aot_emit_emit_if_br__90000106_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_if_br__90000106_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_if_br__90000106_A]()) }

func A_arbace_aot_emit_emit_instance_field_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_instance_field_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_emit_instance_field_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_instance_field_A_New()}; return nil }

func A_arbace_aot_emit_emit_instance_field_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_instance_field_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_instance_field_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_instance_field_A_invoke, New: A_arbace_aot_emit_emit_instance_field_A_new, Get: A_arbace_aot_emit_emit_instance_field_A_get}

var A_arbace_aot_emit_emit_instance_field_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_instance_field", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "emit_instance_field", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_instance_field_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_instance_field_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_instance_field_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_instance_field_A_Init; i.Table = A_arbace_aot_emit_emit_instance_field_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_instance_field_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_instance_field_A]()) }

func A_arbace_aot_emit_emit_instance_method_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_instance_method_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_emit_instance_method_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_instance_method_A_New()}; return nil }

func A_arbace_aot_emit_emit_instance_method_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_instance_method_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_instance_method_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_instance_method_A_invoke, New: A_arbace_aot_emit_emit_instance_method_A_new, Get: A_arbace_aot_emit_emit_instance_method_A_get}

var A_arbace_aot_emit_emit_instance_method_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_instance_method", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "emit_instance_method", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_instance_method_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_instance_method_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_instance_method_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_instance_method_A_Init; i.Table = A_arbace_aot_emit_emit_instance_method_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_instance_method_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_instance_method_A]()) }

func A_arbace_aot_emit_emit_invoke_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_invoke_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_invoke_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_invoke_A_New()}; return nil }

func A_arbace_aot_emit_emit_invoke_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_invoke_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_invoke_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_invoke_A_invoke, New: A_arbace_aot_emit_emit_invoke_A_new, Get: A_arbace_aot_emit_emit_invoke_A_get}

var A_arbace_aot_emit_emit_invoke_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_invoke", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "emit_invoke", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_invoke_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_invoke_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_invoke_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_invoke_A_Init; i.Table = A_arbace_aot_emit_emit_invoke_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_invoke_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_invoke_A]()) }

func A_arbace_aot_emit_emit_invoke_call__90000080_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_invoke_call__90000080_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_invoke_call__90000080_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_invoke_call__90000080_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_invoke_call__90000080_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_invoke_call__90000080_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_invoke_call__90000080_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_invoke_call__90000080_A_invoke, New: A_arbace_aot_emit_emit_invoke_call__90000080_A_new, Get: A_arbace_aot_emit_emit_invoke_call__90000080_A_get}

var A_arbace_aot_emit_emit_invoke_call__90000080_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_invoke$call__90000080", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_invoke_A_class, Simple: "call__90000080", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_invoke_call__90000080_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_invoke_call__90000080_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_invoke_call__90000080_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_invoke_call__90000080_A_Init; i.Table = A_arbace_aot_emit_emit_invoke_call__90000080_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_invoke_call__90000080_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_invoke_call__90000080_A]()) }

func A_arbace_aot_emit_emit_invoke_call__90000080_fn__90000081_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_invoke_call__90000080_fn__90000081_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_invoke_call__90000080_fn__90000081_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_invoke_call__90000080_fn__90000081_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_emit_invoke_call__90000080_fn__90000081_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_invoke_call__90000080_fn__90000081_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_invoke_call__90000080_fn__90000081_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_invoke_call__90000080_fn__90000081_A_invoke, New: A_arbace_aot_emit_emit_invoke_call__90000080_fn__90000081_A_new, Get: A_arbace_aot_emit_emit_invoke_call__90000080_fn__90000081_A_get}

var A_arbace_aot_emit_emit_invoke_call__90000080_fn__90000081_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_invoke$call__90000080$fn__90000081", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_invoke_call__90000080_A_class, Simple: "fn__90000081", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_invoke_call__90000080_fn__90000081_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_invoke_call__90000080_fn__90000081_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_invoke_call__90000080_fn__90000081_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_invoke_call__90000080_fn__90000081_A_Init; i.Table = A_arbace_aot_emit_emit_invoke_call__90000080_fn__90000081_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_invoke_call__90000080_fn__90000081_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_invoke_call__90000080_fn__90000081_A]()) }

func A_arbace_aot_emit_emit_invoke_fn__90000084_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_invoke_fn__90000084_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_invoke_fn__90000084_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_invoke_fn__90000084_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_emit_invoke_fn__90000084_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_invoke_fn__90000084_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_invoke_fn__90000084_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_invoke_fn__90000084_A_invoke, New: A_arbace_aot_emit_emit_invoke_fn__90000084_A_new, Get: A_arbace_aot_emit_emit_invoke_fn__90000084_A_get}

var A_arbace_aot_emit_emit_invoke_fn__90000084_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_invoke$fn__90000084", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_invoke_A_class, Simple: "fn__90000084", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_invoke_fn__90000084_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_invoke_fn__90000084_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_invoke_fn__90000084_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_invoke_fn__90000084_A_Init; i.Table = A_arbace_aot_emit_emit_invoke_fn__90000084_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_invoke_fn__90000084_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_invoke_fn__90000084_A]()) }

func A_arbace_aot_emit_emit_let_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_let_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_emit_let_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_let_A_New()}; return nil }

func A_arbace_aot_emit_emit_let_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_let_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_let_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_let_A_invoke, New: A_arbace_aot_emit_emit_let_A_new, Get: A_arbace_aot_emit_emit_let_A_get}

var A_arbace_aot_emit_emit_let_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_let", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "emit_let", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_let_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_let_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_let_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_let_A_Init; i.Table = A_arbace_aot_emit_emit_let_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_let_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_let_A]()) }

func A_arbace_aot_emit_emit_let_fn__90000111_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_let_fn__90000111_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_let_fn__90000111_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_let_fn__90000111_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_emit_let_fn__90000111_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_let_fn__90000111_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_let_fn__90000111_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_let_fn__90000111_A_invoke, New: A_arbace_aot_emit_emit_let_fn__90000111_A_new, Get: A_arbace_aot_emit_emit_let_fn__90000111_A_get}

var A_arbace_aot_emit_emit_let_fn__90000111_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_let$fn__90000111", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_let_A_class, Simple: "fn__90000111", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_let_fn__90000111_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_let_fn__90000111_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_let_fn__90000111_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_let_fn__90000111_A_Init; i.Table = A_arbace_aot_emit_emit_let_fn__90000111_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_let_fn__90000111_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_let_fn__90000111_A]()) }

func A_arbace_aot_emit_emit_letfn_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_letfn_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_emit_letfn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_letfn_A_New()}; return nil }

func A_arbace_aot_emit_emit_letfn_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_letfn_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_letfn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_letfn_A_invoke, New: A_arbace_aot_emit_emit_letfn_A_new, Get: A_arbace_aot_emit_emit_letfn_A_get}

var A_arbace_aot_emit_emit_letfn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_letfn", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "emit_letfn", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_letfn_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_letfn_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_letfn_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_letfn_A_Init; i.Table = A_arbace_aot_emit_emit_letfn_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_letfn_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_letfn_A]()) }

func A_arbace_aot_emit_emit_letfn_fn__90000132_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_letfn_fn__90000132_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_letfn_fn__90000132_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_letfn_fn__90000132_A_New()}; return nil }

func A_arbace_aot_emit_emit_letfn_fn__90000132_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_letfn_fn__90000132_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_letfn_fn__90000132_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_letfn_fn__90000132_A_invoke, New: A_arbace_aot_emit_emit_letfn_fn__90000132_A_new, Get: A_arbace_aot_emit_emit_letfn_fn__90000132_A_get}

var A_arbace_aot_emit_emit_letfn_fn__90000132_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_letfn$fn__90000132", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_letfn_A_class, Simple: "fn__90000132", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_letfn_fn__90000132_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_letfn_fn__90000132_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_letfn_fn__90000132_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_letfn_fn__90000132_A_Init; i.Table = A_arbace_aot_emit_emit_letfn_fn__90000132_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_letfn_fn__90000132_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_letfn_fn__90000132_A]()) }

func A_arbace_aot_emit_emit_letfn_fn__90000134_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_letfn_fn__90000134_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_letfn_fn__90000134_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_letfn_fn__90000134_A_New()}; return nil }

func A_arbace_aot_emit_emit_letfn_fn__90000134_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_letfn_fn__90000134_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_letfn_fn__90000134_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_letfn_fn__90000134_A_invoke, New: A_arbace_aot_emit_emit_letfn_fn__90000134_A_new, Get: A_arbace_aot_emit_emit_letfn_fn__90000134_A_get}

var A_arbace_aot_emit_emit_letfn_fn__90000134_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_letfn$fn__90000134", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_letfn_A_class, Simple: "fn__90000134", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_letfn_fn__90000134_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_letfn_fn__90000134_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_letfn_fn__90000134_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_letfn_fn__90000134_A_Init; i.Table = A_arbace_aot_emit_emit_letfn_fn__90000134_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_letfn_fn__90000134_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_letfn_fn__90000134_A]()) }

func A_arbace_aot_emit_emit_letfn_fn__90000165_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_letfn_fn__90000165_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_emit_letfn_fn__90000165_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_letfn_fn__90000165_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_emit_letfn_fn__90000165_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_letfn_fn__90000165_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_letfn_fn__90000165_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_letfn_fn__90000165_A_invoke, New: A_arbace_aot_emit_emit_letfn_fn__90000165_A_new, Get: A_arbace_aot_emit_emit_letfn_fn__90000165_A_get}

var A_arbace_aot_emit_emit_letfn_fn__90000165_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_letfn$fn__90000165", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_emit_emit_letfn_A_class, Simple: "fn__90000165", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_letfn_fn__90000165_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_letfn_fn__90000165_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_letfn_fn__90000165_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_letfn_fn__90000165_A_Init; i.Table = A_arbace_aot_emit_emit_letfn_fn__90000165_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_letfn_fn__90000165_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_letfn_fn__90000165_A]()) }

func A_arbace_aot_emit_emit_letfn_fn__90000167_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_letfn_fn__90000167_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_emit_letfn_fn__90000167_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_letfn_fn__90000167_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_emit_letfn_fn__90000167_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_letfn_fn__90000167_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_letfn_fn__90000167_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_letfn_fn__90000167_A_invoke, New: A_arbace_aot_emit_emit_letfn_fn__90000167_A_new, Get: A_arbace_aot_emit_emit_letfn_fn__90000167_A_get}

var A_arbace_aot_emit_emit_letfn_fn__90000167_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_letfn$fn__90000167", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_emit_emit_letfn_A_class, Simple: "fn__90000167", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_letfn_fn__90000167_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_letfn_fn__90000167_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_letfn_fn__90000167_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_letfn_fn__90000167_A_Init; i.Table = A_arbace_aot_emit_emit_letfn_fn__90000167_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_letfn_fn__90000167_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_letfn_fn__90000167_A]()) }

func A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_A_invoke, New: A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_A_new, Get: A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_A_get}

var A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_letfn$iter__90000136__90000140", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_letfn_A_class, Simple: "iter__90000136__90000140", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_A_Init; i.Table = A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_A]()) }

func A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_A_invoke, New: A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_A_new, Get: A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_A_get}

var A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_letfn$iter__90000136__90000140$fn__90000141", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_A_class, Simple: "fn__90000141", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_A_Init; i.Table = A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_A]()) }

func A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_fn__90000142_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_fn__90000142_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_fn__90000142_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_fn__90000142_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_fn__90000142_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_fn__90000142_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_fn__90000142_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_fn__90000142_A_invoke, New: A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_fn__90000142_A_new, Get: A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_fn__90000142_A_get}

var A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_fn__90000142_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_letfn$iter__90000136__90000140$fn__90000141$fn__90000142", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_A_class, Simple: "fn__90000142", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_fn__90000142_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_fn__90000142_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_fn__90000142_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_fn__90000142_A_Init; i.Table = A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_fn__90000142_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_fn__90000142_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_letfn_iter__90000136__90000140_fn__90000141_fn__90000142_A]()) }

func A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_A_invoke, New: A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_A_new, Get: A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_A_get}

var A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_letfn$iter__90000146__90000152", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_letfn_A_class, Simple: "iter__90000146__90000152", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_A_Init; i.Table = A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_A]()) }

func A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_A_invoke, New: A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_A_new, Get: A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_A_get}

var A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_letfn$iter__90000146__90000152$fn__90000153", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_A_class, Simple: "fn__90000153", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_A_Init; i.Table = A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_A]()) }

func A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_A_invoke, New: A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_A_new, Get: A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_A_get}

var A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_letfn$iter__90000146__90000152$fn__90000153$iter__90000148__90000157", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_A_class, Simple: "iter__90000148__90000157", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_A_Init; i.Table = A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_A]()) }

func A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_A_invoke, New: A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_A_new, Get: A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_A_get}

var A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_letfn$iter__90000146__90000152$fn__90000153$iter__90000148__90000157$fn__90000158", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_A_class, Simple: "fn__90000158", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_A_Init; i.Table = A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_A]()) }

func A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_fn__90000159_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_fn__90000159_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_fn__90000159_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_fn__90000159_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_fn__90000159_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_fn__90000159_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_fn__90000159_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_fn__90000159_A_invoke, New: A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_fn__90000159_A_new, Get: A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_fn__90000159_A_get}

var A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_fn__90000159_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_letfn$iter__90000146__90000152$fn__90000153$iter__90000148__90000157$fn__90000158$fn__90000159", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_A_class, Simple: "fn__90000159", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_fn__90000159_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_fn__90000159_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_fn__90000159_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_fn__90000159_A_Init; i.Table = A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_fn__90000159_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_fn__90000159_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_letfn_iter__90000146__90000152_fn__90000153_iter__90000148__90000157_fn__90000158_fn__90000159_A]()) }

func A_arbace_aot_emit_emit_list_array_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_list_array_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_list_array_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_list_array_A_New()}; return nil }

func A_arbace_aot_emit_emit_list_array_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_list_array_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_list_array_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_list_array_A_invoke, New: A_arbace_aot_emit_emit_list_array_A_new, Get: A_arbace_aot_emit_emit_list_array_A_get}

var A_arbace_aot_emit_emit_list_array_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_list_array", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "emit_list_array", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_list_array_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_list_array_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_list_array_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_list_array_A_Init; i.Table = A_arbace_aot_emit_emit_list_array_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_list_array_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_list_array_A]()) }

func A_arbace_aot_emit_emit_list_array_fn__90000036_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_list_array_fn__90000036_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_list_array_fn__90000036_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_list_array_fn__90000036_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_emit_list_array_fn__90000036_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_list_array_fn__90000036_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_list_array_fn__90000036_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_list_array_fn__90000036_A_invoke, New: A_arbace_aot_emit_emit_list_array_fn__90000036_A_new, Get: A_arbace_aot_emit_emit_list_array_fn__90000036_A_get}

var A_arbace_aot_emit_emit_list_array_fn__90000036_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_list_array$fn__90000036", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_list_array_A_class, Simple: "fn__90000036", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_list_array_fn__90000036_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_list_array_fn__90000036_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_list_array_fn__90000036_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_list_array_fn__90000036_A_Init; i.Table = A_arbace_aot_emit_emit_list_array_fn__90000036_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_list_array_fn__90000036_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_list_array_fn__90000036_A]()) }

func A_arbace_aot_emit_emit_local_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_local_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_emit_local_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_local_A_New()}; return nil }

func A_arbace_aot_emit_emit_local_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_local_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_local_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_local_A_invoke, New: A_arbace_aot_emit_emit_local_A_new, Get: A_arbace_aot_emit_emit_local_A_get}

var A_arbace_aot_emit_emit_local_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_local", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "emit_local", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_local_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_local_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_local_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_local_A_Init; i.Table = A_arbace_aot_emit_emit_local_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_local_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_local_A]()) }

func A_arbace_aot_emit_emit_new_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_new_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_new_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_new_A_New()}; return nil }

func A_arbace_aot_emit_emit_new_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_new_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_new_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_new_A_invoke, New: A_arbace_aot_emit_emit_new_A_new, Get: A_arbace_aot_emit_emit_new_A_get}

var A_arbace_aot_emit_emit_new_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_new", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "emit_new", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_new_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_new_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_new_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_new_A_Init; i.Table = A_arbace_aot_emit_emit_new_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_new_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_new_A]()) }

func A_arbace_aot_emit_emit_recur_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_recur_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_recur_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_recur_A_New()}; return nil }

func A_arbace_aot_emit_emit_recur_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_recur_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_recur_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_recur_A_invoke, New: A_arbace_aot_emit_emit_recur_A_new, Get: A_arbace_aot_emit_emit_recur_A_get}

var A_arbace_aot_emit_emit_recur_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_recur", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "emit_recur", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_recur_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_recur_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_recur_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_recur_A_Init; i.Table = A_arbace_aot_emit_emit_recur_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_recur_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_recur_A]()) }

func A_arbace_aot_emit_emit_recur_fn__90000114_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_recur_fn__90000114_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_recur_fn__90000114_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_recur_fn__90000114_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_emit_recur_fn__90000114_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_recur_fn__90000114_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_recur_fn__90000114_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_recur_fn__90000114_A_invoke, New: A_arbace_aot_emit_emit_recur_fn__90000114_A_new, Get: A_arbace_aot_emit_emit_recur_fn__90000114_A_get}

var A_arbace_aot_emit_emit_recur_fn__90000114_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_recur$fn__90000114", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_emit_recur_A_class, Simple: "fn__90000114", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_recur_fn__90000114_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_recur_fn__90000114_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_recur_fn__90000114_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_recur_fn__90000114_A_Init; i.Table = A_arbace_aot_emit_emit_recur_fn__90000114_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_recur_fn__90000114_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_recur_fn__90000114_A]()) }

func A_arbace_aot_emit_emit_source_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_source_A).Invoke_O_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5], args[6])}; return nil }

func A_arbace_aot_emit_emit_source_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_source_A_New()}; return nil }

func A_arbace_aot_emit_emit_source_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_source_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_source_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_source_A_invoke, New: A_arbace_aot_emit_emit_source_A_new, Get: A_arbace_aot_emit_emit_source_A_get}

var A_arbace_aot_emit_emit_source_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_source", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF6_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "emit_source", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_source_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_source_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_source_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_source_A_Init; i.Table = A_arbace_aot_emit_emit_source_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_source_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_source_A]()) }

func A_arbace_aot_emit_emit_source_fn__90000455_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_source_fn__90000455_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_source_fn__90000455_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_source_fn__90000455_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_emit_source_fn__90000455_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_source_fn__90000455_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_source_fn__90000455_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_source_fn__90000455_A_invoke, New: A_arbace_aot_emit_emit_source_fn__90000455_A_new, Get: A_arbace_aot_emit_emit_source_fn__90000455_A_get}

var A_arbace_aot_emit_emit_source_fn__90000455_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_source$fn__90000455", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_emit_source_A_class, Simple: "fn__90000455", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_source_fn__90000455_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_source_fn__90000455_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_source_fn__90000455_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_source_fn__90000455_A_Init; i.Table = A_arbace_aot_emit_emit_source_fn__90000455_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_source_fn__90000455_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_source_fn__90000455_A]()) }

func A_arbace_aot_emit_emit_source_iter__90000460__90000464_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_source_iter__90000460__90000464_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_source_iter__90000460__90000464_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_source_iter__90000460__90000464_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_emit_source_iter__90000460__90000464_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_source_iter__90000460__90000464_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_source_iter__90000460__90000464_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_source_iter__90000460__90000464_A_invoke, New: A_arbace_aot_emit_emit_source_iter__90000460__90000464_A_new, Get: A_arbace_aot_emit_emit_source_iter__90000460__90000464_A_get}

var A_arbace_aot_emit_emit_source_iter__90000460__90000464_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_source$iter__90000460__90000464", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_source_A_class, Simple: "iter__90000460__90000464", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_source_iter__90000460__90000464_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_source_iter__90000460__90000464_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_source_iter__90000460__90000464_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_source_iter__90000460__90000464_A_Init; i.Table = A_arbace_aot_emit_emit_source_iter__90000460__90000464_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_source_iter__90000460__90000464_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_source_iter__90000460__90000464_A]()) }

func A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_A_invoke, New: A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_A_new, Get: A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_A_get}

var A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_source$iter__90000460__90000464$fn__90000465", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_source_iter__90000460__90000464_A_class, Simple: "fn__90000465", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_A_Init; i.Table = A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_A]()) }

func A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_fn__90000466_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_fn__90000466_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_fn__90000466_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_fn__90000466_A_New_O_I_O_O(args[0], args[1].(int32), args[2], args[3])}; return nil }

func A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_fn__90000466_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_fn__90000466_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_fn__90000466_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_fn__90000466_A_invoke, New: A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_fn__90000466_A_new, Get: A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_fn__90000466_A_get}

var A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_fn__90000466_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_source$iter__90000460__90000464$fn__90000465$fn__90000466", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_A_class, Simple: "fn__90000466", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_fn__90000466_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_fn__90000466_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_fn__90000466_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_fn__90000466_A_Init; i.Table = A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_fn__90000466_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_fn__90000466_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_source_iter__90000460__90000464_fn__90000465_fn__90000466_A]()) }

func A_arbace_aot_emit_emit_source_iter__90000476__90000480_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_source_iter__90000476__90000480_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_source_iter__90000476__90000480_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_source_iter__90000476__90000480_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_emit_source_iter__90000476__90000480_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_source_iter__90000476__90000480_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_source_iter__90000476__90000480_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_source_iter__90000476__90000480_A_invoke, New: A_arbace_aot_emit_emit_source_iter__90000476__90000480_A_new, Get: A_arbace_aot_emit_emit_source_iter__90000476__90000480_A_get}

var A_arbace_aot_emit_emit_source_iter__90000476__90000480_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_source$iter__90000476__90000480", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_source_A_class, Simple: "iter__90000476__90000480", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_source_iter__90000476__90000480_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_source_iter__90000476__90000480_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_source_iter__90000476__90000480_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_source_iter__90000476__90000480_A_Init; i.Table = A_arbace_aot_emit_emit_source_iter__90000476__90000480_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_source_iter__90000476__90000480_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_source_iter__90000476__90000480_A]()) }

func A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_A_invoke, New: A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_A_new, Get: A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_A_get}

var A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_source$iter__90000476__90000480$fn__90000481", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_source_iter__90000476__90000480_A_class, Simple: "fn__90000481", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_A_Init; i.Table = A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_A]()) }

func A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_fn__90000482_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_fn__90000482_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_fn__90000482_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_fn__90000482_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_fn__90000482_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_fn__90000482_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_fn__90000482_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_fn__90000482_A_invoke, New: A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_fn__90000482_A_new, Get: A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_fn__90000482_A_get}

var A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_fn__90000482_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_source$iter__90000476__90000480$fn__90000481$fn__90000482", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_A_class, Simple: "fn__90000482", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_fn__90000482_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_fn__90000482_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_fn__90000482_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_fn__90000482_A_Init; i.Table = A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_fn__90000482_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_fn__90000482_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_source_iter__90000476__90000480_fn__90000481_fn__90000482_A]()) }

func A_arbace_aot_emit_emit_static_field_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_static_field_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_emit_static_field_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_static_field_A_New()}; return nil }

func A_arbace_aot_emit_emit_static_field_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_static_field_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_static_field_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_static_field_A_invoke, New: A_arbace_aot_emit_emit_static_field_A_new, Get: A_arbace_aot_emit_emit_static_field_A_get}

var A_arbace_aot_emit_emit_static_field_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_static_field", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "emit_static_field", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_static_field_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_static_field_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_static_field_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_static_field_A_Init; i.Table = A_arbace_aot_emit_emit_static_field_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_static_field_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_static_field_A]()) }

func A_arbace_aot_emit_emit_static_method_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_static_method_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_emit_static_method_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_static_method_A_New()}; return nil }

func A_arbace_aot_emit_emit_static_method_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_static_method_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_static_method_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_static_method_A_invoke, New: A_arbace_aot_emit_emit_static_method_A_new, Get: A_arbace_aot_emit_emit_static_method_A_get}

var A_arbace_aot_emit_emit_static_method_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_static_method", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "emit_static_method", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_static_method_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_static_method_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_static_method_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_static_method_A_Init; i.Table = A_arbace_aot_emit_emit_static_method_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_static_method_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_static_method_A]()) }

func A_arbace_aot_emit_emit_try_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_try_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_emit_try_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_try_A_New()}; return nil }

func A_arbace_aot_emit_emit_try_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_try_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_try_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_try_A_invoke, New: A_arbace_aot_emit_emit_try_A_new, Get: A_arbace_aot_emit_emit_try_A_get}

var A_arbace_aot_emit_emit_try_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_try", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "emit_try", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_try_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_try_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_try_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_try_A_Init; i.Table = A_arbace_aot_emit_emit_try_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_try_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_try_A]()) }

func A_arbace_aot_emit_emit_try_body__90000170_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_try_body__90000170_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_try_body__90000170_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_try_body__90000170_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_try_body__90000170_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_try_body__90000170_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_try_body__90000170_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_try_body__90000170_A_invoke, New: A_arbace_aot_emit_emit_try_body__90000170_A_new, Get: A_arbace_aot_emit_emit_try_body__90000170_A_get}

var A_arbace_aot_emit_emit_try_body__90000170_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_try$body__90000170", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_try_A_class, Simple: "body__90000170", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_try_body__90000170_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_try_body__90000170_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_try_body__90000170_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_try_body__90000170_A_Init; i.Table = A_arbace_aot_emit_emit_try_body__90000170_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_try_body__90000170_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_try_body__90000170_A]()) }

func A_arbace_aot_emit_emit_try_iter__90000172__90000176_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_try_iter__90000172__90000176_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_try_iter__90000172__90000176_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_try_iter__90000172__90000176_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_emit_try_iter__90000172__90000176_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_try_iter__90000172__90000176_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_try_iter__90000172__90000176_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_try_iter__90000172__90000176_A_invoke, New: A_arbace_aot_emit_emit_try_iter__90000172__90000176_A_new, Get: A_arbace_aot_emit_emit_try_iter__90000172__90000176_A_get}

var A_arbace_aot_emit_emit_try_iter__90000172__90000176_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_try$iter__90000172__90000176", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_try_A_class, Simple: "iter__90000172__90000176", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_try_iter__90000172__90000176_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_try_iter__90000172__90000176_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_try_iter__90000172__90000176_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_try_iter__90000172__90000176_A_Init; i.Table = A_arbace_aot_emit_emit_try_iter__90000172__90000176_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_try_iter__90000172__90000176_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_try_iter__90000172__90000176_A]()) }

func A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_A_invoke, New: A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_A_new, Get: A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_A_get}

var A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_try$iter__90000172__90000176$fn__90000177", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_try_iter__90000172__90000176_A_class, Simple: "fn__90000177", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_A_Init; i.Table = A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_A]()) }

func A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_fn__90000178_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_fn__90000178_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_fn__90000178_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_fn__90000178_A_New_O_I_O_O(args[0], args[1].(int32), args[2], args[3])}; return nil }

func A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_fn__90000178_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_fn__90000178_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_fn__90000178_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_fn__90000178_A_invoke, New: A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_fn__90000178_A_new, Get: A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_fn__90000178_A_get}

var A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_fn__90000178_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_try$iter__90000172__90000176$fn__90000177$fn__90000178", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_A_class, Simple: "fn__90000178", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_fn__90000178_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_fn__90000178_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_fn__90000178_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_fn__90000178_A_Init; i.Table = A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_fn__90000178_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_fn__90000178_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_try_iter__90000172__90000176_fn__90000177_fn__90000178_A]()) }

func A_arbace_aot_emit_emit_unboxed_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_unboxed_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_unboxed_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_unboxed_A_New()}; return nil }

func A_arbace_aot_emit_emit_unboxed_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_unboxed_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_unboxed_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_unboxed_A_invoke, New: A_arbace_aot_emit_emit_unboxed_A_new, Get: A_arbace_aot_emit_emit_unboxed_A_get}

var A_arbace_aot_emit_emit_unboxed_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_unboxed", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "emit_unboxed", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_unboxed_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_unboxed_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_unboxed_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_unboxed_A_Init; i.Table = A_arbace_aot_emit_emit_unboxed_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_unboxed_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_unboxed_A]()) }

func A_arbace_aot_emit_emit_unboxed_fn__90000214_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_unboxed_fn__90000214_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_unboxed_fn__90000214_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_unboxed_fn__90000214_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_emit_unboxed_fn__90000214_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_unboxed_fn__90000214_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_unboxed_fn__90000214_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_unboxed_fn__90000214_A_invoke, New: A_arbace_aot_emit_emit_unboxed_fn__90000214_A_new, Get: A_arbace_aot_emit_emit_unboxed_fn__90000214_A_get}

var A_arbace_aot_emit_emit_unboxed_fn__90000214_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_unboxed$fn__90000214", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_unboxed_A_class, Simple: "fn__90000214", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_unboxed_fn__90000214_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_unboxed_fn__90000214_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_unboxed_fn__90000214_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_unboxed_fn__90000214_A_Init; i.Table = A_arbace_aot_emit_emit_unboxed_fn__90000214_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_unboxed_fn__90000214_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_unboxed_fn__90000214_A]()) }

func A_arbace_aot_emit_emit_value_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_value_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_emit_value_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_value_A_New()}; return nil }

func A_arbace_aot_emit_emit_value_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_value_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_value_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_value_A_invoke, New: A_arbace_aot_emit_emit_value_A_new, Get: A_arbace_aot_emit_emit_value_A_get}

var A_arbace_aot_emit_emit_value_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_value", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "emit_value", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_value_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_value_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_value_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_value_A_Init; i.Table = A_arbace_aot_emit_emit_value_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_value_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_value_A]()) }

func A_arbace_aot_emit_emit_value_fn__90000045_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_value_fn__90000045_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_emit_value_fn__90000045_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_value_fn__90000045_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_emit_value_fn__90000045_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_value_fn__90000045_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_value_fn__90000045_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_value_fn__90000045_A_invoke, New: A_arbace_aot_emit_emit_value_fn__90000045_A_new, Get: A_arbace_aot_emit_emit_value_fn__90000045_A_get}

var A_arbace_aot_emit_emit_value_fn__90000045_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_value$fn__90000045", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_emit_value_A_class, Simple: "fn__90000045", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_value_fn__90000045_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_value_fn__90000045_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_value_fn__90000045_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_value_fn__90000045_A_Init; i.Table = A_arbace_aot_emit_emit_value_fn__90000045_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_value_fn__90000045_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_value_fn__90000045_A]()) }

func A_arbace_aot_emit_emit_value_fn__90000047_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_emit_value_fn__90000047_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_emit_value_fn__90000047_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_emit_value_fn__90000047_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_emit_value_fn__90000047_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_emit_value_fn__90000047_A_fn_class)}; return nil }

var A_arbace_aot_emit_emit_value_fn__90000047_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_emit_value_fn__90000047_A_invoke, New: A_arbace_aot_emit_emit_value_fn__90000047_A_new, Get: A_arbace_aot_emit_emit_value_fn__90000047_A_get}

var A_arbace_aot_emit_emit_value_fn__90000047_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$emit_value$fn__90000047", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_emit_value_A_class, Simple: "fn__90000047", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_emit_value_fn__90000047_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_emit_value_fn__90000047_A_class.Info(); i.IsInstance = A_arbace_aot_emit_emit_value_fn__90000047_A_InstanceOf; i.Init = A_arbace_aot_emit_emit_value_fn__90000047_A_Init; i.Table = A_arbace_aot_emit_emit_value_fn__90000047_A_members; jrt.RegisterGoType(A_arbace_aot_emit_emit_value_fn__90000047_A_class, reflect.TypeFor[A_arbace_aot_emit_emit_value_fn__90000047_A]()) }

func A_arbace_aot_emit_eval90000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_eval90000004_A_New()}; return nil }

var A_arbace_aot_emit_eval90000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_aot_emit_eval90000004_A_new}

var A_arbace_aot_emit_eval90000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$eval90000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_aot_emit_A_class, Simple: "eval90000004", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_eval90000004_A"})

func init() { i := A_arbace_aot_emit_eval90000004_A_class.Info(); i.IsInstance = A_arbace_aot_emit_eval90000004_A_InstanceOf; i.Table = A_arbace_aot_emit_eval90000004_A_members; jrt.RegisterGoType(A_arbace_aot_emit_eval90000004_A_class, reflect.TypeFor[A_arbace_aot_emit_eval90000004_A]()) }

func A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A_New()}; return nil }

func A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A_fn_class)}; return nil }

var A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A_invoke, New: A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A_new, Get: A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A_get}

var A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$eval90000004$loading__1927001464__auto____90000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_eval90000004_A_class, Simple: "loading__1927001464__auto____90000005", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A_class.Info(); i.IsInstance = A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A_InstanceOf; i.Init = A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A_Init; i.Table = A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A_members; jrt.RegisterGoType(A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A_class, reflect.TypeFor[A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A]()) }

func A_arbace_aot_emit_eval90000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_eval90000008_A_New()}; return nil }

var A_arbace_aot_emit_eval90000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_aot_emit_eval90000008_A_new}

var A_arbace_aot_emit_eval90000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$eval90000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_aot_emit_A_class, Simple: "eval90000008", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_eval90000008_A"})

func init() { i := A_arbace_aot_emit_eval90000008_A_class.Info(); i.IsInstance = A_arbace_aot_emit_eval90000008_A_InstanceOf; i.Table = A_arbace_aot_emit_eval90000008_A_members; jrt.RegisterGoType(A_arbace_aot_emit_eval90000008_A_class, reflect.TypeFor[A_arbace_aot_emit_eval90000008_A]()) }

func A_arbace_aot_emit_eval90000008_fn__90000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_eval90000008_fn__90000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_eval90000008_fn__90000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_eval90000008_fn__90000009_A_New()}; return nil }

func A_arbace_aot_emit_eval90000008_fn__90000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_eval90000008_fn__90000009_A_fn_class)}; return nil }

var A_arbace_aot_emit_eval90000008_fn__90000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_eval90000008_fn__90000009_A_invoke, New: A_arbace_aot_emit_eval90000008_fn__90000009_A_new, Get: A_arbace_aot_emit_eval90000008_fn__90000009_A_get}

var A_arbace_aot_emit_eval90000008_fn__90000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$eval90000008$fn__90000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_eval90000008_A_class, Simple: "fn__90000009", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_eval90000008_fn__90000009_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_eval90000008_fn__90000009_A_class.Info(); i.IsInstance = A_arbace_aot_emit_eval90000008_fn__90000009_A_InstanceOf; i.Init = A_arbace_aot_emit_eval90000008_fn__90000009_A_Init; i.Table = A_arbace_aot_emit_eval90000008_fn__90000009_A_members; jrt.RegisterGoType(A_arbace_aot_emit_eval90000008_fn__90000009_A_class, reflect.TypeFor[A_arbace_aot_emit_eval90000008_fn__90000009_A]()) }

func A_arbace_aot_emit_fail_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_fail_A).DoInvoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_fail_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_fail_A_New()}; return nil }

func A_arbace_aot_emit_fail_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_fail_A_fn_class)}; return nil }

var A_arbace_aot_emit_fail_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_fail_A_invoke, New: A_arbace_aot_emit_fail_A_new, Get: A_arbace_aot_emit_fail_A_get}

var A_arbace_aot_emit_fail_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$fail", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR1_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "fail", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_fail_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_fail_A_class.Info(); i.IsInstance = A_arbace_aot_emit_fail_A_InstanceOf; i.Init = A_arbace_aot_emit_fail_A_Init; i.Table = A_arbace_aot_emit_fail_A_members; jrt.RegisterGoType(A_arbace_aot_emit_fail_A_class, reflect.TypeFor[A_arbace_aot_emit_fail_A]()) }

func A_arbace_aot_emit_fi_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_fi_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_fi_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_fi_QMARK__A_New()}; return nil }

func A_arbace_aot_emit_fi_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_fi_QMARK__A_fn_class)}; return nil }

var A_arbace_aot_emit_fi_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_fi_QMARK__A_invoke, New: A_arbace_aot_emit_fi_QMARK__A_new, Get: A_arbace_aot_emit_fi_QMARK__A_get}

var A_arbace_aot_emit_fi_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$fi_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "fi_QMARK_", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_fi_QMARK__A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_fi_QMARK__A_class.Info(); i.IsInstance = A_arbace_aot_emit_fi_QMARK__A_InstanceOf; i.Init = A_arbace_aot_emit_fi_QMARK__A_Init; i.Table = A_arbace_aot_emit_fi_QMARK__A_members; jrt.RegisterGoType(A_arbace_aot_emit_fi_QMARK__A_class, reflect.TypeFor[A_arbace_aot_emit_fi_QMARK__A]()) }

func A_arbace_aot_emit_field_mods_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_field_mods_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_field_mods_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_field_mods_A_New()}; return nil }

func A_arbace_aot_emit_field_mods_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_field_mods_A_fn_class)}; return nil }

var A_arbace_aot_emit_field_mods_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_field_mods_A_invoke, New: A_arbace_aot_emit_field_mods_A_new, Get: A_arbace_aot_emit_field_mods_A_get}

var A_arbace_aot_emit_field_mods_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$field_mods", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "field_mods", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_field_mods_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_field_mods_A_class.Info(); i.IsInstance = A_arbace_aot_emit_field_mods_A_InstanceOf; i.Init = A_arbace_aot_emit_field_mods_A_Init; i.Table = A_arbace_aot_emit_field_mods_A_members; jrt.RegisterGoType(A_arbace_aot_emit_field_mods_A_class, reflect.TypeFor[A_arbace_aot_emit_field_mods_A]()) }

func A_arbace_aot_emit_field_ok_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_field_ok_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_field_ok_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_field_ok_QMARK__A_New()}; return nil }

func A_arbace_aot_emit_field_ok_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_field_ok_QMARK__A_fn_class)}; return nil }

var A_arbace_aot_emit_field_ok_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_field_ok_QMARK__A_invoke, New: A_arbace_aot_emit_field_ok_QMARK__A_new, Get: A_arbace_aot_emit_field_ok_QMARK__A_get}

var A_arbace_aot_emit_field_ok_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$field_ok_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "field_ok_QMARK_", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_field_ok_QMARK__A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_field_ok_QMARK__A_class.Info(); i.IsInstance = A_arbace_aot_emit_field_ok_QMARK__A_InstanceOf; i.Init = A_arbace_aot_emit_field_ok_QMARK__A_Init; i.Table = A_arbace_aot_emit_field_ok_QMARK__A_members; jrt.RegisterGoType(A_arbace_aot_emit_field_ok_QMARK__A_class, reflect.TypeFor[A_arbace_aot_emit_field_ok_QMARK__A]()) }

func A_arbace_aot_emit_field_read_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_field_read_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_field_read_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_field_read_A_New()}; return nil }

func A_arbace_aot_emit_field_read_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_field_read_A_fn_class)}; return nil }

var A_arbace_aot_emit_field_read_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_field_read_A_invoke, New: A_arbace_aot_emit_field_read_A_new, Get: A_arbace_aot_emit_field_read_A_get}

var A_arbace_aot_emit_field_read_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$field_read", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "field_read", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_field_read_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_field_read_A_class.Info(); i.IsInstance = A_arbace_aot_emit_field_read_A_InstanceOf; i.Init = A_arbace_aot_emit_field_read_A_Init; i.Table = A_arbace_aot_emit_field_read_A_members; jrt.RegisterGoType(A_arbace_aot_emit_field_read_A_class, reflect.TypeFor[A_arbace_aot_emit_field_read_A]()) }

func A_arbace_aot_emit_field_sym_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_field_sym_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_field_sym_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_field_sym_A_New()}; return nil }

func A_arbace_aot_emit_field_sym_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_field_sym_A_fn_class)}; return nil }

var A_arbace_aot_emit_field_sym_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_field_sym_A_invoke, New: A_arbace_aot_emit_field_sym_A_new, Get: A_arbace_aot_emit_field_sym_A_get}

var A_arbace_aot_emit_field_sym_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$field_sym", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "field_sym", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_field_sym_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_field_sym_A_class.Info(); i.IsInstance = A_arbace_aot_emit_field_sym_A_InstanceOf; i.Init = A_arbace_aot_emit_field_sym_A_Init; i.Table = A_arbace_aot_emit_field_sym_A_members; jrt.RegisterGoType(A_arbace_aot_emit_field_sym_A_class, reflect.TypeFor[A_arbace_aot_emit_field_sym_A]()) }

func A_arbace_aot_emit_fn__90000088_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_fn__90000088_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_fn__90000088_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_fn__90000088_A_New()}; return nil }

func A_arbace_aot_emit_fn__90000088_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_fn__90000088_A_fn_class)}; return nil }

var A_arbace_aot_emit_fn__90000088_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_fn__90000088_A_invoke, New: A_arbace_aot_emit_fn__90000088_A_new, Get: A_arbace_aot_emit_fn__90000088_A_get}

var A_arbace_aot_emit_fn__90000088_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$fn__90000088", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "fn__90000088", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_fn__90000088_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_fn__90000088_A_class.Info(); i.IsInstance = A_arbace_aot_emit_fn__90000088_A_InstanceOf; i.Init = A_arbace_aot_emit_fn__90000088_A_Init; i.Table = A_arbace_aot_emit_fn__90000088_A_members; jrt.RegisterGoType(A_arbace_aot_emit_fn__90000088_A_class, reflect.TypeFor[A_arbace_aot_emit_fn__90000088_A]()) }

func A_arbace_aot_emit_fn_instance_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_fn_instance_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_fn_instance_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_fn_instance_A_New()}; return nil }

func A_arbace_aot_emit_fn_instance_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_fn_instance_A_fn_class)}; return nil }

var A_arbace_aot_emit_fn_instance_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_fn_instance_A_invoke, New: A_arbace_aot_emit_fn_instance_A_new, Get: A_arbace_aot_emit_fn_instance_A_get}

var A_arbace_aot_emit_fn_instance_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$fn_instance", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "fn_instance", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_fn_instance_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_fn_instance_A_class.Info(); i.IsInstance = A_arbace_aot_emit_fn_instance_A_InstanceOf; i.Init = A_arbace_aot_emit_fn_instance_A_Init; i.Table = A_arbace_aot_emit_fn_instance_A_members; jrt.RegisterGoType(A_arbace_aot_emit_fn_instance_A_class, reflect.TypeFor[A_arbace_aot_emit_fn_instance_A]()) }

func A_arbace_aot_emit_fn_wrap_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_fn_wrap_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_fn_wrap_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_fn_wrap_A_New()}; return nil }

func A_arbace_aot_emit_fn_wrap_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_fn_wrap_A_fn_class)}; return nil }

var A_arbace_aot_emit_fn_wrap_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_fn_wrap_A_invoke, New: A_arbace_aot_emit_fn_wrap_A_new, Get: A_arbace_aot_emit_fn_wrap_A_get}

var A_arbace_aot_emit_fn_wrap_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$fn_wrap", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "fn_wrap", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_fn_wrap_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_fn_wrap_A_class.Info(); i.IsInstance = A_arbace_aot_emit_fn_wrap_A_InstanceOf; i.Init = A_arbace_aot_emit_fn_wrap_A_Init; i.Table = A_arbace_aot_emit_fn_wrap_A_members; jrt.RegisterGoType(A_arbace_aot_emit_fn_wrap_A_class, reflect.TypeFor[A_arbace_aot_emit_fn_wrap_A]()) }

func A_arbace_aot_emit_gsym_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_gsym_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_gsym_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_gsym_A_New()}; return nil }

func A_arbace_aot_emit_gsym_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_gsym_A_fn_class)}; return nil }

var A_arbace_aot_emit_gsym_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_gsym_A_invoke, New: A_arbace_aot_emit_gsym_A_new, Get: A_arbace_aot_emit_gsym_A_get}

var A_arbace_aot_emit_gsym_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$gsym", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "gsym", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_gsym_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_gsym_A_class.Info(); i.IsInstance = A_arbace_aot_emit_gsym_A_InstanceOf; i.Init = A_arbace_aot_emit_gsym_A_Init; i.Table = A_arbace_aot_emit_gsym_A_members; jrt.RegisterGoType(A_arbace_aot_emit_gsym_A_class, reflect.TypeFor[A_arbace_aot_emit_gsym_A]()) }

func A_arbace_aot_emit_identity_set_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_identity_set_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_identity_set_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_identity_set_A_New()}; return nil }

func A_arbace_aot_emit_identity_set_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_identity_set_A_fn_class)}; return nil }

var A_arbace_aot_emit_identity_set_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_identity_set_A_invoke, New: A_arbace_aot_emit_identity_set_A_new, Get: A_arbace_aot_emit_identity_set_A_get}

var A_arbace_aot_emit_identity_set_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$identity_set", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "identity_set", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_identity_set_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_identity_set_A_class.Info(); i.IsInstance = A_arbace_aot_emit_identity_set_A_InstanceOf; i.Init = A_arbace_aot_emit_identity_set_A_Init; i.Table = A_arbace_aot_emit_identity_set_A_members; jrt.RegisterGoType(A_arbace_aot_emit_identity_set_A_class, reflect.TypeFor[A_arbace_aot_emit_identity_set_A]()) }

func A_arbace_aot_emit_interface_record_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_interface_record_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_interface_record_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_interface_record_A_New()}; return nil }

func A_arbace_aot_emit_interface_record_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_interface_record_A_fn_class)}; return nil }

var A_arbace_aot_emit_interface_record_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_interface_record_A_invoke, New: A_arbace_aot_emit_interface_record_A_new, Get: A_arbace_aot_emit_interface_record_A_get}

var A_arbace_aot_emit_interface_record_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$interface_record", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "interface_record", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_interface_record_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_interface_record_A_class.Info(); i.IsInstance = A_arbace_aot_emit_interface_record_A_InstanceOf; i.Init = A_arbace_aot_emit_interface_record_A_Init; i.Table = A_arbace_aot_emit_interface_record_A_members; jrt.RegisterGoType(A_arbace_aot_emit_interface_record_A_class, reflect.TypeFor[A_arbace_aot_emit_interface_record_A]()) }

func A_arbace_aot_emit_interface_record_fn__90000541_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_interface_record_fn__90000541_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_interface_record_fn__90000541_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_interface_record_fn__90000541_A_New()}; return nil }

func A_arbace_aot_emit_interface_record_fn__90000541_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_interface_record_fn__90000541_A_fn_class)}; return nil }

var A_arbace_aot_emit_interface_record_fn__90000541_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_interface_record_fn__90000541_A_invoke, New: A_arbace_aot_emit_interface_record_fn__90000541_A_new, Get: A_arbace_aot_emit_interface_record_fn__90000541_A_get}

var A_arbace_aot_emit_interface_record_fn__90000541_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$interface_record$fn__90000541", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_interface_record_A_class, Simple: "fn__90000541", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_interface_record_fn__90000541_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_interface_record_fn__90000541_A_class.Info(); i.IsInstance = A_arbace_aot_emit_interface_record_fn__90000541_A_InstanceOf; i.Init = A_arbace_aot_emit_interface_record_fn__90000541_A_Init; i.Table = A_arbace_aot_emit_interface_record_fn__90000541_A_members; jrt.RegisterGoType(A_arbace_aot_emit_interface_record_fn__90000541_A_class, reflect.TypeFor[A_arbace_aot_emit_interface_record_fn__90000541_A]()) }

func A_arbace_aot_emit_interface_record_iter__90000543__90000547_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_interface_record_iter__90000543__90000547_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_interface_record_iter__90000543__90000547_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_interface_record_iter__90000543__90000547_A_New()}; return nil }

func A_arbace_aot_emit_interface_record_iter__90000543__90000547_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_interface_record_iter__90000543__90000547_A_fn_class)}; return nil }

var A_arbace_aot_emit_interface_record_iter__90000543__90000547_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_interface_record_iter__90000543__90000547_A_invoke, New: A_arbace_aot_emit_interface_record_iter__90000543__90000547_A_new, Get: A_arbace_aot_emit_interface_record_iter__90000543__90000547_A_get}

var A_arbace_aot_emit_interface_record_iter__90000543__90000547_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$interface_record$iter__90000543__90000547", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_interface_record_A_class, Simple: "iter__90000543__90000547", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_interface_record_iter__90000543__90000547_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_interface_record_iter__90000543__90000547_A_class.Info(); i.IsInstance = A_arbace_aot_emit_interface_record_iter__90000543__90000547_A_InstanceOf; i.Init = A_arbace_aot_emit_interface_record_iter__90000543__90000547_A_Init; i.Table = A_arbace_aot_emit_interface_record_iter__90000543__90000547_A_members; jrt.RegisterGoType(A_arbace_aot_emit_interface_record_iter__90000543__90000547_A_class, reflect.TypeFor[A_arbace_aot_emit_interface_record_iter__90000543__90000547_A]()) }

func A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_A_fn_class)}; return nil }

var A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_A_invoke, New: A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_A_new, Get: A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_A_get}

var A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$interface_record$iter__90000543__90000547$fn__90000548", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_interface_record_iter__90000543__90000547_A_class, Simple: "fn__90000548", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_A_class.Info(); i.IsInstance = A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_A_InstanceOf; i.Init = A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_A_Init; i.Table = A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_A_members; jrt.RegisterGoType(A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_A_class, reflect.TypeFor[A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_A]()) }

func A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_A_fn_class)}; return nil }

var A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_A_invoke, New: A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_A_new, Get: A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_A_get}

var A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$interface_record$iter__90000543__90000547$fn__90000548$fn__90000549", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_A_class, Simple: "fn__90000549", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_A_class.Info(); i.IsInstance = A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_A_InstanceOf; i.Init = A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_A_Init; i.Table = A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_A_members; jrt.RegisterGoType(A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_A_class, reflect.TypeFor[A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_A]()) }

func A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_fn__90000553_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_fn__90000553_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_fn__90000553_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_fn__90000553_A_New()}; return nil }

func A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_fn__90000553_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_fn__90000553_A_fn_class)}; return nil }

var A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_fn__90000553_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_fn__90000553_A_invoke, New: A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_fn__90000553_A_new, Get: A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_fn__90000553_A_get}

var A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_fn__90000553_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$interface_record$iter__90000543__90000547$fn__90000548$fn__90000549$fn__90000553", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_A_class, Simple: "fn__90000553", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_fn__90000553_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_fn__90000553_A_class.Info(); i.IsInstance = A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_fn__90000553_A_InstanceOf; i.Init = A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_fn__90000553_A_Init; i.Table = A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_fn__90000553_A_members; jrt.RegisterGoType(A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_fn__90000553_A_class, reflect.TypeFor[A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000549_fn__90000553_A]()) }

func A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000559_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000559_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000559_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000559_A_New()}; return nil }

func A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000559_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000559_A_fn_class)}; return nil }

var A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000559_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000559_A_invoke, New: A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000559_A_new, Get: A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000559_A_get}

var A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000559_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$interface_record$iter__90000543__90000547$fn__90000548$fn__90000559", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_A_class, Simple: "fn__90000559", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000559_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000559_A_class.Info(); i.IsInstance = A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000559_A_InstanceOf; i.Init = A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000559_A_Init; i.Table = A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000559_A_members; jrt.RegisterGoType(A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000559_A_class, reflect.TypeFor[A_arbace_aot_emit_interface_record_iter__90000543__90000547_fn__90000548_fn__90000559_A]()) }

func A_arbace_aot_emit_jrt_lacks_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_jrt_lacks_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_jrt_lacks_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_jrt_lacks_QMARK__A_New()}; return nil }

func A_arbace_aot_emit_jrt_lacks_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_jrt_lacks_QMARK__A_fn_class)}; return nil }

var A_arbace_aot_emit_jrt_lacks_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_jrt_lacks_QMARK__A_invoke, New: A_arbace_aot_emit_jrt_lacks_QMARK__A_new, Get: A_arbace_aot_emit_jrt_lacks_QMARK__A_get}

var A_arbace_aot_emit_jrt_lacks_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$jrt_lacks_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "jrt_lacks_QMARK_", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_jrt_lacks_QMARK__A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_jrt_lacks_QMARK__A_class.Info(); i.IsInstance = A_arbace_aot_emit_jrt_lacks_QMARK__A_InstanceOf; i.Init = A_arbace_aot_emit_jrt_lacks_QMARK__A_Init; i.Table = A_arbace_aot_emit_jrt_lacks_QMARK__A_members; jrt.RegisterGoType(A_arbace_aot_emit_jrt_lacks_QMARK__A_class, reflect.TypeFor[A_arbace_aot_emit_jrt_lacks_QMARK__A]()) }

func A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000091_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000091_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000091_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000091_A_New()}; return nil }

func A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000091_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000091_A_fn_class)}; return nil }

var A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000091_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000091_A_invoke, New: A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000091_A_new, Get: A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000091_A_get}

var A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000091_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$jrt_lacks_QMARK_$fn__90000091", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_jrt_lacks_QMARK__A_class, Simple: "fn__90000091", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000091_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000091_A_class.Info(); i.IsInstance = A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000091_A_InstanceOf; i.Init = A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000091_A_Init; i.Table = A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000091_A_members; jrt.RegisterGoType(A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000091_A_class, reflect.TypeFor[A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000091_A]()) }

func A_arbace_aot_emit_line_meta_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_line_meta_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_line_meta_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_line_meta_A_New()}; return nil }

func A_arbace_aot_emit_line_meta_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_line_meta_A_fn_class)}; return nil }

var A_arbace_aot_emit_line_meta_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_line_meta_A_invoke, New: A_arbace_aot_emit_line_meta_A_new, Get: A_arbace_aot_emit_line_meta_A_get}

var A_arbace_aot_emit_line_meta_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$line_meta", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "line_meta", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_line_meta_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_line_meta_A_class.Info(); i.IsInstance = A_arbace_aot_emit_line_meta_A_InstanceOf; i.Init = A_arbace_aot_emit_line_meta_A_Init; i.Table = A_arbace_aot_emit_line_meta_A_members; jrt.RegisterGoType(A_arbace_aot_emit_line_meta_A_class, reflect.TypeFor[A_arbace_aot_emit_line_meta_A]()) }

func A_arbace_aot_emit_local_sym_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_local_sym_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_local_sym_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_local_sym_A_New()}; return nil }

func A_arbace_aot_emit_local_sym_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_local_sym_A_fn_class)}; return nil }

var A_arbace_aot_emit_local_sym_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_local_sym_A_invoke, New: A_arbace_aot_emit_local_sym_A_new, Get: A_arbace_aot_emit_local_sym_A_get}

var A_arbace_aot_emit_local_sym_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$local_sym", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "local_sym", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_local_sym_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_local_sym_A_class.Info(); i.IsInstance = A_arbace_aot_emit_local_sym_A_InstanceOf; i.Init = A_arbace_aot_emit_local_sym_A_Init; i.Table = A_arbace_aot_emit_local_sym_A_members; jrt.RegisterGoType(A_arbace_aot_emit_local_sym_A_class, reflect.TypeFor[A_arbace_aot_emit_local_sym_A]()) }

func A_arbace_aot_emit_method_body_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_method_body_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_method_body_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_method_body_A_New()}; return nil }

func A_arbace_aot_emit_method_body_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_method_body_A_fn_class)}; return nil }

var A_arbace_aot_emit_method_body_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_method_body_A_invoke, New: A_arbace_aot_emit_method_body_A_new, Get: A_arbace_aot_emit_method_body_A_get}

var A_arbace_aot_emit_method_body_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$method_body", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "method_body", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_method_body_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_method_body_A_class.Info(); i.IsInstance = A_arbace_aot_emit_method_body_A_InstanceOf; i.Init = A_arbace_aot_emit_method_body_A_Init; i.Table = A_arbace_aot_emit_method_body_A_members; jrt.RegisterGoType(A_arbace_aot_emit_method_body_A_class, reflect.TypeFor[A_arbace_aot_emit_method_body_A]()) }

func A_arbace_aot_emit_method_body_fn__90000232_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_method_body_fn__90000232_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_method_body_fn__90000232_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_method_body_fn__90000232_A_New()}; return nil }

func A_arbace_aot_emit_method_body_fn__90000232_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_method_body_fn__90000232_A_fn_class)}; return nil }

var A_arbace_aot_emit_method_body_fn__90000232_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_method_body_fn__90000232_A_invoke, New: A_arbace_aot_emit_method_body_fn__90000232_A_new, Get: A_arbace_aot_emit_method_body_fn__90000232_A_get}

var A_arbace_aot_emit_method_body_fn__90000232_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$method_body$fn__90000232", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_method_body_A_class, Simple: "fn__90000232", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_method_body_fn__90000232_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_method_body_fn__90000232_A_class.Info(); i.IsInstance = A_arbace_aot_emit_method_body_fn__90000232_A_InstanceOf; i.Init = A_arbace_aot_emit_method_body_fn__90000232_A_Init; i.Table = A_arbace_aot_emit_method_body_fn__90000232_A_members; jrt.RegisterGoType(A_arbace_aot_emit_method_body_fn__90000232_A_class, reflect.TypeFor[A_arbace_aot_emit_method_body_fn__90000232_A]()) }

func A_arbace_aot_emit_method_body_fn__90000234_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_method_body_fn__90000234_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_method_body_fn__90000234_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_method_body_fn__90000234_A_New()}; return nil }

func A_arbace_aot_emit_method_body_fn__90000234_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_method_body_fn__90000234_A_fn_class)}; return nil }

var A_arbace_aot_emit_method_body_fn__90000234_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_method_body_fn__90000234_A_invoke, New: A_arbace_aot_emit_method_body_fn__90000234_A_new, Get: A_arbace_aot_emit_method_body_fn__90000234_A_get}

var A_arbace_aot_emit_method_body_fn__90000234_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$method_body$fn__90000234", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_method_body_A_class, Simple: "fn__90000234", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_method_body_fn__90000234_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_method_body_fn__90000234_A_class.Info(); i.IsInstance = A_arbace_aot_emit_method_body_fn__90000234_A_InstanceOf; i.Init = A_arbace_aot_emit_method_body_fn__90000234_A_Init; i.Table = A_arbace_aot_emit_method_body_fn__90000234_A_members; jrt.RegisterGoType(A_arbace_aot_emit_method_body_fn__90000234_A_class, reflect.TypeFor[A_arbace_aot_emit_method_body_fn__90000234_A]()) }

func A_arbace_aot_emit_method_body_iter__90000222__90000226_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_method_body_iter__90000222__90000226_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_method_body_iter__90000222__90000226_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_method_body_iter__90000222__90000226_A_New()}; return nil }

func A_arbace_aot_emit_method_body_iter__90000222__90000226_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_method_body_iter__90000222__90000226_A_fn_class)}; return nil }

var A_arbace_aot_emit_method_body_iter__90000222__90000226_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_method_body_iter__90000222__90000226_A_invoke, New: A_arbace_aot_emit_method_body_iter__90000222__90000226_A_new, Get: A_arbace_aot_emit_method_body_iter__90000222__90000226_A_get}

var A_arbace_aot_emit_method_body_iter__90000222__90000226_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$method_body$iter__90000222__90000226", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_method_body_A_class, Simple: "iter__90000222__90000226", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_method_body_iter__90000222__90000226_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_method_body_iter__90000222__90000226_A_class.Info(); i.IsInstance = A_arbace_aot_emit_method_body_iter__90000222__90000226_A_InstanceOf; i.Init = A_arbace_aot_emit_method_body_iter__90000222__90000226_A_Init; i.Table = A_arbace_aot_emit_method_body_iter__90000222__90000226_A_members; jrt.RegisterGoType(A_arbace_aot_emit_method_body_iter__90000222__90000226_A_class, reflect.TypeFor[A_arbace_aot_emit_method_body_iter__90000222__90000226_A]()) }

func A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_A_fn_class)}; return nil }

var A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_A_invoke, New: A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_A_new, Get: A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_A_get}

var A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$method_body$iter__90000222__90000226$fn__90000227", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_method_body_iter__90000222__90000226_A_class, Simple: "fn__90000227", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_A_class.Info(); i.IsInstance = A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_A_InstanceOf; i.Init = A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_A_Init; i.Table = A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_A_members; jrt.RegisterGoType(A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_A_class, reflect.TypeFor[A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_A]()) }

func A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_fn__90000228_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_fn__90000228_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_fn__90000228_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_fn__90000228_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_fn__90000228_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_fn__90000228_A_fn_class)}; return nil }

var A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_fn__90000228_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_fn__90000228_A_invoke, New: A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_fn__90000228_A_new, Get: A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_fn__90000228_A_get}

var A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_fn__90000228_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$method_body$iter__90000222__90000226$fn__90000227$fn__90000228", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_A_class, Simple: "fn__90000228", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_fn__90000228_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_fn__90000228_A_class.Info(); i.IsInstance = A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_fn__90000228_A_InstanceOf; i.Init = A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_fn__90000228_A_Init; i.Table = A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_fn__90000228_A_members; jrt.RegisterGoType(A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_fn__90000228_A_class, reflect.TypeFor[A_arbace_aot_emit_method_body_iter__90000222__90000226_fn__90000227_fn__90000228_A]()) }

func A_arbace_aot_emit_method_call_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_method_call_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_aot_emit_method_call_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_method_call_A_New()}; return nil }

func A_arbace_aot_emit_method_call_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_method_call_A_fn_class)}; return nil }

var A_arbace_aot_emit_method_call_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_method_call_A_invoke, New: A_arbace_aot_emit_method_call_A_new, Get: A_arbace_aot_emit_method_call_A_get}

var A_arbace_aot_emit_method_call_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$method_call", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "method_call", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_method_call_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_method_call_A_class.Info(); i.IsInstance = A_arbace_aot_emit_method_call_A_InstanceOf; i.Init = A_arbace_aot_emit_method_call_A_Init; i.Table = A_arbace_aot_emit_method_call_A_members; jrt.RegisterGoType(A_arbace_aot_emit_method_call_A_class, reflect.TypeFor[A_arbace_aot_emit_method_call_A]()) }

func A_arbace_aot_emit_node_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_node_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_node_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_node_A_New()}; return nil }

func A_arbace_aot_emit_node_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_node_A_fn_class)}; return nil }

var A_arbace_aot_emit_node_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_node_A_invoke, New: A_arbace_aot_emit_node_A_new, Get: A_arbace_aot_emit_node_A_get}

var A_arbace_aot_emit_node_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$node", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "node", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_node_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_node_A_class.Info(); i.IsInstance = A_arbace_aot_emit_node_A_InstanceOf; i.Init = A_arbace_aot_emit_node_A_Init; i.Table = A_arbace_aot_emit_node_A_members; jrt.RegisterGoType(A_arbace_aot_emit_node_A_class, reflect.TypeFor[A_arbace_aot_emit_node_A]()) }

func A_arbace_aot_emit_obj_array_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_obj_array_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_obj_array_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_obj_array_A_New()}; return nil }

func A_arbace_aot_emit_obj_array_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_obj_array_A_fn_class)}; return nil }

var A_arbace_aot_emit_obj_array_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_obj_array_A_invoke, New: A_arbace_aot_emit_obj_array_A_new, Get: A_arbace_aot_emit_obj_array_A_get}

var A_arbace_aot_emit_obj_array_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$obj_array", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "obj_array", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_obj_array_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_obj_array_A_class.Info(); i.IsInstance = A_arbace_aot_emit_obj_array_A_InstanceOf; i.Init = A_arbace_aot_emit_obj_array_A_Init; i.Table = A_arbace_aot_emit_obj_array_A_members; jrt.RegisterGoType(A_arbace_aot_emit_obj_array_A_class, reflect.TypeFor[A_arbace_aot_emit_obj_array_A]()) }

func A_arbace_aot_emit_obj_array_fn__90000072_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_obj_array_fn__90000072_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_obj_array_fn__90000072_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_obj_array_fn__90000072_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_obj_array_fn__90000072_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_obj_array_fn__90000072_A_fn_class)}; return nil }

var A_arbace_aot_emit_obj_array_fn__90000072_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_obj_array_fn__90000072_A_invoke, New: A_arbace_aot_emit_obj_array_fn__90000072_A_new, Get: A_arbace_aot_emit_obj_array_fn__90000072_A_get}

var A_arbace_aot_emit_obj_array_fn__90000072_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$obj_array$fn__90000072", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_obj_array_A_class, Simple: "fn__90000072", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_obj_array_fn__90000072_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_obj_array_fn__90000072_A_class.Info(); i.IsInstance = A_arbace_aot_emit_obj_array_fn__90000072_A_InstanceOf; i.Init = A_arbace_aot_emit_obj_array_fn__90000072_A_Init; i.Table = A_arbace_aot_emit_obj_array_fn__90000072_A_members; jrt.RegisterGoType(A_arbace_aot_emit_obj_array_fn__90000072_A_class, reflect.TypeFor[A_arbace_aot_emit_obj_array_fn__90000072_A]()) }

func A_arbace_aot_emit_param_sym_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_param_sym_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_param_sym_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_param_sym_A_New()}; return nil }

func A_arbace_aot_emit_param_sym_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_param_sym_A_fn_class)}; return nil }

var A_arbace_aot_emit_param_sym_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_param_sym_A_invoke, New: A_arbace_aot_emit_param_sym_A_new, Get: A_arbace_aot_emit_param_sym_A_get}

var A_arbace_aot_emit_param_sym_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$param_sym", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "param_sym", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_param_sym_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_param_sym_A_class.Info(); i.IsInstance = A_arbace_aot_emit_param_sym_A_InstanceOf; i.Init = A_arbace_aot_emit_param_sym_A_Init; i.Table = A_arbace_aot_emit_param_sym_A_members; jrt.RegisterGoType(A_arbace_aot_emit_param_sym_A_class, reflect.TypeFor[A_arbace_aot_emit_param_sym_A]()) }

func A_arbace_aot_emit_param_tags_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_param_tags_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_param_tags_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_param_tags_A_New()}; return nil }

func A_arbace_aot_emit_param_tags_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_param_tags_A_fn_class)}; return nil }

var A_arbace_aot_emit_param_tags_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_param_tags_A_invoke, New: A_arbace_aot_emit_param_tags_A_new, Get: A_arbace_aot_emit_param_tags_A_get}

var A_arbace_aot_emit_param_tags_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$param_tags", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "param_tags", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_param_tags_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_param_tags_A_class.Info(); i.IsInstance = A_arbace_aot_emit_param_tags_A_InstanceOf; i.Init = A_arbace_aot_emit_param_tags_A_Init; i.Table = A_arbace_aot_emit_param_tags_A_members; jrt.RegisterGoType(A_arbace_aot_emit_param_tags_A_class, reflect.TypeFor[A_arbace_aot_emit_param_tags_A]()) }

func A_arbace_aot_emit_pool_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_pool_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_pool_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_pool_A_New()}; return nil }

func A_arbace_aot_emit_pool_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_pool_A_fn_class)}; return nil }

var A_arbace_aot_emit_pool_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_pool_A_invoke, New: A_arbace_aot_emit_pool_A_new, Get: A_arbace_aot_emit_pool_A_get}

var A_arbace_aot_emit_pool_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$pool", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "pool", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_pool_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_pool_A_class.Info(); i.IsInstance = A_arbace_aot_emit_pool_A_InstanceOf; i.Init = A_arbace_aot_emit_pool_A_Init; i.Table = A_arbace_aot_emit_pool_A_members; jrt.RegisterGoType(A_arbace_aot_emit_pool_A_class, reflect.TypeFor[A_arbace_aot_emit_pool_A]()) }

func A_arbace_aot_emit_pool_fn__90000031_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_pool_fn__90000031_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_pool_fn__90000031_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_pool_fn__90000031_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_pool_fn__90000031_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_pool_fn__90000031_A_fn_class)}; return nil }

var A_arbace_aot_emit_pool_fn__90000031_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_pool_fn__90000031_A_invoke, New: A_arbace_aot_emit_pool_fn__90000031_A_new, Get: A_arbace_aot_emit_pool_fn__90000031_A_get}

var A_arbace_aot_emit_pool_fn__90000031_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$pool$fn__90000031", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_pool_A_class, Simple: "fn__90000031", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_pool_fn__90000031_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_pool_fn__90000031_A_class.Info(); i.IsInstance = A_arbace_aot_emit_pool_fn__90000031_A_InstanceOf; i.Init = A_arbace_aot_emit_pool_fn__90000031_A_Init; i.Table = A_arbace_aot_emit_pool_fn__90000031_A_members; jrt.RegisterGoType(A_arbace_aot_emit_pool_fn__90000031_A_class, reflect.TypeFor[A_arbace_aot_emit_pool_fn__90000031_A]()) }

func A_arbace_aot_emit_prim_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_prim_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_prim_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_prim_A_New()}; return nil }

func A_arbace_aot_emit_prim_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_prim_A_fn_class)}; return nil }

var A_arbace_aot_emit_prim_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_prim_A_invoke, New: A_arbace_aot_emit_prim_A_new, Get: A_arbace_aot_emit_prim_A_get}

var A_arbace_aot_emit_prim_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$prim", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "prim", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_prim_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_prim_A_class.Info(); i.IsInstance = A_arbace_aot_emit_prim_A_InstanceOf; i.Init = A_arbace_aot_emit_prim_A_Init; i.Table = A_arbace_aot_emit_prim_A_members; jrt.RegisterGoType(A_arbace_aot_emit_prim_A_class, reflect.TypeFor[A_arbace_aot_emit_prim_A]()) }

func A_arbace_aot_emit_public_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_public_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_public_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_public_QMARK__A_New()}; return nil }

func A_arbace_aot_emit_public_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_public_QMARK__A_fn_class)}; return nil }

var A_arbace_aot_emit_public_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_public_QMARK__A_invoke, New: A_arbace_aot_emit_public_QMARK__A_new, Get: A_arbace_aot_emit_public_QMARK__A_get}

var A_arbace_aot_emit_public_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$public_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "public_QMARK_", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_public_QMARK__A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_public_QMARK__A_class.Info(); i.IsInstance = A_arbace_aot_emit_public_QMARK__A_InstanceOf; i.Init = A_arbace_aot_emit_public_QMARK__A_Init; i.Table = A_arbace_aot_emit_public_QMARK__A_members; jrt.RegisterGoType(A_arbace_aot_emit_public_QMARK__A_class, reflect.TypeFor[A_arbace_aot_emit_public_QMARK__A]()) }

func A_arbace_aot_emit_registered_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_registered_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_registered_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_registered_QMARK__A_New()}; return nil }

func A_arbace_aot_emit_registered_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_registered_QMARK__A_fn_class)}; return nil }

var A_arbace_aot_emit_registered_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_registered_QMARK__A_invoke, New: A_arbace_aot_emit_registered_QMARK__A_new, Get: A_arbace_aot_emit_registered_QMARK__A_get}

var A_arbace_aot_emit_registered_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$registered_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "registered_QMARK_", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_registered_QMARK__A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_registered_QMARK__A_class.Info(); i.IsInstance = A_arbace_aot_emit_registered_QMARK__A_InstanceOf; i.Init = A_arbace_aot_emit_registered_QMARK__A_Init; i.Table = A_arbace_aot_emit_registered_QMARK__A_members; jrt.RegisterGoType(A_arbace_aot_emit_registered_QMARK__A_class, reflect.TypeFor[A_arbace_aot_emit_registered_QMARK__A]()) }

func A_arbace_aot_emit_registered_QMARK__fn__90000021_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_registered_QMARK__fn__90000021_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_registered_QMARK__fn__90000021_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_registered_QMARK__fn__90000021_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_registered_QMARK__fn__90000021_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_registered_QMARK__fn__90000021_A_fn_class)}; return nil }

var A_arbace_aot_emit_registered_QMARK__fn__90000021_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_registered_QMARK__fn__90000021_A_invoke, New: A_arbace_aot_emit_registered_QMARK__fn__90000021_A_new, Get: A_arbace_aot_emit_registered_QMARK__fn__90000021_A_get}

var A_arbace_aot_emit_registered_QMARK__fn__90000021_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$registered_QMARK_$fn__90000021", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_registered_QMARK__A_class, Simple: "fn__90000021", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_registered_QMARK__fn__90000021_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_registered_QMARK__fn__90000021_A_class.Info(); i.IsInstance = A_arbace_aot_emit_registered_QMARK__fn__90000021_A_InstanceOf; i.Init = A_arbace_aot_emit_registered_QMARK__fn__90000021_A_Init; i.Table = A_arbace_aot_emit_registered_QMARK__fn__90000021_A_members; jrt.RegisterGoType(A_arbace_aot_emit_registered_QMARK__fn__90000021_A_class, reflect.TypeFor[A_arbace_aot_emit_registered_QMARK__fn__90000021_A]()) }

func A_arbace_aot_emit_registered_QMARK__fn__90000023_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_registered_QMARK__fn__90000023_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_registered_QMARK__fn__90000023_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_registered_QMARK__fn__90000023_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_registered_QMARK__fn__90000023_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_registered_QMARK__fn__90000023_A_fn_class)}; return nil }

var A_arbace_aot_emit_registered_QMARK__fn__90000023_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_registered_QMARK__fn__90000023_A_invoke, New: A_arbace_aot_emit_registered_QMARK__fn__90000023_A_new, Get: A_arbace_aot_emit_registered_QMARK__fn__90000023_A_get}

var A_arbace_aot_emit_registered_QMARK__fn__90000023_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$registered_QMARK_$fn__90000023", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_registered_QMARK__A_class, Simple: "fn__90000023", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_registered_QMARK__fn__90000023_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_registered_QMARK__fn__90000023_A_class.Info(); i.IsInstance = A_arbace_aot_emit_registered_QMARK__fn__90000023_A_InstanceOf; i.Init = A_arbace_aot_emit_registered_QMARK__fn__90000023_A_Init; i.Table = A_arbace_aot_emit_registered_QMARK__fn__90000023_A_members; jrt.RegisterGoType(A_arbace_aot_emit_registered_QMARK__fn__90000023_A_class, reflect.TypeFor[A_arbace_aot_emit_registered_QMARK__fn__90000023_A]()) }

func A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A_fn_class)}; return nil }

var A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A_invoke, New: A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A_new, Get: A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A_get}

var A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$registered_QMARK_$fn__90000023$fn__90000024", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_registered_QMARK__fn__90000023_A_class, Simple: "fn__90000024", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A_class.Info(); i.IsInstance = A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A_InstanceOf; i.Init = A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A_Init; i.Table = A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A_members; jrt.RegisterGoType(A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A_class, reflect.TypeFor[A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A]()) }

func A_arbace_aot_emit_ret_body_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_ret_body_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_ret_body_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_ret_body_A_New()}; return nil }

func A_arbace_aot_emit_ret_body_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_ret_body_A_fn_class)}; return nil }

var A_arbace_aot_emit_ret_body_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_ret_body_A_invoke, New: A_arbace_aot_emit_ret_body_A_new, Get: A_arbace_aot_emit_ret_body_A_get}

var A_arbace_aot_emit_ret_body_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$ret_body", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "ret_body", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_ret_body_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_ret_body_A_class.Info(); i.IsInstance = A_arbace_aot_emit_ret_body_A_InstanceOf; i.Init = A_arbace_aot_emit_ret_body_A_Init; i.Table = A_arbace_aot_emit_ret_body_A_members; jrt.RegisterGoType(A_arbace_aot_emit_ret_body_A_class, reflect.TypeFor[A_arbace_aot_emit_ret_body_A]()) }

func A_arbace_aot_emit_runtime_class_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_runtime_class_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_runtime_class_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_runtime_class_QMARK__A_New()}; return nil }

func A_arbace_aot_emit_runtime_class_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_runtime_class_QMARK__A_fn_class)}; return nil }

var A_arbace_aot_emit_runtime_class_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_runtime_class_QMARK__A_invoke, New: A_arbace_aot_emit_runtime_class_QMARK__A_new, Get: A_arbace_aot_emit_runtime_class_QMARK__A_get}

var A_arbace_aot_emit_runtime_class_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$runtime_class_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "runtime_class_QMARK_", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_runtime_class_QMARK__A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_runtime_class_QMARK__A_class.Info(); i.IsInstance = A_arbace_aot_emit_runtime_class_QMARK__A_InstanceOf; i.Init = A_arbace_aot_emit_runtime_class_QMARK__A_Init; i.Table = A_arbace_aot_emit_runtime_class_QMARK__A_members; jrt.RegisterGoType(A_arbace_aot_emit_runtime_class_QMARK__A_class, reflect.TypeFor[A_arbace_aot_emit_runtime_class_QMARK__A]()) }

func A_arbace_aot_emit_simple_name_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_simple_name_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_simple_name_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_simple_name_A_New()}; return nil }

func A_arbace_aot_emit_simple_name_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_simple_name_A_fn_class)}; return nil }

var A_arbace_aot_emit_simple_name_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_simple_name_A_invoke, New: A_arbace_aot_emit_simple_name_A_new, Get: A_arbace_aot_emit_simple_name_A_get}

var A_arbace_aot_emit_simple_name_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$simple_name", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "simple_name", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_simple_name_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_simple_name_A_class.Info(); i.IsInstance = A_arbace_aot_emit_simple_name_A_InstanceOf; i.Init = A_arbace_aot_emit_simple_name_A_Init; i.Table = A_arbace_aot_emit_simple_name_A_members; jrt.RegisterGoType(A_arbace_aot_emit_simple_name_A_class, reflect.TypeFor[A_arbace_aot_emit_simple_name_A]()) }

func A_arbace_aot_emit_tag_class_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_tag_class_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_tag_class_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_tag_class_A_New()}; return nil }

func A_arbace_aot_emit_tag_class_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_tag_class_A_fn_class)}; return nil }

var A_arbace_aot_emit_tag_class_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_tag_class_A_invoke, New: A_arbace_aot_emit_tag_class_A_new, Get: A_arbace_aot_emit_tag_class_A_get}

var A_arbace_aot_emit_tag_class_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$tag_class", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "tag_class", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_tag_class_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_tag_class_A_class.Info(); i.IsInstance = A_arbace_aot_emit_tag_class_A_InstanceOf; i.Init = A_arbace_aot_emit_tag_class_A_Init; i.Table = A_arbace_aot_emit_tag_class_A_members; jrt.RegisterGoType(A_arbace_aot_emit_tag_class_A_class, reflect.TypeFor[A_arbace_aot_emit_tag_class_A]()) }

func A_arbace_aot_emit_tagged_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_tagged_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_tagged_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_tagged_A_New()}; return nil }

func A_arbace_aot_emit_tagged_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_tagged_A_fn_class)}; return nil }

var A_arbace_aot_emit_tagged_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_tagged_A_invoke, New: A_arbace_aot_emit_tagged_A_new, Get: A_arbace_aot_emit_tagged_A_get}

var A_arbace_aot_emit_tagged_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$tagged", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "tagged", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_tagged_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_tagged_A_class.Info(); i.IsInstance = A_arbace_aot_emit_tagged_A_InstanceOf; i.Init = A_arbace_aot_emit_tagged_A_Init; i.Table = A_arbace_aot_emit_tagged_A_members; jrt.RegisterGoType(A_arbace_aot_emit_tagged_A_class, reflect.TypeFor[A_arbace_aot_emit_tagged_A]()) }

func A_arbace_aot_emit_throws_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_throws_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_throws_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_throws_QMARK__A_New()}; return nil }

func A_arbace_aot_emit_throws_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_throws_QMARK__A_fn_class)}; return nil }

var A_arbace_aot_emit_throws_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_throws_QMARK__A_invoke, New: A_arbace_aot_emit_throws_QMARK__A_new, Get: A_arbace_aot_emit_throws_QMARK__A_get}

var A_arbace_aot_emit_throws_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$throws_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "throws_QMARK_", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_throws_QMARK__A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_throws_QMARK__A_class.Info(); i.IsInstance = A_arbace_aot_emit_throws_QMARK__A_InstanceOf; i.Init = A_arbace_aot_emit_throws_QMARK__A_Init; i.Table = A_arbace_aot_emit_throws_QMARK__A_members; jrt.RegisterGoType(A_arbace_aot_emit_throws_QMARK__A_class, reflect.TypeFor[A_arbace_aot_emit_throws_QMARK__A]()) }

func A_arbace_aot_emit_top_name_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_top_name_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_top_name_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_top_name_A_New()}; return nil }

func A_arbace_aot_emit_top_name_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_top_name_A_fn_class)}; return nil }

var A_arbace_aot_emit_top_name_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_top_name_A_invoke, New: A_arbace_aot_emit_top_name_A_new, Get: A_arbace_aot_emit_top_name_A_get}

var A_arbace_aot_emit_top_name_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$top_name", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "top_name", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_top_name_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_top_name_A_class.Info(); i.IsInstance = A_arbace_aot_emit_top_name_A_InstanceOf; i.Init = A_arbace_aot_emit_top_name_A_Init; i.Table = A_arbace_aot_emit_top_name_A_members; jrt.RegisterGoType(A_arbace_aot_emit_top_name_A_class, reflect.TypeFor[A_arbace_aot_emit_top_name_A]()) }

func A_arbace_aot_emit_type_sym_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_type_sym_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_type_sym_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_type_sym_A_New()}; return nil }

func A_arbace_aot_emit_type_sym_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_type_sym_A_fn_class)}; return nil }

var A_arbace_aot_emit_type_sym_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_type_sym_A_invoke, New: A_arbace_aot_emit_type_sym_A_new, Get: A_arbace_aot_emit_type_sym_A_get}

var A_arbace_aot_emit_type_sym_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$type_sym", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "type_sym", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_type_sym_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_type_sym_A_class.Info(); i.IsInstance = A_arbace_aot_emit_type_sym_A_InstanceOf; i.Init = A_arbace_aot_emit_type_sym_A_Init; i.Table = A_arbace_aot_emit_type_sym_A_members; jrt.RegisterGoType(A_arbace_aot_emit_type_sym_A_class, reflect.TypeFor[A_arbace_aot_emit_type_sym_A]()) }

func A_arbace_aot_emit_typed_args_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_typed_args_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_typed_args_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_typed_args_A_New()}; return nil }

func A_arbace_aot_emit_typed_args_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_typed_args_A_fn_class)}; return nil }

var A_arbace_aot_emit_typed_args_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_typed_args_A_invoke, New: A_arbace_aot_emit_typed_args_A_new, Get: A_arbace_aot_emit_typed_args_A_get}

var A_arbace_aot_emit_typed_args_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$typed_args", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "typed_args", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_typed_args_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_typed_args_A_class.Info(); i.IsInstance = A_arbace_aot_emit_typed_args_A_InstanceOf; i.Init = A_arbace_aot_emit_typed_args_A_Init; i.Table = A_arbace_aot_emit_typed_args_A_members; jrt.RegisterGoType(A_arbace_aot_emit_typed_args_A_class, reflect.TypeFor[A_arbace_aot_emit_typed_args_A]()) }

func A_arbace_aot_emit_typed_args_fn__90000067_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_typed_args_fn__90000067_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_typed_args_fn__90000067_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_typed_args_fn__90000067_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_typed_args_fn__90000067_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_typed_args_fn__90000067_A_fn_class)}; return nil }

var A_arbace_aot_emit_typed_args_fn__90000067_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_typed_args_fn__90000067_A_invoke, New: A_arbace_aot_emit_typed_args_fn__90000067_A_new, Get: A_arbace_aot_emit_typed_args_fn__90000067_A_get}

var A_arbace_aot_emit_typed_args_fn__90000067_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$typed_args$fn__90000067", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_typed_args_A_class, Simple: "fn__90000067", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_typed_args_fn__90000067_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_typed_args_fn__90000067_A_class.Info(); i.IsInstance = A_arbace_aot_emit_typed_args_fn__90000067_A_InstanceOf; i.Init = A_arbace_aot_emit_typed_args_fn__90000067_A_Init; i.Table = A_arbace_aot_emit_typed_args_fn__90000067_A_members; jrt.RegisterGoType(A_arbace_aot_emit_typed_args_fn__90000067_A_class, reflect.TypeFor[A_arbace_aot_emit_typed_args_fn__90000067_A]()) }

func A_arbace_aot_emit_unbox_arg_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_unbox_arg_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_unbox_arg_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_unbox_arg_A_New()}; return nil }

func A_arbace_aot_emit_unbox_arg_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_unbox_arg_A_fn_class)}; return nil }

var A_arbace_aot_emit_unbox_arg_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_unbox_arg_A_invoke, New: A_arbace_aot_emit_unbox_arg_A_new, Get: A_arbace_aot_emit_unbox_arg_A_get}

var A_arbace_aot_emit_unbox_arg_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$unbox_arg", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "unbox_arg", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_unbox_arg_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_unbox_arg_A_class.Info(); i.IsInstance = A_arbace_aot_emit_unbox_arg_A_InstanceOf; i.Init = A_arbace_aot_emit_unbox_arg_A_Init; i.Table = A_arbace_aot_emit_unbox_arg_A_members; jrt.RegisterGoType(A_arbace_aot_emit_unbox_arg_A_class, reflect.TypeFor[A_arbace_aot_emit_unbox_arg_A]()) }

func A_arbace_aot_emit_unit_method_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_unit_method_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_emit_unit_method_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_unit_method_A_New()}; return nil }

func A_arbace_aot_emit_unit_method_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_unit_method_A_fn_class)}; return nil }

var A_arbace_aot_emit_unit_method_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_unit_method_A_invoke, New: A_arbace_aot_emit_unit_method_A_new, Get: A_arbace_aot_emit_unit_method_A_get}

var A_arbace_aot_emit_unit_method_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$unit_method", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "unit_method", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_unit_method_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_unit_method_A_class.Info(); i.IsInstance = A_arbace_aot_emit_unit_method_A_InstanceOf; i.Init = A_arbace_aot_emit_unit_method_A_Init; i.Table = A_arbace_aot_emit_unit_method_A_members; jrt.RegisterGoType(A_arbace_aot_emit_unit_method_A_class, reflect.TypeFor[A_arbace_aot_emit_unit_method_A]()) }

func A_arbace_aot_emit_unit_method_iter__90000432__90000436_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_unit_method_iter__90000432__90000436_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_unit_method_iter__90000432__90000436_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_unit_method_iter__90000432__90000436_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_unit_method_iter__90000432__90000436_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_unit_method_iter__90000432__90000436_A_fn_class)}; return nil }

var A_arbace_aot_emit_unit_method_iter__90000432__90000436_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_unit_method_iter__90000432__90000436_A_invoke, New: A_arbace_aot_emit_unit_method_iter__90000432__90000436_A_new, Get: A_arbace_aot_emit_unit_method_iter__90000432__90000436_A_get}

var A_arbace_aot_emit_unit_method_iter__90000432__90000436_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$unit_method$iter__90000432__90000436", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_unit_method_A_class, Simple: "iter__90000432__90000436", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_unit_method_iter__90000432__90000436_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_unit_method_iter__90000432__90000436_A_class.Info(); i.IsInstance = A_arbace_aot_emit_unit_method_iter__90000432__90000436_A_InstanceOf; i.Init = A_arbace_aot_emit_unit_method_iter__90000432__90000436_A_Init; i.Table = A_arbace_aot_emit_unit_method_iter__90000432__90000436_A_members; jrt.RegisterGoType(A_arbace_aot_emit_unit_method_iter__90000432__90000436_A_class, reflect.TypeFor[A_arbace_aot_emit_unit_method_iter__90000432__90000436_A]()) }

func A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_A_fn_class)}; return nil }

var A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_A_invoke, New: A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_A_new, Get: A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_A_get}

var A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$unit_method$iter__90000432__90000436$fn__90000437", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_unit_method_iter__90000432__90000436_A_class, Simple: "fn__90000437", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_A_class.Info(); i.IsInstance = A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_A_InstanceOf; i.Init = A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_A_Init; i.Table = A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_A_members; jrt.RegisterGoType(A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_A_class, reflect.TypeFor[A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_A]()) }

func A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_A_fn_class)}; return nil }

var A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_A_invoke, New: A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_A_new, Get: A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_A_get}

var A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$unit_method$iter__90000432__90000436$fn__90000437$fn__90000438", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_A_class, Simple: "fn__90000438", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_A_class.Info(); i.IsInstance = A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_A_InstanceOf; i.Init = A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_A_Init; i.Table = A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_A_members; jrt.RegisterGoType(A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_A_class, reflect.TypeFor[A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_A]()) }

func A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_fn__90000440_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_fn__90000440_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_fn__90000440_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_fn__90000440_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_fn__90000440_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_fn__90000440_A_fn_class)}; return nil }

var A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_fn__90000440_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_fn__90000440_A_invoke, New: A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_fn__90000440_A_new, Get: A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_fn__90000440_A_get}

var A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_fn__90000440_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$unit_method$iter__90000432__90000436$fn__90000437$fn__90000438$fn__90000440", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_A_class, Simple: "fn__90000440", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_fn__90000440_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_fn__90000440_A_class.Info(); i.IsInstance = A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_fn__90000440_A_InstanceOf; i.Init = A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_fn__90000440_A_Init; i.Table = A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_fn__90000440_A_members; jrt.RegisterGoType(A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_fn__90000440_A_class, reflect.TypeFor[A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000438_fn__90000440_A]()) }

func A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000444_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000444_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000444_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000444_A_New_O(args[0])}; return nil }

func A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000444_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000444_A_fn_class)}; return nil }

var A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000444_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000444_A_invoke, New: A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000444_A_new, Get: A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000444_A_get}

var A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000444_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$unit_method$iter__90000432__90000436$fn__90000437$fn__90000444", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_A_class, Simple: "fn__90000444", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000444_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000444_A_class.Info(); i.IsInstance = A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000444_A_InstanceOf; i.Init = A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000444_A_Init; i.Table = A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000444_A_members; jrt.RegisterGoType(A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000444_A_class, reflect.TypeFor[A_arbace_aot_emit_unit_method_iter__90000432__90000436_fn__90000437_fn__90000444_A]()) }

func A_arbace_aot_emit_unit_ns_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_unit_ns_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_emit_unit_ns_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_unit_ns_A_New()}; return nil }

func A_arbace_aot_emit_unit_ns_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_unit_ns_A_fn_class)}; return nil }

var A_arbace_aot_emit_unit_ns_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_unit_ns_A_invoke, New: A_arbace_aot_emit_unit_ns_A_new, Get: A_arbace_aot_emit_unit_ns_A_get}

var A_arbace_aot_emit_unit_ns_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$unit_ns", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "unit_ns", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_unit_ns_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_unit_ns_A_class.Info(); i.IsInstance = A_arbace_aot_emit_unit_ns_A_InstanceOf; i.Init = A_arbace_aot_emit_unit_ns_A_Init; i.Table = A_arbace_aot_emit_unit_ns_A_members; jrt.RegisterGoType(A_arbace_aot_emit_unit_ns_A_class, reflect.TypeFor[A_arbace_aot_emit_unit_ns_A]()) }

func A_arbace_aot_emit_var_value_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_emit_var_value_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_emit_var_value_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit_var_value_A_New()}; return nil }

func A_arbace_aot_emit_var_value_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_emit_var_value_A_fn_class)}; return nil }

var A_arbace_aot_emit_var_value_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_emit_var_value_A_invoke, New: A_arbace_aot_emit_var_value_A_new, Get: A_arbace_aot_emit_var_value_A_get}

var A_arbace_aot_emit_var_value_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit$var_value", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_emit_A_class, Simple: "var_value", Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit_var_value_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit_var_value_A_class.Info(); i.IsInstance = A_arbace_aot_emit_var_value_A_InstanceOf; i.Init = A_arbace_aot_emit_var_value_A_Init; i.Table = A_arbace_aot_emit_var_value_A_members; jrt.RegisterGoType(A_arbace_aot_emit_var_value_A_class, reflect.TypeFor[A_arbace_aot_emit_var_value_A]()) }

func A_arbace_aot_emit__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_aot_emit__init_A_Load__O(); case 1: return A_arbace_aot_emit__init_A_Unit0__O(); case 2: return A_arbace_aot_emit__init_A_Unit1__O(); case 3: return A_arbace_aot_emit__init_A_Unit10__O(); case 4: return A_arbace_aot_emit__init_A_Unit11__O(); case 5: return A_arbace_aot_emit__init_A_Unit12__O(); case 6: return A_arbace_aot_emit__init_A_Unit13__O(); case 7: return A_arbace_aot_emit__init_A_Unit14__O(); case 8: return A_arbace_aot_emit__init_A_Unit15__O(); case 9: return A_arbace_aot_emit__init_A_Unit16__O(); case 10: return A_arbace_aot_emit__init_A_Unit17__O(); case 11: return A_arbace_aot_emit__init_A_Unit18__O(); case 12: return A_arbace_aot_emit__init_A_Unit19__O(); case 13: return A_arbace_aot_emit__init_A_Unit2__O(); case 14: return A_arbace_aot_emit__init_A_Unit20__O(); case 15: return A_arbace_aot_emit__init_A_Unit21__O(); case 16: return A_arbace_aot_emit__init_A_Unit22__O(); case 17: return A_arbace_aot_emit__init_A_Unit23__O(); case 18: return A_arbace_aot_emit__init_A_Unit24__O(); case 19: return A_arbace_aot_emit__init_A_Unit25__O(); case 20: return A_arbace_aot_emit__init_A_Unit26__O(); case 21: return A_arbace_aot_emit__init_A_Unit27__O(); case 22: return A_arbace_aot_emit__init_A_Unit28__O(); case 23: return A_arbace_aot_emit__init_A_Unit29__O(); case 24: return A_arbace_aot_emit__init_A_Unit3__O(); case 25: return A_arbace_aot_emit__init_A_Unit30__O(); case 26: return A_arbace_aot_emit__init_A_Unit31__O(); case 27: return A_arbace_aot_emit__init_A_Unit32__O(); case 28: return A_arbace_aot_emit__init_A_Unit33__O(); case 29: return A_arbace_aot_emit__init_A_Unit34__O(); case 30: return A_arbace_aot_emit__init_A_Unit35__O(); case 31: return A_arbace_aot_emit__init_A_Unit36__O(); case 32: return A_arbace_aot_emit__init_A_Unit37__O(); case 33: return A_arbace_aot_emit__init_A_Unit38__O(); case 34: return A_arbace_aot_emit__init_A_Unit39__O(); case 35: return A_arbace_aot_emit__init_A_Unit4__O(); case 36: return A_arbace_aot_emit__init_A_Unit40__O(); case 37: return A_arbace_aot_emit__init_A_Unit41__O(); case 38: return A_arbace_aot_emit__init_A_Unit42__O(); case 39: return A_arbace_aot_emit__init_A_Unit43__O(); case 40: return A_arbace_aot_emit__init_A_Unit44__O(); case 41: return A_arbace_aot_emit__init_A_Unit45__O(); case 42: return A_arbace_aot_emit__init_A_Unit46__O(); case 43: return A_arbace_aot_emit__init_A_Unit47__O(); case 44: return A_arbace_aot_emit__init_A_Unit48__O(); case 45: return A_arbace_aot_emit__init_A_Unit49__O(); case 46: return A_arbace_aot_emit__init_A_Unit5__O(); case 47: return A_arbace_aot_emit__init_A_Unit50__O(); case 48: return A_arbace_aot_emit__init_A_Unit51__O(); case 49: return A_arbace_aot_emit__init_A_Unit52__O(); case 50: return A_arbace_aot_emit__init_A_Unit53__O(); case 51: return A_arbace_aot_emit__init_A_Unit54__O(); case 52: return A_arbace_aot_emit__init_A_Unit55__O(); case 53: return A_arbace_aot_emit__init_A_Unit56__O(); case 54: return A_arbace_aot_emit__init_A_Unit57__O(); case 55: return A_arbace_aot_emit__init_A_Unit58__O(); case 56: return A_arbace_aot_emit__init_A_Unit59__O(); case 57: return A_arbace_aot_emit__init_A_Unit6__O(); case 58: return A_arbace_aot_emit__init_A_Unit60__O(); case 59: return A_arbace_aot_emit__init_A_Unit61__O(); case 60: return A_arbace_aot_emit__init_A_Unit62__O(); case 61: return A_arbace_aot_emit__init_A_Unit63__O(); case 62: return A_arbace_aot_emit__init_A_Unit64__O(); case 63: return A_arbace_aot_emit__init_A_Unit65__O(); case 64: return A_arbace_aot_emit__init_A_Unit66__O(); case 65: return A_arbace_aot_emit__init_A_Unit67__O(); case 66: return A_arbace_aot_emit__init_A_Unit68__O(); case 67: return A_arbace_aot_emit__init_A_Unit69__O(); case 68: return A_arbace_aot_emit__init_A_Unit7__O(); case 69: return A_arbace_aot_emit__init_A_Unit70__O(); case 70: return A_arbace_aot_emit__init_A_Unit71__O(); case 71: return A_arbace_aot_emit__init_A_Unit72__O(); case 72: return A_arbace_aot_emit__init_A_Unit73__O(); case 73: return A_arbace_aot_emit__init_A_Unit74__O(); case 74: return A_arbace_aot_emit__init_A_Unit75__O(); case 75: return A_arbace_aot_emit__init_A_Unit76__O(); case 76: return A_arbace_aot_emit__init_A_Unit77__O(); case 77: return A_arbace_aot_emit__init_A_Unit78__O(); case 78: return A_arbace_aot_emit__init_A_Unit79__O(); case 79: return A_arbace_aot_emit__init_A_Unit8__O(); case 80: return A_arbace_aot_emit__init_A_Unit80__O(); case 81: return A_arbace_aot_emit__init_A_Unit81__O(); case 82: return A_arbace_aot_emit__init_A_Unit82__O(); case 83: return A_arbace_aot_emit__init_A_Unit83__O(); case 84: return A_arbace_aot_emit__init_A_Unit84__O(); case 85: return A_arbace_aot_emit__init_A_Unit85__O(); case 86: return A_arbace_aot_emit__init_A_Unit86__O(); case 87: return A_arbace_aot_emit__init_A_Unit87__O(); case 88: return A_arbace_aot_emit__init_A_Unit88__O(); case 89: return A_arbace_aot_emit__init_A_Unit89__O(); case 90: return A_arbace_aot_emit__init_A_Unit9__O(); case 91: return A_arbace_aot_emit__init_A_Unit90__O(); case 92: return A_arbace_aot_emit__init_A_Unit91__O(); case 93: return A_arbace_aot_emit__init_A_Unit92__O(); case 94: return A_arbace_aot_emit__init_A_Unit93__O(); case 95: return A_arbace_aot_emit__init_A_Unit94__O(); case 96: return A_arbace_aot_emit__init_A_Unit95__O()}; return nil }

func A_arbace_aot_emit__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_emit__init_A_New()}; return nil }

var A_arbace_aot_emit__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit34 ()Ljava.lang.Object;\nM9 unit35 ()Ljava.lang.Object;\nM9 unit36 ()Ljava.lang.Object;\nM9 unit37 ()Ljava.lang.Object;\nM9 unit38 ()Ljava.lang.Object;\nM9 unit39 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit40 ()Ljava.lang.Object;\nM9 unit41 ()Ljava.lang.Object;\nM9 unit42 ()Ljava.lang.Object;\nM9 unit43 ()Ljava.lang.Object;\nM9 unit44 ()Ljava.lang.Object;\nM9 unit45 ()Ljava.lang.Object;\nM9 unit46 ()Ljava.lang.Object;\nM9 unit47 ()Ljava.lang.Object;\nM9 unit48 ()Ljava.lang.Object;\nM9 unit49 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit50 ()Ljava.lang.Object;\nM9 unit51 ()Ljava.lang.Object;\nM9 unit52 ()Ljava.lang.Object;\nM9 unit53 ()Ljava.lang.Object;\nM9 unit54 ()Ljava.lang.Object;\nM9 unit55 ()Ljava.lang.Object;\nM9 unit56 ()Ljava.lang.Object;\nM9 unit57 ()Ljava.lang.Object;\nM9 unit58 ()Ljava.lang.Object;\nM9 unit59 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit60 ()Ljava.lang.Object;\nM9 unit61 ()Ljava.lang.Object;\nM9 unit62 ()Ljava.lang.Object;\nM9 unit63 ()Ljava.lang.Object;\nM9 unit64 ()Ljava.lang.Object;\nM9 unit65 ()Ljava.lang.Object;\nM9 unit66 ()Ljava.lang.Object;\nM9 unit67 ()Ljava.lang.Object;\nM9 unit68 ()Ljava.lang.Object;\nM9 unit69 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit70 ()Ljava.lang.Object;\nM9 unit71 ()Ljava.lang.Object;\nM9 unit72 ()Ljava.lang.Object;\nM9 unit73 ()Ljava.lang.Object;\nM9 unit74 ()Ljava.lang.Object;\nM9 unit75 ()Ljava.lang.Object;\nM9 unit76 ()Ljava.lang.Object;\nM9 unit77 ()Ljava.lang.Object;\nM9 unit78 ()Ljava.lang.Object;\nM9 unit79 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit80 ()Ljava.lang.Object;\nM9 unit81 ()Ljava.lang.Object;\nM9 unit82 ()Ljava.lang.Object;\nM9 unit83 ()Ljava.lang.Object;\nM9 unit84 ()Ljava.lang.Object;\nM9 unit85 ()Ljava.lang.Object;\nM9 unit86 ()Ljava.lang.Object;\nM9 unit87 ()Ljava.lang.Object;\nM9 unit88 ()Ljava.lang.Object;\nM9 unit89 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nM9 unit90 ()Ljava.lang.Object;\nM9 unit91 ()Ljava.lang.Object;\nM9 unit92 ()Ljava.lang.Object;\nM9 unit93 ()Ljava.lang.Object;\nM9 unit94 ()Ljava.lang.Object;\nM9 unit95 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_aot_emit__init_A_invoke, New: A_arbace_aot_emit__init_A_new}

var A_arbace_aot_emit__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.emit__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_aot_emit.A_arbace_aot_emit__init_A", Source: "emit.ae"})

func init() { i := A_arbace_aot_emit__init_A_class.Info(); i.IsInstance = A_arbace_aot_emit__init_A_InstanceOf; i.Init = A_arbace_aot_emit__init_A_Init; i.Table = A_arbace_aot_emit__init_A_members; jrt.RegisterGoType(A_arbace_aot_emit__init_A_class, reflect.TypeFor[A_arbace_aot_emit__init_A]()) }
