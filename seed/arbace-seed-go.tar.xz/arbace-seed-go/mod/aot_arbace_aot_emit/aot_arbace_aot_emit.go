//line aot_arbace_aot_emit.ae:1
package aot_arbace_aot_emit

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A_New() *A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp20 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_aot_emit_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_2); lang.IFn_Cast(A_arbace_aot_emit_A_const_1.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_aot_emit_A_const_3, A_arbace_aot_emit_A_const_4, A_arbace_aot_emit_A_const_5); { var tmp4 *lang.Var; lang.RT_Init(); tmp4 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp4).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_193)); var tmp5 *lang.Var; lang.RT_Init(); tmp5 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp5).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_194)); var tmp6 *lang.Var; lang.RT_Init(); tmp6 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp6).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_195)); var tmp7 *lang.Var; lang.RT_Init(); tmp7 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp7).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_196)); var tmp8 *lang.Var; lang.RT_Init(); tmp8 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp8).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_197)); var tmp9 *lang.Var; lang.RT_Init(); tmp9 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp9).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_198)); var tmp10 *lang.Var; lang.RT_Init(); tmp10 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp10).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_199)); var tmp11 *lang.Var; lang.RT_Init(); tmp11 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp11).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_200)); var tmp12 *lang.Var; lang.RT_Init(); tmp12 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp12).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_201)); var tmp13 *lang.Var; lang.RT_Init(); tmp13 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp13).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_202)); var tmp14 *lang.Var; lang.RT_Init(); tmp14 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp14).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_203)); var tmp15 *lang.Var; lang.RT_Init(); tmp15 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp15).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_204)); var tmp16 *lang.Var; lang.RT_Init(); tmp16 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp16).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_205)); var tmp17 *lang.Var; lang.RT_Init(); tmp17 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp17).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_206)); var tmp18 *lang.Var; lang.RT_Init(); tmp18 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp18).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_207)); var tmp19 *lang.Var; lang.RT_Init(); tmp19 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp19).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_208)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp20 != nil { panic(tmp20) }; return tmp3 }
//line :1:1
func A_arbace_aot_emit_eval90000008_fn__90000009_A_New() *A_arbace_aot_emit_eval90000008_fn__90000009_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_eval90000008_fn__90000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_aot_emit_eval90000008_fn__90000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_aot_emit_eval90000008_fn__90000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_aot_emit_A_const_6.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_10), A_arbace_aot_emit_A_const_8.GetRawRoot__O(), A_arbace_aot_emit_A_const_9) }




































func A_arbace_aot_emit_node_A_New() *A_arbace_aot_emit_node_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_node_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_aot_emit_node_A) Ctor() {}
//line :38:1
func (t *A_arbace_aot_emit_node_A) Invoke_O_O__O(self, x__0 any) any {


	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_11.GetRawRoot__O()).Invoke_O__O(x__0)) { var or__1927000174__auto____2 any = jrt.NN(jrt.IdentityHashMap_Cast(A_arbace_aot_emit_A_const_12.GetRawRoot__O())).Get_O__O(x__0)
		if jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var n__3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_13.GetRawRoot__O()).Invoke_O_O_O__O(lang.Compiler_AST_Node_O__IPersistentMap(x__0), A_arbace_aot_emit_A_const_14, x__0)

			jrt.NN(jrt.IdentityHashMap_Cast(A_arbace_aot_emit_A_const_12.GetRawRoot__O())).Put_O_O__O(x__0, n__3)
//line :42:1
			return n__3 } } else {
//line :41:1
				return nil
			}
}



func A_arbace_aot_emit_fail_A_New() *A_arbace_aot_emit_fail_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_fail_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_aot_emit_fail_A) Ctor() {}
//line :47:1
func (t *A_arbace_aot_emit_fail_A) DoInvoke_O_O_O__O(self, msg__0, p__90000013__1 any) any { var vec__90000014__3 any = p__90000013__1; var data__4 any = lang.RT_Nth_O_I_O__O(vec__90000014__3, lang.RT_IntCast_J__I(0), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_15.GetRawRoot__O()); var tmp2 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_209, nil), jrt.RefArrayOf(jrt.Object_class, nil, msg__0)).Ref(); var tmp3 any; var or__1927000174__auto____5 any = data__4; if
												jrt.A2g_Truth(or__1927000174__auto____5) { tmp3 = or__1927000174__auto____5 } else { lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY.Ref() }; /*line :47:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp1.Invoke_O_O__O(tmp2, tmp3)))) }





func A_arbace_aot_emit_destub_A_New() *A_arbace_aot_emit_destub_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_destub_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_aot_emit_destub_A) Ctor() {}
//line :53:1
func (t *A_arbace_aot_emit_destub_A) Invoke_O_O__O(self, n__0 any) any {


	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_16.GetRawRoot__O()).Invoke_O_O__O(n__0, Lit_38)) { return lang.IFn_Cast(A_arbace_aot_emit_A_const_17.GetRawRoot__O()).Invoke_O_O__O(n__0, jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(Lit_38)).Ref()) } else { return n__0
	} }
func A_arbace_aot_emit_type_sym_A_New() *A_arbace_aot_emit_type_sym_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_type_sym_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_aot_emit_type_sym_A) Ctor() {}
//line :58:1
func (t *A_arbace_aot_emit_type_sym_A) Invoke_O_O__O(self, c__0 any) any {



	if jrt.NN(jrt.Class_Cast(c__0)).IsArray__Z() { var e__2 any = c__0; var n__3 int64 = 0; L1: for {

		if jrt.NN(jrt.Class_Cast(e__2)).IsArray__Z() {
			e__2, n__3 = jrt.NN(jrt.Class_Cast(e__2)).GetComponentType__Class().Ref(), lang.Numbers_Inc_J__J(n__3); continue L1 } else {
				return lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(e__2)), lang.IFn_Cast(A_arbace_aot_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(n__3).Ref())) } } } else {
					return lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref())) }
//line :58:1
	panic("a2g: unreachable")
}













func A_arbace_aot_emit_tagged_A_New() *A_arbace_aot_emit_tagged_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_tagged_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_aot_emit_tagged_A) Ctor() {}
//line :73:1
func (t *A_arbace_aot_emit_tagged_A) Invoke_O_O_O__O(self, s__0, c__1 any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_22.GetRawRoot__O()); var tmp2 any = A_arbace_aot_emit_A_const_13.GetRawRoot__O(); var tmp3 any = A_arbace_aot_emit_A_const_23; var tmp4 any; if jrt.Class_InstanceOf(c__1) { var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_24.GetRawRoot__O()).Invoke_O__O(c__1)
		if jrt.A2g_Truth(or__1927000174__auto____3) { tmp4 = or__1927000174__auto____3 } else { if jrt.NN(jrt.Class_Cast(c__1)).IsArray__Z() { tmp4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__1)).GetName__String().Ref()) } else { tmp4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(c__1) } } } else {
//line :78:1
			tmp4 = c__1 }; return tmp1.Invoke_O_O_O_O__O(s__0, tmp2, tmp3, tmp4)
}






func A_arbace_aot_emit_registered_QMARK__A_New() *A_arbace_aot_emit_registered_QMARK__A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_registered_QMARK__A{}; t.Ctor(); return t }
//line :86:1
func (t *A_arbace_aot_emit_registered_QMARK__A) Ctor() {}
//line :86:1
func (t *A_arbace_aot_emit_registered_QMARK__A) Invoke_O_O__O(self, c__0 any) any { var c__2 any; var tmp1 any = A_arbace_aot_emit_registered_QMARK__fn__90000021_A_New_O(c__0); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_aot_emit_registered_QMARK__fn__90000021_A_fn_class; if
											fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_248, false); A_arbace_aot_emit_registered_QMARK__fn__90000021_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; c__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); var or__1927000174__auto____3 any = /*line :86:1*/lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(c__2, Lit_249, false); if

	jrt.A2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var n__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(c__2, Lit_250, false)); var temp__1927000420__auto____5 any = lang.RT_Get_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_26.GetRawRoot__O()), n__4)

		if lang.Util_Identical_O_O__Z(temp__1927000420__auto____5, nil) { var r__6 any; var tmp3 any = A_arbace_aot_emit_registered_QMARK__fn__90000023_A_New_O(n__4); var tmp4 *jrt.Class
			var fncls__3 /*line :90:1*/*jrt.Class = A_arbace_aot_emit_registered_QMARK__fn__90000023_A_fn_class

			if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_251, false); A_arbace_aot_emit_registered_QMARK__fn__90000023_A_fn_class = fncls__3d; tmp4 = fncls__3d } else { tmp4 = fncls__3 }; r__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()







			lang.IFn_Cast(A_arbace_aot_emit_A_const_27.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_aot_emit_A_const_26.GetRawRoot__O(), A_arbace_aot_emit_A_const_13.GetRawRoot__O(), n__4, r__6)
//line :90:1
			return r__6 } else { var r__6_2 any = temp__1927000420__auto____5; return r__6_2 } } }
//line :87:1
func A_arbace_aot_emit_registered_QMARK__fn__90000021_A_New_O(p0 any) *A_arbace_aot_emit_registered_QMARK__fn__90000021_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_registered_QMARK__fn__90000021_A{}; t.Ctor_O(p0); return t }
//line :87:1
func (t *A_arbace_aot_emit_registered_QMARK__fn__90000021_A) Ctor_O(c__c any) { t.F_c = c__c }
//line :87:1
func (t *A_arbace_aot_emit_registered_QMARK__fn__90000021_A) Invoke_O__O(self any) any { { var c__1 any; var t_ any = t.F_c; t.F_c = nil; c__1 = t_; L1: for { if jrt.NN(jrt.Class_Cast(c__1)).IsArray__Z() { c__1 = jrt.NN(jrt.Class_Cast(c__1)).GetComponentType__Class().Ref(); continue L1 } else { return c__1 } } }; panic("a2g: unreachable") }




func A_arbace_aot_emit_registered_QMARK__fn__90000023_A_New_O(p0 any) *A_arbace_aot_emit_registered_QMARK__fn__90000023_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_registered_QMARK__fn__90000023_A{}; t.Ctor_O(p0); return t }
//line :92:1
func (t *A_arbace_aot_emit_registered_QMARK__fn__90000023_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :92:1
func (t *A_arbace_aot_emit_registered_QMARK__fn__90000023_A) Invoke_O__O(self any) any { var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var k__3 any; var tmp2 any; var t_ any = t.F_n; t.F_n = nil; tmp2 = t_; var tmp3 *jrt.String = jrt.String_Cast(tmp2); var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_FALSE; k__3 = jrt.Class_ForName_String_Z_ClassLoader__Class(tmp3, jrt.NN(tmp4).BooleanValue__Z(), nil).Ref(); var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_11.GetRawRoot__O()).Invoke_O__O(k__3)
											if jrt.A2g_Truth(and__1927000168__auto____4) {

		var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_25.GetRawRoot__O()); var tmp6 any = A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A_New_O(k__3); var tmp7 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_252, false); A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A_fn_class = fncls__2d; tmp7 = fncls__2d } else { tmp7 = fncls__2 }; tmp1 = tmp5.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()) } else {
//line :93:1
			tmp1 = and__1927000168__auto____4 } }; return nil }(); if /*line :92:1*/ tmp8 != nil { if true { var ___3 jrt.Throwable_I = tmp8; _ = ___3; jrt.Boolean_Init(); tmp1 = jrt.Boolean_FALSE.Ref() } }; return tmp1 }


func A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A_New_O(p0 any) *A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A{}; t.Ctor_O(p0); return t }
//line :95:1
func (t *A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :95:1
func (t *A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *jrt.String = Lit_193; var tmp3 *jrt.String = Lit_253; var tmp4 any; var t_ any = t.F_k
													t.F_k = nil; tmp4 = t_
//line :95:1
	tmp1 = lang.Reflector_InvokeStaticMethod_String_String_O1__O(tmp2, tmp3, lang.RT_Object_array_O__O1(lang.Tuple_Create_O__IPersistentVector(tmp4))) }; return nil }(); if tmp5 != nil { if true { var ___3 jrt.Throwable_I = tmp5; _ = ___3; jrt.Boolean_Init(); tmp1 = jrt.Boolean_FALSE.Ref() } }; return tmp1 }







func A_arbace_aot_emit_runtime_class_QMARK__A_New() *A_arbace_aot_emit_runtime_class_QMARK__A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_runtime_class_QMARK__A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_aot_emit_runtime_class_QMARK__A) Ctor() {}
//line :103:1
func (t *A_arbace_aot_emit_runtime_class_QMARK__A) Invoke_O_O_O__O(self, c__0, ctx__1 any) any { var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_29.Invoke_O__O(ctx__1)), lang.IFn_Cast(A_arbace_aot_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref())); if





	jrt.A2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else {
		return lang.IFn_Cast(A_arbace_aot_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(c__0)) } }

func A_arbace_aot_emit_public_QMARK__A_New() *A_arbace_aot_emit_public_QMARK__A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_public_QMARK__A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_aot_emit_public_QMARK__A) Ctor() {}
//line :112:1
func (t *A_arbace_aot_emit_public_QMARK__A) Invoke_O_O__O(self, c__0 any) any {
	return jrt.Boolean_ValueOf_Z__Boolean(jrt.Modifier_IsPublic_I__Z(jrt.NN(jrt.Class_Cast(c__0)).GetModifiers__I())).Ref()
}



func A_arbace_aot_emit_top_name_A_New() *A_arbace_aot_emit_top_name_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_top_name_A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_aot_emit_top_name_A) Ctor() {}
//line :118:1
func (t *A_arbace_aot_emit_top_name_A) Invoke_O_O__O(self, n__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_17); if lang.Numbers_IsNeg_J__Z(int64(i__2)) { return n__0 } else { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_aot_emit_A_const_31; return tmp1.Invoke_O_O_O__O(n__0, tmp2, jrt.Integer_ValueOf_I__Integer(i__2).Ref()) } }

func A_arbace_aot_emit_pool_A_New() *A_arbace_aot_emit_pool_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_pool_A{}; t.Ctor(); return t }
//line :120:1
func (t *A_arbace_aot_emit_pool_A) Ctor() {}
//line :120:1
func (t *A_arbace_aot_emit_pool_A) Invoke_O_O_O__O(self, ctx__0, top__1 any) any { var pools__3 any = A_arbace_aot_emit_A_const_32.Invoke_O__O(ctx__0); var or__1927000174__auto____4 any = lang.RT_Get_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(pools__3), top__1); if




	jrt.A2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_27.GetRawRoot__O()); var tmp2 any = A_arbace_aot_emit_pool_fn__90000031_A_New_O(top__1); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_aot_emit_pool_fn__90000031_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_236, false); A_arbace_aot_emit_pool_fn__90000031_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; return lang.RT_Get_O_O__O(tmp1.Invoke_O_O__O(pools__3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)), top__1) } }
//line :126:1
func A_arbace_aot_emit_pool_fn__90000031_A_New_O(p0 any) *A_arbace_aot_emit_pool_fn__90000031_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_pool_fn__90000031_A{}; t.Ctor_O(p0); return t }
//line :126:1
func (t *A_arbace_aot_emit_pool_fn__90000031_A) Ctor_O(c__top any) { t.F_top = c__top }
//line :126:1
func (t *A_arbace_aot_emit_pool_fn__90000031_A) Invoke_O_O__O(self, m__1 any) any { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_28.GetRawRoot__O()).Invoke_O_O__O(m__1, t.F_top)) { return m__1 } else {
											var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_13.GetRawRoot__O()); var tmp2 any = t.F_top; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_33.GetRawRoot__O()); var tmp4 any = A_arbace_aot_emit_A_const_34; var tmp5 any = t.F_top; var tmp6 any = A_arbace_aot_emit_A_const_35; var tmp7 *lang.PersistentVector; lang.PersistentVector_Init(); tmp7 = lang.PersistentVector_EMPTY; var tmp8 any = tmp7.Ref(); var tmp9 any = A_arbace_aot_emit_A_const_36; return tmp1.Invoke_O_O_O__O(m__1, tmp2, tmp3.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, tmp8, tmp9, jrt.IdentityHashMap_New(), A_arbace_aot_emit_A_const_37, Lit_237)))) } }


func A_arbace_aot_emit_const_field_A_New() *A_arbace_aot_emit_const_field_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_const_field_A{}; t.Ctor(); return t }
//line :130:1
func (t *A_arbace_aot_emit_const_field_A) Ctor() {}
//line :130:1
func (t *A_arbace_aot_emit_const_field_A) Invoke_O_O_O_O__O(self, ctx__0, v__1, ctype__2 any) any { var cls__4 any = A_arbace_aot_emit_A_const_38.Invoke_O__O(ctx__0); var tmp1 *lang.Keyword = A_arbace_aot_emit_A_const_36; var m__5 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(cls__4)); var or__1927000174__auto____6 any = jrt.NN(jrt.IdentityHashMap_Cast(m__5)).Get_O__O(v__1); if






	jrt.A2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else { var tmp2 *lang.Keyword = A_arbace_aot_emit_A_const_35; var n__7 int32 = lang.RT_Count_O__I(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(cls__4))); var tmp3 *lang.Keyword = A_arbace_aot_emit_A_const_37; var s__8 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_24, nil), jrt.RefArrayOf(jrt.Object_class, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(cls__4)), nil, jrt.Integer_ValueOf_I__Integer(n__7).Ref())).Ref())


		jrt.NN(jrt.IdentityHashMap_Cast(m__5)).Put_O_O__O(v__1, s__8)
		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_27.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_A_const_39.GetRawRoot__O(); var tmp6 any = A_arbace_aot_emit_A_const_35; tmp4.Invoke_O_O_O_O_O__O(cls__4, tmp5, tmp6, A_arbace_aot_emit_A_const_8.GetRawRoot__O(), lang.Tuple_Create_O_O_O__IPersistentVector(s__8, ctype__2, v__1))
//line :137:1
		return s__8 } }








func A_arbace_aot_emit_emit_list_array_A_New() *A_arbace_aot_emit_emit_list_array_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_list_array_A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_aot_emit_emit_list_array_A) Ctor() {}
//line :146:1
func (t *A_arbace_aot_emit_emit_list_array_A) Invoke_O_O_O__O(self, ctx__0, xs__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp2 any = A_arbace_aot_emit_A_const_41; var tmp3 any = A_arbace_aot_emit_A_const_42; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_43.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_emit_list_array_fn__90000036_A_New_O(ctx__0); var tmp6 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_aot_emit_emit_list_array_fn__90000036_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_169, false); A_arbace_aot_emit_emit_list_array_fn__90000036_A_fn_class = fncls__5d; tmp6 = fncls__5d } else { tmp6 = fncls__5 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), xs__1)) }
//line :147:1
func A_arbace_aot_emit_emit_list_array_fn__90000036_A_New_O(p0 any) *A_arbace_aot_emit_emit_list_array_fn__90000036_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_list_array_fn__90000036_A{}; t.Ctor_O(p0); return t }
//line :147:1
func (t *A_arbace_aot_emit_emit_list_array_fn__90000036_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :147:1
func (t *A_arbace_aot_emit_emit_list_array_fn__90000036_A) Invoke_O_O__O(self, p1__90000035_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_aot_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, p1__90000035_SHARP___1) }

func A_arbace_aot_emit_char_form_A_New() *A_arbace_aot_emit_char_form_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_char_form_A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_aot_emit_char_form_A) Ctor() {}
//line :149:1
func (t *A_arbace_aot_emit_char_form_A) Invoke_O_O__O(self, c__0 any) any { var i__2 int32 = lang.RT_IntCast_C__I(jrt.NN(jrt.Character_Cast(c__0)).CharValue__C()); var tmp1 any; var and__1927000168__auto____3 bool = lang.Numbers_Gte_J_J__Z(int64(i__2), 33); if and__1927000168__auto____3 {

	var and__1927000168__auto____4 bool = lang.Numbers_Lte_J_J__Z(int64(i__2), 126); if and__1927000168__auto____4 { tmp1 = lang.IFn_Cast(A_arbace_aot_emit_A_const_45.GetRawRoot__O()).Invoke_O_O__O(c__0, A_arbace_aot_emit_A_const_46) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }; if jrt.A2g_Truth(tmp1) { return c__0 } else {

		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp3 any = A_arbace_aot_emit_A_const_47; return tmp2.Invoke_O_O__O(tmp3, jrt.Integer_ValueOf_I__Integer(i__2).Ref()) } }

func A_arbace_aot_emit_double_form_A_New() *A_arbace_aot_emit_double_form_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_double_form_A{}; t.Ctor(); return t }
//line :155:1
func (t *A_arbace_aot_emit_double_form_A) Ctor() {}
//line :155:1
func (t *A_arbace_aot_emit_double_form_A) Invoke_O_O__O(self, p_d__0 any) any { var d__0 float64 = lang.RT_DoubleCast_O__D(p_d__0); var tmp1 bool; var or__1927000174__auto____2 bool = jrt.Double_IsNaN_D__Z(d__0); if or__1927000174__auto____2 {
										tmp1 = or__1927000174__auto____2 } else { tmp1 = jrt.Double_IsInfinite_D__Z(d__0) }; if tmp1 {
											var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp3 any = A_arbace_aot_emit_A_const_48; return tmp2.Invoke_O_O__O(tmp3, jrt.Long_ValueOf_J__Long(jrt.Double_DoubleToRawLongBits_D__J(d__0)).Ref()) } else {
//line :156:1
			return jrt.Double_ValueOf_D__Double(d__0).Ref() } }



func A_arbace_aot_emit_emit_value_A_New() *A_arbace_aot_emit_emit_value_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_value_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_aot_emit_emit_value_A) Ctor() {}
//line :160:1
func (t *A_arbace_aot_emit_emit_value_A) Invoke_O_O_O__O(self, ctx__0, v__1 any) any { var vec__90000042__3 any; if



	lang.Util_Identical_O_O__Z(v__1, nil) { vec__90000042__3 = A_arbace_aot_emit_A_const_49 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_50.GetRawRoot__O()).Invoke_O__O(v__1)) { var tmp1 *jrt.Boolean; jrt.Boolean_Init(); tmp1 = jrt.Boolean_TRUE; vec__90000042__3 = lang.Tuple_Create_O_O__IPersistentVector(v__1, tmp1.Ref()) } else { if jrt.Boolean_InstanceOf(v__1) { var tmp2 any


		if jrt.A2g_Truth(v__1) { tmp2 = A_arbace_aot_emit_A_const_63 } else { tmp2 = A_arbace_aot_emit_A_const_64 }
//line :164:1
		var tmp3 any = tmp2; var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_TRUE; vec__90000042__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4.Ref()) } else { if jrt.Integer_InstanceOf(v__1) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp6 any = A_arbace_aot_emit_A_const_65; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp8 any = A_arbace_aot_emit_A_const_66; var tmp9 any = tmp5.Invoke_O_O__O(tmp6, tmp7.Invoke_O_O__O(tmp8, jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(v__1)).Ref())); var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_TRUE; vec__90000042__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp9, tmp10.Ref()) } else { if jrt.Long_InstanceOf(v__1) { var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp12 any = A_arbace_aot_emit_A_const_67; var tmp13 any = tmp11.Invoke_O_O__O(tmp12, jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(v__1)).Ref()); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; vec__90000042__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp13, tmp14.Ref()) } else { if jrt.Double_InstanceOf(v__1) { var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp16 any = A_arbace_aot_emit_A_const_68; var tmp17 any = tmp15.Invoke_O_O__O(tmp16, lang.IFn_Cast(A_arbace_aot_emit_A_const_69.GetRawRoot__O()).Invoke_O__O(v__1)); var tmp18 *jrt.Boolean; jrt.Boolean_Init(); tmp18 = jrt.Boolean_TRUE; vec__90000042__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp17, tmp18.Ref()) } else { if jrt.Character_InstanceOf(v__1) { var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp20 any = A_arbace_aot_emit_A_const_70; var tmp21 any = tmp19.Invoke_O_O__O(tmp20, lang.IFn_Cast(A_arbace_aot_emit_A_const_71.GetRawRoot__O()).Invoke_O__O(v__1)); var tmp22 *jrt.Boolean; jrt.Boolean_Init(); tmp22 = jrt.Boolean_TRUE; vec__90000042__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp21, tmp22.Ref()) } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_51.GetRawRoot__O()).Invoke_O__O(v__1)) { var tmp23 any







			if jrt.NN(jrt.Class_Cast(v__1)).IsPrimitive__Z() {
				var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()); var tmp25 *jrt.Class; jrt.Boolean_Init(); tmp25 = jrt.Boolean_TYPE; var tmp26 any = tmp25.Ref(); var tmp27 any = A_arbace_aot_emit_A_const_72; var tmp28 *jrt.Class; jrt.Byte_Init(); tmp28 = jrt.Byte_TYPE; var tmp29 any = tmp28.Ref(); var tmp30 any = A_arbace_aot_emit_A_const_73; var tmp31 *jrt.Class; jrt.Character_Init(); tmp31 = jrt.Character_TYPE; var tmp32 any = tmp31.Ref(); var tmp33 any = A_arbace_aot_emit_A_const_74; var tmp34 *jrt.Class; jrt.Double_Init(); tmp34 = jrt.Double_TYPE; var tmp35 any = tmp34.Ref(); var tmp36 any = A_arbace_aot_emit_A_const_75; var tmp37 *jrt.Class; jrt.Float_Init(); tmp37 = jrt.Float_TYPE; var tmp38 any = tmp37.Ref(); var tmp39 any = A_arbace_aot_emit_A_const_76; var tmp40 *jrt.Class; jrt.Integer_Init(); tmp40 = jrt.Integer_TYPE; var tmp41 any = tmp40.Ref(); var tmp42 any = A_arbace_aot_emit_A_const_77; var tmp43 *jrt.Class; jrt.Long_Init(); tmp43 = jrt.Long_TYPE; var tmp44 any = tmp43.Ref(); var tmp45 any = A_arbace_aot_emit_A_const_78; var tmp46 *jrt.Class; jrt.Short_Init(); tmp46 = jrt.Short_TYPE; tmp23 = tmp24.Invoke_O_O__O(jrt.NN(jrt.Class_Cast(lang.IFn_Cast(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp26, tmp27, tmp29, tmp30, tmp32, tmp33, tmp35, tmp36, tmp38, tmp39, tmp41, tmp42, tmp44, tmp45, tmp46.Ref(), A_arbace_aot_emit_A_const_79))).Invoke_O__O(v__1))).GetName__String().Ref(), Lit_186) } else {



					var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp48 any = A_arbace_aot_emit_A_const_80; tmp23 = tmp47.Invoke_O_O__O(tmp48, lang.IFn_Cast(A_arbace_aot_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(v__1)).GetName__String().Ref())) }
//line :164:1
			var tmp49 any = tmp23; var tmp50 *jrt.Boolean; jrt.Boolean_Init(); tmp50 = jrt.Boolean_TRUE; vec__90000042__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp49, tmp50.Ref()) } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_52.GetRawRoot__O()).Invoke_O__O(v__1)) { var tmp51 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_84, A_arbace_aot_emit_A_const_85), lang.IFn_Cast(A_arbace_aot_emit_A_const_82.GetRawRoot__O()).Invoke_O__O(v__1), lang.IFn_Cast(A_arbace_aot_emit_A_const_83.GetRawRoot__O()).Invoke_O__O(v__1)); var tmp52 *jrt.Boolean; jrt.Boolean_Init(); tmp52 = jrt.Boolean_TRUE; vec__90000042__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp51, tmp52.Ref()) } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_53.GetRawRoot__O()).Invoke_O__O(v__1)) { var tmp53 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_86, A_arbace_aot_emit_A_const_87), lang.IFn_Cast(A_arbace_aot_emit_A_const_82.GetRawRoot__O()).Invoke_O__O(v__1), lang.IFn_Cast(A_arbace_aot_emit_A_const_83.GetRawRoot__O()).Invoke_O__O(v__1)); var tmp54 *jrt.Boolean; jrt.Boolean_Init(); tmp54 = jrt.Boolean_TRUE; vec__90000042__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp53, tmp54.Ref()) } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_54.GetRawRoot__O()).Invoke_O__O(v__1)) { var tmp55 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_88, A_arbace_aot_emit_A_const_89), lang.IFn_Cast(A_arbace_aot_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.Var_Cast(v__1).F_ns.F_name.Ref()), lang.IFn_Cast(A_arbace_aot_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.Var_Cast(v__1).F_sym.Ref())); var tmp56 *jrt.Boolean; jrt.Boolean_Init(); tmp56 = jrt.Boolean_TRUE; vec__90000042__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp55, tmp56.Ref()) } else { if lang.Namespace_InstanceOf(v__1) { var tmp57 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_90, A_arbace_aot_emit_A_const_91), lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_92, A_arbace_aot_emit_A_const_93), nil, lang.IFn_Cast(A_arbace_aot_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.Namespace_Cast(v__1).F_name.Ref()))); var tmp58 *jrt.Boolean; jrt.Boolean_Init(); tmp58 = jrt.Boolean_FALSE; vec__90000042__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp57, tmp58.Ref()) } else { if lang.IRecord_InstanceOf(v__1) {



























				vec__90000042__3 = lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_187, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_aot_emit_A_const_94.GetRawRoot__O()).Invoke_O__O(v__1))).Ref()) } else {
//line :164:1
					if lang.IType_InstanceOf(v__1) {




























						vec__90000042__3 = lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_188, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_aot_emit_A_const_94.GetRawRoot__O()).Invoke_O__O(v__1))).Ref()) } else {
//line :164:1
							if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_56.GetRawRoot__O()).Invoke_O__O(v__1)) { var tmp59 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_96, A_arbace_aot_emit_A_const_97), lang.IFn_Cast(A_arbace_aot_emit_A_const_95.GetRawRoot__O()).Invoke_O_O__O(ctx__0, lang.IFn_Cast(A_arbace_aot_emit_A_const_98.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_99.GetRawRoot__O(), v__1))); var tmp60 *jrt.Boolean; jrt.Boolean_Init(); tmp60 = jrt.Boolean_TRUE; vec__90000042__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp59, tmp60.Ref()) } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_57.GetRawRoot__O()).Invoke_O__O(v__1)) { var tmp61 any
































								if lang.Numbers_Lte_J_J__Z(int64(lang.RT_Count_O__I(v__1)), 6) {
									var tmp62 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_100.GetRawRoot__O()); var tmp63 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()); var tmp64 any = A_arbace_aot_emit_A_const_102; var tmp65 any = A_arbace_aot_emit_A_const_103; var tmp66 any = tmp63.Invoke_O_O__O(tmp64, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp65, lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_105.GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(v__1)).Ref(), A_arbace_aot_emit_A_const_106))))); var tmp67 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()); var tmp68 any = A_arbace_aot_emit_emit_value_fn__90000045_A_New_O(ctx__0); var tmp69 *jrt.Class
									var fncls__7 /*line :198:1*/*jrt.Class = A_arbace_aot_emit_emit_value_fn__90000045_A_fn_class

									if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_189, false); A_arbace_aot_emit_emit_value_fn__90000045_A_fn_class = fncls__7d; tmp69 = fncls__7d } else { tmp69 = fncls__7 }
//line :198:1
									tmp61 = tmp62.Invoke_O_O__O(tmp66, tmp67.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp68, tmp69, nil), v__1)) } else {


										tmp61 = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_107, A_arbace_aot_emit_A_const_108), lang.IFn_Cast(A_arbace_aot_emit_A_const_95.GetRawRoot__O()).Invoke_O_O__O(ctx__0, v__1)) }
//line :164:1
								var tmp70 any = tmp61; var tmp71 *jrt.Boolean; jrt.Boolean_Init(); tmp71 = jrt.Boolean_TRUE; vec__90000042__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp70, tmp71.Ref()) } else { if lang.PersistentHashSet_InstanceOf(v__1) { var tmp72 any







































									if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_109.GetRawRoot__O()).Invoke_O__O(v__1)) { tmp72 = A_arbace_aot_emit_A_const_110 } else {

										tmp72 = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_111, A_arbace_aot_emit_A_const_112), lang.IFn_Cast(A_arbace_aot_emit_A_const_95.GetRawRoot__O()).Invoke_O_O__O(ctx__0, lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(v__1))) }
//line :164:1
									var tmp73 any = tmp72; var tmp74 *jrt.Boolean; jrt.Boolean_Init(); tmp74 = jrt.Boolean_TRUE; vec__90000042__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp73, tmp74.Ref()) } else { var tmp75 any; var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_58.GetRawRoot__O()).Invoke_O__O(v__1)













































										if jrt.A2g_Truth(or__1927000174__auto____3) { tmp75 = or__1927000174__auto____3 } else { tmp75 = lang.IFn_Cast(A_arbace_aot_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(v__1) }
//line :164:1
										if jrt.A2g_Truth(tmp75) { var tmp76 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_114, A_arbace_aot_emit_A_const_115), lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_116, A_arbace_aot_emit_A_const_117), lang.IFn_Cast(A_arbace_aot_emit_A_const_95.GetRawRoot__O()).Invoke_O_O__O(ctx__0, v__1))); var tmp77 *jrt.Boolean; jrt.Boolean_Init(); tmp77 = jrt.Boolean_TRUE; vec__90000042__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp76, tmp77.Ref()) } else { if jrt.Pattern_InstanceOf(v__1) { var tmp78 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_118, A_arbace_aot_emit_A_const_119), lang.IFn_Cast(A_arbace_aot_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(v__1)); var tmp79 *jrt.Boolean; jrt.Boolean_Init(); tmp79 = jrt.Boolean_TRUE; vec__90000042__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp78, tmp79.Ref()) } else { if A_arbace_aot_emit_A_const_60 != nil { var s__3 any; var tmp80 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_120.GetRawRoot__O()); var tmp81 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_121.GetRawRoot__O()); var tmp82 any = A_arbace_aot_emit_A_const_122; var tmp83 *jrt.Boolean






















































											jrt.Boolean_Init(); tmp83 = jrt.Boolean_TRUE; tmp80.Invoke_O__O(tmp81.Invoke_O_O__O(tmp82, tmp83.Ref())); var tmp84 any = A_arbace_aot_emit_emit_value_fn__90000047_A_New_O(v__1); var tmp85 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_aot_emit_emit_value_fn__90000047_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_190, false); A_arbace_aot_emit_emit_value_fn__90000047_A_fn_class = fncls__6d; tmp85 = fncls__6d } else { tmp85 = fncls__6 }; s__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp84, tmp85, nil).Invoke__O()
											var tmp86 any; var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_109.GetRawRoot__O()).Invoke_O__O(s__3); if jrt.A2g_Truth(or__1927000174__auto____4) { tmp86 = or__1927000174__auto____4 } else { tmp86 = lang.IFn_Cast(A_arbace_aot_emit_A_const_16.GetRawRoot__O()).Invoke_O_O__O(s__3, Lit_191) }; if jrt.A2g_Truth(tmp86) {
												lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_192, nil), jrt.RefArrayOf(jrt.Object_class, nil, s__3)).Ref()) }
//line :164:1
											var tmp87 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_123, A_arbace_aot_emit_A_const_124), s__3); var tmp88 *jrt.Boolean; jrt.Boolean_Init(); tmp88 = jrt.Boolean_FALSE; vec__90000042__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp87, tmp88.Ref()) } else { vec__90000042__3 = nil } } } } } } } } } } } } } } } } } } } }; var form__4 any = /*line :160:1*/lang.RT_Nth_O_I_O__O(vec__90000042__3, lang.RT_IntCast_J__I(0), nil); var partial_QMARK___5 any = lang.RT_Nth_O_I_O__O(vec__90000042__3, lang.RT_IntCast_J__I(1), nil); var m__6 any; var tmp89 any; var and__1927000168__auto____6 any = partial_QMARK___5; if






























































	jrt.A2g_Truth(and__1927000168__auto____6) { tmp89 = jrt.Boolean_ValueOf_Z__Boolean(lang.IObj_InstanceOf(v__1)).Ref() } else { tmp89 = and__1927000168__auto____6 }; if jrt.A2g_Truth(tmp89) { m__6 = lang.RT_Meta_O__IPersistentMap(v__1) } else { m__6 = nil }; if
	lang.Numbers_IsPos_J__Z(int64(lang.RT_Count_O__I(m__6))) {
		var tmp90 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp91 any = A_arbace_aot_emit_A_const_125; var tmp92 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp93 any = A_arbace_aot_emit_A_const_128; var tmp94 any = A_arbace_aot_emit_A_const_129; return tmp90.Invoke_O_O_O__O(tmp91, lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_aot_emit_A_const_126, A_arbace_aot_emit_A_const_127, form__4), tmp92.Invoke_O_O_O__O(tmp93, tmp94, lang.IFn_Cast(A_arbace_aot_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(ctx__0, m__6))) } else {
//line :224:1
			return form__4 } }
//line :200:1
func A_arbace_aot_emit_emit_value_fn__90000045_A_New_O(p0 any) *A_arbace_aot_emit_emit_value_fn__90000045_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_value_fn__90000045_A{}; t.Ctor_O(p0); return t }
//line :200:1
func (t *A_arbace_aot_emit_emit_value_fn__90000045_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :200:1
func (t *A_arbace_aot_emit_emit_value_fn__90000045_A) Invoke_O_O__O(self, p1__90000041_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_aot_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, p1__90000041_SHARP___1) }


















func A_arbace_aot_emit_emit_value_fn__90000047_A_New_O(p0 any) *A_arbace_aot_emit_emit_value_fn__90000047_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_value_fn__90000047_A{}; t.Ctor_O(p0); return t }
//line :219:1
func (t *A_arbace_aot_emit_emit_value_fn__90000047_A) Ctor_O(c__v any) { t.F_v = c__v }
//line :219:1
func (t *A_arbace_aot_emit_emit_value_fn__90000047_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_61.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_v; t.F_v = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); lang.IFn_Cast(A_arbace_aot_emit_A_const_62.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }
















func A_arbace_aot_emit_pool_kind_A_New() *A_arbace_aot_emit_pool_kind_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_pool_kind_A{}; t.Ctor(); return t }
//line :236:1
func (t *A_arbace_aot_emit_pool_kind_A) Ctor() {}
//line :236:1
func (t *A_arbace_aot_emit_pool_kind_A) Invoke_O_O__O(self, v__0 any) any {


	if lang.Util_Identical_O_O__Z(v__0, nil) { return A_arbace_aot_emit_A_const_130 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_50.GetRawRoot__O()).Invoke_O__O(v__0)) { return A_arbace_aot_emit_A_const_131 } else { if jrt.Boolean_InstanceOf(v__0) { return A_arbace_aot_emit_A_const_132 } else { if jrt.Integer_InstanceOf(v__0) { return A_arbace_aot_emit_A_const_133 } else { if jrt.Long_InstanceOf(v__0) { return A_arbace_aot_emit_A_const_134 } else { if jrt.Double_InstanceOf(v__0) { return A_arbace_aot_emit_A_const_135 } else { if jrt.Character_InstanceOf(v__0) { return A_arbace_aot_emit_A_const_136 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_51.GetRawRoot__O()).Invoke_O__O(v__0)) { return A_arbace_aot_emit_A_const_137 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_52.GetRawRoot__O()).Invoke_O__O(v__0)) { return A_arbace_aot_emit_A_const_138 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_53.GetRawRoot__O()).Invoke_O__O(v__0)) { return A_arbace_aot_emit_A_const_139 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_54.GetRawRoot__O()).Invoke_O__O(v__0)) { return A_arbace_aot_emit_A_const_140 } else { if lang.Namespace_InstanceOf(v__0) { return A_arbace_aot_emit_A_const_141 } else { if lang.IRecord_InstanceOf(v__0) {












		return lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_187, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_aot_emit_A_const_94.GetRawRoot__O()).Invoke_O__O(v__0))).Ref()) } else {
//line :239:1
			if lang.IType_InstanceOf(v__0) {













				return lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_188, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_aot_emit_A_const_94.GetRawRoot__O()).Invoke_O__O(v__0))).Ref()) } else {
//line :239:1
					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_56.GetRawRoot__O()).Invoke_O__O(v__0)) { return A_arbace_aot_emit_A_const_142 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_57.GetRawRoot__O()).Invoke_O__O(v__0)) { return A_arbace_aot_emit_A_const_143 } else { if lang.PersistentHashSet_InstanceOf(v__0) { return A_arbace_aot_emit_A_const_144 } else { var tmp1 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_58.GetRawRoot__O()).Invoke_O__O(v__0)

















						if jrt.A2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { tmp1 = lang.IFn_Cast(A_arbace_aot_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(v__0) }
//line :239:1
						if jrt.A2g_Truth(tmp1) { return A_arbace_aot_emit_A_const_145 } else { if jrt.Pattern_InstanceOf(v__0) { return A_arbace_aot_emit_A_const_146 } else { if A_arbace_aot_emit_A_const_60 != nil { return A_arbace_aot_emit_A_const_147 } else { return nil
						}
						}
						}
					}
					}
					}
				}
		}
	}
	}
	}
	}
	}
	}
	}
	}
	}
	}
	}
	}
}




func A_arbace_aot_emit_pool_shared_QMARK__A_New() *A_arbace_aot_emit_pool_shared_QMARK__A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_pool_shared_QMARK__A{}; t.Ctor(); return t }
//line :265:1
func (t *A_arbace_aot_emit_pool_shared_QMARK__A) Ctor() {}
//line :265:1
func (t *A_arbace_aot_emit_pool_shared_QMARK__A) Invoke_O_O__O(self, v__0 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_53.GetRawRoot__O()).Invoke_O__O(v__0); if


	jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_52.GetRawRoot__O()).Invoke_O__O(v__0); if jrt.A2g_Truth(and__1927000168__auto____3) { return lang.IFn_Cast(A_arbace_aot_emit_A_const_109.GetRawRoot__O()).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(v__0)) } else { return and__1927000168__auto____3 } } }

func A_arbace_aot_emit_pool_parts_A_New() *A_arbace_aot_emit_pool_parts_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_pool_parts_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_aot_emit_pool_parts_A) Ctor() {}
//line :270:1
func (t *A_arbace_aot_emit_pool_parts_A) Invoke_O_O__O(self, v__0 any) any { var k__2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_148.GetRawRoot__O()).Invoke_O__O(v__0); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()); var tmp2 any; var G__90000052__3_ any = k__2; L1:



switch { default: switch lang.Util_Hash_O__I(G__90000052__3_) >> 5 & 3 { case 0: if any(G__90000052__3_) == any(A_arbace_aot_emit_A_const_142) {
	tmp2 = lang.IFn_Cast(A_arbace_aot_emit_A_const_98.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_99.GetRawRoot__O(), v__0)
//line :274:1
	break L1 }; case 1: if any(G__90000052__3_) == any(A_arbace_aot_emit_A_const_145) {

		tmp2 = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(v__0)
//line :274:1
		break L1 }; case 2: if any(G__90000052__3_) == any(A_arbace_aot_emit_A_const_143) {

			tmp2 = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(v__0)
//line :274:1
			break L1 }; case 3: if any(G__90000052__3_) == any(A_arbace_aot_emit_A_const_144) {

				tmp2 = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(v__0)
//line :274:1
				break L1 }; default:}; tmp2 = nil}; var tmp3 any = tmp2; var tmp4 lang.IPersistentVector; var tmp5 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_28.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_150.GetRawRoot__O(), k__2); if



	jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 bool = lang.IObj_InstanceOf(v__0); if and__1927000168__auto____4 { tmp5 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsPos_J__Z(int64(lang.RT_Count_O__I(lang.RT_Meta_O__IPersistentMap(v__0))))).Ref() } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4).Ref() } } else { tmp5 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp5) { tmp4 = lang.Tuple_Create_O__IPersistentVector(lang.RT_Meta_O__IPersistentMap(v__0)) } else { tmp4 = nil }; return /*line :274:1*/ tmp1.Invoke_O_O__O(tmp3, tmp4) }






func A_arbace_aot_emit_pool_str_A_New() *A_arbace_aot_emit_pool_str_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_pool_str_A{}; t.Ctor(); return t }
//line :281:1
func (t *A_arbace_aot_emit_pool_str_A) Ctor() {}
//line :281:1
func (t *A_arbace_aot_emit_pool_str_A) Invoke_O_O_O__O(self, sb__0, s__1 any) any {
	return jrt.NN(jrt.NN(jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_I__StringBuilder(jrt.NN(jrt.String_Cast(s__1)).Length__I())).Append_O__StringBuilder(A_arbace_aot_emit_A_const_151)).Append_String__StringBuilder(jrt.String_Cast(s__1)).Ref()
}
func A_arbace_aot_emit_pool_encode_A_New() *A_arbace_aot_emit_pool_encode_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_pool_encode_A{}; t.Ctor(); return t }
//line :284:1
func (t *A_arbace_aot_emit_pool_encode_A) Ctor() {}
//line :284:1
func (t *A_arbace_aot_emit_pool_encode_A) Invoke_O_O_O_O__O(self, sb__0, shared__1, v__2 any) any { var temp__1927000408__auto____4 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_152.GetRawRoot__O()).Invoke_O__O(v__2); if



	jrt.A2g_Truth(and__1927000168__auto____4) { temp__1927000408__auto____4 = lang.RT_Get_O_O__O(shared__1, v__2) } else { temp__1927000408__auto____4 = and__1927000168__auto____4 }; if jrt.A2g_Truth(temp__1927000408__auto____4) { var i__5 any = temp__1927000408__auto____4
		return jrt.NN(jrt.NN(jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_aot_emit_A_const_153)).Append_J__StringBuilder(lang.RT_LongCast_O__J(i__5))).Append_O__StringBuilder(A_arbace_aot_emit_A_const_151).Ref() } else {
//line :288:1
			var k__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_148.GetRawRoot__O()).Invoke_O__O(v__2); var num__6 any; var tmp1 any = A_arbace_aot_emit_pool_encode_num__90000055_A_New_O(sb__0); var tmp2 *jrt.Class
			var fncls__9 /*line :288:1*/*jrt.Class = A_arbace_aot_emit_pool_encode_num__90000055_A_fn_class


			if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_238, false); A_arbace_aot_emit_pool_encode_num__90000055_A_fn_class = fncls__9d; tmp2 = fncls__9d } else { tmp2 = fncls__9 }; num__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :288:1
			var arr__7 any; var tmp3 any = A_arbace_aot_emit_pool_encode_arr__90000057_A_New_O_O(shared__1, sb__0); var tmp4 *jrt.Class
			var fncls__10 /*line :288:1*/*jrt.Class = A_arbace_aot_emit_pool_encode_arr__90000057_A_fn_class



			if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_239, false); A_arbace_aot_emit_pool_encode_arr__90000057_A_fn_class = fncls__10d; tmp4 = fncls__10d } else { tmp4 = fncls__10 }; arr__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)
//line :288:1
			var m__8 any; var tmp5 any; var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_28.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_150.GetRawRoot__O(), k__5)





			if jrt.A2g_Truth(and__1927000168__auto____8) { tmp5 = jrt.Boolean_ValueOf_Z__Boolean(lang.IObj_InstanceOf(v__2)).Ref() } else { tmp5 = and__1927000168__auto____8 }; if jrt.A2g_Truth(tmp5) { m__8 = lang.RT_Meta_O__IPersistentMap(v__2) } else { m__8 = nil }
//line :288:1
			var m_QMARK___9 bool = lang.Numbers_IsPos_J__Z(int64(lang.RT_Count_O__I(m__8)))







			if m_QMARK___9 { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_aot_emit_A_const_160) }
//line :288:1
			var G__90000063__10_ any = k__5








		L1: switch { default: switch lang.Util_Hash_O__I(G__90000063__10_) >> 4 & 63 { case 1: if any(G__90000063__10_) == any(A_arbace_aot_emit_A_const_140) {


















			jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_aot_emit_A_const_165)
			lang.IFn_Cast(A_arbace_aot_emit_A_const_161.GetRawRoot__O()).Invoke_O_O__O(sb__0, lang.IFn_Cast(A_arbace_aot_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.Var_Cast(v__2).F_ns.F_name.Ref()))
			lang.IFn_Cast(A_arbace_aot_emit_A_const_161.GetRawRoot__O()).Invoke_O_O__O(sb__0, lang.IFn_Cast(A_arbace_aot_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.Var_Cast(v__2).F_sym.Ref()))
//line :297:1
			break L1 }; case 2: if any(G__90000063__10_) == any(A_arbace_aot_emit_A_const_130) {
				jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_aot_emit_A_const_162)
//line :297:1
				break L1 }; case 5: if any(G__90000063__10_) == any(A_arbace_aot_emit_A_const_139) {















					jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_aot_emit_A_const_166)
					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_82.GetRawRoot__O()).Invoke_O__O(v__2)) { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_aot_emit_A_const_167); lang.IFn_Cast(A_arbace_aot_emit_A_const_161.GetRawRoot__O()).Invoke_O_O__O(sb__0, lang.IFn_Cast(A_arbace_aot_emit_A_const_82.GetRawRoot__O()).Invoke_O__O(v__2)) } else { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_aot_emit_A_const_162) }
					lang.IFn_Cast(A_arbace_aot_emit_A_const_161.GetRawRoot__O()).Invoke_O_O__O(sb__0, lang.IFn_Cast(A_arbace_aot_emit_A_const_83.GetRawRoot__O()).Invoke_O__O(v__2))
//line :297:1
					break L1 }; case 10: if any(G__90000063__10_) == any(A_arbace_aot_emit_A_const_132) {


						var tmp6 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__0); var tmp7 any; if jrt.A2g_Truth(v__2) { tmp7 = A_arbace_aot_emit_A_const_163 } else { tmp7 = A_arbace_aot_emit_A_const_164 }; jrt.NN(tmp6).Append_O__StringBuilder(tmp7)
//line :297:1
						break L1 }; case 12: if any(G__90000063__10_) == any(A_arbace_aot_emit_A_const_146) {


























							jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_aot_emit_A_const_168); lang.IFn_Cast(A_arbace_aot_emit_A_const_161.GetRawRoot__O()).Invoke_O_O__O(sb__0, lang.IFn_Cast(A_arbace_aot_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(v__2))
//line :297:1
							break L1 }; case 15: if any(G__90000063__10_) == any(A_arbace_aot_emit_A_const_135) {





								var tmp8 lang.IFn = lang.IFn_Cast(num__6); var tmp9 any = A_arbace_aot_emit_A_const_169; tmp8.Invoke_O_O__O(tmp9, jrt.Long_ValueOf_J__Long(jrt.Double_DoubleToRawLongBits_D__J(lang.RT_DoubleCast_O__D(v__2))).Ref())
//line :297:1
								break L1 }; case 16: if any(G__90000063__10_) == any(A_arbace_aot_emit_A_const_142) {






















									var tmp10 lang.IFn = lang.IFn_Cast(arr__7); var tmp11 any = A_arbace_aot_emit_A_const_170; tmp10.Invoke_O_O__O(tmp11, lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_98.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_99.GetRawRoot__O(), v__2)))
//line :297:1
									break L1 }; case 17: if any(G__90000063__10_) == any(A_arbace_aot_emit_A_const_136) {






										var tmp12 lang.IFn = lang.IFn_Cast(num__6); var tmp13 any = A_arbace_aot_emit_A_const_180; tmp12.Invoke_O_O__O(tmp13, jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_C__I(jrt.NN(jrt.Character_Cast(v__2)).CharValue__C())).Ref())
//line :297:1
										break L1 }; case 18: if any(G__90000063__10_) == any(A_arbace_aot_emit_A_const_137) {







											if jrt.NN(jrt.Class_Cast(v__2)).IsPrimitive__Z() {

												var tmp14 *jrt.StringBuilder = jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_aot_emit_A_const_171); var tmp15 *jrt.Class; jrt.Void_Init(); tmp15 = jrt.Void_TYPE; var tmp16 any = tmp15.Ref(); var tmp17 any = A_arbace_aot_emit_A_const_172; var tmp18 *jrt.Class; jrt.Double_Init(); tmp18 = jrt.Double_TYPE; var tmp19 any = tmp18.Ref(); var tmp20 any = A_arbace_aot_emit_A_const_173; var tmp21 *jrt.Class; jrt.Character_Init(); tmp21 = jrt.Character_TYPE; var tmp22 any = tmp21.Ref(); var tmp23 any = A_arbace_aot_emit_A_const_174; var tmp24 *jrt.Class; jrt.Byte_Init(); tmp24 = jrt.Byte_TYPE; var tmp25 any = tmp24.Ref(); var tmp26 any = A_arbace_aot_emit_A_const_175; var tmp27 *jrt.Class; jrt.Boolean_Init(); tmp27 = jrt.Boolean_TYPE; var tmp28 any = tmp27.Ref(); var tmp29 any = A_arbace_aot_emit_A_const_176; var tmp30 *jrt.Class; jrt.Float_Init(); tmp30 = jrt.Float_TYPE; var tmp31 any = tmp30.Ref(); var tmp32 any = A_arbace_aot_emit_A_const_164; var tmp33 *jrt.Class; jrt.Long_Init(); tmp33 = jrt.Long_TYPE; var tmp34 any = tmp33.Ref(); var tmp35 any = A_arbace_aot_emit_A_const_177; var tmp36 *jrt.Class; jrt.Short_Init(); tmp36 = jrt.Short_TYPE; var tmp37 any = tmp36.Ref(); var tmp38 any = A_arbace_aot_emit_A_const_178; var tmp39 *jrt.Class; jrt.Integer_Init(); tmp39 = jrt.Integer_TYPE; jrt.NN(tmp14).Append_O__StringBuilder(lang.IFn_Cast(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp17, tmp19, tmp20, tmp22, tmp23, tmp25, tmp26, tmp28, tmp29, tmp31, tmp32, tmp34, tmp35, tmp37, tmp38, tmp39.Ref(), A_arbace_aot_emit_A_const_179))).Invoke_O__O(v__2)) } else {

													jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_aot_emit_A_const_174); lang.IFn_Cast(A_arbace_aot_emit_A_const_161.GetRawRoot__O()).Invoke_O_O__O(sb__0, lang.IFn_Cast(A_arbace_aot_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(v__2)).GetName__String().Ref())) }
//line :297:1
											break L1 }; case 20: if any(G__90000063__10_) == any(A_arbace_aot_emit_A_const_143) {























												var tmp40 lang.IFn = lang.IFn_Cast(arr__7); var tmp41 any = A_arbace_aot_emit_A_const_172; tmp40.Invoke_O_O__O(tmp41, lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()).Invoke_O__O(v__2))
//line :297:1
												break L1 }; case 22: if any(G__90000063__10_) == any(A_arbace_aot_emit_A_const_141) {





















													jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_aot_emit_A_const_181); lang.IFn_Cast(A_arbace_aot_emit_A_const_161.GetRawRoot__O()).Invoke_O_O__O(sb__0, lang.IFn_Cast(A_arbace_aot_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.Namespace_Cast(v__2).F_name.Ref()))
//line :297:1
													break L1 }; case 28: if any(G__90000063__10_) == any(A_arbace_aot_emit_A_const_147) { var s__11 any; var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_120.GetRawRoot__O()); var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_121.GetRawRoot__O()); var tmp44 any = A_arbace_aot_emit_A_const_122; var tmp45 *jrt.Boolean



























														jrt.Boolean_Init(); tmp45 = jrt.Boolean_TRUE; tmp42.Invoke_O__O(tmp43.Invoke_O_O__O(tmp44, tmp45.Ref())); var tmp46 any = A_arbace_aot_emit_pool_encode_fn__90000064_A_New_O(v__2); var tmp47 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_aot_emit_pool_encode_fn__90000064_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_240, false); A_arbace_aot_emit_pool_encode_fn__90000064_A_fn_class = fncls__12d; tmp47 = fncls__12d } else { tmp47 = fncls__12 }; s__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp46, tmp47, nil).Invoke__O()
														var tmp48 any; var or__1927000174__auto____12 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_109.GetRawRoot__O()).Invoke_O__O(s__11); if jrt.A2g_Truth(or__1927000174__auto____12) { tmp48 = or__1927000174__auto____12 } else { tmp48 = lang.IFn_Cast(A_arbace_aot_emit_A_const_16.GetRawRoot__O()).Invoke_O_O__O(s__11, Lit_191) }; if jrt.A2g_Truth(tmp48) {
															lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_192, nil), jrt.RefArrayOf(jrt.Object_class, nil, s__11)).Ref()) }
														jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_aot_emit_A_const_182); lang.IFn_Cast(A_arbace_aot_emit_A_const_161.GetRawRoot__O()).Invoke_O_O__O(sb__0, s__11)
//line :297:1
														break L1 }; case 29: if any(G__90000063__10_) == any(A_arbace_aot_emit_A_const_134) {




															lang.IFn_Cast(num__6).Invoke_O_O__O(A_arbace_aot_emit_A_const_183, v__2)
//line :297:1
															break L1 }; case 36: if any(G__90000063__10_) == any(A_arbace_aot_emit_A_const_138) {












																jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_aot_emit_A_const_184)
																if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_82.GetRawRoot__O()).Invoke_O__O(v__2)) { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_aot_emit_A_const_167); lang.IFn_Cast(A_arbace_aot_emit_A_const_161.GetRawRoot__O()).Invoke_O_O__O(sb__0, lang.IFn_Cast(A_arbace_aot_emit_A_const_82.GetRawRoot__O()).Invoke_O__O(v__2)) } else { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_aot_emit_A_const_162) }
																lang.IFn_Cast(A_arbace_aot_emit_A_const_161.GetRawRoot__O()).Invoke_O_O__O(sb__0, lang.IFn_Cast(A_arbace_aot_emit_A_const_83.GetRawRoot__O()).Invoke_O__O(v__2))
//line :297:1
																break L1 }; case 37: if any(G__90000063__10_) == any(A_arbace_aot_emit_A_const_133) {



																	lang.IFn_Cast(num__6).Invoke_O_O__O(A_arbace_aot_emit_A_const_186, v__2)
//line :297:1
																	break L1 }; case 46: if any(G__90000063__10_) == any(A_arbace_aot_emit_A_const_144) {
























																		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_109.GetRawRoot__O()).Invoke_O__O(v__2)) { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_aot_emit_A_const_185) } else { var tmp49 lang.IFn = lang.IFn_Cast(arr__7); var tmp50 any = A_arbace_aot_emit_A_const_178; tmp49.Invoke_O_O__O(tmp50, lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(v__2))) }
//line :297:1
																		break L1 }; case 58: if any(G__90000063__10_) == any(A_arbace_aot_emit_A_const_131) {

																			jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_aot_emit_A_const_167); lang.IFn_Cast(A_arbace_aot_emit_A_const_161.GetRawRoot__O()).Invoke_O_O__O(sb__0, v__2)
//line :297:1
																			break L1 }; case 59: if any(G__90000063__10_) == any(A_arbace_aot_emit_A_const_145) {

























																				var tmp51 lang.IFn = lang.IFn_Cast(arr__7); var tmp52 any = A_arbace_aot_emit_A_const_187; tmp51.Invoke_O_O__O(tmp52, lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()).Invoke_O__O(v__2))
//line :297:1
																				break L1 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_241, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__90000063__10_)))))
		}






























			if m_QMARK___9 { lang.IFn_Cast(A_arbace_aot_emit_A_const_157.GetRawRoot__O()).Invoke_O_O_O__O(sb__0, shared__1, m__8) }
//line :288:1
			return sb__0 } }


func A_arbace_aot_emit_pool_encode_num__90000055_A_New_O(p0 any) *A_arbace_aot_emit_pool_encode_num__90000055_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_pool_encode_num__90000055_A{}; t.Ctor_O(p0); return t }
//line :291:1
func (t *A_arbace_aot_emit_pool_encode_num__90000055_A) Ctor_O(c__sb any) { t.F_sb = c__sb }
//line :291:1
func (t *A_arbace_aot_emit_pool_encode_num__90000055_A) Invoke_O_O_O__O(self, tag__1, n__2 any) any { return jrt.NN(jrt.NN(jrt.NN(jrt.StringBuilder_Cast(t.F_sb)).Append_O__StringBuilder(tag__1)).Append_J__StringBuilder(lang.RT_LongCast_O__J(n__2))).Append_O__StringBuilder(A_arbace_aot_emit_A_const_151).Ref() }
func A_arbace_aot_emit_pool_encode_arr__90000057_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_pool_encode_arr__90000057_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_pool_encode_arr__90000057_A{}; t.Ctor_O_O(p0, p1); return t }
//line :292:1
func (t *A_arbace_aot_emit_pool_encode_arr__90000057_A) Ctor_O_O(c__shared, c__sb any) { t.F_shared = c__shared; t.F_sb = c__sb }
//line :292:1
func (t *A_arbace_aot_emit_pool_encode_arr__90000057_A) Invoke_O_O_O__O(self, tag__1, xs__2 any) any { jrt.NN(jrt.StringBuilder_Cast(t.F_sb)).Append_O__StringBuilder(tag__1); { var tmp1 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp1).Append_J__StringBuilder(lang.RT_LongCast_I__J(lang.RT_Count_O__I(xs__2))); jrt.NN(jrt.StringBuilder_Cast(t.F_sb)).Append_O__StringBuilder(A_arbace_aot_emit_A_const_151); var seq_90000058__3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(xs__2); var chunk_90000059__4 any; var count_90000060__5 int64 = 0; var i_90000061__6 int64 = 0; L1: for {
													if lang.Numbers_Lt_J_J__Z(i_90000061__6, count_90000060__5) { var x__7 any = lang.Indexed_Cast(chunk_90000059__4).Nth_I__O(lang.RT_IntCast_J__I(i_90000061__6)); lang.IFn_Cast(A_arbace_aot_emit_A_const_157.GetRawRoot__O()).Invoke_O_O_O__O(t.F_sb, t.F_shared, x__7); seq_90000058__3, chunk_90000059__4, count_90000060__5, i_90000061__6 = seq_90000058__3, chunk_90000059__4, count_90000060__5, lang.Numbers_Unchecked_inc_J__J(i_90000061__6); continue L1 } else { var temp__1927000414__auto____7 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(seq_90000058__3); if jrt.A2g_Truth(temp__1927000414__auto____7) { var seq_90000058__8 any = temp__1927000414__auto____7; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(seq_90000058__8)) { var c__1927000678__auto____9 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(seq_90000058__8); seq_90000058__3, chunk_90000059__4, count_90000060__5, i_90000061__6 = lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(seq_90000058__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var x__9 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(seq_90000058__8); lang.IFn_Cast(A_arbace_aot_emit_A_const_157.GetRawRoot__O()).Invoke_O_O_O__O(t.F_sb, t.F_shared, x__9); seq_90000058__3, chunk_90000059__4, count_90000060__5, i_90000061__6 = lang.IFn_Cast(A_arbace_aot_emit_A_const_159.GetRawRoot__O()).Invoke_O__O(seq_90000058__8), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :292:1*/panic("a2g: unreachable") }
































func A_arbace_aot_emit_pool_encode_fn__90000064_A_New_O(p0 any) *A_arbace_aot_emit_pool_encode_fn__90000064_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_pool_encode_fn__90000064_A{}; t.Ctor_O(p0); return t }
//line :325:1
func (t *A_arbace_aot_emit_pool_encode_fn__90000064_A) Ctor_O(c__v any) { t.F_v = c__v }
//line :325:1
func (t *A_arbace_aot_emit_pool_encode_fn__90000064_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_61.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_v; t.F_v = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); lang.IFn_Cast(A_arbace_aot_emit_A_const_62.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }






func A_arbace_aot_emit_pool_fields_A_New() *A_arbace_aot_emit_pool_fields_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_pool_fields_A{}; t.Ctor(); return t }
//line :332:1
func (t *A_arbace_aot_emit_pool_fields_A) Ctor() {}
//line :332:1
func (t *A_arbace_aot_emit_pool_fields_A) Invoke_O_O__O(self, consts__0 any) any {



	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(consts__0)) { var seen__2 any = jrt.LinkedHashSet_New(); var walk__3 any; var tmp1 any = A_arbace_aot_emit_pool_fields_walk__90000067_A_New_O(seen__2); var tmp2 *jrt.Class
		var fncls__13 /*line :336:1*/*jrt.Class = A_arbace_aot_emit_pool_fields_walk__90000067_A_fn_class


		if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_242, false); A_arbace_aot_emit_pool_fields_walk__90000067_A_fn_class = fncls__13d; tmp2 = fncls__13d } else { tmp2 = fncls__13 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :336:1
		var ___4 any; var tmp3 any = A_arbace_aot_emit_pool_fields_fn__90000073_A_New_O_O(walk__3, consts__0); var tmp4 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_aot_emit_pool_fields_fn__90000073_A_fn_class; _ = ___4





		if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_243, false); A_arbace_aot_emit_pool_fields_fn__90000073_A_fn_class = fncls__14d; tmp4 = fncls__14d } else { tmp4 = fncls__14 }; ___4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()
//line :336:1
		var sh__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()).Invoke_O__O(seen__2); var shared__6 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_190.GetRawRoot__O()); var tmp6 *lang.PersistentArrayMap







		lang.PersistentArrayMap_Init(); tmp6 = lang.PersistentArrayMap_EMPTY; var tmp7 any = tmp6.Ref(); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_192.GetRawRoot__O()); var tmp9 any = A_arbace_aot_emit_pool_fields_fn__90000081_A_New(); var tmp10 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_aot_emit_pool_fields_fn__90000081_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_244, false); A_arbace_aot_emit_pool_fields_fn__90000081_A_fn_class = fncls__17d; tmp10 = fncls__17d } else { tmp10 = fncls__17 }; shared__6 = tmp5.Invoke_O_O__O(tmp7, tmp8.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), sh__5))
//line :336:1
		var sb__7 any = jrt.StringBuilder_New(); var ___8 any; var tmp11 any = A_arbace_aot_emit_pool_fields_fn__90000087_A_New_O_O(sb__7, sh__5); var tmp12 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_aot_emit_pool_fields_fn__90000087_A_fn_class; _ = ___8









		if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_245, false); A_arbace_aot_emit_pool_fields_fn__90000087_A_fn_class = fncls__15d; tmp12 = fncls__15d } else { tmp12 = fncls__15 }; ___8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil).Invoke__O()
//line :336:1
		var base__9 int32 = lang.RT_Count_O__I(sh__5); var ___10 any; var tmp13 any = A_arbace_aot_emit_pool_fields_fn__90000093_A_New_O_O_O(sb__7, consts__0, shared__6); var tmp14 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_aot_emit_pool_fields_fn__90000093_A_fn_class; _ = ___10












		if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_246, false); A_arbace_aot_emit_pool_fields_fn__90000093_A_fn_class = fncls__16d; tmp14 = fncls__16d } else { tmp14 = fncls__16 }; ___10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil).Invoke__O()
//line :336:1
		var n__11 int64 = lang.Numbers_Add_J_J__J(int64(base__9), int64(lang.RT_Count_O__I(consts__0))); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()); var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp17 any = A_arbace_aot_emit_A_const_193; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp19 any = A_arbace_aot_emit_A_const_199; var tmp20 any = tmp16.Invoke_O_O_O__O(tmp17, lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_195, A_arbace_aot_emit_A_const_196), lang.IFn_Cast(A_arbace_aot_emit_A_const_94.GetRawRoot__O()).Invoke_O__O(lang.RT_Object_array_O__O1(A_arbace_aot_emit_A_const_31).Ref())), lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_197, A_arbace_aot_emit_A_const_198), lang.IFn_Cast(A_arbace_aot_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(sb__7), tmp18.Invoke_O_O__O(tmp19, jrt.Long_ValueOf_J__Long(n__11).Ref()))); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_192.GetRawRoot__O()); var tmp22 any = A_arbace_aot_emit_pool_fields_fn__90000102_A_New_I(base__9); var tmp23 *jrt.Class
		var fncls__18 /*line :336:1*/*jrt.Class = A_arbace_aot_emit_pool_fields_fn__90000102_A_fn_class

















		if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_247, false); A_arbace_aot_emit_pool_fields_fn__90000102_A_fn_class = fncls__18d; tmp23 = fncls__18d } else { tmp23 = fncls__18 }
//line :351:1
		return tmp15.Invoke_O_O__O(tmp20, tmp21.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil), consts__0)) } else {
//line :336:1
			return nil
		}
}
func A_arbace_aot_emit_pool_fields_walk__90000067_A_New_O(p0 any) *A_arbace_aot_emit_pool_fields_walk__90000067_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_pool_fields_walk__90000067_A{}; t.Ctor_O(p0); return t }
//line :339:1
func (t *A_arbace_aot_emit_pool_fields_walk__90000067_A) Ctor_O(c__seen any) { t.F_seen = c__seen }
//line :339:1
func (t *A_arbace_aot_emit_pool_fields_walk__90000067_A) Invoke_O_O__O(self, v__1 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_152.GetRawRoot__O()).Invoke_O__O(v__1)) { jrt.Boolean_ValueOf_Z__Boolean(jrt.HashSet_Cast(t.F_seen).Add_O__Z(v__1)) }
	return lang.IFn_Cast(A_arbace_aot_emit_A_const_188.GetRawRoot__O()).Invoke_O_O__O(self, lang.IFn_Cast(A_arbace_aot_emit_A_const_189.GetRawRoot__O()).Invoke_O__O(v__1)) }
func A_arbace_aot_emit_pool_fields_fn__90000073_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_pool_fields_fn__90000073_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_pool_fields_fn__90000073_A{}; t.Ctor_O_O(p0, p1); return t }
//line :342:1
func (t *A_arbace_aot_emit_pool_fields_fn__90000073_A) Ctor_O_O(c__walk, c__consts any) { t.F_walk = c__walk; t.F_consts = c__consts }
//line :342:1
func (t *A_arbace_aot_emit_pool_fields_fn__90000073_A) Invoke_O__O(self any) any { { var seq_90000069__1 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_consts; t.F_consts = nil; tmp2 = t_; seq_90000069__1 = tmp1.Invoke_O__O(tmp2); var chunk_90000070__2 any; var count_90000071__3 int64 = 0; var i_90000072__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z(i_90000072__4, count_90000071__3) { var vec__90000074__5 any = lang.Indexed_Cast(chunk_90000070__2).Nth_I__O(lang.RT_IntCast_J__I(i_90000072__4)); var ___6 any = lang.RT_Nth_O_I_O__O(vec__90000074__5, lang.RT_IntCast_J__I(0), nil); var ___7 any = lang.RT_Nth_O_I_O__O(vec__90000074__5, lang.RT_IntCast_J__I(1), nil); var v__8 any = lang.RT_Nth_O_I_O__O(vec__90000074__5, lang.RT_IntCast_J__I(2), nil); _ = ___6; _ = ___7; lang.IFn_Cast(t.F_walk).Invoke_O__O(v__8); seq_90000069__1, chunk_90000070__2, count_90000071__3, i_90000072__4 = seq_90000069__1, chunk_90000070__2, count_90000071__3, lang.Numbers_Unchecked_inc_J__J(i_90000072__4); continue L1 } else { var temp__1927000414__auto____5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(seq_90000069__1); if jrt.A2g_Truth(temp__1927000414__auto____5) { var seq_90000069__6 any = temp__1927000414__auto____5; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(seq_90000069__6)) { var c__1927000678__auto____7 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(seq_90000069__6); seq_90000069__1, chunk_90000070__2, count_90000071__3, i_90000072__4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(seq_90000069__6), c__1927000678__auto____7, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__90000077__7 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(seq_90000069__6); var ___8 any = lang.RT_Nth_O_I_O__O(vec__90000077__7, lang.RT_IntCast_J__I(0), nil); var ___9 any = lang.RT_Nth_O_I_O__O(vec__90000077__7, lang.RT_IntCast_J__I(1), nil); var v__10 any = lang.RT_Nth_O_I_O__O(vec__90000077__7, lang.RT_IntCast_J__I(2), nil); _ = ___8; _ = ___9; lang.IFn_Cast(t.F_walk).Invoke_O__O(v__10); seq_90000069__1, chunk_90000070__2, count_90000071__3, i_90000072__4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_159.GetRawRoot__O()).Invoke_O__O(seq_90000069__6), nil, 0, 0; continue L1 } } else { return nil } } } }; panic("a2g: unreachable") }

func A_arbace_aot_emit_pool_fields_fn__90000081_A_New() *A_arbace_aot_emit_pool_fields_fn__90000081_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_pool_fields_fn__90000081_A{}; t.Ctor(); return t }
//line :344:1
func (t *A_arbace_aot_emit_pool_fields_fn__90000081_A) Ctor() {}
//line :344:1
func (t *A_arbace_aot_emit_pool_fields_fn__90000081_A) Invoke_O_O_O__O(self, i__1, v__2 any) any { return lang.Tuple_Create_O_O__IPersistentVector(v__2, i__1) }

func A_arbace_aot_emit_pool_fields_fn__90000087_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_pool_fields_fn__90000087_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_pool_fields_fn__90000087_A{}; t.Ctor_O_O(p0, p1); return t }
//line :346:1
func (t *A_arbace_aot_emit_pool_fields_fn__90000087_A) Ctor_O_O(c__sb, c__sh any) { t.F_sb = c__sb; t.F_sh = c__sh }
//line :346:1
func (t *A_arbace_aot_emit_pool_fields_fn__90000087_A) Invoke_O__O(self any) any { { var seq_90000083__1 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_sh; t.F_sh = nil; tmp2 = t_; seq_90000083__1 = tmp1.Invoke_O__O(tmp2); var chunk_90000084__2 any; var count_90000085__3 int64 = 0; var i_90000086__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z(i_90000086__4, count_90000085__3) { var v__5 any = lang.Indexed_Cast(chunk_90000084__2).Nth_I__O(lang.RT_IntCast_J__I(i_90000086__4)); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_157.GetRawRoot__O()); var tmp4 any = t.F_sb; var tmp5 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp5 = lang.PersistentArrayMap_EMPTY; tmp3.Invoke_O_O_O__O(tmp4, tmp5.Ref(), v__5); seq_90000083__1, chunk_90000084__2, count_90000085__3, i_90000086__4 = seq_90000083__1, chunk_90000084__2, count_90000085__3, lang.Numbers_Unchecked_inc_J__J(i_90000086__4); continue L1 } else { var temp__1927000414__auto____5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(seq_90000083__1); if jrt.A2g_Truth(temp__1927000414__auto____5) { var seq_90000083__6 any = temp__1927000414__auto____5; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(seq_90000083__6)) { var c__1927000678__auto____7 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(seq_90000083__6); seq_90000083__1, chunk_90000084__2, count_90000085__3, i_90000086__4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(seq_90000083__6), c__1927000678__auto____7, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var v__7 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(seq_90000083__6); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_157.GetRawRoot__O()); var tmp7 any = t.F_sb; var tmp8 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp8 = lang.PersistentArrayMap_EMPTY; tmp6.Invoke_O_O_O__O(tmp7, tmp8.Ref(), v__7); seq_90000083__1, chunk_90000084__2, count_90000085__3, i_90000086__4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_159.GetRawRoot__O()).Invoke_O__O(seq_90000083__6), nil, 0, 0; continue L1 } } else { return nil } } } }; panic("a2g: unreachable") }


func A_arbace_aot_emit_pool_fields_fn__90000093_A_New_O_O_O(p0, p1, p2 any) *A_arbace_aot_emit_pool_fields_fn__90000093_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_pool_fields_fn__90000093_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :349:1
func (t *A_arbace_aot_emit_pool_fields_fn__90000093_A) Ctor_O_O_O(c__sb, c__consts, c__shared any) { t.F_sb = c__sb; t.F_consts = c__consts; t.F_shared = c__shared }
//line :349:1
func (t *A_arbace_aot_emit_pool_fields_fn__90000093_A) Invoke_O__O(self any) any { { var seq_90000089__1 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_consts; t.F_consts = nil; tmp2 = t_; seq_90000089__1 = tmp1.Invoke_O__O(tmp2); var chunk_90000090__2 any; var count_90000091__3 int64 = 0; var i_90000092__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z(i_90000092__4, count_90000091__3) { var vec__90000094__5 any = lang.Indexed_Cast(chunk_90000090__2).Nth_I__O(lang.RT_IntCast_J__I(i_90000092__4)); var ___6 any = lang.RT_Nth_O_I_O__O(vec__90000094__5, lang.RT_IntCast_J__I(0), nil); var ___7 any = lang.RT_Nth_O_I_O__O(vec__90000094__5, lang.RT_IntCast_J__I(1), nil); var v__8 any = lang.RT_Nth_O_I_O__O(vec__90000094__5, lang.RT_IntCast_J__I(2), nil); _ = ___6; _ = ___7; lang.IFn_Cast(A_arbace_aot_emit_A_const_157.GetRawRoot__O()).Invoke_O_O_O__O(t.F_sb, t.F_shared, v__8); seq_90000089__1, chunk_90000090__2, count_90000091__3, i_90000092__4 = seq_90000089__1, chunk_90000090__2, count_90000091__3, lang.Numbers_Unchecked_inc_J__J(i_90000092__4); continue L1 } else { var temp__1927000414__auto____5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(seq_90000089__1); if jrt.A2g_Truth(temp__1927000414__auto____5) { var seq_90000089__6 any = temp__1927000414__auto____5; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(seq_90000089__6)) { var c__1927000678__auto____7 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(seq_90000089__6); seq_90000089__1, chunk_90000090__2, count_90000091__3, i_90000092__4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(seq_90000089__6), c__1927000678__auto____7, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__90000097__7 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(seq_90000089__6); var ___8 any = lang.RT_Nth_O_I_O__O(vec__90000097__7, lang.RT_IntCast_J__I(0), nil); var ___9 any = lang.RT_Nth_O_I_O__O(vec__90000097__7, lang.RT_IntCast_J__I(1), nil); var v__10 any = lang.RT_Nth_O_I_O__O(vec__90000097__7, lang.RT_IntCast_J__I(2), nil); _ = ___8; _ = ___9; lang.IFn_Cast(A_arbace_aot_emit_A_const_157.GetRawRoot__O()).Invoke_O_O_O__O(t.F_sb, t.F_shared, v__10); seq_90000089__1, chunk_90000090__2, count_90000091__3, i_90000092__4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_159.GetRawRoot__O()).Invoke_O__O(seq_90000089__6), nil, 0, 0; continue L1 } } else { return nil } } } }; panic("a2g: unreachable") }




func A_arbace_aot_emit_pool_fields_fn__90000102_A_New_I(p0 int32) *A_arbace_aot_emit_pool_fields_fn__90000102_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_pool_fields_fn__90000102_A{}; t.Ctor_I(p0); return t }
//line :354:1
func (t *A_arbace_aot_emit_pool_fields_fn__90000102_A) Ctor_I(c__base int32) { t.F_base = c__base }
//line :354:1
func (t *A_arbace_aot_emit_pool_fields_fn__90000102_A) Invoke_O_O_O__O(self, i__1, p__90000101__2 any) any { var vec__90000103__3 any = p__90000101__2; var s__4 any = lang.RT_Nth_O_I_O__O(vec__90000103__3, lang.RT_IntCast_J__I(0), nil); var t__5 any = lang.RT_Nth_O_I_O__O(vec__90000103__3, lang.RT_IntCast_J__I(1), nil); var ___6 any = lang.RT_Nth_O_I_O__O(vec__90000103__3, lang.RT_IntCast_J__I(2), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp2 any = A_arbace_aot_emit_A_const_200; var tmp3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(s__4, A_arbace_aot_emit_A_const_202), t__5); var tmp4 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp6 any = A_arbace_aot_emit_A_const_203; var tmp7 any = A_arbace_aot_emit_A_const_204; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp9 any = A_arbace_aot_emit_A_const_205; var e__7 any = tmp5.Invoke_O_O_O__O(tmp6, tmp7, tmp8.Invoke_O_O__O(tmp9, lang.Numbers_Add_J_O__Number(int64(t.F_base), i__1))); _ = ___6; if


	lang.Util_Equiv_O_O__Z(t__5, A_arbace_aot_emit_A_const_201) { tmp4 = e__7 } else { tmp4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_aot_emit_A_const_206, t__5, e__7) }; return /*line :355:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4) }




func A_arbace_aot_emit_const_type_A_New() *A_arbace_aot_emit_const_type_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_const_type_A{}; t.Ctor(); return t }
//line :360:1
func (t *A_arbace_aot_emit_const_type_A) Ctor() {}
//line :360:1
func (t *A_arbace_aot_emit_const_type_A) Invoke_O_O__O(self, v__0 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_54.GetRawRoot__O()).Invoke_O__O(v__0)) { return A_arbace_aot_emit_A_const_207 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_53.GetRawRoot__O()).Invoke_O__O(v__0)) { return A_arbace_aot_emit_A_const_208 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_51.GetRawRoot__O()).Invoke_O__O(v__0)) { return A_arbace_aot_emit_A_const_209 } else { if A_arbace_aot_emit_A_const_60 != nil { return A_arbace_aot_emit_A_const_210 } else { return nil
	}
	}
	}
	} }
func A_arbace_aot_emit_constant_A_New() *A_arbace_aot_emit_constant_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_constant_A{}; t.Ctor(); return t }
//line :366:1
func (t *A_arbace_aot_emit_constant_A) Ctor() {}
//line :366:1
func (t *A_arbace_aot_emit_constant_A) Invoke_O_O_O__O(self, ctx__0, v__1 any) any {
	var tmp1 any; var or__1927000174__auto____3 bool = lang.Util_Identical_O_O__Z(v__1, nil)
	if or__1927000174__auto____3 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____3).Ref() } else { tmp1 = lang.IFn_Cast(A_arbace_aot_emit_A_const_50.GetRawRoot__O()).Invoke_O__O(v__1) }
//line :367:1
	if jrt.A2g_Truth(tmp1) { return v__1 } else { var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_51.GetRawRoot__O()).Invoke_O__O(v__1)



		if jrt.A2g_Truth(and__1927000168__auto____3) { tmp2 = lang.IFn_Cast(A_arbace_aot_emit_A_const_211.GetRawRoot__O()).Invoke_O_O__O(v__1, ctx__0) } else { tmp2 = and__1927000168__auto____3 }
//line :367:1
		if jrt.A2g_Truth(tmp2) {




			return lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_213, A_arbace_aot_emit_A_const_214), lang.IFn_Cast(A_arbace_aot_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(v__1)).GetName__String().Ref())) } else {
//line :367:1
				if A_arbace_aot_emit_A_const_60 != nil {






					return lang.IFn_Cast(A_arbace_aot_emit_A_const_212.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, v__1, lang.IFn_Cast(A_arbace_aot_emit_A_const_215.GetRawRoot__O()).Invoke_O__O(v__1)) } else {
//line :367:1
						return nil
					}
			}
	}
}







func A_arbace_aot_emit_gsym_A_New() *A_arbace_aot_emit_gsym_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_gsym_A{}; t.Ctor(); return t }
//line :379:1
func (t *A_arbace_aot_emit_gsym_A) Ctor() {}
//line :379:1
func (t *A_arbace_aot_emit_gsym_A) Invoke_O_O_O__O(self, ctx__0, base__1 any) any { var cls__3 any = A_arbace_aot_emit_A_const_38.Invoke_O__O(ctx__0); var tmp1 *lang.Keyword = A_arbace_aot_emit_A_const_216; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_27.GetRawRoot__O()); var tmp3 any = A_arbace_aot_emit_A_const_39.GetRawRoot__O(); var tmp4 any = A_arbace_aot_emit_A_const_216; var k__4 any = tmp1.Invoke_O__O(tmp2.Invoke_O_O_O_O__O(cls__3, tmp3, tmp4, lang.IFn_Cast(A_arbace_aot_emit_A_const_217.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_218.GetRawRoot__O(), A_arbace_aot_emit_A_const_31))); return /*line :385:1*/ lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, base__1, k__4)).Ref()) }

func A_arbace_aot_emit_local_sym_A_New() *A_arbace_aot_emit_local_sym_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_local_sym_A{}; t.Ctor(); return t }
//line :387:1
func (t *A_arbace_aot_emit_local_sym_A) Ctor() {}
//line :387:1
func (t *A_arbace_aot_emit_local_sym_A) Invoke_O_O__O(self, b__0 any) any {



	return lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_128, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_aot_emit_A_const_34.Invoke_O__O(b__0), nil, A_arbace_aot_emit_A_const_219.Invoke_O__O(b__0))).Ref())
}
func A_arbace_aot_emit_identity_set_A_New() *A_arbace_aot_emit_identity_set_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_identity_set_A{}; t.Ctor(); return t }
//line :393:1
func (t *A_arbace_aot_emit_identity_set_A) Ctor() {}
//line :393:1
func (t *A_arbace_aot_emit_identity_set_A) Invoke_O_O__O(self, xs__0 any) any { var m__2 any = jrt.IdentityHashMap_New(); var seq_90000112__3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(xs__0); var chunk_90000113__4 any; var count_90000114__5 int64 = 0; var i_90000115__6 int64 = 0; L1: for {





	if lang.Numbers_Lt_J_J__Z(i_90000115__6, count_90000114__5) { var x__7 any = lang.Indexed_Cast(chunk_90000113__4).Nth_I__O(lang.RT_IntCast_J__I(i_90000115__6)); var tmp1 *jrt.IdentityHashMap = jrt.IdentityHashMap_Cast(m__2); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; jrt.NN(tmp1).Put_O_O__O(x__7, tmp2.Ref()); seq_90000112__3, chunk_90000113__4, count_90000114__5, i_90000115__6 = seq_90000112__3, chunk_90000113__4, count_90000114__5, lang.Numbers_Unchecked_inc_J__J(i_90000115__6); continue L1 } else { var temp__1927000414__auto____7 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(seq_90000112__3); if jrt.A2g_Truth(temp__1927000414__auto____7) { var seq_90000112__8 any = temp__1927000414__auto____7; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(seq_90000112__8)) { var c__1927000678__auto____9 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(seq_90000112__8); seq_90000112__3, chunk_90000113__4, count_90000114__5, i_90000115__6 = lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(seq_90000112__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var x__9 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(seq_90000112__8); var tmp3 *jrt.IdentityHashMap = jrt.IdentityHashMap_Cast(m__2); var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_TRUE; jrt.NN(tmp3).Put_O_O__O(x__9, tmp4.Ref()); seq_90000112__3, chunk_90000113__4, count_90000114__5, i_90000115__6 = lang.IFn_Cast(A_arbace_aot_emit_A_const_159.GetRawRoot__O()).Invoke_O__O(seq_90000112__8), nil, 0, 0; continue L1 } } }
//line :393:1
	break L1 }; return m__2 }








func A_arbace_aot_emit_closed_QMARK__A_New() *A_arbace_aot_emit_closed_QMARK__A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_closed_QMARK__A{}; t.Ctor(); return t }
//line :402:1
func (t *A_arbace_aot_emit_closed_QMARK__A) Ctor() {}
//line :402:1
func (t *A_arbace_aot_emit_closed_QMARK__A) Invoke_O_O_O__O(self, ctx__0, lb__1 any) any { var temp__1927000414__auto____3 any = A_arbace_aot_emit_A_const_220.Invoke_O__O(ctx__0); if
												jrt.A2g_Truth(temp__1927000414__auto____3) { var s__4 any = temp__1927000414__auto____3
													return jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.IdentityHashMap_Cast(s__4)).ContainsKey_O__Z(lb__1)).Ref() } else {
//line :403:1
			return nil } }


func A_arbace_aot_emit_field_sym_A_New() *A_arbace_aot_emit_field_sym_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_field_sym_A{}; t.Ctor(); return t }
//line :406:1
func (t *A_arbace_aot_emit_field_sym_A) Ctor() {}
//line :406:1
func (t *A_arbace_aot_emit_field_sym_A) Invoke_O_O__O(self, b__0 any) any { return lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_84, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_aot_emit_A_const_34.Invoke_O__O(b__0))).Ref()) }

func A_arbace_aot_emit_field_read_A_New() *A_arbace_aot_emit_field_read_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_field_read_A{}; t.Ctor(); return t }
//line :408:1
func (t *A_arbace_aot_emit_field_read_A) Ctor() {}
//line :408:1
func (t *A_arbace_aot_emit_field_read_A) Invoke_O_O_O_O__O(self, ctx__0, lb__1, b__2 any) any {
	return lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_221.GetRawRoot__O()).Invoke_O__O(b__2), A_arbace_aot_emit_A_const_222)
}





func A_arbace_aot_emit_prim_A_New() *A_arbace_aot_emit_prim_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_prim_A{}; t.Ctor(); return t }
//line :416:1
func (t *A_arbace_aot_emit_prim_A) Ctor() {}
//line :416:1
func (t *A_arbace_aot_emit_prim_A) Invoke_O_O__O(self, e__0 any) any { var tmp1 *lang.Keyword = A_arbace_aot_emit_A_const_223; return tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(e__0)) }

func A_arbace_aot_emit_can_prim_QMARK__A_New() *A_arbace_aot_emit_can_prim_QMARK__A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_can_prim_QMARK__A{}; t.Ctor(); return t }
//line :418:1
func (t *A_arbace_aot_emit_can_prim_QMARK__A) Ctor() {}
//line :418:1
func (t *A_arbace_aot_emit_can_prim_QMARK__A) Invoke_O_O__O(self, n__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(A_arbace_aot_emit_A_const_225.Invoke_O__O(n__0))).Ref() }



func A_arbace_aot_emit_box_A_New() *A_arbace_aot_emit_box_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_box_A{}; t.Ctor(); return t }
//line :422:1
func (t *A_arbace_aot_emit_box_A) Ctor() {}
//line :422:1
func (t *A_arbace_aot_emit_box_A) Invoke_O_O_O__O(self, f__0, c__1 any) any {



	var tmp1 *jrt.Class; jrt.Void_Init(); tmp1 = jrt.Void_TYPE; if lang.Util_Equiv_O_O__Z(c__1, tmp1.Ref()) {
		return lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_aot_emit_A_const_226, f__0, nil) } else {
//line :426:1
			if jrt.NN(jrt.Class_Cast(c__1)).IsPrimitive__Z() {

				var tmp2 any = A_arbace_aot_emit_A_const_103; return lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_227.GetRawRoot__O()).Invoke_O__O(c__1), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_aot_emit_A_const_24.GetRawRoot__O()).Invoke_O__O(c__1))))), f__0) } else {
//line :426:1
					if A_arbace_aot_emit_A_const_60 != nil { return f__0 } else { return nil
					}
				}
		}
}
func A_arbace_aot_emit_unbox_arg_A_New() *A_arbace_aot_emit_unbox_arg_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_unbox_arg_A{}; t.Ctor(); return t }
//line :431:1
func (t *A_arbace_aot_emit_unbox_arg_A) Ctor() {}
//line :431:1
func (t *A_arbace_aot_emit_unbox_arg_A) Invoke_O_O_O_O__O(self, ctx__0, f__1, p__2 any) any {


	if lang.Util_Equiv_O_O__Z(p__2, A_arbace_aot_emit_A_const_228) { return f__1 } else { var tmp1 *jrt.Class; jrt.Boolean_Init(); tmp1 = jrt.Boolean_TYPE; if lang.Util_Equiv_O_O__Z(p__2, tmp1.Ref()) {

		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp3 any = A_arbace_aot_emit_A_const_230; return tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_aot_emit_A_const_231, A_arbace_aot_emit_A_const_232, f__1)) } else {
//line :434:1
			var tmp4 *jrt.Class; jrt.Character_Init(); tmp4 = jrt.Character_TYPE; if lang.Util_Equiv_O_O__Z(p__2, tmp4.Ref()) {


				var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp6 any = A_arbace_aot_emit_A_const_233; return tmp5.Invoke_O_O__O(tmp6, lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_aot_emit_A_const_234, A_arbace_aot_emit_A_const_235, f__1)) } else {
//line :434:1
					if jrt.NN(jrt.Class_Cast(p__2)).IsPrimitive__Z() { var unchecked__4 any = A_arbace_aot_emit_A_const_229.Invoke_O__O(ctx__0); var m__5 any; var tmp7 *jrt.Class





						jrt.Integer_Init(); tmp7 = jrt.Integer_TYPE; var tmp8 any = tmp7.Ref(); var tmp9 *jrt.String; if jrt.A2g_Truth(unchecked__4) { tmp9 = Lit_257 } else { tmp9 = Lit_258 }; var tmp10 any = tmp9.Ref(); var tmp11 *jrt.Class; jrt.Float_Init(); tmp11 = jrt.Float_TYPE; var tmp12 any = tmp11.Ref(); var tmp13 *jrt.String
						if jrt.A2g_Truth(unchecked__4) { tmp13 = Lit_259 } else { tmp13 = Lit_260 }
//line :440:1
						var tmp14 any = tmp13.Ref(); var tmp15 *jrt.Class; jrt.Double_Init(); tmp15 = jrt.Double_TYPE; var tmp16 any = tmp15.Ref(); var tmp17 *jrt.String

						if jrt.A2g_Truth(unchecked__4) { tmp17 = Lit_261 } else { tmp17 = Lit_262 }
//line :440:1
						var tmp18 any = tmp17.Ref(); var tmp19 *jrt.Class; jrt.Long_Init(); tmp19 = jrt.Long_TYPE; var tmp20 any = tmp19.Ref(); var tmp21 *jrt.String


						if jrt.A2g_Truth(unchecked__4) { tmp21 = Lit_263 } else { tmp21 = Lit_264 }
//line :440:1
						var tmp22 any = tmp21.Ref(); var tmp23 *jrt.Class; jrt.Byte_Init(); tmp23 = jrt.Byte_TYPE; var tmp24 any = tmp23.Ref(); var tmp25 *jrt.String



						if jrt.A2g_Truth(unchecked__4) { tmp25 = Lit_265 } else { tmp25 = Lit_266 }
//line :440:1
						var tmp26 any = tmp25.Ref(); var tmp27 *jrt.Class; jrt.Short_Init(); tmp27 = jrt.Short_TYPE; var tmp28 any = tmp27.Ref(); var tmp29 *jrt.String




						if jrt.A2g_Truth(unchecked__4) { tmp29 = Lit_267 } else { tmp29 = Lit_268 }
//line :440:1
						m__5 = lang.IFn_Cast(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp10, tmp12, tmp14, tmp16, tmp18, tmp20, tmp22, tmp24, tmp26, tmp28, tmp29.Ref()))).Invoke_O__O(p__2)





						return lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O_O__O(Lit_269, m__5), A_arbace_aot_emit_A_const_236), f__1) } else {
//line :434:1
							var tmp30 any; var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_211.GetRawRoot__O()).Invoke_O_O__O(p__2, ctx__0)












							if jrt.A2g_Truth(or__1927000174__auto____4) { tmp30 = or__1927000174__auto____4 } else { tmp30 = lang.IFn_Cast(A_arbace_aot_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_237.GetRawRoot__O()).Invoke_O__O(p__2)) }
//line :434:1
							if jrt.A2g_Truth(tmp30) { return f__1 } else { if A_arbace_aot_emit_A_const_60 != nil {













								var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp32 any = A_arbace_aot_emit_A_const_238; return tmp31.Invoke_O_O_O__O(tmp32, lang.IFn_Cast(A_arbace_aot_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(p__2), f__1) } else {
//line :434:1
									return nil
								}
							}
						}
				}
		}
	}
}








func A_arbace_aot_emit_fi_QMARK__A_New() *A_arbace_aot_emit_fi_QMARK__A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_fi_QMARK__A{}; t.Ctor(); return t }
//line :450:1
func (t *A_arbace_aot_emit_fi_QMARK__A) Ctor() {}
//line :450:1
func (t *A_arbace_aot_emit_fi_QMARK__A) Invoke_O_O__O(self, p__0 any) any { var and__1927000168__auto____2 bool = jrt.NN(jrt.Class_Cast(p__0)).IsInterface__Z(); if and__1927000168__auto____2 {




	return lang.IFn_Cast(A_arbace_aot_emit_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.Reflector_InvokeStaticMethod_String_String_O1__O(Lit_193, Lit_210, lang.RT_Object_array_O__O1(lang.Tuple_Create_O__IPersistentVector(p__0)))) } else {
//line :454:1
		return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() } }


func A_arbace_aot_emit_typed_args_A_New() *A_arbace_aot_emit_typed_args_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_typed_args_A{}; t.Ctor(); return t }
//line :457:1
func (t *A_arbace_aot_emit_typed_args_A) Ctor() {}
//line :457:1
func (t *A_arbace_aot_emit_typed_args_A) Invoke_O_O_O_O__O(self, ctx__0, ps__1, es__2 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_43.GetRawRoot__O()); var tmp2 any = A_arbace_aot_emit_typed_args_fn__90000125_A_New_O(ctx__0); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_aot_emit_typed_args_fn__90000125_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_256, false); A_arbace_aot_emit_typed_args_fn__90000125_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), ps__1, es__2) }
//line :460:1
func A_arbace_aot_emit_typed_args_fn__90000125_A_New_O(p0 any) *A_arbace_aot_emit_typed_args_fn__90000125_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_typed_args_fn__90000125_A{}; t.Ctor_O(p0); return t }
//line :460:1
func (t *A_arbace_aot_emit_typed_args_fn__90000125_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :460:1
func (t *A_arbace_aot_emit_typed_args_fn__90000125_A) Invoke_O_O_O__O(self, p__1, e__2 any) any { var n__3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(e__2); var pc__4 any = A_arbace_aot_emit_A_const_223.Invoke_O__O(n__3); var tmp1 any; var and__1927000168__auto____5 any = pc__4; if



	jrt.A2g_Truth(and__1927000168__auto____5) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(pc__4, p__1)).Ref() } else { tmp1 = and__1927000168__auto____5 }; if /*line :463:1*/ jrt.A2g_Truth(tmp1) {
		return lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, e__2) } else {
//line :463:1
			var tmp2 bool; var and__1927000168__auto____5_2 bool; var tmp3 *jrt.Class

			jrt.Integer_Init(); tmp3 = jrt.Integer_TYPE; and__1927000168__auto____5_2 = lang.Util_Equiv_O_O__Z(pc__4, tmp3.Ref()); if and__1927000168__auto____5_2 { var tmp4 *jrt.Class; jrt.Long_Init(); tmp4 = jrt.Long_TYPE; tmp2 = lang.Util_Equiv_O_O__Z(p__1, tmp4.Ref()) } else { tmp2 = and__1927000168__auto____5_2 }
//line :463:1
			if tmp2 {

				return lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, e__2) } else {
//line :463:1
					var tmp5 bool; var and__1927000168__auto____5_3 bool; var tmp6 *jrt.Class


					jrt.Long_Init(); tmp6 = jrt.Long_TYPE; and__1927000168__auto____5_3 = lang.Util_Equiv_O_O__Z(pc__4, tmp6.Ref()); if and__1927000168__auto____5_3 { var tmp7 *jrt.Class; jrt.Integer_Init(); tmp7 = jrt.Integer_TYPE; tmp5 = lang.Util_Equiv_O_O__Z(p__1, tmp7.Ref()) } else { tmp5 = and__1927000168__auto____5_3 }
//line :463:1
					if tmp5 {



						var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()); var tmp10 any; if jrt.A2g_Truth(A_arbace_aot_emit_A_const_229.Invoke_O__O(t.F_ctx)) { tmp10 = A_arbace_aot_emit_A_const_243 } else { tmp10 = A_arbace_aot_emit_A_const_244 }; return tmp8.Invoke_O_O__O(tmp9.Invoke_O_O__O(tmp10, A_arbace_aot_emit_A_const_245), lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, e__2)) } else {
//line :463:1
							var tmp11 bool; var and__1927000168__auto____5_4 bool; var tmp12 *jrt.Class






							jrt.Float_Init(); tmp12 = jrt.Float_TYPE; and__1927000168__auto____5_4 = lang.Util_Equiv_O_O__Z(pc__4, tmp12.Ref()); if and__1927000168__auto____5_4 { var tmp13 *jrt.Class; jrt.Double_Init(); tmp13 = jrt.Double_TYPE; tmp11 = lang.Util_Equiv_O_O__Z(p__1, tmp13.Ref()) } else { tmp11 = and__1927000168__auto____5_4 }
//line :463:1
							if tmp11 {






								return lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, e__2) } else {
//line :463:1
									var tmp14 bool; var and__1927000168__auto____5_5 bool; var tmp15 *jrt.Class







									jrt.Double_Init(); tmp15 = jrt.Double_TYPE; and__1927000168__auto____5_5 = lang.Util_Equiv_O_O__Z(pc__4, tmp15.Ref()); if and__1927000168__auto____5_5 { var tmp16 *jrt.Class; jrt.Float_Init(); tmp16 = jrt.Float_TYPE; tmp14 = lang.Util_Equiv_O_O__Z(p__1, tmp16.Ref()) } else { tmp14 = and__1927000168__auto____5_5 }
//line :463:1
									if tmp14 {







										var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp18 any = A_arbace_aot_emit_A_const_246; return tmp17.Invoke_O_O__O(tmp18, lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, e__2)) } else {
//line :463:1
											if A_arbace_aot_emit_A_const_60 != nil { var f__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, e__2); var jc__6 any = A_arbace_aot_emit_A_const_137.Invoke_O__O(n__3); var tmp19 any; var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_241.GetRawRoot__O()).Invoke_O__O(p__1)











												if jrt.A2g_Truth(and__1927000168__auto____7) { var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_25.GetRawRoot__O()); var tmp21 any; var and__1927000168__auto____8 any = jc__6; if jrt.A2g_Truth(and__1927000168__auto____8) { tmp21 = jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.Class_Cast(p__1)).IsAssignableFrom_Class__Z(jrt.Class_Cast(jc__6))).Ref() } else { tmp21 = and__1927000168__auto____8 }; tmp19 = tmp20.Invoke_O__O(tmp21) } else { tmp19 = and__1927000168__auto____7 }; if jrt.A2g_Truth(tmp19) {

													var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_242.GetRawRoot__O()); var tmp23 any = t.F_ctx; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp25 any = A_arbace_aot_emit_A_const_247; return tmp22.Invoke_O_O_O__O(tmp23, tmp24.Invoke_O_O_O__O(tmp25, lang.IFn_Cast(A_arbace_aot_emit_A_const_248.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, p__1), f__5), p__1) } else {
														return lang.IFn_Cast(A_arbace_aot_emit_A_const_242.GetRawRoot__O()).Invoke_O_O_O__O(t.F_ctx, f__5, p__1) } } else {
//line :463:1
															return nil } } } } } } }

















func A_arbace_aot_emit_param_tags_A_New() *A_arbace_aot_emit_param_tags_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_param_tags_A{}; t.Ctor(); return t }
//line :481:1
func (t *A_arbace_aot_emit_param_tags_A) Ctor() {}
//line :481:1
func (t *A_arbace_aot_emit_param_tags_A) Invoke_O_O__O(self, ps__0 any) any { var tmp1 any = A_arbace_aot_emit_A_const_103; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, lang.IFn_Cast(A_arbace_aot_emit_A_const_43.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_20.GetRawRoot__O(), ps__0))) }

func A_arbace_aot_emit_obj_array_A_New() *A_arbace_aot_emit_obj_array_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_obj_array_A{}; t.Ctor(); return t }
//line :483:1
func (t *A_arbace_aot_emit_obj_array_A) Ctor() {}
//line :483:1
func (t *A_arbace_aot_emit_obj_array_A) Invoke_O_O_O__O(self, ctx__0, es__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp2 any = A_arbace_aot_emit_A_const_249; var tmp3 any = A_arbace_aot_emit_A_const_250; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_43.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_obj_array_fn__90000130_A_New_O(ctx__0); var tmp6 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_aot_emit_obj_array_fn__90000130_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_235, false); A_arbace_aot_emit_obj_array_fn__90000130_A_fn_class = fncls__20d; tmp6 = fncls__20d } else { tmp6 = fncls__20 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), es__1)) }
//line :484:1
func A_arbace_aot_emit_obj_array_fn__90000130_A_New_O(p0 any) *A_arbace_aot_emit_obj_array_fn__90000130_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_obj_array_fn__90000130_A{}; t.Ctor_O(p0); return t }
//line :484:1
func (t *A_arbace_aot_emit_obj_array_fn__90000130_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :484:1
func (t *A_arbace_aot_emit_obj_array_fn__90000130_A) Invoke_O_O__O(self, p1__90000129_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, p1__90000129_SHARP___1) }

func A_arbace_aot_emit_var_value_A_New() *A_arbace_aot_emit_var_value_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_var_value_A{}; t.Ctor(); return t }
//line :486:1
func (t *A_arbace_aot_emit_var_value_A) Ctor() {}
//line :486:1
func (t *A_arbace_aot_emit_var_value_A) Invoke_O_O_O__O(self, ctx__0, v__1 any) any { var c__3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_212.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, v__1, A_arbace_aot_emit_A_const_251); if

	jrt.NN(lang.Var_Cast(v__1)).IsDynamic__Z() { return lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_252, c__3) } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_253, c__3) } }

func A_arbace_aot_emit_line_meta_A_New() *A_arbace_aot_emit_line_meta_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_line_meta_A{}; t.Ctor(); return t }
//line :490:1
func (t *A_arbace_aot_emit_line_meta_A) Ctor() {}
//line :490:1
func (t *A_arbace_aot_emit_line_meta_A) Invoke_O_O_O__O(self, f__0, n__1 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_58.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp2 any; var or__1927000174__auto____4 any = A_arbace_aot_emit_A_const_254.Invoke_O__O(n__1); if jrt.A2g_Truth(or__1927000174__auto____4) { tmp2 = or__1927000174__auto____4 } else { tmp2 = A_arbace_aot_emit_A_const_31 }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsPos_O__Z(tmp2)).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp1) {
		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_22.GetRawRoot__O()); var tmp4 any = A_arbace_aot_emit_A_const_13.GetRawRoot__O(); var tmp5 any = A_arbace_aot_emit_A_const_255; return tmp3.Invoke_O_O_O_O__O(f__0, tmp4, tmp5, A_arbace_aot_emit_A_const_254.Invoke_O__O(n__1)) } else {
//line :491:1
			return f__0
		}
}

func A_arbace_aot_emit_emit_local_A_New() *A_arbace_aot_emit_emit_local_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_local_A{}; t.Ctor(); return t }
//line :495:1
func (t *A_arbace_aot_emit_emit_local_A) Ctor() {}
//line :495:1
func (t *A_arbace_aot_emit_emit_local_A) Invoke_O_O_O_O__O(self, ctx__0, n__1, unboxed_QMARK___2 any) any { var lb__4 any = A_arbace_aot_emit_A_const_256.Invoke_O__O(n__1); var b__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__4); if


	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_257.GetRawRoot__O()).Invoke_O_O__O(ctx__0, lb__4)) { var r__6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_258.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, lb__4, b__5); var tmp1 any; var and__1927000168__auto____7 any = A_arbace_aot_emit_A_const_259.Invoke_O__O(ctx__0)


		if jrt.A2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any = A_arbace_aot_emit_A_const_260.Invoke_O__O(n__1); if jrt.A2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any = A_arbace_aot_emit_A_const_261.Invoke_O__O(b__5); if jrt.A2g_Truth(and__1927000168__auto____9) { tmp1 = lang.IFn_Cast(A_arbace_aot_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_265.Invoke_O__O(b__5)) } else { tmp1 = and__1927000168__auto____9 } } else { tmp1 = and__1927000168__auto____8 } } else { tmp1 = and__1927000168__auto____7 }; if jrt.A2g_Truth(tmp1) {
			var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp3 any = A_arbace_aot_emit_A_const_266; return tmp2.Invoke_O_O_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(A_arbace_aot_emit_A_const_268, r__6), lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_aot_emit_A_const_269, r__6, nil), A_arbace_aot_emit_A_const_267) } else {
//line :501:1
				return r__6 } } else {
//line :498:1
					var tmp4 any; var and__1927000168__auto____6 bool = lang.Numbers_IsZero_O__Z(A_arbace_aot_emit_A_const_219.Invoke_O__O(b__5))





					if and__1927000168__auto____6 { tmp4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_270.Invoke_O__O(b__5)) } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____6).Ref() }
//line :498:1
					if jrt.A2g_Truth(tmp4) { var or__1927000174__auto____6 any = A_arbace_aot_emit_A_const_262.Invoke_O__O(ctx__0)





						if jrt.A2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else { return A_arbace_aot_emit_A_const_263 } } else {
//line :498:1
							if A_arbace_aot_emit_A_const_60 != nil {






								return lang.IFn_Cast(A_arbace_aot_emit_A_const_264.GetRawRoot__O()).Invoke_O__O(b__5) } else {
//line :498:1
									return nil } } } }








func A_arbace_aot_emit_emit_invoke_A_New() *A_arbace_aot_emit_emit_invoke_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_invoke_A{}; t.Ctor(); return t }
//line :507:1
func (t *A_arbace_aot_emit_emit_invoke_A) Ctor() {}
//line :507:1
func (t *A_arbace_aot_emit_emit_invoke_A) Invoke_O_O_O__O(self, ctx__0, n__1 any) any { var args__3 any = A_arbace_aot_emit_A_const_271.Invoke_O__O(n__1); var fexpr__4 any = A_arbace_aot_emit_A_const_272.Invoke_O__O(n__1); var call__5 any; var tmp1 any = A_arbace_aot_emit_emit_invoke_call__90000138_A_New_O_O(ctx__0, args__3); var tmp2 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_aot_emit_emit_invoke_call__90000138_A_fn_class; if


	fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_152, false); A_arbace_aot_emit_emit_invoke_call__90000138_A_fn_class = fncls__22d; tmp2 = fncls__22d } else { tmp2 = fncls__22 }; call__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 any; var and__1927000168__auto____6 any =





	A_arbace_aot_emit_A_const_282.Invoke_O__O(n__1); if jrt.A2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any = A_arbace_aot_emit_A_const_283.Invoke_O__O(n__1); if jrt.A2g_Truth(and__1927000168__auto____7) { tmp3 = lang.IFn_Cast(A_arbace_aot_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_211.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_283.Invoke_O__O(n__1), ctx__0)) } else { tmp3 = and__1927000168__auto____7 } } else { tmp3 = and__1927000168__auto____6 }; if jrt.A2g_Truth(tmp3) { var m__6 any = A_arbace_aot_emit_A_const_284.Invoke_O__O(n__1); var on__7 any = A_arbace_aot_emit_A_const_283.Invoke_O__O(n__1); var t__8 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_285.GetRawRoot__O()).Invoke_O_O__O(ctx__0, Lit_151); var rest_args__9 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(args__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_A_const_287; var tmp6 any = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(t__8, A_arbace_aot_emit_A_const_228), lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(args__3))); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp8 any = A_arbace_aot_emit_A_const_288; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp10 any = A_arbace_aot_emit_A_const_290; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp12 any = A_arbace_aot_emit_A_const_291; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp14 any = A_arbace_aot_emit_A_const_292; var tmp15 any = tmp9.Invoke_O_O_O__O(tmp10, tmp11.Invoke_O_O_O__O(tmp12, lang.IFn_Cast(A_arbace_aot_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(on__7), t__8), tmp13.Invoke_O_O__O(tmp14, lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_293, t__8))); var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp17 any = A_arbace_aot_emit_A_const_296; var tmp18 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_289.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_100.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(on__7)), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_34, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.Method_Cast(m__6)).GetName__String().Ref())).Ref()), lang.IFn_Cast(A_arbace_aot_emit_A_const_295.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Method_Cast(m__6)).GetParameterTypes__Class1().Ref())), tmp16.Invoke_O_O_O__O(tmp17, lang.IFn_Cast(A_arbace_aot_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(on__7), t__8), lang.IFn_Cast(A_arbace_aot_emit_A_const_294.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, jrt.NN(jrt.Method_Cast(m__6)).GetParameterTypes__Class1().Ref(), rest_args__9)), jrt.NN(jrt.Method_Cast(m__6)).GetReturnType__Class().Ref()); var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_100.GetRawRoot__O()); var tmp20 any = A_arbace_aot_emit_A_const_297; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp22 any = A_arbace_aot_emit_A_const_298; var tmp23 any = A_arbace_aot_emit_A_const_299; var tmp24 any = tmp21.Invoke_O_O_O__O(tmp22, tmp23, lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, fexpr__4)); var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()); var tmp26 any = A_arbace_aot_emit_emit_invoke_fn__90000142_A_New_O(ctx__0); var tmp27 *jrt.Class
		var fncls__23 /*line :516:1*/*jrt.Class = A_arbace_aot_emit_emit_invoke_fn__90000142_A_fn_class

















		if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_153, false); A_arbace_aot_emit_emit_invoke_fn__90000142_A_fn_class = fncls__23d; tmp27 = fncls__23d } else { tmp27 = fncls__23 }
//line :523:1
		return tmp4.Invoke_O_O_O__O(tmp5, tmp6, tmp7.Invoke_O_O_O_O__O(tmp8, tmp15, tmp18, tmp19.Invoke_O_O_O_O__O(tmp20, tmp24, t__8, tmp25.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil), rest_args__9)))) } else {











			return lang.IFn_Cast(call__5).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, fexpr__4)) } }
//line :510:1
func A_arbace_aot_emit_emit_invoke_call__90000138_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_emit_invoke_call__90000138_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_invoke_call__90000138_A{}; t.Ctor_O_O(p0, p1); return t }
//line :510:1
func (t *A_arbace_aot_emit_emit_invoke_call__90000138_A) Ctor_O_O(c__ctx, c__args any) { t.F_ctx = c__ctx; t.F_args = c__args }
//line :510:1
func (t *A_arbace_aot_emit_emit_invoke_call__90000138_A) Invoke_O_O__O(self, f__1 any) any {
	if lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(t.F_args)), 20) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp2 any = A_arbace_aot_emit_A_const_273; return tmp1.Invoke_O_O_O__O(tmp2, lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_aot_emit_A_const_274, A_arbace_aot_emit_A_const_275, f__1), lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_277, A_arbace_aot_emit_A_const_278), lang.IFn_Cast(A_arbace_aot_emit_A_const_276.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, t.F_args))) } else {


			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_100.GetRawRoot__O()); var tmp4 any = A_arbace_aot_emit_A_const_279; var tmp5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_aot_emit_A_const_280, A_arbace_aot_emit_A_const_281, f__1); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()); var tmp7 any = A_arbace_aot_emit_emit_invoke_call__90000138_fn__90000139_A_New_O(t.F_ctx); var tmp8 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_aot_emit_emit_invoke_call__90000138_fn__90000139_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_154, false); A_arbace_aot_emit_emit_invoke_call__90000138_fn__90000139_A_fn_class = fncls__21d; tmp8 = fncls__21d } else { tmp8 = fncls__21 }; return tmp3.Invoke_O_O_O__O(tmp4, tmp5, tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), t.F_args)) } }
//line :515:1
func A_arbace_aot_emit_emit_invoke_call__90000138_fn__90000139_A_New_O(p0 any) *A_arbace_aot_emit_emit_invoke_call__90000138_fn__90000139_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_invoke_call__90000138_fn__90000139_A{}; t.Ctor_O(p0); return t }
//line :515:1
func (t *A_arbace_aot_emit_emit_invoke_call__90000138_fn__90000139_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :515:1
func (t *A_arbace_aot_emit_emit_invoke_call__90000138_fn__90000139_A) Invoke_O_O__O(self, p1__90000136_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, p1__90000136_SHARP___1) }


















func A_arbace_aot_emit_emit_invoke_fn__90000142_A_New_O(p0 any) *A_arbace_aot_emit_emit_invoke_fn__90000142_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_invoke_fn__90000142_A{}; t.Ctor_O(p0); return t }
//line :534:1
func (t *A_arbace_aot_emit_emit_invoke_fn__90000142_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :534:1
func (t *A_arbace_aot_emit_emit_invoke_fn__90000142_A) Invoke_O_O__O(self, p1__90000137_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, p1__90000137_SHARP___1) }


func A_arbace_aot_emit_descriptor_A_New() *A_arbace_aot_emit_descriptor_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_descriptor_A{}; t.Ctor(); return t }
//line :537:1
func (t *A_arbace_aot_emit_descriptor_A) Ctor() {}
//line :537:1
func (t *A_arbace_aot_emit_descriptor_A) Invoke_O_O__O(self, c__0 any) any {
	var tmp1 *jrt.Class; jrt.Void_Init(); tmp1 = jrt.Void_TYPE; if lang.Util_Equiv_O_O__Z(c__0, tmp1.Ref()) { return Lit_25 } else { var tmp2 *jrt.Class; jrt.Long_Init(); tmp2 = jrt.Long_TYPE; if lang.Util_Equiv_O_O__Z(c__0, tmp2.Ref()) { return Lit_26 } else { var tmp3 *jrt.Class; jrt.Integer_Init(); tmp3 = jrt.Integer_TYPE; if lang.Util_Equiv_O_O__Z(c__0, tmp3.Ref()) { return Lit_27 } else { var tmp4 *jrt.Class; jrt.Double_Init(); tmp4 = jrt.Double_TYPE; if lang.Util_Equiv_O_O__Z(c__0, tmp4.Ref()) { return Lit_28 } else { var tmp5 *jrt.Class; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TYPE; if lang.Util_Equiv_O_O__Z(c__0, tmp5.Ref()) { return Lit_29 } else { var tmp6 *jrt.Class; jrt.Character_Init(); tmp6 = jrt.Character_TYPE; if lang.Util_Equiv_O_O__Z(c__0, tmp6.Ref()) { return Lit_30 } else { var tmp7 *jrt.Class; jrt.Float_Init(); tmp7 = jrt.Float_TYPE; if lang.Util_Equiv_O_O__Z(c__0, tmp7.Ref()) { return Lit_31 } else { var tmp8 *jrt.Class; jrt.Short_Init(); tmp8 = jrt.Short_TYPE; if lang.Util_Equiv_O_O__Z(c__0, tmp8.Ref()) { return Lit_32 } else { var tmp9 *jrt.Class; jrt.Byte_Init(); tmp9 = jrt.Byte_TYPE; if lang.Util_Equiv_O_O__Z(c__0, tmp9.Ref()) { return Lit_33 } else { if jrt.NN(jrt.Class_Cast(c__0)).IsArray__Z() {



		return lang.IFn_Cast(A_arbace_aot_emit_A_const_300.GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(), Lit_34, Lit_35) } else {
//line :538:1
			if A_arbace_aot_emit_A_const_60 != nil {




				return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_36, nil, Lit_37), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_aot_emit_A_const_300.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref()), Lit_34, Lit_35), nil)).Ref() } else {
//line :538:1
					return nil
				}
		}
	}
	}
	}
	}
	} } } } } }
func A_arbace_aot_emit_fn__90000146_A_New() *A_arbace_aot_emit_fn__90000146_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_fn__90000146_A{}; t.Ctor(); return t }
//line :546:1
func (t *A_arbace_aot_emit_fn__90000146_A) Ctor() {}
//line :546:1
func (t *A_arbace_aot_emit_fn__90000146_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_301.GetRawRoot__O()); var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_211); var tmp3 any; var or__1927000174__auto____3 any = jrt.System_Getenv_String__String(Lit_212).Ref(); if jrt.A2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { tmp3 = Lit_34 }; return tmp1.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil)).Ref()) }

func A_arbace_aot_emit_jrt_lacks_QMARK__A_New() *A_arbace_aot_emit_jrt_lacks_QMARK__A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_jrt_lacks_QMARK__A{}; t.Ctor(); return t }
//line :548:1
func (t *A_arbace_aot_emit_jrt_lacks_QMARK__A) Ctor() {}
//line :548:1
func (t *A_arbace_aot_emit_jrt_lacks_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var scan__2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_307.GetRawRoot__O()); var c__3 any = jrt.NN(jrt.Method_Cast(m__0)).GetDeclaringClass__Class().Ref(); var jc__4 any = lang.RT_Get_O_O__O(A_arbace_aot_emit_A_const_302.Invoke_O__O(scan__2), jrt.NN(jrt.Class_Cast(c__3)).GetName__String().Ref()); var tmp1 any; var and__1927000168__auto____5 any = jc__4; if







	jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_308.Invoke_O__O(jc__4)); if jrt.A2g_Truth(and__1927000168__auto____6) { tmp1 = lang.IFn_Cast(A_arbace_aot_emit_A_const_45.GetRawRoot__O()).Invoke_O_O__O(c__3, A_arbace_aot_emit_A_const_228) } else { tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 }; if jrt.A2g_Truth(tmp1) { var g__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_303.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_300.GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(jrt.Class_Cast(c__3)).GetName__String().Ref(), Lit_34, Lit_35)); var desc__6 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_223, nil, Lit_224, nil); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_304.GetRawRoot__O()); var tmp4 any = A_arbace_aot_emit_A_const_19.GetRawRoot__O(); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()); var tmp6 any = A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000149_A_New(); var tmp7 *jrt.Class
		var fncls__24 /*line :556:1*/*jrt.Class = A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000149_A_fn_class

		if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_225, false); A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000149_A_fn_class = fncls__24d; tmp7 = fncls__24d } else { tmp7 = fncls__24 }; desc__6 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3.Invoke_O_O__O(tmp4, tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), jrt.NN(jrt.Method_Cast(m__0)).GetParameterTypes__Class1().Ref())), nil, lang.IFn_Cast(A_arbace_aot_emit_A_const_305.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Method_Cast(m__0)).GetReturnType__Class().Ref()))).Ref()
//line :556:1
		var base__7 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_306.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.Method_Cast(m__0)).GetName__String().Ref(), desc__6)




		if jrt.Modifier_IsStatic_I__Z(jrt.NN(jrt.Method_Cast(m__0)).GetModifiers__I()) {
			return lang.IFn_Cast(A_arbace_aot_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_28.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_309.Invoke_O__O(scan__2), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_226, nil), jrt.RefArrayOf(jrt.Object_class, g__5, nil, base__7)).Ref())) } else {
//line :561:1
				var ms__8 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_190.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_310.GetRawRoot__O()).Invoke_O_O__O(scan__2, g__5), lang.IFn_Cast(A_arbace_aot_emit_A_const_311.GetRawRoot__O()).Invoke_O_O__O(scan__2, g__5)); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_25.GetRawRoot__O()); var tmp9 any; var or__1927000174__auto____9 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_28.GetRawRoot__O()).Invoke_O_O__O(ms__8, base__7)


				if jrt.A2g_Truth(or__1927000174__auto____9) { tmp9 = or__1927000174__auto____9 } else { var or__1927000174__auto____10 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_28.GetRawRoot__O()).Invoke_O_O__O(ms__8, lang.IFn_Cast(A_arbace_aot_emit_A_const_312.GetRawRoot__O()).Invoke_O__O(base__7)); if jrt.A2g_Truth(or__1927000174__auto____10) { tmp9 = or__1927000174__auto____10 } else {
					tmp9 = lang.IFn_Cast(A_arbace_aot_emit_A_const_28.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_309.Invoke_O__O(scan__2), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_226, nil), jrt.RefArrayOf(jrt.Object_class, g__5, nil, base__7)).Ref()) } }
//line :564:1
				return tmp8.Invoke_O__O(tmp9) } } else {
//line :556:1
					return nil } }

func A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000149_A_New() *A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000149_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000149_A{}; t.Ctor(); return t }
//line :558:1
func (t *A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000149_A) Ctor() {}
//line :558:1
func (t *A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000149_A) Invoke_O_O__O(self, p1__90000148_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_aot_emit_A_const_305.GetRawRoot__O()).Invoke_O__O(p1__90000148_SHARP___1) }








func A_arbace_aot_emit_method_call_A_New() *A_arbace_aot_emit_method_call_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_method_call_A{}; t.Ctor(); return t }
//line :567:1
func (t *A_arbace_aot_emit_method_call_A) Ctor() {}
//line :567:1
func (t *A_arbace_aot_emit_method_call_A) Invoke_O_O_O_O_O__O(self, ctx__0, m__1, t__2, args__3 any) any { var dc__5 any = jrt.NN(jrt.Method_Cast(m__1)).GetDeclaringClass__Class().Ref(); var ps__6 any = jrt.NN(jrt.Method_Cast(m__1)).GetParameterTypes__Class1().Ref(); var static_QMARK___7 bool = jrt.Modifier_IsStatic_I__Z(jrt.NN(jrt.Method_Cast(m__1)).GetModifiers__I()); var head__8 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(dc__5)); var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp5 *jrt.String; if static_QMARK___7 {





	tmp5 = nil } else { tmp5 = Lit_34 }; head__8 = tmp1.Invoke_O_O__O(tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp4, jrt.RefArrayOf(jrt.Object_class, tmp5.Ref(), jrt.NN(jrt.Method_Cast(m__1)).GetName__String().Ref())).Ref()), lang.IFn_Cast(A_arbace_aot_emit_A_const_295.GetRawRoot__O()).Invoke_O__O(ps__6)); if

	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_211.GetRawRoot__O()).Invoke_O_O__O(dc__5, ctx__0)) { lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_234, nil), jrt.RefArrayOf(jrt.Object_class, nil, m__1)).Ref()) }; if static_QMARK___7 {

		return lang.IFn_Cast(A_arbace_aot_emit_A_const_100.GetRawRoot__O()).Invoke_O_O__O(head__8, lang.IFn_Cast(A_arbace_aot_emit_A_const_294.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, ps__6, args__3)) } else {
			var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp7 any = A_arbace_aot_emit_A_const_313; return lang.IFn_Cast(A_arbace_aot_emit_A_const_100.GetRawRoot__O()).Invoke_O_O_O__O(head__8, tmp6.Invoke_O_O_O__O(tmp7, lang.IFn_Cast(A_arbace_aot_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(dc__5), t__2), lang.IFn_Cast(A_arbace_aot_emit_A_const_294.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, ps__6, args__3)) } }

func A_arbace_aot_emit_compiled_interface_QMARK__A_New() *A_arbace_aot_emit_compiled_interface_QMARK__A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_compiled_interface_QMARK__A{}; t.Ctor(); return t }
//line :580:1
func (t *A_arbace_aot_emit_compiled_interface_QMARK__A) Ctor() {}
//line :580:1
func (t *A_arbace_aot_emit_compiled_interface_QMARK__A) Invoke_O_O_O__O(self, ctx__0, c__1 any) any {


	var tmp1 any = A_arbace_aot_emit_A_const_314; var tmp2 *lang.Keyword = A_arbace_aot_emit_A_const_315; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp1, tmp2.Invoke_O__O(lang.RT_Get_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_302.Invoke_O__O(ctx__0)), lang.IFn_Cast(A_arbace_aot_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__1)).GetName__String().Ref()))))).Ref()
}
func A_arbace_aot_emit_emit_instance_method_A_New() *A_arbace_aot_emit_emit_instance_method_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_instance_method_A{}; t.Ctor(); return t }
//line :585:1
func (t *A_arbace_aot_emit_emit_instance_method_A) Ctor() {}
//line :585:1
func (t *A_arbace_aot_emit_emit_instance_method_A) Invoke_O_O_O_O__O(self, ctx__0, n__1, unboxed_QMARK___2 any) any { var m__4 any = A_arbace_aot_emit_A_const_316.Invoke_O__O(n__1); var tmp1 any; var and__1927000168__auto____5 any = m__4; if





	jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_317.GetRawRoot__O()).Invoke_O_O__O(ctx__0, jrt.NN(jrt.Method_Cast(m__4)).GetDeclaringClass__Class().Ref()); if jrt.A2g_Truth(and__1927000168__auto____6) { tmp1 = lang.IFn_Cast(A_arbace_aot_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_321.Invoke_O__O(n__1)) } else { tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 }; if /*line :587:1*/ jrt.A2g_Truth(tmp1) { var t__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_285.GetRawRoot__O()).Invoke_O_O__O(ctx__0, Lit_151); var dc__6 any = jrt.NN(jrt.Method_Cast(m__4)).GetDeclaringClass__Class().Ref(); var n_SINGLEQUOTE___7 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_13.GetRawRoot__O()); var tmp3 any = A_arbace_aot_emit_A_const_322; var tmp4 any = A_arbace_aot_emit_A_const_323; var tmp5 any = A_arbace_aot_emit_A_const_321; var tmp6 *jrt.Boolean; _ = dc__6






		jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; n_SINGLEQUOTE___7 = tmp2.Invoke_O_O_O_O_O_O_O__O(n__1, tmp3, tmp4, tmp5, tmp6.Ref(), A_arbace_aot_emit_A_const_324, t__5)
		var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp8 any = A_arbace_aot_emit_A_const_325; var tmp9 any = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(t__5, A_arbace_aot_emit_A_const_228), lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_322.Invoke_O__O(n__1))); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp11 any = A_arbace_aot_emit_A_const_326; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp13 any = A_arbace_aot_emit_A_const_327; var tmp14 any = tmp12.Invoke_O_O_O__O(tmp13, lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_328, t__5), lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_329, t__5)); var tmp15 any; var r__8 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_331, A_arbace_aot_emit_A_const_332), t__5, A_arbace_aot_emit_A_const_330.Invoke_O__O(n__1), lang.IFn_Cast(A_arbace_aot_emit_A_const_276.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_271.Invoke_O__O(n__1)))




		if jrt.A2g_Truth(unboxed_QMARK___2) { tmp15 = lang.IFn_Cast(A_arbace_aot_emit_A_const_242.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, r__8, jrt.NN(jrt.Method_Cast(m__4)).GetReturnType__Class().Ref()) } else { tmp15 = r__8 }
//line :595:1
		return tmp7.Invoke_O_O_O__O(tmp8, tmp9, tmp10.Invoke_O_O_O_O__O(tmp11, tmp14, tmp15, lang.IFn_Cast(A_arbace_aot_emit_A_const_319.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, n_SINGLEQUOTE___7, unboxed_QMARK___2))) } else {
//line :587:1
			var tmp16 any
			var and__1927000168__auto____5_2 any = m__4













			if jrt.A2g_Truth(and__1927000168__auto____5_2) { var and__1927000168__auto____6_2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_237.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Method_Cast(m__4)).GetDeclaringClass__Class().Ref()); if jrt.A2g_Truth(and__1927000168__auto____6_2) { var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_211.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.Method_Cast(m__4)).GetDeclaringClass__Class().Ref(), ctx__0)); if jrt.A2g_Truth(and__1927000168__auto____7) {
				tmp16 = lang.IFn_Cast(A_arbace_aot_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_333.GetRawRoot__O()).Invoke_O__O(m__4)) } else {
//line :602:1
					tmp16 = and__1927000168__auto____7 } } else { tmp16 = and__1927000168__auto____6_2 } } else { tmp16 = and__1927000168__auto____5_2 }
//line :587:1
			if jrt.A2g_Truth(tmp16) { var f__5 any; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_318.GetRawRoot__O()); var tmp18 any
















				if jrt.A2g_Truth(A_arbace_aot_emit_A_const_324.Invoke_O__O(n__1)) { tmp18 = A_arbace_aot_emit_A_const_324.Invoke_O__O(n__1) } else { tmp18 = lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_322.Invoke_O__O(n__1)) }; f__5 = tmp17.Invoke_O_O_O_O__O(ctx__0, m__4, tmp18, A_arbace_aot_emit_A_const_271.Invoke_O__O(n__1))
				if jrt.A2g_Truth(unboxed_QMARK___2) { return f__5 } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_289.GetRawRoot__O()).Invoke_O_O__O(f__5, jrt.NN(jrt.Method_Cast(m__4)).GetReturnType__Class().Ref()) } } else {
//line :587:1
					var tmp19 any
					var and__1927000168__auto____5_3 any = m__4

















					if jrt.A2g_Truth(and__1927000168__auto____5_3) { tmp19 = unboxed_QMARK___2 } else { tmp19 = and__1927000168__auto____5_3 }
//line :587:1
					if jrt.A2g_Truth(tmp19) {



















						var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_242.GetRawRoot__O()); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_319.GetRawRoot__O()); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_13.GetRawRoot__O()); var tmp23 any = A_arbace_aot_emit_A_const_316; var tmp24 any = A_arbace_aot_emit_A_const_320; var tmp25 any = tmp22.Invoke_O_O_O_O_O__O(n__1, tmp23, nil, tmp24, jrt.NN(jrt.Method_Cast(m__4)).GetDeclaringClass__Class().Ref()); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_FALSE; return tmp20.Invoke_O_O_O__O(ctx__0, tmp21.Invoke_O_O_O__O(ctx__0, tmp25, tmp26.Ref()), jrt.NN(jrt.Method_Cast(m__4)).GetReturnType__Class().Ref()) } else {
//line :587:1
							if jrt.A2g_Truth(m__4) {





















								var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_319.GetRawRoot__O()); var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_13.GetRawRoot__O()); var tmp29 any = A_arbace_aot_emit_A_const_316; var tmp30 any = A_arbace_aot_emit_A_const_320; var tmp31 any = tmp28.Invoke_O_O_O_O_O__O(n__1, tmp29, nil, tmp30, jrt.NN(jrt.Method_Cast(m__4)).GetDeclaringClass__Class().Ref()); var tmp32 *jrt.Boolean; jrt.Boolean_Init(); tmp32 = jrt.Boolean_FALSE; return tmp27.Invoke_O_O_O__O(ctx__0, tmp31, tmp32.Ref()) } else {
//line :587:1
									if jrt.A2g_Truth(A_arbace_aot_emit_A_const_320.Invoke_O__O(n__1)) {























										var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp34 any = A_arbace_aot_emit_A_const_334; return tmp33.Invoke_O_O_O_O_O__O(tmp34, lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_322.Invoke_O__O(n__1)), lang.IFn_Cast(A_arbace_aot_emit_A_const_248.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_320.Invoke_O__O(n__1)), A_arbace_aot_emit_A_const_330.Invoke_O__O(n__1), lang.IFn_Cast(A_arbace_aot_emit_A_const_276.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_271.Invoke_O__O(n__1))) } else {
//line :587:1
											if A_arbace_aot_emit_A_const_60 != nil {


























												return lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_335, A_arbace_aot_emit_A_const_336), lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_322.Invoke_O__O(n__1)), A_arbace_aot_emit_A_const_330.Invoke_O__O(n__1), lang.IFn_Cast(A_arbace_aot_emit_A_const_276.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_271.Invoke_O__O(n__1))) } else {
//line :587:1
													return nil } } } } } } }






























func A_arbace_aot_emit_emit_static_method_A_New() *A_arbace_aot_emit_emit_static_method_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_static_method_A{}; t.Ctor(); return t }
//line :618:1
func (t *A_arbace_aot_emit_emit_static_method_A) Ctor() {}
//line :618:1
func (t *A_arbace_aot_emit_emit_static_method_A) Invoke_O_O_O_O__O(self, ctx__0, n__1, unboxed_QMARK___2 any) any { var m__4 any = A_arbace_aot_emit_A_const_316.Invoke_O__O(n__1); var tmp1 any; var and__1927000168__auto____5 any = m__4; if


	jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_237.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Method_Cast(m__4)).GetDeclaringClass__Class().Ref()); if jrt.A2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_211.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.Method_Cast(m__4)).GetDeclaringClass__Class().Ref(), ctx__0)); if jrt.A2g_Truth(and__1927000168__auto____7) {
		tmp1 = lang.IFn_Cast(A_arbace_aot_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_333.GetRawRoot__O()).Invoke_O__O(m__4)) } else {
//line :621:1
			tmp1 = and__1927000168__auto____7 } } else { tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 }; if /*line :620:1*/ jrt.A2g_Truth(tmp1) { var f__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_318.GetRawRoot__O()).Invoke_O_O_O_O__O(ctx__0, m__4, nil, A_arbace_aot_emit_A_const_271.Invoke_O__O(n__1))



				if jrt.A2g_Truth(unboxed_QMARK___2) { return f__5 } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_289.GetRawRoot__O()).Invoke_O_O__O(f__5, jrt.NN(jrt.Method_Cast(m__4)).GetReturnType__Class().Ref()) } } else {
//line :620:1
					var tmp2 any
					var and__1927000168__auto____5_2 any = m__4



					if jrt.A2g_Truth(and__1927000168__auto____5_2) { tmp2 = unboxed_QMARK___2 } else { tmp2 = and__1927000168__auto____5_2 }
//line :620:1
					if jrt.A2g_Truth(tmp2) {





						var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_242.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_337.GetRawRoot__O()); var tmp5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_13.GetRawRoot__O()).Invoke_O_O_O__O(n__1, A_arbace_aot_emit_A_const_316, nil); var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_FALSE; return tmp3.Invoke_O_O_O__O(ctx__0, tmp4.Invoke_O_O_O__O(ctx__0, tmp5, tmp6.Ref()), jrt.NN(jrt.Method_Cast(m__4)).GetReturnType__Class().Ref()) } else {
//line :620:1
							if A_arbace_aot_emit_A_const_60 != nil {







								return lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_338, A_arbace_aot_emit_A_const_339), lang.IFn_Cast(A_arbace_aot_emit_A_const_248.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_340.Invoke_O__O(n__1)), A_arbace_aot_emit_A_const_330.Invoke_O__O(n__1), lang.IFn_Cast(A_arbace_aot_emit_A_const_276.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_271.Invoke_O__O(n__1))) } else {
//line :620:1
									return nil } } } }











func A_arbace_aot_emit_field_ok_QMARK__A_New() *A_arbace_aot_emit_field_ok_QMARK__A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_field_ok_QMARK__A{}; t.Ctor(); return t }
//line :632:1
func (t *A_arbace_aot_emit_field_ok_QMARK__A) Ctor() {}
//line :632:1
func (t *A_arbace_aot_emit_field_ok_QMARK__A) Invoke_O_O_O__O(self, ctx__0, f__1 any) any { var and__1927000168__auto____3 any = f__1; if
												jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_237.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Field_Cast(f__1)).GetDeclaringClass__Class().Ref()); if jrt.A2g_Truth(and__1927000168__auto____4) { return lang.IFn_Cast(A_arbace_aot_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_211.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.Field_Cast(f__1)).GetDeclaringClass__Class().Ref(), ctx__0)) } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } }

func A_arbace_aot_emit_emit_instance_field_A_New() *A_arbace_aot_emit_emit_instance_field_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_instance_field_A{}; t.Ctor(); return t }
//line :635:1
func (t *A_arbace_aot_emit_emit_instance_field_A) Ctor() {}
//line :635:1
func (t *A_arbace_aot_emit_emit_instance_field_A) Invoke_O_O_O_O__O(self, ctx__0, n__1, unboxed_QMARK___2 any) any { var f__4 any = A_arbace_aot_emit_A_const_341.Invoke_O__O(n__1); if

	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_342.GetRawRoot__O()).Invoke_O_O__O(ctx__0, f__4)) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp2 any = A_arbace_aot_emit_A_const_343; var r__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_84, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.Field_Cast(f__4)).GetName__String().Ref())).Ref()), tmp1.Invoke_O_O_O__O(tmp2, lang.IFn_Cast(A_arbace_aot_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Field_Cast(f__4)).GetDeclaringClass__Class().Ref()), lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_322.Invoke_O__O(n__1))))

		if jrt.A2g_Truth(unboxed_QMARK___2) { return r__5 } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_289.GetRawRoot__O()).Invoke_O_O__O(r__5, jrt.NN(jrt.Field_Cast(f__4)).GetType__Class().Ref()) } } else {
			return lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_346, A_arbace_aot_emit_A_const_347), lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_322.Invoke_O__O(n__1)), A_arbace_aot_emit_A_const_344.Invoke_O__O(n__1), A_arbace_aot_emit_A_const_345.Invoke_O__O(n__1)) } }



func A_arbace_aot_emit_emit_static_field_A_New() *A_arbace_aot_emit_emit_static_field_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_static_field_A{}; t.Ctor(); return t }
//line :644:1
func (t *A_arbace_aot_emit_emit_static_field_A) Ctor() {}
//line :644:1
func (t *A_arbace_aot_emit_emit_static_field_A) Invoke_O_O_O_O__O(self, ctx__0, n__1, unboxed_QMARK___2 any) any { var f__4 any = A_arbace_aot_emit_A_const_341.Invoke_O__O(n__1); if

	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_342.GetRawRoot__O()).Invoke_O_O__O(ctx__0, f__4)) { var r__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Field_Cast(f__4)).GetDeclaringClass__Class().Ref())), jrt.NN(jrt.Field_Cast(f__4)).GetName__String().Ref())

		if jrt.A2g_Truth(unboxed_QMARK___2) { return r__5 } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_289.GetRawRoot__O()).Invoke_O_O__O(r__5, jrt.NN(jrt.Field_Cast(f__4)).GetType__Class().Ref()) } } else {
			return lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_348, A_arbace_aot_emit_A_const_349), lang.IFn_Cast(A_arbace_aot_emit_A_const_248.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_340.Invoke_O__O(n__1)), A_arbace_aot_emit_A_const_344.Invoke_O__O(n__1)) } }


func A_arbace_aot_emit_emit_new_A_New() *A_arbace_aot_emit_emit_new_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_new_A{}; t.Ctor(); return t }
//line :652:1
func (t *A_arbace_aot_emit_emit_new_A) Ctor() {}
//line :652:1
func (t *A_arbace_aot_emit_emit_new_A) Invoke_O_O_O__O(self, ctx__0, n__1 any) any { var k__3 any = A_arbace_aot_emit_A_const_350.Invoke_O__O(n__1); var c__4 any = A_arbace_aot_emit_A_const_340.Invoke_O__O(n__1); var tmp1 any; var and__1927000168__auto____5 any = k__3; if


	jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_237.GetRawRoot__O()).Invoke_O__O(c__4); if jrt.A2g_Truth(and__1927000168__auto____6) { tmp1 = lang.IFn_Cast(A_arbace_aot_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_211.GetRawRoot__O()).Invoke_O_O__O(c__4, ctx__0)) } else { tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 }; if jrt.A2g_Truth(tmp1) {
		return lang.IFn_Cast(A_arbace_aot_emit_A_const_100.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_34), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_aot_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(c__4), nil)).Ref()), lang.IFn_Cast(A_arbace_aot_emit_A_const_295.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Constructor_Cast(k__3)).GetParameterTypes__Class1().Ref())), lang.IFn_Cast(A_arbace_aot_emit_A_const_294.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, jrt.NN(jrt.Constructor_Cast(k__3)).GetParameterTypes__Class1().Ref(), A_arbace_aot_emit_A_const_271.Invoke_O__O(n__1))) } else {

			return lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_351, A_arbace_aot_emit_A_const_352), lang.IFn_Cast(A_arbace_aot_emit_A_const_248.GetRawRoot__O()).Invoke_O_O__O(ctx__0, c__4), lang.IFn_Cast(A_arbace_aot_emit_A_const_276.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_271.Invoke_O__O(n__1))) } }


func A_arbace_aot_emit_emit_def_A_New() *A_arbace_aot_emit_emit_def_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_def_A{}; t.Ctor(); return t }
//line :661:1
func (t *A_arbace_aot_emit_emit_def_A) Ctor() {}
//line :661:1
func (t *A_arbace_aot_emit_emit_def_A) Invoke_O_O_O_O__O(self, ctx__0, n__1, top_QMARK___2 any) any { var v__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_212.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, A_arbace_aot_emit_A_const_140.Invoke_O__O(n__1), A_arbace_aot_emit_A_const_355); var init__5 any; if

	jrt.A2g_Truth(A_arbace_aot_emit_A_const_353.Invoke_O__O(n__1)) { init__5 = lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_356.Invoke_O__O(n__1)) } else { init__5 = nil }; var meta__6 any; if
	jrt.A2g_Truth(A_arbace_aot_emit_A_const_354.Invoke_O__O(n__1)) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp2 any = A_arbace_aot_emit_A_const_357; var tmp3 any = A_arbace_aot_emit_A_const_358; meta__6 = tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_354.Invoke_O__O(n__1))) } else { meta__6 = nil }; if
	jrt.A2g_Truth(top_QMARK___2) {


		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()); var tmp5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_359); var tmp6 lang.IPersistentVector
		if jrt.A2g_Truth(A_arbace_aot_emit_A_const_353.Invoke_O__O(n__1)) { tmp6 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_aot_emit_A_const_360, v__4, init__5)) } else { tmp6 = nil }
//line :668:1
		var tmp7 any = tmp6; var tmp8 lang.IPersistentVector

		if jrt.A2g_Truth(meta__6) { tmp8 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_aot_emit_A_const_361, v__4, meta__6)) } else { tmp8 = nil }
//line :668:1
		var tmp9 any = tmp8; var tmp10 any


		if jrt.A2g_Truth(A_arbace_aot_emit_A_const_362.Invoke_O__O(n__1)) { var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp12 any = A_arbace_aot_emit_A_const_363; var tmp13 *jrt.Boolean; jrt.Boolean_Init(); tmp13 = jrt.Boolean_TRUE; tmp10 = tmp11.Invoke_O_O_O__O(tmp12, v__4, tmp13.Ref()) } else { tmp10 = v__4 }
//line :668:1
		return tmp4.Invoke_O_O_O_O__O(tmp5, tmp7, tmp9, lang.Tuple_Create_O__IPersistentVector(tmp10)) } else {




			var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()); var tmp15 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_364); var tmp16 lang.IPersistentVector
			if jrt.A2g_Truth(A_arbace_aot_emit_A_const_362.Invoke_O__O(n__1)) { var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp18 any = A_arbace_aot_emit_A_const_365; var tmp19 *jrt.Boolean; jrt.Boolean_Init(); tmp19 = jrt.Boolean_TRUE; tmp16 = lang.Tuple_Create_O__IPersistentVector(tmp17.Invoke_O_O_O__O(tmp18, v__4, tmp19.Ref())) } else { tmp16 = nil }
//line :673:1
			var tmp20 any = tmp16; var tmp21 lang.IPersistentVector

			if jrt.A2g_Truth(meta__6) { tmp21 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_aot_emit_A_const_366, v__4, meta__6)) } else { tmp21 = nil }
//line :673:1
			var tmp22 any = tmp21; var tmp23 lang.IPersistentVector


			if jrt.A2g_Truth(A_arbace_aot_emit_A_const_353.Invoke_O__O(n__1)) { tmp23 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_aot_emit_A_const_367, v__4, init__5)) } else { tmp23 = nil }
//line :673:1
			return tmp14.Invoke_O_O_O_O_O__O(tmp15, tmp20, tmp22, tmp23, lang.Tuple_Create_O__IPersistentVector(v__4)) } }





func A_arbace_aot_emit_emit_assign_A_New() *A_arbace_aot_emit_emit_assign_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_assign_A{}; t.Ctor(); return t }
//line :679:1
func (t *A_arbace_aot_emit_emit_assign_A) Ctor() {}
//line :679:1
func (t *A_arbace_aot_emit_emit_assign_A) Invoke_O_O_O__O(self, ctx__0, n__1 any) any { var t__3 any = A_arbace_aot_emit_A_const_322.Invoke_O__O(n__1); var tn__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(t__3); var val__5 any = A_arbace_aot_emit_A_const_368.Invoke_O__O(n__1); var G__90000161__6_ any = A_arbace_aot_emit_A_const_369.Invoke_O__O(tn__4); switch



	lang.Util_Hash_O__I(G__90000161__6_) >> 21 & 3 { case 0: if lang.Util_Equiv_O_O__Z(G__90000161__6_, Lit_46) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp2 any = A_arbace_aot_emit_A_const_370; return tmp1.Invoke_O_O_O__O(tmp2, lang.IFn_Cast(A_arbace_aot_emit_A_const_212.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, A_arbace_aot_emit_A_const_140.Invoke_O__O(tn__4), A_arbace_aot_emit_A_const_371), lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, val__5)) }
//line :683:1
	case 1: if lang.Util_Equiv_O_O__Z(G__90000161__6_, Lit_58) { var lb__7 any = A_arbace_aot_emit_A_const_256.Invoke_O__O(tn__4); var b__8 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__7)


		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_257.GetRawRoot__O()).Invoke_O_O__O(ctx__0, lb__7)) {
			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp4 any = A_arbace_aot_emit_A_const_372; var tmp5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_258.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, lb__7, b__8); var tmp6 any; if jrt.A2g_Truth(A_arbace_aot_emit_A_const_265.Invoke_O__O(b__8)) { tmp6 = lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(ctx__0, val__5) } else { tmp6 = lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, val__5) }; return tmp3.Invoke_O_O_O__O(tmp4, tmp5, tmp6) } else {
				return lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(Lit_83) } }
//line :683:1
	case 2: if lang.Util_Equiv_O_O__Z(G__90000161__6_, Lit_75) { var f__7 any = A_arbace_aot_emit_A_const_341.Invoke_O__O(tn__4); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O())
		var tmp8 any = A_arbace_aot_emit_A_const_373












		return tmp7.Invoke_O_O_O__O(tmp8, lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Field_Cast(f__7)).GetDeclaringClass__Class().Ref())), jrt.NN(jrt.Field_Cast(f__7)).GetName__String().Ref()), lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_294.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, lang.Tuple_Create_O__IPersistentVector(jrt.NN(jrt.Field_Cast(f__7)).GetType__Class().Ref()), lang.Tuple_Create_O__IPersistentVector(val__5)))) }
//line :683:1
	case 3: if lang.Util_Equiv_O_O__Z(G__90000161__6_, Lit_45) { var f__7_2 any = A_arbace_aot_emit_A_const_341.Invoke_O__O(tn__4)






		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_342.GetRawRoot__O()).Invoke_O_O__O(ctx__0, f__7_2)) {
			var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp10 any = A_arbace_aot_emit_A_const_374; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp12 any = A_arbace_aot_emit_A_const_375; return tmp9.Invoke_O_O_O__O(tmp10, lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_84, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.Field_Cast(f__7_2)).GetName__String().Ref())).Ref()), tmp11.Invoke_O_O_O__O(tmp12, lang.IFn_Cast(A_arbace_aot_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Field_Cast(f__7_2)).GetDeclaringClass__Class().Ref()), lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_322.Invoke_O__O(tn__4)))), lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_294.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, lang.Tuple_Create_O__IPersistentVector(jrt.NN(jrt.Field_Cast(f__7_2)).GetType__Class().Ref()), lang.Tuple_Create_O__IPersistentVector(val__5)))) } else {


				var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp14 any = A_arbace_aot_emit_A_const_376; return tmp13.Invoke_O_O_O_O__O(tmp14, lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_322.Invoke_O__O(tn__4)), A_arbace_aot_emit_A_const_344.Invoke_O__O(tn__4), lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, val__5)) } }
//line :683:1
	default:}; return /*line :699:1*/ lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_85, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_aot_emit_A_const_369.Invoke_O__O(tn__4))).Ref()) }

func A_arbace_aot_emit_coll_call_A_New() *A_arbace_aot_emit_coll_call_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_coll_call_A{}; t.Ctor(); return t }
//line :701:1
func (t *A_arbace_aot_emit_coll_call_A) Ctor() {}
//line :701:1
func (t *A_arbace_aot_emit_coll_call_A) Invoke_O_O_O_O__O(self, sym__0, es__1, ctx__2 any) any {
	return lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(sym__0, A_arbace_aot_emit_A_const_377), lang.IFn_Cast(A_arbace_aot_emit_A_const_276.GetRawRoot__O()).Invoke_O_O__O(ctx__2, es__1))
}
func A_arbace_aot_emit_emit_if_A_New() *A_arbace_aot_emit_emit_if_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_if_A{}; t.Ctor(); return t }
//line :704:1
func (t *A_arbace_aot_emit_emit_if_A) Ctor() {}
//line :704:1
func (t *A_arbace_aot_emit_emit_if_A) Invoke_O_O_O_O__O(self, ctx__0, n__1, unboxed_QMARK___2 any) any { var t__4 any = A_arbace_aot_emit_A_const_378.Invoke_O__O(n__1); var tn__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(t__4); var test__6 any; var tmp1 any; var and__1927000168__auto____6 bool; var tmp2 any = A_arbace_aot_emit_A_const_223.Invoke_O__O(tn__5); var tmp3 *jrt.Class;


	jrt.Boolean_Init(); tmp3 = jrt.Boolean_TYPE; and__1927000168__auto____6 = lang.Util_Equiv_O_O__Z(tmp2, tmp3.Ref()); if and__1927000168__auto____6 { tmp1 = lang.IFn_Cast(A_arbace_aot_emit_A_const_379.GetRawRoot__O()).Invoke_O__O(tn__5) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____6).Ref() }; if jrt.A2g_Truth(tmp1) {
		test__6 = lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(ctx__0, t__4) } else {
			test__6 = lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, t__4) }; var br__7 any; var tmp4 any = /*line :704:1*/A_arbace_aot_emit_emit_if_br__90000164_A_New_O_O(ctx__0, unboxed_QMARK___2); var tmp5 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_aot_emit_emit_if_br__90000164_A_fn_class; if





	fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_150, false); A_arbace_aot_emit_emit_if_br__90000164_A_fn_class = fncls__26d; tmp5 = fncls__26d } else { tmp5 = fncls__26 }; br__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp6 lang.IFn =
	lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp7 any = A_arbace_aot_emit_A_const_380; return tmp6.Invoke_O_O_O_O__O(tmp7, test__6, lang.IFn_Cast(br__7).Invoke_O__O(A_arbace_aot_emit_A_const_381.Invoke_O__O(n__1)), lang.IFn_Cast(br__7).Invoke_O__O(A_arbace_aot_emit_A_const_382.Invoke_O__O(n__1))) }
//line :710:1
func A_arbace_aot_emit_emit_if_br__90000164_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_emit_if_br__90000164_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_if_br__90000164_A{}; t.Ctor_O_O(p0, p1); return t }
//line :710:1
func (t *A_arbace_aot_emit_emit_if_br__90000164_A) Ctor_O_O(c__ctx, c__unboxed_QMARK_ any) { t.F_ctx = c__ctx; t.F_unboxed_QMARK_ = c__unboxed_QMARK_ }
//line :710:1
func (t *A_arbace_aot_emit_emit_if_br__90000164_A) Invoke_O_O__O(self, e__1 any) any { if jrt.A2g_Truth(t.F_unboxed_QMARK_) { return lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, e__1) } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, e__1) } }


func A_arbace_aot_emit_emit_binding_init_A_New() *A_arbace_aot_emit_emit_binding_init_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_binding_init_A{}; t.Ctor(); return t }
//line :713:1
func (t *A_arbace_aot_emit_emit_binding_init_A) Ctor() {}
//line :713:1
func (t *A_arbace_aot_emit_emit_binding_init_A) Invoke_O_O_O_O__O(self, ctx__0, lb__1, init__2 any) any { var b__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__1); var p__5 any = A_arbace_aot_emit_A_const_265.Invoke_O__O(b__4); if




	jrt.A2g_Truth(p__5) { return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_264.GetRawRoot__O()).Invoke_O__O(b__4), p__5), lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(ctx__0, init__2)) } else { return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_264.GetRawRoot__O()).Invoke_O__O(b__4), A_arbace_aot_emit_A_const_228), lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, init__2)) } }



func A_arbace_aot_emit_emit_let_A_New() *A_arbace_aot_emit_emit_let_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_let_A{}; t.Ctor(); return t }
//line :722:1
func (t *A_arbace_aot_emit_emit_let_A) Ctor() {}
//line :722:1
func (t *A_arbace_aot_emit_emit_let_A) Invoke_O_O_O_O__O(self, ctx__0, n__1, unboxed_QMARK___2 any) any { var bis__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_224.GetRawRoot__O(), A_arbace_aot_emit_A_const_384.Invoke_O__O(n__1)); var ctx_SINGLEQUOTE___5 any; if

	jrt.A2g_Truth(A_arbace_aot_emit_A_const_383.Invoke_O__O(n__1)) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_13.GetRawRoot__O()); var tmp2 any = A_arbace_aot_emit_A_const_385; ctx_SINGLEQUOTE___5 = tmp1.Invoke_O_O_O__O(ctx__0, tmp2, lang.IFn_Cast(A_arbace_aot_emit_A_const_43.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_386, bis__4)) } else { ctx_SINGLEQUOTE___5 = ctx__0 }; var bindings__6 any; var tmp3 lang.IFn = /*line :722:1*/lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_98.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_emit_let_fn__90000169_A_New_O(ctx__0); var tmp6 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_aot_emit_emit_let_fn__90000169_A_fn_class; if


	fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_155, false); A_arbace_aot_emit_emit_let_fn__90000169_A_fn_class = fncls__27d; tmp6 = fncls__27d } else { tmp6 = fncls__27 }; bindings__6 = tmp3.Invoke_O__O(tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), bis__4)); var body__7 any; if
	jrt.A2g_Truth(unboxed_QMARK___2) { body__7 = lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(ctx_SINGLEQUOTE___5, A_arbace_aot_emit_A_const_388.Invoke_O__O(n__1)) } else { body__7 = lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx_SINGLEQUOTE___5, A_arbace_aot_emit_A_const_388.Invoke_O__O(n__1)) }; var tmp7 lang.IFn =
	lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp8 any; if jrt.A2g_Truth(A_arbace_aot_emit_A_const_383.Invoke_O__O(n__1)) { tmp8 = A_arbace_aot_emit_A_const_389 } else { tmp8 = A_arbace_aot_emit_A_const_390 }; return tmp7.Invoke_O_O_O__O(tmp8, bindings__6, body__7) }
//line :725:1
func A_arbace_aot_emit_emit_let_fn__90000169_A_New_O(p0 any) *A_arbace_aot_emit_emit_let_fn__90000169_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_let_fn__90000169_A{}; t.Ctor_O(p0); return t }
//line :725:1
func (t *A_arbace_aot_emit_emit_let_fn__90000169_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :725:1
func (t *A_arbace_aot_emit_emit_let_fn__90000169_A) Invoke_O_O__O(self, p1__90000168_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_387.GetRawRoot__O()); var tmp2 any = t.F_ctx; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_aot_emit_A_const_386.Invoke_O__O(p1__90000168_SHARP___1), A_arbace_aot_emit_A_const_356.Invoke_O__O(p1__90000168_SHARP___1)) }



func A_arbace_aot_emit_emit_recur_A_New() *A_arbace_aot_emit_emit_recur_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_recur_A{}; t.Ctor(); return t }
//line :729:1
func (t *A_arbace_aot_emit_emit_recur_A) Ctor() {}
//line :729:1
func (t *A_arbace_aot_emit_emit_recur_A) Invoke_O_O_O__O(self, ctx__0, n__1 any) any { var lls__3 any = A_arbace_aot_emit_A_const_391.Invoke_O__O(n__1); if

	jrt.A2g_Truth(A_arbace_aot_emit_A_const_392.Invoke_O__O(ctx__0)) {
		if lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()).Invoke_O__O(lls__3), A_arbace_aot_emit_A_const_393.Invoke_O__O(ctx__0)) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_394.GetRawRoot__O()); var tmp2 any = A_arbace_aot_emit_A_const_392.Invoke_O__O(ctx__0); var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_TRUE; tmp1.Invoke_O_O__O(tmp2, tmp3.Ref()) } }; var tmp4 lang.IFn =
	lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_A_const_395; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()); var tmp7 any = A_arbace_aot_emit_emit_recur_fn__90000172_A_New_O(ctx__0); var tmp8 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_aot_emit_emit_recur_fn__90000172_A_fn_class; if
	fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_170, false); A_arbace_aot_emit_emit_recur_fn__90000172_A_fn_class = fncls__28d; tmp8 = fncls__28d } else { tmp8 = fncls__28 }; return /*line :733:1*/ tmp4.Invoke_O_O__O(tmp5, tmp6.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), lls__3, A_arbace_aot_emit_A_const_271.Invoke_O__O(n__1))) }
func A_arbace_aot_emit_emit_recur_fn__90000172_A_New_O(p0 any) *A_arbace_aot_emit_emit_recur_fn__90000172_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_recur_fn__90000172_A{}; t.Ctor_O(p0); return t }
//line :734:1
func (t *A_arbace_aot_emit_emit_recur_fn__90000172_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :734:1
func (t *A_arbace_aot_emit_emit_recur_fn__90000172_A) Invoke_O_O_O__O(self, lb__1, arg__2 any) any { var b__3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__1); var primc__4 any = A_arbace_aot_emit_A_const_265.Invoke_O__O(b__3); var pc__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_396.GetRawRoot__O()).Invoke_O__O(arg__2); if



	jrt.A2g_Truth(primc__4) {
		if lang.Util_Equiv_O_O__Z(pc__5, primc__4) {
			return lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, arg__2) } else {
//line :739:1
				var tmp1 bool; var and__1927000168__auto____6 bool; var tmp2 *jrt.Class

				jrt.Long_Init(); tmp2 = jrt.Long_TYPE; and__1927000168__auto____6 = lang.Util_Equiv_O_O__Z(primc__4, tmp2.Ref()); if and__1927000168__auto____6 { var tmp3 *jrt.Class; jrt.Integer_Init(); tmp3 = jrt.Integer_TYPE; tmp1 = lang.Util_Equiv_O_O__Z(pc__5, tmp3.Ref()) } else { tmp1 = and__1927000168__auto____6 }
//line :739:1
				if tmp1 {

					return lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, arg__2) } else {
//line :739:1
						var tmp4 bool; var and__1927000168__auto____6_2 bool; var tmp5 *jrt.Class


						jrt.Double_Init(); tmp5 = jrt.Double_TYPE; and__1927000168__auto____6_2 = lang.Util_Equiv_O_O__Z(primc__4, tmp5.Ref()); if and__1927000168__auto____6_2 { var tmp6 *jrt.Class; jrt.Float_Init(); tmp6 = jrt.Float_TYPE; tmp4 = lang.Util_Equiv_O_O__Z(pc__5, tmp6.Ref()) } else { tmp4 = and__1927000168__auto____6_2 }
//line :739:1
						if tmp4 {


							return lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, arg__2) } else {
//line :739:1
								var tmp7 bool; var and__1927000168__auto____6_3 bool; var tmp8 *jrt.Class



								jrt.Integer_Init(); tmp8 = jrt.Integer_TYPE; and__1927000168__auto____6_3 = lang.Util_Equiv_O_O__Z(primc__4, tmp8.Ref()); if and__1927000168__auto____6_3 { var tmp9 *jrt.Class; jrt.Long_Init(); tmp9 = jrt.Long_TYPE; tmp7 = lang.Util_Equiv_O_O__Z(pc__5, tmp9.Ref()) } else { tmp7 = and__1927000168__auto____6_3 }
//line :739:1
								if tmp7 {




									return lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_397, A_arbace_aot_emit_A_const_398), lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, arg__2)) } else {
//line :739:1
										var tmp10 bool; var and__1927000168__auto____6_4 bool; var tmp11 *jrt.Class





										jrt.Float_Init(); tmp11 = jrt.Float_TYPE; and__1927000168__auto____6_4 = lang.Util_Equiv_O_O__Z(primc__4, tmp11.Ref()); if and__1927000168__auto____6_4 { var tmp12 *jrt.Class; jrt.Double_Init(); tmp12 = jrt.Double_TYPE; tmp10 = lang.Util_Equiv_O_O__Z(pc__5, tmp12.Ref()) } else { tmp10 = and__1927000168__auto____6_4 }
//line :739:1
										if tmp10 {





											var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp14 any = A_arbace_aot_emit_A_const_399; return tmp13.Invoke_O_O__O(tmp14, lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, arg__2)) } else {
//line :739:1
												if A_arbace_aot_emit_A_const_60 != nil {






													return lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_171, nil, Lit_172), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_aot_emit_A_const_34.Invoke_O__O(b__3), nil)).Ref()) } else {
//line :739:1
														return nil } } } } } } } else {







															return lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, arg__2) } }


func A_arbace_aot_emit_body_instance_A_New() *A_arbace_aot_emit_body_instance_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_body_instance_A{}; t.Ctor(); return t }
//line :750:1
func (t *A_arbace_aot_emit_body_instance_A) Ctor() {}
//line :750:1
func (t *A_arbace_aot_emit_body_instance_A) Invoke_O_O_O_O__O(self, ctx__0, ox__1, nil_locals__2 any) any { var cname__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_400.GetRawRoot__O()).Invoke_O_O__O(ctx__0, ox__1); var args__5 any; var iter__1927001039__auto____5 any; var tmp1 any = A_arbace_aot_emit_body_instance_iter__90000175__90000179_A_New_O_O(ctx__0, nil_locals__2); var tmp2 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_aot_emit_body_instance_iter__90000175__90000179_A_fn_class; if





	fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1, false); A_arbace_aot_emit_body_instance_iter__90000175__90000179_A_fn_class = fncls__31d; tmp2 = fncls__31d } else { tmp2 = fncls__31 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); args__5 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_406.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_407.Invoke_O__O(ox__1))); var tmp3 lang.IFn =




	lang.IFn_Cast(A_arbace_aot_emit_A_const_100.GetRawRoot__O()); var tmp4 any = A_arbace_aot_emit_A_const_408; var tmp5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(cname__4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()); var tmp7 any; var tmp8 any; var and__1927000168__auto____6 bool = lang.Util_Equiv_O_O__Z(Lit_2, A_arbace_aot_emit_A_const_369.Invoke_O__O(ox__1)); if and__1927000168__auto____6 { tmp8 = A_arbace_aot_emit_A_const_409.Invoke_O__O(ox__1) } else { tmp8 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____6).Ref() }; if jrt.A2g_Truth(tmp8) { tmp7 = A_arbace_aot_emit_A_const_410 } else { tmp7 = nil }; return tmp3.Invoke_O_O_O__O(tmp4, tmp5, tmp6.Invoke_O_O__O(tmp7, args__5)) }
//line :756:1
func A_arbace_aot_emit_body_instance_iter__90000175__90000179_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_body_instance_iter__90000175__90000179_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_body_instance_iter__90000175__90000179_A{}; t.Ctor_O_O(p0, p1); return t }
//line :756:1
func (t *A_arbace_aot_emit_body_instance_iter__90000175__90000179_A) Ctor_O_O(c__ctx, c__nil_locals any) { t.F_ctx = c__ctx; t.F_nil_locals = c__nil_locals }
//line :756:1
func (t *A_arbace_aot_emit_body_instance_iter__90000175__90000179_A) Invoke_O_O__O(self, s__90000176__1 any) any { var tmp1 any = A_arbace_aot_emit_body_instance_iter__90000175__90000179_fn__90000180_A_New_O_O_O_O(t.F_ctx, s__90000176__1, self, t.F_nil_locals); var tmp2 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_aot_emit_body_instance_iter__90000175__90000179_fn__90000180_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, false); A_arbace_aot_emit_body_instance_iter__90000175__90000179_fn__90000180_A_fn_class = fncls__30d; tmp2 = fncls__30d } else { tmp2 = fncls__30 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :756:1
func A_arbace_aot_emit_body_instance_iter__90000175__90000179_fn__90000180_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_aot_emit_body_instance_iter__90000175__90000179_fn__90000180_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_body_instance_iter__90000175__90000179_fn__90000180_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :756:1
func (t *A_arbace_aot_emit_body_instance_iter__90000175__90000179_fn__90000180_A) Ctor_O_O_O_O(c__ctx, c__s__90000176, c__iter__90000175, c__nil_locals any) { t.F_ctx = c__ctx; t.F_s__90000176 = c__s__90000176; t.F_iter__90000175 = c__iter__90000175; t.F_nil_locals = c__nil_locals }
//line :756:1
func (t *A_arbace_aot_emit_body_instance_iter__90000175__90000179_fn__90000180_A) Invoke_O__O(self any) any { { var s__90000176__1 any; var t_ any = t.F_s__90000176; t.F_s__90000176 = nil; s__90000176__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(s__90000176__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__90000176__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(s__90000176__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(s__90000176__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__90000178__6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_401.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_aot_emit_body_instance_iter__90000175__90000179_fn__90000180_fn__90000181_A_New_O_O_O_I_O(t.F_ctx, t.F_nil_locals, b__90000178__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_aot_emit_body_instance_iter__90000175__90000179_fn__90000180_fn__90000181_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_4, false); A_arbace_aot_emit_body_instance_iter__90000175__90000179_fn__90000180_fn__90000181_A_fn_class = fncls__29d; tmp2 = fncls__29d } else { tmp2 = fncls__29 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__90000175); return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000178__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__90000176__3))) } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000178__6), nil) } } else { var lb__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__90000176__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()); var tmp5 any
														if jrt.NN(jrt.IdentityHashMap_Cast(t.F_nil_locals)).ContainsKey_O__Z(lb__4) { tmp5 = nil } else { var b__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_403.GetRawRoot__O()); var tmp7 any = t.F_ctx; var tmp8 any = A_arbace_aot_emit_A_const_256; var tmp9 any = A_arbace_aot_emit_A_const_260; var tmp10 *jrt.Boolean


		jrt.Boolean_Init(); tmp10 = jrt.Boolean_FALSE; tmp5 = tmp6.Invoke_O_O_O__O(tmp7, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp8, lb__4, tmp9, tmp10.Ref())), jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(A_arbace_aot_emit_A_const_265.Invoke_O__O(b__5))).Ref()) }
//line :756:1
	var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__90000175); return tmp4.Invoke_O_O__O(tmp5, tmp11.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(s__90000176__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :756:1
func A_arbace_aot_emit_body_instance_iter__90000175__90000179_fn__90000180_fn__90000181_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_aot_emit_body_instance_iter__90000175__90000179_fn__90000180_fn__90000181_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_body_instance_iter__90000175__90000179_fn__90000180_fn__90000181_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :756:1
func (t *A_arbace_aot_emit_body_instance_iter__90000175__90000179_fn__90000180_fn__90000181_A) Ctor_O_O_O_I_O(c__ctx, c__nil_locals, c__b__90000178 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_ctx = c__ctx; t.F_nil_locals = c__nil_locals; t.F_b__90000178 = c__b__90000178; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :756:1
func (t *A_arbace_aot_emit_body_instance_iter__90000175__90000179_fn__90000180_fn__90000181_A) Invoke_O__O(self any) any { { var i__90000177__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__90000177__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var lb__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__90000177__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_402.GetRawRoot__O()); var tmp3 any = t.F_b__90000178; var tmp4 any
																if jrt.NN(jrt.IdentityHashMap_Cast(t.F_nil_locals)).ContainsKey_O__Z(lb__2) { tmp4 = nil } else { var b__3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__2); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_403.GetRawRoot__O()); var tmp6 any = t.F_ctx; var tmp7 any = A_arbace_aot_emit_A_const_256; var tmp8 any = A_arbace_aot_emit_A_const_260; var tmp9 *jrt.Boolean


		jrt.Boolean_Init(); tmp9 = jrt.Boolean_FALSE; tmp4 = tmp5.Invoke_O_O_O__O(tmp6, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, lb__2, tmp8, tmp9.Ref())), jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(A_arbace_aot_emit_A_const_265.Invoke_O__O(b__3))).Ref()) }
//line :756:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__90000177__1 = lang.Numbers_Unchecked_inc_J__J(i__90000177__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }






func A_arbace_aot_emit_fn_wrap_A_New() *A_arbace_aot_emit_fn_wrap_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_fn_wrap_A{}; t.Ctor(); return t }
//line :763:1
func (t *A_arbace_aot_emit_fn_wrap_A) Ctor() {}
//line :763:1
func (t *A_arbace_aot_emit_fn_wrap_A) Invoke_O_O_O_O__O(self, ctx__0, ox__1, body__2 any) any { var cname__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_400.GetRawRoot__O()).Invoke_O_O__O(ctx__0, ox__1); var tmp1 *lang.Keyword = A_arbace_aot_emit_A_const_411; var k__5 any = tmp1.Invoke_O__O(lang.RT_Get_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_302.Invoke_O__O(ctx__0)), cname__4)); var f__6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O_O__O(cname__4, Lit_213); var c__7 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_285.GetRawRoot__O()).Invoke_O_O__O(ctx__0, Lit_214); var cls__8 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp3 any = A_arbace_aot_emit_A_const_412; var tmp4 any = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(c__7, A_arbace_aot_emit_A_const_413), f__6); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp6 any = A_arbace_aot_emit_A_const_414; var tmp7 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_415, c__7); var tmp8 any; var d__8 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_215), jrt.RefArrayOf(jrt.Object_class, c__7, nil)).Ref()); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp10 any = A_arbace_aot_emit_A_const_416; tmp8 =












	tmp9.Invoke_O_O_O_O__O(tmp10, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(d__8, A_arbace_aot_emit_A_const_417), lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_418, A_arbace_aot_emit_A_const_419), cname__4, jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(k__5)).Ref())), lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_aot_emit_A_const_420, f__6, d__8), d__8); cls__8 = /*line :773:1*/tmp2.Invoke_O_O_O__O(tmp3, tmp4, tmp5.Invoke_O_O_O_O__O(tmp6, tmp7, tmp8, c__7)); if








	jrt.A2g_Truth(k__5) {
		var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp12 any = A_arbace_aot_emit_A_const_421; var tmp13 any = A_arbace_aot_emit_A_const_422; return tmp11.Invoke_O_O_O_O_O_O__O(tmp12, tmp13, body__2, cls__8, nil, lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_423, k__5)) } else {
			return lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_aot_emit_A_const_424, A_arbace_aot_emit_A_const_425, body__2, cls__8, nil) } }

func A_arbace_aot_emit_fn_instance_A_New() *A_arbace_aot_emit_fn_instance_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_fn_instance_A{}; t.Ctor(); return t }
//line :786:1
func (t *A_arbace_aot_emit_fn_instance_A) Ctor() {}
//line :786:1
func (t *A_arbace_aot_emit_fn_instance_A) Invoke_O_O_O_O__O(self, ctx__0, ox__1, nil_locals__2 any) any { var b__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_426.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, ox__1, nil_locals__2); if



	lang.Util_Equiv_O_O__Z(Lit_50, A_arbace_aot_emit_A_const_369.Invoke_O__O(ox__1)) { return lang.IFn_Cast(A_arbace_aot_emit_A_const_427.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, ox__1, b__4) } else { return b__4 } }

func A_arbace_aot_emit_emit_letfn_A_New() *A_arbace_aot_emit_emit_letfn_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_letfn_A{}; t.Ctor(); return t }
//line :792:1
func (t *A_arbace_aot_emit_emit_letfn_A) Ctor() {}
//line :792:1
func (t *A_arbace_aot_emit_emit_letfn_A) Invoke_O_O_O_O__O(self, ctx__0, n__1, unboxed_QMARK___2 any) any { var bis__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_224.GetRawRoot__O(), A_arbace_aot_emit_A_const_384.Invoke_O__O(n__1)); var lbs__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_428.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_386, bis__4)); var syms__6 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()); var tmp2 any = A_arbace_aot_emit_emit_letfn_fn__90000190_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_aot_emit_emit_letfn_fn__90000190_A_fn_class; if


	fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_156, false); A_arbace_aot_emit_emit_letfn_fn__90000190_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; syms__6 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), bis__4); var bsyms__7 any; var tmp4 lang.IFn = /*line :792:1*/lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_emit_letfn_fn__90000192_A_New(); var tmp6 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_aot_emit_emit_letfn_fn__90000192_A_fn_class; if



	fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_157, false); A_arbace_aot_emit_emit_letfn_fn__90000192_A_fn_class = fncls__41d; tmp6 = fncls__41d } else { tmp6 = fncls__41 }; bsyms__7 = tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), syms__6); var bodies__8 any; var iter__1927001039__auto____8 any; var tmp7 any = /*line :792:1*/A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_A_New_O_O(ctx__0, lbs__5); var tmp8 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_A_fn_class; if




	fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_158, false); A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_A_fn_class = fncls__34d; tmp8 = fncls__34d } else { tmp8 = fncls__34 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); bodies__8 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(bis__4); var sets__9 any; var iter__1927001039__auto____9 any; var tmp9 any = /*line :792:1*/A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_A_New_O_O(ctx__0, lbs__5); var tmp10 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_A_fn_class; if





	fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_159, false); A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_A_fn_class = fncls__39d; tmp10 = fncls__39d } else { tmp10 = fncls__39 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); sets__9 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_aot_emit_A_const_430.GetRawRoot__O(), bis__4, bsyms__7)); var tmp11 lang.IFn =





	lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp12 any = A_arbace_aot_emit_A_const_431; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_98.GetRawRoot__O()); var tmp16 any = A_arbace_aot_emit_emit_letfn_fn__90000223_A_New_O(ctx__0); var tmp17 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_aot_emit_emit_letfn_fn__90000223_A_fn_class; if
	fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_160, false); A_arbace_aot_emit_emit_letfn_fn__90000223_A_fn_class = fncls__42d; tmp17 = fncls__42d } else { tmp17 = fncls__42 }; var tmp18 any = /*line :804:1*/tmp15.Invoke_O_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil), bsyms__7, bis__4, bodies__8); var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_98.GetRawRoot__O()); var tmp20 any = A_arbace_aot_emit_emit_letfn_fn__90000225_A_New_O(ctx__0); var tmp21 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_aot_emit_emit_letfn_fn__90000225_A_fn_class; if

	fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_161, false); A_arbace_aot_emit_emit_letfn_fn__90000225_A_fn_class = fncls__43d; tmp21 = fncls__43d } else { tmp21 = fncls__43 }; var tmp22 any = /*line :804:1*/tmp13.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, tmp19.Invoke_O_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil), syms__6, bsyms__7, bis__4))); var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()); var tmp24 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_432); var tmp25 any; if


	jrt.A2g_Truth(unboxed_QMARK___2) { tmp25 = lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_388.Invoke_O__O(n__1)) } else { tmp25 = lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_388.Invoke_O__O(n__1)) }; return /*line :804:1*/ tmp11.Invoke_O_O_O__O(tmp12, tmp22, tmp23.Invoke_O_O_O__O(tmp24, sets__9, lang.Tuple_Create_O__IPersistentVector(tmp25))) }
//line :795:1
func A_arbace_aot_emit_emit_letfn_fn__90000190_A_New() *A_arbace_aot_emit_emit_letfn_fn__90000190_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_letfn_fn__90000190_A{}; t.Ctor(); return t }
//line :795:1
func (t *A_arbace_aot_emit_emit_letfn_fn__90000190_A) Ctor() {}
//line :795:1
func (t *A_arbace_aot_emit_emit_letfn_fn__90000190_A) Invoke_O_O__O(self, p1__90000188_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_aot_emit_A_const_264.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_386.Invoke_O__O(p1__90000188_SHARP___1))) }
func A_arbace_aot_emit_emit_letfn_fn__90000192_A_New() *A_arbace_aot_emit_emit_letfn_fn__90000192_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_letfn_fn__90000192_A{}; t.Ctor(); return t }
//line :796:1
func (t *A_arbace_aot_emit_emit_letfn_fn__90000192_A) Ctor() {}
//line :796:1
func (t *A_arbace_aot_emit_emit_letfn_fn__90000192_A) Invoke_O_O__O(self, p1__90000189_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_162, nil), jrt.RefArrayOf(jrt.Object_class, nil, p1__90000189_SHARP___1)).Ref()) }
func A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_A{}; t.Ctor_O_O(p0, p1); return t }
//line :797:1
func (t *A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_A) Ctor_O_O(c__ctx, c__lbs any) { t.F_ctx = c__ctx; t.F_lbs = c__lbs }
//line :797:1
func (t *A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_A) Invoke_O_O__O(self, s__90000195__1 any) any { var tmp1 any = A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_fn__90000199_A_New_O_O_O_O(s__90000195__1, t.F_ctx, self, t.F_lbs); var tmp2 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_fn__90000199_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_163, false); A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_fn__90000199_A_fn_class = fncls__33d; tmp2 = fncls__33d } else { tmp2 = fncls__33 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :797:1
func A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_fn__90000199_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_fn__90000199_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_fn__90000199_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :797:1
func (t *A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_fn__90000199_A) Ctor_O_O_O_O(c__s__90000195, c__ctx, c__iter__90000194, c__lbs any) { t.F_s__90000195 = c__s__90000195; t.F_ctx = c__ctx; t.F_iter__90000194 = c__iter__90000194; t.F_lbs = c__lbs }
//line :797:1
func (t *A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_fn__90000199_A) Invoke_O__O(self any) any { { var s__90000195__1 any; var t_ any = t.F_s__90000195; t.F_s__90000195 = nil; s__90000195__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(s__90000195__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__90000195__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(s__90000195__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(s__90000195__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__90000197__6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_401.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_fn__90000199_fn__90000200_A_New_O_O_O_I_O(t.F_ctx, b__90000197__6, t.F_lbs, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_fn__90000199_fn__90000200_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_164, false); A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_fn__90000199_fn__90000200_A_fn_class = fncls__32d; tmp2 = fncls__32d } else { tmp2 = fncls__32 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__90000194); return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000197__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__90000195__3))) } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000197__6), nil) } } else { var bi__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__90000195__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_426.GetRawRoot__O()); var tmp5 any = t.F_ctx; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__90000194); return lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O_O_O__O(tmp5, lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_356.Invoke_O__O(bi__4)), t.F_lbs), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(s__90000195__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :797:1
func A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_fn__90000199_fn__90000200_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_fn__90000199_fn__90000200_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_fn__90000199_fn__90000200_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :797:1
func (t *A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_fn__90000199_fn__90000200_A) Ctor_O_O_O_I_O(c__ctx, c__b__90000197, c__lbs any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_ctx = c__ctx; t.F_b__90000197 = c__b__90000197; t.F_lbs = c__lbs; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :797:1
func (t *A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_fn__90000199_fn__90000200_A) Invoke_O__O(self any) any { { var i__90000196__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__90000196__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var bi__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__90000196__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_402.GetRawRoot__O()); var tmp3 any = t.F_b__90000197; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_426.GetRawRoot__O()); var tmp5 any = t.F_ctx; tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O__O(tmp5, lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_356.Invoke_O__O(bi__2)), t.F_lbs)); i__90000196__1 = lang.Numbers_Unchecked_inc_J__J(i__90000196__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }
func A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_A{}; t.Ctor_O_O(p0, p1); return t }
//line :798:1
func (t *A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_A) Ctor_O_O(c__ctx, c__lbs any) { t.F_ctx = c__ctx; t.F_lbs = c__lbs }
//line :798:1
func (t *A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_A) Invoke_O_O__O(self, s__90000205__1 any) any { var tmp1 any = A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_A_New_O_O_O_O(t.F_ctx, s__90000205__1, self, t.F_lbs); var tmp2 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_165, false); A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_A_fn_class = fncls__38d; tmp2 = fncls__38d } else { tmp2 = fncls__38 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :798:1
func A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :798:1
func (t *A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_A) Ctor_O_O_O_O(c__ctx, c__s__90000205, c__iter__90000204, c__lbs any) { t.F_ctx = c__ctx; t.F_s__90000205 = c__s__90000205; t.F_iter__90000204 = c__iter__90000204; t.F_lbs = c__lbs }
//line :798:1
func (t *A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_A) Invoke_O__O(self any) any { { var s__90000205__1 any; var t_ any = t.F_s__90000205; t.F_s__90000205 = nil; s__90000205__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(s__90000205__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__90000212__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var bi__5 any = lang.RT_Nth_O_I_O__O(vec__90000212__4, lang.RT_IntCast_J__I(0), nil); var bs__6 any = lang.RT_Nth_O_I_O__O(vec__90000212__4, lang.RT_IntCast_J__I(1), nil); var ox__7 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_356.Invoke_O__O(bi__5)); var cname__8 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_400.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, ox__7); var iterys__1927001035__auto____9 any; var tmp1 any = A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_A_New_O_O(bs__6, t.F_lbs); var tmp2 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_A_fn_class; _ = cname__8; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_166, false); A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_A_fn_class = fncls__37d; tmp2 = fncls__37d } else { tmp2 = fncls__37 }; iterys__1927001035__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____10 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____9).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_406.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_407.Invoke_O__O(ox__7)))); if jrt.A2g_Truth(fs__1927001036__auto____10) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__90000204); return lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____10, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(s__90000205__1))) } else { s__90000205__1 = lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(s__90000205__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :798:1
func A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_A{}; t.Ctor_O_O(p0, p1); return t }
//line :798:1
func (t *A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_A) Ctor_O_O(c__bs, c__lbs any) { t.F_bs = c__bs; t.F_lbs = c__lbs }
//line :798:1
func (t *A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_A) Invoke_O_O__O(self, s__90000207__1 any) any { var tmp1 any = A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_fn__90000216_A_New_O_O_O_O(t.F_bs, s__90000207__1, self, t.F_lbs); var tmp2 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_fn__90000216_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_167, false); A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_fn__90000216_A_fn_class = fncls__36d; tmp2 = fncls__36d } else { tmp2 = fncls__36 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :798:1
func A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_fn__90000216_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_fn__90000216_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_fn__90000216_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :798:1
func (t *A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_fn__90000216_A) Ctor_O_O_O_O(c__bs, c__s__90000207, c__iter__90000206, c__lbs any) { t.F_bs = c__bs; t.F_s__90000207 = c__s__90000207; t.F_iter__90000206 = c__iter__90000206; t.F_lbs = c__lbs }
//line :798:1
func (t *A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_fn__90000216_A) Invoke_O__O(self any) any { { var s__90000207__1 any; var t_ any = t.F_s__90000207; t.F_s__90000207 = nil; s__90000207__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(s__90000207__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__90000207__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(s__90000207__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(s__90000207__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__90000209__6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_401.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_fn__90000216_fn__90000217_A_New_O_O_I_O_O(t.F_bs, t.F_lbs, size__1927001038__auto____5, b__90000209__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_fn__90000216_fn__90000217_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_168, false); A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_fn__90000216_fn__90000217_A_fn_class = fncls__35d; tmp2 = fncls__35d } else { tmp2 = fncls__35 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__90000206); return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000209__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__90000207__3))) } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000209__6), nil) } } else { var lb__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__90000207__3); if jrt.NN(jrt.IdentityHashMap_Cast(t.F_lbs)).ContainsKey_O__Z(lb__4) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_A_const_429; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__90000206); return lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O_O_O__O(tmp5, lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_221.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__4)), t.F_bs), lang.IFn_Cast(A_arbace_aot_emit_A_const_264.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__4))), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(s__90000207__3))) } else { s__90000207__1 = lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(s__90000207__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :798:1
func A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_fn__90000216_fn__90000217_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_fn__90000216_fn__90000217_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_fn__90000216_fn__90000217_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :798:1
func (t *A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_fn__90000216_fn__90000217_A) Ctor_O_O_I_O_O(c__bs, c__lbs any, c__size__1927001038__auto__ int32, c__b__90000209, c__c__1927001037__auto__ any) { t.F_bs = c__bs; t.F_lbs = c__lbs; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__90000209 = c__b__90000209; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :798:1
func (t *A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_fn__90000216_fn__90000217_A) Invoke_O__O(self any) any { { var i__90000208__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__90000208__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var lb__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__90000208__1)); if jrt.NN(jrt.IdentityHashMap_Cast(t.F_lbs)).ContainsKey_O__Z(lb__2) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_402.GetRawRoot__O()); var tmp3 any = t.F_b__90000209; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_A_const_429; tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O__O(tmp5, lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_221.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__2)), t.F_bs), lang.IFn_Cast(A_arbace_aot_emit_A_const_264.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__2)))); i__90000208__1 = lang.Numbers_Unchecked_inc_J__J(i__90000208__1); continue L1 } else { i__90000208__1 = lang.Numbers_Unchecked_inc_J__J(i__90000208__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }






func A_arbace_aot_emit_emit_letfn_fn__90000223_A_New_O(p0 any) *A_arbace_aot_emit_emit_letfn_fn__90000223_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_letfn_fn__90000223_A{}; t.Ctor_O(p0); return t }
//line :805:1
func (t *A_arbace_aot_emit_emit_letfn_fn__90000223_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :805:1
func (t *A_arbace_aot_emit_emit_letfn_fn__90000223_A) Invoke_O_O_O_O__O(self, bs__1, bi__2, b__3 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_400.GetRawRoot__O()); var tmp2 any = t.F_ctx; return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(bs__1, lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_356.Invoke_O__O(bi__2))))), b__3) }
func A_arbace_aot_emit_emit_letfn_fn__90000225_A_New_O(p0 any) *A_arbace_aot_emit_emit_letfn_fn__90000225_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_letfn_fn__90000225_A{}; t.Ctor_O(p0); return t }
//line :806:1
func (t *A_arbace_aot_emit_emit_letfn_fn__90000225_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :806:1
func (t *A_arbace_aot_emit_emit_letfn_fn__90000225_A) Invoke_O_O_O_O__O(self, s__1, bs__2, bi__3 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_427.GetRawRoot__O()); var tmp2 any = t.F_ctx; return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(s__1, A_arbace_aot_emit_A_const_228), tmp1.Invoke_O_O_O__O(tmp2, lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_356.Invoke_O__O(bi__3)), bs__2)) }


func A_arbace_aot_emit_emit_try_A_New() *A_arbace_aot_emit_emit_try_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_try_A{}; t.Ctor(); return t }
//line :809:1
func (t *A_arbace_aot_emit_emit_try_A) Ctor() {}
//line :809:1
func (t *A_arbace_aot_emit_emit_try_A) Invoke_O_O_O_O__O(self, ctx__0, n__1, unboxed_QMARK___2 any) any { var body__4 any; var tmp1 any = A_arbace_aot_emit_emit_try_body__90000228_A_New_O_O(ctx__0, unboxed_QMARK___2); var tmp2 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_aot_emit_emit_try_body__90000228_A_fn_class; if
													fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_179, false); A_arbace_aot_emit_emit_try_body__90000228_A_fn_class = fncls__44d; tmp2 = fncls__44d } else { tmp2 = fncls__44 }; body__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn =
													lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_A_const_437; var tmp6 any = tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(body__4).Invoke_O__O(A_arbace_aot_emit_A_const_438.Invoke_O__O(n__1))); var tmp7 any; var iter__1927001039__auto____5 any; var tmp8 any = A_arbace_aot_emit_emit_try_iter__90000230__90000234_A_New_O(body__4); var tmp9 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_aot_emit_emit_try_iter__90000230__90000234_A_fn_class; if
													fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_180, false); A_arbace_aot_emit_emit_try_iter__90000230__90000234_A_fn_class = fncls__47d; tmp9 = fncls__47d } else { tmp9 = fncls__47 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); tmp7 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(A_arbace_aot_emit_A_const_439.Invoke_O__O(n__1)); var tmp10 any = tmp7; var tmp11 lang.IPersistentVector; if


	jrt.A2g_Truth(A_arbace_aot_emit_A_const_436.Invoke_O__O(n__1)) { var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp13 any = A_arbace_aot_emit_A_const_440; tmp11 = lang.Tuple_Create_O__IPersistentVector(tmp12.Invoke_O_O__O(tmp13, lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_436.Invoke_O__O(n__1)))) } else { tmp11 = nil }; return /*line :811:1*/ tmp3.Invoke_O_O_O__O(tmp6, tmp10, tmp11) }
//line :810:1
func A_arbace_aot_emit_emit_try_body__90000228_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_emit_try_body__90000228_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_try_body__90000228_A{}; t.Ctor_O_O(p0, p1); return t }
//line :810:1
func (t *A_arbace_aot_emit_emit_try_body__90000228_A) Ctor_O_O(c__ctx, c__unboxed_QMARK_ any) { t.F_ctx = c__ctx; t.F_unboxed_QMARK_ = c__unboxed_QMARK_ }
//line :810:1
func (t *A_arbace_aot_emit_emit_try_body__90000228_A) Invoke_O_O__O(self, e__1 any) any { if jrt.A2g_Truth(t.F_unboxed_QMARK_) { return lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, e__1) } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, e__1) } }

func A_arbace_aot_emit_emit_try_iter__90000230__90000234_A_New_O(p0 any) *A_arbace_aot_emit_emit_try_iter__90000230__90000234_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_try_iter__90000230__90000234_A{}; t.Ctor_O(p0); return t }
//line :812:1
func (t *A_arbace_aot_emit_emit_try_iter__90000230__90000234_A) Ctor_O(c__body any) { t.F_body = c__body }
//line :812:1
func (t *A_arbace_aot_emit_emit_try_iter__90000230__90000234_A) Invoke_O_O__O(self, s__90000231__1 any) any { var tmp1 any = A_arbace_aot_emit_emit_try_iter__90000230__90000234_fn__90000235_A_New_O_O_O(s__90000231__1, self, t.F_body); var tmp2 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_aot_emit_emit_try_iter__90000230__90000234_fn__90000235_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_181, false); A_arbace_aot_emit_emit_try_iter__90000230__90000234_fn__90000235_A_fn_class = fncls__46d; tmp2 = fncls__46d } else { tmp2 = fncls__46 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :812:1
func A_arbace_aot_emit_emit_try_iter__90000230__90000234_fn__90000235_A_New_O_O_O(p0, p1, p2 any) *A_arbace_aot_emit_emit_try_iter__90000230__90000234_fn__90000235_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_try_iter__90000230__90000234_fn__90000235_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :812:1
func (t *A_arbace_aot_emit_emit_try_iter__90000230__90000234_fn__90000235_A) Ctor_O_O_O(c__s__90000231, c__iter__90000230, c__body any) { t.F_s__90000231 = c__s__90000231; t.F_iter__90000230 = c__iter__90000230; t.F_body = c__body }
//line :812:1
func (t *A_arbace_aot_emit_emit_try_iter__90000230__90000234_fn__90000235_A) Invoke_O__O(self any) any { { var s__90000231__1 any; var t_ any = t.F_s__90000231; t.F_s__90000231 = nil; s__90000231__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(s__90000231__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__90000231__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(s__90000231__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(s__90000231__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__90000233__6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_401.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_aot_emit_emit_try_iter__90000230__90000234_fn__90000235_fn__90000236_A_New_O_I_O_O(b__90000233__6, size__1927001038__auto____5, t.F_body, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_aot_emit_emit_try_iter__90000230__90000234_fn__90000235_fn__90000236_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_182, false); A_arbace_aot_emit_emit_try_iter__90000230__90000234_fn__90000235_fn__90000236_A_fn_class = fncls__45d; tmp2 = fncls__45d } else { tmp2 = fncls__45 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__90000230); return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000233__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__90000231__3))) } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000233__6), nil) } } else { var c__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__90000231__3); var cn__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(c__4); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_A_const_433; var tmp6 lang.IFn = lang.IFn_Cast(t.F_body); var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__90000230); return lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O_O_O_O__O(tmp5, lang.IFn_Cast(A_arbace_aot_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_340.Invoke_O__O(cn__5)), lang.IFn_Cast(A_arbace_aot_emit_A_const_264.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_434.Invoke_O__O(cn__5))), tmp6.Invoke_O__O(A_arbace_aot_emit_A_const_435.Invoke_O__O(cn__5))), tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(s__90000231__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :812:1
func A_arbace_aot_emit_emit_try_iter__90000230__90000234_fn__90000235_fn__90000236_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_aot_emit_emit_try_iter__90000230__90000234_fn__90000235_fn__90000236_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_try_iter__90000230__90000234_fn__90000235_fn__90000236_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :812:1
func (t *A_arbace_aot_emit_emit_try_iter__90000230__90000234_fn__90000235_fn__90000236_A) Ctor_O_I_O_O(c__b__90000233 any, c__size__1927001038__auto__ int32, c__body, c__c__1927001037__auto__ any) { t.F_b__90000233 = c__b__90000233; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_body = c__body; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :812:1
func (t *A_arbace_aot_emit_emit_try_iter__90000230__90000234_fn__90000235_fn__90000236_A) Invoke_O__O(self any) any { { var i__90000232__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__90000232__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__90000232__1)); var cn__3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(c__2); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_402.GetRawRoot__O()); var tmp3 any = t.F_b__90000233; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_A_const_433; var tmp6 lang.IFn = lang.IFn_Cast(t.F_body); tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O_O__O(tmp5, lang.IFn_Cast(A_arbace_aot_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_340.Invoke_O__O(cn__3)), lang.IFn_Cast(A_arbace_aot_emit_A_const_264.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_434.Invoke_O__O(cn__3))), tmp6.Invoke_O__O(A_arbace_aot_emit_A_const_435.Invoke_O__O(cn__3)))); i__90000232__1 = lang.Numbers_Unchecked_inc_J__J(i__90000232__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }





func A_arbace_aot_emit_emit_case_A_New() *A_arbace_aot_emit_emit_case_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_case_A{}; t.Ctor(); return t }
//line :818:1
func (t *A_arbace_aot_emit_emit_case_A) Ctor() {}
//line :818:1
func (t *A_arbace_aot_emit_emit_case_A) Invoke_O_O_O_O__O(self, ctx__0, n__1, unboxed_QMARK___2 any) any { var e__4 any = A_arbace_aot_emit_A_const_441.Invoke_O__O(n__1); var en__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(e__4); var pt__6 any = A_arbace_aot_emit_A_const_223.Invoke_O__O(en__5); var shift__7 any = A_arbace_aot_emit_A_const_442.Invoke_O__O(n__1); var mask__8 any = A_arbace_aot_emit_A_const_443.Invoke_O__O(n__1); var sm__9 any; var tmp1 any = A_arbace_aot_emit_emit_case_sm__90000241_A_New_O_O(mask__8, shift__7); var tmp2 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_aot_emit_emit_case_sm__90000241_A_fn_class; if




	fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_86, false); A_arbace_aot_emit_emit_case_sm__90000241_A_fn_class = fncls__48d; tmp2 = fncls__48d } else { tmp2 = fncls__48 }; sm__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tests__10 any = /*line :818:1*/lang.IFn_Cast(A_arbace_aot_emit_A_const_190.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_472.GetRawRoot__O()).Invoke__O(), A_arbace_aot_emit_A_const_473.Invoke_O__O(n__1)); var thens__11 any = A_arbace_aot_emit_A_const_446.Invoke_O__O(n__1); var ret__12 any; var tmp3 any = A_arbace_aot_emit_emit_case_ret__90000243_A_New_O_O(ctx__0, unboxed_QMARK___2); var tmp4 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_aot_emit_emit_case_ret__90000243_A_fn_class; if







	fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_87, false); A_arbace_aot_emit_emit_case_ret__90000243_A_fn_class = fncls__49d; tmp4 = fncls__49d } else { tmp4 = fncls__49 }; ret__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var lbl__13 any = /*line :818:1*/lang.IFn_Cast(A_arbace_aot_emit_A_const_447.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_285.GetRawRoot__O()).Invoke_O_O__O(ctx__0, Lit_88))); var int_test_QMARK___14 bool = lang.Util_Equiv_O_O__Z(A_arbace_aot_emit_A_const_448.Invoke_O__O(n__1), A_arbace_aot_emit_A_const_133); var key__15 any; if










	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(int_test_QMARK___14).Ref())) {
		var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp6 any = A_arbace_aot_emit_A_const_474; key__15 = lang.IFn_Cast(sm__9).Invoke_O__O(tmp5.Invoke_O_O__O(tmp6, lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, e__4))) } else {
//line :829:1
			if lang.Util_Identical_O_O__Z(pt__6, nil) { key__15 = nil } else { var tmp7 *jrt.Class; jrt.Byte_Init(); tmp7 = jrt.Byte_TYPE; var tmp8 any = tmp7.Ref(); var tmp9 *jrt.Class; jrt.Long_Init(); tmp9 = jrt.Long_TYPE; var tmp10 any = tmp9.Ref(); var tmp11 *jrt.Class; jrt.Short_Init(); tmp11 = jrt.Short_TYPE; var tmp12 any = tmp11.Ref(); var tmp13 *jrt.Class; jrt.Integer_Init(); tmp13 = jrt.Integer_TYPE; if jrt.A2g_Truth(lang.IFn_Cast(lang.RT_Set_O1__IPersistentSet(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp10, tmp12, tmp13.Ref()))).Invoke_O__O(pt__6)) {


				var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp15 any = A_arbace_aot_emit_A_const_475; key__15 = lang.IFn_Cast(sm__9).Invoke_O__O(tmp14.Invoke_O_O__O(tmp15, lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(ctx__0, e__4))) } else {
//line :829:1
					if A_arbace_aot_emit_A_const_60 != nil { key__15 = A_arbace_aot_emit_A_const_449 } else { key__15 = nil } } } }; var skip__16 any = /*line :818:1*/lang.IFn_Cast(A_arbace_aot_emit_A_const_450.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_476.Invoke_O__O(n__1)); var arm__17 any; var tmp16 any = A_arbace_aot_emit_emit_case_arm__90000245_A_New_O_O_O_O_O_O_Z_O_O(e__4, mask__8, ctx__0, lbl__13, n__1, skip__16, int_test_QMARK___14, ret__12, pt__6); var tmp17 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_aot_emit_emit_case_arm__90000245_A_fn_class; if
















	fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_89, false); A_arbace_aot_emit_emit_case_arm__90000245_A_fn_class = fncls__50d; tmp17 = fncls__50d } else { tmp17 = fncls__50 }; arm__17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var sw__18 any; if


















	lang.Util_Equiv_O_O__Z(key__15, A_arbace_aot_emit_A_const_449) { sw__18 = nil } else { var tmp18 bool
		var and__1927000168__auto____18 bool = int_test_QMARK___14
		if and__1927000168__auto____18 { tmp18 = lang.Util_Identical_O_O__Z(pt__6, nil) } else { tmp18 = and__1927000168__auto____18 }
//line :854:1
		if tmp18 {


			var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp20 any = A_arbace_aot_emit_A_const_477; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp22 any = A_arbace_aot_emit_A_const_478; var tmp23 any = A_arbace_aot_emit_A_const_479; var tmp24 any = tmp21.Invoke_O_O_O__O(tmp22, tmp23, lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, e__4)); var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()); var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp27 any = A_arbace_aot_emit_A_const_480; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp29 any = A_arbace_aot_emit_A_const_481; var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp31 any = A_arbace_aot_emit_A_const_482; var tmp32 any = A_arbace_aot_emit_A_const_483; var tmp33 any = tmp26.Invoke_O_O__O(tmp27, lang.IFn_Cast(sm__9).Invoke_O__O(tmp28.Invoke_O_O__O(tmp29, tmp30.Invoke_O_O_O__O(tmp31, tmp32, lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, e__4))))); var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_98.GetRawRoot__O()); var tmp35 any = A_arbace_aot_emit_emit_case_fn__90000248_A_New_O_O(arm__17, thens__11); var tmp36 *jrt.Class
			var fncls__51 /*line :857:1*/*jrt.Class = A_arbace_aot_emit_emit_case_fn__90000248_A_fn_class

			if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_90, false); A_arbace_aot_emit_emit_case_fn__90000248_A_fn_class = fncls__51d; tmp36 = fncls__51d } else { tmp36 = fncls__51 }
//line :857:1
			sw__18 = tmp19.Invoke_O_O_O__O(tmp20, tmp24, tmp25.Invoke_O_O__O(tmp33, tmp34.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp35, tmp36, nil), tests__10))) } else {
//line :854:1
				if A_arbace_aot_emit_A_const_60 != nil {






					var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()); var tmp38 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_484, key__15); var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_98.GetRawRoot__O()); var tmp40 any = A_arbace_aot_emit_emit_case_fn__90000254_A_New_O_O(arm__17, thens__11); var tmp41 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_aot_emit_emit_case_fn__90000254_A_fn_class
					if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_91, false); A_arbace_aot_emit_emit_case_fn__90000254_A_fn_class = fncls__52d; tmp41 = fncls__52d } else { tmp41 = fncls__52 }
//line :861:1
					sw__18 = tmp37.Invoke_O_O__O(tmp38, tmp39.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp40, tmp41, nil), tests__10)) } else {
//line :854:1
						sw__18 = nil } } }; var tmp42 lang.IFn =








	lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp43 any = A_arbace_aot_emit_A_const_485; return tmp42.Invoke_O_O_O_O__O(tmp43, lbl__13, sw__18, lang.IFn_Cast(ret__12).Invoke_O__O(A_arbace_aot_emit_A_const_486.Invoke_O__O(n__1))) }
//line :823:1
func A_arbace_aot_emit_emit_case_sm__90000241_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_emit_case_sm__90000241_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_case_sm__90000241_A{}; t.Ctor_O_O(p0, p1); return t }
//line :823:1
func (t *A_arbace_aot_emit_emit_case_sm__90000241_A) Ctor_O_O(c__mask, c__shift any) { t.F_mask = c__mask; t.F_shift = c__shift }
//line :823:1
func (t *A_arbace_aot_emit_emit_case_sm__90000241_A) Invoke_O_O__O(self, f__1 any) any { if lang.Numbers_IsZero_O__Z(t.F_mask) { return f__1 } else { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp2 any = A_arbace_aot_emit_A_const_444; return tmp1.Invoke_O_O_O__O(tmp2, lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_aot_emit_A_const_445, f__1, t.F_shift), jrt.Integer_ValueOf_I__Integer(lang.RT_UncheckedIntCast_O__I(t.F_mask)).Ref()) } }


func A_arbace_aot_emit_emit_case_ret__90000243_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_emit_case_ret__90000243_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_case_ret__90000243_A{}; t.Ctor_O_O(p0, p1); return t }
//line :826:1
func (t *A_arbace_aot_emit_emit_case_ret__90000243_A) Ctor_O_O(c__ctx, c__unboxed_QMARK_ any) { t.F_ctx = c__ctx; t.F_unboxed_QMARK_ = c__unboxed_QMARK_ }
//line :826:1
func (t *A_arbace_aot_emit_emit_case_ret__90000243_A) Invoke_O_O__O(self, x__1 any) any { if jrt.A2g_Truth(t.F_unboxed_QMARK_) { return lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, x__1) } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, x__1) } }








func A_arbace_aot_emit_emit_case_arm__90000245_A_New_O_O_O_O_O_O_Z_O_O(p0, p1, p2, p3, p4, p5 any, p6 bool, p7, p8 any) *A_arbace_aot_emit_emit_case_arm__90000245_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_case_arm__90000245_A{}; t.Ctor_O_O_O_O_O_O_Z_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8); return t }
//line :835:1
func (t *A_arbace_aot_emit_emit_case_arm__90000245_A) Ctor_O_O_O_O_O_O_Z_O_O(c__e, c__mask, c__ctx, c__lbl, c__n, c__skip any, c__int_test_QMARK_ bool, c__ret, c__pt any) { t.F_e = c__e; t.F_mask = c__mask; t.F_ctx = c__ctx; t.F_lbl = c__lbl; t.F_n = c__n; t.F_skip = c__skip; t.F_int_test_QMARK_ = c__int_test_QMARK_; t.F_ret = c__ret; t.F_pt = c__pt }
//line :835:1
func (t *A_arbace_aot_emit_emit_case_arm__90000245_A) Invoke_O_O_O_O__O(self, i__1, t__2, th__3 any) any {
	var tmp1 bool; var and__1927000168__auto____4 bool = t.F_int_test_QMARK_
	if and__1927000168__auto____4 { tmp1 = lang.Util_Identical_O_O__Z(t.F_pt, nil) } else { tmp1 = and__1927000168__auto____4 }
//line :836:1
	if tmp1 {

		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp3 any = A_arbace_aot_emit_A_const_452; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_A_const_455; var tmp6 any = t.F_lbl; return tmp2.Invoke_O_O_O__O(tmp3, lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_453, A_arbace_aot_emit_A_const_454), lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, t.F_e), lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, t__2)), tmp4.Invoke_O_O_O__O(tmp5, tmp6, lang.IFn_Cast(t.F_ret).Invoke_O__O(th__3))) } else {
//line :836:1
			var tmp7 bool; var and__1927000168__auto____4_2 bool = t.F_int_test_QMARK_




			if and__1927000168__auto____4_2 { var tmp8 any = t.F_pt; var tmp9 *jrt.Class; jrt.Long_Init(); tmp9 = jrt.Long_TYPE; tmp7 = lang.Util_Equiv_O_O__Z(tmp8, tmp9.Ref()) } else { tmp7 = and__1927000168__auto____4_2 }
//line :836:1
			if tmp7 {





				var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp11 any = A_arbace_aot_emit_A_const_456; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp13 any = A_arbace_aot_emit_A_const_457; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp15 any = A_arbace_aot_emit_A_const_458; var tmp16 any = t.F_lbl; return tmp10.Invoke_O_O_O__O(tmp11, tmp12.Invoke_O_O_O__O(tmp13, lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, t__2), lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, t.F_e)), tmp14.Invoke_O_O_O__O(tmp15, tmp16, lang.IFn_Cast(t.F_ret).Invoke_O__O(th__3))) } else {
//line :836:1
					if t.F_int_test_QMARK_ {







						if lang.Numbers_IsZero_O__Z(t.F_mask) {
							var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp18 any = A_arbace_aot_emit_A_const_459; var tmp19 any = t.F_lbl; return tmp17.Invoke_O_O_O__O(tmp18, tmp19, lang.IFn_Cast(t.F_ret).Invoke_O__O(th__3)) } else {
								var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp21 any = A_arbace_aot_emit_A_const_460; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp23 any = A_arbace_aot_emit_A_const_461; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp25 any = A_arbace_aot_emit_A_const_462; var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp27 any = A_arbace_aot_emit_A_const_463; var tmp28 any = t.F_lbl; return tmp20.Invoke_O_O_O__O(tmp21, tmp22.Invoke_O_O_O__O(tmp23, lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, t__2), tmp24.Invoke_O_O__O(tmp25, lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, t.F_e))), tmp26.Invoke_O_O_O__O(tmp27, tmp28, lang.IFn_Cast(t.F_ret).Invoke_O__O(th__3))) } } else {
//line :836:1
									if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_28.GetRawRoot__O()).Invoke_O_O__O(t.F_skip, i__1)) {










										var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp30 any = A_arbace_aot_emit_A_const_464; var tmp31 any = t.F_lbl; return tmp29.Invoke_O_O_O__O(tmp30, tmp31, lang.IFn_Cast(t.F_ret).Invoke_O__O(th__3)) } else {
//line :836:1
											if lang.Util_Equiv_O_O__Z(A_arbace_aot_emit_A_const_448.Invoke_O__O(t.F_n), A_arbace_aot_emit_A_const_451) {












												var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp33 any = A_arbace_aot_emit_A_const_465; var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp35 any = A_arbace_aot_emit_A_const_466; var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp37 any = A_arbace_aot_emit_A_const_467; var tmp38 any = t.F_lbl; return tmp32.Invoke_O_O_O__O(tmp33, tmp34.Invoke_O_O_O__O(tmp35, lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, t.F_e), lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, t__2)), tmp36.Invoke_O_O_O__O(tmp37, tmp38, lang.IFn_Cast(t.F_ret).Invoke_O__O(th__3))) } else {
//line :836:1
													if A_arbace_aot_emit_A_const_60 != nil {














														var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp40 any = A_arbace_aot_emit_A_const_468; var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp42 any = A_arbace_aot_emit_A_const_471; var tmp43 any = t.F_lbl; return tmp39.Invoke_O_O_O__O(tmp40, lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_469, A_arbace_aot_emit_A_const_470), lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, t.F_e), lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, t__2)), tmp41.Invoke_O_O_O__O(tmp42, tmp43, lang.IFn_Cast(t.F_ret).Invoke_O__O(th__3))) } else {
//line :836:1
															return nil
														}
												}
										}
								}
				}
		}
}















func A_arbace_aot_emit_emit_case_fn__90000248_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_emit_case_fn__90000248_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_case_fn__90000248_A{}; t.Ctor_O_O(p0, p1); return t }
//line :859:1
func (t *A_arbace_aot_emit_emit_case_fn__90000248_A) Ctor_O_O(c__arm, c__thens any) { t.F_arm = c__arm; t.F_thens = c__thens }
//line :859:1
func (t *A_arbace_aot_emit_emit_case_fn__90000248_A) Invoke_O_O__O(self, p__90000247__1 any) any { var vec__90000249__2 any = p__90000247__1; var i__3 any = lang.RT_Nth_O_I_O__O(vec__90000249__2, lang.RT_IntCast_J__I(0), nil); var t__4 any = lang.RT_Nth_O_I_O__O(vec__90000249__2, lang.RT_IntCast_J__I(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(t.F_arm); return lang.Tuple_Create_O_O__IPersistentVector(i__3, tmp1.Invoke_O_O_O__O(i__3, t__4, lang.RT_Get_O_O__O(t.F_thens, i__3))) }


func A_arbace_aot_emit_emit_case_fn__90000254_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_emit_case_fn__90000254_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_case_fn__90000254_A{}; t.Ctor_O_O(p0, p1); return t }
//line :862:1
func (t *A_arbace_aot_emit_emit_case_fn__90000254_A) Ctor_O_O(c__arm, c__thens any) { t.F_arm = c__arm; t.F_thens = c__thens }
//line :862:1
func (t *A_arbace_aot_emit_emit_case_fn__90000254_A) Invoke_O_O__O(self, p__90000253__1 any) any { var vec__90000255__2 any = p__90000253__1; var i__3 any = lang.RT_Nth_O_I_O__O(vec__90000255__2, lang.RT_IntCast_J__I(0), nil); var t__4 any = lang.RT_Nth_O_I_O__O(vec__90000255__2, lang.RT_IntCast_J__I(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(t.F_arm); return lang.Tuple_Create_O_O__IPersistentVector(i__3, tmp1.Invoke_O_O_O__O(i__3, t__4, lang.RT_Get_O_O__O(t.F_thens, i__3))) }








func A_arbace_aot_emit_box_prim_A_New() *A_arbace_aot_emit_box_prim_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_box_prim_A{}; t.Ctor(); return t }
//line :871:1
func (t *A_arbace_aot_emit_box_prim_A) Ctor() {}
//line :871:1
func (t *A_arbace_aot_emit_box_prim_A) Invoke_O_O_O__O(self, f__0, n__1 any) any { var p__3 any = A_arbace_aot_emit_A_const_223.Invoke_O__O(n__1); var tmp1 any; var and__1927000168__auto____4 any = p__3; if





	jrt.A2g_Truth(and__1927000168__auto____4) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_487); var and__1927000168__auto____5 any = tmp2.Invoke_O__O(A_arbace_aot_emit_A_const_369.Invoke_O__O(n__1)); if jrt.A2g_Truth(and__1927000168__auto____5) {
		tmp1 = lang.IFn_Cast(A_arbace_aot_emit_A_const_227.GetRawRoot__O()).Invoke_O__O(p__3) } else {
//line :877:1
			tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.A2g_Truth(tmp1) {

				var tmp3 any = A_arbace_aot_emit_A_const_103; return lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_227.GetRawRoot__O()).Invoke_O__O(p__3), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_aot_emit_A_const_24.GetRawRoot__O()).Invoke_O__O(p__3))))), f__0) } else {
//line :877:1
					return f__0 } }




func A_arbace_aot_emit_emit_A_New() *A_arbace_aot_emit_emit_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_A{}; t.Ctor(); return t }
//line :882:1
func (t *A_arbace_aot_emit_emit_A) Ctor() {}
//line :882:1
func (t *A_arbace_aot_emit_emit_A) Invoke_O_O_O__O(self, ctx__0, e__1 any) any { var n__3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(e__1); var f__4 any; var G__90000262__4_ any = A_arbace_aot_emit_A_const_369.Invoke_O__O(n__3); L1:



switch { default: switch lang.Util_Hash_O__I(G__90000262__4_) >> 6 & 255 { case 6: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_39) {


























	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_488.GetRawRoot__O()); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_FALSE; f__4 = tmp1.Invoke_O_O_O__O(ctx__0, n__3, tmp2.Ref())
//line :886:1
	break L1 }; case 8: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_2) {




















































		if jrt.A2g_Truth(A_arbace_aot_emit_A_const_489.Invoke_O__O(n__3)) {

			lang.IFn_Cast(A_arbace_aot_emit_A_const_494.GetRawRoot__O()).Invoke_O_O__O(ctx__0, n__3)
//line :939:1
			f__4 = nil } else {


				f__4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_490.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, n__3, jrt.IdentityHashMap_New()) }
//line :886:1
		break L1 }; case 16: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_40) {















			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_491.GetRawRoot__O()); var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_FALSE; f__4 = tmp3.Invoke_O_O_O__O(ctx__0, n__3, tmp4.Ref())
//line :886:1
			break L1 }; case 17: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_41) {


















































				f__4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_492.GetRawRoot__O()).Invoke_O_O__O(ctx__0, n__3)
//line :886:1
				break L1 }; case 20: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_42) {






















					var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_319.GetRawRoot__O()); var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_FALSE; f__4 = tmp5.Invoke_O_O_O__O(ctx__0, n__3, tmp6.Ref())
//line :886:1
					break L1 }; case 21: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_43) { var c__5 any = A_arbace_aot_emit_A_const_495.Invoke_O__O(n__3)








						if lang.IPersistentList_InstanceOf(c__5) { f__4 = A_arbace_aot_emit_A_const_496 } else { if lang.IPersistentVector_InstanceOf(c__5) { f__4 = A_arbace_aot_emit_A_const_497 } else { if lang.IPersistentMap_InstanceOf(c__5) { f__4 = A_arbace_aot_emit_A_const_498 } else { if lang.IPersistentSet_InstanceOf(c__5) { f__4 = A_arbace_aot_emit_A_const_499 } else { if A_arbace_aot_emit_A_const_60 != nil {



							f__4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(Lit_44) } else {
//line :895:1
								f__4 = nil } } } } }
//line :886:1
						break L1 }; case 23: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_45) {




















							var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_500.GetRawRoot__O()); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_FALSE; f__4 = tmp7.Invoke_O_O_O__O(ctx__0, n__3, tmp8.Ref())
//line :886:1
							break L1 }; case 28: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_46) {













								f__4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_501.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_140.Invoke_O__O(n__3))
//line :886:1
								break L1 }; case 35: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_47) {








































									var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp10 any = A_arbace_aot_emit_A_const_503; var tmp11 *lang.Keyword = A_arbace_aot_emit_A_const_504; f__4 = tmp9.Invoke_O_O_O__O(tmp10, lang.IFn_Cast(A_arbace_aot_emit_A_const_212.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, tmp11.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_506.Invoke_O__O(n__3))), A_arbace_aot_emit_A_const_505), lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_322.Invoke_O__O(n__3)))
//line :886:1
									break L1 }; case 50: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_48) { var es__5 any = A_arbace_aot_emit_A_const_502.Invoke_O__O(n__3)

























































										if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_109.GetRawRoot__O()).Invoke_O__O(es__5)) { f__4 = nil } else {

											var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()); var tmp13 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_508); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_507.GetRawRoot__O()); var tmp15 any = A_arbace_aot_emit_emit_fn__90000263_A_New_O(ctx__0); var tmp16 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_aot_emit_emit_fn__90000263_A_fn_class
											if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_49, false); A_arbace_aot_emit_emit_fn__90000263_A_fn_class = fncls__54d; tmp16 = fncls__54d } else { tmp16 = fncls__54 }
//line :946:1
											f__4 = tmp12.Invoke_O_O_O__O(tmp13, tmp14.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil), lang.IFn_Cast(A_arbace_aot_emit_A_const_509.GetRawRoot__O()).Invoke_O__O(es__5)), lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, lang.IFn_Cast(A_arbace_aot_emit_A_const_510.GetRawRoot__O()).Invoke_O__O(es__5)))) }
//line :886:1
										break L1 }; case 51: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_50) {



















































											f__4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_490.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, n__3, jrt.IdentityHashMap_New())
//line :886:1
											break L1 }; case 52: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_51) {































												var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_511.GetRawRoot__O()); var tmp18 *jrt.Boolean; jrt.Boolean_Init(); tmp18 = jrt.Boolean_FALSE; f__4 = tmp17.Invoke_O_O_O__O(ctx__0, n__3, tmp18.Ref())
//line :886:1
												break L1 }; case 63: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_52) {
















													f__4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_512.GetRawRoot__O()).Invoke_O_O__O(ctx__0, n__3)
//line :886:1
													break L1 }; case 74: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_53) {





























														var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp20 any = A_arbace_aot_emit_A_const_514; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp22 any = A_arbace_aot_emit_A_const_515; var tmp23 any = A_arbace_aot_emit_A_const_516; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp25 any = A_arbace_aot_emit_A_const_517; var tmp26 any = A_arbace_aot_emit_A_const_518; f__4 = tmp19.Invoke_O_O_O__O(tmp20, tmp21.Invoke_O_O_O__O(tmp22, tmp23, lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_441.Invoke_O__O(n__3))), tmp24.Invoke_O_O_O__O(tmp25, tmp26, lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_354.Invoke_O__O(n__3))))
//line :886:1
														break L1 }; case 80: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_54) {

































































															var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_513.GetRawRoot__O()); var tmp28 *jrt.Boolean; jrt.Boolean_Init(); tmp28 = jrt.Boolean_FALSE; f__4 = tmp27.Invoke_O_O_O__O(ctx__0, n__3, tmp28.Ref())
//line :886:1
															break L1 }; case 109: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_55) {

																f__4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_248.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_519.Invoke_O__O(n__3))
//line :886:1
																break L1 }; case 111: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_56) {














																	f__4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_212.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, A_arbace_aot_emit_A_const_140.Invoke_O__O(n__3), A_arbace_aot_emit_A_const_520)
//line :886:1
																	break L1 }; case 119: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_57) {




																		f__4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_212.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, A_arbace_aot_emit_A_const_504.Invoke_O__O(n__3), A_arbace_aot_emit_A_const_521)
//line :886:1
																		break L1 }; case 125: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_58) {
																			var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_403.GetRawRoot__O()); var tmp30 *jrt.Boolean; jrt.Boolean_Init(); tmp30 = jrt.Boolean_FALSE; f__4 = tmp29.Invoke_O_O_O__O(ctx__0, n__3, tmp30.Ref())
//line :886:1
																			break L1 }; case 128: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_59) {



																				f__4 = A_arbace_aot_emit_A_const_522.Invoke_O__O(n__3)
//line :886:1
																				break L1 }; case 133: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_60) { var args__5 any = A_arbace_aot_emit_A_const_271.Invoke_O__O(n__3)


































																					if lang.Numbers_Lte_J_J__Z(int64(lang.RT_Count_O__I(args__5)), 6) {
																						var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_100.GetRawRoot__O()); var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()); var tmp33 any = A_arbace_aot_emit_A_const_525; var tmp34 any = A_arbace_aot_emit_A_const_103; var tmp35 any = tmp32.Invoke_O_O__O(tmp33, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_105.GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(args__5)).Ref(), A_arbace_aot_emit_A_const_526))))); var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()); var tmp37 any = A_arbace_aot_emit_emit_fn__90000265_A_New_O(ctx__0); var tmp38 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_aot_emit_emit_fn__90000265_A_fn_class
																						if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_61, false); A_arbace_aot_emit_emit_fn__90000265_A_fn_class = fncls__55d; tmp38 = fncls__55d } else { tmp38 = fncls__55 }
//line :922:1
																						f__4 = tmp31.Invoke_O_O__O(tmp35, tmp36.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp37, tmp38, nil), args__5)) } else {

																							f__4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_523.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_aot_emit_A_const_527, args__5, ctx__0) }
//line :886:1
																					break L1 }; case 136: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_62) {
































































																						var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_524.GetRawRoot__O()); var tmp40 *jrt.Boolean; jrt.Boolean_Init(); tmp40 = jrt.Boolean_FALSE; f__4 = tmp39.Invoke_O_O_O__O(ctx__0, n__3, tmp40.Ref())
//line :886:1
																						break L1 }; case 140: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_63) {


































































																							f__4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_528.GetRawRoot__O()).Invoke_O_O__O(ctx__0, n__3)
//line :886:1
																							break L1 }; case 142: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_64) {


																								f__4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_248.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_529.Invoke_O__O(n__3))
//line :886:1
																								break L1 }; case 149: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_65) {






































																									var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_523.GetRawRoot__O()); var tmp42 any = A_arbace_aot_emit_A_const_530; f__4 = tmp41.Invoke_O_O_O__O(tmp42, A_arbace_aot_emit_A_const_531.Invoke_O__O(n__3), ctx__0)
//line :886:1
																									break L1 }; case 150: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_66) {

























																										var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp44 any = A_arbace_aot_emit_A_const_532; var tmp45 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp46 any = A_arbace_aot_emit_A_const_533; f__4 = tmp43.Invoke_O_O_O__O(tmp44, tmp45.Invoke_O_O__O(tmp46, lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_322.Invoke_O__O(n__3))), nil)
//line :886:1
																										break L1 }; case 155: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_67) {



























																											var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp48 any = A_arbace_aot_emit_A_const_535; var tmp49 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp50 any = A_arbace_aot_emit_A_const_536; var tmp51 any = A_arbace_aot_emit_A_const_537; f__4 = tmp47.Invoke_O_O__O(tmp48, tmp49.Invoke_O_O_O__O(tmp50, tmp51, lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_538.Invoke_O__O(n__3))))
//line :886:1
																											break L1 }; case 166: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_68) {




























																												f__4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_534.GetRawRoot__O()).Invoke_O_O__O(ctx__0, n__3)
//line :886:1
																												break L1 }; case 168: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_69) { f__4 = nil; break L1 }; case 176: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_70) {






																													if jrt.A2g_Truth(A_arbace_aot_emit_A_const_368.Invoke_O__O(n__3)) { f__4 = A_arbace_aot_emit_A_const_539 } else { f__4 = A_arbace_aot_emit_A_const_540 }
//line :886:1
																													break L1 }; case 178: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_71) {
























																														var tmp52 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp53 any = A_arbace_aot_emit_A_const_541; var tmp54 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp55 any = A_arbace_aot_emit_A_const_542; f__4 = tmp52.Invoke_O_O_O__O(tmp53, tmp54.Invoke_O_O__O(tmp55, lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_322.Invoke_O__O(n__3))), nil)
//line :886:1
																														break L1 }; case 194: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_72) {
































																															var tmp56 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_523.GetRawRoot__O()); var tmp57 any = A_arbace_aot_emit_A_const_543; f__4 = tmp56.Invoke_O_O_O__O(tmp57, A_arbace_aot_emit_A_const_271.Invoke_O__O(n__3), ctx__0)
//line :886:1
																															break L1 }; case 206: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_73) {

















																																var tmp58 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp59 any = A_arbace_aot_emit_A_const_544; var tmp60 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp61 any = A_arbace_aot_emit_A_const_545; var tmp62 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp63 any = A_arbace_aot_emit_A_const_546; var tmp64 any = A_arbace_aot_emit_A_const_547; var tmp65 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp66 any = A_arbace_aot_emit_A_const_550; f__4 = tmp58.Invoke_O_O_O__O(tmp59, tmp60.Invoke_O_O_O__O(tmp61, tmp62.Invoke_O_O_O__O(tmp63, tmp64, lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_548, A_arbace_aot_emit_A_const_549)), tmp65.Invoke_O_O__O(tmp66, A_arbace_aot_emit_A_const_340.Invoke_O__O(n__3))), nil)
//line :886:1
																																break L1 }; case 212: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_74) {























																																	var tmp67 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_337.GetRawRoot__O()); var tmp68 *jrt.Boolean; jrt.Boolean_Init(); tmp68 = jrt.Boolean_FALSE; f__4 = tmp67.Invoke_O_O_O__O(ctx__0, n__3, tmp68.Ref())
//line :886:1
																																	break L1 }; case 227: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_75) {





















																																		var tmp69 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_551.GetRawRoot__O()); var tmp70 *jrt.Boolean; jrt.Boolean_Init(); tmp70 = jrt.Boolean_FALSE; f__4 = tmp69.Invoke_O_O_O__O(ctx__0, n__3, tmp70.Ref())
//line :886:1
																																		break L1 }; case 232: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_76) { var texts__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_553.Invoke_O__O(n__3)); var tmp71 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp72 any = A_arbace_aot_emit_A_const_554; var tmp73 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_aot_emit_A_const_555, A_arbace_aot_emit_A_const_556, texts__5); var tmp74 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp75 any = A_arbace_aot_emit_A_const_557; var tmp76 any = A_arbace_aot_emit_A_const_558; var tmp77 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_43.GetRawRoot__O()); var tmp78 any = A_arbace_aot_emit_emit_fn__90000267_A_New_O(ctx__0); var tmp79 *jrt.Class
																																			var fncls__56 /*line :886:1*/*jrt.Class = A_arbace_aot_emit_emit_fn__90000267_A_fn_class













































																																			if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_77, false); A_arbace_aot_emit_emit_fn__90000267_A_fn_class = fncls__56d; tmp79 = fncls__56d } else { tmp79 = fncls__56 }
//line :929:1
																																			f__4 = tmp71.Invoke_O_O_O__O(tmp72, tmp73, tmp74.Invoke_O_O_O__O(tmp75, tmp76, tmp77.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp78, tmp79, nil), texts__5, A_arbace_aot_emit_A_const_271.Invoke_O__O(n__3))))
//line :886:1
																																			break L1 }; case 236: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_78) {



































































																																				var tmp80 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_552.GetRawRoot__O()); var tmp81 *jrt.Boolean; jrt.Boolean_Init(); tmp81 = jrt.Boolean_FALSE; f__4 = tmp80.Invoke_O_O_O__O(ctx__0, n__3, tmp81.Ref())
//line :886:1
																																				break L1 }; case 241: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_79) {







































																																					var tmp82 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_523.GetRawRoot__O()); var tmp83 any = A_arbace_aot_emit_A_const_559; f__4 = tmp82.Invoke_O_O_O__O(tmp83, A_arbace_aot_emit_A_const_560.Invoke_O__O(n__3), ctx__0)
//line :886:1
																																					break L1 }; case 249: if lang.Util_Equiv_O_O__Z(G__90000262__4_, Lit_80) { var c__5_2 any = A_arbace_aot_emit_A_const_340.Invoke_O__O(n__3)















































																																						if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_211.GetRawRoot__O()).Invoke_O_O__O(c__5_2, ctx__0)) {
																																							var tmp84 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp85 any = A_arbace_aot_emit_A_const_561; f__4 = tmp84.Invoke_O_O_O__O(tmp85, lang.IFn_Cast(A_arbace_aot_emit_A_const_248.GetRawRoot__O()).Invoke_O_O__O(ctx__0, c__5_2), lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_441.Invoke_O__O(n__3))) } else {
																																								var tmp86 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp87 any = A_arbace_aot_emit_A_const_562; f__4 = tmp86.Invoke_O_O_O__O(tmp87, lang.IFn_Cast(A_arbace_aot_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(c__5_2), lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_441.Invoke_O__O(n__3))) }
//line :886:1
																																						break L1 }; default:
}



































































	var tmp88 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()); var tmp89 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_81, nil, nil); var tmp90 any = A_arbace_aot_emit_A_const_369.Invoke_O__O(n__3); var tmp91 *jrt.String; if jrt.A2g_Truth(A_arbace_aot_emit_A_const_563.Invoke_O__O(n__3)) { tmp91 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_82, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_aot_emit_A_const_563.Invoke_O__O(n__3))) } else { tmp91 = nil }; f__4 = tmp88.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp89, jrt.RefArrayOf(jrt.Object_class, nil, tmp90, tmp91.Ref())).Ref())}; return /*line :956:1*/ lang.IFn_Cast(A_arbace_aot_emit_A_const_493.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_564.GetRawRoot__O()).Invoke_O_O__O(f__4, n__3), n__3) }
//line :923:1
func A_arbace_aot_emit_emit_fn__90000265_A_New_O(p0 any) *A_arbace_aot_emit_emit_fn__90000265_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn__90000265_A{}; t.Ctor_O(p0); return t }
//line :923:1
func (t *A_arbace_aot_emit_emit_fn__90000265_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :923:1
func (t *A_arbace_aot_emit_emit_fn__90000265_A) Invoke_O_O__O(self, p1__90000261_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, p1__90000261_SHARP___1) }








func A_arbace_aot_emit_emit_fn__90000267_A_New_O(p0 any) *A_arbace_aot_emit_emit_fn__90000267_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn__90000267_A{}; t.Ctor_O(p0); return t }
//line :932:1
func (t *A_arbace_aot_emit_emit_fn__90000267_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :932:1
func (t *A_arbace_aot_emit_emit_fn__90000267_A) Invoke_O_O_O__O(self, t__1, a__2 any) any { if jrt.A2g_Truth(t__1) { return nil } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, a__2) } }














func A_arbace_aot_emit_emit_fn__90000263_A_New_O(p0 any) *A_arbace_aot_emit_emit_fn__90000263_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn__90000263_A{}; t.Ctor_O(p0); return t }
//line :947:1
func (t *A_arbace_aot_emit_emit_fn__90000263_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :947:1
func (t *A_arbace_aot_emit_emit_fn__90000263_A) Invoke_O_O__O(self, x__1 any) any { var xn__2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(x__1); if
											lang.Util_Equiv_O_O__Z(Lit_58, A_arbace_aot_emit_A_const_369.Invoke_O__O(xn__2)) { return nil } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, x__1) } }









func A_arbace_aot_emit_emit_unboxed_A_New() *A_arbace_aot_emit_emit_unboxed_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_unboxed_A{}; t.Ctor(); return t }
//line :958:1
func (t *A_arbace_aot_emit_emit_unboxed_A) Ctor() {}
//line :958:1
func (t *A_arbace_aot_emit_emit_unboxed_A) Invoke_O_O_O__O(self, ctx__0, e__1 any) any { var n__3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(e__1); var tmp1 any; var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_379.GetRawRoot__O()).Invoke_O__O(n__3); if



	jrt.A2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_67, A_arbace_aot_emit_A_const_369.Invoke_O__O(n__3))).Ref() }; if jrt.A2g_Truth(tmp1) { } else { lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_183, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_aot_emit_A_const_369.Invoke_O__O(n__3))).Ref()) }; var tmp2 lang.IFn =
	lang.IFn_Cast(A_arbace_aot_emit_A_const_493.GetRawRoot__O()); var tmp3 any; var G__90000271__4_ any = A_arbace_aot_emit_A_const_369.Invoke_O__O(n__3); L1:
	switch { default: switch lang.Util_Hash_O__I(G__90000271__4_) >> 1 & 63 { case 5: if lang.Util_Equiv_O_O__Z(G__90000271__4_, Lit_48) { var es__5 any = A_arbace_aot_emit_A_const_502.Invoke_O__O(n__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()); var tmp5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_565); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()); var tmp7 any = A_arbace_aot_emit_emit_unboxed_fn__90000272_A_New_O(ctx__0); var tmp8 *jrt.Class
		var fncls__58 /*line :964:1*/*jrt.Class = A_arbace_aot_emit_emit_unboxed_fn__90000272_A_fn_class








		if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_184, false); A_arbace_aot_emit_emit_unboxed_fn__90000272_A_fn_class = fncls__58d; tmp8 = fncls__58d } else { tmp8 = fncls__58 }; tmp3 = tmp4.Invoke_O_O_O__O(tmp5, tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), lang.IFn_Cast(A_arbace_aot_emit_A_const_509.GetRawRoot__O()).Invoke_O__O(es__5)), lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(ctx__0, lang.IFn_Cast(A_arbace_aot_emit_A_const_510.GetRawRoot__O()).Invoke_O__O(es__5))))
//line :964:1
		break L1 }; case 12: if lang.Util_Equiv_O_O__Z(G__90000271__4_, Lit_42) {


			var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_319.GetRawRoot__O()); var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_TRUE; tmp3 = tmp9.Invoke_O_O_O__O(ctx__0, n__3, tmp10.Ref())
//line :964:1
			break L1 }; case 13: if lang.Util_Equiv_O_O__Z(G__90000271__4_, Lit_62) {









				var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_524.GetRawRoot__O()); var tmp12 *jrt.Boolean; jrt.Boolean_Init(); tmp12 = jrt.Boolean_TRUE; tmp3 = tmp11.Invoke_O_O_O__O(ctx__0, n__3, tmp12.Ref())
//line :964:1
				break L1 }; case 14: if lang.Util_Equiv_O_O__Z(G__90000271__4_, Lit_51) {






					var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_511.GetRawRoot__O()); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; tmp3 = tmp13.Invoke_O_O_O__O(ctx__0, n__3, tmp14.Ref())
//line :964:1
					break L1 }; case 16: if lang.Util_Equiv_O_O__Z(G__90000271__4_, Lit_74) {



						var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_337.GetRawRoot__O()); var tmp16 *jrt.Boolean; jrt.Boolean_Init(); tmp16 = jrt.Boolean_TRUE; tmp3 = tmp15.Invoke_O_O_O__O(ctx__0, n__3, tmp16.Ref())
//line :964:1
						break L1 }; case 17: if lang.Util_Equiv_O_O__Z(G__90000271__4_, Lit_54) {










							var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_513.GetRawRoot__O()); var tmp18 *jrt.Boolean; jrt.Boolean_Init(); tmp18 = jrt.Boolean_TRUE; tmp3 = tmp17.Invoke_O_O_O__O(ctx__0, n__3, tmp18.Ref())
//line :964:1
							break L1 }; case 22: if lang.Util_Equiv_O_O__Z(G__90000271__4_, Lit_63) {

















								tmp3 = lang.IFn_Cast(A_arbace_aot_emit_A_const_528.GetRawRoot__O()).Invoke_O_O__O(ctx__0, n__3)
//line :964:1
								break L1 }; case 24: if lang.Util_Equiv_O_O__Z(G__90000271__4_, Lit_78) {












									var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_552.GetRawRoot__O()); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; tmp3 = tmp19.Invoke_O_O_O__O(ctx__0, n__3, tmp20.Ref())
//line :964:1
									break L1 }; case 29: if lang.Util_Equiv_O_O__Z(G__90000271__4_, Lit_39) {











										var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_488.GetRawRoot__O()); var tmp22 *jrt.Boolean; jrt.Boolean_Init(); tmp22 = jrt.Boolean_TRUE; tmp3 = tmp21.Invoke_O_O_O__O(ctx__0, n__3, tmp22.Ref())
//line :964:1
										break L1 }; case 33: if lang.Util_Equiv_O_O__Z(G__90000271__4_, Lit_45) {





											var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_500.GetRawRoot__O()); var tmp24 *jrt.Boolean; jrt.Boolean_Init(); tmp24 = jrt.Boolean_TRUE; tmp3 = tmp23.Invoke_O_O_O__O(ctx__0, n__3, tmp24.Ref())
//line :964:1
											break L1 }; case 36: if lang.Util_Equiv_O_O__Z(G__90000271__4_, Lit_55) { var v__5 any = A_arbace_aot_emit_A_const_519.Invoke_O__O(n__3)

												if jrt.Double_InstanceOf(v__5) { tmp3 = lang.IFn_Cast(A_arbace_aot_emit_A_const_69.GetRawRoot__O()).Invoke_O__O(v__5) } else { tmp3 = jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(v__5)).Ref() }
//line :964:1
												break L1 }; case 37: if lang.Util_Equiv_O_O__Z(G__90000271__4_, Lit_80) { var c__5 any = A_arbace_aot_emit_A_const_340.Invoke_O__O(n__3)














													if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_211.GetRawRoot__O()).Invoke_O_O__O(c__5, ctx__0)) {
														var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp26 any = A_arbace_aot_emit_A_const_566; tmp3 = tmp25.Invoke_O_O_O__O(tmp26, lang.IFn_Cast(A_arbace_aot_emit_A_const_248.GetRawRoot__O()).Invoke_O_O__O(ctx__0, c__5), lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_441.Invoke_O__O(n__3))) } else {
															var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp28 any = A_arbace_aot_emit_A_const_567; tmp3 = tmp27.Invoke_O_O_O__O(tmp28, lang.IFn_Cast(A_arbace_aot_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(c__5), lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_441.Invoke_O__O(n__3))) }
//line :964:1
													break L1 }; case 45: if lang.Util_Equiv_O_O__Z(G__90000271__4_, Lit_75) {




														var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_551.GetRawRoot__O()); var tmp30 *jrt.Boolean; jrt.Boolean_Init(); tmp30 = jrt.Boolean_TRUE; tmp3 = tmp29.Invoke_O_O_O__O(ctx__0, n__3, tmp30.Ref())
//line :964:1
														break L1 }; case 51: if lang.Util_Equiv_O_O__Z(G__90000271__4_, Lit_67) {


















															var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp32 any = A_arbace_aot_emit_A_const_568; var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp34 any = A_arbace_aot_emit_A_const_569; var tmp35 any = A_arbace_aot_emit_A_const_570; tmp3 = tmp31.Invoke_O_O__O(tmp32, tmp33.Invoke_O_O_O__O(tmp34, tmp35, lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_aot_emit_A_const_538.Invoke_O__O(n__3))))
//line :964:1
															break L1 }; case 53: if lang.Util_Equiv_O_O__Z(G__90000271__4_, Lit_58) {
																var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_403.GetRawRoot__O()); var tmp37 *jrt.Boolean; jrt.Boolean_Init(); tmp37 = jrt.Boolean_TRUE; tmp3 = tmp36.Invoke_O_O_O__O(ctx__0, n__3, tmp37.Ref())
//line :964:1
																break L1 }; default:
	}


















		tmp3 = lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_185, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_aot_emit_A_const_369.Invoke_O__O(n__3))).Ref())}; return /*line :963:1*/ tmp2.Invoke_O_O__O(tmp3, n__3) }









func A_arbace_aot_emit_emit_unboxed_fn__90000272_A_New_O(p0 any) *A_arbace_aot_emit_emit_unboxed_fn__90000272_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_unboxed_fn__90000272_A{}; t.Ctor_O(p0); return t }
//line :973:1
func (t *A_arbace_aot_emit_emit_unboxed_fn__90000272_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :973:1
func (t *A_arbace_aot_emit_emit_unboxed_fn__90000272_A) Invoke_O_O__O(self, p1__90000270_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, p1__90000270_SHARP___1) }
















func A_arbace_aot_emit_deep_A_New() *A_arbace_aot_emit_deep_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_deep_A{}; t.Ctor(); return t }
//line :990:1
func (t *A_arbace_aot_emit_deep_A) Ctor() {}
//line :990:1
func (t *A_arbace_aot_emit_deep_A) Invoke_O_O__O(self, f__0 any) any {



	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_58.GetRawRoot__O()).Invoke_O__O(f__0)) {
		return lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_304.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_40.GetRawRoot__O(), lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_571.GetRawRoot__O(), f__0)), lang.RT_Meta_O__IPersistentMap(f__0)) } else {
//line :994:1
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_57.GetRawRoot__O()).Invoke_O__O(f__0)) {

				return lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_43.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_571.GetRawRoot__O(), f__0), lang.RT_Meta_O__IPersistentMap(f__0)) } else {
//line :994:1
					if A_arbace_aot_emit_A_const_60 != nil { return f__0 } else { return nil
					}
				}
		}
}
func A_arbace_aot_emit_simple_name_A_New() *A_arbace_aot_emit_simple_name_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_simple_name_A{}; t.Ctor(); return t }
//line :999:1
func (t *A_arbace_aot_emit_simple_name_A) Ctor() {}
//line :999:1
func (t *A_arbace_aot_emit_simple_name_A) Invoke_O_O__O(self, binary__0 any) any {
	return lang.IFn_Cast(A_arbace_aot_emit_A_const_17.GetRawRoot__O()).Invoke_O_O__O(binary__0, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(jrt.NN(jrt.String_Cast(binary__0)).LastIndexOf_String__I(Lit_17)))).Ref())
}
func A_arbace_aot_emit_throws_QMARK__A_New() *A_arbace_aot_emit_throws_QMARK__A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_throws_QMARK__A{}; t.Ctor(); return t }
//line :1002:1
func (t *A_arbace_aot_emit_throws_QMARK__A) Ctor() {}
//line :1002:1
func (t *A_arbace_aot_emit_throws_QMARK__A) Invoke_O_O__O(self, e__0 any) any { var n__2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(e__0); var G__90000277__3_ any = A_arbace_aot_emit_A_const_369.Invoke_O__O(n__2); switch



	lang.Util_Hash_O__I(G__90000277__3_) >> 0 & 1 { case 0: if lang.Util_Equiv_O_O__Z(G__90000277__3_, Lit_67) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 1: if lang.Util_Equiv_O_O__Z(G__90000277__3_, Lit_48) {

		return lang.IFn_Cast(A_arbace_aot_emit_A_const_572.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_510.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_502.Invoke_O__O(n__2))) }
//line :1006:1
	default:}; jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() }




func A_arbace_aot_emit_ret_body_A_New() *A_arbace_aot_emit_ret_body_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_ret_body_A{}; t.Ctor(); return t }
//line :1011:1
func (t *A_arbace_aot_emit_ret_body_A) Ctor() {}
//line :1011:1
func (t *A_arbace_aot_emit_ret_body_A) Invoke_O_O_O_O__O(self, ctx__0, body__1, ret__2 any) any { var n__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(body__1); var bc__5 any = A_arbace_aot_emit_A_const_223.Invoke_O__O(n__4); var tmp1 any; var and__1927000168__auto____6 bool = jrt.NN(jrt.Class_Cast(ret__2)).IsPrimitive__Z(); if and__1927000168__auto____6 {





	var and__1927000168__auto____7 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_45.GetRawRoot__O()); var tmp3 *jrt.Class; jrt.Void_Init(); tmp3 = jrt.Void_TYPE; and__1927000168__auto____7 = tmp2.Invoke_O_O__O(ret__2, tmp3.Ref()); if jrt.A2g_Truth(and__1927000168__auto____7) { tmp1 = lang.IFn_Cast(A_arbace_aot_emit_A_const_379.GetRawRoot__O()).Invoke_O__O(n__4) } else { tmp1 = and__1927000168__auto____7 } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____6).Ref() }; if jrt.A2g_Truth(tmp1) {
		if lang.Util_Equiv_O_O__Z(bc__5, ret__2) {
			return lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(ctx__0, body__1) } else {
//line :1018:1
				var tmp4 bool; var and__1927000168__auto____6_2 bool; var tmp5 *jrt.Class

				jrt.Long_Init(); tmp5 = jrt.Long_TYPE; and__1927000168__auto____6_2 = lang.Util_Equiv_O_O__Z(ret__2, tmp5.Ref()); if and__1927000168__auto____6_2 { var tmp6 *jrt.Class; jrt.Integer_Init(); tmp6 = jrt.Integer_TYPE; tmp4 = lang.Util_Equiv_O_O__Z(bc__5, tmp6.Ref()) } else { tmp4 = and__1927000168__auto____6_2 }
//line :1018:1
				if tmp4 {

					return lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(ctx__0, body__1) } else {
//line :1018:1
						var tmp7 bool; var and__1927000168__auto____6_3 bool; var tmp8 *jrt.Class


						jrt.Double_Init(); tmp8 = jrt.Double_TYPE; and__1927000168__auto____6_3 = lang.Util_Equiv_O_O__Z(ret__2, tmp8.Ref()); if and__1927000168__auto____6_3 { var tmp9 *jrt.Class; jrt.Float_Init(); tmp9 = jrt.Float_TYPE; tmp7 = lang.Util_Equiv_O_O__Z(bc__5, tmp9.Ref()) } else { tmp7 = and__1927000168__auto____6_3 }
//line :1018:1
						if tmp7 {


							return lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(ctx__0, body__1) } else {
//line :1018:1
								var tmp10 bool; var and__1927000168__auto____6_4 bool; var tmp11 *jrt.Class



								jrt.Integer_Init(); tmp11 = jrt.Integer_TYPE; and__1927000168__auto____6_4 = lang.Util_Equiv_O_O__Z(ret__2, tmp11.Ref()); if and__1927000168__auto____6_4 { var tmp12 *jrt.Class; jrt.Long_Init(); tmp12 = jrt.Long_TYPE; tmp10 = lang.Util_Equiv_O_O__Z(bc__5, tmp12.Ref()) } else { tmp10 = and__1927000168__auto____6_4 }
//line :1018:1
								if tmp10 {




									return lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_573, A_arbace_aot_emit_A_const_574), lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(ctx__0, body__1)) } else {
//line :1018:1
										var tmp13 bool; var and__1927000168__auto____6_5 bool; var tmp14 *jrt.Class





										jrt.Float_Init(); tmp14 = jrt.Float_TYPE; and__1927000168__auto____6_5 = lang.Util_Equiv_O_O__Z(ret__2, tmp14.Ref()); if and__1927000168__auto____6_5 { var tmp15 *jrt.Class; jrt.Double_Init(); tmp15 = jrt.Double_TYPE; tmp13 = lang.Util_Equiv_O_O__Z(bc__5, tmp15.Ref()) } else { tmp13 = and__1927000168__auto____6_5 }
//line :1018:1
										if tmp13 {





											var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp17 any = A_arbace_aot_emit_A_const_575; return tmp16.Invoke_O_O__O(tmp17, lang.IFn_Cast(A_arbace_aot_emit_A_const_239.GetRawRoot__O()).Invoke_O_O__O(ctx__0, body__1)) } else {
//line :1018:1
												if A_arbace_aot_emit_A_const_60 != nil {






													return lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_254, nil, Lit_255, nil), jrt.RefArrayOf(jrt.Object_class, nil, ret__2, nil, bc__5)).Ref()) } else {
//line :1018:1
														return nil } } } } } } } else {
//line :1017:1
															var f__6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, body__1)









															if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_572.GetRawRoot__O()).Invoke_O__O(body__1)) { return f__6 } else { var tmp18 *jrt.Class; jrt.Void_Init(); tmp18 = jrt.Void_TYPE; if lang.Util_Equiv_O_O__Z(ret__2, tmp18.Ref()) { return f__6 } else { if lang.Util_Equiv_O_O__Z(ret__2, A_arbace_aot_emit_A_const_228) { return f__6 } else { var tmp19 *jrt.Class; jrt.Boolean_Init(); tmp19 = jrt.Boolean_TYPE; if lang.Util_Equiv_O_O__Z(ret__2, tmp19.Ref()) {



																var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp21 any = A_arbace_aot_emit_A_const_576; return tmp20.Invoke_O_O__O(tmp21, lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_aot_emit_A_const_577, A_arbace_aot_emit_A_const_578, f__6)) } else {
//line :1027:1
																	var tmp22 *jrt.Class; jrt.Character_Init(); tmp22 = jrt.Character_TYPE; if lang.Util_Equiv_O_O__Z(ret__2, tmp22.Ref()) {




																		var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp24 any = A_arbace_aot_emit_A_const_579; return tmp23.Invoke_O_O__O(tmp24, lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_aot_emit_A_const_580, A_arbace_aot_emit_A_const_581, f__6)) } else {
//line :1027:1
																			if jrt.NN(jrt.Class_Cast(ret__2)).IsPrimitive__Z() {





																				return lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_34, nil, Lit_107), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.Class_Cast(ret__2)).GetName__String().Ref(), nil)).Ref()), lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_aot_emit_A_const_582, A_arbace_aot_emit_A_const_583, f__6)) } else {
//line :1027:1
																					var tmp25 any; var or__1927000174__auto____7 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_211.GetRawRoot__O()).Invoke_O_O__O(ret__2, ctx__0)






																					if jrt.A2g_Truth(or__1927000174__auto____7) { tmp25 = or__1927000174__auto____7 } else { tmp25 = lang.IFn_Cast(A_arbace_aot_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_237.GetRawRoot__O()).Invoke_O__O(ret__2)) }
//line :1027:1
																					if jrt.A2g_Truth(tmp25) { return f__6 } else { if A_arbace_aot_emit_A_const_60 != nil {







																						var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp27 any = A_arbace_aot_emit_A_const_584; return tmp26.Invoke_O_O_O__O(tmp27, lang.IFn_Cast(A_arbace_aot_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(ret__2), f__6) } else {
//line :1027:1
																							return nil } } } } } } } } } }









func A_arbace_aot_emit_method_body_A_New() *A_arbace_aot_emit_method_body_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_method_body_A{}; t.Ctor(); return t }
//line :1037:1
func (t *A_arbace_aot_emit_method_body_A) Ctor() {}
//line :1037:1
func (t *A_arbace_aot_emit_method_body_A) Invoke_O_O_O_O__O(self, ctx__0, mn__1, params__2 any) any { var rec__4 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_33.GetRawRoot__O()); var tmp2 *jrt.Boolean;



	jrt.Boolean_Init(); tmp2 = jrt.Boolean_FALSE; rec__4 = tmp1.Invoke_O__O(tmp2.Ref()); var locals__5 any; var tmp3 lang.IFn = /*line :1037:1*/lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_A_const_587.Invoke_O__O(mn__1); var tmp6 lang.IPersistentVector; if




	jrt.A2g_Truth(A_arbace_aot_emit_A_const_588.Invoke_O__O(mn__1)) { tmp6 = lang.Tuple_Create_O__IPersistentVector(A_arbace_aot_emit_A_const_588.Invoke_O__O(mn__1)) } else { tmp6 = nil }; var tmp7 any = tmp6; var tmp8 any; if
	jrt.A2g_Truth(A_arbace_aot_emit_A_const_587.Invoke_O__O(mn__1)) { tmp8 = nil } else { tmp8 = A_arbace_aot_emit_A_const_589.Invoke_O__O(mn__1) }; locals__5 = /*line :1042:1*/tmp3.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp5, tmp7, tmp8)); var ctx_SINGLEQUOTE___6 any = /*line :1037:1*/lang.IFn_Cast(A_arbace_aot_emit_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O__O(ctx__0, A_arbace_aot_emit_A_const_392, rec__4, A_arbace_aot_emit_A_const_393, locals__5, A_arbace_aot_emit_A_const_385, locals__5); var fn_method_QMARK___7 bool = lang.Util_Equiv_O_O__Z(Lit_227, A_arbace_aot_emit_A_const_369.Invoke_O__O(mn__1)); var prims__8 any; if fn_method_QMARK___7 {










		var iter__1927001039__auto____8 any; var tmp9 any = A_arbace_aot_emit_method_body_iter__90000280__90000284_A_New(); var tmp10 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_aot_emit_method_body_iter__90000280__90000284_A_fn_class
		if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_228, false); A_arbace_aot_emit_method_body_iter__90000280__90000284_A_fn_class = fncls__62d; tmp10 = fncls__62d } else { tmp10 = fncls__62 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); prims__8 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(locals__5) } else {
//line :1048:1
			prims__8 = nil }; var ret__9 any = /*line :1037:1*/A_arbace_aot_emit_A_const_585.Invoke_O__O(mn__1); var body__10 any; var tmp11 any; var and__1927000168__auto____10 bool = fn_method_QMARK___7; if and__1927000168__auto____10 {



















				var tmp12 *jrt.Class; jrt.Double_Init(); tmp12 = jrt.Double_TYPE; var tmp13 any = tmp12.Ref(); var tmp14 *jrt.Class; jrt.Long_Init(); tmp14 = jrt.Long_TYPE; tmp11 = lang.IFn_Cast(lang.RT_Set_O1__IPersistentSet(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14.Ref()))).Invoke_O__O(ret__9) } else { tmp11 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____10).Ref() }; if /*line :1054:1*/ jrt.A2g_Truth(tmp11) {


					body__10 = lang.IFn_Cast(A_arbace_aot_emit_A_const_289.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_586.GetRawRoot__O()).Invoke_O_O_O__O(ctx_SINGLEQUOTE___6, A_arbace_aot_emit_A_const_388.Invoke_O__O(mn__1), ret__9), ret__9) } else {
//line :1054:1
						if fn_method_QMARK___7 {



							body__10 = lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx_SINGLEQUOTE___6, A_arbace_aot_emit_A_const_388.Invoke_O__O(mn__1)) } else {
//line :1054:1
								if A_arbace_aot_emit_A_const_60 != nil {




									body__10 = lang.IFn_Cast(A_arbace_aot_emit_A_const_586.GetRawRoot__O()).Invoke_O_O_O__O(ctx_SINGLEQUOTE___6, A_arbace_aot_emit_A_const_388.Invoke_O__O(mn__1), ret__9) } else {
//line :1054:1
										body__10 = nil } } }; var body__11 any; if





	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(rec__4)) {
		var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp16 any = A_arbace_aot_emit_A_const_590; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_98.GetRawRoot__O()); var tmp19 any = A_arbace_aot_emit_method_body_fn__90000290_A_New(); var tmp20 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_aot_emit_method_body_fn__90000290_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_229, false); A_arbace_aot_emit_method_body_fn__90000290_A_fn_class = fncls__63d; tmp20 = fncls__63d } else { tmp20 = fncls__63 }; body__11 = tmp15.Invoke_O_O_O__O(tmp16, tmp17.Invoke_O__O(tmp18.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil), locals__5)), body__10) } else {
//line :1060:1
			body__11 = body__10 }; if




	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(prims__8)) {
		var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp22 any = A_arbace_aot_emit_A_const_591; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()); var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_98.GetRawRoot__O()); var tmp25 any = A_arbace_aot_emit_method_body_fn__90000292_A_New(); var tmp26 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_aot_emit_method_body_fn__90000292_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_230, false); A_arbace_aot_emit_method_body_fn__90000292_A_fn_class = fncls__64d; tmp26 = fncls__64d } else { tmp26 = fncls__64 }; return tmp21.Invoke_O_O_O__O(tmp22, tmp23.Invoke_O__O(tmp24.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil), prims__8)), body__11) } else {
//line :1065:1
			return body__11 } }
//line :1049:1
func A_arbace_aot_emit_method_body_iter__90000280__90000284_A_New() *A_arbace_aot_emit_method_body_iter__90000280__90000284_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_method_body_iter__90000280__90000284_A{}; t.Ctor(); return t }
//line :1049:1
func (t *A_arbace_aot_emit_method_body_iter__90000280__90000284_A) Ctor() {}
//line :1049:1
func (t *A_arbace_aot_emit_method_body_iter__90000280__90000284_A) Invoke_O_O__O(self, s__90000281__1 any) any { var tmp1 any = A_arbace_aot_emit_method_body_iter__90000280__90000284_fn__90000285_A_New_O_O(s__90000281__1, self); var tmp2 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_aot_emit_method_body_iter__90000280__90000284_fn__90000285_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_232, false); A_arbace_aot_emit_method_body_iter__90000280__90000284_fn__90000285_A_fn_class = fncls__61d; tmp2 = fncls__61d } else { tmp2 = fncls__61 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1049:1
func A_arbace_aot_emit_method_body_iter__90000280__90000284_fn__90000285_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_method_body_iter__90000280__90000284_fn__90000285_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_method_body_iter__90000280__90000284_fn__90000285_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1049:1
func (t *A_arbace_aot_emit_method_body_iter__90000280__90000284_fn__90000285_A) Ctor_O_O(c__s__90000281, c__iter__90000280 any) { t.F_s__90000281 = c__s__90000281; t.F_iter__90000280 = c__iter__90000280 }
//line :1049:1
func (t *A_arbace_aot_emit_method_body_iter__90000280__90000284_fn__90000285_A) Invoke_O__O(self any) any { { var s__90000281__1 any; var t_ any = t.F_s__90000281; t.F_s__90000281 = nil; s__90000281__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(s__90000281__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__90000281__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(s__90000281__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(s__90000281__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__90000283__6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_401.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_aot_emit_method_body_iter__90000280__90000284_fn__90000285_fn__90000286_A_New_O_I_O(b__90000283__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_aot_emit_method_body_iter__90000280__90000284_fn__90000285_fn__90000286_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_233, false); A_arbace_aot_emit_method_body_iter__90000280__90000284_fn__90000285_fn__90000286_A_fn_class = fncls__60d; tmp2 = fncls__60d } else { tmp2 = fncls__60 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__90000280); return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000283__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__90000281__3))) } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000283__6), nil) } } else { var lb__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__90000281__3); var b__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__4); if jrt.A2g_Truth(A_arbace_aot_emit_A_const_265.Invoke_O__O(b__5)) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__90000280); return lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()).Invoke_O_O__O(b__5, tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(s__90000281__3))) } else { s__90000281__1 = lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(s__90000281__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :1049:1
func A_arbace_aot_emit_method_body_iter__90000280__90000284_fn__90000285_fn__90000286_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_aot_emit_method_body_iter__90000280__90000284_fn__90000285_fn__90000286_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_method_body_iter__90000280__90000284_fn__90000285_fn__90000286_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :1049:1
func (t *A_arbace_aot_emit_method_body_iter__90000280__90000284_fn__90000285_fn__90000286_A) Ctor_O_I_O(c__b__90000283 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__90000283 = c__b__90000283; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1049:1
func (t *A_arbace_aot_emit_method_body_iter__90000280__90000284_fn__90000285_fn__90000286_A) Invoke_O__O(self any) any { { var i__90000282__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__90000282__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var lb__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__90000282__1)); var b__3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__2); if jrt.A2g_Truth(A_arbace_aot_emit_A_const_265.Invoke_O__O(b__3)) { lang.IFn_Cast(A_arbace_aot_emit_A_const_402.GetRawRoot__O()).Invoke_O_O__O(t.F_b__90000283, b__3); i__90000282__1 = lang.Numbers_Unchecked_inc_J__J(i__90000282__1); continue L1 } else { i__90000282__1 = lang.Numbers_Unchecked_inc_J__J(i__90000282__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }











func A_arbace_aot_emit_method_body_fn__90000290_A_New() *A_arbace_aot_emit_method_body_fn__90000290_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_method_body_fn__90000290_A{}; t.Ctor(); return t }
//line :1061:1
func (t *A_arbace_aot_emit_method_body_fn__90000290_A) Ctor() {}
//line :1061:1
func (t *A_arbace_aot_emit_method_body_fn__90000290_A) Invoke_O_O__O(self, lb__1 any) any { var b__2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_264.GetRawRoot__O()).Invoke_O__O(b__2); var tmp3 any; var or__1927000174__auto____3 any = A_arbace_aot_emit_A_const_265.Invoke_O__O(b__2); if jrt.A2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { tmp3 = A_arbace_aot_emit_A_const_228 }; return lang.Tuple_Create_O_O__IPersistentVector(tmp1.Invoke_O_O__O(tmp2, tmp3), lang.IFn_Cast(A_arbace_aot_emit_A_const_264.GetRawRoot__O()).Invoke_O__O(b__2)) }




func A_arbace_aot_emit_method_body_fn__90000292_A_New() *A_arbace_aot_emit_method_body_fn__90000292_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_method_body_fn__90000292_A{}; t.Ctor(); return t }
//line :1066:1
func (t *A_arbace_aot_emit_method_body_fn__90000292_A) Ctor() {}
//line :1066:1
func (t *A_arbace_aot_emit_method_body_fn__90000292_A) Invoke_O_O__O(self, b__1 any) any { var tmp1 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_264.GetRawRoot__O()).Invoke_O__O(b__1), A_arbace_aot_emit_A_const_265.Invoke_O__O(b__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()); var tmp4 any; var tmp5 any = A_arbace_aot_emit_A_const_265.Invoke_O__O(b__1); var tmp6 *jrt.Class;
												jrt.Double_Init(); tmp6 = jrt.Double_TYPE; if lang.Util_Equiv_O_O__Z(tmp5, tmp6.Ref()) { tmp4 = A_arbace_aot_emit_A_const_592 } else { tmp4 = A_arbace_aot_emit_A_const_593 }; return /*line :1066:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2.Invoke_O_O__O(tmp3.Invoke_O_O__O(tmp4, A_arbace_aot_emit_A_const_594), lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_231, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_aot_emit_A_const_264.GetRawRoot__O()).Invoke_O__O(b__1))).Ref()))) }







func A_arbace_aot_emit_param_sym_A_New() *A_arbace_aot_emit_param_sym_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_param_sym_A{}; t.Ctor(); return t }
//line :1074:1
func (t *A_arbace_aot_emit_param_sym_A) Ctor() {}
//line :1074:1
func (t *A_arbace_aot_emit_param_sym_A) Invoke_O_O__O(self, lb__0 any) any { var b__2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__0); if

	jrt.A2g_Truth(A_arbace_aot_emit_A_const_265.Invoke_O__O(b__2)) {
		return lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_231, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_aot_emit_A_const_264.GetRawRoot__O()).Invoke_O__O(b__2))).Ref()) } else {
			return lang.IFn_Cast(A_arbace_aot_emit_A_const_264.GetRawRoot__O()).Invoke_O__O(b__2) } }





func A_arbace_aot_emit_tag_class_A_New() *A_arbace_aot_emit_tag_class_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_tag_class_A{}; t.Ctor(); return t }
//line :1084:1
func (t *A_arbace_aot_emit_tag_class_A) Ctor() {}
//line :1084:1
func (t *A_arbace_aot_emit_tag_class_A) Invoke_O_O__O(self, tag__0 any) any {


	if lang.Util_Identical_O_O__Z(tag__0, nil) { return A_arbace_aot_emit_A_const_228 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_595.GetRawRoot__O()).Invoke_O__O(tag__0)) {

		return lang.IFn_Cast(A_arbace_aot_emit_A_const_595.GetRawRoot__O()).Invoke_O__O(tag__0) } else {
//line :1087:1
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_51.GetRawRoot__O()).Invoke_O__O(tag__0)) { return tag__0 } else { if A_arbace_aot_emit_A_const_60 != nil { var c__2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_596.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_597.Get__O(), tag__0)



				if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_51.GetRawRoot__O()).Invoke_O__O(c__2)) { return c__2 } else { return jrt.Class_ForName_String__Class(jrt.String_Cast(lang.IFn_Cast(A_arbace_aot_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(tag__0))).Ref() } } else {
//line :1087:1
					return nil
				}
			}
		}
	}
}
func A_arbace_aot_emit_box_class_A_New() *A_arbace_aot_emit_box_class_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_box_class_A{}; t.Ctor(); return t }
//line :1093:1
func (t *A_arbace_aot_emit_box_class_A) Ctor() {}
//line :1093:1
func (t *A_arbace_aot_emit_box_class_A) Invoke_O_O__O(self, c__0 any) any {
	var tmp1 *jrt.Class; jrt.Long_Init(); tmp1 = jrt.Long_TYPE; var tmp2 any = tmp1.Ref(); var tmp3 any = A_arbace_aot_emit_A_const_78; var tmp4 *jrt.Class; jrt.Double_Init(); tmp4 = jrt.Double_TYPE; var tmp5 any = tmp4.Ref(); var tmp6 any = A_arbace_aot_emit_A_const_75; var tmp7 *jrt.Class; jrt.Integer_Init(); tmp7 = jrt.Integer_TYPE; var tmp8 any = tmp7.Ref(); var tmp9 any = A_arbace_aot_emit_A_const_77; var tmp10 *jrt.Class; jrt.Boolean_Init(); tmp10 = jrt.Boolean_TYPE; var tmp11 any = tmp10.Ref(); var tmp12 any = A_arbace_aot_emit_A_const_72; var tmp13 *jrt.Class; jrt.Character_Init(); tmp13 = jrt.Character_TYPE; var tmp14 any = tmp13.Ref(); var tmp15 any = A_arbace_aot_emit_A_const_74; var tmp16 *jrt.Class; jrt.Float_Init(); tmp16 = jrt.Float_TYPE; var tmp17 any = tmp16.Ref(); var tmp18 any = A_arbace_aot_emit_A_const_76; var tmp19 *jrt.Class; jrt.Short_Init(); tmp19 = jrt.Short_TYPE; var tmp20 any = tmp19.Ref(); var tmp21 any = A_arbace_aot_emit_A_const_79; var tmp22 *jrt.Class; jrt.Byte_Init(); tmp22 = jrt.Byte_TYPE; return lang.IFn_Cast(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp5, tmp6, tmp8, tmp9, tmp11, tmp12, tmp14, tmp15, tmp17, tmp18, tmp20, tmp21, tmp22.Ref(), A_arbace_aot_emit_A_const_73))).Invoke_O__O(c__0)
}

func A_arbace_aot_emit_class_interfaces_A_New() *A_arbace_aot_emit_class_interfaces_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_class_interfaces_A{}; t.Ctor(); return t }
//line :1097:1
func (t *A_arbace_aot_emit_class_interfaces_A) Ctor() {}
//line :1097:1
func (t *A_arbace_aot_emit_class_interfaces_A) Invoke_O_O_O__O(self, ctx__0, ox__1 any) any { var c__3 any = A_arbace_aot_emit_A_const_598.Invoke_O__O(ox__1); if




	jrt.A2g_Truth(c__3) { } else { lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_18, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_aot_emit_A_const_34.Invoke_O__O(ox__1))).Ref()) }; var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____4 any; var tmp3 any = A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_A_New_O_O(ctx__0, ox__1); var tmp4 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_19, false); A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_A_fn_class = fncls__67d; tmp4 = fncls__67d } else { tmp4 = fncls__67 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); tmp2 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__3)).GetInterfaces__Class1().Ref()); return tmp1.Invoke_O__O(tmp2) }
//line :1103:1
func A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1103:1
func (t *A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_A) Ctor_O_O(c__ctx, c__ox any) { t.F_ctx = c__ctx; t.F_ox = c__ox }
//line :1103:1
func (t *A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_A) Invoke_O_O__O(self, s__90000299__1 any) any { var tmp1 any = A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_fn__90000303_A_New_O_O_O_O(t.F_ctx, t.F_ox, s__90000299__1, self); var tmp2 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_fn__90000303_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_20, false); A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_fn__90000303_A_fn_class = fncls__66d; tmp2 = fncls__66d } else { tmp2 = fncls__66 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1103:1
func A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_fn__90000303_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_fn__90000303_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_fn__90000303_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :1103:1
func (t *A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_fn__90000303_A) Ctor_O_O_O_O(c__ctx, c__ox, c__s__90000299, c__iter__90000298 any) { t.F_ctx = c__ctx; t.F_ox = c__ox; t.F_s__90000299 = c__s__90000299; t.F_iter__90000298 = c__iter__90000298 }
//line :1103:1
func (t *A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_fn__90000303_A) Invoke_O__O(self any) any { { var s__90000299__1 any; var t_ any = t.F_s__90000299; t.F_s__90000299 = nil; s__90000299__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(s__90000299__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__90000299__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(s__90000299__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(s__90000299__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__90000301__6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_401.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_fn__90000303_fn__90000304_A_New_O_O_O_I_O(t.F_ctx, t.F_ox, b__90000301__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_fn__90000303_fn__90000304_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_21, false); A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_fn__90000303_fn__90000304_A_fn_class = fncls__65d; tmp2 = fncls__65d } else { tmp2 = fncls__65 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__90000298); return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000301__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__90000299__3))) } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000301__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__90000299__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()); var tmp5 any
														if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_211.GetRawRoot__O()).Invoke_O_O__O(i__4, t.F_ctx)) {
															tmp5 = lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_22, nil, Lit_23), jrt.RefArrayOf(jrt.Object_class, A_arbace_aot_emit_A_const_34.Invoke_O__O(t.F_ox), nil, jrt.NN(jrt.Class_Cast(i__4)).GetName__String().Ref(), nil)).Ref()) } else {
																tmp5 = lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(i__4)).GetName__String().Ref())) }
//line :1103:1
	var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__90000298); return tmp4.Invoke_O_O__O(tmp5, tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(s__90000299__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :1103:1
func A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_fn__90000303_fn__90000304_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_fn__90000303_fn__90000304_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_fn__90000303_fn__90000304_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :1103:1
func (t *A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_fn__90000303_fn__90000304_A) Ctor_O_O_O_I_O(c__ctx, c__ox, c__b__90000301 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_ctx = c__ctx; t.F_ox = c__ox; t.F_b__90000301 = c__b__90000301; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1103:1
func (t *A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_fn__90000303_fn__90000304_A) Invoke_O__O(self any) any { { var i__90000300__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__90000300__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__90000300__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_402.GetRawRoot__O()); var tmp3 any = t.F_b__90000301; var tmp4 any
																if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_211.GetRawRoot__O()).Invoke_O_O__O(i__2, t.F_ctx)) {
																	tmp4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_22, nil, Lit_23), jrt.RefArrayOf(jrt.Object_class, A_arbace_aot_emit_A_const_34.Invoke_O__O(t.F_ox), nil, jrt.NN(jrt.Class_Cast(i__2)).GetName__String().Ref(), nil)).Ref()) } else {
																		tmp4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(i__2)).GetName__String().Ref())) }
//line :1103:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__90000300__1 = lang.Numbers_Unchecked_inc_J__J(i__90000300__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_aot_emit_field_mods_A_New() *A_arbace_aot_emit_field_mods_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_field_mods_A{}; t.Ctor(); return t }
//line :1108:1
func (t *A_arbace_aot_emit_field_mods_A) Ctor() {}
//line :1108:1
func (t *A_arbace_aot_emit_field_mods_A) Invoke_O_O_O__O(self, ox__0, lb__1 any) any { var tmp1 *lang.Keyword = A_arbace_aot_emit_A_const_599; var m__3 any = lang.RT_Meta_O__IPersistentMap(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__1))); if




	jrt.A2g_Truth(A_arbace_aot_emit_A_const_600.Invoke_O__O(m__3)) { return A_arbace_aot_emit_A_const_601 } else { if jrt.A2g_Truth(A_arbace_aot_emit_A_const_602.Invoke_O__O(m__3)) { lang.PersistentArrayMap_Init(); return lang.PersistentArrayMap_EMPTY.Ref() } else { if A_arbace_aot_emit_A_const_60 != nil { return A_arbace_aot_emit_A_const_603 } else { return nil } } } }




func A_arbace_aot_emit_emit_deftype_class_BANG__A_New() *A_arbace_aot_emit_emit_deftype_class_BANG__A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_deftype_class_BANG__A{}; t.Ctor(); return t }
//line :1118:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__A) Ctor() {}
//line :1118:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__A) Invoke_O_O_O__O(self, ctx__0, ox__1 any) any { var cname__3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_34.Invoke_O__O(ox__1)); if





	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_302.Invoke_O__O(ctx__0)), cname__3)) { } else {
		lang.IFn_Cast(A_arbace_aot_emit_A_const_27.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_aot_emit_A_const_302.Invoke_O__O(ctx__0), A_arbace_aot_emit_A_const_13.GetRawRoot__O(), cname__3, A_arbace_aot_emit_A_const_617)
//line :1124:1
		var cls__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_604.GetRawRoot__O()).Invoke_O_O__O(ctx__0, cname__3); var fields__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_406.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_407.Invoke_O__O(ox__1))); var ctx_SINGLEQUOTE___6 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_13.GetRawRoot__O()); var tmp2 any = A_arbace_aot_emit_A_const_38; var tmp3 any = A_arbace_aot_emit_A_const_618; var tmp4 any = A_arbace_aot_emit_A_const_259; var tmp5 *jrt.Boolean



		jrt.Boolean_Init(); tmp5 = jrt.Boolean_FALSE; var tmp6 any = tmp5.Ref(); var tmp7 any = A_arbace_aot_emit_A_const_220; ctx_SINGLEQUOTE___6 = tmp1.Invoke_O_O_O_O_O_O_O_O_O__O(ctx__0, tmp2, cls__4, tmp3, ox__1, tmp4, tmp6, tmp7, lang.IFn_Cast(A_arbace_aot_emit_A_const_428.GetRawRoot__O()).Invoke_O__O(fields__5))
//line :1124:1
		var fbs__7 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_43.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_224.GetRawRoot__O(), fields__5); var ftype__8 any; var tmp8 any = A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000313_A_New(); var tmp9 *jrt.Class
		var fncls__68 /*line :1124:1*/*jrt.Class = A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000313_A_fn_class





		if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_92, false); A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000313_A_fn_class = fncls__68d; tmp9 = fncls__68d } else { tmp9 = fncls__68 }; ftype__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)
//line :1124:1
		var fsym__9 any; var tmp10 any = A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000315_A_New(); var tmp11 *jrt.Class
		var fncls__69 /*line :1124:1*/*jrt.Class = A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000315_A_fn_class






		if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_93, false); A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000315_A_fn_class = fncls__69d; tmp11 = fncls__69d } else { tmp11 = fncls__69 }; fsym__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)
//line :1124:1
		var hinted__10 any = A_arbace_aot_emit_A_const_605.Invoke_O__O(ox__1); var nh__11 int32 = lang.RT_Count_O__I(hinted__10); var drops__12 any = A_arbace_aot_emit_A_const_606.Invoke_O__O(ox__1); var ctor__13 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_100.GetRawRoot__O()); var tmp13 any = A_arbace_aot_emit_A_const_619; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()); var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()); var tmp17 any = A_arbace_aot_emit_A_const_624; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()); var tmp19 any = A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000317_A_New_O_O(ftype__8, fsym__9); var tmp20 *jrt.Class
		var fncls__85 /*line :1124:1*/*jrt.Class = A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000317_A_fn_class










		if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_94, false); A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000317_A_fn_class = fncls__85d; tmp20 = fncls__85d } else { tmp20 = fncls__85 }; var tmp21 any = tmp14.Invoke_O_O__O(tmp15.Invoke_O__O(tmp16.Invoke_O_O__O(tmp17, tmp18.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil), fbs__7))), A_arbace_aot_emit_A_const_623); var tmp22 any = A_arbace_aot_emit_A_const_620; var tmp23 any; var iter__1927001039__auto____13 any; var tmp24 any = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_A_New_O(fsym__9); var tmp25 *jrt.Class
		var fncls__84 /*line :1135:1*/*jrt.Class = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_A_fn_class

		if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_95, false); A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_A_fn_class = fncls__84d; tmp25 = fncls__84d } else { tmp25 = fncls__84 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil); tmp23 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(fbs__7)
//line :1135:1
		ctor__13 = tmp12.Invoke_O_O_O_O__O(tmp13, tmp21, tmp22, tmp23)
//line :1124:1
		var alt_ctors__14 any













		if lang.Numbers_IsPos_O__Z(drops__12) { var n__14 int32 = lang.RT_Count_O__I(fbs__7); var ps__15 any; var tmp26 any = A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000329_A_New_O_O_O(fbs__7, ftype__8, fsym__9); var tmp27 *jrt.Class
			var fncls__71 /*line :1138:1*/*jrt.Class = A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000329_A_fn_class

			if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_96, false); A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000329_A_fn_class = fncls__71d; tmp27 = fncls__71d } else { tmp27 = fncls__71 }; ps__15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil)
//line :1138:1
			var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp29 any = A_arbace_aot_emit_A_const_625; var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_100.GetRawRoot__O()); var tmp31 any = A_arbace_aot_emit_A_const_627; var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp33 any = A_arbace_aot_emit_A_const_630; var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_100.GetRawRoot__O()); var tmp35 any = A_arbace_aot_emit_A_const_632; alt_ctors__14 = lang.Tuple_Create_O_O__IPersistentVector(tmp28.Invoke_O_O_O__O(tmp29, lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(ps__15).Invoke_O__O(lang.Numbers_Minus_J_O__Number(int64(n__14), drops__12)), A_arbace_aot_emit_A_const_626), tmp30.Invoke_O_O__O(tmp31, lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()).Invoke_O_O__O(fsym__9, lang.IFn_Cast(A_arbace_aot_emit_A_const_608.GetRawRoot__O()).Invoke_O_O__O(lang.Numbers_Minus_J_O__Number(int64(n__14), drops__12), fbs__7)), lang.Tuple_Create_O_O_O_O__IPersistentVector(nil, nil, lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_628, A_arbace_aot_emit_A_const_31), lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_629, A_arbace_aot_emit_A_const_31))))), tmp32.Invoke_O_O_O__O(tmp33, lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(ps__15).Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(int64(n__14), 2)).Ref()), A_arbace_aot_emit_A_const_631), tmp34.Invoke_O_O__O(tmp35, lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()).Invoke_O_O__O(fsym__9, lang.IFn_Cast(A_arbace_aot_emit_A_const_608.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(int64(n__14), 2)).Ref(), fbs__7)), lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_633, A_arbace_aot_emit_A_const_31), lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_634, A_arbace_aot_emit_A_const_31)))))) } else { alt_ctors__14 = nil }
//line :1124:1
		var basis__15 any; var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp37 any = A_arbace_aot_emit_A_const_635; var tmp38 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_636, A_arbace_aot_emit_A_const_637); var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()); var tmp40 *lang.PersistentVector




















		lang.PersistentVector_Init(); tmp40 = lang.PersistentVector_EMPTY; basis__15 = tmp36.Invoke_O_O_O_O__O(tmp37, tmp38, tmp39.Invoke_O_O__O(tmp40.Ref(), A_arbace_aot_emit_A_const_638), lang.IFn_Cast(A_arbace_aot_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(ctx_SINGLEQUOTE___6, hinted__10))
//line :1124:1
		var create__16 any






















		if lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(fbs__7)), int64(nh__11)) { var m__16 any = A_arbace_aot_emit_A_const_609; var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp42 any = A_arbace_aot_emit_A_const_639; var tmp43 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_647, A_arbace_aot_emit_A_const_648); var tmp44 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(m__16, A_arbace_aot_emit_A_const_649)), lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(cname__3)); var tmp45 any; var steps__17 any; var iter__1927001039__auto____17 any; var tmp46 any = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_A_New_O(m__16); var tmp47 *jrt.Class
			var fncls__88 /*line :1147:1*/*jrt.Class = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_A_fn_class



			if fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_97, false); A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_A_fn_class = fncls__88d; tmp47 = fncls__88d } else { tmp47 = fncls__88 }; iter__1927001039__auto____17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp46, tmp47, nil); steps__17 = lang.IFn_Cast(iter__1927001039__auto____17).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_192.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_430.GetRawRoot__O(), hinted__10))









			var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp49 any = A_arbace_aot_emit_A_const_650; var tmp50 any = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(m__16, A_arbace_aot_emit_A_const_651), m__16); var tmp51 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_100.GetRawRoot__O()); var tmp52 any = A_arbace_aot_emit_A_const_652; var tmp53 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()); var tmp54 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_98.GetRawRoot__O()); var tmp55 any = A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000350_A_New(); var tmp56 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000350_A_fn_class
			if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_98, false); A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000350_A_fn_class = fncls__89d; tmp56 = fncls__89d } else { tmp56 = fncls__89 }
//line :1161:1
			var tmp57 any = tmp53.Invoke_O__O(tmp54.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp55, tmp56, nil), steps__17)); var tmp58 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()); var tmp59 any; var iter__1927001039__auto____18 any; var tmp60 any = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_A_New_O(m__16); var tmp61 *jrt.Class
			var fncls__92 /*line :1161:1*/*jrt.Class = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_A_fn_class

			if fncls__92 == nil { var fncls__92d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_99, false); A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_A_fn_class = fncls__92d; tmp61 = fncls__92d } else { tmp61 = fncls__92 }; iter__1927001039__auto____18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp60, tmp61, nil); tmp59 = lang.IFn_Cast(iter__1927001039__auto____18).Invoke_O__O(steps__17)
//line :1161:1
			var tmp62 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_100.GetRawRoot__O()); var tmp63 any = A_arbace_aot_emit_A_const_655; tmp45 = tmp48.Invoke_O_O_O__O(tmp49, tmp50, tmp51.Invoke_O_O_O__O(tmp52, tmp57, tmp58.Invoke_O_O__O(tmp59, lang.Tuple_Create_O__IPersistentVector(tmp62.Invoke_O_O_O__O(tmp63, lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(cname__3), lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_156.GetRawRoot__O(), steps__17), lang.Tuple_Create_O_O_O_O__IPersistentVector(nil, lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_656, m__16), lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_657, A_arbace_aot_emit_A_const_31), lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_658, A_arbace_aot_emit_A_const_31))))))))
//line :1149:1
			create__16 = tmp41.Invoke_O_O_O_O__O(tmp42, tmp43, tmp44, tmp45) } else {
//line :1147:1
				create__16 = nil }
//line :1124:1
		var methods__17 any; var iter__1927001039__auto____17_2 any; var tmp64 any = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_A_New_O(ctx_SINGLEQUOTE___6); var tmp65 *jrt.Class
		var fncls__78 /*line :1124:1*/*jrt.Class = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_A_fn_class











































		if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_100, false); A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_A_fn_class = fncls__78d; tmp65 = fncls__78d } else { tmp65 = fncls__78 }; iter__1927001039__auto____17_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp64, tmp65, nil); methods__17 = lang.IFn_Cast(iter__1927001039__auto____17_2).Invoke_O__O(A_arbace_aot_emit_A_const_659.Invoke_O__O(ox__1))
//line :1124:1
		var fields_forms__18 any; var iter__1927001039__auto____18_2 any; var tmp66 any = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_A_New_O_O_O(ox__1, ftype__8, fsym__9); var tmp67 *jrt.Class
		var fncls__81 /*line :1124:1*/*jrt.Class = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_A_fn_class




















































		if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_101, false); A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_A_fn_class = fncls__81d; tmp67 = fncls__81d } else { tmp67 = fncls__81 }; iter__1927001039__auto____18_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp66, tmp67, nil); fields_forms__18 = lang.IFn_Cast(iter__1927001039__auto____18_2).Invoke_O__O(fields__5)
//line :1124:1
		var members__19 any; var tmp68 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_571.GetRawRoot__O()); var tmp69 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()); var tmp70 any = lang.Tuple_Create_O__IPersistentVector(ctor__13); var tmp71 any = lang.Tuple_Create_O__IPersistentVector(basis__15); var tmp72 lang.IPersistentVector






















































		if jrt.A2g_Truth(create__16) { tmp72 = lang.Tuple_Create_O__IPersistentVector(create__16) } else { tmp72 = nil }; members__19 = tmp68.Invoke_O__O(tmp69.Invoke_O_O_O_O_O_O__O(fields_forms__18, tmp70, alt_ctors__14, tmp71, tmp72, methods__17))
		var tmp73 any = A_arbace_aot_emit_A_const_34; var tmp74 any = A_arbace_aot_emit_A_const_315; var tmp75 any = A_arbace_aot_emit_A_const_660; var tmp76 any = A_arbace_aot_emit_A_const_661; var tmp77 any = A_arbace_aot_emit_A_const_662; var tmp78 any = A_arbace_aot_emit_A_const_663; var tmp79 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_664.GetRawRoot__O()).Invoke_O_O__O(ctx__0, ox__1); var tmp80 any = A_arbace_aot_emit_A_const_665; var tmp81 any = A_arbace_aot_emit_A_const_254; var tmp82 any = A_arbace_aot_emit_A_const_254.Invoke_O__O(ox__1); var tmp83 any = A_arbace_aot_emit_A_const_666; lang.IFn_Cast(A_arbace_aot_emit_A_const_27.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_aot_emit_A_const_302.Invoke_O__O(ctx__0), A_arbace_aot_emit_A_const_13.GetRawRoot__O(), cname__3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp73, cname__3, tmp74, tmp75, tmp76, tmp77, tmp78, tmp79, tmp80, members__19, tmp81, tmp82, tmp83, A_arbace_aot_emit_A_const_666.Invoke_O__O(ctx__0)))) }; return cname__3 }
//line :1130:1
func A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000313_A_New() *A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000313_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000313_A{}; t.Ctor(); return t }
//line :1130:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000313_A) Ctor() {}
//line :1130:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000313_A) Invoke_O_O__O(self, b__1 any) any { var or__1927000174__auto____2 any = A_arbace_aot_emit_A_const_265.Invoke_O__O(b__1); if jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return A_arbace_aot_emit_A_const_228 } }
func A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000315_A_New() *A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000315_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000315_A{}; t.Ctor(); return t }
//line :1131:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000315_A) Ctor() {}
//line :1131:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000315_A) Invoke_O_O__O(self, b__1 any) any { return lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_34.Invoke_O__O(b__1)) }



func A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000317_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000317_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000317_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1135:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000317_A) Ctor_O_O(c__ftype, c__fsym any) { t.F_ftype = c__ftype; t.F_fsym = c__fsym }
//line :1135:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000317_A) Invoke_O_O__O(self, p1__90000310_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_fsym).Invoke_O__O(p1__90000310_SHARP___1), lang.IFn_Cast(t.F_ftype).Invoke_O__O(p1__90000310_SHARP___1)) }

func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_A_New_O(p0 any) *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_A{}; t.Ctor_O(p0); return t }
//line :1137:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_A) Ctor_O(c__fsym any) { t.F_fsym = c__fsym }
//line :1137:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_A) Invoke_O_O__O(self, s__90000320__1 any) any { var tmp1 any = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_fn__90000324_A_New_O_O_O(s__90000320__1, t.F_fsym, self); var tmp2 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_fn__90000324_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_102, false); A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_fn__90000324_A_fn_class = fncls__83d; tmp2 = fncls__83d } else { tmp2 = fncls__83 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1137:1
func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_fn__90000324_A_New_O_O_O(p0, p1, p2 any) *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_fn__90000324_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_fn__90000324_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1137:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_fn__90000324_A) Ctor_O_O_O(c__s__90000320, c__fsym, c__iter__90000319 any) { t.F_s__90000320 = c__s__90000320; t.F_fsym = c__fsym; t.F_iter__90000319 = c__iter__90000319 }
//line :1137:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_fn__90000324_A) Invoke_O__O(self any) any { { var s__90000320__1 any; var t_ any = t.F_s__90000320; t.F_s__90000320 = nil; s__90000320__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(s__90000320__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__90000320__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(s__90000320__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(s__90000320__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__90000322__6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_401.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_fn__90000324_fn__90000325_A_New_O_O_I_O(b__90000322__6, t.F_fsym, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__82 *jrt.Class = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_fn__90000324_fn__90000325_A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_103, false); A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_fn__90000324_fn__90000325_A_fn_class = fncls__82d; tmp2 = fncls__82d } else { tmp2 = fncls__82 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__90000319); return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000322__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__90000320__3))) } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000322__6), nil) } } else { var b__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__90000320__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_A_const_621; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__90000319); return lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O_O_O__O(tmp5, lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_221.GetRawRoot__O()).Invoke_O__O(b__4), A_arbace_aot_emit_A_const_622), lang.IFn_Cast(t.F_fsym).Invoke_O__O(b__4)), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(s__90000320__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :1137:1
func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_fn__90000324_fn__90000325_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_fn__90000324_fn__90000325_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_fn__90000324_fn__90000325_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :1137:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_fn__90000324_fn__90000325_A) Ctor_O_O_I_O(c__b__90000322, c__fsym any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__90000322 = c__b__90000322; t.F_fsym = c__fsym; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1137:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_fn__90000324_fn__90000325_A) Invoke_O__O(self any) any { { var i__90000321__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__90000321__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var b__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__90000321__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_402.GetRawRoot__O()); var tmp3 any = t.F_b__90000322; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_A_const_621; tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O__O(tmp5, lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_221.GetRawRoot__O()).Invoke_O__O(b__2), A_arbace_aot_emit_A_const_622), lang.IFn_Cast(t.F_fsym).Invoke_O__O(b__2))); i__90000321__1 = lang.Numbers_Unchecked_inc_J__J(i__90000321__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000329_A_New_O_O_O(p0, p1, p2 any) *A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000329_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000329_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1140:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000329_A) Ctor_O_O_O(c__fbs, c__ftype, c__fsym any) { t.F_fbs = c__fbs; t.F_ftype = c__ftype; t.F_fsym = c__fsym }
//line :1140:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000329_A) Invoke_O_O__O(self, k__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()); var tmp3 any = A_arbace_aot_emit_A_const_607; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000329_fn__90000330_A_New_O_O(t.F_ftype, t.F_fsym); var tmp6 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000329_fn__90000330_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_118, false); A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000329_fn__90000330_A_fn_class = fncls__70d; tmp6 = fncls__70d } else { tmp6 = fncls__70 }; return tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), lang.IFn_Cast(A_arbace_aot_emit_A_const_608.GetRawRoot__O()).Invoke_O_O__O(k__1, t.F_fbs)))) }
//line :1140:1
func A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000329_fn__90000330_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000329_fn__90000330_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000329_fn__90000330_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1140:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000329_fn__90000330_A) Ctor_O_O(c__ftype, c__fsym any) { t.F_ftype = c__ftype; t.F_fsym = c__fsym }
//line :1140:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000329_fn__90000330_A) Invoke_O_O__O(self, p1__90000311_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_fsym).Invoke_O__O(p1__90000311_SHARP___1), lang.IFn_Cast(t.F_ftype).Invoke_O__O(p1__90000311_SHARP___1)) }










func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_A_New_O(p0 any) *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_A{}; t.Ctor_O(p0); return t }
//line :1151:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_A) Ctor_O(c__m any) { t.F_m = c__m }
//line :1151:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_A) Invoke_O_O__O(self, s__90000334__1 any) any { var tmp1 any = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_fn__90000338_A_New_O_O_O(s__90000334__1, self, t.F_m); var tmp2 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_fn__90000338_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_104, false); A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_fn__90000338_A_fn_class = fncls__87d; tmp2 = fncls__87d } else { tmp2 = fncls__87 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1151:1
func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_fn__90000338_A_New_O_O_O(p0, p1, p2 any) *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_fn__90000338_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_fn__90000338_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1151:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_fn__90000338_A) Ctor_O_O_O(c__s__90000334, c__iter__90000333, c__m any) { t.F_s__90000334 = c__s__90000334; t.F_iter__90000333 = c__iter__90000333; t.F_m = c__m }
//line :1151:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_fn__90000338_A) Invoke_O__O(self any) any { { var s__90000334__1 any; var t_ any = t.F_s__90000334; t.F_s__90000334 = nil; s__90000334__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(s__90000334__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__90000334__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(s__90000334__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(s__90000334__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__90000336__6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_401.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_fn__90000338_fn__90000339_A_New_O_I_O_O(b__90000336__6, size__1927001038__auto____5, t.F_m, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__86 *jrt.Class = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_fn__90000338_fn__90000339_A_fn_class; if fncls__86 == nil { var fncls__86d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_105, false); A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_fn__90000338_fn__90000339_A_fn_class = fncls__86d; tmp2 = fncls__86d } else { tmp2 = fncls__86 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__90000333); return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000336__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__90000334__3))) } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000336__6), nil) } } else { var vec__90000344__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__90000334__3); var i__5 any = lang.RT_Nth_O_I_O__O(vec__90000344__4, lang.RT_IntCast_J__I(0), nil); var f__6 any = lang.RT_Nth_O_I_O__O(vec__90000344__4, lang.RT_IntCast_J__I(1), nil); var k__7 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_641, A_arbace_aot_emit_A_const_646), lang.IFn_Cast(A_arbace_aot_emit_A_const_83.GetRawRoot__O()).Invoke_O__O(f__6)); var tmp4 *lang.Keyword = A_arbace_aot_emit_A_const_23; var c__8 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_640.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__6))); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()); var tmp6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_106, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__5)).Ref()); var tmp7 any; var v__9 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_aot_emit_A_const_643, t.F_m, k__7, nil)




	if jrt.NN(jrt.Class_Cast(c__8)).IsPrimitive__Z() {
		var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp9 any = A_arbace_aot_emit_A_const_644; tmp7 = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_34, nil, Lit_107), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.Class_Cast(c__8)).GetName__String().Ref(), nil)).Ref()), tmp8.Invoke_O_O_O__O(tmp9, lang.IFn_Cast(A_arbace_aot_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_645.GetRawRoot__O()).Invoke_O__O(c__8)), v__9)) } else {
//line :1156:1
			tmp7 = v__9 }
//line :1151:1
	var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__90000333); return tmp5.Invoke_O_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(tmp6, tmp7, k__7), tmp10.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(s__90000334__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :1151:1
func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_fn__90000338_fn__90000339_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_fn__90000338_fn__90000339_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_fn__90000338_fn__90000339_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :1151:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_fn__90000338_fn__90000339_A) Ctor_O_I_O_O(c__b__90000336 any, c__size__1927001038__auto__ int32, c__m, c__c__1927001037__auto__ any) { t.F_b__90000336 = c__b__90000336; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_m = c__m; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1151:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_fn__90000338_fn__90000339_A) Invoke_O__O(self any) any { { var i__90000335__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__90000335__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__90000340__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__90000335__1)); var i__3 any = lang.RT_Nth_O_I_O__O(vec__90000340__2, lang.RT_IntCast_J__I(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O(vec__90000340__2, lang.RT_IntCast_J__I(1), nil); var k__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_641, A_arbace_aot_emit_A_const_642), lang.IFn_Cast(A_arbace_aot_emit_A_const_83.GetRawRoot__O()).Invoke_O__O(f__4)); var tmp2 *lang.Keyword = A_arbace_aot_emit_A_const_23; var c__6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_640.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__4))); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_402.GetRawRoot__O()); var tmp4 any = t.F_b__90000336; var tmp5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_106, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__3)).Ref()); var tmp6 any; var v__7 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_aot_emit_A_const_643, t.F_m, k__5, nil)




	if jrt.NN(jrt.Class_Cast(c__6)).IsPrimitive__Z() {
		var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp8 any = A_arbace_aot_emit_A_const_644; tmp6 = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_34, nil, Lit_107), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.Class_Cast(c__6)).GetName__String().Ref(), nil)).Ref()), tmp7.Invoke_O_O_O__O(tmp8, lang.IFn_Cast(A_arbace_aot_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_645.GetRawRoot__O()).Invoke_O__O(c__6)), v__7)) } else {
//line :1156:1
			tmp6 = v__7 }
//line :1151:1
	tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, tmp6, k__5)); i__90000335__1 = lang.Numbers_Unchecked_inc_J__J(i__90000335__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }










func A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000350_A_New() *A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000350_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000350_A{}; t.Ctor(); return t }
//line :1162:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000350_A) Ctor() {}
//line :1162:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000350_A) Invoke_O_O__O(self, p__90000349__1 any) any { var vec__90000351__2 any = p__90000349__1; var v__3 any = lang.RT_Nth_O_I_O__O(vec__90000351__2, lang.RT_IntCast_J__I(0), nil); var x__4 any = lang.RT_Nth_O_I_O__O(vec__90000351__2, lang.RT_IntCast_J__I(1), nil); var ___5 any = lang.RT_Nth_O_I_O__O(vec__90000351__2, lang.RT_IntCast_J__I(2), nil); _ = ___5; return lang.Tuple_Create_O_O__IPersistentVector(v__3, x__4) }
func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_A_New_O(p0 any) *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_A{}; t.Ctor_O(p0); return t }
//line :1163:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_A) Ctor_O(c__m any) { t.F_m = c__m }
//line :1163:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_A) Invoke_O_O__O(self, s__90000356__1 any) any { var tmp1 any = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_fn__90000360_A_New_O_O_O(s__90000356__1, self, t.F_m); var tmp2 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_fn__90000360_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_108, false); A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_fn__90000360_A_fn_class = fncls__91d; tmp2 = fncls__91d } else { tmp2 = fncls__91 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1163:1
func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_fn__90000360_A_New_O_O_O(p0, p1, p2 any) *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_fn__90000360_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_fn__90000360_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1163:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_fn__90000360_A) Ctor_O_O_O(c__s__90000356, c__iter__90000355, c__m any) { t.F_s__90000356 = c__s__90000356; t.F_iter__90000355 = c__iter__90000355; t.F_m = c__m }
//line :1163:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_fn__90000360_A) Invoke_O__O(self any) any { { var s__90000356__1 any; var t_ any = t.F_s__90000356; t.F_s__90000356 = nil; s__90000356__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(s__90000356__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__90000356__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(s__90000356__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(s__90000356__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__90000358__6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_401.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_fn__90000360_fn__90000361_A_New_O_I_O_O(b__90000358__6, size__1927001038__auto____5, t.F_m, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__90 *jrt.Class = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_fn__90000360_fn__90000361_A_fn_class; if fncls__90 == nil { var fncls__90d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_109, false); A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_fn__90000360_fn__90000361_A_fn_class = fncls__90d; tmp2 = fncls__90d } else { tmp2 = fncls__90 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__90000355); return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000358__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__90000356__3))) } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000358__6), nil) } } else { var vec__90000366__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__90000356__3); var ___5 any = lang.RT_Nth_O_I_O__O(vec__90000366__4, lang.RT_IntCast_J__I(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O(vec__90000366__4, lang.RT_IntCast_J__I(1), nil); var k__7 any = lang.RT_Nth_O_I_O__O(vec__90000366__4, lang.RT_IntCast_J__I(2), nil); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_A_const_653; var tmp6 any = t.F_m; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__90000355); _ = ___5; _ = ___6; return lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O_O_O__O(tmp5, tmp6, lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_aot_emit_A_const_654, t.F_m, k__7)), tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(s__90000356__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :1163:1
func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_fn__90000360_fn__90000361_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_fn__90000360_fn__90000361_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_fn__90000360_fn__90000361_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :1163:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_fn__90000360_fn__90000361_A) Ctor_O_I_O_O(c__b__90000358 any, c__size__1927001038__auto__ int32, c__m, c__c__1927001037__auto__ any) { t.F_b__90000358 = c__b__90000358; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_m = c__m; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1163:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_fn__90000360_fn__90000361_A) Invoke_O__O(self any) any { { var i__90000357__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__90000357__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__90000362__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__90000357__1)); var ___3 any = lang.RT_Nth_O_I_O__O(vec__90000362__2, lang.RT_IntCast_J__I(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O(vec__90000362__2, lang.RT_IntCast_J__I(1), nil); var k__5 any = lang.RT_Nth_O_I_O__O(vec__90000362__2, lang.RT_IntCast_J__I(2), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_402.GetRawRoot__O()); var tmp3 any = t.F_b__90000358; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_A_const_653; var tmp6 any = t.F_m; _ = ___3; _ = ___4; tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O__O(tmp5, tmp6, lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_aot_emit_A_const_654, t.F_m, k__5))); i__90000357__1 = lang.Numbers_Unchecked_inc_J__J(i__90000357__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_A_New_O(p0 any) *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_A{}; t.Ctor_O(p0); return t }
//line :1168:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_A) Ctor_O(c__ctx_SINGLEQUOTE_ any) { t.F_ctx_SINGLEQUOTE_ = c__ctx_SINGLEQUOTE_ }
//line :1168:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_A) Invoke_O_O__O(self, s__90000372__1 any) any { var tmp1 any = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_A_New_O_O_O(s__90000372__1, self, t.F_ctx_SINGLEQUOTE_); var tmp2 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_110, false); A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_A_fn_class = fncls__77d; tmp2 = fncls__77d } else { tmp2 = fncls__77 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1168:1
func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_A_New_O_O_O(p0, p1, p2 any) *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1168:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_A) Ctor_O_O_O(c__s__90000372, c__iter__90000371, c__ctx_SINGLEQUOTE_ any) { t.F_s__90000372 = c__s__90000372; t.F_iter__90000371 = c__iter__90000371; t.F_ctx_SINGLEQUOTE_ = c__ctx_SINGLEQUOTE_ }
//line :1168:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_A) Invoke_O__O(self any) any { { var s__90000372__1 any; var t_ any = t.F_s__90000372; t.F_s__90000372 = nil; s__90000372__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(s__90000372__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__90000372__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(s__90000372__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(s__90000372__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__90000374__6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_401.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_A_New_O_I_O_O(b__90000374__6, size__1927001038__auto____5, t.F_ctx_SINGLEQUOTE_, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_111, false); A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_A_fn_class = fncls__74d; tmp2 = fncls__74d } else { tmp2 = fncls__74 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__90000371); return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000374__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__90000372__3))) } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000374__6), nil) } } else { var m__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__90000372__3); var mn__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(m__4); var als__6 any = A_arbace_aot_emit_A_const_589.Invoke_O__O(mn__5); var ptypes__7 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000383_A_New(); var tmp6 *jrt.Class
															var fncls__75 /*line :1168:1*/*jrt.Class = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000383_A_fn_class


	if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_112, false); A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000383_A_fn_class = fncls__75d; tmp6 = fncls__75d } else { tmp6 = fncls__75 }; ptypes__7 = tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), als__6)
//line :1168:1
	var ps__8 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()); var tmp9 any = A_arbace_aot_emit_A_const_610; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()); var tmp11 any = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000385_A_New(); var tmp12 *jrt.Class
	var fncls__76 /*line :1168:1*/*jrt.Class = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000385_A_fn_class



	if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_113, false); A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000385_A_fn_class = fncls__76d; tmp12 = fncls__76d } else { tmp12 = fncls__76 }; ps__8 = tmp7.Invoke_O__O(tmp8.Invoke_O_O__O(tmp9, tmp10.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), als__6, ptypes__7)))
//line :1168:1
	var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_22.GetRawRoot__O()); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp15 any = A_arbace_aot_emit_A_const_611; var tmp16 any = tmp14.Invoke_O_O_O_O__O(tmp15, lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_34.Invoke_O__O(mn__5)), A_arbace_aot_emit_A_const_614), lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(ps__8, A_arbace_aot_emit_A_const_585.Invoke_O__O(mn__5)), lang.IFn_Cast(A_arbace_aot_emit_A_const_612.GetRawRoot__O()).Invoke_O_O_O__O(t.F_ctx_SINGLEQUOTE_, mn__5, ps__8)); var tmp17 any = A_arbace_aot_emit_A_const_13.GetRawRoot__O(); var tmp18 any = A_arbace_aot_emit_A_const_255; var tmp19 lang.IFn = lang.IFn_Cast(t.F_iter__90000371); return lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()).Invoke_O_O__O(tmp13.Invoke_O_O_O_O__O(tmp16, tmp17, tmp18, A_arbace_aot_emit_A_const_254.Invoke_O__O(mn__5)), tmp19.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(s__90000372__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :1168:1
func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :1168:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_A) Ctor_O_I_O_O(c__b__90000374 any, c__size__1927001038__auto__ int32, c__ctx_SINGLEQUOTE_, c__c__1927001037__auto__ any) { t.F_b__90000374 = c__b__90000374; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_ctx_SINGLEQUOTE_ = c__ctx_SINGLEQUOTE_; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1168:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_A) Invoke_O__O(self any) any { { var i__90000373__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__90000373__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__90000373__1)); var mn__3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(m__2); var als__4 any = A_arbace_aot_emit_A_const_589.Invoke_O__O(mn__3); var ptypes__5 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()); var tmp3 any = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_fn__90000378_A_New(); var tmp4 *jrt.Class
																	var fncls__72 /*line :1168:1*/*jrt.Class = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_fn__90000378_A_fn_class


	if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_114, false); A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_fn__90000378_A_fn_class = fncls__72d; tmp4 = fncls__72d } else { tmp4 = fncls__72 }; ptypes__5 = tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), als__4)
//line :1168:1
	var ps__6 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()); var tmp7 any = A_arbace_aot_emit_A_const_610; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()); var tmp9 any = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_fn__90000380_A_New(); var tmp10 *jrt.Class
	var fncls__73 /*line :1168:1*/*jrt.Class = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_fn__90000380_A_fn_class



	if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_115, false); A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_fn__90000380_A_fn_class = fncls__73d; tmp10 = fncls__73d } else { tmp10 = fncls__73 }; ps__6 = tmp5.Invoke_O__O(tmp6.Invoke_O_O__O(tmp7, tmp8.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), als__4, ptypes__5)))
//line :1168:1
	var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_402.GetRawRoot__O()); var tmp12 any = t.F_b__90000374; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_22.GetRawRoot__O()); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp15 any = A_arbace_aot_emit_A_const_611; var tmp16 any = tmp14.Invoke_O_O_O_O__O(tmp15, lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_34.Invoke_O__O(mn__3)), A_arbace_aot_emit_A_const_613), lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(ps__6, A_arbace_aot_emit_A_const_585.Invoke_O__O(mn__3)), lang.IFn_Cast(A_arbace_aot_emit_A_const_612.GetRawRoot__O()).Invoke_O_O_O__O(t.F_ctx_SINGLEQUOTE_, mn__3, ps__6)); var tmp17 any = A_arbace_aot_emit_A_const_13.GetRawRoot__O(); var tmp18 any = A_arbace_aot_emit_A_const_255; tmp11.Invoke_O_O__O(tmp12, tmp13.Invoke_O_O_O_O__O(tmp16, tmp17, tmp18, A_arbace_aot_emit_A_const_254.Invoke_O__O(mn__3))); i__90000373__1 = lang.Numbers_Unchecked_inc_J__J(i__90000373__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_fn__90000378_A_New() *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_fn__90000378_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_fn__90000378_A{}; t.Ctor(); return t }
//line :1171:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_fn__90000378_A) Ctor() {}
//line :1171:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_fn__90000378_A) Invoke_O_O__O(self, p1__90000312_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_aot_emit_A_const_340; var tmp2 *lang.Keyword = A_arbace_aot_emit_A_const_356; return tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(p1__90000312_SHARP___1)))) }
//line :1171:1
func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000383_A_New() *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000383_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000383_A{}; t.Ctor(); return t }
//line :1171:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000383_A) Ctor() {}
//line :1171:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000383_A) Invoke_O_O__O(self, p1__90000312_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_aot_emit_A_const_340; var tmp2 *lang.Keyword = A_arbace_aot_emit_A_const_356; return tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(p1__90000312_SHARP___1)))) }
func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_fn__90000380_A_New() *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_fn__90000380_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_fn__90000380_A{}; t.Ctor(); return t }
//line :1172:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_fn__90000380_A) Ctor() {}
//line :1172:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_fn__90000380_A) Invoke_O_O_O__O(self, lb__1, c__2 any) any { return lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_264.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__1)), c__2) }
//line :1172:1
func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000385_A_New() *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000385_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000385_A{}; t.Ctor(); return t }
//line :1172:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000385_A) Ctor() {}
//line :1172:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000385_A) Invoke_O_O_O__O(self, lb__1, c__2 any) any { return lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_264.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__1)), c__2) }




func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_A_New_O_O_O(p0, p1, p2 any) *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1177:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_A) Ctor_O_O_O(c__ox, c__ftype, c__fsym any) { t.F_ox = c__ox; t.F_ftype = c__ftype; t.F_fsym = c__fsym }
//line :1177:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_A) Invoke_O_O__O(self, s__90000390__1 any) any { var tmp1 any = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_fn__90000394_A_New_O_O_O_O_O(s__90000390__1, t.F_ox, self, t.F_ftype, t.F_fsym); var tmp2 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_fn__90000394_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_116, false); A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_fn__90000394_A_fn_class = fncls__80d; tmp2 = fncls__80d } else { tmp2 = fncls__80 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1177:1
func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_fn__90000394_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_fn__90000394_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_fn__90000394_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :1177:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_fn__90000394_A) Ctor_O_O_O_O_O(c__s__90000390, c__ox, c__iter__90000389, c__ftype, c__fsym any) { t.F_s__90000390 = c__s__90000390; t.F_ox = c__ox; t.F_iter__90000389 = c__iter__90000389; t.F_ftype = c__ftype; t.F_fsym = c__fsym }
//line :1177:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_fn__90000394_A) Invoke_O__O(self any) any { { var s__90000390__1 any; var t_ any = t.F_s__90000390; t.F_s__90000390 = nil; s__90000390__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(s__90000390__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__90000390__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(s__90000390__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(s__90000390__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__90000392__6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_401.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_fn__90000394_fn__90000395_A_New_O_O_O_O_I_O(t.F_ox, b__90000392__6, t.F_ftype, t.F_fsym, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_fn__90000394_fn__90000395_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_117, false); A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_fn__90000394_fn__90000395_A_fn_class = fncls__79d; tmp2 = fncls__79d } else { tmp2 = fncls__79 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__90000389); return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000392__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__90000390__3))) } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000392__6), nil) } } else { var lb__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__90000390__3); var b__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__4); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_A_const_615; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__90000389); return lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_fsym).Invoke_O__O(b__5), lang.IFn_Cast(A_arbace_aot_emit_A_const_616.GetRawRoot__O()).Invoke_O_O__O(t.F_ox, lb__4)), lang.IFn_Cast(t.F_ftype).Invoke_O__O(b__5))), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(s__90000390__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :1177:1
func A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_fn__90000394_fn__90000395_A_New_O_O_O_O_I_O(p0, p1, p2, p3 any, p4 int32, p5 any) *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_fn__90000394_fn__90000395_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_fn__90000394_fn__90000395_A{}; t.Ctor_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5); return t }
//line :1177:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_fn__90000394_fn__90000395_A) Ctor_O_O_O_O_I_O(c__ox, c__b__90000392, c__ftype, c__fsym any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_ox = c__ox; t.F_b__90000392 = c__b__90000392; t.F_ftype = c__ftype; t.F_fsym = c__fsym; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1177:1
func (t *A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_fn__90000394_fn__90000395_A) Invoke_O__O(self any) any { { var i__90000391__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__90000391__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var lb__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__90000391__1)); var b__3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__2); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_402.GetRawRoot__O()); var tmp3 any = t.F_b__90000392; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_A_const_615; tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_fsym).Invoke_O__O(b__3), lang.IFn_Cast(A_arbace_aot_emit_A_const_616.GetRawRoot__O()).Invoke_O_O__O(t.F_ox, lb__2)), lang.IFn_Cast(t.F_ftype).Invoke_O__O(b__3)))); i__90000391__1 = lang.Numbers_Unchecked_inc_J__J(i__90000391__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }







func A_arbace_aot_emit_emit_fn_class_BANG__A_New() *A_arbace_aot_emit_emit_fn_class_BANG__A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__A{}; t.Ctor(); return t }
//line :1185:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__A) Ctor() {}
//line :1185:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__A) Invoke_O_O_O__O(self, ctx__0, ox__1 any) any { var named__3 any = A_arbace_aot_emit_A_const_667.Invoke_O__O(ctx__0); var known__4 any = jrt.NN(jrt.IdentityHashMap_Cast(named__3)).Get_O__O(A_arbace_aot_emit_A_const_14.Invoke_O__O(ox__1)); var base__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_34.Invoke_O__O(ox__1)); var cname__6 any; var or__1927000174__auto____6 any = known__4; if









	jrt.A2g_Truth(or__1927000174__auto____6) { cname__6 = or__1927000174__auto____6 } else {
		var tmp1 any = A_arbace_aot_emit_emit_fn_class_BANG__fn__90000402_A_New_O_O(ctx__0, base__5); var tmp2 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__fn__90000402_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_119, false); A_arbace_aot_emit_emit_fn_class_BANG__fn__90000402_A_fn_class = fncls__93d; tmp2 = fncls__93d } else { tmp2 = fncls__93 }; cname__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }; if


	jrt.A2g_Truth(known__4) { } else {
		jrt.NN(jrt.IdentityHashMap_Cast(named__3)).Put_O_O__O(A_arbace_aot_emit_A_const_14.Invoke_O__O(ox__1), cname__6)
		lang.IFn_Cast(A_arbace_aot_emit_A_const_27.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_aot_emit_A_const_302.Invoke_O__O(ctx__0), A_arbace_aot_emit_A_const_13.GetRawRoot__O(), cname__6, A_arbace_aot_emit_A_const_617)
//line :1199:1
		var cls__7 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_604.GetRawRoot__O()).Invoke_O_O__O(ctx__0, lang.IFn_Cast(A_arbace_aot_emit_A_const_683.GetRawRoot__O()).Invoke_O__O(cname__6)); var fn_QMARK___8 bool = lang.Util_Equiv_O_O__Z(Lit_50, A_arbace_aot_emit_A_const_369.Invoke_O__O(ox__1)); var ctx_SINGLEQUOTE___9 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_13.GetRawRoot__O()); var tmp4 any = A_arbace_aot_emit_A_const_38; var tmp5 any = A_arbace_aot_emit_A_const_618; var tmp6 any = A_arbace_aot_emit_A_const_259; var tmp7 any = A_arbace_aot_emit_A_const_684.Invoke_O__O(ox__1); var tmp8 any = A_arbace_aot_emit_A_const_220; var tmp9 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_428.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_406.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_407.Invoke_O__O(ox__1))); var tmp10 any = A_arbace_aot_emit_A_const_262; var tmp11 any





		if fn_QMARK___8 { tmp11 = A_arbace_aot_emit_A_const_685 } else { tmp11 = A_arbace_aot_emit_A_const_686 }
//line :1204:1
		ctx_SINGLEQUOTE___9 = tmp3.Invoke_O_O_O_O_O_O_O_O_O_O_O__O(ctx__0, tmp4, cls__7, tmp5, ox__1, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11)
//line :1199:1
		var closes__10 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_406.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_407.Invoke_O__O(ox__1)); var meta_QMARK___11 any; var and__1927000168__auto____11 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(fn_QMARK___8).Ref())








		if jrt.A2g_Truth(and__1927000168__auto____11) { meta_QMARK___11 = jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(A_arbace_aot_emit_A_const_409.Invoke_O__O(ox__1))).Ref() } else { meta_QMARK___11 = and__1927000168__auto____11 }
//line :1199:1
		var fields__12 any; var iter__1927001039__auto____12 any; var tmp12 any = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_A_New(); var tmp13 *jrt.Class
		var fncls__96 /*line :1199:1*/*jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_A_fn_class









		if fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_120, false); A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_A_fn_class = fncls__96d; tmp13 = fncls__96d } else { tmp13 = fncls__96 }; iter__1927001039__auto____12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); fields__12 = lang.IFn_Cast(iter__1927001039__auto____12).Invoke_O__O(closes__10)
//line :1199:1
		var ctor__13 any; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_100.GetRawRoot__O()); var tmp15 any = A_arbace_aot_emit_A_const_687; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()); var tmp19 any = A_arbace_aot_emit_A_const_690; var tmp20 lang.IPersistentVector











		if jrt.A2g_Truth(meta_QMARK___11) { tmp20 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_691, A_arbace_aot_emit_A_const_692)) } else { tmp20 = nil }; var tmp21 any = tmp20; var tmp22 any; var iter__1927001039__auto____13 any; var tmp23 any = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_A_New(); var tmp24 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_A_fn_class
		if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_121, false); A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_A_fn_class = fncls__109d; tmp24 = fncls__109d } else { tmp24 = fncls__109 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); tmp22 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(closes__10)
//line :1211:1
		var tmp25 any = tmp16.Invoke_O_O__O(tmp17.Invoke_O__O(tmp18.Invoke_O_O_O__O(tmp19, tmp21, tmp22)), A_arbace_aot_emit_A_const_689); var tmp26 any = A_arbace_aot_emit_A_const_688; var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()); var tmp28 any




		if jrt.A2g_Truth(meta_QMARK___11) { tmp28 = A_arbace_aot_emit_A_const_693 } else { tmp28 = nil }
//line :1211:1
		var tmp29 any = tmp28; var tmp30 any; var iter__1927001039__auto____13_2 any; var tmp31 any = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_A_New(); var tmp32 *jrt.Class
		var fncls__112 /*line :1211:1*/*jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_A_fn_class





		if fncls__112 == nil { var fncls__112d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_122, false); A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_A_fn_class = fncls__112d; tmp32 = fncls__112d } else { tmp32 = fncls__112 }; iter__1927001039__auto____13_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil); tmp30 = lang.IFn_Cast(iter__1927001039__auto____13_2).Invoke_O__O(closes__10)
//line :1211:1
		ctor__13 = tmp14.Invoke_O_O_O_O__O(tmp15, tmp25, tmp26, tmp27.Invoke_O_O__O(tmp29, tmp30))
//line :1199:1
		var variadic__14 any; var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_669.GetRawRoot__O()); var tmp34 any = A_arbace_aot_emit_emit_fn_class_BANG__fn__90000434_A_New(); var tmp35 *jrt.Class
		var fncls__113 /*line :1199:1*/*jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__fn__90000434_A_fn_class



















		if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_123, false); A_arbace_aot_emit_emit_fn_class_BANG__fn__90000434_A_fn_class = fncls__113d; tmp35 = fncls__113d } else { tmp35 = fncls__113 }; var tmp36 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp34, tmp35, nil); var tmp37 any; if fn_QMARK___8 { tmp37 = A_arbace_aot_emit_A_const_659.Invoke_O__O(ox__1) } else { tmp37 = nil }; variadic__14 = tmp33.Invoke_O_O__O(tmp36, tmp37)
//line :1199:1
		var methods__15 any





















		if fn_QMARK___8 { var iter__1927001039__auto____15 any; var tmp38 any = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_A_New_O(ctx_SINGLEQUOTE___9); var tmp39 *jrt.Class
			var fncls__99 /*line :1221:1*/*jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_A_fn_class


			if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_124, false); A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_A_fn_class = fncls__99d; tmp39 = fncls__99d } else { tmp39 = fncls__99 }; iter__1927001039__auto____15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp38, tmp39, nil); methods__15 = lang.IFn_Cast(iter__1927001039__auto____15).Invoke_O__O(A_arbace_aot_emit_A_const_659.Invoke_O__O(ox__1)) } else {
//line :1221:1
				var iter__1927001039__auto____15_2 any; var tmp40 any = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_A_New_O(ctx_SINGLEQUOTE___9); var tmp41 *jrt.Class
				var fncls__106 /*line :1221:1*/*jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_A_fn_class











				if fncls__106 == nil { var fncls__106d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_125, false); A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_A_fn_class = fncls__106d; tmp41 = fncls__106d } else { tmp41 = fncls__106 }; iter__1927001039__auto____15_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp40, tmp41, nil); methods__15 = lang.IFn_Cast(iter__1927001039__auto____15_2).Invoke_O__O(A_arbace_aot_emit_A_const_659.Invoke_O__O(ox__1)) }
//line :1199:1
		var extra__16 any; var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()); var tmp43 lang.IPersistentVector









































		if fn_QMARK___8 { var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp45 any = A_arbace_aot_emit_A_const_696; tmp43 = lang.Tuple_Create_O__IPersistentVector(tmp44.Invoke_O_O__O(tmp45, lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_698, A_arbace_aot_emit_A_const_699), A_arbace_aot_emit_A_const_697))) } else { tmp43 = nil }
//line :1240:1
		var tmp46 any = tmp43; var tmp47 lang.IPersistentVector





		if jrt.A2g_Truth(meta_QMARK___11) { var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp49 any = A_arbace_aot_emit_A_const_700; var tmp50 any = tmp48.Invoke_O_O__O(tmp49, lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_701, A_arbace_aot_emit_A_const_702)); var tmp51 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp52 any = A_arbace_aot_emit_A_const_703; var tmp53 any = tmp51.Invoke_O_O_O_O__O(tmp52, lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_705, A_arbace_aot_emit_A_const_706), lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_707, A_arbace_aot_emit_A_const_708), A_arbace_aot_emit_A_const_704); var tmp54 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp55 any = A_arbace_aot_emit_A_const_709; var tmp56 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_710, A_arbace_aot_emit_A_const_711); var tmp57 any = A_arbace_aot_emit_A_const_713; var tmp58 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp57, lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_714, A_arbace_aot_emit_A_const_715)), A_arbace_aot_emit_A_const_712); var tmp59 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_100.GetRawRoot__O()); var tmp60 any = A_arbace_aot_emit_A_const_716; var tmp61 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(cname__6); var tmp62 any = A_arbace_aot_emit_A_const_717; var tmp63 any; var iter__1927001039__auto____16 any; var tmp64 any = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_A_New(); var tmp65 *jrt.Class
			var fncls__116 /*line :1246:1*/*jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_A_fn_class




			if fncls__116 == nil { var fncls__116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_126, false); A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_A_fn_class = fncls__116d; tmp65 = fncls__116d } else { tmp65 = fncls__116 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp64, tmp65, nil); tmp63 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(closes__10)
//line :1246:1
			tmp47 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp50, tmp53, tmp54.Invoke_O_O_O_O__O(tmp55, tmp56, tmp58, tmp59.Invoke_O_O_O_O__O(tmp60, tmp61, tmp62, tmp63))) } else { tmp47 = nil }
//line :1240:1
		extra__16 = tmp42.Invoke_O_O__O(tmp46, tmp47)
//line :1199:1
		var interfaces__17 any




















































		if fn_QMARK___8 {
			var tmp66 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()); var tmp67 any; var iter__1927001039__auto____17 any; var tmp68 any = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_A_New(); var tmp69 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_127, false); A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_A_fn_class = fncls__119d; tmp69 = fncls__119d } else { tmp69 = fncls__119 }; iter__1927001039__auto____17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp68, tmp69, nil); tmp67 = lang.IFn_Cast(iter__1927001039__auto____17).Invoke_O__O(A_arbace_aot_emit_A_const_659.Invoke_O__O(ox__1)); interfaces__17 = tmp66.Invoke_O__O(tmp67) } else {


				interfaces__17 = lang.IFn_Cast(A_arbace_aot_emit_A_const_664.GetRawRoot__O()).Invoke_O_O__O(ctx__0, ox__1) }
//line :1199:1
		var members__18 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_571.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()).Invoke_O_O_O_O__O(fields__12, lang.Tuple_Create_O__IPersistentVector(ctor__13), methods__15, extra__16)); var tmp70 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_27.GetRawRoot__O()); var tmp71 any = A_arbace_aot_emit_A_const_302.Invoke_O__O(ctx__0); var tmp72 any = A_arbace_aot_emit_A_const_13.GetRawRoot__O(); var tmp73 any = A_arbace_aot_emit_A_const_34; var tmp74 any = A_arbace_aot_emit_A_const_665; var tmp75 any = A_arbace_aot_emit_A_const_666; var tmp76 any = A_arbace_aot_emit_A_const_666.Invoke_O__O(ctx__0); var tmp77 any = A_arbace_aot_emit_A_const_315; var tmp78 *lang.Keyword






























































		if fn_QMARK___8 { tmp78 = A_arbace_aot_emit_A_const_719 } else { tmp78 = A_arbace_aot_emit_A_const_720 }
//line :1258:1
		var tmp79 any = tmp78.Ref(); var tmp80 any = A_arbace_aot_emit_A_const_661; var tmp81 any = A_arbace_aot_emit_A_const_721; var tmp82 any = A_arbace_aot_emit_A_const_663; var tmp83 any = A_arbace_aot_emit_A_const_411; var tmp84 *jrt.Integer






		if jrt.A2g_Truth(variadic__14) { tmp84 = jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(A_arbace_aot_emit_A_const_587.Invoke_O__O(variadic__14))) } else { tmp84 = nil }
//line :1258:1
		var tmp85 any = tmp84.Ref(); var tmp86 any = A_arbace_aot_emit_A_const_254; tmp70.Invoke_O_O_O_O__O(tmp71, tmp72, cname__6, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp73, cname__6, tmp74, members__18, tmp75, tmp76, tmp77, tmp79, tmp80, tmp81, tmp82, interfaces__17, tmp83, tmp85, tmp86, A_arbace_aot_emit_A_const_254.Invoke_O__O(ox__1)))) }; return cname__6 }
//line :1196:1
func A_arbace_aot_emit_emit_fn_class_BANG__fn__90000402_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_emit_fn_class_BANG__fn__90000402_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__fn__90000402_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1196:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__fn__90000402_A) Ctor_O_O(c__ctx, c__base any) { t.F_ctx = c__ctx; t.F_base = c__base }
//line :1196:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__fn__90000402_A) Invoke_O__O(self any) any { { var k__1 int64 = 0; L1: for { var c__2 any
												if lang.Numbers_IsZero_J__Z(k__1) { c__2 = t.F_base } else { var tmp1 any = t.F_base; c__2 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_128, nil), jrt.RefArrayOf(jrt.Object_class, tmp1, nil, jrt.Long_ValueOf_J__Long(k__1).Ref())).Ref() }
												if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_302.Invoke_O__O(t.F_ctx)), c__2)) { k__1 = lang.Numbers_Inc_J__J(k__1); continue L1 } else { return c__2 } } }; /*line :1196:1*/panic("a2g: unreachable") }












func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_A_New() *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_A{}; t.Ctor(); return t }
//line :1209:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_A) Ctor() {}
//line :1209:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_A) Invoke_O_O__O(self, s__90000405__1 any) any { var tmp1 any = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_fn__90000409_A_New_O_O(s__90000405__1, self); var tmp2 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_fn__90000409_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_129, false); A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_fn__90000409_A_fn_class = fncls__95d; tmp2 = fncls__95d } else { tmp2 = fncls__95 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1209:1
func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_fn__90000409_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_fn__90000409_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_fn__90000409_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1209:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_fn__90000409_A) Ctor_O_O(c__s__90000405, c__iter__90000404 any) { t.F_s__90000405 = c__s__90000405; t.F_iter__90000404 = c__iter__90000404 }
//line :1209:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_fn__90000409_A) Invoke_O__O(self any) any { { var s__90000405__1 any; var t_ any = t.F_s__90000405; t.F_s__90000405 = nil; s__90000405__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(s__90000405__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__90000405__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(s__90000405__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(s__90000405__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__90000407__6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_401.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_fn__90000409_fn__90000410_A_New_I_O_O(size__1927001038__auto____5, b__90000407__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__94 *jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_fn__90000409_fn__90000410_A_fn_class; if fncls__94 == nil { var fncls__94d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_130, false); A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_fn__90000409_fn__90000410_A_fn_class = fncls__94d; tmp2 = fncls__94d } else { tmp2 = fncls__94 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__90000404); return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000407__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__90000405__3))) } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000407__6), nil) } } else { var lb__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__90000405__3); var b__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__4); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp6 any = A_arbace_aot_emit_A_const_668; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()); var tmp8 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_34.Invoke_O__O(b__5)); var tmp9 any; var or__1927000174__auto____6 any = A_arbace_aot_emit_A_const_265.Invoke_O__O(b__5)
															if jrt.A2g_Truth(or__1927000174__auto____6) { tmp9 = or__1927000174__auto____6 } else { tmp9 = A_arbace_aot_emit_A_const_228 }
//line :1209:1
	var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__90000404); return tmp4.Invoke_O_O__O(tmp5.Invoke_O_O__O(tmp6, tmp7.Invoke_O_O__O(tmp8, tmp9)), tmp10.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(s__90000405__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :1209:1
func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_fn__90000409_fn__90000410_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_fn__90000409_fn__90000410_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_fn__90000409_fn__90000410_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :1209:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_fn__90000409_fn__90000410_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__90000407, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__90000407 = c__b__90000407; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1209:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_fn__90000409_fn__90000410_A) Invoke_O__O(self any) any { { var i__90000406__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__90000406__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var lb__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__90000406__1)); var b__3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__2); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_402.GetRawRoot__O()); var tmp3 any = t.F_b__90000407; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_A_const_668; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()); var tmp7 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_34.Invoke_O__O(b__3)); var tmp8 any; var or__1927000174__auto____4 any = A_arbace_aot_emit_A_const_265.Invoke_O__O(b__3)
																if jrt.A2g_Truth(or__1927000174__auto____4) { tmp8 = or__1927000174__auto____4 } else { tmp8 = A_arbace_aot_emit_A_const_228 }
//line :1209:1
	tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(tmp5, tmp6.Invoke_O_O__O(tmp7, tmp8))); i__90000406__1 = lang.Numbers_Unchecked_inc_J__J(i__90000406__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_A_New() *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_A{}; t.Ctor(); return t }
//line :1212:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_A) Ctor() {}
//line :1212:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_A) Invoke_O_O__O(self, s__90000415__1 any) any { var tmp1 any = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_fn__90000419_A_New_O_O(s__90000415__1, self); var tmp2 *jrt.Class; var fncls__108 *jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_fn__90000419_A_fn_class; if fncls__108 == nil { var fncls__108d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_131, false); A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_fn__90000419_A_fn_class = fncls__108d; tmp2 = fncls__108d } else { tmp2 = fncls__108 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1212:1
func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_fn__90000419_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_fn__90000419_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_fn__90000419_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1212:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_fn__90000419_A) Ctor_O_O(c__s__90000415, c__iter__90000414 any) { t.F_s__90000415 = c__s__90000415; t.F_iter__90000414 = c__iter__90000414 }
//line :1212:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_fn__90000419_A) Invoke_O__O(self any) any { { var s__90000415__1 any; var t_ any = t.F_s__90000415; t.F_s__90000415 = nil; s__90000415__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(s__90000415__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__90000415__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(s__90000415__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(s__90000415__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__90000417__6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_401.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_fn__90000419_fn__90000420_A_New_I_O_O(size__1927001038__auto____5, b__90000417__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_fn__90000419_fn__90000420_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_132, false); A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_fn__90000419_fn__90000420_A_fn_class = fncls__107d; tmp2 = fncls__107d } else { tmp2 = fncls__107 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__90000414); return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000417__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__90000415__3))) } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000417__6), nil) } } else { var lb__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__90000415__3); var b__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__4); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()); var tmp6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_133, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_aot_emit_A_const_34.Invoke_O__O(b__5))).Ref()); var tmp7 any; var or__1927000174__auto____6 any = A_arbace_aot_emit_A_const_265.Invoke_O__O(b__5)
															if jrt.A2g_Truth(or__1927000174__auto____6) { tmp7 = or__1927000174__auto____6 } else { tmp7 = A_arbace_aot_emit_A_const_228 }
//line :1212:1
	var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__90000414); return tmp4.Invoke_O_O__O(tmp5.Invoke_O_O__O(tmp6, tmp7), tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(s__90000415__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :1212:1
func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_fn__90000419_fn__90000420_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_fn__90000419_fn__90000420_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_fn__90000419_fn__90000420_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :1212:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_fn__90000419_fn__90000420_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__90000417, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__90000417 = c__b__90000417; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1212:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_fn__90000419_fn__90000420_A) Invoke_O__O(self any) any { { var i__90000416__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__90000416__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var lb__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__90000416__1)); var b__3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__2); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_402.GetRawRoot__O()); var tmp3 any = t.F_b__90000417; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()); var tmp5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_133, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_aot_emit_A_const_34.Invoke_O__O(b__3))).Ref()); var tmp6 any; var or__1927000174__auto____4 any = A_arbace_aot_emit_A_const_265.Invoke_O__O(b__3)
																if jrt.A2g_Truth(or__1927000174__auto____4) { tmp6 = or__1927000174__auto____4 } else { tmp6 = A_arbace_aot_emit_A_const_228 }
//line :1212:1
	tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(tmp5, tmp6)); i__90000416__1 = lang.Numbers_Unchecked_inc_J__J(i__90000416__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_A_New() *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_A{}; t.Ctor(); return t }
//line :1217:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_A) Ctor() {}
//line :1217:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_A) Invoke_O_O__O(self, s__90000425__1 any) any { var tmp1 any = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_fn__90000429_A_New_O_O(s__90000425__1, self); var tmp2 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_fn__90000429_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_134, false); A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_fn__90000429_A_fn_class = fncls__111d; tmp2 = fncls__111d } else { tmp2 = fncls__111 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1217:1
func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_fn__90000429_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_fn__90000429_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_fn__90000429_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1217:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_fn__90000429_A) Ctor_O_O(c__s__90000425, c__iter__90000424 any) { t.F_s__90000425 = c__s__90000425; t.F_iter__90000424 = c__iter__90000424 }
//line :1217:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_fn__90000429_A) Invoke_O__O(self any) any { { var s__90000425__1 any; var t_ any = t.F_s__90000425; t.F_s__90000425 = nil; s__90000425__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(s__90000425__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__90000425__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(s__90000425__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(s__90000425__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__90000427__6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_401.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_fn__90000429_fn__90000430_A_New_O_I_O(b__90000427__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__110 *jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_fn__90000429_fn__90000430_A_fn_class; if fncls__110 == nil { var fncls__110d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_135, false); A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_fn__90000429_fn__90000430_A_fn_class = fncls__110d; tmp2 = fncls__110d } else { tmp2 = fncls__110 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__90000424); return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000427__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__90000425__3))) } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000427__6), nil) } } else { var lb__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__90000425__3); var b__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__4); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_A_const_694; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__90000424); return lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O_O_O__O(tmp5, lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_221.GetRawRoot__O()).Invoke_O__O(b__5), A_arbace_aot_emit_A_const_695), lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_133, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_aot_emit_A_const_34.Invoke_O__O(b__5))).Ref())), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(s__90000425__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :1217:1
func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_fn__90000429_fn__90000430_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_fn__90000429_fn__90000430_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_fn__90000429_fn__90000430_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :1217:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_fn__90000429_fn__90000430_A) Ctor_O_I_O(c__b__90000427 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__90000427 = c__b__90000427; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1217:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_fn__90000429_fn__90000430_A) Invoke_O__O(self any) any { { var i__90000426__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__90000426__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var lb__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__90000426__1)); var b__3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__2); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_402.GetRawRoot__O()); var tmp3 any = t.F_b__90000427; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_A_const_694; tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O__O(tmp5, lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_221.GetRawRoot__O()).Invoke_O__O(b__3), A_arbace_aot_emit_A_const_695), lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_133, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_aot_emit_A_const_34.Invoke_O__O(b__3))).Ref()))); i__90000426__1 = lang.Numbers_Unchecked_inc_J__J(i__90000426__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_aot_emit_emit_fn_class_BANG__fn__90000434_A_New() *A_arbace_aot_emit_emit_fn_class_BANG__fn__90000434_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__fn__90000434_A{}; t.Ctor(); return t }
//line :1219:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__fn__90000434_A) Ctor() {}
//line :1219:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__fn__90000434_A) Invoke_O_O__O(self, p1__90000400_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_aot_emit_A_const_673; if jrt.A2g_Truth(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(p1__90000400_SHARP___1))) { return lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(p1__90000400_SHARP___1) } else { return nil } }




func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_A_New_O(p0 any) *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_A{}; t.Ctor_O(p0); return t }
//line :1224:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_A) Ctor_O(c__ctx_SINGLEQUOTE_ any) { t.F_ctx_SINGLEQUOTE_ = c__ctx_SINGLEQUOTE_ }
//line :1224:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_A) Invoke_O_O__O(self, s__90000437__1 any) any { var tmp1 any = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_fn__90000441_A_New_O_O_O(s__90000437__1, self, t.F_ctx_SINGLEQUOTE_); var tmp2 *jrt.Class; var fncls__98 *jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_fn__90000441_A_fn_class; if fncls__98 == nil { var fncls__98d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_136, false); A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_fn__90000441_A_fn_class = fncls__98d; tmp2 = fncls__98d } else { tmp2 = fncls__98 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1224:1
func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_fn__90000441_A_New_O_O_O(p0, p1, p2 any) *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_fn__90000441_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_fn__90000441_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1224:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_fn__90000441_A) Ctor_O_O_O(c__s__90000437, c__iter__90000436, c__ctx_SINGLEQUOTE_ any) { t.F_s__90000437 = c__s__90000437; t.F_iter__90000436 = c__iter__90000436; t.F_ctx_SINGLEQUOTE_ = c__ctx_SINGLEQUOTE_ }
//line :1224:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_fn__90000441_A) Invoke_O__O(self any) any { { var s__90000437__1 any; var t_ any = t.F_s__90000437; t.F_s__90000437 = nil; s__90000437__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(s__90000437__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__90000437__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(s__90000437__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(s__90000437__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__90000439__6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_401.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_fn__90000441_fn__90000442_A_New_O_I_O_O(t.F_ctx_SINGLEQUOTE_, size__1927001038__auto____5, b__90000439__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_fn__90000441_fn__90000442_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_137, false); A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_fn__90000441_fn__90000442_A_fn_class = fncls__97d; tmp2 = fncls__97d } else { tmp2 = fncls__97 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__90000436); return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000439__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__90000437__3))) } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000439__6), nil) } } else { var m__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__90000437__3); var mn__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(m__4); var req__6 any = A_arbace_aot_emit_A_const_587.Invoke_O__O(mn__5); var ps__7 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()); var tmp6 any = A_arbace_aot_emit_A_const_677; var tmp7 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_671.GetRawRoot__O(), req__6); var tmp8 lang.IPersistentVector



	if jrt.A2g_Truth(A_arbace_aot_emit_A_const_588.Invoke_O__O(mn__5)) { tmp8 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_aot_emit_A_const_671.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_588.Invoke_O__O(mn__5))) } else { tmp8 = nil }
//line :1227:1
	ps__7 = tmp4.Invoke_O__O(tmp5.Invoke_O_O_O__O(tmp6, tmp7, tmp8))
//line :1224:1
	var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_22.GetRawRoot__O()); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp12 any = A_arbace_aot_emit_A_const_672; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()); var tmp14 any





	if jrt.A2g_Truth(A_arbace_aot_emit_A_const_673.Invoke_O__O(mn__5)) { tmp14 = A_arbace_aot_emit_A_const_674 } else { tmp14 = A_arbace_aot_emit_A_const_675 }
//line :1224:1
	var tmp15 any = tmp11.Invoke_O_O_O_O__O(tmp12, tmp13.Invoke_O_O__O(tmp14, A_arbace_aot_emit_A_const_678), ps__7, lang.IFn_Cast(A_arbace_aot_emit_A_const_612.GetRawRoot__O()).Invoke_O_O_O__O(t.F_ctx_SINGLEQUOTE_, mn__5, ps__7)); var tmp16 any = A_arbace_aot_emit_A_const_13.GetRawRoot__O(); var tmp17 any = A_arbace_aot_emit_A_const_255; var tmp18 lang.IFn = lang.IFn_Cast(t.F_iter__90000436); return tmp9.Invoke_O_O__O(tmp10.Invoke_O_O_O_O__O(tmp15, tmp16, tmp17, A_arbace_aot_emit_A_const_254.Invoke_O__O(mn__5)), tmp18.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(s__90000437__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :1224:1
func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_fn__90000441_fn__90000442_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_fn__90000441_fn__90000442_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_fn__90000441_fn__90000442_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :1224:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_fn__90000441_fn__90000442_A) Ctor_O_I_O_O(c__ctx_SINGLEQUOTE_ any, c__size__1927001038__auto__ int32, c__b__90000439, c__c__1927001037__auto__ any) { t.F_ctx_SINGLEQUOTE_ = c__ctx_SINGLEQUOTE_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__90000439 = c__b__90000439; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1224:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_fn__90000441_fn__90000442_A) Invoke_O__O(self any) any { { var i__90000438__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__90000438__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__90000438__1)); var mn__3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(m__2); var req__4 any = A_arbace_aot_emit_A_const_587.Invoke_O__O(mn__3); var ps__5 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()); var tmp4 any = A_arbace_aot_emit_A_const_670; var tmp5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_671.GetRawRoot__O(), req__4); var tmp6 lang.IPersistentVector



	if jrt.A2g_Truth(A_arbace_aot_emit_A_const_588.Invoke_O__O(mn__3)) { tmp6 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_aot_emit_A_const_671.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_588.Invoke_O__O(mn__3))) } else { tmp6 = nil }
//line :1227:1
	ps__5 = tmp2.Invoke_O__O(tmp3.Invoke_O_O_O__O(tmp4, tmp5, tmp6))
//line :1224:1
	var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_402.GetRawRoot__O()); var tmp8 any = t.F_b__90000439; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_22.GetRawRoot__O()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp11 any = A_arbace_aot_emit_A_const_672; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()); var tmp13 any





	if jrt.A2g_Truth(A_arbace_aot_emit_A_const_673.Invoke_O__O(mn__3)) { tmp13 = A_arbace_aot_emit_A_const_674 } else { tmp13 = A_arbace_aot_emit_A_const_675 }
//line :1224:1
	var tmp14 any = tmp10.Invoke_O_O_O_O__O(tmp11, tmp12.Invoke_O_O__O(tmp13, A_arbace_aot_emit_A_const_676), ps__5, lang.IFn_Cast(A_arbace_aot_emit_A_const_612.GetRawRoot__O()).Invoke_O_O_O__O(t.F_ctx_SINGLEQUOTE_, mn__3, ps__5)); var tmp15 any = A_arbace_aot_emit_A_const_13.GetRawRoot__O(); var tmp16 any = A_arbace_aot_emit_A_const_255; tmp7.Invoke_O_O__O(tmp8, tmp9.Invoke_O_O_O_O__O(tmp14, tmp15, tmp16, A_arbace_aot_emit_A_const_254.Invoke_O__O(mn__3))); i__90000438__1 = lang.Numbers_Unchecked_inc_J__J(i__90000438__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }








func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_A_New_O(p0 any) *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_A{}; t.Ctor_O(p0); return t }
//line :1233:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_A) Ctor_O(c__ctx_SINGLEQUOTE_ any) { t.F_ctx_SINGLEQUOTE_ = c__ctx_SINGLEQUOTE_ }
//line :1233:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_A) Invoke_O_O__O(self, s__90000447__1 any) any { var tmp1 any = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_A_New_O_O_O(s__90000447__1, self, t.F_ctx_SINGLEQUOTE_); var tmp2 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_138, false); A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_A_fn_class = fncls__105d; tmp2 = fncls__105d } else { tmp2 = fncls__105 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1233:1
func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_A_New_O_O_O(p0, p1, p2 any) *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1233:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_A) Ctor_O_O_O(c__s__90000447, c__iter__90000446, c__ctx_SINGLEQUOTE_ any) { t.F_s__90000447 = c__s__90000447; t.F_iter__90000446 = c__iter__90000446; t.F_ctx_SINGLEQUOTE_ = c__ctx_SINGLEQUOTE_ }
//line :1233:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_A) Invoke_O__O(self any) any { { var s__90000447__1 any; var t_ any = t.F_s__90000447; t.F_s__90000447 = nil; s__90000447__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(s__90000447__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__90000447__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(s__90000447__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(s__90000447__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__90000449__6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_401.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_A_New_O_O_I_O(t.F_ctx_SINGLEQUOTE_, b__90000449__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__102 *jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_A_fn_class; if fncls__102 == nil { var fncls__102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_139, false); A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_A_fn_class = fncls__102d; tmp2 = fncls__102d } else { tmp2 = fncls__102 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__90000446); return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000449__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__90000447__3))) } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000449__6), nil) } } else { var m__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__90000447__3); var mn__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(m__4); var als__6 any = A_arbace_aot_emit_A_const_589.Invoke_O__O(mn__5); var ptypes__7 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000458_A_New(); var tmp6 *jrt.Class
															var fncls__103 /*line :1233:1*/*jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000458_A_fn_class


	if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_140, false); A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000458_A_fn_class = fncls__103d; tmp6 = fncls__103d } else { tmp6 = fncls__103 }; ptypes__7 = tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), als__6)
//line :1233:1
	var ps__8 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()); var tmp9 any = A_arbace_aot_emit_A_const_679; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()); var tmp11 any = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000460_A_New(); var tmp12 *jrt.Class
	var fncls__104 /*line :1233:1*/*jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000460_A_fn_class



	if fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_141, false); A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000460_A_fn_class = fncls__104d; tmp12 = fncls__104d } else { tmp12 = fncls__104 }; ps__8 = tmp7.Invoke_O__O(tmp8.Invoke_O_O__O(tmp9, tmp10.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), als__6, ptypes__7)))
//line :1233:1
	var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp14 any = A_arbace_aot_emit_A_const_680; var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__90000446); return lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()).Invoke_O_O__O(tmp13.Invoke_O_O_O_O__O(tmp14, lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_34.Invoke_O__O(mn__5)), A_arbace_aot_emit_A_const_682), lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(ps__8, A_arbace_aot_emit_A_const_585.Invoke_O__O(mn__5)), lang.IFn_Cast(A_arbace_aot_emit_A_const_612.GetRawRoot__O()).Invoke_O_O_O__O(t.F_ctx_SINGLEQUOTE_, mn__5, ps__8)), tmp15.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(s__90000447__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :1233:1
func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :1233:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_A) Ctor_O_O_I_O(c__ctx_SINGLEQUOTE_, c__b__90000449 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_ctx_SINGLEQUOTE_ = c__ctx_SINGLEQUOTE_; t.F_b__90000449 = c__b__90000449; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1233:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_A) Invoke_O__O(self any) any { { var i__90000448__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__90000448__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__90000448__1)); var mn__3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(m__2); var als__4 any = A_arbace_aot_emit_A_const_589.Invoke_O__O(mn__3); var ptypes__5 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()); var tmp3 any = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_fn__90000453_A_New(); var tmp4 *jrt.Class
																var fncls__100 /*line :1233:1*/*jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_fn__90000453_A_fn_class


	if fncls__100 == nil { var fncls__100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_142, false); A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_fn__90000453_A_fn_class = fncls__100d; tmp4 = fncls__100d } else { tmp4 = fncls__100 }; ptypes__5 = tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), als__4)
//line :1233:1
	var ps__6 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()); var tmp7 any = A_arbace_aot_emit_A_const_679; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()); var tmp9 any = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_fn__90000455_A_New(); var tmp10 *jrt.Class
	var fncls__101 /*line :1233:1*/*jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_fn__90000455_A_fn_class



	if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_143, false); A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_fn__90000455_A_fn_class = fncls__101d; tmp10 = fncls__101d } else { tmp10 = fncls__101 }; ps__6 = tmp5.Invoke_O__O(tmp6.Invoke_O_O__O(tmp7, tmp8.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), als__4, ptypes__5)))
//line :1233:1
	var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_402.GetRawRoot__O()); var tmp12 any = t.F_b__90000449; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp14 any = A_arbace_aot_emit_A_const_680; tmp11.Invoke_O_O__O(tmp12, tmp13.Invoke_O_O_O_O__O(tmp14, lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_34.Invoke_O__O(mn__3)), A_arbace_aot_emit_A_const_681), lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(ps__6, A_arbace_aot_emit_A_const_585.Invoke_O__O(mn__3)), lang.IFn_Cast(A_arbace_aot_emit_A_const_612.GetRawRoot__O()).Invoke_O_O_O__O(t.F_ctx_SINGLEQUOTE_, mn__3, ps__6))); i__90000448__1 = lang.Numbers_Unchecked_inc_J__J(i__90000448__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_fn__90000453_A_New() *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_fn__90000453_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_fn__90000453_A{}; t.Ctor(); return t }
//line :1236:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_fn__90000453_A) Ctor() {}
//line :1236:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_fn__90000453_A) Invoke_O_O__O(self, p1__90000401_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_aot_emit_A_const_340; var tmp2 *lang.Keyword = A_arbace_aot_emit_A_const_356; return tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(p1__90000401_SHARP___1)))) }
//line :1236:1
func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000458_A_New() *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000458_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000458_A{}; t.Ctor(); return t }
//line :1236:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000458_A) Ctor() {}
//line :1236:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000458_A) Invoke_O_O__O(self, p1__90000401_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_aot_emit_A_const_340; var tmp2 *lang.Keyword = A_arbace_aot_emit_A_const_356; return tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(p1__90000401_SHARP___1)))) }
func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_fn__90000455_A_New() *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_fn__90000455_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_fn__90000455_A{}; t.Ctor(); return t }
//line :1237:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_fn__90000455_A) Ctor() {}
//line :1237:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_fn__90000455_A) Invoke_O_O_O__O(self, lb__1, c__2 any) any { return lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_264.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__1)), c__2) }
//line :1237:1
func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000460_A_New() *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000460_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000460_A{}; t.Ctor(); return t }
//line :1237:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000460_A) Ctor() {}
//line :1237:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000460_A) Invoke_O_O_O__O(self, lb__1, c__2 any) any { return lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_264.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__1)), c__2) }













func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_A_New() *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_A{}; t.Ctor(); return t }
//line :1251:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_A) Ctor() {}
//line :1251:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_A) Invoke_O_O__O(self, s__90000465__1 any) any { var tmp1 any = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_fn__90000469_A_New_O_O(s__90000465__1, self); var tmp2 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_fn__90000469_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_144, false); A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_fn__90000469_A_fn_class = fncls__115d; tmp2 = fncls__115d } else { tmp2 = fncls__115 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1251:1
func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_fn__90000469_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_fn__90000469_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_fn__90000469_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1251:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_fn__90000469_A) Ctor_O_O(c__s__90000465, c__iter__90000464 any) { t.F_s__90000465 = c__s__90000465; t.F_iter__90000464 = c__iter__90000464 }
//line :1251:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_fn__90000469_A) Invoke_O__O(self any) any { { var s__90000465__1 any; var t_ any = t.F_s__90000465; t.F_s__90000465 = nil; s__90000465__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(s__90000465__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__90000465__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(s__90000465__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(s__90000465__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__90000467__6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_401.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_fn__90000469_fn__90000470_A_New_O_I_O(b__90000467__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__114 *jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_fn__90000469_fn__90000470_A_fn_class; if fncls__114 == nil { var fncls__114d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_145, false); A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_fn__90000469_fn__90000470_A_fn_class = fncls__114d; tmp2 = fncls__114d } else { tmp2 = fncls__114 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__90000464); return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000467__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__90000465__3))) } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000467__6), nil) } } else { var lb__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__90000465__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__90000464); return lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_221.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__4)), A_arbace_aot_emit_A_const_718), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(s__90000465__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :1251:1
func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_fn__90000469_fn__90000470_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_fn__90000469_fn__90000470_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_fn__90000469_fn__90000470_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :1251:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_fn__90000469_fn__90000470_A) Ctor_O_I_O(c__b__90000467 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__90000467 = c__b__90000467; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1251:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_fn__90000469_fn__90000470_A) Invoke_O__O(self any) any { { var i__90000466__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__90000466__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var lb__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__90000466__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_402.GetRawRoot__O()); var tmp3 any = t.F_b__90000467; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_221.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lb__2)), A_arbace_aot_emit_A_const_718)); i__90000466__1 = lang.Numbers_Unchecked_inc_J__J(i__90000466__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_A_New() *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_A{}; t.Ctor(); return t }
//line :1253:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_A) Ctor() {}
//line :1253:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_A) Invoke_O_O__O(self, s__90000475__1 any) any { var tmp1 any = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_fn__90000479_A_New_O_O(s__90000475__1, self); var tmp2 *jrt.Class; var fncls__118 *jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_fn__90000479_A_fn_class; if fncls__118 == nil { var fncls__118d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_146, false); A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_fn__90000479_A_fn_class = fncls__118d; tmp2 = fncls__118d } else { tmp2 = fncls__118 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1253:1
func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_fn__90000479_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_fn__90000479_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_fn__90000479_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1253:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_fn__90000479_A) Ctor_O_O(c__s__90000475, c__iter__90000474 any) { t.F_s__90000475 = c__s__90000475; t.F_iter__90000474 = c__iter__90000474 }
//line :1253:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_fn__90000479_A) Invoke_O__O(self any) any { { var s__90000475__1 any; var t_ any = t.F_s__90000475; t.F_s__90000475 = nil; s__90000475__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(s__90000475__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__90000475__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(s__90000475__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(s__90000475__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__90000477__6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_401.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_fn__90000479_fn__90000480_A_New_O_I_O(b__90000477__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_fn__90000479_fn__90000480_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_147, false); A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_fn__90000479_fn__90000480_A_fn_class = fncls__117d; tmp2 = fncls__117d } else { tmp2 = fncls__117 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__90000474); return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000477__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__90000475__3))) } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000477__6), nil) } } else { var m__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__90000475__3); var mn__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(m__4); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()); var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp7 *jrt.String
															if jrt.A2g_Truth(A_arbace_aot_emit_A_const_673.Invoke_O__O(mn__5)) { tmp7 = Lit_148 } else { tmp7 = Lit_149 }
//line :1253:1
	var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__90000474); return tmp4.Invoke_O_O__O(tmp5.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7.Ref(), jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(A_arbace_aot_emit_A_const_587.Invoke_O__O(mn__5))).Ref())).Ref()), tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(s__90000475__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :1253:1
func A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_fn__90000479_fn__90000480_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_fn__90000479_fn__90000480_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_fn__90000479_fn__90000480_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :1253:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_fn__90000479_fn__90000480_A) Ctor_O_I_O(c__b__90000477 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__90000477 = c__b__90000477; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1253:1
func (t *A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_fn__90000479_fn__90000480_A) Invoke_O__O(self any) any { { var i__90000476__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__90000476__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__90000476__1)); var mn__3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(m__2); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_402.GetRawRoot__O()); var tmp3 any = t.F_b__90000477; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()); var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp6 *jrt.String
																if jrt.A2g_Truth(A_arbace_aot_emit_A_const_673.Invoke_O__O(mn__3)) { tmp6 = Lit_148 } else { tmp6 = Lit_149 }
//line :1253:1
	tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp6.Ref(), jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(A_arbace_aot_emit_A_const_587.Invoke_O__O(mn__3))).Ref())).Ref())); i__90000476__1 = lang.Numbers_Unchecked_inc_J__J(i__90000476__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


















func A_arbace_aot_emit_unit_method_A_New() *A_arbace_aot_emit_unit_method_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_unit_method_A{}; t.Ctor(); return t }
//line :1272:1
func (t *A_arbace_aot_emit_unit_method_A) Ctor() {}
//line :1272:1
func (t *A_arbace_aot_emit_unit_method_A) Invoke_O_O_O_O__O(self, ctx__0, k__1, p__90000486__2 any) any { var vec__90000487__4 any = p__90000486__2; var kind__5 any = lang.RT_Nth_O_I_O__O(vec__90000487__4, lang.RT_IntCast_J__I(0), nil); var line__6 any = lang.RT_Nth_O_I_O__O(vec__90000487__4, lang.RT_IntCast_J__I(1), nil); var column__7 any = lang.RT_Nth_O_I_O__O(vec__90000487__4, lang.RT_IntCast_J__I(2), nil); var ___8 any = lang.RT_Nth_O_I_O__O(vec__90000487__4, lang.RT_IntCast_J__I(3), nil); var ___9 any = lang.RT_Nth_O_I_O__O(vec__90000487__4, lang.RT_IntCast_J__I(4), nil); var expr__10 any = lang.RT_Nth_O_I_O__O(vec__90000487__4, lang.RT_IntCast_J__I(5), nil); var events__11 any = lang.RT_Nth_O_I_O__O(vec__90000487__4, lang.RT_IntCast_J__I(6), nil); var ns_events__12 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_507.GetRawRoot__O()); var tmp2 any = A_arbace_aot_emit_A_const_99.GetRawRoot__O(); var tmp3 any; var iter__1927001039__auto____12 any; var tmp4 any = A_arbace_aot_emit_unit_method_iter__90000490__90000494_A_New_O(ctx__0); var tmp5 *jrt.Class; var fncls__126 *jrt.Class = A_arbace_aot_emit_unit_method_iter__90000490__90000494_A_fn_class; _ = ___8; _ = ___9; if



	fncls__126 == nil { var fncls__126d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_270, false); A_arbace_aot_emit_unit_method_iter__90000490__90000494_A_fn_class = fncls__126d; tmp5 = fncls__126d } else { tmp5 = fncls__126 }; iter__1927001039__auto____12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); tmp3 = lang.IFn_Cast(iter__1927001039__auto____12).Invoke_O__O(events__11); ns_events__12 = tmp1.Invoke_O_O__O(tmp2, tmp3); var n__13 any = /*line :1272:1*/lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(expr__10); var code__14 any; if
























	lang.Util_Equiv_O_J__Z(kind__5, 1) { var m__14 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_659.Invoke_O__O(n__13))); var ctx_SINGLEQUOTE___15 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_13.GetRawRoot__O()); var tmp7 any = A_arbace_aot_emit_A_const_618; var tmp8 any = A_arbace_aot_emit_A_const_259; var tmp9 *jrt.Boolean


		jrt.Boolean_Init(); tmp9 = jrt.Boolean_FALSE; ctx_SINGLEQUOTE___15 = tmp6.Invoke_O_O_O_O_O_O_O__O(ctx__0, tmp7, n__13, tmp8, tmp9.Ref(), A_arbace_aot_emit_A_const_220, nil)
		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_407.Invoke_O__O(n__13))) { lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(Lit_271) }
		code__14 = lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx_SINGLEQUOTE___15, A_arbace_aot_emit_A_const_388.Invoke_O__O(m__14)) } else {
			if lang.Util_Equiv_O_O__Z(Lit_40, A_arbace_aot_emit_A_const_369.Invoke_O__O(n__13)) {
				var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_491.GetRawRoot__O()); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; code__14 = tmp10.Invoke_O_O_O__O(ctx__0, n__13, tmp11.Ref()) } else {
					code__14 = lang.IFn_Cast(A_arbace_aot_emit_A_const_240.GetRawRoot__O()).Invoke_O_O__O(ctx__0, expr__10) } }; var tmp12 lang.IFn =
	lang.IFn_Cast(A_arbace_aot_emit_A_const_22.GetRawRoot__O()); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp14 any = A_arbace_aot_emit_A_const_741; var tmp15 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_178, nil), jrt.RefArrayOf(jrt.Object_class, nil, k__1)).Ref()), A_arbace_aot_emit_A_const_742); var tmp16 *lang.PersistentVector; lang.PersistentVector_Init(); tmp16 = lang.PersistentVector_EMPTY; var tmp17 any = tmp16.Ref(); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp19 any = A_arbace_aot_emit_A_const_743; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp21 any = A_arbace_aot_emit_A_const_744; return tmp12.Invoke_O_O_O_O__O(tmp13.Invoke_O_O_O_O__O(tmp14, tmp15, tmp17, lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()).Invoke_O_O_O__O(tmp18.Invoke_O_O__O(tmp19, tmp20.Invoke_O_O_O__O(tmp21, lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_745, line__6), lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_746, column__7))), ns_events__12, lang.Tuple_Create_O__IPersistentVector(code__14))), A_arbace_aot_emit_A_const_13.GetRawRoot__O(), A_arbace_aot_emit_A_const_255, line__6) }
//line :1276:1
func A_arbace_aot_emit_unit_method_iter__90000490__90000494_A_New_O(p0 any) *A_arbace_aot_emit_unit_method_iter__90000490__90000494_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_unit_method_iter__90000490__90000494_A{}; t.Ctor_O(p0); return t }
//line :1276:1
func (t *A_arbace_aot_emit_unit_method_iter__90000490__90000494_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :1276:1
func (t *A_arbace_aot_emit_unit_method_iter__90000490__90000494_A) Invoke_O_O__O(self, s__90000491__1 any) any { var tmp1 any = A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_A_New_O_O_O(s__90000491__1, t.F_ctx, self); var tmp2 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_272, false); A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_A_fn_class = fncls__125d; tmp2 = fncls__125d } else { tmp2 = fncls__125 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1276:1
func A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_A_New_O_O_O(p0, p1, p2 any) *A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1276:1
func (t *A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_A) Ctor_O_O_O(c__s__90000491, c__ctx, c__iter__90000490 any) { t.F_s__90000491 = c__s__90000491; t.F_ctx = c__ctx; t.F_iter__90000490 = c__iter__90000490 }
//line :1276:1
func (t *A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_A) Invoke_O__O(self any) any { { var s__90000491__1 any; var t_ any = t.F_s__90000491; t.F_s__90000491 = nil; s__90000491__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(s__90000491__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__90000491__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(s__90000491__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(s__90000491__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__90000493__6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_401.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000496_A_New_O_O_I_O(t.F_ctx, b__90000493__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__122 *jrt.Class = A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000496_A_fn_class; if fncls__122 == nil { var fncls__122d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_273, false); A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000496_A_fn_class = fncls__122d; tmp2 = fncls__122d } else { tmp2 = fncls__122 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__90000490); return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000493__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__90000491__3))) } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000493__6), nil) } } else { var ev__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__90000491__3); var ev__5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()).Invoke_O__O(ev__4); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()); var tmp5 any; var G__90000501__6_ any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(ev__5)

L2: switch { default: switch lang.Util_Hash_O__I(G__90000501__6_) >> 5 & 7 { case 1: if lang.Util_Equiv_O_O__Z(G__90000501__6_, Lit_274) { var temp__1927000408__auto____7 any; var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_50.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(ev__5, lang.RT_IntCast_J__I(1)))




	if jrt.A2g_Truth(and__1927000168__auto____7) { temp__1927000408__auto____7 = lang.RT_Nth_O_I__O(ev__5, lang.RT_IntCast_J__I(1)) } else { temp__1927000408__auto____7 = and__1927000168__auto____7 }; if jrt.A2g_Truth(temp__1927000408__auto____7) { var n__8 any = temp__1927000408__auto____7
		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_211.GetRawRoot__O()).Invoke_O_O__O(jrt.Class_ForName_String__Class(jrt.String_Cast(lang.IFn_Cast(A_arbace_aot_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(n__8))).Ref(), t.F_ctx)) {
			tmp5 = lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_275, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__8)).Ref()) } else {
//line :1284:1
				tmp5 = nil } } else {
//line :1283:1
					tmp5 = nil }
//line :1278:1
	break L2 }; case 2: if lang.Util_Equiv_O_O__Z(G__90000501__6_, Lit_276) { var temp__1927000408__auto____7_2 any; var and__1927000168__auto____7_2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_50.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(ev__5, lang.RT_IntCast_J__I(1)))




		if jrt.A2g_Truth(and__1927000168__auto____7_2) { temp__1927000408__auto____7_2 = lang.RT_Nth_O_I__O(ev__5, lang.RT_IntCast_J__I(1)) } else { temp__1927000408__auto____7_2 = and__1927000168__auto____7_2 }; if jrt.A2g_Truth(temp__1927000408__auto____7_2) { var n__8_2 any = temp__1927000408__auto____7_2
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_211.GetRawRoot__O()).Invoke_O_O__O(jrt.Class_ForName_String__Class(jrt.String_Cast(lang.IFn_Cast(A_arbace_aot_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(n__8_2))).Ref(), t.F_ctx)) {
				tmp5 = lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_275, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__8_2)).Ref()) } else {
//line :1284:1
					tmp5 = nil } } else {
//line :1283:1
						tmp5 = nil }
//line :1278:1
		break L2 }; case 3: if lang.Util_Equiv_O_O__Z(G__90000501__6_, Lit_277) {










			var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp7 any = A_arbace_aot_emit_A_const_722; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp9 any = A_arbace_aot_emit_A_const_723; var tmp10 any = A_arbace_aot_emit_A_const_724; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp12 any = A_arbace_aot_emit_A_const_725; var tmp13 any = tmp8.Invoke_O_O_O__O(tmp9, tmp10, tmp11.Invoke_O_O__O(tmp12, lang.IFn_Cast(A_arbace_aot_emit_A_const_212.GetRawRoot__O()).Invoke_O_O_O__O(t.F_ctx, A_arbace_aot_emit_A_const_726, A_arbace_aot_emit_A_const_727))); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp15 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_728, A_arbace_aot_emit_A_const_739); var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_248.GetRawRoot__O()); var tmp17 any = t.F_ctx; var tmp18 any = tmp16.Invoke_O_O__O(tmp17, lang.RT_Nth_O_I__O(ev__5, lang.RT_IntCast_J__I(2))); var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp20 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_730, A_arbace_aot_emit_A_const_740); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp22 any = A_arbace_aot_emit_A_const_732; var tmp23 any = A_arbace_aot_emit_A_const_733; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_43.GetRawRoot__O()); var tmp25 any = A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000502_A_New_O(t.F_ctx); var tmp26 *jrt.Class
			var fncls__124 /*line :1289:1*/*jrt.Class = A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000502_A_fn_class




			if fncls__124 == nil { var fncls__124d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_278, false); A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000502_A_fn_class = fncls__124d; tmp26 = fncls__124d } else { tmp26 = fncls__124 }
//line :1289:1
			tmp5 = tmp6.Invoke_O_O_O__O(tmp7, tmp13, tmp14.Invoke_O_O_O__O(tmp15, tmp18, tmp19.Invoke_O_O__O(tmp20, tmp21.Invoke_O_O_O__O(tmp22, tmp23, tmp24.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil), lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(ev__5, lang.RT_IntCast_J__I(3))))))))
//line :1278:1
			break L2 }; case 4: if lang.Util_Equiv_O_O__Z(G__90000501__6_, Lit_279) { var temp__1927000408__auto____7_3 any; var and__1927000168__auto____7_3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_50.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(ev__5, lang.RT_IntCast_J__I(1)))




				if jrt.A2g_Truth(and__1927000168__auto____7_3) { temp__1927000408__auto____7_3 = lang.RT_Nth_O_I__O(ev__5, lang.RT_IntCast_J__I(1)) } else { temp__1927000408__auto____7_3 = and__1927000168__auto____7_3 }; if jrt.A2g_Truth(temp__1927000408__auto____7_3) { var n__8_3 any = temp__1927000408__auto____7_3
					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_211.GetRawRoot__O()).Invoke_O_O__O(jrt.Class_ForName_String__Class(jrt.String_Cast(lang.IFn_Cast(A_arbace_aot_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(n__8_3))).Ref(), t.F_ctx)) {
						tmp5 = lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_275, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__8_3)).Ref()) } else {
//line :1284:1
							tmp5 = nil } } else {
//line :1283:1
								tmp5 = nil }
//line :1278:1
				break L2 }; case 5: if lang.Util_Equiv_O_O__Z(G__90000501__6_, Lit_280) { var temp__1927000408__auto____7_4 any; var and__1927000168__auto____7_4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_50.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(ev__5, lang.RT_IntCast_J__I(1)))




					if jrt.A2g_Truth(and__1927000168__auto____7_4) { temp__1927000408__auto____7_4 = lang.RT_Nth_O_I__O(ev__5, lang.RT_IntCast_J__I(1)) } else { temp__1927000408__auto____7_4 = and__1927000168__auto____7_4 }; if jrt.A2g_Truth(temp__1927000408__auto____7_4) { var n__8_4 any = temp__1927000408__auto____7_4
						if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_211.GetRawRoot__O()).Invoke_O_O__O(jrt.Class_ForName_String__Class(jrt.String_Cast(lang.IFn_Cast(A_arbace_aot_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(n__8_4))).Ref(), t.F_ctx)) {
							tmp5 = lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_275, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__8_4)).Ref()) } else {
//line :1284:1
								tmp5 = nil } } else {
//line :1283:1
									tmp5 = nil }
//line :1278:1
					break L2 }; case 6: if lang.Util_Equiv_O_O__Z(G__90000501__6_, Lit_281) {
						var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp28 any = A_arbace_aot_emit_A_const_734; var tmp29 any = A_arbace_aot_emit_A_const_735; var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp31 any = A_arbace_aot_emit_A_const_736; var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp33 any = A_arbace_aot_emit_A_const_737; var tmp34 any = A_arbace_aot_emit_A_const_738; var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_248.GetRawRoot__O()); var tmp36 any = t.F_ctx; tmp5 = tmp27.Invoke_O_O_O__O(tmp28, tmp29, tmp30.Invoke_O_O__O(tmp31, tmp32.Invoke_O_O_O__O(tmp33, tmp34, tmp35.Invoke_O_O__O(tmp36, lang.RT_Nth_O_I__O(ev__5, lang.RT_IntCast_J__I(2))))))
//line :1278:1
						break L2 }; default:
}















	tmp5 = lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_282, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(ev__5))).Ref())}
//line :1276:1
	var tmp37 lang.IFn = lang.IFn_Cast(t.F_iter__90000490); return tmp4.Invoke_O_O__O(tmp5, tmp37.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(s__90000491__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :1276:1
func A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000496_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000496_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000496_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :1276:1
func (t *A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000496_A) Ctor_O_O_I_O(c__ctx, c__b__90000493 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_ctx = c__ctx; t.F_b__90000493 = c__b__90000493; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1276:1
func (t *A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000496_A) Invoke_O__O(self any) any { { var i__90000492__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__90000492__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var ev__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__90000492__1)); var ev__3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()).Invoke_O__O(ev__2); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_402.GetRawRoot__O()); var tmp3 any = t.F_b__90000493; var tmp4 any; var G__90000497__4_ any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(ev__3)

L2: switch { default: switch lang.Util_Hash_O__I(G__90000497__4_) >> 5 & 7 { case 1: if lang.Util_Equiv_O_O__Z(G__90000497__4_, Lit_274) { var temp__1927000408__auto____5 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_50.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(ev__3, lang.RT_IntCast_J__I(1)))




	if jrt.A2g_Truth(and__1927000168__auto____5) { temp__1927000408__auto____5 = lang.RT_Nth_O_I__O(ev__3, lang.RT_IntCast_J__I(1)) } else { temp__1927000408__auto____5 = and__1927000168__auto____5 }; if jrt.A2g_Truth(temp__1927000408__auto____5) { var n__6 any = temp__1927000408__auto____5
		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_211.GetRawRoot__O()).Invoke_O_O__O(jrt.Class_ForName_String__Class(jrt.String_Cast(lang.IFn_Cast(A_arbace_aot_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(n__6))).Ref(), t.F_ctx)) {
			tmp4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_275, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__6)).Ref()) } else {
//line :1284:1
				tmp4 = nil } } else {
//line :1283:1
					tmp4 = nil }
//line :1278:1
	break L2 }; case 2: if lang.Util_Equiv_O_O__Z(G__90000497__4_, Lit_276) { var temp__1927000408__auto____5_2 any; var and__1927000168__auto____5_2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_50.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(ev__3, lang.RT_IntCast_J__I(1)))




		if jrt.A2g_Truth(and__1927000168__auto____5_2) { temp__1927000408__auto____5_2 = lang.RT_Nth_O_I__O(ev__3, lang.RT_IntCast_J__I(1)) } else { temp__1927000408__auto____5_2 = and__1927000168__auto____5_2 }; if jrt.A2g_Truth(temp__1927000408__auto____5_2) { var n__6_2 any = temp__1927000408__auto____5_2
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_211.GetRawRoot__O()).Invoke_O_O__O(jrt.Class_ForName_String__Class(jrt.String_Cast(lang.IFn_Cast(A_arbace_aot_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(n__6_2))).Ref(), t.F_ctx)) {
				tmp4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_275, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__6_2)).Ref()) } else {
//line :1284:1
					tmp4 = nil } } else {
//line :1283:1
						tmp4 = nil }
//line :1278:1
		break L2 }; case 3: if lang.Util_Equiv_O_O__Z(G__90000497__4_, Lit_277) {










			var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp6 any = A_arbace_aot_emit_A_const_722; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp8 any = A_arbace_aot_emit_A_const_723; var tmp9 any = A_arbace_aot_emit_A_const_724; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp11 any = A_arbace_aot_emit_A_const_725; var tmp12 any = tmp7.Invoke_O_O_O__O(tmp8, tmp9, tmp10.Invoke_O_O__O(tmp11, lang.IFn_Cast(A_arbace_aot_emit_A_const_212.GetRawRoot__O()).Invoke_O_O_O__O(t.F_ctx, A_arbace_aot_emit_A_const_726, A_arbace_aot_emit_A_const_727))); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp14 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_728, A_arbace_aot_emit_A_const_729); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_248.GetRawRoot__O()); var tmp16 any = t.F_ctx; var tmp17 any = tmp15.Invoke_O_O__O(tmp16, lang.RT_Nth_O_I__O(ev__3, lang.RT_IntCast_J__I(2))); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp19 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_730, A_arbace_aot_emit_A_const_731); var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp21 any = A_arbace_aot_emit_A_const_732; var tmp22 any = A_arbace_aot_emit_A_const_733; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_43.GetRawRoot__O()); var tmp24 any = A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000496_fn__90000498_A_New_O(t.F_ctx); var tmp25 *jrt.Class
			var fncls__121 /*line :1289:1*/*jrt.Class = A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000496_fn__90000498_A_fn_class




			if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_283, false); A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000496_fn__90000498_A_fn_class = fncls__121d; tmp25 = fncls__121d } else { tmp25 = fncls__121 }
//line :1289:1
			tmp4 = tmp5.Invoke_O_O_O__O(tmp6, tmp12, tmp13.Invoke_O_O_O__O(tmp14, tmp17, tmp18.Invoke_O_O__O(tmp19, tmp20.Invoke_O_O_O__O(tmp21, tmp22, tmp23.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil), lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(ev__3, lang.RT_IntCast_J__I(3))))))))
//line :1278:1
			break L2 }; case 4: if lang.Util_Equiv_O_O__Z(G__90000497__4_, Lit_279) { var temp__1927000408__auto____5_3 any; var and__1927000168__auto____5_3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_50.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(ev__3, lang.RT_IntCast_J__I(1)))




				if jrt.A2g_Truth(and__1927000168__auto____5_3) { temp__1927000408__auto____5_3 = lang.RT_Nth_O_I__O(ev__3, lang.RT_IntCast_J__I(1)) } else { temp__1927000408__auto____5_3 = and__1927000168__auto____5_3 }; if jrt.A2g_Truth(temp__1927000408__auto____5_3) { var n__6_3 any = temp__1927000408__auto____5_3
					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_211.GetRawRoot__O()).Invoke_O_O__O(jrt.Class_ForName_String__Class(jrt.String_Cast(lang.IFn_Cast(A_arbace_aot_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(n__6_3))).Ref(), t.F_ctx)) {
						tmp4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_275, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__6_3)).Ref()) } else {
//line :1284:1
							tmp4 = nil } } else {
//line :1283:1
								tmp4 = nil }
//line :1278:1
				break L2 }; case 5: if lang.Util_Equiv_O_O__Z(G__90000497__4_, Lit_280) { var temp__1927000408__auto____5_4 any; var and__1927000168__auto____5_4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_50.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(ev__3, lang.RT_IntCast_J__I(1)))




					if jrt.A2g_Truth(and__1927000168__auto____5_4) { temp__1927000408__auto____5_4 = lang.RT_Nth_O_I__O(ev__3, lang.RT_IntCast_J__I(1)) } else { temp__1927000408__auto____5_4 = and__1927000168__auto____5_4 }; if jrt.A2g_Truth(temp__1927000408__auto____5_4) { var n__6_4 any = temp__1927000408__auto____5_4
						if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_211.GetRawRoot__O()).Invoke_O_O__O(jrt.Class_ForName_String__Class(jrt.String_Cast(lang.IFn_Cast(A_arbace_aot_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(n__6_4))).Ref(), t.F_ctx)) {
							tmp4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_275, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__6_4)).Ref()) } else {
//line :1284:1
								tmp4 = nil } } else {
//line :1283:1
									tmp4 = nil }
//line :1278:1
					break L2 }; case 6: if lang.Util_Equiv_O_O__Z(G__90000497__4_, Lit_281) {
						var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp27 any = A_arbace_aot_emit_A_const_734; var tmp28 any = A_arbace_aot_emit_A_const_735; var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp30 any = A_arbace_aot_emit_A_const_736; var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp32 any = A_arbace_aot_emit_A_const_737; var tmp33 any = A_arbace_aot_emit_A_const_738; var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_248.GetRawRoot__O()); var tmp35 any = t.F_ctx; tmp4 = tmp26.Invoke_O_O_O__O(tmp27, tmp28, tmp29.Invoke_O_O__O(tmp30, tmp31.Invoke_O_O_O__O(tmp32, tmp33, tmp34.Invoke_O_O__O(tmp35, lang.RT_Nth_O_I__O(ev__3, lang.RT_IntCast_J__I(2))))))
//line :1278:1
						break L2 }; default:
}















	tmp4 = lang.IFn_Cast(A_arbace_aot_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_282, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(ev__3))).Ref())}
//line :1276:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__90000492__1 = lang.Numbers_Unchecked_inc_J__J(i__90000492__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

















func A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000496_fn__90000498_A_New_O(p0 any) *A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000496_fn__90000498_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000496_fn__90000498_A{}; t.Ctor_O(p0); return t }
//line :1294:1
func (t *A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000496_fn__90000498_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :1294:1
func (t *A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000496_fn__90000498_A) Invoke_O_O__O(self, p1__90000485_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_aot_emit_A_const_248.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, p1__90000485_SHARP___1) }
//line :1294:1
func A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000502_A_New_O(p0 any) *A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000502_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000502_A{}; t.Ctor_O(p0); return t }
//line :1294:1
func (t *A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000502_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :1294:1
func (t *A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000502_A) Invoke_O_O__O(self, p1__90000485_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_aot_emit_A_const_248.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, p1__90000485_SHARP___1) }


















func A_arbace_aot_emit_unit_ns_A_New() *A_arbace_aot_emit_unit_ns_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_unit_ns_A{}; t.Ctor(); return t }
//line :1313:1
func (t *A_arbace_aot_emit_unit_ns_A) Ctor() {}
//line :1313:1
func (t *A_arbace_aot_emit_unit_ns_A) Invoke_O_O__O(self, p__90000507__0 any) any { var vec__90000508__2 any = p__90000507__0; var kind__3 any = lang.RT_Nth_O_I_O__O(vec__90000508__2, lang.RT_IntCast_J__I(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O(vec__90000508__2, lang.RT_IntCast_J__I(1), nil); var ___5 any = lang.RT_Nth_O_I_O__O(vec__90000508__2, lang.RT_IntCast_J__I(2), nil); var ___6 any = lang.RT_Nth_O_I_O__O(vec__90000508__2, lang.RT_IntCast_J__I(3), nil); var ___7 any = lang.RT_Nth_O_I_O__O(vec__90000508__2, lang.RT_IntCast_J__I(4), nil); var expr__8 any = lang.RT_Nth_O_I_O__O(vec__90000508__2, lang.RT_IntCast_J__I(5), nil); var n__9 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_224.GetRawRoot__O()).Invoke_O__O(expr__8); _ = ___4; _ = ___5; _ = ___6; _ = ___7; if



	lang.Util_Equiv_O_J__Z(kind__3, 1) { var nm__10 any = A_arbace_aot_emit_A_const_34.Invoke_O__O(n__9); var i__11 int32 = jrt.NN(jrt.String_Cast(nm__10)).IndexOf_String__I(Lit_17); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_747.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()); var tmp3 any


		if lang.Numbers_IsNeg_J__Z(int64(i__11)) { tmp3 = nm__10 } else { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_A_const_31; tmp3 = tmp4.Invoke_O_O_O__O(nm__10, tmp5, jrt.Integer_ValueOf_I__Integer(i__11).Ref()) }; return tmp1.Invoke_O__O(tmp2.Invoke_O__O(lang.Compiler_Demunge_String__String(jrt.String_Cast(tmp3)).Ref())) } else {
//line :1317:1
			if lang.Util_Equiv_O_O__Z(Lit_40, A_arbace_aot_emit_A_const_369.Invoke_O__O(n__9)) {



				return lang.Var_Cast(A_arbace_aot_emit_A_const_140.Invoke_O__O(n__9)).F_ns.Ref() } else {
//line :1317:1
					if A_arbace_aot_emit_A_const_60 != nil { return nil } else { return nil } } } }






func A_arbace_aot_emit_emit_source_A_New() *A_arbace_aot_emit_emit_source_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_source_A{}; t.Ctor(); return t }
//line :1324:1
func (t *A_arbace_aot_emit_emit_source_A) Ctor() {}
//line :1324:1
func (t *A_arbace_aot_emit_emit_source_A) Invoke_O_O_O_O_O_O_O__O(self, classes__0, runtime_classes__1, fn_names__2, pools__3, src__4, units__5 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_aot_emit_A_const_31; var base__7 any = tmp1.Invoke_O_O_O__O(src__4, tmp2, jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.String_Cast(src__4)).LastIndexOf_String__I(Lit_34)).Ref()); var lname__8 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_173), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_aot_emit_A_const_300.GetRawRoot__O()).Invoke_O_O_O__O(base__7, Lit_35, Lit_34), nil)).Ref(); var cls__9 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_604.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_aot_emit_A_const_32, pools__3)), lname__8); var file__10 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_17.GetRawRoot__O()).Invoke_O_O__O(src__4, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(jrt.NN(jrt.String_Cast(src__4)).LastIndexOf_String__I(Lit_35)))).Ref()); var ctx__11 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_aot_emit_A_const_302, classes__0, A_arbace_aot_emit_A_const_29, runtime_classes__1, A_arbace_aot_emit_A_const_38, cls__9, A_arbace_aot_emit_A_const_667, fn_names__2, A_arbace_aot_emit_A_const_32, pools__3, A_arbace_aot_emit_A_const_666, file__10)); var ms__12 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_192.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_emit_source_fn__90000513_A_New_O(ctx__11); var tmp6 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_aot_emit_emit_source_fn__90000513_A_fn_class; if











	fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_174, false); A_arbace_aot_emit_emit_source_fn__90000513_A_fn_class = fncls__127d; tmp6 = fncls__127d } else { tmp6 = fncls__127 }; ms__12 = tmp3.Invoke_O__O(tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), units__5)); var tmp7 any = A_arbace_aot_emit_A_const_34; var tmp8 any = A_arbace_aot_emit_A_const_748; var tmp9 lang.IFn = /*line :1324:1*/lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp11 any = A_arbace_aot_emit_A_const_752; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()); var tmp13 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lname__8); var tmp14 any = A_arbace_aot_emit_A_const_753; var tmp15 *jrt.Boolean; jrt.Boolean_Init(); tmp15 = jrt.Boolean_TRUE; var tmp16 any = tmp15.Ref(); var tmp17 any = A_arbace_aot_emit_A_const_754; var tmp18 *jrt.Boolean; jrt.Boolean_Init(); tmp18 = jrt.Boolean_TRUE; var tmp19 any = tmp10.Invoke_O_O__O(tmp11, tmp12.Invoke_O_O__O(tmp13, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp16, tmp17, tmp18.Ref(), A_arbace_aot_emit_A_const_755, file__10)))); var tmp20 *lang.Keyword = A_arbace_aot_emit_A_const_35; var tmp21 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_751.GetRawRoot__O()).Invoke_O__O(tmp20.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(cls__9))); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp23 any = A_arbace_aot_emit_A_const_756; var tmp24 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_aot_emit_A_const_757, A_arbace_aot_emit_A_const_758); var tmp25 *lang.PersistentVector; lang.PersistentVector_Init(); tmp25 = lang.PersistentVector_EMPTY; var tmp26 any = tmp25.Ref(); var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()); var tmp28 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_760); var tmp29 any; var iter__1927001039__auto____13 any; var tmp30 any = A_arbace_aot_emit_emit_source_iter__90000518__90000522_A_New_O(lname__8); var tmp31 *jrt.Class; var fncls__130 *jrt.Class = A_arbace_aot_emit_emit_source_iter__90000518__90000522_A_fn_class; if






















	fncls__130 == nil { var fncls__130d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_175, false); A_arbace_aot_emit_emit_source_iter__90000518__90000522_A_fn_class = fncls__130d; tmp31 = fncls__130d } else { tmp31 = fncls__130 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp30, tmp31, nil); tmp29 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_761.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(ms__12)).Ref())); return /*line :1324:1*/ lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, lname__8, tmp8, tmp9.Invoke_O_O_O_O__O(tmp19, tmp21, ms__12, lang.Tuple_Create_O__IPersistentVector(tmp22.Invoke_O_O_O_O__O(tmp23, tmp24, tmp26, tmp27.Invoke_O_O_O__O(tmp28, tmp29, A_arbace_aot_emit_A_const_759)))))) }











func A_arbace_aot_emit_emit_source_fn__90000513_A_New_O(p0 any) *A_arbace_aot_emit_emit_source_fn__90000513_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_source_fn__90000513_A{}; t.Ctor_O(p0); return t }
//line :1336:1
func (t *A_arbace_aot_emit_emit_source_fn__90000513_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :1336:1
func (t *A_arbace_aot_emit_emit_source_fn__90000513_A) Invoke_O_O_O__O(self, k__1, p__90000512__2 any) any { var vec__90000514__3 any = p__90000512__2; var u__4 any = lang.RT_Nth_O_I_O__O(vec__90000514__3, lang.RT_IntCast_J__I(0), nil); var um__5 any = lang.RT_Nth_O_I_O__O(vec__90000514__3, lang.RT_IntCast_J__I(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_120.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_121.GetRawRoot__O()); var tmp3 any = A_arbace_aot_emit_A_const_597; var tmp4 any; var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_749.GetRawRoot__O()).Invoke_O__O(u__4); if


	jrt.A2g_Truth(or__1927000174__auto____6) { tmp4 = or__1927000174__auto____6 } else { tmp4 = A_arbace_aot_emit_A_const_597.Get__O() }; tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, tmp4)); var tmp5 any; tmp6 := /*line :1336:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



		tmp5 = lang.IFn_Cast(A_arbace_aot_emit_A_const_571.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_750.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_13.GetRawRoot__O()).Invoke_O_O_O__O(t.F_ctx, A_arbace_aot_emit_A_const_229, um__5), k__1, u__4))
//line :1336:1
		return nil }();


	lang.IFn_Cast(A_arbace_aot_emit_A_const_62.GetRawRoot__O()).Invoke__O(); if /*line :1336:1*/ tmp6 != nil { panic(tmp6) }; return tmp5 }










func A_arbace_aot_emit_emit_source_iter__90000518__90000522_A_New_O(p0 any) *A_arbace_aot_emit_emit_source_iter__90000518__90000522_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_source_iter__90000518__90000522_A{}; t.Ctor_O(p0); return t }
//line :1347:1
func (t *A_arbace_aot_emit_emit_source_iter__90000518__90000522_A) Ctor_O(c__lname any) { t.F_lname = c__lname }
//line :1347:1
func (t *A_arbace_aot_emit_emit_source_iter__90000518__90000522_A) Invoke_O_O__O(self, s__90000519__1 any) any { var tmp1 any = A_arbace_aot_emit_emit_source_iter__90000518__90000522_fn__90000523_A_New_O_O_O(t.F_lname, s__90000519__1, self); var tmp2 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_aot_emit_emit_source_iter__90000518__90000522_fn__90000523_A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_176, false); A_arbace_aot_emit_emit_source_iter__90000518__90000522_fn__90000523_A_fn_class = fncls__129d; tmp2 = fncls__129d } else { tmp2 = fncls__129 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1347:1
func A_arbace_aot_emit_emit_source_iter__90000518__90000522_fn__90000523_A_New_O_O_O(p0, p1, p2 any) *A_arbace_aot_emit_emit_source_iter__90000518__90000522_fn__90000523_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_source_iter__90000518__90000522_fn__90000523_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1347:1
func (t *A_arbace_aot_emit_emit_source_iter__90000518__90000522_fn__90000523_A) Ctor_O_O_O(c__lname, c__s__90000519, c__iter__90000518 any) { t.F_lname = c__lname; t.F_s__90000519 = c__s__90000519; t.F_iter__90000518 = c__iter__90000518 }
//line :1347:1
func (t *A_arbace_aot_emit_emit_source_iter__90000518__90000522_fn__90000523_A) Invoke_O__O(self any) any { { var s__90000519__1 any; var t_ any = t.F_s__90000519; t.F_s__90000519 = nil; s__90000519__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(s__90000519__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__90000519__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(s__90000519__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(s__90000519__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__90000521__6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_401.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_aot_emit_emit_source_iter__90000518__90000522_fn__90000523_fn__90000524_A_New_O_O_I_O(t.F_lname, b__90000521__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__128 *jrt.Class = A_arbace_aot_emit_emit_source_iter__90000518__90000522_fn__90000523_fn__90000524_A_fn_class; if fncls__128 == nil { var fncls__128d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_177, false); A_arbace_aot_emit_emit_source_iter__90000518__90000522_fn__90000523_fn__90000524_A_fn_class = fncls__128d; tmp2 = fncls__128d } else { tmp2 = fncls__128 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__90000518); return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000521__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__90000519__3))) } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000521__6), nil) } } else { var k__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__90000519__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()); var tmp5 any = t.F_lname; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__90000518); return lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O_O__O(tmp5, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_178, nil), jrt.RefArrayOf(jrt.Object_class, nil, k__4)).Ref())), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(s__90000519__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :1347:1
func A_arbace_aot_emit_emit_source_iter__90000518__90000522_fn__90000523_fn__90000524_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_aot_emit_emit_source_iter__90000518__90000522_fn__90000523_fn__90000524_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_emit_source_iter__90000518__90000522_fn__90000523_fn__90000524_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :1347:1
func (t *A_arbace_aot_emit_emit_source_iter__90000518__90000522_fn__90000523_fn__90000524_A) Ctor_O_O_I_O(c__lname, c__b__90000521 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_lname = c__lname; t.F_b__90000521 = c__b__90000521; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1347:1
func (t *A_arbace_aot_emit_emit_source_iter__90000518__90000522_fn__90000523_fn__90000524_A) Invoke_O__O(self any) any { { var i__90000520__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__90000520__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var k__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__90000520__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_402.GetRawRoot__O()); var tmp3 any = t.F_b__90000521; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()); var tmp5 any = t.F_lname; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O_O__O(tmp5, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_178, nil), jrt.RefArrayOf(jrt.Object_class, nil, k__2)).Ref()))); i__90000520__1 = lang.Numbers_Unchecked_inc_J__J(i__90000520__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_aot_emit_class_form_A_New() *A_arbace_aot_emit_class_form_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_class_form_A{}; t.Ctor(); return t }
//line :1352:1
func (t *A_arbace_aot_emit_class_form_A) Ctor() {}
//line :1352:1
func (t *A_arbace_aot_emit_class_form_A) Invoke_O_O_O_O_O__O(self, c__0, children_of__1, top_QMARK___2, pools__3 any) any { var nm__5 any = A_arbace_aot_emit_A_const_34.Invoke_O__O(c__0); var nested__6 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()); var tmp2 any = A_arbace_aot_emit_class_form_fn__90000530_A_New_O_O(pools__3, children_of__1); var tmp3 *jrt.Class; var fncls__132 *jrt.Class = A_arbace_aot_emit_class_form_fn__90000530_A_fn_class; if






	fncls__132 == nil { var fncls__132d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_5, false); A_arbace_aot_emit_class_form_fn__90000530_A_fn_class = fncls__132d; tmp3 = fncls__132d } else { tmp3 = fncls__132 }; nested__6 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(children_of__1).Invoke_O__O(nm__5)); var mods__7 any; var tmp4 any = /*line :1352:1*/A_arbace_aot_emit_class_form_mods__90000532_A_New_O_O(c__0, top_QMARK___2); var tmp5 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_aot_emit_class_form_mods__90000532_A_fn_class; if









	fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_6, false); A_arbace_aot_emit_class_form_mods__90000532_A_fn_class = fncls__131d; tmp5 = fncls__131d } else { tmp5 = fncls__131 }; mods__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var head__8 any; if



	jrt.A2g_Truth(top_QMARK___2) { head__8 = lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(nm__5) } else { head__8 = lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_766.GetRawRoot__O()).Invoke_O__O(nm__5)) }; var ctx__9 any; var tmp6 any = A_arbace_aot_emit_A_const_38; var tmp7 lang.IFn = /*line :1352:1*/lang.IFn_Cast(A_arbace_aot_emit_A_const_33.GetRawRoot__O()); var tmp8 *lang.PersistentArrayMap; _ = ctx__9; lang.PersistentArrayMap_Init(); tmp8 = lang.PersistentArrayMap_EMPTY; var tmp9 any = tmp7.Invoke_O__O(tmp8.Ref()); var tmp10 any = A_arbace_aot_emit_A_const_29; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_33.GetRawRoot__O()); var tmp12 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp12 = lang.PersistentHashSet_EMPTY; ctx__9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp9, tmp10, tmp11.Invoke_O__O(tmp12.Ref()))); var consts__10 any; if















	jrt.A2g_Truth(top_QMARK___2) { var temp__1927000414__auto____10 any = lang.RT_Get_O_O__O(pools__3, nm__5); if jrt.A2g_Truth(temp__1927000414__auto____10) { var p__11 any = temp__1927000414__auto____10; var tmp13 *lang.Keyword = A_arbace_aot_emit_A_const_35; consts__10 = tmp13.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(p__11)) } else { consts__10 = nil } } else { consts__10 = nil }; var const_forms__11 any = /*line :1352:1*/lang.IFn_Cast(A_arbace_aot_emit_A_const_751.GetRawRoot__O()).Invoke_O__O(consts__10); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_22.GetRawRoot__O()); var tmp15 any; var G__90000535__12_ any = A_arbace_aot_emit_A_const_315.Invoke_O__O(c__0); L1:


















	switch { default: switch lang.Util_Hash_O__I(G__90000535__12_) >> 1 & 1 { case 0: if any(G__90000535__12_) == any(A_arbace_aot_emit_A_const_767) {
		var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp17 any = A_arbace_aot_emit_A_const_768; tmp15 = lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()).Invoke_O_O_O__O(tmp16.Invoke_O_O__O(tmp17, lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(head__8, lang.IFn_Cast(mods__7).Invoke_O__O(A_arbace_aot_emit_A_const_769))), const_forms__11, nested__6)
//line :1371:1
		break L1 }; case 1: if any(G__90000535__12_) == any(A_arbace_aot_emit_A_const_314) {

			var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()); var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp20 any = A_arbace_aot_emit_A_const_770; var tmp21 any = tmp19.Invoke_O_O__O(tmp20, lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(head__8, lang.IFn_Cast(mods__7).Invoke_O__O(A_arbace_aot_emit_A_const_771))); var tmp22 lang.IPersistentVector
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_772.Invoke_O__O(c__0))) { var tmp23 any = A_arbace_aot_emit_A_const_772; tmp22 = lang.Tuple_Create_O_O__IPersistentVector(tmp23, A_arbace_aot_emit_A_const_772.Invoke_O__O(c__0)) } else { tmp22 = nil }
//line :1373:1
			tmp15 = tmp18.Invoke_O_O_O_O__O(tmp21, tmp22, A_arbace_aot_emit_A_const_665.Invoke_O__O(c__0), nested__6)
//line :1371:1
			break L1 }; default:
	}




		var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_149.GetRawRoot__O()); var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp26 any = A_arbace_aot_emit_A_const_773; var tmp27 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(head__8, lang.IFn_Cast(mods__7).Invoke_O__O(A_arbace_aot_emit_A_const_774)); var tmp28 any = A_arbace_aot_emit_A_const_772; var tmp29 any = tmp25.Invoke_O_O_O_O__O(tmp26, tmp27, tmp28, A_arbace_aot_emit_A_const_661.Invoke_O__O(c__0)); var tmp30 lang.IPersistentVector

		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(A_arbace_aot_emit_A_const_663.Invoke_O__O(c__0))) { var tmp31 any = A_arbace_aot_emit_A_const_775; tmp30 = lang.Tuple_Create_O_O__IPersistentVector(tmp31, A_arbace_aot_emit_A_const_663.Invoke_O__O(c__0)) } else { tmp30 = nil }
//line :1377:1
		tmp15 = tmp24.Invoke_O_O_O_O_O__O(tmp29, tmp30, const_forms__11, A_arbace_aot_emit_A_const_665.Invoke_O__O(c__0), nested__6)}; var tmp32 any = tmp15; var tmp33 any = /*line :1370:1*/A_arbace_aot_emit_A_const_13.GetRawRoot__O(); var tmp34 any = A_arbace_aot_emit_A_const_255; return tmp14.Invoke_O_O_O_O__O(tmp32, tmp33, tmp34, A_arbace_aot_emit_A_const_254.Invoke_O__O(c__0)) }
//line :1359:1
func A_arbace_aot_emit_class_form_fn__90000530_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_class_form_fn__90000530_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_class_form_fn__90000530_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1359:1
func (t *A_arbace_aot_emit_class_form_fn__90000530_A) Ctor_O_O(c__pools, c__children_of any) { t.F_pools = c__pools; t.F_children_of = c__children_of }
//line :1359:1
func (t *A_arbace_aot_emit_class_form_fn__90000530_A) Invoke_O_O__O(self, p1__90000529_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_765.GetRawRoot__O()); var tmp2 any = t.F_children_of; var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_FALSE; return tmp1.Invoke_O_O_O_O__O(p1__90000529_SHARP___1, tmp2, tmp3.Ref(), t.F_pools) }


func A_arbace_aot_emit_class_form_mods__90000532_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_class_form_mods__90000532_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_class_form_mods__90000532_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1362:1
func (t *A_arbace_aot_emit_class_form_mods__90000532_A) Ctor_O_O(c__c, c__top_QMARK_ any) { t.F_c = c__c; t.F_top_QMARK_ = c__top_QMARK_ }
//line :1362:1
func (t *A_arbace_aot_emit_class_form_mods__90000532_A) Invoke_O_O__O(self, m__1 any) any { var G__90000533__2_ any; if jrt.A2g_Truth(t.F_top_QMARK_) { G__90000533__2_ = lang.IFn_Cast(A_arbace_aot_emit_A_const_762.GetRawRoot__O()).Invoke_O_O__O(m__1, A_arbace_aot_emit_A_const_763) } else { G__90000533__2_ = m__1 }; var G__90000533__3_ any; if jrt.A2g_Truth(A_arbace_aot_emit_A_const_666.Invoke_O__O(t.F_c)) {
												var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_13.GetRawRoot__O()); var tmp2 any = A_arbace_aot_emit_A_const_755; G__90000533__3_ = tmp1.Invoke_O_O_O__O(G__90000533__2_, tmp2, A_arbace_aot_emit_A_const_666.Invoke_O__O(t.F_c)) } else {
//line :1362:1
		G__90000533__3_ = G__90000533__2_ }; var tmp3 any = A_arbace_aot_emit_A_const_719; if lang.Util_Equiv_O_O__Z(tmp3, A_arbace_aot_emit_A_const_315.Invoke_O__O(t.F_c)) {


			var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_13.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_A_const_764; var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; return tmp4.Invoke_O_O_O__O(G__90000533__3_, tmp5, tmp6.Ref()) } else {
//line :1362:1
				return G__90000533__3_ } }






















func A_arbace_aot_emit_class_forms_A_New() *A_arbace_aot_emit_class_forms_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_class_forms_A{}; t.Ctor(); return t }
//line :1385:1
func (t *A_arbace_aot_emit_class_forms_A) Ctor() {}
//line :1385:1
func (t *A_arbace_aot_emit_class_forms_A) Invoke_O_O_O__O(self, classes__0, pools__1 any) any { var names__3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_450.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_406.GetRawRoot__O()).Invoke_O__O(classes__0)); var parent__4 any; var tmp1 any = A_arbace_aot_emit_class_forms_parent__90000537_A_New(); var tmp2 *jrt.Class; var fncls__134 *jrt.Class = A_arbace_aot_emit_class_forms_parent__90000537_A_fn_class; if





	fncls__134 == nil { var fncls__134d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_7, false); A_arbace_aot_emit_class_forms_parent__90000537_A_fn_class = fncls__134d; tmp2 = fncls__134d } else { tmp2 = fncls__134 }; parent__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var all__5 any; var tmp3 any = /*line :1385:1*/A_arbace_aot_emit_class_forms_fn__90000539_A_New_O_O(names__3, parent__4); var tmp4 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_aot_emit_class_forms_fn__90000539_A_fn_class; if






	fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_8, false); A_arbace_aot_emit_class_forms_fn__90000539_A_fn_class = fncls__135d; tmp4 = fncls__135d } else { tmp4 = fncls__135 }; all__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O(); var recs__6 any; var tmp5 lang.IFn = /*line :1385:1*/lang.IFn_Cast(A_arbace_aot_emit_A_const_190.GetRawRoot__O()); var tmp6 *lang.PersistentArrayMap;













	lang.PersistentArrayMap_Init(); tmp6 = lang.PersistentArrayMap_EMPTY; var tmp7 any = tmp6.Ref(); var tmp8 any; var iter__1927001039__auto____6 any; var tmp9 any = A_arbace_aot_emit_class_forms_iter__90000541__90000545_A_New_O(classes__0); var tmp10 *jrt.Class; var fncls__142 *jrt.Class = A_arbace_aot_emit_class_forms_iter__90000541__90000545_A_fn_class; if fncls__142 == nil { var fncls__142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_9, false); A_arbace_aot_emit_class_forms_iter__90000541__90000545_A_fn_class = fncls__142d; tmp10 = fncls__142d } else { tmp10 = fncls__142 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); tmp8 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(all__5); recs__6 = tmp5.Invoke_O_O__O(tmp7, tmp8); var kids__7 any; var tmp11 lang.IFn = /*line :1385:1*/lang.IFn_Cast(A_arbace_aot_emit_A_const_778.GetRawRoot__O()); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_779.GetRawRoot__O()); var tmp13 any = A_arbace_aot_emit_class_forms_fn__90000551_A_New_O(recs__6); var tmp14 *jrt.Class; var fncls__143 *jrt.Class = A_arbace_aot_emit_class_forms_fn__90000551_A_fn_class; if
















	fncls__143 == nil { var fncls__143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_10, false); A_arbace_aot_emit_class_forms_fn__90000551_A_fn_class = fncls__143d; tmp14 = fncls__143d } else { tmp14 = fncls__143 }; kids__7 = tmp11.Invoke_O_O__O(parent__4, tmp12.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil), all__5)); var children_of__8 any; var tmp15 any = /*line :1385:1*/A_arbace_aot_emit_class_forms_children_of__90000553_A_New_O_O(kids__7, recs__6); var tmp16 *jrt.Class; var fncls__136 *jrt.Class = A_arbace_aot_emit_class_forms_children_of__90000553_A_fn_class; if

















	fncls__136 == nil { var fncls__136d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_11, false); A_arbace_aot_emit_class_forms_children_of__90000553_A_fn_class = fncls__136d; tmp16 = fncls__136d } else { tmp16 = fncls__136 }; children_of__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); var iter__1927001039__auto____9 any; var tmp17 any = /*line :1385:1*/A_arbace_aot_emit_class_forms_iter__90000555__90000559_A_New_O_O_O(children_of__8, pools__1, recs__6); var tmp18 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_aot_emit_class_forms_iter__90000555__90000559_A_fn_class; if


















	fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_12, false); A_arbace_aot_emit_class_forms_iter__90000555__90000559_A_fn_class = fncls__139d; tmp18 = fncls__139d } else { tmp18 = fncls__139 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); return lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_780.GetRawRoot__O()).Invoke_O__O(lang.RT_Get_O_O__O(kids__7, nil))) }
//line :1391:1
func A_arbace_aot_emit_class_forms_parent__90000537_A_New() *A_arbace_aot_emit_class_forms_parent__90000537_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_class_forms_parent__90000537_A{}; t.Ctor(); return t }
//line :1391:1
func (t *A_arbace_aot_emit_class_forms_parent__90000537_A) Ctor() {}
//line :1391:1
func (t *A_arbace_aot_emit_class_forms_parent__90000537_A) Invoke_O_O__O(self, n__1 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__1)).LastIndexOf_String__I(Lit_17); if lang.Numbers_IsPos_J__Z(int64(i__2)) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_aot_emit_A_const_31; return tmp1.Invoke_O_O_O__O(n__1, tmp2, jrt.Integer_ValueOf_I__Integer(i__2).Ref()) } else { return nil } }
func A_arbace_aot_emit_class_forms_fn__90000539_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_class_forms_fn__90000539_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_class_forms_fn__90000539_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1392:1
func (t *A_arbace_aot_emit_class_forms_fn__90000539_A) Ctor_O_O(c__names, c__parent any) { t.F_names = c__names; t.F_parent = c__parent }
//line :1392:1
func (t *A_arbace_aot_emit_class_forms_fn__90000539_A) Invoke_O__O(self any) any { { var todo__1 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()).Invoke_O__O(t.F_names); var acc__2 any; var t_ any = t.F_names; t.F_names = nil; acc__2 = t_; L1: for { var temp__1927000408__auto____3 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_776.GetRawRoot__O()).Invoke_O__O(todo__1)
											if jrt.A2g_Truth(temp__1927000408__auto____3) { var n__4 any = temp__1927000408__auto____3; var p__5 any = lang.IFn_Cast(t.F_parent).Invoke_O__O(n__4); var tmp1 any
												var and__1927000168__auto____6 any = p__5
												if jrt.A2g_Truth(and__1927000168__auto____6) { tmp1 = lang.IFn_Cast(A_arbace_aot_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_28.GetRawRoot__O()).Invoke_O_O__O(acc__2, p__5)) } else { tmp1 = and__1927000168__auto____6 }; if jrt.A2g_Truth(tmp1) {
													todo__1, acc__2 = lang.IFn_Cast(A_arbace_aot_emit_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_777.GetRawRoot__O()).Invoke_O__O(todo__1), p__5), lang.IFn_Cast(A_arbace_aot_emit_A_const_8.GetRawRoot__O()).Invoke_O_O__O(acc__2, p__5); continue L1 } else {
														todo__1, acc__2 = lang.IFn_Cast(A_arbace_aot_emit_A_const_777.GetRawRoot__O()).Invoke_O__O(todo__1), acc__2; continue L1 } } else {
//line :1393:1
					return acc__2 } } }; /*line :1392:1*/panic("a2g: unreachable") }






func A_arbace_aot_emit_class_forms_iter__90000541__90000545_A_New_O(p0 any) *A_arbace_aot_emit_class_forms_iter__90000541__90000545_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_class_forms_iter__90000541__90000545_A{}; t.Ctor_O(p0); return t }
//line :1399:1
func (t *A_arbace_aot_emit_class_forms_iter__90000541__90000545_A) Ctor_O(c__classes any) { t.F_classes = c__classes }
//line :1399:1
func (t *A_arbace_aot_emit_class_forms_iter__90000541__90000545_A) Invoke_O_O__O(self, s__90000542__1 any) any { var tmp1 any = A_arbace_aot_emit_class_forms_iter__90000541__90000545_fn__90000546_A_New_O_O_O(t.F_classes, s__90000542__1, self); var tmp2 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_aot_emit_class_forms_iter__90000541__90000545_fn__90000546_A_fn_class; if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_13, false); A_arbace_aot_emit_class_forms_iter__90000541__90000545_fn__90000546_A_fn_class = fncls__141d; tmp2 = fncls__141d } else { tmp2 = fncls__141 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1399:1
func A_arbace_aot_emit_class_forms_iter__90000541__90000545_fn__90000546_A_New_O_O_O(p0, p1, p2 any) *A_arbace_aot_emit_class_forms_iter__90000541__90000545_fn__90000546_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_class_forms_iter__90000541__90000545_fn__90000546_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1399:1
func (t *A_arbace_aot_emit_class_forms_iter__90000541__90000545_fn__90000546_A) Ctor_O_O_O(c__classes, c__s__90000542, c__iter__90000541 any) { t.F_classes = c__classes; t.F_s__90000542 = c__s__90000542; t.F_iter__90000541 = c__iter__90000541 }
//line :1399:1
func (t *A_arbace_aot_emit_class_forms_iter__90000541__90000545_fn__90000546_A) Invoke_O__O(self any) any { { var s__90000542__1 any; var t_ any = t.F_s__90000542; t.F_s__90000542 = nil; s__90000542__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(s__90000542__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__90000542__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(s__90000542__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(s__90000542__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__90000544__6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_401.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_aot_emit_class_forms_iter__90000541__90000545_fn__90000546_fn__90000547_A_New_O_O_I_O(t.F_classes, b__90000544__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__140 *jrt.Class = A_arbace_aot_emit_class_forms_iter__90000541__90000545_fn__90000546_fn__90000547_A_fn_class; if fncls__140 == nil { var fncls__140d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_14, false); A_arbace_aot_emit_class_forms_iter__90000541__90000545_fn__90000546_fn__90000547_A_fn_class = fncls__140d; tmp2 = fncls__140d } else { tmp2 = fncls__140 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__90000541); return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000544__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__90000542__3))) } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000544__6), nil) } } else { var n__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__90000542__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()); var tmp5 any; var or__1927000174__auto____5 any = lang.RT_Get_O_O__O(t.F_classes, n__4); if jrt.A2g_Truth(or__1927000174__auto____5) { tmp5 = or__1927000174__auto____5 } else { tmp5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_aot_emit_A_const_34, n__4, A_arbace_aot_emit_A_const_315, A_arbace_aot_emit_A_const_767)) }; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__90000541); return tmp4.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(n__4, tmp5), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(s__90000542__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :1399:1
func A_arbace_aot_emit_class_forms_iter__90000541__90000545_fn__90000546_fn__90000547_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_aot_emit_class_forms_iter__90000541__90000545_fn__90000546_fn__90000547_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_class_forms_iter__90000541__90000545_fn__90000546_fn__90000547_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :1399:1
func (t *A_arbace_aot_emit_class_forms_iter__90000541__90000545_fn__90000546_fn__90000547_A) Ctor_O_O_I_O(c__classes, c__b__90000544 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_classes = c__classes; t.F_b__90000544 = c__b__90000544; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1399:1
func (t *A_arbace_aot_emit_class_forms_iter__90000541__90000545_fn__90000546_fn__90000547_A) Invoke_O__O(self any) any { { var i__90000543__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__90000543__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__90000543__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_402.GetRawRoot__O()); var tmp3 any = t.F_b__90000544; var tmp4 any; var or__1927000174__auto____3 any = lang.RT_Get_O_O__O(t.F_classes, n__2); if jrt.A2g_Truth(or__1927000174__auto____3) { tmp4 = or__1927000174__auto____3 } else { tmp4 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_aot_emit_A_const_34, n__2, A_arbace_aot_emit_A_const_315, A_arbace_aot_emit_A_const_767)) }; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(n__2, tmp4)); i__90000543__1 = lang.Numbers_Unchecked_inc_J__J(i__90000543__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_aot_emit_class_forms_fn__90000551_A_New_O(p0 any) *A_arbace_aot_emit_class_forms_fn__90000551_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_class_forms_fn__90000551_A{}; t.Ctor_O(p0); return t }
//line :1402:1
func (t *A_arbace_aot_emit_class_forms_fn__90000551_A) Ctor_O(c__recs any) { t.F_recs = c__recs }
//line :1402:1
func (t *A_arbace_aot_emit_class_forms_fn__90000551_A) Invoke_O_O__O(self, n__1 any) any { var tmp1 any; var tmp2 *lang.Keyword = A_arbace_aot_emit_A_const_254; var or__1927000174__auto____2 any = tmp2.Invoke_O__O(lang.IFn_Cast(t.F_recs).Invoke_O__O(n__1)); if jrt.A2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { tmp1 = A_arbace_aot_emit_A_const_31 }; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, n__1) }
func A_arbace_aot_emit_class_forms_children_of__90000553_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_class_forms_children_of__90000553_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_class_forms_children_of__90000553_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1403:1
func (t *A_arbace_aot_emit_class_forms_children_of__90000553_A) Ctor_O_O(c__kids, c__recs any) { t.F_kids = c__kids; t.F_recs = c__recs }
//line :1403:1
func (t *A_arbace_aot_emit_class_forms_children_of__90000553_A) Invoke_O_O__O(self, n__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_101.GetRawRoot__O()); var tmp2 any = t.F_recs; return tmp1.Invoke_O_O__O(tmp2, lang.RT_Get_O_O__O(t.F_kids, n__1)) }
func A_arbace_aot_emit_class_forms_iter__90000555__90000559_A_New_O_O_O(p0, p1, p2 any) *A_arbace_aot_emit_class_forms_iter__90000555__90000559_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_class_forms_iter__90000555__90000559_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1404:1
func (t *A_arbace_aot_emit_class_forms_iter__90000555__90000559_A) Ctor_O_O_O(c__children_of, c__pools, c__recs any) { t.F_children_of = c__children_of; t.F_pools = c__pools; t.F_recs = c__recs }
//line :1404:1
func (t *A_arbace_aot_emit_class_forms_iter__90000555__90000559_A) Invoke_O_O__O(self, s__90000556__1 any) any { var tmp1 any = A_arbace_aot_emit_class_forms_iter__90000555__90000559_fn__90000560_A_New_O_O_O_O_O(t.F_children_of, s__90000556__1, self, t.F_pools, t.F_recs); var tmp2 *jrt.Class; var fncls__138 *jrt.Class = A_arbace_aot_emit_class_forms_iter__90000555__90000559_fn__90000560_A_fn_class; if fncls__138 == nil { var fncls__138d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_15, false); A_arbace_aot_emit_class_forms_iter__90000555__90000559_fn__90000560_A_fn_class = fncls__138d; tmp2 = fncls__138d } else { tmp2 = fncls__138 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1404:1
func A_arbace_aot_emit_class_forms_iter__90000555__90000559_fn__90000560_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_aot_emit_class_forms_iter__90000555__90000559_fn__90000560_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_class_forms_iter__90000555__90000559_fn__90000560_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :1404:1
func (t *A_arbace_aot_emit_class_forms_iter__90000555__90000559_fn__90000560_A) Ctor_O_O_O_O_O(c__children_of, c__s__90000556, c__iter__90000555, c__pools, c__recs any) { t.F_children_of = c__children_of; t.F_s__90000556 = c__s__90000556; t.F_iter__90000555 = c__iter__90000555; t.F_pools = c__pools; t.F_recs = c__recs }
//line :1404:1
func (t *A_arbace_aot_emit_class_forms_iter__90000555__90000559_fn__90000560_A) Invoke_O__O(self any) any { { var s__90000556__1 any; var t_ any = t.F_s__90000556; t.F_s__90000556 = nil; s__90000556__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(s__90000556__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__90000556__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(s__90000556__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(s__90000556__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__90000558__6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_401.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_aot_emit_class_forms_iter__90000555__90000559_fn__90000560_fn__90000561_A_New_O_O_O_I_O_O(t.F_children_of, t.F_pools, b__90000558__6, size__1927001038__auto____5, t.F_recs, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__137 *jrt.Class = A_arbace_aot_emit_class_forms_iter__90000555__90000559_fn__90000560_fn__90000561_A_fn_class; if fncls__137 == nil { var fncls__137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_16, false); A_arbace_aot_emit_class_forms_iter__90000555__90000559_fn__90000560_fn__90000561_A_fn_class = fncls__137d; tmp2 = fncls__137d } else { tmp2 = fncls__137 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__90000555); return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000558__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__90000556__3))) } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000558__6), nil) } } else { var top__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__90000556__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_765.GetRawRoot__O()); var tmp6 any = lang.IFn_Cast(t.F_recs).Invoke_O__O(top__4); var tmp7 any = t.F_children_of; var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__90000555); return tmp4.Invoke_O_O__O(tmp5.Invoke_O_O_O_O__O(tmp6, tmp7, tmp8.Ref(), t.F_pools), tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(s__90000556__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :1404:1
func A_arbace_aot_emit_class_forms_iter__90000555__90000559_fn__90000560_fn__90000561_A_New_O_O_O_I_O_O(p0, p1, p2 any, p3 int32, p4, p5 any) *A_arbace_aot_emit_class_forms_iter__90000555__90000559_fn__90000560_fn__90000561_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_class_forms_iter__90000555__90000559_fn__90000560_fn__90000561_A{}; t.Ctor_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :1404:1
func (t *A_arbace_aot_emit_class_forms_iter__90000555__90000559_fn__90000560_fn__90000561_A) Ctor_O_O_O_I_O_O(c__children_of, c__pools, c__b__90000558 any, c__size__1927001038__auto__ int32, c__recs, c__c__1927001037__auto__ any) { t.F_children_of = c__children_of; t.F_pools = c__pools; t.F_b__90000558 = c__b__90000558; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_recs = c__recs; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1404:1
func (t *A_arbace_aot_emit_class_forms_iter__90000555__90000559_fn__90000560_fn__90000561_A) Invoke_O__O(self any) any { { var i__90000557__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__90000557__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var top__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__90000557__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_402.GetRawRoot__O()); var tmp3 any = t.F_b__90000558; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_765.GetRawRoot__O()); var tmp5 any = lang.IFn_Cast(t.F_recs).Invoke_O__O(top__2); var tmp6 any = t.F_children_of; var tmp7 *jrt.Boolean; jrt.Boolean_Init(); tmp7 = jrt.Boolean_TRUE; tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O_O__O(tmp5, tmp6, tmp7.Ref(), t.F_pools)); i__90000557__1 = lang.Numbers_Unchecked_inc_J__J(i__90000557__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_aot_emit_interface_record_A_New() *A_arbace_aot_emit_interface_record_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_interface_record_A{}; t.Ctor(); return t }
//line :1407:1
func (t *A_arbace_aot_emit_interface_record_A) Ctor() {}
//line :1407:1
func (t *A_arbace_aot_emit_interface_record_A) Invoke_O_O_O_O__O(self, name__0, extends__1, methods__2 any) any { var tmp1 any = A_arbace_aot_emit_A_const_34; var tmp2 any = A_arbace_aot_emit_A_const_315; var tmp3 any = A_arbace_aot_emit_A_const_314; var tmp4 any = A_arbace_aot_emit_A_const_772; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_43.GetRawRoot__O()); var tmp6 any = A_arbace_aot_emit_interface_record_fn__90000567_A_New(); var tmp7 *jrt.Class; var fncls__149 *jrt.Class = A_arbace_aot_emit_interface_record_fn__90000567_A_fn_class; if




	fncls__149 == nil { var fncls__149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_216, false); A_arbace_aot_emit_interface_record_fn__90000567_A_fn_class = fncls__149d; tmp7 = fncls__149d } else { tmp7 = fncls__149 }; var tmp8 any = /*line :1407:1*/tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), extends__1); var tmp9 any = A_arbace_aot_emit_A_const_665; var tmp10 any; var iter__1927001039__auto____4 any; var tmp11 any = A_arbace_aot_emit_interface_record_iter__90000569__90000573_A_New(); var tmp12 *jrt.Class; var fncls__148 *jrt.Class = A_arbace_aot_emit_interface_record_iter__90000569__90000573_A_fn_class; if





	fncls__148 == nil { var fncls__148d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_217, false); A_arbace_aot_emit_interface_record_iter__90000569__90000573_A_fn_class = fncls__148d; tmp12 = fncls__148d } else { tmp12 = fncls__148 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); tmp10 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(methods__2); return /*line :1407:1*/ lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, name__0, tmp2, tmp3, tmp4, tmp8, tmp9, tmp10)) }




func A_arbace_aot_emit_interface_record_fn__90000567_A_New() *A_arbace_aot_emit_interface_record_fn__90000567_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_interface_record_fn__90000567_A{}; t.Ctor(); return t }
//line :1412:1
func (t *A_arbace_aot_emit_interface_record_fn__90000567_A) Ctor() {}
//line :1412:1
func (t *A_arbace_aot_emit_interface_record_fn__90000567_A) Invoke_O_O__O(self, p1__90000566_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(p1__90000566_SHARP___1)).GetName__String().Ref())) }
func A_arbace_aot_emit_interface_record_iter__90000569__90000573_A_New() *A_arbace_aot_emit_interface_record_iter__90000569__90000573_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_interface_record_iter__90000569__90000573_A{}; t.Ctor(); return t }
//line :1413:1
func (t *A_arbace_aot_emit_interface_record_iter__90000569__90000573_A) Ctor() {}
//line :1413:1
func (t *A_arbace_aot_emit_interface_record_iter__90000569__90000573_A) Invoke_O_O__O(self, s__90000570__1 any) any { var tmp1 any = A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_A_New_O_O(s__90000570__1, self); var tmp2 *jrt.Class; var fncls__147 *jrt.Class = A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_A_fn_class; if fncls__147 == nil { var fncls__147d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_218, false); A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_A_fn_class = fncls__147d; tmp2 = fncls__147d } else { tmp2 = fncls__147 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1413:1
func A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_A_New_O_O(p0, p1 any) *A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1413:1
func (t *A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_A) Ctor_O_O(c__s__90000570, c__iter__90000569 any) { t.F_s__90000570 = c__s__90000570; t.F_iter__90000569 = c__iter__90000569 }
//line :1413:1
func (t *A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_A) Invoke_O__O(self any) any { { var s__90000570__1 any; var t_ any = t.F_s__90000570; t.F_s__90000570 = nil; s__90000570__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_113.GetRawRoot__O()).Invoke_O__O(s__90000570__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__90000570__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_aot_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(s__90000570__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_155.GetRawRoot__O()).Invoke_O__O(s__90000570__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__90000572__6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_401.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000575_A_New_O_I_O(b__90000572__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__145 *jrt.Class = A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000575_A_fn_class; if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_219, false); A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000575_A_fn_class = fncls__145d; tmp2 = fncls__145d } else { tmp2 = fncls__145 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__90000569); return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000572__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__90000570__3))) } else { return lang.IFn_Cast(A_arbace_aot_emit_A_const_404.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_405.GetRawRoot__O()).Invoke_O__O(b__90000572__6), nil) } } else { var vec__90000582__4 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__90000570__3); var mname__5 any = lang.RT_Nth_O_I_O__O(vec__90000582__4, lang.RT_IntCast_J__I(0), nil); var ps__6 any = lang.RT_Nth_O_I_O__O(vec__90000582__4, lang.RT_IntCast_J__I(1), nil); var ret__7 any = lang.RT_Nth_O_I_O__O(vec__90000582__4, lang.RT_IntCast_J__I(2), nil); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp6 any = A_arbace_aot_emit_A_const_781; var tmp7 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(mname__5), A_arbace_aot_emit_A_const_784); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()); var tmp11 any = A_arbace_aot_emit_A_const_783; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_192.GetRawRoot__O()); var tmp13 any = A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000585_A_New(); var tmp14 *jrt.Class
														var fncls__146 /*line :1413:1*/*jrt.Class = A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000585_A_fn_class

	if fncls__146 == nil { var fncls__146d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_220, false); A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000585_A_fn_class = fncls__146d; tmp14 = fncls__146d } else { tmp14 = fncls__146 }
//line :1413:1
	var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__90000569); return tmp4.Invoke_O_O__O(tmp5.Invoke_O_O_O__O(tmp6, tmp7, tmp8.Invoke_O_O__O(tmp9.Invoke_O__O(tmp10.Invoke_O_O__O(tmp11, tmp12.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil), ps__6))), ret__7)), tmp15.Invoke_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_286.GetRawRoot__O()).Invoke_O__O(s__90000570__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :1413:1
func A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000575_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000575_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000575_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :1413:1
func (t *A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000575_A) Ctor_O_I_O(c__b__90000572 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__90000572 = c__b__90000572; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1413:1
func (t *A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000575_A) Invoke_O__O(self any) any { { var i__90000571__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__90000571__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__90000576__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__90000571__1)); var mname__3 any = lang.RT_Nth_O_I_O__O(vec__90000576__2, lang.RT_IntCast_J__I(0), nil); var ps__4 any = lang.RT_Nth_O_I_O__O(vec__90000576__2, lang.RT_IntCast_J__I(1), nil); var ret__5 any = lang.RT_Nth_O_I_O__O(vec__90000576__2, lang.RT_IntCast_J__I(2), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_402.GetRawRoot__O()); var tmp3 any = t.F_b__90000572; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_40.GetRawRoot__O()); var tmp5 any = A_arbace_aot_emit_A_const_781; var tmp6 any = lang.IFn_Cast(A_arbace_aot_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(mname__3), A_arbace_aot_emit_A_const_782); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_104.GetRawRoot__O()); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_191.GetRawRoot__O()); var tmp10 any = A_arbace_aot_emit_A_const_783; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_aot_emit_A_const_192.GetRawRoot__O()); var tmp12 any = A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000575_fn__90000579_A_New(); var tmp13 *jrt.Class
																var fncls__144 /*line :1413:1*/*jrt.Class = A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000575_fn__90000579_A_fn_class

	if fncls__144 == nil { var fncls__144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_221, false); A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000575_fn__90000579_A_fn_class = fncls__144d; tmp13 = fncls__144d } else { tmp13 = fncls__144 }
//line :1413:1
	tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O__O(tmp5, tmp6, tmp7.Invoke_O_O__O(tmp8.Invoke_O__O(tmp9.Invoke_O_O__O(tmp10, tmp11.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), ps__4))), ret__5))); i__90000571__1 = lang.Numbers_Unchecked_inc_J__J(i__90000571__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000575_fn__90000579_A_New() *A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000575_fn__90000579_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000575_fn__90000579_A{}; t.Ctor(); return t }
//line :1415:1
func (t *A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000575_fn__90000579_A) Ctor() {}
//line :1415:1
func (t *A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000575_fn__90000579_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { return lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_222, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__1)).Ref()), p__2) }
//line :1415:1
func A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000585_A_New() *A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000585_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000585_A{}; t.Ctor(); return t }
//line :1415:1
func (t *A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000585_A) Ctor() {}
//line :1415:1
func (t *A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000585_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { return lang.IFn_Cast(A_arbace_aot_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_aot_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_222, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__1)).Ref()), p__2) }













































































































































































































































type A_arbace_aot_emit_A struct{ jrt.Object }

var A_arbace_aot_emit_A_const_pool *jrt.RefArray

var A_arbace_aot_emit_A_const_0 *lang.Var

var A_arbace_aot_emit_A_const_1 *lang.Var

var A_arbace_aot_emit_A_const_2 any

var A_arbace_aot_emit_A_const_3 any

var A_arbace_aot_emit_A_const_4 any

var A_arbace_aot_emit_A_const_5 any

var A_arbace_aot_emit_A_const_6 *lang.Var

var A_arbace_aot_emit_A_const_7 *lang.Var

var A_arbace_aot_emit_A_const_8 *lang.Var

var A_arbace_aot_emit_A_const_9 any

var A_arbace_aot_emit_A_const_10 *lang.Var

var A_arbace_aot_emit_A_const_11 *lang.Var

var A_arbace_aot_emit_A_const_12 *lang.Var

var A_arbace_aot_emit_A_const_13 *lang.Var

var A_arbace_aot_emit_A_const_14 *lang.Keyword

var A_arbace_aot_emit_A_const_15 *lang.Var

var A_arbace_aot_emit_A_const_16 *lang.Var

var A_arbace_aot_emit_A_const_17 *lang.Var

var A_arbace_aot_emit_A_const_18 *lang.Var

var A_arbace_aot_emit_A_const_19 *lang.Var

var A_arbace_aot_emit_A_const_20 *lang.Var

var A_arbace_aot_emit_A_const_21 *lang.Var

var A_arbace_aot_emit_A_const_22 *lang.Var

var A_arbace_aot_emit_A_const_23 *lang.Keyword

var A_arbace_aot_emit_A_const_24 *lang.Var

var A_arbace_aot_emit_A_const_25 *lang.Var

var A_arbace_aot_emit_A_const_26 *lang.Var

var A_arbace_aot_emit_A_const_27 *lang.Var

var A_arbace_aot_emit_A_const_28 *lang.Var

var A_arbace_aot_emit_A_const_29 *lang.Keyword

var A_arbace_aot_emit_A_const_30 *lang.Var

var A_arbace_aot_emit_A_const_31 any

var A_arbace_aot_emit_A_const_32 *lang.Keyword

var A_arbace_aot_emit_A_const_33 *lang.Var

var A_arbace_aot_emit_A_const_34 *lang.Keyword

var A_arbace_aot_emit_A_const_35 *lang.Keyword

var A_arbace_aot_emit_A_const_36 *lang.Keyword

var A_arbace_aot_emit_A_const_37 *lang.Keyword

var A_arbace_aot_emit_A_const_38 *lang.Keyword

var A_arbace_aot_emit_A_const_39 *lang.Var

var A_arbace_aot_emit_A_const_40 *lang.Var

var A_arbace_aot_emit_A_const_41 any

var A_arbace_aot_emit_A_const_42 any

var A_arbace_aot_emit_A_const_43 *lang.Var

var A_arbace_aot_emit_A_const_44 *lang.Var

var A_arbace_aot_emit_A_const_45 *lang.Var

var A_arbace_aot_emit_A_const_46 any

var A_arbace_aot_emit_A_const_47 any

var A_arbace_aot_emit_A_const_48 any

var A_arbace_aot_emit_A_const_49 any

var A_arbace_aot_emit_A_const_50 *lang.Var

var A_arbace_aot_emit_A_const_51 *lang.Var

var A_arbace_aot_emit_A_const_52 *lang.Var

var A_arbace_aot_emit_A_const_53 *lang.Var

var A_arbace_aot_emit_A_const_54 *lang.Var

var A_arbace_aot_emit_A_const_55 *lang.Var

var A_arbace_aot_emit_A_const_56 *lang.Var

var A_arbace_aot_emit_A_const_57 *lang.Var

var A_arbace_aot_emit_A_const_58 *lang.Var

var A_arbace_aot_emit_A_const_59 *lang.Var

var A_arbace_aot_emit_A_const_60 *lang.Keyword

var A_arbace_aot_emit_A_const_61 *lang.Var

var A_arbace_aot_emit_A_const_62 *lang.Var

var A_arbace_aot_emit_A_const_63 any

var A_arbace_aot_emit_A_const_64 any

var A_arbace_aot_emit_A_const_65 any

var A_arbace_aot_emit_A_const_66 any

var A_arbace_aot_emit_A_const_67 any

var A_arbace_aot_emit_A_const_68 any

var A_arbace_aot_emit_A_const_69 *lang.Var

var A_arbace_aot_emit_A_const_70 any

var A_arbace_aot_emit_A_const_71 *lang.Var

var A_arbace_aot_emit_A_const_72 *jrt.Class

var A_arbace_aot_emit_A_const_73 *jrt.Class

var A_arbace_aot_emit_A_const_74 *jrt.Class

var A_arbace_aot_emit_A_const_75 *jrt.Class

var A_arbace_aot_emit_A_const_76 *jrt.Class

var A_arbace_aot_emit_A_const_77 *jrt.Class

var A_arbace_aot_emit_A_const_78 *jrt.Class

var A_arbace_aot_emit_A_const_79 *jrt.Class

var A_arbace_aot_emit_A_const_80 any

var A_arbace_aot_emit_A_const_81 *lang.Var

var A_arbace_aot_emit_A_const_82 *lang.Var

var A_arbace_aot_emit_A_const_83 *lang.Var

var A_arbace_aot_emit_A_const_84 any

var A_arbace_aot_emit_A_const_85 any

var A_arbace_aot_emit_A_const_86 any

var A_arbace_aot_emit_A_const_87 any

var A_arbace_aot_emit_A_const_88 any

var A_arbace_aot_emit_A_const_89 any

var A_arbace_aot_emit_A_const_90 any

var A_arbace_aot_emit_A_const_91 any

var A_arbace_aot_emit_A_const_92 any

var A_arbace_aot_emit_A_const_93 any

var A_arbace_aot_emit_A_const_94 *lang.Var

var A_arbace_aot_emit_A_const_95 *lang.Var

var A_arbace_aot_emit_A_const_96 any

var A_arbace_aot_emit_A_const_97 any

var A_arbace_aot_emit_A_const_98 *lang.Var

var A_arbace_aot_emit_A_const_99 *lang.Var

var A_arbace_aot_emit_A_const_100 *lang.Var

var A_arbace_aot_emit_A_const_101 *lang.Var

var A_arbace_aot_emit_A_const_102 any

var A_arbace_aot_emit_A_const_103 *lang.Keyword

var A_arbace_aot_emit_A_const_104 *lang.Var

var A_arbace_aot_emit_A_const_105 *lang.Var

var A_arbace_aot_emit_A_const_106 any

var A_arbace_aot_emit_A_const_107 any

var A_arbace_aot_emit_A_const_108 any

var A_arbace_aot_emit_A_const_109 *lang.Var

var A_arbace_aot_emit_A_const_110 any

var A_arbace_aot_emit_A_const_111 any

var A_arbace_aot_emit_A_const_112 any

var A_arbace_aot_emit_A_const_113 *lang.Var

var A_arbace_aot_emit_A_const_114 any

var A_arbace_aot_emit_A_const_115 any

var A_arbace_aot_emit_A_const_116 any

var A_arbace_aot_emit_A_const_117 any

var A_arbace_aot_emit_A_const_118 any

var A_arbace_aot_emit_A_const_119 any

var A_arbace_aot_emit_A_const_120 *lang.Var

var A_arbace_aot_emit_A_const_121 *lang.Var

var A_arbace_aot_emit_A_const_122 *lang.Var

var A_arbace_aot_emit_A_const_123 any

var A_arbace_aot_emit_A_const_124 any

var A_arbace_aot_emit_A_const_125 any

var A_arbace_aot_emit_A_const_126 any

var A_arbace_aot_emit_A_const_127 any

var A_arbace_aot_emit_A_const_128 any

var A_arbace_aot_emit_A_const_129 any

var A_arbace_aot_emit_A_const_130 *lang.Keyword

var A_arbace_aot_emit_A_const_131 *lang.Keyword

var A_arbace_aot_emit_A_const_132 *lang.Keyword

var A_arbace_aot_emit_A_const_133 *lang.Keyword

var A_arbace_aot_emit_A_const_134 *lang.Keyword

var A_arbace_aot_emit_A_const_135 *lang.Keyword

var A_arbace_aot_emit_A_const_136 *lang.Keyword

var A_arbace_aot_emit_A_const_137 *lang.Keyword

var A_arbace_aot_emit_A_const_138 *lang.Keyword

var A_arbace_aot_emit_A_const_139 *lang.Keyword

var A_arbace_aot_emit_A_const_140 *lang.Keyword

var A_arbace_aot_emit_A_const_141 *lang.Keyword

var A_arbace_aot_emit_A_const_142 *lang.Keyword

var A_arbace_aot_emit_A_const_143 *lang.Keyword

var A_arbace_aot_emit_A_const_144 *lang.Keyword

var A_arbace_aot_emit_A_const_145 *lang.Keyword

var A_arbace_aot_emit_A_const_146 *lang.Keyword

var A_arbace_aot_emit_A_const_147 *lang.Keyword

var A_arbace_aot_emit_A_const_148 *lang.Var

var A_arbace_aot_emit_A_const_149 *lang.Var

var A_arbace_aot_emit_A_const_150 *lang.Var

var A_arbace_aot_emit_A_const_151 any

var A_arbace_aot_emit_A_const_152 *lang.Var

var A_arbace_aot_emit_A_const_153 any

var A_arbace_aot_emit_A_const_154 *lang.Var

var A_arbace_aot_emit_A_const_155 *lang.Var

var A_arbace_aot_emit_A_const_156 *lang.Var

var A_arbace_aot_emit_A_const_157 *lang.Var

var A_arbace_aot_emit_A_const_158 *lang.Var

var A_arbace_aot_emit_A_const_159 *lang.Var

var A_arbace_aot_emit_A_const_160 any

var A_arbace_aot_emit_A_const_161 *lang.Var

var A_arbace_aot_emit_A_const_162 any

var A_arbace_aot_emit_A_const_163 any

var A_arbace_aot_emit_A_const_164 any

var A_arbace_aot_emit_A_const_165 any

var A_arbace_aot_emit_A_const_166 any

var A_arbace_aot_emit_A_const_167 any

var A_arbace_aot_emit_A_const_168 any

var A_arbace_aot_emit_A_const_169 any

var A_arbace_aot_emit_A_const_170 any

var A_arbace_aot_emit_A_const_171 any

var A_arbace_aot_emit_A_const_172 any

var A_arbace_aot_emit_A_const_173 any

var A_arbace_aot_emit_A_const_174 any

var A_arbace_aot_emit_A_const_175 any

var A_arbace_aot_emit_A_const_176 any

var A_arbace_aot_emit_A_const_177 any

var A_arbace_aot_emit_A_const_178 any

var A_arbace_aot_emit_A_const_179 any

var A_arbace_aot_emit_A_const_180 any

var A_arbace_aot_emit_A_const_181 any

var A_arbace_aot_emit_A_const_182 any

var A_arbace_aot_emit_A_const_183 any

var A_arbace_aot_emit_A_const_184 any

var A_arbace_aot_emit_A_const_185 any

var A_arbace_aot_emit_A_const_186 any

var A_arbace_aot_emit_A_const_187 any

var A_arbace_aot_emit_A_const_188 *lang.Var

var A_arbace_aot_emit_A_const_189 *lang.Var

var A_arbace_aot_emit_A_const_190 *lang.Var

var A_arbace_aot_emit_A_const_191 *lang.Var

var A_arbace_aot_emit_A_const_192 *lang.Var

var A_arbace_aot_emit_A_const_193 any

var A_arbace_aot_emit_A_const_194 *lang.Var

var A_arbace_aot_emit_A_const_195 any

var A_arbace_aot_emit_A_const_196 any

var A_arbace_aot_emit_A_const_197 any

var A_arbace_aot_emit_A_const_198 any

var A_arbace_aot_emit_A_const_199 any

var A_arbace_aot_emit_A_const_200 any

var A_arbace_aot_emit_A_const_201 any

var A_arbace_aot_emit_A_const_202 any

var A_arbace_aot_emit_A_const_203 any

var A_arbace_aot_emit_A_const_204 any

var A_arbace_aot_emit_A_const_205 any

var A_arbace_aot_emit_A_const_206 any

var A_arbace_aot_emit_A_const_207 any

var A_arbace_aot_emit_A_const_208 any

var A_arbace_aot_emit_A_const_209 any

var A_arbace_aot_emit_A_const_210 any

var A_arbace_aot_emit_A_const_211 *lang.Var

var A_arbace_aot_emit_A_const_212 *lang.Var

var A_arbace_aot_emit_A_const_213 any

var A_arbace_aot_emit_A_const_214 any

var A_arbace_aot_emit_A_const_215 *lang.Var

var A_arbace_aot_emit_A_const_216 *lang.Keyword

var A_arbace_aot_emit_A_const_217 *lang.Var

var A_arbace_aot_emit_A_const_218 *lang.Var

var A_arbace_aot_emit_A_const_219 *lang.Keyword

var A_arbace_aot_emit_A_const_220 *lang.Keyword

var A_arbace_aot_emit_A_const_221 *lang.Var

var A_arbace_aot_emit_A_const_222 any

var A_arbace_aot_emit_A_const_223 *lang.Keyword

var A_arbace_aot_emit_A_const_224 *lang.Var

var A_arbace_aot_emit_A_const_225 *lang.Keyword

var A_arbace_aot_emit_A_const_226 any

var A_arbace_aot_emit_A_const_227 *lang.Var

var A_arbace_aot_emit_A_const_228 *jrt.Class

var A_arbace_aot_emit_A_const_229 *lang.Keyword

var A_arbace_aot_emit_A_const_230 any

var A_arbace_aot_emit_A_const_231 any

var A_arbace_aot_emit_A_const_232 any

var A_arbace_aot_emit_A_const_233 any

var A_arbace_aot_emit_A_const_234 any

var A_arbace_aot_emit_A_const_235 any

var A_arbace_aot_emit_A_const_236 any

var A_arbace_aot_emit_A_const_237 *lang.Var

var A_arbace_aot_emit_A_const_238 any

var A_arbace_aot_emit_A_const_239 *lang.Var

var A_arbace_aot_emit_A_const_240 *lang.Var

var A_arbace_aot_emit_A_const_241 *lang.Var

var A_arbace_aot_emit_A_const_242 *lang.Var

var A_arbace_aot_emit_A_const_243 any

var A_arbace_aot_emit_A_const_244 any

var A_arbace_aot_emit_A_const_245 any

var A_arbace_aot_emit_A_const_246 any

var A_arbace_aot_emit_A_const_247 any

var A_arbace_aot_emit_A_const_248 *lang.Var

var A_arbace_aot_emit_A_const_249 any

var A_arbace_aot_emit_A_const_250 any

var A_arbace_aot_emit_A_const_251 any

var A_arbace_aot_emit_A_const_252 any

var A_arbace_aot_emit_A_const_253 any

var A_arbace_aot_emit_A_const_254 *lang.Keyword

var A_arbace_aot_emit_A_const_255 *lang.Keyword

var A_arbace_aot_emit_A_const_256 *lang.Keyword

var A_arbace_aot_emit_A_const_257 *lang.Var

var A_arbace_aot_emit_A_const_258 *lang.Var

var A_arbace_aot_emit_A_const_259 *lang.Keyword

var A_arbace_aot_emit_A_const_260 *lang.Keyword

var A_arbace_aot_emit_A_const_261 *lang.Keyword

var A_arbace_aot_emit_A_const_262 *lang.Keyword

var A_arbace_aot_emit_A_const_263 any

var A_arbace_aot_emit_A_const_264 *lang.Var

var A_arbace_aot_emit_A_const_265 *lang.Keyword

var A_arbace_aot_emit_A_const_266 any

var A_arbace_aot_emit_A_const_267 any

var A_arbace_aot_emit_A_const_268 any

var A_arbace_aot_emit_A_const_269 any

var A_arbace_aot_emit_A_const_270 *lang.Keyword

var A_arbace_aot_emit_A_const_271 *lang.Keyword

var A_arbace_aot_emit_A_const_272 *lang.Keyword

var A_arbace_aot_emit_A_const_273 any

var A_arbace_aot_emit_A_const_274 any

var A_arbace_aot_emit_A_const_275 any

var A_arbace_aot_emit_A_const_276 *lang.Var

var A_arbace_aot_emit_A_const_277 any

var A_arbace_aot_emit_A_const_278 any

var A_arbace_aot_emit_A_const_279 any

var A_arbace_aot_emit_A_const_280 any

var A_arbace_aot_emit_A_const_281 any

var A_arbace_aot_emit_A_const_282 *lang.Keyword

var A_arbace_aot_emit_A_const_283 *lang.Keyword

var A_arbace_aot_emit_A_const_284 *lang.Keyword

var A_arbace_aot_emit_A_const_285 *lang.Var

var A_arbace_aot_emit_A_const_286 *lang.Var

var A_arbace_aot_emit_A_const_287 any

var A_arbace_aot_emit_A_const_288 any

var A_arbace_aot_emit_A_const_289 *lang.Var

var A_arbace_aot_emit_A_const_290 any

var A_arbace_aot_emit_A_const_291 any

var A_arbace_aot_emit_A_const_292 any

var A_arbace_aot_emit_A_const_293 any

var A_arbace_aot_emit_A_const_294 *lang.Var

var A_arbace_aot_emit_A_const_295 *lang.Var

var A_arbace_aot_emit_A_const_296 any

var A_arbace_aot_emit_A_const_297 any

var A_arbace_aot_emit_A_const_298 any

var A_arbace_aot_emit_A_const_299 any

var A_arbace_aot_emit_A_const_300 *lang.Var

var A_arbace_aot_emit_A_const_301 *lang.Var

var A_arbace_aot_emit_A_const_302 *lang.Keyword

var A_arbace_aot_emit_A_const_303 *lang.Var

var A_arbace_aot_emit_A_const_304 *lang.Var

var A_arbace_aot_emit_A_const_305 *lang.Var

var A_arbace_aot_emit_A_const_306 *lang.Var

var A_arbace_aot_emit_A_const_307 *lang.Var

var A_arbace_aot_emit_A_const_308 *lang.Keyword

var A_arbace_aot_emit_A_const_309 *lang.Keyword

var A_arbace_aot_emit_A_const_310 *lang.Var

var A_arbace_aot_emit_A_const_311 *lang.Var

var A_arbace_aot_emit_A_const_312 *lang.Var

var A_arbace_aot_emit_A_const_313 any

var A_arbace_aot_emit_A_const_314 *lang.Keyword

var A_arbace_aot_emit_A_const_315 *lang.Keyword

var A_arbace_aot_emit_A_const_316 *lang.Keyword

var A_arbace_aot_emit_A_const_317 *lang.Var

var A_arbace_aot_emit_A_const_318 *lang.Var

var A_arbace_aot_emit_A_const_319 *lang.Var

var A_arbace_aot_emit_A_const_320 *lang.Keyword

var A_arbace_aot_emit_A_const_321 *lang.Keyword

var A_arbace_aot_emit_A_const_322 *lang.Keyword

var A_arbace_aot_emit_A_const_323 *lang.Keyword

var A_arbace_aot_emit_A_const_324 *lang.Keyword

var A_arbace_aot_emit_A_const_325 any

var A_arbace_aot_emit_A_const_326 any

var A_arbace_aot_emit_A_const_327 any

var A_arbace_aot_emit_A_const_328 any

var A_arbace_aot_emit_A_const_329 any

var A_arbace_aot_emit_A_const_330 *lang.Keyword

var A_arbace_aot_emit_A_const_331 any

var A_arbace_aot_emit_A_const_332 any

var A_arbace_aot_emit_A_const_333 *lang.Var

var A_arbace_aot_emit_A_const_334 any

var A_arbace_aot_emit_A_const_335 any

var A_arbace_aot_emit_A_const_336 any

var A_arbace_aot_emit_A_const_337 *lang.Var

var A_arbace_aot_emit_A_const_338 any

var A_arbace_aot_emit_A_const_339 any

var A_arbace_aot_emit_A_const_340 *lang.Keyword

var A_arbace_aot_emit_A_const_341 *lang.Keyword

var A_arbace_aot_emit_A_const_342 *lang.Var

var A_arbace_aot_emit_A_const_343 any

var A_arbace_aot_emit_A_const_344 *lang.Keyword

var A_arbace_aot_emit_A_const_345 *lang.Keyword

var A_arbace_aot_emit_A_const_346 any

var A_arbace_aot_emit_A_const_347 any

var A_arbace_aot_emit_A_const_348 any

var A_arbace_aot_emit_A_const_349 any

var A_arbace_aot_emit_A_const_350 *lang.Keyword

var A_arbace_aot_emit_A_const_351 any

var A_arbace_aot_emit_A_const_352 any

var A_arbace_aot_emit_A_const_353 *lang.Keyword

var A_arbace_aot_emit_A_const_354 *lang.Keyword

var A_arbace_aot_emit_A_const_355 any

var A_arbace_aot_emit_A_const_356 *lang.Keyword

var A_arbace_aot_emit_A_const_357 any

var A_arbace_aot_emit_A_const_358 any

var A_arbace_aot_emit_A_const_359 any

var A_arbace_aot_emit_A_const_360 any

var A_arbace_aot_emit_A_const_361 any

var A_arbace_aot_emit_A_const_362 *lang.Keyword

var A_arbace_aot_emit_A_const_363 any

var A_arbace_aot_emit_A_const_364 any

var A_arbace_aot_emit_A_const_365 any

var A_arbace_aot_emit_A_const_366 any

var A_arbace_aot_emit_A_const_367 any

var A_arbace_aot_emit_A_const_368 *lang.Keyword

var A_arbace_aot_emit_A_const_369 *lang.Keyword

var A_arbace_aot_emit_A_const_370 any

var A_arbace_aot_emit_A_const_371 any

var A_arbace_aot_emit_A_const_372 any

var A_arbace_aot_emit_A_const_373 any

var A_arbace_aot_emit_A_const_374 any

var A_arbace_aot_emit_A_const_375 any

var A_arbace_aot_emit_A_const_376 any

var A_arbace_aot_emit_A_const_377 any

var A_arbace_aot_emit_A_const_378 *lang.Keyword

var A_arbace_aot_emit_A_const_379 *lang.Var

var A_arbace_aot_emit_A_const_380 any

var A_arbace_aot_emit_A_const_381 *lang.Keyword

var A_arbace_aot_emit_A_const_382 *lang.Keyword

var A_arbace_aot_emit_A_const_383 *lang.Keyword

var A_arbace_aot_emit_A_const_384 *lang.Keyword

var A_arbace_aot_emit_A_const_385 *lang.Keyword

var A_arbace_aot_emit_A_const_386 *lang.Keyword

var A_arbace_aot_emit_A_const_387 *lang.Var

var A_arbace_aot_emit_A_const_388 *lang.Keyword

var A_arbace_aot_emit_A_const_389 any

var A_arbace_aot_emit_A_const_390 any

var A_arbace_aot_emit_A_const_391 *lang.Keyword

var A_arbace_aot_emit_A_const_392 *lang.Keyword

var A_arbace_aot_emit_A_const_393 *lang.Keyword

var A_arbace_aot_emit_A_const_394 *lang.Var

var A_arbace_aot_emit_A_const_395 any

var A_arbace_aot_emit_A_const_396 *lang.Var

var A_arbace_aot_emit_A_const_397 any

var A_arbace_aot_emit_A_const_398 any

var A_arbace_aot_emit_A_const_399 any

var A_arbace_aot_emit_A_const_400 *lang.Var

var A_arbace_aot_emit_A_const_401 *lang.Var

var A_arbace_aot_emit_A_const_402 *lang.Var

var A_arbace_aot_emit_A_const_403 *lang.Var

var A_arbace_aot_emit_A_const_404 *lang.Var

var A_arbace_aot_emit_A_const_405 *lang.Var

var A_arbace_aot_emit_A_const_406 *lang.Var

var A_arbace_aot_emit_A_const_407 *lang.Keyword

var A_arbace_aot_emit_A_const_408 any

var A_arbace_aot_emit_A_const_409 *lang.Keyword

var A_arbace_aot_emit_A_const_410 any

var A_arbace_aot_emit_A_const_411 *lang.Keyword

var A_arbace_aot_emit_A_const_412 any

var A_arbace_aot_emit_A_const_413 any

var A_arbace_aot_emit_A_const_414 any

var A_arbace_aot_emit_A_const_415 any

var A_arbace_aot_emit_A_const_416 any

var A_arbace_aot_emit_A_const_417 any

var A_arbace_aot_emit_A_const_418 any

var A_arbace_aot_emit_A_const_419 any

var A_arbace_aot_emit_A_const_420 any

var A_arbace_aot_emit_A_const_421 any

var A_arbace_aot_emit_A_const_422 any

var A_arbace_aot_emit_A_const_423 any

var A_arbace_aot_emit_A_const_424 any

var A_arbace_aot_emit_A_const_425 any

var A_arbace_aot_emit_A_const_426 *lang.Var

var A_arbace_aot_emit_A_const_427 *lang.Var

var A_arbace_aot_emit_A_const_428 *lang.Var

var A_arbace_aot_emit_A_const_429 any

var A_arbace_aot_emit_A_const_430 *lang.Var

var A_arbace_aot_emit_A_const_431 any

var A_arbace_aot_emit_A_const_432 any

var A_arbace_aot_emit_A_const_433 any

var A_arbace_aot_emit_A_const_434 *lang.Keyword

var A_arbace_aot_emit_A_const_435 *lang.Keyword

var A_arbace_aot_emit_A_const_436 *lang.Keyword

var A_arbace_aot_emit_A_const_437 any

var A_arbace_aot_emit_A_const_438 *lang.Keyword

var A_arbace_aot_emit_A_const_439 *lang.Keyword

var A_arbace_aot_emit_A_const_440 any

var A_arbace_aot_emit_A_const_441 *lang.Keyword

var A_arbace_aot_emit_A_const_442 *lang.Keyword

var A_arbace_aot_emit_A_const_443 *lang.Keyword

var A_arbace_aot_emit_A_const_444 any

var A_arbace_aot_emit_A_const_445 any

var A_arbace_aot_emit_A_const_446 *lang.Keyword

var A_arbace_aot_emit_A_const_447 *lang.Var

var A_arbace_aot_emit_A_const_448 *lang.Keyword

var A_arbace_aot_emit_A_const_449 *lang.Keyword

var A_arbace_aot_emit_A_const_450 *lang.Var

var A_arbace_aot_emit_A_const_451 *lang.Keyword

var A_arbace_aot_emit_A_const_452 any

var A_arbace_aot_emit_A_const_453 any

var A_arbace_aot_emit_A_const_454 any

var A_arbace_aot_emit_A_const_455 any

var A_arbace_aot_emit_A_const_456 any

var A_arbace_aot_emit_A_const_457 any

var A_arbace_aot_emit_A_const_458 any

var A_arbace_aot_emit_A_const_459 any

var A_arbace_aot_emit_A_const_460 any

var A_arbace_aot_emit_A_const_461 any

var A_arbace_aot_emit_A_const_462 any

var A_arbace_aot_emit_A_const_463 any

var A_arbace_aot_emit_A_const_464 any

var A_arbace_aot_emit_A_const_465 any

var A_arbace_aot_emit_A_const_466 any

var A_arbace_aot_emit_A_const_467 any

var A_arbace_aot_emit_A_const_468 any

var A_arbace_aot_emit_A_const_469 any

var A_arbace_aot_emit_A_const_470 any

var A_arbace_aot_emit_A_const_471 any

var A_arbace_aot_emit_A_const_472 *lang.Var

var A_arbace_aot_emit_A_const_473 *lang.Keyword

var A_arbace_aot_emit_A_const_474 any

var A_arbace_aot_emit_A_const_475 any

var A_arbace_aot_emit_A_const_476 *lang.Keyword

var A_arbace_aot_emit_A_const_477 any

var A_arbace_aot_emit_A_const_478 any

var A_arbace_aot_emit_A_const_479 any

var A_arbace_aot_emit_A_const_480 any

var A_arbace_aot_emit_A_const_481 any

var A_arbace_aot_emit_A_const_482 any

var A_arbace_aot_emit_A_const_483 any

var A_arbace_aot_emit_A_const_484 any

var A_arbace_aot_emit_A_const_485 any

var A_arbace_aot_emit_A_const_486 *lang.Keyword

var A_arbace_aot_emit_A_const_487 any

var A_arbace_aot_emit_A_const_488 *lang.Var

var A_arbace_aot_emit_A_const_489 *lang.Keyword

var A_arbace_aot_emit_A_const_490 *lang.Var

var A_arbace_aot_emit_A_const_491 *lang.Var

var A_arbace_aot_emit_A_const_492 *lang.Var

var A_arbace_aot_emit_A_const_493 *lang.Var

var A_arbace_aot_emit_A_const_494 *lang.Var

var A_arbace_aot_emit_A_const_495 *lang.Keyword

var A_arbace_aot_emit_A_const_496 any

var A_arbace_aot_emit_A_const_497 any

var A_arbace_aot_emit_A_const_498 any

var A_arbace_aot_emit_A_const_499 any

var A_arbace_aot_emit_A_const_500 *lang.Var

var A_arbace_aot_emit_A_const_501 *lang.Var

var A_arbace_aot_emit_A_const_502 *lang.Keyword

var A_arbace_aot_emit_A_const_503 any

var A_arbace_aot_emit_A_const_504 *lang.Keyword

var A_arbace_aot_emit_A_const_505 any

var A_arbace_aot_emit_A_const_506 *lang.Keyword

var A_arbace_aot_emit_A_const_507 *lang.Var

var A_arbace_aot_emit_A_const_508 any

var A_arbace_aot_emit_A_const_509 *lang.Var

var A_arbace_aot_emit_A_const_510 *lang.Var

var A_arbace_aot_emit_A_const_511 *lang.Var

var A_arbace_aot_emit_A_const_512 *lang.Var

var A_arbace_aot_emit_A_const_513 *lang.Var

var A_arbace_aot_emit_A_const_514 any

var A_arbace_aot_emit_A_const_515 any

var A_arbace_aot_emit_A_const_516 any

var A_arbace_aot_emit_A_const_517 any

var A_arbace_aot_emit_A_const_518 any

var A_arbace_aot_emit_A_const_519 *lang.Keyword

var A_arbace_aot_emit_A_const_520 any

var A_arbace_aot_emit_A_const_521 any

var A_arbace_aot_emit_A_const_522 *lang.Keyword

var A_arbace_aot_emit_A_const_523 *lang.Var

var A_arbace_aot_emit_A_const_524 *lang.Var

var A_arbace_aot_emit_A_const_525 any

var A_arbace_aot_emit_A_const_526 any

var A_arbace_aot_emit_A_const_527 any

var A_arbace_aot_emit_A_const_528 *lang.Var

var A_arbace_aot_emit_A_const_529 *lang.Keyword

var A_arbace_aot_emit_A_const_530 any

var A_arbace_aot_emit_A_const_531 *lang.Keyword

var A_arbace_aot_emit_A_const_532 any

var A_arbace_aot_emit_A_const_533 any

var A_arbace_aot_emit_A_const_534 *lang.Var

var A_arbace_aot_emit_A_const_535 any

var A_arbace_aot_emit_A_const_536 any

var A_arbace_aot_emit_A_const_537 any

var A_arbace_aot_emit_A_const_538 *lang.Keyword

var A_arbace_aot_emit_A_const_539 any

var A_arbace_aot_emit_A_const_540 any

var A_arbace_aot_emit_A_const_541 any

var A_arbace_aot_emit_A_const_542 any

var A_arbace_aot_emit_A_const_543 any

var A_arbace_aot_emit_A_const_544 any

var A_arbace_aot_emit_A_const_545 any

var A_arbace_aot_emit_A_const_546 any

var A_arbace_aot_emit_A_const_547 any

var A_arbace_aot_emit_A_const_548 any

var A_arbace_aot_emit_A_const_549 any

var A_arbace_aot_emit_A_const_550 any

var A_arbace_aot_emit_A_const_551 *lang.Var

var A_arbace_aot_emit_A_const_552 *lang.Var

var A_arbace_aot_emit_A_const_553 *lang.Keyword

var A_arbace_aot_emit_A_const_554 any

var A_arbace_aot_emit_A_const_555 any

var A_arbace_aot_emit_A_const_556 any

var A_arbace_aot_emit_A_const_557 any

var A_arbace_aot_emit_A_const_558 any

var A_arbace_aot_emit_A_const_559 any

var A_arbace_aot_emit_A_const_560 *lang.Keyword

var A_arbace_aot_emit_A_const_561 any

var A_arbace_aot_emit_A_const_562 any

var A_arbace_aot_emit_A_const_563 *lang.Keyword

var A_arbace_aot_emit_A_const_564 *lang.Var

var A_arbace_aot_emit_A_const_565 any

var A_arbace_aot_emit_A_const_566 any

var A_arbace_aot_emit_A_const_567 any

var A_arbace_aot_emit_A_const_568 any

var A_arbace_aot_emit_A_const_569 any

var A_arbace_aot_emit_A_const_570 any

var A_arbace_aot_emit_A_const_571 *lang.Var

var A_arbace_aot_emit_A_const_572 *lang.Var

var A_arbace_aot_emit_A_const_573 any

var A_arbace_aot_emit_A_const_574 any

var A_arbace_aot_emit_A_const_575 any

var A_arbace_aot_emit_A_const_576 any

var A_arbace_aot_emit_A_const_577 any

var A_arbace_aot_emit_A_const_578 any

var A_arbace_aot_emit_A_const_579 any

var A_arbace_aot_emit_A_const_580 any

var A_arbace_aot_emit_A_const_581 any

var A_arbace_aot_emit_A_const_582 any

var A_arbace_aot_emit_A_const_583 any

var A_arbace_aot_emit_A_const_584 any

var A_arbace_aot_emit_A_const_585 *lang.Keyword

var A_arbace_aot_emit_A_const_586 *lang.Var

var A_arbace_aot_emit_A_const_587 *lang.Keyword

var A_arbace_aot_emit_A_const_588 *lang.Keyword

var A_arbace_aot_emit_A_const_589 *lang.Keyword

var A_arbace_aot_emit_A_const_590 any

var A_arbace_aot_emit_A_const_591 any

var A_arbace_aot_emit_A_const_592 any

var A_arbace_aot_emit_A_const_593 any

var A_arbace_aot_emit_A_const_594 any

var A_arbace_aot_emit_A_const_595 *lang.Var

var A_arbace_aot_emit_A_const_596 *lang.Var

var A_arbace_aot_emit_A_const_597 *lang.Var

var A_arbace_aot_emit_A_const_598 *lang.Keyword

var A_arbace_aot_emit_A_const_599 *lang.Keyword

var A_arbace_aot_emit_A_const_600 *lang.Keyword

var A_arbace_aot_emit_A_const_601 any

var A_arbace_aot_emit_A_const_602 *lang.Keyword

var A_arbace_aot_emit_A_const_603 any

var A_arbace_aot_emit_A_const_604 *lang.Var

var A_arbace_aot_emit_A_const_605 *lang.Keyword

var A_arbace_aot_emit_A_const_606 *lang.Keyword

var A_arbace_aot_emit_A_const_607 any

var A_arbace_aot_emit_A_const_608 *lang.Var

var A_arbace_aot_emit_A_const_609 any

var A_arbace_aot_emit_A_const_610 any

var A_arbace_aot_emit_A_const_611 any

var A_arbace_aot_emit_A_const_612 *lang.Var

var A_arbace_aot_emit_A_const_613 any

var A_arbace_aot_emit_A_const_614 any

var A_arbace_aot_emit_A_const_615 any

var A_arbace_aot_emit_A_const_616 *lang.Var

var A_arbace_aot_emit_A_const_617 *lang.Keyword

var A_arbace_aot_emit_A_const_618 *lang.Keyword

var A_arbace_aot_emit_A_const_619 any

var A_arbace_aot_emit_A_const_620 any

var A_arbace_aot_emit_A_const_621 any

var A_arbace_aot_emit_A_const_622 any

var A_arbace_aot_emit_A_const_623 any

var A_arbace_aot_emit_A_const_624 any

var A_arbace_aot_emit_A_const_625 any

var A_arbace_aot_emit_A_const_626 any

var A_arbace_aot_emit_A_const_627 any

var A_arbace_aot_emit_A_const_628 any

var A_arbace_aot_emit_A_const_629 any

var A_arbace_aot_emit_A_const_630 any

var A_arbace_aot_emit_A_const_631 any

var A_arbace_aot_emit_A_const_632 any

var A_arbace_aot_emit_A_const_633 any

var A_arbace_aot_emit_A_const_634 any

var A_arbace_aot_emit_A_const_635 any

var A_arbace_aot_emit_A_const_636 any

var A_arbace_aot_emit_A_const_637 any

var A_arbace_aot_emit_A_const_638 any

var A_arbace_aot_emit_A_const_639 any

var A_arbace_aot_emit_A_const_640 *lang.Var

var A_arbace_aot_emit_A_const_641 any

var A_arbace_aot_emit_A_const_642 any

var A_arbace_aot_emit_A_const_643 any

var A_arbace_aot_emit_A_const_644 any

var A_arbace_aot_emit_A_const_645 *lang.Var

var A_arbace_aot_emit_A_const_646 any

var A_arbace_aot_emit_A_const_647 any

var A_arbace_aot_emit_A_const_648 any

var A_arbace_aot_emit_A_const_649 any

var A_arbace_aot_emit_A_const_650 any

var A_arbace_aot_emit_A_const_651 any

var A_arbace_aot_emit_A_const_652 any

var A_arbace_aot_emit_A_const_653 any

var A_arbace_aot_emit_A_const_654 any

var A_arbace_aot_emit_A_const_655 any

var A_arbace_aot_emit_A_const_656 any

var A_arbace_aot_emit_A_const_657 any

var A_arbace_aot_emit_A_const_658 any

var A_arbace_aot_emit_A_const_659 *lang.Keyword

var A_arbace_aot_emit_A_const_660 *lang.Keyword

var A_arbace_aot_emit_A_const_661 *lang.Keyword

var A_arbace_aot_emit_A_const_662 any

var A_arbace_aot_emit_A_const_663 *lang.Keyword

var A_arbace_aot_emit_A_const_664 *lang.Var

var A_arbace_aot_emit_A_const_665 *lang.Keyword

var A_arbace_aot_emit_A_const_666 *lang.Keyword

var A_arbace_aot_emit_A_const_667 *lang.Keyword

var A_arbace_aot_emit_A_const_668 any

var A_arbace_aot_emit_A_const_669 *lang.Var

var A_arbace_aot_emit_A_const_670 any

var A_arbace_aot_emit_A_const_671 *lang.Var

var A_arbace_aot_emit_A_const_672 any

var A_arbace_aot_emit_A_const_673 *lang.Keyword

var A_arbace_aot_emit_A_const_674 any

var A_arbace_aot_emit_A_const_675 any

var A_arbace_aot_emit_A_const_676 any

var A_arbace_aot_emit_A_const_677 any

var A_arbace_aot_emit_A_const_678 any

var A_arbace_aot_emit_A_const_679 any

var A_arbace_aot_emit_A_const_680 any

var A_arbace_aot_emit_A_const_681 any

var A_arbace_aot_emit_A_const_682 any

var A_arbace_aot_emit_A_const_683 *lang.Var

var A_arbace_aot_emit_A_const_684 *lang.Keyword

var A_arbace_aot_emit_A_const_685 any

var A_arbace_aot_emit_A_const_686 any

var A_arbace_aot_emit_A_const_687 any

var A_arbace_aot_emit_A_const_688 any

var A_arbace_aot_emit_A_const_689 any

var A_arbace_aot_emit_A_const_690 any

var A_arbace_aot_emit_A_const_691 any

var A_arbace_aot_emit_A_const_692 any

var A_arbace_aot_emit_A_const_693 any

var A_arbace_aot_emit_A_const_694 any

var A_arbace_aot_emit_A_const_695 any

var A_arbace_aot_emit_A_const_696 any

var A_arbace_aot_emit_A_const_697 any

var A_arbace_aot_emit_A_const_698 any

var A_arbace_aot_emit_A_const_699 any

var A_arbace_aot_emit_A_const_700 any

var A_arbace_aot_emit_A_const_701 any

var A_arbace_aot_emit_A_const_702 any

var A_arbace_aot_emit_A_const_703 any

var A_arbace_aot_emit_A_const_704 any

var A_arbace_aot_emit_A_const_705 any

var A_arbace_aot_emit_A_const_706 any

var A_arbace_aot_emit_A_const_707 any

var A_arbace_aot_emit_A_const_708 any

var A_arbace_aot_emit_A_const_709 any

var A_arbace_aot_emit_A_const_710 any

var A_arbace_aot_emit_A_const_711 any

var A_arbace_aot_emit_A_const_712 any

var A_arbace_aot_emit_A_const_713 any

var A_arbace_aot_emit_A_const_714 any

var A_arbace_aot_emit_A_const_715 any

var A_arbace_aot_emit_A_const_716 any

var A_arbace_aot_emit_A_const_717 any

var A_arbace_aot_emit_A_const_718 any

var A_arbace_aot_emit_A_const_719 *lang.Keyword

var A_arbace_aot_emit_A_const_720 *lang.Keyword

var A_arbace_aot_emit_A_const_721 any

var A_arbace_aot_emit_A_const_722 any

var A_arbace_aot_emit_A_const_723 any

var A_arbace_aot_emit_A_const_724 any

var A_arbace_aot_emit_A_const_725 any

var A_arbace_aot_emit_A_const_726 *lang.Var

var A_arbace_aot_emit_A_const_727 any

var A_arbace_aot_emit_A_const_728 any

var A_arbace_aot_emit_A_const_729 any

var A_arbace_aot_emit_A_const_730 any

var A_arbace_aot_emit_A_const_731 any

var A_arbace_aot_emit_A_const_732 any

var A_arbace_aot_emit_A_const_733 any

var A_arbace_aot_emit_A_const_734 any

var A_arbace_aot_emit_A_const_735 any

var A_arbace_aot_emit_A_const_736 any

var A_arbace_aot_emit_A_const_737 any

var A_arbace_aot_emit_A_const_738 any

var A_arbace_aot_emit_A_const_739 any

var A_arbace_aot_emit_A_const_740 any

var A_arbace_aot_emit_A_const_741 any

var A_arbace_aot_emit_A_const_742 any

var A_arbace_aot_emit_A_const_743 any

var A_arbace_aot_emit_A_const_744 any

var A_arbace_aot_emit_A_const_745 any

var A_arbace_aot_emit_A_const_746 any

var A_arbace_aot_emit_A_const_747 *lang.Var

var A_arbace_aot_emit_A_const_748 *lang.Keyword

var A_arbace_aot_emit_A_const_749 *lang.Var

var A_arbace_aot_emit_A_const_750 *lang.Var

var A_arbace_aot_emit_A_const_751 *lang.Var

var A_arbace_aot_emit_A_const_752 any

var A_arbace_aot_emit_A_const_753 *lang.Keyword

var A_arbace_aot_emit_A_const_754 *lang.Keyword

var A_arbace_aot_emit_A_const_755 *lang.Keyword

var A_arbace_aot_emit_A_const_756 any

var A_arbace_aot_emit_A_const_757 any

var A_arbace_aot_emit_A_const_758 any

var A_arbace_aot_emit_A_const_759 any

var A_arbace_aot_emit_A_const_760 any

var A_arbace_aot_emit_A_const_761 *lang.Var

var A_arbace_aot_emit_A_const_762 *lang.Var

var A_arbace_aot_emit_A_const_763 *lang.Keyword

var A_arbace_aot_emit_A_const_764 *lang.Keyword

var A_arbace_aot_emit_A_const_765 *lang.Var

var A_arbace_aot_emit_A_const_766 *lang.Var

var A_arbace_aot_emit_A_const_767 *lang.Keyword

var A_arbace_aot_emit_A_const_768 any

var A_arbace_aot_emit_A_const_769 any

var A_arbace_aot_emit_A_const_770 any

var A_arbace_aot_emit_A_const_771 any

var A_arbace_aot_emit_A_const_772 *lang.Keyword

var A_arbace_aot_emit_A_const_773 any

var A_arbace_aot_emit_A_const_774 any

var A_arbace_aot_emit_A_const_775 *lang.Keyword

var A_arbace_aot_emit_A_const_776 *lang.Var

var A_arbace_aot_emit_A_const_777 *lang.Var

var A_arbace_aot_emit_A_const_778 *lang.Var

var A_arbace_aot_emit_A_const_779 *lang.Var

var A_arbace_aot_emit_A_const_780 *lang.Var

var A_arbace_aot_emit_A_const_781 any

var A_arbace_aot_emit_A_const_782 any

var A_arbace_aot_emit_A_const_783 any

var A_arbace_aot_emit_A_const_784 any

var A_arbace_aot_emit_A_init jrt.ClassInit

func A_arbace_aot_emit_A_Init() { if !A_arbace_aot_emit_A_init.Done() { A_arbace_aot_emit_A_init.Run(A_arbace_aot_emit_A_clinit) } }

func A_arbace_aot_emit_A_clinit() { A_arbace_aot_emit_A_clinit_p0(); A_arbace_aot_emit_A_clinit_p1(); A_arbace_aot_emit_A_clinit_p2(); A_arbace_aot_emit_A_clinit_p3(); A_arbace_aot_emit_A_clinit_p4(); A_arbace_aot_emit_A_clinit_p5(); A_arbace_aot_emit_A_clinit_p6(); A_arbace_aot_emit_A_clinit_p7(); A_arbace_aot_emit_A_clinit_p8(); A_arbace_aot_emit_A_clinit_p9(); A_arbace_aot_emit_A_clinit_p10(); A_arbace_aot_emit_A_clinit_p11(); A_arbace_aot_emit_A_clinit_p12(); A_arbace_aot_emit_A_clinit_p13(); A_arbace_aot_emit_A_clinit_p14(); A_arbace_aot_emit_A_clinit_p15(); A_arbace_aot_emit_A_clinit_p16(); A_arbace_aot_emit_A_clinit_p17(); A_arbace_aot_emit_A_clinit_p18(); A_arbace_aot_emit_A_clinit_p19(); A_arbace_aot_emit_A_clinit_p20(); A_arbace_aot_emit_A_clinit_p21(); A_arbace_aot_emit_A_clinit_p22(); A_arbace_aot_emit_A_clinit_p23(); A_arbace_aot_emit_A_clinit_p24(); A_arbace_aot_emit_A_clinit_p25(); A_arbace_aot_emit_A_clinit_p26(); A_arbace_aot_emit_A_clinit_p27(); A_arbace_aot_emit_A_clinit_p28(); A_arbace_aot_emit_A_clinit_p29(); A_arbace_aot_emit_A_clinit_p30(); A_arbace_aot_emit_A_clinit_p31(); A_arbace_aot_emit_A_clinit_p32(); A_arbace_aot_emit_A_clinit_p33(); A_arbace_aot_emit_A_clinit_p34(); A_arbace_aot_emit_A_clinit_p35(); A_arbace_aot_emit_A_clinit_p36(); A_arbace_aot_emit_A_clinit_p37(); A_arbace_aot_emit_A_clinit_p38(); A_arbace_aot_emit_A_clinit_p39(); A_arbace_aot_emit_A_clinit_p40(); A_arbace_aot_emit_A_clinit_p41(); A_arbace_aot_emit_A_clinit_p42(); A_arbace_aot_emit_A_clinit_p43(); A_arbace_aot_emit_A_clinit_p44(); A_arbace_aot_emit_A_clinit_p45(); A_arbace_aot_emit_A_clinit_p46(); A_arbace_aot_emit_A_clinit_p47(); A_arbace_aot_emit_A_clinit_p48(); A_arbace_aot_emit_A_clinit_p49(); A_arbace_aot_emit_A_clinit_p50(); A_arbace_aot_emit_A_clinit_p51(); A_arbace_aot_emit_A_clinit_p52(); A_arbace_aot_emit_A_clinit_p53(); A_arbace_aot_emit_A_clinit_p54(); A_arbace_aot_emit_A_clinit_p55(); A_arbace_aot_emit_A_clinit_p56(); A_arbace_aot_emit_A_clinit_p57() }

func A_arbace_aot_emit_A_clinit_p0() { A_arbace_aot_emit_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 1091); A_arbace_aot_emit_A_const_0 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[306]); A_arbace_aot_emit_A_const_1 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[307]); A_arbace_aot_emit_A_const_2 = A_arbace_aot_emit_A_const_pool.A[308]; A_arbace_aot_emit_A_const_3 = A_arbace_aot_emit_A_const_pool.A[309]; A_arbace_aot_emit_A_const_4 = A_arbace_aot_emit_A_const_pool.A[310]; A_arbace_aot_emit_A_const_5 = A_arbace_aot_emit_A_const_pool.A[311]; A_arbace_aot_emit_A_const_6 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[312]); A_arbace_aot_emit_A_const_7 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[313]); A_arbace_aot_emit_A_const_8 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[314]); A_arbace_aot_emit_A_const_9 = A_arbace_aot_emit_A_const_pool.A[315]; A_arbace_aot_emit_A_const_10 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[316]); A_arbace_aot_emit_A_const_11 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[317]) }

func A_arbace_aot_emit_A_clinit_p1() { A_arbace_aot_emit_A_const_12 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[318]); A_arbace_aot_emit_A_const_13 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[319]); A_arbace_aot_emit_A_const_14 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[320]); A_arbace_aot_emit_A_const_15 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[321]); A_arbace_aot_emit_A_const_16 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[322]); A_arbace_aot_emit_A_const_17 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[323]); A_arbace_aot_emit_A_const_18 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[324]); A_arbace_aot_emit_A_const_19 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[325]); A_arbace_aot_emit_A_const_20 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[326]); A_arbace_aot_emit_A_const_21 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[327]); A_arbace_aot_emit_A_const_22 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[328]); A_arbace_aot_emit_A_const_23 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[329]) }

func A_arbace_aot_emit_A_clinit_p2() { A_arbace_aot_emit_A_const_24 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[330]); A_arbace_aot_emit_A_const_25 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[331]); A_arbace_aot_emit_A_const_26 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[332]); A_arbace_aot_emit_A_const_27 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[333]); A_arbace_aot_emit_A_const_28 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[334]); A_arbace_aot_emit_A_const_29 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[335]); A_arbace_aot_emit_A_const_30 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[336]); A_arbace_aot_emit_A_const_31 = A_arbace_aot_emit_A_const_pool.A[337]; A_arbace_aot_emit_A_const_32 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[338]); A_arbace_aot_emit_A_const_33 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[339]); A_arbace_aot_emit_A_const_34 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[340]); A_arbace_aot_emit_A_const_35 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[341]) }

func A_arbace_aot_emit_A_clinit_p3() { A_arbace_aot_emit_A_const_36 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[342]); A_arbace_aot_emit_A_const_37 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[343]); A_arbace_aot_emit_A_const_38 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[344]); A_arbace_aot_emit_A_const_39 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[345]); A_arbace_aot_emit_A_const_40 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[346]); A_arbace_aot_emit_A_const_41 = A_arbace_aot_emit_A_const_pool.A[347]; A_arbace_aot_emit_A_const_42 = A_arbace_aot_emit_A_const_pool.A[348]; A_arbace_aot_emit_A_const_43 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[349]); A_arbace_aot_emit_A_const_44 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[350]); A_arbace_aot_emit_A_const_45 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[351]); A_arbace_aot_emit_A_const_46 = A_arbace_aot_emit_A_const_pool.A[352]; A_arbace_aot_emit_A_const_47 = A_arbace_aot_emit_A_const_pool.A[353]; A_arbace_aot_emit_A_const_48 = A_arbace_aot_emit_A_const_pool.A[354] }

func A_arbace_aot_emit_A_clinit_p4() { A_arbace_aot_emit_A_const_49 = A_arbace_aot_emit_A_const_pool.A[355]; A_arbace_aot_emit_A_const_50 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[356]); A_arbace_aot_emit_A_const_51 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[357]); A_arbace_aot_emit_A_const_52 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[358]); A_arbace_aot_emit_A_const_53 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[359]); A_arbace_aot_emit_A_const_54 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[360]); A_arbace_aot_emit_A_const_55 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[361]); A_arbace_aot_emit_A_const_56 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[362]); A_arbace_aot_emit_A_const_57 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[363]); A_arbace_aot_emit_A_const_58 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[364]); A_arbace_aot_emit_A_const_59 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[365]); A_arbace_aot_emit_A_const_60 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[366]) }

func A_arbace_aot_emit_A_clinit_p5() { A_arbace_aot_emit_A_const_61 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[367]); A_arbace_aot_emit_A_const_62 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[368]); A_arbace_aot_emit_A_const_63 = A_arbace_aot_emit_A_const_pool.A[369]; A_arbace_aot_emit_A_const_64 = A_arbace_aot_emit_A_const_pool.A[370]; A_arbace_aot_emit_A_const_65 = A_arbace_aot_emit_A_const_pool.A[371]; A_arbace_aot_emit_A_const_66 = A_arbace_aot_emit_A_const_pool.A[372]; A_arbace_aot_emit_A_const_67 = A_arbace_aot_emit_A_const_pool.A[373]; A_arbace_aot_emit_A_const_68 = A_arbace_aot_emit_A_const_pool.A[374]; A_arbace_aot_emit_A_const_69 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[375]); A_arbace_aot_emit_A_const_70 = A_arbace_aot_emit_A_const_pool.A[376]; A_arbace_aot_emit_A_const_71 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[377]); A_arbace_aot_emit_A_const_72 = jrt.Class_Cast(A_arbace_aot_emit_A_const_pool.A[378]); A_arbace_aot_emit_A_const_73 = jrt.Class_Cast(A_arbace_aot_emit_A_const_pool.A[379]) }

func A_arbace_aot_emit_A_clinit_p6() { A_arbace_aot_emit_A_const_74 = jrt.Class_Cast(A_arbace_aot_emit_A_const_pool.A[380]); A_arbace_aot_emit_A_const_75 = jrt.Class_Cast(A_arbace_aot_emit_A_const_pool.A[381]); A_arbace_aot_emit_A_const_76 = jrt.Class_Cast(A_arbace_aot_emit_A_const_pool.A[382]); A_arbace_aot_emit_A_const_77 = jrt.Class_Cast(A_arbace_aot_emit_A_const_pool.A[383]); A_arbace_aot_emit_A_const_78 = jrt.Class_Cast(A_arbace_aot_emit_A_const_pool.A[384]); A_arbace_aot_emit_A_const_79 = jrt.Class_Cast(A_arbace_aot_emit_A_const_pool.A[385]); A_arbace_aot_emit_A_const_80 = A_arbace_aot_emit_A_const_pool.A[386]; A_arbace_aot_emit_A_const_81 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[387]); A_arbace_aot_emit_A_const_82 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[388]); A_arbace_aot_emit_A_const_83 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[389]); A_arbace_aot_emit_A_const_84 = A_arbace_aot_emit_A_const_pool.A[390]; A_arbace_aot_emit_A_const_85 = A_arbace_aot_emit_A_const_pool.A[391]; A_arbace_aot_emit_A_const_86 = A_arbace_aot_emit_A_const_pool.A[392] }

func A_arbace_aot_emit_A_clinit_p7() { A_arbace_aot_emit_A_const_87 = A_arbace_aot_emit_A_const_pool.A[393]; A_arbace_aot_emit_A_const_88 = A_arbace_aot_emit_A_const_pool.A[394]; A_arbace_aot_emit_A_const_89 = A_arbace_aot_emit_A_const_pool.A[395]; A_arbace_aot_emit_A_const_90 = A_arbace_aot_emit_A_const_pool.A[396]; A_arbace_aot_emit_A_const_91 = A_arbace_aot_emit_A_const_pool.A[397]; A_arbace_aot_emit_A_const_92 = A_arbace_aot_emit_A_const_pool.A[398]; A_arbace_aot_emit_A_const_93 = A_arbace_aot_emit_A_const_pool.A[399]; A_arbace_aot_emit_A_const_94 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[400]); A_arbace_aot_emit_A_const_95 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[401]); A_arbace_aot_emit_A_const_96 = A_arbace_aot_emit_A_const_pool.A[402]; A_arbace_aot_emit_A_const_97 = A_arbace_aot_emit_A_const_pool.A[403]; A_arbace_aot_emit_A_const_98 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[404]); A_arbace_aot_emit_A_const_99 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[405]); A_arbace_aot_emit_A_const_100 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[406]) }

func A_arbace_aot_emit_A_clinit_p8() { A_arbace_aot_emit_A_const_101 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[407]); A_arbace_aot_emit_A_const_102 = A_arbace_aot_emit_A_const_pool.A[408]; A_arbace_aot_emit_A_const_103 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[409]); A_arbace_aot_emit_A_const_104 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[410]); A_arbace_aot_emit_A_const_105 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[411]); A_arbace_aot_emit_A_const_106 = A_arbace_aot_emit_A_const_pool.A[412]; A_arbace_aot_emit_A_const_107 = A_arbace_aot_emit_A_const_pool.A[413]; A_arbace_aot_emit_A_const_108 = A_arbace_aot_emit_A_const_pool.A[414]; A_arbace_aot_emit_A_const_109 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[415]); A_arbace_aot_emit_A_const_110 = A_arbace_aot_emit_A_const_pool.A[416]; A_arbace_aot_emit_A_const_111 = A_arbace_aot_emit_A_const_pool.A[417]; A_arbace_aot_emit_A_const_112 = A_arbace_aot_emit_A_const_pool.A[418]; A_arbace_aot_emit_A_const_113 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[419]); A_arbace_aot_emit_A_const_114 = A_arbace_aot_emit_A_const_pool.A[420] }

func A_arbace_aot_emit_A_clinit_p9() { A_arbace_aot_emit_A_const_115 = A_arbace_aot_emit_A_const_pool.A[421]; A_arbace_aot_emit_A_const_116 = A_arbace_aot_emit_A_const_pool.A[422]; A_arbace_aot_emit_A_const_117 = A_arbace_aot_emit_A_const_pool.A[423]; A_arbace_aot_emit_A_const_118 = A_arbace_aot_emit_A_const_pool.A[424]; A_arbace_aot_emit_A_const_119 = A_arbace_aot_emit_A_const_pool.A[425]; A_arbace_aot_emit_A_const_120 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[426]); A_arbace_aot_emit_A_const_121 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[427]); A_arbace_aot_emit_A_const_122 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[428]); A_arbace_aot_emit_A_const_123 = A_arbace_aot_emit_A_const_pool.A[429]; A_arbace_aot_emit_A_const_124 = A_arbace_aot_emit_A_const_pool.A[430]; A_arbace_aot_emit_A_const_125 = A_arbace_aot_emit_A_const_pool.A[431]; A_arbace_aot_emit_A_const_126 = A_arbace_aot_emit_A_const_pool.A[432]; A_arbace_aot_emit_A_const_127 = A_arbace_aot_emit_A_const_pool.A[433]; A_arbace_aot_emit_A_const_128 = A_arbace_aot_emit_A_const_pool.A[434]; A_arbace_aot_emit_A_const_129 = A_arbace_aot_emit_A_const_pool.A[435] }

func A_arbace_aot_emit_A_clinit_p10() { A_arbace_aot_emit_A_const_130 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[436]); A_arbace_aot_emit_A_const_131 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[437]); A_arbace_aot_emit_A_const_132 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[438]); A_arbace_aot_emit_A_const_133 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[439]); A_arbace_aot_emit_A_const_134 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[440]); A_arbace_aot_emit_A_const_135 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[441]); A_arbace_aot_emit_A_const_136 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[442]); A_arbace_aot_emit_A_const_137 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[443]); A_arbace_aot_emit_A_const_138 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[444]); A_arbace_aot_emit_A_const_139 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[445]); A_arbace_aot_emit_A_const_140 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[446]); A_arbace_aot_emit_A_const_141 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[447]) }

func A_arbace_aot_emit_A_clinit_p11() { A_arbace_aot_emit_A_const_142 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[448]); A_arbace_aot_emit_A_const_143 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[449]); A_arbace_aot_emit_A_const_144 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[450]); A_arbace_aot_emit_A_const_145 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[451]); A_arbace_aot_emit_A_const_146 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[452]); A_arbace_aot_emit_A_const_147 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[453]); A_arbace_aot_emit_A_const_148 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[454]); A_arbace_aot_emit_A_const_149 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[455]); A_arbace_aot_emit_A_const_150 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[456]); A_arbace_aot_emit_A_const_151 = A_arbace_aot_emit_A_const_pool.A[457]; A_arbace_aot_emit_A_const_152 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[458]); A_arbace_aot_emit_A_const_153 = A_arbace_aot_emit_A_const_pool.A[459] }

func A_arbace_aot_emit_A_clinit_p12() { A_arbace_aot_emit_A_const_154 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[460]); A_arbace_aot_emit_A_const_155 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[461]); A_arbace_aot_emit_A_const_156 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[462]); A_arbace_aot_emit_A_const_157 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[463]); A_arbace_aot_emit_A_const_158 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[464]); A_arbace_aot_emit_A_const_159 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[465]); A_arbace_aot_emit_A_const_160 = A_arbace_aot_emit_A_const_pool.A[466]; A_arbace_aot_emit_A_const_161 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[467]); A_arbace_aot_emit_A_const_162 = A_arbace_aot_emit_A_const_pool.A[468]; A_arbace_aot_emit_A_const_163 = A_arbace_aot_emit_A_const_pool.A[469]; A_arbace_aot_emit_A_const_164 = A_arbace_aot_emit_A_const_pool.A[470]; A_arbace_aot_emit_A_const_165 = A_arbace_aot_emit_A_const_pool.A[471]; A_arbace_aot_emit_A_const_166 = A_arbace_aot_emit_A_const_pool.A[472] }

func A_arbace_aot_emit_A_clinit_p13() { A_arbace_aot_emit_A_const_167 = A_arbace_aot_emit_A_const_pool.A[473]; A_arbace_aot_emit_A_const_168 = A_arbace_aot_emit_A_const_pool.A[474]; A_arbace_aot_emit_A_const_169 = A_arbace_aot_emit_A_const_pool.A[475]; A_arbace_aot_emit_A_const_170 = A_arbace_aot_emit_A_const_pool.A[476]; A_arbace_aot_emit_A_const_171 = A_arbace_aot_emit_A_const_pool.A[477]; A_arbace_aot_emit_A_const_172 = A_arbace_aot_emit_A_const_pool.A[478]; A_arbace_aot_emit_A_const_173 = A_arbace_aot_emit_A_const_pool.A[479]; A_arbace_aot_emit_A_const_174 = A_arbace_aot_emit_A_const_pool.A[480]; A_arbace_aot_emit_A_const_175 = A_arbace_aot_emit_A_const_pool.A[481]; A_arbace_aot_emit_A_const_176 = A_arbace_aot_emit_A_const_pool.A[482]; A_arbace_aot_emit_A_const_177 = A_arbace_aot_emit_A_const_pool.A[483]; A_arbace_aot_emit_A_const_178 = A_arbace_aot_emit_A_const_pool.A[484]; A_arbace_aot_emit_A_const_179 = A_arbace_aot_emit_A_const_pool.A[485]; A_arbace_aot_emit_A_const_180 = A_arbace_aot_emit_A_const_pool.A[486]; A_arbace_aot_emit_A_const_181 = A_arbace_aot_emit_A_const_pool.A[487]; A_arbace_aot_emit_A_const_182 = A_arbace_aot_emit_A_const_pool.A[488] }

func A_arbace_aot_emit_A_clinit_p14() { A_arbace_aot_emit_A_const_183 = A_arbace_aot_emit_A_const_pool.A[489]; A_arbace_aot_emit_A_const_184 = A_arbace_aot_emit_A_const_pool.A[490]; A_arbace_aot_emit_A_const_185 = A_arbace_aot_emit_A_const_pool.A[491]; A_arbace_aot_emit_A_const_186 = A_arbace_aot_emit_A_const_pool.A[492]; A_arbace_aot_emit_A_const_187 = A_arbace_aot_emit_A_const_pool.A[493]; A_arbace_aot_emit_A_const_188 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[494]); A_arbace_aot_emit_A_const_189 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[495]); A_arbace_aot_emit_A_const_190 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[496]); A_arbace_aot_emit_A_const_191 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[497]); A_arbace_aot_emit_A_const_192 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[498]); A_arbace_aot_emit_A_const_193 = A_arbace_aot_emit_A_const_pool.A[499]; A_arbace_aot_emit_A_const_194 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[500]); A_arbace_aot_emit_A_const_195 = A_arbace_aot_emit_A_const_pool.A[501]; A_arbace_aot_emit_A_const_196 = A_arbace_aot_emit_A_const_pool.A[502] }

func A_arbace_aot_emit_A_clinit_p15() { A_arbace_aot_emit_A_const_197 = A_arbace_aot_emit_A_const_pool.A[503]; A_arbace_aot_emit_A_const_198 = A_arbace_aot_emit_A_const_pool.A[504]; A_arbace_aot_emit_A_const_199 = A_arbace_aot_emit_A_const_pool.A[505]; A_arbace_aot_emit_A_const_200 = A_arbace_aot_emit_A_const_pool.A[506]; A_arbace_aot_emit_A_const_201 = A_arbace_aot_emit_A_const_pool.A[507]; A_arbace_aot_emit_A_const_202 = A_arbace_aot_emit_A_const_pool.A[508]; A_arbace_aot_emit_A_const_203 = A_arbace_aot_emit_A_const_pool.A[509]; A_arbace_aot_emit_A_const_204 = A_arbace_aot_emit_A_const_pool.A[510]; A_arbace_aot_emit_A_const_205 = A_arbace_aot_emit_A_const_pool.A[511]; A_arbace_aot_emit_A_const_206 = A_arbace_aot_emit_A_const_pool.A[512]; A_arbace_aot_emit_A_const_207 = A_arbace_aot_emit_A_const_pool.A[513]; A_arbace_aot_emit_A_const_208 = A_arbace_aot_emit_A_const_pool.A[514]; A_arbace_aot_emit_A_const_209 = A_arbace_aot_emit_A_const_pool.A[515]; A_arbace_aot_emit_A_const_210 = A_arbace_aot_emit_A_const_pool.A[516]; A_arbace_aot_emit_A_const_211 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[517]) }

func A_arbace_aot_emit_A_clinit_p16() { A_arbace_aot_emit_A_const_212 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[518]); A_arbace_aot_emit_A_const_213 = A_arbace_aot_emit_A_const_pool.A[519]; A_arbace_aot_emit_A_const_214 = A_arbace_aot_emit_A_const_pool.A[520]; A_arbace_aot_emit_A_const_215 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[521]); A_arbace_aot_emit_A_const_216 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[522]); A_arbace_aot_emit_A_const_217 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[523]); A_arbace_aot_emit_A_const_218 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[524]); A_arbace_aot_emit_A_const_219 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[525]); A_arbace_aot_emit_A_const_220 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[526]); A_arbace_aot_emit_A_const_221 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[527]); A_arbace_aot_emit_A_const_222 = A_arbace_aot_emit_A_const_pool.A[528]; A_arbace_aot_emit_A_const_223 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[529]) }

func A_arbace_aot_emit_A_clinit_p17() { A_arbace_aot_emit_A_const_224 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[530]); A_arbace_aot_emit_A_const_225 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[531]); A_arbace_aot_emit_A_const_226 = A_arbace_aot_emit_A_const_pool.A[532]; A_arbace_aot_emit_A_const_227 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[533]); A_arbace_aot_emit_A_const_228 = jrt.Class_Cast(A_arbace_aot_emit_A_const_pool.A[534]); A_arbace_aot_emit_A_const_229 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[535]); A_arbace_aot_emit_A_const_230 = A_arbace_aot_emit_A_const_pool.A[536]; A_arbace_aot_emit_A_const_231 = A_arbace_aot_emit_A_const_pool.A[537]; A_arbace_aot_emit_A_const_232 = A_arbace_aot_emit_A_const_pool.A[538]; A_arbace_aot_emit_A_const_233 = A_arbace_aot_emit_A_const_pool.A[539]; A_arbace_aot_emit_A_const_234 = A_arbace_aot_emit_A_const_pool.A[540]; A_arbace_aot_emit_A_const_235 = A_arbace_aot_emit_A_const_pool.A[541]; A_arbace_aot_emit_A_const_236 = A_arbace_aot_emit_A_const_pool.A[542]; A_arbace_aot_emit_A_const_237 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[543]) }

func A_arbace_aot_emit_A_clinit_p18() { A_arbace_aot_emit_A_const_238 = A_arbace_aot_emit_A_const_pool.A[544]; A_arbace_aot_emit_A_const_239 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[545]); A_arbace_aot_emit_A_const_240 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[546]); A_arbace_aot_emit_A_const_241 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[547]); A_arbace_aot_emit_A_const_242 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[548]); A_arbace_aot_emit_A_const_243 = A_arbace_aot_emit_A_const_pool.A[549]; A_arbace_aot_emit_A_const_244 = A_arbace_aot_emit_A_const_pool.A[550]; A_arbace_aot_emit_A_const_245 = A_arbace_aot_emit_A_const_pool.A[551]; A_arbace_aot_emit_A_const_246 = A_arbace_aot_emit_A_const_pool.A[552]; A_arbace_aot_emit_A_const_247 = A_arbace_aot_emit_A_const_pool.A[553]; A_arbace_aot_emit_A_const_248 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[554]); A_arbace_aot_emit_A_const_249 = A_arbace_aot_emit_A_const_pool.A[555]; A_arbace_aot_emit_A_const_250 = A_arbace_aot_emit_A_const_pool.A[556]; A_arbace_aot_emit_A_const_251 = A_arbace_aot_emit_A_const_pool.A[557] }

func A_arbace_aot_emit_A_clinit_p19() { A_arbace_aot_emit_A_const_252 = A_arbace_aot_emit_A_const_pool.A[558]; A_arbace_aot_emit_A_const_253 = A_arbace_aot_emit_A_const_pool.A[559]; A_arbace_aot_emit_A_const_254 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[560]); A_arbace_aot_emit_A_const_255 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[561]); A_arbace_aot_emit_A_const_256 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[562]); A_arbace_aot_emit_A_const_257 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[563]); A_arbace_aot_emit_A_const_258 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[564]); A_arbace_aot_emit_A_const_259 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[565]); A_arbace_aot_emit_A_const_260 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[566]); A_arbace_aot_emit_A_const_261 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[567]); A_arbace_aot_emit_A_const_262 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[568]); A_arbace_aot_emit_A_const_263 = A_arbace_aot_emit_A_const_pool.A[569] }

func A_arbace_aot_emit_A_clinit_p20() { A_arbace_aot_emit_A_const_264 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[570]); A_arbace_aot_emit_A_const_265 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[571]); A_arbace_aot_emit_A_const_266 = A_arbace_aot_emit_A_const_pool.A[572]; A_arbace_aot_emit_A_const_267 = A_arbace_aot_emit_A_const_pool.A[573]; A_arbace_aot_emit_A_const_268 = A_arbace_aot_emit_A_const_pool.A[574]; A_arbace_aot_emit_A_const_269 = A_arbace_aot_emit_A_const_pool.A[575]; A_arbace_aot_emit_A_const_270 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[576]); A_arbace_aot_emit_A_const_271 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[577]); A_arbace_aot_emit_A_const_272 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[578]); A_arbace_aot_emit_A_const_273 = A_arbace_aot_emit_A_const_pool.A[579]; A_arbace_aot_emit_A_const_274 = A_arbace_aot_emit_A_const_pool.A[580]; A_arbace_aot_emit_A_const_275 = A_arbace_aot_emit_A_const_pool.A[581]; A_arbace_aot_emit_A_const_276 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[582]); A_arbace_aot_emit_A_const_277 = A_arbace_aot_emit_A_const_pool.A[583] }

func A_arbace_aot_emit_A_clinit_p21() { A_arbace_aot_emit_A_const_278 = A_arbace_aot_emit_A_const_pool.A[584]; A_arbace_aot_emit_A_const_279 = A_arbace_aot_emit_A_const_pool.A[585]; A_arbace_aot_emit_A_const_280 = A_arbace_aot_emit_A_const_pool.A[586]; A_arbace_aot_emit_A_const_281 = A_arbace_aot_emit_A_const_pool.A[587]; A_arbace_aot_emit_A_const_282 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[588]); A_arbace_aot_emit_A_const_283 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[589]); A_arbace_aot_emit_A_const_284 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[590]); A_arbace_aot_emit_A_const_285 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[591]); A_arbace_aot_emit_A_const_286 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[592]); A_arbace_aot_emit_A_const_287 = A_arbace_aot_emit_A_const_pool.A[593]; A_arbace_aot_emit_A_const_288 = A_arbace_aot_emit_A_const_pool.A[594]; A_arbace_aot_emit_A_const_289 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[595]); A_arbace_aot_emit_A_const_290 = A_arbace_aot_emit_A_const_pool.A[596]; A_arbace_aot_emit_A_const_291 = A_arbace_aot_emit_A_const_pool.A[597] }

func A_arbace_aot_emit_A_clinit_p22() { A_arbace_aot_emit_A_const_292 = A_arbace_aot_emit_A_const_pool.A[598]; A_arbace_aot_emit_A_const_293 = A_arbace_aot_emit_A_const_pool.A[599]; A_arbace_aot_emit_A_const_294 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[600]); A_arbace_aot_emit_A_const_295 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[601]); A_arbace_aot_emit_A_const_296 = A_arbace_aot_emit_A_const_pool.A[602]; A_arbace_aot_emit_A_const_297 = A_arbace_aot_emit_A_const_pool.A[603]; A_arbace_aot_emit_A_const_298 = A_arbace_aot_emit_A_const_pool.A[604]; A_arbace_aot_emit_A_const_299 = A_arbace_aot_emit_A_const_pool.A[605]; A_arbace_aot_emit_A_const_300 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[606]); A_arbace_aot_emit_A_const_301 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[607]); A_arbace_aot_emit_A_const_302 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[608]); A_arbace_aot_emit_A_const_303 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[609]); A_arbace_aot_emit_A_const_304 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[610]) }

func A_arbace_aot_emit_A_clinit_p23() { A_arbace_aot_emit_A_const_305 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[611]); A_arbace_aot_emit_A_const_306 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[612]); A_arbace_aot_emit_A_const_307 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[613]); A_arbace_aot_emit_A_const_308 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[614]); A_arbace_aot_emit_A_const_309 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[615]); A_arbace_aot_emit_A_const_310 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[616]); A_arbace_aot_emit_A_const_311 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[617]); A_arbace_aot_emit_A_const_312 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[618]); A_arbace_aot_emit_A_const_313 = A_arbace_aot_emit_A_const_pool.A[619]; A_arbace_aot_emit_A_const_314 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[620]); A_arbace_aot_emit_A_const_315 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[621]); A_arbace_aot_emit_A_const_316 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[622]) }

func A_arbace_aot_emit_A_clinit_p24() { A_arbace_aot_emit_A_const_317 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[623]); A_arbace_aot_emit_A_const_318 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[624]); A_arbace_aot_emit_A_const_319 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[625]); A_arbace_aot_emit_A_const_320 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[626]); A_arbace_aot_emit_A_const_321 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[627]); A_arbace_aot_emit_A_const_322 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[628]); A_arbace_aot_emit_A_const_323 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[629]); A_arbace_aot_emit_A_const_324 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[630]); A_arbace_aot_emit_A_const_325 = A_arbace_aot_emit_A_const_pool.A[631]; A_arbace_aot_emit_A_const_326 = A_arbace_aot_emit_A_const_pool.A[632]; A_arbace_aot_emit_A_const_327 = A_arbace_aot_emit_A_const_pool.A[633]; A_arbace_aot_emit_A_const_328 = A_arbace_aot_emit_A_const_pool.A[634]; A_arbace_aot_emit_A_const_329 = A_arbace_aot_emit_A_const_pool.A[635] }

func A_arbace_aot_emit_A_clinit_p25() { A_arbace_aot_emit_A_const_330 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[636]); A_arbace_aot_emit_A_const_331 = A_arbace_aot_emit_A_const_pool.A[637]; A_arbace_aot_emit_A_const_332 = A_arbace_aot_emit_A_const_pool.A[638]; A_arbace_aot_emit_A_const_333 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[639]); A_arbace_aot_emit_A_const_334 = A_arbace_aot_emit_A_const_pool.A[640]; A_arbace_aot_emit_A_const_335 = A_arbace_aot_emit_A_const_pool.A[641]; A_arbace_aot_emit_A_const_336 = A_arbace_aot_emit_A_const_pool.A[642]; A_arbace_aot_emit_A_const_337 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[643]); A_arbace_aot_emit_A_const_338 = A_arbace_aot_emit_A_const_pool.A[644]; A_arbace_aot_emit_A_const_339 = A_arbace_aot_emit_A_const_pool.A[645]; A_arbace_aot_emit_A_const_340 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[646]); A_arbace_aot_emit_A_const_341 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[647]); A_arbace_aot_emit_A_const_342 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[648]); A_arbace_aot_emit_A_const_343 = A_arbace_aot_emit_A_const_pool.A[649] }

func A_arbace_aot_emit_A_clinit_p26() { A_arbace_aot_emit_A_const_344 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[650]); A_arbace_aot_emit_A_const_345 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[651]); A_arbace_aot_emit_A_const_346 = A_arbace_aot_emit_A_const_pool.A[652]; A_arbace_aot_emit_A_const_347 = A_arbace_aot_emit_A_const_pool.A[653]; A_arbace_aot_emit_A_const_348 = A_arbace_aot_emit_A_const_pool.A[654]; A_arbace_aot_emit_A_const_349 = A_arbace_aot_emit_A_const_pool.A[655]; A_arbace_aot_emit_A_const_350 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[656]); A_arbace_aot_emit_A_const_351 = A_arbace_aot_emit_A_const_pool.A[657]; A_arbace_aot_emit_A_const_352 = A_arbace_aot_emit_A_const_pool.A[658]; A_arbace_aot_emit_A_const_353 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[659]); A_arbace_aot_emit_A_const_354 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[660]); A_arbace_aot_emit_A_const_355 = A_arbace_aot_emit_A_const_pool.A[661]; A_arbace_aot_emit_A_const_356 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[662]); A_arbace_aot_emit_A_const_357 = A_arbace_aot_emit_A_const_pool.A[663] }

func A_arbace_aot_emit_A_clinit_p27() { A_arbace_aot_emit_A_const_358 = A_arbace_aot_emit_A_const_pool.A[664]; A_arbace_aot_emit_A_const_359 = A_arbace_aot_emit_A_const_pool.A[665]; A_arbace_aot_emit_A_const_360 = A_arbace_aot_emit_A_const_pool.A[666]; A_arbace_aot_emit_A_const_361 = A_arbace_aot_emit_A_const_pool.A[667]; A_arbace_aot_emit_A_const_362 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[668]); A_arbace_aot_emit_A_const_363 = A_arbace_aot_emit_A_const_pool.A[669]; A_arbace_aot_emit_A_const_364 = A_arbace_aot_emit_A_const_pool.A[670]; A_arbace_aot_emit_A_const_365 = A_arbace_aot_emit_A_const_pool.A[671]; A_arbace_aot_emit_A_const_366 = A_arbace_aot_emit_A_const_pool.A[672]; A_arbace_aot_emit_A_const_367 = A_arbace_aot_emit_A_const_pool.A[673]; A_arbace_aot_emit_A_const_368 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[674]); A_arbace_aot_emit_A_const_369 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[675]); A_arbace_aot_emit_A_const_370 = A_arbace_aot_emit_A_const_pool.A[676]; A_arbace_aot_emit_A_const_371 = A_arbace_aot_emit_A_const_pool.A[677]; A_arbace_aot_emit_A_const_372 = A_arbace_aot_emit_A_const_pool.A[678] }

func A_arbace_aot_emit_A_clinit_p28() { A_arbace_aot_emit_A_const_373 = A_arbace_aot_emit_A_const_pool.A[679]; A_arbace_aot_emit_A_const_374 = A_arbace_aot_emit_A_const_pool.A[680]; A_arbace_aot_emit_A_const_375 = A_arbace_aot_emit_A_const_pool.A[681]; A_arbace_aot_emit_A_const_376 = A_arbace_aot_emit_A_const_pool.A[682]; A_arbace_aot_emit_A_const_377 = A_arbace_aot_emit_A_const_pool.A[683]; A_arbace_aot_emit_A_const_378 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[684]); A_arbace_aot_emit_A_const_379 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[685]); A_arbace_aot_emit_A_const_380 = A_arbace_aot_emit_A_const_pool.A[686]; A_arbace_aot_emit_A_const_381 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[687]); A_arbace_aot_emit_A_const_382 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[688]); A_arbace_aot_emit_A_const_383 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[689]); A_arbace_aot_emit_A_const_384 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[690]); A_arbace_aot_emit_A_const_385 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[691]) }

func A_arbace_aot_emit_A_clinit_p29() { A_arbace_aot_emit_A_const_386 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[692]); A_arbace_aot_emit_A_const_387 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[693]); A_arbace_aot_emit_A_const_388 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[694]); A_arbace_aot_emit_A_const_389 = A_arbace_aot_emit_A_const_pool.A[695]; A_arbace_aot_emit_A_const_390 = A_arbace_aot_emit_A_const_pool.A[696]; A_arbace_aot_emit_A_const_391 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[697]); A_arbace_aot_emit_A_const_392 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[698]); A_arbace_aot_emit_A_const_393 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[699]); A_arbace_aot_emit_A_const_394 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[700]); A_arbace_aot_emit_A_const_395 = A_arbace_aot_emit_A_const_pool.A[701]; A_arbace_aot_emit_A_const_396 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[702]); A_arbace_aot_emit_A_const_397 = A_arbace_aot_emit_A_const_pool.A[703]; A_arbace_aot_emit_A_const_398 = A_arbace_aot_emit_A_const_pool.A[704] }

func A_arbace_aot_emit_A_clinit_p30() { A_arbace_aot_emit_A_const_399 = A_arbace_aot_emit_A_const_pool.A[705]; A_arbace_aot_emit_A_const_400 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[706]); A_arbace_aot_emit_A_const_401 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[707]); A_arbace_aot_emit_A_const_402 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[708]); A_arbace_aot_emit_A_const_403 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[709]); A_arbace_aot_emit_A_const_404 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[710]); A_arbace_aot_emit_A_const_405 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[711]); A_arbace_aot_emit_A_const_406 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[712]); A_arbace_aot_emit_A_const_407 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[713]); A_arbace_aot_emit_A_const_408 = A_arbace_aot_emit_A_const_pool.A[714]; A_arbace_aot_emit_A_const_409 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[715]); A_arbace_aot_emit_A_const_410 = A_arbace_aot_emit_A_const_pool.A[716] }

func A_arbace_aot_emit_A_clinit_p31() { A_arbace_aot_emit_A_const_411 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[717]); A_arbace_aot_emit_A_const_412 = A_arbace_aot_emit_A_const_pool.A[718]; A_arbace_aot_emit_A_const_413 = A_arbace_aot_emit_A_const_pool.A[719]; A_arbace_aot_emit_A_const_414 = A_arbace_aot_emit_A_const_pool.A[720]; A_arbace_aot_emit_A_const_415 = A_arbace_aot_emit_A_const_pool.A[721]; A_arbace_aot_emit_A_const_416 = A_arbace_aot_emit_A_const_pool.A[722]; A_arbace_aot_emit_A_const_417 = A_arbace_aot_emit_A_const_pool.A[723]; A_arbace_aot_emit_A_const_418 = A_arbace_aot_emit_A_const_pool.A[724]; A_arbace_aot_emit_A_const_419 = A_arbace_aot_emit_A_const_pool.A[725]; A_arbace_aot_emit_A_const_420 = A_arbace_aot_emit_A_const_pool.A[726]; A_arbace_aot_emit_A_const_421 = A_arbace_aot_emit_A_const_pool.A[727]; A_arbace_aot_emit_A_const_422 = A_arbace_aot_emit_A_const_pool.A[728]; A_arbace_aot_emit_A_const_423 = A_arbace_aot_emit_A_const_pool.A[729]; A_arbace_aot_emit_A_const_424 = A_arbace_aot_emit_A_const_pool.A[730]; A_arbace_aot_emit_A_const_425 = A_arbace_aot_emit_A_const_pool.A[731] }

func A_arbace_aot_emit_A_clinit_p32() { A_arbace_aot_emit_A_const_426 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[732]); A_arbace_aot_emit_A_const_427 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[733]); A_arbace_aot_emit_A_const_428 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[734]); A_arbace_aot_emit_A_const_429 = A_arbace_aot_emit_A_const_pool.A[735]; A_arbace_aot_emit_A_const_430 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[736]); A_arbace_aot_emit_A_const_431 = A_arbace_aot_emit_A_const_pool.A[737]; A_arbace_aot_emit_A_const_432 = A_arbace_aot_emit_A_const_pool.A[738]; A_arbace_aot_emit_A_const_433 = A_arbace_aot_emit_A_const_pool.A[739]; A_arbace_aot_emit_A_const_434 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[740]); A_arbace_aot_emit_A_const_435 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[741]); A_arbace_aot_emit_A_const_436 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[742]); A_arbace_aot_emit_A_const_437 = A_arbace_aot_emit_A_const_pool.A[743]; A_arbace_aot_emit_A_const_438 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[744]) }

func A_arbace_aot_emit_A_clinit_p33() { A_arbace_aot_emit_A_const_439 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[745]); A_arbace_aot_emit_A_const_440 = A_arbace_aot_emit_A_const_pool.A[746]; A_arbace_aot_emit_A_const_441 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[747]); A_arbace_aot_emit_A_const_442 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[748]); A_arbace_aot_emit_A_const_443 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[749]); A_arbace_aot_emit_A_const_444 = A_arbace_aot_emit_A_const_pool.A[750]; A_arbace_aot_emit_A_const_445 = A_arbace_aot_emit_A_const_pool.A[751]; A_arbace_aot_emit_A_const_446 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[752]); A_arbace_aot_emit_A_const_447 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[753]); A_arbace_aot_emit_A_const_448 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[754]); A_arbace_aot_emit_A_const_449 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[755]); A_arbace_aot_emit_A_const_450 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[756]) }

func A_arbace_aot_emit_A_clinit_p34() { A_arbace_aot_emit_A_const_451 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[757]); A_arbace_aot_emit_A_const_452 = A_arbace_aot_emit_A_const_pool.A[758]; A_arbace_aot_emit_A_const_453 = A_arbace_aot_emit_A_const_pool.A[759]; A_arbace_aot_emit_A_const_454 = A_arbace_aot_emit_A_const_pool.A[760]; A_arbace_aot_emit_A_const_455 = A_arbace_aot_emit_A_const_pool.A[761]; A_arbace_aot_emit_A_const_456 = A_arbace_aot_emit_A_const_pool.A[762]; A_arbace_aot_emit_A_const_457 = A_arbace_aot_emit_A_const_pool.A[763]; A_arbace_aot_emit_A_const_458 = A_arbace_aot_emit_A_const_pool.A[764]; A_arbace_aot_emit_A_const_459 = A_arbace_aot_emit_A_const_pool.A[765]; A_arbace_aot_emit_A_const_460 = A_arbace_aot_emit_A_const_pool.A[766]; A_arbace_aot_emit_A_const_461 = A_arbace_aot_emit_A_const_pool.A[767]; A_arbace_aot_emit_A_const_462 = A_arbace_aot_emit_A_const_pool.A[768]; A_arbace_aot_emit_A_const_463 = A_arbace_aot_emit_A_const_pool.A[769]; A_arbace_aot_emit_A_const_464 = A_arbace_aot_emit_A_const_pool.A[770]; A_arbace_aot_emit_A_const_465 = A_arbace_aot_emit_A_const_pool.A[771] }

func A_arbace_aot_emit_A_clinit_p35() { A_arbace_aot_emit_A_const_466 = A_arbace_aot_emit_A_const_pool.A[772]; A_arbace_aot_emit_A_const_467 = A_arbace_aot_emit_A_const_pool.A[773]; A_arbace_aot_emit_A_const_468 = A_arbace_aot_emit_A_const_pool.A[774]; A_arbace_aot_emit_A_const_469 = A_arbace_aot_emit_A_const_pool.A[775]; A_arbace_aot_emit_A_const_470 = A_arbace_aot_emit_A_const_pool.A[776]; A_arbace_aot_emit_A_const_471 = A_arbace_aot_emit_A_const_pool.A[777]; A_arbace_aot_emit_A_const_472 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[778]); A_arbace_aot_emit_A_const_473 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[779]); A_arbace_aot_emit_A_const_474 = A_arbace_aot_emit_A_const_pool.A[780]; A_arbace_aot_emit_A_const_475 = A_arbace_aot_emit_A_const_pool.A[781]; A_arbace_aot_emit_A_const_476 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[782]); A_arbace_aot_emit_A_const_477 = A_arbace_aot_emit_A_const_pool.A[783]; A_arbace_aot_emit_A_const_478 = A_arbace_aot_emit_A_const_pool.A[784]; A_arbace_aot_emit_A_const_479 = A_arbace_aot_emit_A_const_pool.A[785]; A_arbace_aot_emit_A_const_480 = A_arbace_aot_emit_A_const_pool.A[786] }

func A_arbace_aot_emit_A_clinit_p36() { A_arbace_aot_emit_A_const_481 = A_arbace_aot_emit_A_const_pool.A[787]; A_arbace_aot_emit_A_const_482 = A_arbace_aot_emit_A_const_pool.A[788]; A_arbace_aot_emit_A_const_483 = A_arbace_aot_emit_A_const_pool.A[789]; A_arbace_aot_emit_A_const_484 = A_arbace_aot_emit_A_const_pool.A[790]; A_arbace_aot_emit_A_const_485 = A_arbace_aot_emit_A_const_pool.A[791]; A_arbace_aot_emit_A_const_486 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[792]); A_arbace_aot_emit_A_const_487 = A_arbace_aot_emit_A_const_pool.A[793]; A_arbace_aot_emit_A_const_488 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[794]); A_arbace_aot_emit_A_const_489 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[795]); A_arbace_aot_emit_A_const_490 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[796]); A_arbace_aot_emit_A_const_491 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[797]); A_arbace_aot_emit_A_const_492 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[798]); A_arbace_aot_emit_A_const_493 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[799]) }

func A_arbace_aot_emit_A_clinit_p37() { A_arbace_aot_emit_A_const_494 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[800]); A_arbace_aot_emit_A_const_495 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[801]); A_arbace_aot_emit_A_const_496 = A_arbace_aot_emit_A_const_pool.A[802]; A_arbace_aot_emit_A_const_497 = A_arbace_aot_emit_A_const_pool.A[803]; A_arbace_aot_emit_A_const_498 = A_arbace_aot_emit_A_const_pool.A[804]; A_arbace_aot_emit_A_const_499 = A_arbace_aot_emit_A_const_pool.A[805]; A_arbace_aot_emit_A_const_500 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[806]); A_arbace_aot_emit_A_const_501 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[807]); A_arbace_aot_emit_A_const_502 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[808]); A_arbace_aot_emit_A_const_503 = A_arbace_aot_emit_A_const_pool.A[809]; A_arbace_aot_emit_A_const_504 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[810]); A_arbace_aot_emit_A_const_505 = A_arbace_aot_emit_A_const_pool.A[811]; A_arbace_aot_emit_A_const_506 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[812]) }

func A_arbace_aot_emit_A_clinit_p38() { A_arbace_aot_emit_A_const_507 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[813]); A_arbace_aot_emit_A_const_508 = A_arbace_aot_emit_A_const_pool.A[814]; A_arbace_aot_emit_A_const_509 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[815]); A_arbace_aot_emit_A_const_510 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[816]); A_arbace_aot_emit_A_const_511 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[817]); A_arbace_aot_emit_A_const_512 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[818]); A_arbace_aot_emit_A_const_513 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[819]); A_arbace_aot_emit_A_const_514 = A_arbace_aot_emit_A_const_pool.A[820]; A_arbace_aot_emit_A_const_515 = A_arbace_aot_emit_A_const_pool.A[821]; A_arbace_aot_emit_A_const_516 = A_arbace_aot_emit_A_const_pool.A[822]; A_arbace_aot_emit_A_const_517 = A_arbace_aot_emit_A_const_pool.A[823]; A_arbace_aot_emit_A_const_518 = A_arbace_aot_emit_A_const_pool.A[824]; A_arbace_aot_emit_A_const_519 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[825]) }

func A_arbace_aot_emit_A_clinit_p39() { A_arbace_aot_emit_A_const_520 = A_arbace_aot_emit_A_const_pool.A[826]; A_arbace_aot_emit_A_const_521 = A_arbace_aot_emit_A_const_pool.A[827]; A_arbace_aot_emit_A_const_522 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[828]); A_arbace_aot_emit_A_const_523 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[829]); A_arbace_aot_emit_A_const_524 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[830]); A_arbace_aot_emit_A_const_525 = A_arbace_aot_emit_A_const_pool.A[831]; A_arbace_aot_emit_A_const_526 = A_arbace_aot_emit_A_const_pool.A[832]; A_arbace_aot_emit_A_const_527 = A_arbace_aot_emit_A_const_pool.A[833]; A_arbace_aot_emit_A_const_528 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[834]); A_arbace_aot_emit_A_const_529 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[835]); A_arbace_aot_emit_A_const_530 = A_arbace_aot_emit_A_const_pool.A[836]; A_arbace_aot_emit_A_const_531 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[837]); A_arbace_aot_emit_A_const_532 = A_arbace_aot_emit_A_const_pool.A[838]; A_arbace_aot_emit_A_const_533 = A_arbace_aot_emit_A_const_pool.A[839] }

func A_arbace_aot_emit_A_clinit_p40() { A_arbace_aot_emit_A_const_534 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[840]); A_arbace_aot_emit_A_const_535 = A_arbace_aot_emit_A_const_pool.A[841]; A_arbace_aot_emit_A_const_536 = A_arbace_aot_emit_A_const_pool.A[842]; A_arbace_aot_emit_A_const_537 = A_arbace_aot_emit_A_const_pool.A[843]; A_arbace_aot_emit_A_const_538 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[844]); A_arbace_aot_emit_A_const_539 = A_arbace_aot_emit_A_const_pool.A[845]; A_arbace_aot_emit_A_const_540 = A_arbace_aot_emit_A_const_pool.A[846]; A_arbace_aot_emit_A_const_541 = A_arbace_aot_emit_A_const_pool.A[847]; A_arbace_aot_emit_A_const_542 = A_arbace_aot_emit_A_const_pool.A[848]; A_arbace_aot_emit_A_const_543 = A_arbace_aot_emit_A_const_pool.A[849]; A_arbace_aot_emit_A_const_544 = A_arbace_aot_emit_A_const_pool.A[850]; A_arbace_aot_emit_A_const_545 = A_arbace_aot_emit_A_const_pool.A[851]; A_arbace_aot_emit_A_const_546 = A_arbace_aot_emit_A_const_pool.A[852]; A_arbace_aot_emit_A_const_547 = A_arbace_aot_emit_A_const_pool.A[853]; A_arbace_aot_emit_A_const_548 = A_arbace_aot_emit_A_const_pool.A[854] }

func A_arbace_aot_emit_A_clinit_p41() { A_arbace_aot_emit_A_const_549 = A_arbace_aot_emit_A_const_pool.A[855]; A_arbace_aot_emit_A_const_550 = A_arbace_aot_emit_A_const_pool.A[856]; A_arbace_aot_emit_A_const_551 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[857]); A_arbace_aot_emit_A_const_552 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[858]); A_arbace_aot_emit_A_const_553 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[859]); A_arbace_aot_emit_A_const_554 = A_arbace_aot_emit_A_const_pool.A[860]; A_arbace_aot_emit_A_const_555 = A_arbace_aot_emit_A_const_pool.A[861]; A_arbace_aot_emit_A_const_556 = A_arbace_aot_emit_A_const_pool.A[862]; A_arbace_aot_emit_A_const_557 = A_arbace_aot_emit_A_const_pool.A[863]; A_arbace_aot_emit_A_const_558 = A_arbace_aot_emit_A_const_pool.A[864]; A_arbace_aot_emit_A_const_559 = A_arbace_aot_emit_A_const_pool.A[865]; A_arbace_aot_emit_A_const_560 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[866]); A_arbace_aot_emit_A_const_561 = A_arbace_aot_emit_A_const_pool.A[867]; A_arbace_aot_emit_A_const_562 = A_arbace_aot_emit_A_const_pool.A[868] }

func A_arbace_aot_emit_A_clinit_p42() { A_arbace_aot_emit_A_const_563 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[869]); A_arbace_aot_emit_A_const_564 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[870]); A_arbace_aot_emit_A_const_565 = A_arbace_aot_emit_A_const_pool.A[871]; A_arbace_aot_emit_A_const_566 = A_arbace_aot_emit_A_const_pool.A[872]; A_arbace_aot_emit_A_const_567 = A_arbace_aot_emit_A_const_pool.A[873]; A_arbace_aot_emit_A_const_568 = A_arbace_aot_emit_A_const_pool.A[874]; A_arbace_aot_emit_A_const_569 = A_arbace_aot_emit_A_const_pool.A[875]; A_arbace_aot_emit_A_const_570 = A_arbace_aot_emit_A_const_pool.A[876]; A_arbace_aot_emit_A_const_571 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[877]); A_arbace_aot_emit_A_const_572 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[878]); A_arbace_aot_emit_A_const_573 = A_arbace_aot_emit_A_const_pool.A[879]; A_arbace_aot_emit_A_const_574 = A_arbace_aot_emit_A_const_pool.A[880]; A_arbace_aot_emit_A_const_575 = A_arbace_aot_emit_A_const_pool.A[881]; A_arbace_aot_emit_A_const_576 = A_arbace_aot_emit_A_const_pool.A[882] }

func A_arbace_aot_emit_A_clinit_p43() { A_arbace_aot_emit_A_const_577 = A_arbace_aot_emit_A_const_pool.A[883]; A_arbace_aot_emit_A_const_578 = A_arbace_aot_emit_A_const_pool.A[884]; A_arbace_aot_emit_A_const_579 = A_arbace_aot_emit_A_const_pool.A[885]; A_arbace_aot_emit_A_const_580 = A_arbace_aot_emit_A_const_pool.A[886]; A_arbace_aot_emit_A_const_581 = A_arbace_aot_emit_A_const_pool.A[887]; A_arbace_aot_emit_A_const_582 = A_arbace_aot_emit_A_const_pool.A[888]; A_arbace_aot_emit_A_const_583 = A_arbace_aot_emit_A_const_pool.A[889]; A_arbace_aot_emit_A_const_584 = A_arbace_aot_emit_A_const_pool.A[890]; A_arbace_aot_emit_A_const_585 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[891]); A_arbace_aot_emit_A_const_586 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[892]); A_arbace_aot_emit_A_const_587 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[893]); A_arbace_aot_emit_A_const_588 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[894]); A_arbace_aot_emit_A_const_589 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[895]); A_arbace_aot_emit_A_const_590 = A_arbace_aot_emit_A_const_pool.A[896] }

func A_arbace_aot_emit_A_clinit_p44() { A_arbace_aot_emit_A_const_591 = A_arbace_aot_emit_A_const_pool.A[897]; A_arbace_aot_emit_A_const_592 = A_arbace_aot_emit_A_const_pool.A[898]; A_arbace_aot_emit_A_const_593 = A_arbace_aot_emit_A_const_pool.A[899]; A_arbace_aot_emit_A_const_594 = A_arbace_aot_emit_A_const_pool.A[900]; A_arbace_aot_emit_A_const_595 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[901]); A_arbace_aot_emit_A_const_596 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[902]); A_arbace_aot_emit_A_const_597 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[903]); A_arbace_aot_emit_A_const_598 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[904]); A_arbace_aot_emit_A_const_599 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[905]); A_arbace_aot_emit_A_const_600 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[906]); A_arbace_aot_emit_A_const_601 = A_arbace_aot_emit_A_const_pool.A[907]; A_arbace_aot_emit_A_const_602 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[908]); A_arbace_aot_emit_A_const_603 = A_arbace_aot_emit_A_const_pool.A[909] }

func A_arbace_aot_emit_A_clinit_p45() { A_arbace_aot_emit_A_const_604 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[910]); A_arbace_aot_emit_A_const_605 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[911]); A_arbace_aot_emit_A_const_606 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[912]); A_arbace_aot_emit_A_const_607 = A_arbace_aot_emit_A_const_pool.A[913]; A_arbace_aot_emit_A_const_608 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[914]); A_arbace_aot_emit_A_const_609 = A_arbace_aot_emit_A_const_pool.A[915]; A_arbace_aot_emit_A_const_610 = A_arbace_aot_emit_A_const_pool.A[916]; A_arbace_aot_emit_A_const_611 = A_arbace_aot_emit_A_const_pool.A[917]; A_arbace_aot_emit_A_const_612 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[918]); A_arbace_aot_emit_A_const_613 = A_arbace_aot_emit_A_const_pool.A[919]; A_arbace_aot_emit_A_const_614 = A_arbace_aot_emit_A_const_pool.A[920]; A_arbace_aot_emit_A_const_615 = A_arbace_aot_emit_A_const_pool.A[921]; A_arbace_aot_emit_A_const_616 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[922]) }

func A_arbace_aot_emit_A_clinit_p46() { A_arbace_aot_emit_A_const_617 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[923]); A_arbace_aot_emit_A_const_618 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[924]); A_arbace_aot_emit_A_const_619 = A_arbace_aot_emit_A_const_pool.A[925]; A_arbace_aot_emit_A_const_620 = A_arbace_aot_emit_A_const_pool.A[926]; A_arbace_aot_emit_A_const_621 = A_arbace_aot_emit_A_const_pool.A[927]; A_arbace_aot_emit_A_const_622 = A_arbace_aot_emit_A_const_pool.A[928]; A_arbace_aot_emit_A_const_623 = A_arbace_aot_emit_A_const_pool.A[929]; A_arbace_aot_emit_A_const_624 = A_arbace_aot_emit_A_const_pool.A[930]; A_arbace_aot_emit_A_const_625 = A_arbace_aot_emit_A_const_pool.A[931]; A_arbace_aot_emit_A_const_626 = A_arbace_aot_emit_A_const_pool.A[932]; A_arbace_aot_emit_A_const_627 = A_arbace_aot_emit_A_const_pool.A[933]; A_arbace_aot_emit_A_const_628 = A_arbace_aot_emit_A_const_pool.A[934]; A_arbace_aot_emit_A_const_629 = A_arbace_aot_emit_A_const_pool.A[935]; A_arbace_aot_emit_A_const_630 = A_arbace_aot_emit_A_const_pool.A[936]; A_arbace_aot_emit_A_const_631 = A_arbace_aot_emit_A_const_pool.A[937] }

func A_arbace_aot_emit_A_clinit_p47() { A_arbace_aot_emit_A_const_632 = A_arbace_aot_emit_A_const_pool.A[938]; A_arbace_aot_emit_A_const_633 = A_arbace_aot_emit_A_const_pool.A[939]; A_arbace_aot_emit_A_const_634 = A_arbace_aot_emit_A_const_pool.A[940]; A_arbace_aot_emit_A_const_635 = A_arbace_aot_emit_A_const_pool.A[941]; A_arbace_aot_emit_A_const_636 = A_arbace_aot_emit_A_const_pool.A[942]; A_arbace_aot_emit_A_const_637 = A_arbace_aot_emit_A_const_pool.A[943]; A_arbace_aot_emit_A_const_638 = A_arbace_aot_emit_A_const_pool.A[944]; A_arbace_aot_emit_A_const_639 = A_arbace_aot_emit_A_const_pool.A[945]; A_arbace_aot_emit_A_const_640 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[946]); A_arbace_aot_emit_A_const_641 = A_arbace_aot_emit_A_const_pool.A[947]; A_arbace_aot_emit_A_const_642 = A_arbace_aot_emit_A_const_pool.A[948]; A_arbace_aot_emit_A_const_643 = A_arbace_aot_emit_A_const_pool.A[949]; A_arbace_aot_emit_A_const_644 = A_arbace_aot_emit_A_const_pool.A[950]; A_arbace_aot_emit_A_const_645 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[951]); A_arbace_aot_emit_A_const_646 = A_arbace_aot_emit_A_const_pool.A[952] }

func A_arbace_aot_emit_A_clinit_p48() { A_arbace_aot_emit_A_const_647 = A_arbace_aot_emit_A_const_pool.A[953]; A_arbace_aot_emit_A_const_648 = A_arbace_aot_emit_A_const_pool.A[954]; A_arbace_aot_emit_A_const_649 = A_arbace_aot_emit_A_const_pool.A[955]; A_arbace_aot_emit_A_const_650 = A_arbace_aot_emit_A_const_pool.A[956]; A_arbace_aot_emit_A_const_651 = A_arbace_aot_emit_A_const_pool.A[957]; A_arbace_aot_emit_A_const_652 = A_arbace_aot_emit_A_const_pool.A[958]; A_arbace_aot_emit_A_const_653 = A_arbace_aot_emit_A_const_pool.A[959]; A_arbace_aot_emit_A_const_654 = A_arbace_aot_emit_A_const_pool.A[960]; A_arbace_aot_emit_A_const_655 = A_arbace_aot_emit_A_const_pool.A[961]; A_arbace_aot_emit_A_const_656 = A_arbace_aot_emit_A_const_pool.A[962]; A_arbace_aot_emit_A_const_657 = A_arbace_aot_emit_A_const_pool.A[963]; A_arbace_aot_emit_A_const_658 = A_arbace_aot_emit_A_const_pool.A[964]; A_arbace_aot_emit_A_const_659 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[965]); A_arbace_aot_emit_A_const_660 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[966]); A_arbace_aot_emit_A_const_661 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[967]) }

func A_arbace_aot_emit_A_clinit_p49() { A_arbace_aot_emit_A_const_662 = A_arbace_aot_emit_A_const_pool.A[968]; A_arbace_aot_emit_A_const_663 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[969]); A_arbace_aot_emit_A_const_664 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[970]); A_arbace_aot_emit_A_const_665 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[971]); A_arbace_aot_emit_A_const_666 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[972]); A_arbace_aot_emit_A_const_667 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[973]); A_arbace_aot_emit_A_const_668 = A_arbace_aot_emit_A_const_pool.A[974]; A_arbace_aot_emit_A_const_669 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[975]); A_arbace_aot_emit_A_const_670 = A_arbace_aot_emit_A_const_pool.A[976]; A_arbace_aot_emit_A_const_671 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[977]); A_arbace_aot_emit_A_const_672 = A_arbace_aot_emit_A_const_pool.A[978]; A_arbace_aot_emit_A_const_673 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[979]); A_arbace_aot_emit_A_const_674 = A_arbace_aot_emit_A_const_pool.A[980] }

func A_arbace_aot_emit_A_clinit_p50() { A_arbace_aot_emit_A_const_675 = A_arbace_aot_emit_A_const_pool.A[981]; A_arbace_aot_emit_A_const_676 = A_arbace_aot_emit_A_const_pool.A[982]; A_arbace_aot_emit_A_const_677 = A_arbace_aot_emit_A_const_pool.A[983]; A_arbace_aot_emit_A_const_678 = A_arbace_aot_emit_A_const_pool.A[984]; A_arbace_aot_emit_A_const_679 = A_arbace_aot_emit_A_const_pool.A[985]; A_arbace_aot_emit_A_const_680 = A_arbace_aot_emit_A_const_pool.A[986]; A_arbace_aot_emit_A_const_681 = A_arbace_aot_emit_A_const_pool.A[987]; A_arbace_aot_emit_A_const_682 = A_arbace_aot_emit_A_const_pool.A[988]; A_arbace_aot_emit_A_const_683 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[989]); A_arbace_aot_emit_A_const_684 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[990]); A_arbace_aot_emit_A_const_685 = A_arbace_aot_emit_A_const_pool.A[991]; A_arbace_aot_emit_A_const_686 = A_arbace_aot_emit_A_const_pool.A[992]; A_arbace_aot_emit_A_const_687 = A_arbace_aot_emit_A_const_pool.A[993]; A_arbace_aot_emit_A_const_688 = A_arbace_aot_emit_A_const_pool.A[994]; A_arbace_aot_emit_A_const_689 = A_arbace_aot_emit_A_const_pool.A[995] }

func A_arbace_aot_emit_A_clinit_p51() { A_arbace_aot_emit_A_const_690 = A_arbace_aot_emit_A_const_pool.A[996]; A_arbace_aot_emit_A_const_691 = A_arbace_aot_emit_A_const_pool.A[997]; A_arbace_aot_emit_A_const_692 = A_arbace_aot_emit_A_const_pool.A[998]; A_arbace_aot_emit_A_const_693 = A_arbace_aot_emit_A_const_pool.A[999]; A_arbace_aot_emit_A_const_694 = A_arbace_aot_emit_A_const_pool.A[1000]; A_arbace_aot_emit_A_const_695 = A_arbace_aot_emit_A_const_pool.A[1001]; A_arbace_aot_emit_A_const_696 = A_arbace_aot_emit_A_const_pool.A[1002]; A_arbace_aot_emit_A_const_697 = A_arbace_aot_emit_A_const_pool.A[1003]; A_arbace_aot_emit_A_const_698 = A_arbace_aot_emit_A_const_pool.A[1004]; A_arbace_aot_emit_A_const_699 = A_arbace_aot_emit_A_const_pool.A[1005]; A_arbace_aot_emit_A_const_700 = A_arbace_aot_emit_A_const_pool.A[1006]; A_arbace_aot_emit_A_const_701 = A_arbace_aot_emit_A_const_pool.A[1007]; A_arbace_aot_emit_A_const_702 = A_arbace_aot_emit_A_const_pool.A[1008]; A_arbace_aot_emit_A_const_703 = A_arbace_aot_emit_A_const_pool.A[1009]; A_arbace_aot_emit_A_const_704 = A_arbace_aot_emit_A_const_pool.A[1010]; A_arbace_aot_emit_A_const_705 = A_arbace_aot_emit_A_const_pool.A[1011] }

func A_arbace_aot_emit_A_clinit_p52() { A_arbace_aot_emit_A_const_706 = A_arbace_aot_emit_A_const_pool.A[1012]; A_arbace_aot_emit_A_const_707 = A_arbace_aot_emit_A_const_pool.A[1013]; A_arbace_aot_emit_A_const_708 = A_arbace_aot_emit_A_const_pool.A[1014]; A_arbace_aot_emit_A_const_709 = A_arbace_aot_emit_A_const_pool.A[1015]; A_arbace_aot_emit_A_const_710 = A_arbace_aot_emit_A_const_pool.A[1016]; A_arbace_aot_emit_A_const_711 = A_arbace_aot_emit_A_const_pool.A[1017]; A_arbace_aot_emit_A_const_712 = A_arbace_aot_emit_A_const_pool.A[1018]; A_arbace_aot_emit_A_const_713 = A_arbace_aot_emit_A_const_pool.A[1019]; A_arbace_aot_emit_A_const_714 = A_arbace_aot_emit_A_const_pool.A[1020]; A_arbace_aot_emit_A_const_715 = A_arbace_aot_emit_A_const_pool.A[1021]; A_arbace_aot_emit_A_const_716 = A_arbace_aot_emit_A_const_pool.A[1022]; A_arbace_aot_emit_A_const_717 = A_arbace_aot_emit_A_const_pool.A[1023]; A_arbace_aot_emit_A_const_718 = A_arbace_aot_emit_A_const_pool.A[1024]; A_arbace_aot_emit_A_const_719 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[1025]); A_arbace_aot_emit_A_const_720 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[1026]) }

func A_arbace_aot_emit_A_clinit_p53() { A_arbace_aot_emit_A_const_721 = A_arbace_aot_emit_A_const_pool.A[1027]; A_arbace_aot_emit_A_const_722 = A_arbace_aot_emit_A_const_pool.A[1028]; A_arbace_aot_emit_A_const_723 = A_arbace_aot_emit_A_const_pool.A[1029]; A_arbace_aot_emit_A_const_724 = A_arbace_aot_emit_A_const_pool.A[1030]; A_arbace_aot_emit_A_const_725 = A_arbace_aot_emit_A_const_pool.A[1031]; A_arbace_aot_emit_A_const_726 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[1032]); A_arbace_aot_emit_A_const_727 = A_arbace_aot_emit_A_const_pool.A[1033]; A_arbace_aot_emit_A_const_728 = A_arbace_aot_emit_A_const_pool.A[1034]; A_arbace_aot_emit_A_const_729 = A_arbace_aot_emit_A_const_pool.A[1035]; A_arbace_aot_emit_A_const_730 = A_arbace_aot_emit_A_const_pool.A[1036]; A_arbace_aot_emit_A_const_731 = A_arbace_aot_emit_A_const_pool.A[1037]; A_arbace_aot_emit_A_const_732 = A_arbace_aot_emit_A_const_pool.A[1038]; A_arbace_aot_emit_A_const_733 = A_arbace_aot_emit_A_const_pool.A[1039]; A_arbace_aot_emit_A_const_734 = A_arbace_aot_emit_A_const_pool.A[1040]; A_arbace_aot_emit_A_const_735 = A_arbace_aot_emit_A_const_pool.A[1041] }

func A_arbace_aot_emit_A_clinit_p54() { A_arbace_aot_emit_A_const_736 = A_arbace_aot_emit_A_const_pool.A[1042]; A_arbace_aot_emit_A_const_737 = A_arbace_aot_emit_A_const_pool.A[1043]; A_arbace_aot_emit_A_const_738 = A_arbace_aot_emit_A_const_pool.A[1044]; A_arbace_aot_emit_A_const_739 = A_arbace_aot_emit_A_const_pool.A[1045]; A_arbace_aot_emit_A_const_740 = A_arbace_aot_emit_A_const_pool.A[1046]; A_arbace_aot_emit_A_const_741 = A_arbace_aot_emit_A_const_pool.A[1047]; A_arbace_aot_emit_A_const_742 = A_arbace_aot_emit_A_const_pool.A[1048]; A_arbace_aot_emit_A_const_743 = A_arbace_aot_emit_A_const_pool.A[1049]; A_arbace_aot_emit_A_const_744 = A_arbace_aot_emit_A_const_pool.A[1050]; A_arbace_aot_emit_A_const_745 = A_arbace_aot_emit_A_const_pool.A[1051]; A_arbace_aot_emit_A_const_746 = A_arbace_aot_emit_A_const_pool.A[1052]; A_arbace_aot_emit_A_const_747 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[1053]); A_arbace_aot_emit_A_const_748 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[1054]); A_arbace_aot_emit_A_const_749 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[1055]) }

func A_arbace_aot_emit_A_clinit_p55() { A_arbace_aot_emit_A_const_750 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[1056]); A_arbace_aot_emit_A_const_751 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[1057]); A_arbace_aot_emit_A_const_752 = A_arbace_aot_emit_A_const_pool.A[1058]; A_arbace_aot_emit_A_const_753 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[1059]); A_arbace_aot_emit_A_const_754 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[1060]); A_arbace_aot_emit_A_const_755 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[1061]); A_arbace_aot_emit_A_const_756 = A_arbace_aot_emit_A_const_pool.A[1062]; A_arbace_aot_emit_A_const_757 = A_arbace_aot_emit_A_const_pool.A[1063]; A_arbace_aot_emit_A_const_758 = A_arbace_aot_emit_A_const_pool.A[1064]; A_arbace_aot_emit_A_const_759 = A_arbace_aot_emit_A_const_pool.A[1065]; A_arbace_aot_emit_A_const_760 = A_arbace_aot_emit_A_const_pool.A[1066]; A_arbace_aot_emit_A_const_761 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[1067]); A_arbace_aot_emit_A_const_762 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[1068]) }

func A_arbace_aot_emit_A_clinit_p56() { A_arbace_aot_emit_A_const_763 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[1069]); A_arbace_aot_emit_A_const_764 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[1070]); A_arbace_aot_emit_A_const_765 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[1071]); A_arbace_aot_emit_A_const_766 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[1072]); A_arbace_aot_emit_A_const_767 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[1073]); A_arbace_aot_emit_A_const_768 = A_arbace_aot_emit_A_const_pool.A[1074]; A_arbace_aot_emit_A_const_769 = A_arbace_aot_emit_A_const_pool.A[1075]; A_arbace_aot_emit_A_const_770 = A_arbace_aot_emit_A_const_pool.A[1076]; A_arbace_aot_emit_A_const_771 = A_arbace_aot_emit_A_const_pool.A[1077]; A_arbace_aot_emit_A_const_772 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[1078]); A_arbace_aot_emit_A_const_773 = A_arbace_aot_emit_A_const_pool.A[1079]; A_arbace_aot_emit_A_const_774 = A_arbace_aot_emit_A_const_pool.A[1080]; A_arbace_aot_emit_A_const_775 = lang.Keyword_Cast(A_arbace_aot_emit_A_const_pool.A[1081]) }

func A_arbace_aot_emit_A_clinit_p57() { A_arbace_aot_emit_A_const_776 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[1082]); A_arbace_aot_emit_A_const_777 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[1083]); A_arbace_aot_emit_A_const_778 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[1084]); A_arbace_aot_emit_A_const_779 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[1085]); A_arbace_aot_emit_A_const_780 = lang.Var_Cast(A_arbace_aot_emit_A_const_pool.A[1086]); A_arbace_aot_emit_A_const_781 = A_arbace_aot_emit_A_const_pool.A[1087]; A_arbace_aot_emit_A_const_782 = A_arbace_aot_emit_A_const_pool.A[1088]; A_arbace_aot_emit_A_const_783 = A_arbace_aot_emit_A_const_pool.A[1089]; A_arbace_aot_emit_A_const_784 = A_arbace_aot_emit_A_const_pool.A[1090] }

func A_arbace_aot_emit_A_New() *A_arbace_aot_emit_A { A_arbace_aot_emit_A_Init(); t := &A_arbace_aot_emit_A{}; t.Ctor(); return t }

func (t *A_arbace_aot_emit_A) Ctor() {}

func (t *A_arbace_aot_emit_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_emit_A) GetClass__Class() *jrt.Class { return A_arbace_aot_emit_A_class }

func (t *A_arbace_aot_emit_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_emit_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_emit_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_emit_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_emit_A); return ok }

func A_arbace_aot_emit_A_Cast(x any) *A_arbace_aot_emit_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_emit_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_emit_A_class)) }; return v }



type A_arbace_aot_emit_body_instance_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_body_instance_A_fn_class *jrt.Class



type A_arbace_aot_emit_body_instance_iter__90000175__90000179_A struct{ a2g_header uint64; F_ctx, F_nil_locals any }

var A_arbace_aot_emit_body_instance_iter__90000175__90000179_A_fn_class *jrt.Class



type A_arbace_aot_emit_body_instance_iter__90000175__90000179_fn__90000180_A struct{ a2g_header uint64; F_ctx, F_s__90000176, F_iter__90000175, F_nil_locals any }

var A_arbace_aot_emit_body_instance_iter__90000175__90000179_fn__90000180_A_fn_class *jrt.Class



type A_arbace_aot_emit_body_instance_iter__90000175__90000179_fn__90000180_fn__90000181_A struct{ a2g_header uint64; F_ctx, F_nil_locals, F_b__90000178 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_aot_emit_body_instance_iter__90000175__90000179_fn__90000180_fn__90000181_A_fn_class *jrt.Class



type A_arbace_aot_emit_box_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_box_A_fn_class *jrt.Class



type A_arbace_aot_emit_box_class_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_box_class_A_fn_class *jrt.Class



type A_arbace_aot_emit_box_prim_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_box_prim_A_fn_class *jrt.Class



type A_arbace_aot_emit_can_prim_QMARK__A struct{ a2g_header uint64 }

var A_arbace_aot_emit_can_prim_QMARK__A_fn_class *jrt.Class



type A_arbace_aot_emit_char_form_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_char_form_A_fn_class *jrt.Class



type A_arbace_aot_emit_class_form_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_class_form_A_fn_class *jrt.Class



type A_arbace_aot_emit_class_form_fn__90000530_A struct{ a2g_header uint64; F_pools, F_children_of any }

var A_arbace_aot_emit_class_form_fn__90000530_A_fn_class *jrt.Class



type A_arbace_aot_emit_class_form_mods__90000532_A struct{ a2g_header uint64; F_c, F_top_QMARK_ any }

var A_arbace_aot_emit_class_form_mods__90000532_A_fn_class *jrt.Class



type A_arbace_aot_emit_class_forms_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_class_forms_A_fn_class *jrt.Class



type A_arbace_aot_emit_class_forms_children_of__90000553_A struct{ a2g_header uint64; F_kids, F_recs any }

var A_arbace_aot_emit_class_forms_children_of__90000553_A_fn_class *jrt.Class



type A_arbace_aot_emit_class_forms_fn__90000539_A struct{ a2g_header uint64; F_names, F_parent any }

var A_arbace_aot_emit_class_forms_fn__90000539_A_fn_class *jrt.Class



type A_arbace_aot_emit_class_forms_fn__90000551_A struct{ a2g_header uint64; F_recs any }

var A_arbace_aot_emit_class_forms_fn__90000551_A_fn_class *jrt.Class



type A_arbace_aot_emit_class_forms_iter__90000541__90000545_A struct{ a2g_header uint64; F_classes any }

var A_arbace_aot_emit_class_forms_iter__90000541__90000545_A_fn_class *jrt.Class



type A_arbace_aot_emit_class_forms_iter__90000541__90000545_fn__90000546_A struct{ a2g_header uint64; F_classes, F_s__90000542, F_iter__90000541 any }

var A_arbace_aot_emit_class_forms_iter__90000541__90000545_fn__90000546_A_fn_class *jrt.Class



type A_arbace_aot_emit_class_forms_iter__90000541__90000545_fn__90000546_fn__90000547_A struct{ a2g_header uint64; F_classes, F_b__90000544 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_aot_emit_class_forms_iter__90000541__90000545_fn__90000546_fn__90000547_A_fn_class *jrt.Class



type A_arbace_aot_emit_class_forms_iter__90000555__90000559_A struct{ a2g_header uint64; F_children_of, F_pools, F_recs any }

var A_arbace_aot_emit_class_forms_iter__90000555__90000559_A_fn_class *jrt.Class



type A_arbace_aot_emit_class_forms_iter__90000555__90000559_fn__90000560_A struct{ a2g_header uint64; F_children_of, F_s__90000556, F_iter__90000555, F_pools, F_recs any }

var A_arbace_aot_emit_class_forms_iter__90000555__90000559_fn__90000560_A_fn_class *jrt.Class



type A_arbace_aot_emit_class_forms_iter__90000555__90000559_fn__90000560_fn__90000561_A struct{ a2g_header uint64; F_children_of, F_pools, F_b__90000558 any; F_size__1927001038__auto__ int32; F_recs, F_c__1927001037__auto__ any }

var A_arbace_aot_emit_class_forms_iter__90000555__90000559_fn__90000560_fn__90000561_A_fn_class *jrt.Class



type A_arbace_aot_emit_class_forms_parent__90000537_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_class_forms_parent__90000537_A_fn_class *jrt.Class



type A_arbace_aot_emit_class_interfaces_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_class_interfaces_A_fn_class *jrt.Class



type A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_A struct{ a2g_header uint64; F_ctx, F_ox any }

var A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_A_fn_class *jrt.Class



type A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_fn__90000303_A struct{ a2g_header uint64; F_ctx, F_ox, F_s__90000299, F_iter__90000298 any }

var A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_fn__90000303_A_fn_class *jrt.Class



type A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_fn__90000303_fn__90000304_A struct{ a2g_header uint64; F_ctx, F_ox, F_b__90000301 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_aot_emit_class_interfaces_iter__90000298__90000302_fn__90000303_fn__90000304_A_fn_class *jrt.Class



type A_arbace_aot_emit_closed_QMARK__A struct{ a2g_header uint64 }

var A_arbace_aot_emit_closed_QMARK__A_fn_class *jrt.Class



type A_arbace_aot_emit_coll_call_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_coll_call_A_fn_class *jrt.Class



type A_arbace_aot_emit_compiled_interface_QMARK__A struct{ a2g_header uint64 }

var A_arbace_aot_emit_compiled_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_aot_emit_const_field_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_const_field_A_fn_class *jrt.Class



type A_arbace_aot_emit_const_type_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_const_type_A_fn_class *jrt.Class



type A_arbace_aot_emit_constant_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_constant_A_fn_class *jrt.Class



type A_arbace_aot_emit_deep_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_deep_A_fn_class *jrt.Class



type A_arbace_aot_emit_descriptor_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_descriptor_A_fn_class *jrt.Class



type A_arbace_aot_emit_destub_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_destub_A_fn_class *jrt.Class



type A_arbace_aot_emit_double_form_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_double_form_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn__90000263_A struct{ a2g_header uint64; F_ctx any }

var A_arbace_aot_emit_emit_fn__90000263_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn__90000265_A struct{ a2g_header uint64; F_ctx any }

var A_arbace_aot_emit_emit_fn__90000265_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn__90000267_A struct{ a2g_header uint64; F_ctx any }

var A_arbace_aot_emit_emit_fn__90000267_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_assign_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_assign_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_binding_init_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_binding_init_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_case_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_case_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_case_arm__90000245_A struct{ a2g_header uint64; F_e, F_mask, F_ctx, F_lbl, F_n, F_skip any; F_int_test_QMARK_ bool; F_ret, F_pt any }

var A_arbace_aot_emit_emit_case_arm__90000245_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_case_fn__90000248_A struct{ a2g_header uint64; F_arm, F_thens any }

var A_arbace_aot_emit_emit_case_fn__90000248_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_case_fn__90000254_A struct{ a2g_header uint64; F_arm, F_thens any }

var A_arbace_aot_emit_emit_case_fn__90000254_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_case_ret__90000243_A struct{ a2g_header uint64; F_ctx, F_unboxed_QMARK_ any }

var A_arbace_aot_emit_emit_case_ret__90000243_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_case_sm__90000241_A struct{ a2g_header uint64; F_mask, F_shift any }

var A_arbace_aot_emit_emit_case_sm__90000241_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_def_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_def_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_deftype_class_BANG__A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_deftype_class_BANG__A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000317_A struct{ a2g_header uint64; F_ftype, F_fsym any }

var A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000317_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000350_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_deftype_class_BANG__fn__90000350_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000315_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_deftype_class_BANG__fsym__90000315_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000313_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_deftype_class_BANG__ftype__90000313_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_A struct{ a2g_header uint64; F_fsym any }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_fn__90000324_A struct{ a2g_header uint64; F_s__90000320, F_fsym, F_iter__90000319 any }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_fn__90000324_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_fn__90000324_fn__90000325_A struct{ a2g_header uint64; F_b__90000322, F_fsym any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000319__90000323_fn__90000324_fn__90000325_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_A struct{ a2g_header uint64; F_m any }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_fn__90000338_A struct{ a2g_header uint64; F_s__90000334, F_iter__90000333, F_m any }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_fn__90000338_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_fn__90000338_fn__90000339_A struct{ a2g_header uint64; F_b__90000336 any; F_size__1927001038__auto__ int32; F_m, F_c__1927001037__auto__ any }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000333__90000337_fn__90000338_fn__90000339_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_A struct{ a2g_header uint64; F_m any }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_fn__90000360_A struct{ a2g_header uint64; F_s__90000356, F_iter__90000355, F_m any }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_fn__90000360_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_fn__90000360_fn__90000361_A struct{ a2g_header uint64; F_b__90000358 any; F_size__1927001038__auto__ int32; F_m, F_c__1927001037__auto__ any }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000355__90000359_fn__90000360_fn__90000361_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_A struct{ a2g_header uint64; F_ctx_SINGLEQUOTE_ any }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_A struct{ a2g_header uint64; F_s__90000372, F_iter__90000371, F_ctx_SINGLEQUOTE_ any }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_A struct{ a2g_header uint64; F_b__90000374 any; F_size__1927001038__auto__ int32; F_ctx_SINGLEQUOTE_, F_c__1927001037__auto__ any }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_fn__90000378_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_fn__90000378_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_fn__90000380_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000377_fn__90000380_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000383_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000383_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000385_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000371__90000375_fn__90000376_fn__90000385_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_A struct{ a2g_header uint64; F_ox, F_ftype, F_fsym any }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_fn__90000394_A struct{ a2g_header uint64; F_s__90000390, F_ox, F_iter__90000389, F_ftype, F_fsym any }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_fn__90000394_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_fn__90000394_fn__90000395_A struct{ a2g_header uint64; F_ox, F_b__90000392, F_ftype, F_fsym any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_aot_emit_emit_deftype_class_BANG__iter__90000389__90000393_fn__90000394_fn__90000395_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000329_A struct{ a2g_header uint64; F_fbs, F_ftype, F_fsym any }

var A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000329_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000329_fn__90000330_A struct{ a2g_header uint64; F_ftype, F_fsym any }

var A_arbace_aot_emit_emit_deftype_class_BANG__ps__90000329_fn__90000330_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_fn_class_BANG__A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__fn__90000402_A struct{ a2g_header uint64; F_ctx, F_base any }

var A_arbace_aot_emit_emit_fn_class_BANG__fn__90000402_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__fn__90000434_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_fn_class_BANG__fn__90000434_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_fn__90000409_A struct{ a2g_header uint64; F_s__90000405, F_iter__90000404 any }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_fn__90000409_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_fn__90000409_fn__90000410_A struct{ a2g_header uint64; F_size__1927001038__auto__ int32; F_b__90000407, F_c__1927001037__auto__ any }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000404__90000408_fn__90000409_fn__90000410_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_fn__90000419_A struct{ a2g_header uint64; F_s__90000415, F_iter__90000414 any }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_fn__90000419_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_fn__90000419_fn__90000420_A struct{ a2g_header uint64; F_size__1927001038__auto__ int32; F_b__90000417, F_c__1927001037__auto__ any }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000414__90000418_fn__90000419_fn__90000420_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_fn__90000429_A struct{ a2g_header uint64; F_s__90000425, F_iter__90000424 any }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_fn__90000429_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_fn__90000429_fn__90000430_A struct{ a2g_header uint64; F_b__90000427 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000424__90000428_fn__90000429_fn__90000430_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_A struct{ a2g_header uint64; F_ctx_SINGLEQUOTE_ any }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_fn__90000441_A struct{ a2g_header uint64; F_s__90000437, F_iter__90000436, F_ctx_SINGLEQUOTE_ any }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_fn__90000441_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_fn__90000441_fn__90000442_A struct{ a2g_header uint64; F_ctx_SINGLEQUOTE_ any; F_size__1927001038__auto__ int32; F_b__90000439, F_c__1927001037__auto__ any }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000436__90000440_fn__90000441_fn__90000442_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_A struct{ a2g_header uint64; F_ctx_SINGLEQUOTE_ any }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_A struct{ a2g_header uint64; F_s__90000447, F_iter__90000446, F_ctx_SINGLEQUOTE_ any }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_A struct{ a2g_header uint64; F_ctx_SINGLEQUOTE_, F_b__90000449 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_fn__90000453_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_fn__90000453_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_fn__90000455_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000452_fn__90000455_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000458_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000458_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000460_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000446__90000450_fn__90000451_fn__90000460_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_fn__90000469_A struct{ a2g_header uint64; F_s__90000465, F_iter__90000464 any }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_fn__90000469_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_fn__90000469_fn__90000470_A struct{ a2g_header uint64; F_b__90000467 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000464__90000468_fn__90000469_fn__90000470_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_fn__90000479_A struct{ a2g_header uint64; F_s__90000475, F_iter__90000474 any }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_fn__90000479_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_fn__90000479_fn__90000480_A struct{ a2g_header uint64; F_b__90000477 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_aot_emit_emit_fn_class_BANG__iter__90000474__90000478_fn__90000479_fn__90000480_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_if_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_if_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_if_br__90000164_A struct{ a2g_header uint64; F_ctx, F_unboxed_QMARK_ any }

var A_arbace_aot_emit_emit_if_br__90000164_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_instance_field_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_instance_field_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_instance_method_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_instance_method_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_invoke_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_invoke_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_invoke_call__90000138_A struct{ a2g_header uint64; F_ctx, F_args any }

var A_arbace_aot_emit_emit_invoke_call__90000138_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_invoke_call__90000138_fn__90000139_A struct{ a2g_header uint64; F_ctx any }

var A_arbace_aot_emit_emit_invoke_call__90000138_fn__90000139_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_invoke_fn__90000142_A struct{ a2g_header uint64; F_ctx any }

var A_arbace_aot_emit_emit_invoke_fn__90000142_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_let_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_let_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_let_fn__90000169_A struct{ a2g_header uint64; F_ctx any }

var A_arbace_aot_emit_emit_let_fn__90000169_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_letfn_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_letfn_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_letfn_fn__90000190_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_letfn_fn__90000190_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_letfn_fn__90000192_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_letfn_fn__90000192_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_letfn_fn__90000223_A struct{ a2g_header uint64; F_ctx any }

var A_arbace_aot_emit_emit_letfn_fn__90000223_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_letfn_fn__90000225_A struct{ a2g_header uint64; F_ctx any }

var A_arbace_aot_emit_emit_letfn_fn__90000225_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_A struct{ a2g_header uint64; F_ctx, F_lbs any }

var A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_fn__90000199_A struct{ a2g_header uint64; F_s__90000195, F_ctx, F_iter__90000194, F_lbs any }

var A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_fn__90000199_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_fn__90000199_fn__90000200_A struct{ a2g_header uint64; F_ctx, F_b__90000197, F_lbs any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_aot_emit_emit_letfn_iter__90000194__90000198_fn__90000199_fn__90000200_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_A struct{ a2g_header uint64; F_ctx, F_lbs any }

var A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_A struct{ a2g_header uint64; F_ctx, F_s__90000205, F_iter__90000204, F_lbs any }

var A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_A struct{ a2g_header uint64; F_bs, F_lbs any }

var A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_fn__90000216_A struct{ a2g_header uint64; F_bs, F_s__90000207, F_iter__90000206, F_lbs any }

var A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_fn__90000216_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_fn__90000216_fn__90000217_A struct{ a2g_header uint64; F_bs, F_lbs any; F_size__1927001038__auto__ int32; F_b__90000209, F_c__1927001037__auto__ any }

var A_arbace_aot_emit_emit_letfn_iter__90000204__90000210_fn__90000211_iter__90000206__90000215_fn__90000216_fn__90000217_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_list_array_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_list_array_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_list_array_fn__90000036_A struct{ a2g_header uint64; F_ctx any }

var A_arbace_aot_emit_emit_list_array_fn__90000036_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_local_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_local_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_new_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_new_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_recur_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_recur_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_recur_fn__90000172_A struct{ a2g_header uint64; F_ctx any }

var A_arbace_aot_emit_emit_recur_fn__90000172_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_source_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_source_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_source_fn__90000513_A struct{ a2g_header uint64; F_ctx any }

var A_arbace_aot_emit_emit_source_fn__90000513_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_source_iter__90000518__90000522_A struct{ a2g_header uint64; F_lname any }

var A_arbace_aot_emit_emit_source_iter__90000518__90000522_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_source_iter__90000518__90000522_fn__90000523_A struct{ a2g_header uint64; F_lname, F_s__90000519, F_iter__90000518 any }

var A_arbace_aot_emit_emit_source_iter__90000518__90000522_fn__90000523_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_source_iter__90000518__90000522_fn__90000523_fn__90000524_A struct{ a2g_header uint64; F_lname, F_b__90000521 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_aot_emit_emit_source_iter__90000518__90000522_fn__90000523_fn__90000524_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_static_field_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_static_field_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_static_method_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_static_method_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_try_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_try_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_try_body__90000228_A struct{ a2g_header uint64; F_ctx, F_unboxed_QMARK_ any }

var A_arbace_aot_emit_emit_try_body__90000228_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_try_iter__90000230__90000234_A struct{ a2g_header uint64; F_body any }

var A_arbace_aot_emit_emit_try_iter__90000230__90000234_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_try_iter__90000230__90000234_fn__90000235_A struct{ a2g_header uint64; F_s__90000231, F_iter__90000230, F_body any }

var A_arbace_aot_emit_emit_try_iter__90000230__90000234_fn__90000235_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_try_iter__90000230__90000234_fn__90000235_fn__90000236_A struct{ a2g_header uint64; F_b__90000233 any; F_size__1927001038__auto__ int32; F_body, F_c__1927001037__auto__ any }

var A_arbace_aot_emit_emit_try_iter__90000230__90000234_fn__90000235_fn__90000236_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_unboxed_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_unboxed_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_unboxed_fn__90000272_A struct{ a2g_header uint64; F_ctx any }

var A_arbace_aot_emit_emit_unboxed_fn__90000272_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_value_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_emit_value_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_value_fn__90000045_A struct{ a2g_header uint64; F_ctx any }

var A_arbace_aot_emit_emit_value_fn__90000045_A_fn_class *jrt.Class



type A_arbace_aot_emit_emit_value_fn__90000047_A struct{ a2g_header uint64; F_v any }

var A_arbace_aot_emit_emit_value_fn__90000047_A_fn_class *jrt.Class



type A_arbace_aot_emit_eval90000004_A struct{ jrt.Object }

func A_arbace_aot_emit_eval90000004_A_New() *A_arbace_aot_emit_eval90000004_A { t := &A_arbace_aot_emit_eval90000004_A{}; t.Ctor(); return t }

func (t *A_arbace_aot_emit_eval90000004_A) Ctor() {}

func (t *A_arbace_aot_emit_eval90000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_emit_eval90000004_A) GetClass__Class() *jrt.Class { return A_arbace_aot_emit_eval90000004_A_class }

func (t *A_arbace_aot_emit_eval90000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_emit_eval90000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_emit_eval90000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_emit_eval90000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_emit_eval90000004_A); return ok }

func A_arbace_aot_emit_eval90000004_A_Cast(x any) *A_arbace_aot_emit_eval90000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_emit_eval90000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_emit_eval90000004_A_class)) }; return v }



type A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_eval90000004_loading__1927001464__auto____90000005_A_fn_class *jrt.Class



type A_arbace_aot_emit_eval90000008_A struct{ jrt.Object }

func A_arbace_aot_emit_eval90000008_A_New() *A_arbace_aot_emit_eval90000008_A { t := &A_arbace_aot_emit_eval90000008_A{}; t.Ctor(); return t }

func (t *A_arbace_aot_emit_eval90000008_A) Ctor() {}

func (t *A_arbace_aot_emit_eval90000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_emit_eval90000008_A) GetClass__Class() *jrt.Class { return A_arbace_aot_emit_eval90000008_A_class }

func (t *A_arbace_aot_emit_eval90000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_emit_eval90000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_emit_eval90000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_emit_eval90000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_emit_eval90000008_A); return ok }

func A_arbace_aot_emit_eval90000008_A_Cast(x any) *A_arbace_aot_emit_eval90000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_emit_eval90000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_emit_eval90000008_A_class)) }; return v }



type A_arbace_aot_emit_eval90000008_fn__90000009_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_eval90000008_fn__90000009_A_fn_class *jrt.Class



type A_arbace_aot_emit_fail_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_fail_A_fn_class *jrt.Class



type A_arbace_aot_emit_fi_QMARK__A struct{ a2g_header uint64 }

var A_arbace_aot_emit_fi_QMARK__A_fn_class *jrt.Class



type A_arbace_aot_emit_field_mods_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_field_mods_A_fn_class *jrt.Class



type A_arbace_aot_emit_field_ok_QMARK__A struct{ a2g_header uint64 }

var A_arbace_aot_emit_field_ok_QMARK__A_fn_class *jrt.Class



type A_arbace_aot_emit_field_read_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_field_read_A_fn_class *jrt.Class



type A_arbace_aot_emit_field_sym_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_field_sym_A_fn_class *jrt.Class



type A_arbace_aot_emit_fn__90000146_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_fn__90000146_A_fn_class *jrt.Class



type A_arbace_aot_emit_fn_instance_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_fn_instance_A_fn_class *jrt.Class



type A_arbace_aot_emit_fn_wrap_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_fn_wrap_A_fn_class *jrt.Class



type A_arbace_aot_emit_gsym_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_gsym_A_fn_class *jrt.Class



type A_arbace_aot_emit_identity_set_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_identity_set_A_fn_class *jrt.Class



type A_arbace_aot_emit_interface_record_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_interface_record_A_fn_class *jrt.Class



type A_arbace_aot_emit_interface_record_fn__90000567_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_interface_record_fn__90000567_A_fn_class *jrt.Class



type A_arbace_aot_emit_interface_record_iter__90000569__90000573_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_interface_record_iter__90000569__90000573_A_fn_class *jrt.Class



type A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_A struct{ a2g_header uint64; F_s__90000570, F_iter__90000569 any }

var A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_A_fn_class *jrt.Class



type A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000575_A struct{ a2g_header uint64; F_b__90000572 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000575_A_fn_class *jrt.Class



type A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000575_fn__90000579_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000575_fn__90000579_A_fn_class *jrt.Class



type A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000585_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_interface_record_iter__90000569__90000573_fn__90000574_fn__90000585_A_fn_class *jrt.Class



type A_arbace_aot_emit_jrt_lacks_QMARK__A struct{ a2g_header uint64 }

var A_arbace_aot_emit_jrt_lacks_QMARK__A_fn_class *jrt.Class



type A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000149_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_jrt_lacks_QMARK__fn__90000149_A_fn_class *jrt.Class



type A_arbace_aot_emit_line_meta_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_line_meta_A_fn_class *jrt.Class



type A_arbace_aot_emit_local_sym_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_local_sym_A_fn_class *jrt.Class



type A_arbace_aot_emit_method_body_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_method_body_A_fn_class *jrt.Class



type A_arbace_aot_emit_method_body_fn__90000290_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_method_body_fn__90000290_A_fn_class *jrt.Class



type A_arbace_aot_emit_method_body_fn__90000292_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_method_body_fn__90000292_A_fn_class *jrt.Class



type A_arbace_aot_emit_method_body_iter__90000280__90000284_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_method_body_iter__90000280__90000284_A_fn_class *jrt.Class



type A_arbace_aot_emit_method_body_iter__90000280__90000284_fn__90000285_A struct{ a2g_header uint64; F_s__90000281, F_iter__90000280 any }

var A_arbace_aot_emit_method_body_iter__90000280__90000284_fn__90000285_A_fn_class *jrt.Class



type A_arbace_aot_emit_method_body_iter__90000280__90000284_fn__90000285_fn__90000286_A struct{ a2g_header uint64; F_b__90000283 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_aot_emit_method_body_iter__90000280__90000284_fn__90000285_fn__90000286_A_fn_class *jrt.Class



type A_arbace_aot_emit_method_call_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_method_call_A_fn_class *jrt.Class



type A_arbace_aot_emit_node_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_node_A_fn_class *jrt.Class



type A_arbace_aot_emit_obj_array_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_obj_array_A_fn_class *jrt.Class



type A_arbace_aot_emit_obj_array_fn__90000130_A struct{ a2g_header uint64; F_ctx any }

var A_arbace_aot_emit_obj_array_fn__90000130_A_fn_class *jrt.Class



type A_arbace_aot_emit_param_sym_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_param_sym_A_fn_class *jrt.Class



type A_arbace_aot_emit_param_tags_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_param_tags_A_fn_class *jrt.Class



type A_arbace_aot_emit_pool_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_pool_A_fn_class *jrt.Class



type A_arbace_aot_emit_pool_fn__90000031_A struct{ a2g_header uint64; F_top any }

var A_arbace_aot_emit_pool_fn__90000031_A_fn_class *jrt.Class



type A_arbace_aot_emit_pool_encode_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_pool_encode_A_fn_class *jrt.Class



type A_arbace_aot_emit_pool_encode_arr__90000057_A struct{ a2g_header uint64; F_shared, F_sb any }

var A_arbace_aot_emit_pool_encode_arr__90000057_A_fn_class *jrt.Class



type A_arbace_aot_emit_pool_encode_fn__90000064_A struct{ a2g_header uint64; F_v any }

var A_arbace_aot_emit_pool_encode_fn__90000064_A_fn_class *jrt.Class



type A_arbace_aot_emit_pool_encode_num__90000055_A struct{ a2g_header uint64; F_sb any }

var A_arbace_aot_emit_pool_encode_num__90000055_A_fn_class *jrt.Class



type A_arbace_aot_emit_pool_fields_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_pool_fields_A_fn_class *jrt.Class



type A_arbace_aot_emit_pool_fields_fn__90000073_A struct{ a2g_header uint64; F_walk, F_consts any }

var A_arbace_aot_emit_pool_fields_fn__90000073_A_fn_class *jrt.Class



type A_arbace_aot_emit_pool_fields_fn__90000081_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_pool_fields_fn__90000081_A_fn_class *jrt.Class



type A_arbace_aot_emit_pool_fields_fn__90000087_A struct{ a2g_header uint64; F_sb, F_sh any }

var A_arbace_aot_emit_pool_fields_fn__90000087_A_fn_class *jrt.Class



type A_arbace_aot_emit_pool_fields_fn__90000093_A struct{ a2g_header uint64; F_sb, F_consts, F_shared any }

var A_arbace_aot_emit_pool_fields_fn__90000093_A_fn_class *jrt.Class



type A_arbace_aot_emit_pool_fields_fn__90000102_A struct{ a2g_header uint64; F_base int32 }

var A_arbace_aot_emit_pool_fields_fn__90000102_A_fn_class *jrt.Class



type A_arbace_aot_emit_pool_fields_walk__90000067_A struct{ a2g_header uint64; F_seen any }

var A_arbace_aot_emit_pool_fields_walk__90000067_A_fn_class *jrt.Class



type A_arbace_aot_emit_pool_kind_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_pool_kind_A_fn_class *jrt.Class



type A_arbace_aot_emit_pool_parts_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_pool_parts_A_fn_class *jrt.Class



type A_arbace_aot_emit_pool_shared_QMARK__A struct{ a2g_header uint64 }

var A_arbace_aot_emit_pool_shared_QMARK__A_fn_class *jrt.Class



type A_arbace_aot_emit_pool_str_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_pool_str_A_fn_class *jrt.Class



type A_arbace_aot_emit_prim_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_prim_A_fn_class *jrt.Class



type A_arbace_aot_emit_public_QMARK__A struct{ a2g_header uint64 }

var A_arbace_aot_emit_public_QMARK__A_fn_class *jrt.Class



type A_arbace_aot_emit_registered_QMARK__A struct{ a2g_header uint64 }

var A_arbace_aot_emit_registered_QMARK__A_fn_class *jrt.Class



type A_arbace_aot_emit_registered_QMARK__fn__90000021_A struct{ a2g_header uint64; F_c any }

var A_arbace_aot_emit_registered_QMARK__fn__90000021_A_fn_class *jrt.Class



type A_arbace_aot_emit_registered_QMARK__fn__90000023_A struct{ a2g_header uint64; F_n any }

var A_arbace_aot_emit_registered_QMARK__fn__90000023_A_fn_class *jrt.Class



type A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A struct{ a2g_header uint64; F_k any }

var A_arbace_aot_emit_registered_QMARK__fn__90000023_fn__90000024_A_fn_class *jrt.Class



type A_arbace_aot_emit_ret_body_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_ret_body_A_fn_class *jrt.Class



type A_arbace_aot_emit_runtime_class_QMARK__A struct{ a2g_header uint64 }

var A_arbace_aot_emit_runtime_class_QMARK__A_fn_class *jrt.Class



type A_arbace_aot_emit_simple_name_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_simple_name_A_fn_class *jrt.Class



type A_arbace_aot_emit_tag_class_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_tag_class_A_fn_class *jrt.Class



type A_arbace_aot_emit_tagged_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_tagged_A_fn_class *jrt.Class



type A_arbace_aot_emit_throws_QMARK__A struct{ a2g_header uint64 }

var A_arbace_aot_emit_throws_QMARK__A_fn_class *jrt.Class



type A_arbace_aot_emit_top_name_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_top_name_A_fn_class *jrt.Class



type A_arbace_aot_emit_type_sym_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_type_sym_A_fn_class *jrt.Class



type A_arbace_aot_emit_typed_args_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_typed_args_A_fn_class *jrt.Class



type A_arbace_aot_emit_typed_args_fn__90000125_A struct{ a2g_header uint64; F_ctx any }

var A_arbace_aot_emit_typed_args_fn__90000125_A_fn_class *jrt.Class



type A_arbace_aot_emit_unbox_arg_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_unbox_arg_A_fn_class *jrt.Class



type A_arbace_aot_emit_unit_method_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_unit_method_A_fn_class *jrt.Class



type A_arbace_aot_emit_unit_method_iter__90000490__90000494_A struct{ a2g_header uint64; F_ctx any }

var A_arbace_aot_emit_unit_method_iter__90000490__90000494_A_fn_class *jrt.Class



type A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_A struct{ a2g_header uint64; F_s__90000491, F_ctx, F_iter__90000490 any }

var A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_A_fn_class *jrt.Class



type A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000496_A struct{ a2g_header uint64; F_ctx, F_b__90000493 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000496_A_fn_class *jrt.Class



type A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000496_fn__90000498_A struct{ a2g_header uint64; F_ctx any }

var A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000496_fn__90000498_A_fn_class *jrt.Class



type A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000502_A struct{ a2g_header uint64; F_ctx any }

var A_arbace_aot_emit_unit_method_iter__90000490__90000494_fn__90000495_fn__90000502_A_fn_class *jrt.Class



type A_arbace_aot_emit_unit_ns_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_unit_ns_A_fn_class *jrt.Class



type A_arbace_aot_emit_var_value_A struct{ a2g_header uint64 }

var A_arbace_aot_emit_var_value_A_fn_class *jrt.Class
