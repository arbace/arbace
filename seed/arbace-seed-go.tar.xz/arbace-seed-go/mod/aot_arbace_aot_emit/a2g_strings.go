//line a2g_strings.ae:1
package aot_arbace_aot_emit

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn14,arbace.a2g.jrtyn3,jrtyn16,arbace.a2g.namesyn2,nmkn3,dockn4,selfkn3,tagkn15,runtime-classeskn5,poolskn4,namekn6,constskn9,const-mapkn12,const-prefixkn3,clskn4,prevyn3,newys16,java.lang.Object1,1yn14,unchecked-charys16,java.lang.Double16,longBitsToDoublekn4,elseys17,java.lang.Boolean4,TRUEys17,java.lang.Boolean5,FALSEys17,java.lang.Integer7,valueOfyn13,unchecked-intys14,java.lang.Long7,valueOfys16,java.lang.Double7,valueOfys19,java.lang.Character7,valueOfys14,arbace.lang.RT22,classForNameNonLoadingys18,arbace.lang.Symbol6,internkn10,param-tagsyn16,java.lang.Stringys14,arbace.lang.RT7,keywordys14,arbace.lang.RT3,varys21,arbace.lang.Namespace12,findOrCreateyn18,arbace.lang.Symbolys14,arbace.lang.RT3,mapys17,arbace.lang.Tuple6,createyn16,java.lang.Objectys14,arbace.lang.RT6,vectorys29,arbace.lang.PersistentHashSet5,EMPTYys29,arbace.lang.PersistentHashSet6,createys26,arbace.lang.PersistentList6,createyn14,java.util.Listys16,java.util.Arrays6,asListys23,java.util.regex.Pattern7,compileys14,arbace.lang.RT10,readStringyn9,.withMetayn4,castyn16,arbace.lang.IObjyn26,arbace.lang.IPersistentMapkn3,nilkn6,stringkn7,booleankn3,intkn4,longkn6,doublekn4,charkn5,classkn6,symbolkn7,keywordkn3,varkn2,nskn3,mapkn6,vectorkn3,setkn4,listkn7,patternkn4,readyn5,fieldkn6,statickn5,finalks3,aot2,nnyn4,agetyn10,const-poolkn7,privateys24,arbace.lang.Compiler$AOT4,poolyn3,intyn15,arbace.lang.Varyn19,arbace.lang.Keywordyn15,java.lang.Classkn7,gensymskn3,idxkn6,closedyn4,thiskn4,primkn16,canEmitPrimitiveyn2,dokn14,unchecked-mathyn13,.booleanValueyn17,java.lang.Booleanyn10,.charValueyn19,java.lang.Characterys14,arbace.lang.RT16,uncheckedIntCastys14,arbace.lang.RT7,intCastyn4,longyn15,unchecked-floatys30,arbace.lang.Compiler$Evaluator7,fiAdaptyn4,.getyn11,.getRawRootkn4,lineks3,aot4,linekn1,bkn4,oncekn11,shouldClearkn12,canBeClearedkn8,self-symkn11,bindingPrimyn3,letyn2,t-yn4,set!kn5,isArgkn4,argskn5,fexpryn8,.applyToyn15,arbace.lang.IFnys20,arbace.lang.ArraySeq6,createyn7,.invokekn10,isProtocolkn10,protocolOnkn8,onMethodyn2,ifyn3,andyn9,instance?yn3,notys24,arbace.lang.Compiler$AOT5,isDynkn7,classeskn7,standinkn5,funcskn9,interfacekn4,kindkn6,methodkn15,qualifyingClasskn11,dyn-guardedkn6,targetks15,arbace.aot.emit5,localkn10,target-symyn5,some?kn10,methodNameys21,arbace.lang.Reflector20,invokeInstanceMethodys21,arbace.lang.Reflector27,invokeInstanceMethodOfClassys21,arbace.lang.Reflector18,invokeStaticMethodkn1,ckn5,fieldkn9,fieldNamekn12,requireFieldys21,arbace.lang.Reflector25,invokeNoArgInstanceMemberyn7,booleanys21,arbace.lang.Reflector14,getStaticFieldkn4,ctorys21,arbace.lang.Reflector17,invokeConstructorkn12,initProvidedkn4,metakn4,inityn9,.bindRootyn8,.setMetakn9,isDynamicyn11,.setDynamickn3,valkn2,opyn4,.setys21,arbace.lang.Reflector16,setInstanceFieldkn8,testExprkn8,thenExprkn8,elseExprkn6,isLoopkn12,bindingInitskn11,loop-localskn7,bindingkn4,bodyyn4,loopkn10,loopLocalskn12,method-recurkn13,method-localsyn5,recurkn6,closeskn12,supportsMetakn8,variadicyn4,nil?ys24,arbace.lang.Compiler$AOT7,fnClassyn30,arbace.lang.Compiler$AOTRestFnyn26,arbace.lang.Compiler$AOTFnyn5,catchkn2,lbkn7,handlerkn11,finallyExpryn3,trykn7,tryExprkn10,catchExprsyn7,finallykn4,exprkn5,shiftkn4,maskyn11,bit-and-intyn19,bit-shift-right-intkn5,thenskn8,testTypekn7,defaultkn13,hash-identityyn4,whenys16,arbace.lang.Util5,equivyn5,breakyn2,==yn10,identical?kn5,testsys16,arbace.lang.Util4,hashkn9,skipCheckyn16,java.lang.Numberyn6,switchyn9,.intValueyn5,labelkn11,defaultExprkn9,isDeftypekn4,collys26,arbace.lang.PersistentList5,EMPTYys28,arbace.lang.PersistentVector5,EMPTYys30,arbace.lang.PersistentArrayMap5,EMPTYkn5,exprskn1,kkn2,kwkn1,nkn3,strkn1,vkn7,keyvalsys30,arbace.lang.Compiler$Evaluator11,monitorExityn5,throwyn19,java.lang.Throwablekn7,excExprys30,arbace.lang.Compiler$Evaluator12,monitorEnterys14,arbace.lang.RT11,arrayToListyn12,.importClassyn21,arbace.lang.Namespaceyn6,.derefys14,arbace.lang.RT10,CURRENT_NSkn5,textsys24,arbace.lang.Compiler$AOT9,strConcatys16,java.lang.String1,1ys14,arbace.lang.RT3,setkn4,keysyn11,.isInstancekn4,typekn8,retClasskn8,reqParmskn8,restParmkn9,argLocalsys14,arbace.lang.RT10,doubleCastys14,arbace.lang.RT8,longCastkn13,compiledClasskn3,symkn16,volatile-mutablekn8,volatilekn22,unsynchronized-mutablekn6,publickn12,hintedFieldskn12,altCtorDropsyn3,m__yn6,methodks15,arbace.aot.emit7,pendingkn4,objxyn11,constructoryn6,super.kn6,columnyn5,this.yn8,getBasisyn29,arbace.lang.IPersistentVectorys19,arbace.lang.Keyword6,internyn6,.valAtyn6,createkn7,mutableyn8,.withoutys14,arbace.lang.RT9,seqOrElsekn7,methodskn7,deftypekn5,superkn10,interfaceskn7,memberskn6,sourcekn8,fn-namesyn4,selfkn10,isVariadicyn8,doInvokeyn6,invokekn8,onceOnlyyn6,meta__yn8,.-__metayn8,fn-classyn6,__metayn4,metayn8,withMetayn1,mkn2,fnkn5,reifyys14,arbace.lang.RT4,consys14,arbace.lang.RT3,seqys24,arbace.lang.Compiler$AOT2,atkn4,formyn8,defclassks3,aot6,sourceyn4,loadyn4,initks3,aot4,codekn6,holderkn7,extendskn10,implementskn8,abstractv11,arbace.core5,referv11,arbace.core7,requireR0,V3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn15,arbace.aot.emitm2,R8,s1622,Standalone S6 (doc/STANDALONE-NOTES.md, \"S6: Arbace compiled to Go\"): the back end that\n  compiles analyzed namespaces to class forms, which a2g translates into Go like the runtime's\n  own classes.\n\n  The input is what the program records while it prepares its namespaces (ARBACE_COMPILE): for\n  each source, its units in order (a top-level form, analyzed: Compiler$Image's unit, its Expr\n  tree and the events of its analysis), read through Compiler$AST/node, which shows a node's\n  fields as a map. The output follows the JVM's bytecode back end (Compiler.clj on the branch\n  arbace-for-java-26: ObjExpr.compile, the emit methods), with class forms in place of\n  bytecode:\n\n  - a fn (FnExpr) is a class named as the JVM names it (arbace.walk$walk), a static member\n    class of a holder class per namespace (arbace.walk), nested as its name nests; it extends\n    AFunction (RestFn when variadic), its closed-over locals are fields set by its constructor,\n    each arity an invoke method (doInvoke for the variadic one), its constants static fields;\n  - a source's top-level forms are the static methods of its loader class SCRIPTBASE__init\n    (arbace.walk__init), whose load() runs them in order; Compiler$AOT/load calls it in the\n    bindings Compiler.load makes; past loader-part-units units, in parts, static member\n    classes SCRIPTBASE__init$partP (SA210);\n  - each Expr becomes the class forms code its emit method's bytecode is: interop on the\n    analyzer's resolved members (param-tags pin the overload), reflection where it was\n    unresolved, Clojure's boxing and conversions (emitBoxReturn, emitTypedArgs).v11,arbace.core13,*loaded-libs*v11,arbace.core5,some?v15,arbace.aot.emit10,node-cachev11,arbace.core5,assocR9,v11,arbace.core7,ex-infov13,arbace.string12,starts-with?v11,arbace.core4,subsv11,arbace.core6,symbolv11,arbace.core3,strv15,arbace.aot.emit8,type-symv15,arbace.aot.emit6,destubv11,arbace.core9,vary-metaR10,v15,arbace.aot.emit10,prim-namesv11,arbace.core3,notv15,arbace.aot.emit10,registeredv11,arbace.core5,swap!v11,arbace.core9,contains?R11,v15,arbace.aot.emit11,registered?l0,R12,v11,arbace.core4,atomR13,R14,R15,R16,R17,R18,v11,arbace.core4,namev11,arbace.core6,updatev11,arbace.core4,listR19,R20,v11,arbace.core4,mapvv15,arbace.aot.emit10,emit-valuev11,arbace.core4,not=c92,R21,R22,V2,nTv11,arbace.core7,string?v11,arbace.core6,class?v11,arbace.core7,symbol?v11,arbace.core8,keyword?v11,arbace.core4,var?v15,arbace.aot.emit4,failv11,arbace.core4,map?v11,arbace.core7,vector?v11,arbace.core4,seq?v11,arbace.core5,list?R23,v11,arbace.core6,pr-strv11,arbace.core19,pop-thread-bindingsR24,R25,R26,R27,R28,R29,v15,arbace.aot.emit11,double-formR30,v15,arbace.aot.emit9,char-formC17,java.lang.BooleanC14,java.lang.ByteC19,java.lang.CharacterC16,java.lang.DoubleC15,java.lang.FloatC17,java.lang.IntegerC14,java.lang.LongC15,java.lang.ShortR31,v11,arbace.core9,with-metav11,arbace.core9,namespaceR32,m2,R33,V2,R34,R34,R35,m2,R33,V2,R34,R34,R36,m2,R33,V2,R34,R34,R37,m2,R33,V1,R38,R32,m2,R33,V2,R34,R34,v11,arbace.core5,classv15,arbace.aot.emit15,emit-list-arrayR39,m2,R33,V1,R20,v11,arbace.core6,mapcatv11,arbace.core8,identityv11,arbace.core5,list*v11,arbace.core3,mapR40,R33,v11,arbace.core3,vecv11,arbace.core6,repeatR41,R42,m2,R33,V1,R20,v11,arbace.core6,empty?R43,R44,m2,R33,V1,R20,v11,arbace.core3,seqR45,m2,R33,V1,R46,R47,m2,R33,V1,R20,R48,m2,R33,V1,R34,v11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core11,*print-dup*R49,m2,R33,V1,R34,R50,R51,R52,R51,R53,R54,R55,R56,R57,R58,R59,R60,R61,R62,R63,R64,R65,R66,R67,R68,R69,R70,R71,v15,arbace.aot.emit9,pool-kindv11,arbace.core6,concatv15,arbace.aot.emit12,pool-partialc44,v15,arbace.aot.emit12,pool-shared?c82,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,firstv15,arbace.aot.emit11,pool-encodev11,arbace.core10,chunk-restv11,arbace.core4,nextc77,v15,arbace.aot.emit8,pool-strc110,c84,c70,c118,c107,c115,c112,c100,c109,c80,c86,c68,c67,c66,c90,c74,c83,c73,c99,c78,c114,c108,c121,c69,c105,c76,v11,arbace.core4,run!v15,arbace.aot.emit10,pool-partsv11,arbace.core4,intov11,arbace.core6,removev11,arbace.core11,map-indexedv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendR72,v15,arbace.aot.emit6,taggedR41,m6,R73,TR74,TR75,TR76,R77,R27,R51,v11,arbace.core10,chunk-consv11,arbace.core4,consv11,arbace.core5,chunkm6,R73,TR74,TR75,Tv11,arbace.core4,restR72,R77,m6,R73,TR74,TR78,TR79,m2,R33,V2,R34,R80,R27,R81,R82,R83,R41,v15,arbace.aot.emit14,runtime-class?v15,arbace.aot.emit11,const-fieldR31,m2,R33,V1,R34,v15,arbace.aot.emit10,const-typeR84,v11,arbace.core4,fnilv11,arbace.core3,incR85,R86,v15,arbace.aot.emit9,field-symR87,R88,v15,arbace.aot.emit4,nodeR89,R90,v15,arbace.aot.emit6,box-ofC16,java.lang.ObjectR91,R92,R51,R93,R94,R51,R95,m2,R33,V1,R41,v15,arbace.aot.emit7,public?R51,v15,arbace.aot.emit12,emit-unboxedv15,arbace.aot.emit4,emitv15,arbace.aot.emit3,fi?v15,arbace.aot.emit9,unbox-argR96,R97,m2,R33,V1,R98,R99,R100,v15,arbace.aot.emit8,constantR19,R20,R81,R101,R102,R103,R104,R105,v15,arbace.aot.emit7,closed?v15,arbace.aot.emit10,field-readR106,R107,R108,R109,R87,v15,arbace.aot.emit9,local-symR110,R111,R112,R112,R113,R114,R115,R116,R117,R51,R118,v15,arbace.aot.emit9,obj-arrayR119,m2,R33,V1,R20,R120,R51,R118,R121,R122,R123,v15,arbace.aot.emit4,gsymR111,R124,v15,arbace.aot.emit3,boxR125,R126,R127,R128,v15,arbace.aot.emit10,typed-argsv15,arbace.aot.emit10,param-tagsR51,R120,R51,R118,v13,arbace.string7,replacev14,arbace.a2g.jrt4,scanR129,v16,arbace.a2g.names13,go-class-namev11,arbace.core5,applyv15,arbace.aot.emit10,descriptorv16,arbace.a2g.names11,method-basev15,arbace.aot.emit8,jrt-scanR130,R131,v14,arbace.a2g.jrt14,struct-methodsv14,arbace.a2g.jrt13,iface-methodsv16,arbace.a2g.names9,impl-nameR51,R132,R133,R134,v15,arbace.aot.emit19,compiled-interface?v15,arbace.aot.emit11,method-callv15,arbace.aot.emit20,emit-instance-methodR135,R136,R137,R138,R139,R111,R124,R125,R140,R128,R141,R142,m2,R33,V3,R41,R34,R20,v15,arbace.aot.emit10,jrt-lacks?R143,R142,m2,R33,V3,R41,R34,R20,v15,arbace.aot.emit18,emit-static-methodR144,m2,R33,V3,R83,R34,R20,R145,R146,v15,arbace.aot.emit9,field-ok?R51,R147,R148,R149,m2,R33,V3,R41,R34,R150,R151,m2,R33,V2,R83,R34,R152,R153,m2,R33,V2,R83,R20,R154,R155,R81,R156,R51,R53,R90,R157,R158,R159,R160,R90,R160,R158,R157,R161,R162,R163,R81,R113,R113,R113,R51,R164,m2,R33,V1,R20,R165,v15,arbace.aot.emit9,can-prim?R124,R166,R167,R168,R169,R170,R171,v15,arbace.aot.emit17,emit-binding-initR172,R173,R111,R174,R175,R176,v11,arbace.core6,reset!R177,v15,arbace.aot.emit4,primR97,m2,R33,V1,R98,R99,v15,arbace.aot.emit14,emit-fn-class!v15,arbace.aot.emit10,emit-localv11,arbace.core4,keysR178,R19,R179,V1,nR180,R111,R83,R124,R181,R111,R83,R182,m2,R33,V2,R34,R150,R113,R19,R183,R27,R19,R184,v15,arbace.aot.emit13,body-instancev15,arbace.aot.emit7,fn-wrapv15,arbace.aot.emit12,identity-setR113,v11,arbace.core6,vectorR111,R90,R185,R186,R187,R188,R189,R190,R191,R192,R193,R194,R195,R196,R197,R198,v11,arbace.core7,keywordR199,R200,v11,arbace.core3,setR201,R202,R203,m2,R33,V2,R41,R41,R204,R202,R205,R204,R204,R202,R205,R98,R204,R204,R202,R206,R204,R202,R203,m2,R33,V2,R41,R41,R204,v11,arbace.core10,sorted-mapR207,R208,R27,R209,R202,R126,R210,R211,R212,R51,R210,R211,R213,R214,S2,s9,instance?s5,localv15,arbace.aot.emit8,emit-tryR215,v15,arbace.aot.emit11,fn-instancev15,arbace.aot.emit8,emit-defv15,arbace.aot.emit11,emit-invokev15,arbace.aot.emit9,line-metav15,arbace.aot.emit19,emit-deftype-class!R216,R217,R218,R219,R43,v15,arbace.aot.emit19,emit-instance-fieldv15,arbace.aot.emit9,var-valueR220,R120,R221,R82,R222,v11,arbace.core4,keepR90,v11,arbace.core7,butlastv11,arbace.core4,lastv15,arbace.aot.emit7,emit-ifv15,arbace.aot.emit11,emit-assignv15,arbace.aot.emit10,emit-letfnR50,R51,R52,R51,R53,R223,R81,R82,R224,v15,arbace.aot.emit9,coll-callv15,arbace.aot.emit8,emit-letR40,R41,R42,v15,arbace.aot.emit10,emit-recurR225,R39,R226,R90,R227,v15,arbace.aot.emit8,emit-newR228,R51,R229,R230,R24,R25,R90,R231,R232,R90,R233,R51,R234,R235,R236,R31,v15,arbace.aot.emit17,emit-static-fieldv15,arbace.aot.emit9,emit-caseR237,R238,R19,R239,R19,R20,R240,R241,R242,R126,R243,v15,arbace.aot.emit8,box-primR90,R242,R126,R228,R51,R229,v15,arbace.aot.emit4,deepv15,arbace.aot.emit7,throws?R97,m2,R33,V1,R98,R99,R92,R51,R93,R94,R51,R95,R51,R210,R51,R244,v15,arbace.aot.emit8,ret-bodyR245,R246,R247,R173,R111,R248,R249,m2,R33,V1,R41,v15,arbace.aot.emit12,prim-classesv11,arbace.core10,ns-resolvev11,arbace.core4,*ns*R250,R251,R252,m2,R253,TR254,m4,R255,TR74,Tv15,arbace.aot.emit4,poolR256,R257,R87,v11,arbace.core4,takeR258,R87,R259,v15,arbace.aot.emit11,method-bodym2,R255,Tm2,R255,TR72,v15,arbace.aot.emit10,field-modsR260,R261,R262,ML1,R263,m4,R103,i1149,R264,i26,R113,R87,m2,R255,TR87,R262,m2,R255,TR265,R27,R27,R262,m2,R255,TR265,R27,R27,R259,R266,m4,R255,TR73,TR267,R259,v15,arbace.aot.emit9,tag-classR268,m2,R33,V1,R34,R269,R51,v15,arbace.aot.emit9,box-classm2,R33,V1,R34,R270,m4,R255,TR73,TR53,R111,m2,R271,TR111,R113,R272,R19,R273,R27,R27,R274,R275,R276,R41,R277,v15,arbace.aot.emit16,class-interfacesR278,R279,R280,R72,v11,arbace.core4,someV2,R87,R281,v15,arbace.aot.emit9,param-symR259,R282,R283,R284,m2,R255,TV2,R87,R281,m2,R255,TR87,R259,m2,R255,Tm2,R255,Tv15,arbace.aot.emit8,top-nameR285,R281,R87,R262,ML1,R263,m4,R103,i1228,R264,i26,m2,R255,TV1,R87,R286,R53,V1,ML3,R113,ML2,R287,R87,m4,R103,i1229,R264,i53,R286,m4,R103,i1229,R264,i47,R113,R87,R72,R83,R288,m4,R255,TR73,TR72,R289,R53,R259,ML2,R287,R87,m4,R103,i1261,R264,i117,R290,m2,R255,TV1,R87,R53,R259,R291,m2,R255,TR52,R87,R292,R53,R19,R292,R87,R293,R294,R41,R117,R51,R118,R102,v11,arbace.core15,get-proxy-classR81,R295,m2,R33,V2,R41,R41,R296,m2,R33,V1,R41,R19,R20,R163,R236,R37,R51,R38,m2,R33,V2,R41,R41,m2,R33,V1,R41,R259,m4,R78,TR73,TR90,R297,R27,R27,v11,arbace.core7,find-nsv15,arbace.aot.emit7,unit-nsv15,arbace.aot.emit11,unit-methodv15,arbace.aot.emit17,loader-part-unitsR298,v11,arbace.core5,rangev15,arbace.aot.emit11,pool-fieldsR299,R255,R74,R300,R259,R301,m4,R255,TR73,TV1,nR90,R299,R73,R259,R302,m2,R73,TR259,R301,m2,R73,TV1,nR90,m2,R73,Tm2,R73,TV1,nv11,arbace.core13,partition-allR299,R259,R301,m4,R255,TR73,Tv11,arbace.core8,to-arrayV1,nR90,v11,arbace.core6,dissocR303,v15,arbace.aot.emit10,class-formv15,arbace.aot.emit11,simple-nameR304,R299,m6,R255,TR73,TR74,TR299,m6,R255,TR73,TR132,TR305,R299,m6,R255,TR73,TR74,TR306,v11,arbace.core4,peekv11,arbace.core3,popv11,arbace.core8,group-byv11,arbace.core7,sort-byv11,arbace.core4,sortR259,m4,R255,TR307,TR87,m4,R255,TR307,T")

var Lit_1 *jrt.String = jrt.Intern("arbace.aot.emit$body_instance$iter__90000194__90000198")

var Lit_2 *jrt.String = jrt.Intern("new-instance")

var Lit_3 *jrt.String = jrt.Intern("arbace.aot.emit$body_instance$iter__90000194__90000198$fn__90000199")

var Lit_4 *jrt.String = jrt.Intern("arbace.aot.emit$body_instance$iter__90000194__90000198$fn__90000199$fn__90000200")

var Lit_5 *jrt.String = jrt.Intern("arbace.aot.emit$class_form$fn__90000596")

var Lit_6 *jrt.String = jrt.Intern("arbace.aot.emit$class_form$mods__90000598")

var Lit_7 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$parent__90000603")

var Lit_8 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$fn__90000605")

var Lit_9 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$iter__90000607__90000611")

var Lit_10 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$fn__90000617")

var Lit_11 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$children_of__90000619")

var Lit_12 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$iter__90000621__90000625")

var Lit_13 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$iter__90000607__90000611$fn__90000612")

var Lit_14 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$iter__90000607__90000611$fn__90000612$fn__90000613")

var Lit_15 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$iter__90000621__90000625$fn__90000626")

var Lit_16 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$iter__90000621__90000625$fn__90000626$fn__90000627")

var Lit_17 *jrt.String = jrt.Intern("$")

var Lit_18 *jrt.String = jrt.Intern("no class for ")

var Lit_19 *jrt.String = jrt.Intern("arbace.aot.emit$class_interfaces$iter__90000317__90000321")

var Lit_20 *jrt.String = jrt.Intern("arbace.aot.emit$class_interfaces$iter__90000317__90000321$fn__90000322")

var Lit_21 *jrt.String = jrt.Intern("arbace.aot.emit$class_interfaces$iter__90000317__90000321$fn__90000322$fn__90000323")

var Lit_22 *jrt.String = jrt.Intern(" implements ")

var Lit_23 *jrt.String = jrt.Intern(", made at run time")

var Lit_24 *jrt.String = jrt.Intern("const-")

var Lit_25 *jrt.String = jrt.Intern("V")

var Lit_26 *jrt.String = jrt.Intern("J")

var Lit_27 *jrt.String = jrt.Intern("I")

var Lit_28 *jrt.String = jrt.Intern("D")

var Lit_29 *jrt.String = jrt.Intern("Z")

var Lit_30 *jrt.String = jrt.Intern("C")

var Lit_31 *jrt.String = jrt.Intern("F")

var Lit_32 *jrt.String = jrt.Intern("S")

var Lit_33 *jrt.String = jrt.Intern("B")

var Lit_34 *jrt.String = jrt.Intern(".")

var Lit_35 *jrt.String = jrt.Intern("/")

var Lit_36 *jrt.String = jrt.Intern("L")

var Lit_37 *jrt.String = jrt.Intern(";")

var Lit_38 *jrt.String = jrt.Intern("compile__stub.")

var Lit_39 *jrt.String = jrt.Intern("try")

var Lit_40 *jrt.String = jrt.Intern("def")

var Lit_41 *jrt.String = jrt.Intern("invoke")

var Lit_42 *jrt.String = jrt.Intern("instance-method")

var Lit_43 *jrt.String = jrt.Intern("empty")

var Lit_44 *jrt.String = jrt.Intern("unknown empty collection")

var Lit_45 *jrt.String = jrt.Intern("instance-field")

var Lit_46 *jrt.String = jrt.Intern("var")

var Lit_47 *jrt.String = jrt.Intern("keyword-invoke")

var Lit_48 *jrt.String = jrt.Intern("do")

var Lit_49 *jrt.String = jrt.Intern("arbace.aot.emit$emit$fn__90000282")

var Lit_50 *jrt.String = jrt.Intern("fn")

var Lit_51 *jrt.String = jrt.Intern("if")

var Lit_52 *jrt.String = jrt.Intern("set!")

var Lit_53 *jrt.String = jrt.Intern("with-meta")

var Lit_54 *jrt.String = jrt.Intern("letfn")

var Lit_55 *jrt.String = jrt.Intern("number")

var Lit_56 *jrt.String = jrt.Intern("the-var")

var Lit_57 *jrt.String = jrt.Intern("keyword")

var Lit_58 *jrt.String = jrt.Intern("local")

var Lit_59 *jrt.String = jrt.Intern("string")

var Lit_60 *jrt.String = jrt.Intern("vector")

var Lit_61 *jrt.String = jrt.Intern("arbace.aot.emit$emit$fn__90000284")

var Lit_62 *jrt.String = jrt.Intern("let")

var Lit_63 *jrt.String = jrt.Intern("recur")

var Lit_64 *jrt.String = jrt.Intern("constant")

var Lit_65 *jrt.String = jrt.Intern("map")

var Lit_66 *jrt.String = jrt.Intern("monitor-exit")

var Lit_67 *jrt.String = jrt.Intern("throw")

var Lit_68 *jrt.String = jrt.Intern("new")

var Lit_69 *jrt.String = jrt.Intern("nil")

var Lit_70 *jrt.String = jrt.Intern("boolean")

var Lit_71 *jrt.String = jrt.Intern("monitor-enter")

var Lit_72 *jrt.String = jrt.Intern("list")

var Lit_73 *jrt.String = jrt.Intern("import")

var Lit_74 *jrt.String = jrt.Intern("static-method")

var Lit_75 *jrt.String = jrt.Intern("static-field")

var Lit_76 *jrt.String = jrt.Intern("str-concat")

var Lit_77 *jrt.String = jrt.Intern("arbace.aot.emit$emit$fn__90000286")

var Lit_78 *jrt.String = jrt.Intern("case")

var Lit_79 *jrt.String = jrt.Intern("set")

var Lit_80 *jrt.String = jrt.Intern("instance?")

var Lit_81 *jrt.String = jrt.Intern("no back end for ")

var Lit_82 *jrt.String = jrt.Intern(" ")

var Lit_83 *jrt.String = jrt.Intern("set! of a local that is no field")

var Lit_84 *jrt.String = jrt.Intern(".-")

var Lit_85 *jrt.String = jrt.Intern("set! of ")

var Lit_86 *jrt.String = jrt.Intern("arbace.aot.emit$emit_case$sm__90000260")

var Lit_87 *jrt.String = jrt.Intern("arbace.aot.emit$emit_case$ret__90000262")

var Lit_88 *jrt.String = jrt.Intern("case-")

var Lit_89 *jrt.String = jrt.Intern("arbace.aot.emit$emit_case$arm__90000264")

var Lit_90 *jrt.String = jrt.Intern("arbace.aot.emit$emit_case$fn__90000267")

var Lit_91 *jrt.String = jrt.Intern("arbace.aot.emit$emit_case$fn__90000273")

var Lit_92 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$ftype__90000332")

var Lit_93 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$fsym__90000334")

var Lit_94 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$fn__90000336")

var Lit_95 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000338__90000342")

var Lit_96 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$ps__90000348")

var Lit_97 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000352__90000356")

var Lit_98 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$fn__90000369")

var Lit_99 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000374__90000378")

var Lit_100 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000390__90000394")

var Lit_101 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000408__90000412")

var Lit_102 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000338__90000342$fn__90000343")

var Lit_103 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000338__90000342$fn__90000343$fn__90000344")

var Lit_104 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000352__90000356$fn__90000357")

var Lit_105 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000352__90000356$fn__90000357$fn__90000358")

var Lit_106 *jrt.String = jrt.Intern("v__")

var Lit_107 *jrt.String = jrt.Intern("Value")

var Lit_108 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000374__90000378$fn__90000379")

var Lit_109 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000374__90000378$fn__90000379$fn__90000380")

var Lit_110 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000390__90000394$fn__90000395")

var Lit_111 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000390__90000394$fn__90000395$fn__90000396")

var Lit_112 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000390__90000394$fn__90000395$fn__90000402")

var Lit_113 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000390__90000394$fn__90000395$fn__90000404")

var Lit_114 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000390__90000394$fn__90000395$fn__90000396$fn__90000397")

var Lit_115 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000390__90000394$fn__90000395$fn__90000396$fn__90000399")

var Lit_116 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000408__90000412$fn__90000413")

var Lit_117 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000408__90000412$fn__90000413$fn__90000414")

var Lit_118 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$ps__90000348$fn__90000349")

var Lit_119 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$fn__90000421")

var Lit_120 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000423__90000427")

var Lit_121 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000433__90000437")

var Lit_122 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000443__90000447")

var Lit_123 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$fn__90000453")

var Lit_124 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000455__90000459")

var Lit_125 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000465__90000469")

var Lit_126 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000483__90000487")

var Lit_127 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000493__90000497")

var Lit_128 *jrt.String = jrt.Intern("__")

var Lit_129 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000423__90000427$fn__90000428")

var Lit_130 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000423__90000427$fn__90000428$fn__90000429")

var Lit_131 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000433__90000437$fn__90000438")

var Lit_132 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000433__90000437$fn__90000438$fn__90000439")

var Lit_133 *jrt.String = jrt.Intern("c__")

var Lit_134 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000443__90000447$fn__90000448")

var Lit_135 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000443__90000447$fn__90000448$fn__90000449")

var Lit_136 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000455__90000459$fn__90000460")

var Lit_137 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000455__90000459$fn__90000460$fn__90000461")

var Lit_138 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000465__90000469$fn__90000470")

var Lit_139 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000465__90000469$fn__90000470$fn__90000471")

var Lit_140 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000465__90000469$fn__90000470$fn__90000477")

var Lit_141 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000465__90000469$fn__90000470$fn__90000479")

var Lit_142 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000465__90000469$fn__90000470$fn__90000471$fn__90000472")

var Lit_143 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000465__90000469$fn__90000470$fn__90000471$fn__90000474")

var Lit_144 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000483__90000487$fn__90000488")

var Lit_145 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000483__90000487$fn__90000488$fn__90000489")

var Lit_146 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000493__90000497$fn__90000498")

var Lit_147 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000493__90000497$fn__90000498$fn__90000499")

var Lit_148 *jrt.String = jrt.Intern("arbace.lang.Compiler$AOTR")

var Lit_149 *jrt.String = jrt.Intern("arbace.lang.Compiler$AOTF")

var Lit_150 *jrt.String = jrt.Intern("arbace.aot.emit$emit_if$br__90000183")

var Lit_151 *jrt.String = jrt.Intern("target-")

var Lit_152 *jrt.String = jrt.Intern("arbace.aot.emit$emit_invoke$call__90000157")

var Lit_153 *jrt.String = jrt.Intern("arbace.aot.emit$emit_invoke$fn__90000161")

var Lit_154 *jrt.String = jrt.Intern("arbace.aot.emit$emit_invoke$call__90000157$fn__90000158")

var Lit_155 *jrt.String = jrt.Intern("arbace.aot.emit$emit_let$fn__90000188")

var Lit_156 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$fn__90000209")

var Lit_157 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$fn__90000211")

var Lit_158 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$iter__90000213__90000217")

var Lit_159 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$iter__90000223__90000229")

var Lit_160 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$fn__90000242")

var Lit_161 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$fn__90000244")

var Lit_162 *jrt.String = jrt.Intern("body-")

var Lit_163 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$iter__90000213__90000217$fn__90000218")

var Lit_164 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$iter__90000213__90000217$fn__90000218$fn__90000219")

var Lit_165 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$iter__90000223__90000229$fn__90000230")

var Lit_166 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$iter__90000223__90000229$fn__90000230$iter__90000225__90000234")

var Lit_167 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$iter__90000223__90000229$fn__90000230$iter__90000225__90000234$fn__90000235")

var Lit_168 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$iter__90000223__90000229$fn__90000230$iter__90000225__90000234$fn__90000235$fn__90000236")

var Lit_169 *jrt.String = jrt.Intern("arbace.aot.emit$emit_list_array$fn__90000036")

var Lit_170 *jrt.String = jrt.Intern("arbace.aot.emit$emit_recur$fn__90000191")

var Lit_171 *jrt.String = jrt.Intern("recur arg for primitive local: ")

var Lit_172 *jrt.String = jrt.Intern(" is not matching primitive")

var Lit_173 *jrt.String = jrt.Intern("__init")

var Lit_174 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source$unit_methods__90000531")

var Lit_175 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source$calls__90000538")

var Lit_176 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source$iter__90000550__90000554")

var Lit_177 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source$iter__90000566__90000570")

var Lit_178 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source$iter__90000580__90000584")

var Lit_179 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source$calls__90000538$iter__90000539__90000543")

var Lit_180 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source$calls__90000538$iter__90000539__90000543$fn__90000544")

var Lit_181 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source$calls__90000538$iter__90000539__90000543$fn__90000544$fn__90000545")

var Lit_182 *jrt.String = jrt.Intern("unit")

var Lit_183 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source$iter__90000550__90000554$fn__90000555")

var Lit_184 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source$iter__90000550__90000554$fn__90000555$fn__90000556")

var Lit_185 *jrt.String = jrt.Intern("$part")

var Lit_186 *jrt.String = jrt.Intern("")

var Lit_187 *jrt.String = jrt.Intern("part")

var Lit_188 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source$iter__90000566__90000570$fn__90000571")

var Lit_189 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source$iter__90000566__90000570$fn__90000571$fn__90000572")

var Lit_190 *jrt.String = jrt.Intern("init")

var Lit_191 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source$iter__90000580__90000584$fn__90000585")

var Lit_192 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source$iter__90000580__90000584$fn__90000585$fn__90000586")

var Lit_193 *jrt.String = jrt.Intern("load")

var Lit_194 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source$unit_methods__90000531$fn__90000532")

var Lit_195 *jrt.String = jrt.Intern("arbace.aot.emit$emit_try$body__90000247")

var Lit_196 *jrt.String = jrt.Intern("arbace.aot.emit$emit_try$iter__90000249__90000253")

var Lit_197 *jrt.String = jrt.Intern("arbace.aot.emit$emit_try$iter__90000249__90000253$fn__90000254")

var Lit_198 *jrt.String = jrt.Intern("arbace.aot.emit$emit_try$iter__90000249__90000253$fn__90000254$fn__90000255")

var Lit_199 *jrt.String = jrt.Intern("unboxed emit of ")

var Lit_200 *jrt.String = jrt.Intern("arbace.aot.emit$emit_unboxed$fn__90000291")

var Lit_201 *jrt.String = jrt.Intern("no unboxed back end for ")

var Lit_202 *jrt.String = jrt.Intern("TYPE")

var Lit_203 *jrt.String = jrt.Intern("a record as a constant: ")

var Lit_204 *jrt.String = jrt.Intern("a deftype as a constant: ")

var Lit_205 *jrt.String = jrt.Intern("arbace.aot.emit$emit_value$fn__90000045")

var Lit_206 *jrt.String = jrt.Intern("arbace.aot.emit$emit_value$fn__90000047")

var Lit_207 *jrt.String = jrt.Intern("#<")

var Lit_208 *jrt.String = jrt.Intern("can't embed unreadable object in code: ")

var Lit_209 *jrt.String = jrt.Intern("arbace.lang.Compiler$AST")

var Lit_210 *jrt.String = jrt.Intern("arbace.lang.Var")

var Lit_211 *jrt.String = jrt.Intern("arbace.lang.Keyword")

var Lit_212 *jrt.String = jrt.Intern("arbace.lang.Symbol")

var Lit_213 *jrt.String = jrt.Intern("arbace.lang.IObj")

var Lit_214 *jrt.String = jrt.Intern("arbace.lang.IPersistentMap")

var Lit_215 *jrt.String = jrt.Intern("arbace.lang.IPersistentVector")

var Lit_216 *jrt.String = jrt.Intern("arbace.lang.IPersistentSet")

var Lit_217 *jrt.String = jrt.Intern("arbace.lang.IPersistentList")

var Lit_218 *jrt.String = jrt.Intern("arbace.lang.ISeq")

var Lit_219 *jrt.String = jrt.Intern("arbace.lang.IType")

var Lit_220 *jrt.String = jrt.Intern("arbace.lang.IRecord")

var Lit_221 *jrt.String = jrt.Intern("arbace.lang.PersistentHashSet")

var Lit_222 *jrt.String = jrt.Intern("arbace.lang.Namespace")

var Lit_223 *jrt.String = jrt.Intern("java.util.IdentityHashMap")

var Lit_224 *jrt.String = jrt.Intern("java.util.regex.Pattern")

var Lit_225 *jrt.String = jrt.Intern("aot: ")

var Lit_226 *jrt.String = jrt.Intern("fiMethod")

var Lit_227 *jrt.String = jrt.Intern("/go/arbace/jrt")

var Lit_228 *jrt.String = jrt.Intern("ARBACE_AOT_ROOT")

var Lit_229 *jrt.String = jrt.Intern("fn-class")

var Lit_230 *jrt.String = jrt.Intern("fncls__")

var Lit_231 *jrt.String = jrt.Intern("d")

var Lit_232 *jrt.String = jrt.Intern("arbace.aot.emit$interface_record$fn__90000633")

var Lit_233 *jrt.String = jrt.Intern("arbace.aot.emit$interface_record$iter__90000635__90000639")

var Lit_234 *jrt.String = jrt.Intern("arbace.aot.emit$interface_record$iter__90000635__90000639$fn__90000640")

var Lit_235 *jrt.String = jrt.Intern("arbace.aot.emit$interface_record$iter__90000635__90000639$fn__90000640$fn__90000641")

var Lit_236 *jrt.String = jrt.Intern("arbace.aot.emit$interface_record$iter__90000635__90000639$fn__90000640$fn__90000651")

var Lit_237 *jrt.String = jrt.Intern("arbace.aot.emit$interface_record$iter__90000635__90000639$fn__90000640$fn__90000641$fn__90000645")

var Lit_238 *jrt.String = jrt.Intern("p")

var Lit_239 *jrt.String = jrt.Intern("(")

var Lit_240 *jrt.String = jrt.Intern(")")

var Lit_241 *jrt.String = jrt.Intern("arbace.aot.emit$jrt_lacks_QMARK_$fn__90000168")

var Lit_242 *jrt.String = jrt.Intern("_")

var Lit_243 *jrt.String = jrt.Intern("fn-method")

var Lit_244 *jrt.String = jrt.Intern("arbace.aot.emit$method_body$iter__90000299__90000303")

var Lit_245 *jrt.String = jrt.Intern("arbace.aot.emit$method_body$fn__90000309")

var Lit_246 *jrt.String = jrt.Intern("arbace.aot.emit$method_body$fn__90000311")

var Lit_247 *jrt.String = jrt.Intern("p-")

var Lit_248 *jrt.String = jrt.Intern("arbace.aot.emit$method_body$iter__90000299__90000303$fn__90000304")

var Lit_249 *jrt.String = jrt.Intern("arbace.aot.emit$method_body$iter__90000299__90000303$fn__90000304$fn__90000305")

var Lit_250 *jrt.String = jrt.Intern("a call of a method of a class made at run time: ")

var Lit_251 *jrt.String = jrt.Intern("arbace.aot.emit$obj_array$fn__90000149")

var Lit_252 *jrt.String = jrt.Intern("arbace.aot.emit$pool$fn__90000031")

var Lit_253 *jrt.String = jrt.Intern("arbace.aot.emit$pool_encode$num__90000055")

var Lit_254 *jrt.String = jrt.Intern("arbace.aot.emit$pool_encode$arr__90000057")

var Lit_255 *jrt.String = jrt.Intern("arbace.aot.emit$pool_encode$fn__90000064")

var Lit_256 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_257 *jrt.String = jrt.Intern("arbace.aot.emit$pool_fields$fn__90000068")

var Lit_258 *jrt.String = jrt.Intern("arbace.aot.emit$pool_fields$walk__90000070")

var Lit_259 *jrt.String = jrt.Intern("arbace.aot.emit$pool_fields$fn__90000076")

var Lit_260 *jrt.String = jrt.Intern("arbace.aot.emit$pool_fields$fn__90000084")

var Lit_261 *jrt.String = jrt.Intern("arbace.aot.emit$pool_fields$fn__90000090")

var Lit_262 *jrt.String = jrt.Intern("arbace.aot.emit$pool_fields$fn__90000096")

var Lit_263 *jrt.String = jrt.Intern("arbace.aot.emit$pool_fields$fn__90000105")

var Lit_264 *jrt.String = jrt.Intern("arbace.aot.emit$pool_fields$iter__90000110__90000114")

var Lit_265 *jrt.String = jrt.Intern("arbace.aot.emit$pool_fields$iter__90000110__90000114$fn__90000115")

var Lit_266 *jrt.String = jrt.Intern("arbace.aot.emit$pool_fields$iter__90000110__90000114$fn__90000115$fn__90000116")

var Lit_267 *jrt.String = jrt.Intern("arbace.aot.emit$registered_QMARK_$fn__90000021")

var Lit_268 *jrt.String = jrt.Intern("arbace.aot.emit$registered_QMARK_$fn__90000023")

var Lit_269 *jrt.String = jrt.Intern("arbace.aot.emit$registered_QMARK_$fn__90000023$fn__90000024")

var Lit_270 *jrt.String = jrt.Intern("cut")

var Lit_271 *jrt.String = jrt.Intern("mismatched primitive return, expected ")

var Lit_272 *jrt.String = jrt.Intern(", had ")

var Lit_273 *jrt.String = jrt.Intern("arbace.aot.emit$typed_args$fn__90000144")

var Lit_274 *jrt.String = jrt.Intern("uncheckedIntCast")

var Lit_275 *jrt.String = jrt.Intern("intCast")

var Lit_276 *jrt.String = jrt.Intern("uncheckedFloatCast")

var Lit_277 *jrt.String = jrt.Intern("floatCast")

var Lit_278 *jrt.String = jrt.Intern("uncheckedDoubleCast")

var Lit_279 *jrt.String = jrt.Intern("doubleCast")

var Lit_280 *jrt.String = jrt.Intern("uncheckedLongCast")

var Lit_281 *jrt.String = jrt.Intern("longCast")

var Lit_282 *jrt.String = jrt.Intern("uncheckedByteCast")

var Lit_283 *jrt.String = jrt.Intern("byteCast")

var Lit_284 *jrt.String = jrt.Intern("uncheckedShortCast")

var Lit_285 *jrt.String = jrt.Intern("shortCast")

var Lit_286 *jrt.String = jrt.Intern("arbace.lang.RT")

var Lit_287 *jrt.String = jrt.Intern("arbace.aot.emit$unit_method$iter__90000509__90000513")

var Lit_288 *jrt.String = jrt.Intern("a top-level fn closing over locals")

var Lit_289 *jrt.String = jrt.Intern("arbace.aot.emit$unit_method$iter__90000509__90000513$fn__90000514")

var Lit_290 *jrt.String = jrt.Intern("arbace.aot.emit$unit_method$iter__90000509__90000513$fn__90000514$fn__90000515")

var Lit_291 *jrt.String = jrt.Intern("type")

var Lit_292 *jrt.String = jrt.Intern("an event of a class made at run time: ")

var Lit_293 *jrt.String = jrt.Intern("iface")

var Lit_294 *jrt.String = jrt.Intern("proxy")

var Lit_295 *jrt.String = jrt.Intern("arbace.aot.emit$unit_method$iter__90000509__90000513$fn__90000514$fn__90000521")

var Lit_296 *jrt.String = jrt.Intern("imethod")

var Lit_297 *jrt.String = jrt.Intern("stub")

var Lit_298 *jrt.String = jrt.Intern("ns")

var Lit_299 *jrt.String = jrt.Intern("an event of kind ")

var Lit_300 *jrt.String = jrt.Intern("arbace.aot.emit$unit_method$iter__90000509__90000513$fn__90000514$fn__90000515$fn__90000517")

var Lit_301 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn4,linekn6,columnkn4,filekn8,arglistsyn1,xyn3,msgyn1,&yn4,datakn3,tagyn6,Stringyn5,Classyn4,voidyn6,doubleyn4,charyn4,byteyn7,booleanyn5,floatyn4,longyn5,shortyn3,intyn1,syn1,cyn3,ctxyn3,topyn1,vyn5,ctypekn8,declaredyn2,xsyn9,Characterkn4,longkn6,doublekn3,intkn6,symbolkn6,stringkn6,vectorkn4,listkn3,varkn7,keywordkn5,classkn3,nilkn3,setkn7,booleankn3,mapkn4,charkn7,patternyn13,StringBuilderyn6,sharedyn6,constsyn4,baseyn1,byn2,lbyn1,eyn1,nyn1,fyn2,psyn2,esyn3,Varyn8,unboxed?yn24,java.lang.reflect.Methodyn1,tyn4,argsyn23,java.lang.reflect.Fieldyn4,top?yn3,symyn4,inityn2,oxyn10,nil-localsyn4,bodyys14,java.lang.Long7,valueOfys16,java.lang.Double7,valueOfys17,java.lang.Integer7,valueOfys17,java.lang.Boolean7,valueOfys19,java.lang.Character7,valueOfys15,java.lang.Float7,valueOfys15,java.lang.Short7,valueOfys14,java.lang.Byte7,valueOfyn2,mnyn6,paramsyn3,tagyn1,kyn4,kindyn4,lineyn6,columnyn1,_yn4,expryn6,eventsv11,arbace.core5,in-nsMyn15,arbace.aot.emitm2,R0,s1622,Standalone S6 (doc/STANDALONE-NOTES.md, \"S6: Arbace compiled to Go\"): the back end that\n  compiles analyzed namespaces to class forms, which a2g translates into Go like the runtime's\n  own classes.\n\n  The input is what the program records while it prepares its namespaces (ARBACE_COMPILE): for\n  each source, its units in order (a top-level form, analyzed: Compiler$Image's unit, its Expr\n  tree and the events of its analysis), read through Compiler$AST/node, which shows a node's\n  fields as a map. The output follows the JVM's bytecode back end (Compiler.clj on the branch\n  arbace-for-java-26: ObjExpr.compile, the emit methods), with class forms in place of\n  bytecode:\n\n  - a fn (FnExpr) is a class named as the JVM names it (arbace.walk$walk), a static member\n    class of a holder class per namespace (arbace.walk), nested as its name nests; it extends\n    AFunction (RestFn when variadic), its closed-over locals are fields set by its constructor,\n    each arity an invoke method (doInvoke for the variadic one), its constants static fields;\n  - a source's top-level forms are the static methods of its loader class SCRIPTBASE__init\n    (arbace.walk__init), whose load() runs them in order; Compiler$AOT/load calls it in the\n    bindings Compiler.load makes; past loader-part-units units, in parts, static member\n    classes SCRIPTBASE__init$partP (SA210);\n  - each Expr becomes the class forms code its emit method's bytecode is: interop on the\n    analyzer's resolved members (param-tags pin the overload), reflection where it was\n    unresolved, Clojure's boxing and conversions (emitBoxReturn, emitTypedArgs).m2,R0,s1622,Standalone S6 (doc/STANDALONE-NOTES.md, \"S6: Arbace compiled to Go\"): the back end that\n  compiles analyzed namespaces to class forms, which a2g translates into Go like the runtime's\n  own classes.\n\n  The input is what the program records while it prepares its namespaces (ARBACE_COMPILE): for\n  each source, its units in order (a top-level form, analyzed: Compiler$Image's unit, its Expr\n  tree and the events of its analysis), read through Compiler$AST/node, which shows a node's\n  fields as a map. The output follows the JVM's bytecode back end (Compiler.clj on the branch\n  arbace-for-java-26: ObjExpr.compile, the emit methods), with class forms in place of\n  bytecode:\n\n  - a fn (FnExpr) is a class named as the JVM names it (arbace.walk$walk), a static member\n    class of a holder class per namespace (arbace.walk), nested as its name nests; it extends\n    AFunction (RestFn when variadic), its closed-over locals are fields set by its constructor,\n    each arity an invoke method (doInvoke for the variadic one), its constants static fields;\n  - a source's top-level forms are the static methods of its loader class SCRIPTBASE__init\n    (arbace.walk__init), whose load() runs them in order; Compiler$AOT/load calls it in the\n    bindings Compiler.load makes; past loader-part-units units, in parts, static member\n    classes SCRIPTBASE__init$partP (SA210);\n  - each Expr becomes the class forms code its emit method's bytecode is: interop on the\n    analyzer's resolved members (param-tags pin the overload), reflection where it was\n    unresolved, Clojure's boxing and conversions (emitBoxReturn, emitTypedArgs).R1,v15,arbace.aot.emit10,node-cachem10,R2,TR3,i35,R4,i1,R5,s18,arbace/aot/emit.aeR0,s58,The nodes' maps by node (the back end runs on one thread).v15,arbace.aot.emit4,nodem10,R6,L1,V1,R7,R0,s62,The analyzed node x as a map (Compiler$AST/node), nil for nil.R3,i39,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit4,failm10,R2,TR6,L1,V3,R8,R9,V1,R10,R3,i48,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit6,destubm10,R6,L1,V1,Myn1,nm2,R11,R12,R0,s74,A class name without the compile stub's prefix (Compiler.destubClassName).R3,i54,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit8,type-symm10,R6,L1,V1,Myn1,cm2,R11,R13,R0,s94,The class forms type of class c: a primitive's name, a class's binary name, an array as\n  T/n.R3,i59,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,prim-namesR14,R15,R16,R17,R18,R19,R20,R21,R22,m8,R2,TR3,i70,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit6,taggedm12,R2,TR6,L1,V2,R23,R24,R0,s45,Symbol s with the class forms tag of class c.R3,i74,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,registeredv11,arbace.core4,atomm10,R2,TR3,i83,R4,i1,R5,s18,arbace/aot/emit.aeR0,s84,Whether a class name is registered in the program (Class/forName finds it), by name.v15,arbace.aot.emit11,registered?m10,R2,TR6,L1,V1,Myn1,cm2,R11,R13,R3,i87,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit14,runtime-class?m12,R2,TR6,L1,V2,Myn1,cm2,R11,R13,R25,R0,s291,Is class c made at run time (a Dyn class: an evaluated fn's, deftype's, interface's, proxy's)\n  rather than a class of the program, or one the program does not register by name (java.sql's,\n  whose members reflection reached from a world class)? Such a class is not named in compiled\n  code.R3,i104,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit7,public?m10,R2,TR6,L1,V1,Myn1,cm2,R11,R13,R3,i113,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit8,top-namem10,R2,TR6,L1,V1,Myn1,nm2,R11,R12,R3,i119,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit4,poolm12,R2,TR6,L1,V2,R25,R26,R0,s178,The constants of top-level class top (a namespace's holder, a deftype, a loader), which its\n  member classes share (SA145): an atom {:name :consts :const-map}, made on first use.R3,i121,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit11,const-fieldm12,R2,TR6,L1,V3,R25,R27,R28,R0,s236,The static field holding constant value v in the class being emitted, made on first use (as\n  the JVM's const__N, one per distinct object): its symbol, const-N (a munged local's name has\n  no -, so no local, name__index, can shadow it).R3,i131,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,emit-valuem8,R29,TR3,i152,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit15,emit-list-arraym10,R2,TR6,L1,V2,R25,R30,R3,i154,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,char-formm10,R2,TR6,L1,V1,Myn1,cm2,R11,R31,R3,i157,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit11,double-formm10,R2,TR6,L1,V1,Myn1,dm2,R11,R15,R3,i163,R4,i1,R5,s18,arbace/aot/emit.aem10,R6,L1,V2,R25,R27,R0,s72,Code making constant value v (ObjExpr.emitValue), its metadata included.R3,i168,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,pool-kindm12,R2,TR6,L1,V1,R27,R0,s58,The tag of constant v, in the order of emit-value's cases.R3,i244,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit12,pool-partialS16,R32,R33,R34,R35,R36,R37,R38,R39,R40,R41,R42,R43,R44,R45,R46,R47,m10,R2,TR3,i269,R4,i1,R5,s18,arbace/aot/emit.aeR0,s61,The kinds whose metadata is made too (emit-value's partial?).v15,arbace.aot.emit12,pool-shared?m12,R2,TR6,L1,V1,R27,R0,s84,Is v made once in a pool and named where used: a keyword, a symbol without metadata.R3,i273,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,pool-partsm12,R2,TR6,L1,V1,R27,R0,s62,The values constant v is made of (its elements, its metadata).R3,i278,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit8,pool-strm10,R2,TR6,L1,V2,Myn2,sbm2,R11,R48,Myn1,sm2,R11,R12,R3,i289,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit11,pool-encodem12,R2,TR6,L1,V3,Myn2,sbm2,R11,R48,R49,R27,R0,s102,Appends the encoding of v to sb (Compiler$AOT/poolValue's format); shared: shared value →\n  its index.R3,i292,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit11,pool-fieldsm12,R2,TR6,L1,V1,R50,R0,s264,The static fields of constants consts ([sym type value alias] ...): the pool's array, decoded\n  once (Compiler$AOT/pool), then each constant's field, its element, or for one with an alias\n  (a split loader's constant an earlier part made, SA210) that part's field.R3,i340,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,const-typem10,R2,TR6,L1,V1,R27,R3,i373,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit8,constantm10,R2,TR6,L1,V2,R25,R27,R3,i379,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit4,gsymm12,R2,TR6,L1,V2,R25,R51,R0,s146,A fresh name for a temporary of the emitted code, numbered per class being emitted (the\n  output does not depend on the program's gensym counter).R3,i392,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,local-symm12,R2,TR6,L1,V1,R52,R0,s96,The class forms local of LocalBinding lb (its node b): its name and index, unique in a\n  method.R3,i400,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit12,identity-setm12,R2,TR6,L1,V1,R30,R0,s259,The objects of xs as a set by identity. A fn's closes map cannot be asked containsKey: its\n  keys, LocalBindings, hash by their index (Arbace's deterministic hashCode), and FnExpr.parse\n  renumbers a direct fn's arguments after its inner fns closed over them.R3,i406,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit7,closed?m10,R2,TR6,L1,V2,R25,R53,R3,i415,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,field-symm10,R2,TR6,L1,V1,R52,R3,i419,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,field-readm10,R2,TR6,L1,V3,R25,R53,R52,R3,i421,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit4,emitm8,R29,TR3,i427,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit12,emit-unboxedm8,R29,TR3,i427,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit14,emit-fn-class!m8,R29,TR3,i427,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit19,emit-deftype-class!m8,R29,TR3,i427,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,emit-bodym8,R29,TR3,i427,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit4,primm10,R2,TR6,L1,V1,R54,R3,i429,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,can-prim?m10,R2,TR6,L1,V1,R55,R3,i431,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit6,box-ofm8,R29,TR3,i433,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit3,boxm12,R2,TR6,L1,V2,R56,Myn1,cm2,R11,R13,R0,s113,Form f of type c as a boxed value (emitBoxReturn: valueOf, long's Numbers.num being\n  Long.valueOf; void as nil).R3,i435,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,unbox-argm12,R2,TR6,L1,V3,R25,R56,Myn1,pm2,R11,R13,R0,s67,Boxed form f converted to parameter type p (HostExpr.emitUnboxArg).R3,i444,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit3,fi?m12,R2,TR6,L1,V1,Myn1,pm2,R11,R13,R0,s136,Is p a functional interface a fn argument is adapted to (Clojure 1.12's FISupport, as the\n  analysis decides it: Compiler$AST/fiMethod)?R3,i463,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,typed-argsm12,R2,TR6,L1,V3,R25,R57,R58,R0,s70,The arguments es as parameters of types ps (MethodExpr.emitTypedArgs).R3,i470,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,param-tagsm10,R2,TR6,L1,V1,R57,R3,i494,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,obj-arraym10,R2,TR6,L1,V2,R25,R58,R3,i496,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,var-valuem10,R2,TR6,L1,V2,R25,Myn1,vm2,R11,R59,R3,i499,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,line-metam10,R2,TR6,L1,V2,R56,R55,R3,i503,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,emit-localm10,R2,TR6,L1,V3,R25,R55,R60,R3,i508,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit11,emit-invokem10,R2,TR6,L1,V2,R25,R55,R3,i520,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,descriptorm10,R2,TR6,L1,V1,Myn1,cm2,R11,R13,R3,i550,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit8,jrt-scanm8,R2,TR3,i558,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,jrt-lacks?m12,R2,TR6,L1,V1,Myn1,mm2,R11,R61,R0,s255,Is method m declared by a class jrt writes by hand (not a stand-in a2g's translation\n  replaces) without it in Go? a2g would translate a direct call to a throw; the member tables\n  (reflection) have such members, so compiled code calls them by reflection.R3,i561,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit11,method-callm12,R2,TR6,L1,V4,R25,Myn1,mm2,R11,R61,R62,R63,R0,s69,A call of resolved method m: static (target nil) or on target form t.R3,i580,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit19,compiled-interface?m12,R2,TR6,L1,V2,R25,Myn1,cm2,R11,R13,R0,s86,Is class c an interface of a namespace being compiled (gen-interface's, a protocol's)?R3,i593,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit20,emit-instance-methodm10,R2,TR6,L1,V3,R25,R55,R60,R3,i598,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit18,emit-static-methodm10,R2,TR6,L1,V3,R25,R55,R60,R3,i631,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,field-ok?m10,R2,TR6,L1,V2,R25,Myn1,fm2,R11,R64,R3,i645,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit19,emit-instance-fieldm10,R2,TR6,L1,V3,R25,R55,R60,R3,i648,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit17,emit-static-fieldm10,R2,TR6,L1,V3,R25,R55,R60,R3,i657,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit8,emit-newm10,R2,TR6,L1,V2,R25,R55,R3,i665,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit8,emit-defm10,R2,TR6,L1,V3,R25,R55,R65,R3,i674,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit11,emit-assignm10,R2,TR6,L1,V2,R25,R55,R3,i692,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,coll-callm10,R2,TR6,L1,V3,R66,R58,R25,R3,i714,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit7,emit-ifm10,R2,TR6,L1,V3,R25,R55,R60,R3,i717,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit17,emit-binding-initm12,R2,TR6,L1,V3,R25,R53,R67,R0,s69,A let or loop binding [sym init] of LocalBinding lb (LetExpr.doEmit).R3,i726,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit8,emit-letm10,R2,TR6,L1,V3,R25,R55,R60,R3,i735,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,emit-recurm10,R2,TR6,L1,V2,R25,R55,R3,i742,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit13,body-instancem12,R2,TR6,L1,V3,R25,R68,R69,R0,s228,A new instance of fn or reify class ox (its node), its closed-over values from the current\n  method: (new C closed...) (ObjExpr.emit); letfn's own locals nil (set after). A fn's is its\n  code (SA141), which fn-wrap makes the fn.R3,i763,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit7,fn-wrapm12,R2,TR6,L1,V3,R25,R68,R70,R0,s135,The fn of fn ox (its node) whose code is form body: a Compiler$AOTFn, or a\n  Compiler$AOTRestFn of the variadic arity's required count.R3,i776,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit11,fn-instancem12,R2,TR6,L1,V3,R25,R68,R69,R0,s33,A new fn or reify (ox, its node).R3,i799,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,emit-letfnm10,R2,TR6,L1,V3,R25,R55,R60,R3,i805,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit8,emit-trym10,R2,TR6,L1,V3,R25,R55,R60,R3,i822,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,emit-casem10,R2,TR6,L1,V3,R25,R55,R60,R3,i831,R4,i1,R5,s18,arbace/aot/emit.aeR71,R72,R73,R74,R75,R76,R77,R78,m8,R2,TR3,i878,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit8,box-primm12,R2,TR6,L1,V2,R56,R55,R0,s200,Form f of node n boxed when it is of a primitive type (emitBoxReturn: valueOf, long's\n  Numbers.num being Long.valueOf), so that emit's code is always a reference, as the bytecode's\n  emit leaves one.R3,i884,R4,i1,R5,s18,arbace/aot/emit.aem10,R6,L1,V2,R25,R54,R0,s59,Code for analyzed node e, its value boxed (an Expr's emit).R3,i895,R4,i1,R5,s18,arbace/aot/emit.aem10,R6,L1,V2,R25,R54,R0,s72,Code for analyzed node e, its value of its primitive type (emitUnboxed).R3,i971,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit4,deepm12,R2,TR6,L1,V1,R56,R0,s160,Form f realized throughout (the emitters build lazy seqs; what they record, the constants\n  and the classes, must be recorded before it is read), metadata kept.R3,i1003,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit11,simple-namem10,R2,TR6,L1,V1,Myn6,binarym2,R11,R12,R3,i1012,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit7,throws?m12,R2,TR6,L1,V1,R54,R0,s86,Does node e end in a throw (a form that does not complete, which needs no conversion)?R3,i1015,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit8,ret-bodym12,R2,TR6,L1,V3,R25,R70,Myn3,retm2,R11,R13,R0,s148,A deftype's method body as returned in type ret (ObjMethod.emitBody): unboxed when it can be,\n  else boxed then cast or unboxed as ASM's unbox does.R3,i1024,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit11,method-bodym12,R2,TR6,L1,V3,R25,R79,R80,R0,s147,The body of FnMethod or NewInstanceMethod m (its node), in the method's context: wrapped in\n  a loop over its parameters when a recur targets them.R3,i1050,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,param-symm10,R2,TR6,L1,V1,R53,R3,i1087,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit12,prim-classesR20,R15,R22,R18,R16,R19,R21,R17,m8,R2,TR3,i1093,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,tag-classm12,R2,TR6,L1,V1,R81,R0,s70,The class a field's tag names (Compiler.tagClass): Object without one.R3,i1097,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,box-classm10,R2,TR6,L1,V1,Myn1,cm2,R11,R13,R3,i1106,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit16,class-interfacesm12,R2,TR6,L1,V2,R25,R68,R0,s179,The interfaces of a deftype's or reify's class (its node ox), as the analysis made the\n  class: their names. A class of the program cannot implement an interface made at run time.R3,i1110,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,field-modsm12,R2,TR6,L1,V2,R68,R53,R0,s104,The modifiers of a deftype's field lb (ObjExpr.compile): volatile, mutable (package), or\n  public final.R3,i1121,R4,i1,R5,s18,arbace/aot/emit.aem10,R6,L1,V2,R25,R68,R0,s202,Defines deftype ox's class (its node), a top-level class named as the deftype, once:\n  its fields, constructors, getBasis (and create for a record), and methods\n  (NewInstanceExpr.compile, emitStatics).R3,i1131,R4,i1,R5,s18,arbace/aot/emit.aem10,R6,L1,V2,R25,R68,R0,s109,Defines the class of fn or reify ox (its node) once, in the classes being emitted; returns\n  its binary name.R3,i1198,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit11,unit-methodm12,R2,TR6,L1,V3,R25,R82,V7,R83,R84,R85,R86,R86,R87,R88,R0,s96,The static method unitK of a source's loader class: unit u's events made again, then its\n  code.R3,i1285,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit7,unit-nsm12,R2,TR6,L1,V1,V6,R83,R86,R86,R86,R86,R87,R0,s79,The namespace unit u was analyzed in: its fn's (kind 1) or its def's, else nil.R3,i1326,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit17,loader-part-unitsl100,m8,R3,i1337,R4,i1,R5,s18,arbace/aot/emit.aeR0,s251,The most units a source's loader class holds itself; a source of more is split into parts of\n  as many (SA210): a2g analyzes classes in parallel, one class on one thread (arbace.core's 903\n  units were one task of 9 to 14 s, the last of the analysis).")

var Lit_302 *jrt.String = jrt.Intern("arbace.aot.emit$eval90000004$loading__1927001464__auto____90000005")

var Lit_303 *jrt.String = jrt.Intern("arbace.aot.emit$eval90000008$fn__90000009")

var Lit_304 *jrt.String = jrt.Intern("arbace.aot.emit$node")

var Lit_305 *jrt.String = jrt.Intern("arbace.aot.emit$fail")

var Lit_306 *jrt.String = jrt.Intern("arbace.aot.emit$destub")

var Lit_307 *jrt.String = jrt.Intern("arbace.aot.emit$type_sym")

var Lit_308 *jrt.String = jrt.Intern("arbace.aot.emit$tagged")

var Lit_309 *jrt.String = jrt.Intern("arbace.aot.emit$registered_QMARK_")

var Lit_310 *jrt.String = jrt.Intern("arbace.aot.emit$runtime_class_QMARK_")

var Lit_311 *jrt.String = jrt.Intern("arbace.aot.emit$public_QMARK_")

var Lit_312 *jrt.String = jrt.Intern("arbace.aot.emit$top_name")

var Lit_313 *jrt.String = jrt.Intern("arbace.aot.emit$pool")

var Lit_314 *jrt.String = jrt.Intern("arbace.aot.emit$const_field")

var Lit_315 *jrt.String = jrt.Intern("arbace.aot.emit$emit_list_array")

var Lit_316 *jrt.String = jrt.Intern("arbace.aot.emit$char_form")

var Lit_317 *jrt.String = jrt.Intern("arbace.aot.emit$double_form")

var Lit_318 *jrt.String = jrt.Intern("arbace.aot.emit$emit_value")

var Lit_319 *jrt.String = jrt.Intern("arbace.aot.emit$pool_kind")

var Lit_320 *jrt.String = jrt.Intern("arbace.aot.emit$pool_shared_QMARK_")

var Lit_321 *jrt.String = jrt.Intern("arbace.aot.emit$pool_parts")

var Lit_322 *jrt.String = jrt.Intern("arbace.aot.emit$pool_str")

var Lit_323 *jrt.String = jrt.Intern("arbace.aot.emit$pool_encode")

var Lit_324 *jrt.String = jrt.Intern("arbace.aot.emit$pool_fields")

var Lit_325 *jrt.String = jrt.Intern("arbace.aot.emit$const_type")

var Lit_326 *jrt.String = jrt.Intern("arbace.aot.emit$constant")

var Lit_327 *jrt.String = jrt.Intern("arbace.aot.emit$gsym")

var Lit_328 *jrt.String = jrt.Intern("arbace.aot.emit$local_sym")

var Lit_329 *jrt.String = jrt.Intern("arbace.aot.emit$identity_set")

var Lit_330 *jrt.String = jrt.Intern("arbace.aot.emit$closed_QMARK_")

var Lit_331 *jrt.String = jrt.Intern("arbace.aot.emit$field_sym")

var Lit_332 *jrt.String = jrt.Intern("arbace.aot.emit$field_read")

var Lit_333 *jrt.String = jrt.Intern("arbace.aot.emit$prim")

var Lit_334 *jrt.String = jrt.Intern("arbace.aot.emit$can_prim_QMARK_")

var Lit_335 *jrt.String = jrt.Intern("arbace.aot.emit$box")

var Lit_336 *jrt.String = jrt.Intern("arbace.aot.emit$unbox_arg")

var Lit_337 *jrt.String = jrt.Intern("arbace.aot.emit$fi_QMARK_")

var Lit_338 *jrt.String = jrt.Intern("arbace.aot.emit$typed_args")

var Lit_339 *jrt.String = jrt.Intern("arbace.aot.emit$param_tags")

var Lit_340 *jrt.String = jrt.Intern("arbace.aot.emit$obj_array")

var Lit_341 *jrt.String = jrt.Intern("arbace.aot.emit$var_value")

var Lit_342 *jrt.String = jrt.Intern("arbace.aot.emit$line_meta")

var Lit_343 *jrt.String = jrt.Intern("arbace.aot.emit$emit_local")

var Lit_344 *jrt.String = jrt.Intern("arbace.aot.emit$emit_invoke")

var Lit_345 *jrt.String = jrt.Intern("arbace.aot.emit$descriptor")

var Lit_346 *jrt.String = jrt.Intern("arbace.aot.emit$fn__90000165")

var Lit_347 *jrt.String = jrt.Intern("arbace.aot.emit$jrt_lacks_QMARK_")

var Lit_348 *jrt.String = jrt.Intern("arbace.aot.emit$method_call")

var Lit_349 *jrt.String = jrt.Intern("arbace.aot.emit$compiled_interface_QMARK_")

var Lit_350 *jrt.String = jrt.Intern("arbace.aot.emit$emit_instance_method")

var Lit_351 *jrt.String = jrt.Intern("arbace.aot.emit$emit_static_method")

var Lit_352 *jrt.String = jrt.Intern("arbace.aot.emit$field_ok_QMARK_")

var Lit_353 *jrt.String = jrt.Intern("arbace.aot.emit$emit_instance_field")

var Lit_354 *jrt.String = jrt.Intern("arbace.aot.emit$emit_static_field")

var Lit_355 *jrt.String = jrt.Intern("arbace.aot.emit$emit_new")

var Lit_356 *jrt.String = jrt.Intern("arbace.aot.emit$emit_def")

var Lit_357 *jrt.String = jrt.Intern("arbace.aot.emit$emit_assign")

var Lit_358 *jrt.String = jrt.Intern("arbace.aot.emit$coll_call")

var Lit_359 *jrt.String = jrt.Intern("arbace.aot.emit$emit_if")

var Lit_360 *jrt.String = jrt.Intern("arbace.aot.emit$emit_binding_init")

var Lit_361 *jrt.String = jrt.Intern("arbace.aot.emit$emit_let")

var Lit_362 *jrt.String = jrt.Intern("arbace.aot.emit$emit_recur")

var Lit_363 *jrt.String = jrt.Intern("arbace.aot.emit$body_instance")

var Lit_364 *jrt.String = jrt.Intern("arbace.aot.emit$fn_wrap")

var Lit_365 *jrt.String = jrt.Intern("arbace.aot.emit$fn_instance")

var Lit_366 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn")

var Lit_367 *jrt.String = jrt.Intern("arbace.aot.emit$emit_try")

var Lit_368 *jrt.String = jrt.Intern("arbace.aot.emit$emit_case")

var Lit_369 *jrt.String = jrt.Intern("arbace.aot.emit$box_prim")

var Lit_370 *jrt.String = jrt.Intern("arbace.aot.emit$emit")

var Lit_371 *jrt.String = jrt.Intern("arbace.aot.emit$emit_unboxed")

var Lit_372 *jrt.String = jrt.Intern("arbace.aot.emit$deep")

var Lit_373 *jrt.String = jrt.Intern("arbace.aot.emit$simple_name")

var Lit_374 *jrt.String = jrt.Intern("arbace.aot.emit$throws_QMARK_")

var Lit_375 *jrt.String = jrt.Intern("arbace.aot.emit$ret_body")

var Lit_376 *jrt.String = jrt.Intern("arbace.aot.emit$method_body")

var Lit_377 *jrt.String = jrt.Intern("arbace.aot.emit$param_sym")

var Lit_378 *jrt.String = jrt.Intern("arbace.aot.emit$tag_class")

var Lit_379 *jrt.String = jrt.Intern("arbace.aot.emit$box_class")

var Lit_380 *jrt.String = jrt.Intern("arbace.aot.emit$class_interfaces")

var Lit_381 *jrt.String = jrt.Intern("arbace.aot.emit$field_mods")

var Lit_382 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_")

var Lit_383 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_")

var Lit_384 *jrt.String = jrt.Intern("arbace.aot.emit$unit_method")

var Lit_385 *jrt.String = jrt.Intern("arbace.aot.emit$unit_ns")

var Lit_386 *jrt.String = jrt.Intern("kn8,arglistsyn7,classesyn15,runtime-classesyn8,fn-namesyn5,poolsyn3,srcyn5,unitskn3,dockn4,linekn6,columnkn4,filekn7,privateyn1,cyn11,children-ofyn4,top?yn4,nameyn7,extendsyn7,methodsv15,arbace.aot.emit11,emit-sourcem10,R0,L1,V6,R1,R2,R3,R4,R5,R6,R7,s260,The class forms of source path src (scriptbase.ae), compiled from its units: the loader\n  class SCRIPTBASE__init's form and the fn classes made, into the atom classes (fn-names: the\n  fns' class names by their FnExpr, an IdentityHashMap shared by the sources).R8,i1343,R9,i1,R10,s18,arbace/aot/emit.aev15,arbace.aot.emit10,class-formm12,R11,TR0,L1,V4,R12,R13,R14,R4,R7,s289,The defclass form of class c (its record: a fn's, a reify's, a deftype's, an interface's, or\n  a holder of nested classes), its nested classes inside; at the top its full name and the\n  constants it shares with them (pools: top → its pool), else a static member class by its\n  simple name.R8,i1407,R9,i1,R10,s18,arbace/aot/emit.aev15,arbace.aot.emit11,class-formsm10,R0,L1,V2,R1,R4,R7,s262,The top-level class forms holding every class of classes (name → record), nested as their\n  binary names nest, with holder classes made for the missing levels (a namespace's fns nest\n  in a holder named as the namespace); pools: the top-level classes' constants.R8,i1440,R9,i1,R10,s18,arbace/aot/emit.aev15,arbace.aot.emit16,interface-recordm10,R0,L1,V3,R15,R16,R17,R7,s133,The record of an interface made by gen-interface (events iface and imethod): name, the\n  interfaces it extends, its abstract methods.R8,i1462,R9,i1,R10,s18,arbace/aot/emit.ae")

var Lit_387 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source")

var Lit_388 *jrt.String = jrt.Intern("arbace.aot.emit$class_form")

var Lit_389 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms")

var Lit_390 *jrt.String = jrt.Intern("arbace.aot.emit$interface_record")
