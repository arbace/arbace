//line a2g_strings.ae:1
package aot_arbace_aot_emit

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("require")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("arbace.a2g.jrt")

var Lit_7 *jrt.String = jrt.Intern("jrt")

var Lit_8 *jrt.String = jrt.Intern("arbace.a2g.names")

var Lit_9 *jrt.String = jrt.Intern("nm")

var Lit_10 *jrt.String = jrt.Intern("commute")

var Lit_11 *jrt.String = jrt.Intern("deref")

var Lit_12 *jrt.String = jrt.Intern("conj")

var Lit_13 *jrt.String = jrt.Intern("arbace.aot.emit")

var Lit_14 *jrt.String = jrt.Intern("doc")

var Lit_15 *jrt.String = jrt.Intern("Standalone S6 (doc/STANDALONE-NOTES.md, \"S6: Arbace compiled to Go\"): the back end that\n  compiles analyzed namespaces to class forms, which a2g translates into Go like the runtime's\n  own classes.\n\n  The input is what the program records while it prepares its namespaces (ARBACE_COMPILE): for\n  each source, its units in order (a top-level form, analyzed: Compiler$Image's unit, its Expr\n  tree and the events of its analysis), read through Compiler$AST/node, which shows a node's\n  fields as a map. The output follows the JVM's bytecode back end (Compiler.clj on the branch\n  arbace-for-java-26: ObjExpr.compile, the emit methods), with class forms in place of\n  bytecode:\n\n  - a fn (FnExpr) is a class named as the JVM names it (arbace.walk$walk), a static member\n    class of a holder class per namespace (arbace.walk), nested as its name nests; it extends\n    AFunction (RestFn when variadic), its closed-over locals are fields set by its constructor,\n    each arity an invoke method (doInvoke for the variadic one), its constants static fields;\n  - a source's top-level forms are the static methods of its loader class SCRIPTBASE__init\n    (arbace.walk__init), whose load() runs them in order; Compiler$AOT/load calls it in the\n    bindings Compiler.load makes;\n  - each Expr becomes the class forms code its emit method's bytecode is: interop on the\n    analyzer's resolved members (param-tags pin the overload), reflection where it was\n    unresolved, Clojure's boxing and conversions (emitBoxReturn, emitTypedArgs).")

var Lit_16 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_17 *jrt.String = jrt.Intern("some?")

var Lit_18 *jrt.String = jrt.Intern("node-cache")

var Lit_19 *jrt.String = jrt.Intern("assoc")

var Lit_20 *jrt.String = jrt.Intern("self")

var Lit_21 *jrt.String = jrt.Intern("ex-info")

var Lit_22 *jrt.String = jrt.Intern("starts-with?")

var Lit_23 *jrt.String = jrt.Intern("subs")

var Lit_24 *jrt.String = jrt.Intern("symbol")

var Lit_25 *jrt.String = jrt.Intern("type-sym")

var Lit_26 *jrt.String = jrt.Intern("destub")

var Lit_27 *jrt.String = jrt.Intern("vary-meta")

var Lit_28 *jrt.String = jrt.Intern("tag")

var Lit_29 *jrt.String = jrt.Intern("prim-names")

var Lit_30 *jrt.String = jrt.Intern("not")

var Lit_31 *jrt.String = jrt.Intern("registered")

var Lit_32 *jrt.String = jrt.Intern("swap!")

var Lit_33 *jrt.String = jrt.Intern("contains?")

var Lit_34 *jrt.String = jrt.Intern("runtime-classes")

var Lit_35 *jrt.String = jrt.Intern("registered?")

var Lit_36 *jrt.String = jrt.Intern("pools")

var Lit_37 *jrt.String = jrt.Intern("atom")

var Lit_38 *jrt.String = jrt.Intern("name")

var Lit_39 *jrt.String = jrt.Intern("consts")

var Lit_40 *jrt.String = jrt.Intern("const-map")

var Lit_41 *jrt.String = jrt.Intern("const-prefix")

var Lit_42 *jrt.String = jrt.Intern("cls")

var Lit_43 *jrt.String = jrt.Intern("update")

var Lit_44 *jrt.String = jrt.Intern("list")

var Lit_45 *jrt.String = jrt.Intern("new")

var Lit_46 *jrt.String = jrt.Intern("java.lang.Object")

var Lit_47 *jrt.String = jrt.Intern("1")

var Lit_48 *jrt.String = jrt.Intern("mapv")

var Lit_49 *jrt.String = jrt.Intern("emit-value")

var Lit_50 *jrt.String = jrt.Intern("not=")

var Lit_51 *jrt.String = jrt.Intern("unchecked-char")

var Lit_52 *jrt.String = jrt.Intern("java.lang.Double")

var Lit_53 *jrt.String = jrt.Intern("longBitsToDouble")

var Lit_54 *jrt.String = jrt.Intern("string?")

var Lit_55 *jrt.String = jrt.Intern("class?")

var Lit_56 *jrt.String = jrt.Intern("symbol?")

var Lit_57 *jrt.String = jrt.Intern("keyword?")

var Lit_58 *jrt.String = jrt.Intern("var?")

var Lit_59 *jrt.String = jrt.Intern("fail")

var Lit_60 *jrt.String = jrt.Intern("map?")

var Lit_61 *jrt.String = jrt.Intern("vector?")

var Lit_62 *jrt.String = jrt.Intern("seq?")

var Lit_63 *jrt.String = jrt.Intern("list?")

var Lit_64 *jrt.String = jrt.Intern("else")

var Lit_65 *jrt.String = jrt.Intern("pr-str")

var Lit_66 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_67 *jrt.String = jrt.Intern("java.lang.Boolean")

var Lit_68 *jrt.String = jrt.Intern("TRUE")

var Lit_69 *jrt.String = jrt.Intern("FALSE")

var Lit_70 *jrt.String = jrt.Intern("java.lang.Integer")

var Lit_71 *jrt.String = jrt.Intern("valueOf")

var Lit_72 *jrt.String = jrt.Intern("unchecked-int")

var Lit_73 *jrt.String = jrt.Intern("java.lang.Long")

var Lit_74 *jrt.String = jrt.Intern("double-form")

var Lit_75 *jrt.String = jrt.Intern("java.lang.Character")

var Lit_76 *jrt.String = jrt.Intern("char-form")

var Lit_77 *jrt.String = jrt.Intern("java.lang.Byte")

var Lit_78 *jrt.String = jrt.Intern("java.lang.Float")

var Lit_79 *jrt.String = jrt.Intern("java.lang.Short")

var Lit_80 *jrt.String = jrt.Intern("arbace.lang.RT")

var Lit_81 *jrt.String = jrt.Intern("classForNameNonLoading")

var Lit_82 *jrt.String = jrt.Intern("with-meta")

var Lit_83 *jrt.String = jrt.Intern("namespace")

var Lit_84 *jrt.String = jrt.Intern("arbace.lang.Symbol")

var Lit_85 *jrt.String = jrt.Intern("intern")

var Lit_86 *jrt.String = jrt.Intern("param-tags")

var Lit_87 *jrt.String = jrt.Intern("java.lang.String")

var Lit_88 *jrt.String = jrt.Intern("keyword")

var Lit_89 *jrt.String = jrt.Intern("var")

var Lit_90 *jrt.String = jrt.Intern("arbace.lang.Namespace")

var Lit_91 *jrt.String = jrt.Intern("findOrCreate")

var Lit_92 *jrt.String = jrt.Intern("class")

var Lit_93 *jrt.String = jrt.Intern("emit-list-array")

var Lit_94 *jrt.String = jrt.Intern("map")

var Lit_95 *jrt.String = jrt.Intern("mapcat")

var Lit_96 *jrt.String = jrt.Intern("identity")

var Lit_97 *jrt.String = jrt.Intern("list*")

var Lit_98 *jrt.String = jrt.Intern("arbace.lang.Tuple")

var Lit_99 *jrt.String = jrt.Intern("create")

var Lit_100 *jrt.String = jrt.Intern("vec")

var Lit_101 *jrt.String = jrt.Intern("repeat")

var Lit_102 *jrt.String = jrt.Intern("vector")

var Lit_103 *jrt.String = jrt.Intern("empty?")

var Lit_104 *jrt.String = jrt.Intern("arbace.lang.PersistentHashSet")

var Lit_105 *jrt.String = jrt.Intern("EMPTY")

var Lit_106 *jrt.String = jrt.Intern("seq")

var Lit_107 *jrt.String = jrt.Intern("arbace.lang.PersistentList")

var Lit_108 *jrt.String = jrt.Intern("java.util.List")

var Lit_109 *jrt.String = jrt.Intern("java.util.Arrays")

var Lit_110 *jrt.String = jrt.Intern("asList")

var Lit_111 *jrt.String = jrt.Intern("java.util.regex.Pattern")

var Lit_112 *jrt.String = jrt.Intern("compile")

var Lit_113 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_114 *jrt.String = jrt.Intern("hash-map")

var Lit_115 *jrt.String = jrt.Intern("*print-dup*")

var Lit_116 *jrt.String = jrt.Intern("readString")

var Lit_117 *jrt.String = jrt.Intern(".withMeta")

var Lit_118 *jrt.String = jrt.Intern("cast")

var Lit_119 *jrt.String = jrt.Intern("arbace.lang.IObj")

var Lit_120 *jrt.String = jrt.Intern("arbace.lang.IPersistentMap")

var Lit_121 *jrt.String = jrt.Intern("arbace.lang.Var")

var Lit_122 *jrt.String = jrt.Intern("arbace.lang.Keyword")

var Lit_123 *jrt.String = jrt.Intern("java.lang.Class")

var Lit_124 *jrt.String = jrt.Intern("runtime-class?")

var Lit_125 *jrt.String = jrt.Intern("const-field")

var Lit_126 *jrt.String = jrt.Intern("const-type")

var Lit_127 *jrt.String = jrt.Intern("gensyms")

var Lit_128 *jrt.String = jrt.Intern("fnil")

var Lit_129 *jrt.String = jrt.Intern("inc")

var Lit_130 *jrt.String = jrt.Intern("idx")

var Lit_131 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_132 *jrt.String = jrt.Intern("chunk-first")

var Lit_133 *jrt.String = jrt.Intern("first")

var Lit_134 *jrt.String = jrt.Intern("chunk-rest")

var Lit_135 *jrt.String = jrt.Intern("next")

var Lit_136 *jrt.String = jrt.Intern("closed")

var Lit_137 *jrt.String = jrt.Intern("field-sym")

var Lit_138 *jrt.String = jrt.Intern("this")

var Lit_139 *jrt.String = jrt.Intern("prim")

var Lit_140 *jrt.String = jrt.Intern("node")

var Lit_141 *jrt.String = jrt.Intern("canEmitPrimitive")

var Lit_142 *jrt.String = jrt.Intern("do")

var Lit_143 *jrt.String = jrt.Intern("box-of")

var Lit_144 *jrt.String = jrt.Intern("unchecked-math")

var Lit_145 *jrt.String = jrt.Intern(".booleanValue")

var Lit_146 *jrt.String = jrt.Intern(".charValue")

var Lit_147 *jrt.String = jrt.Intern("public?")

var Lit_148 *jrt.String = jrt.Intern("emit-unboxed")

var Lit_149 *jrt.String = jrt.Intern("emit")

var Lit_150 *jrt.String = jrt.Intern("fi?")

var Lit_151 *jrt.String = jrt.Intern("unbox-arg")

var Lit_152 *jrt.String = jrt.Intern("uncheckedIntCast")

var Lit_153 *jrt.String = jrt.Intern("intCast")

var Lit_154 *jrt.String = jrt.Intern("long")

var Lit_155 *jrt.String = jrt.Intern("unchecked-float")

var Lit_156 *jrt.String = jrt.Intern("arbace.lang.Compiler$Evaluator")

var Lit_157 *jrt.String = jrt.Intern("fiAdapt")

var Lit_158 *jrt.String = jrt.Intern("constant")

var Lit_159 *jrt.String = jrt.Intern(".get")

var Lit_160 *jrt.String = jrt.Intern(".getRawRoot")

var Lit_161 *jrt.String = jrt.Intern("line")

var Lit_162 *jrt.String = jrt.Intern("aot")

var Lit_163 *jrt.String = jrt.Intern("b")

var Lit_164 *jrt.String = jrt.Intern("closed?")

var Lit_165 *jrt.String = jrt.Intern("field-read")

var Lit_166 *jrt.String = jrt.Intern("once")

var Lit_167 *jrt.String = jrt.Intern("shouldClear")

var Lit_168 *jrt.String = jrt.Intern("canBeCleared")

var Lit_169 *jrt.String = jrt.Intern("self-sym")

var Lit_170 *jrt.String = jrt.Intern("local-sym")

var Lit_171 *jrt.String = jrt.Intern("bindingPrim")

var Lit_172 *jrt.String = jrt.Intern("let")

var Lit_173 *jrt.String = jrt.Intern("t-")

var Lit_174 *jrt.String = jrt.Intern("set!")

var Lit_175 *jrt.String = jrt.Intern("isArg")

var Lit_176 *jrt.String = jrt.Intern("args")

var Lit_177 *jrt.String = jrt.Intern("fexpr")

var Lit_178 *jrt.String = jrt.Intern(".applyTo")

var Lit_179 *jrt.String = jrt.Intern("arbace.lang.IFn")

var Lit_180 *jrt.String = jrt.Intern("obj-array")

var Lit_181 *jrt.String = jrt.Intern("arbace.lang.ArraySeq")

var Lit_182 *jrt.String = jrt.Intern(".invoke")

var Lit_183 *jrt.String = jrt.Intern("isProtocol")

var Lit_184 *jrt.String = jrt.Intern("protocolOn")

var Lit_185 *jrt.String = jrt.Intern("onMethod")

var Lit_186 *jrt.String = jrt.Intern("gsym")

var Lit_187 *jrt.String = jrt.Intern("rest")

var Lit_188 *jrt.String = jrt.Intern("tagged")

var Lit_189 *jrt.String = jrt.Intern("if")

var Lit_190 *jrt.String = jrt.Intern("box")

var Lit_191 *jrt.String = jrt.Intern("and")

var Lit_192 *jrt.String = jrt.Intern("instance?")

var Lit_193 *jrt.String = jrt.Intern("arbace.lang.Compiler$AOT")

var Lit_194 *jrt.String = jrt.Intern("isDyn")

var Lit_195 *jrt.String = jrt.Intern("typed-args")

var Lit_196 *jrt.String = jrt.Intern("replace")

var Lit_197 *jrt.String = jrt.Intern("scan")

var Lit_198 *jrt.String = jrt.Intern("classes")

var Lit_199 *jrt.String = jrt.Intern("go-class-name")

var Lit_200 *jrt.String = jrt.Intern("apply")

var Lit_201 *jrt.String = jrt.Intern("descriptor")

var Lit_202 *jrt.String = jrt.Intern("method-base")

var Lit_203 *jrt.String = jrt.Intern("into")

var Lit_204 *jrt.String = jrt.Intern("jrt-scan")

var Lit_205 *jrt.String = jrt.Intern("standin")

var Lit_206 *jrt.String = jrt.Intern("funcs")

var Lit_207 *jrt.String = jrt.Intern("struct-methods")

var Lit_208 *jrt.String = jrt.Intern("iface-methods")

var Lit_209 *jrt.String = jrt.Intern("impl-name")

var Lit_210 *jrt.String = jrt.Intern("interface")

var Lit_211 *jrt.String = jrt.Intern("kind")

var Lit_212 *jrt.String = jrt.Intern("method")

var Lit_213 *jrt.String = jrt.Intern("compiled-interface?")

var Lit_214 *jrt.String = jrt.Intern("method-call")

var Lit_215 *jrt.String = jrt.Intern("emit-instance-method")

var Lit_216 *jrt.String = jrt.Intern("qualifyingClass")

var Lit_217 *jrt.String = jrt.Intern("dyn-guarded")

var Lit_218 *jrt.String = jrt.Intern("target")

var Lit_219 *jrt.String = jrt.Intern("local")

var Lit_220 *jrt.String = jrt.Intern("target-sym")

var Lit_221 *jrt.String = jrt.Intern("methodName")

var Lit_222 *jrt.String = jrt.Intern("arbace.lang.Reflector")

var Lit_223 *jrt.String = jrt.Intern("invokeInstanceMethod")

var Lit_224 *jrt.String = jrt.Intern("jrt-lacks?")

var Lit_225 *jrt.String = jrt.Intern("invokeInstanceMethodOfClass")

var Lit_226 *jrt.String = jrt.Intern("emit-static-method")

var Lit_227 *jrt.String = jrt.Intern("invokeStaticMethod")

var Lit_228 *jrt.String = jrt.Intern("c")

var Lit_229 *jrt.String = jrt.Intern("field")

var Lit_230 *jrt.String = jrt.Intern("field-ok?")

var Lit_231 *jrt.String = jrt.Intern("fieldName")

var Lit_232 *jrt.String = jrt.Intern("requireField")

var Lit_233 *jrt.String = jrt.Intern("invokeNoArgInstanceMember")

var Lit_234 *jrt.String = jrt.Intern("boolean")

var Lit_235 *jrt.String = jrt.Intern("getStaticField")

var Lit_236 *jrt.String = jrt.Intern("ctor")

var Lit_237 *jrt.String = jrt.Intern("invokeConstructor")

var Lit_238 *jrt.String = jrt.Intern("initProvided")

var Lit_239 *jrt.String = jrt.Intern("meta")

var Lit_240 *jrt.String = jrt.Intern("concat")

var Lit_241 *jrt.String = jrt.Intern("init")

var Lit_242 *jrt.String = jrt.Intern(".bindRoot")

var Lit_243 *jrt.String = jrt.Intern(".setMeta")

var Lit_244 *jrt.String = jrt.Intern("isDynamic")

var Lit_245 *jrt.String = jrt.Intern(".setDynamic")

var Lit_246 *jrt.String = jrt.Intern("val")

var Lit_247 *jrt.String = jrt.Intern("op")

var Lit_248 *jrt.String = jrt.Intern(".set")

var Lit_249 *jrt.String = jrt.Intern("setInstanceField")

var Lit_250 *jrt.String = jrt.Intern("testExpr")

var Lit_251 *jrt.String = jrt.Intern("can-prim?")

var Lit_252 *jrt.String = jrt.Intern("thenExpr")

var Lit_253 *jrt.String = jrt.Intern("elseExpr")

var Lit_254 *jrt.String = jrt.Intern("isLoop")

var Lit_255 *jrt.String = jrt.Intern("bindingInits")

var Lit_256 *jrt.String = jrt.Intern("loop-locals")

var Lit_257 *jrt.String = jrt.Intern("binding")

var Lit_258 *jrt.String = jrt.Intern("emit-binding-init")

var Lit_259 *jrt.String = jrt.Intern("body")

var Lit_260 *jrt.String = jrt.Intern("loop")

var Lit_261 *jrt.String = jrt.Intern("loopLocals")

var Lit_262 *jrt.String = jrt.Intern("cons")

var Lit_263 *jrt.String = jrt.Intern("method-recur")

var Lit_264 *jrt.String = jrt.Intern("method-locals")

var Lit_265 *jrt.String = jrt.Intern("reset!")

var Lit_266 *jrt.String = jrt.Intern("recur")

var Lit_267 *jrt.String = jrt.Intern("emit-fn-class!")

var Lit_268 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_269 *jrt.String = jrt.Intern("chunk-append")

var Lit_270 *jrt.String = jrt.Intern("emit-local")

var Lit_271 *jrt.String = jrt.Intern("chunk-cons")

var Lit_272 *jrt.String = jrt.Intern("chunk")

var Lit_273 *jrt.String = jrt.Intern("keys")

var Lit_274 *jrt.String = jrt.Intern("closes")

var Lit_275 *jrt.String = jrt.Intern("supportsMeta")

var Lit_276 *jrt.String = jrt.Intern("variadic")

var Lit_277 *jrt.String = jrt.Intern("arbace.lang.Compiler$AOTRestFn")

var Lit_278 *jrt.String = jrt.Intern("arbace.lang.Compiler$AOTFn")

var Lit_279 *jrt.String = jrt.Intern("body-instance")

var Lit_280 *jrt.String = jrt.Intern("fn-wrap")

var Lit_281 *jrt.String = jrt.Intern("identity-set")

var Lit_282 *jrt.String = jrt.Intern("catch")

var Lit_283 *jrt.String = jrt.Intern("lb")

var Lit_284 *jrt.String = jrt.Intern("handler")

var Lit_285 *jrt.String = jrt.Intern("finallyExpr")

var Lit_286 *jrt.String = jrt.Intern("try")

var Lit_287 *jrt.String = jrt.Intern("tryExpr")

var Lit_288 *jrt.String = jrt.Intern("catchExprs")

var Lit_289 *jrt.String = jrt.Intern("finally")

var Lit_290 *jrt.String = jrt.Intern("expr")

var Lit_291 *jrt.String = jrt.Intern("shift")

var Lit_292 *jrt.String = jrt.Intern("mask")

var Lit_293 *jrt.String = jrt.Intern("bit-and-int")

var Lit_294 *jrt.String = jrt.Intern("bit-shift-right-int")

var Lit_295 *jrt.String = jrt.Intern("thens")

var Lit_296 *jrt.String = jrt.Intern("testType")

var Lit_297 *jrt.String = jrt.Intern("int")

var Lit_298 *jrt.String = jrt.Intern("default")

var Lit_299 *jrt.String = jrt.Intern("set")

var Lit_300 *jrt.String = jrt.Intern("hash-identity")

var Lit_301 *jrt.String = jrt.Intern("when")

var Lit_302 *jrt.String = jrt.Intern("arbace.lang.Util")

var Lit_303 *jrt.String = jrt.Intern("equiv")

var Lit_304 *jrt.String = jrt.Intern("break")

var Lit_305 *jrt.String = jrt.Intern("==")

var Lit_306 *jrt.String = jrt.Intern("identical?")

var Lit_307 *jrt.String = jrt.Intern("sorted-map")

var Lit_308 *jrt.String = jrt.Intern("tests")

var Lit_309 *jrt.String = jrt.Intern("hash")

var Lit_310 *jrt.String = jrt.Intern("skipCheck")

var Lit_311 *jrt.String = jrt.Intern("java.lang.Number")

var Lit_312 *jrt.String = jrt.Intern("switch")

var Lit_313 *jrt.String = jrt.Intern(".intValue")

var Lit_314 *jrt.String = jrt.Intern("label")

var Lit_315 *jrt.String = jrt.Intern("defaultExpr")

var Lit_316 *jrt.String = jrt.Intern("emit-try")

var Lit_317 *jrt.String = jrt.Intern("isDeftype")

var Lit_318 *jrt.String = jrt.Intern("fn-instance")

var Lit_319 *jrt.String = jrt.Intern("emit-def")

var Lit_320 *jrt.String = jrt.Intern("emit-invoke")

var Lit_321 *jrt.String = jrt.Intern("line-meta")

var Lit_322 *jrt.String = jrt.Intern("emit-deftype-class!")

var Lit_323 *jrt.String = jrt.Intern("coll")

var Lit_324 *jrt.String = jrt.Intern("arbace.lang.PersistentVector")

var Lit_325 *jrt.String = jrt.Intern("arbace.lang.PersistentArrayMap")

var Lit_326 *jrt.String = jrt.Intern("emit-instance-field")

var Lit_327 *jrt.String = jrt.Intern("var-value")

var Lit_328 *jrt.String = jrt.Intern("exprs")

var Lit_329 *jrt.String = jrt.Intern("k")

var Lit_330 *jrt.String = jrt.Intern("kw")

var Lit_331 *jrt.String = jrt.Intern("keep")

var Lit_332 *jrt.String = jrt.Intern("butlast")

var Lit_333 *jrt.String = jrt.Intern("last")

var Lit_334 *jrt.String = jrt.Intern("emit-if")

var Lit_335 *jrt.String = jrt.Intern("emit-assign")

var Lit_336 *jrt.String = jrt.Intern("emit-letfn")

var Lit_337 *jrt.String = jrt.Intern("n")

var Lit_338 *jrt.String = jrt.Intern("coll-call")

var Lit_339 *jrt.String = jrt.Intern("emit-let")

var Lit_340 *jrt.String = jrt.Intern("emit-recur")

var Lit_341 *jrt.String = jrt.Intern("v")

var Lit_342 *jrt.String = jrt.Intern("keyvals")

var Lit_343 *jrt.String = jrt.Intern("monitorExit")

var Lit_344 *jrt.String = jrt.Intern("emit-new")

var Lit_345 *jrt.String = jrt.Intern("throw")

var Lit_346 *jrt.String = jrt.Intern("java.lang.Throwable")

var Lit_347 *jrt.String = jrt.Intern("excExpr")

var Lit_348 *jrt.String = jrt.Intern("monitorEnter")

var Lit_349 *jrt.String = jrt.Intern("arrayToList")

var Lit_350 *jrt.String = jrt.Intern(".importClass")

var Lit_351 *jrt.String = jrt.Intern(".deref")

var Lit_352 *jrt.String = jrt.Intern("CURRENT_NS")

var Lit_353 *jrt.String = jrt.Intern("emit-static-field")

var Lit_354 *jrt.String = jrt.Intern("emit-case")

var Lit_355 *jrt.String = jrt.Intern("texts")

var Lit_356 *jrt.String = jrt.Intern("strConcat")

var Lit_357 *jrt.String = jrt.Intern(".isInstance")

var Lit_358 *jrt.String = jrt.Intern("type")

var Lit_359 *jrt.String = jrt.Intern("box-prim")

var Lit_360 *jrt.String = jrt.Intern("deep")

var Lit_361 *jrt.String = jrt.Intern("throws?")

var Lit_362 *jrt.String = jrt.Intern("retClass")

var Lit_363 *jrt.String = jrt.Intern("ret-body")

var Lit_364 *jrt.String = jrt.Intern("reqParms")

var Lit_365 *jrt.String = jrt.Intern("restParm")

var Lit_366 *jrt.String = jrt.Intern("argLocals")

var Lit_367 *jrt.String = jrt.Intern("doubleCast")

var Lit_368 *jrt.String = jrt.Intern("longCast")

var Lit_369 *jrt.String = jrt.Intern("prim-classes")

var Lit_370 *jrt.String = jrt.Intern("ns-resolve")

var Lit_371 *jrt.String = jrt.Intern("*ns*")

var Lit_372 *jrt.String = jrt.Intern("compiledClass")

var Lit_373 *jrt.String = jrt.Intern("sym")

var Lit_374 *jrt.String = jrt.Intern("volatile-mutable")

var Lit_375 *jrt.String = jrt.Intern("volatile")

var Lit_376 *jrt.String = jrt.Intern("unsynchronized-mutable")

var Lit_377 *jrt.String = jrt.Intern("public")

var Lit_378 *jrt.String = jrt.Intern("final")

var Lit_379 *jrt.String = jrt.Intern("pool")

var Lit_380 *jrt.String = jrt.Intern("hintedFields")

var Lit_381 *jrt.String = jrt.Intern("altCtorDrops")

var Lit_382 *jrt.String = jrt.Intern("take")

var Lit_383 *jrt.String = jrt.Intern("m__")

var Lit_384 *jrt.String = jrt.Intern("method-body")

var Lit_385 *jrt.String = jrt.Intern("field-mods")

var Lit_386 *jrt.String = jrt.Intern("pending")

var Lit_387 *jrt.String = jrt.Intern("objx")

var Lit_388 *jrt.String = jrt.Intern("constructor")

var Lit_389 *jrt.String = jrt.Intern("super.")

var Lit_390 *jrt.String = jrt.Intern("column")

var Lit_391 *jrt.String = jrt.Intern("this.")

var Lit_392 *jrt.String = jrt.Intern("getBasis")

var Lit_393 *jrt.String = jrt.Intern("static")

var Lit_394 *jrt.String = jrt.Intern("arbace.lang.IPersistentVector")

var Lit_395 *jrt.String = jrt.Intern("tag-class")

var Lit_396 *jrt.String = jrt.Intern(".valAt")

var Lit_397 *jrt.String = jrt.Intern("box-class")

var Lit_398 *jrt.String = jrt.Intern("map-indexed")

var Lit_399 *jrt.String = jrt.Intern("mutable")

var Lit_400 *jrt.String = jrt.Intern(".without")

var Lit_401 *jrt.String = jrt.Intern("seqOrElse")

var Lit_402 *jrt.String = jrt.Intern("methods")

var Lit_403 *jrt.String = jrt.Intern("deftype")

var Lit_404 *jrt.String = jrt.Intern("super")

var Lit_405 *jrt.String = jrt.Intern("interfaces")

var Lit_406 *jrt.String = jrt.Intern("class-interfaces")

var Lit_407 *jrt.String = jrt.Intern("members")

var Lit_408 *jrt.String = jrt.Intern("source")

var Lit_409 *jrt.String = jrt.Intern("fn-names")

var Lit_410 *jrt.String = jrt.Intern("some")

var Lit_411 *jrt.String = jrt.Intern("param-sym")

var Lit_412 *jrt.String = jrt.Intern("isVariadic")

var Lit_413 *jrt.String = jrt.Intern("doInvoke")

var Lit_414 *jrt.String = jrt.Intern("invoke")

var Lit_415 *jrt.String = jrt.Intern("top-name")

var Lit_416 *jrt.String = jrt.Intern("onceOnly")

var Lit_417 *jrt.String = jrt.Intern("meta__")

var Lit_418 *jrt.String = jrt.Intern(".-__meta")

var Lit_419 *jrt.String = jrt.Intern("fn-class")

var Lit_420 *jrt.String = jrt.Intern("arbace.lang.Compiler$Dyn")

var Lit_421 *jrt.String = jrt.Intern("defineFnClass")

var Lit_422 *jrt.String = jrt.Intern("__meta")

var Lit_423 *jrt.String = jrt.Intern("withMeta")

var Lit_424 *jrt.String = jrt.Intern("m")

var Lit_425 *jrt.String = jrt.Intern("fn")

var Lit_426 *jrt.String = jrt.Intern("reify")

var Lit_427 *jrt.String = jrt.Intern("get-proxy-class")

var Lit_428 *jrt.String = jrt.Intern("at")

var Lit_429 *jrt.String = jrt.Intern("find-ns")

var Lit_430 *jrt.String = jrt.Intern("form")

var Lit_431 *jrt.String = jrt.Intern("unit-ns")

var Lit_432 *jrt.String = jrt.Intern("unit-method")

var Lit_433 *jrt.String = jrt.Intern("defclass")

var Lit_434 *jrt.String = jrt.Intern("load")

var Lit_435 *jrt.String = jrt.Intern("range")

var Lit_436 *jrt.String = jrt.Intern("dissoc")

var Lit_437 *jrt.String = jrt.Intern("class-form")

var Lit_438 *jrt.String = jrt.Intern("simple-name")

var Lit_439 *jrt.String = jrt.Intern("holder")

var Lit_440 *jrt.String = jrt.Intern("extends")

var Lit_441 *jrt.String = jrt.Intern("implements")

var Lit_442 *jrt.String = jrt.Intern("peek")

var Lit_443 *jrt.String = jrt.Intern("pop")

var Lit_444 *jrt.String = jrt.Intern("group-by")

var Lit_445 *jrt.String = jrt.Intern("sort-by")

var Lit_446 *jrt.String = jrt.Intern("sort")

var Lit_447 *jrt.String = jrt.Intern("abstract")

var Lit_448 *jrt.String = jrt.Intern("arbace.aot.emit$body_instance")

var Lit_449 *jrt.String = jrt.Intern("new-instance")

var Lit_450 *jrt.String = jrt.Intern("arbace.aot.emit$body_instance$iter__90000117__90000121")

var Lit_451 *jrt.String = jrt.Intern("arbace.aot.emit$body_instance$iter__90000117__90000121$fn__90000122")

var Lit_452 *jrt.String = jrt.Intern("arbace.aot.emit$body_instance$iter__90000117__90000121$fn__90000122$fn__90000123")

var Lit_453 *jrt.String = jrt.Intern("arbace.aot.emit$box")

var Lit_454 *jrt.String = jrt.Intern("arbace.aot.emit$box_class")

var Lit_455 *jrt.String = jrt.Intern("arbace.aot.emit$box_prim")

var Lit_456 *jrt.String = jrt.Intern("arbace.aot.emit$can_prim_QMARK_")

var Lit_457 *jrt.String = jrt.Intern("arbace.aot.emit$char_form")

var Lit_458 *jrt.String = jrt.Intern("arbace.aot.emit$class_form")

var Lit_459 *jrt.String = jrt.Intern("arbace.aot.emit$class_form$fn__90000488")

var Lit_460 *jrt.String = jrt.Intern("arbace.aot.emit$class_form$iter__90000493__90000497")

var Lit_461 *jrt.String = jrt.Intern("arbace.aot.emit$class_form$iter__90000493__90000497$fn__90000498")

var Lit_462 *jrt.String = jrt.Intern("arbace.aot.emit$class_form$iter__90000493__90000497$fn__90000498$fn__90000499")

var Lit_463 *jrt.String = jrt.Intern("arbace.aot.emit$class_form$mods__90000490")

var Lit_464 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms")

var Lit_465 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$children_of__90000527")

var Lit_466 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$fn__90000513")

var Lit_467 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$fn__90000525")

var Lit_468 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$iter__90000515__90000519")

var Lit_469 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$iter__90000515__90000519$fn__90000520")

var Lit_470 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$iter__90000515__90000519$fn__90000520$fn__90000521")

var Lit_471 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$iter__90000529__90000533")

var Lit_472 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$iter__90000529__90000533$fn__90000534")

var Lit_473 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$iter__90000529__90000533$fn__90000534$fn__90000535")

var Lit_474 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$parent__90000511")

var Lit_475 *jrt.String = jrt.Intern("$")

var Lit_476 *jrt.String = jrt.Intern("arbace.aot.emit$class_interfaces")

var Lit_477 *jrt.String = jrt.Intern("no class for ")

var Lit_478 *jrt.String = jrt.Intern("arbace.aot.emit$class_interfaces$iter__90000240__90000244")

var Lit_479 *jrt.String = jrt.Intern("arbace.aot.emit$class_interfaces$iter__90000240__90000244$fn__90000245")

var Lit_480 *jrt.String = jrt.Intern(" implements ")

var Lit_481 *jrt.String = jrt.Intern(", made at run time")

var Lit_482 *jrt.String = jrt.Intern("arbace.aot.emit$class_interfaces$iter__90000240__90000244$fn__90000245$fn__90000246")

var Lit_483 *jrt.String = jrt.Intern("arbace.aot.emit$closed_QMARK_")

var Lit_484 *jrt.String = jrt.Intern("arbace.aot.emit$coll_call")

var Lit_485 *jrt.String = jrt.Intern("arbace.aot.emit$compiled_interface_QMARK_")

var Lit_486 *jrt.String = jrt.Intern("arbace.aot.emit$const_field")

var Lit_487 *jrt.String = jrt.Intern("const-")

var Lit_488 *jrt.String = jrt.Intern("arbace.aot.emit$const_type")

var Lit_489 *jrt.String = jrt.Intern("arbace.aot.emit$constant")

var Lit_490 *jrt.String = jrt.Intern("arbace.aot.emit$deep")

var Lit_491 *jrt.String = jrt.Intern("arbace.aot.emit$descriptor")

var Lit_492 *jrt.String = jrt.Intern("V")

var Lit_493 *jrt.String = jrt.Intern("J")

var Lit_494 *jrt.String = jrt.Intern("I")

var Lit_495 *jrt.String = jrt.Intern("D")

var Lit_496 *jrt.String = jrt.Intern("Z")

var Lit_497 *jrt.String = jrt.Intern("C")

var Lit_498 *jrt.String = jrt.Intern("F")

var Lit_499 *jrt.String = jrt.Intern("S")

var Lit_500 *jrt.String = jrt.Intern("B")

var Lit_501 *jrt.String = jrt.Intern(".")

var Lit_502 *jrt.String = jrt.Intern("/")

var Lit_503 *jrt.String = jrt.Intern("L")

var Lit_504 *jrt.String = jrt.Intern(";")

var Lit_505 *jrt.String = jrt.Intern("arbace.aot.emit$destub")

var Lit_506 *jrt.String = jrt.Intern("compile__stub.")

var Lit_507 *jrt.String = jrt.Intern("arbace.aot.emit$double_form")

var Lit_508 *jrt.String = jrt.Intern("arbace.aot.emit$emit")

var Lit_509 *jrt.String = jrt.Intern("def")

var Lit_510 *jrt.String = jrt.Intern("instance-method")

var Lit_511 *jrt.String = jrt.Intern("empty")

var Lit_512 *jrt.String = jrt.Intern("unknown empty collection")

var Lit_513 *jrt.String = jrt.Intern("instance-field")

var Lit_514 *jrt.String = jrt.Intern("keyword-invoke")

var Lit_515 *jrt.String = jrt.Intern("letfn")

var Lit_516 *jrt.String = jrt.Intern("number")

var Lit_517 *jrt.String = jrt.Intern("the-var")

var Lit_518 *jrt.String = jrt.Intern("string")

var Lit_519 *jrt.String = jrt.Intern("monitor-exit")

var Lit_520 *jrt.String = jrt.Intern("nil")

var Lit_521 *jrt.String = jrt.Intern("monitor-enter")

var Lit_522 *jrt.String = jrt.Intern("import")

var Lit_523 *jrt.String = jrt.Intern("static-method")

var Lit_524 *jrt.String = jrt.Intern("static-field")

var Lit_525 *jrt.String = jrt.Intern("str-concat")

var Lit_526 *jrt.String = jrt.Intern("case")

var Lit_527 *jrt.String = jrt.Intern("no back end for ")

var Lit_528 *jrt.String = jrt.Intern(" ")

var Lit_529 *jrt.String = jrt.Intern("arbace.aot.emit$emit$fn__90000205")

var Lit_530 *jrt.String = jrt.Intern("arbace.aot.emit$emit$fn__90000207")

var Lit_531 *jrt.String = jrt.Intern("arbace.aot.emit$emit$fn__90000209")

var Lit_532 *jrt.String = jrt.Intern("arbace.aot.emit$emit_assign")

var Lit_533 *jrt.String = jrt.Intern("set! of a local that is no field")

var Lit_534 *jrt.String = jrt.Intern(".-")

var Lit_535 *jrt.String = jrt.Intern("set! of ")

var Lit_536 *jrt.String = jrt.Intern("arbace.aot.emit$emit_binding_init")

var Lit_537 *jrt.String = jrt.Intern("arbace.aot.emit$emit_case")

var Lit_538 *jrt.String = jrt.Intern("case-")

var Lit_539 *jrt.String = jrt.Intern("arbace.aot.emit$emit_case$arm__90000187")

var Lit_540 *jrt.String = jrt.Intern("arbace.aot.emit$emit_case$fn__90000190")

var Lit_541 *jrt.String = jrt.Intern("arbace.aot.emit$emit_case$fn__90000196")

var Lit_542 *jrt.String = jrt.Intern("arbace.aot.emit$emit_case$ret__90000185")

var Lit_543 *jrt.String = jrt.Intern("arbace.aot.emit$emit_case$sm__90000183")

var Lit_544 *jrt.String = jrt.Intern("arbace.aot.emit$emit_def")

var Lit_545 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_")

var Lit_546 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$fn__90000259")

var Lit_547 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$fn__90000292")

var Lit_548 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$fsym__90000257")

var Lit_549 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$ftype__90000255")

var Lit_550 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000261__90000265")

var Lit_551 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000261__90000265$fn__90000266")

var Lit_552 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000261__90000265$fn__90000266$fn__90000267")

var Lit_553 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000275__90000279")

var Lit_554 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000275__90000279$fn__90000280")

var Lit_555 *jrt.String = jrt.Intern("v__")

var Lit_556 *jrt.String = jrt.Intern("Value")

var Lit_557 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000275__90000279$fn__90000280$fn__90000281")

var Lit_558 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000297__90000301")

var Lit_559 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000297__90000301$fn__90000302")

var Lit_560 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000297__90000301$fn__90000302$fn__90000303")

var Lit_561 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000313__90000317")

var Lit_562 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000313__90000317$fn__90000318")

var Lit_563 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000313__90000317$fn__90000318$fn__90000319")

var Lit_564 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000313__90000317$fn__90000318$fn__90000319$fn__90000320")

var Lit_565 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000313__90000317$fn__90000318$fn__90000319$fn__90000322")

var Lit_566 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000313__90000317$fn__90000318$fn__90000325")

var Lit_567 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000313__90000317$fn__90000318$fn__90000327")

var Lit_568 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000331__90000335")

var Lit_569 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000331__90000335$fn__90000336")

var Lit_570 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000331__90000335$fn__90000336$fn__90000337")

var Lit_571 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$ps__90000271")

var Lit_572 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$ps__90000271$fn__90000272")

var Lit_573 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_")

var Lit_574 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$fn__90000344")

var Lit_575 *jrt.String = jrt.Intern("__")

var Lit_576 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$fn__90000376")

var Lit_577 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000346__90000350")

var Lit_578 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000346__90000350$fn__90000351")

var Lit_579 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000346__90000350$fn__90000351$fn__90000352")

var Lit_580 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000356__90000360")

var Lit_581 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000356__90000360$fn__90000361")

var Lit_582 *jrt.String = jrt.Intern("c__")

var Lit_583 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000356__90000360$fn__90000361$fn__90000362")

var Lit_584 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000366__90000370")

var Lit_585 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000366__90000370$fn__90000371")

var Lit_586 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000366__90000370$fn__90000371$fn__90000372")

var Lit_587 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000378__90000382")

var Lit_588 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000378__90000382$fn__90000383")

var Lit_589 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000378__90000382$fn__90000383$fn__90000384")

var Lit_590 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000388__90000392")

var Lit_591 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000388__90000392$fn__90000393")

var Lit_592 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000388__90000392$fn__90000393$fn__90000394")

var Lit_593 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000388__90000392$fn__90000393$fn__90000394$fn__90000395")

var Lit_594 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000388__90000392$fn__90000393$fn__90000394$fn__90000397")

var Lit_595 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000388__90000392$fn__90000393$fn__90000400")

var Lit_596 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000388__90000392$fn__90000393$fn__90000402")

var Lit_597 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000406__90000410")

var Lit_598 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000406__90000410$fn__90000411")

var Lit_599 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000406__90000410$fn__90000411$fn__90000412")

var Lit_600 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000416__90000420")

var Lit_601 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000416__90000420$fn__90000421")

var Lit_602 *jrt.String = jrt.Intern("arbace.lang.Compiler$AOTR")

var Lit_603 *jrt.String = jrt.Intern("arbace.lang.Compiler$AOTF")

var Lit_604 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000416__90000420$fn__90000421$fn__90000422")

var Lit_605 *jrt.String = jrt.Intern("arbace.aot.emit$emit_if")

var Lit_606 *jrt.String = jrt.Intern("arbace.aot.emit$emit_if$br__90000106")

var Lit_607 *jrt.String = jrt.Intern("arbace.aot.emit$emit_instance_field")

var Lit_608 *jrt.String = jrt.Intern("arbace.aot.emit$emit_instance_method")

var Lit_609 *jrt.String = jrt.Intern("target-")

var Lit_610 *jrt.String = jrt.Intern("arbace.aot.emit$emit_invoke")

var Lit_611 *jrt.String = jrt.Intern("arbace.aot.emit$emit_invoke$call__90000080")

var Lit_612 *jrt.String = jrt.Intern("arbace.aot.emit$emit_invoke$call__90000080$fn__90000081")

var Lit_613 *jrt.String = jrt.Intern("arbace.aot.emit$emit_invoke$fn__90000084")

var Lit_614 *jrt.String = jrt.Intern("arbace.aot.emit$emit_let")

var Lit_615 *jrt.String = jrt.Intern("arbace.aot.emit$emit_let$fn__90000111")

var Lit_616 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn")

var Lit_617 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$fn__90000132")

var Lit_618 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$fn__90000134")

var Lit_619 *jrt.String = jrt.Intern("body-")

var Lit_620 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$fn__90000165")

var Lit_621 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$fn__90000167")

var Lit_622 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$iter__90000136__90000140")

var Lit_623 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$iter__90000136__90000140$fn__90000141")

var Lit_624 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$iter__90000136__90000140$fn__90000141$fn__90000142")

var Lit_625 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$iter__90000146__90000152")

var Lit_626 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$iter__90000146__90000152$fn__90000153")

var Lit_627 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$iter__90000146__90000152$fn__90000153$iter__90000148__90000157")

var Lit_628 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$iter__90000146__90000152$fn__90000153$iter__90000148__90000157$fn__90000158")

var Lit_629 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$iter__90000146__90000152$fn__90000153$iter__90000148__90000157$fn__90000158$fn__90000159")

var Lit_630 *jrt.String = jrt.Intern("arbace.aot.emit$emit_list_array")

var Lit_631 *jrt.String = jrt.Intern("arbace.aot.emit$emit_list_array$fn__90000036")

var Lit_632 *jrt.String = jrt.Intern("arbace.aot.emit$emit_local")

var Lit_633 *jrt.String = jrt.Intern("arbace.aot.emit$emit_new")

var Lit_634 *jrt.String = jrt.Intern("arbace.aot.emit$emit_recur")

var Lit_635 *jrt.String = jrt.Intern("arbace.aot.emit$emit_recur$fn__90000114")

var Lit_636 *jrt.String = jrt.Intern("recur arg for primitive local: ")

var Lit_637 *jrt.String = jrt.Intern(" is not matching primitive")

var Lit_638 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source")

var Lit_639 *jrt.String = jrt.Intern("__init")

var Lit_640 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source$fn__90000455")

var Lit_641 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source$iter__90000460__90000464")

var Lit_642 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source$iter__90000460__90000464$fn__90000465")

var Lit_643 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source$iter__90000460__90000464$fn__90000465$fn__90000466")

var Lit_644 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source$iter__90000476__90000480")

var Lit_645 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source$iter__90000476__90000480$fn__90000481")

var Lit_646 *jrt.String = jrt.Intern("unit")

var Lit_647 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source$iter__90000476__90000480$fn__90000481$fn__90000482")

var Lit_648 *jrt.String = jrt.Intern("arbace.aot.emit$emit_static_field")

var Lit_649 *jrt.String = jrt.Intern("arbace.aot.emit$emit_static_method")

var Lit_650 *jrt.String = jrt.Intern("arbace.aot.emit$emit_try")

var Lit_651 *jrt.String = jrt.Intern("arbace.aot.emit$emit_try$body__90000170")

var Lit_652 *jrt.String = jrt.Intern("arbace.aot.emit$emit_try$iter__90000172__90000176")

var Lit_653 *jrt.String = jrt.Intern("arbace.aot.emit$emit_try$iter__90000172__90000176$fn__90000177")

var Lit_654 *jrt.String = jrt.Intern("arbace.aot.emit$emit_try$iter__90000172__90000176$fn__90000177$fn__90000178")

var Lit_655 *jrt.String = jrt.Intern("arbace.aot.emit$emit_unboxed")

var Lit_656 *jrt.String = jrt.Intern("unboxed emit of ")

var Lit_657 *jrt.String = jrt.Intern("no unboxed back end for ")

var Lit_658 *jrt.String = jrt.Intern("arbace.aot.emit$emit_unboxed$fn__90000214")

var Lit_659 *jrt.String = jrt.Intern("arbace.aot.emit$emit_value")

var Lit_660 *jrt.String = jrt.Intern("TYPE")

var Lit_661 *jrt.String = jrt.Intern("a record as a constant: ")

var Lit_662 *jrt.String = jrt.Intern("a deftype as a constant: ")

var Lit_663 *jrt.String = jrt.Intern("#<")

var Lit_664 *jrt.String = jrt.Intern("can't embed unreadable object in code: ")

var Lit_665 *jrt.String = jrt.Intern("arbace.aot.emit$emit_value$fn__90000045")

var Lit_666 *jrt.String = jrt.Intern("arbace.aot.emit$emit_value$fn__90000047")

var Lit_667 *jrt.String = jrt.Intern("arbace.aot.emit$eval90000004$loading__1927001464__auto____90000005")

var Lit_668 *jrt.String = jrt.Intern("arbace.lang.Compiler$AST")

var Lit_669 *jrt.String = jrt.Intern("arbace.lang.IPersistentSet")

var Lit_670 *jrt.String = jrt.Intern("arbace.lang.IPersistentList")

var Lit_671 *jrt.String = jrt.Intern("arbace.lang.ISeq")

var Lit_672 *jrt.String = jrt.Intern("arbace.lang.IType")

var Lit_673 *jrt.String = jrt.Intern("arbace.lang.IRecord")

var Lit_674 *jrt.String = jrt.Intern("java.util.IdentityHashMap")

var Lit_675 *jrt.String = jrt.Intern("arbace.aot.emit$eval90000008$fn__90000009")

var Lit_676 *jrt.String = jrt.Intern("arbace.aot.emit$fail")

var Lit_677 *jrt.String = jrt.Intern("aot: ")

var Lit_678 *jrt.String = jrt.Intern("arbace.aot.emit$fi_QMARK_")

var Lit_679 *jrt.String = jrt.Intern("fiMethod")

var Lit_680 *jrt.String = jrt.Intern("arbace.aot.emit$field_mods")

var Lit_681 *jrt.String = jrt.Intern("arbace.aot.emit$field_ok_QMARK_")

var Lit_682 *jrt.String = jrt.Intern("arbace.aot.emit$field_read")

var Lit_683 *jrt.String = jrt.Intern("arbace.aot.emit$field_sym")

var Lit_684 *jrt.String = jrt.Intern("arbace.aot.emit$fn__90000088")

var Lit_685 *jrt.String = jrt.Intern("/go/arbace/jrt")

var Lit_686 *jrt.String = jrt.Intern("ARBACE_AOT_ROOT")

var Lit_687 *jrt.String = jrt.Intern("arbace.aot.emit$fn_instance")

var Lit_688 *jrt.String = jrt.Intern("arbace.aot.emit$fn_wrap")

var Lit_689 *jrt.String = jrt.Intern("arbace.aot.emit$gsym")

var Lit_690 *jrt.String = jrt.Intern("arbace.aot.emit$identity_set")

var Lit_691 *jrt.String = jrt.Intern("arbace.aot.emit$interface_record")

var Lit_692 *jrt.String = jrt.Intern("arbace.aot.emit$interface_record$fn__90000541")

var Lit_693 *jrt.String = jrt.Intern("arbace.aot.emit$interface_record$iter__90000543__90000547")

var Lit_694 *jrt.String = jrt.Intern("arbace.aot.emit$interface_record$iter__90000543__90000547$fn__90000548")

var Lit_695 *jrt.String = jrt.Intern("arbace.aot.emit$interface_record$iter__90000543__90000547$fn__90000548$fn__90000549")

var Lit_696 *jrt.String = jrt.Intern("arbace.aot.emit$interface_record$iter__90000543__90000547$fn__90000548$fn__90000549$fn__90000553")

var Lit_697 *jrt.String = jrt.Intern("p")

var Lit_698 *jrt.String = jrt.Intern("arbace.aot.emit$interface_record$iter__90000543__90000547$fn__90000548$fn__90000559")

var Lit_699 *jrt.String = jrt.Intern("arbace.aot.emit$jrt_lacks_QMARK_")

var Lit_700 *jrt.String = jrt.Intern("(")

var Lit_701 *jrt.String = jrt.Intern(")")

var Lit_702 *jrt.String = jrt.Intern("_")

var Lit_703 *jrt.String = jrt.Intern("arbace.aot.emit$jrt_lacks_QMARK_$fn__90000091")

var Lit_704 *jrt.String = jrt.Intern("arbace.aot.emit$line_meta")

var Lit_705 *jrt.String = jrt.Intern("arbace.aot.emit$local_sym")

var Lit_706 *jrt.String = jrt.Intern("arbace.aot.emit$method_body")

var Lit_707 *jrt.String = jrt.Intern("fn-method")

var Lit_708 *jrt.String = jrt.Intern("arbace.aot.emit$method_body$fn__90000232")

var Lit_709 *jrt.String = jrt.Intern("arbace.aot.emit$method_body$fn__90000234")

var Lit_710 *jrt.String = jrt.Intern("p-")

var Lit_711 *jrt.String = jrt.Intern("arbace.aot.emit$method_body$iter__90000222__90000226")

var Lit_712 *jrt.String = jrt.Intern("arbace.aot.emit$method_body$iter__90000222__90000226$fn__90000227")

var Lit_713 *jrt.String = jrt.Intern("arbace.aot.emit$method_body$iter__90000222__90000226$fn__90000227$fn__90000228")

var Lit_714 *jrt.String = jrt.Intern("arbace.aot.emit$method_call")

var Lit_715 *jrt.String = jrt.Intern("a call of a method of a class made at run time: ")

var Lit_716 *jrt.String = jrt.Intern("arbace.aot.emit$node")

var Lit_717 *jrt.String = jrt.Intern("arbace.aot.emit$obj_array")

var Lit_718 *jrt.String = jrt.Intern("arbace.aot.emit$obj_array$fn__90000072")

var Lit_719 *jrt.String = jrt.Intern("arbace.aot.emit$param_sym")

var Lit_720 *jrt.String = jrt.Intern("arbace.aot.emit$param_tags")

var Lit_721 *jrt.String = jrt.Intern("arbace.aot.emit$pool")

var Lit_722 *jrt.String = jrt.Intern("arbace.aot.emit$pool$fn__90000031")

var Lit_723 *jrt.String = jrt.Intern("")

var Lit_724 *jrt.String = jrt.Intern("arbace.aot.emit$prim")

var Lit_725 *jrt.String = jrt.Intern("arbace.aot.emit$public_QMARK_")

var Lit_726 *jrt.String = jrt.Intern("arbace.aot.emit$registered_QMARK_")

var Lit_727 *jrt.String = jrt.Intern("isPrimitive")

var Lit_728 *jrt.String = jrt.Intern("getName")

var Lit_729 *jrt.String = jrt.Intern("arbace.aot.emit$registered_QMARK_$fn__90000021")

var Lit_730 *jrt.String = jrt.Intern("arbace.aot.emit$registered_QMARK_$fn__90000023")

var Lit_731 *jrt.String = jrt.Intern("arbace.aot.emit$registered_QMARK_$fn__90000023$fn__90000024")

var Lit_732 *jrt.String = jrt.Intern("cut")

var Lit_733 *jrt.String = jrt.Intern("arbace.aot.emit$ret_body")

var Lit_734 *jrt.String = jrt.Intern("mismatched primitive return, expected ")

var Lit_735 *jrt.String = jrt.Intern(", had ")

var Lit_736 *jrt.String = jrt.Intern("arbace.aot.emit$runtime_class_QMARK_")

var Lit_737 *jrt.String = jrt.Intern("arbace.aot.emit$simple_name")

var Lit_738 *jrt.String = jrt.Intern("arbace.aot.emit$tag_class")

var Lit_739 *jrt.String = jrt.Intern("arbace.aot.emit$tagged")

var Lit_740 *jrt.String = jrt.Intern("arbace.aot.emit$throws_QMARK_")

var Lit_741 *jrt.String = jrt.Intern("arbace.aot.emit$top_name")

var Lit_742 *jrt.String = jrt.Intern("arbace.aot.emit$type_sym")

var Lit_743 *jrt.String = jrt.Intern("arbace.aot.emit$typed_args")

var Lit_744 *jrt.String = jrt.Intern("arbace.aot.emit$typed_args$fn__90000067")

var Lit_745 *jrt.String = jrt.Intern("arbace.aot.emit$unbox_arg")

var Lit_746 *jrt.String = jrt.Intern("uncheckedFloatCast")

var Lit_747 *jrt.String = jrt.Intern("floatCast")

var Lit_748 *jrt.String = jrt.Intern("uncheckedDoubleCast")

var Lit_749 *jrt.String = jrt.Intern("uncheckedLongCast")

var Lit_750 *jrt.String = jrt.Intern("uncheckedByteCast")

var Lit_751 *jrt.String = jrt.Intern("byteCast")

var Lit_752 *jrt.String = jrt.Intern("uncheckedShortCast")

var Lit_753 *jrt.String = jrt.Intern("shortCast")

var Lit_754 *jrt.String = jrt.Intern("arbace.aot.emit$unit_method")

var Lit_755 *jrt.String = jrt.Intern("a top-level fn closing over locals")

var Lit_756 *jrt.String = jrt.Intern("arbace.aot.emit$unit_method$iter__90000432__90000436")

var Lit_757 *jrt.String = jrt.Intern("arbace.aot.emit$unit_method$iter__90000432__90000436$fn__90000437")

var Lit_758 *jrt.String = jrt.Intern("an event of a class made at run time: ")

var Lit_759 *jrt.String = jrt.Intern("iface")

var Lit_760 *jrt.String = jrt.Intern("proxy")

var Lit_761 *jrt.String = jrt.Intern("imethod")

var Lit_762 *jrt.String = jrt.Intern("stub")

var Lit_763 *jrt.String = jrt.Intern("ns")

var Lit_764 *jrt.String = jrt.Intern("an event of kind ")

var Lit_765 *jrt.String = jrt.Intern("arbace.aot.emit$unit_method$iter__90000432__90000436$fn__90000437$fn__90000438")

var Lit_766 *jrt.String = jrt.Intern("arbace.aot.emit$unit_method$iter__90000432__90000436$fn__90000437$fn__90000438$fn__90000440")

var Lit_767 *jrt.String = jrt.Intern("arbace.aot.emit$unit_method$iter__90000432__90000436$fn__90000437$fn__90000444")

var Lit_768 *jrt.String = jrt.Intern("arbace.aot.emit$unit_ns")

var Lit_769 *jrt.String = jrt.Intern("arbace.aot.emit$var_value")

var Lit_770 *jrt.String = jrt.Intern("in-ns")

var Lit_771 *jrt.String = jrt.Intern("private")

var Lit_772 *jrt.String = jrt.Intern("file")

var Lit_773 *jrt.String = jrt.Intern("arbace/aot/emit.ae")

var Lit_774 *jrt.String = jrt.Intern("The nodes' maps by node (the back end runs on one thread).")

var Lit_775 *jrt.String = jrt.Intern("arglists")

var Lit_776 *jrt.String = jrt.Intern("x")

var Lit_777 *jrt.String = jrt.Intern("The analyzed node x as a map (Compiler$AST/node), nil for nil.")

var Lit_778 *jrt.String = jrt.Intern("msg")

var Lit_779 *jrt.String = jrt.Intern("&")

var Lit_780 *jrt.String = jrt.Intern("data")

var Lit_781 *jrt.String = jrt.Intern("String")

var Lit_782 *jrt.String = jrt.Intern("A class name without the compile stub's prefix (Compiler.destubClassName).")

var Lit_783 *jrt.String = jrt.Intern("Class")

var Lit_784 *jrt.String = jrt.Intern("The class forms type of class c: a primitive's name, a class's binary name, an array as\n  T/n.")

var Lit_785 *jrt.String = jrt.Intern("void")

var Lit_786 *jrt.String = jrt.Intern("double")

var Lit_787 *jrt.String = jrt.Intern("char")

var Lit_788 *jrt.String = jrt.Intern("byte")

var Lit_789 *jrt.String = jrt.Intern("float")

var Lit_790 *jrt.String = jrt.Intern("short")

var Lit_791 *jrt.String = jrt.Intern("s")

var Lit_792 *jrt.String = jrt.Intern("Symbol s with the class forms tag of class c.")

var Lit_793 *jrt.String = jrt.Intern("Whether a class name is registered in the program (Class/forName finds it), by name.")

var Lit_794 *jrt.String = jrt.Intern("ctx")

var Lit_795 *jrt.String = jrt.Intern("Is class c made at run time (a Dyn class: an evaluated fn's, deftype's, interface's, proxy's)\n  rather than a class of the program, or one the program does not register by name (java.sql's,\n  whose members reflection reached from a world class)? Such a class is not named in compiled\n  code.")

var Lit_796 *jrt.String = jrt.Intern("top")

var Lit_797 *jrt.String = jrt.Intern("The constants of top-level class top (a namespace's holder, a deftype, a loader), which its\n  member classes share (SA145): an atom {:name :consts :const-map}, made on first use.")

var Lit_798 *jrt.String = jrt.Intern("ctype")

var Lit_799 *jrt.String = jrt.Intern("The static field holding constant value v in the class being emitted, made on first use (as\n  the JVM's const__N, one per distinct object): its symbol, const-N (a munged local's name has\n  no -, so no local, name__index, can shadow it).")

var Lit_800 *jrt.String = jrt.Intern("declared")

var Lit_801 *jrt.String = jrt.Intern("xs")

var Lit_802 *jrt.String = jrt.Intern("Character")

var Lit_803 *jrt.String = jrt.Intern("d")

var Lit_804 *jrt.String = jrt.Intern("Code making constant value v (ObjExpr.emitValue), its metadata included.")

var Lit_805 *jrt.String = jrt.Intern("base")

var Lit_806 *jrt.String = jrt.Intern("A fresh name for a temporary of the emitted code, numbered per class being emitted (the\n  output does not depend on the program's gensym counter).")

var Lit_807 *jrt.String = jrt.Intern("The class forms local of LocalBinding lb (its node b): its name and index, unique in a\n  method.")

var Lit_808 *jrt.String = jrt.Intern("The objects of xs as a set by identity. A fn's closes map cannot be asked containsKey: its\n  keys, LocalBindings, hash by their index (Arbace's deterministic hashCode), and FnExpr.parse\n  renumbers a direct fn's arguments after its inner fns closed over them.")

var Lit_809 *jrt.String = jrt.Intern("emit-body")

var Lit_810 *jrt.String = jrt.Intern("e")

var Lit_811 *jrt.String = jrt.Intern("f")

var Lit_812 *jrt.String = jrt.Intern("Form f of type c as a boxed value (emitBoxReturn: valueOf, long's Numbers.num being\n  Long.valueOf; void as nil).")

var Lit_813 *jrt.String = jrt.Intern("Boxed form f converted to parameter type p (HostExpr.emitUnboxArg).")

var Lit_814 *jrt.String = jrt.Intern("Is p a functional interface a fn argument is adapted to (Clojure 1.12's FISupport, as the\n  analysis decides it: Compiler$AST/fiMethod)?")

var Lit_815 *jrt.String = jrt.Intern("ps")

var Lit_816 *jrt.String = jrt.Intern("es")

var Lit_817 *jrt.String = jrt.Intern("The arguments es as parameters of types ps (MethodExpr.emitTypedArgs).")

var Lit_818 *jrt.String = jrt.Intern("Var")

var Lit_819 *jrt.String = jrt.Intern("unboxed?")

var Lit_820 *jrt.String = jrt.Intern("java.lang.reflect.Method")

var Lit_821 *jrt.String = jrt.Intern("Is method m declared by a class jrt writes by hand (not a stand-in a2g's translation\n  replaces) without it in Go? a2g would translate a direct call to a throw; the member tables\n  (reflection) have such members, so compiled code calls them by reflection.")

var Lit_822 *jrt.String = jrt.Intern("t")

var Lit_823 *jrt.String = jrt.Intern("A call of resolved method m: static (target nil) or on target form t.")

var Lit_824 *jrt.String = jrt.Intern("Is class c an interface of a namespace being compiled (gen-interface's, a protocol's)?")

var Lit_825 *jrt.String = jrt.Intern("java.lang.reflect.Field")

var Lit_826 *jrt.String = jrt.Intern("top?")

var Lit_827 *jrt.String = jrt.Intern("A let or loop binding [sym init] of LocalBinding lb (LetExpr.doEmit).")

var Lit_828 *jrt.String = jrt.Intern("ox")

var Lit_829 *jrt.String = jrt.Intern("nil-locals")

var Lit_830 *jrt.String = jrt.Intern("A new instance of fn or reify class ox (its node), its closed-over values from the current\n  method: (new C closed...) (ObjExpr.emit); letfn's own locals nil (set after). A fn's is its\n  code (SA141), which fn-wrap makes the fn.")

var Lit_831 *jrt.String = jrt.Intern("The fn of fn ox (its node) whose code is form body: a Compiler$AOTFn, or a\n  Compiler$AOTRestFn of the variadic arity's required count.")

var Lit_832 *jrt.String = jrt.Intern("A new fn or reify (ox, its node).")

var Lit_833 *jrt.String = jrt.Intern("Form f of node n boxed when it is of a primitive type (emitBoxReturn: valueOf, long's\n  Numbers.num being Long.valueOf), so that emit's code is always a reference, as the bytecode's\n  emit leaves one.")

var Lit_834 *jrt.String = jrt.Intern("Code for analyzed node e, its value boxed (an Expr's emit).")

var Lit_835 *jrt.String = jrt.Intern("Code for analyzed node e, its value of its primitive type (emitUnboxed).")

var Lit_836 *jrt.String = jrt.Intern("Form f realized throughout (the emitters build lazy seqs; what they record, the constants\n  and the classes, must be recorded before it is read), metadata kept.")

var Lit_837 *jrt.String = jrt.Intern("binary")

var Lit_838 *jrt.String = jrt.Intern("Does node e end in a throw (a form that does not complete, which needs no conversion)?")

var Lit_839 *jrt.String = jrt.Intern("ret")

var Lit_840 *jrt.String = jrt.Intern("A deftype's method body as returned in type ret (ObjMethod.emitBody): unboxed when it can be,\n  else boxed then cast or unboxed as ASM's unbox does.")

var Lit_841 *jrt.String = jrt.Intern("mn")

var Lit_842 *jrt.String = jrt.Intern("params")

var Lit_843 *jrt.String = jrt.Intern("The body of FnMethod or NewInstanceMethod m (its node), in the method's context: wrapped in\n  a loop over its parameters when a recur targets them.")

var Lit_844 *jrt.String = jrt.Intern("The class a field's tag names (Compiler.tagClass): Object without one.")

var Lit_845 *jrt.String = jrt.Intern("The interfaces of a deftype's or reify's class (its node ox), as the analysis made the\n  class: their names. A class of the program cannot implement an interface made at run time.")

var Lit_846 *jrt.String = jrt.Intern("The modifiers of a deftype's field lb (ObjExpr.compile): volatile, mutable (package), or\n  public final.")

var Lit_847 *jrt.String = jrt.Intern("Defines deftype ox's class (its node), a top-level class named as the deftype, once:\n  its fields, constructors, getBasis (and create for a record), and methods\n  (NewInstanceExpr.compile, emitStatics).")

var Lit_848 *jrt.String = jrt.Intern("Defines the class of fn or reify ox (its node) once, in the classes being emitted; returns\n  its binary name.")

var Lit_849 *jrt.String = jrt.Intern("events")

var Lit_850 *jrt.String = jrt.Intern("The static method unitK of a source's loader class: unit u's events made again, then its\n  code.")

var Lit_851 *jrt.String = jrt.Intern("The namespace unit u was analyzed in: its fn's (kind 1) or its def's, else nil.")

var Lit_852 *jrt.String = jrt.Intern("emit-source")

var Lit_853 *jrt.String = jrt.Intern("src")

var Lit_854 *jrt.String = jrt.Intern("units")

var Lit_855 *jrt.String = jrt.Intern("The class forms of source path src (scriptbase.ae), compiled from its units: the loader\n  class SCRIPTBASE__init's form and the fn classes made, into the atom classes (fn-names: the\n  fns' class names by their FnExpr, an IdentityHashMap shared by the sources).")

var Lit_856 *jrt.String = jrt.Intern("children-of")

var Lit_857 *jrt.String = jrt.Intern("The defclass form of class c (its record: a fn's, a reify's, a deftype's, an interface's, or\n  a holder of nested classes), its nested classes inside; at the top its full name and the\n  constants it shares with them (pools: top → its pool), else a static member class by its\n  simple name.")

var Lit_858 *jrt.String = jrt.Intern("class-forms")

var Lit_859 *jrt.String = jrt.Intern("The top-level class forms holding every class of classes (name → record), nested as their\n  binary names nest, with holder classes made for the missing levels (a namespace's fns nest\n  in a holder named as the namespace); pools: the top-level classes' constants.")

var Lit_860 *jrt.String = jrt.Intern("interface-record")

var Lit_861 *jrt.String = jrt.Intern("The record of an interface made by gen-interface (events iface and imethod): name, the\n  interfaces it extends, its abstract methods.")
