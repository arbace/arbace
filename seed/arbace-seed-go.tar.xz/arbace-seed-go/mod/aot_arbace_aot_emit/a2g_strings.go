//line a2g_strings.ae:1
package aot_arbace_aot_emit

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn14,arbace.a2g.jrtyn3,jrtyn16,arbace.a2g.namesyn2,nmkn3,dockn4,selfkn3,tagkn15,runtime-classeskn5,poolskn4,namekn6,constskn9,const-mapkn12,const-prefixkn3,clsyn3,newys16,java.lang.Object1,1yn14,unchecked-charys16,java.lang.Double16,longBitsToDoublekn4,elseys17,java.lang.Boolean4,TRUEys17,java.lang.Boolean5,FALSEys17,java.lang.Integer7,valueOfyn13,unchecked-intys14,java.lang.Long7,valueOfys16,java.lang.Double7,valueOfys19,java.lang.Character7,valueOfys14,arbace.lang.RT22,classForNameNonLoadingys18,arbace.lang.Symbol6,internkn10,param-tagsyn16,java.lang.Stringys14,arbace.lang.RT7,keywordys14,arbace.lang.RT3,varys21,arbace.lang.Namespace12,findOrCreateyn18,arbace.lang.Symbolys14,arbace.lang.RT3,mapys17,arbace.lang.Tuple6,createyn16,java.lang.Objectys14,arbace.lang.RT6,vectorys29,arbace.lang.PersistentHashSet5,EMPTYys29,arbace.lang.PersistentHashSet6,createys26,arbace.lang.PersistentList6,createyn14,java.util.Listys16,java.util.Arrays6,asListys23,java.util.regex.Pattern7,compileys14,arbace.lang.RT10,readStringyn9,.withMetayn4,castyn16,arbace.lang.IObjyn26,arbace.lang.IPersistentMapkn3,nilkn6,stringkn7,booleankn3,intkn4,longkn6,doublekn4,charkn5,classkn6,symbolkn7,keywordkn3,varkn2,nskn3,mapkn6,vectorkn3,setkn4,listkn7,patternkn4,readyn5,fieldyn10,const-poolkn6,statickn5,finalkn7,privateys24,arbace.lang.Compiler$AOT4,poolyn3,intks3,aot2,nnyn4,agetyn15,arbace.lang.Varyn19,arbace.lang.Keywordyn15,java.lang.Classkn7,gensymskn3,idxkn6,closedyn4,thiskn4,primkn16,canEmitPrimitiveyn2,dokn14,unchecked-mathyn13,.booleanValueyn17,java.lang.Booleanyn10,.charValueyn19,java.lang.Characterys14,arbace.lang.RT16,uncheckedIntCastys14,arbace.lang.RT7,intCastyn4,longyn15,unchecked-floatys30,arbace.lang.Compiler$Evaluator7,fiAdaptyn4,.getyn11,.getRawRootkn4,lineks3,aot4,linekn1,bkn4,oncekn11,shouldClearkn12,canBeClearedkn8,self-symkn11,bindingPrimyn3,letyn2,t-yn4,set!kn5,isArgkn4,argskn5,fexpryn8,.applyToyn15,arbace.lang.IFnys20,arbace.lang.ArraySeq6,createyn7,.invokekn10,isProtocolkn10,protocolOnkn8,onMethodyn2,ifyn3,andyn9,instance?yn3,notys24,arbace.lang.Compiler$AOT5,isDynkn7,classeskn7,standinkn5,funcskn9,interfacekn4,kindkn6,methodkn15,qualifyingClasskn11,dyn-guardedkn6,targetks15,arbace.aot.emit5,localkn10,target-symyn5,some?kn10,methodNameys21,arbace.lang.Reflector20,invokeInstanceMethodys21,arbace.lang.Reflector27,invokeInstanceMethodOfClassys21,arbace.lang.Reflector18,invokeStaticMethodkn1,ckn5,fieldkn9,fieldNamekn12,requireFieldys21,arbace.lang.Reflector25,invokeNoArgInstanceMemberyn7,booleanys21,arbace.lang.Reflector14,getStaticFieldkn4,ctorys21,arbace.lang.Reflector17,invokeConstructorkn12,initProvidedkn4,metakn4,inityn9,.bindRootyn8,.setMetakn9,isDynamicyn11,.setDynamickn3,valkn2,opyn4,.setys21,arbace.lang.Reflector16,setInstanceFieldkn8,testExprkn8,thenExprkn8,elseExprkn6,isLoopkn12,bindingInitskn11,loop-localskn7,bindingkn4,bodyyn4,loopkn10,loopLocalskn12,method-recurkn13,method-localsyn5,recurkn6,closeskn12,supportsMetakn8,variadicyn4,nil?ys24,arbace.lang.Compiler$AOT7,fnClassyn30,arbace.lang.Compiler$AOTRestFnyn26,arbace.lang.Compiler$AOTFnyn5,catchkn2,lbkn7,handlerkn11,finallyExpryn3,trykn7,tryExprkn10,catchExprsyn7,finallykn4,exprkn5,shiftkn4,maskyn11,bit-and-intyn19,bit-shift-right-intkn5,thenskn8,testTypekn7,defaultkn13,hash-identityyn4,whenys16,arbace.lang.Util5,equivyn5,breakyn2,==yn10,identical?kn5,testsys16,arbace.lang.Util4,hashkn9,skipCheckyn16,java.lang.Numberyn6,switchyn9,.intValueyn5,labelkn11,defaultExprkn9,isDeftypekn4,collys26,arbace.lang.PersistentList5,EMPTYys28,arbace.lang.PersistentVector5,EMPTYys30,arbace.lang.PersistentArrayMap5,EMPTYkn5,exprskn1,kkn2,kwkn1,nkn3,strkn1,vkn7,keyvalsys30,arbace.lang.Compiler$Evaluator11,monitorExityn5,throwyn19,java.lang.Throwablekn7,excExprys30,arbace.lang.Compiler$Evaluator12,monitorEnterys14,arbace.lang.RT11,arrayToListyn12,.importClassyn21,arbace.lang.Namespaceyn6,.derefys14,arbace.lang.RT10,CURRENT_NSkn5,textsys24,arbace.lang.Compiler$AOT9,strConcatys16,java.lang.String1,1ys14,arbace.lang.RT3,setkn4,keysyn11,.isInstancekn4,typekn8,retClasskn8,reqParmskn8,restParmkn9,argLocalsys14,arbace.lang.RT10,doubleCastys14,arbace.lang.RT8,longCastkn13,compiledClasskn3,symkn16,volatile-mutablekn8,volatilekn22,unsynchronized-mutablekn6,publickn12,hintedFieldskn12,altCtorDropsyn3,m__yn6,methodks15,arbace.aot.emit7,pendingkn4,objxyn11,constructoryn6,super.kn6,columnyn5,this.yn8,getBasisyn29,arbace.lang.IPersistentVectorys19,arbace.lang.Keyword6,internyn6,.valAtyn6,createkn7,mutableyn8,.withoutys14,arbace.lang.RT9,seqOrElsekn7,methodskn7,deftypekn5,superkn10,interfaceskn7,memberskn6,sourcekn8,fn-namesyn4,selfkn10,isVariadicyn8,doInvokeyn6,invokekn8,onceOnlyyn6,meta__yn8,.-__metayn8,fn-classyn6,__metayn4,metayn8,withMetayn1,mkn2,fnkn5,reifyys14,arbace.lang.RT4,consys14,arbace.lang.RT3,seqys24,arbace.lang.Compiler$AOT2,atkn4,formyn8,defclassks3,aot6,sourceyn4,loadks3,aot4,codekn6,holderkn7,extendskn10,implementskn8,abstractv11,arbace.core5,referv11,arbace.core7,requireR0,V3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn15,arbace.aot.emitm2,R8,s1524,Standalone S6 (doc/STANDALONE-NOTES.md, \"S6: Arbace compiled to Go\"): the back end that\n  compiles analyzed namespaces to class forms, which a2g translates into Go like the runtime's\n  own classes.\n\n  The input is what the program records while it prepares its namespaces (ARBACE_COMPILE): for\n  each source, its units in order (a top-level form, analyzed: Compiler$Image's unit, its Expr\n  tree and the events of its analysis), read through Compiler$AST/node, which shows a node's\n  fields as a map. The output follows the JVM's bytecode back end (Compiler.clj on the branch\n  arbace-for-java-26: ObjExpr.compile, the emit methods), with class forms in place of\n  bytecode:\n\n  - a fn (FnExpr) is a class named as the JVM names it (arbace.walk$walk), a static member\n    class of a holder class per namespace (arbace.walk), nested as its name nests; it extends\n    AFunction (RestFn when variadic), its closed-over locals are fields set by its constructor,\n    each arity an invoke method (doInvoke for the variadic one), its constants static fields;\n  - a source's top-level forms are the static methods of its loader class SCRIPTBASE__init\n    (arbace.walk__init), whose load() runs them in order; Compiler$AOT/load calls it in the\n    bindings Compiler.load makes;\n  - each Expr becomes the class forms code its emit method's bytecode is: interop on the\n    analyzer's resolved members (param-tags pin the overload), reflection where it was\n    unresolved, Clojure's boxing and conversions (emitBoxReturn, emitTypedArgs).v11,arbace.core13,*loaded-libs*v11,arbace.core5,some?v15,arbace.aot.emit10,node-cachev11,arbace.core5,assocR9,v11,arbace.core7,ex-infov13,arbace.string12,starts-with?v11,arbace.core4,subsv11,arbace.core6,symbolv11,arbace.core3,strv15,arbace.aot.emit8,type-symv15,arbace.aot.emit6,destubv11,arbace.core9,vary-metaR10,v15,arbace.aot.emit10,prim-namesv11,arbace.core3,notv15,arbace.aot.emit10,registeredv11,arbace.core5,swap!v11,arbace.core9,contains?R11,v15,arbace.aot.emit11,registered?l0,R12,v11,arbace.core4,atomR13,R14,R15,R16,R17,v11,arbace.core6,updatev11,arbace.core4,listR18,R19,v11,arbace.core4,mapvv15,arbace.aot.emit10,emit-valuev11,arbace.core4,not=c92,R20,R21,V2,nTv11,arbace.core7,string?v11,arbace.core6,class?v11,arbace.core7,symbol?v11,arbace.core8,keyword?v11,arbace.core4,var?v15,arbace.aot.emit4,failv11,arbace.core4,map?v11,arbace.core7,vector?v11,arbace.core4,seq?v11,arbace.core5,list?R22,v11,arbace.core6,pr-strv11,arbace.core19,pop-thread-bindingsR23,R24,R25,R26,R27,R28,v15,arbace.aot.emit11,double-formR29,v15,arbace.aot.emit9,char-formC17,java.lang.BooleanC14,java.lang.ByteC19,java.lang.CharacterC16,java.lang.DoubleC15,java.lang.FloatC17,java.lang.IntegerC14,java.lang.LongC15,java.lang.ShortR30,v11,arbace.core9,with-metav11,arbace.core9,namespacev11,arbace.core4,nameR31,m2,R32,V2,R33,R33,R34,m2,R32,V2,R33,R33,R35,m2,R32,V2,R33,R33,R36,m2,R32,V1,R37,R31,m2,R32,V2,R33,R33,v11,arbace.core5,classv15,arbace.aot.emit15,emit-list-arrayR38,m2,R32,V1,R19,v11,arbace.core6,mapcatv11,arbace.core8,identityv11,arbace.core5,list*v11,arbace.core3,mapR39,R32,v11,arbace.core3,vecv11,arbace.core6,repeatR40,R41,m2,R32,V1,R19,v11,arbace.core6,empty?R42,R43,m2,R32,V1,R19,v11,arbace.core3,seqR44,m2,R32,V1,R45,R46,m2,R32,V1,R19,R47,m2,R32,V1,R33,v11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core11,*print-dup*R48,m2,R32,V1,R33,R49,R50,R51,R50,R52,R53,R54,R55,R56,R57,R58,R59,R60,R61,R62,R63,R64,R65,R66,R67,R68,R69,R70,v15,arbace.aot.emit9,pool-kindv11,arbace.core6,concatv15,arbace.aot.emit12,pool-partialc44,v15,arbace.aot.emit12,pool-shared?c82,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,firstv15,arbace.aot.emit11,pool-encodev11,arbace.core10,chunk-restv11,arbace.core4,nextc77,v15,arbace.aot.emit8,pool-strc110,c84,c70,c118,c107,c115,c112,c100,c109,c80,c86,c68,c67,c66,c90,c74,c83,c73,c99,c78,c114,c108,c121,c69,c105,c76,v11,arbace.core4,run!v15,arbace.aot.emit10,pool-partsv11,arbace.core4,intov11,arbace.core4,consv11,arbace.core11,map-indexedR71,v15,arbace.aot.emit6,taggedR72,m6,R73,TR74,TR75,TR76,m2,R32,V2,R33,R77,R26,R71,R40,m6,R73,TR74,TR78,TR79,R72,R26,R50,R80,R81,R82,R40,v15,arbace.aot.emit14,runtime-class?v15,arbace.aot.emit11,const-fieldR30,m2,R32,V1,R33,v15,arbace.aot.emit10,const-typeR83,v11,arbace.core4,fnilv11,arbace.core3,incR84,R85,v15,arbace.aot.emit9,field-symR86,R87,v15,arbace.aot.emit4,nodeR88,R89,v15,arbace.aot.emit6,box-ofC16,java.lang.ObjectR90,R91,R50,R92,R93,R50,R94,m2,R32,V1,R40,v15,arbace.aot.emit7,public?R50,v15,arbace.aot.emit12,emit-unboxedv15,arbace.aot.emit4,emitv15,arbace.aot.emit3,fi?v15,arbace.aot.emit9,unbox-argR95,R96,m2,R32,V1,R97,R98,R99,v15,arbace.aot.emit8,constantR18,R19,R80,R100,R101,R102,R103,R104,v15,arbace.aot.emit7,closed?v15,arbace.aot.emit10,field-readR105,R106,R107,R108,R86,v15,arbace.aot.emit9,local-symR109,R110,R111,R111,R112,R113,R114,R115,R116,R50,R117,v15,arbace.aot.emit9,obj-arrayR118,m2,R32,V1,R19,R119,R50,R117,R120,R121,R122,v15,arbace.aot.emit4,gsymv11,arbace.core4,restR110,R123,v15,arbace.aot.emit3,boxR124,R125,R126,R127,v15,arbace.aot.emit10,typed-argsv15,arbace.aot.emit10,param-tagsR50,R119,R50,R117,v13,arbace.string7,replacev14,arbace.a2g.jrt4,scanR128,v16,arbace.a2g.names13,go-class-namev11,arbace.core5,applyv15,arbace.aot.emit10,descriptorv16,arbace.a2g.names11,method-basev15,arbace.aot.emit8,jrt-scanR129,R130,v14,arbace.a2g.jrt14,struct-methodsv14,arbace.a2g.jrt13,iface-methodsv16,arbace.a2g.names9,impl-nameR50,R131,R132,R133,v15,arbace.aot.emit19,compiled-interface?v15,arbace.aot.emit11,method-callv15,arbace.aot.emit20,emit-instance-methodR134,R135,R136,R137,R138,R110,R123,R124,R139,R127,R140,R141,m2,R32,V3,R40,R33,R19,v15,arbace.aot.emit10,jrt-lacks?R142,R141,m2,R32,V3,R40,R33,R19,v15,arbace.aot.emit18,emit-static-methodR143,m2,R32,V3,R82,R33,R19,R144,R145,v15,arbace.aot.emit9,field-ok?R50,R146,R147,R148,m2,R32,V3,R40,R33,R149,R150,m2,R32,V2,R82,R33,R151,R152,m2,R32,V2,R82,R19,R153,R154,R80,R155,R50,R52,R89,R156,R157,R158,R159,R89,R159,R157,R156,R160,R161,R162,R80,R112,R112,R112,R50,R163,m2,R32,V1,R19,R164,v15,arbace.aot.emit9,can-prim?R123,R165,R166,R167,R168,R169,R170,v15,arbace.aot.emit17,emit-binding-initR171,R172,R110,R173,R174,R175,v11,arbace.core6,reset!R176,v15,arbace.aot.emit4,primR96,m2,R32,V1,R97,R98,v15,arbace.aot.emit14,emit-fn-class!v11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv15,arbace.aot.emit10,emit-localv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core4,keysR177,R18,R178,V1,nR179,R110,R82,R123,R180,R110,R82,R181,m2,R32,V2,R33,R149,R112,R18,R182,R26,R18,R183,v15,arbace.aot.emit13,body-instancev15,arbace.aot.emit7,fn-wrapv15,arbace.aot.emit12,identity-setR112,v11,arbace.core6,vectorR110,R89,R184,R185,R186,R187,R188,R189,R190,R191,R192,R193,R194,R195,R196,R197,v11,arbace.core7,keywordR198,R199,v11,arbace.core3,setR200,R201,R202,m2,R32,V2,R40,R40,R203,R201,R204,R203,R203,R201,R204,R97,R203,R203,R201,R205,R203,R201,R202,m2,R32,V2,R40,R40,R203,v11,arbace.core10,sorted-mapR206,R207,R26,R208,R201,R125,R209,R210,R211,R50,R209,R210,R212,R213,S2,s9,instance?s5,localv15,arbace.aot.emit8,emit-tryR214,v15,arbace.aot.emit11,fn-instancev15,arbace.aot.emit8,emit-defv15,arbace.aot.emit11,emit-invokev15,arbace.aot.emit9,line-metav15,arbace.aot.emit19,emit-deftype-class!R215,R216,R217,R218,R42,v15,arbace.aot.emit19,emit-instance-fieldv15,arbace.aot.emit9,var-valueR219,R119,R220,R81,R221,v11,arbace.core4,keepR89,v11,arbace.core7,butlastv11,arbace.core4,lastv15,arbace.aot.emit7,emit-ifv15,arbace.aot.emit11,emit-assignv15,arbace.aot.emit10,emit-letfnR49,R50,R51,R50,R52,R222,R80,R81,R223,v15,arbace.aot.emit9,coll-callv15,arbace.aot.emit8,emit-letR39,R40,R41,v15,arbace.aot.emit10,emit-recurR224,R38,R225,R89,R226,v15,arbace.aot.emit8,emit-newR227,R50,R228,R229,R23,R24,R89,R230,R231,R89,R232,R50,R233,R234,R235,R30,v15,arbace.aot.emit17,emit-static-fieldv15,arbace.aot.emit9,emit-caseR236,R237,R18,R238,R18,R19,R239,R240,R241,R125,R242,v15,arbace.aot.emit8,box-primR89,R241,R125,R227,R50,R228,v15,arbace.aot.emit4,deepv15,arbace.aot.emit7,throws?R96,m2,R32,V1,R97,R98,R91,R50,R92,R93,R50,R94,R50,R209,R50,R243,v15,arbace.aot.emit8,ret-bodyR244,R245,R246,R172,R110,R247,R248,m2,R32,V1,R40,v15,arbace.aot.emit12,prim-classesv11,arbace.core10,ns-resolvev11,arbace.core4,*ns*R249,R250,R251,m2,R252,TR253,m4,R254,TR74,Tv15,arbace.aot.emit4,poolR255,R256,R86,v11,arbace.core4,takeR257,R86,R258,v15,arbace.aot.emit11,method-bodym2,R254,Tm2,R254,TR71,v15,arbace.aot.emit10,field-modsR259,R260,R261,ML1,R262,m4,R102,i1136,R263,i26,R112,R86,m2,R254,TR86,R261,m2,R254,TR264,R26,R26,R261,m2,R254,TR264,R26,R26,R258,R265,m4,R254,TR73,TR266,R258,v15,arbace.aot.emit9,tag-classR267,m2,R32,V1,R33,R268,R50,v15,arbace.aot.emit9,box-classm2,R32,V1,R33,R269,m4,R254,TR73,TR52,R110,m2,R270,TR110,R112,R271,R18,R272,R26,R26,R273,R274,R275,R40,R276,v15,arbace.aot.emit16,class-interfacesR277,R278,R279,R71,v11,arbace.core4,someV2,R86,R280,v15,arbace.aot.emit9,param-symR258,R281,R282,R283,m2,R254,TV2,R86,R280,m2,R254,TR86,R258,m2,R254,Tm2,R254,Tv15,arbace.aot.emit8,top-nameR284,R280,R86,R261,ML1,R262,m4,R102,i1215,R263,i26,m2,R254,TV1,R86,R285,R52,V1,ML3,R112,ML2,R286,R86,m4,R102,i1216,R263,i53,R285,m4,R102,i1216,R263,i47,R112,R86,R71,R82,R287,m4,R254,TR73,TR71,R288,R52,R258,ML2,R286,R86,m4,R102,i1248,R263,i117,R289,m2,R254,TV1,R86,R52,R258,R290,m2,R254,TR51,R86,R291,R52,R18,R291,R86,R292,R293,R40,R116,R50,R117,R101,v11,arbace.core15,get-proxy-classR80,R294,m2,R32,V2,R40,R40,R295,m2,R32,V1,R40,R18,R19,R162,R235,R36,R50,R37,m2,R32,V2,R40,R40,m2,R32,V1,R40,R258,m4,R75,TR73,TR89,R296,R26,R26,v11,arbace.core7,find-nsR297,v15,arbace.aot.emit7,unit-nsv15,arbace.aot.emit11,unit-methodv15,arbace.aot.emit11,pool-fieldsR298,R254,R74,R299,R258,R300,m4,R254,TR73,TV1,nR89,v11,arbace.core5,rangev11,arbace.core6,dissocR73,R301,v15,arbace.aot.emit10,class-formv15,arbace.aot.emit11,simple-nameR302,R298,m6,R254,TR73,TR74,TR298,m6,R254,TR73,TR131,TR303,R298,m6,R254,TR73,TR74,TR304,v11,arbace.core4,peekv11,arbace.core3,popv11,arbace.core8,group-byv11,arbace.core7,sort-byv11,arbace.core4,sortR258,m4,R254,TR305,TR86,m4,R254,TR305,T")

var Lit_1 *jrt.String = jrt.Intern("arbace.aot.emit$body_instance$iter__90000175__90000179")

var Lit_2 *jrt.String = jrt.Intern("new-instance")

var Lit_3 *jrt.String = jrt.Intern("arbace.aot.emit$body_instance$iter__90000175__90000179$fn__90000180")

var Lit_4 *jrt.String = jrt.Intern("arbace.aot.emit$body_instance$iter__90000175__90000179$fn__90000180$fn__90000181")

var Lit_5 *jrt.String = jrt.Intern("arbace.aot.emit$class_form$fn__90000530")

var Lit_6 *jrt.String = jrt.Intern("arbace.aot.emit$class_form$mods__90000532")

var Lit_7 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$parent__90000537")

var Lit_8 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$fn__90000539")

var Lit_9 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$iter__90000541__90000545")

var Lit_10 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$fn__90000551")

var Lit_11 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$children_of__90000553")

var Lit_12 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$iter__90000555__90000559")

var Lit_13 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$iter__90000541__90000545$fn__90000546")

var Lit_14 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$iter__90000541__90000545$fn__90000546$fn__90000547")

var Lit_15 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$iter__90000555__90000559$fn__90000560")

var Lit_16 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms$iter__90000555__90000559$fn__90000560$fn__90000561")

var Lit_17 *jrt.String = jrt.Intern("$")

var Lit_18 *jrt.String = jrt.Intern("no class for ")

var Lit_19 *jrt.String = jrt.Intern("arbace.aot.emit$class_interfaces$iter__90000298__90000302")

var Lit_20 *jrt.String = jrt.Intern("arbace.aot.emit$class_interfaces$iter__90000298__90000302$fn__90000303")

var Lit_21 *jrt.String = jrt.Intern("arbace.aot.emit$class_interfaces$iter__90000298__90000302$fn__90000303$fn__90000304")

var Lit_22 *jrt.String = jrt.Intern(" implements ")

var Lit_23 *jrt.String = jrt.Intern(", made at run time")

var Lit_24 *jrt.String = jrt.Intern("const-")

var Lit_25 *jrt.String = jrt.Intern("V")

var Lit_26 *jrt.String = jrt.Intern("J")

var Lit_27 *jrt.String = jrt.Intern("I")

var Lit_28 *jrt.String = jrt.Intern("D")

var Lit_29 *jrt.String = jrt.Intern("Z")

var Lit_30 *jrt.String = jrt.Intern("C")

var Lit_31 *jrt.String = jrt.Intern("F")

var Lit_32 *jrt.String = jrt.Intern("S")

var Lit_33 *jrt.String = jrt.Intern("B")

var Lit_34 *jrt.String = jrt.Intern(".")

var Lit_35 *jrt.String = jrt.Intern("/")

var Lit_36 *jrt.String = jrt.Intern("L")

var Lit_37 *jrt.String = jrt.Intern(";")

var Lit_38 *jrt.String = jrt.Intern("compile__stub.")

var Lit_39 *jrt.String = jrt.Intern("try")

var Lit_40 *jrt.String = jrt.Intern("def")

var Lit_41 *jrt.String = jrt.Intern("invoke")

var Lit_42 *jrt.String = jrt.Intern("instance-method")

var Lit_43 *jrt.String = jrt.Intern("empty")

var Lit_44 *jrt.String = jrt.Intern("unknown empty collection")

var Lit_45 *jrt.String = jrt.Intern("instance-field")

var Lit_46 *jrt.String = jrt.Intern("var")

var Lit_47 *jrt.String = jrt.Intern("keyword-invoke")

var Lit_48 *jrt.String = jrt.Intern("do")

var Lit_49 *jrt.String = jrt.Intern("arbace.aot.emit$emit$fn__90000263")

var Lit_50 *jrt.String = jrt.Intern("fn")

var Lit_51 *jrt.String = jrt.Intern("if")

var Lit_52 *jrt.String = jrt.Intern("set!")

var Lit_53 *jrt.String = jrt.Intern("with-meta")

var Lit_54 *jrt.String = jrt.Intern("letfn")

var Lit_55 *jrt.String = jrt.Intern("number")

var Lit_56 *jrt.String = jrt.Intern("the-var")

var Lit_57 *jrt.String = jrt.Intern("keyword")

var Lit_58 *jrt.String = jrt.Intern("local")

var Lit_59 *jrt.String = jrt.Intern("string")

var Lit_60 *jrt.String = jrt.Intern("vector")

var Lit_61 *jrt.String = jrt.Intern("arbace.aot.emit$emit$fn__90000265")

var Lit_62 *jrt.String = jrt.Intern("let")

var Lit_63 *jrt.String = jrt.Intern("recur")

var Lit_64 *jrt.String = jrt.Intern("constant")

var Lit_65 *jrt.String = jrt.Intern("map")

var Lit_66 *jrt.String = jrt.Intern("monitor-exit")

var Lit_67 *jrt.String = jrt.Intern("throw")

var Lit_68 *jrt.String = jrt.Intern("new")

var Lit_69 *jrt.String = jrt.Intern("nil")

var Lit_70 *jrt.String = jrt.Intern("boolean")

var Lit_71 *jrt.String = jrt.Intern("monitor-enter")

var Lit_72 *jrt.String = jrt.Intern("list")

var Lit_73 *jrt.String = jrt.Intern("import")

var Lit_74 *jrt.String = jrt.Intern("static-method")

var Lit_75 *jrt.String = jrt.Intern("static-field")

var Lit_76 *jrt.String = jrt.Intern("str-concat")

var Lit_77 *jrt.String = jrt.Intern("arbace.aot.emit$emit$fn__90000267")

var Lit_78 *jrt.String = jrt.Intern("case")

var Lit_79 *jrt.String = jrt.Intern("set")

var Lit_80 *jrt.String = jrt.Intern("instance?")

var Lit_81 *jrt.String = jrt.Intern("no back end for ")

var Lit_82 *jrt.String = jrt.Intern(" ")

var Lit_83 *jrt.String = jrt.Intern("set! of a local that is no field")

var Lit_84 *jrt.String = jrt.Intern(".-")

var Lit_85 *jrt.String = jrt.Intern("set! of ")

var Lit_86 *jrt.String = jrt.Intern("arbace.aot.emit$emit_case$sm__90000241")

var Lit_87 *jrt.String = jrt.Intern("arbace.aot.emit$emit_case$ret__90000243")

var Lit_88 *jrt.String = jrt.Intern("case-")

var Lit_89 *jrt.String = jrt.Intern("arbace.aot.emit$emit_case$arm__90000245")

var Lit_90 *jrt.String = jrt.Intern("arbace.aot.emit$emit_case$fn__90000248")

var Lit_91 *jrt.String = jrt.Intern("arbace.aot.emit$emit_case$fn__90000254")

var Lit_92 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$ftype__90000313")

var Lit_93 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$fsym__90000315")

var Lit_94 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$fn__90000317")

var Lit_95 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000319__90000323")

var Lit_96 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$ps__90000329")

var Lit_97 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000333__90000337")

var Lit_98 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$fn__90000350")

var Lit_99 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000355__90000359")

var Lit_100 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000371__90000375")

var Lit_101 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000389__90000393")

var Lit_102 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000319__90000323$fn__90000324")

var Lit_103 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000319__90000323$fn__90000324$fn__90000325")

var Lit_104 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000333__90000337$fn__90000338")

var Lit_105 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000333__90000337$fn__90000338$fn__90000339")

var Lit_106 *jrt.String = jrt.Intern("v__")

var Lit_107 *jrt.String = jrt.Intern("Value")

var Lit_108 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000355__90000359$fn__90000360")

var Lit_109 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000355__90000359$fn__90000360$fn__90000361")

var Lit_110 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000371__90000375$fn__90000376")

var Lit_111 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000371__90000375$fn__90000376$fn__90000377")

var Lit_112 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000371__90000375$fn__90000376$fn__90000383")

var Lit_113 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000371__90000375$fn__90000376$fn__90000385")

var Lit_114 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000371__90000375$fn__90000376$fn__90000377$fn__90000378")

var Lit_115 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000371__90000375$fn__90000376$fn__90000377$fn__90000380")

var Lit_116 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000389__90000393$fn__90000394")

var Lit_117 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$iter__90000389__90000393$fn__90000394$fn__90000395")

var Lit_118 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_$ps__90000329$fn__90000330")

var Lit_119 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$fn__90000402")

var Lit_120 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000404__90000408")

var Lit_121 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000414__90000418")

var Lit_122 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000424__90000428")

var Lit_123 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$fn__90000434")

var Lit_124 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000436__90000440")

var Lit_125 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000446__90000450")

var Lit_126 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000464__90000468")

var Lit_127 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000474__90000478")

var Lit_128 *jrt.String = jrt.Intern("__")

var Lit_129 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000404__90000408$fn__90000409")

var Lit_130 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000404__90000408$fn__90000409$fn__90000410")

var Lit_131 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000414__90000418$fn__90000419")

var Lit_132 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000414__90000418$fn__90000419$fn__90000420")

var Lit_133 *jrt.String = jrt.Intern("c__")

var Lit_134 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000424__90000428$fn__90000429")

var Lit_135 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000424__90000428$fn__90000429$fn__90000430")

var Lit_136 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000436__90000440$fn__90000441")

var Lit_137 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000436__90000440$fn__90000441$fn__90000442")

var Lit_138 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000446__90000450$fn__90000451")

var Lit_139 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000446__90000450$fn__90000451$fn__90000452")

var Lit_140 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000446__90000450$fn__90000451$fn__90000458")

var Lit_141 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000446__90000450$fn__90000451$fn__90000460")

var Lit_142 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000446__90000450$fn__90000451$fn__90000452$fn__90000453")

var Lit_143 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000446__90000450$fn__90000451$fn__90000452$fn__90000455")

var Lit_144 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000464__90000468$fn__90000469")

var Lit_145 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000464__90000468$fn__90000469$fn__90000470")

var Lit_146 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000474__90000478$fn__90000479")

var Lit_147 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_$iter__90000474__90000478$fn__90000479$fn__90000480")

var Lit_148 *jrt.String = jrt.Intern("arbace.lang.Compiler$AOTR")

var Lit_149 *jrt.String = jrt.Intern("arbace.lang.Compiler$AOTF")

var Lit_150 *jrt.String = jrt.Intern("arbace.aot.emit$emit_if$br__90000164")

var Lit_151 *jrt.String = jrt.Intern("target-")

var Lit_152 *jrt.String = jrt.Intern("arbace.aot.emit$emit_invoke$call__90000138")

var Lit_153 *jrt.String = jrt.Intern("arbace.aot.emit$emit_invoke$fn__90000142")

var Lit_154 *jrt.String = jrt.Intern("arbace.aot.emit$emit_invoke$call__90000138$fn__90000139")

var Lit_155 *jrt.String = jrt.Intern("arbace.aot.emit$emit_let$fn__90000169")

var Lit_156 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$fn__90000190")

var Lit_157 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$fn__90000192")

var Lit_158 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$iter__90000194__90000198")

var Lit_159 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$iter__90000204__90000210")

var Lit_160 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$fn__90000223")

var Lit_161 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$fn__90000225")

var Lit_162 *jrt.String = jrt.Intern("body-")

var Lit_163 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$iter__90000194__90000198$fn__90000199")

var Lit_164 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$iter__90000194__90000198$fn__90000199$fn__90000200")

var Lit_165 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$iter__90000204__90000210$fn__90000211")

var Lit_166 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$iter__90000204__90000210$fn__90000211$iter__90000206__90000215")

var Lit_167 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$iter__90000204__90000210$fn__90000211$iter__90000206__90000215$fn__90000216")

var Lit_168 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn$iter__90000204__90000210$fn__90000211$iter__90000206__90000215$fn__90000216$fn__90000217")

var Lit_169 *jrt.String = jrt.Intern("arbace.aot.emit$emit_list_array$fn__90000036")

var Lit_170 *jrt.String = jrt.Intern("arbace.aot.emit$emit_recur$fn__90000172")

var Lit_171 *jrt.String = jrt.Intern("recur arg for primitive local: ")

var Lit_172 *jrt.String = jrt.Intern(" is not matching primitive")

var Lit_173 *jrt.String = jrt.Intern("__init")

var Lit_174 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source$fn__90000513")

var Lit_175 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source$iter__90000518__90000522")

var Lit_176 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source$iter__90000518__90000522$fn__90000523")

var Lit_177 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source$iter__90000518__90000522$fn__90000523$fn__90000524")

var Lit_178 *jrt.String = jrt.Intern("unit")

var Lit_179 *jrt.String = jrt.Intern("arbace.aot.emit$emit_try$body__90000228")

var Lit_180 *jrt.String = jrt.Intern("arbace.aot.emit$emit_try$iter__90000230__90000234")

var Lit_181 *jrt.String = jrt.Intern("arbace.aot.emit$emit_try$iter__90000230__90000234$fn__90000235")

var Lit_182 *jrt.String = jrt.Intern("arbace.aot.emit$emit_try$iter__90000230__90000234$fn__90000235$fn__90000236")

var Lit_183 *jrt.String = jrt.Intern("unboxed emit of ")

var Lit_184 *jrt.String = jrt.Intern("arbace.aot.emit$emit_unboxed$fn__90000272")

var Lit_185 *jrt.String = jrt.Intern("no unboxed back end for ")

var Lit_186 *jrt.String = jrt.Intern("TYPE")

var Lit_187 *jrt.String = jrt.Intern("a record as a constant: ")

var Lit_188 *jrt.String = jrt.Intern("a deftype as a constant: ")

var Lit_189 *jrt.String = jrt.Intern("arbace.aot.emit$emit_value$fn__90000045")

var Lit_190 *jrt.String = jrt.Intern("arbace.aot.emit$emit_value$fn__90000047")

var Lit_191 *jrt.String = jrt.Intern("#<")

var Lit_192 *jrt.String = jrt.Intern("can't embed unreadable object in code: ")

var Lit_193 *jrt.String = jrt.Intern("arbace.lang.Compiler$AST")

var Lit_194 *jrt.String = jrt.Intern("arbace.lang.Var")

var Lit_195 *jrt.String = jrt.Intern("arbace.lang.Keyword")

var Lit_196 *jrt.String = jrt.Intern("arbace.lang.Symbol")

var Lit_197 *jrt.String = jrt.Intern("arbace.lang.IObj")

var Lit_198 *jrt.String = jrt.Intern("arbace.lang.IPersistentMap")

var Lit_199 *jrt.String = jrt.Intern("arbace.lang.IPersistentVector")

var Lit_200 *jrt.String = jrt.Intern("arbace.lang.IPersistentSet")

var Lit_201 *jrt.String = jrt.Intern("arbace.lang.IPersistentList")

var Lit_202 *jrt.String = jrt.Intern("arbace.lang.ISeq")

var Lit_203 *jrt.String = jrt.Intern("arbace.lang.IType")

var Lit_204 *jrt.String = jrt.Intern("arbace.lang.IRecord")

var Lit_205 *jrt.String = jrt.Intern("arbace.lang.PersistentHashSet")

var Lit_206 *jrt.String = jrt.Intern("arbace.lang.Namespace")

var Lit_207 *jrt.String = jrt.Intern("java.util.IdentityHashMap")

var Lit_208 *jrt.String = jrt.Intern("java.util.regex.Pattern")

var Lit_209 *jrt.String = jrt.Intern("aot: ")

var Lit_210 *jrt.String = jrt.Intern("fiMethod")

var Lit_211 *jrt.String = jrt.Intern("/go/arbace/jrt")

var Lit_212 *jrt.String = jrt.Intern("ARBACE_AOT_ROOT")

var Lit_213 *jrt.String = jrt.Intern("fn-class")

var Lit_214 *jrt.String = jrt.Intern("fncls__")

var Lit_215 *jrt.String = jrt.Intern("d")

var Lit_216 *jrt.String = jrt.Intern("arbace.aot.emit$interface_record$fn__90000567")

var Lit_217 *jrt.String = jrt.Intern("arbace.aot.emit$interface_record$iter__90000569__90000573")

var Lit_218 *jrt.String = jrt.Intern("arbace.aot.emit$interface_record$iter__90000569__90000573$fn__90000574")

var Lit_219 *jrt.String = jrt.Intern("arbace.aot.emit$interface_record$iter__90000569__90000573$fn__90000574$fn__90000575")

var Lit_220 *jrt.String = jrt.Intern("arbace.aot.emit$interface_record$iter__90000569__90000573$fn__90000574$fn__90000585")

var Lit_221 *jrt.String = jrt.Intern("arbace.aot.emit$interface_record$iter__90000569__90000573$fn__90000574$fn__90000575$fn__90000579")

var Lit_222 *jrt.String = jrt.Intern("p")

var Lit_223 *jrt.String = jrt.Intern("(")

var Lit_224 *jrt.String = jrt.Intern(")")

var Lit_225 *jrt.String = jrt.Intern("arbace.aot.emit$jrt_lacks_QMARK_$fn__90000149")

var Lit_226 *jrt.String = jrt.Intern("_")

var Lit_227 *jrt.String = jrt.Intern("fn-method")

var Lit_228 *jrt.String = jrt.Intern("arbace.aot.emit$method_body$iter__90000280__90000284")

var Lit_229 *jrt.String = jrt.Intern("arbace.aot.emit$method_body$fn__90000290")

var Lit_230 *jrt.String = jrt.Intern("arbace.aot.emit$method_body$fn__90000292")

var Lit_231 *jrt.String = jrt.Intern("p-")

var Lit_232 *jrt.String = jrt.Intern("arbace.aot.emit$method_body$iter__90000280__90000284$fn__90000285")

var Lit_233 *jrt.String = jrt.Intern("arbace.aot.emit$method_body$iter__90000280__90000284$fn__90000285$fn__90000286")

var Lit_234 *jrt.String = jrt.Intern("a call of a method of a class made at run time: ")

var Lit_235 *jrt.String = jrt.Intern("arbace.aot.emit$obj_array$fn__90000130")

var Lit_236 *jrt.String = jrt.Intern("arbace.aot.emit$pool$fn__90000031")

var Lit_237 *jrt.String = jrt.Intern("")

var Lit_238 *jrt.String = jrt.Intern("arbace.aot.emit$pool_encode$num__90000055")

var Lit_239 *jrt.String = jrt.Intern("arbace.aot.emit$pool_encode$arr__90000057")

var Lit_240 *jrt.String = jrt.Intern("arbace.aot.emit$pool_encode$fn__90000064")

var Lit_241 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_242 *jrt.String = jrt.Intern("arbace.aot.emit$pool_fields$walk__90000067")

var Lit_243 *jrt.String = jrt.Intern("arbace.aot.emit$pool_fields$fn__90000073")

var Lit_244 *jrt.String = jrt.Intern("arbace.aot.emit$pool_fields$fn__90000081")

var Lit_245 *jrt.String = jrt.Intern("arbace.aot.emit$pool_fields$fn__90000087")

var Lit_246 *jrt.String = jrt.Intern("arbace.aot.emit$pool_fields$fn__90000093")

var Lit_247 *jrt.String = jrt.Intern("arbace.aot.emit$pool_fields$fn__90000102")

var Lit_248 *jrt.String = jrt.Intern("arbace.aot.emit$registered_QMARK_$fn__90000021")

var Lit_249 *jrt.String = jrt.Intern("arbace.aot.emit$registered_QMARK_$fn__90000023")

var Lit_250 *jrt.String = jrt.Intern("arbace.aot.emit$registered_QMARK_$fn__90000023$fn__90000024")

var Lit_251 *jrt.String = jrt.Intern("cut")

var Lit_252 *jrt.String = jrt.Intern("mismatched primitive return, expected ")

var Lit_253 *jrt.String = jrt.Intern(", had ")

var Lit_254 *jrt.String = jrt.Intern("arbace.aot.emit$typed_args$fn__90000125")

var Lit_255 *jrt.String = jrt.Intern("uncheckedIntCast")

var Lit_256 *jrt.String = jrt.Intern("intCast")

var Lit_257 *jrt.String = jrt.Intern("uncheckedFloatCast")

var Lit_258 *jrt.String = jrt.Intern("floatCast")

var Lit_259 *jrt.String = jrt.Intern("uncheckedDoubleCast")

var Lit_260 *jrt.String = jrt.Intern("doubleCast")

var Lit_261 *jrt.String = jrt.Intern("uncheckedLongCast")

var Lit_262 *jrt.String = jrt.Intern("longCast")

var Lit_263 *jrt.String = jrt.Intern("uncheckedByteCast")

var Lit_264 *jrt.String = jrt.Intern("byteCast")

var Lit_265 *jrt.String = jrt.Intern("uncheckedShortCast")

var Lit_266 *jrt.String = jrt.Intern("shortCast")

var Lit_267 *jrt.String = jrt.Intern("arbace.lang.RT")

var Lit_268 *jrt.String = jrt.Intern("arbace.aot.emit$unit_method$iter__90000490__90000494")

var Lit_269 *jrt.String = jrt.Intern("a top-level fn closing over locals")

var Lit_270 *jrt.String = jrt.Intern("arbace.aot.emit$unit_method$iter__90000490__90000494$fn__90000495")

var Lit_271 *jrt.String = jrt.Intern("arbace.aot.emit$unit_method$iter__90000490__90000494$fn__90000495$fn__90000496")

var Lit_272 *jrt.String = jrt.Intern("type")

var Lit_273 *jrt.String = jrt.Intern("an event of a class made at run time: ")

var Lit_274 *jrt.String = jrt.Intern("iface")

var Lit_275 *jrt.String = jrt.Intern("proxy")

var Lit_276 *jrt.String = jrt.Intern("arbace.aot.emit$unit_method$iter__90000490__90000494$fn__90000495$fn__90000502")

var Lit_277 *jrt.String = jrt.Intern("imethod")

var Lit_278 *jrt.String = jrt.Intern("stub")

var Lit_279 *jrt.String = jrt.Intern("ns")

var Lit_280 *jrt.String = jrt.Intern("an event of kind ")

var Lit_281 *jrt.String = jrt.Intern("arbace.aot.emit$unit_method$iter__90000490__90000494$fn__90000495$fn__90000496$fn__90000498")

var Lit_282 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn4,linekn6,columnkn4,filekn8,arglistsyn1,xyn3,msgyn1,&yn4,datakn3,tagyn6,Stringyn5,Classyn4,voidyn6,doubleyn4,charyn4,byteyn7,booleanyn5,floatyn4,longyn5,shortyn3,intyn1,syn1,cyn3,ctxyn3,topyn1,vyn5,ctypekn8,declaredyn2,xsyn9,Characterkn4,longkn6,doublekn3,intkn6,symbolkn6,stringkn6,vectorkn4,listkn3,varkn7,keywordkn5,classkn3,nilkn3,setkn7,booleankn3,mapkn4,charkn7,patternyn13,StringBuilderyn6,sharedyn6,constsyn4,baseyn1,byn2,lbyn1,eyn1,nyn1,fyn2,psyn2,esyn3,Varyn8,unboxed?yn24,java.lang.reflect.Methodyn1,tyn4,argsyn23,java.lang.reflect.Fieldyn4,top?yn3,symyn4,inityn2,oxyn10,nil-localsyn4,bodyys14,java.lang.Long7,valueOfys16,java.lang.Double7,valueOfys17,java.lang.Integer7,valueOfys17,java.lang.Boolean7,valueOfys19,java.lang.Character7,valueOfys15,java.lang.Float7,valueOfys15,java.lang.Short7,valueOfys14,java.lang.Byte7,valueOfyn2,mnyn6,paramsyn3,tagyn1,kyn4,kindyn4,lineyn6,columnyn1,_yn4,expryn6,eventsyn7,classesyn15,runtime-classesyn8,fn-namesyn5,poolsyn3,srcyn5,unitsyn11,children-ofyn4,nameyn7,extendsyn7,methodsv11,arbace.core5,in-nsMyn15,arbace.aot.emitm2,R0,s1524,Standalone S6 (doc/STANDALONE-NOTES.md, \"S6: Arbace compiled to Go\"): the back end that\n  compiles analyzed namespaces to class forms, which a2g translates into Go like the runtime's\n  own classes.\n\n  The input is what the program records while it prepares its namespaces (ARBACE_COMPILE): for\n  each source, its units in order (a top-level form, analyzed: Compiler$Image's unit, its Expr\n  tree and the events of its analysis), read through Compiler$AST/node, which shows a node's\n  fields as a map. The output follows the JVM's bytecode back end (Compiler.clj on the branch\n  arbace-for-java-26: ObjExpr.compile, the emit methods), with class forms in place of\n  bytecode:\n\n  - a fn (FnExpr) is a class named as the JVM names it (arbace.walk$walk), a static member\n    class of a holder class per namespace (arbace.walk), nested as its name nests; it extends\n    AFunction (RestFn when variadic), its closed-over locals are fields set by its constructor,\n    each arity an invoke method (doInvoke for the variadic one), its constants static fields;\n  - a source's top-level forms are the static methods of its loader class SCRIPTBASE__init\n    (arbace.walk__init), whose load() runs them in order; Compiler$AOT/load calls it in the\n    bindings Compiler.load makes;\n  - each Expr becomes the class forms code its emit method's bytecode is: interop on the\n    analyzer's resolved members (param-tags pin the overload), reflection where it was\n    unresolved, Clojure's boxing and conversions (emitBoxReturn, emitTypedArgs).m2,R0,s1524,Standalone S6 (doc/STANDALONE-NOTES.md, \"S6: Arbace compiled to Go\"): the back end that\n  compiles analyzed namespaces to class forms, which a2g translates into Go like the runtime's\n  own classes.\n\n  The input is what the program records while it prepares its namespaces (ARBACE_COMPILE): for\n  each source, its units in order (a top-level form, analyzed: Compiler$Image's unit, its Expr\n  tree and the events of its analysis), read through Compiler$AST/node, which shows a node's\n  fields as a map. The output follows the JVM's bytecode back end (Compiler.clj on the branch\n  arbace-for-java-26: ObjExpr.compile, the emit methods), with class forms in place of\n  bytecode:\n\n  - a fn (FnExpr) is a class named as the JVM names it (arbace.walk$walk), a static member\n    class of a holder class per namespace (arbace.walk), nested as its name nests; it extends\n    AFunction (RestFn when variadic), its closed-over locals are fields set by its constructor,\n    each arity an invoke method (doInvoke for the variadic one), its constants static fields;\n  - a source's top-level forms are the static methods of its loader class SCRIPTBASE__init\n    (arbace.walk__init), whose load() runs them in order; Compiler$AOT/load calls it in the\n    bindings Compiler.load makes;\n  - each Expr becomes the class forms code its emit method's bytecode is: interop on the\n    analyzer's resolved members (param-tags pin the overload), reflection where it was\n    unresolved, Clojure's boxing and conversions (emitBoxReturn, emitTypedArgs).R1,v15,arbace.aot.emit10,node-cachem10,R2,TR3,i34,R4,i1,R5,s18,arbace/aot/emit.aeR0,s58,The nodes' maps by node (the back end runs on one thread).v15,arbace.aot.emit4,nodem10,R6,L1,V1,R7,R0,s62,The analyzed node x as a map (Compiler$AST/node), nil for nil.R3,i38,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit4,failm10,R2,TR6,L1,V3,R8,R9,V1,R10,R3,i47,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit6,destubm10,R6,L1,V1,Myn1,nm2,R11,R12,R0,s74,A class name without the compile stub's prefix (Compiler.destubClassName).R3,i53,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit8,type-symm10,R6,L1,V1,Myn1,cm2,R11,R13,R0,s94,The class forms type of class c: a primitive's name, a class's binary name, an array as\n  T/n.R3,i58,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,prim-namesR14,R15,R16,R17,R18,R19,R20,R21,R22,m8,R2,TR3,i69,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit6,taggedm12,R2,TR6,L1,V2,R23,R24,R0,s45,Symbol s with the class forms tag of class c.R3,i73,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,registeredv11,arbace.core4,atomm10,R2,TR3,i82,R4,i1,R5,s18,arbace/aot/emit.aeR0,s84,Whether a class name is registered in the program (Class/forName finds it), by name.v15,arbace.aot.emit11,registered?m10,R2,TR6,L1,V1,Myn1,cm2,R11,R13,R3,i86,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit14,runtime-class?m12,R2,TR6,L1,V2,Myn1,cm2,R11,R13,R25,R0,s291,Is class c made at run time (a Dyn class: an evaluated fn's, deftype's, interface's, proxy's)\n  rather than a class of the program, or one the program does not register by name (java.sql's,\n  whose members reflection reached from a world class)? Such a class is not named in compiled\n  code.R3,i103,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit7,public?m10,R2,TR6,L1,V1,Myn1,cm2,R11,R13,R3,i112,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit8,top-namem10,R2,TR6,L1,V1,Myn1,nm2,R11,R12,R3,i118,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit4,poolm12,R2,TR6,L1,V2,R25,R26,R0,s178,The constants of top-level class top (a namespace's holder, a deftype, a loader), which its\n  member classes share (SA145): an atom {:name :consts :const-map}, made on first use.R3,i120,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit11,const-fieldm12,R2,TR6,L1,V3,R25,R27,R28,R0,s236,The static field holding constant value v in the class being emitted, made on first use (as\n  the JVM's const__N, one per distinct object): its symbol, const-N (a munged local's name has\n  no -, so no local, name__index, can shadow it).R3,i130,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,emit-valuem8,R29,TR3,i144,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit15,emit-list-arraym10,R2,TR6,L1,V2,R25,R30,R3,i146,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,char-formm10,R2,TR6,L1,V1,Myn1,cm2,R11,R31,R3,i149,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit11,double-formm10,R2,TR6,L1,V1,Myn1,dm2,R11,R15,R3,i155,R4,i1,R5,s18,arbace/aot/emit.aem10,R6,L1,V2,R25,R27,R0,s72,Code making constant value v (ObjExpr.emitValue), its metadata included.R3,i160,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,pool-kindm12,R2,TR6,L1,V1,R27,R0,s58,The tag of constant v, in the order of emit-value's cases.R3,i236,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit12,pool-partialS16,R32,R33,R34,R35,R36,R37,R38,R39,R40,R41,R42,R43,R44,R45,R46,R47,m10,R2,TR3,i261,R4,i1,R5,s18,arbace/aot/emit.aeR0,s61,The kinds whose metadata is made too (emit-value's partial?).v15,arbace.aot.emit12,pool-shared?m12,R2,TR6,L1,V1,R27,R0,s84,Is v made once in a pool and named where used: a keyword, a symbol without metadata.R3,i265,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,pool-partsm12,R2,TR6,L1,V1,R27,R0,s62,The values constant v is made of (its elements, its metadata).R3,i270,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit8,pool-strm10,R2,TR6,L1,V2,Myn2,sbm2,R11,R48,Myn1,sm2,R11,R12,R3,i281,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit11,pool-encodem12,R2,TR6,L1,V3,Myn2,sbm2,R11,R48,R49,R27,R0,s102,Appends the encoding of v to sb (Compiler$AOT/poolValue's format); shared: shared value →\n  its index.R3,i284,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit11,pool-fieldsm12,R2,TR6,L1,V1,R50,R0,s156,The static fields of constants consts ([sym type value] ...): the pool's array, decoded\n  once (Compiler$AOT/pool), then each constant's field, its element.R3,i332,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,const-typem10,R2,TR6,L1,V1,R27,R3,i360,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit8,constantm10,R2,TR6,L1,V2,R25,R27,R3,i366,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit4,gsymm12,R2,TR6,L1,V2,R25,R51,R0,s146,A fresh name for a temporary of the emitted code, numbered per class being emitted (the\n  output does not depend on the program's gensym counter).R3,i379,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,local-symm12,R2,TR6,L1,V1,R52,R0,s96,The class forms local of LocalBinding lb (its node b): its name and index, unique in a\n  method.R3,i387,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit12,identity-setm12,R2,TR6,L1,V1,R30,R0,s259,The objects of xs as a set by identity. A fn's closes map cannot be asked containsKey: its\n  keys, LocalBindings, hash by their index (Arbace's deterministic hashCode), and FnExpr.parse\n  renumbers a direct fn's arguments after its inner fns closed over them.R3,i393,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit7,closed?m10,R2,TR6,L1,V2,R25,R53,R3,i402,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,field-symm10,R2,TR6,L1,V1,R52,R3,i406,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,field-readm10,R2,TR6,L1,V3,R25,R53,R52,R3,i408,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit4,emitm8,R29,TR3,i414,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit12,emit-unboxedm8,R29,TR3,i414,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit14,emit-fn-class!m8,R29,TR3,i414,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit19,emit-deftype-class!m8,R29,TR3,i414,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,emit-bodym8,R29,TR3,i414,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit4,primm10,R2,TR6,L1,V1,R54,R3,i416,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,can-prim?m10,R2,TR6,L1,V1,R55,R3,i418,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit6,box-ofm8,R29,TR3,i420,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit3,boxm12,R2,TR6,L1,V2,R56,Myn1,cm2,R11,R13,R0,s113,Form f of type c as a boxed value (emitBoxReturn: valueOf, long's Numbers.num being\n  Long.valueOf; void as nil).R3,i422,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,unbox-argm12,R2,TR6,L1,V3,R25,R56,Myn1,pm2,R11,R13,R0,s67,Boxed form f converted to parameter type p (HostExpr.emitUnboxArg).R3,i431,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit3,fi?m12,R2,TR6,L1,V1,Myn1,pm2,R11,R13,R0,s136,Is p a functional interface a fn argument is adapted to (Clojure 1.12's FISupport, as the\n  analysis decides it: Compiler$AST/fiMethod)?R3,i450,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,typed-argsm12,R2,TR6,L1,V3,R25,R57,R58,R0,s70,The arguments es as parameters of types ps (MethodExpr.emitTypedArgs).R3,i457,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,param-tagsm10,R2,TR6,L1,V1,R57,R3,i481,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,obj-arraym10,R2,TR6,L1,V2,R25,R58,R3,i483,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,var-valuem10,R2,TR6,L1,V2,R25,Myn1,vm2,R11,R59,R3,i486,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,line-metam10,R2,TR6,L1,V2,R56,R55,R3,i490,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,emit-localm10,R2,TR6,L1,V3,R25,R55,R60,R3,i495,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit11,emit-invokem10,R2,TR6,L1,V2,R25,R55,R3,i507,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,descriptorm10,R2,TR6,L1,V1,Myn1,cm2,R11,R13,R3,i537,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit8,jrt-scanm8,R2,TR3,i545,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,jrt-lacks?m12,R2,TR6,L1,V1,Myn1,mm2,R11,R61,R0,s255,Is method m declared by a class jrt writes by hand (not a stand-in a2g's translation\n  replaces) without it in Go? a2g would translate a direct call to a throw; the member tables\n  (reflection) have such members, so compiled code calls them by reflection.R3,i548,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit11,method-callm12,R2,TR6,L1,V4,R25,Myn1,mm2,R11,R61,R62,R63,R0,s69,A call of resolved method m: static (target nil) or on target form t.R3,i567,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit19,compiled-interface?m12,R2,TR6,L1,V2,R25,Myn1,cm2,R11,R13,R0,s86,Is class c an interface of a namespace being compiled (gen-interface's, a protocol's)?R3,i580,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit20,emit-instance-methodm10,R2,TR6,L1,V3,R25,R55,R60,R3,i585,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit18,emit-static-methodm10,R2,TR6,L1,V3,R25,R55,R60,R3,i618,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,field-ok?m10,R2,TR6,L1,V2,R25,Myn1,fm2,R11,R64,R3,i632,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit19,emit-instance-fieldm10,R2,TR6,L1,V3,R25,R55,R60,R3,i635,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit17,emit-static-fieldm10,R2,TR6,L1,V3,R25,R55,R60,R3,i644,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit8,emit-newm10,R2,TR6,L1,V2,R25,R55,R3,i652,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit8,emit-defm10,R2,TR6,L1,V3,R25,R55,R65,R3,i661,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit11,emit-assignm10,R2,TR6,L1,V2,R25,R55,R3,i679,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,coll-callm10,R2,TR6,L1,V3,R66,R58,R25,R3,i701,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit7,emit-ifm10,R2,TR6,L1,V3,R25,R55,R60,R3,i704,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit17,emit-binding-initm12,R2,TR6,L1,V3,R25,R53,R67,R0,s69,A let or loop binding [sym init] of LocalBinding lb (LetExpr.doEmit).R3,i713,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit8,emit-letm10,R2,TR6,L1,V3,R25,R55,R60,R3,i722,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,emit-recurm10,R2,TR6,L1,V2,R25,R55,R3,i729,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit13,body-instancem12,R2,TR6,L1,V3,R25,R68,R69,R0,s228,A new instance of fn or reify class ox (its node), its closed-over values from the current\n  method: (new C closed...) (ObjExpr.emit); letfn's own locals nil (set after). A fn's is its\n  code (SA141), which fn-wrap makes the fn.R3,i750,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit7,fn-wrapm12,R2,TR6,L1,V3,R25,R68,R70,R0,s135,The fn of fn ox (its node) whose code is form body: a Compiler$AOTFn, or a\n  Compiler$AOTRestFn of the variadic arity's required count.R3,i763,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit11,fn-instancem12,R2,TR6,L1,V3,R25,R68,R69,R0,s33,A new fn or reify (ox, its node).R3,i786,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,emit-letfnm10,R2,TR6,L1,V3,R25,R55,R60,R3,i792,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit8,emit-trym10,R2,TR6,L1,V3,R25,R55,R60,R3,i809,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,emit-casem10,R2,TR6,L1,V3,R25,R55,R60,R3,i818,R4,i1,R5,s18,arbace/aot/emit.aeR71,R72,R73,R74,R75,R76,R77,R78,m8,R2,TR3,i865,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit8,box-primm12,R2,TR6,L1,V2,R56,R55,R0,s200,Form f of node n boxed when it is of a primitive type (emitBoxReturn: valueOf, long's\n  Numbers.num being Long.valueOf), so that emit's code is always a reference, as the bytecode's\n  emit leaves one.R3,i871,R4,i1,R5,s18,arbace/aot/emit.aem10,R6,L1,V2,R25,R54,R0,s59,Code for analyzed node e, its value boxed (an Expr's emit).R3,i882,R4,i1,R5,s18,arbace/aot/emit.aem10,R6,L1,V2,R25,R54,R0,s72,Code for analyzed node e, its value of its primitive type (emitUnboxed).R3,i958,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit4,deepm12,R2,TR6,L1,V1,R56,R0,s160,Form f realized throughout (the emitters build lazy seqs; what they record, the constants\n  and the classes, must be recorded before it is read), metadata kept.R3,i990,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit11,simple-namem10,R2,TR6,L1,V1,Myn6,binarym2,R11,R12,R3,i999,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit7,throws?m12,R2,TR6,L1,V1,R54,R0,s86,Does node e end in a throw (a form that does not complete, which needs no conversion)?R3,i1002,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit8,ret-bodym12,R2,TR6,L1,V3,R25,R70,Myn3,retm2,R11,R13,R0,s148,A deftype's method body as returned in type ret (ObjMethod.emitBody): unboxed when it can be,\n  else boxed then cast or unboxed as ASM's unbox does.R3,i1011,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit11,method-bodym12,R2,TR6,L1,V3,R25,R79,R80,R0,s147,The body of FnMethod or NewInstanceMethod m (its node), in the method's context: wrapped in\n  a loop over its parameters when a recur targets them.R3,i1037,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,param-symm10,R2,TR6,L1,V1,R53,R3,i1074,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit12,prim-classesR20,R15,R22,R18,R16,R19,R21,R17,m8,R2,TR3,i1080,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,tag-classm12,R2,TR6,L1,V1,R81,R0,s70,The class a field's tag names (Compiler.tagClass): Object without one.R3,i1084,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit9,box-classm10,R2,TR6,L1,V1,Myn1,cm2,R11,R13,R3,i1093,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit16,class-interfacesm12,R2,TR6,L1,V2,R25,R68,R0,s179,The interfaces of a deftype's or reify's class (its node ox), as the analysis made the\n  class: their names. A class of the program cannot implement an interface made at run time.R3,i1097,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,field-modsm12,R2,TR6,L1,V2,R68,R53,R0,s104,The modifiers of a deftype's field lb (ObjExpr.compile): volatile, mutable (package), or\n  public final.R3,i1108,R4,i1,R5,s18,arbace/aot/emit.aem10,R6,L1,V2,R25,R68,R0,s202,Defines deftype ox's class (its node), a top-level class named as the deftype, once:\n  its fields, constructors, getBasis (and create for a record), and methods\n  (NewInstanceExpr.compile, emitStatics).R3,i1118,R4,i1,R5,s18,arbace/aot/emit.aem10,R6,L1,V2,R25,R68,R0,s109,Defines the class of fn or reify ox (its node) once, in the classes being emitted; returns\n  its binary name.R3,i1185,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit11,unit-methodm12,R2,TR6,L1,V3,R25,R82,V7,R83,R84,R85,R86,R86,R87,R88,R0,s96,The static method unitK of a source's loader class: unit u's events made again, then its\n  code.R3,i1272,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit7,unit-nsm12,R2,TR6,L1,V1,V6,R83,R86,R86,R86,R86,R87,R0,s79,The namespace unit u was analyzed in: its fn's (kind 1) or its def's, else nil.R3,i1313,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit11,emit-sourcem10,R6,L1,V6,R89,R90,R91,R92,R93,R94,R0,s260,The class forms of source path src (scriptbase.ae), compiled from its units: the loader\n  class SCRIPTBASE__init's form and the fn classes made, into the atom classes (fn-names: the\n  fns' class names by their FnExpr, an IdentityHashMap shared by the sources).R3,i1324,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit10,class-formm12,R2,TR6,L1,V4,R24,R95,R65,R92,R0,s289,The defclass form of class c (its record: a fn's, a reify's, a deftype's, an interface's, or\n  a holder of nested classes), its nested classes inside; at the top its full name and the\n  constants it shares with them (pools: top → its pool), else a static member class by its\n  simple name.R3,i1352,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit11,class-formsm10,R6,L1,V2,R89,R92,R0,s262,The top-level class forms holding every class of classes (name → record), nested as their\n  binary names nest, with holder classes made for the missing levels (a namespace's fns nest\n  in a holder named as the namespace); pools: the top-level classes' constants.R3,i1385,R4,i1,R5,s18,arbace/aot/emit.aev15,arbace.aot.emit16,interface-recordm10,R6,L1,V3,R96,R97,R98,R0,s133,The record of an interface made by gen-interface (events iface and imethod): name, the\n  interfaces it extends, its abstract methods.R3,i1407,R4,i1,R5,s18,arbace/aot/emit.ae")

var Lit_283 *jrt.String = jrt.Intern("arbace.aot.emit$eval90000004$loading__1927001464__auto____90000005")

var Lit_284 *jrt.String = jrt.Intern("arbace.aot.emit$eval90000008$fn__90000009")

var Lit_285 *jrt.String = jrt.Intern("arbace.aot.emit$node")

var Lit_286 *jrt.String = jrt.Intern("arbace.aot.emit$fail")

var Lit_287 *jrt.String = jrt.Intern("arbace.aot.emit$destub")

var Lit_288 *jrt.String = jrt.Intern("arbace.aot.emit$type_sym")

var Lit_289 *jrt.String = jrt.Intern("arbace.aot.emit$tagged")

var Lit_290 *jrt.String = jrt.Intern("arbace.aot.emit$registered_QMARK_")

var Lit_291 *jrt.String = jrt.Intern("arbace.aot.emit$runtime_class_QMARK_")

var Lit_292 *jrt.String = jrt.Intern("arbace.aot.emit$public_QMARK_")

var Lit_293 *jrt.String = jrt.Intern("arbace.aot.emit$top_name")

var Lit_294 *jrt.String = jrt.Intern("arbace.aot.emit$pool")

var Lit_295 *jrt.String = jrt.Intern("arbace.aot.emit$const_field")

var Lit_296 *jrt.String = jrt.Intern("arbace.aot.emit$emit_list_array")

var Lit_297 *jrt.String = jrt.Intern("arbace.aot.emit$char_form")

var Lit_298 *jrt.String = jrt.Intern("arbace.aot.emit$double_form")

var Lit_299 *jrt.String = jrt.Intern("arbace.aot.emit$emit_value")

var Lit_300 *jrt.String = jrt.Intern("arbace.aot.emit$pool_kind")

var Lit_301 *jrt.String = jrt.Intern("arbace.aot.emit$pool_shared_QMARK_")

var Lit_302 *jrt.String = jrt.Intern("arbace.aot.emit$pool_parts")

var Lit_303 *jrt.String = jrt.Intern("arbace.aot.emit$pool_str")

var Lit_304 *jrt.String = jrt.Intern("arbace.aot.emit$pool_encode")

var Lit_305 *jrt.String = jrt.Intern("arbace.aot.emit$pool_fields")

var Lit_306 *jrt.String = jrt.Intern("arbace.aot.emit$const_type")

var Lit_307 *jrt.String = jrt.Intern("arbace.aot.emit$constant")

var Lit_308 *jrt.String = jrt.Intern("arbace.aot.emit$gsym")

var Lit_309 *jrt.String = jrt.Intern("arbace.aot.emit$local_sym")

var Lit_310 *jrt.String = jrt.Intern("arbace.aot.emit$identity_set")

var Lit_311 *jrt.String = jrt.Intern("arbace.aot.emit$closed_QMARK_")

var Lit_312 *jrt.String = jrt.Intern("arbace.aot.emit$field_sym")

var Lit_313 *jrt.String = jrt.Intern("arbace.aot.emit$field_read")

var Lit_314 *jrt.String = jrt.Intern("arbace.aot.emit$prim")

var Lit_315 *jrt.String = jrt.Intern("arbace.aot.emit$can_prim_QMARK_")

var Lit_316 *jrt.String = jrt.Intern("arbace.aot.emit$box")

var Lit_317 *jrt.String = jrt.Intern("arbace.aot.emit$unbox_arg")

var Lit_318 *jrt.String = jrt.Intern("arbace.aot.emit$fi_QMARK_")

var Lit_319 *jrt.String = jrt.Intern("arbace.aot.emit$typed_args")

var Lit_320 *jrt.String = jrt.Intern("arbace.aot.emit$param_tags")

var Lit_321 *jrt.String = jrt.Intern("arbace.aot.emit$obj_array")

var Lit_322 *jrt.String = jrt.Intern("arbace.aot.emit$var_value")

var Lit_323 *jrt.String = jrt.Intern("arbace.aot.emit$line_meta")

var Lit_324 *jrt.String = jrt.Intern("arbace.aot.emit$emit_local")

var Lit_325 *jrt.String = jrt.Intern("arbace.aot.emit$emit_invoke")

var Lit_326 *jrt.String = jrt.Intern("arbace.aot.emit$descriptor")

var Lit_327 *jrt.String = jrt.Intern("arbace.aot.emit$fn__90000146")

var Lit_328 *jrt.String = jrt.Intern("arbace.aot.emit$jrt_lacks_QMARK_")

var Lit_329 *jrt.String = jrt.Intern("arbace.aot.emit$method_call")

var Lit_330 *jrt.String = jrt.Intern("arbace.aot.emit$compiled_interface_QMARK_")

var Lit_331 *jrt.String = jrt.Intern("arbace.aot.emit$emit_instance_method")

var Lit_332 *jrt.String = jrt.Intern("arbace.aot.emit$emit_static_method")

var Lit_333 *jrt.String = jrt.Intern("arbace.aot.emit$field_ok_QMARK_")

var Lit_334 *jrt.String = jrt.Intern("arbace.aot.emit$emit_instance_field")

var Lit_335 *jrt.String = jrt.Intern("arbace.aot.emit$emit_static_field")

var Lit_336 *jrt.String = jrt.Intern("arbace.aot.emit$emit_new")

var Lit_337 *jrt.String = jrt.Intern("arbace.aot.emit$emit_def")

var Lit_338 *jrt.String = jrt.Intern("arbace.aot.emit$emit_assign")

var Lit_339 *jrt.String = jrt.Intern("arbace.aot.emit$coll_call")

var Lit_340 *jrt.String = jrt.Intern("arbace.aot.emit$emit_if")

var Lit_341 *jrt.String = jrt.Intern("arbace.aot.emit$emit_binding_init")

var Lit_342 *jrt.String = jrt.Intern("arbace.aot.emit$emit_let")

var Lit_343 *jrt.String = jrt.Intern("arbace.aot.emit$emit_recur")

var Lit_344 *jrt.String = jrt.Intern("arbace.aot.emit$body_instance")

var Lit_345 *jrt.String = jrt.Intern("arbace.aot.emit$fn_wrap")

var Lit_346 *jrt.String = jrt.Intern("arbace.aot.emit$fn_instance")

var Lit_347 *jrt.String = jrt.Intern("arbace.aot.emit$emit_letfn")

var Lit_348 *jrt.String = jrt.Intern("arbace.aot.emit$emit_try")

var Lit_349 *jrt.String = jrt.Intern("arbace.aot.emit$emit_case")

var Lit_350 *jrt.String = jrt.Intern("arbace.aot.emit$box_prim")

var Lit_351 *jrt.String = jrt.Intern("arbace.aot.emit$emit")

var Lit_352 *jrt.String = jrt.Intern("arbace.aot.emit$emit_unboxed")

var Lit_353 *jrt.String = jrt.Intern("arbace.aot.emit$deep")

var Lit_354 *jrt.String = jrt.Intern("arbace.aot.emit$simple_name")

var Lit_355 *jrt.String = jrt.Intern("arbace.aot.emit$throws_QMARK_")

var Lit_356 *jrt.String = jrt.Intern("arbace.aot.emit$ret_body")

var Lit_357 *jrt.String = jrt.Intern("arbace.aot.emit$method_body")

var Lit_358 *jrt.String = jrt.Intern("arbace.aot.emit$param_sym")

var Lit_359 *jrt.String = jrt.Intern("arbace.aot.emit$tag_class")

var Lit_360 *jrt.String = jrt.Intern("arbace.aot.emit$box_class")

var Lit_361 *jrt.String = jrt.Intern("arbace.aot.emit$class_interfaces")

var Lit_362 *jrt.String = jrt.Intern("arbace.aot.emit$field_mods")

var Lit_363 *jrt.String = jrt.Intern("arbace.aot.emit$emit_deftype_class_BANG_")

var Lit_364 *jrt.String = jrt.Intern("arbace.aot.emit$emit_fn_class_BANG_")

var Lit_365 *jrt.String = jrt.Intern("arbace.aot.emit$unit_method")

var Lit_366 *jrt.String = jrt.Intern("arbace.aot.emit$unit_ns")

var Lit_367 *jrt.String = jrt.Intern("arbace.aot.emit$emit_source")

var Lit_368 *jrt.String = jrt.Intern("arbace.aot.emit$class_form")

var Lit_369 *jrt.String = jrt.Intern("arbace.aot.emit$class_forms")

var Lit_370 *jrt.String = jrt.Intern("arbace.aot.emit$interface_record")
