//line a2g_strings.ae:1
package aot_arbace_gvec

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("in-ns")

var Lit_2 *jrt.String = jrt.Intern("*warn-on-reflection*")

var Lit_3 *jrt.String = jrt.Intern("arbace.core.VecNode")

var Lit_4 *jrt.String = jrt.Intern("->VecNode")

var Lit_5 *jrt.String = jrt.Intern("arglists")

var Lit_6 *jrt.String = jrt.Intern("edit")

var Lit_7 *jrt.String = jrt.Intern("arr")

var Lit_8 *jrt.String = jrt.Intern("doc")

var Lit_9 *jrt.String = jrt.Intern("Positional factory function for class arbace.core.VecNode.")

var Lit_10 *jrt.String = jrt.Intern("line")

var Lit_11 *jrt.String = jrt.Intern("column")

var Lit_12 *jrt.String = jrt.Intern("file")

var Lit_13 *jrt.String = jrt.Intern("arbace/gvec.ae")

var Lit_14 *jrt.String = jrt.Intern("EMPTY-NODE")

var Lit_15 *jrt.String = jrt.Intern("arbace.core.IVecImpl")

var Lit_16 *jrt.String = jrt.Intern("arbace.core.ArrayManager")

var Lit_17 *jrt.String = jrt.Intern("arbace.core.ArrayChunk")

var Lit_18 *jrt.String = jrt.Intern("->ArrayChunk")

var Lit_19 *jrt.String = jrt.Intern("am")

var Lit_20 *jrt.String = jrt.Intern("off")

var Lit_21 *jrt.String = jrt.Intern("end")

var Lit_22 *jrt.String = jrt.Intern("Positional factory function for class arbace.core.ArrayChunk.")

var Lit_23 *jrt.String = jrt.Intern("arbace.core.VecSeq")

var Lit_24 *jrt.String = jrt.Intern("->VecSeq")

var Lit_25 *jrt.String = jrt.Intern("vec")

var Lit_26 *jrt.String = jrt.Intern("anode")

var Lit_27 *jrt.String = jrt.Intern("i")

var Lit_28 *jrt.String = jrt.Intern("offset")

var Lit_29 *jrt.String = jrt.Intern("_meta")

var Lit_30 *jrt.String = jrt.Intern("Positional factory function for class arbace.core.VecSeq.")

var Lit_31 *jrt.String = jrt.Intern("print-method")

var Lit_32 *jrt.String = jrt.Intern("VecSeq")

var Lit_33 *jrt.String = jrt.Intern("arbace.core.Vec")

var Lit_34 *jrt.String = jrt.Intern("->Vec")

var Lit_35 *jrt.String = jrt.Intern("cnt")

var Lit_36 *jrt.String = jrt.Intern("shift")

var Lit_37 *jrt.String = jrt.Intern("root")

var Lit_38 *jrt.String = jrt.Intern("tail")

var Lit_39 *jrt.String = jrt.Intern("Positional factory function for class arbace.core.Vec.")

var Lit_40 *jrt.String = jrt.Intern("Vec")

var Lit_41 *jrt.String = jrt.Intern("mk-am")

var Lit_42 *jrt.String = jrt.Intern("t")

var Lit_43 *jrt.String = jrt.Intern("private")

var Lit_44 *jrt.String = jrt.Intern("ams")

var Lit_45 *jrt.String = jrt.Intern("int")

var Lit_46 *jrt.String = jrt.Intern("long")

var Lit_47 *jrt.String = jrt.Intern("float")

var Lit_48 *jrt.String = jrt.Intern("double")

var Lit_49 *jrt.String = jrt.Intern("byte")

var Lit_50 *jrt.String = jrt.Intern("short")

var Lit_51 *jrt.String = jrt.Intern("char")

var Lit_52 *jrt.String = jrt.Intern("boolean")

var Lit_53 *jrt.String = jrt.Intern("ams-check")

var Lit_54 *jrt.String = jrt.Intern("vector-of")

var Lit_55 *jrt.String = jrt.Intern("&")

var Lit_56 *jrt.String = jrt.Intern("elements")

var Lit_57 *jrt.String = jrt.Intern("Creates a new vector of a single primitive type t, where t is one\n  of :int :long :float :double :byte :short :char or :boolean. The\n  resulting vector complies with the interface of vectors in general,\n  but stores the values unboxed internally.\n\n  Optionally takes one or more elements to populate the vector.")

var Lit_58 *jrt.String = jrt.Intern("added")

var Lit_59 *jrt.String = jrt.Intern("1.2")

var Lit_60 *jrt.String = jrt.Intern("arbace.lang.Murmur3")

var Lit_61 *jrt.String = jrt.Intern("arbace.lang.IHashEq")

var Lit_62 *jrt.String = jrt.Intern("arbace.lang.Sequential")

var Lit_63 *jrt.String = jrt.Intern("arbace.lang.Util")

var Lit_64 *jrt.String = jrt.Intern("arbace.lang.SeqIterator")

var Lit_65 *jrt.String = jrt.Intern("java.util.List")
