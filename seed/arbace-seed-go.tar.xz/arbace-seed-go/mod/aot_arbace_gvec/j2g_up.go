//line j2g_up.ae:1
package aot_arbace_gvec

import "arbace/lang"


func Up_Compiler_AOTFn_IFn(p *lang.Compiler_AOTFn) lang.IFn { if p == nil { return nil }; return p }
