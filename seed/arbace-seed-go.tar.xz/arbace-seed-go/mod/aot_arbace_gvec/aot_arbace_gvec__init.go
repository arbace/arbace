//line aot_arbace_gvec__init.ae:1
package aot_arbace_gvec

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_gvec__init_A_Load__O() any { A_arbace_gvec__init_A_Init(); A_arbace_gvec__init_A_Unit0__O(); A_arbace_gvec__init_A_Unit1__O(); A_arbace_gvec__init_A_Unit2__O(); A_arbace_gvec__init_A_Unit3__O(); A_arbace_gvec__init_A_Unit4__O(); A_arbace_gvec__init_A_Unit5__O(); A_arbace_gvec__init_A_Unit6__O(); A_arbace_gvec__init_A_Unit7__O(); A_arbace_gvec__init_A_Unit8__O(); A_arbace_gvec__init_A_Unit9__O(); A_arbace_gvec__init_A_Unit10__O(); A_arbace_gvec__init_A_Unit11__O(); A_arbace_gvec__init_A_Unit12__O(); A_arbace_gvec__init_A_Unit13__O(); A_arbace_gvec__init_A_Unit14__O(); A_arbace_gvec__init_A_Unit15__O(); A_arbace_gvec__init_A_Unit16__O(); A_arbace_gvec__init_A_Unit17__O(); A_arbace_gvec__init_A_Unit18__O(); A_arbace_gvec__init_A_Unit19__O(); A_arbace_gvec__init_A_Unit20__O(); A_arbace_gvec__init_A_Unit21__O(); A_arbace_gvec__init_A_Unit22__O(); A_arbace_gvec__init_A_Unit23__O(); A_arbace_gvec__init_A_Unit24__O(); return nil }





func A_arbace_gvec__init_A_Unit0__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(11, 1); return lang.IFn_Cast(jrt.NN(A_arbace_gvec__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_gvec__init_A_const_1) }

func A_arbace_gvec__init_A_Unit1__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_60)); return nil }
//line :13:1
func A_arbace_gvec__init_A_Unit2__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_61)); return nil }
//line :13:1
func A_arbace_gvec__init_A_Unit3__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_62)); return nil }
//line :13:1
func A_arbace_gvec__init_A_Unit4__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_63)); return nil }
//line :13:1
func A_arbace_gvec__init_A_Unit5__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_64)); return nil }
//line :13:1
func A_arbace_gvec__init_A_Unit6__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_65)); return nil }


func A_arbace_gvec__init_A_Unit7__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(16, 1); var tmp1 *lang.Var = A_arbace_gvec__init_A_const_2; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; return jrt.NN(tmp1).Set_O__O(tmp2.Ref()) }

func A_arbace_gvec__init_A_Unit8__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(18, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_3)); var tmp2 *lang.Var = A_arbace_gvec__init_A_const_4; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_gvec__init_A_const_5)); var tmp3 *lang.Var = A_arbace_gvec__init_A_const_4; var tmp4 any = aot_arbace_core.A_arbace_core_eval57000016___GT_VecNode__57000018_A_New(); var tmp5 *jrt.Class; aot_arbace_core.A_arbace_core_eval57000016___GT_VecNode__57000018_A_Init(); tmp5 = aot_arbace_core.A_arbace_core_eval57000016___GT_VecNode__57000018_A_fn_class; jrt.NN(tmp3).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)); return A_arbace_gvec__init_A_const_3.Ref() }

func A_arbace_gvec__init_A_Unit9__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); var tmp1 *lang.Var = A_arbace_gvec__init_A_const_6; jrt.NN(tmp1).BindRoot_O__V(aot_arbace_core.A_arbace_core_VecNode_A_New_O_O(nil, lang.RT_Object_array_O__O1(A_arbace_gvec__init_A_const_7).Ref())); var tmp2 *lang.Var = A_arbace_gvec__init_A_const_6; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_gvec__init_A_const_8)); return A_arbace_gvec__init_A_const_6.Ref() }

func A_arbace_gvec__init_A_Unit10__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(22, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_15)); return nil }







func A_arbace_gvec__init_A_Unit11__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(30, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_16)); return nil }






func A_arbace_gvec__init_A_Unit12__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(37, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_17)); var tmp2 *lang.Var = A_arbace_gvec__init_A_const_12; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_gvec__init_A_const_13)); var tmp3 *lang.Var = A_arbace_gvec__init_A_const_12; var tmp4 any = aot_arbace_core.A_arbace_core_eval57000025___GT_ArrayChunk__57000027_A_New(); var tmp5 *jrt.Class; aot_arbace_core.A_arbace_core_eval57000025___GT_ArrayChunk__57000027_A_Init(); tmp5 = aot_arbace_core.A_arbace_core_eval57000025___GT_ArrayChunk__57000027_A_fn_class; jrt.NN(tmp3).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)); return A_arbace_gvec__init_A_const_11.Ref() }





















func A_arbace_gvec__init_A_Unit13__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(59, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_23)); var tmp2 *lang.Var = A_arbace_gvec__init_A_const_15; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_gvec__init_A_const_16)); var tmp3 *lang.Var = A_arbace_gvec__init_A_const_15; var tmp4 any = aot_arbace_core.A_arbace_core_eval57000030___GT_VecSeq__57000034_A_New(); var tmp5 *jrt.Class; aot_arbace_core.A_arbace_core_eval57000030___GT_VecSeq__57000034_A_Init(); tmp5 = aot_arbace_core.A_arbace_core_eval57000030___GT_VecSeq__57000034_A_fn_class; jrt.NN(tmp3).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)); return A_arbace_gvec__init_A_const_14.Ref() }










































































































func A_arbace_gvec__init_A_Unit14__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(166, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_gvec__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_gvec__init_A_const_18.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval57000037_fn__57000038_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval57000037_fn__57000038_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval57000037_fn__57000038_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_gvec__init_A_Unit15__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(169, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_33)); var tmp2 *lang.Var = A_arbace_gvec__init_A_const_20; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_gvec__init_A_const_21)); var tmp3 *lang.Var = A_arbace_gvec__init_A_const_20; var tmp4 any = aot_arbace_core.A_arbace_core_eval57000043___GT_Vec__57000054_A_New(); var tmp5 *jrt.Class; aot_arbace_core.A_arbace_core_eval57000043___GT_Vec__57000054_A_Init(); tmp5 = aot_arbace_core.A_arbace_core_eval57000043___GT_Vec__57000054_A_fn_class; jrt.NN(tmp3).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)); return A_arbace_gvec__init_A_const_19.Ref() }



































































































































































































































































































































func A_arbace_gvec__init_A_Unit16__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(493, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_gvec__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_gvec__init_A_const_22.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval57000057_fn__57000058_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval57000057_fn__57000058_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval57000057_fn__57000058_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_gvec__init_A_Unit17__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(496, 1); var tmp1 *lang.Var = A_arbace_gvec__init_A_const_23; var tmp2 any = aot_arbace_core.A_arbace_core_mk_am_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_mk_am_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_mk_am_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_gvec__init_A_const_23; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_gvec__init_A_const_24)); return A_arbace_gvec__init_A_const_23.Ref() }
//line :496:1
func A_arbace_gvec__init_A_Unit18__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(496, 1); jrt.NN(A_arbace_gvec__init_A_const_23).SetMacro__V(); return nil }
//line :496:1
func A_arbace_gvec__init_A_Unit19__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(496, 1); return A_arbace_gvec__init_A_const_23.Ref() }









func A_arbace_gvec__init_A_Unit20__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(506, 1); var tmp1 *lang.Var = A_arbace_gvec__init_A_const_25; var tmp2 any = A_arbace_gvec__init_A_const_26.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_reify__57000070_A_New_IPersistentMap(nil); var tmp4 any = A_arbace_gvec__init_A_const_27.Ref(); var tmp5 any = aot_arbace_core.A_arbace_core_reify__57000073_A_New_IPersistentMap(nil); var tmp6 any = A_arbace_gvec__init_A_const_28.Ref(); var tmp7 any = aot_arbace_core.A_arbace_core_reify__57000076_A_New_IPersistentMap(nil); var tmp8 any = A_arbace_gvec__init_A_const_29.Ref(); var tmp9 any = aot_arbace_core.A_arbace_core_reify__57000079_A_New_IPersistentMap(nil); var tmp10 any = A_arbace_gvec__init_A_const_30.Ref(); var tmp11 any = aot_arbace_core.A_arbace_core_reify__57000082_A_New_IPersistentMap(nil); var tmp12 any = A_arbace_gvec__init_A_const_31.Ref(); var tmp13 any = aot_arbace_core.A_arbace_core_reify__57000085_A_New_IPersistentMap(nil); var tmp14 any = A_arbace_gvec__init_A_const_32.Ref(); var tmp15 any = aot_arbace_core.A_arbace_core_reify__57000088_A_New_IPersistentMap(nil); var tmp16 any = A_arbace_gvec__init_A_const_33.Ref(); jrt.NN(tmp1).BindRoot_O__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, aot_arbace_core.A_arbace_core_reify__57000091_A_New_IPersistentMap(nil)))); var tmp17 *lang.Var = A_arbace_gvec__init_A_const_25; jrt.NN(tmp17).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_gvec__init_A_const_34)); return A_arbace_gvec__init_A_const_25.Ref() }









func A_arbace_gvec__init_A_Unit21__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(516, 1); var tmp1 *lang.Var = A_arbace_gvec__init_A_const_35; var tmp2 any = aot_arbace_core.A_arbace_core_ams_check_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_ams_check_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_ams_check_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_gvec__init_A_const_35; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_gvec__init_A_const_36)); return A_arbace_gvec__init_A_const_35.Ref() }
//line :516:1
func A_arbace_gvec__init_A_Unit22__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(516, 1); jrt.NN(A_arbace_gvec__init_A_const_35).SetMacro__V(); return nil }
//line :516:1
func A_arbace_gvec__init_A_Unit23__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(516, 1); return A_arbace_gvec__init_A_const_35.Ref() }





func A_arbace_gvec__init_A_Unit24__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(522, 1); var tmp1 *lang.Var = A_arbace_gvec__init_A_const_37; var tmp2 any = aot_arbace_core.A_arbace_core_vector_of_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_vector_of_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_vector_of_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 5)); var tmp4 *lang.Var = A_arbace_gvec__init_A_const_37; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_gvec__init_A_const_38)); return A_arbace_gvec__init_A_const_37.Ref() }



type A_arbace_gvec__init_A struct{ jrt.Object }

var A_arbace_gvec__init_A_const_0 *lang.Var

var A_arbace_gvec__init_A_const_1 any

var A_arbace_gvec__init_A_const_2 *lang.Var

var A_arbace_gvec__init_A_const_3 *jrt.Class

var A_arbace_gvec__init_A_const_4 *lang.Var

var A_arbace_gvec__init_A_const_5 any

var A_arbace_gvec__init_A_const_6 *lang.Var

var A_arbace_gvec__init_A_const_7 any

var A_arbace_gvec__init_A_const_8 any

var A_arbace_gvec__init_A_const_9 *jrt.Class

var A_arbace_gvec__init_A_const_10 *jrt.Class

var A_arbace_gvec__init_A_const_11 *jrt.Class

var A_arbace_gvec__init_A_const_12 *lang.Var

var A_arbace_gvec__init_A_const_13 any

var A_arbace_gvec__init_A_const_14 *jrt.Class

var A_arbace_gvec__init_A_const_15 *lang.Var

var A_arbace_gvec__init_A_const_16 any

var A_arbace_gvec__init_A_const_17 *lang.Var

var A_arbace_gvec__init_A_const_18 *lang.Keyword

var A_arbace_gvec__init_A_const_19 *jrt.Class

var A_arbace_gvec__init_A_const_20 *lang.Var

var A_arbace_gvec__init_A_const_21 any

var A_arbace_gvec__init_A_const_22 *lang.Keyword

var A_arbace_gvec__init_A_const_23 *lang.Var

var A_arbace_gvec__init_A_const_24 any

var A_arbace_gvec__init_A_const_25 *lang.Var

var A_arbace_gvec__init_A_const_26 *lang.Keyword

var A_arbace_gvec__init_A_const_27 *lang.Keyword

var A_arbace_gvec__init_A_const_28 *lang.Keyword

var A_arbace_gvec__init_A_const_29 *lang.Keyword

var A_arbace_gvec__init_A_const_30 *lang.Keyword

var A_arbace_gvec__init_A_const_31 *lang.Keyword

var A_arbace_gvec__init_A_const_32 *lang.Keyword

var A_arbace_gvec__init_A_const_33 *lang.Keyword

var A_arbace_gvec__init_A_const_34 any

var A_arbace_gvec__init_A_const_35 *lang.Var

var A_arbace_gvec__init_A_const_36 any

var A_arbace_gvec__init_A_const_37 *lang.Var

var A_arbace_gvec__init_A_const_38 any

var A_arbace_gvec__init_A_init jrt.ClassInit

func A_arbace_gvec__init_A_Init() { if !A_arbace_gvec__init_A_init.Done() { A_arbace_gvec__init_A_init.Run(A_arbace_gvec__init_A_clinit) } }

func A_arbace_gvec__init_A_clinit() { A_arbace_gvec__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_gvec__init_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_gvec__init_A_const_2 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_gvec__init_A_const_3 = lang.RT_ClassForNameNonLoading_String__Class(Lit_3); A_arbace_gvec__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_4); A_arbace_gvec__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(18).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_gvec__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_gvec__init_A_const_7 = jrt.Long_ValueOf_J__Long(32).Ref(); A_arbace_gvec__init_A_const_8 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(20).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_gvec__init_A_const_9 = lang.RT_ClassForNameNonLoading_String__Class(Lit_15); A_arbace_gvec__init_A_const_10 = lang.RT_ClassForNameNonLoading_String__Class(Lit_16); A_arbace_gvec__init_A_const_11 = lang.RT_ClassForNameNonLoading_String__Class(Lit_17); A_arbace_gvec__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_gvec__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_20).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_21).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_22, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(37).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_gvec__init_A_const_14 = lang.RT_ClassForNameNonLoading_String__Class(Lit_23); A_arbace_gvec__init_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_gvec__init_A_const_16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_25).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_26).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_27).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_28).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_29).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_30, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(59).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_gvec__init_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_gvec__init_A_const_18 = lang.RT_Keyword_String_String__Keyword(Lit_0, Lit_32); A_arbace_gvec__init_A_const_19 = lang.RT_ClassForNameNonLoading_String__Class(Lit_33); A_arbace_gvec__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_gvec__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_35).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_36).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_29).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_39, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(169).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_gvec__init_A_const_22 = lang.RT_Keyword_String_String__Keyword(Lit_0, Lit_40); A_arbace_gvec__init_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_41); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(); var tmp2 any = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_42).Ref())))); var tmp3 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_43).Ref(); var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_TRUE; var tmp5 any = tmp4.Ref(); A_arbace_gvec__init_A_const_24 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp5, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(496).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_gvec__init_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_44); A_arbace_gvec__init_A_const_26 = lang.RT_Keyword_String_String__Keyword(nil, Lit_45); A_arbace_gvec__init_A_const_27 = lang.RT_Keyword_String_String__Keyword(nil, Lit_46); A_arbace_gvec__init_A_const_28 = lang.RT_Keyword_String_String__Keyword(nil, Lit_47); A_arbace_gvec__init_A_const_29 = lang.RT_Keyword_String_String__Keyword(nil, Lit_48); A_arbace_gvec__init_A_const_30 = lang.RT_Keyword_String_String__Keyword(nil, Lit_49); A_arbace_gvec__init_A_const_31 = lang.RT_Keyword_String_String__Keyword(nil, Lit_50); A_arbace_gvec__init_A_const_32 = lang.RT_Keyword_String_String__Keyword(nil, Lit_51); A_arbace_gvec__init_A_const_33 = lang.RT_Keyword_String_String__Keyword(nil, Lit_52); var tmp6 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_43).Ref(); var tmp7 *jrt.Boolean; jrt.Boolean_Init(); tmp7 = jrt.Boolean_TRUE; var tmp8 any = tmp7.Ref(); A_arbace_gvec__init_A_const_34 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(506).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_gvec__init_A_const_35 = lang.RT_Var_String_String__Var(Lit_0, Lit_53); var tmp9 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_43).Ref(); var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_TRUE; var tmp11 any = tmp10.Ref(); A_arbace_gvec__init_A_const_36 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp11, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_42).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(516).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_gvec__init_A_const_37 = lang.RT_Var_String_String__Var(Lit_0, Lit_54); A_arbace_gvec__init_A_const_38 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_42).Ref()), lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_42).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_55).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_56).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(530).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(15).Ref()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_57, lang.RT_Keyword_String_String__Keyword(nil, Lit_58).Ref(), Lit_59, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(522).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)) }

func A_arbace_gvec__init_A_New() *A_arbace_gvec__init_A { A_arbace_gvec__init_A_Init(); t := &A_arbace_gvec__init_A{}; t.Ctor(); return t }

func (t *A_arbace_gvec__init_A) Ctor() {}

func (t *A_arbace_gvec__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_gvec__init_A) GetClass__Class() *jrt.Class { return A_arbace_gvec__init_A_class }

func (t *A_arbace_gvec__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_gvec__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_gvec__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_gvec__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_gvec__init_A); return ok }

func A_arbace_gvec__init_A_Cast(x any) *A_arbace_gvec__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_gvec__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_gvec__init_A_class)) }; return v }
