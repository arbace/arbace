//line aot_arbace_gvec__init.ae:1
package aot_arbace_gvec

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_gvec__init_A_Load__O() any { A_arbace_gvec__init_A_Init(); A_arbace_gvec__init_A_Unit0__O(); A_arbace_gvec__init_A_Unit1__O(); A_arbace_gvec__init_A_Unit2__O(); A_arbace_gvec__init_A_Unit3__O(); A_arbace_gvec__init_A_Unit4__O(); A_arbace_gvec__init_A_Unit5__O(); A_arbace_gvec__init_A_Unit6__O(); A_arbace_gvec__init_A_Unit7__O(); A_arbace_gvec__init_A_Unit8__O(); A_arbace_gvec__init_A_Unit9__O(); A_arbace_gvec__init_A_Unit10__O(); A_arbace_gvec__init_A_Unit11__O(); A_arbace_gvec__init_A_Unit12__O(); A_arbace_gvec__init_A_Unit13__O(); A_arbace_gvec__init_A_Unit14__O(); A_arbace_gvec__init_A_Unit15__O(); A_arbace_gvec__init_A_Unit16__O(); A_arbace_gvec__init_A_Unit17__O(); A_arbace_gvec__init_A_Unit18__O(); A_arbace_gvec__init_A_Unit19__O(); A_arbace_gvec__init_A_Unit20__O(); A_arbace_gvec__init_A_Unit21__O(); A_arbace_gvec__init_A_Unit22__O(); A_arbace_gvec__init_A_Unit23__O(); A_arbace_gvec__init_A_Unit24__O(); return nil }





func A_arbace_gvec__init_A_Unit0__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(11, 1); return lang.IFn_Cast(A_arbace_gvec__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_gvec__init_A_const_1) }

func A_arbace_gvec__init_A_Unit1__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_1)); return nil }
//line :13:1
func A_arbace_gvec__init_A_Unit2__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_2)); return nil }
//line :13:1
func A_arbace_gvec__init_A_Unit3__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_3)); return nil }
//line :13:1
func A_arbace_gvec__init_A_Unit4__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_4)); return nil }
//line :13:1
func A_arbace_gvec__init_A_Unit5__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_5)); return nil }
//line :13:1
func A_arbace_gvec__init_A_Unit6__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_6)); return nil }


func A_arbace_gvec__init_A_Unit7__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(16, 1); var tmp1 *lang.Var = A_arbace_gvec__init_A_const_2; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; return tmp1.Set_O__O(tmp2.Ref()) }

func A_arbace_gvec__init_A_Unit8__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(18, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_7)); var tmp2 *lang.Var = A_arbace_gvec__init_A_const_4; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_gvec__init_A_const_5)); var tmp3 *lang.Var = A_arbace_gvec__init_A_const_4; var tmp4 any = aot_arbace_core.A_arbace_core_eval57000016___GT_VecNode__57000018_A_New(); var tmp5 *jrt.Class; var fncls__1 *jrt.Class = aot_arbace_core.A_arbace_core_eval57000016___GT_VecNode__57000018_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_8, false); aot_arbace_core.A_arbace_core_eval57000016___GT_VecNode__57000018_A_fn_class = fncls__1d; tmp5 = fncls__1d } else { tmp5 = fncls__1 }; tmp3.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)); return A_arbace_gvec__init_A_const_3 }

func A_arbace_gvec__init_A_Unit9__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); var tmp1 *lang.Var = A_arbace_gvec__init_A_const_6; tmp1.BindRoot_O__V(aot_arbace_core.A_arbace_core_VecNode_A_New_O_O(nil, lang.RT_Object_array_O__O1(A_arbace_gvec__init_A_const_7).Ref())); var tmp2 *lang.Var = A_arbace_gvec__init_A_const_6; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_gvec__init_A_const_8)); return A_arbace_gvec__init_A_const_6 }

func A_arbace_gvec__init_A_Unit10__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(22, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_9)); return nil }







func A_arbace_gvec__init_A_Unit11__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(30, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_10)); return nil }






func A_arbace_gvec__init_A_Unit12__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(37, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_11)); var tmp2 *lang.Var = A_arbace_gvec__init_A_const_12; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_gvec__init_A_const_13)); var tmp3 *lang.Var = A_arbace_gvec__init_A_const_12; var tmp4 any = aot_arbace_core.A_arbace_core_eval57000025___GT_ArrayChunk__57000027_A_New(); var tmp5 *jrt.Class; var fncls__2 *jrt.Class = aot_arbace_core.A_arbace_core_eval57000025___GT_ArrayChunk__57000027_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_12, false); aot_arbace_core.A_arbace_core_eval57000025___GT_ArrayChunk__57000027_A_fn_class = fncls__2d; tmp5 = fncls__2d } else { tmp5 = fncls__2 }; tmp3.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)); return A_arbace_gvec__init_A_const_11 }





















func A_arbace_gvec__init_A_Unit13__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(59, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_13)); var tmp2 *lang.Var = A_arbace_gvec__init_A_const_15; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_gvec__init_A_const_16)); var tmp3 *lang.Var = A_arbace_gvec__init_A_const_15; var tmp4 any = aot_arbace_core.A_arbace_core_eval57000030___GT_VecSeq__57000034_A_New(); var tmp5 *jrt.Class; var fncls__3 *jrt.Class = aot_arbace_core.A_arbace_core_eval57000030___GT_VecSeq__57000034_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_14, false); aot_arbace_core.A_arbace_core_eval57000030___GT_VecSeq__57000034_A_fn_class = fncls__3d; tmp5 = fncls__3d } else { tmp5 = fncls__3 }; tmp3.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)); return A_arbace_gvec__init_A_const_14 }










































































































func A_arbace_gvec__init_A_Unit14__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(166, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_gvec__init_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_gvec__init_A_const_18; var tmp3 any = aot_arbace_core.A_arbace_core_eval57000037_fn__57000038_A_New(); var tmp4 *jrt.Class; var fncls__4 *jrt.Class = aot_arbace_core.A_arbace_core_eval57000037_fn__57000038_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_15, false); aot_arbace_core.A_arbace_core_eval57000037_fn__57000038_A_fn_class = fncls__4d; tmp4 = fncls__4d } else { tmp4 = fncls__4 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_gvec__init_A_Unit15__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(169, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_16)); var tmp2 *lang.Var = A_arbace_gvec__init_A_const_20; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_gvec__init_A_const_21)); var tmp3 *lang.Var = A_arbace_gvec__init_A_const_20; var tmp4 any = aot_arbace_core.A_arbace_core_eval57000043___GT_Vec__57000054_A_New(); var tmp5 *jrt.Class; var fncls__5 *jrt.Class = aot_arbace_core.A_arbace_core_eval57000043___GT_Vec__57000054_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_17, false); aot_arbace_core.A_arbace_core_eval57000043___GT_Vec__57000054_A_fn_class = fncls__5d; tmp5 = fncls__5d } else { tmp5 = fncls__5 }; tmp3.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)); return A_arbace_gvec__init_A_const_19 }



































































































































































































































































































































func A_arbace_gvec__init_A_Unit16__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(493, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_gvec__init_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_gvec__init_A_const_22; var tmp3 any = aot_arbace_core.A_arbace_core_eval57000057_fn__57000058_A_New(); var tmp4 *jrt.Class; var fncls__6 *jrt.Class = aot_arbace_core.A_arbace_core_eval57000057_fn__57000058_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); aot_arbace_core.A_arbace_core_eval57000057_fn__57000058_A_fn_class = fncls__6d; tmp4 = fncls__6d } else { tmp4 = fncls__6 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_gvec__init_A_Unit17__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(496, 1); var tmp1 *lang.Var = A_arbace_gvec__init_A_const_23; var tmp2 any = aot_arbace_core.A_arbace_core_mk_am_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = aot_arbace_core.A_arbace_core_mk_am_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_19, false); aot_arbace_core.A_arbace_core_mk_am_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_gvec__init_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_gvec__init_A_const_24)); return A_arbace_gvec__init_A_const_23 }
//line :496:1
func A_arbace_gvec__init_A_Unit18__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(496, 1); A_arbace_gvec__init_A_const_23.SetMacro__V(); return nil }
//line :496:1
func A_arbace_gvec__init_A_Unit19__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(496, 1); return A_arbace_gvec__init_A_const_23 }









func A_arbace_gvec__init_A_Unit20__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(506, 1); var tmp1 *lang.Var = A_arbace_gvec__init_A_const_25; var tmp2 any = A_arbace_gvec__init_A_const_26; var tmp3 any = aot_arbace_core.A_arbace_core_reify__57000070_A_New_IPersistentMap(nil); var tmp4 any = A_arbace_gvec__init_A_const_27; var tmp5 any = aot_arbace_core.A_arbace_core_reify__57000073_A_New_IPersistentMap(nil); var tmp6 any = A_arbace_gvec__init_A_const_28; var tmp7 any = aot_arbace_core.A_arbace_core_reify__57000076_A_New_IPersistentMap(nil); var tmp8 any = A_arbace_gvec__init_A_const_29; var tmp9 any = aot_arbace_core.A_arbace_core_reify__57000079_A_New_IPersistentMap(nil); var tmp10 any = A_arbace_gvec__init_A_const_30; var tmp11 any = aot_arbace_core.A_arbace_core_reify__57000082_A_New_IPersistentMap(nil); var tmp12 any = A_arbace_gvec__init_A_const_31; var tmp13 any = aot_arbace_core.A_arbace_core_reify__57000085_A_New_IPersistentMap(nil); var tmp14 any = A_arbace_gvec__init_A_const_32; var tmp15 any = aot_arbace_core.A_arbace_core_reify__57000088_A_New_IPersistentMap(nil); var tmp16 any = A_arbace_gvec__init_A_const_33; tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, aot_arbace_core.A_arbace_core_reify__57000091_A_New_IPersistentMap(nil)))); var tmp17 *lang.Var = A_arbace_gvec__init_A_const_25; tmp17.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_gvec__init_A_const_34)); return A_arbace_gvec__init_A_const_25 }









func A_arbace_gvec__init_A_Unit21__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(516, 1); var tmp1 *lang.Var = A_arbace_gvec__init_A_const_35; var tmp2 any = aot_arbace_core.A_arbace_core_ams_check_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = aot_arbace_core.A_arbace_core_ams_check_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_20, false); aot_arbace_core.A_arbace_core_ams_check_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_gvec__init_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_gvec__init_A_const_36)); return A_arbace_gvec__init_A_const_35 }
//line :516:1
func A_arbace_gvec__init_A_Unit22__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(516, 1); A_arbace_gvec__init_A_const_35.SetMacro__V(); return nil }
//line :516:1
func A_arbace_gvec__init_A_Unit23__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(516, 1); return A_arbace_gvec__init_A_const_35 }





func A_arbace_gvec__init_A_Unit24__O() any { A_arbace_gvec__init_A_Init(); lang.Compiler_AOT_At_I_I__V(522, 1); var tmp1 *lang.Var = A_arbace_gvec__init_A_const_37; var tmp2 any = aot_arbace_core.A_arbace_core_vector_of_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = aot_arbace_core.A_arbace_core_vector_of_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_21, true); aot_arbace_core.A_arbace_core_vector_of_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 5)); var tmp4 *lang.Var = A_arbace_gvec__init_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_gvec__init_A_const_38)); return A_arbace_gvec__init_A_const_37 }



type A_arbace_gvec__init_A struct{ jrt.Object }

var A_arbace_gvec__init_A_const_pool *jrt.RefArray

var A_arbace_gvec__init_A_const_0 *lang.Var

var A_arbace_gvec__init_A_const_1 any

var A_arbace_gvec__init_A_const_2 *lang.Var

var A_arbace_gvec__init_A_const_3 *jrt.Class

var A_arbace_gvec__init_A_const_4 *lang.Var

var A_arbace_gvec__init_A_const_5 any

var A_arbace_gvec__init_A_const_6 *lang.Var

var A_arbace_gvec__init_A_const_7 any

var A_arbace_gvec__init_A_const_8 any

var A_arbace_gvec__init_A_const_9 *jrt.Class

var A_arbace_gvec__init_A_const_10 *jrt.Class

var A_arbace_gvec__init_A_const_11 *jrt.Class

var A_arbace_gvec__init_A_const_12 *lang.Var

var A_arbace_gvec__init_A_const_13 any

var A_arbace_gvec__init_A_const_14 *jrt.Class

var A_arbace_gvec__init_A_const_15 *lang.Var

var A_arbace_gvec__init_A_const_16 any

var A_arbace_gvec__init_A_const_17 *lang.Var

var A_arbace_gvec__init_A_const_18 *lang.Keyword

var A_arbace_gvec__init_A_const_19 *jrt.Class

var A_arbace_gvec__init_A_const_20 *lang.Var

var A_arbace_gvec__init_A_const_21 any

var A_arbace_gvec__init_A_const_22 *lang.Keyword

var A_arbace_gvec__init_A_const_23 *lang.Var

var A_arbace_gvec__init_A_const_24 any

var A_arbace_gvec__init_A_const_25 *lang.Var

var A_arbace_gvec__init_A_const_26 *lang.Keyword

var A_arbace_gvec__init_A_const_27 *lang.Keyword

var A_arbace_gvec__init_A_const_28 *lang.Keyword

var A_arbace_gvec__init_A_const_29 *lang.Keyword

var A_arbace_gvec__init_A_const_30 *lang.Keyword

var A_arbace_gvec__init_A_const_31 *lang.Keyword

var A_arbace_gvec__init_A_const_32 *lang.Keyword

var A_arbace_gvec__init_A_const_33 *lang.Keyword

var A_arbace_gvec__init_A_const_34 any

var A_arbace_gvec__init_A_const_35 *lang.Var

var A_arbace_gvec__init_A_const_36 any

var A_arbace_gvec__init_A_const_37 *lang.Var

var A_arbace_gvec__init_A_const_38 any

var A_arbace_gvec__init_A_init jrt.ClassInit

func A_arbace_gvec__init_A_Init() { if !A_arbace_gvec__init_A_init.Done() { A_arbace_gvec__init_A_init.Run(A_arbace_gvec__init_A_clinit) } }

func A_arbace_gvec__init_A_clinit() { A_arbace_gvec__init_A_clinit_p0(); A_arbace_gvec__init_A_clinit_p1(); A_arbace_gvec__init_A_clinit_p2(); A_arbace_gvec__init_A_clinit_p3() }

func A_arbace_gvec__init_A_clinit_p0() { A_arbace_gvec__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 74); A_arbace_gvec__init_A_const_0 = lang.Var_Cast(A_arbace_gvec__init_A_const_pool.A[35]); A_arbace_gvec__init_A_const_1 = A_arbace_gvec__init_A_const_pool.A[36]; A_arbace_gvec__init_A_const_2 = lang.Var_Cast(A_arbace_gvec__init_A_const_pool.A[37]); A_arbace_gvec__init_A_const_3 = jrt.Class_Cast(A_arbace_gvec__init_A_const_pool.A[38]); A_arbace_gvec__init_A_const_4 = lang.Var_Cast(A_arbace_gvec__init_A_const_pool.A[39]); A_arbace_gvec__init_A_const_5 = A_arbace_gvec__init_A_const_pool.A[40]; A_arbace_gvec__init_A_const_6 = lang.Var_Cast(A_arbace_gvec__init_A_const_pool.A[41]); A_arbace_gvec__init_A_const_7 = A_arbace_gvec__init_A_const_pool.A[42]; A_arbace_gvec__init_A_const_8 = A_arbace_gvec__init_A_const_pool.A[43]; A_arbace_gvec__init_A_const_9 = jrt.Class_Cast(A_arbace_gvec__init_A_const_pool.A[44]); A_arbace_gvec__init_A_const_10 = jrt.Class_Cast(A_arbace_gvec__init_A_const_pool.A[45]); A_arbace_gvec__init_A_const_11 = jrt.Class_Cast(A_arbace_gvec__init_A_const_pool.A[46]) }

func A_arbace_gvec__init_A_clinit_p1() { A_arbace_gvec__init_A_const_12 = lang.Var_Cast(A_arbace_gvec__init_A_const_pool.A[47]); A_arbace_gvec__init_A_const_13 = A_arbace_gvec__init_A_const_pool.A[48]; A_arbace_gvec__init_A_const_14 = jrt.Class_Cast(A_arbace_gvec__init_A_const_pool.A[49]); A_arbace_gvec__init_A_const_15 = lang.Var_Cast(A_arbace_gvec__init_A_const_pool.A[50]); A_arbace_gvec__init_A_const_16 = A_arbace_gvec__init_A_const_pool.A[51]; A_arbace_gvec__init_A_const_17 = lang.Var_Cast(A_arbace_gvec__init_A_const_pool.A[52]); A_arbace_gvec__init_A_const_18 = lang.Keyword_Cast(A_arbace_gvec__init_A_const_pool.A[53]); A_arbace_gvec__init_A_const_19 = jrt.Class_Cast(A_arbace_gvec__init_A_const_pool.A[54]); A_arbace_gvec__init_A_const_20 = lang.Var_Cast(A_arbace_gvec__init_A_const_pool.A[55]); A_arbace_gvec__init_A_const_21 = A_arbace_gvec__init_A_const_pool.A[56]; A_arbace_gvec__init_A_const_22 = lang.Keyword_Cast(A_arbace_gvec__init_A_const_pool.A[57]); A_arbace_gvec__init_A_const_23 = lang.Var_Cast(A_arbace_gvec__init_A_const_pool.A[58]); A_arbace_gvec__init_A_const_24 = A_arbace_gvec__init_A_const_pool.A[59] }

func A_arbace_gvec__init_A_clinit_p2() { A_arbace_gvec__init_A_const_25 = lang.Var_Cast(A_arbace_gvec__init_A_const_pool.A[60]); A_arbace_gvec__init_A_const_26 = lang.Keyword_Cast(A_arbace_gvec__init_A_const_pool.A[61]); A_arbace_gvec__init_A_const_27 = lang.Keyword_Cast(A_arbace_gvec__init_A_const_pool.A[62]); A_arbace_gvec__init_A_const_28 = lang.Keyword_Cast(A_arbace_gvec__init_A_const_pool.A[63]); A_arbace_gvec__init_A_const_29 = lang.Keyword_Cast(A_arbace_gvec__init_A_const_pool.A[64]); A_arbace_gvec__init_A_const_30 = lang.Keyword_Cast(A_arbace_gvec__init_A_const_pool.A[65]); A_arbace_gvec__init_A_const_31 = lang.Keyword_Cast(A_arbace_gvec__init_A_const_pool.A[66]); A_arbace_gvec__init_A_const_32 = lang.Keyword_Cast(A_arbace_gvec__init_A_const_pool.A[67]); A_arbace_gvec__init_A_const_33 = lang.Keyword_Cast(A_arbace_gvec__init_A_const_pool.A[68]); A_arbace_gvec__init_A_const_34 = A_arbace_gvec__init_A_const_pool.A[69]; A_arbace_gvec__init_A_const_35 = lang.Var_Cast(A_arbace_gvec__init_A_const_pool.A[70]); A_arbace_gvec__init_A_const_36 = A_arbace_gvec__init_A_const_pool.A[71] }

func A_arbace_gvec__init_A_clinit_p3() { A_arbace_gvec__init_A_const_37 = lang.Var_Cast(A_arbace_gvec__init_A_const_pool.A[72]); A_arbace_gvec__init_A_const_38 = A_arbace_gvec__init_A_const_pool.A[73] }

func A_arbace_gvec__init_A_New() *A_arbace_gvec__init_A { A_arbace_gvec__init_A_Init(); t := &A_arbace_gvec__init_A{}; t.Ctor(); return t }

func (t *A_arbace_gvec__init_A) Ctor() {}

func (t *A_arbace_gvec__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_gvec__init_A) GetClass__Class() *jrt.Class { return A_arbace_gvec__init_A_class }

func (t *A_arbace_gvec__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_gvec__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_gvec__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_gvec__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_gvec__init_A); return ok }

func A_arbace_gvec__init_A_Cast(x any) *A_arbace_gvec__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_gvec__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_gvec__init_A_class)) }; return v }
