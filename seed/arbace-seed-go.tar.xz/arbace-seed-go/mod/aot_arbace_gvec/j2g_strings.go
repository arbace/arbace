//line j2g_strings.ae:1
package aot_arbace_gvec

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn8,arglistsyn4,edityn3,arrkn3,dockn4,linekn6,columnkn4,fileyn2,amyn3,offyn3,endyn3,vecyn5,anodeyn1,iyn6,offsetyn5,_metaks11,arbace.core6,VecSeqyn3,cntyn5,shiftyn4,rootyn4,tailks11,arbace.core3,Vecyn1,tkn7,privatekn3,intkn4,longkn5,floatkn6,doublekn4,bytekn5,shortkn4,charkn7,booleanyn1,&yn8,elementskn5,addedv11,arbace.core5,in-nsR0,v11,arbace.core20,*warn-on-reflection*C19,arbace.core.VecNodev11,arbace.core9,->VecNodem10,R1,L1,V2,R2,R3,R4,s58,Positional factory function for class arbace.core.VecNode.R5,i18,R6,i1,R7,s14,arbace/gvec.aev11,arbace.core10,EMPTY-NODEl32,m6,R5,i20,R6,i1,R7,s14,arbace/gvec.aeC20,arbace.core.IVecImplC24,arbace.core.ArrayManagerC22,arbace.core.ArrayChunkv11,arbace.core12,->ArrayChunkm10,R1,L1,V4,R8,R3,R9,R10,R4,s61,Positional factory function for class arbace.core.ArrayChunk.R5,i37,R6,i1,R7,s14,arbace/gvec.aeC18,arbace.core.VecSeqv11,arbace.core8,->VecSeqm10,R1,L1,V6,R8,R11,R12,R13,R14,R15,R4,s57,Positional factory function for class arbace.core.VecSeq.R5,i59,R6,i1,R7,s14,arbace/gvec.aev11,arbace.core12,print-methodR16,C15,arbace.core.Vecv11,arbace.core5,->Vecm10,R1,L1,V6,R8,R17,R18,R19,R20,R15,R4,s54,Positional factory function for class arbace.core.Vec.R5,i169,R6,i1,R7,s14,arbace/gvec.aeR21,v11,arbace.core5,mk-amm10,R1,L1,V1,R22,R23,TR5,i496,R6,i1,R7,s14,arbace/gvec.aev11,arbace.core3,amsR24,R25,R26,R27,R28,R29,R30,R31,m8,R23,TR5,i506,R6,i1,R7,s14,arbace/gvec.aev11,arbace.core9,ams-checkm10,R23,TR1,L1,V1,R22,R5,i516,R6,i1,R7,s14,arbace/gvec.aev11,arbace.core9,vector-ofm12,R1,ML2,V1,R22,V3,R22,R32,R33,m4,R5,i530,R6,i15,R4,s311,Creates a new vector of a single primitive type t, where t is one\n  of :int :long :float :double :byte :short :char or :boolean. The\n  resulting vector complies with the interface of vectors in general,\n  but stores the values unboxed internally.\n\n  Optionally takes one or more elements to populate the vector.R34,s3,1.2R5,i522,R6,i1,R7,s14,arbace/gvec.ae")

var Lit_1 *jrt.String = jrt.Intern("arbace.lang.Murmur3")

var Lit_2 *jrt.String = jrt.Intern("arbace.lang.IHashEq")

var Lit_3 *jrt.String = jrt.Intern("arbace.lang.Sequential")

var Lit_4 *jrt.String = jrt.Intern("arbace.lang.Util")

var Lit_5 *jrt.String = jrt.Intern("arbace.lang.SeqIterator")

var Lit_6 *jrt.String = jrt.Intern("java.util.List")

var Lit_7 *jrt.String = jrt.Intern("arbace.core.VecNode")

var Lit_8 *jrt.String = jrt.Intern("arbace.core$eval57000016$__GT_VecNode__57000018")

var Lit_9 *jrt.String = jrt.Intern("arbace.core.IVecImpl")

var Lit_10 *jrt.String = jrt.Intern("arbace.core.ArrayManager")

var Lit_11 *jrt.String = jrt.Intern("arbace.core.ArrayChunk")

var Lit_12 *jrt.String = jrt.Intern("arbace.core$eval57000025$__GT_ArrayChunk__57000027")

var Lit_13 *jrt.String = jrt.Intern("arbace.core.VecSeq")

var Lit_14 *jrt.String = jrt.Intern("arbace.core$eval57000030$__GT_VecSeq__57000034")

var Lit_15 *jrt.String = jrt.Intern("arbace.core$eval57000037$fn__57000038")

var Lit_16 *jrt.String = jrt.Intern("arbace.core.Vec")

var Lit_17 *jrt.String = jrt.Intern("arbace.core$eval57000043$__GT_Vec__57000054")

var Lit_18 *jrt.String = jrt.Intern("arbace.core$eval57000057$fn__57000058")

var Lit_19 *jrt.String = jrt.Intern("arbace.core$mk_am")

var Lit_20 *jrt.String = jrt.Intern("arbace.core$ams_check")

var Lit_21 *jrt.String = jrt.Intern("arbace.core$vector_of")
