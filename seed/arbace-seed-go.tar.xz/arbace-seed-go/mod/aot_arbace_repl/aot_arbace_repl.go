//line aot_arbace_repl.ae:1
package aot_arbace_repl

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_spec_alpha"
	"arbace/jrt"
	"arbace/lang"
)


func A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_New() *A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A{}; t.Ctor(); return t }
//line :11:1
func (t *A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A) Ctor() {}
//line :11:1
func (t *A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repl_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_1); lang.IFn_Cast(A_arbace_repl_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_3); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_5)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_6)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_7)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_8)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_9)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :11:1
func A_arbace_repl_eval1239000008_fn__1239000009_A_New() *A_arbace_repl_eval1239000008_fn__1239000009_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_eval1239000008_fn__1239000009_A{}; t.Ctor(); return t }
//line :11:1
func (t *A_arbace_repl_eval1239000008_fn__1239000009_A) Ctor() {}
//line :11:1
func (t *A_arbace_repl_eval1239000008_fn__1239000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_4.GetRawRoot__O()); var tmp2 any; var root_15 any = A_arbace_repl_A_const_5.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = A_arbace_repl_A_const_6; if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_15, arg_18) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repl_A_const_7.GetRawRoot__O(), A_arbace_repl_A_const_8) }































































func A_arbace_repl_special_doc_A_New() *A_arbace_repl_special_doc_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_special_doc_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_repl_special_doc_A) Ctor() {}
//line :75:1
func (t *A_arbace_repl_special_doc_A) Invoke_O_O__O(self, name_symbol__0 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_9.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_repl_A_const_10.GetRawRoot__O()).Invoke_O__O(name_symbol__0); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp2 = or__1927000174__auto____2 } else { var tmp3 any; var root_27 any = A_arbace_repl_A_const_11.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = name_symbol__0; if linked_28 == nil { tmp3 = ifn_29.Invoke_O__O(arg_30) } else { tmp3 = linked_28.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_27, arg_30) }; tmp2 = lang.RT_Meta_O__IPersistentMap_NoInit(tmp3) }; return tmp1.Invoke_O_O_O_O_O__O(tmp2, A_arbace_repl_A_const_12, name_symbol__0, A_arbace_repl_A_const_13, jrt.Boolean_TRUE.Ref())
}


func A_arbace_repl_namespace_doc_A_New() *A_arbace_repl_namespace_doc_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_namespace_doc_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_repl_namespace_doc_A) Ctor() {}
//line :80:1
func (t *A_arbace_repl_namespace_doc_A) Invoke_O_O__O(self, nspace__0 any) any {
	var root_31 any = A_arbace_repl_A_const_9.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = lang.RT_Meta_O__IPersistentMap_NoInit(nspace__0); var arg_35 any = A_arbace_repl_A_const_12; var arg_36 any; var root_37 any = A_arbace_repl_A_const_14.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_39 lang.IFn; if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = nspace__0; if linked_38 == nil { arg_36 = ifn_39.Invoke_O__O(arg_40) } else { arg_36 = linked_38.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_37, arg_40) }; if linked_32 == nil { return ifn_33.Invoke_O_O_O__O(arg_34, arg_35, arg_36) } else { return linked_32.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_31, arg_34, arg_35, arg_36)
	} }
func A_arbace_repl_print_doc_A_New() *A_arbace_repl_print_doc_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_print_doc_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_repl_print_doc_A) Ctor() {}
//line :83:1
func (t *A_arbace_repl_print_doc_A) Invoke_O_O__O(self, p__1239000014__0 any) any { { var map__1239000015__2 any = p__1239000014__0; var map__1239000015__3 any; if lang.ISeq_InstanceOf(map__1239000015__2) { var tmp1 any; var root_41 any = A_arbace_repl_A_const_15.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = map__1239000015__2; if linked_42 == nil { tmp1 = ifn_43.Invoke_O__O(arg_44) } else { tmp1 = linked_42.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_41, arg_44) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_45 any = A_arbace_repl_A_const_16.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = map__1239000015__2; if linked_46 == nil { tmp2 = ifn_47.Invoke_O__O(arg_48) } else { tmp2 = linked_46.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_45, arg_48) }; map__1239000015__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_49 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = map__1239000015__2; if linked_50 == nil { tmp3 = ifn_51.Invoke_O__O(arg_52) } else { tmp3 = linked_50.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_49, arg_52) }; if jrt.J2g_Truth(tmp3) { var root_53 any = A_arbace_repl_A_const_18.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = map__1239000015__2; if linked_54 == nil { map__1239000015__3 = ifn_55.Invoke_O__O(arg_56) } else { map__1239000015__3 = linked_54.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_53, arg_56) } } else { map__1239000015__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1239000015__3 = map__1239000015__2 }; var m__4 any = map__1239000015__3; var n__5 any = lang.RT_Get_O_O__O_NoInit(map__1239000015__3, A_arbace_repl_A_const_19); var nm__6 any = lang.RT_Get_O_O__O_NoInit(map__1239000015__3, A_arbace_repl_A_const_12); var forms__7 any = lang.RT_Get_O_O__O_NoInit(map__1239000015__3, A_arbace_repl_A_const_20); var arglists__8 any = lang.RT_Get_O_O__O_NoInit(map__1239000015__3, A_arbace_repl_A_const_21); var special_form__9 any = lang.RT_Get_O_O__O_NoInit(map__1239000015__3, A_arbace_repl_A_const_13); var doc__10 any = lang.RT_Get_O_O__O_NoInit(map__1239000015__3, A_arbace_repl_A_const_22); var url__11 any = lang.RT_Get_O_O__O_NoInit(map__1239000015__3, A_arbace_repl_A_const_23); var macro__12 any = lang.RT_Get_O_O__O_NoInit(map__1239000015__3, A_arbace_repl_A_const_24); var spec__13 any = lang.RT_Get_O_O__O_NoInit(map__1239000015__3, A_arbace_repl_A_const_25)



	lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(Lit_11)
	var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()); var tmp5 any; var or__1927000174__auto____14 any = spec__13; if jrt.J2g_Truth(or__1927000174__auto____14) { tmp5 = or__1927000174__auto____14 } else { var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp7 *jrt.String; if jrt.J2g_Truth(n__5) { var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_12); var tmp9 any; var root_106 any = A_arbace_repl_A_const_14.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = n__5; if linked_107 == nil { tmp9 = ifn_108.Invoke_O__O(arg_109) } else { tmp9 = linked_107.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_106, arg_109) }; tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, tmp9, nil)) } else { tmp7 = nil }; tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7.Ref(), nm__6)).Ref() }; tmp4.Invoke_O__O(tmp5)
	if jrt.J2g_Truth(forms__7) { var seq_1239000017__14 any; var root_110 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_112 lang.IFn
		if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any = forms__7; if linked_111 == nil { seq_1239000017__14 = ifn_112.Invoke_O__O(arg_113) } else { seq_1239000017__14 = linked_111.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_110, arg_113) }
//line :89:1
		var chunk_1239000018__15 any; var count_1239000019__16 int64 = 0; var i_1239000020__17 int64 = 0; L1: for {
			if lang.Numbers_Lt_J_J__Z_NoInit(i_1239000020__17, count_1239000019__16) { var f__18 any = lang.Indexed_Cast(chunk_1239000018__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1239000020__17))
				lang.IFn_Cast(A_arbace_repl_A_const_36.GetRawRoot__O()).Invoke_O__O(Lit_13)
				lang.IFn_Cast(A_arbace_repl_A_const_34.GetRawRoot__O()).Invoke_O__O(f__18)
//line :90:1
				seq_1239000017__14, chunk_1239000018__15, count_1239000019__16, i_1239000020__17 = seq_1239000017__14, chunk_1239000018__15, count_1239000019__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1239000020__17); continue L1 } else { var temp__1927000414__auto____18 any; var root_114 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_116 lang.IFn; if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any = seq_1239000017__14; if linked_115 == nil { temp__1927000414__auto____18 = ifn_116.Invoke_O__O(arg_117) } else { temp__1927000414__auto____18 = linked_115.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_114, arg_117) }; if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_1239000017__19 any = temp__1927000414__auto____18; var tmp10 any; var root_118 any = A_arbace_repl_A_const_31.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_118, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_120 lang.IFn; if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = seq_1239000017__19; if linked_119 == nil { tmp10 = ifn_120.Invoke_O__O(arg_121) } else { tmp10 = linked_119.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_118, arg_121) }; if jrt.J2g_Truth(tmp10) { var c__1927000678__auto____20 any; var root_122 any = A_arbace_repl_A_const_32.GetRawRoot__O(); var linked_123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_122, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_124 lang.IFn; if linked_123 == nil { ifn_124 = lang.IFn_Cast(root_122) } else { ifn_124 = nil }; var arg_125 any = seq_1239000017__19; if linked_123 == nil { c__1927000678__auto____20 = ifn_124.Invoke_O__O(arg_125) } else { c__1927000678__auto____20 = linked_123.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_122, arg_125) }; var tmp11 any; var root_172 any = A_arbace_repl_A_const_37.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = seq_1239000017__19; if linked_173 == nil { tmp11 = ifn_174.Invoke_O__O(arg_175) } else { tmp11 = linked_173.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_172, arg_175) }; seq_1239000017__14, chunk_1239000018__15, count_1239000019__16, i_1239000020__17 = tmp11, c__1927000678__auto____20, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__20 any; var root_126 any = A_arbace_repl_A_const_18.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_128 lang.IFn; if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = seq_1239000017__19; if linked_127 == nil { f__20 = ifn_128.Invoke_O__O(arg_129) } else { f__20 = linked_127.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_126, arg_129) }
					lang.IFn_Cast(A_arbace_repl_A_const_36.GetRawRoot__O()).Invoke_O__O(Lit_13)
					lang.IFn_Cast(A_arbace_repl_A_const_34.GetRawRoot__O()).Invoke_O__O(f__20)
//line :90:1
					var tmp12 any; var root_184 any = A_arbace_repl_A_const_15.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = seq_1239000017__19; if linked_185 == nil { tmp12 = ifn_186.Invoke_O__O(arg_187) } else { tmp12 = linked_185.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_184, arg_187) }; seq_1239000017__14, chunk_1239000018__15, count_1239000019__16, i_1239000020__17 = tmp12, nil, 0, 0; continue L1 } } }
//line :89:1
			break L1
		}
	}

	if jrt.J2g_Truth(arglists__8) {
		lang.IFn_Cast(A_arbace_repl_A_const_34.GetRawRoot__O()).Invoke_O__O(arglists__8) }
	if jrt.J2g_Truth(special_form__9) {

		lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(Lit_14) } else {
//line :95:1
			if jrt.J2g_Truth(macro__12) {



				lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(Lit_15) } else {
//line :95:1
					if jrt.J2g_Truth(spec__13) {





						lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(Lit_16) } } }
	if jrt.J2g_Truth(doc__10) { lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O_O__O(Lit_17, doc__10) }
	if jrt.J2g_Truth(special_form__9) {
		var tmp13 any; var root_151 any = A_arbace_repl_A_const_35.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = m__4; var arg_155 any = A_arbace_repl_A_const_23; if linked_152 == nil { tmp13 = ifn_153.Invoke_O_O__O(arg_154, arg_155) } else { tmp13 = linked_152.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_151, arg_154, arg_155) }; if jrt.J2g_Truth(tmp13) {
			if jrt.J2g_Truth(url__11) {
				lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_18, nil), jrt.RefArrayOf(jrt.Object_class, nil, url__11)).Ref()) } } else {
					lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, nm__6)).Ref()) } }
	if jrt.J2g_Truth(n__5) { var temp__1927000414__auto____14 any; var root_57 any = A_arbace_repl_A_const_26.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_spec_alpha.A_arbace_spec_alpha_get_spec_A_fn_class); var ifn_59 lang.IFn
		if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any; var root_61 any = A_arbace_repl_A_const_27.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any; var root_66 any = A_arbace_repl_A_const_28.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any; var root_70 any = A_arbace_repl_A_const_14.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = n__5; if linked_71 == nil { arg_69 = ifn_72.Invoke_O__O(arg_73) } else { arg_69 = linked_71.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_70, arg_73) }; if linked_67 == nil { arg_64 = ifn_68.Invoke_O__O(arg_69) } else { arg_64 = linked_67.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_66, arg_69) }; var arg_65 any; var root_74 any = A_arbace_repl_A_const_29.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_76 lang.IFn; if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any = nm__6; if linked_75 == nil { arg_65 = ifn_76.Invoke_O__O(arg_77) } else { arg_65 = linked_75.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_74, arg_77) }; if linked_62 == nil { arg_60 = ifn_63.Invoke_O_O__O(arg_64, arg_65) } else { arg_60 = linked_62.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_61, arg_64, arg_65) }; if linked_58 == nil { temp__1927000414__auto____14 = ifn_59.Invoke_O__O(arg_60) } else { temp__1927000414__auto____14 = linked_58.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_get_spec_A).Invoke_O_O__O(root_57, arg_60) }; if jrt.J2g_Truth(temp__1927000414__auto____14) { var fnspec__15 any = temp__1927000414__auto____14
			lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(Lit_16)
//line :109:1
			var seq_1239000021__16 any; var root_78 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_80 lang.IFn

			if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = A_arbace_repl_A_const_30; if linked_79 == nil { seq_1239000021__16 = ifn_80.Invoke_O__O(arg_81) } else { seq_1239000021__16 = linked_79.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_78, arg_81) }
//line :109:1
			var chunk_1239000022__17 any; var count_1239000023__18 int64 = 0; var i_1239000024__19 int64 = 0; L2: for {

				if lang.Numbers_Lt_J_J__Z_NoInit(i_1239000024__19, count_1239000023__18) { var role__20 any = lang.Indexed_Cast(chunk_1239000022__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1239000024__19)); var temp__1927000414__auto____21 any = lang.RT_Get_O_O__O_NoInit(fnspec__15, role__20)
					if jrt.J2g_Truth(temp__1927000414__auto____21) { var spec__22 any = temp__1927000414__auto____21; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()); var tmp15 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_20); var tmp16 any; var root_198 any = A_arbace_repl_A_const_29.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_200 lang.IFn
						if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = role__20; if linked_199 == nil { tmp16 = ifn_200.Invoke_O__O(arg_201) } else { tmp16 = linked_199.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_198, arg_201) }; var tmp17 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp15, jrt.RefArrayOf(jrt.Object_class, tmp16, nil)).Ref(); var tmp18 any; var root_202 any = A_arbace_repl_A_const_38.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_spec_alpha.A_arbace_spec_alpha_describe_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = spec__22; if linked_203 == nil { tmp18 = ifn_204.Invoke_O__O(arg_205) } else { tmp18 = linked_203.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_describe_A).Invoke_O_O__O(root_202, arg_205) }; tmp14.Invoke_O_O_O__O(Lit_17, tmp17, tmp18) }
//line :111:1
					seq_1239000021__16, chunk_1239000022__17, count_1239000023__18, i_1239000024__19 = seq_1239000021__16, chunk_1239000022__17, count_1239000023__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1239000024__19); continue L2 } else { var temp__1927000414__auto____20 any; var root_82 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = seq_1239000021__16; if linked_83 == nil { temp__1927000414__auto____20 = ifn_84.Invoke_O__O(arg_85) } else { temp__1927000414__auto____20 = linked_83.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_82, arg_85) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1239000021__21 any = temp__1927000414__auto____20; var tmp19 any; var root_86 any = A_arbace_repl_A_const_31.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_88 lang.IFn; if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any = seq_1239000021__21; if linked_87 == nil { tmp19 = ifn_88.Invoke_O__O(arg_89) } else { tmp19 = linked_87.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_86, arg_89) }; if jrt.J2g_Truth(tmp19) { var c__1927000678__auto____22 any; var root_90 any = A_arbace_repl_A_const_32.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = seq_1239000021__21; if linked_91 == nil { c__1927000678__auto____22 = ifn_92.Invoke_O__O(arg_93) } else { c__1927000678__auto____22 = linked_91.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_90, arg_93) }; var tmp20 any; var root_206 any = A_arbace_repl_A_const_37.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = seq_1239000021__21; if linked_207 == nil { tmp20 = ifn_208.Invoke_O__O(arg_209) } else { tmp20 = linked_207.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_206, arg_209) }; seq_1239000021__16, chunk_1239000022__17, count_1239000023__18, i_1239000024__19 = tmp20, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var role__22 any; var root_94 any = A_arbace_repl_A_const_18.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = seq_1239000021__21; if linked_95 == nil { role__22 = ifn_96.Invoke_O__O(arg_97) } else { role__22 = linked_95.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_94, arg_97) }; var temp__1927000414__auto____23 any = lang.RT_Get_O_O__O_NoInit(fnspec__15, role__22)
						if jrt.J2g_Truth(temp__1927000414__auto____23) { var spec__24 any = temp__1927000414__auto____23; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()); var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_20); var tmp23 any; var root_216 any = A_arbace_repl_A_const_29.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_218 lang.IFn
							if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = role__22; if linked_217 == nil { tmp23 = ifn_218.Invoke_O__O(arg_219) } else { tmp23 = linked_217.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_216, arg_219) }; var tmp24 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, tmp23, nil)).Ref(); var tmp25 any; var root_220 any = A_arbace_repl_A_const_38.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, aot_arbace_spec_alpha.A_arbace_spec_alpha_describe_A_fn_class); var ifn_222 lang.IFn; if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any = spec__24; if linked_221 == nil { tmp25 = ifn_222.Invoke_O__O(arg_223) } else { tmp25 = linked_221.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_describe_A).Invoke_O_O__O(root_220, arg_223) }; tmp21.Invoke_O_O_O__O(Lit_17, tmp24, tmp25) }
//line :111:1
						var tmp26 any; var root_224 any = A_arbace_repl_A_const_15.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = seq_1239000021__21; if linked_225 == nil { tmp26 = ifn_226.Invoke_O__O(arg_227) } else { tmp26 = linked_225.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_224, arg_227) }; seq_1239000021__16, chunk_1239000022__17, count_1239000023__18, i_1239000024__19 = tmp26, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :109:1
							return nil } } else {
//line :108:1
								return nil } }; /*line :83:1*/panic("j2g: unreachable") }































func A_arbace_repl_find_doc_A_New() *A_arbace_repl_find_doc_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_find_doc_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_repl_find_doc_A) Ctor() {}
//line :115:1
func (t *A_arbace_repl_find_doc_A) Invoke_O_O__O(self, re_string_or_pattern__0 any) any { { var re__2 any; var root_228 any = A_arbace_repl_A_const_39.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_re_pattern_A_fn_class); var ifn_230 lang.IFn




	if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = re_string_or_pattern__0; if linked_229 == nil { re__2 = ifn_230.Invoke_O__O(arg_231) } else { re__2 = linked_229.(*aot_arbace_core.A_arbace_core_re_pattern_A).Invoke_O_O__O(root_228, arg_231) }
//line :115:1
	var ms__3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_41.GetRawRoot__O()); var tmp3 any = A_arbace_repl_find_doc_fn__1239000027_A_New(); var tmp4 *jrt.Class
	var fncls__261 /*line :115:1*/*jrt.Class = A_arbace_repl_find_doc_fn__1239000027_A_fn_class





	if fncls__261 == nil { var fncls__261d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_repl_find_doc_fn__1239000027_A_fn_class = fncls__261d; tmp4 = fncls__261d } else { tmp4 = fncls__261 }; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 any; var root_262 any = A_arbace_repl_A_const_47.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_core.A_arbace_core_all_ns_A_fn_class); var ifn_264 lang.IFn
	if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; if linked_263 == nil { tmp6 = ifn_264.Invoke__O() } else { tmp6 = linked_263.(*aot_arbace_core.A_arbace_core_all_ns_A).Invoke_O__O(root_262) }
//line :121:1
	var tmp7 any = tmp2.Invoke_O_O__O(tmp5, tmp6); var tmp8 any; var root_265 any = A_arbace_repl_A_const_43.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_265, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_267 lang.IFn

	if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = A_arbace_repl_A_const_48.GetRawRoot__O(); var arg_269 any; var root_270 any = A_arbace_repl_A_const_47.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, aot_arbace_core.A_arbace_core_all_ns_A_fn_class); var ifn_272 lang.IFn; if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; if linked_271 == nil { arg_269 = ifn_272.Invoke__O() } else { arg_269 = linked_271.(*aot_arbace_core.A_arbace_core_all_ns_A).Invoke_O__O(root_270) }; if linked_266 == nil { tmp8 = ifn_267.Invoke_O_O__O(arg_268, arg_269) } else { tmp8 = linked_266.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_265, arg_268, arg_269) }
//line :121:1
	var tmp9 any = tmp8; var tmp10 any; var root_273 any = A_arbace_repl_A_const_43.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_275 lang.IFn


	if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = A_arbace_repl_A_const_49.GetRawRoot__O(); var arg_277 any; var root_278 any = A_arbace_repl_A_const_50.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_278, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_280 lang.IFn; if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any = A_arbace_repl_A_const_10.GetRawRoot__O(); if linked_279 == nil { arg_277 = ifn_280.Invoke_O__O(arg_281) } else { arg_277 = linked_279.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_278, arg_281) }; if linked_274 == nil { tmp10 = ifn_275.Invoke_O_O__O(arg_276, arg_277) } else { tmp10 = linked_274.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_273, arg_276, arg_277) }
//line :121:1
	ms__3 = tmp1.Invoke_O_O_O__O(tmp7, tmp9, tmp10)
//line :115:1
	var seq_1239000029__4 any; var root_282 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_284 lang.IFn









	if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = ms__3; if linked_283 == nil { seq_1239000029__4 = ifn_284.Invoke_O__O(arg_285) } else { seq_1239000029__4 = linked_283.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_282, arg_285) }
//line :115:1
	var chunk_1239000030__5 any; var count_1239000031__6 int64 = 0; var i_1239000032__7 int64 = 0; L1: for {









		if lang.Numbers_Lt_J_J__Z_NoInit(i_1239000032__7, count_1239000031__6) { var m__8 any = lang.Indexed_Cast(chunk_1239000030__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1239000032__7)); var tmp11 any; var and__1927000168__auto____9 any = A_arbace_repl_A_const_22.Invoke_O__O(m__8)
			if jrt.J2g_Truth(and__1927000168__auto____9) { var or__1927000174__auto____10 any; var root_286 any = A_arbace_repl_A_const_51.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_288 lang.IFn
				if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any; var root_290 any = A_arbace_repl_A_const_52.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_re_matcher_A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = re__2; var arg_294 any = A_arbace_repl_A_const_22.Invoke_O__O(m__8); if linked_291 == nil { arg_289 = ifn_292.Invoke_O_O__O(arg_293, arg_294) } else { arg_289 = linked_291.(*aot_arbace_core.A_arbace_core_re_matcher_A).Invoke_O_O_O__O(root_290, arg_293, arg_294) }; if linked_287 == nil { or__1927000174__auto____10 = ifn_288.Invoke_O__O(arg_289) } else { or__1927000174__auto____10 = linked_287.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O__O(root_286, arg_289) }; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp11 = or__1927000174__auto____10 } else {
					var root_295 any = A_arbace_repl_A_const_51.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any; var root_299 any = A_arbace_repl_A_const_52.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, aot_arbace_core.A_arbace_core_re_matcher_A_fn_class); var ifn_301 lang.IFn; if linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = re__2; var arg_303 any; var root_304 any = A_arbace_repl_A_const_28.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_304, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_306 lang.IFn; if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = A_arbace_repl_A_const_12.Invoke_O__O(m__8); if linked_305 == nil { arg_303 = ifn_306.Invoke_O__O(arg_307) } else { arg_303 = linked_305.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_304, arg_307) }; if linked_300 == nil { arg_298 = ifn_301.Invoke_O_O__O(arg_302, arg_303) } else { arg_298 = linked_300.(*aot_arbace_core.A_arbace_core_re_matcher_A).Invoke_O_O_O__O(root_299, arg_302, arg_303) }; if linked_296 == nil { tmp11 = ifn_297.Invoke_O__O(arg_298) } else { tmp11 = linked_296.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O__O(root_295, arg_298) } } } else {
//line :126:1
						tmp11 = and__1927000168__auto____9 }
//line :125:1
			if jrt.J2g_Truth(tmp11) {



				var root_346 any = A_arbace_repl_A_const_53.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, A_arbace_repl_print_doc_A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = m__8; if linked_347 == nil { ifn_348.Invoke_O__O(arg_349) } else { linked_347.(*A_arbace_repl_print_doc_A).Invoke_O_O__O(root_346, arg_349) }
//line :125:1
				seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, i_1239000032__7 = seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1239000032__7); continue L1 } else { seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, i_1239000032__7 = seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1239000032__7); continue L1 } } else { var temp__1927000414__auto____8 any; var root_308 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = seq_1239000029__4; if linked_309 == nil { temp__1927000414__auto____8 = ifn_310.Invoke_O__O(arg_311) } else { temp__1927000414__auto____8 = linked_309.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_308, arg_311) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1239000029__9 any = temp__1927000414__auto____8; var tmp12 any; var root_312 any = A_arbace_repl_A_const_31.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = seq_1239000029__9; if linked_313 == nil { tmp12 = ifn_314.Invoke_O__O(arg_315) } else { tmp12 = linked_313.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_312, arg_315) }; if jrt.J2g_Truth(tmp12) { var c__1927000678__auto____10 any; var root_316 any = A_arbace_repl_A_const_32.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = seq_1239000029__9; if linked_317 == nil { c__1927000678__auto____10 = ifn_318.Invoke_O__O(arg_319) } else { c__1927000678__auto____10 = linked_317.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_316, arg_319) }; var tmp13 any; var root_350 any = A_arbace_repl_A_const_37.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = seq_1239000029__9; if linked_351 == nil { tmp13 = ifn_352.Invoke_O__O(arg_353) } else { tmp13 = linked_351.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_350, arg_353) }; seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, i_1239000032__7 = tmp13, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var m__10 any; var root_320 any = A_arbace_repl_A_const_18.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = seq_1239000029__9; if linked_321 == nil { m__10 = ifn_322.Invoke_O__O(arg_323) } else { m__10 = linked_321.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_320, arg_323) }; var tmp14 any; var and__1927000168__auto____11 any = A_arbace_repl_A_const_22.Invoke_O__O(m__10)
					if jrt.J2g_Truth(and__1927000168__auto____11) { var or__1927000174__auto____12 any; var root_324 any = A_arbace_repl_A_const_51.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_326 lang.IFn
						if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any; var root_328 any = A_arbace_repl_A_const_52.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_re_matcher_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = re__2; var arg_332 any = A_arbace_repl_A_const_22.Invoke_O__O(m__10); if linked_329 == nil { arg_327 = ifn_330.Invoke_O_O__O(arg_331, arg_332) } else { arg_327 = linked_329.(*aot_arbace_core.A_arbace_core_re_matcher_A).Invoke_O_O_O__O(root_328, arg_331, arg_332) }; if linked_325 == nil { or__1927000174__auto____12 = ifn_326.Invoke_O__O(arg_327) } else { or__1927000174__auto____12 = linked_325.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O__O(root_324, arg_327) }; if jrt.J2g_Truth(or__1927000174__auto____12) { tmp14 = or__1927000174__auto____12 } else {
							var root_333 any = A_arbace_repl_A_const_51.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any; var root_337 any = A_arbace_repl_A_const_52.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, aot_arbace_core.A_arbace_core_re_matcher_A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = re__2; var arg_341 any; var root_342 any = A_arbace_repl_A_const_28.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = A_arbace_repl_A_const_12.Invoke_O__O(m__10); if linked_343 == nil { arg_341 = ifn_344.Invoke_O__O(arg_345) } else { arg_341 = linked_343.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_342, arg_345) }; if linked_338 == nil { arg_336 = ifn_339.Invoke_O_O__O(arg_340, arg_341) } else { arg_336 = linked_338.(*aot_arbace_core.A_arbace_core_re_matcher_A).Invoke_O_O_O__O(root_337, arg_340, arg_341) }; if linked_334 == nil { tmp14 = ifn_335.Invoke_O__O(arg_336) } else { tmp14 = linked_334.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O__O(root_333, arg_336) } } } else {
//line :126:1
								tmp14 = and__1927000168__auto____11 }
//line :125:1
					if jrt.J2g_Truth(tmp14) {



						var root_354 any = A_arbace_repl_A_const_53.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, A_arbace_repl_print_doc_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = m__10; if linked_355 == nil { ifn_356.Invoke_O__O(arg_357) } else { linked_355.(*A_arbace_repl_print_doc_A).Invoke_O_O__O(root_354, arg_357) }
//line :125:1
						var tmp15 any; var root_358 any = A_arbace_repl_A_const_15.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = seq_1239000029__9; if linked_359 == nil { tmp15 = ifn_360.Invoke_O__O(arg_361) } else { tmp15 = linked_359.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_358, arg_361) }; seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, i_1239000032__7 = tmp15, nil, 0, 0; continue L1 } else { var tmp16 any; var root_362 any = A_arbace_repl_A_const_15.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_364 lang.IFn; if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = seq_1239000029__9; if linked_363 == nil { tmp16 = ifn_364.Invoke_O__O(arg_365) } else { tmp16 = linked_363.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_362, arg_365) }; seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, i_1239000032__7 = tmp16, nil, 0, 0; continue L1 } } } else { return nil } } } }; /*line :115:1*/panic("j2g: unreachable") }





func A_arbace_repl_find_doc_fn__1239000027_A_New() *A_arbace_repl_find_doc_fn__1239000027_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_find_doc_fn__1239000027_A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_repl_find_doc_fn__1239000027_A) Ctor() {}
//line :121:1
func (t *A_arbace_repl_find_doc_fn__1239000027_A) Invoke_O_O__O(self, p1__1239000026_SHARP___1 any) any { var root_243 any = A_arbace_repl_A_const_42.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_243, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_245 lang.IFn; if linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any = A_arbace_repl_A_const_12; var arg_247 any; var root_248 any = A_arbace_repl_A_const_43.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_248, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_250 lang.IFn; if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any = A_arbace_repl_A_const_44.GetRawRoot__O(); var arg_252 any; var root_253 any = A_arbace_repl_A_const_45.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any; var root_257 any = A_arbace_repl_A_const_46.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_core.A_arbace_core_ns_interns_A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = p1__1239000026_SHARP___1; if linked_258 == nil { arg_256 = ifn_259.Invoke_O__O(arg_260) } else { arg_256 = linked_258.(*aot_arbace_core.A_arbace_core_ns_interns_A).Invoke_O_O__O(root_257, arg_260) }; if linked_254 == nil { arg_252 = ifn_255.Invoke_O__O(arg_256) } else { arg_252 = linked_254.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_253, arg_256) }; if linked_249 == nil { arg_247 = ifn_250.Invoke_O_O__O(arg_251, arg_252) } else { arg_247 = linked_249.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_248, arg_251, arg_252) }; if linked_244 == nil { return ifn_245.Invoke_O_O__O(arg_246, arg_247) } else { return linked_244.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_243, arg_246, arg_247) } }









func A_arbace_repl_doc_A_New() *A_arbace_repl_doc_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_doc_A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_repl_doc_A) Ctor() {}
//line :131:1
func (t *A_arbace_repl_doc_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, name__2 any) any { var temp__1927000408__auto____4 any = lang.IFn_Cast(A_arbace_repl_A_const_54).Invoke_O__O(name__2); if




	jrt.J2g_Truth(temp__1927000408__auto____4) { var special_name__5 any = temp__1927000408__auto____4; var root_366 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any; var root_370 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_370, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp2 any; var root_375 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any; var root_379 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_379, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_381 lang.IFn; if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_56); var arg_383 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_57); if linked_380 == nil { arg_378 = ifn_381.Invoke_O_O__O(arg_382, arg_383) } else { arg_378 = linked_380.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_379, arg_382, arg_383) }; if linked_376 == nil { tmp2 = ifn_377.Invoke_O__O(arg_378) } else { tmp2 = linked_376.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_375, arg_378) }; arg_373 = tmp1.Invoke_O__O(tmp2); var arg_374 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp4 any; var root_384 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_386 lang.IFn; if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any; var root_388 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_388, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_390 lang.IFn; if linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp6 any; var root_393 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_393, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_395 lang.IFn; if linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var arg_396 any; var root_397 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_397, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_399 lang.IFn; if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_56); var arg_401 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_58); if linked_398 == nil { arg_396 = ifn_399.Invoke_O_O__O(arg_400, arg_401) } else { arg_396 = linked_398.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_397, arg_400, arg_401) }; if linked_394 == nil { tmp6 = ifn_395.Invoke_O__O(arg_396) } else { tmp6 = linked_394.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_393, arg_396) }; arg_391 = tmp5.Invoke_O__O(tmp6); var arg_392 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp8 any; var root_402 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any; var root_406 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_406, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_408 lang.IFn; if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_59); var arg_410 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(special_name__5); if linked_407 == nil { arg_405 = ifn_408.Invoke_O_O__O(arg_409, arg_410) } else { arg_405 = linked_407.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_406, arg_409, arg_410) }; if linked_403 == nil { tmp8 = ifn_404.Invoke_O__O(arg_405) } else { tmp8 = linked_403.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_402, arg_405) }; arg_392 = tmp7.Invoke_O__O(tmp8); if linked_389 == nil { arg_387 = ifn_390.Invoke_O_O__O(arg_391, arg_392) } else { arg_387 = linked_389.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_388, arg_391, arg_392) }; if linked_385 == nil { tmp4 = ifn_386.Invoke_O__O(arg_387) } else { tmp4 = linked_385.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_384, arg_387) }; arg_374 = tmp3.Invoke_O__O(tmp4); if linked_371 == nil { arg_369 = ifn_372.Invoke_O_O__O(arg_373, arg_374) } else { arg_369 = linked_371.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_370, arg_373, arg_374) }; if linked_367 == nil { return ifn_368.Invoke_O__O(arg_369) } else { return linked_367.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_366, arg_369) } } else {

		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repl_A_const_10.GetRawRoot__O()).Invoke_O__O(name__2)) { var root_411 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_411, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_413 lang.IFn; if linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any; var root_415 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_415, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp10 any; var root_420 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any; var root_424 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_56); var arg_428 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_60); if linked_425 == nil { arg_423 = ifn_426.Invoke_O_O__O(arg_427, arg_428) } else { arg_423 = linked_425.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_424, arg_427, arg_428) }; if linked_421 == nil { tmp10 = ifn_422.Invoke_O__O(arg_423) } else { tmp10 = linked_421.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_420, arg_423) }; arg_418 = tmp9.Invoke_O__O(tmp10); var arg_419 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp12 any; var root_429 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_429, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_431 lang.IFn; if linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any; var root_433 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_433, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_435 lang.IFn; if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp14 any; var root_438 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any; var root_442 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_442, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_444 lang.IFn; if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_56); var arg_446 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_61); if linked_443 == nil { arg_441 = ifn_444.Invoke_O_O__O(arg_445, arg_446) } else { arg_441 = linked_443.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_442, arg_445, arg_446) }; if linked_439 == nil { tmp14 = ifn_440.Invoke_O__O(arg_441) } else { tmp14 = linked_439.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_438, arg_441) }; arg_436 = tmp13.Invoke_O__O(tmp14); var arg_437 any; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp16 any; var root_447 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_447, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_449 lang.IFn; if linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any; var root_451 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_453 lang.IFn; if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_59); var arg_455 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(name__2); if linked_452 == nil { arg_450 = ifn_453.Invoke_O_O__O(arg_454, arg_455) } else { arg_450 = linked_452.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_451, arg_454, arg_455) }; if linked_448 == nil { tmp16 = ifn_449.Invoke_O__O(arg_450) } else { tmp16 = linked_448.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_447, arg_450) }; arg_437 = tmp15.Invoke_O__O(tmp16); if linked_434 == nil { arg_432 = ifn_435.Invoke_O_O__O(arg_436, arg_437) } else { arg_432 = linked_434.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_433, arg_436, arg_437) }; if linked_430 == nil { tmp12 = ifn_431.Invoke_O__O(arg_432) } else { tmp12 = linked_430.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_429, arg_432) }; arg_419 = tmp11.Invoke_O__O(tmp12); if linked_416 == nil { arg_414 = ifn_417.Invoke_O_O__O(arg_418, arg_419) } else { arg_414 = linked_416.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_415, arg_418, arg_419) }; if linked_412 == nil { return ifn_413.Invoke_O__O(arg_414) } else { return linked_412.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_411, arg_414) } } else { var tmp17 any; var root_456 any = A_arbace_repl_A_const_62.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_456, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_458 lang.IFn

			if linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; var arg_459 any = name__2; if linked_457 == nil { tmp17 = ifn_458.Invoke_O__O(arg_459) } else { tmp17 = linked_457.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_456, arg_459) }
//line :138:1
			if jrt.J2g_Truth(tmp17) { var root_460 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_460, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_462 lang.IFn; if linked_461 == nil { ifn_462 = lang.IFn_Cast(root_460) } else { ifn_462 = nil }; var arg_463 any; var root_464 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_464, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_466 lang.IFn; if linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp19 any; var root_469 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any; var root_473 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_474 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_473, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_475 lang.IFn; if linked_474 == nil { ifn_475 = lang.IFn_Cast(root_473) } else { ifn_475 = nil }; var arg_476 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_56); var arg_477 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_63); if linked_474 == nil { arg_472 = ifn_475.Invoke_O_O__O(arg_476, arg_477) } else { arg_472 = linked_474.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_473, arg_476, arg_477) }; if linked_470 == nil { tmp19 = ifn_471.Invoke_O__O(arg_472) } else { tmp19 = linked_470.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_469, arg_472) }; arg_467 = tmp18.Invoke_O__O(tmp19); var arg_468 any; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp21 any; var root_478 any = A_arbace_repl_A_const_64.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_478, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_480 lang.IFn; if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var arg_481 any = A_arbace_repl_A_const_65.GetRawRoot__O(); var arg_482 any; var root_483 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_485 lang.IFn; if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()); var tmp23 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_25); var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp25 any; var root_494 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any; var root_498 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_59); var arg_502 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(name__2); if linked_499 == nil { arg_497 = ifn_500.Invoke_O_O__O(arg_501, arg_502) } else { arg_497 = linked_499.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_498, arg_501, arg_502) }; if linked_495 == nil { tmp25 = ifn_496.Invoke_O__O(arg_497) } else { tmp25 = linked_495.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_494, arg_497) }; var tmp26 any = tmp24.Invoke_O__O(tmp25); var tmp27 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_22); var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp29 any; var root_503 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any; var root_507 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_59); var arg_511 any; var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp31 any; var root_512 any = A_arbace_repl_A_const_38.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_512, aot_arbace_spec_alpha.A_arbace_spec_alpha_describe_A_fn_class); var ifn_514 lang.IFn

				if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any = name__2; if linked_513 == nil { tmp31 = ifn_514.Invoke_O__O(arg_515) } else { tmp31 = linked_513.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_describe_A).Invoke_O_O__O(root_512, arg_515) }
//line :138:1
				arg_511 = tmp30.Invoke_O__O(tmp31); if linked_508 == nil { arg_506 = ifn_509.Invoke_O_O__O(arg_510, arg_511) } else { arg_506 = linked_508.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_507, arg_510, arg_511) }; if linked_504 == nil { tmp29 = ifn_505.Invoke_O__O(arg_506) } else { tmp29 = linked_504.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_503, arg_506) }; arg_486 = tmp22.Invoke_O_O_O_O__O(tmp23, tmp26, tmp27, tmp28.Invoke_O__O(tmp29)); if linked_484 == nil { arg_482 = ifn_485.Invoke_O__O(arg_486) } else { arg_482 = linked_484.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_483, arg_486) }; if linked_479 == nil { tmp21 = ifn_480.Invoke_O_O__O(arg_481, arg_482) } else { tmp21 = linked_479.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_478, arg_481, arg_482) }; arg_468 = tmp20.Invoke_O__O(tmp21); if linked_465 == nil { arg_463 = ifn_466.Invoke_O_O__O(arg_467, arg_468) } else { arg_463 = linked_465.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_464, arg_467, arg_468) }; if linked_461 == nil { return ifn_462.Invoke_O__O(arg_463) } else { return linked_461.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_460, arg_463) } } else { var tmp32 any; var root_516 any = A_arbace_repl_A_const_66.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_516, aot_arbace_core.A_arbace_core_find_ns_A_fn_class); var ifn_518 lang.IFn


					if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any = name__2; if linked_517 == nil { tmp32 = ifn_518.Invoke_O__O(arg_519) } else { tmp32 = linked_517.(*aot_arbace_core.A_arbace_core_find_ns_A).Invoke_O_O__O(root_516, arg_519) }
//line :138:1
					if jrt.J2g_Truth(tmp32) { var root_520 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_520, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_522 lang.IFn; if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any; var root_524 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_524, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_526 lang.IFn; if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any; var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp34 any; var root_529 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any; var root_533 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_533, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_535 lang.IFn; if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_56); var arg_537 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_67); if linked_534 == nil { arg_532 = ifn_535.Invoke_O_O__O(arg_536, arg_537) } else { arg_532 = linked_534.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_533, arg_536, arg_537) }; if linked_530 == nil { tmp34 = ifn_531.Invoke_O__O(arg_532) } else { tmp34 = linked_530.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_529, arg_532) }; arg_527 = tmp33.Invoke_O__O(tmp34); var arg_528 any; var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp36 any; var root_538 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_538, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_540 lang.IFn; if linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any; var root_542 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_542, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any; var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp38 any; var root_547 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any; var root_551 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_551, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_553 lang.IFn; if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_56); var arg_555 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_68); if linked_552 == nil { arg_550 = ifn_553.Invoke_O_O__O(arg_554, arg_555) } else { arg_550 = linked_552.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_551, arg_554, arg_555) }; if linked_548 == nil { tmp38 = ifn_549.Invoke_O__O(arg_550) } else { tmp38 = linked_548.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_547, arg_550) }; arg_545 = tmp37.Invoke_O__O(tmp38); var arg_546 any; var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp40 any; var root_556 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_556, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_558 lang.IFn; if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any; var root_560 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_69); var arg_564 any; var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp42 any; var root_565 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_565, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_567 lang.IFn; if linked_566 == nil { ifn_567 = lang.IFn_Cast(root_565) } else { ifn_567 = nil }; var arg_568 any; var root_569 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_569, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_571 lang.IFn; if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_59); var arg_573 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(name__2); if linked_570 == nil { arg_568 = ifn_571.Invoke_O_O__O(arg_572, arg_573) } else { arg_568 = linked_570.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_569, arg_572, arg_573) }; if linked_566 == nil { tmp42 = ifn_567.Invoke_O__O(arg_568) } else { tmp42 = linked_566.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_565, arg_568) }; arg_564 = tmp41.Invoke_O__O(tmp42); if linked_561 == nil { arg_559 = ifn_562.Invoke_O_O__O(arg_563, arg_564) } else { arg_559 = linked_561.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_560, arg_563, arg_564) }; if linked_557 == nil { tmp40 = ifn_558.Invoke_O__O(arg_559) } else { tmp40 = linked_557.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_556, arg_559) }; arg_546 = tmp39.Invoke_O__O(tmp40); if linked_543 == nil { arg_541 = ifn_544.Invoke_O_O__O(arg_545, arg_546) } else { arg_541 = linked_543.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_542, arg_545, arg_546) }; if linked_539 == nil { tmp36 = ifn_540.Invoke_O__O(arg_541) } else { tmp36 = linked_539.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_538, arg_541) }; arg_528 = tmp35.Invoke_O__O(tmp36); if linked_525 == nil { arg_523 = ifn_526.Invoke_O_O__O(arg_527, arg_528) } else { arg_523 = linked_525.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_524, arg_527, arg_528) }; if linked_521 == nil { return ifn_522.Invoke_O__O(arg_523) } else { return linked_521.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_520, arg_523) } } else { var tmp43 any; var root_574 any = A_arbace_repl_A_const_11.GetRawRoot__O(); var linked_575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_574, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_576 lang.IFn



						if linked_575 == nil { ifn_576 = lang.IFn_Cast(root_574) } else { ifn_576 = nil }; var arg_577 any = name__2; if linked_575 == nil { tmp43 = ifn_576.Invoke_O__O(arg_577) } else { tmp43 = linked_575.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_574, arg_577) }
//line :138:1
						if jrt.J2g_Truth(tmp43) { var root_578 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_578, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_580 lang.IFn; if linked_579 == nil { ifn_580 = lang.IFn_Cast(root_578) } else { ifn_580 = nil }; var arg_581 any; var root_582 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_583 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_582, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_584 lang.IFn; if linked_583 == nil { ifn_584 = lang.IFn_Cast(root_582) } else { ifn_584 = nil }; var arg_585 any; var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp45 any; var root_587 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_587, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_589 lang.IFn; if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any; var root_591 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_592 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_591, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_593 lang.IFn; if linked_592 == nil { ifn_593 = lang.IFn_Cast(root_591) } else { ifn_593 = nil }; var arg_594 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_56); var arg_595 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_70); if linked_592 == nil { arg_590 = ifn_593.Invoke_O_O__O(arg_594, arg_595) } else { arg_590 = linked_592.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_591, arg_594, arg_595) }; if linked_588 == nil { tmp45 = ifn_589.Invoke_O__O(arg_590) } else { tmp45 = linked_588.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_587, arg_590) }; arg_585 = tmp44.Invoke_O__O(tmp45); var arg_586 any; var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp47 any; var root_596 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_596, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_598 lang.IFn; if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any; var root_600 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_600, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_602 lang.IFn; if linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_71); var arg_604 any; var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp49 any; var root_605 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_605, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_607 lang.IFn; if linked_606 == nil { ifn_607 = lang.IFn_Cast(root_605) } else { ifn_607 = nil }; var arg_608 any; var root_609 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_610 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_609, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_611 lang.IFn; if linked_610 == nil { ifn_611 = lang.IFn_Cast(root_609) } else { ifn_611 = nil }; var arg_612 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_72); var arg_613 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(name__2); if linked_610 == nil { arg_608 = ifn_611.Invoke_O_O__O(arg_612, arg_613) } else { arg_608 = linked_610.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_609, arg_612, arg_613) }; if linked_606 == nil { tmp49 = ifn_607.Invoke_O__O(arg_608) } else { tmp49 = linked_606.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_605, arg_608) }; arg_604 = tmp48.Invoke_O__O(tmp49); if linked_601 == nil { arg_599 = ifn_602.Invoke_O_O__O(arg_603, arg_604) } else { arg_599 = linked_601.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_600, arg_603, arg_604) }; if linked_597 == nil { tmp47 = ifn_598.Invoke_O__O(arg_599) } else { tmp47 = linked_597.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_596, arg_599) }; arg_586 = tmp46.Invoke_O__O(tmp47); if linked_583 == nil { arg_581 = ifn_584.Invoke_O_O__O(arg_585, arg_586) } else { arg_581 = linked_583.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_582, arg_585, arg_586) }; if linked_579 == nil { return ifn_580.Invoke_O__O(arg_581) } else { return linked_579.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_578, arg_581) } } else { return nil } } } } } }








func A_arbace_repl_source_fn_A_New() *A_arbace_repl_source_fn_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_source_fn_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_repl_source_fn_A) Ctor() {}
//line :147:1
func (t *A_arbace_repl_source_fn_A) Invoke_O_O__O(self, x__0 any) any { var temp__1927000414__auto____2 any; var root_614 any = A_arbace_repl_A_const_11.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_616 lang.IFn; if








	linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = x__0; if linked_615 == nil { temp__1927000414__auto____2 = ifn_616.Invoke_O__O(arg_617) } else { temp__1927000414__auto____2 = linked_615.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_614, arg_617) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var v__3 any = temp__1927000414__auto____2; var tmp1 *lang.Keyword = A_arbace_repl_A_const_73; var temp__1927000414__auto____4 any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__3))
		if jrt.J2g_Truth(temp__1927000414__auto____4) { var filepath__5 any = temp__1927000414__auto____4; var tmp2 any = lang.RT_BaseLoader__ClassLoader_NoInit(); var tmp3 *jrt.Class = A_arbace_repl_A_const_74; var temp__1927000414__auto____6 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp2, tmp3, Lit_34, jrt.RefArrayOf(jrt.Object_class, filepath__5))
			if jrt.J2g_Truth(temp__1927000414__auto____6) { var strm__7 any = temp__1927000414__auto____6; var rdr__8 any = jrt.LineNumberReader_New_Reader(jrt.InputStreamReader_New_InputStream(jrt.InputStream_Cast(strm__7))); var tmp4 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var n__1927000701__auto____11 int64; var tmp5 jrt.Number_I; var tmp6 *lang.Keyword = A_arbace_repl_A_const_76; var na_622 any = tmp6.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__3))

				if jrt.Long_InstanceOf(na_622) { var n0_623 int64 = jrt.NN(jrt.Long_Cast(na_622)).LongValue__J(); if n0_623 == -9223372036854775808 { tmp5 = lang.Numbers_Dec_O__Number_NoInit(na_622) } else { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_623 - 1)) } } else { if jrt.Double_InstanceOf(na_622) { var n0_623_2 float64 = jrt.NN(jrt.Double_Cast(na_622)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_623_2 - 1.0)) } else { tmp5 = lang.Numbers_Dec_O__Number_NoInit(na_622) } }; n__1927000701__auto____11 = lang.RT_LongCast_O__J_NoInit(tmp5)
//line :158:1
				var ___12 int64 = 0; L1: for {

					if lang.Numbers_Lt_J_J__Z_NoInit(___12, n__1927000701__auto____11) { jrt.NN(jrt.LineNumberReader_Cast(rdr__8)).ReadLine__String(); ___12 = lang.Numbers_Unchecked_inc_J__J_NoInit(___12); continue L1 }
//line :158:1
					break L1 }; var text__11 any = jrt.StringBuilder_New(); var pbr__12 any; var p__840000142__auto____12 any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_35), jrt.RefArrayOf(jrt.Object_class, rdr__8)); var root_624 any = A_arbace_repl_A_const_77.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, aot_arbace_core.A_arbace_core_init_proxy_A_fn_class); var ifn_626 lang.IFn



				if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any = p__840000142__auto____12; var arg_628 any; var tmp7 any = A_arbace_repl_source_fn_fn__1239000039_A_New_O(text__11); var tmp8 *jrt.Class; var fncls__636 *jrt.Class = A_arbace_repl_source_fn_fn__1239000039_A_fn_class; if fncls__636 == nil { var fncls__636d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_repl_source_fn_fn__1239000039_A_fn_class = fncls__636d; tmp8 = fncls__636d } else { tmp8 = fncls__636 }; arg_628 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_36, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil))); if linked_625 == nil { ifn_626.Invoke_O_O__O(arg_627, arg_628) } else { linked_625.(*aot_arbace_core.A_arbace_core_init_proxy_A).Invoke_O_O_O__O(root_624, arg_627, arg_628) }
//line :158:1
				pbr__12 = p__840000142__auto____12; var read_opts__13 any







				if jrt.NN(jrt.String_Cast(filepath__5)).EndsWith_String__Z(Lit_38) { read_opts__13 = A_arbace_repl_A_const_75 } else { read_opts__13 = lang.PersistentArrayMap_EMPTY.Ref() }
				var tmp9 any = A_arbace_repl_A_const_79; if lang.Util_Equiv_O_O__Z_NoInit(tmp9, A_arbace_repl_A_const_80.Get__O()) { panic(jrt.Thrown(jrt.IllegalStateException_New_String(Lit_39))) } else {

					var root_637 any = A_arbace_repl_A_const_81.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_639 lang.IFn; if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any = read_opts__13; var arg_641 any = jrt.PushbackReader_New_Reader(jrt.Reader_Cast(pbr__12)); if linked_638 == nil { ifn_639.Invoke_O_O__O(arg_640, arg_641) } else { linked_638.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O__O(root_637, arg_640, arg_641) } }
				var root_618 any = A_arbace_repl_A_const_28.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_618, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_620 lang.IFn; if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; var arg_621 any = text__11; if linked_619 == nil { tmp4 = ifn_620.Invoke_O__O(arg_621) } else { tmp4 = linked_619.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_618, arg_621) } }; return nil }()
//line :159:1
				jrt.BufferedReader_Cast(rdr__8).Close__V()
//line :158:1
				if tmp10 != nil { panic(tmp10) }; return tmp4 } else { return nil } } else {
//line :157:1
					return nil } } else {
//line :156:1
						return nil } }





func A_arbace_repl_source_fn_fn__1239000039_A_New_O(p0 any) *A_arbace_repl_source_fn_fn__1239000039_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_source_fn_fn__1239000039_A{}; t.Ctor_O(p0); return t }
//line :162:1
func (t *A_arbace_repl_source_fn_fn__1239000039_A) Ctor_O(c__text any) { t.F_text = c__text }
//line :162:1
func (t *A_arbace_repl_source_fn_fn__1239000039_A) Invoke_O_O__O(self, this__1 any) any { var i__2 any; var root_629 any = A_arbace_repl_A_const_78.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, aot_arbace_core.A_arbace_core_proxy_call_with_super_A_fn_class); var ifn_631 lang.IFn; if
											linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any; var tmp1 any = A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_New_O(this__1); var tmp2 *jrt.Class; var fncls__635 *jrt.Class = A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_fn_class; if fncls__635 == nil { var fncls__635d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_fn_class = fncls__635d; tmp2 = fncls__635d } else { tmp2 = fncls__635 }; arg_632 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_633 any = this__1; var arg_634 any = Lit_36; if linked_630 == nil { i__2 = ifn_631.Invoke_O_O_O__O(arg_632, arg_633, arg_634) } else { i__2 = linked_630.(*aot_arbace_core.A_arbace_core_proxy_call_with_super_A).Invoke_O_O_O_O__O(root_629, arg_632, arg_633, arg_634) }; var tmp3 /*line :164:1*/*jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_text); jrt.NN(tmp3).Append_C__StringBuilder(lang.RT_CharCast_O__C_NoInit(i__2)); return i__2 }
//line :163:1
func A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_New_O(p0 any) *A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A{}; t.Ctor_O(p0); return t }
//line :163:1
func (t *A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A) Ctor_O(c__this any) { t.F_this = c__this }
//line :163:1
func (t *A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A) Invoke_O__O(self any) any { return lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(t.F_this, Lit_36, false) }








func A_arbace_repl_source_A_New() *A_arbace_repl_source_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_source_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_repl_source_A) Ctor() {}
//line :172:1
func (t *A_arbace_repl_source_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, n__2 any) any { var root_642 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any; var root_646 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_646, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_648 lang.IFn; if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_82); var arg_650 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp2 any; var root_651 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_651, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_653 lang.IFn; if linked_652 == nil { ifn_653 = lang.IFn_Cast(root_651) } else { ifn_653 = nil }; var arg_654 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()); var tmp4 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_83); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp6 any; var root_661 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_663 lang.IFn; if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any; var root_665 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_84); var arg_669 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp8 any; var root_670 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_670, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_672 lang.IFn; if linked_671 == nil { ifn_672 = lang.IFn_Cast(root_670) } else { ifn_672 = nil }; var arg_673 any; var root_674 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_674, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_676 lang.IFn; if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_59); var arg_678 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(n__2); if linked_675 == nil { arg_673 = ifn_676.Invoke_O_O__O(arg_677, arg_678) } else { arg_673 = linked_675.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_674, arg_677, arg_678) }; if linked_671 == nil { tmp8 = ifn_672.Invoke_O__O(arg_673) } else { tmp8 = linked_671.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_670, arg_673) }; arg_669 = tmp7.Invoke_O__O(tmp8); if linked_666 == nil { arg_664 = ifn_667.Invoke_O_O__O(arg_668, arg_669) } else { arg_664 = linked_666.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_665, arg_668, arg_669) }; if linked_662 == nil { tmp6 = ifn_663.Invoke_O__O(arg_664) } else { tmp6 = linked_662.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_661, arg_664) }; var tmp9 any = tmp5.Invoke_O__O(tmp6); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp11 any; var root_679 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any; var root_683 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_683, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_685 lang.IFn; if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_85); var arg_687 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(Lit_33); if linked_684 == nil { arg_682 = ifn_685.Invoke_O_O__O(arg_686, arg_687) } else { arg_682 = linked_684.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_683, arg_686, arg_687) }; if linked_680 == nil { tmp11 = ifn_681.Invoke_O__O(arg_682) } else { tmp11 = linked_680.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_679, arg_682) }; arg_654 = tmp3.Invoke_O_O_O__O(tmp4, tmp9, tmp10.Invoke_O__O(tmp11)); if linked_652 == nil { tmp2 = ifn_653.Invoke_O__O(arg_654) } else { tmp2 = linked_652.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_651, arg_654) }; arg_650 = tmp1.Invoke_O__O(tmp2); if linked_647 == nil { arg_645 = ifn_648.Invoke_O_O__O(arg_649, arg_650) } else { arg_645 = linked_647.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_646, arg_649, arg_650) }; if linked_643 == nil { return ifn_644.Invoke_O__O(arg_645) } else { return linked_643.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_642, arg_645) } }








func A_arbace_repl_apropos_A_New() *A_arbace_repl_apropos_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_apropos_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_repl_apropos_A) Ctor() {}
//line :181:1
func (t *A_arbace_repl_apropos_A) Invoke_O_O__O(self, str_or_pattern__0 any) any { var matches_QMARK___2 any; if




	jrt.Pattern_InstanceOf(str_or_pattern__0) { var tmp1 any = A_arbace_repl_apropos_fn__1239000052_A_New_O(str_or_pattern__0); var tmp2 *jrt.Class; var fncls__697 *jrt.Class = A_arbace_repl_apropos_fn__1239000052_A_fn_class; if fncls__697 == nil { var fncls__697d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_repl_apropos_fn__1239000052_A_fn_class = fncls__697d; tmp2 = fncls__697d } else { tmp2 = fncls__697 }; matches_QMARK___2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) } else { var tmp3 any = A_arbace_repl_apropos_fn__1239000054_A_New_O(str_or_pattern__0); var tmp4 *jrt.Class; var fncls__706 *jrt.Class = A_arbace_repl_apropos_fn__1239000054_A_fn_class; if fncls__706 == nil { var fncls__706d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_repl_apropos_fn__1239000054_A_fn_class = fncls__706d; tmp4 = fncls__706d } else { tmp4 = fncls__706 }; matches_QMARK___2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil) }; var root_707 any =


	A_arbace_repl_A_const_86.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_709 lang.IFn; if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_41.GetRawRoot__O()); var tmp6 any = A_arbace_repl_apropos_fn__1239000056_A_New_O(matches_QMARK___2); var tmp7 *jrt.Class; var fncls__748 *jrt.Class = A_arbace_repl_apropos_fn__1239000056_A_fn_class; if fncls__748 == nil { var fncls__748d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_repl_apropos_fn__1239000056_A_fn_class = fncls__748d; tmp7 = fncls__748d } else { tmp7 = fncls__748 }; var tmp8 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp9 any; var root_749 any = A_arbace_repl_A_const_47.GetRawRoot__O(); var linked_750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_749, aot_arbace_core.A_arbace_core_all_ns_A_fn_class); var ifn_751 lang.IFn; if



	linked_750 == nil { ifn_751 = lang.IFn_Cast(root_749) } else { ifn_751 = nil }; if linked_750 == nil { tmp9 = ifn_751.Invoke__O() } else { tmp9 = linked_750.(*aot_arbace_core.A_arbace_core_all_ns_A).Invoke_O__O(root_749) }; arg_710 = /*line :189:1*/tmp5.Invoke_O_O__O(tmp8, tmp9); if linked_708 == nil { return ifn_709.Invoke_O__O(arg_710) } else { return linked_708.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_707, arg_710) } }
//line :186:1
func A_arbace_repl_apropos_fn__1239000052_A_New_O(p0 any) *A_arbace_repl_apropos_fn__1239000052_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_apropos_fn__1239000052_A{}; t.Ctor_O(p0); return t }
//line :186:1
func (t *A_arbace_repl_apropos_fn__1239000052_A) Ctor_O(c__str_or_pattern any) { t.F_str_or_pattern = c__str_or_pattern }
//line :186:1
func (t *A_arbace_repl_apropos_fn__1239000052_A) Invoke_O_O__O(self, p1__1239000049_SHARP___1 any) any {
	var root_688 any = A_arbace_repl_A_const_51.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_688, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_690 lang.IFn; if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any = t.F_str_or_pattern; var arg_692 any; var root_693 any = A_arbace_repl_A_const_28.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_693, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_695 lang.IFn; if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any = p1__1239000049_SHARP___1; if linked_694 == nil { arg_692 = ifn_695.Invoke_O__O(arg_696) } else { arg_692 = linked_694.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_693, arg_696) }; if linked_689 == nil { return ifn_690.Invoke_O_O__O(arg_691, arg_692) } else { return linked_689.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_688, arg_691, arg_692) } }
//line :186:1
func A_arbace_repl_apropos_fn__1239000054_A_New_O(p0 any) *A_arbace_repl_apropos_fn__1239000054_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_apropos_fn__1239000054_A{}; t.Ctor_O(p0); return t }
//line :186:1
func (t *A_arbace_repl_apropos_fn__1239000054_A) Ctor_O(c__str_or_pattern any) { t.F_str_or_pattern = c__str_or_pattern }
//line :186:1
func (t *A_arbace_repl_apropos_fn__1239000054_A) Invoke_O_O__O(self, p1__1239000050_SHARP___1 any) any {

	var tmp1 any; var root_698 any = A_arbace_repl_A_const_28.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_698, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_700 lang.IFn; if linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any = p1__1239000050_SHARP___1; if linked_699 == nil { tmp1 = ifn_700.Invoke_O__O(arg_701) } else { tmp1 = linked_699.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_698, arg_701) }; var tmp2 *jrt.String = jrt.String_Cast(tmp1); var tmp3 any; var root_702 any = A_arbace_repl_A_const_28.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_704 lang.IFn; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any = t.F_str_or_pattern; if linked_703 == nil { tmp3 = ifn_704.Invoke_O__O(arg_705) } else { tmp3 = linked_703.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_702, arg_705) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(tmp2).Contains_CharSequence__Z(jrt.CharSequence_Cast(tmp3))).Ref() }
func A_arbace_repl_apropos_fn__1239000056_A_New_O(p0 any) *A_arbace_repl_apropos_fn__1239000056_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_apropos_fn__1239000056_A{}; t.Ctor_O(p0); return t }
//line :189:1
func (t *A_arbace_repl_apropos_fn__1239000056_A) Ctor_O(c__matches_QMARK_ any) { t.F_matches_QMARK_ = c__matches_QMARK_ }
//line :189:1
func (t *A_arbace_repl_apropos_fn__1239000056_A) Invoke_O_O__O(self, ns__1 any) any { var ns_name__2 any; var root_716 any = A_arbace_repl_A_const_28.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_716, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_718 lang.IFn; if
											linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any = ns__1; if linked_717 == nil { ns_name__2 = ifn_718.Invoke_O__O(arg_719) } else { ns_name__2 = linked_717.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_716, arg_719) }; var root_720 any =
											A_arbace_repl_A_const_43.GetRawRoot__O(); var linked_721 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_720, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_722 lang.IFn; if linked_721 == nil { ifn_722 = lang.IFn_Cast(root_720) } else { ifn_722 = nil }; var arg_723 any; var tmp1 any = A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_New_O(ns_name__2); var tmp2 *jrt.Class; var fncls__734 *jrt.Class = A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_fn_class; if fncls__734 == nil { var fncls__734d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_fn_class = fncls__734d; tmp2 = fncls__734d } else { tmp2 = fncls__734 }; arg_723 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_724 any; var root_735 any = A_arbace_repl_A_const_87.GetRawRoot__O(); var linked_736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_735, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_737 lang.IFn; if
											linked_736 == nil { ifn_737 = lang.IFn_Cast(root_735) } else { ifn_737 = nil }; var arg_738 any = t.F_matches_QMARK_; var arg_739 any; var root_740 any = A_arbace_repl_A_const_50.GetRawRoot__O(); var linked_741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_740, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_742 lang.IFn; if linked_741 == nil { ifn_742 = lang.IFn_Cast(root_740) } else { ifn_742 = nil }; var arg_743 any; var root_744 any = A_arbace_repl_A_const_88.GetRawRoot__O(); var linked_745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_744, aot_arbace_core.A_arbace_core_ns_publics_A_fn_class); var ifn_746 lang.IFn; if linked_745 == nil { ifn_746 = lang.IFn_Cast(root_744) } else { ifn_746 = nil }; var arg_747 any = ns__1; if linked_745 == nil { arg_743 = ifn_746.Invoke_O__O(arg_747) } else { arg_743 = linked_745.(*aot_arbace_core.A_arbace_core_ns_publics_A).Invoke_O_O__O(root_744, arg_747) }; if linked_741 == nil { arg_739 = ifn_742.Invoke_O__O(arg_743) } else { arg_739 = linked_741.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_740, arg_743) }; if linked_736 == nil { arg_724 = ifn_737.Invoke_O_O__O(arg_738, arg_739) } else { arg_724 = linked_736.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_735, arg_738, arg_739) }; if /*line :191:1*/ linked_721 == nil { return ifn_722.Invoke_O_O__O(arg_723, arg_724) } else { return linked_721.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_720, arg_723, arg_724) } }
//line :191:1
func A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_New_O(p0 any) *A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A{}; t.Ctor_O(p0); return t }
//line :191:1
func (t *A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A) Ctor_O(c__ns_name any) { t.F_ns_name = c__ns_name }
//line :191:1
func (t *A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A) Invoke_O_O__O(self, p1__1239000051_SHARP___1 any) any { var root_725 any = A_arbace_repl_A_const_27.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any = t.F_ns_name; var arg_729 any; var root_730 any = A_arbace_repl_A_const_28.GetRawRoot__O(); var linked_731 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_730, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_732 lang.IFn; if linked_731 == nil { ifn_732 = lang.IFn_Cast(root_730) } else { ifn_732 = nil }; var arg_733 any = p1__1239000051_SHARP___1; if linked_731 == nil { arg_729 = ifn_732.Invoke_O__O(arg_733) } else { arg_729 = linked_731.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_730, arg_733) }; if linked_726 == nil { return ifn_727.Invoke_O_O__O(arg_728, arg_729) } else { return linked_726.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_725, arg_728, arg_729) } }



func A_arbace_repl_dir_fn_A_New() *A_arbace_repl_dir_fn_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_dir_fn_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_repl_dir_fn_A) Ctor() {}
//line :195:1
func (t *A_arbace_repl_dir_fn_A) Invoke_O_O__O(self, ns__0 any) any {



	var root_752 any = A_arbace_repl_A_const_86.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any; var root_756 any = A_arbace_repl_A_const_43.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_756, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = A_arbace_repl_A_const_18.GetRawRoot__O(); var arg_760 any; var root_761 any = A_arbace_repl_A_const_88.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, aot_arbace_core.A_arbace_core_ns_publics_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any; var root_765 any = A_arbace_repl_A_const_89.GetRawRoot__O(); var linked_766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_765, aot_arbace_core.A_arbace_core_the_ns_A_fn_class); var ifn_767 lang.IFn; if linked_766 == nil { ifn_767 = lang.IFn_Cast(root_765) } else { ifn_767 = nil }; var arg_768 any; var tmp1 any; var root_769 any = A_arbace_repl_A_const_90.GetRawRoot__O(); var linked_770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_769, aot_arbace_core.A_arbace_core_ns_aliases_A_fn_class); var ifn_771 lang.IFn; if linked_770 == nil { ifn_771 = lang.IFn_Cast(root_769) } else { ifn_771 = nil }; var arg_772 any = A_arbace_repl_A_const_91.Get__O(); if linked_770 == nil { tmp1 = ifn_771.Invoke_O__O(arg_772) } else { tmp1 = linked_770.(*aot_arbace_core.A_arbace_core_ns_aliases_A).Invoke_O_O__O(root_769, arg_772) }; arg_768 = lang.RT_Get_O_O_O__O_NoInit(tmp1, ns__0, ns__0); if linked_766 == nil { arg_764 = ifn_767.Invoke_O__O(arg_768) } else { arg_764 = linked_766.(*aot_arbace_core.A_arbace_core_the_ns_A).Invoke_O_O__O(root_765, arg_768) }; if linked_762 == nil { arg_760 = ifn_763.Invoke_O__O(arg_764) } else { arg_760 = linked_762.(*aot_arbace_core.A_arbace_core_ns_publics_A).Invoke_O_O__O(root_761, arg_764) }; if linked_757 == nil { arg_755 = ifn_758.Invoke_O_O__O(arg_759, arg_760) } else { arg_755 = linked_757.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_756, arg_759, arg_760) }; if linked_753 == nil { return ifn_754.Invoke_O__O(arg_755) } else { return linked_753.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_752, arg_755)
	} }
func A_arbace_repl_dir_A_New() *A_arbace_repl_dir_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_dir_A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_repl_dir_A) Ctor() {}
//line :201:1
func (t *A_arbace_repl_dir_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, nsname__2 any) any { var root_773 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_773, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_775 lang.IFn; if linked_774 == nil { ifn_775 = lang.IFn_Cast(root_773) } else { ifn_775 = nil }; var arg_776 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_92); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp4 any; var root_783 any = A_arbace_repl_A_const_64.GetRawRoot__O(); var linked_784 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_783, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_785 lang.IFn; if linked_784 == nil { ifn_785 = lang.IFn_Cast(root_783) } else { ifn_785 = nil }; var arg_786 any = A_arbace_repl_A_const_93.GetRawRoot__O(); var arg_787 any; var root_788 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_788, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_790 lang.IFn; if linked_789 == nil { ifn_790 = lang.IFn_Cast(root_788) } else { ifn_790 = nil }; var arg_791 any; var root_792 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_793 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_792, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_794 lang.IFn; if linked_793 == nil { ifn_794 = lang.IFn_Cast(root_792) } else { ifn_794 = nil }; var arg_795 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_94); var arg_796 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp6 any; var root_797 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_797, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_799 lang.IFn; if linked_798 == nil { ifn_799 = lang.IFn_Cast(root_797) } else { ifn_799 = nil }; var arg_800 any; var root_801 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_802 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_801, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_803 lang.IFn; if linked_802 == nil { ifn_803 = lang.IFn_Cast(root_801) } else { ifn_803 = nil }; var arg_804 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_95); var arg_805 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp8 any; var root_806 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_806, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_808 lang.IFn; if linked_807 == nil { ifn_808 = lang.IFn_Cast(root_806) } else { ifn_808 = nil }; var arg_809 any; var root_810 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_811 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_810, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_812 lang.IFn; if linked_811 == nil { ifn_812 = lang.IFn_Cast(root_810) } else { ifn_812 = nil }; var arg_813 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_59); var arg_814 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(nsname__2); if linked_811 == nil { arg_809 = ifn_812.Invoke_O_O__O(arg_813, arg_814) } else { arg_809 = linked_811.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_810, arg_813, arg_814) }; if linked_807 == nil { tmp8 = ifn_808.Invoke_O__O(arg_809) } else { tmp8 = linked_807.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_806, arg_809) }; arg_805 = tmp7.Invoke_O__O(tmp8); if linked_802 == nil { arg_800 = ifn_803.Invoke_O_O__O(arg_804, arg_805) } else { arg_800 = linked_802.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_801, arg_804, arg_805) }; if linked_798 == nil { tmp6 = ifn_799.Invoke_O__O(arg_800) } else { tmp6 = linked_798.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_797, arg_800) }; arg_796 = tmp5.Invoke_O__O(tmp6); if linked_793 == nil { arg_791 = ifn_794.Invoke_O_O__O(arg_795, arg_796) } else { arg_791 = linked_793.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_792, arg_795, arg_796) }; if linked_789 == nil { arg_787 = ifn_790.Invoke_O__O(arg_791) } else { arg_787 = linked_789.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_788, arg_791) }; if linked_784 == nil { tmp4 = ifn_785.Invoke_O_O__O(arg_786, arg_787) } else { tmp4 = linked_784.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_783, arg_786, arg_787) }; var tmp9 any = tmp3.Invoke_O__O(tmp4); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp11 any; var root_815 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_815, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_817 lang.IFn; if linked_816 == nil { ifn_817 = lang.IFn_Cast(root_815) } else { ifn_817 = nil }; var arg_818 any; var root_819 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_820 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_819, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_821 lang.IFn; if linked_820 == nil { ifn_821 = lang.IFn_Cast(root_819) } else { ifn_821 = nil }; var arg_822 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_96); var arg_823 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_94); if linked_820 == nil { arg_818 = ifn_821.Invoke_O_O__O(arg_822, arg_823) } else { arg_818 = linked_820.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_819, arg_822, arg_823) }; if linked_816 == nil { tmp11 = ifn_817.Invoke_O__O(arg_818) } else { tmp11 = linked_816.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_815, arg_818) }; arg_776 = tmp1.Invoke_O_O_O__O(tmp2, tmp9, tmp10.Invoke_O__O(tmp11)); if linked_774 == nil { return ifn_775.Invoke_O__O(arg_776) } else { return linked_774.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_773, arg_776) } }





func A_arbace_repl_demunge_A_New() *A_arbace_repl_demunge_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_demunge_A{}; t.Ctor(); return t }
//line :207:1
func (t *A_arbace_repl_demunge_A) Ctor() {}
//line :207:1
func (t *A_arbace_repl_demunge_A) Invoke_O_O__O(self, fn_name__0 any) any {




	return lang.Compiler_Demunge_String__String_NoInit(jrt.String_Cast(fn_name__0)).Ref()
}
func A_arbace_repl_root_cause_A_New() *A_arbace_repl_root_cause_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_root_cause_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_repl_root_cause_A) Ctor() {}
//line :214:1
func (t *A_arbace_repl_root_cause_A) Invoke_O_O__O(self, t__0 any) any { { var cause__2 any = t__0; L1: for {





	var tmp1 any; var and__1927000168__auto____3 bool = lang.Compiler_CompilerException_InstanceOf(cause__2); if and__1927000168__auto____3 {
		var root_824 any = A_arbace_repl_A_const_97.GetRawRoot__O(); var linked_825 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_824, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_826 lang.IFn; if linked_825 == nil { ifn_826 = lang.IFn_Cast(root_824) } else { ifn_826 = nil }; var arg_827 any = lang.Compiler_CompilerException_Cast(cause__2).F_source.Ref(); var arg_828 any = Lit_26; if linked_825 == nil { tmp1 = ifn_826.Invoke_O_O__O(arg_827, arg_828) } else { tmp1 = linked_825.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_824, arg_827, arg_828) } } else {
//line :220:1
			tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) { return cause__2 } else { var temp__1927000408__auto____3 any = jrt.Throwable_Cast(cause__2).GetCause__Throwable()


				if jrt.J2g_Truth(temp__1927000408__auto____3) { var cause__4 any = temp__1927000408__auto____3
					cause__2 = cause__4; continue L1 } else {
//line :223:1
						return cause__2 } } } }; /*line :214:1*/panic("j2g: unreachable") }












func A_arbace_repl_stack_element_str_A_New() *A_arbace_repl_stack_element_str_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_stack_element_str_A{}; t.Ctor(); return t }
//line :227:1
func (t *A_arbace_repl_stack_element_str_A) Ctor() {}
//line :227:1
func (t *A_arbace_repl_stack_element_str_A) Invoke_O_O__O(self, el__0 any) any { var file__2 any = jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetFileName__String().Ref(); var clojure_fn_QMARK___3 any; var and__1927000168__auto____3 any = file__2; if




	jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 bool = jrt.NN(jrt.String_Cast(file__2)).EndsWith_String__Z(Lit_41); if or__1927000174__auto____4 { clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else { var or__1927000174__auto____5 bool = jrt.NN(jrt.String_Cast(file__2)).EndsWith_String__Z(Lit_42); if or__1927000174__auto____5 { clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool = jrt.NN(jrt.String_Cast(file__2)).EndsWith_String__Z(Lit_43); if or__1927000174__auto____6 { clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else {


		clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(file__2, Lit_26)).Ref() } } } } else {
//line :232:1
			clojure_fn_QMARK___3 = and__1927000168__auto____3 }; var tmp1 /*line :236:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_44, nil, Lit_20, nil, Lit_45); var tmp2 any; if jrt.J2g_Truth(clojure_fn_QMARK___3) {
				var root_829 any = A_arbace_repl_A_const_98.GetRawRoot__O(); var linked_830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_829, A_arbace_repl_demunge_A_fn_class); var ifn_831 lang.IFn; if linked_830 == nil { ifn_831 = lang.IFn_Cast(root_829) } else { ifn_831 = nil }; var arg_832 any = jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetClassName__String().Ref(); if linked_830 == nil { tmp2 = ifn_831.Invoke_O__O(arg_832) } else { tmp2 = linked_830.(*A_arbace_repl_demunge_A).Invoke_O_O__O(root_829, arg_832) } } else {
					tmp2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_46, nil), jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetClassName__String().Ref(), nil, jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetMethodName__String().Ref())).Ref() }; return /*line :236:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil, jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetFileName__String().Ref(), nil, jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetLineNumber__I()).Ref(), nil)).Ref() }




func A_arbace_repl_pst_A_New() *A_arbace_repl_pst_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_pst_A{}; t.Ctor(); return t }
//line :241:1
func (t *A_arbace_repl_pst_A) Ctor() {}
//line :241:1
func (t *A_arbace_repl_pst_A) Invoke_O_O_O__O(self, e__0, depth__1 any) any {










	var root_841 any = A_arbace_repl_A_const_101.GetRawRoot__O(); var linked_842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_841, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_843 lang.IFn; if linked_842 == nil { ifn_843 = lang.IFn_Cast(root_841) } else { ifn_843 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_65.GetRawRoot__O()); var tmp2 any = A_arbace_repl_A_const_102; var arg_844 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_repl_A_const_103.Get__O()); if linked_842 == nil { ifn_843.Invoke_O__O(arg_844) } else { linked_842.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_841, arg_844) }
//line :241:1
	var tmp3 any; tmp24 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)











		{ var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_104); var tmp5 *lang.Keyword = A_arbace_repl_A_const_108; var tmp6 any; var root_870 any = A_arbace_repl_A_const_106.GetRawRoot__O(); var linked_871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_870, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_872 lang.IFn
			if linked_871 == nil { ifn_872 = lang.IFn_Cast(root_870) } else { ifn_872 = nil }; var arg_873 any = e__0; if linked_871 == nil { tmp6 = ifn_872.Invoke_O__O(arg_873) } else { tmp6 = linked_871.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_870, arg_873) }
//line :253:1
			if jrt.J2g_Truth(tmp4.Invoke_O__O(tmp5.Invoke_O__O(tmp6))) {

				lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(Lit_21) }
			var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()); var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_17, nil, nil); var tmp9 any; var root_858 any = A_arbace_repl_A_const_105.GetRawRoot__O(); var linked_859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_858, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_860 lang.IFn; if linked_859 == nil { ifn_860 = lang.IFn_Cast(root_858) } else { ifn_860 = nil }; var arg_861 any = e__0; if linked_859 == nil { tmp9 = ifn_860.Invoke_O__O(arg_861) } else { tmp9 = linked_859.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_858, arg_861) }; var tmp10 any = jrt.NN(jrt.Class_Cast(tmp9)).GetSimpleName__String().Ref(); var tmp11 any = jrt.Throwable_Cast(e__0).GetMessage__String().Ref(); var tmp12 *jrt.String; var temp__1927000414__auto____9 any; var root_862 any = A_arbace_repl_A_const_106.GetRawRoot__O(); var linked_863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_862, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_864 lang.IFn

			if linked_863 == nil { ifn_864 = lang.IFn_Cast(root_862) } else { ifn_864 = nil }; var arg_865 any = e__0; if linked_863 == nil { temp__1927000414__auto____9 = ifn_864.Invoke_O__O(arg_865) } else { temp__1927000414__auto____9 = linked_863.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_862, arg_865) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var info__10 any = temp__1927000414__auto____9; tmp12 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repl_A_const_107.GetRawRoot__O()).Invoke_O__O(info__10))) } else { tmp12 = nil }
//line :256:1
			tmp7.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, tmp10, nil, tmp11, tmp12.Ref())).Ref())
//line :241:1
			var st__5 any = jrt.Throwable_Cast(e__0).GetStackTrace__StackTraceElement1().Ref(); var cause__6 any = jrt.Throwable_Cast(e__0).GetCause__Throwable(); var seq_1239000072__7 any; var root_874 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_874, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_876 lang.IFn



















			if linked_875 == nil { ifn_876 = lang.IFn_Cast(root_874) } else { ifn_876 = nil }; var arg_877 any; var root_878 any = A_arbace_repl_A_const_109.GetRawRoot__O(); var linked_879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_878, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_880 lang.IFn; if linked_879 == nil { ifn_880 = lang.IFn_Cast(root_878) } else { ifn_880 = nil }; var arg_881 any = depth__1; var arg_882 any; var root_883 any = A_arbace_repl_A_const_110.GetRawRoot__O(); var linked_884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_883, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_885 lang.IFn
			if linked_884 == nil { ifn_885 = lang.IFn_Cast(root_883) } else { ifn_885 = nil }; var arg_886 any; var tmp13 any = A_arbace_repl_pst_fn__1239000076_A_New(); var tmp14 *jrt.Class; var fncls__888 *jrt.Class = A_arbace_repl_pst_fn__1239000076_A_fn_class; if fncls__888 == nil { var fncls__888d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_repl_pst_fn__1239000076_A_fn_class = fncls__888d; tmp14 = fncls__888d } else { tmp14 = fncls__888 }; arg_886 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var arg_887 any = st__5; if linked_884 == nil { arg_882 = ifn_885.Invoke_O_O__O(arg_886, arg_887) } else { arg_882 = linked_884.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_883, arg_886, arg_887) }
//line :261:1
			if linked_879 == nil { arg_877 = ifn_880.Invoke_O_O__O(arg_881, arg_882) } else { arg_877 = linked_879.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_878, arg_881, arg_882) }; if linked_875 == nil { seq_1239000072__7 = ifn_876.Invoke_O__O(arg_877) } else { seq_1239000072__7 = linked_875.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_874, arg_877) }
//line :241:1
			var chunk_1239000073__8 any; var count_1239000074__9 int64 = 0; var i_1239000075__10 int64 = 0; L1: for {



















				if lang.Numbers_Lt_J_J__Z_NoInit(i_1239000075__10, count_1239000074__9) { var el__11 any = lang.Indexed_Cast(chunk_1239000073__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1239000075__10)); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()); var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_23, nil); var tmp17 any; var root_909 any = A_arbace_repl_A_const_112.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, A_arbace_repl_stack_element_str_A_fn_class); var ifn_911 lang.IFn


					if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any = el__11; if linked_910 == nil { tmp17 = ifn_911.Invoke_O__O(arg_912) } else { tmp17 = linked_910.(*A_arbace_repl_stack_element_str_A).Invoke_O_O__O(root_909, arg_912) }; tmp15.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp16, jrt.RefArrayOf(jrt.Object_class, nil, tmp17)).Ref())
//line :261:1
					seq_1239000072__7, chunk_1239000073__8, count_1239000074__9, i_1239000075__10 = seq_1239000072__7, chunk_1239000073__8, count_1239000074__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1239000075__10); continue L1 } else { var temp__1927000414__auto____11 any; var root_889 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_889, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_891 lang.IFn; if linked_890 == nil { ifn_891 = lang.IFn_Cast(root_889) } else { ifn_891 = nil }; var arg_892 any = seq_1239000072__7; if linked_890 == nil { temp__1927000414__auto____11 = ifn_891.Invoke_O__O(arg_892) } else { temp__1927000414__auto____11 = linked_890.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_889, arg_892) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1239000072__12 any = temp__1927000414__auto____11; var tmp18 any; var root_893 any = A_arbace_repl_A_const_31.GetRawRoot__O(); var linked_894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_893, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_895 lang.IFn; if linked_894 == nil { ifn_895 = lang.IFn_Cast(root_893) } else { ifn_895 = nil }; var arg_896 any = seq_1239000072__12; if linked_894 == nil { tmp18 = ifn_895.Invoke_O__O(arg_896) } else { tmp18 = linked_894.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_893, arg_896) }; if jrt.J2g_Truth(tmp18) { var c__1927000678__auto____13 any; var root_897 any = A_arbace_repl_A_const_32.GetRawRoot__O(); var linked_898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_897, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_899 lang.IFn; if linked_898 == nil { ifn_899 = lang.IFn_Cast(root_897) } else { ifn_899 = nil }; var arg_900 any = seq_1239000072__12; if linked_898 == nil { c__1927000678__auto____13 = ifn_899.Invoke_O__O(arg_900) } else { c__1927000678__auto____13 = linked_898.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_897, arg_900) }; var tmp19 any; var root_913 any = A_arbace_repl_A_const_37.GetRawRoot__O(); var linked_914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_913, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_915 lang.IFn; if linked_914 == nil { ifn_915 = lang.IFn_Cast(root_913) } else { ifn_915 = nil }; var arg_916 any = seq_1239000072__12; if linked_914 == nil { tmp19 = ifn_915.Invoke_O__O(arg_916) } else { tmp19 = linked_914.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_913, arg_916) }; seq_1239000072__7, chunk_1239000073__8, count_1239000074__9, i_1239000075__10 = tmp19, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var el__13 any; var root_901 any = A_arbace_repl_A_const_18.GetRawRoot__O(); var linked_902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_901, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_903 lang.IFn; if linked_902 == nil { ifn_903 = lang.IFn_Cast(root_901) } else { ifn_903 = nil }; var arg_904 any = seq_1239000072__12; if linked_902 == nil { el__13 = ifn_903.Invoke_O__O(arg_904) } else { el__13 = linked_902.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_901, arg_904)
					}

						var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()); var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_23, nil); var tmp22 any; var root_921 any = A_arbace_repl_A_const_112.GetRawRoot__O(); var linked_922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_921, A_arbace_repl_stack_element_str_A_fn_class); var ifn_923 lang.IFn; if linked_922 == nil { ifn_923 = lang.IFn_Cast(root_921) } else { ifn_923 = nil }; var arg_924 any = el__13; if linked_922 == nil { tmp22 = ifn_923.Invoke_O__O(arg_924) } else { tmp22 = linked_922.(*A_arbace_repl_stack_element_str_A).Invoke_O_O__O(root_921, arg_924) }; tmp20.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp21, jrt.RefArrayOf(jrt.Object_class, nil, tmp22)).Ref())
//line :261:1
						var tmp23 any; var root_925 any = A_arbace_repl_A_const_15.GetRawRoot__O(); var linked_926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_925, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_927 lang.IFn; if linked_926 == nil { ifn_927 = lang.IFn_Cast(root_925) } else { ifn_927 = nil }; var arg_928 any = seq_1239000072__12; if linked_926 == nil { tmp23 = ifn_927.Invoke_O__O(arg_928) } else { tmp23 = linked_926.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_925, arg_928) }; seq_1239000072__7, chunk_1239000073__8, count_1239000074__9, i_1239000075__10 = tmp23, nil, 0, 0; continue L1 } } }
//line :241:1
				break L1
			}






















			if jrt.J2g_Truth(cause__6) {
				lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(Lit_24)
				var root_833 any = A_arbace_repl_A_const_99.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_833, A_arbace_repl_pst_A_fn_class); var ifn_835 lang.IFn; if linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any = cause__6; var arg_837 any = lang.Numbers_Min_O_J__O_NoInit(depth__1, lang.Numbers_Add_J_J__J_NoInit(2, lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(jrt.Throwable_Cast(cause__6).GetStackTrace__StackTraceElement1().Ref())), int64(lang.RT_Count_O__I_NoInit(st__5))))); if linked_834 == nil { tmp3 = ifn_835.Invoke_O_O__O(arg_836, arg_837) } else { tmp3 = linked_834.(*A_arbace_repl_pst_A).Invoke_O_O_O__O(root_833, arg_836, arg_837) } } else {
//line :265:1
					tmp3 = nil } }
//line :241:1
		return nil }(); var root_838 any = A_arbace_repl_A_const_100.GetRawRoot__O(); var linked_839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_838, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_840 lang.IFn










	if linked_839 == nil { ifn_840 = lang.IFn_Cast(root_838) } else { ifn_840 = nil }; if linked_839 == nil { ifn_840.Invoke__O() } else { linked_839.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_838) }
//line :241:1
	if tmp24 != nil { panic(tmp24) }; return tmp3 }
//line :241:1
func (t *A_arbace_repl_pst_A) Invoke_O_O__O(self, e_or_depth__0 any) any {





	if jrt.Throwable_InstanceOf(e_or_depth__0) {
		var root_933 any = A_arbace_repl_A_const_99.GetRawRoot__O(); var linked_934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_933, A_arbace_repl_pst_A_fn_class); var ifn_935 lang.IFn; if linked_934 == nil { ifn_935 = lang.IFn_Cast(root_933) } else { ifn_935 = nil }; var arg_936 any = e_or_depth__0; var arg_937 any = A_arbace_repl_A_const_113; if linked_934 == nil { return ifn_935.Invoke_O_O__O(arg_936, arg_937) } else { return linked_934.(*A_arbace_repl_pst_A).Invoke_O_O_O__O(root_933, arg_936, arg_937) } } else {
//line :247:1
			var temp__1927000414__auto____2 any = A_arbace_repl_A_const_114.Get__O()

			if jrt.J2g_Truth(temp__1927000414__auto____2) { var e__3 any = temp__1927000414__auto____2; var root_938 any = A_arbace_repl_A_const_99.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_938, A_arbace_repl_pst_A_fn_class); var ifn_940 lang.IFn
				if linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any; var root_943 any = A_arbace_repl_A_const_115.GetRawRoot__O(); var linked_944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_943, A_arbace_repl_root_cause_A_fn_class); var ifn_945 lang.IFn; if linked_944 == nil { ifn_945 = lang.IFn_Cast(root_943) } else { ifn_945 = nil }; var arg_946 any = e__3; if linked_944 == nil { arg_941 = ifn_945.Invoke_O__O(arg_946) } else { arg_941 = linked_944.(*A_arbace_repl_root_cause_A).Invoke_O_O__O(root_943, arg_946) }; var arg_942 any = e_or_depth__0; if linked_939 == nil { return ifn_940.Invoke_O_O__O(arg_941, arg_942) } else { return linked_939.(*A_arbace_repl_pst_A).Invoke_O_O_O__O(root_938, arg_941, arg_942) } } else {
//line :249:1
					return nil } } }
//line :241:1
func (t *A_arbace_repl_pst_A) Invoke_O__O(self any) any {



	var root_947 any = A_arbace_repl_A_const_99.GetRawRoot__O(); var linked_948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_947, A_arbace_repl_pst_A_fn_class); var ifn_949 lang.IFn; if linked_948 == nil { ifn_949 = lang.IFn_Cast(root_947) } else { ifn_949 = nil }; var arg_950 any = A_arbace_repl_A_const_113; if linked_948 == nil { return ifn_949.Invoke_O__O(arg_950) } else { return linked_948.(*A_arbace_repl_pst_A).Invoke_O_O__O(root_947, arg_950)
	}
}














func A_arbace_repl_pst_fn__1239000076_A_New() *A_arbace_repl_pst_fn__1239000076_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_pst_fn__1239000076_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_repl_pst_fn__1239000076_A) Ctor() {}
//line :262:1
func (t *A_arbace_repl_pst_fn__1239000076_A) Invoke_O_O__O(self, p1__1239000071_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_111); return tmp1.Invoke_O__O(lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(p1__1239000071_SHARP___1, Lit_25, false)) }











func A_arbace_repl_thread_stopper_A_New() *A_arbace_repl_thread_stopper_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_thread_stopper_A{}; t.Ctor(); return t }
//line :274:1
func (t *A_arbace_repl_thread_stopper_A) Ctor() {}
//line :274:1
func (t *A_arbace_repl_thread_stopper_A) Invoke_O_O__O(self, thread__0 any) any {



	var tmp1 any = A_arbace_repl_thread_stopper_fn__1239000079_A_New_O(thread__0); var tmp2 *jrt.Class; var fncls__951 *jrt.Class = A_arbace_repl_thread_stopper_fn__1239000079_A_fn_class; if fncls__951 == nil { var fncls__951d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_repl_thread_stopper_fn__1239000079_A_fn_class = fncls__951d; tmp2 = fncls__951d } else { tmp2 = fncls__951 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :274:1
func (t *A_arbace_repl_thread_stopper_A) Invoke_O__O(self any) any {


	var root_952 any = A_arbace_repl_A_const_117.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_952, A_arbace_repl_thread_stopper_A_fn_class); var ifn_954 lang.IFn; if linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any = jrt.Thread_CurrentThread__Thread(); if linked_953 == nil { return ifn_954.Invoke_O__O(arg_955) } else { return linked_953.(*A_arbace_repl_thread_stopper_A).Invoke_O_O__O(root_952, arg_955) } }
func A_arbace_repl_thread_stopper_fn__1239000079_A_New_O(p0 any) *A_arbace_repl_thread_stopper_fn__1239000079_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_thread_stopper_fn__1239000079_A{}; t.Ctor_O(p0); return t }
//line :278:1
func (t *A_arbace_repl_thread_stopper_fn__1239000079_A) Ctor_O(c__thread any) { t.F_thread = c__thread }
//line :278:1
func (t *A_arbace_repl_thread_stopper_fn__1239000079_A) Invoke_O_O__O(self, msg__1 any) any { var tmp1 any = t.F_thread; var tmp2 *jrt.Class = A_arbace_repl_A_const_116; return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(tmp1, Lit_48, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(tmp2, jrt.RefArrayOf(jrt.Object_class, msg__1)))) }

func A_arbace_repl_set_break_handler_BANG__A_New() *A_arbace_repl_set_break_handler_BANG__A { A_arbace_repl_A_Init(); t := &A_arbace_repl_set_break_handler_BANG__A{}; t.Ctor(); return t }
//line :280:1
func (t *A_arbace_repl_set_break_handler_BANG__A) Ctor() {}
//line :280:1
func (t *A_arbace_repl_set_break_handler_BANG__A) Invoke_O_O__O(self, f__0 any) any {





	var tmp1 *jrt.Class = lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_27); var tmp2 any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_27), jrt.RefArrayOf(jrt.Object_class, Lit_29)); var tmp3 any; var p__840000142__auto____2 any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_30), jrt.RefArrayOf(jrt.Object_class)); var root_956 any = A_arbace_repl_A_const_77.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_956, aot_arbace_core.A_arbace_core_init_proxy_A_fn_class); var ifn_958 lang.IFn

	if linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any = p__840000142__auto____2; var arg_960 any; var tmp4 any = A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_New_O(f__0); var tmp5 *jrt.Class; var fncls__961 *jrt.Class = A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_fn_class; if fncls__961 == nil { var fncls__961d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_fn_class = fncls__961d; tmp5 = fncls__961d } else { tmp5 = fncls__961 }; arg_960 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_28, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil))); if linked_957 == nil { ifn_958.Invoke_O_O__O(arg_959, arg_960) } else { linked_957.(*aot_arbace_core.A_arbace_core_init_proxy_A).Invoke_O_O_O__O(root_956, arg_959, arg_960) }
//line :286:1
	tmp3 = p__840000142__auto____2; return lang.Reflector_InvokeStaticMethod_Class_String_O1__O(tmp1, Lit_28, jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3)) }
//line :280:1
func (t *A_arbace_repl_set_break_handler_BANG__A) Invoke_O__O(self any) any {



	var root_962 any = A_arbace_repl_A_const_118.GetRawRoot__O(); var linked_963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_962, A_arbace_repl_set_break_handler_BANG__A_fn_class); var ifn_964 lang.IFn; if linked_963 == nil { ifn_964 = lang.IFn_Cast(root_962) } else { ifn_964 = nil }; var arg_965 any; var root_966 any = A_arbace_repl_A_const_117.GetRawRoot__O(); var linked_967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_966, A_arbace_repl_thread_stopper_A_fn_class); var ifn_968 lang.IFn; if linked_967 == nil { ifn_968 = lang.IFn_Cast(root_966) } else { ifn_968 = nil }; if linked_967 == nil { arg_965 = ifn_968.Invoke__O() } else { arg_965 = linked_967.(*A_arbace_repl_thread_stopper_A).Invoke_O__O(root_966) }; if linked_963 == nil { return ifn_964.Invoke_O__O(arg_965) } else { return linked_963.(*A_arbace_repl_set_break_handler_BANG__A).Invoke_O_O__O(root_962, arg_965)
	}
}

func A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_New_O(p0 any) *A_arbace_repl_set_break_handler_BANG__fn__1239000082_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_set_break_handler_BANG__fn__1239000082_A{}; t.Ctor_O(p0); return t }
//line :288:1
func (t *A_arbace_repl_set_break_handler_BANG__fn__1239000082_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :288:1
func (t *A_arbace_repl_set_break_handler_BANG__fn__1239000082_A) Invoke_O_O_O__O(self, this__1, signal__2 any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(t.F_f); return tmp1.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_32, nil), jrt.RefArrayOf(jrt.Object_class, nil, signal__2)).Ref())
}












type A_arbace_repl_A struct{ jrt.Object }

var A_arbace_repl_A_const_pool *jrt.RefArray

var A_arbace_repl_A_const_0 *lang.Var

var A_arbace_repl_A_const_1 any

var A_arbace_repl_A_const_2 *lang.Var

var A_arbace_repl_A_const_3 any

var A_arbace_repl_A_const_4 *lang.Var

var A_arbace_repl_A_const_5 *lang.Var

var A_arbace_repl_A_const_6 *lang.Var

var A_arbace_repl_A_const_7 *lang.Var

var A_arbace_repl_A_const_8 any

var A_arbace_repl_A_const_9 *lang.Var

var A_arbace_repl_A_const_10 *lang.Var

var A_arbace_repl_A_const_11 *lang.Var

var A_arbace_repl_A_const_12 *lang.Keyword

var A_arbace_repl_A_const_13 *lang.Keyword

var A_arbace_repl_A_const_14 *lang.Var

var A_arbace_repl_A_const_15 *lang.Var

var A_arbace_repl_A_const_16 *lang.Var

var A_arbace_repl_A_const_17 *lang.Var

var A_arbace_repl_A_const_18 *lang.Var

var A_arbace_repl_A_const_19 *lang.Keyword

var A_arbace_repl_A_const_20 *lang.Keyword

var A_arbace_repl_A_const_21 *lang.Keyword

var A_arbace_repl_A_const_22 *lang.Keyword

var A_arbace_repl_A_const_23 *lang.Keyword

var A_arbace_repl_A_const_24 *lang.Keyword

var A_arbace_repl_A_const_25 *lang.Keyword

var A_arbace_repl_A_const_26 *lang.Var

var A_arbace_repl_A_const_27 *lang.Var

var A_arbace_repl_A_const_28 *lang.Var

var A_arbace_repl_A_const_29 *lang.Var

var A_arbace_repl_A_const_30 any

var A_arbace_repl_A_const_31 *lang.Var

var A_arbace_repl_A_const_32 *lang.Var

var A_arbace_repl_A_const_33 *lang.Var

var A_arbace_repl_A_const_34 *lang.Var

var A_arbace_repl_A_const_35 *lang.Var

var A_arbace_repl_A_const_36 *lang.Var

var A_arbace_repl_A_const_37 *lang.Var

var A_arbace_repl_A_const_38 *lang.Var

var A_arbace_repl_A_const_39 *lang.Var

var A_arbace_repl_A_const_40 *lang.Var

var A_arbace_repl_A_const_41 *lang.Var

var A_arbace_repl_A_const_42 *lang.Var

var A_arbace_repl_A_const_43 *lang.Var

var A_arbace_repl_A_const_44 *lang.Var

var A_arbace_repl_A_const_45 *lang.Var

var A_arbace_repl_A_const_46 *lang.Var

var A_arbace_repl_A_const_47 *lang.Var

var A_arbace_repl_A_const_48 *lang.Var

var A_arbace_repl_A_const_49 *lang.Var

var A_arbace_repl_A_const_50 *lang.Var

var A_arbace_repl_A_const_51 *lang.Var

var A_arbace_repl_A_const_52 *lang.Var

var A_arbace_repl_A_const_53 *lang.Var

var A_arbace_repl_A_const_54 any

var A_arbace_repl_A_const_55 *lang.Var

var A_arbace_repl_A_const_56 any

var A_arbace_repl_A_const_57 any

var A_arbace_repl_A_const_58 any

var A_arbace_repl_A_const_59 any

var A_arbace_repl_A_const_60 any

var A_arbace_repl_A_const_61 any

var A_arbace_repl_A_const_62 *lang.Var

var A_arbace_repl_A_const_63 any

var A_arbace_repl_A_const_64 *lang.Var

var A_arbace_repl_A_const_65 *lang.Var

var A_arbace_repl_A_const_66 *lang.Var

var A_arbace_repl_A_const_67 any

var A_arbace_repl_A_const_68 any

var A_arbace_repl_A_const_69 any

var A_arbace_repl_A_const_70 any

var A_arbace_repl_A_const_71 any

var A_arbace_repl_A_const_72 any

var A_arbace_repl_A_const_73 *lang.Keyword

var A_arbace_repl_A_const_74 *jrt.Class

var A_arbace_repl_A_const_75 any

var A_arbace_repl_A_const_76 *lang.Keyword

var A_arbace_repl_A_const_77 *lang.Var

var A_arbace_repl_A_const_78 *lang.Var

var A_arbace_repl_A_const_79 *lang.Keyword

var A_arbace_repl_A_const_80 *lang.Var

var A_arbace_repl_A_const_81 *lang.Var

var A_arbace_repl_A_const_82 any

var A_arbace_repl_A_const_83 any

var A_arbace_repl_A_const_84 any

var A_arbace_repl_A_const_85 any

var A_arbace_repl_A_const_86 *lang.Var

var A_arbace_repl_A_const_87 *lang.Var

var A_arbace_repl_A_const_88 *lang.Var

var A_arbace_repl_A_const_89 *lang.Var

var A_arbace_repl_A_const_90 *lang.Var

var A_arbace_repl_A_const_91 *lang.Var

var A_arbace_repl_A_const_92 any

var A_arbace_repl_A_const_93 *lang.Var

var A_arbace_repl_A_const_94 any

var A_arbace_repl_A_const_95 any

var A_arbace_repl_A_const_96 any

var A_arbace_repl_A_const_97 *lang.Var

var A_arbace_repl_A_const_98 *lang.Var

var A_arbace_repl_A_const_99 *lang.Var

var A_arbace_repl_A_const_100 *lang.Var

var A_arbace_repl_A_const_101 *lang.Var

var A_arbace_repl_A_const_102 *lang.Var

var A_arbace_repl_A_const_103 *lang.Var

var A_arbace_repl_A_const_104 any

var A_arbace_repl_A_const_105 *lang.Var

var A_arbace_repl_A_const_106 *lang.Var

var A_arbace_repl_A_const_107 *lang.Var

var A_arbace_repl_A_const_108 *lang.Keyword

var A_arbace_repl_A_const_109 *lang.Var

var A_arbace_repl_A_const_110 *lang.Var

var A_arbace_repl_A_const_111 any

var A_arbace_repl_A_const_112 *lang.Var

var A_arbace_repl_A_const_113 any

var A_arbace_repl_A_const_114 *lang.Var

var A_arbace_repl_A_const_115 *lang.Var

var A_arbace_repl_A_const_116 *jrt.Class

var A_arbace_repl_A_const_117 *lang.Var

var A_arbace_repl_A_const_118 *lang.Var

var A_arbace_repl_A_init jrt.ClassInit

func A_arbace_repl_A_Init() { if !A_arbace_repl_A_init.Done() { A_arbace_repl_A_init.Run(A_arbace_repl_A_clinit) } }

func A_arbace_repl_A_clinit() { A_arbace_repl_A_clinit_p0(); A_arbace_repl_A_clinit_p1(); A_arbace_repl_A_clinit_p2(); A_arbace_repl_A_clinit_p3(); A_arbace_repl_A_clinit_p4(); A_arbace_repl_A_clinit_p5(); A_arbace_repl_A_clinit_p6(); A_arbace_repl_A_clinit_p7(); A_arbace_repl_A_clinit_p8(); A_arbace_repl_A_clinit_p9() }

func A_arbace_repl_A_clinit_p0() { jrt.StartCheck(); A_arbace_repl_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 166); A_arbace_repl_A_const_0 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[47]); A_arbace_repl_A_const_1 = A_arbace_repl_A_const_pool.A[48]; A_arbace_repl_A_const_2 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[49]); A_arbace_repl_A_const_3 = A_arbace_repl_A_const_pool.A[50]; A_arbace_repl_A_const_4 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[51]); A_arbace_repl_A_const_5 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[52]); A_arbace_repl_A_const_6 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[53]); A_arbace_repl_A_const_7 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[54]); A_arbace_repl_A_const_8 = A_arbace_repl_A_const_pool.A[55]; A_arbace_repl_A_const_9 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[56]); A_arbace_repl_A_const_10 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[57]); A_arbace_repl_A_const_11 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[58]) }

func A_arbace_repl_A_clinit_p1() { A_arbace_repl_A_const_12 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[59]); A_arbace_repl_A_const_13 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[60]); A_arbace_repl_A_const_14 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[61]); A_arbace_repl_A_const_15 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[62]); A_arbace_repl_A_const_16 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[63]); A_arbace_repl_A_const_17 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[64]); A_arbace_repl_A_const_18 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[65]); A_arbace_repl_A_const_19 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[66]); A_arbace_repl_A_const_20 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[67]); A_arbace_repl_A_const_21 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[68]); A_arbace_repl_A_const_22 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[69]); A_arbace_repl_A_const_23 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[70]) }

func A_arbace_repl_A_clinit_p2() { A_arbace_repl_A_const_24 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[71]); A_arbace_repl_A_const_25 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[72]); A_arbace_repl_A_const_26 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[73]); A_arbace_repl_A_const_27 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[74]); A_arbace_repl_A_const_28 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[75]); A_arbace_repl_A_const_29 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[76]); A_arbace_repl_A_const_30 = A_arbace_repl_A_const_pool.A[77]; A_arbace_repl_A_const_31 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[78]); A_arbace_repl_A_const_32 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[79]); A_arbace_repl_A_const_33 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[80]); A_arbace_repl_A_const_34 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[81]); A_arbace_repl_A_const_35 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[82]) }

func A_arbace_repl_A_clinit_p3() { A_arbace_repl_A_const_36 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[83]); A_arbace_repl_A_const_37 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[84]); A_arbace_repl_A_const_38 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[85]); A_arbace_repl_A_const_39 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[86]); A_arbace_repl_A_const_40 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[87]); A_arbace_repl_A_const_41 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[88]); A_arbace_repl_A_const_42 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[89]); A_arbace_repl_A_const_43 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[90]); A_arbace_repl_A_const_44 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[91]); A_arbace_repl_A_const_45 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[92]); A_arbace_repl_A_const_46 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[93]); A_arbace_repl_A_const_47 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[94]) }

func A_arbace_repl_A_clinit_p4() { A_arbace_repl_A_const_48 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[95]); A_arbace_repl_A_const_49 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[96]); A_arbace_repl_A_const_50 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[97]); A_arbace_repl_A_const_51 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[98]); A_arbace_repl_A_const_52 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[99]); A_arbace_repl_A_const_53 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[100]); A_arbace_repl_A_const_54 = A_arbace_repl_A_const_pool.A[101]; A_arbace_repl_A_const_55 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[102]); A_arbace_repl_A_const_56 = A_arbace_repl_A_const_pool.A[103]; A_arbace_repl_A_const_57 = A_arbace_repl_A_const_pool.A[104]; A_arbace_repl_A_const_58 = A_arbace_repl_A_const_pool.A[105]; A_arbace_repl_A_const_59 = A_arbace_repl_A_const_pool.A[106]; A_arbace_repl_A_const_60 = A_arbace_repl_A_const_pool.A[107] }

func A_arbace_repl_A_clinit_p5() { A_arbace_repl_A_const_61 = A_arbace_repl_A_const_pool.A[108]; A_arbace_repl_A_const_62 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[109]); A_arbace_repl_A_const_63 = A_arbace_repl_A_const_pool.A[110]; A_arbace_repl_A_const_64 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[111]); A_arbace_repl_A_const_65 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[112]); A_arbace_repl_A_const_66 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[113]); A_arbace_repl_A_const_67 = A_arbace_repl_A_const_pool.A[114]; A_arbace_repl_A_const_68 = A_arbace_repl_A_const_pool.A[115]; A_arbace_repl_A_const_69 = A_arbace_repl_A_const_pool.A[116]; A_arbace_repl_A_const_70 = A_arbace_repl_A_const_pool.A[117]; A_arbace_repl_A_const_71 = A_arbace_repl_A_const_pool.A[118]; A_arbace_repl_A_const_72 = A_arbace_repl_A_const_pool.A[119]; A_arbace_repl_A_const_73 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[120]); A_arbace_repl_A_const_74 = jrt.Class_Cast(A_arbace_repl_A_const_pool.A[121]) }

func A_arbace_repl_A_clinit_p6() { A_arbace_repl_A_const_75 = A_arbace_repl_A_const_pool.A[122]; A_arbace_repl_A_const_76 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[123]); A_arbace_repl_A_const_77 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[124]); A_arbace_repl_A_const_78 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[125]); A_arbace_repl_A_const_79 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[126]); A_arbace_repl_A_const_80 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[127]); A_arbace_repl_A_const_81 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[128]); A_arbace_repl_A_const_82 = A_arbace_repl_A_const_pool.A[129]; A_arbace_repl_A_const_83 = A_arbace_repl_A_const_pool.A[130]; A_arbace_repl_A_const_84 = A_arbace_repl_A_const_pool.A[131]; A_arbace_repl_A_const_85 = A_arbace_repl_A_const_pool.A[132]; A_arbace_repl_A_const_86 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[133]); A_arbace_repl_A_const_87 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[134]) }

func A_arbace_repl_A_clinit_p7() { A_arbace_repl_A_const_88 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[135]); A_arbace_repl_A_const_89 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[136]); A_arbace_repl_A_const_90 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[137]); A_arbace_repl_A_const_91 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[138]); A_arbace_repl_A_const_92 = A_arbace_repl_A_const_pool.A[139]; A_arbace_repl_A_const_93 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[140]); A_arbace_repl_A_const_94 = A_arbace_repl_A_const_pool.A[141]; A_arbace_repl_A_const_95 = A_arbace_repl_A_const_pool.A[142]; A_arbace_repl_A_const_96 = A_arbace_repl_A_const_pool.A[143]; A_arbace_repl_A_const_97 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[144]); A_arbace_repl_A_const_98 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[145]); A_arbace_repl_A_const_99 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[146]); A_arbace_repl_A_const_100 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[147]) }

func A_arbace_repl_A_clinit_p8() { A_arbace_repl_A_const_101 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[148]); A_arbace_repl_A_const_102 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[149]); A_arbace_repl_A_const_103 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[150]); A_arbace_repl_A_const_104 = A_arbace_repl_A_const_pool.A[151]; A_arbace_repl_A_const_105 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[152]); A_arbace_repl_A_const_106 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[153]); A_arbace_repl_A_const_107 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[154]); A_arbace_repl_A_const_108 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[155]); A_arbace_repl_A_const_109 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[156]); A_arbace_repl_A_const_110 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[157]); A_arbace_repl_A_const_111 = A_arbace_repl_A_const_pool.A[158]; A_arbace_repl_A_const_112 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[159]) }

func A_arbace_repl_A_clinit_p9() { A_arbace_repl_A_const_113 = A_arbace_repl_A_const_pool.A[160]; A_arbace_repl_A_const_114 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[161]); A_arbace_repl_A_const_115 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[162]); A_arbace_repl_A_const_116 = jrt.Class_Cast(A_arbace_repl_A_const_pool.A[163]); A_arbace_repl_A_const_117 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[164]); A_arbace_repl_A_const_118 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[165]) }

func A_arbace_repl_A_New() *A_arbace_repl_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_A{}; t.Ctor(); return t }

func (t *A_arbace_repl_A) Ctor() {}

func (t *A_arbace_repl_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_A) GetClass__Class() *jrt.Class { return A_arbace_repl_A_class }

func (t *A_arbace_repl_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repl_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_A); return ok }

func A_arbace_repl_A_Cast(x any) *A_arbace_repl_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_A_class)) }; return v }



type A_arbace_repl_apropos_A struct{ j2g_header uint64 }

var A_arbace_repl_apropos_A_fn_class *jrt.Class



type A_arbace_repl_apropos_fn__1239000052_A struct{ j2g_header uint64; F_str_or_pattern any }

var A_arbace_repl_apropos_fn__1239000052_A_fn_class *jrt.Class



type A_arbace_repl_apropos_fn__1239000054_A struct{ j2g_header uint64; F_str_or_pattern any }

var A_arbace_repl_apropos_fn__1239000054_A_fn_class *jrt.Class



type A_arbace_repl_apropos_fn__1239000056_A struct{ j2g_header uint64; F_matches_QMARK_ any }

var A_arbace_repl_apropos_fn__1239000056_A_fn_class *jrt.Class



type A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A struct{ j2g_header uint64; F_ns_name any }

var A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_fn_class *jrt.Class



type A_arbace_repl_demunge_A struct{ j2g_header uint64 }

var A_arbace_repl_demunge_A_fn_class *jrt.Class



type A_arbace_repl_dir_A struct{ j2g_header uint64 }

var A_arbace_repl_dir_A_fn_class *jrt.Class



type A_arbace_repl_dir_fn_A struct{ j2g_header uint64 }

var A_arbace_repl_dir_fn_A_fn_class *jrt.Class



type A_arbace_repl_doc_A struct{ j2g_header uint64 }

var A_arbace_repl_doc_A_fn_class *jrt.Class



type A_arbace_repl_eval1239000004_A struct{ jrt.Object }

func A_arbace_repl_eval1239000004_A_New() *A_arbace_repl_eval1239000004_A { t := &A_arbace_repl_eval1239000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repl_eval1239000004_A) Ctor() {}

func (t *A_arbace_repl_eval1239000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_eval1239000004_A) GetClass__Class() *jrt.Class { return A_arbace_repl_eval1239000004_A_class }

func (t *A_arbace_repl_eval1239000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_eval1239000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repl_eval1239000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_eval1239000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_eval1239000004_A); return ok }

func A_arbace_repl_eval1239000004_A_Cast(x any) *A_arbace_repl_eval1239000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_eval1239000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_eval1239000004_A_class)) }; return v }



type A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A struct{ j2g_header uint64 }

var A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_fn_class *jrt.Class



type A_arbace_repl_eval1239000008_A struct{ jrt.Object }

func A_arbace_repl_eval1239000008_A_New() *A_arbace_repl_eval1239000008_A { t := &A_arbace_repl_eval1239000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repl_eval1239000008_A) Ctor() {}

func (t *A_arbace_repl_eval1239000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_eval1239000008_A) GetClass__Class() *jrt.Class { return A_arbace_repl_eval1239000008_A_class }

func (t *A_arbace_repl_eval1239000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_eval1239000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repl_eval1239000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_eval1239000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_eval1239000008_A); return ok }

func A_arbace_repl_eval1239000008_A_Cast(x any) *A_arbace_repl_eval1239000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_eval1239000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_eval1239000008_A_class)) }; return v }



type A_arbace_repl_eval1239000008_fn__1239000009_A struct{ j2g_header uint64 }

var A_arbace_repl_eval1239000008_fn__1239000009_A_fn_class *jrt.Class



type A_arbace_repl_find_doc_A struct{ j2g_header uint64 }

var A_arbace_repl_find_doc_A_fn_class *jrt.Class



type A_arbace_repl_find_doc_fn__1239000027_A struct{ j2g_header uint64 }

var A_arbace_repl_find_doc_fn__1239000027_A_fn_class *jrt.Class



type A_arbace_repl_namespace_doc_A struct{ j2g_header uint64 }

var A_arbace_repl_namespace_doc_A_fn_class *jrt.Class



type A_arbace_repl_print_doc_A struct{ j2g_header uint64 }

var A_arbace_repl_print_doc_A_fn_class *jrt.Class



type A_arbace_repl_pst_A struct{ j2g_header uint64 }

var A_arbace_repl_pst_A_fn_class *jrt.Class



type A_arbace_repl_pst_fn__1239000076_A struct{ j2g_header uint64 }

var A_arbace_repl_pst_fn__1239000076_A_fn_class *jrt.Class



type A_arbace_repl_root_cause_A struct{ j2g_header uint64 }

var A_arbace_repl_root_cause_A_fn_class *jrt.Class



type A_arbace_repl_set_break_handler_BANG__A struct{ j2g_header uint64 }

var A_arbace_repl_set_break_handler_BANG__A_fn_class *jrt.Class



type A_arbace_repl_set_break_handler_BANG__fn__1239000082_A struct{ j2g_header uint64; F_f any }

var A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_fn_class *jrt.Class



type A_arbace_repl_source_A struct{ j2g_header uint64 }

var A_arbace_repl_source_A_fn_class *jrt.Class



type A_arbace_repl_source_fn_A struct{ j2g_header uint64 }

var A_arbace_repl_source_fn_A_fn_class *jrt.Class



type A_arbace_repl_source_fn_fn__1239000039_A struct{ j2g_header uint64; F_text any }

var A_arbace_repl_source_fn_fn__1239000039_A_fn_class *jrt.Class



type A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A struct{ j2g_header uint64; F_this any }

var A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_fn_class *jrt.Class



type A_arbace_repl_special_doc_A struct{ j2g_header uint64 }

var A_arbace_repl_special_doc_A_fn_class *jrt.Class



type A_arbace_repl_stack_element_str_A struct{ j2g_header uint64 }

var A_arbace_repl_stack_element_str_A_fn_class *jrt.Class



type A_arbace_repl_thread_stopper_A struct{ j2g_header uint64 }

var A_arbace_repl_thread_stopper_A_fn_class *jrt.Class



type A_arbace_repl_thread_stopper_fn__1239000079_A struct{ j2g_header uint64; F_thread any }

var A_arbace_repl_thread_stopper_fn__1239000079_A_fn_class *jrt.Class
