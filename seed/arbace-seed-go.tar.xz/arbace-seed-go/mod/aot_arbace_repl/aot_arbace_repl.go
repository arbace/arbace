//line aot_arbace_repl.ae:1
package aot_arbace_repl

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_spec_alpha"
	"arbace/jrt"
	"arbace/lang"
)


func A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_New() *A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A{}; t.Ctor(); return t }
//line :11:1
func (t *A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A) Ctor() {}
//line :11:1
func (t *A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repl_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_1); lang.IFn_Cast(A_arbace_repl_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_3); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_5)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_6)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_7)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_8)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_9)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :11:1
func A_arbace_repl_eval1239000008_fn__1239000009_A_New() *A_arbace_repl_eval1239000008_fn__1239000009_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_eval1239000008_fn__1239000009_A{}; t.Ctor(); return t }
//line :11:1
func (t *A_arbace_repl_eval1239000008_fn__1239000009_A) Ctor() {}
//line :11:1
func (t *A_arbace_repl_eval1239000008_fn__1239000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_4.GetRawRoot__O()); var tmp2 any; var root_9 any = A_arbace_repl_A_const_5.GetRawRoot__O(); var linked_10 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_9, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_11 lang.IFn; if linked_10 == nil { ifn_11 = lang.IFn_Cast(root_9) } else { ifn_11 = nil }; var arg_12 any = A_arbace_repl_A_const_6; if linked_10 == nil { tmp2 = ifn_11.Invoke_O__O(arg_12) } else { tmp2 = linked_10.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_9, arg_12) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repl_A_const_7.GetRawRoot__O(), A_arbace_repl_A_const_8) }































































func A_arbace_repl_special_doc_A_New() *A_arbace_repl_special_doc_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_special_doc_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_repl_special_doc_A) Ctor() {}
//line :75:1
func (t *A_arbace_repl_special_doc_A) Invoke_O_O__O(self, name_symbol__0 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_9.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_repl_A_const_10.GetRawRoot__O()).Invoke_O__O(name_symbol__0); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp2 = or__1927000174__auto____2 } else { var tmp3 any; var root_19 any = A_arbace_repl_A_const_11.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = name_symbol__0; if linked_20 == nil { tmp3 = ifn_21.Invoke_O__O(arg_22) } else { tmp3 = linked_20.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_19, arg_22) }; tmp2 = lang.RT_Meta_O__IPersistentMap_NoInit(tmp3) }; return tmp1.Invoke_O_O_O_O_O__O(tmp2, A_arbace_repl_A_const_12, name_symbol__0, A_arbace_repl_A_const_13, jrt.Boolean_TRUE.Ref())
}


func A_arbace_repl_namespace_doc_A_New() *A_arbace_repl_namespace_doc_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_namespace_doc_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_repl_namespace_doc_A) Ctor() {}
//line :80:1
func (t *A_arbace_repl_namespace_doc_A) Invoke_O_O__O(self, nspace__0 any) any {
	var root_35 any = A_arbace_repl_A_const_9.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = lang.RT_Meta_O__IPersistentMap_NoInit(nspace__0); var arg_39 any = A_arbace_repl_A_const_12; var arg_40 any; var root_31 any = A_arbace_repl_A_const_14.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = nspace__0; if linked_32 == nil { arg_40 = ifn_33.Invoke_O__O(arg_34) } else { arg_40 = linked_32.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_31, arg_34) }; if linked_36 == nil { return ifn_37.Invoke_O_O_O__O(arg_38, arg_39, arg_40) } else { return linked_36.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_35, arg_38, arg_39, arg_40)
	} }
func A_arbace_repl_print_doc_A_New() *A_arbace_repl_print_doc_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_print_doc_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_repl_print_doc_A) Ctor() {}
//line :83:1
func (t *A_arbace_repl_print_doc_A) Invoke_O_O__O(self, p__1239000014__0 any) any { { var map__1239000015__2 any = p__1239000014__0; var map__1239000015__3 any; if lang.ISeq_InstanceOf(map__1239000015__2) { var tmp1 any; var root_41 any = A_arbace_repl_A_const_15.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = map__1239000015__2; if linked_42 == nil { tmp1 = ifn_43.Invoke_O__O(arg_44) } else { tmp1 = linked_42.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_41, arg_44) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_45 any = A_arbace_repl_A_const_16.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = map__1239000015__2; if linked_46 == nil { tmp2 = ifn_47.Invoke_O__O(arg_48) } else { tmp2 = linked_46.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_45, arg_48) }; map__1239000015__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_49 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = map__1239000015__2; if linked_50 == nil { tmp3 = ifn_51.Invoke_O__O(arg_52) } else { tmp3 = linked_50.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_49, arg_52) }; if jrt.J2g_Truth(tmp3) { var root_53 any = A_arbace_repl_A_const_18.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = map__1239000015__2; if linked_54 == nil { map__1239000015__3 = ifn_55.Invoke_O__O(arg_56) } else { map__1239000015__3 = linked_54.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_53, arg_56) } } else { map__1239000015__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1239000015__3 = map__1239000015__2 }; var m__4 any = map__1239000015__3; var n__5 any = lang.RT_Get_O_O__O_NoInit(map__1239000015__3, A_arbace_repl_A_const_19); var nm__6 any = lang.RT_Get_O_O__O_NoInit(map__1239000015__3, A_arbace_repl_A_const_12); var forms__7 any = lang.RT_Get_O_O__O_NoInit(map__1239000015__3, A_arbace_repl_A_const_20); var arglists__8 any = lang.RT_Get_O_O__O_NoInit(map__1239000015__3, A_arbace_repl_A_const_21); var special_form__9 any = lang.RT_Get_O_O__O_NoInit(map__1239000015__3, A_arbace_repl_A_const_13); var doc__10 any = lang.RT_Get_O_O__O_NoInit(map__1239000015__3, A_arbace_repl_A_const_22); var url__11 any = lang.RT_Get_O_O__O_NoInit(map__1239000015__3, A_arbace_repl_A_const_23); var macro__12 any = lang.RT_Get_O_O__O_NoInit(map__1239000015__3, A_arbace_repl_A_const_24); var spec__13 any = lang.RT_Get_O_O__O_NoInit(map__1239000015__3, A_arbace_repl_A_const_25)



	lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(Lit_11)
	var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()); var tmp5 any; var or__1927000174__auto____14 any = spec__13; if jrt.J2g_Truth(or__1927000174__auto____14) { tmp5 = or__1927000174__auto____14 } else { var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp7 *jrt.String; if jrt.J2g_Truth(n__5) { var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_12); var tmp9 any; var root_102 any = A_arbace_repl_A_const_14.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = n__5; if linked_103 == nil { tmp9 = ifn_104.Invoke_O__O(arg_105) } else { tmp9 = linked_103.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_102, arg_105) }; tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, tmp9, nil)) } else { tmp7 = nil }; tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7.Ref(), nm__6)).Ref() }; tmp4.Invoke_O__O(tmp5)
	if jrt.J2g_Truth(forms__7) { var seq_1239000017__14 any; var root_110 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_112 lang.IFn
		if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any = forms__7; if linked_111 == nil { seq_1239000017__14 = ifn_112.Invoke_O__O(arg_113) } else { seq_1239000017__14 = linked_111.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_110, arg_113) }
//line :89:1
		var chunk_1239000018__15 any; var count_1239000019__16 int64 = 0; var i_1239000020__17 int64 = 0; L1: for {
			if lang.Numbers_Lt_J_J__Z_NoInit(i_1239000020__17, count_1239000019__16) { var f__18 any = lang.Indexed_Cast(chunk_1239000018__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1239000020__17))
				lang.IFn_Cast(A_arbace_repl_A_const_36.GetRawRoot__O()).Invoke_O__O(Lit_13)
				lang.IFn_Cast(A_arbace_repl_A_const_34.GetRawRoot__O()).Invoke_O__O(f__18)
//line :90:1
				seq_1239000017__14, chunk_1239000018__15, count_1239000019__16, i_1239000020__17 = seq_1239000017__14, chunk_1239000018__15, count_1239000019__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1239000020__17); continue L1 } else { var temp__1927000414__auto____18 any; var root_114 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_116 lang.IFn; if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any = seq_1239000017__14; if linked_115 == nil { temp__1927000414__auto____18 = ifn_116.Invoke_O__O(arg_117) } else { temp__1927000414__auto____18 = linked_115.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_114, arg_117) }; if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_1239000017__19 any = temp__1927000414__auto____18; var tmp10 any; var root_118 any = A_arbace_repl_A_const_31.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_118, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_120 lang.IFn; if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = seq_1239000017__19; if linked_119 == nil { tmp10 = ifn_120.Invoke_O__O(arg_121) } else { tmp10 = linked_119.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_118, arg_121) }; if jrt.J2g_Truth(tmp10) { var c__1927000678__auto____20 any; var root_122 any = A_arbace_repl_A_const_32.GetRawRoot__O(); var linked_123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_122, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_124 lang.IFn; if linked_123 == nil { ifn_124 = lang.IFn_Cast(root_122) } else { ifn_124 = nil }; var arg_125 any = seq_1239000017__19; if linked_123 == nil { c__1927000678__auto____20 = ifn_124.Invoke_O__O(arg_125) } else { c__1927000678__auto____20 = linked_123.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_122, arg_125) }; var tmp11 any; var root_172 any = A_arbace_repl_A_const_37.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = seq_1239000017__19; if linked_173 == nil { tmp11 = ifn_174.Invoke_O__O(arg_175) } else { tmp11 = linked_173.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_172, arg_175) }; seq_1239000017__14, chunk_1239000018__15, count_1239000019__16, i_1239000020__17 = tmp11, c__1927000678__auto____20, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__20 any; var root_126 any = A_arbace_repl_A_const_18.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_128 lang.IFn; if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = seq_1239000017__19; if linked_127 == nil { f__20 = ifn_128.Invoke_O__O(arg_129) } else { f__20 = linked_127.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_126, arg_129) }
					lang.IFn_Cast(A_arbace_repl_A_const_36.GetRawRoot__O()).Invoke_O__O(Lit_13)
					lang.IFn_Cast(A_arbace_repl_A_const_34.GetRawRoot__O()).Invoke_O__O(f__20)
//line :90:1
					var tmp12 any; var root_184 any = A_arbace_repl_A_const_15.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = seq_1239000017__19; if linked_185 == nil { tmp12 = ifn_186.Invoke_O__O(arg_187) } else { tmp12 = linked_185.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_184, arg_187) }; seq_1239000017__14, chunk_1239000018__15, count_1239000019__16, i_1239000020__17 = tmp12, nil, 0, 0; continue L1 } } }
//line :89:1
			break L1
		}
	}

	if jrt.J2g_Truth(arglists__8) {
		lang.IFn_Cast(A_arbace_repl_A_const_34.GetRawRoot__O()).Invoke_O__O(arglists__8) }
	if jrt.J2g_Truth(special_form__9) {

		lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(Lit_14) } else {
//line :95:1
			if jrt.J2g_Truth(macro__12) {



				lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(Lit_15) } else {
//line :95:1
					if jrt.J2g_Truth(spec__13) {





						lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(Lit_16) } } }
	if jrt.J2g_Truth(doc__10) { lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O_O__O(Lit_17, doc__10) }
	if jrt.J2g_Truth(special_form__9) {
		var tmp13 any; var root_151 any = A_arbace_repl_A_const_35.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = m__4; var arg_155 any = A_arbace_repl_A_const_23; if linked_152 == nil { tmp13 = ifn_153.Invoke_O_O__O(arg_154, arg_155) } else { tmp13 = linked_152.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_151, arg_154, arg_155) }; if jrt.J2g_Truth(tmp13) {
			if jrt.J2g_Truth(url__11) {
				lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_18, nil), jrt.RefArrayOf(jrt.Object_class, nil, url__11)).Ref()) } } else {
					lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, nm__6)).Ref()) } }
	if jrt.J2g_Truth(n__5) { var temp__1927000414__auto____14 any; var root_74 any = A_arbace_repl_A_const_26.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, aot_arbace_spec_alpha.A_arbace_spec_alpha_get_spec_A_fn_class); var ifn_76 lang.IFn
		if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any; var root_69 any = A_arbace_repl_A_const_27.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any; var root_61 any = A_arbace_repl_A_const_28.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any; var root_57 any = A_arbace_repl_A_const_14.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = n__5; if linked_58 == nil { arg_64 = ifn_59.Invoke_O__O(arg_60) } else { arg_64 = linked_58.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_57, arg_60) }; if linked_62 == nil { arg_72 = ifn_63.Invoke_O__O(arg_64) } else { arg_72 = linked_62.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_61, arg_64) }; var arg_73 any; var root_65 any = A_arbace_repl_A_const_29.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_67 lang.IFn; if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = nm__6; if linked_66 == nil { arg_73 = ifn_67.Invoke_O__O(arg_68) } else { arg_73 = linked_66.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_65, arg_68) }; if linked_70 == nil { arg_77 = ifn_71.Invoke_O_O__O(arg_72, arg_73) } else { arg_77 = linked_70.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_69, arg_72, arg_73) }; if linked_75 == nil { temp__1927000414__auto____14 = ifn_76.Invoke_O__O(arg_77) } else { temp__1927000414__auto____14 = linked_75.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_get_spec_A).Invoke_O_O__O(root_74, arg_77) }; if jrt.J2g_Truth(temp__1927000414__auto____14) { var fnspec__15 any = temp__1927000414__auto____14
			lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(Lit_16)
//line :109:1
			var seq_1239000021__16 any; var root_78 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_80 lang.IFn

			if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = A_arbace_repl_A_const_30; if linked_79 == nil { seq_1239000021__16 = ifn_80.Invoke_O__O(arg_81) } else { seq_1239000021__16 = linked_79.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_78, arg_81) }
//line :109:1
			var chunk_1239000022__17 any; var count_1239000023__18 int64 = 0; var i_1239000024__19 int64 = 0; L2: for {

				if lang.Numbers_Lt_J_J__Z_NoInit(i_1239000024__19, count_1239000023__18) { var role__20 any = lang.Indexed_Cast(chunk_1239000022__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1239000024__19)); var temp__1927000414__auto____21 any = lang.RT_Get_O_O__O_NoInit(fnspec__15, role__20)
					if jrt.J2g_Truth(temp__1927000414__auto____21) { var spec__22 any = temp__1927000414__auto____21; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()); var tmp15 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_20); var tmp16 any; var root_192 any = A_arbace_repl_A_const_29.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_194 lang.IFn
						if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = role__20; if linked_193 == nil { tmp16 = ifn_194.Invoke_O__O(arg_195) } else { tmp16 = linked_193.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_192, arg_195) }; var tmp17 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp15, jrt.RefArrayOf(jrt.Object_class, tmp16, nil)).Ref(); var tmp18 any; var root_196 any = A_arbace_repl_A_const_38.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, aot_arbace_spec_alpha.A_arbace_spec_alpha_describe_A_fn_class); var ifn_198 lang.IFn; if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = spec__22; if linked_197 == nil { tmp18 = ifn_198.Invoke_O__O(arg_199) } else { tmp18 = linked_197.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_describe_A).Invoke_O_O__O(root_196, arg_199) }; tmp14.Invoke_O_O_O__O(Lit_17, tmp17, tmp18) }
//line :111:1
					seq_1239000021__16, chunk_1239000022__17, count_1239000023__18, i_1239000024__19 = seq_1239000021__16, chunk_1239000022__17, count_1239000023__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1239000024__19); continue L2 } else { var temp__1927000414__auto____20 any; var root_82 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = seq_1239000021__16; if linked_83 == nil { temp__1927000414__auto____20 = ifn_84.Invoke_O__O(arg_85) } else { temp__1927000414__auto____20 = linked_83.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_82, arg_85) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1239000021__21 any = temp__1927000414__auto____20; var tmp19 any; var root_86 any = A_arbace_repl_A_const_31.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_88 lang.IFn; if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any = seq_1239000021__21; if linked_87 == nil { tmp19 = ifn_88.Invoke_O__O(arg_89) } else { tmp19 = linked_87.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_86, arg_89) }; if jrt.J2g_Truth(tmp19) { var c__1927000678__auto____22 any; var root_90 any = A_arbace_repl_A_const_32.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = seq_1239000021__21; if linked_91 == nil { c__1927000678__auto____22 = ifn_92.Invoke_O__O(arg_93) } else { c__1927000678__auto____22 = linked_91.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_90, arg_93) }; var tmp20 any; var root_206 any = A_arbace_repl_A_const_37.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = seq_1239000021__21; if linked_207 == nil { tmp20 = ifn_208.Invoke_O__O(arg_209) } else { tmp20 = linked_207.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_206, arg_209) }; seq_1239000021__16, chunk_1239000022__17, count_1239000023__18, i_1239000024__19 = tmp20, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var role__22 any; var root_94 any = A_arbace_repl_A_const_18.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = seq_1239000021__21; if linked_95 == nil { role__22 = ifn_96.Invoke_O__O(arg_97) } else { role__22 = linked_95.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_94, arg_97) }; var temp__1927000414__auto____23 any = lang.RT_Get_O_O__O_NoInit(fnspec__15, role__22)
						if jrt.J2g_Truth(temp__1927000414__auto____23) { var spec__24 any = temp__1927000414__auto____23; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()); var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_20); var tmp23 any; var root_210 any = A_arbace_repl_A_const_29.GetRawRoot__O(); var linked_211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_210, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_212 lang.IFn
							if linked_211 == nil { ifn_212 = lang.IFn_Cast(root_210) } else { ifn_212 = nil }; var arg_213 any = role__22; if linked_211 == nil { tmp23 = ifn_212.Invoke_O__O(arg_213) } else { tmp23 = linked_211.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_210, arg_213) }; var tmp24 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, tmp23, nil)).Ref(); var tmp25 any; var root_214 any = A_arbace_repl_A_const_38.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, aot_arbace_spec_alpha.A_arbace_spec_alpha_describe_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = spec__24; if linked_215 == nil { tmp25 = ifn_216.Invoke_O__O(arg_217) } else { tmp25 = linked_215.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_describe_A).Invoke_O_O__O(root_214, arg_217) }; tmp21.Invoke_O_O_O__O(Lit_17, tmp24, tmp25) }
//line :111:1
						var tmp26 any; var root_224 any = A_arbace_repl_A_const_15.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = seq_1239000021__21; if linked_225 == nil { tmp26 = ifn_226.Invoke_O__O(arg_227) } else { tmp26 = linked_225.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_224, arg_227) }; seq_1239000021__16, chunk_1239000022__17, count_1239000023__18, i_1239000024__19 = tmp26, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :109:1
							return nil } } else {
//line :108:1
								return nil } }; /*line :83:1*/panic("j2g: unreachable") }































func A_arbace_repl_find_doc_A_New() *A_arbace_repl_find_doc_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_find_doc_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_repl_find_doc_A) Ctor() {}
//line :115:1
func (t *A_arbace_repl_find_doc_A) Invoke_O_O__O(self, re_string_or_pattern__0 any) any { { var re__2 any; var root_228 any = A_arbace_repl_A_const_39.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_re_pattern_A_fn_class); var ifn_230 lang.IFn




	if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = re_string_or_pattern__0; if linked_229 == nil { re__2 = ifn_230.Invoke_O__O(arg_231) } else { re__2 = linked_229.(*aot_arbace_core.A_arbace_core_re_pattern_A).Invoke_O_O__O(root_228, arg_231) }
//line :115:1
	var ms__3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_41.GetRawRoot__O()); var tmp3 any = A_arbace_repl_find_doc_fn__1239000027_A_New(); var tmp4 *jrt.Class
	var fncls__250 /*line :115:1*/*jrt.Class = A_arbace_repl_find_doc_fn__1239000027_A_fn_class





	if fncls__250 == nil { var fncls__250d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_repl_find_doc_fn__1239000027_A_fn_class = fncls__250d; tmp4 = fncls__250d } else { tmp4 = fncls__250 }; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 any; var root_251 any = A_arbace_repl_A_const_47.GetRawRoot__O(); var linked_252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_251, aot_arbace_core.A_arbace_core_all_ns_A_fn_class); var ifn_253 lang.IFn
	if linked_252 == nil { ifn_253 = lang.IFn_Cast(root_251) } else { ifn_253 = nil }; if linked_252 == nil { tmp6 = ifn_253.Invoke__O() } else { tmp6 = linked_252.(*aot_arbace_core.A_arbace_core_all_ns_A).Invoke_O__O(root_251) }
//line :121:1
	var tmp7 any = tmp2.Invoke_O_O__O(tmp5, tmp6); var tmp8 any; var root_262 any = A_arbace_repl_A_const_43.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_262, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_264 lang.IFn

	if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = A_arbace_repl_A_const_48.GetRawRoot__O(); var arg_266 any; var root_259 any = A_arbace_repl_A_const_47.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_259, aot_arbace_core.A_arbace_core_all_ns_A_fn_class); var ifn_261 lang.IFn; if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; if linked_260 == nil { arg_266 = ifn_261.Invoke__O() } else { arg_266 = linked_260.(*aot_arbace_core.A_arbace_core_all_ns_A).Invoke_O__O(root_259) }; if linked_263 == nil { tmp8 = ifn_264.Invoke_O_O__O(arg_265, arg_266) } else { tmp8 = linked_263.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_262, arg_265, arg_266) }
//line :121:1
	var tmp9 any = tmp8; var tmp10 any; var root_271 any = A_arbace_repl_A_const_43.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_271, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_273 lang.IFn


	if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = A_arbace_repl_A_const_49.GetRawRoot__O(); var arg_275 any; var root_267 any = A_arbace_repl_A_const_50.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = A_arbace_repl_A_const_10.GetRawRoot__O(); if linked_268 == nil { arg_275 = ifn_269.Invoke_O__O(arg_270) } else { arg_275 = linked_268.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_267, arg_270) }; if linked_272 == nil { tmp10 = ifn_273.Invoke_O_O__O(arg_274, arg_275) } else { tmp10 = linked_272.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_271, arg_274, arg_275) }
//line :121:1
	ms__3 = tmp1.Invoke_O_O_O__O(tmp7, tmp9, tmp10)
//line :115:1
	var seq_1239000029__4 any; var root_282 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_284 lang.IFn









	if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = ms__3; if linked_283 == nil { seq_1239000029__4 = ifn_284.Invoke_O__O(arg_285) } else { seq_1239000029__4 = linked_283.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_282, arg_285) }
//line :115:1
	var chunk_1239000030__5 any; var count_1239000031__6 int64 = 0; var i_1239000032__7 int64 = 0; L1: for {









		if lang.Numbers_Lt_J_J__Z_NoInit(i_1239000032__7, count_1239000031__6) { var m__8 any = lang.Indexed_Cast(chunk_1239000030__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1239000032__7)); var tmp11 any; var and__1927000168__auto____9 any = A_arbace_repl_A_const_22.Invoke_O__O(m__8)
			if jrt.J2g_Truth(and__1927000168__auto____9) { var or__1927000174__auto____10 any; var root_291 any = A_arbace_repl_A_const_51.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_293 lang.IFn
				if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any; var root_286 any = A_arbace_repl_A_const_52.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, aot_arbace_core.A_arbace_core_re_matcher_A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = re__2; var arg_290 any = A_arbace_repl_A_const_22.Invoke_O__O(m__8); if linked_287 == nil { arg_294 = ifn_288.Invoke_O_O__O(arg_289, arg_290) } else { arg_294 = linked_287.(*aot_arbace_core.A_arbace_core_re_matcher_A).Invoke_O_O_O__O(root_286, arg_289, arg_290) }; if linked_292 == nil { or__1927000174__auto____10 = ifn_293.Invoke_O__O(arg_294) } else { or__1927000174__auto____10 = linked_292.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O__O(root_291, arg_294) }; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp11 = or__1927000174__auto____10 } else {
					var root_304 any = A_arbace_repl_A_const_51.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_306 lang.IFn; if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any; var root_299 any = A_arbace_repl_A_const_52.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, aot_arbace_core.A_arbace_core_re_matcher_A_fn_class); var ifn_301 lang.IFn; if linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = re__2; var arg_303 any; var root_295 any = A_arbace_repl_A_const_28.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = A_arbace_repl_A_const_12.Invoke_O__O(m__8); if linked_296 == nil { arg_303 = ifn_297.Invoke_O__O(arg_298) } else { arg_303 = linked_296.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_295, arg_298) }; if linked_300 == nil { arg_307 = ifn_301.Invoke_O_O__O(arg_302, arg_303) } else { arg_307 = linked_300.(*aot_arbace_core.A_arbace_core_re_matcher_A).Invoke_O_O_O__O(root_299, arg_302, arg_303) }; if linked_305 == nil { tmp11 = ifn_306.Invoke_O__O(arg_307) } else { tmp11 = linked_305.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O__O(root_304, arg_307) } } } else {
//line :126:1
						tmp11 = and__1927000168__auto____9 }
//line :125:1
			if jrt.J2g_Truth(tmp11) {



				var root_346 any = A_arbace_repl_A_const_53.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, A_arbace_repl_print_doc_A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = m__8; if linked_347 == nil { ifn_348.Invoke_O__O(arg_349) } else { linked_347.(*A_arbace_repl_print_doc_A).Invoke_O_O__O(root_346, arg_349) }
//line :125:1
				seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, i_1239000032__7 = seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1239000032__7); continue L1 } else { seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, i_1239000032__7 = seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1239000032__7); continue L1 } } else { var temp__1927000414__auto____8 any; var root_308 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = seq_1239000029__4; if linked_309 == nil { temp__1927000414__auto____8 = ifn_310.Invoke_O__O(arg_311) } else { temp__1927000414__auto____8 = linked_309.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_308, arg_311) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1239000029__9 any = temp__1927000414__auto____8; var tmp12 any; var root_312 any = A_arbace_repl_A_const_31.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = seq_1239000029__9; if linked_313 == nil { tmp12 = ifn_314.Invoke_O__O(arg_315) } else { tmp12 = linked_313.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_312, arg_315) }; if jrt.J2g_Truth(tmp12) { var c__1927000678__auto____10 any; var root_316 any = A_arbace_repl_A_const_32.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = seq_1239000029__9; if linked_317 == nil { c__1927000678__auto____10 = ifn_318.Invoke_O__O(arg_319) } else { c__1927000678__auto____10 = linked_317.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_316, arg_319) }; var tmp13 any; var root_350 any = A_arbace_repl_A_const_37.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = seq_1239000029__9; if linked_351 == nil { tmp13 = ifn_352.Invoke_O__O(arg_353) } else { tmp13 = linked_351.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_350, arg_353) }; seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, i_1239000032__7 = tmp13, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var m__10 any; var root_320 any = A_arbace_repl_A_const_18.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = seq_1239000029__9; if linked_321 == nil { m__10 = ifn_322.Invoke_O__O(arg_323) } else { m__10 = linked_321.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_320, arg_323) }; var tmp14 any; var and__1927000168__auto____11 any = A_arbace_repl_A_const_22.Invoke_O__O(m__10)
					if jrt.J2g_Truth(and__1927000168__auto____11) { var or__1927000174__auto____12 any; var root_329 any = A_arbace_repl_A_const_51.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_331 lang.IFn
						if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any; var root_324 any = A_arbace_repl_A_const_52.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, aot_arbace_core.A_arbace_core_re_matcher_A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = re__2; var arg_328 any = A_arbace_repl_A_const_22.Invoke_O__O(m__10); if linked_325 == nil { arg_332 = ifn_326.Invoke_O_O__O(arg_327, arg_328) } else { arg_332 = linked_325.(*aot_arbace_core.A_arbace_core_re_matcher_A).Invoke_O_O_O__O(root_324, arg_327, arg_328) }; if linked_330 == nil { or__1927000174__auto____12 = ifn_331.Invoke_O__O(arg_332) } else { or__1927000174__auto____12 = linked_330.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O__O(root_329, arg_332) }; if jrt.J2g_Truth(or__1927000174__auto____12) { tmp14 = or__1927000174__auto____12 } else {
							var root_342 any = A_arbace_repl_A_const_51.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any; var root_337 any = A_arbace_repl_A_const_52.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, aot_arbace_core.A_arbace_core_re_matcher_A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = re__2; var arg_341 any; var root_333 any = A_arbace_repl_A_const_28.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_333, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = A_arbace_repl_A_const_12.Invoke_O__O(m__10); if linked_334 == nil { arg_341 = ifn_335.Invoke_O__O(arg_336) } else { arg_341 = linked_334.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_333, arg_336) }; if linked_338 == nil { arg_345 = ifn_339.Invoke_O_O__O(arg_340, arg_341) } else { arg_345 = linked_338.(*aot_arbace_core.A_arbace_core_re_matcher_A).Invoke_O_O_O__O(root_337, arg_340, arg_341) }; if linked_343 == nil { tmp14 = ifn_344.Invoke_O__O(arg_345) } else { tmp14 = linked_343.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O__O(root_342, arg_345) } } } else {
//line :126:1
								tmp14 = and__1927000168__auto____11 }
//line :125:1
					if jrt.J2g_Truth(tmp14) {



						var root_354 any = A_arbace_repl_A_const_53.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, A_arbace_repl_print_doc_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = m__10; if linked_355 == nil { ifn_356.Invoke_O__O(arg_357) } else { linked_355.(*A_arbace_repl_print_doc_A).Invoke_O_O__O(root_354, arg_357) }
//line :125:1
						var tmp15 any; var root_358 any = A_arbace_repl_A_const_15.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = seq_1239000029__9; if linked_359 == nil { tmp15 = ifn_360.Invoke_O__O(arg_361) } else { tmp15 = linked_359.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_358, arg_361) }; seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, i_1239000032__7 = tmp15, nil, 0, 0; continue L1 } else { var tmp16 any; var root_362 any = A_arbace_repl_A_const_15.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_364 lang.IFn; if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = seq_1239000029__9; if linked_363 == nil { tmp16 = ifn_364.Invoke_O__O(arg_365) } else { tmp16 = linked_363.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_362, arg_365) }; seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, i_1239000032__7 = tmp16, nil, 0, 0; continue L1 } } } else { return nil } } } }; /*line :115:1*/panic("j2g: unreachable") }





func A_arbace_repl_find_doc_fn__1239000027_A_New() *A_arbace_repl_find_doc_fn__1239000027_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_find_doc_fn__1239000027_A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_repl_find_doc_fn__1239000027_A) Ctor() {}
//line :121:1
func (t *A_arbace_repl_find_doc_fn__1239000027_A) Invoke_O_O__O(self, p1__1239000026_SHARP___1 any) any { var root_245 any = A_arbace_repl_A_const_42.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = A_arbace_repl_A_const_12; var arg_249 any; var root_240 any = A_arbace_repl_A_const_43.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = A_arbace_repl_A_const_44.GetRawRoot__O(); var arg_244 any; var root_236 any = A_arbace_repl_A_const_45.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any; var root_232 any = A_arbace_repl_A_const_46.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, aot_arbace_core.A_arbace_core_ns_interns_A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = p1__1239000026_SHARP___1; if linked_233 == nil { arg_239 = ifn_234.Invoke_O__O(arg_235) } else { arg_239 = linked_233.(*aot_arbace_core.A_arbace_core_ns_interns_A).Invoke_O_O__O(root_232, arg_235) }; if linked_237 == nil { arg_244 = ifn_238.Invoke_O__O(arg_239) } else { arg_244 = linked_237.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_236, arg_239) }; if linked_241 == nil { arg_249 = ifn_242.Invoke_O_O__O(arg_243, arg_244) } else { arg_249 = linked_241.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_240, arg_243, arg_244) }; if linked_246 == nil { return ifn_247.Invoke_O_O__O(arg_248, arg_249) } else { return linked_246.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_245, arg_248, arg_249) } }









func A_arbace_repl_doc_A_New() *A_arbace_repl_doc_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_doc_A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_repl_doc_A) Ctor() {}
//line :131:1
func (t *A_arbace_repl_doc_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, name__2 any) any { var temp__1927000408__auto____4 any = lang.IFn_Cast(A_arbace_repl_A_const_54).Invoke_O__O(name__2); if




	jrt.J2g_Truth(temp__1927000408__auto____4) { var special_name__5 any = temp__1927000408__auto____4; var root_407 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any; var root_402 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp2 any; var root_371 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any; var root_366 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_366, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_56); var arg_370 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_57); if linked_367 == nil { arg_374 = ifn_368.Invoke_O_O__O(arg_369, arg_370) } else { arg_374 = linked_367.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_366, arg_369, arg_370) }; if linked_372 == nil { tmp2 = ifn_373.Invoke_O__O(arg_374) } else { tmp2 = linked_372.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_371, arg_374) }; arg_405 = tmp1.Invoke_O__O(tmp2); var arg_406 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp4 any; var root_398 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any; var root_393 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_393, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_395 lang.IFn; if linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var arg_396 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp6 any; var root_380 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any; var root_375 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_375, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_56); var arg_379 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_58); if linked_376 == nil { arg_383 = ifn_377.Invoke_O_O__O(arg_378, arg_379) } else { arg_383 = linked_376.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_375, arg_378, arg_379) }; if linked_381 == nil { tmp6 = ifn_382.Invoke_O__O(arg_383) } else { tmp6 = linked_381.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_380, arg_383) }; arg_396 = tmp5.Invoke_O__O(tmp6); var arg_397 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp8 any; var root_389 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_389, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_391 lang.IFn; if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any; var root_384 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_384, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_386 lang.IFn; if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_59); var arg_388 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(special_name__5); if linked_385 == nil { arg_392 = ifn_386.Invoke_O_O__O(arg_387, arg_388) } else { arg_392 = linked_385.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_384, arg_387, arg_388) }; if linked_390 == nil { tmp8 = ifn_391.Invoke_O__O(arg_392) } else { tmp8 = linked_390.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_389, arg_392) }; arg_397 = tmp7.Invoke_O__O(tmp8); if linked_394 == nil { arg_401 = ifn_395.Invoke_O_O__O(arg_396, arg_397) } else { arg_401 = linked_394.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_393, arg_396, arg_397) }; if linked_399 == nil { tmp4 = ifn_400.Invoke_O__O(arg_401) } else { tmp4 = linked_399.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_398, arg_401) }; arg_406 = tmp3.Invoke_O__O(tmp4); if linked_403 == nil { arg_410 = ifn_404.Invoke_O_O__O(arg_405, arg_406) } else { arg_410 = linked_403.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_402, arg_405, arg_406) }; if linked_408 == nil { return ifn_409.Invoke_O__O(arg_410) } else { return linked_408.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_407, arg_410) } } else {

		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repl_A_const_10.GetRawRoot__O()).Invoke_O__O(name__2)) { var root_452 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_452, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_454 lang.IFn; if linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any; var root_447 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_447, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_449 lang.IFn; if linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp10 any; var root_416 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any; var root_411 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_411, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_413 lang.IFn; if linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_56); var arg_415 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_60); if linked_412 == nil { arg_419 = ifn_413.Invoke_O_O__O(arg_414, arg_415) } else { arg_419 = linked_412.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_411, arg_414, arg_415) }; if linked_417 == nil { tmp10 = ifn_418.Invoke_O__O(arg_419) } else { tmp10 = linked_417.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_416, arg_419) }; arg_450 = tmp9.Invoke_O__O(tmp10); var arg_451 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp12 any; var root_443 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_445 lang.IFn; if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any; var root_438 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp14 any; var root_425 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any; var root_420 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_56); var arg_424 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_61); if linked_421 == nil { arg_428 = ifn_422.Invoke_O_O__O(arg_423, arg_424) } else { arg_428 = linked_421.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_420, arg_423, arg_424) }; if linked_426 == nil { tmp14 = ifn_427.Invoke_O__O(arg_428) } else { tmp14 = linked_426.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_425, arg_428) }; arg_441 = tmp13.Invoke_O__O(tmp14); var arg_442 any; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp16 any; var root_434 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any; var root_429 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_429, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_431 lang.IFn; if linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_59); var arg_433 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(name__2); if linked_430 == nil { arg_437 = ifn_431.Invoke_O_O__O(arg_432, arg_433) } else { arg_437 = linked_430.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_429, arg_432, arg_433) }; if linked_435 == nil { tmp16 = ifn_436.Invoke_O__O(arg_437) } else { tmp16 = linked_435.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_434, arg_437) }; arg_442 = tmp15.Invoke_O__O(tmp16); if linked_439 == nil { arg_446 = ifn_440.Invoke_O_O__O(arg_441, arg_442) } else { arg_446 = linked_439.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_438, arg_441, arg_442) }; if linked_444 == nil { tmp12 = ifn_445.Invoke_O__O(arg_446) } else { tmp12 = linked_444.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_443, arg_446) }; arg_451 = tmp11.Invoke_O__O(tmp12); if linked_448 == nil { arg_455 = ifn_449.Invoke_O_O__O(arg_450, arg_451) } else { arg_455 = linked_448.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_447, arg_450, arg_451) }; if linked_453 == nil { return ifn_454.Invoke_O__O(arg_455) } else { return linked_453.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_452, arg_455) } } else { var tmp17 any; var root_456 any = A_arbace_repl_A_const_62.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_456, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_458 lang.IFn

			if linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; var arg_459 any = name__2; if linked_457 == nil { tmp17 = ifn_458.Invoke_O__O(arg_459) } else { tmp17 = linked_457.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_456, arg_459) }
//line :138:1
			if jrt.J2g_Truth(tmp17) { var root_512 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_512, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_514 lang.IFn; if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any; var root_507 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp19 any; var root_465 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_465, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_467 lang.IFn; if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any; var root_460 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_461 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_460, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_462 lang.IFn; if linked_461 == nil { ifn_462 = lang.IFn_Cast(root_460) } else { ifn_462 = nil }; var arg_463 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_56); var arg_464 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_63); if linked_461 == nil { arg_468 = ifn_462.Invoke_O_O__O(arg_463, arg_464) } else { arg_468 = linked_461.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_460, arg_463, arg_464) }; if linked_466 == nil { tmp19 = ifn_467.Invoke_O__O(arg_468) } else { tmp19 = linked_466.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_465, arg_468) }; arg_510 = tmp18.Invoke_O__O(tmp19); var arg_511 any; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp21 any; var root_502 any = A_arbace_repl_A_const_64.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_502, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_504 lang.IFn; if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any = A_arbace_repl_A_const_65.GetRawRoot__O(); var arg_506 any; var root_498 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()); var tmp23 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_25); var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp25 any; var root_474 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_476 lang.IFn; if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any; var root_469 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_59); var arg_473 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(name__2); if linked_470 == nil { arg_477 = ifn_471.Invoke_O_O__O(arg_472, arg_473) } else { arg_477 = linked_470.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_469, arg_472, arg_473) }; if linked_475 == nil { tmp25 = ifn_476.Invoke_O__O(arg_477) } else { tmp25 = linked_475.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_474, arg_477) }; var tmp26 any = tmp24.Invoke_O__O(tmp25); var tmp27 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_22); var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp29 any; var root_487 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_489 lang.IFn; if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any; var root_482 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_483 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_482, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_484 lang.IFn; if linked_483 == nil { ifn_484 = lang.IFn_Cast(root_482) } else { ifn_484 = nil }; var arg_485 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_59); var arg_486 any; var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp31 any; var root_478 any = A_arbace_repl_A_const_38.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_478, aot_arbace_spec_alpha.A_arbace_spec_alpha_describe_A_fn_class); var ifn_480 lang.IFn

				if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var arg_481 any = name__2; if linked_479 == nil { tmp31 = ifn_480.Invoke_O__O(arg_481) } else { tmp31 = linked_479.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_describe_A).Invoke_O_O__O(root_478, arg_481) }
//line :138:1
				arg_486 = tmp30.Invoke_O__O(tmp31); if linked_483 == nil { arg_490 = ifn_484.Invoke_O_O__O(arg_485, arg_486) } else { arg_490 = linked_483.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_482, arg_485, arg_486) }; if linked_488 == nil { tmp29 = ifn_489.Invoke_O__O(arg_490) } else { tmp29 = linked_488.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_487, arg_490) }; arg_501 = tmp22.Invoke_O_O_O_O__O(tmp23, tmp26, tmp27, tmp28.Invoke_O__O(tmp29)); if linked_499 == nil { arg_506 = ifn_500.Invoke_O__O(arg_501) } else { arg_506 = linked_499.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_498, arg_501) }; if linked_503 == nil { tmp21 = ifn_504.Invoke_O_O__O(arg_505, arg_506) } else { tmp21 = linked_503.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_502, arg_505, arg_506) }; arg_511 = tmp20.Invoke_O__O(tmp21); if linked_508 == nil { arg_515 = ifn_509.Invoke_O_O__O(arg_510, arg_511) } else { arg_515 = linked_508.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_507, arg_510, arg_511) }; if linked_513 == nil { return ifn_514.Invoke_O__O(arg_515) } else { return linked_513.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_512, arg_515) } } else { var tmp32 any; var root_516 any = A_arbace_repl_A_const_66.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_516, aot_arbace_core.A_arbace_core_find_ns_A_fn_class); var ifn_518 lang.IFn


					if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any = name__2; if linked_517 == nil { tmp32 = ifn_518.Invoke_O__O(arg_519) } else { tmp32 = linked_517.(*aot_arbace_core.A_arbace_core_find_ns_A).Invoke_O_O__O(root_516, arg_519) }
//line :138:1
					if jrt.J2g_Truth(tmp32) { var root_570 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_572 lang.IFn; if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any; var root_565 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_566 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_565, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_567 lang.IFn; if linked_566 == nil { ifn_567 = lang.IFn_Cast(root_565) } else { ifn_567 = nil }; var arg_568 any; var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp34 any; var root_525 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_527 lang.IFn; if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any; var root_520 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_520, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_522 lang.IFn; if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_56); var arg_524 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_67); if linked_521 == nil { arg_528 = ifn_522.Invoke_O_O__O(arg_523, arg_524) } else { arg_528 = linked_521.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_520, arg_523, arg_524) }; if linked_526 == nil { tmp34 = ifn_527.Invoke_O__O(arg_528) } else { tmp34 = linked_526.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_525, arg_528) }; arg_568 = tmp33.Invoke_O__O(tmp34); var arg_569 any; var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp36 any; var root_561 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_561, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_563 lang.IFn; if linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any; var root_556 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_556, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_558 lang.IFn; if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any; var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp38 any; var root_534 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_536 lang.IFn; if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any; var root_529 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_56); var arg_533 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_68); if linked_530 == nil { arg_537 = ifn_531.Invoke_O_O__O(arg_532, arg_533) } else { arg_537 = linked_530.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_529, arg_532, arg_533) }; if linked_535 == nil { tmp38 = ifn_536.Invoke_O__O(arg_537) } else { tmp38 = linked_535.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_534, arg_537) }; arg_559 = tmp37.Invoke_O__O(tmp38); var arg_560 any; var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp40 any; var root_552 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any; var root_547 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_547, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_69); var arg_551 any; var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp42 any; var root_543 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_543, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any; var root_538 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_538, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_540 lang.IFn; if linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_59); var arg_542 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(name__2); if linked_539 == nil { arg_546 = ifn_540.Invoke_O_O__O(arg_541, arg_542) } else { arg_546 = linked_539.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_538, arg_541, arg_542) }; if linked_544 == nil { tmp42 = ifn_545.Invoke_O__O(arg_546) } else { tmp42 = linked_544.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_543, arg_546) }; arg_551 = tmp41.Invoke_O__O(tmp42); if linked_548 == nil { arg_555 = ifn_549.Invoke_O_O__O(arg_550, arg_551) } else { arg_555 = linked_548.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_547, arg_550, arg_551) }; if linked_553 == nil { tmp40 = ifn_554.Invoke_O__O(arg_555) } else { tmp40 = linked_553.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_552, arg_555) }; arg_560 = tmp39.Invoke_O__O(tmp40); if linked_557 == nil { arg_564 = ifn_558.Invoke_O_O__O(arg_559, arg_560) } else { arg_564 = linked_557.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_556, arg_559, arg_560) }; if linked_562 == nil { tmp36 = ifn_563.Invoke_O__O(arg_564) } else { tmp36 = linked_562.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_561, arg_564) }; arg_569 = tmp35.Invoke_O__O(tmp36); if linked_566 == nil { arg_573 = ifn_567.Invoke_O_O__O(arg_568, arg_569) } else { arg_573 = linked_566.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_565, arg_568, arg_569) }; if linked_571 == nil { return ifn_572.Invoke_O__O(arg_573) } else { return linked_571.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_570, arg_573) } } else { var tmp43 any; var root_574 any = A_arbace_repl_A_const_11.GetRawRoot__O(); var linked_575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_574, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_576 lang.IFn



						if linked_575 == nil { ifn_576 = lang.IFn_Cast(root_574) } else { ifn_576 = nil }; var arg_577 any = name__2; if linked_575 == nil { tmp43 = ifn_576.Invoke_O__O(arg_577) } else { tmp43 = linked_575.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_574, arg_577) }
//line :138:1
						if jrt.J2g_Truth(tmp43) { var root_610 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any; var root_605 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_606 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_605, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_607 lang.IFn; if linked_606 == nil { ifn_607 = lang.IFn_Cast(root_605) } else { ifn_607 = nil }; var arg_608 any; var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp45 any; var root_583 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_585 lang.IFn; if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any; var root_578 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_579 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_578, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_580 lang.IFn; if linked_579 == nil { ifn_580 = lang.IFn_Cast(root_578) } else { ifn_580 = nil }; var arg_581 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_56); var arg_582 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_70); if linked_579 == nil { arg_586 = ifn_580.Invoke_O_O__O(arg_581, arg_582) } else { arg_586 = linked_579.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_578, arg_581, arg_582) }; if linked_584 == nil { tmp45 = ifn_585.Invoke_O__O(arg_586) } else { tmp45 = linked_584.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_583, arg_586) }; arg_608 = tmp44.Invoke_O__O(tmp45); var arg_609 any; var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp47 any; var root_601 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_601, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_603 lang.IFn; if linked_602 == nil { ifn_603 = lang.IFn_Cast(root_601) } else { ifn_603 = nil }; var arg_604 any; var root_596 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_596, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_598 lang.IFn; if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_71); var arg_600 any; var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp49 any; var root_592 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_592, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_594 lang.IFn; if linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any; var root_587 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_587, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_589 lang.IFn; if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_72); var arg_591 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(name__2); if linked_588 == nil { arg_595 = ifn_589.Invoke_O_O__O(arg_590, arg_591) } else { arg_595 = linked_588.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_587, arg_590, arg_591) }; if linked_593 == nil { tmp49 = ifn_594.Invoke_O__O(arg_595) } else { tmp49 = linked_593.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_592, arg_595) }; arg_600 = tmp48.Invoke_O__O(tmp49); if linked_597 == nil { arg_604 = ifn_598.Invoke_O_O__O(arg_599, arg_600) } else { arg_604 = linked_597.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_596, arg_599, arg_600) }; if linked_602 == nil { tmp47 = ifn_603.Invoke_O__O(arg_604) } else { tmp47 = linked_602.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_601, arg_604) }; arg_609 = tmp46.Invoke_O__O(tmp47); if linked_606 == nil { arg_613 = ifn_607.Invoke_O_O__O(arg_608, arg_609) } else { arg_613 = linked_606.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_605, arg_608, arg_609) }; if linked_611 == nil { return ifn_612.Invoke_O__O(arg_613) } else { return linked_611.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_610, arg_613) } } else { return nil } } } } } }








func A_arbace_repl_source_fn_A_New() *A_arbace_repl_source_fn_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_source_fn_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_repl_source_fn_A) Ctor() {}
//line :147:1
func (t *A_arbace_repl_source_fn_A) Invoke_O_O__O(self, x__0 any) any { var temp__1927000414__auto____2 any; var root_614 any = A_arbace_repl_A_const_11.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_616 lang.IFn; if








	linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = x__0; if linked_615 == nil { temp__1927000414__auto____2 = ifn_616.Invoke_O__O(arg_617) } else { temp__1927000414__auto____2 = linked_615.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_614, arg_617) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var v__3 any = temp__1927000414__auto____2; var tmp1 *lang.Keyword = A_arbace_repl_A_const_73; var temp__1927000414__auto____4 any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__3))
		if jrt.J2g_Truth(temp__1927000414__auto____4) { var filepath__5 any = temp__1927000414__auto____4; var tmp2 any = lang.RT_BaseLoader__ClassLoader_NoInit(); var tmp3 *jrt.Class = A_arbace_repl_A_const_74; var temp__1927000414__auto____6 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp2, tmp3, Lit_34, jrt.RefArrayOf(jrt.Object_class, filepath__5))
			if jrt.J2g_Truth(temp__1927000414__auto____6) { var strm__7 any = temp__1927000414__auto____6; var rdr__8 any = jrt.LineNumberReader_New_Reader(jrt.InputStreamReader_New_InputStream(jrt.InputStream_Cast(strm__7))); var tmp4 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var n__1927000701__auto____11 int64; var tmp5 jrt.Number_I; var tmp6 *lang.Keyword = A_arbace_repl_A_const_76; var na_622 any = tmp6.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__3))

				if jrt.Long_InstanceOf(na_622) { var n0_623 int64 = jrt.NN(jrt.Long_Cast(na_622)).LongValue__J(); if n0_623 == -9223372036854775808 { tmp5 = lang.Numbers_Dec_O__Number_NoInit(na_622) } else { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_623 - 1)) } } else { if jrt.Double_InstanceOf(na_622) { var n0_623_2 float64 = jrt.NN(jrt.Double_Cast(na_622)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_623_2 - 1.0)) } else { tmp5 = lang.Numbers_Dec_O__Number_NoInit(na_622) } }; n__1927000701__auto____11 = lang.RT_LongCast_O__J_NoInit(tmp5)
//line :158:1
				var ___12 int64 = 0; L1: for {

					if lang.Numbers_Lt_J_J__Z_NoInit(___12, n__1927000701__auto____11) { jrt.NN(jrt.LineNumberReader_Cast(rdr__8)).ReadLine__String(); ___12 = lang.Numbers_Unchecked_inc_J__J_NoInit(___12); continue L1 }
//line :158:1
					break L1 }; var text__11 any = jrt.StringBuilder_New(); var pbr__12 any; var p__840000142__auto____12 any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_35), jrt.RefArrayOf(jrt.Object_class, rdr__8)); var root_632 any = A_arbace_repl_A_const_77.GetRawRoot__O(); var linked_633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_632, aot_arbace_core.A_arbace_core_init_proxy_A_fn_class); var ifn_634 lang.IFn



				if linked_633 == nil { ifn_634 = lang.IFn_Cast(root_632) } else { ifn_634 = nil }; var arg_635 any = p__840000142__auto____12; var arg_636 any; var tmp7 any = A_arbace_repl_source_fn_fn__1239000039_A_New_O(text__11); var tmp8 *jrt.Class; var fncls__631 *jrt.Class = A_arbace_repl_source_fn_fn__1239000039_A_fn_class; if fncls__631 == nil { var fncls__631d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_repl_source_fn_fn__1239000039_A_fn_class = fncls__631d; tmp8 = fncls__631d } else { tmp8 = fncls__631 }; arg_636 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_36, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil))); if linked_633 == nil { ifn_634.Invoke_O_O__O(arg_635, arg_636) } else { linked_633.(*aot_arbace_core.A_arbace_core_init_proxy_A).Invoke_O_O_O__O(root_632, arg_635, arg_636) }
//line :158:1
				pbr__12 = p__840000142__auto____12; var read_opts__13 any







				if jrt.NN(jrt.String_Cast(filepath__5)).EndsWith_String__Z(Lit_38) { read_opts__13 = A_arbace_repl_A_const_75 } else { read_opts__13 = lang.PersistentArrayMap_EMPTY.Ref() }
				var tmp9 any = A_arbace_repl_A_const_79; if lang.Util_Equiv_O_O__Z_NoInit(tmp9, A_arbace_repl_A_const_80.Get__O()) { panic(jrt.Thrown(jrt.IllegalStateException_New_String(Lit_39))) } else {

					var root_637 any = A_arbace_repl_A_const_81.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_639 lang.IFn; if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any = read_opts__13; var arg_641 any = jrt.PushbackReader_New_Reader(jrt.Reader_Cast(pbr__12)); if linked_638 == nil { ifn_639.Invoke_O_O__O(arg_640, arg_641) } else { linked_638.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O__O(root_637, arg_640, arg_641) } }
				var root_618 any = A_arbace_repl_A_const_28.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_618, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_620 lang.IFn; if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; var arg_621 any = text__11; if linked_619 == nil { tmp4 = ifn_620.Invoke_O__O(arg_621) } else { tmp4 = linked_619.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_618, arg_621) } }; return nil }()
//line :159:1
				jrt.BufferedReader_Cast(rdr__8).Close__V()
//line :158:1
				if tmp10 != nil { panic(tmp10) }; return tmp4 } else { return nil } } else {
//line :157:1
					return nil } } else {
//line :156:1
						return nil } }





func A_arbace_repl_source_fn_fn__1239000039_A_New_O(p0 any) *A_arbace_repl_source_fn_fn__1239000039_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_source_fn_fn__1239000039_A{}; t.Ctor_O(p0); return t }
//line :162:1
func (t *A_arbace_repl_source_fn_fn__1239000039_A) Ctor_O(c__text any) { t.F_text = c__text }
//line :162:1
func (t *A_arbace_repl_source_fn_fn__1239000039_A) Invoke_O_O__O(self, this__1 any) any { var i__2 any; var root_625 any = A_arbace_repl_A_const_78.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_proxy_call_with_super_A_fn_class); var ifn_627 lang.IFn; if
											linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any; var tmp1 any = A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_New_O(this__1); var tmp2 *jrt.Class; var fncls__624 *jrt.Class = A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_fn_class; if fncls__624 == nil { var fncls__624d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_fn_class = fncls__624d; tmp2 = fncls__624d } else { tmp2 = fncls__624 }; arg_628 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_629 any = this__1; var arg_630 any = Lit_36; if linked_626 == nil { i__2 = ifn_627.Invoke_O_O_O__O(arg_628, arg_629, arg_630) } else { i__2 = linked_626.(*aot_arbace_core.A_arbace_core_proxy_call_with_super_A).Invoke_O_O_O_O__O(root_625, arg_628, arg_629, arg_630) }; var tmp3 /*line :164:1*/*jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_text); jrt.NN(tmp3).Append_C__StringBuilder(lang.RT_CharCast_O__C_NoInit(i__2)); return i__2 }
//line :163:1
func A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_New_O(p0 any) *A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A{}; t.Ctor_O(p0); return t }
//line :163:1
func (t *A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A) Ctor_O(c__this any) { t.F_this = c__this }
//line :163:1
func (t *A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A) Invoke_O__O(self any) any { return lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(t.F_this, Lit_36, false) }








func A_arbace_repl_source_A_New() *A_arbace_repl_source_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_source_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_repl_source_A) Ctor() {}
//line :172:1
func (t *A_arbace_repl_source_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, n__2 any) any { var root_684 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_686 lang.IFn; if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any; var root_679 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_82); var arg_683 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp2 any; var root_675 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_677 lang.IFn; if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()); var tmp4 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_83); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp6 any; var root_656 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_656, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_658 lang.IFn; if linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any; var root_651 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_652 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_651, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_653 lang.IFn; if linked_652 == nil { ifn_653 = lang.IFn_Cast(root_651) } else { ifn_653 = nil }; var arg_654 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_84); var arg_655 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp8 any; var root_647 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_647, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_649 lang.IFn; if linked_648 == nil { ifn_649 = lang.IFn_Cast(root_647) } else { ifn_649 = nil }; var arg_650 any; var root_642 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_59); var arg_646 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(n__2); if linked_643 == nil { arg_650 = ifn_644.Invoke_O_O__O(arg_645, arg_646) } else { arg_650 = linked_643.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_642, arg_645, arg_646) }; if linked_648 == nil { tmp8 = ifn_649.Invoke_O__O(arg_650) } else { tmp8 = linked_648.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_647, arg_650) }; arg_655 = tmp7.Invoke_O__O(tmp8); if linked_652 == nil { arg_659 = ifn_653.Invoke_O_O__O(arg_654, arg_655) } else { arg_659 = linked_652.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_651, arg_654, arg_655) }; if linked_657 == nil { tmp6 = ifn_658.Invoke_O__O(arg_659) } else { tmp6 = linked_657.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_656, arg_659) }; var tmp9 any = tmp5.Invoke_O__O(tmp6); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp11 any; var root_665 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any; var root_660 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_661 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_660, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_662 lang.IFn; if linked_661 == nil { ifn_662 = lang.IFn_Cast(root_660) } else { ifn_662 = nil }; var arg_663 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_85); var arg_664 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(Lit_33); if linked_661 == nil { arg_668 = ifn_662.Invoke_O_O__O(arg_663, arg_664) } else { arg_668 = linked_661.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_660, arg_663, arg_664) }; if linked_666 == nil { tmp11 = ifn_667.Invoke_O__O(arg_668) } else { tmp11 = linked_666.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_665, arg_668) }; arg_678 = tmp3.Invoke_O_O_O__O(tmp4, tmp9, tmp10.Invoke_O__O(tmp11)); if linked_676 == nil { tmp2 = ifn_677.Invoke_O__O(arg_678) } else { tmp2 = linked_676.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_675, arg_678) }; arg_683 = tmp1.Invoke_O__O(tmp2); if linked_680 == nil { arg_687 = ifn_681.Invoke_O_O__O(arg_682, arg_683) } else { arg_687 = linked_680.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_679, arg_682, arg_683) }; if linked_685 == nil { return ifn_686.Invoke_O__O(arg_687) } else { return linked_685.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_684, arg_687) } }








func A_arbace_repl_apropos_A_New() *A_arbace_repl_apropos_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_apropos_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_repl_apropos_A) Ctor() {}
//line :181:1
func (t *A_arbace_repl_apropos_A) Invoke_O_O__O(self, str_or_pattern__0 any) any { var matches_QMARK___2 any; if




	jrt.Pattern_InstanceOf(str_or_pattern__0) { var tmp1 any = A_arbace_repl_apropos_fn__1239000052_A_New_O(str_or_pattern__0); var tmp2 *jrt.Class; var fncls__697 *jrt.Class = A_arbace_repl_apropos_fn__1239000052_A_fn_class; if fncls__697 == nil { var fncls__697d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_repl_apropos_fn__1239000052_A_fn_class = fncls__697d; tmp2 = fncls__697d } else { tmp2 = fncls__697 }; matches_QMARK___2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) } else { var tmp3 any = A_arbace_repl_apropos_fn__1239000054_A_New_O(str_or_pattern__0); var tmp4 *jrt.Class; var fncls__706 *jrt.Class = A_arbace_repl_apropos_fn__1239000054_A_fn_class; if fncls__706 == nil { var fncls__706d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_repl_apropos_fn__1239000054_A_fn_class = fncls__706d; tmp4 = fncls__706d } else { tmp4 = fncls__706 }; matches_QMARK___2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil) }; var root_748 any =


	A_arbace_repl_A_const_86.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_748, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_750 lang.IFn; if linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; var arg_751 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_41.GetRawRoot__O()); var tmp6 any = A_arbace_repl_apropos_fn__1239000056_A_New_O(matches_QMARK___2); var tmp7 *jrt.Class; var fncls__739 *jrt.Class = A_arbace_repl_apropos_fn__1239000056_A_fn_class; if fncls__739 == nil { var fncls__739d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_repl_apropos_fn__1239000056_A_fn_class = fncls__739d; tmp7 = fncls__739d } else { tmp7 = fncls__739 }; var tmp8 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp9 any; var root_740 any = A_arbace_repl_A_const_47.GetRawRoot__O(); var linked_741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_740, aot_arbace_core.A_arbace_core_all_ns_A_fn_class); var ifn_742 lang.IFn; if



	linked_741 == nil { ifn_742 = lang.IFn_Cast(root_740) } else { ifn_742 = nil }; if linked_741 == nil { tmp9 = ifn_742.Invoke__O() } else { tmp9 = linked_741.(*aot_arbace_core.A_arbace_core_all_ns_A).Invoke_O__O(root_740) }; arg_751 = /*line :189:1*/tmp5.Invoke_O_O__O(tmp8, tmp9); if linked_749 == nil { return ifn_750.Invoke_O__O(arg_751) } else { return linked_749.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_748, arg_751) } }
//line :186:1
func A_arbace_repl_apropos_fn__1239000052_A_New_O(p0 any) *A_arbace_repl_apropos_fn__1239000052_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_apropos_fn__1239000052_A{}; t.Ctor_O(p0); return t }
//line :186:1
func (t *A_arbace_repl_apropos_fn__1239000052_A) Ctor_O(c__str_or_pattern any) { t.F_str_or_pattern = c__str_or_pattern }
//line :186:1
func (t *A_arbace_repl_apropos_fn__1239000052_A) Invoke_O_O__O(self, p1__1239000049_SHARP___1 any) any {
	var root_692 any = A_arbace_repl_A_const_51.GetRawRoot__O(); var linked_693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_692, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_694 lang.IFn; if linked_693 == nil { ifn_694 = lang.IFn_Cast(root_692) } else { ifn_694 = nil }; var arg_695 any = t.F_str_or_pattern; var arg_696 any; var root_688 any = A_arbace_repl_A_const_28.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_688, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_690 lang.IFn; if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any = p1__1239000049_SHARP___1; if linked_689 == nil { arg_696 = ifn_690.Invoke_O__O(arg_691) } else { arg_696 = linked_689.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_688, arg_691) }; if linked_693 == nil { return ifn_694.Invoke_O_O__O(arg_695, arg_696) } else { return linked_693.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_692, arg_695, arg_696) } }
//line :186:1
func A_arbace_repl_apropos_fn__1239000054_A_New_O(p0 any) *A_arbace_repl_apropos_fn__1239000054_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_apropos_fn__1239000054_A{}; t.Ctor_O(p0); return t }
//line :186:1
func (t *A_arbace_repl_apropos_fn__1239000054_A) Ctor_O(c__str_or_pattern any) { t.F_str_or_pattern = c__str_or_pattern }
//line :186:1
func (t *A_arbace_repl_apropos_fn__1239000054_A) Invoke_O_O__O(self, p1__1239000050_SHARP___1 any) any {

	var tmp1 any; var root_698 any = A_arbace_repl_A_const_28.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_698, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_700 lang.IFn; if linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any = p1__1239000050_SHARP___1; if linked_699 == nil { tmp1 = ifn_700.Invoke_O__O(arg_701) } else { tmp1 = linked_699.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_698, arg_701) }; var tmp2 *jrt.String = jrt.String_Cast(tmp1); var tmp3 any; var root_702 any = A_arbace_repl_A_const_28.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_704 lang.IFn; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any = t.F_str_or_pattern; if linked_703 == nil { tmp3 = ifn_704.Invoke_O__O(arg_705) } else { tmp3 = linked_703.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_702, arg_705) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(tmp2).Contains_CharSequence__Z(jrt.CharSequence_Cast(tmp3))).Ref() }
func A_arbace_repl_apropos_fn__1239000056_A_New_O(p0 any) *A_arbace_repl_apropos_fn__1239000056_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_apropos_fn__1239000056_A{}; t.Ctor_O(p0); return t }
//line :189:1
func (t *A_arbace_repl_apropos_fn__1239000056_A) Ctor_O(c__matches_QMARK_ any) { t.F_matches_QMARK_ = c__matches_QMARK_ }
//line :189:1
func (t *A_arbace_repl_apropos_fn__1239000056_A) Invoke_O_O__O(self, ns__1 any) any { var ns_name__2 any; var root_707 any = A_arbace_repl_A_const_28.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_709 lang.IFn; if
											linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any = ns__1; if linked_708 == nil { ns_name__2 = ifn_709.Invoke_O__O(arg_710) } else { ns_name__2 = linked_708.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_707, arg_710) }; var root_734 any =
											A_arbace_repl_A_const_43.GetRawRoot__O(); var linked_735 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_734, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_736 lang.IFn; if linked_735 == nil { ifn_736 = lang.IFn_Cast(root_734) } else { ifn_736 = nil }; var arg_737 any; var tmp1 any = A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_New_O(ns_name__2); var tmp2 *jrt.Class; var fncls__720 *jrt.Class = A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_fn_class; if fncls__720 == nil { var fncls__720d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_fn_class = fncls__720d; tmp2 = fncls__720d } else { tmp2 = fncls__720 }; arg_737 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_738 any; var root_729 any = A_arbace_repl_A_const_87.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_729, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_731 lang.IFn; if
											linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any = t.F_matches_QMARK_; var arg_733 any; var root_725 any = A_arbace_repl_A_const_50.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any; var root_721 any = A_arbace_repl_A_const_88.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, aot_arbace_core.A_arbace_core_ns_publics_A_fn_class); var ifn_723 lang.IFn; if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any = ns__1; if linked_722 == nil { arg_728 = ifn_723.Invoke_O__O(arg_724) } else { arg_728 = linked_722.(*aot_arbace_core.A_arbace_core_ns_publics_A).Invoke_O_O__O(root_721, arg_724) }; if linked_726 == nil { arg_733 = ifn_727.Invoke_O__O(arg_728) } else { arg_733 = linked_726.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_725, arg_728) }; if linked_730 == nil { arg_738 = ifn_731.Invoke_O_O__O(arg_732, arg_733) } else { arg_738 = linked_730.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_729, arg_732, arg_733) }; if /*line :191:1*/ linked_735 == nil { return ifn_736.Invoke_O_O__O(arg_737, arg_738) } else { return linked_735.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_734, arg_737, arg_738) } }
//line :191:1
func A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_New_O(p0 any) *A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A{}; t.Ctor_O(p0); return t }
//line :191:1
func (t *A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A) Ctor_O(c__ns_name any) { t.F_ns_name = c__ns_name }
//line :191:1
func (t *A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A) Invoke_O_O__O(self, p1__1239000051_SHARP___1 any) any { var root_715 any = A_arbace_repl_A_const_27.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_715, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_717 lang.IFn; if linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any = t.F_ns_name; var arg_719 any; var root_711 any = A_arbace_repl_A_const_28.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_711, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_713 lang.IFn; if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = p1__1239000051_SHARP___1; if linked_712 == nil { arg_719 = ifn_713.Invoke_O__O(arg_714) } else { arg_719 = linked_712.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_711, arg_714) }; if linked_716 == nil { return ifn_717.Invoke_O_O__O(arg_718, arg_719) } else { return linked_716.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_715, arg_718, arg_719) } }



func A_arbace_repl_dir_fn_A_New() *A_arbace_repl_dir_fn_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_dir_fn_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_repl_dir_fn_A) Ctor() {}
//line :195:1
func (t *A_arbace_repl_dir_fn_A) Invoke_O_O__O(self, ns__0 any) any {



	var root_769 any = A_arbace_repl_A_const_86.GetRawRoot__O(); var linked_770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_769, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_771 lang.IFn; if linked_770 == nil { ifn_771 = lang.IFn_Cast(root_769) } else { ifn_771 = nil }; var arg_772 any; var root_764 any = A_arbace_repl_A_const_43.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_764, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_766 lang.IFn; if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any = A_arbace_repl_A_const_18.GetRawRoot__O(); var arg_768 any; var root_760 any = A_arbace_repl_A_const_88.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, aot_arbace_core.A_arbace_core_ns_publics_A_fn_class); var ifn_762 lang.IFn; if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any; var root_756 any = A_arbace_repl_A_const_89.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, aot_arbace_core.A_arbace_core_the_ns_A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any; var tmp1 any; var root_752 any = A_arbace_repl_A_const_90.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_ns_aliases_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any = A_arbace_repl_A_const_91.Get__O(); if linked_753 == nil { tmp1 = ifn_754.Invoke_O__O(arg_755) } else { tmp1 = linked_753.(*aot_arbace_core.A_arbace_core_ns_aliases_A).Invoke_O_O__O(root_752, arg_755) }; arg_759 = lang.RT_Get_O_O_O__O_NoInit(tmp1, ns__0, ns__0); if linked_757 == nil { arg_763 = ifn_758.Invoke_O__O(arg_759) } else { arg_763 = linked_757.(*aot_arbace_core.A_arbace_core_the_ns_A).Invoke_O_O__O(root_756, arg_759) }; if linked_761 == nil { arg_768 = ifn_762.Invoke_O__O(arg_763) } else { arg_768 = linked_761.(*aot_arbace_core.A_arbace_core_ns_publics_A).Invoke_O_O__O(root_760, arg_763) }; if linked_765 == nil { arg_772 = ifn_766.Invoke_O_O__O(arg_767, arg_768) } else { arg_772 = linked_765.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_764, arg_767, arg_768) }; if linked_770 == nil { return ifn_771.Invoke_O__O(arg_772) } else { return linked_770.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_769, arg_772)
	} }
func A_arbace_repl_dir_A_New() *A_arbace_repl_dir_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_dir_A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_repl_dir_A) Ctor() {}
//line :201:1
func (t *A_arbace_repl_dir_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, nsname__2 any) any { var root_820 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_820, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_822 lang.IFn; if linked_821 == nil { ifn_822 = lang.IFn_Cast(root_820) } else { ifn_822 = nil }; var arg_823 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_92); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp4 any; var root_800 any = A_arbace_repl_A_const_64.GetRawRoot__O(); var linked_801 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_800, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_802 lang.IFn; if linked_801 == nil { ifn_802 = lang.IFn_Cast(root_800) } else { ifn_802 = nil }; var arg_803 any = A_arbace_repl_A_const_93.GetRawRoot__O(); var arg_804 any; var root_796 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_796, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_798 lang.IFn; if linked_797 == nil { ifn_798 = lang.IFn_Cast(root_796) } else { ifn_798 = nil }; var arg_799 any; var root_791 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_791, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_94); var arg_795 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp6 any; var root_787 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_787, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_789 lang.IFn; if linked_788 == nil { ifn_789 = lang.IFn_Cast(root_787) } else { ifn_789 = nil }; var arg_790 any; var root_782 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_783 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_782, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_784 lang.IFn; if linked_783 == nil { ifn_784 = lang.IFn_Cast(root_782) } else { ifn_784 = nil }; var arg_785 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_95); var arg_786 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp8 any; var root_778 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_778, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_780 lang.IFn; if linked_779 == nil { ifn_780 = lang.IFn_Cast(root_778) } else { ifn_780 = nil }; var arg_781 any; var root_773 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_774 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_773, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_775 lang.IFn; if linked_774 == nil { ifn_775 = lang.IFn_Cast(root_773) } else { ifn_775 = nil }; var arg_776 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_59); var arg_777 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(nsname__2); if linked_774 == nil { arg_781 = ifn_775.Invoke_O_O__O(arg_776, arg_777) } else { arg_781 = linked_774.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_773, arg_776, arg_777) }; if linked_779 == nil { tmp8 = ifn_780.Invoke_O__O(arg_781) } else { tmp8 = linked_779.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_778, arg_781) }; arg_786 = tmp7.Invoke_O__O(tmp8); if linked_783 == nil { arg_790 = ifn_784.Invoke_O_O__O(arg_785, arg_786) } else { arg_790 = linked_783.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_782, arg_785, arg_786) }; if linked_788 == nil { tmp6 = ifn_789.Invoke_O__O(arg_790) } else { tmp6 = linked_788.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_787, arg_790) }; arg_795 = tmp5.Invoke_O__O(tmp6); if linked_792 == nil { arg_799 = ifn_793.Invoke_O_O__O(arg_794, arg_795) } else { arg_799 = linked_792.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_791, arg_794, arg_795) }; if linked_797 == nil { arg_804 = ifn_798.Invoke_O__O(arg_799) } else { arg_804 = linked_797.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_796, arg_799) }; if linked_801 == nil { tmp4 = ifn_802.Invoke_O_O__O(arg_803, arg_804) } else { tmp4 = linked_801.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_800, arg_803, arg_804) }; var tmp9 any = tmp3.Invoke_O__O(tmp4); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp11 any; var root_810 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_810, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_812 lang.IFn; if linked_811 == nil { ifn_812 = lang.IFn_Cast(root_810) } else { ifn_812 = nil }; var arg_813 any; var root_805 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_806 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_805, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_807 lang.IFn; if linked_806 == nil { ifn_807 = lang.IFn_Cast(root_805) } else { ifn_807 = nil }; var arg_808 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_96); var arg_809 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_94); if linked_806 == nil { arg_813 = ifn_807.Invoke_O_O__O(arg_808, arg_809) } else { arg_813 = linked_806.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_805, arg_808, arg_809) }; if linked_811 == nil { tmp11 = ifn_812.Invoke_O__O(arg_813) } else { tmp11 = linked_811.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_810, arg_813) }; arg_823 = tmp1.Invoke_O_O_O__O(tmp2, tmp9, tmp10.Invoke_O__O(tmp11)); if linked_821 == nil { return ifn_822.Invoke_O__O(arg_823) } else { return linked_821.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_820, arg_823) } }





func A_arbace_repl_demunge_A_New() *A_arbace_repl_demunge_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_demunge_A{}; t.Ctor(); return t }
//line :207:1
func (t *A_arbace_repl_demunge_A) Ctor() {}
//line :207:1
func (t *A_arbace_repl_demunge_A) Invoke_O_O__O(self, fn_name__0 any) any {




	return lang.Compiler_Demunge_String__String_NoInit(jrt.String_Cast(fn_name__0)).Ref()
}
func A_arbace_repl_root_cause_A_New() *A_arbace_repl_root_cause_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_root_cause_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_repl_root_cause_A) Ctor() {}
//line :214:1
func (t *A_arbace_repl_root_cause_A) Invoke_O_O__O(self, t__0 any) any { { var cause__2 any = t__0; L1: for {





	var tmp1 any; var and__1927000168__auto____3 bool = lang.Compiler_CompilerException_InstanceOf(cause__2); if and__1927000168__auto____3 {
		var root_824 any = A_arbace_repl_A_const_97.GetRawRoot__O(); var linked_825 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_824, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_826 lang.IFn; if linked_825 == nil { ifn_826 = lang.IFn_Cast(root_824) } else { ifn_826 = nil }; var arg_827 any = lang.Compiler_CompilerException_Cast(cause__2).F_source.Ref(); var arg_828 any = Lit_26; if linked_825 == nil { tmp1 = ifn_826.Invoke_O_O__O(arg_827, arg_828) } else { tmp1 = linked_825.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_824, arg_827, arg_828) } } else {
//line :220:1
			tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) { return cause__2 } else { var temp__1927000408__auto____3 any = jrt.Throwable_Cast(cause__2).GetCause__Throwable()


				if jrt.J2g_Truth(temp__1927000408__auto____3) { var cause__4 any = temp__1927000408__auto____3
					cause__2 = cause__4; continue L1 } else {
//line :223:1
						return cause__2 } } } }; /*line :214:1*/panic("j2g: unreachable") }












func A_arbace_repl_stack_element_str_A_New() *A_arbace_repl_stack_element_str_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_stack_element_str_A{}; t.Ctor(); return t }
//line :227:1
func (t *A_arbace_repl_stack_element_str_A) Ctor() {}
//line :227:1
func (t *A_arbace_repl_stack_element_str_A) Invoke_O_O__O(self, el__0 any) any { var file__2 any = jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetFileName__String().Ref(); var clojure_fn_QMARK___3 any; var and__1927000168__auto____3 any = file__2; if




	jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 bool = jrt.NN(jrt.String_Cast(file__2)).EndsWith_String__Z(Lit_41); if or__1927000174__auto____4 { clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else { var or__1927000174__auto____5 bool = jrt.NN(jrt.String_Cast(file__2)).EndsWith_String__Z(Lit_42); if or__1927000174__auto____5 { clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool = jrt.NN(jrt.String_Cast(file__2)).EndsWith_String__Z(Lit_43); if or__1927000174__auto____6 { clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else {


		clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(file__2, Lit_26)).Ref() } } } } else {
//line :232:1
			clojure_fn_QMARK___3 = and__1927000168__auto____3 }; var tmp1 /*line :236:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_44, nil, Lit_20, nil, Lit_45); var tmp2 any; if jrt.J2g_Truth(clojure_fn_QMARK___3) {
				var root_829 any = A_arbace_repl_A_const_98.GetRawRoot__O(); var linked_830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_829, A_arbace_repl_demunge_A_fn_class); var ifn_831 lang.IFn; if linked_830 == nil { ifn_831 = lang.IFn_Cast(root_829) } else { ifn_831 = nil }; var arg_832 any = jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetClassName__String().Ref(); if linked_830 == nil { tmp2 = ifn_831.Invoke_O__O(arg_832) } else { tmp2 = linked_830.(*A_arbace_repl_demunge_A).Invoke_O_O__O(root_829, arg_832) } } else {
					tmp2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_46, nil), jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetClassName__String().Ref(), nil, jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetMethodName__String().Ref())).Ref() }; return /*line :236:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil, jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetFileName__String().Ref(), nil, jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetLineNumber__I()).Ref(), nil)).Ref() }




func A_arbace_repl_pst_A_New() *A_arbace_repl_pst_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_pst_A{}; t.Ctor(); return t }
//line :241:1
func (t *A_arbace_repl_pst_A) Ctor() {}
//line :241:1
func (t *A_arbace_repl_pst_A) Invoke_O_O_O__O(self, e__0, depth__1 any) any {










	var root_846 any = A_arbace_repl_A_const_101.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_848 lang.IFn; if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_65.GetRawRoot__O()); var tmp2 any = A_arbace_repl_A_const_102; var arg_849 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_repl_A_const_103.Get__O()); if linked_847 == nil { ifn_848.Invoke_O__O(arg_849) } else { linked_847.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_846, arg_849) }
//line :241:1
	var tmp3 any; tmp24 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)











		{ var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_104); var tmp5 *lang.Keyword = A_arbace_repl_A_const_108; var tmp6 any; var root_870 any = A_arbace_repl_A_const_106.GetRawRoot__O(); var linked_871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_870, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_872 lang.IFn
			if linked_871 == nil { ifn_872 = lang.IFn_Cast(root_870) } else { ifn_872 = nil }; var arg_873 any = e__0; if linked_871 == nil { tmp6 = ifn_872.Invoke_O__O(arg_873) } else { tmp6 = linked_871.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_870, arg_873) }
//line :253:1
			if jrt.J2g_Truth(tmp4.Invoke_O__O(tmp5.Invoke_O__O(tmp6))) {

				lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(Lit_21) }
			var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()); var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_17, nil, nil); var tmp9 any; var root_854 any = A_arbace_repl_A_const_105.GetRawRoot__O(); var linked_855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_854, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_856 lang.IFn; if linked_855 == nil { ifn_856 = lang.IFn_Cast(root_854) } else { ifn_856 = nil }; var arg_857 any = e__0; if linked_855 == nil { tmp9 = ifn_856.Invoke_O__O(arg_857) } else { tmp9 = linked_855.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_854, arg_857) }; var tmp10 any = jrt.NN(jrt.Class_Cast(tmp9)).GetSimpleName__String().Ref(); var tmp11 any = jrt.Throwable_Cast(e__0).GetMessage__String().Ref(); var tmp12 *jrt.String; var temp__1927000414__auto____9 any; var root_858 any = A_arbace_repl_A_const_106.GetRawRoot__O(); var linked_859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_858, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_860 lang.IFn

			if linked_859 == nil { ifn_860 = lang.IFn_Cast(root_858) } else { ifn_860 = nil }; var arg_861 any = e__0; if linked_859 == nil { temp__1927000414__auto____9 = ifn_860.Invoke_O__O(arg_861) } else { temp__1927000414__auto____9 = linked_859.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_858, arg_861) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var info__10 any = temp__1927000414__auto____9; tmp12 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repl_A_const_107.GetRawRoot__O()).Invoke_O__O(info__10))) } else { tmp12 = nil }
//line :256:1
			tmp7.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, tmp10, nil, tmp11, tmp12.Ref())).Ref())
//line :241:1
			var st__5 any = jrt.Throwable_Cast(e__0).GetStackTrace__StackTraceElement1().Ref(); var cause__6 any = jrt.Throwable_Cast(e__0).GetCause__Throwable(); var seq_1239000072__7 any; var root_885 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_885, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_887 lang.IFn



















			if linked_886 == nil { ifn_887 = lang.IFn_Cast(root_885) } else { ifn_887 = nil }; var arg_888 any; var root_880 any = A_arbace_repl_A_const_109.GetRawRoot__O(); var linked_881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_880, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_882 lang.IFn; if linked_881 == nil { ifn_882 = lang.IFn_Cast(root_880) } else { ifn_882 = nil }; var arg_883 any = depth__1; var arg_884 any; var root_875 any = A_arbace_repl_A_const_110.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_875, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_877 lang.IFn
			if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any; var tmp13 any = A_arbace_repl_pst_fn__1239000076_A_New(); var tmp14 *jrt.Class; var fncls__874 *jrt.Class = A_arbace_repl_pst_fn__1239000076_A_fn_class; if fncls__874 == nil { var fncls__874d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_repl_pst_fn__1239000076_A_fn_class = fncls__874d; tmp14 = fncls__874d } else { tmp14 = fncls__874 }; arg_878 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var arg_879 any = st__5; if linked_876 == nil { arg_884 = ifn_877.Invoke_O_O__O(arg_878, arg_879) } else { arg_884 = linked_876.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_875, arg_878, arg_879) }
//line :261:1
			if linked_881 == nil { arg_888 = ifn_882.Invoke_O_O__O(arg_883, arg_884) } else { arg_888 = linked_881.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_880, arg_883, arg_884) }; if linked_886 == nil { seq_1239000072__7 = ifn_887.Invoke_O__O(arg_888) } else { seq_1239000072__7 = linked_886.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_885, arg_888) }
//line :241:1
			var chunk_1239000073__8 any; var count_1239000074__9 int64 = 0; var i_1239000075__10 int64 = 0; L1: for {



















				if lang.Numbers_Lt_J_J__Z_NoInit(i_1239000075__10, count_1239000074__9) { var el__11 any = lang.Indexed_Cast(chunk_1239000073__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1239000075__10)); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()); var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_23, nil); var tmp17 any; var root_905 any = A_arbace_repl_A_const_112.GetRawRoot__O(); var linked_906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_905, A_arbace_repl_stack_element_str_A_fn_class); var ifn_907 lang.IFn


					if linked_906 == nil { ifn_907 = lang.IFn_Cast(root_905) } else { ifn_907 = nil }; var arg_908 any = el__11; if linked_906 == nil { tmp17 = ifn_907.Invoke_O__O(arg_908) } else { tmp17 = linked_906.(*A_arbace_repl_stack_element_str_A).Invoke_O_O__O(root_905, arg_908) }; tmp15.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp16, jrt.RefArrayOf(jrt.Object_class, nil, tmp17)).Ref())
//line :261:1
					seq_1239000072__7, chunk_1239000073__8, count_1239000074__9, i_1239000075__10 = seq_1239000072__7, chunk_1239000073__8, count_1239000074__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1239000075__10); continue L1 } else { var temp__1927000414__auto____11 any; var root_889 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_889, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_891 lang.IFn; if linked_890 == nil { ifn_891 = lang.IFn_Cast(root_889) } else { ifn_891 = nil }; var arg_892 any = seq_1239000072__7; if linked_890 == nil { temp__1927000414__auto____11 = ifn_891.Invoke_O__O(arg_892) } else { temp__1927000414__auto____11 = linked_890.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_889, arg_892) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1239000072__12 any = temp__1927000414__auto____11; var tmp18 any; var root_893 any = A_arbace_repl_A_const_31.GetRawRoot__O(); var linked_894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_893, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_895 lang.IFn; if linked_894 == nil { ifn_895 = lang.IFn_Cast(root_893) } else { ifn_895 = nil }; var arg_896 any = seq_1239000072__12; if linked_894 == nil { tmp18 = ifn_895.Invoke_O__O(arg_896) } else { tmp18 = linked_894.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_893, arg_896) }; if jrt.J2g_Truth(tmp18) { var c__1927000678__auto____13 any; var root_897 any = A_arbace_repl_A_const_32.GetRawRoot__O(); var linked_898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_897, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_899 lang.IFn; if linked_898 == nil { ifn_899 = lang.IFn_Cast(root_897) } else { ifn_899 = nil }; var arg_900 any = seq_1239000072__12; if linked_898 == nil { c__1927000678__auto____13 = ifn_899.Invoke_O__O(arg_900) } else { c__1927000678__auto____13 = linked_898.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_897, arg_900) }; var tmp19 any; var root_913 any = A_arbace_repl_A_const_37.GetRawRoot__O(); var linked_914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_913, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_915 lang.IFn; if linked_914 == nil { ifn_915 = lang.IFn_Cast(root_913) } else { ifn_915 = nil }; var arg_916 any = seq_1239000072__12; if linked_914 == nil { tmp19 = ifn_915.Invoke_O__O(arg_916) } else { tmp19 = linked_914.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_913, arg_916) }; seq_1239000072__7, chunk_1239000073__8, count_1239000074__9, i_1239000075__10 = tmp19, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var el__13 any; var root_901 any = A_arbace_repl_A_const_18.GetRawRoot__O(); var linked_902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_901, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_903 lang.IFn; if linked_902 == nil { ifn_903 = lang.IFn_Cast(root_901) } else { ifn_903 = nil }; var arg_904 any = seq_1239000072__12; if linked_902 == nil { el__13 = ifn_903.Invoke_O__O(arg_904) } else { el__13 = linked_902.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_901, arg_904)
					}

						var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()); var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_23, nil); var tmp22 any; var root_917 any = A_arbace_repl_A_const_112.GetRawRoot__O(); var linked_918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_917, A_arbace_repl_stack_element_str_A_fn_class); var ifn_919 lang.IFn; if linked_918 == nil { ifn_919 = lang.IFn_Cast(root_917) } else { ifn_919 = nil }; var arg_920 any = el__13; if linked_918 == nil { tmp22 = ifn_919.Invoke_O__O(arg_920) } else { tmp22 = linked_918.(*A_arbace_repl_stack_element_str_A).Invoke_O_O__O(root_917, arg_920) }; tmp20.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp21, jrt.RefArrayOf(jrt.Object_class, nil, tmp22)).Ref())
//line :261:1
						var tmp23 any; var root_925 any = A_arbace_repl_A_const_15.GetRawRoot__O(); var linked_926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_925, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_927 lang.IFn; if linked_926 == nil { ifn_927 = lang.IFn_Cast(root_925) } else { ifn_927 = nil }; var arg_928 any = seq_1239000072__12; if linked_926 == nil { tmp23 = ifn_927.Invoke_O__O(arg_928) } else { tmp23 = linked_926.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_925, arg_928) }; seq_1239000072__7, chunk_1239000073__8, count_1239000074__9, i_1239000075__10 = tmp23, nil, 0, 0; continue L1 } } }
//line :241:1
				break L1
			}






















			if jrt.J2g_Truth(cause__6) {
				lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(Lit_24)
				var root_833 any = A_arbace_repl_A_const_99.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_833, A_arbace_repl_pst_A_fn_class); var ifn_835 lang.IFn; if linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any = cause__6; var arg_837 any = lang.Numbers_Min_O_J__O_NoInit(depth__1, lang.Numbers_Add_J_J__J_NoInit(2, lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(jrt.Throwable_Cast(cause__6).GetStackTrace__StackTraceElement1().Ref())), int64(lang.RT_Count_O__I_NoInit(st__5))))); if linked_834 == nil { tmp3 = ifn_835.Invoke_O_O__O(arg_836, arg_837) } else { tmp3 = linked_834.(*A_arbace_repl_pst_A).Invoke_O_O_O__O(root_833, arg_836, arg_837) } } else {
//line :265:1
					tmp3 = nil } }
//line :241:1
		return nil }(); var root_838 any = A_arbace_repl_A_const_100.GetRawRoot__O(); var linked_839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_838, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_840 lang.IFn










	if linked_839 == nil { ifn_840 = lang.IFn_Cast(root_838) } else { ifn_840 = nil }; if linked_839 == nil { ifn_840.Invoke__O() } else { linked_839.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_838) }
//line :241:1
	if tmp24 != nil { panic(tmp24) }; return tmp3 }
//line :241:1
func (t *A_arbace_repl_pst_A) Invoke_O_O__O(self, e_or_depth__0 any) any {





	if jrt.Throwable_InstanceOf(e_or_depth__0) {
		var root_933 any = A_arbace_repl_A_const_99.GetRawRoot__O(); var linked_934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_933, A_arbace_repl_pst_A_fn_class); var ifn_935 lang.IFn; if linked_934 == nil { ifn_935 = lang.IFn_Cast(root_933) } else { ifn_935 = nil }; var arg_936 any = e_or_depth__0; var arg_937 any = A_arbace_repl_A_const_113; if linked_934 == nil { return ifn_935.Invoke_O_O__O(arg_936, arg_937) } else { return linked_934.(*A_arbace_repl_pst_A).Invoke_O_O_O__O(root_933, arg_936, arg_937) } } else {
//line :247:1
			var temp__1927000414__auto____2 any = A_arbace_repl_A_const_114.Get__O()

			if jrt.J2g_Truth(temp__1927000414__auto____2) { var e__3 any = temp__1927000414__auto____2; var root_942 any = A_arbace_repl_A_const_99.GetRawRoot__O(); var linked_943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_942, A_arbace_repl_pst_A_fn_class); var ifn_944 lang.IFn
				if linked_943 == nil { ifn_944 = lang.IFn_Cast(root_942) } else { ifn_944 = nil }; var arg_945 any; var root_938 any = A_arbace_repl_A_const_115.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_938, A_arbace_repl_root_cause_A_fn_class); var ifn_940 lang.IFn; if linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any = e__3; if linked_939 == nil { arg_945 = ifn_940.Invoke_O__O(arg_941) } else { arg_945 = linked_939.(*A_arbace_repl_root_cause_A).Invoke_O_O__O(root_938, arg_941) }; var arg_946 any = e_or_depth__0; if linked_943 == nil { return ifn_944.Invoke_O_O__O(arg_945, arg_946) } else { return linked_943.(*A_arbace_repl_pst_A).Invoke_O_O_O__O(root_942, arg_945, arg_946) } } else {
//line :249:1
					return nil } } }
//line :241:1
func (t *A_arbace_repl_pst_A) Invoke_O__O(self any) any {



	var root_947 any = A_arbace_repl_A_const_99.GetRawRoot__O(); var linked_948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_947, A_arbace_repl_pst_A_fn_class); var ifn_949 lang.IFn; if linked_948 == nil { ifn_949 = lang.IFn_Cast(root_947) } else { ifn_949 = nil }; var arg_950 any = A_arbace_repl_A_const_113; if linked_948 == nil { return ifn_949.Invoke_O__O(arg_950) } else { return linked_948.(*A_arbace_repl_pst_A).Invoke_O_O__O(root_947, arg_950)
	}
}














func A_arbace_repl_pst_fn__1239000076_A_New() *A_arbace_repl_pst_fn__1239000076_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_pst_fn__1239000076_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_repl_pst_fn__1239000076_A) Ctor() {}
//line :262:1
func (t *A_arbace_repl_pst_fn__1239000076_A) Invoke_O_O__O(self, p1__1239000071_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_111); return tmp1.Invoke_O__O(lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(p1__1239000071_SHARP___1, Lit_25, false)) }











func A_arbace_repl_thread_stopper_A_New() *A_arbace_repl_thread_stopper_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_thread_stopper_A{}; t.Ctor(); return t }
//line :274:1
func (t *A_arbace_repl_thread_stopper_A) Ctor() {}
//line :274:1
func (t *A_arbace_repl_thread_stopper_A) Invoke_O_O__O(self, thread__0 any) any {



	var tmp1 any = A_arbace_repl_thread_stopper_fn__1239000079_A_New_O(thread__0); var tmp2 *jrt.Class; var fncls__951 *jrt.Class = A_arbace_repl_thread_stopper_fn__1239000079_A_fn_class; if fncls__951 == nil { var fncls__951d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_repl_thread_stopper_fn__1239000079_A_fn_class = fncls__951d; tmp2 = fncls__951d } else { tmp2 = fncls__951 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :274:1
func (t *A_arbace_repl_thread_stopper_A) Invoke_O__O(self any) any {


	var root_952 any = A_arbace_repl_A_const_117.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_952, A_arbace_repl_thread_stopper_A_fn_class); var ifn_954 lang.IFn; if linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any = jrt.Thread_CurrentThread__Thread(); if linked_953 == nil { return ifn_954.Invoke_O__O(arg_955) } else { return linked_953.(*A_arbace_repl_thread_stopper_A).Invoke_O_O__O(root_952, arg_955) } }
func A_arbace_repl_thread_stopper_fn__1239000079_A_New_O(p0 any) *A_arbace_repl_thread_stopper_fn__1239000079_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_thread_stopper_fn__1239000079_A{}; t.Ctor_O(p0); return t }
//line :278:1
func (t *A_arbace_repl_thread_stopper_fn__1239000079_A) Ctor_O(c__thread any) { t.F_thread = c__thread }
//line :278:1
func (t *A_arbace_repl_thread_stopper_fn__1239000079_A) Invoke_O_O__O(self, msg__1 any) any { var tmp1 any = t.F_thread; var tmp2 *jrt.Class = A_arbace_repl_A_const_116; return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(tmp1, Lit_48, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(tmp2, jrt.RefArrayOf(jrt.Object_class, msg__1)))) }

func A_arbace_repl_set_break_handler_BANG__A_New() *A_arbace_repl_set_break_handler_BANG__A { A_arbace_repl_A_Init(); t := &A_arbace_repl_set_break_handler_BANG__A{}; t.Ctor(); return t }
//line :280:1
func (t *A_arbace_repl_set_break_handler_BANG__A) Ctor() {}
//line :280:1
func (t *A_arbace_repl_set_break_handler_BANG__A) Invoke_O_O__O(self, f__0 any) any {





	var tmp1 *jrt.Class = lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_27); var tmp2 any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_27), jrt.RefArrayOf(jrt.Object_class, Lit_29)); var tmp3 any; var p__840000142__auto____2 any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_30), jrt.RefArrayOf(jrt.Object_class)); var root_957 any = A_arbace_repl_A_const_77.GetRawRoot__O(); var linked_958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_957, aot_arbace_core.A_arbace_core_init_proxy_A_fn_class); var ifn_959 lang.IFn

	if linked_958 == nil { ifn_959 = lang.IFn_Cast(root_957) } else { ifn_959 = nil }; var arg_960 any = p__840000142__auto____2; var arg_961 any; var tmp4 any = A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_New_O(f__0); var tmp5 *jrt.Class; var fncls__956 *jrt.Class = A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_fn_class; if fncls__956 == nil { var fncls__956d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_fn_class = fncls__956d; tmp5 = fncls__956d } else { tmp5 = fncls__956 }; arg_961 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_28, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil))); if linked_958 == nil { ifn_959.Invoke_O_O__O(arg_960, arg_961) } else { linked_958.(*aot_arbace_core.A_arbace_core_init_proxy_A).Invoke_O_O_O__O(root_957, arg_960, arg_961) }
//line :286:1
	tmp3 = p__840000142__auto____2; return lang.Reflector_InvokeStaticMethod_Class_String_O1__O(tmp1, Lit_28, jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3)) }
//line :280:1
func (t *A_arbace_repl_set_break_handler_BANG__A) Invoke_O__O(self any) any {



	var root_965 any = A_arbace_repl_A_const_118.GetRawRoot__O(); var linked_966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_965, A_arbace_repl_set_break_handler_BANG__A_fn_class); var ifn_967 lang.IFn; if linked_966 == nil { ifn_967 = lang.IFn_Cast(root_965) } else { ifn_967 = nil }; var arg_968 any; var root_962 any = A_arbace_repl_A_const_117.GetRawRoot__O(); var linked_963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_962, A_arbace_repl_thread_stopper_A_fn_class); var ifn_964 lang.IFn; if linked_963 == nil { ifn_964 = lang.IFn_Cast(root_962) } else { ifn_964 = nil }; if linked_963 == nil { arg_968 = ifn_964.Invoke__O() } else { arg_968 = linked_963.(*A_arbace_repl_thread_stopper_A).Invoke_O__O(root_962) }; if linked_966 == nil { return ifn_967.Invoke_O__O(arg_968) } else { return linked_966.(*A_arbace_repl_set_break_handler_BANG__A).Invoke_O_O__O(root_965, arg_968)
	}
}

func A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_New_O(p0 any) *A_arbace_repl_set_break_handler_BANG__fn__1239000082_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_set_break_handler_BANG__fn__1239000082_A{}; t.Ctor_O(p0); return t }
//line :288:1
func (t *A_arbace_repl_set_break_handler_BANG__fn__1239000082_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :288:1
func (t *A_arbace_repl_set_break_handler_BANG__fn__1239000082_A) Invoke_O_O_O__O(self, this__1, signal__2 any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(t.F_f); return tmp1.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_32, nil), jrt.RefArrayOf(jrt.Object_class, nil, signal__2)).Ref())
}












type A_arbace_repl_A struct{ jrt.Object }

var A_arbace_repl_A_const_pool *jrt.RefArray

var A_arbace_repl_A_const_0 *lang.Var

var A_arbace_repl_A_const_1 any

var A_arbace_repl_A_const_2 *lang.Var

var A_arbace_repl_A_const_3 any

var A_arbace_repl_A_const_4 *lang.Var

var A_arbace_repl_A_const_5 *lang.Var

var A_arbace_repl_A_const_6 *lang.Var

var A_arbace_repl_A_const_7 *lang.Var

var A_arbace_repl_A_const_8 any

var A_arbace_repl_A_const_9 *lang.Var

var A_arbace_repl_A_const_10 *lang.Var

var A_arbace_repl_A_const_11 *lang.Var

var A_arbace_repl_A_const_12 *lang.Keyword

var A_arbace_repl_A_const_13 *lang.Keyword

var A_arbace_repl_A_const_14 *lang.Var

var A_arbace_repl_A_const_15 *lang.Var

var A_arbace_repl_A_const_16 *lang.Var

var A_arbace_repl_A_const_17 *lang.Var

var A_arbace_repl_A_const_18 *lang.Var

var A_arbace_repl_A_const_19 *lang.Keyword

var A_arbace_repl_A_const_20 *lang.Keyword

var A_arbace_repl_A_const_21 *lang.Keyword

var A_arbace_repl_A_const_22 *lang.Keyword

var A_arbace_repl_A_const_23 *lang.Keyword

var A_arbace_repl_A_const_24 *lang.Keyword

var A_arbace_repl_A_const_25 *lang.Keyword

var A_arbace_repl_A_const_26 *lang.Var

var A_arbace_repl_A_const_27 *lang.Var

var A_arbace_repl_A_const_28 *lang.Var

var A_arbace_repl_A_const_29 *lang.Var

var A_arbace_repl_A_const_30 any

var A_arbace_repl_A_const_31 *lang.Var

var A_arbace_repl_A_const_32 *lang.Var

var A_arbace_repl_A_const_33 *lang.Var

var A_arbace_repl_A_const_34 *lang.Var

var A_arbace_repl_A_const_35 *lang.Var

var A_arbace_repl_A_const_36 *lang.Var

var A_arbace_repl_A_const_37 *lang.Var

var A_arbace_repl_A_const_38 *lang.Var

var A_arbace_repl_A_const_39 *lang.Var

var A_arbace_repl_A_const_40 *lang.Var

var A_arbace_repl_A_const_41 *lang.Var

var A_arbace_repl_A_const_42 *lang.Var

var A_arbace_repl_A_const_43 *lang.Var

var A_arbace_repl_A_const_44 *lang.Var

var A_arbace_repl_A_const_45 *lang.Var

var A_arbace_repl_A_const_46 *lang.Var

var A_arbace_repl_A_const_47 *lang.Var

var A_arbace_repl_A_const_48 *lang.Var

var A_arbace_repl_A_const_49 *lang.Var

var A_arbace_repl_A_const_50 *lang.Var

var A_arbace_repl_A_const_51 *lang.Var

var A_arbace_repl_A_const_52 *lang.Var

var A_arbace_repl_A_const_53 *lang.Var

var A_arbace_repl_A_const_54 any

var A_arbace_repl_A_const_55 *lang.Var

var A_arbace_repl_A_const_56 any

var A_arbace_repl_A_const_57 any

var A_arbace_repl_A_const_58 any

var A_arbace_repl_A_const_59 any

var A_arbace_repl_A_const_60 any

var A_arbace_repl_A_const_61 any

var A_arbace_repl_A_const_62 *lang.Var

var A_arbace_repl_A_const_63 any

var A_arbace_repl_A_const_64 *lang.Var

var A_arbace_repl_A_const_65 *lang.Var

var A_arbace_repl_A_const_66 *lang.Var

var A_arbace_repl_A_const_67 any

var A_arbace_repl_A_const_68 any

var A_arbace_repl_A_const_69 any

var A_arbace_repl_A_const_70 any

var A_arbace_repl_A_const_71 any

var A_arbace_repl_A_const_72 any

var A_arbace_repl_A_const_73 *lang.Keyword

var A_arbace_repl_A_const_74 *jrt.Class

var A_arbace_repl_A_const_75 any

var A_arbace_repl_A_const_76 *lang.Keyword

var A_arbace_repl_A_const_77 *lang.Var

var A_arbace_repl_A_const_78 *lang.Var

var A_arbace_repl_A_const_79 *lang.Keyword

var A_arbace_repl_A_const_80 *lang.Var

var A_arbace_repl_A_const_81 *lang.Var

var A_arbace_repl_A_const_82 any

var A_arbace_repl_A_const_83 any

var A_arbace_repl_A_const_84 any

var A_arbace_repl_A_const_85 any

var A_arbace_repl_A_const_86 *lang.Var

var A_arbace_repl_A_const_87 *lang.Var

var A_arbace_repl_A_const_88 *lang.Var

var A_arbace_repl_A_const_89 *lang.Var

var A_arbace_repl_A_const_90 *lang.Var

var A_arbace_repl_A_const_91 *lang.Var

var A_arbace_repl_A_const_92 any

var A_arbace_repl_A_const_93 *lang.Var

var A_arbace_repl_A_const_94 any

var A_arbace_repl_A_const_95 any

var A_arbace_repl_A_const_96 any

var A_arbace_repl_A_const_97 *lang.Var

var A_arbace_repl_A_const_98 *lang.Var

var A_arbace_repl_A_const_99 *lang.Var

var A_arbace_repl_A_const_100 *lang.Var

var A_arbace_repl_A_const_101 *lang.Var

var A_arbace_repl_A_const_102 *lang.Var

var A_arbace_repl_A_const_103 *lang.Var

var A_arbace_repl_A_const_104 any

var A_arbace_repl_A_const_105 *lang.Var

var A_arbace_repl_A_const_106 *lang.Var

var A_arbace_repl_A_const_107 *lang.Var

var A_arbace_repl_A_const_108 *lang.Keyword

var A_arbace_repl_A_const_109 *lang.Var

var A_arbace_repl_A_const_110 *lang.Var

var A_arbace_repl_A_const_111 any

var A_arbace_repl_A_const_112 *lang.Var

var A_arbace_repl_A_const_113 any

var A_arbace_repl_A_const_114 *lang.Var

var A_arbace_repl_A_const_115 *lang.Var

var A_arbace_repl_A_const_116 *jrt.Class

var A_arbace_repl_A_const_117 *lang.Var

var A_arbace_repl_A_const_118 *lang.Var

var A_arbace_repl_A_init jrt.ClassInit

func A_arbace_repl_A_Init() { if !A_arbace_repl_A_init.Done() { A_arbace_repl_A_init.Run(A_arbace_repl_A_clinit) } }

func A_arbace_repl_A_clinit() { A_arbace_repl_A_clinit_p0(); A_arbace_repl_A_clinit_p1(); A_arbace_repl_A_clinit_p2(); A_arbace_repl_A_clinit_p3(); A_arbace_repl_A_clinit_p4(); A_arbace_repl_A_clinit_p5(); A_arbace_repl_A_clinit_p6(); A_arbace_repl_A_clinit_p7(); A_arbace_repl_A_clinit_p8(); A_arbace_repl_A_clinit_p9() }

func A_arbace_repl_A_clinit_p0() { jrt.StartCheck(); A_arbace_repl_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 166); A_arbace_repl_A_const_0 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[47]); A_arbace_repl_A_const_1 = A_arbace_repl_A_const_pool.A[48]; A_arbace_repl_A_const_2 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[49]); A_arbace_repl_A_const_3 = A_arbace_repl_A_const_pool.A[50]; A_arbace_repl_A_const_4 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[51]); A_arbace_repl_A_const_5 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[52]); A_arbace_repl_A_const_6 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[53]); A_arbace_repl_A_const_7 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[54]); A_arbace_repl_A_const_8 = A_arbace_repl_A_const_pool.A[55]; A_arbace_repl_A_const_9 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[56]); A_arbace_repl_A_const_10 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[57]); A_arbace_repl_A_const_11 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[58]) }

func A_arbace_repl_A_clinit_p1() { A_arbace_repl_A_const_12 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[59]); A_arbace_repl_A_const_13 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[60]); A_arbace_repl_A_const_14 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[61]); A_arbace_repl_A_const_15 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[62]); A_arbace_repl_A_const_16 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[63]); A_arbace_repl_A_const_17 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[64]); A_arbace_repl_A_const_18 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[65]); A_arbace_repl_A_const_19 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[66]); A_arbace_repl_A_const_20 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[67]); A_arbace_repl_A_const_21 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[68]); A_arbace_repl_A_const_22 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[69]); A_arbace_repl_A_const_23 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[70]) }

func A_arbace_repl_A_clinit_p2() { A_arbace_repl_A_const_24 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[71]); A_arbace_repl_A_const_25 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[72]); A_arbace_repl_A_const_26 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[73]); A_arbace_repl_A_const_27 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[74]); A_arbace_repl_A_const_28 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[75]); A_arbace_repl_A_const_29 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[76]); A_arbace_repl_A_const_30 = A_arbace_repl_A_const_pool.A[77]; A_arbace_repl_A_const_31 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[78]); A_arbace_repl_A_const_32 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[79]); A_arbace_repl_A_const_33 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[80]); A_arbace_repl_A_const_34 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[81]); A_arbace_repl_A_const_35 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[82]) }

func A_arbace_repl_A_clinit_p3() { A_arbace_repl_A_const_36 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[83]); A_arbace_repl_A_const_37 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[84]); A_arbace_repl_A_const_38 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[85]); A_arbace_repl_A_const_39 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[86]); A_arbace_repl_A_const_40 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[87]); A_arbace_repl_A_const_41 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[88]); A_arbace_repl_A_const_42 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[89]); A_arbace_repl_A_const_43 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[90]); A_arbace_repl_A_const_44 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[91]); A_arbace_repl_A_const_45 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[92]); A_arbace_repl_A_const_46 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[93]); A_arbace_repl_A_const_47 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[94]) }

func A_arbace_repl_A_clinit_p4() { A_arbace_repl_A_const_48 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[95]); A_arbace_repl_A_const_49 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[96]); A_arbace_repl_A_const_50 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[97]); A_arbace_repl_A_const_51 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[98]); A_arbace_repl_A_const_52 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[99]); A_arbace_repl_A_const_53 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[100]); A_arbace_repl_A_const_54 = A_arbace_repl_A_const_pool.A[101]; A_arbace_repl_A_const_55 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[102]); A_arbace_repl_A_const_56 = A_arbace_repl_A_const_pool.A[103]; A_arbace_repl_A_const_57 = A_arbace_repl_A_const_pool.A[104]; A_arbace_repl_A_const_58 = A_arbace_repl_A_const_pool.A[105]; A_arbace_repl_A_const_59 = A_arbace_repl_A_const_pool.A[106]; A_arbace_repl_A_const_60 = A_arbace_repl_A_const_pool.A[107] }

func A_arbace_repl_A_clinit_p5() { A_arbace_repl_A_const_61 = A_arbace_repl_A_const_pool.A[108]; A_arbace_repl_A_const_62 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[109]); A_arbace_repl_A_const_63 = A_arbace_repl_A_const_pool.A[110]; A_arbace_repl_A_const_64 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[111]); A_arbace_repl_A_const_65 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[112]); A_arbace_repl_A_const_66 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[113]); A_arbace_repl_A_const_67 = A_arbace_repl_A_const_pool.A[114]; A_arbace_repl_A_const_68 = A_arbace_repl_A_const_pool.A[115]; A_arbace_repl_A_const_69 = A_arbace_repl_A_const_pool.A[116]; A_arbace_repl_A_const_70 = A_arbace_repl_A_const_pool.A[117]; A_arbace_repl_A_const_71 = A_arbace_repl_A_const_pool.A[118]; A_arbace_repl_A_const_72 = A_arbace_repl_A_const_pool.A[119]; A_arbace_repl_A_const_73 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[120]); A_arbace_repl_A_const_74 = jrt.Class_Cast(A_arbace_repl_A_const_pool.A[121]) }

func A_arbace_repl_A_clinit_p6() { A_arbace_repl_A_const_75 = A_arbace_repl_A_const_pool.A[122]; A_arbace_repl_A_const_76 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[123]); A_arbace_repl_A_const_77 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[124]); A_arbace_repl_A_const_78 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[125]); A_arbace_repl_A_const_79 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[126]); A_arbace_repl_A_const_80 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[127]); A_arbace_repl_A_const_81 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[128]); A_arbace_repl_A_const_82 = A_arbace_repl_A_const_pool.A[129]; A_arbace_repl_A_const_83 = A_arbace_repl_A_const_pool.A[130]; A_arbace_repl_A_const_84 = A_arbace_repl_A_const_pool.A[131]; A_arbace_repl_A_const_85 = A_arbace_repl_A_const_pool.A[132]; A_arbace_repl_A_const_86 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[133]); A_arbace_repl_A_const_87 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[134]) }

func A_arbace_repl_A_clinit_p7() { A_arbace_repl_A_const_88 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[135]); A_arbace_repl_A_const_89 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[136]); A_arbace_repl_A_const_90 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[137]); A_arbace_repl_A_const_91 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[138]); A_arbace_repl_A_const_92 = A_arbace_repl_A_const_pool.A[139]; A_arbace_repl_A_const_93 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[140]); A_arbace_repl_A_const_94 = A_arbace_repl_A_const_pool.A[141]; A_arbace_repl_A_const_95 = A_arbace_repl_A_const_pool.A[142]; A_arbace_repl_A_const_96 = A_arbace_repl_A_const_pool.A[143]; A_arbace_repl_A_const_97 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[144]); A_arbace_repl_A_const_98 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[145]); A_arbace_repl_A_const_99 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[146]); A_arbace_repl_A_const_100 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[147]) }

func A_arbace_repl_A_clinit_p8() { A_arbace_repl_A_const_101 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[148]); A_arbace_repl_A_const_102 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[149]); A_arbace_repl_A_const_103 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[150]); A_arbace_repl_A_const_104 = A_arbace_repl_A_const_pool.A[151]; A_arbace_repl_A_const_105 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[152]); A_arbace_repl_A_const_106 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[153]); A_arbace_repl_A_const_107 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[154]); A_arbace_repl_A_const_108 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[155]); A_arbace_repl_A_const_109 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[156]); A_arbace_repl_A_const_110 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[157]); A_arbace_repl_A_const_111 = A_arbace_repl_A_const_pool.A[158]; A_arbace_repl_A_const_112 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[159]) }

func A_arbace_repl_A_clinit_p9() { A_arbace_repl_A_const_113 = A_arbace_repl_A_const_pool.A[160]; A_arbace_repl_A_const_114 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[161]); A_arbace_repl_A_const_115 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[162]); A_arbace_repl_A_const_116 = jrt.Class_Cast(A_arbace_repl_A_const_pool.A[163]); A_arbace_repl_A_const_117 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[164]); A_arbace_repl_A_const_118 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[165]) }

func A_arbace_repl_A_New() *A_arbace_repl_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_A{}; t.Ctor(); return t }

func (t *A_arbace_repl_A) Ctor() {}

func (t *A_arbace_repl_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_A) GetClass__Class() *jrt.Class { return A_arbace_repl_A_class }

func (t *A_arbace_repl_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repl_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_A); return ok }

func A_arbace_repl_A_Cast(x any) *A_arbace_repl_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_A_class)) }; return v }



type A_arbace_repl_apropos_A struct{ j2g_header uint64 }

var A_arbace_repl_apropos_A_fn_class *jrt.Class



type A_arbace_repl_apropos_fn__1239000052_A struct{ j2g_header uint64; F_str_or_pattern any }

var A_arbace_repl_apropos_fn__1239000052_A_fn_class *jrt.Class



type A_arbace_repl_apropos_fn__1239000054_A struct{ j2g_header uint64; F_str_or_pattern any }

var A_arbace_repl_apropos_fn__1239000054_A_fn_class *jrt.Class



type A_arbace_repl_apropos_fn__1239000056_A struct{ j2g_header uint64; F_matches_QMARK_ any }

var A_arbace_repl_apropos_fn__1239000056_A_fn_class *jrt.Class



type A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A struct{ j2g_header uint64; F_ns_name any }

var A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_fn_class *jrt.Class



type A_arbace_repl_demunge_A struct{ j2g_header uint64 }

var A_arbace_repl_demunge_A_fn_class *jrt.Class



type A_arbace_repl_dir_A struct{ j2g_header uint64 }

var A_arbace_repl_dir_A_fn_class *jrt.Class



type A_arbace_repl_dir_fn_A struct{ j2g_header uint64 }

var A_arbace_repl_dir_fn_A_fn_class *jrt.Class



type A_arbace_repl_doc_A struct{ j2g_header uint64 }

var A_arbace_repl_doc_A_fn_class *jrt.Class



type A_arbace_repl_eval1239000004_A struct{ jrt.Object }

func A_arbace_repl_eval1239000004_A_New() *A_arbace_repl_eval1239000004_A { t := &A_arbace_repl_eval1239000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repl_eval1239000004_A) Ctor() {}

func (t *A_arbace_repl_eval1239000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_eval1239000004_A) GetClass__Class() *jrt.Class { return A_arbace_repl_eval1239000004_A_class }

func (t *A_arbace_repl_eval1239000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_eval1239000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repl_eval1239000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_eval1239000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_eval1239000004_A); return ok }

func A_arbace_repl_eval1239000004_A_Cast(x any) *A_arbace_repl_eval1239000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_eval1239000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_eval1239000004_A_class)) }; return v }



type A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A struct{ j2g_header uint64 }

var A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_fn_class *jrt.Class



type A_arbace_repl_eval1239000008_A struct{ jrt.Object }

func A_arbace_repl_eval1239000008_A_New() *A_arbace_repl_eval1239000008_A { t := &A_arbace_repl_eval1239000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repl_eval1239000008_A) Ctor() {}

func (t *A_arbace_repl_eval1239000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_eval1239000008_A) GetClass__Class() *jrt.Class { return A_arbace_repl_eval1239000008_A_class }

func (t *A_arbace_repl_eval1239000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_eval1239000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repl_eval1239000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_eval1239000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_eval1239000008_A); return ok }

func A_arbace_repl_eval1239000008_A_Cast(x any) *A_arbace_repl_eval1239000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_eval1239000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_eval1239000008_A_class)) }; return v }



type A_arbace_repl_eval1239000008_fn__1239000009_A struct{ j2g_header uint64 }

var A_arbace_repl_eval1239000008_fn__1239000009_A_fn_class *jrt.Class



type A_arbace_repl_find_doc_A struct{ j2g_header uint64 }

var A_arbace_repl_find_doc_A_fn_class *jrt.Class



type A_arbace_repl_find_doc_fn__1239000027_A struct{ j2g_header uint64 }

var A_arbace_repl_find_doc_fn__1239000027_A_fn_class *jrt.Class



type A_arbace_repl_namespace_doc_A struct{ j2g_header uint64 }

var A_arbace_repl_namespace_doc_A_fn_class *jrt.Class



type A_arbace_repl_print_doc_A struct{ j2g_header uint64 }

var A_arbace_repl_print_doc_A_fn_class *jrt.Class



type A_arbace_repl_pst_A struct{ j2g_header uint64 }

var A_arbace_repl_pst_A_fn_class *jrt.Class



type A_arbace_repl_pst_fn__1239000076_A struct{ j2g_header uint64 }

var A_arbace_repl_pst_fn__1239000076_A_fn_class *jrt.Class



type A_arbace_repl_root_cause_A struct{ j2g_header uint64 }

var A_arbace_repl_root_cause_A_fn_class *jrt.Class



type A_arbace_repl_set_break_handler_BANG__A struct{ j2g_header uint64 }

var A_arbace_repl_set_break_handler_BANG__A_fn_class *jrt.Class



type A_arbace_repl_set_break_handler_BANG__fn__1239000082_A struct{ j2g_header uint64; F_f any }

var A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_fn_class *jrt.Class



type A_arbace_repl_source_A struct{ j2g_header uint64 }

var A_arbace_repl_source_A_fn_class *jrt.Class



type A_arbace_repl_source_fn_A struct{ j2g_header uint64 }

var A_arbace_repl_source_fn_A_fn_class *jrt.Class



type A_arbace_repl_source_fn_fn__1239000039_A struct{ j2g_header uint64; F_text any }

var A_arbace_repl_source_fn_fn__1239000039_A_fn_class *jrt.Class



type A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A struct{ j2g_header uint64; F_this any }

var A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_fn_class *jrt.Class



type A_arbace_repl_special_doc_A struct{ j2g_header uint64 }

var A_arbace_repl_special_doc_A_fn_class *jrt.Class



type A_arbace_repl_stack_element_str_A struct{ j2g_header uint64 }

var A_arbace_repl_stack_element_str_A_fn_class *jrt.Class



type A_arbace_repl_thread_stopper_A struct{ j2g_header uint64 }

var A_arbace_repl_thread_stopper_A_fn_class *jrt.Class



type A_arbace_repl_thread_stopper_fn__1239000079_A struct{ j2g_header uint64; F_thread any }

var A_arbace_repl_thread_stopper_fn__1239000079_A_fn_class *jrt.Class
