//line aot_arbace_repl.ae:1
package aot_arbace_repl

import (
	"arbace/jrt"
	"arbace/lang"
)




func A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_New() *A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A { A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_Init(); t := &A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A{}; t.Ctor(); return t }
//line :11:1
func (t *A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A) Ctor() {}
//line :11:1
func (t *A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp15 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_repl_A_Init(); tmp4 = A_arbace_repl_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_repl_A_Init(); tmp6 = A_arbace_repl_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_repl_A_Init(); tmp7 = A_arbace_repl_A_const_1; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_repl_A_Init(); tmp9 = A_arbace_repl_A_const_3; tmp8.Invoke_O__O(tmp9); var tmp10 *lang.Var; lang.RT_Init(); tmp10 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp10).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_129)); var tmp11 *lang.Var; lang.RT_Init(); tmp11 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp11).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_130)); var tmp12 *lang.Var; lang.RT_Init(); tmp12 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp12).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_131)); var tmp13 *lang.Var; lang.RT_Init(); tmp13 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp13).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_132)); var tmp14 *lang.Var; lang.RT_Init(); tmp14 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp14).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_133)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp15 != nil { panic(tmp15) }; return tmp3 }
//line :11:1
func A_arbace_repl_eval1239000008_fn__1239000009_A_New() *A_arbace_repl_eval1239000008_fn__1239000009_A { A_arbace_repl_eval1239000008_fn__1239000009_A_Init(); t := &A_arbace_repl_eval1239000008_fn__1239000009_A{}; t.Ctor(); return t }
//line :11:1
func (t *A_arbace_repl_eval1239000008_fn__1239000009_A) Ctor() {}
//line :11:1
func (t *A_arbace_repl_eval1239000008_fn__1239000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_repl_A_Init(); tmp1 = A_arbace_repl_A_const_4; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_repl_A_Init(); tmp3 = A_arbace_repl_A_const_5; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_repl_A_Init(); tmp5 = A_arbace_repl_A_const_8; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_repl_A_Init(); tmp7 = A_arbace_repl_A_const_6; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_repl_A_Init(); tmp9 = A_arbace_repl_A_const_7; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }































































func A_arbace_repl_special_doc_A_New() *A_arbace_repl_special_doc_A { A_arbace_repl_special_doc_A_Init(); t := &A_arbace_repl_special_doc_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_repl_special_doc_A) Ctor() {}
//line :75:1
func (t *A_arbace_repl_special_doc_A) Invoke_O_O__O(self, name_symbol__0 any) any {
	var tmp1 *lang.Var; A_arbace_repl_A_Init(); tmp1 = A_arbace_repl_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; var or__1927000174__auto____2 any; var tmp4 *lang.Var; A_arbace_repl_A_Init(); tmp4 = A_arbace_repl_A_const_10; or__1927000174__auto____2 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(name_symbol__0); if jrt.A2g_Truth(or__1927000174__auto____2) { tmp3 = or__1927000174__auto____2 } else { var tmp5 *lang.Var; A_arbace_repl_A_Init(); tmp5 = A_arbace_repl_A_const_11; tmp3 = lang.RT_Meta_O__IPersistentMap(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(name_symbol__0)) }; var tmp6 any = tmp3; var tmp7 *lang.Keyword; A_arbace_repl_A_Init(); tmp7 = A_arbace_repl_A_const_12; var tmp8 any = tmp7.Ref(); var tmp9 *lang.Keyword; A_arbace_repl_A_Init(); tmp9 = A_arbace_repl_A_const_13; var tmp10 any = tmp9.Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; return tmp2.Invoke_O_O_O_O_O__O(tmp6, tmp8, name_symbol__0, tmp10, tmp11.Ref())
}


func A_arbace_repl_namespace_doc_A_New() *A_arbace_repl_namespace_doc_A { A_arbace_repl_namespace_doc_A_Init(); t := &A_arbace_repl_namespace_doc_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_repl_namespace_doc_A) Ctor() {}
//line :80:1
func (t *A_arbace_repl_namespace_doc_A) Invoke_O_O__O(self, nspace__0 any) any {
	var tmp1 *lang.Var; A_arbace_repl_A_Init(); tmp1 = A_arbace_repl_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = lang.RT_Meta_O__IPersistentMap(nspace__0); var tmp4 *lang.Keyword; A_arbace_repl_A_Init(); tmp4 = A_arbace_repl_A_const_12; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Var; A_arbace_repl_A_Init(); tmp6 = A_arbace_repl_A_const_14; return tmp2.Invoke_O_O_O__O(tmp3, tmp5, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(nspace__0))
}
func A_arbace_repl_print_doc_A_New() *A_arbace_repl_print_doc_A { A_arbace_repl_print_doc_A_Init(); t := &A_arbace_repl_print_doc_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_repl_print_doc_A) Ctor() {}
//line :83:1
func (t *A_arbace_repl_print_doc_A) Invoke_O_O__O(self, p__1239000014__0 any) any { { var map__1239000015__2 any = p__1239000014__0; var map__1239000015__3 any; if lang.ISeq_InstanceOf(map__1239000015__2) { var tmp1 *lang.Var; A_arbace_repl_A_Init(); tmp1 = A_arbace_repl_A_const_15; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__1239000015__2)) { var tmp2 *lang.Var; A_arbace_repl_A_Init(); tmp2 = A_arbace_repl_A_const_16; map__1239000015__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__1239000015__2), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_repl_A_Init(); tmp3 = A_arbace_repl_A_const_17; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__1239000015__2)) { var tmp4 *lang.Var; A_arbace_repl_A_Init(); tmp4 = A_arbace_repl_A_const_18; map__1239000015__3 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__1239000015__2) } else { lang.PersistentArrayMap_Init(); map__1239000015__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1239000015__3 = map__1239000015__2 }; var m__4 any = map__1239000015__3; var n__5 any; var tmp5 *lang.Keyword; A_arbace_repl_A_Init(); tmp5 = A_arbace_repl_A_const_19; n__5 = lang.RT_Get_O_O__O(map__1239000015__3, tmp5.Ref()); var nm__6 any; var tmp6 *lang.Keyword; A_arbace_repl_A_Init(); tmp6 = A_arbace_repl_A_const_12; nm__6 = lang.RT_Get_O_O__O(map__1239000015__3, tmp6.Ref()); var forms__7 any; var tmp7 *lang.Keyword; A_arbace_repl_A_Init(); tmp7 = A_arbace_repl_A_const_20; forms__7 = lang.RT_Get_O_O__O(map__1239000015__3, tmp7.Ref()); var arglists__8 any; var tmp8 *lang.Keyword; A_arbace_repl_A_Init(); tmp8 = A_arbace_repl_A_const_21; arglists__8 = lang.RT_Get_O_O__O(map__1239000015__3, tmp8.Ref()); var special_form__9 any; var tmp9 *lang.Keyword; A_arbace_repl_A_Init(); tmp9 = A_arbace_repl_A_const_13; special_form__9 = lang.RT_Get_O_O__O(map__1239000015__3, tmp9.Ref()); var doc__10 any; var tmp10 *lang.Keyword; A_arbace_repl_A_Init(); tmp10 = A_arbace_repl_A_const_22; doc__10 = lang.RT_Get_O_O__O(map__1239000015__3, tmp10.Ref()); var url__11 any; var tmp11 *lang.Keyword; A_arbace_repl_A_Init(); tmp11 = A_arbace_repl_A_const_23; url__11 = lang.RT_Get_O_O__O(map__1239000015__3, tmp11.Ref()); var macro__12 any; var tmp12 *lang.Keyword; A_arbace_repl_A_Init(); tmp12 = A_arbace_repl_A_const_24; macro__12 = lang.RT_Get_O_O__O(map__1239000015__3, tmp12.Ref()); var spec__13 any; var tmp13 *lang.Keyword; A_arbace_repl_A_Init(); tmp13 = A_arbace_repl_A_const_25; spec__13 = lang.RT_Get_O_O__O(map__1239000015__3, tmp13.Ref())



	var tmp14 *lang.Var; A_arbace_repl_A_Init(); tmp14 = A_arbace_repl_A_const_29; lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(Lit_139)
	var tmp15 *lang.Var; A_arbace_repl_A_Init(); tmp15 = A_arbace_repl_A_const_29; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; var or__1927000174__auto____14 any = spec__13; if jrt.A2g_Truth(or__1927000174__auto____14) { tmp17 = or__1927000174__auto____14 } else { var tmp18 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp19 *jrt.String; if jrt.A2g_Truth(n__5) { var tmp20 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_140); var tmp21 *lang.Var; A_arbace_repl_A_Init(); tmp21 = A_arbace_repl_A_const_14; tmp19 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp20, jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(n__5), nil)) } else { tmp19 = nil }; tmp17 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp18, jrt.RefArrayOf(jrt.Object_class, tmp19.Ref(), nm__6)).Ref() }; tmp16.Invoke_O__O(tmp17)
	if jrt.A2g_Truth(forms__7) { var seq_1239000017__14 any; var tmp22 *lang.Var
		A_arbace_repl_A_Init(); tmp22 = A_arbace_repl_A_const_17; seq_1239000017__14 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(forms__7)
//line :89:1
		var chunk_1239000018__15 any; var count_1239000019__16 int64 = 0; var i_1239000020__17 int64 = 0; L1: for {
			if lang.Numbers_Lt_J_J__Z(i_1239000020__17, count_1239000019__16) { var f__18 any = lang.Indexed_Cast(chunk_1239000018__15).Nth_I__O(lang.RT_IntCast_J__I(i_1239000020__17)); var tmp23 *lang.Var
				A_arbace_repl_A_Init(); tmp23 = A_arbace_repl_A_const_32; lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(Lit_141)
				var tmp24 *lang.Var; A_arbace_repl_A_Init(); tmp24 = A_arbace_repl_A_const_30; lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(f__18)
//line :90:1
				seq_1239000017__14, chunk_1239000018__15, count_1239000019__16, i_1239000020__17 = seq_1239000017__14, chunk_1239000018__15, count_1239000019__16, lang.Numbers_Unchecked_inc_J__J(i_1239000020__17); continue L1 } else { var temp__1927000414__auto____18 any; var tmp25 *lang.Var; A_arbace_repl_A_Init(); tmp25 = A_arbace_repl_A_const_17; temp__1927000414__auto____18 = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(seq_1239000017__14); if jrt.A2g_Truth(temp__1927000414__auto____18) { var seq_1239000017__19 any = temp__1927000414__auto____18; var tmp26 *lang.Var; A_arbace_repl_A_Init(); tmp26 = A_arbace_repl_A_const_27; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(seq_1239000017__19)) { var c__1927000678__auto____20 any; var tmp27 *lang.Var; A_arbace_repl_A_Init(); tmp27 = A_arbace_repl_A_const_28; c__1927000678__auto____20 = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(seq_1239000017__19); var tmp28 *lang.Var; A_arbace_repl_A_Init(); tmp28 = A_arbace_repl_A_const_33; seq_1239000017__14, chunk_1239000018__15, count_1239000019__16, i_1239000020__17 = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(seq_1239000017__19), c__1927000678__auto____20, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var f__20 any; var tmp29 *lang.Var; A_arbace_repl_A_Init(); tmp29 = A_arbace_repl_A_const_18; f__20 = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(seq_1239000017__19)
					var tmp30 *lang.Var; A_arbace_repl_A_Init(); tmp30 = A_arbace_repl_A_const_32; lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(Lit_141)
					var tmp31 *lang.Var; A_arbace_repl_A_Init(); tmp31 = A_arbace_repl_A_const_30; lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(f__20)
//line :90:1
					var tmp32 *lang.Var; A_arbace_repl_A_Init(); tmp32 = A_arbace_repl_A_const_15; seq_1239000017__14, chunk_1239000018__15, count_1239000019__16, i_1239000020__17 = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()).Invoke_O__O(seq_1239000017__19), nil, 0, 0; continue L1 } } }
//line :89:1
			break L1
		}
	}

	if jrt.A2g_Truth(arglists__8) {
		var tmp33 *lang.Var; A_arbace_repl_A_Init(); tmp33 = A_arbace_repl_A_const_30; lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()).Invoke_O__O(arglists__8) }
	if jrt.A2g_Truth(special_form__9) {

		var tmp34 *lang.Var; A_arbace_repl_A_Init(); tmp34 = A_arbace_repl_A_const_29; lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O__O(Lit_142) } else {
//line :95:1
			if jrt.A2g_Truth(macro__12) {



				var tmp35 *lang.Var; A_arbace_repl_A_Init(); tmp35 = A_arbace_repl_A_const_29; lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke_O__O(Lit_143) } else {
//line :95:1
					if jrt.A2g_Truth(spec__13) {





						var tmp36 *lang.Var; A_arbace_repl_A_Init(); tmp36 = A_arbace_repl_A_const_29; lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()).Invoke_O__O(Lit_144) } } }
	if jrt.A2g_Truth(doc__10) { var tmp37 *lang.Var; A_arbace_repl_A_Init(); tmp37 = A_arbace_repl_A_const_29; lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke_O_O__O(Lit_145, doc__10) }
	if jrt.A2g_Truth(special_form__9) {
		var tmp38 *lang.Var; A_arbace_repl_A_Init(); tmp38 = A_arbace_repl_A_const_31; var tmp39 lang.IFn = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()); var tmp40 *lang.Keyword; A_arbace_repl_A_Init(); tmp40 = A_arbace_repl_A_const_23; if jrt.A2g_Truth(tmp39.Invoke_O_O__O(m__4, tmp40.Ref())) {
			if jrt.A2g_Truth(url__11) {
				var tmp41 *lang.Var; A_arbace_repl_A_Init(); tmp41 = A_arbace_repl_A_const_29; lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_146, nil), jrt.RefArrayOf(jrt.Object_class, nil, url__11)).Ref()) } } else {
					var tmp42 *lang.Var; A_arbace_repl_A_Init(); tmp42 = A_arbace_repl_A_const_29; lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_147, nil), jrt.RefArrayOf(jrt.Object_class, nil, nm__6)).Ref()) } }
	if jrt.A2g_Truth(n__5) { var temp__1927000414__auto____14 any; var tmp43 *lang.Var
		A_arbace_repl_A_Init(); tmp43 = A_arbace_repl_A_const_26; var tmp44 lang.IFn = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()); var tmp45 *lang.Var; A_arbace_repl_A_Init(); tmp45 = A_arbace_repl_A_const_34; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 *lang.Var; A_arbace_repl_A_Init(); tmp47 = A_arbace_repl_A_const_35; var tmp48 lang.IFn = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()); var tmp49 *lang.Var; A_arbace_repl_A_Init(); tmp49 = A_arbace_repl_A_const_14; var tmp50 any = tmp48.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()).Invoke_O__O(n__5)); var tmp51 *lang.Var; A_arbace_repl_A_Init(); tmp51 = A_arbace_repl_A_const_36; temp__1927000414__auto____14 = tmp44.Invoke_O__O(tmp46.Invoke_O_O__O(tmp50, lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()).Invoke_O__O(nm__6))); if jrt.A2g_Truth(temp__1927000414__auto____14) { var fnspec__15 any = temp__1927000414__auto____14; var tmp52 *lang.Var
			A_arbace_repl_A_Init(); tmp52 = A_arbace_repl_A_const_29; lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()).Invoke_O__O(Lit_144)
//line :109:1
			var seq_1239000021__16 any; var tmp53 *lang.Var

			A_arbace_repl_A_Init(); tmp53 = A_arbace_repl_A_const_17; var tmp54 lang.IFn = lang.IFn_Cast(jrt.NN(tmp53).GetRawRoot__O()); var tmp55 any; A_arbace_repl_A_Init(); tmp55 = A_arbace_repl_A_const_37; seq_1239000021__16 = tmp54.Invoke_O__O(tmp55)
//line :109:1
			var chunk_1239000022__17 any; var count_1239000023__18 int64 = 0; var i_1239000024__19 int64 = 0; L2: for {

				if lang.Numbers_Lt_J_J__Z(i_1239000024__19, count_1239000023__18) { var role__20 any = lang.Indexed_Cast(chunk_1239000022__17).Nth_I__O(lang.RT_IntCast_J__I(i_1239000024__19)); var temp__1927000414__auto____21 any = lang.RT_Get_O_O__O(fnspec__15, role__20)
					if jrt.A2g_Truth(temp__1927000414__auto____21) { var spec__22 any = temp__1927000414__auto____21; var tmp56 *lang.Var
						A_arbace_repl_A_Init(); tmp56 = A_arbace_repl_A_const_29; var tmp57 lang.IFn = lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()); var tmp58 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_148); var tmp59 *lang.Var; A_arbace_repl_A_Init(); tmp59 = A_arbace_repl_A_const_36; var tmp60 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp58, jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()).Invoke_O__O(role__20), nil)).Ref(); var tmp61 *lang.Var; A_arbace_repl_A_Init(); tmp61 = A_arbace_repl_A_const_38; tmp57.Invoke_O_O_O__O(Lit_145, tmp60, lang.IFn_Cast(jrt.NN(tmp61).GetRawRoot__O()).Invoke_O__O(spec__22)) }
//line :111:1
					seq_1239000021__16, chunk_1239000022__17, count_1239000023__18, i_1239000024__19 = seq_1239000021__16, chunk_1239000022__17, count_1239000023__18, lang.Numbers_Unchecked_inc_J__J(i_1239000024__19); continue L2 } else { var temp__1927000414__auto____20 any; var tmp62 *lang.Var; A_arbace_repl_A_Init(); tmp62 = A_arbace_repl_A_const_17; temp__1927000414__auto____20 = lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()).Invoke_O__O(seq_1239000021__16); if jrt.A2g_Truth(temp__1927000414__auto____20) { var seq_1239000021__21 any = temp__1927000414__auto____20; var tmp63 *lang.Var; A_arbace_repl_A_Init(); tmp63 = A_arbace_repl_A_const_27; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp63).GetRawRoot__O()).Invoke_O__O(seq_1239000021__21)) { var c__1927000678__auto____22 any; var tmp64 *lang.Var; A_arbace_repl_A_Init(); tmp64 = A_arbace_repl_A_const_28; c__1927000678__auto____22 = lang.IFn_Cast(jrt.NN(tmp64).GetRawRoot__O()).Invoke_O__O(seq_1239000021__21); var tmp65 *lang.Var; A_arbace_repl_A_Init(); tmp65 = A_arbace_repl_A_const_33; seq_1239000021__16, chunk_1239000022__17, count_1239000023__18, i_1239000024__19 = lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()).Invoke_O__O(seq_1239000021__21), c__1927000678__auto____22, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var role__22 any; var tmp66 *lang.Var; A_arbace_repl_A_Init(); tmp66 = A_arbace_repl_A_const_18; role__22 = lang.IFn_Cast(jrt.NN(tmp66).GetRawRoot__O()).Invoke_O__O(seq_1239000021__21); var temp__1927000414__auto____23 any = lang.RT_Get_O_O__O(fnspec__15, role__22)
						if jrt.A2g_Truth(temp__1927000414__auto____23) { var spec__24 any = temp__1927000414__auto____23; var tmp67 *lang.Var
							A_arbace_repl_A_Init(); tmp67 = A_arbace_repl_A_const_29; var tmp68 lang.IFn = lang.IFn_Cast(jrt.NN(tmp67).GetRawRoot__O()); var tmp69 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_148); var tmp70 *lang.Var; A_arbace_repl_A_Init(); tmp70 = A_arbace_repl_A_const_36; var tmp71 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp69, jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()).Invoke_O__O(role__22), nil)).Ref(); var tmp72 *lang.Var; A_arbace_repl_A_Init(); tmp72 = A_arbace_repl_A_const_38; tmp68.Invoke_O_O_O__O(Lit_145, tmp71, lang.IFn_Cast(jrt.NN(tmp72).GetRawRoot__O()).Invoke_O__O(spec__24)) }
//line :111:1
						var tmp73 *lang.Var; A_arbace_repl_A_Init(); tmp73 = A_arbace_repl_A_const_15; seq_1239000021__16, chunk_1239000022__17, count_1239000023__18, i_1239000024__19 = lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()).Invoke_O__O(seq_1239000021__21), nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :109:1
							return nil } } else {
//line :108:1
								return nil } }; /*line :83:1*/panic("a2g: unreachable") }































func A_arbace_repl_find_doc_A_New() *A_arbace_repl_find_doc_A { A_arbace_repl_find_doc_A_Init(); t := &A_arbace_repl_find_doc_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_repl_find_doc_A) Ctor() {}
//line :115:1
func (t *A_arbace_repl_find_doc_A) Invoke_O_O__O(self, re_string_or_pattern__0 any) any { { var re__2 any; var tmp1 *lang.Var




	A_arbace_repl_A_Init(); tmp1 = A_arbace_repl_A_const_39; re__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(re_string_or_pattern__0)
//line :115:1
	var ms__3 any; var tmp2 *lang.Var





	A_arbace_repl_A_Init(); tmp2 = A_arbace_repl_A_const_40; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_repl_A_Init(); tmp4 = A_arbace_repl_A_const_42; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any = A_arbace_repl_find_doc_fn__1239000027_A_New(); var tmp7 *jrt.Class; A_arbace_repl_find_doc_fn__1239000027_A_Init(); tmp7 = A_arbace_repl_find_doc_fn__1239000027_A_fn_class; var tmp8 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp9 *lang.Var; A_arbace_repl_A_Init(); tmp9 = A_arbace_repl_A_const_48; var tmp10 any = tmp5.Invoke_O_O__O(tmp8, lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke__O()); var tmp11 *lang.Var; A_arbace_repl_A_Init(); tmp11 = A_arbace_repl_A_const_43; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_repl_A_Init(); tmp13 = A_arbace_repl_A_const_49; var tmp14 any = jrt.NN(tmp13).GetRawRoot__O(); var tmp15 *lang.Var; A_arbace_repl_A_Init(); tmp15 = A_arbace_repl_A_const_48; var tmp16 any = tmp12.Invoke_O_O__O(tmp14, lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke__O()); var tmp17 *lang.Var; A_arbace_repl_A_Init(); tmp17 = A_arbace_repl_A_const_43; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_repl_A_Init(); tmp19 = A_arbace_repl_A_const_50; var tmp20 any = jrt.NN(tmp19).GetRawRoot__O(); var tmp21 *lang.Var; A_arbace_repl_A_Init(); tmp21 = A_arbace_repl_A_const_51; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_repl_A_Init(); tmp23 = A_arbace_repl_A_const_10; ms__3 = tmp3.Invoke_O_O_O__O(tmp10, tmp16, tmp18.Invoke_O_O__O(tmp20, tmp22.Invoke_O__O(jrt.NN(tmp23).GetRawRoot__O())))
//line :115:1
	var seq_1239000029__4 any; var tmp24 *lang.Var









	A_arbace_repl_A_Init(); tmp24 = A_arbace_repl_A_const_17; seq_1239000029__4 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(ms__3)
//line :115:1
	var chunk_1239000030__5 any; var count_1239000031__6 int64 = 0; var i_1239000032__7 int64 = 0; L1: for {









		if lang.Numbers_Lt_J_J__Z(i_1239000032__7, count_1239000031__6) { var m__8 any = lang.Indexed_Cast(chunk_1239000030__5).Nth_I__O(lang.RT_IntCast_J__I(i_1239000032__7)); var tmp25 any; var and__1927000168__auto____9 any; var tmp26 *lang.Keyword
			A_arbace_repl_A_Init(); tmp26 = A_arbace_repl_A_const_22; and__1927000168__auto____9 = jrt.NN(tmp26).Invoke_O__O(m__8); if jrt.A2g_Truth(and__1927000168__auto____9) { var or__1927000174__auto____10 any; var tmp27 *lang.Var
				A_arbace_repl_A_Init(); tmp27 = A_arbace_repl_A_const_41; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_repl_A_Init(); tmp29 = A_arbace_repl_A_const_52; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Keyword; A_arbace_repl_A_Init(); tmp31 = A_arbace_repl_A_const_22; or__1927000174__auto____10 = tmp28.Invoke_O__O(tmp30.Invoke_O_O__O(re__2, jrt.NN(tmp31).Invoke_O__O(m__8))); if jrt.A2g_Truth(or__1927000174__auto____10) { tmp25 = or__1927000174__auto____10 } else {
					var tmp32 *lang.Var; A_arbace_repl_A_Init(); tmp32 = A_arbace_repl_A_const_41; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *lang.Var; A_arbace_repl_A_Init(); tmp34 = A_arbace_repl_A_const_52; var tmp35 lang.IFn = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()); var tmp36 *lang.Var; A_arbace_repl_A_Init(); tmp36 = A_arbace_repl_A_const_35; var tmp37 lang.IFn = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()); var tmp38 *lang.Keyword; A_arbace_repl_A_Init(); tmp38 = A_arbace_repl_A_const_12; tmp25 = tmp33.Invoke_O__O(tmp35.Invoke_O_O__O(re__2, tmp37.Invoke_O__O(jrt.NN(tmp38).Invoke_O__O(m__8)))) } } else {
//line :126:1
						tmp25 = and__1927000168__auto____9 }
//line :125:1
			if jrt.A2g_Truth(tmp25) {



				var tmp39 *lang.Var; A_arbace_repl_A_Init(); tmp39 = A_arbace_repl_A_const_53; lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()).Invoke_O__O(m__8)
//line :125:1
				seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, i_1239000032__7 = seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, lang.Numbers_Unchecked_inc_J__J(i_1239000032__7); continue L1 } else { seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, i_1239000032__7 = seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, lang.Numbers_Unchecked_inc_J__J(i_1239000032__7); continue L1 } } else { var temp__1927000414__auto____8 any; var tmp40 *lang.Var; A_arbace_repl_A_Init(); tmp40 = A_arbace_repl_A_const_17; temp__1927000414__auto____8 = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()).Invoke_O__O(seq_1239000029__4); if jrt.A2g_Truth(temp__1927000414__auto____8) { var seq_1239000029__9 any = temp__1927000414__auto____8; var tmp41 *lang.Var; A_arbace_repl_A_Init(); tmp41 = A_arbace_repl_A_const_27; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()).Invoke_O__O(seq_1239000029__9)) { var c__1927000678__auto____10 any; var tmp42 *lang.Var; A_arbace_repl_A_Init(); tmp42 = A_arbace_repl_A_const_28; c__1927000678__auto____10 = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O__O(seq_1239000029__9); var tmp43 *lang.Var; A_arbace_repl_A_Init(); tmp43 = A_arbace_repl_A_const_33; seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, i_1239000032__7 = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()).Invoke_O__O(seq_1239000029__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var m__10 any; var tmp44 *lang.Var; A_arbace_repl_A_Init(); tmp44 = A_arbace_repl_A_const_18; m__10 = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()).Invoke_O__O(seq_1239000029__9); var tmp45 any; var and__1927000168__auto____11 any; var tmp46 *lang.Keyword
					A_arbace_repl_A_Init(); tmp46 = A_arbace_repl_A_const_22; and__1927000168__auto____11 = jrt.NN(tmp46).Invoke_O__O(m__10); if jrt.A2g_Truth(and__1927000168__auto____11) { var or__1927000174__auto____12 any; var tmp47 *lang.Var
						A_arbace_repl_A_Init(); tmp47 = A_arbace_repl_A_const_41; var tmp48 lang.IFn = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()); var tmp49 *lang.Var; A_arbace_repl_A_Init(); tmp49 = A_arbace_repl_A_const_52; var tmp50 lang.IFn = lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()); var tmp51 *lang.Keyword; A_arbace_repl_A_Init(); tmp51 = A_arbace_repl_A_const_22; or__1927000174__auto____12 = tmp48.Invoke_O__O(tmp50.Invoke_O_O__O(re__2, jrt.NN(tmp51).Invoke_O__O(m__10))); if jrt.A2g_Truth(or__1927000174__auto____12) { tmp45 = or__1927000174__auto____12 } else {
							var tmp52 *lang.Var; A_arbace_repl_A_Init(); tmp52 = A_arbace_repl_A_const_41; var tmp53 lang.IFn = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()); var tmp54 *lang.Var; A_arbace_repl_A_Init(); tmp54 = A_arbace_repl_A_const_52; var tmp55 lang.IFn = lang.IFn_Cast(jrt.NN(tmp54).GetRawRoot__O()); var tmp56 *lang.Var; A_arbace_repl_A_Init(); tmp56 = A_arbace_repl_A_const_35; var tmp57 lang.IFn = lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()); var tmp58 *lang.Keyword; A_arbace_repl_A_Init(); tmp58 = A_arbace_repl_A_const_12; tmp45 = tmp53.Invoke_O__O(tmp55.Invoke_O_O__O(re__2, tmp57.Invoke_O__O(jrt.NN(tmp58).Invoke_O__O(m__10)))) } } else {
//line :126:1
								tmp45 = and__1927000168__auto____11 }
//line :125:1
					if jrt.A2g_Truth(tmp45) {



						var tmp59 *lang.Var; A_arbace_repl_A_Init(); tmp59 = A_arbace_repl_A_const_53; lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()).Invoke_O__O(m__10)
//line :125:1
						var tmp60 *lang.Var; A_arbace_repl_A_Init(); tmp60 = A_arbace_repl_A_const_15; seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, i_1239000032__7 = lang.IFn_Cast(jrt.NN(tmp60).GetRawRoot__O()).Invoke_O__O(seq_1239000029__9), nil, 0, 0; continue L1 } else { var tmp61 *lang.Var; A_arbace_repl_A_Init(); tmp61 = A_arbace_repl_A_const_15; seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, i_1239000032__7 = lang.IFn_Cast(jrt.NN(tmp61).GetRawRoot__O()).Invoke_O__O(seq_1239000029__9), nil, 0, 0; continue L1 } } } else { return nil } } } }; /*line :115:1*/panic("a2g: unreachable") }





func A_arbace_repl_find_doc_fn__1239000027_A_New() *A_arbace_repl_find_doc_fn__1239000027_A { A_arbace_repl_find_doc_fn__1239000027_A_Init(); t := &A_arbace_repl_find_doc_fn__1239000027_A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_repl_find_doc_fn__1239000027_A) Ctor() {}
//line :121:1
func (t *A_arbace_repl_find_doc_fn__1239000027_A) Invoke_O_O__O(self, p1__1239000026_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_repl_A_Init(); tmp1 = A_arbace_repl_A_const_44; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_repl_A_Init(); tmp3 = A_arbace_repl_A_const_12; var tmp4 any = tmp3.Ref(); var tmp5 *lang.Var; A_arbace_repl_A_Init(); tmp5 = A_arbace_repl_A_const_43; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_repl_A_Init(); tmp7 = A_arbace_repl_A_const_45; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 *lang.Var; A_arbace_repl_A_Init(); tmp9 = A_arbace_repl_A_const_46; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_repl_A_Init(); tmp11 = A_arbace_repl_A_const_47; return tmp2.Invoke_O_O__O(tmp4, tmp6.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(p1__1239000026_SHARP___1)))) }









func A_arbace_repl_doc_A_New() *A_arbace_repl_doc_A { A_arbace_repl_doc_A_Init(); t := &A_arbace_repl_doc_A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_repl_doc_A) Ctor() {}
//line :131:1
func (t *A_arbace_repl_doc_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, name__2 any) any { var temp__1927000408__auto____4 any; var tmp1 any;




	A_arbace_repl_A_Init(); tmp1 = A_arbace_repl_A_const_54; temp__1927000408__auto____4 = lang.IFn_Cast(tmp1).Invoke_O__O(name__2); if jrt.A2g_Truth(temp__1927000408__auto____4) { var special_name__5 any = temp__1927000408__auto____4; var tmp2 *lang.Var; A_arbace_repl_A_Init(); tmp2 = A_arbace_repl_A_const_17; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_repl_A_Init(); tmp4 = A_arbace_repl_A_const_40; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_repl_A_Init(); tmp6 = A_arbace_repl_A_const_57; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_repl_A_Init(); tmp8 = A_arbace_repl_A_const_17; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_repl_A_Init(); tmp10 = A_arbace_repl_A_const_40; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_repl_A_Init(); tmp12 = A_arbace_repl_A_const_57; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any; A_arbace_repl_A_Init(); tmp14 = A_arbace_repl_A_const_58; var tmp15 any = tmp13.Invoke_O__O(tmp14); var tmp16 *lang.Var; A_arbace_repl_A_Init(); tmp16 = A_arbace_repl_A_const_57; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 any; A_arbace_repl_A_Init(); tmp18 = A_arbace_repl_A_const_59; var tmp19 any = tmp7.Invoke_O__O(tmp9.Invoke_O__O(tmp11.Invoke_O_O__O(tmp15, tmp17.Invoke_O__O(tmp18)))); var tmp20 *lang.Var; A_arbace_repl_A_Init(); tmp20 = A_arbace_repl_A_const_57; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Var; A_arbace_repl_A_Init(); tmp22 = A_arbace_repl_A_const_17; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_repl_A_Init(); tmp24 = A_arbace_repl_A_const_40; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 *lang.Var; A_arbace_repl_A_Init(); tmp26 = A_arbace_repl_A_const_57; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_repl_A_Init(); tmp28 = A_arbace_repl_A_const_17; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Var; A_arbace_repl_A_Init(); tmp30 = A_arbace_repl_A_const_40; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_repl_A_Init(); tmp32 = A_arbace_repl_A_const_57; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 any; A_arbace_repl_A_Init(); tmp34 = A_arbace_repl_A_const_58; var tmp35 any = tmp33.Invoke_O__O(tmp34); var tmp36 *lang.Var; A_arbace_repl_A_Init(); tmp36 = A_arbace_repl_A_const_57; var tmp37 lang.IFn = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()); var tmp38 any; A_arbace_repl_A_Init(); tmp38 = A_arbace_repl_A_const_60; var tmp39 any = tmp27.Invoke_O__O(tmp29.Invoke_O__O(tmp31.Invoke_O_O__O(tmp35, tmp37.Invoke_O__O(tmp38)))); var tmp40 *lang.Var; A_arbace_repl_A_Init(); tmp40 = A_arbace_repl_A_const_57; var tmp41 lang.IFn = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()); var tmp42 *lang.Var; A_arbace_repl_A_Init(); tmp42 = A_arbace_repl_A_const_17; var tmp43 lang.IFn = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()); var tmp44 *lang.Var; A_arbace_repl_A_Init(); tmp44 = A_arbace_repl_A_const_40; var tmp45 lang.IFn = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()); var tmp46 *lang.Var; A_arbace_repl_A_Init(); tmp46 = A_arbace_repl_A_const_57; var tmp47 lang.IFn = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()); var tmp48 any; A_arbace_repl_A_Init(); tmp48 = A_arbace_repl_A_const_61; var tmp49 any = tmp47.Invoke_O__O(tmp48); var tmp50 *lang.Var; A_arbace_repl_A_Init(); tmp50 = A_arbace_repl_A_const_57; return tmp3.Invoke_O__O(tmp5.Invoke_O_O__O(tmp19, tmp21.Invoke_O__O(tmp23.Invoke_O__O(tmp25.Invoke_O_O__O(tmp39, tmp41.Invoke_O__O(tmp43.Invoke_O__O(tmp45.Invoke_O_O__O(tmp49, lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()).Invoke_O__O(special_name__5))))))))) } else {

		var tmp51 *lang.Var; A_arbace_repl_A_Init(); tmp51 = A_arbace_repl_A_const_10; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()).Invoke_O__O(name__2)) { var tmp52 *lang.Var; A_arbace_repl_A_Init(); tmp52 = A_arbace_repl_A_const_17; var tmp53 lang.IFn = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()); var tmp54 *lang.Var; A_arbace_repl_A_Init(); tmp54 = A_arbace_repl_A_const_40; var tmp55 lang.IFn = lang.IFn_Cast(jrt.NN(tmp54).GetRawRoot__O()); var tmp56 *lang.Var; A_arbace_repl_A_Init(); tmp56 = A_arbace_repl_A_const_57; var tmp57 lang.IFn = lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()); var tmp58 *lang.Var; A_arbace_repl_A_Init(); tmp58 = A_arbace_repl_A_const_17; var tmp59 lang.IFn = lang.IFn_Cast(jrt.NN(tmp58).GetRawRoot__O()); var tmp60 *lang.Var; A_arbace_repl_A_Init(); tmp60 = A_arbace_repl_A_const_40; var tmp61 lang.IFn = lang.IFn_Cast(jrt.NN(tmp60).GetRawRoot__O()); var tmp62 *lang.Var; A_arbace_repl_A_Init(); tmp62 = A_arbace_repl_A_const_57; var tmp63 lang.IFn = lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()); var tmp64 any; A_arbace_repl_A_Init(); tmp64 = A_arbace_repl_A_const_58; var tmp65 any = tmp63.Invoke_O__O(tmp64); var tmp66 *lang.Var; A_arbace_repl_A_Init(); tmp66 = A_arbace_repl_A_const_57; var tmp67 lang.IFn = lang.IFn_Cast(jrt.NN(tmp66).GetRawRoot__O()); var tmp68 any; A_arbace_repl_A_Init(); tmp68 = A_arbace_repl_A_const_62; var tmp69 any = tmp57.Invoke_O__O(tmp59.Invoke_O__O(tmp61.Invoke_O_O__O(tmp65, tmp67.Invoke_O__O(tmp68)))); var tmp70 *lang.Var; A_arbace_repl_A_Init(); tmp70 = A_arbace_repl_A_const_57; var tmp71 lang.IFn = lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()); var tmp72 *lang.Var; A_arbace_repl_A_Init(); tmp72 = A_arbace_repl_A_const_17; var tmp73 lang.IFn = lang.IFn_Cast(jrt.NN(tmp72).GetRawRoot__O()); var tmp74 *lang.Var; A_arbace_repl_A_Init(); tmp74 = A_arbace_repl_A_const_40; var tmp75 lang.IFn = lang.IFn_Cast(jrt.NN(tmp74).GetRawRoot__O()); var tmp76 *lang.Var; A_arbace_repl_A_Init(); tmp76 = A_arbace_repl_A_const_57; var tmp77 lang.IFn = lang.IFn_Cast(jrt.NN(tmp76).GetRawRoot__O()); var tmp78 *lang.Var; A_arbace_repl_A_Init(); tmp78 = A_arbace_repl_A_const_17; var tmp79 lang.IFn = lang.IFn_Cast(jrt.NN(tmp78).GetRawRoot__O()); var tmp80 *lang.Var; A_arbace_repl_A_Init(); tmp80 = A_arbace_repl_A_const_40; var tmp81 lang.IFn = lang.IFn_Cast(jrt.NN(tmp80).GetRawRoot__O()); var tmp82 *lang.Var; A_arbace_repl_A_Init(); tmp82 = A_arbace_repl_A_const_57; var tmp83 lang.IFn = lang.IFn_Cast(jrt.NN(tmp82).GetRawRoot__O()); var tmp84 any; A_arbace_repl_A_Init(); tmp84 = A_arbace_repl_A_const_58; var tmp85 any = tmp83.Invoke_O__O(tmp84); var tmp86 *lang.Var; A_arbace_repl_A_Init(); tmp86 = A_arbace_repl_A_const_57; var tmp87 lang.IFn = lang.IFn_Cast(jrt.NN(tmp86).GetRawRoot__O()); var tmp88 any; A_arbace_repl_A_Init(); tmp88 = A_arbace_repl_A_const_63; var tmp89 any = tmp77.Invoke_O__O(tmp79.Invoke_O__O(tmp81.Invoke_O_O__O(tmp85, tmp87.Invoke_O__O(tmp88)))); var tmp90 *lang.Var; A_arbace_repl_A_Init(); tmp90 = A_arbace_repl_A_const_57; var tmp91 lang.IFn = lang.IFn_Cast(jrt.NN(tmp90).GetRawRoot__O()); var tmp92 *lang.Var; A_arbace_repl_A_Init(); tmp92 = A_arbace_repl_A_const_17; var tmp93 lang.IFn = lang.IFn_Cast(jrt.NN(tmp92).GetRawRoot__O()); var tmp94 *lang.Var; A_arbace_repl_A_Init(); tmp94 = A_arbace_repl_A_const_40; var tmp95 lang.IFn = lang.IFn_Cast(jrt.NN(tmp94).GetRawRoot__O()); var tmp96 *lang.Var; A_arbace_repl_A_Init(); tmp96 = A_arbace_repl_A_const_57; var tmp97 lang.IFn = lang.IFn_Cast(jrt.NN(tmp96).GetRawRoot__O()); var tmp98 any; A_arbace_repl_A_Init(); tmp98 = A_arbace_repl_A_const_61; var tmp99 any = tmp97.Invoke_O__O(tmp98); var tmp100 *lang.Var; A_arbace_repl_A_Init(); tmp100 = A_arbace_repl_A_const_57; return tmp53.Invoke_O__O(tmp55.Invoke_O_O__O(tmp69, tmp71.Invoke_O__O(tmp73.Invoke_O__O(tmp75.Invoke_O_O__O(tmp89, tmp91.Invoke_O__O(tmp93.Invoke_O__O(tmp95.Invoke_O_O__O(tmp99, lang.IFn_Cast(jrt.NN(tmp100).GetRawRoot__O()).Invoke_O__O(name__2))))))))) } else { var tmp101 *lang.Var; A_arbace_repl_A_Init(); tmp101 = A_arbace_repl_A_const_55; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp101).GetRawRoot__O()).Invoke_O__O(name__2)) { var tmp102 *lang.Var; A_arbace_repl_A_Init(); tmp102 = A_arbace_repl_A_const_17; var tmp103 lang.IFn = lang.IFn_Cast(jrt.NN(tmp102).GetRawRoot__O()); var tmp104 *lang.Var; A_arbace_repl_A_Init(); tmp104 = A_arbace_repl_A_const_40; var tmp105 lang.IFn = lang.IFn_Cast(jrt.NN(tmp104).GetRawRoot__O()); var tmp106 *lang.Var; A_arbace_repl_A_Init(); tmp106 = A_arbace_repl_A_const_57; var tmp107 lang.IFn = lang.IFn_Cast(jrt.NN(tmp106).GetRawRoot__O()); var tmp108 *lang.Var; A_arbace_repl_A_Init(); tmp108 = A_arbace_repl_A_const_17; var tmp109 lang.IFn = lang.IFn_Cast(jrt.NN(tmp108).GetRawRoot__O()); var tmp110 *lang.Var; A_arbace_repl_A_Init(); tmp110 = A_arbace_repl_A_const_40; var tmp111 lang.IFn = lang.IFn_Cast(jrt.NN(tmp110).GetRawRoot__O()); var tmp112 *lang.Var; A_arbace_repl_A_Init(); tmp112 = A_arbace_repl_A_const_57; var tmp113 lang.IFn = lang.IFn_Cast(jrt.NN(tmp112).GetRawRoot__O()); var tmp114 any; A_arbace_repl_A_Init(); tmp114 = A_arbace_repl_A_const_58; var tmp115 any = tmp113.Invoke_O__O(tmp114); var tmp116 *lang.Var; A_arbace_repl_A_Init(); tmp116 = A_arbace_repl_A_const_57; var tmp117 lang.IFn = lang.IFn_Cast(jrt.NN(tmp116).GetRawRoot__O()); var tmp118 any; A_arbace_repl_A_Init(); tmp118 = A_arbace_repl_A_const_64; var tmp119 any = tmp107.Invoke_O__O(tmp109.Invoke_O__O(tmp111.Invoke_O_O__O(tmp115, tmp117.Invoke_O__O(tmp118)))); var tmp120 *lang.Var; A_arbace_repl_A_Init(); tmp120 = A_arbace_repl_A_const_57; var tmp121 lang.IFn = lang.IFn_Cast(jrt.NN(tmp120).GetRawRoot__O()); var tmp122 *lang.Var; A_arbace_repl_A_Init(); tmp122 = A_arbace_repl_A_const_65; var tmp123 lang.IFn = lang.IFn_Cast(jrt.NN(tmp122).GetRawRoot__O()); var tmp124 *lang.Var; A_arbace_repl_A_Init(); tmp124 = A_arbace_repl_A_const_66; var tmp125 any = jrt.NN(tmp124).GetRawRoot__O(); var tmp126 *lang.Var; A_arbace_repl_A_Init(); tmp126 = A_arbace_repl_A_const_17; var tmp127 lang.IFn = lang.IFn_Cast(jrt.NN(tmp126).GetRawRoot__O()); var tmp128 *lang.Var; A_arbace_repl_A_Init(); tmp128 = A_arbace_repl_A_const_40; var tmp129 lang.IFn = lang.IFn_Cast(jrt.NN(tmp128).GetRawRoot__O()); var tmp130 *lang.Var; A_arbace_repl_A_Init(); tmp130 = A_arbace_repl_A_const_57; var tmp131 lang.IFn = lang.IFn_Cast(jrt.NN(tmp130).GetRawRoot__O()); var tmp132 *lang.Keyword; A_arbace_repl_A_Init(); tmp132 = A_arbace_repl_A_const_25; var tmp133 any = tmp131.Invoke_O__O(tmp132.Ref()); var tmp134 *lang.Var; A_arbace_repl_A_Init(); tmp134 = A_arbace_repl_A_const_57; var tmp135 lang.IFn = lang.IFn_Cast(jrt.NN(tmp134).GetRawRoot__O()); var tmp136 *lang.Var; A_arbace_repl_A_Init(); tmp136 = A_arbace_repl_A_const_17; var tmp137 lang.IFn = lang.IFn_Cast(jrt.NN(tmp136).GetRawRoot__O()); var tmp138 *lang.Var; A_arbace_repl_A_Init(); tmp138 = A_arbace_repl_A_const_40; var tmp139 lang.IFn = lang.IFn_Cast(jrt.NN(tmp138).GetRawRoot__O()); var tmp140 *lang.Var; A_arbace_repl_A_Init(); tmp140 = A_arbace_repl_A_const_57; var tmp141 lang.IFn = lang.IFn_Cast(jrt.NN(tmp140).GetRawRoot__O()); var tmp142 any; A_arbace_repl_A_Init(); tmp142 = A_arbace_repl_A_const_61; var tmp143 any = tmp141.Invoke_O__O(tmp142); var tmp144 *lang.Var; A_arbace_repl_A_Init(); tmp144 = A_arbace_repl_A_const_57; var tmp145 any = tmp135.Invoke_O__O(tmp137.Invoke_O__O(tmp139.Invoke_O_O__O(tmp143, lang.IFn_Cast(jrt.NN(tmp144).GetRawRoot__O()).Invoke_O__O(name__2)))); var tmp146 *lang.Var; A_arbace_repl_A_Init(); tmp146 = A_arbace_repl_A_const_57; var tmp147 lang.IFn = lang.IFn_Cast(jrt.NN(tmp146).GetRawRoot__O()); var tmp148 *lang.Keyword; A_arbace_repl_A_Init(); tmp148 = A_arbace_repl_A_const_22; var tmp149 any = tmp147.Invoke_O__O(tmp148.Ref()); var tmp150 *lang.Var; A_arbace_repl_A_Init(); tmp150 = A_arbace_repl_A_const_57; var tmp151 lang.IFn = lang.IFn_Cast(jrt.NN(tmp150).GetRawRoot__O()); var tmp152 *lang.Var; A_arbace_repl_A_Init(); tmp152 = A_arbace_repl_A_const_17; var tmp153 lang.IFn = lang.IFn_Cast(jrt.NN(tmp152).GetRawRoot__O()); var tmp154 *lang.Var; A_arbace_repl_A_Init(); tmp154 = A_arbace_repl_A_const_40; var tmp155 lang.IFn = lang.IFn_Cast(jrt.NN(tmp154).GetRawRoot__O()); var tmp156 *lang.Var; A_arbace_repl_A_Init(); tmp156 = A_arbace_repl_A_const_57; var tmp157 lang.IFn = lang.IFn_Cast(jrt.NN(tmp156).GetRawRoot__O()); var tmp158 any; A_arbace_repl_A_Init(); tmp158 = A_arbace_repl_A_const_61; var tmp159 any = tmp157.Invoke_O__O(tmp158); var tmp160 *lang.Var; A_arbace_repl_A_Init(); tmp160 = A_arbace_repl_A_const_57; var tmp161 lang.IFn = lang.IFn_Cast(jrt.NN(tmp160).GetRawRoot__O()); var tmp162 *lang.Var; A_arbace_repl_A_Init(); tmp162 = A_arbace_repl_A_const_38; return tmp103.Invoke_O__O(tmp105.Invoke_O_O__O(tmp119, tmp121.Invoke_O__O(tmp123.Invoke_O_O__O(tmp125, tmp127.Invoke_O__O(tmp129.Invoke_O_O_O_O__O(tmp133, tmp145, tmp149, tmp151.Invoke_O__O(tmp153.Invoke_O__O(tmp155.Invoke_O_O__O(tmp159, tmp161.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp162).GetRawRoot__O()).Invoke_O__O(name__2))))))))))) } else { var tmp163 *lang.Var; A_arbace_repl_A_Init(); tmp163 = A_arbace_repl_A_const_56; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp163).GetRawRoot__O()).Invoke_O__O(name__2)) { var tmp164 *lang.Var; A_arbace_repl_A_Init(); tmp164 = A_arbace_repl_A_const_17; var tmp165 lang.IFn = lang.IFn_Cast(jrt.NN(tmp164).GetRawRoot__O()); var tmp166 *lang.Var; A_arbace_repl_A_Init(); tmp166 = A_arbace_repl_A_const_40; var tmp167 lang.IFn = lang.IFn_Cast(jrt.NN(tmp166).GetRawRoot__O()); var tmp168 *lang.Var; A_arbace_repl_A_Init(); tmp168 = A_arbace_repl_A_const_57; var tmp169 lang.IFn = lang.IFn_Cast(jrt.NN(tmp168).GetRawRoot__O()); var tmp170 *lang.Var; A_arbace_repl_A_Init(); tmp170 = A_arbace_repl_A_const_17; var tmp171 lang.IFn = lang.IFn_Cast(jrt.NN(tmp170).GetRawRoot__O()); var tmp172 *lang.Var; A_arbace_repl_A_Init(); tmp172 = A_arbace_repl_A_const_40; var tmp173 lang.IFn = lang.IFn_Cast(jrt.NN(tmp172).GetRawRoot__O()); var tmp174 *lang.Var; A_arbace_repl_A_Init(); tmp174 = A_arbace_repl_A_const_57; var tmp175 lang.IFn = lang.IFn_Cast(jrt.NN(tmp174).GetRawRoot__O()); var tmp176 any; A_arbace_repl_A_Init(); tmp176 = A_arbace_repl_A_const_58; var tmp177 any = tmp175.Invoke_O__O(tmp176); var tmp178 *lang.Var; A_arbace_repl_A_Init(); tmp178 = A_arbace_repl_A_const_57; var tmp179 lang.IFn = lang.IFn_Cast(jrt.NN(tmp178).GetRawRoot__O()); var tmp180 any; A_arbace_repl_A_Init(); tmp180 = A_arbace_repl_A_const_67; var tmp181 any = tmp169.Invoke_O__O(tmp171.Invoke_O__O(tmp173.Invoke_O_O__O(tmp177, tmp179.Invoke_O__O(tmp180)))); var tmp182 *lang.Var; A_arbace_repl_A_Init(); tmp182 = A_arbace_repl_A_const_57; var tmp183 lang.IFn = lang.IFn_Cast(jrt.NN(tmp182).GetRawRoot__O()); var tmp184 *lang.Var; A_arbace_repl_A_Init(); tmp184 = A_arbace_repl_A_const_17; var tmp185 lang.IFn = lang.IFn_Cast(jrt.NN(tmp184).GetRawRoot__O()); var tmp186 *lang.Var; A_arbace_repl_A_Init(); tmp186 = A_arbace_repl_A_const_40; var tmp187 lang.IFn = lang.IFn_Cast(jrt.NN(tmp186).GetRawRoot__O()); var tmp188 *lang.Var; A_arbace_repl_A_Init(); tmp188 = A_arbace_repl_A_const_57; var tmp189 lang.IFn = lang.IFn_Cast(jrt.NN(tmp188).GetRawRoot__O()); var tmp190 *lang.Var; A_arbace_repl_A_Init(); tmp190 = A_arbace_repl_A_const_17; var tmp191 lang.IFn = lang.IFn_Cast(jrt.NN(tmp190).GetRawRoot__O()); var tmp192 *lang.Var; A_arbace_repl_A_Init(); tmp192 = A_arbace_repl_A_const_40; var tmp193 lang.IFn = lang.IFn_Cast(jrt.NN(tmp192).GetRawRoot__O()); var tmp194 *lang.Var; A_arbace_repl_A_Init(); tmp194 = A_arbace_repl_A_const_57; var tmp195 lang.IFn = lang.IFn_Cast(jrt.NN(tmp194).GetRawRoot__O()); var tmp196 any; A_arbace_repl_A_Init(); tmp196 = A_arbace_repl_A_const_58; var tmp197 any = tmp195.Invoke_O__O(tmp196); var tmp198 *lang.Var; A_arbace_repl_A_Init(); tmp198 = A_arbace_repl_A_const_57; var tmp199 lang.IFn = lang.IFn_Cast(jrt.NN(tmp198).GetRawRoot__O()); var tmp200 any; A_arbace_repl_A_Init(); tmp200 = A_arbace_repl_A_const_68; var tmp201 any = tmp189.Invoke_O__O(tmp191.Invoke_O__O(tmp193.Invoke_O_O__O(tmp197, tmp199.Invoke_O__O(tmp200)))); var tmp202 *lang.Var; A_arbace_repl_A_Init(); tmp202 = A_arbace_repl_A_const_57; var tmp203 lang.IFn = lang.IFn_Cast(jrt.NN(tmp202).GetRawRoot__O()); var tmp204 *lang.Var; A_arbace_repl_A_Init(); tmp204 = A_arbace_repl_A_const_17; var tmp205 lang.IFn = lang.IFn_Cast(jrt.NN(tmp204).GetRawRoot__O()); var tmp206 *lang.Var; A_arbace_repl_A_Init(); tmp206 = A_arbace_repl_A_const_40; var tmp207 lang.IFn = lang.IFn_Cast(jrt.NN(tmp206).GetRawRoot__O()); var tmp208 *lang.Var; A_arbace_repl_A_Init(); tmp208 = A_arbace_repl_A_const_57; var tmp209 lang.IFn = lang.IFn_Cast(jrt.NN(tmp208).GetRawRoot__O()); var tmp210 any; A_arbace_repl_A_Init(); tmp210 = A_arbace_repl_A_const_69; var tmp211 any = tmp209.Invoke_O__O(tmp210); var tmp212 *lang.Var; A_arbace_repl_A_Init(); tmp212 = A_arbace_repl_A_const_57; var tmp213 lang.IFn = lang.IFn_Cast(jrt.NN(tmp212).GetRawRoot__O()); var tmp214 *lang.Var; A_arbace_repl_A_Init(); tmp214 = A_arbace_repl_A_const_17; var tmp215 lang.IFn = lang.IFn_Cast(jrt.NN(tmp214).GetRawRoot__O()); var tmp216 *lang.Var; A_arbace_repl_A_Init(); tmp216 = A_arbace_repl_A_const_40; var tmp217 lang.IFn = lang.IFn_Cast(jrt.NN(tmp216).GetRawRoot__O()); var tmp218 *lang.Var; A_arbace_repl_A_Init(); tmp218 = A_arbace_repl_A_const_57; var tmp219 lang.IFn = lang.IFn_Cast(jrt.NN(tmp218).GetRawRoot__O()); var tmp220 any; A_arbace_repl_A_Init(); tmp220 = A_arbace_repl_A_const_61; var tmp221 any = tmp219.Invoke_O__O(tmp220); var tmp222 *lang.Var; A_arbace_repl_A_Init(); tmp222 = A_arbace_repl_A_const_57; return tmp165.Invoke_O__O(tmp167.Invoke_O_O__O(tmp181, tmp183.Invoke_O__O(tmp185.Invoke_O__O(tmp187.Invoke_O_O__O(tmp201, tmp203.Invoke_O__O(tmp205.Invoke_O__O(tmp207.Invoke_O_O__O(tmp211, tmp213.Invoke_O__O(tmp215.Invoke_O__O(tmp217.Invoke_O_O__O(tmp221, lang.IFn_Cast(jrt.NN(tmp222).GetRawRoot__O()).Invoke_O__O(name__2)))))))))))) } else { var tmp223 *lang.Var; A_arbace_repl_A_Init(); tmp223 = A_arbace_repl_A_const_11; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp223).GetRawRoot__O()).Invoke_O__O(name__2)) { var tmp224 *lang.Var; A_arbace_repl_A_Init(); tmp224 = A_arbace_repl_A_const_17; var tmp225 lang.IFn = lang.IFn_Cast(jrt.NN(tmp224).GetRawRoot__O()); var tmp226 *lang.Var; A_arbace_repl_A_Init(); tmp226 = A_arbace_repl_A_const_40; var tmp227 lang.IFn = lang.IFn_Cast(jrt.NN(tmp226).GetRawRoot__O()); var tmp228 *lang.Var; A_arbace_repl_A_Init(); tmp228 = A_arbace_repl_A_const_57; var tmp229 lang.IFn = lang.IFn_Cast(jrt.NN(tmp228).GetRawRoot__O()); var tmp230 *lang.Var; A_arbace_repl_A_Init(); tmp230 = A_arbace_repl_A_const_17; var tmp231 lang.IFn = lang.IFn_Cast(jrt.NN(tmp230).GetRawRoot__O()); var tmp232 *lang.Var; A_arbace_repl_A_Init(); tmp232 = A_arbace_repl_A_const_40; var tmp233 lang.IFn = lang.IFn_Cast(jrt.NN(tmp232).GetRawRoot__O()); var tmp234 *lang.Var; A_arbace_repl_A_Init(); tmp234 = A_arbace_repl_A_const_57; var tmp235 lang.IFn = lang.IFn_Cast(jrt.NN(tmp234).GetRawRoot__O()); var tmp236 any; A_arbace_repl_A_Init(); tmp236 = A_arbace_repl_A_const_58; var tmp237 any = tmp235.Invoke_O__O(tmp236); var tmp238 *lang.Var; A_arbace_repl_A_Init(); tmp238 = A_arbace_repl_A_const_57; var tmp239 lang.IFn = lang.IFn_Cast(jrt.NN(tmp238).GetRawRoot__O()); var tmp240 any; A_arbace_repl_A_Init(); tmp240 = A_arbace_repl_A_const_70; var tmp241 any = tmp229.Invoke_O__O(tmp231.Invoke_O__O(tmp233.Invoke_O_O__O(tmp237, tmp239.Invoke_O__O(tmp240)))); var tmp242 *lang.Var; A_arbace_repl_A_Init(); tmp242 = A_arbace_repl_A_const_57; var tmp243 lang.IFn = lang.IFn_Cast(jrt.NN(tmp242).GetRawRoot__O()); var tmp244 *lang.Var; A_arbace_repl_A_Init(); tmp244 = A_arbace_repl_A_const_17; var tmp245 lang.IFn = lang.IFn_Cast(jrt.NN(tmp244).GetRawRoot__O()); var tmp246 *lang.Var; A_arbace_repl_A_Init(); tmp246 = A_arbace_repl_A_const_40; var tmp247 lang.IFn = lang.IFn_Cast(jrt.NN(tmp246).GetRawRoot__O()); var tmp248 *lang.Var; A_arbace_repl_A_Init(); tmp248 = A_arbace_repl_A_const_57; var tmp249 lang.IFn = lang.IFn_Cast(jrt.NN(tmp248).GetRawRoot__O()); var tmp250 any; A_arbace_repl_A_Init(); tmp250 = A_arbace_repl_A_const_71; var tmp251 any = tmp249.Invoke_O__O(tmp250); var tmp252 *lang.Var; A_arbace_repl_A_Init(); tmp252 = A_arbace_repl_A_const_57; var tmp253 lang.IFn = lang.IFn_Cast(jrt.NN(tmp252).GetRawRoot__O()); var tmp254 *lang.Var; A_arbace_repl_A_Init(); tmp254 = A_arbace_repl_A_const_17; var tmp255 lang.IFn = lang.IFn_Cast(jrt.NN(tmp254).GetRawRoot__O()); var tmp256 *lang.Var; A_arbace_repl_A_Init(); tmp256 = A_arbace_repl_A_const_40; var tmp257 lang.IFn = lang.IFn_Cast(jrt.NN(tmp256).GetRawRoot__O()); var tmp258 *lang.Var; A_arbace_repl_A_Init(); tmp258 = A_arbace_repl_A_const_57; var tmp259 lang.IFn = lang.IFn_Cast(jrt.NN(tmp258).GetRawRoot__O()); var tmp260 any; A_arbace_repl_A_Init(); tmp260 = A_arbace_repl_A_const_72; var tmp261 any = tmp259.Invoke_O__O(tmp260); var tmp262 *lang.Var; A_arbace_repl_A_Init(); tmp262 = A_arbace_repl_A_const_57; return tmp225.Invoke_O__O(tmp227.Invoke_O_O__O(tmp241, tmp243.Invoke_O__O(tmp245.Invoke_O__O(tmp247.Invoke_O_O__O(tmp251, tmp253.Invoke_O__O(tmp255.Invoke_O__O(tmp257.Invoke_O_O__O(tmp261, lang.IFn_Cast(jrt.NN(tmp262).GetRawRoot__O()).Invoke_O__O(name__2))))))))) } else { return nil } } } } } }








func A_arbace_repl_source_fn_A_New() *A_arbace_repl_source_fn_A { A_arbace_repl_source_fn_A_Init(); t := &A_arbace_repl_source_fn_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_repl_source_fn_A) Ctor() {}
//line :147:1
func (t *A_arbace_repl_source_fn_A) Invoke_O_O__O(self, x__0 any) any { var temp__1927000414__auto____2 any; var tmp1 *lang.Var;








	A_arbace_repl_A_Init(); tmp1 = A_arbace_repl_A_const_11; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(x__0); if jrt.A2g_Truth(temp__1927000414__auto____2) { var v__3 any = temp__1927000414__auto____2; var temp__1927000414__auto____4 any; var tmp2 *lang.Keyword
		A_arbace_repl_A_Init(); tmp2 = A_arbace_repl_A_const_73; var tmp3 *lang.Keyword = tmp2; temp__1927000414__auto____4 = jrt.NN(tmp3).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(v__3)); if jrt.A2g_Truth(temp__1927000414__auto____4) { var filepath__5 any = temp__1927000414__auto____4; var temp__1927000414__auto____6 any; var tmp4 any = lang.RT_BaseLoader__ClassLoader(); var tmp5 *jrt.Class
			A_arbace_repl_A_Init(); tmp5 = A_arbace_repl_A_const_74; var tmp6 *jrt.Class = tmp5; temp__1927000414__auto____6 = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp4, tmp6, Lit_167, jrt.RefArrayOf(jrt.Object_class, filepath__5)); if jrt.A2g_Truth(temp__1927000414__auto____6) { var strm__7 any = temp__1927000414__auto____6; var rdr__8 any = jrt.LineNumberReader_New_Reader(jrt.InputStreamReader_New_InputStream(jrt.InputStream_Cast(strm__7))); var tmp7 any; tmp19 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var n__1927000701__auto____11 int64; var tmp8 *lang.Keyword

				A_arbace_repl_A_Init(); tmp8 = A_arbace_repl_A_const_76; var tmp9 *lang.Keyword = tmp8; n__1927000701__auto____11 = lang.RT_LongCast_O__J(lang.Numbers_Dec_O__Number(jrt.NN(tmp9).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(v__3))))
//line :158:1
				var ___12 int64 = 0; L1: for {

					if lang.Numbers_Lt_J_J__Z(___12, n__1927000701__auto____11) { jrt.NN(jrt.LineNumberReader_Cast(rdr__8)).ReadLine__String(); ___12 = lang.Numbers_Unchecked_inc_J__J(___12); continue L1 }
//line :158:1
					break L1 }; var text__11 any = jrt.StringBuilder_New(); var pbr__12 any; var p__840000142__auto____12 any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class(Lit_168), jrt.RefArrayOf(jrt.Object_class, rdr__8)); var tmp10 *lang.Var



				A_arbace_repl_A_Init(); tmp10 = A_arbace_repl_A_const_77; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any = A_arbace_repl_source_fn_fn__1239000039_A_New_O(text__11); var tmp13 *jrt.Class; A_arbace_repl_source_fn_fn__1239000039_A_Init(); tmp13 = A_arbace_repl_source_fn_fn__1239000039_A_fn_class; tmp11.Invoke_O_O__O(p__840000142__auto____12, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_79, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil))))
//line :158:1
				pbr__12 = p__840000142__auto____12; var read_opts__13 any







				if jrt.NN(jrt.String_Cast(filepath__5)).EndsWith_String__Z(Lit_169) { A_arbace_repl_A_Init(); read_opts__13 = A_arbace_repl_A_const_75 } else { lang.PersistentArrayMap_Init(); read_opts__13 = lang.PersistentArrayMap_EMPTY.Ref() }
				var tmp14 *lang.Keyword; A_arbace_repl_A_Init(); tmp14 = A_arbace_repl_A_const_79; var tmp15 any = tmp14.Ref(); var tmp16 *lang.Var; A_arbace_repl_A_Init(); tmp16 = A_arbace_repl_A_const_80; if lang.Util_Equiv_O_O__Z(tmp15, jrt.NN(tmp16).Get__O()) { panic(jrt.Thrown(jrt.IllegalStateException_New_String(Lit_170))) } else {

					var tmp17 *lang.Var; A_arbace_repl_A_Init(); tmp17 = A_arbace_repl_A_const_81; lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O_O__O(read_opts__13, jrt.PushbackReader_New_Reader(jrt.Reader_Cast(pbr__12))) }
				var tmp18 *lang.Var; A_arbace_repl_A_Init(); tmp18 = A_arbace_repl_A_const_35; tmp7 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(text__11) }; return nil }()
//line :159:1
				jrt.BufferedReader_Cast(rdr__8).Close__V()
//line :158:1
				if tmp19 != nil { panic(tmp19) }; return tmp7 } else { return nil } } else {
//line :157:1
					return nil } } else {
//line :156:1
						return nil } }





func A_arbace_repl_source_fn_fn__1239000039_A_New_O(p0 any) *A_arbace_repl_source_fn_fn__1239000039_A { A_arbace_repl_source_fn_fn__1239000039_A_Init(); t := &A_arbace_repl_source_fn_fn__1239000039_A{}; t.Ctor_O(p0); return t }
//line :162:1
func (t *A_arbace_repl_source_fn_fn__1239000039_A) Ctor_O(c__text any) { t.F_text = c__text }
//line :162:1
func (t *A_arbace_repl_source_fn_fn__1239000039_A) Invoke_O_O__O(self, this__1 any) any { var i__2 any; var tmp1 *lang.Var;
											A_arbace_repl_A_Init(); tmp1 = A_arbace_repl_A_const_78; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_New_O(this__1); var tmp4 *jrt.Class; A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_Init(); tmp4 = A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_fn_class; i__2 = tmp2.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), this__1, Lit_79); var tmp5 /*line :164:1*/*jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_text); jrt.NN(tmp5).Append_C__StringBuilder(lang.RT_CharCast_O__C(i__2)); return i__2 }
//line :163:1
func A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_New_O(p0 any) *A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A { A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_Init(); t := &A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A{}; t.Ctor_O(p0); return t }
//line :163:1
func (t *A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A) Ctor_O(c__this any) { t.F_this = c__this }
//line :163:1
func (t *A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A) Invoke_O__O(self any) any { return lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(t.F_this, Lit_79, false) }








func A_arbace_repl_source_A_New() *A_arbace_repl_source_A { A_arbace_repl_source_A_Init(); t := &A_arbace_repl_source_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_repl_source_A) Ctor() {}
//line :172:1
func (t *A_arbace_repl_source_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, n__2 any) any { var tmp1 *lang.Var; A_arbace_repl_A_Init(); tmp1 = A_arbace_repl_A_const_17; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_repl_A_Init(); tmp3 = A_arbace_repl_A_const_40; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_repl_A_Init(); tmp5 = A_arbace_repl_A_const_57; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_repl_A_Init(); tmp7 = A_arbace_repl_A_const_82; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_repl_A_Init(); tmp9 = A_arbace_repl_A_const_57; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_repl_A_Init(); tmp11 = A_arbace_repl_A_const_17; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_repl_A_Init(); tmp13 = A_arbace_repl_A_const_40; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_repl_A_Init(); tmp15 = A_arbace_repl_A_const_57; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_repl_A_Init(); tmp17 = A_arbace_repl_A_const_83; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_repl_A_Init(); tmp19 = A_arbace_repl_A_const_57; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_repl_A_Init(); tmp21 = A_arbace_repl_A_const_17; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_repl_A_Init(); tmp23 = A_arbace_repl_A_const_40; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_repl_A_Init(); tmp25 = A_arbace_repl_A_const_57; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 any; A_arbace_repl_A_Init(); tmp27 = A_arbace_repl_A_const_84; var tmp28 any = tmp26.Invoke_O__O(tmp27); var tmp29 *lang.Var; A_arbace_repl_A_Init(); tmp29 = A_arbace_repl_A_const_57; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Var; A_arbace_repl_A_Init(); tmp31 = A_arbace_repl_A_const_17; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 *lang.Var; A_arbace_repl_A_Init(); tmp33 = A_arbace_repl_A_const_40; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *lang.Var; A_arbace_repl_A_Init(); tmp35 = A_arbace_repl_A_const_57; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 any; A_arbace_repl_A_Init(); tmp37 = A_arbace_repl_A_const_61; var tmp38 any = tmp36.Invoke_O__O(tmp37); var tmp39 *lang.Var; A_arbace_repl_A_Init(); tmp39 = A_arbace_repl_A_const_57; var tmp40 any = tmp20.Invoke_O__O(tmp22.Invoke_O__O(tmp24.Invoke_O_O__O(tmp28, tmp30.Invoke_O__O(tmp32.Invoke_O__O(tmp34.Invoke_O_O__O(tmp38, lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()).Invoke_O__O(n__2))))))); var tmp41 *lang.Var; A_arbace_repl_A_Init(); tmp41 = A_arbace_repl_A_const_57; var tmp42 lang.IFn = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()); var tmp43 *lang.Var; A_arbace_repl_A_Init(); tmp43 = A_arbace_repl_A_const_17; var tmp44 lang.IFn = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()); var tmp45 *lang.Var; A_arbace_repl_A_Init(); tmp45 = A_arbace_repl_A_const_40; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 *lang.Var; A_arbace_repl_A_Init(); tmp47 = A_arbace_repl_A_const_57; var tmp48 lang.IFn = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()); var tmp49 any; A_arbace_repl_A_Init(); tmp49 = A_arbace_repl_A_const_85; var tmp50 any = tmp48.Invoke_O__O(tmp49); var tmp51 *lang.Var; A_arbace_repl_A_Init(); tmp51 = A_arbace_repl_A_const_57; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O_O__O(tmp18, tmp40, tmp42.Invoke_O__O(tmp44.Invoke_O__O(tmp46.Invoke_O_O__O(tmp50, lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()).Invoke_O__O(Lit_165))))))))) }








func A_arbace_repl_apropos_A_New() *A_arbace_repl_apropos_A { A_arbace_repl_apropos_A_Init(); t := &A_arbace_repl_apropos_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_repl_apropos_A) Ctor() {}
//line :181:1
func (t *A_arbace_repl_apropos_A) Invoke_O_O__O(self, str_or_pattern__0 any) any { var matches_QMARK___2 any; if




	jrt.Pattern_InstanceOf(str_or_pattern__0) { var tmp1 any = A_arbace_repl_apropos_fn__1239000052_A_New_O(str_or_pattern__0); var tmp2 *jrt.Class; A_arbace_repl_apropos_fn__1239000052_A_Init(); tmp2 = A_arbace_repl_apropos_fn__1239000052_A_fn_class; matches_QMARK___2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) } else { var tmp3 any = A_arbace_repl_apropos_fn__1239000054_A_New_O(str_or_pattern__0); var tmp4 *jrt.Class; A_arbace_repl_apropos_fn__1239000054_A_Init(); tmp4 = A_arbace_repl_apropos_fn__1239000054_A_fn_class; matches_QMARK___2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil) }; var tmp5 /*line :189:1*/*lang.Var; A_arbace_repl_A_Init(); tmp5 = A_arbace_repl_A_const_86; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_repl_A_Init(); tmp7 = A_arbace_repl_A_const_42; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any = A_arbace_repl_apropos_fn__1239000056_A_New_O(matches_QMARK___2); var tmp10 *jrt.Class; A_arbace_repl_apropos_fn__1239000056_A_Init(); tmp10 = A_arbace_repl_apropos_fn__1239000056_A_fn_class; var tmp11 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var tmp12 *lang.Var; A_arbace_repl_A_Init(); tmp12 = A_arbace_repl_A_const_48; return tmp6.Invoke_O__O(tmp8.Invoke_O_O__O(tmp11, lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke__O())) }
//line :186:1
func A_arbace_repl_apropos_fn__1239000052_A_New_O(p0 any) *A_arbace_repl_apropos_fn__1239000052_A { A_arbace_repl_apropos_fn__1239000052_A_Init(); t := &A_arbace_repl_apropos_fn__1239000052_A{}; t.Ctor_O(p0); return t }
//line :186:1
func (t *A_arbace_repl_apropos_fn__1239000052_A) Ctor_O(c__str_or_pattern any) { t.F_str_or_pattern = c__str_or_pattern }
//line :186:1
func (t *A_arbace_repl_apropos_fn__1239000052_A) Invoke_O_O__O(self, p1__1239000049_SHARP___1 any) any {
	var tmp1 *lang.Var; A_arbace_repl_A_Init(); tmp1 = A_arbace_repl_A_const_41; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = t.F_str_or_pattern; var tmp4 *lang.Var; A_arbace_repl_A_Init(); tmp4 = A_arbace_repl_A_const_35; return tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(p1__1239000049_SHARP___1)) }
//line :186:1
func A_arbace_repl_apropos_fn__1239000054_A_New_O(p0 any) *A_arbace_repl_apropos_fn__1239000054_A { A_arbace_repl_apropos_fn__1239000054_A_Init(); t := &A_arbace_repl_apropos_fn__1239000054_A{}; t.Ctor_O(p0); return t }
//line :186:1
func (t *A_arbace_repl_apropos_fn__1239000054_A) Ctor_O(c__str_or_pattern any) { t.F_str_or_pattern = c__str_or_pattern }
//line :186:1
func (t *A_arbace_repl_apropos_fn__1239000054_A) Invoke_O_O__O(self, p1__1239000050_SHARP___1 any) any {

	var tmp1 *lang.Var; A_arbace_repl_A_Init(); tmp1 = A_arbace_repl_A_const_35; var tmp2 *jrt.String = jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(p1__1239000050_SHARP___1)); var tmp3 *lang.Var; A_arbace_repl_A_Init(); tmp3 = A_arbace_repl_A_const_35; return jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(tmp2).Contains_CharSequence__Z(jrt.CharSequence_Cast(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t.F_str_or_pattern)))).Ref() }
func A_arbace_repl_apropos_fn__1239000056_A_New_O(p0 any) *A_arbace_repl_apropos_fn__1239000056_A { A_arbace_repl_apropos_fn__1239000056_A_Init(); t := &A_arbace_repl_apropos_fn__1239000056_A{}; t.Ctor_O(p0); return t }
//line :189:1
func (t *A_arbace_repl_apropos_fn__1239000056_A) Ctor_O(c__matches_QMARK_ any) { t.F_matches_QMARK_ = c__matches_QMARK_ }
//line :189:1
func (t *A_arbace_repl_apropos_fn__1239000056_A) Invoke_O_O__O(self, ns__1 any) any { var ns_name__2 any; var tmp1 *lang.Var;
											A_arbace_repl_A_Init(); tmp1 = A_arbace_repl_A_const_35; ns_name__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(ns__1); var tmp2 /*line :191:1*/*lang.Var; A_arbace_repl_A_Init(); tmp2 = A_arbace_repl_A_const_43; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_New_O(ns_name__2); var tmp5 *jrt.Class; A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_Init(); tmp5 = A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_fn_class; var tmp6 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp7 *lang.Var; A_arbace_repl_A_Init(); tmp7 = A_arbace_repl_A_const_87; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any = t.F_matches_QMARK_; var tmp10 *lang.Var; A_arbace_repl_A_Init(); tmp10 = A_arbace_repl_A_const_51; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_repl_A_Init(); tmp12 = A_arbace_repl_A_const_88; return tmp3.Invoke_O_O__O(tmp6, tmp8.Invoke_O_O__O(tmp9, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(ns__1)))) }
//line :191:1
func A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_New_O(p0 any) *A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A { A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_Init(); t := &A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A{}; t.Ctor_O(p0); return t }
//line :191:1
func (t *A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A) Ctor_O(c__ns_name any) { t.F_ns_name = c__ns_name }
//line :191:1
func (t *A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A) Invoke_O_O__O(self, p1__1239000051_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_repl_A_Init(); tmp1 = A_arbace_repl_A_const_34; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = t.F_ns_name; var tmp4 *lang.Var; A_arbace_repl_A_Init(); tmp4 = A_arbace_repl_A_const_35; return tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(p1__1239000051_SHARP___1)) }



func A_arbace_repl_dir_fn_A_New() *A_arbace_repl_dir_fn_A { A_arbace_repl_dir_fn_A_Init(); t := &A_arbace_repl_dir_fn_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_repl_dir_fn_A) Ctor() {}
//line :195:1
func (t *A_arbace_repl_dir_fn_A) Invoke_O_O__O(self, ns__0 any) any {



	var tmp1 *lang.Var; A_arbace_repl_A_Init(); tmp1 = A_arbace_repl_A_const_86; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_repl_A_Init(); tmp3 = A_arbace_repl_A_const_43; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_repl_A_Init(); tmp5 = A_arbace_repl_A_const_18; var tmp6 any = jrt.NN(tmp5).GetRawRoot__O(); var tmp7 *lang.Var; A_arbace_repl_A_Init(); tmp7 = A_arbace_repl_A_const_88; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_repl_A_Init(); tmp9 = A_arbace_repl_A_const_89; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_repl_A_Init(); tmp11 = A_arbace_repl_A_const_90; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_repl_A_Init(); tmp13 = A_arbace_repl_A_const_91; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, tmp8.Invoke_O__O(tmp10.Invoke_O__O(lang.RT_Get_O_O_O__O(tmp12.Invoke_O__O(jrt.NN(tmp13).Get__O()), ns__0, ns__0)))))
}
func A_arbace_repl_dir_A_New() *A_arbace_repl_dir_A { A_arbace_repl_dir_A_Init(); t := &A_arbace_repl_dir_A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_repl_dir_A) Ctor() {}
//line :201:1
func (t *A_arbace_repl_dir_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, nsname__2 any) any { var tmp1 *lang.Var; A_arbace_repl_A_Init(); tmp1 = A_arbace_repl_A_const_17; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_repl_A_Init(); tmp3 = A_arbace_repl_A_const_40; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_repl_A_Init(); tmp5 = A_arbace_repl_A_const_57; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_repl_A_Init(); tmp7 = A_arbace_repl_A_const_92; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_repl_A_Init(); tmp9 = A_arbace_repl_A_const_57; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_repl_A_Init(); tmp11 = A_arbace_repl_A_const_65; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_repl_A_Init(); tmp13 = A_arbace_repl_A_const_93; var tmp14 any = jrt.NN(tmp13).GetRawRoot__O(); var tmp15 *lang.Var; A_arbace_repl_A_Init(); tmp15 = A_arbace_repl_A_const_17; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_repl_A_Init(); tmp17 = A_arbace_repl_A_const_40; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_repl_A_Init(); tmp19 = A_arbace_repl_A_const_57; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_repl_A_Init(); tmp21 = A_arbace_repl_A_const_94; var tmp22 any = tmp20.Invoke_O__O(tmp21); var tmp23 *lang.Var; A_arbace_repl_A_Init(); tmp23 = A_arbace_repl_A_const_57; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_repl_A_Init(); tmp25 = A_arbace_repl_A_const_17; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_repl_A_Init(); tmp27 = A_arbace_repl_A_const_40; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_repl_A_Init(); tmp29 = A_arbace_repl_A_const_57; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 any; A_arbace_repl_A_Init(); tmp31 = A_arbace_repl_A_const_95; var tmp32 any = tmp30.Invoke_O__O(tmp31); var tmp33 *lang.Var; A_arbace_repl_A_Init(); tmp33 = A_arbace_repl_A_const_57; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *lang.Var; A_arbace_repl_A_Init(); tmp35 = A_arbace_repl_A_const_17; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *lang.Var; A_arbace_repl_A_Init(); tmp37 = A_arbace_repl_A_const_40; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 *lang.Var; A_arbace_repl_A_Init(); tmp39 = A_arbace_repl_A_const_57; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 any; A_arbace_repl_A_Init(); tmp41 = A_arbace_repl_A_const_61; var tmp42 any = tmp40.Invoke_O__O(tmp41); var tmp43 *lang.Var; A_arbace_repl_A_Init(); tmp43 = A_arbace_repl_A_const_57; var tmp44 any = tmp10.Invoke_O__O(tmp12.Invoke_O_O__O(tmp14, tmp16.Invoke_O__O(tmp18.Invoke_O_O__O(tmp22, tmp24.Invoke_O__O(tmp26.Invoke_O__O(tmp28.Invoke_O_O__O(tmp32, tmp34.Invoke_O__O(tmp36.Invoke_O__O(tmp38.Invoke_O_O__O(tmp42, lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()).Invoke_O__O(nsname__2))))))))))); var tmp45 *lang.Var; A_arbace_repl_A_Init(); tmp45 = A_arbace_repl_A_const_57; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 *lang.Var; A_arbace_repl_A_Init(); tmp47 = A_arbace_repl_A_const_17; var tmp48 lang.IFn = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()); var tmp49 *lang.Var; A_arbace_repl_A_Init(); tmp49 = A_arbace_repl_A_const_40; var tmp50 lang.IFn = lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()); var tmp51 *lang.Var; A_arbace_repl_A_Init(); tmp51 = A_arbace_repl_A_const_57; var tmp52 lang.IFn = lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()); var tmp53 any; A_arbace_repl_A_Init(); tmp53 = A_arbace_repl_A_const_96; var tmp54 any = tmp52.Invoke_O__O(tmp53); var tmp55 *lang.Var; A_arbace_repl_A_Init(); tmp55 = A_arbace_repl_A_const_57; var tmp56 lang.IFn = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()); var tmp57 any; A_arbace_repl_A_Init(); tmp57 = A_arbace_repl_A_const_94; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp44, tmp46.Invoke_O__O(tmp48.Invoke_O__O(tmp50.Invoke_O_O__O(tmp54, tmp56.Invoke_O__O(tmp57)))))) }





func A_arbace_repl_demunge_A_New() *A_arbace_repl_demunge_A { A_arbace_repl_demunge_A_Init(); t := &A_arbace_repl_demunge_A{}; t.Ctor(); return t }
//line :207:1
func (t *A_arbace_repl_demunge_A) Ctor() {}
//line :207:1
func (t *A_arbace_repl_demunge_A) Invoke_O_O__O(self, fn_name__0 any) any {




	return lang.Compiler_Demunge_String__String(jrt.String_Cast(fn_name__0)).Ref()
}
func A_arbace_repl_root_cause_A_New() *A_arbace_repl_root_cause_A { A_arbace_repl_root_cause_A_Init(); t := &A_arbace_repl_root_cause_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_repl_root_cause_A) Ctor() {}
//line :214:1
func (t *A_arbace_repl_root_cause_A) Invoke_O_O__O(self, t__0 any) any { { var cause__2 any = t__0; L1: for {





	var tmp1 any; var and__1927000168__auto____3 bool = lang.Compiler_CompilerException_InstanceOf(cause__2); if and__1927000168__auto____3 {
		var tmp2 *lang.Var; A_arbace_repl_A_Init(); tmp2 = A_arbace_repl_A_const_97; tmp1 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_CompilerException_Cast(cause__2).F_source.Ref(), Lit_156) } else {
//line :220:1
			tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }; if jrt.A2g_Truth(tmp1) { return cause__2 } else { var temp__1927000408__auto____3 any = jrt.Throwable_Cast(cause__2).GetCause__Throwable()


				if jrt.A2g_Truth(temp__1927000408__auto____3) { var cause__4 any = temp__1927000408__auto____3
					cause__2 = cause__4; continue L1 } else {
//line :223:1
						return cause__2 } } } }; /*line :214:1*/panic("a2g: unreachable") }












func A_arbace_repl_stack_element_str_A_New() *A_arbace_repl_stack_element_str_A { A_arbace_repl_stack_element_str_A_Init(); t := &A_arbace_repl_stack_element_str_A{}; t.Ctor(); return t }
//line :227:1
func (t *A_arbace_repl_stack_element_str_A) Ctor() {}
//line :227:1
func (t *A_arbace_repl_stack_element_str_A) Invoke_O_O__O(self, el__0 any) any { var file__2 any = jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetFileName__String().Ref(); var clojure_fn_QMARK___3 any; var and__1927000168__auto____3 any = file__2; if




	jrt.A2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 bool = jrt.NN(jrt.String_Cast(file__2)).EndsWith_String__Z(Lit_175); if or__1927000174__auto____4 { clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____4).Ref() } else { var or__1927000174__auto____5 bool = jrt.NN(jrt.String_Cast(file__2)).EndsWith_String__Z(Lit_176); if or__1927000174__auto____5 { clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool = jrt.NN(jrt.String_Cast(file__2)).EndsWith_String__Z(Lit_177); if or__1927000174__auto____6 { clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____6).Ref() } else {


		clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(file__2, Lit_156)).Ref() } } } } else {
//line :232:1
			clojure_fn_QMARK___3 = and__1927000168__auto____3 }; var tmp1 /*line :236:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_178, nil, Lit_148, nil, Lit_179); var tmp2 any; if jrt.A2g_Truth(clojure_fn_QMARK___3) {
				var tmp3 *lang.Var; A_arbace_repl_A_Init(); tmp3 = A_arbace_repl_A_const_98; tmp2 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetClassName__String().Ref()) } else {
					tmp2 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_180, nil), jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetClassName__String().Ref(), nil, jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetMethodName__String().Ref())).Ref() }; return /*line :236:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil, jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetFileName__String().Ref(), nil, jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetLineNumber__I()).Ref(), nil)).Ref() }




func A_arbace_repl_pst_A_New() *A_arbace_repl_pst_A { A_arbace_repl_pst_A_Init(); t := &A_arbace_repl_pst_A{}; t.Ctor(); return t }
//line :241:1
func (t *A_arbace_repl_pst_A) Ctor() {}
//line :241:1
func (t *A_arbace_repl_pst_A) Invoke_O_O_O__O(self, e__0, depth__1 any) any {










	var tmp1 *lang.Var; A_arbace_repl_A_Init(); tmp1 = A_arbace_repl_A_const_101; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_repl_A_Init(); tmp3 = A_arbace_repl_A_const_66; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_repl_A_Init(); tmp5 = A_arbace_repl_A_const_102; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_repl_A_Init(); tmp7 = A_arbace_repl_A_const_103; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, jrt.NN(tmp7).Get__O()))
//line :241:1
	var tmp8 any; tmp49 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)











		{ var tmp9 any; A_arbace_repl_A_Init(); tmp9 = A_arbace_repl_A_const_104; var tmp10 lang.IFn = lang.IFn_Cast(tmp9); var tmp11 *lang.Keyword; A_arbace_repl_A_Init(); tmp11 = A_arbace_repl_A_const_105; var tmp12 *lang.Keyword = tmp11; var tmp13 *lang.Var; A_arbace_repl_A_Init(); tmp13 = A_arbace_repl_A_const_106; if jrt.A2g_Truth(tmp10.Invoke_O__O(jrt.NN(tmp12).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(e__0)))) {

			var tmp14 *lang.Var; A_arbace_repl_A_Init(); tmp14 = A_arbace_repl_A_const_29; lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(Lit_150) }
			var tmp15 *lang.Var; A_arbace_repl_A_Init(); tmp15 = A_arbace_repl_A_const_29; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_145, nil, nil); var tmp18 *lang.Var; A_arbace_repl_A_Init(); tmp18 = A_arbace_repl_A_const_107; var tmp19 any = jrt.NN(jrt.Class_Cast(lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(e__0))).GetSimpleName__String().Ref(); var tmp20 any = jrt.Throwable_Cast(e__0).GetMessage__String().Ref(); var tmp21 *jrt.String; var temp__1927000414__auto____9 any; var tmp22 *lang.Var

			A_arbace_repl_A_Init(); tmp22 = A_arbace_repl_A_const_106; temp__1927000414__auto____9 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(e__0); if jrt.A2g_Truth(temp__1927000414__auto____9) { var info__10 any = temp__1927000414__auto____9; var tmp23 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_145, nil); var tmp24 *lang.Var; A_arbace_repl_A_Init(); tmp24 = A_arbace_repl_A_const_108; tmp21 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp23, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(info__10))) } else { tmp21 = nil }
//line :256:1
			tmp16.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp17, jrt.RefArrayOf(jrt.Object_class, tmp19, nil, tmp20, tmp21.Ref())).Ref())
//line :241:1
			var st__5 any = jrt.Throwable_Cast(e__0).GetStackTrace__StackTraceElement1().Ref(); var cause__6 any = jrt.Throwable_Cast(e__0).GetCause__Throwable(); var seq_1239000072__7 any; var tmp25 *lang.Var



















			A_arbace_repl_A_Init(); tmp25 = A_arbace_repl_A_const_17; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_repl_A_Init(); tmp27 = A_arbace_repl_A_const_109; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_repl_A_Init(); tmp29 = A_arbace_repl_A_const_110; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 any = A_arbace_repl_pst_fn__1239000076_A_New(); var tmp32 *jrt.Class; A_arbace_repl_pst_fn__1239000076_A_Init(); tmp32 = A_arbace_repl_pst_fn__1239000076_A_fn_class; seq_1239000072__7 = tmp26.Invoke_O__O(tmp28.Invoke_O_O__O(depth__1, tmp30.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil), st__5)))
//line :241:1
			var chunk_1239000073__8 any; var count_1239000074__9 int64 = 0; var i_1239000075__10 int64 = 0; L1: for {



















				if lang.Numbers_Lt_J_J__Z(i_1239000075__10, count_1239000074__9) { var el__11 any = lang.Indexed_Cast(chunk_1239000073__8).Nth_I__O(lang.RT_IntCast_J__I(i_1239000075__10)); var tmp33 *lang.Var


					A_arbace_repl_A_Init(); tmp33 = A_arbace_repl_A_const_29; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_151, nil); var tmp36 *lang.Var; A_arbace_repl_A_Init(); tmp36 = A_arbace_repl_A_const_112; tmp34.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp35, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()).Invoke_O__O(el__11))).Ref())
//line :261:1
					seq_1239000072__7, chunk_1239000073__8, count_1239000074__9, i_1239000075__10 = seq_1239000072__7, chunk_1239000073__8, count_1239000074__9, lang.Numbers_Unchecked_inc_J__J(i_1239000075__10); continue L1 } else { var temp__1927000414__auto____11 any; var tmp37 *lang.Var; A_arbace_repl_A_Init(); tmp37 = A_arbace_repl_A_const_17; temp__1927000414__auto____11 = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke_O__O(seq_1239000072__7); if jrt.A2g_Truth(temp__1927000414__auto____11) { var seq_1239000072__12 any = temp__1927000414__auto____11; var tmp38 *lang.Var; A_arbace_repl_A_Init(); tmp38 = A_arbace_repl_A_const_27; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()).Invoke_O__O(seq_1239000072__12)) { var c__1927000678__auto____13 any; var tmp39 *lang.Var; A_arbace_repl_A_Init(); tmp39 = A_arbace_repl_A_const_28; c__1927000678__auto____13 = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()).Invoke_O__O(seq_1239000072__12); var tmp40 *lang.Var; A_arbace_repl_A_Init(); tmp40 = A_arbace_repl_A_const_33; seq_1239000072__7, chunk_1239000073__8, count_1239000074__9, i_1239000075__10 = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()).Invoke_O__O(seq_1239000072__12), c__1927000678__auto____13, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var el__13 any; var tmp41 *lang.Var; A_arbace_repl_A_Init(); tmp41 = A_arbace_repl_A_const_18; el__13 = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()).Invoke_O__O(seq_1239000072__12)


						var tmp42 *lang.Var; A_arbace_repl_A_Init(); tmp42 = A_arbace_repl_A_const_29; var tmp43 lang.IFn = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()); var tmp44 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_151, nil); var tmp45 *lang.Var; A_arbace_repl_A_Init(); tmp45 = A_arbace_repl_A_const_112; tmp43.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp44, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()).Invoke_O__O(el__13))).Ref())
//line :261:1
						var tmp46 *lang.Var; A_arbace_repl_A_Init(); tmp46 = A_arbace_repl_A_const_15; seq_1239000072__7, chunk_1239000073__8, count_1239000074__9, i_1239000075__10 = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()).Invoke_O__O(seq_1239000072__12), nil, 0, 0; continue L1 } } }
//line :241:1
				break L1
			}






















			if jrt.A2g_Truth(cause__6) {
				var tmp47 *lang.Var; A_arbace_repl_A_Init(); tmp47 = A_arbace_repl_A_const_29; lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()).Invoke_O__O(Lit_152)
				var tmp48 *lang.Var; A_arbace_repl_A_Init(); tmp48 = A_arbace_repl_A_const_99; tmp8 = lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()).Invoke_O_O__O(cause__6, lang.Numbers_Min_O_J__O(depth__1, lang.Numbers_Add_J_J__J(2, lang.Numbers_Minus_J_J__J(int64(lang.RT_Count_O__I(jrt.Throwable_Cast(cause__6).GetStackTrace__StackTraceElement1().Ref())), int64(lang.RT_Count_O__I(st__5)))))) } else {
//line :265:1
					tmp8 = nil } }
//line :241:1
		return nil }(); var tmp50 *lang.Var










	A_arbace_repl_A_Init(); tmp50 = A_arbace_repl_A_const_100; lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()).Invoke__O()
//line :241:1
	if tmp49 != nil { panic(tmp49) }; return tmp8 }
//line :241:1
func (t *A_arbace_repl_pst_A) Invoke_O_O__O(self, e_or_depth__0 any) any {





	if jrt.Throwable_InstanceOf(e_or_depth__0) {
		var tmp1 *lang.Var; A_arbace_repl_A_Init(); tmp1 = A_arbace_repl_A_const_99; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_repl_A_Init(); tmp3 = A_arbace_repl_A_const_114; return tmp2.Invoke_O_O__O(e_or_depth__0, tmp3) } else {
//line :247:1
			var temp__1927000414__auto____2 any; var tmp4 *lang.Var; A_arbace_repl_A_Init(); tmp4 = A_arbace_repl_A_const_113; temp__1927000414__auto____2 = jrt.NN(tmp4).Get__O()

			if jrt.A2g_Truth(temp__1927000414__auto____2) { var e__3 any = temp__1927000414__auto____2; var tmp5 *lang.Var
				A_arbace_repl_A_Init(); tmp5 = A_arbace_repl_A_const_99; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_repl_A_Init(); tmp7 = A_arbace_repl_A_const_115; return tmp6.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(e__3), e_or_depth__0) } else {
//line :249:1
					return nil } } }
//line :241:1
func (t *A_arbace_repl_pst_A) Invoke_O__O(self any) any {



	var tmp1 *lang.Var; A_arbace_repl_A_Init(); tmp1 = A_arbace_repl_A_const_99; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_repl_A_Init(); tmp3 = A_arbace_repl_A_const_114; return tmp2.Invoke_O__O(tmp3)
}















func A_arbace_repl_pst_fn__1239000076_A_New() *A_arbace_repl_pst_fn__1239000076_A { A_arbace_repl_pst_fn__1239000076_A_Init(); t := &A_arbace_repl_pst_fn__1239000076_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_repl_pst_fn__1239000076_A) Ctor() {}
//line :262:1
func (t *A_arbace_repl_pst_fn__1239000076_A) Invoke_O_O__O(self, p1__1239000071_SHARP___1 any) any { var tmp1 any; A_arbace_repl_A_Init(); tmp1 = A_arbace_repl_A_const_111; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); return tmp2.Invoke_O__O(lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(p1__1239000071_SHARP___1, Lit_154, false)) }











func A_arbace_repl_thread_stopper_A_New() *A_arbace_repl_thread_stopper_A { A_arbace_repl_thread_stopper_A_Init(); t := &A_arbace_repl_thread_stopper_A{}; t.Ctor(); return t }
//line :274:1
func (t *A_arbace_repl_thread_stopper_A) Ctor() {}
//line :274:1
func (t *A_arbace_repl_thread_stopper_A) Invoke_O_O__O(self, thread__0 any) any {



	var tmp1 any = A_arbace_repl_thread_stopper_fn__1239000079_A_New_O(thread__0); var tmp2 *jrt.Class; A_arbace_repl_thread_stopper_fn__1239000079_A_Init(); tmp2 = A_arbace_repl_thread_stopper_fn__1239000079_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :274:1
func (t *A_arbace_repl_thread_stopper_A) Invoke_O__O(self any) any {


	var tmp1 *lang.Var; A_arbace_repl_A_Init(); tmp1 = A_arbace_repl_A_const_117; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(jrt.Thread_CurrentThread__Thread()) }
func A_arbace_repl_thread_stopper_fn__1239000079_A_New_O(p0 any) *A_arbace_repl_thread_stopper_fn__1239000079_A { A_arbace_repl_thread_stopper_fn__1239000079_A_Init(); t := &A_arbace_repl_thread_stopper_fn__1239000079_A{}; t.Ctor_O(p0); return t }
//line :278:1
func (t *A_arbace_repl_thread_stopper_fn__1239000079_A) Ctor_O(c__thread any) { t.F_thread = c__thread }
//line :278:1
func (t *A_arbace_repl_thread_stopper_fn__1239000079_A) Invoke_O_O__O(self, msg__1 any) any { var tmp1 any = t.F_thread; var tmp2 *jrt.Class; A_arbace_repl_A_Init(); tmp2 = A_arbace_repl_A_const_116; var tmp3 *jrt.Class = tmp2; return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(tmp1, Lit_183, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(tmp3, jrt.RefArrayOf(jrt.Object_class, msg__1)))) }

func A_arbace_repl_set_break_handler_BANG__A_New() *A_arbace_repl_set_break_handler_BANG__A { A_arbace_repl_set_break_handler_BANG__A_Init(); t := &A_arbace_repl_set_break_handler_BANG__A{}; t.Ctor(); return t }
//line :280:1
func (t *A_arbace_repl_set_break_handler_BANG__A) Ctor() {}
//line :280:1
func (t *A_arbace_repl_set_break_handler_BANG__A) Invoke_O_O__O(self, f__0 any) any {





	var tmp1 *jrt.Class = lang.RT_ClassForNameNonLoading_String__Class(Lit_158); var tmp2 any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class(Lit_158), jrt.RefArrayOf(jrt.Object_class, Lit_160)); var tmp3 any; var p__840000142__auto____2 any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class(Lit_161), jrt.RefArrayOf(jrt.Object_class)); var tmp4 *lang.Var

	A_arbace_repl_A_Init(); tmp4 = A_arbace_repl_A_const_77; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any = A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_New_O(f__0); var tmp7 *jrt.Class; A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_Init(); tmp7 = A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_fn_class; tmp5.Invoke_O_O__O(p__840000142__auto____2, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_159, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil))))
//line :286:1
	tmp3 = p__840000142__auto____2; return lang.Reflector_InvokeStaticMethod_Class_String_O1__O(tmp1, Lit_159, jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3)) }
//line :280:1
func (t *A_arbace_repl_set_break_handler_BANG__A) Invoke_O__O(self any) any {



	var tmp1 *lang.Var; A_arbace_repl_A_Init(); tmp1 = A_arbace_repl_A_const_118; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_repl_A_Init(); tmp3 = A_arbace_repl_A_const_117; return tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke__O())
}


func A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_New_O(p0 any) *A_arbace_repl_set_break_handler_BANG__fn__1239000082_A { A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_Init(); t := &A_arbace_repl_set_break_handler_BANG__fn__1239000082_A{}; t.Ctor_O(p0); return t }
//line :288:1
func (t *A_arbace_repl_set_break_handler_BANG__fn__1239000082_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :288:1
func (t *A_arbace_repl_set_break_handler_BANG__fn__1239000082_A) Invoke_O_O_O__O(self, this__1, signal__2 any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(t.F_f); return tmp1.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_163, nil), jrt.RefArrayOf(jrt.Object_class, nil, signal__2)).Ref())
}












type A_arbace_repl_A struct{ jrt.Object }

var A_arbace_repl_A_const_0 *lang.Var

var A_arbace_repl_A_const_1 *lang.Var

var A_arbace_repl_A_const_2 any

var A_arbace_repl_A_const_3 any

var A_arbace_repl_A_const_4 *lang.Var

var A_arbace_repl_A_const_5 *lang.Var

var A_arbace_repl_A_const_6 *lang.Var

var A_arbace_repl_A_const_7 any

var A_arbace_repl_A_const_8 *lang.Var

var A_arbace_repl_A_const_9 *lang.Var

var A_arbace_repl_A_const_10 *lang.Var

var A_arbace_repl_A_const_11 *lang.Var

var A_arbace_repl_A_const_12 *lang.Keyword

var A_arbace_repl_A_const_13 *lang.Keyword

var A_arbace_repl_A_const_14 *lang.Var

var A_arbace_repl_A_const_15 *lang.Var

var A_arbace_repl_A_const_16 *lang.Var

var A_arbace_repl_A_const_17 *lang.Var

var A_arbace_repl_A_const_18 *lang.Var

var A_arbace_repl_A_const_19 *lang.Keyword

var A_arbace_repl_A_const_20 *lang.Keyword

var A_arbace_repl_A_const_21 *lang.Keyword

var A_arbace_repl_A_const_22 *lang.Keyword

var A_arbace_repl_A_const_23 *lang.Keyword

var A_arbace_repl_A_const_24 *lang.Keyword

var A_arbace_repl_A_const_25 *lang.Keyword

var A_arbace_repl_A_const_26 *lang.Var

var A_arbace_repl_A_const_27 *lang.Var

var A_arbace_repl_A_const_28 *lang.Var

var A_arbace_repl_A_const_29 *lang.Var

var A_arbace_repl_A_const_30 *lang.Var

var A_arbace_repl_A_const_31 *lang.Var

var A_arbace_repl_A_const_32 *lang.Var

var A_arbace_repl_A_const_33 *lang.Var

var A_arbace_repl_A_const_34 *lang.Var

var A_arbace_repl_A_const_35 *lang.Var

var A_arbace_repl_A_const_36 *lang.Var

var A_arbace_repl_A_const_37 any

var A_arbace_repl_A_const_38 *lang.Var

var A_arbace_repl_A_const_39 *lang.Var

var A_arbace_repl_A_const_40 *lang.Var

var A_arbace_repl_A_const_41 *lang.Var

var A_arbace_repl_A_const_42 *lang.Var

var A_arbace_repl_A_const_43 *lang.Var

var A_arbace_repl_A_const_44 *lang.Var

var A_arbace_repl_A_const_45 *lang.Var

var A_arbace_repl_A_const_46 *lang.Var

var A_arbace_repl_A_const_47 *lang.Var

var A_arbace_repl_A_const_48 *lang.Var

var A_arbace_repl_A_const_49 *lang.Var

var A_arbace_repl_A_const_50 *lang.Var

var A_arbace_repl_A_const_51 *lang.Var

var A_arbace_repl_A_const_52 *lang.Var

var A_arbace_repl_A_const_53 *lang.Var

var A_arbace_repl_A_const_54 any

var A_arbace_repl_A_const_55 *lang.Var

var A_arbace_repl_A_const_56 *lang.Var

var A_arbace_repl_A_const_57 *lang.Var

var A_arbace_repl_A_const_58 any

var A_arbace_repl_A_const_59 any

var A_arbace_repl_A_const_60 any

var A_arbace_repl_A_const_61 any

var A_arbace_repl_A_const_62 any

var A_arbace_repl_A_const_63 any

var A_arbace_repl_A_const_64 any

var A_arbace_repl_A_const_65 *lang.Var

var A_arbace_repl_A_const_66 *lang.Var

var A_arbace_repl_A_const_67 any

var A_arbace_repl_A_const_68 any

var A_arbace_repl_A_const_69 any

var A_arbace_repl_A_const_70 any

var A_arbace_repl_A_const_71 any

var A_arbace_repl_A_const_72 any

var A_arbace_repl_A_const_73 *lang.Keyword

var A_arbace_repl_A_const_74 *jrt.Class

var A_arbace_repl_A_const_75 any

var A_arbace_repl_A_const_76 *lang.Keyword

var A_arbace_repl_A_const_77 *lang.Var

var A_arbace_repl_A_const_78 *lang.Var

var A_arbace_repl_A_const_79 *lang.Keyword

var A_arbace_repl_A_const_80 *lang.Var

var A_arbace_repl_A_const_81 *lang.Var

var A_arbace_repl_A_const_82 any

var A_arbace_repl_A_const_83 any

var A_arbace_repl_A_const_84 any

var A_arbace_repl_A_const_85 any

var A_arbace_repl_A_const_86 *lang.Var

var A_arbace_repl_A_const_87 *lang.Var

var A_arbace_repl_A_const_88 *lang.Var

var A_arbace_repl_A_const_89 *lang.Var

var A_arbace_repl_A_const_90 *lang.Var

var A_arbace_repl_A_const_91 *lang.Var

var A_arbace_repl_A_const_92 any

var A_arbace_repl_A_const_93 *lang.Var

var A_arbace_repl_A_const_94 any

var A_arbace_repl_A_const_95 any

var A_arbace_repl_A_const_96 any

var A_arbace_repl_A_const_97 *lang.Var

var A_arbace_repl_A_const_98 *lang.Var

var A_arbace_repl_A_const_99 *lang.Var

var A_arbace_repl_A_const_100 *lang.Var

var A_arbace_repl_A_const_101 *lang.Var

var A_arbace_repl_A_const_102 *lang.Var

var A_arbace_repl_A_const_103 *lang.Var

var A_arbace_repl_A_const_104 any

var A_arbace_repl_A_const_105 *lang.Keyword

var A_arbace_repl_A_const_106 *lang.Var

var A_arbace_repl_A_const_107 *lang.Var

var A_arbace_repl_A_const_108 *lang.Var

var A_arbace_repl_A_const_109 *lang.Var

var A_arbace_repl_A_const_110 *lang.Var

var A_arbace_repl_A_const_111 any

var A_arbace_repl_A_const_112 *lang.Var

var A_arbace_repl_A_const_113 *lang.Var

var A_arbace_repl_A_const_114 any

var A_arbace_repl_A_const_115 *lang.Var

var A_arbace_repl_A_const_116 *jrt.Class

var A_arbace_repl_A_const_117 *lang.Var

var A_arbace_repl_A_const_118 *lang.Var

var A_arbace_repl_A_init jrt.ClassInit

func A_arbace_repl_A_Init() { if !A_arbace_repl_A_init.Done() { A_arbace_repl_A_init.Run(A_arbace_repl_A_clinit) } }

func A_arbace_repl_A_clinit() { A_arbace_repl_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_repl_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_repl_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_repl_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_repl_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_6); A_arbace_repl_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_7); A_arbace_repl_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_repl_A_const_7 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13))); A_arbace_repl_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_repl_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_15); A_arbace_repl_A_const_10 = lang.RT_Var_String_String__Var(Lit_9, Lit_16); A_arbace_repl_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_repl_A_const_12 = lang.RT_Keyword_String_String__Keyword(nil, Lit_18); A_arbace_repl_A_const_13 = lang.RT_Keyword_String_String__Keyword(nil, Lit_19); A_arbace_repl_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_repl_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_repl_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_repl_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_repl_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_repl_A_const_19 = lang.RT_Keyword_String_String__Keyword(nil, Lit_25); A_arbace_repl_A_const_20 = lang.RT_Keyword_String_String__Keyword(nil, Lit_26); A_arbace_repl_A_const_21 = lang.RT_Keyword_String_String__Keyword(nil, Lit_27); A_arbace_repl_A_const_22 = lang.RT_Keyword_String_String__Keyword(nil, Lit_12); A_arbace_repl_A_const_23 = lang.RT_Keyword_String_String__Keyword(nil, Lit_28); A_arbace_repl_A_const_24 = lang.RT_Keyword_String_String__Keyword(nil, Lit_29); A_arbace_repl_A_const_25 = lang.RT_Keyword_String_String__Keyword(nil, Lit_5); A_arbace_repl_A_const_26 = lang.RT_Var_String_String__Var(Lit_3, Lit_30); A_arbace_repl_A_const_27 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_repl_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_repl_A_const_29 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); A_arbace_repl_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_repl_A_const_31 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_repl_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_repl_A_const_33 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); A_arbace_repl_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_38); A_arbace_repl_A_const_35 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_repl_A_const_36 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_repl_A_const_37 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_40).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_41).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref()); A_arbace_repl_A_const_38 = lang.RT_Var_String_String__Var(Lit_3, Lit_43); A_arbace_repl_A_const_39 = lang.RT_Var_String_String__Var(Lit_0, Lit_44); A_arbace_repl_A_const_40 = lang.RT_Var_String_String__Var(Lit_0, Lit_45); A_arbace_repl_A_const_41 = lang.RT_Var_String_String__Var(Lit_0, Lit_46); A_arbace_repl_A_const_42 = lang.RT_Var_String_String__Var(Lit_0, Lit_47); A_arbace_repl_A_const_43 = lang.RT_Var_String_String__Var(Lit_0, Lit_48); A_arbace_repl_A_const_44 = lang.RT_Var_String_String__Var(Lit_0, Lit_49); A_arbace_repl_A_const_45 = lang.RT_Var_String_String__Var(Lit_0, Lit_50); A_arbace_repl_A_const_46 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_repl_A_const_47 = lang.RT_Var_String_String__Var(Lit_0, Lit_52); A_arbace_repl_A_const_48 = lang.RT_Var_String_String__Var(Lit_0, Lit_53); A_arbace_repl_A_const_49 = lang.RT_Var_String_String__Var(Lit_9, Lit_54); A_arbace_repl_A_const_50 = lang.RT_Var_String_String__Var(Lit_9, Lit_55); A_arbace_repl_A_const_51 = lang.RT_Var_String_String__Var(Lit_0, Lit_56); A_arbace_repl_A_const_52 = lang.RT_Var_String_String__Var(Lit_0, Lit_57); A_arbace_repl_A_const_53 = lang.RT_Var_String_String__Var(Lit_9, Lit_58); A_arbace_repl_A_const_54 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_59).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_42).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_60).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_61).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_62).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_61).Ref())); A_arbace_repl_A_const_55 = lang.RT_Var_String_String__Var(Lit_0, Lit_63); A_arbace_repl_A_const_56 = lang.RT_Var_String_String__Var(Lit_0, Lit_64); A_arbace_repl_A_const_57 = lang.RT_Var_String_String__Var(Lit_0, Lit_65); A_arbace_repl_A_const_58 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_66).Ref(); A_arbace_repl_A_const_59 = lang.Symbol_Intern_String_String__Symbol(Lit_9, Lit_58).Ref(); A_arbace_repl_A_const_60 = lang.Symbol_Intern_String_String__Symbol(Lit_9, Lit_55).Ref(); A_arbace_repl_A_const_61 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_67).Ref(); A_arbace_repl_A_const_62 = lang.Symbol_Intern_String_String__Symbol(Lit_9, Lit_58).Ref(); A_arbace_repl_A_const_63 = lang.Symbol_Intern_String_String__Symbol(Lit_9, Lit_55).Ref(); A_arbace_repl_A_const_64 = lang.Symbol_Intern_String_String__Symbol(Lit_9, Lit_58).Ref(); A_arbace_repl_A_const_65 = lang.RT_Var_String_String__Var(Lit_0, Lit_68); A_arbace_repl_A_const_66 = lang.RT_Var_String_String__Var(Lit_0, Lit_69); A_arbace_repl_A_const_67 = lang.Symbol_Intern_String_String__Symbol(Lit_9, Lit_58).Ref(); A_arbace_repl_A_const_68 = lang.Symbol_Intern_String_String__Symbol(Lit_9, Lit_54).Ref(); A_arbace_repl_A_const_69 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_64).Ref(); A_arbace_repl_A_const_70 = lang.Symbol_Intern_String_String__Symbol(Lit_9, Lit_58).Ref(); A_arbace_repl_A_const_71 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_50).Ref(); A_arbace_repl_A_const_72 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_66).Ref(); A_arbace_repl_A_const_73 = lang.RT_Keyword_String_String__Keyword(nil, Lit_70); A_arbace_repl_A_const_74 = lang.RT_ClassForNameNonLoading_String__Class(Lit_71); A_arbace_repl_A_const_75 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_72).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref())); A_arbace_repl_A_const_76 = lang.RT_Keyword_String_String__Keyword(nil, Lit_74); A_arbace_repl_A_const_77 = lang.RT_Var_String_String__Var(Lit_0, Lit_75); A_arbace_repl_A_const_78 = lang.RT_Var_String_String__Var(Lit_0, Lit_76); A_arbace_repl_A_const_79 = lang.RT_Keyword_String_String__Keyword(nil, Lit_77); A_arbace_repl_A_const_80 = lang.RT_Var_String_String__Var(Lit_0, Lit_78); A_arbace_repl_A_const_81 = lang.RT_Var_String_String__Var(Lit_0, Lit_79); A_arbace_repl_A_const_82 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_33).Ref(); A_arbace_repl_A_const_83 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_80).Ref(); A_arbace_repl_A_const_84 = lang.Symbol_Intern_String_String__Symbol(Lit_9, Lit_81).Ref(); A_arbace_repl_A_const_85 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_39).Ref(); A_arbace_repl_A_const_86 = lang.RT_Var_String_String__Var(Lit_0, Lit_82); A_arbace_repl_A_const_87 = lang.RT_Var_String_String__Var(Lit_0, Lit_83); A_arbace_repl_A_const_88 = lang.RT_Var_String_String__Var(Lit_0, Lit_84); A_arbace_repl_A_const_89 = lang.RT_Var_String_String__Var(Lit_0, Lit_85); A_arbace_repl_A_const_90 = lang.RT_Var_String_String__Var(Lit_0, Lit_86); A_arbace_repl_A_const_91 = lang.RT_Var_String_String__Var(Lit_0, Lit_87); A_arbace_repl_A_const_92 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_88).Ref(); A_arbace_repl_A_const_93 = lang.RT_Var_String_String__Var(Lit_0, Lit_89); A_arbace_repl_A_const_94 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_90).Ref(); A_arbace_repl_A_const_95 = lang.Symbol_Intern_String_String__Symbol(Lit_9, Lit_91).Ref(); A_arbace_repl_A_const_96 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_33).Ref(); A_arbace_repl_A_const_97 = lang.RT_Var_String_String__Var(Lit_0, Lit_92); A_arbace_repl_A_const_98 = lang.RT_Var_String_String__Var(Lit_9, Lit_93); A_arbace_repl_A_const_99 = lang.RT_Var_String_String__Var(Lit_9, Lit_94); A_arbace_repl_A_const_100 = lang.RT_Var_String_String__Var(Lit_0, Lit_95); A_arbace_repl_A_const_101 = lang.RT_Var_String_String__Var(Lit_0, Lit_96); A_arbace_repl_A_const_102 = lang.RT_Var_String_String__Var(Lit_0, Lit_97); A_arbace_repl_A_const_103 = lang.RT_Var_String_String__Var(Lit_0, Lit_98); A_arbace_repl_A_const_104 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_99).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_100).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_101).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref())).Ref(); A_arbace_repl_A_const_105 = lang.RT_Keyword_String_String__Keyword(Lit_104, Lit_105); A_arbace_repl_A_const_106 = lang.RT_Var_String_String__Var(Lit_0, Lit_106); A_arbace_repl_A_const_107 = lang.RT_Var_String_String__Var(Lit_0, Lit_107); A_arbace_repl_A_const_108 = lang.RT_Var_String_String__Var(Lit_0, Lit_108); A_arbace_repl_A_const_109 = lang.RT_Var_String_String__Var(Lit_0, Lit_109); A_arbace_repl_A_const_110 = lang.RT_Var_String_String__Var(Lit_0, Lit_110); A_arbace_repl_A_const_111 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_111, Lit_112)).Ref(); A_arbace_repl_A_const_112 = lang.RT_Var_String_String__Var(Lit_9, Lit_113); A_arbace_repl_A_const_113 = lang.RT_Var_String_String__Var(Lit_0, Lit_114); A_arbace_repl_A_const_114 = jrt.Long_ValueOf_J__Long(12).Ref(); A_arbace_repl_A_const_115 = lang.RT_Var_String_String__Var(Lit_9, Lit_115); A_arbace_repl_A_const_116 = lang.RT_ClassForNameNonLoading_String__Class(Lit_116); A_arbace_repl_A_const_117 = lang.RT_Var_String_String__Var(Lit_9, Lit_117); A_arbace_repl_A_const_118 = lang.RT_Var_String_String__Var(Lit_9, Lit_118) }

func A_arbace_repl_A_New() *A_arbace_repl_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_A{}; t.Ctor(); return t }

func (t *A_arbace_repl_A) Ctor() {}

func (t *A_arbace_repl_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_A) GetClass__Class() *jrt.Class { return A_arbace_repl_A_class }

func (t *A_arbace_repl_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_A); return ok }

func A_arbace_repl_A_Cast(x any) *A_arbace_repl_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_A_class)) }; return v }



type A_arbace_repl_apropos_A struct{ jrt.Object }

func (t *A_arbace_repl_apropos_A) Is_Compiler_AOTF1() {}

var A_arbace_repl_apropos_A_fn_class *jrt.Class

var A_arbace_repl_apropos_A_init jrt.ClassInit

func A_arbace_repl_apropos_A_Init() { if !A_arbace_repl_apropos_A_init.Done() { A_arbace_repl_apropos_A_init.Run(A_arbace_repl_apropos_A_clinit) } }

func A_arbace_repl_apropos_A_clinit() { A_arbace_repl_apropos_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_119, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_apropos_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_apropos_A) GetClass__Class() *jrt.Class { return A_arbace_repl_apropos_A_class }

func (t *A_arbace_repl_apropos_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_apropos_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_apropos_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_apropos_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_apropos_A); return ok }

func A_arbace_repl_apropos_A_Cast(x any) *A_arbace_repl_apropos_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_apropos_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_apropos_A_class)) }; return v }



type A_arbace_repl_apropos_fn__1239000052_A struct{ jrt.Object; F_str_or_pattern any }

func (t *A_arbace_repl_apropos_fn__1239000052_A) Is_Compiler_AOTF1() {}

var A_arbace_repl_apropos_fn__1239000052_A_fn_class *jrt.Class

var A_arbace_repl_apropos_fn__1239000052_A_init jrt.ClassInit

func A_arbace_repl_apropos_fn__1239000052_A_Init() { if !A_arbace_repl_apropos_fn__1239000052_A_init.Done() { A_arbace_repl_apropos_fn__1239000052_A_init.Run(A_arbace_repl_apropos_fn__1239000052_A_clinit) } }

func A_arbace_repl_apropos_fn__1239000052_A_clinit() { A_arbace_repl_apropos_fn__1239000052_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_120, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_apropos_fn__1239000052_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_apropos_fn__1239000052_A) GetClass__Class() *jrt.Class { return A_arbace_repl_apropos_fn__1239000052_A_class }

func (t *A_arbace_repl_apropos_fn__1239000052_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_apropos_fn__1239000052_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_apropos_fn__1239000052_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_apropos_fn__1239000052_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_apropos_fn__1239000052_A); return ok }

func A_arbace_repl_apropos_fn__1239000052_A_Cast(x any) *A_arbace_repl_apropos_fn__1239000052_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_apropos_fn__1239000052_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_apropos_fn__1239000052_A_class)) }; return v }



type A_arbace_repl_apropos_fn__1239000054_A struct{ jrt.Object; F_str_or_pattern any }

func (t *A_arbace_repl_apropos_fn__1239000054_A) Is_Compiler_AOTF1() {}

var A_arbace_repl_apropos_fn__1239000054_A_fn_class *jrt.Class

var A_arbace_repl_apropos_fn__1239000054_A_init jrt.ClassInit

func A_arbace_repl_apropos_fn__1239000054_A_Init() { if !A_arbace_repl_apropos_fn__1239000054_A_init.Done() { A_arbace_repl_apropos_fn__1239000054_A_init.Run(A_arbace_repl_apropos_fn__1239000054_A_clinit) } }

func A_arbace_repl_apropos_fn__1239000054_A_clinit() { A_arbace_repl_apropos_fn__1239000054_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_121, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_apropos_fn__1239000054_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_apropos_fn__1239000054_A) GetClass__Class() *jrt.Class { return A_arbace_repl_apropos_fn__1239000054_A_class }

func (t *A_arbace_repl_apropos_fn__1239000054_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_apropos_fn__1239000054_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_apropos_fn__1239000054_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_apropos_fn__1239000054_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_apropos_fn__1239000054_A); return ok }

func A_arbace_repl_apropos_fn__1239000054_A_Cast(x any) *A_arbace_repl_apropos_fn__1239000054_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_apropos_fn__1239000054_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_apropos_fn__1239000054_A_class)) }; return v }



type A_arbace_repl_apropos_fn__1239000056_A struct{ jrt.Object; F_matches_QMARK_ any }

func (t *A_arbace_repl_apropos_fn__1239000056_A) Is_Compiler_AOTF1() {}

var A_arbace_repl_apropos_fn__1239000056_A_fn_class *jrt.Class

var A_arbace_repl_apropos_fn__1239000056_A_init jrt.ClassInit

func A_arbace_repl_apropos_fn__1239000056_A_Init() { if !A_arbace_repl_apropos_fn__1239000056_A_init.Done() { A_arbace_repl_apropos_fn__1239000056_A_init.Run(A_arbace_repl_apropos_fn__1239000056_A_clinit) } }

func A_arbace_repl_apropos_fn__1239000056_A_clinit() { A_arbace_repl_apropos_fn__1239000056_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_122, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_apropos_fn__1239000056_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_apropos_fn__1239000056_A) GetClass__Class() *jrt.Class { return A_arbace_repl_apropos_fn__1239000056_A_class }

func (t *A_arbace_repl_apropos_fn__1239000056_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_apropos_fn__1239000056_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_apropos_fn__1239000056_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_apropos_fn__1239000056_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_apropos_fn__1239000056_A); return ok }

func A_arbace_repl_apropos_fn__1239000056_A_Cast(x any) *A_arbace_repl_apropos_fn__1239000056_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_apropos_fn__1239000056_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_apropos_fn__1239000056_A_class)) }; return v }



type A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A struct{ jrt.Object; F_ns_name any }

func (t *A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A) Is_Compiler_AOTF1() {}

var A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_fn_class *jrt.Class

var A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_init jrt.ClassInit

func A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_Init() { if !A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_init.Done() { A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_init.Run(A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_clinit) } }

func A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_clinit() { A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_123, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A) GetClass__Class() *jrt.Class { return A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_class }

func (t *A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A); return ok }

func A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_Cast(x any) *A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_class)) }; return v }



type A_arbace_repl_demunge_A struct{ jrt.Object }

func (t *A_arbace_repl_demunge_A) Is_Compiler_AOTF1() {}

var A_arbace_repl_demunge_A_fn_class *jrt.Class

var A_arbace_repl_demunge_A_init jrt.ClassInit

func A_arbace_repl_demunge_A_Init() { if !A_arbace_repl_demunge_A_init.Done() { A_arbace_repl_demunge_A_init.Run(A_arbace_repl_demunge_A_clinit) } }

func A_arbace_repl_demunge_A_clinit() { A_arbace_repl_demunge_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_124, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_demunge_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_demunge_A) GetClass__Class() *jrt.Class { return A_arbace_repl_demunge_A_class }

func (t *A_arbace_repl_demunge_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_demunge_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_demunge_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_demunge_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_demunge_A); return ok }

func A_arbace_repl_demunge_A_Cast(x any) *A_arbace_repl_demunge_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_demunge_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_demunge_A_class)) }; return v }



type A_arbace_repl_dir_A struct{ jrt.Object }

func (t *A_arbace_repl_dir_A) Is_Compiler_AOTF3() {}

var A_arbace_repl_dir_A_fn_class *jrt.Class

var A_arbace_repl_dir_A_init jrt.ClassInit

func A_arbace_repl_dir_A_Init() { if !A_arbace_repl_dir_A_init.Done() { A_arbace_repl_dir_A_init.Run(A_arbace_repl_dir_A_clinit) } }

func A_arbace_repl_dir_A_clinit() { A_arbace_repl_dir_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_125, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_dir_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_dir_A) GetClass__Class() *jrt.Class { return A_arbace_repl_dir_A_class }

func (t *A_arbace_repl_dir_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_dir_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_dir_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_dir_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_dir_A); return ok }

func A_arbace_repl_dir_A_Cast(x any) *A_arbace_repl_dir_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_dir_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_dir_A_class)) }; return v }



type A_arbace_repl_dir_fn_A struct{ jrt.Object }

func (t *A_arbace_repl_dir_fn_A) Is_Compiler_AOTF1() {}

var A_arbace_repl_dir_fn_A_fn_class *jrt.Class

var A_arbace_repl_dir_fn_A_init jrt.ClassInit

func A_arbace_repl_dir_fn_A_Init() { if !A_arbace_repl_dir_fn_A_init.Done() { A_arbace_repl_dir_fn_A_init.Run(A_arbace_repl_dir_fn_A_clinit) } }

func A_arbace_repl_dir_fn_A_clinit() { A_arbace_repl_dir_fn_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_126, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_dir_fn_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_dir_fn_A) GetClass__Class() *jrt.Class { return A_arbace_repl_dir_fn_A_class }

func (t *A_arbace_repl_dir_fn_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_dir_fn_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_dir_fn_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_dir_fn_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_dir_fn_A); return ok }

func A_arbace_repl_dir_fn_A_Cast(x any) *A_arbace_repl_dir_fn_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_dir_fn_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_dir_fn_A_class)) }; return v }



type A_arbace_repl_doc_A struct{ jrt.Object }

func (t *A_arbace_repl_doc_A) Is_Compiler_AOTF3() {}

var A_arbace_repl_doc_A_fn_class *jrt.Class

var A_arbace_repl_doc_A_init jrt.ClassInit

func A_arbace_repl_doc_A_Init() { if !A_arbace_repl_doc_A_init.Done() { A_arbace_repl_doc_A_init.Run(A_arbace_repl_doc_A_clinit) } }

func A_arbace_repl_doc_A_clinit() { A_arbace_repl_doc_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_127, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_doc_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_doc_A) GetClass__Class() *jrt.Class { return A_arbace_repl_doc_A_class }

func (t *A_arbace_repl_doc_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_doc_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_doc_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_doc_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_doc_A); return ok }

func A_arbace_repl_doc_A_Cast(x any) *A_arbace_repl_doc_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_doc_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_doc_A_class)) }; return v }



type A_arbace_repl_eval1239000004_A struct{ jrt.Object }

func A_arbace_repl_eval1239000004_A_New() *A_arbace_repl_eval1239000004_A { t := &A_arbace_repl_eval1239000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repl_eval1239000004_A) Ctor() {}

func (t *A_arbace_repl_eval1239000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_eval1239000004_A) GetClass__Class() *jrt.Class { return A_arbace_repl_eval1239000004_A_class }

func (t *A_arbace_repl_eval1239000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_eval1239000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_eval1239000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_eval1239000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_eval1239000004_A); return ok }

func A_arbace_repl_eval1239000004_A_Cast(x any) *A_arbace_repl_eval1239000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_eval1239000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_eval1239000004_A_class)) }; return v }



type A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A struct{ jrt.Object }

func (t *A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A) Is_Compiler_AOTF0() {}

var A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_fn_class *jrt.Class

var A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_init jrt.ClassInit

func A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_Init() { if !A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_init.Done() { A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_init.Run(A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_clinit) } }

func A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_clinit() { A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_128, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A) GetClass__Class() *jrt.Class { return A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_class }

func (t *A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A); return ok }

func A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_Cast(x any) *A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_class)) }; return v }



type A_arbace_repl_eval1239000008_A struct{ jrt.Object }

func A_arbace_repl_eval1239000008_A_New() *A_arbace_repl_eval1239000008_A { t := &A_arbace_repl_eval1239000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repl_eval1239000008_A) Ctor() {}

func (t *A_arbace_repl_eval1239000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_eval1239000008_A) GetClass__Class() *jrt.Class { return A_arbace_repl_eval1239000008_A_class }

func (t *A_arbace_repl_eval1239000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_eval1239000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_eval1239000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_eval1239000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_eval1239000008_A); return ok }

func A_arbace_repl_eval1239000008_A_Cast(x any) *A_arbace_repl_eval1239000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_eval1239000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_eval1239000008_A_class)) }; return v }



type A_arbace_repl_eval1239000008_fn__1239000009_A struct{ jrt.Object }

func (t *A_arbace_repl_eval1239000008_fn__1239000009_A) Is_Compiler_AOTF0() {}

var A_arbace_repl_eval1239000008_fn__1239000009_A_fn_class *jrt.Class

var A_arbace_repl_eval1239000008_fn__1239000009_A_init jrt.ClassInit

func A_arbace_repl_eval1239000008_fn__1239000009_A_Init() { if !A_arbace_repl_eval1239000008_fn__1239000009_A_init.Done() { A_arbace_repl_eval1239000008_fn__1239000009_A_init.Run(A_arbace_repl_eval1239000008_fn__1239000009_A_clinit) } }

func A_arbace_repl_eval1239000008_fn__1239000009_A_clinit() { A_arbace_repl_eval1239000008_fn__1239000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_134, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_eval1239000008_fn__1239000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_eval1239000008_fn__1239000009_A) GetClass__Class() *jrt.Class { return A_arbace_repl_eval1239000008_fn__1239000009_A_class }

func (t *A_arbace_repl_eval1239000008_fn__1239000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_eval1239000008_fn__1239000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_eval1239000008_fn__1239000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_eval1239000008_fn__1239000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_eval1239000008_fn__1239000009_A); return ok }

func A_arbace_repl_eval1239000008_fn__1239000009_A_Cast(x any) *A_arbace_repl_eval1239000008_fn__1239000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_eval1239000008_fn__1239000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_eval1239000008_fn__1239000009_A_class)) }; return v }



type A_arbace_repl_find_doc_A struct{ jrt.Object }

func (t *A_arbace_repl_find_doc_A) Is_Compiler_AOTF1() {}

var A_arbace_repl_find_doc_A_fn_class *jrt.Class

var A_arbace_repl_find_doc_A_init jrt.ClassInit

func A_arbace_repl_find_doc_A_Init() { if !A_arbace_repl_find_doc_A_init.Done() { A_arbace_repl_find_doc_A_init.Run(A_arbace_repl_find_doc_A_clinit) } }

func A_arbace_repl_find_doc_A_clinit() { A_arbace_repl_find_doc_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_135, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_find_doc_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_find_doc_A) GetClass__Class() *jrt.Class { return A_arbace_repl_find_doc_A_class }

func (t *A_arbace_repl_find_doc_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_find_doc_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_find_doc_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_find_doc_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_find_doc_A); return ok }

func A_arbace_repl_find_doc_A_Cast(x any) *A_arbace_repl_find_doc_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_find_doc_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_find_doc_A_class)) }; return v }



type A_arbace_repl_find_doc_fn__1239000027_A struct{ jrt.Object }

func (t *A_arbace_repl_find_doc_fn__1239000027_A) Is_Compiler_AOTF1() {}

var A_arbace_repl_find_doc_fn__1239000027_A_fn_class *jrt.Class

var A_arbace_repl_find_doc_fn__1239000027_A_init jrt.ClassInit

func A_arbace_repl_find_doc_fn__1239000027_A_Init() { if !A_arbace_repl_find_doc_fn__1239000027_A_init.Done() { A_arbace_repl_find_doc_fn__1239000027_A_init.Run(A_arbace_repl_find_doc_fn__1239000027_A_clinit) } }

func A_arbace_repl_find_doc_fn__1239000027_A_clinit() { A_arbace_repl_find_doc_fn__1239000027_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_136, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_find_doc_fn__1239000027_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_find_doc_fn__1239000027_A) GetClass__Class() *jrt.Class { return A_arbace_repl_find_doc_fn__1239000027_A_class }

func (t *A_arbace_repl_find_doc_fn__1239000027_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_find_doc_fn__1239000027_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_find_doc_fn__1239000027_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_find_doc_fn__1239000027_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_find_doc_fn__1239000027_A); return ok }

func A_arbace_repl_find_doc_fn__1239000027_A_Cast(x any) *A_arbace_repl_find_doc_fn__1239000027_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_find_doc_fn__1239000027_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_find_doc_fn__1239000027_A_class)) }; return v }



type A_arbace_repl_namespace_doc_A struct{ jrt.Object }

func (t *A_arbace_repl_namespace_doc_A) Is_Compiler_AOTF1() {}

var A_arbace_repl_namespace_doc_A_fn_class *jrt.Class

var A_arbace_repl_namespace_doc_A_init jrt.ClassInit

func A_arbace_repl_namespace_doc_A_Init() { if !A_arbace_repl_namespace_doc_A_init.Done() { A_arbace_repl_namespace_doc_A_init.Run(A_arbace_repl_namespace_doc_A_clinit) } }

func A_arbace_repl_namespace_doc_A_clinit() { A_arbace_repl_namespace_doc_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_137, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_namespace_doc_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_namespace_doc_A) GetClass__Class() *jrt.Class { return A_arbace_repl_namespace_doc_A_class }

func (t *A_arbace_repl_namespace_doc_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_namespace_doc_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_namespace_doc_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_namespace_doc_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_namespace_doc_A); return ok }

func A_arbace_repl_namespace_doc_A_Cast(x any) *A_arbace_repl_namespace_doc_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_namespace_doc_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_namespace_doc_A_class)) }; return v }



type A_arbace_repl_print_doc_A struct{ jrt.Object }

func (t *A_arbace_repl_print_doc_A) Is_Compiler_AOTF1() {}

var A_arbace_repl_print_doc_A_fn_class *jrt.Class

var A_arbace_repl_print_doc_A_init jrt.ClassInit

func A_arbace_repl_print_doc_A_Init() { if !A_arbace_repl_print_doc_A_init.Done() { A_arbace_repl_print_doc_A_init.Run(A_arbace_repl_print_doc_A_clinit) } }

func A_arbace_repl_print_doc_A_clinit() { A_arbace_repl_print_doc_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_138, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_print_doc_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_print_doc_A) GetClass__Class() *jrt.Class { return A_arbace_repl_print_doc_A_class }

func (t *A_arbace_repl_print_doc_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_print_doc_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_print_doc_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_print_doc_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_print_doc_A); return ok }

func A_arbace_repl_print_doc_A_Cast(x any) *A_arbace_repl_print_doc_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_print_doc_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_print_doc_A_class)) }; return v }



type A_arbace_repl_pst_A struct{ jrt.Object }

func (t *A_arbace_repl_pst_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_repl_pst_A) Is_Compiler_AOTF1() {}

func (t *A_arbace_repl_pst_A) Is_Compiler_AOTF0() {}

var A_arbace_repl_pst_A_fn_class *jrt.Class

var A_arbace_repl_pst_A_init jrt.ClassInit

func A_arbace_repl_pst_A_Init() { if !A_arbace_repl_pst_A_init.Done() { A_arbace_repl_pst_A_init.Run(A_arbace_repl_pst_A_clinit) } }

func A_arbace_repl_pst_A_clinit() { A_arbace_repl_pst_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_149, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_pst_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_pst_A) GetClass__Class() *jrt.Class { return A_arbace_repl_pst_A_class }

func (t *A_arbace_repl_pst_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_pst_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_pst_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_pst_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_pst_A); return ok }

func A_arbace_repl_pst_A_Cast(x any) *A_arbace_repl_pst_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_pst_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_pst_A_class)) }; return v }



type A_arbace_repl_pst_fn__1239000076_A struct{ jrt.Object }

func (t *A_arbace_repl_pst_fn__1239000076_A) Is_Compiler_AOTF1() {}

var A_arbace_repl_pst_fn__1239000076_A_fn_class *jrt.Class

var A_arbace_repl_pst_fn__1239000076_A_init jrt.ClassInit

func A_arbace_repl_pst_fn__1239000076_A_Init() { if !A_arbace_repl_pst_fn__1239000076_A_init.Done() { A_arbace_repl_pst_fn__1239000076_A_init.Run(A_arbace_repl_pst_fn__1239000076_A_clinit) } }

func A_arbace_repl_pst_fn__1239000076_A_clinit() { A_arbace_repl_pst_fn__1239000076_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_153, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_pst_fn__1239000076_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_pst_fn__1239000076_A) GetClass__Class() *jrt.Class { return A_arbace_repl_pst_fn__1239000076_A_class }

func (t *A_arbace_repl_pst_fn__1239000076_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_pst_fn__1239000076_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_pst_fn__1239000076_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_pst_fn__1239000076_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_pst_fn__1239000076_A); return ok }

func A_arbace_repl_pst_fn__1239000076_A_Cast(x any) *A_arbace_repl_pst_fn__1239000076_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_pst_fn__1239000076_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_pst_fn__1239000076_A_class)) }; return v }



type A_arbace_repl_root_cause_A struct{ jrt.Object }

func (t *A_arbace_repl_root_cause_A) Is_Compiler_AOTF1() {}

var A_arbace_repl_root_cause_A_fn_class *jrt.Class

var A_arbace_repl_root_cause_A_init jrt.ClassInit

func A_arbace_repl_root_cause_A_Init() { if !A_arbace_repl_root_cause_A_init.Done() { A_arbace_repl_root_cause_A_init.Run(A_arbace_repl_root_cause_A_clinit) } }

func A_arbace_repl_root_cause_A_clinit() { A_arbace_repl_root_cause_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_155, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_root_cause_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_root_cause_A) GetClass__Class() *jrt.Class { return A_arbace_repl_root_cause_A_class }

func (t *A_arbace_repl_root_cause_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_root_cause_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_root_cause_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_root_cause_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_root_cause_A); return ok }

func A_arbace_repl_root_cause_A_Cast(x any) *A_arbace_repl_root_cause_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_root_cause_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_root_cause_A_class)) }; return v }



type A_arbace_repl_set_break_handler_BANG__A struct{ jrt.Object }

func (t *A_arbace_repl_set_break_handler_BANG__A) Is_Compiler_AOTF1() {}

func (t *A_arbace_repl_set_break_handler_BANG__A) Is_Compiler_AOTF0() {}

var A_arbace_repl_set_break_handler_BANG__A_fn_class *jrt.Class

var A_arbace_repl_set_break_handler_BANG__A_init jrt.ClassInit

func A_arbace_repl_set_break_handler_BANG__A_Init() { if !A_arbace_repl_set_break_handler_BANG__A_init.Done() { A_arbace_repl_set_break_handler_BANG__A_init.Run(A_arbace_repl_set_break_handler_BANG__A_clinit) } }

func A_arbace_repl_set_break_handler_BANG__A_clinit() { A_arbace_repl_set_break_handler_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_157, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_set_break_handler_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_set_break_handler_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_repl_set_break_handler_BANG__A_class }

func (t *A_arbace_repl_set_break_handler_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_set_break_handler_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_set_break_handler_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_set_break_handler_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_set_break_handler_BANG__A); return ok }

func A_arbace_repl_set_break_handler_BANG__A_Cast(x any) *A_arbace_repl_set_break_handler_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_set_break_handler_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_set_break_handler_BANG__A_class)) }; return v }



type A_arbace_repl_set_break_handler_BANG__fn__1239000082_A struct{ jrt.Object; F_f any }

func (t *A_arbace_repl_set_break_handler_BANG__fn__1239000082_A) Is_Compiler_AOTF2() {}

var A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_fn_class *jrt.Class

var A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_init jrt.ClassInit

func A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_Init() { if !A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_init.Done() { A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_init.Run(A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_clinit) } }

func A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_clinit() { A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_162, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_set_break_handler_BANG__fn__1239000082_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_set_break_handler_BANG__fn__1239000082_A) GetClass__Class() *jrt.Class { return A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_class }

func (t *A_arbace_repl_set_break_handler_BANG__fn__1239000082_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_set_break_handler_BANG__fn__1239000082_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_set_break_handler_BANG__fn__1239000082_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_set_break_handler_BANG__fn__1239000082_A); return ok }

func A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_Cast(x any) *A_arbace_repl_set_break_handler_BANG__fn__1239000082_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_set_break_handler_BANG__fn__1239000082_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_class)) }; return v }



type A_arbace_repl_source_A struct{ jrt.Object }

func (t *A_arbace_repl_source_A) Is_Compiler_AOTF3() {}

var A_arbace_repl_source_A_fn_class *jrt.Class

var A_arbace_repl_source_A_init jrt.ClassInit

func A_arbace_repl_source_A_Init() { if !A_arbace_repl_source_A_init.Done() { A_arbace_repl_source_A_init.Run(A_arbace_repl_source_A_clinit) } }

func A_arbace_repl_source_A_clinit() { A_arbace_repl_source_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_164, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_source_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_source_A) GetClass__Class() *jrt.Class { return A_arbace_repl_source_A_class }

func (t *A_arbace_repl_source_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_source_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_source_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_source_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_source_A); return ok }

func A_arbace_repl_source_A_Cast(x any) *A_arbace_repl_source_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_source_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_source_A_class)) }; return v }



type A_arbace_repl_source_fn_A struct{ jrt.Object }

func (t *A_arbace_repl_source_fn_A) Is_Compiler_AOTF1() {}

var A_arbace_repl_source_fn_A_fn_class *jrt.Class

var A_arbace_repl_source_fn_A_init jrt.ClassInit

func A_arbace_repl_source_fn_A_Init() { if !A_arbace_repl_source_fn_A_init.Done() { A_arbace_repl_source_fn_A_init.Run(A_arbace_repl_source_fn_A_clinit) } }

func A_arbace_repl_source_fn_A_clinit() { A_arbace_repl_source_fn_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_166, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_source_fn_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_source_fn_A) GetClass__Class() *jrt.Class { return A_arbace_repl_source_fn_A_class }

func (t *A_arbace_repl_source_fn_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_source_fn_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_source_fn_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_source_fn_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_source_fn_A); return ok }

func A_arbace_repl_source_fn_A_Cast(x any) *A_arbace_repl_source_fn_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_source_fn_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_source_fn_A_class)) }; return v }



type A_arbace_repl_source_fn_fn__1239000039_A struct{ jrt.Object; F_text any }

func (t *A_arbace_repl_source_fn_fn__1239000039_A) Is_Compiler_AOTF1() {}

var A_arbace_repl_source_fn_fn__1239000039_A_fn_class *jrt.Class

var A_arbace_repl_source_fn_fn__1239000039_A_init jrt.ClassInit

func A_arbace_repl_source_fn_fn__1239000039_A_Init() { if !A_arbace_repl_source_fn_fn__1239000039_A_init.Done() { A_arbace_repl_source_fn_fn__1239000039_A_init.Run(A_arbace_repl_source_fn_fn__1239000039_A_clinit) } }

func A_arbace_repl_source_fn_fn__1239000039_A_clinit() { A_arbace_repl_source_fn_fn__1239000039_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_171, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_source_fn_fn__1239000039_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_source_fn_fn__1239000039_A) GetClass__Class() *jrt.Class { return A_arbace_repl_source_fn_fn__1239000039_A_class }

func (t *A_arbace_repl_source_fn_fn__1239000039_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_source_fn_fn__1239000039_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_source_fn_fn__1239000039_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_source_fn_fn__1239000039_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_source_fn_fn__1239000039_A); return ok }

func A_arbace_repl_source_fn_fn__1239000039_A_Cast(x any) *A_arbace_repl_source_fn_fn__1239000039_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_source_fn_fn__1239000039_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_source_fn_fn__1239000039_A_class)) }; return v }



type A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A struct{ jrt.Object; F_this any }

func (t *A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A) Is_Compiler_AOTF0() {}

var A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_fn_class *jrt.Class

var A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_init jrt.ClassInit

func A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_Init() { if !A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_init.Done() { A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_init.Run(A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_clinit) } }

func A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_clinit() { A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_172, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A) GetClass__Class() *jrt.Class { return A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_class }

func (t *A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A); return ok }

func A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_Cast(x any) *A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_class)) }; return v }



type A_arbace_repl_special_doc_A struct{ jrt.Object }

func (t *A_arbace_repl_special_doc_A) Is_Compiler_AOTF1() {}

var A_arbace_repl_special_doc_A_fn_class *jrt.Class

var A_arbace_repl_special_doc_A_init jrt.ClassInit

func A_arbace_repl_special_doc_A_Init() { if !A_arbace_repl_special_doc_A_init.Done() { A_arbace_repl_special_doc_A_init.Run(A_arbace_repl_special_doc_A_clinit) } }

func A_arbace_repl_special_doc_A_clinit() { A_arbace_repl_special_doc_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_173, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_special_doc_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_special_doc_A) GetClass__Class() *jrt.Class { return A_arbace_repl_special_doc_A_class }

func (t *A_arbace_repl_special_doc_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_special_doc_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_special_doc_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_special_doc_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_special_doc_A); return ok }

func A_arbace_repl_special_doc_A_Cast(x any) *A_arbace_repl_special_doc_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_special_doc_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_special_doc_A_class)) }; return v }



type A_arbace_repl_stack_element_str_A struct{ jrt.Object }

func (t *A_arbace_repl_stack_element_str_A) Is_Compiler_AOTF1() {}

var A_arbace_repl_stack_element_str_A_fn_class *jrt.Class

var A_arbace_repl_stack_element_str_A_init jrt.ClassInit

func A_arbace_repl_stack_element_str_A_Init() { if !A_arbace_repl_stack_element_str_A_init.Done() { A_arbace_repl_stack_element_str_A_init.Run(A_arbace_repl_stack_element_str_A_clinit) } }

func A_arbace_repl_stack_element_str_A_clinit() { A_arbace_repl_stack_element_str_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_174, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_stack_element_str_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_stack_element_str_A) GetClass__Class() *jrt.Class { return A_arbace_repl_stack_element_str_A_class }

func (t *A_arbace_repl_stack_element_str_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_stack_element_str_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_stack_element_str_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_stack_element_str_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_stack_element_str_A); return ok }

func A_arbace_repl_stack_element_str_A_Cast(x any) *A_arbace_repl_stack_element_str_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_stack_element_str_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_stack_element_str_A_class)) }; return v }



type A_arbace_repl_thread_stopper_A struct{ jrt.Object }

func (t *A_arbace_repl_thread_stopper_A) Is_Compiler_AOTF1() {}

func (t *A_arbace_repl_thread_stopper_A) Is_Compiler_AOTF0() {}

var A_arbace_repl_thread_stopper_A_fn_class *jrt.Class

var A_arbace_repl_thread_stopper_A_init jrt.ClassInit

func A_arbace_repl_thread_stopper_A_Init() { if !A_arbace_repl_thread_stopper_A_init.Done() { A_arbace_repl_thread_stopper_A_init.Run(A_arbace_repl_thread_stopper_A_clinit) } }

func A_arbace_repl_thread_stopper_A_clinit() { A_arbace_repl_thread_stopper_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_181, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_thread_stopper_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_thread_stopper_A) GetClass__Class() *jrt.Class { return A_arbace_repl_thread_stopper_A_class }

func (t *A_arbace_repl_thread_stopper_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_thread_stopper_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_thread_stopper_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_thread_stopper_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_thread_stopper_A); return ok }

func A_arbace_repl_thread_stopper_A_Cast(x any) *A_arbace_repl_thread_stopper_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_thread_stopper_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_thread_stopper_A_class)) }; return v }



type A_arbace_repl_thread_stopper_fn__1239000079_A struct{ jrt.Object; F_thread any }

func (t *A_arbace_repl_thread_stopper_fn__1239000079_A) Is_Compiler_AOTF1() {}

var A_arbace_repl_thread_stopper_fn__1239000079_A_fn_class *jrt.Class

var A_arbace_repl_thread_stopper_fn__1239000079_A_init jrt.ClassInit

func A_arbace_repl_thread_stopper_fn__1239000079_A_Init() { if !A_arbace_repl_thread_stopper_fn__1239000079_A_init.Done() { A_arbace_repl_thread_stopper_fn__1239000079_A_init.Run(A_arbace_repl_thread_stopper_fn__1239000079_A_clinit) } }

func A_arbace_repl_thread_stopper_fn__1239000079_A_clinit() { A_arbace_repl_thread_stopper_fn__1239000079_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_182, lang.Compiler_AOTFn_class) }

func (t *A_arbace_repl_thread_stopper_fn__1239000079_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_thread_stopper_fn__1239000079_A) GetClass__Class() *jrt.Class { return A_arbace_repl_thread_stopper_fn__1239000079_A_class }

func (t *A_arbace_repl_thread_stopper_fn__1239000079_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_thread_stopper_fn__1239000079_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl_thread_stopper_fn__1239000079_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_thread_stopper_fn__1239000079_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_thread_stopper_fn__1239000079_A); return ok }

func A_arbace_repl_thread_stopper_fn__1239000079_A_Cast(x any) *A_arbace_repl_thread_stopper_fn__1239000079_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_thread_stopper_fn__1239000079_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_thread_stopper_fn__1239000079_A_class)) }; return v }
