//line aot_arbace_repl.ae:1
package aot_arbace_repl

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_spec_alpha"
	"arbace/jrt"
	"arbace/lang"
)


func A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_New() *A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A{}; t.Ctor(); return t }
//line :11:1
func (t *A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A) Ctor() {}
//line :11:1
func (t *A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repl_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_1); lang.IFn_Cast(A_arbace_repl_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_3); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_5)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_6)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_7)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_8)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_9)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :11:1
func A_arbace_repl_eval1239000008_fn__1239000009_A_New() *A_arbace_repl_eval1239000008_fn__1239000009_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_eval1239000008_fn__1239000009_A{}; t.Ctor(); return t }
//line :11:1
func (t *A_arbace_repl_eval1239000008_fn__1239000009_A) Ctor() {}
//line :11:1
func (t *A_arbace_repl_eval1239000008_fn__1239000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_4.GetRawRoot__O()); var tmp2 any; var root_15 any = A_arbace_repl_A_const_5.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = A_arbace_repl_A_const_6; if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_15, arg_18) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repl_A_const_7.GetRawRoot__O(), A_arbace_repl_A_const_8) }































































func A_arbace_repl_special_doc_A_New() *A_arbace_repl_special_doc_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_special_doc_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_repl_special_doc_A) Ctor() {}
//line :75:1
func (t *A_arbace_repl_special_doc_A) Invoke_O_O__O(self, name_symbol__0 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_9.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_repl_A_const_10.GetRawRoot__O()).Invoke_O__O(name_symbol__0); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp2 = or__1927000174__auto____2 } else { var tmp3 any; var root_27 any = A_arbace_repl_A_const_11.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = name_symbol__0; if linked_28 == nil { tmp3 = ifn_29.Invoke_O__O(arg_30) } else { tmp3 = linked_28.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_27, arg_30) }; tmp2 = lang.RT_Meta_O__IPersistentMap_NoInit(tmp3) }; return tmp1.Invoke_O_O_O_O_O__O(tmp2, A_arbace_repl_A_const_12, name_symbol__0, A_arbace_repl_A_const_13, jrt.Boolean_TRUE.Ref())
}


func A_arbace_repl_namespace_doc_A_New() *A_arbace_repl_namespace_doc_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_namespace_doc_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_repl_namespace_doc_A) Ctor() {}
//line :80:1
func (t *A_arbace_repl_namespace_doc_A) Invoke_O_O__O(self, nspace__0 any) any {
	var root_31 any = A_arbace_repl_A_const_9.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = lang.RT_Meta_O__IPersistentMap_NoInit(nspace__0); var arg_35 any = A_arbace_repl_A_const_12; var arg_36 any; var root_37 any = A_arbace_repl_A_const_14.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_39 lang.IFn; if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = nspace__0; if linked_38 == nil { arg_36 = ifn_39.Invoke_O__O(arg_40) } else { arg_36 = linked_38.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_37, arg_40) }; if linked_32 == nil { return ifn_33.Invoke_O_O_O__O(arg_34, arg_35, arg_36) } else { return linked_32.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_31, arg_34, arg_35, arg_36)
	} }
func A_arbace_repl_print_doc_A_New() *A_arbace_repl_print_doc_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_print_doc_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_repl_print_doc_A) Ctor() {}
//line :83:1
func (t *A_arbace_repl_print_doc_A) Invoke_O_O__O(self, p__1239000014__0 any) any { { var map__1239000015__2 any = p__1239000014__0; var map__1239000015__3 any; if lang.ISeq_InstanceOf(map__1239000015__2) { var tmp1 any; var root_41 any = A_arbace_repl_A_const_15.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = map__1239000015__2; if linked_42 == nil { tmp1 = ifn_43.Invoke_O__O(arg_44) } else { tmp1 = linked_42.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_41, arg_44) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_45 any = A_arbace_repl_A_const_16.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = map__1239000015__2; if linked_46 == nil { tmp2 = ifn_47.Invoke_O__O(arg_48) } else { tmp2 = linked_46.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_45, arg_48) }; map__1239000015__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_49 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = map__1239000015__2; if linked_50 == nil { tmp3 = ifn_51.Invoke_O__O(arg_52) } else { tmp3 = linked_50.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_49, arg_52) }; if jrt.J2g_Truth(tmp3) { var root_53 any = A_arbace_repl_A_const_18.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = map__1239000015__2; if linked_54 == nil { map__1239000015__3 = ifn_55.Invoke_O__O(arg_56) } else { map__1239000015__3 = linked_54.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_53, arg_56) } } else { map__1239000015__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1239000015__3 = map__1239000015__2 }; var m__4 any = map__1239000015__3; var n__5 any = lang.RT_Get_O_O__O_NoInit(map__1239000015__3, A_arbace_repl_A_const_19); var nm__6 any = lang.RT_Get_O_O__O_NoInit(map__1239000015__3, A_arbace_repl_A_const_12); var forms__7 any = lang.RT_Get_O_O__O_NoInit(map__1239000015__3, A_arbace_repl_A_const_20); var arglists__8 any = lang.RT_Get_O_O__O_NoInit(map__1239000015__3, A_arbace_repl_A_const_21); var special_form__9 any = lang.RT_Get_O_O__O_NoInit(map__1239000015__3, A_arbace_repl_A_const_13); var doc__10 any = lang.RT_Get_O_O__O_NoInit(map__1239000015__3, A_arbace_repl_A_const_22); var url__11 any = lang.RT_Get_O_O__O_NoInit(map__1239000015__3, A_arbace_repl_A_const_23); var macro__12 any = lang.RT_Get_O_O__O_NoInit(map__1239000015__3, A_arbace_repl_A_const_24); var spec__13 any = lang.RT_Get_O_O__O_NoInit(map__1239000015__3, A_arbace_repl_A_const_25)



	lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(Lit_11)
	var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()); var tmp5 any; var or__1927000174__auto____14 any = spec__13; if jrt.J2g_Truth(or__1927000174__auto____14) { tmp5 = or__1927000174__auto____14 } else { var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp7 *jrt.String; if jrt.J2g_Truth(n__5) { var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_12); var tmp9 any; var root_106 any = A_arbace_repl_A_const_14.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = n__5; if linked_107 == nil { tmp9 = ifn_108.Invoke_O__O(arg_109) } else { tmp9 = linked_107.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_106, arg_109) }; tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, tmp9, nil)) } else { tmp7 = nil }; tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7.Ref(), nm__6)).Ref() }; tmp4.Invoke_O__O(tmp5)
	if jrt.J2g_Truth(forms__7) { var seq_1239000017__14 any; var root_110 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_112 lang.IFn
		if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any = forms__7; if linked_111 == nil { seq_1239000017__14 = ifn_112.Invoke_O__O(arg_113) } else { seq_1239000017__14 = linked_111.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_110, arg_113) }
//line :89:1
		var chunk_1239000018__15 any; var count_1239000019__16 int64 = 0; var i_1239000020__17 int64 = 0; L1: for {
			if lang.Numbers_Lt_J_J__Z_NoInit(i_1239000020__17, count_1239000019__16) { var f__18 any = lang.Indexed_Cast(chunk_1239000018__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1239000020__17))
				lang.IFn_Cast(A_arbace_repl_A_const_36.GetRawRoot__O()).Invoke_O__O(Lit_13)
				lang.IFn_Cast(A_arbace_repl_A_const_34.GetRawRoot__O()).Invoke_O__O(f__18)
//line :90:1
				seq_1239000017__14, chunk_1239000018__15, count_1239000019__16, i_1239000020__17 = seq_1239000017__14, chunk_1239000018__15, count_1239000019__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1239000020__17); continue L1 } else { var temp__1927000414__auto____18 any; var root_114 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_116 lang.IFn; if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any = seq_1239000017__14; if linked_115 == nil { temp__1927000414__auto____18 = ifn_116.Invoke_O__O(arg_117) } else { temp__1927000414__auto____18 = linked_115.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_114, arg_117) }; if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_1239000017__19 any = temp__1927000414__auto____18; var tmp10 any; var root_118 any = A_arbace_repl_A_const_31.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_118, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_120 lang.IFn; if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = seq_1239000017__19; if linked_119 == nil { tmp10 = ifn_120.Invoke_O__O(arg_121) } else { tmp10 = linked_119.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_118, arg_121) }; if jrt.J2g_Truth(tmp10) { var c__1927000678__auto____20 any; var root_122 any = A_arbace_repl_A_const_32.GetRawRoot__O(); var linked_123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_122, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_124 lang.IFn; if linked_123 == nil { ifn_124 = lang.IFn_Cast(root_122) } else { ifn_124 = nil }; var arg_125 any = seq_1239000017__19; if linked_123 == nil { c__1927000678__auto____20 = ifn_124.Invoke_O__O(arg_125) } else { c__1927000678__auto____20 = linked_123.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_122, arg_125) }; var tmp11 any; var root_172 any = A_arbace_repl_A_const_37.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = seq_1239000017__19; if linked_173 == nil { tmp11 = ifn_174.Invoke_O__O(arg_175) } else { tmp11 = linked_173.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_172, arg_175) }; seq_1239000017__14, chunk_1239000018__15, count_1239000019__16, i_1239000020__17 = tmp11, c__1927000678__auto____20, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__20 any; var root_126 any = A_arbace_repl_A_const_18.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_128 lang.IFn; if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = seq_1239000017__19; if linked_127 == nil { f__20 = ifn_128.Invoke_O__O(arg_129) } else { f__20 = linked_127.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_126, arg_129) }
					lang.IFn_Cast(A_arbace_repl_A_const_36.GetRawRoot__O()).Invoke_O__O(Lit_13)
					lang.IFn_Cast(A_arbace_repl_A_const_34.GetRawRoot__O()).Invoke_O__O(f__20)
//line :90:1
					var tmp12 any; var root_184 any = A_arbace_repl_A_const_15.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = seq_1239000017__19; if linked_185 == nil { tmp12 = ifn_186.Invoke_O__O(arg_187) } else { tmp12 = linked_185.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_184, arg_187) }; seq_1239000017__14, chunk_1239000018__15, count_1239000019__16, i_1239000020__17 = tmp12, nil, 0, 0; continue L1 } } }
//line :89:1
			break L1
		}
	}

	if jrt.J2g_Truth(arglists__8) {
		lang.IFn_Cast(A_arbace_repl_A_const_34.GetRawRoot__O()).Invoke_O__O(arglists__8) }
	if jrt.J2g_Truth(special_form__9) {

		lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(Lit_14) } else {
//line :95:1
			if jrt.J2g_Truth(macro__12) {



				lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(Lit_15) } else {
//line :95:1
					if jrt.J2g_Truth(spec__13) {





						lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(Lit_16) } } }
	if jrt.J2g_Truth(doc__10) { lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O_O__O(Lit_17, doc__10) }
	if jrt.J2g_Truth(special_form__9) {
		var tmp13 any; var root_151 any = A_arbace_repl_A_const_35.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = m__4; var arg_155 any = A_arbace_repl_A_const_23; if linked_152 == nil { tmp13 = ifn_153.Invoke_O_O__O(arg_154, arg_155) } else { tmp13 = linked_152.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_151, arg_154, arg_155) }; if jrt.J2g_Truth(tmp13) {
			if jrt.J2g_Truth(url__11) {
				lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_18, nil), jrt.RefArrayOf(jrt.Object_class, nil, url__11)).Ref()) } } else {
					lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, nm__6)).Ref()) } }
	if jrt.J2g_Truth(n__5) { var temp__1927000414__auto____14 any; var root_57 any = A_arbace_repl_A_const_26.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_spec_alpha.A_arbace_spec_alpha_get_spec_A_fn_class); var ifn_59 lang.IFn
		if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any; var root_61 any = A_arbace_repl_A_const_27.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any; var root_66 any = A_arbace_repl_A_const_28.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any; var root_70 any = A_arbace_repl_A_const_14.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = n__5; if linked_71 == nil { arg_69 = ifn_72.Invoke_O__O(arg_73) } else { arg_69 = linked_71.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_70, arg_73) }; if linked_67 == nil { arg_64 = ifn_68.Invoke_O__O(arg_69) } else { arg_64 = linked_67.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_66, arg_69) }; var arg_65 any; var root_74 any = A_arbace_repl_A_const_29.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_76 lang.IFn; if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any = nm__6; if linked_75 == nil { arg_65 = ifn_76.Invoke_O__O(arg_77) } else { arg_65 = linked_75.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_74, arg_77) }; if linked_62 == nil { arg_60 = ifn_63.Invoke_O_O__O(arg_64, arg_65) } else { arg_60 = linked_62.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_61, arg_64, arg_65) }; if linked_58 == nil { temp__1927000414__auto____14 = ifn_59.Invoke_O__O(arg_60) } else { temp__1927000414__auto____14 = linked_58.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_get_spec_A).Invoke_O_O__O(root_57, arg_60) }; if jrt.J2g_Truth(temp__1927000414__auto____14) { var fnspec__15 any = temp__1927000414__auto____14
			lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(Lit_16)
//line :109:1
			var seq_1239000021__16 any; var root_78 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_80 lang.IFn

			if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = A_arbace_repl_A_const_30; if linked_79 == nil { seq_1239000021__16 = ifn_80.Invoke_O__O(arg_81) } else { seq_1239000021__16 = linked_79.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_78, arg_81) }
//line :109:1
			var chunk_1239000022__17 any; var count_1239000023__18 int64 = 0; var i_1239000024__19 int64 = 0; L2: for {

				if lang.Numbers_Lt_J_J__Z_NoInit(i_1239000024__19, count_1239000023__18) { var role__20 any = lang.Indexed_Cast(chunk_1239000022__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1239000024__19)); var temp__1927000414__auto____21 any = lang.RT_Get_O_O__O_NoInit(fnspec__15, role__20)
					if jrt.J2g_Truth(temp__1927000414__auto____21) { var spec__22 any = temp__1927000414__auto____21; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()); var tmp15 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_20); var tmp16 any; var root_198 any = A_arbace_repl_A_const_29.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_200 lang.IFn
						if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = role__20; if linked_199 == nil { tmp16 = ifn_200.Invoke_O__O(arg_201) } else { tmp16 = linked_199.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_198, arg_201) }; var tmp17 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp15, jrt.RefArrayOf(jrt.Object_class, tmp16, nil)).Ref(); var tmp18 any; var root_202 any = A_arbace_repl_A_const_38.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_spec_alpha.A_arbace_spec_alpha_describe_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = spec__22; if linked_203 == nil { tmp18 = ifn_204.Invoke_O__O(arg_205) } else { tmp18 = linked_203.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_describe_A).Invoke_O_O__O(root_202, arg_205) }; tmp14.Invoke_O_O_O__O(Lit_17, tmp17, tmp18) }
//line :111:1
					seq_1239000021__16, chunk_1239000022__17, count_1239000023__18, i_1239000024__19 = seq_1239000021__16, chunk_1239000022__17, count_1239000023__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1239000024__19); continue L2 } else { var temp__1927000414__auto____20 any; var root_82 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = seq_1239000021__16; if linked_83 == nil { temp__1927000414__auto____20 = ifn_84.Invoke_O__O(arg_85) } else { temp__1927000414__auto____20 = linked_83.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_82, arg_85) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1239000021__21 any = temp__1927000414__auto____20; var tmp19 any; var root_86 any = A_arbace_repl_A_const_31.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_88 lang.IFn; if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any = seq_1239000021__21; if linked_87 == nil { tmp19 = ifn_88.Invoke_O__O(arg_89) } else { tmp19 = linked_87.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_86, arg_89) }; if jrt.J2g_Truth(tmp19) { var c__1927000678__auto____22 any; var root_90 any = A_arbace_repl_A_const_32.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = seq_1239000021__21; if linked_91 == nil { c__1927000678__auto____22 = ifn_92.Invoke_O__O(arg_93) } else { c__1927000678__auto____22 = linked_91.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_90, arg_93) }; var tmp20 any; var root_206 any = A_arbace_repl_A_const_37.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = seq_1239000021__21; if linked_207 == nil { tmp20 = ifn_208.Invoke_O__O(arg_209) } else { tmp20 = linked_207.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_206, arg_209) }; seq_1239000021__16, chunk_1239000022__17, count_1239000023__18, i_1239000024__19 = tmp20, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var role__22 any; var root_94 any = A_arbace_repl_A_const_18.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = seq_1239000021__21; if linked_95 == nil { role__22 = ifn_96.Invoke_O__O(arg_97) } else { role__22 = linked_95.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_94, arg_97) }; var temp__1927000414__auto____23 any = lang.RT_Get_O_O__O_NoInit(fnspec__15, role__22)
						if jrt.J2g_Truth(temp__1927000414__auto____23) { var spec__24 any = temp__1927000414__auto____23; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()); var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_20); var tmp23 any; var root_216 any = A_arbace_repl_A_const_29.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_218 lang.IFn
							if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = role__22; if linked_217 == nil { tmp23 = ifn_218.Invoke_O__O(arg_219) } else { tmp23 = linked_217.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_216, arg_219) }; var tmp24 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, tmp23, nil)).Ref(); var tmp25 any; var root_220 any = A_arbace_repl_A_const_38.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, aot_arbace_spec_alpha.A_arbace_spec_alpha_describe_A_fn_class); var ifn_222 lang.IFn; if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any = spec__24; if linked_221 == nil { tmp25 = ifn_222.Invoke_O__O(arg_223) } else { tmp25 = linked_221.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_describe_A).Invoke_O_O__O(root_220, arg_223) }; tmp21.Invoke_O_O_O__O(Lit_17, tmp24, tmp25) }
//line :111:1
						var tmp26 any; var root_224 any = A_arbace_repl_A_const_15.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = seq_1239000021__21; if linked_225 == nil { tmp26 = ifn_226.Invoke_O__O(arg_227) } else { tmp26 = linked_225.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_224, arg_227) }; seq_1239000021__16, chunk_1239000022__17, count_1239000023__18, i_1239000024__19 = tmp26, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :109:1
							return nil } } else {
//line :108:1
								return nil } }; /*line :83:1*/panic("j2g: unreachable") }































func A_arbace_repl_find_doc_A_New() *A_arbace_repl_find_doc_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_find_doc_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_repl_find_doc_A) Ctor() {}
//line :115:1
func (t *A_arbace_repl_find_doc_A) Invoke_O_O__O(self, re_string_or_pattern__0 any) any { { var re__2 any; var root_228 any = A_arbace_repl_A_const_39.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_re_pattern_A_fn_class); var ifn_230 lang.IFn




	if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = re_string_or_pattern__0; if linked_229 == nil { re__2 = ifn_230.Invoke_O__O(arg_231) } else { re__2 = linked_229.(*aot_arbace_core.A_arbace_core_re_pattern_A).Invoke_O_O__O(root_228, arg_231) }
//line :115:1
	var ms__3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_41.GetRawRoot__O()); var tmp3 *lang.Compiler_AOTFn; var fnbody__262 any = A_arbace_repl_find_doc_fn__1239000027_A_New(); var tmp4 *jrt.Class
	var fncls__261 /*line :115:1*/*jrt.Class = A_arbace_repl_find_doc_fn__1239000027_A_fn_class





	if fncls__261 == nil { var fncls__261d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, nil); A_arbace_repl_find_doc_fn__1239000027_A_fn_class = fncls__261d; tmp4 = fncls__261d } else { tmp4 = fncls__261 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__262, tmp4, nil); var tmp5 any = tmp3.Ref(); var tmp6 any; var root_263 any = A_arbace_repl_A_const_47.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_263, aot_arbace_core.A_arbace_core_all_ns_A_fn_class); var ifn_265 lang.IFn
	if linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; if linked_264 == nil { tmp6 = ifn_265.Invoke__O() } else { tmp6 = linked_264.(*aot_arbace_core.A_arbace_core_all_ns_A).Invoke_O__O(root_263) }
//line :121:1
	var tmp7 any = tmp2.Invoke_O_O__O(tmp5, tmp6); var tmp8 any; var root_266 any = A_arbace_repl_A_const_43.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_266, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_268 lang.IFn

	if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = A_arbace_repl_A_const_48.GetRawRoot__O(); var arg_270 any; var root_271 any = A_arbace_repl_A_const_47.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, aot_arbace_core.A_arbace_core_all_ns_A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; if linked_272 == nil { arg_270 = ifn_273.Invoke__O() } else { arg_270 = linked_272.(*aot_arbace_core.A_arbace_core_all_ns_A).Invoke_O__O(root_271) }; if linked_267 == nil { tmp8 = ifn_268.Invoke_O_O__O(arg_269, arg_270) } else { tmp8 = linked_267.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_266, arg_269, arg_270) }
//line :121:1
	var tmp9 any = tmp8; var tmp10 any; var root_274 any = A_arbace_repl_A_const_43.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_274, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_276 lang.IFn


	if linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any = A_arbace_repl_A_const_49.GetRawRoot__O(); var arg_278 any; var root_279 any = A_arbace_repl_A_const_50.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = A_arbace_repl_A_const_10.GetRawRoot__O(); if linked_280 == nil { arg_278 = ifn_281.Invoke_O__O(arg_282) } else { arg_278 = linked_280.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_279, arg_282) }; if linked_275 == nil { tmp10 = ifn_276.Invoke_O_O__O(arg_277, arg_278) } else { tmp10 = linked_275.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_274, arg_277, arg_278) }
//line :121:1
	ms__3 = tmp1.Invoke_O_O_O__O(tmp7, tmp9, tmp10)
//line :115:1
	var seq_1239000029__4 any; var root_283 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_285 lang.IFn









	if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any = ms__3; if linked_284 == nil { seq_1239000029__4 = ifn_285.Invoke_O__O(arg_286) } else { seq_1239000029__4 = linked_284.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_283, arg_286) }
//line :115:1
	var chunk_1239000030__5 any; var count_1239000031__6 int64 = 0; var i_1239000032__7 int64 = 0; L1: for {









		if lang.Numbers_Lt_J_J__Z_NoInit(i_1239000032__7, count_1239000031__6) { var m__8 any = lang.Indexed_Cast(chunk_1239000030__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1239000032__7)); var tmp11 any; var and__1927000168__auto____9 any = A_arbace_repl_A_const_22.Invoke_O__O(m__8)
			if jrt.J2g_Truth(and__1927000168__auto____9) { var or__1927000174__auto____10 any; var root_287 any = A_arbace_repl_A_const_51.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_289 lang.IFn
				if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any; var root_291 any = A_arbace_repl_A_const_52.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_core.A_arbace_core_re_matcher_A_fn_class); var ifn_293 lang.IFn; if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = re__2; var arg_295 any = A_arbace_repl_A_const_22.Invoke_O__O(m__8); if linked_292 == nil { arg_290 = ifn_293.Invoke_O_O__O(arg_294, arg_295) } else { arg_290 = linked_292.(*aot_arbace_core.A_arbace_core_re_matcher_A).Invoke_O_O_O__O(root_291, arg_294, arg_295) }; if linked_288 == nil { or__1927000174__auto____10 = ifn_289.Invoke_O__O(arg_290) } else { or__1927000174__auto____10 = linked_288.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O__O(root_287, arg_290) }; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp11 = or__1927000174__auto____10 } else {
					var root_296 any = A_arbace_repl_A_const_51.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any; var root_300 any = A_arbace_repl_A_const_52.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_re_matcher_A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = re__2; var arg_304 any; var root_305 any = A_arbace_repl_A_const_28.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_305, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_307 lang.IFn; if linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any = A_arbace_repl_A_const_12.Invoke_O__O(m__8); if linked_306 == nil { arg_304 = ifn_307.Invoke_O__O(arg_308) } else { arg_304 = linked_306.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_305, arg_308) }; if linked_301 == nil { arg_299 = ifn_302.Invoke_O_O__O(arg_303, arg_304) } else { arg_299 = linked_301.(*aot_arbace_core.A_arbace_core_re_matcher_A).Invoke_O_O_O__O(root_300, arg_303, arg_304) }; if linked_297 == nil { tmp11 = ifn_298.Invoke_O__O(arg_299) } else { tmp11 = linked_297.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O__O(root_296, arg_299) } } } else {
//line :126:1
						tmp11 = and__1927000168__auto____9 }
//line :125:1
			if jrt.J2g_Truth(tmp11) {



				var root_347 any = A_arbace_repl_A_const_53.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, A_arbace_repl_print_doc_A_fn_class); var ifn_349 lang.IFn; if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any = m__8; if linked_348 == nil { ifn_349.Invoke_O__O(arg_350) } else { linked_348.(*A_arbace_repl_print_doc_A).Invoke_O_O__O(root_347, arg_350) }
//line :125:1
				seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, i_1239000032__7 = seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1239000032__7); continue L1 } else { seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, i_1239000032__7 = seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1239000032__7); continue L1 } } else { var temp__1927000414__auto____8 any; var root_309 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any = seq_1239000029__4; if linked_310 == nil { temp__1927000414__auto____8 = ifn_311.Invoke_O__O(arg_312) } else { temp__1927000414__auto____8 = linked_310.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_309, arg_312) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1239000029__9 any = temp__1927000414__auto____8; var tmp12 any; var root_313 any = A_arbace_repl_A_const_31.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_313, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_315 lang.IFn; if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any = seq_1239000029__9; if linked_314 == nil { tmp12 = ifn_315.Invoke_O__O(arg_316) } else { tmp12 = linked_314.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_313, arg_316) }; if jrt.J2g_Truth(tmp12) { var c__1927000678__auto____10 any; var root_317 any = A_arbace_repl_A_const_32.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_319 lang.IFn; if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any = seq_1239000029__9; if linked_318 == nil { c__1927000678__auto____10 = ifn_319.Invoke_O__O(arg_320) } else { c__1927000678__auto____10 = linked_318.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_317, arg_320) }; var tmp13 any; var root_351 any = A_arbace_repl_A_const_37.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_351, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_353 lang.IFn; if linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; var arg_354 any = seq_1239000029__9; if linked_352 == nil { tmp13 = ifn_353.Invoke_O__O(arg_354) } else { tmp13 = linked_352.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_351, arg_354) }; seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, i_1239000032__7 = tmp13, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var m__10 any; var root_321 any = A_arbace_repl_A_const_18.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any = seq_1239000029__9; if linked_322 == nil { m__10 = ifn_323.Invoke_O__O(arg_324) } else { m__10 = linked_322.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_321, arg_324) }; var tmp14 any; var and__1927000168__auto____11 any = A_arbace_repl_A_const_22.Invoke_O__O(m__10)
					if jrt.J2g_Truth(and__1927000168__auto____11) { var or__1927000174__auto____12 any; var root_325 any = A_arbace_repl_A_const_51.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_327 lang.IFn
						if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any; var root_329 any = A_arbace_repl_A_const_52.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_core.A_arbace_core_re_matcher_A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = re__2; var arg_333 any = A_arbace_repl_A_const_22.Invoke_O__O(m__10); if linked_330 == nil { arg_328 = ifn_331.Invoke_O_O__O(arg_332, arg_333) } else { arg_328 = linked_330.(*aot_arbace_core.A_arbace_core_re_matcher_A).Invoke_O_O_O__O(root_329, arg_332, arg_333) }; if linked_326 == nil { or__1927000174__auto____12 = ifn_327.Invoke_O__O(arg_328) } else { or__1927000174__auto____12 = linked_326.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O__O(root_325, arg_328) }; if jrt.J2g_Truth(or__1927000174__auto____12) { tmp14 = or__1927000174__auto____12 } else {
							var root_334 any = A_arbace_repl_A_const_51.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any; var root_338 any = A_arbace_repl_A_const_52.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_re_matcher_A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = re__2; var arg_342 any; var root_343 any = A_arbace_repl_A_const_28.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_343, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_345 lang.IFn; if linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = A_arbace_repl_A_const_12.Invoke_O__O(m__10); if linked_344 == nil { arg_342 = ifn_345.Invoke_O__O(arg_346) } else { arg_342 = linked_344.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_343, arg_346) }; if linked_339 == nil { arg_337 = ifn_340.Invoke_O_O__O(arg_341, arg_342) } else { arg_337 = linked_339.(*aot_arbace_core.A_arbace_core_re_matcher_A).Invoke_O_O_O__O(root_338, arg_341, arg_342) }; if linked_335 == nil { tmp14 = ifn_336.Invoke_O__O(arg_337) } else { tmp14 = linked_335.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O__O(root_334, arg_337) } } } else {
//line :126:1
								tmp14 = and__1927000168__auto____11 }
//line :125:1
					if jrt.J2g_Truth(tmp14) {



						var root_355 any = A_arbace_repl_A_const_53.GetRawRoot__O(); var linked_356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_355, A_arbace_repl_print_doc_A_fn_class); var ifn_357 lang.IFn; if linked_356 == nil { ifn_357 = lang.IFn_Cast(root_355) } else { ifn_357 = nil }; var arg_358 any = m__10; if linked_356 == nil { ifn_357.Invoke_O__O(arg_358) } else { linked_356.(*A_arbace_repl_print_doc_A).Invoke_O_O__O(root_355, arg_358) }
//line :125:1
						var tmp15 any; var root_359 any = A_arbace_repl_A_const_15.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = seq_1239000029__9; if linked_360 == nil { tmp15 = ifn_361.Invoke_O__O(arg_362) } else { tmp15 = linked_360.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_359, arg_362) }; seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, i_1239000032__7 = tmp15, nil, 0, 0; continue L1 } else { var tmp16 any; var root_363 any = A_arbace_repl_A_const_15.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = seq_1239000029__9; if linked_364 == nil { tmp16 = ifn_365.Invoke_O__O(arg_366) } else { tmp16 = linked_364.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_363, arg_366) }; seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, i_1239000032__7 = tmp16, nil, 0, 0; continue L1 } } } else { return nil } } } }; /*line :115:1*/panic("j2g: unreachable") }





func A_arbace_repl_find_doc_fn__1239000027_A_New() *A_arbace_repl_find_doc_fn__1239000027_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_find_doc_fn__1239000027_A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_repl_find_doc_fn__1239000027_A) Ctor() {}
//line :121:1
func (t *A_arbace_repl_find_doc_fn__1239000027_A) Invoke_O_O__O(self, p1__1239000026_SHARP___1 any) any { var root_243 any = A_arbace_repl_A_const_42.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_243, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_245 lang.IFn; if linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any = A_arbace_repl_A_const_12; var arg_247 any; var root_248 any = A_arbace_repl_A_const_43.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_248, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_250 lang.IFn; if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any = A_arbace_repl_A_const_44.GetRawRoot__O(); var arg_252 any; var root_253 any = A_arbace_repl_A_const_45.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any; var root_257 any = A_arbace_repl_A_const_46.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_core.A_arbace_core_ns_interns_A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = p1__1239000026_SHARP___1; if linked_258 == nil { arg_256 = ifn_259.Invoke_O__O(arg_260) } else { arg_256 = linked_258.(*aot_arbace_core.A_arbace_core_ns_interns_A).Invoke_O_O__O(root_257, arg_260) }; if linked_254 == nil { arg_252 = ifn_255.Invoke_O__O(arg_256) } else { arg_252 = linked_254.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_253, arg_256) }; if linked_249 == nil { arg_247 = ifn_250.Invoke_O_O__O(arg_251, arg_252) } else { arg_247 = linked_249.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_248, arg_251, arg_252) }; if linked_244 == nil { return ifn_245.Invoke_O_O__O(arg_246, arg_247) } else { return linked_244.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_243, arg_246, arg_247) } }









func A_arbace_repl_doc_A_New() *A_arbace_repl_doc_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_doc_A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_repl_doc_A) Ctor() {}
//line :131:1
func (t *A_arbace_repl_doc_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, name__2 any) any { var temp__1927000408__auto____4 any = lang.IFn_Cast(A_arbace_repl_A_const_54).Invoke_O__O(name__2); if




	jrt.J2g_Truth(temp__1927000408__auto____4) { var special_name__5 any = temp__1927000408__auto____4; var root_367 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_369 lang.IFn; if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any; var root_371 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp2 any; var root_376 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any; var root_380 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_56); var arg_384 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_57); if linked_381 == nil { arg_379 = ifn_382.Invoke_O_O__O(arg_383, arg_384) } else { arg_379 = linked_381.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_380, arg_383, arg_384) }; if linked_377 == nil { tmp2 = ifn_378.Invoke_O__O(arg_379) } else { tmp2 = linked_377.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_376, arg_379) }; arg_374 = tmp1.Invoke_O__O(tmp2); var arg_375 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp4 any; var root_385 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_385, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_387 lang.IFn; if linked_386 == nil { ifn_387 = lang.IFn_Cast(root_385) } else { ifn_387 = nil }; var arg_388 any; var root_389 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_389, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_391 lang.IFn; if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp6 any; var root_394 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any; var root_398 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_56); var arg_402 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_58); if linked_399 == nil { arg_397 = ifn_400.Invoke_O_O__O(arg_401, arg_402) } else { arg_397 = linked_399.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_398, arg_401, arg_402) }; if linked_395 == nil { tmp6 = ifn_396.Invoke_O__O(arg_397) } else { tmp6 = linked_395.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_394, arg_397) }; arg_392 = tmp5.Invoke_O__O(tmp6); var arg_393 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp8 any; var root_403 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any; var root_407 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_59); var arg_411 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(special_name__5); if linked_408 == nil { arg_406 = ifn_409.Invoke_O_O__O(arg_410, arg_411) } else { arg_406 = linked_408.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_407, arg_410, arg_411) }; if linked_404 == nil { tmp8 = ifn_405.Invoke_O__O(arg_406) } else { tmp8 = linked_404.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_403, arg_406) }; arg_393 = tmp7.Invoke_O__O(tmp8); if linked_390 == nil { arg_388 = ifn_391.Invoke_O_O__O(arg_392, arg_393) } else { arg_388 = linked_390.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_389, arg_392, arg_393) }; if linked_386 == nil { tmp4 = ifn_387.Invoke_O__O(arg_388) } else { tmp4 = linked_386.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_385, arg_388) }; arg_375 = tmp3.Invoke_O__O(tmp4); if linked_372 == nil { arg_370 = ifn_373.Invoke_O_O__O(arg_374, arg_375) } else { arg_370 = linked_372.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_371, arg_374, arg_375) }; if linked_368 == nil { return ifn_369.Invoke_O__O(arg_370) } else { return linked_368.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_367, arg_370) } } else {

		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repl_A_const_10.GetRawRoot__O()).Invoke_O__O(name__2)) { var root_412 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any; var root_416 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_416, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp10 any; var root_421 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_423 lang.IFn; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any; var root_425 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_56); var arg_429 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_60); if linked_426 == nil { arg_424 = ifn_427.Invoke_O_O__O(arg_428, arg_429) } else { arg_424 = linked_426.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_425, arg_428, arg_429) }; if linked_422 == nil { tmp10 = ifn_423.Invoke_O__O(arg_424) } else { tmp10 = linked_422.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_421, arg_424) }; arg_419 = tmp9.Invoke_O__O(tmp10); var arg_420 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp12 any; var root_430 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any; var root_434 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp14 any; var root_439 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_439, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_441 lang.IFn; if linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any; var root_443 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_445 lang.IFn; if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_56); var arg_447 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_61); if linked_444 == nil { arg_442 = ifn_445.Invoke_O_O__O(arg_446, arg_447) } else { arg_442 = linked_444.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_443, arg_446, arg_447) }; if linked_440 == nil { tmp14 = ifn_441.Invoke_O__O(arg_442) } else { tmp14 = linked_440.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_439, arg_442) }; arg_437 = tmp13.Invoke_O__O(tmp14); var arg_438 any; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp16 any; var root_448 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_448, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_450 lang.IFn; if linked_449 == nil { ifn_450 = lang.IFn_Cast(root_448) } else { ifn_450 = nil }; var arg_451 any; var root_452 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_452, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_454 lang.IFn; if linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_59); var arg_456 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(name__2); if linked_453 == nil { arg_451 = ifn_454.Invoke_O_O__O(arg_455, arg_456) } else { arg_451 = linked_453.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_452, arg_455, arg_456) }; if linked_449 == nil { tmp16 = ifn_450.Invoke_O__O(arg_451) } else { tmp16 = linked_449.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_448, arg_451) }; arg_438 = tmp15.Invoke_O__O(tmp16); if linked_435 == nil { arg_433 = ifn_436.Invoke_O_O__O(arg_437, arg_438) } else { arg_433 = linked_435.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_434, arg_437, arg_438) }; if linked_431 == nil { tmp12 = ifn_432.Invoke_O__O(arg_433) } else { tmp12 = linked_431.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_430, arg_433) }; arg_420 = tmp11.Invoke_O__O(tmp12); if linked_417 == nil { arg_415 = ifn_418.Invoke_O_O__O(arg_419, arg_420) } else { arg_415 = linked_417.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_416, arg_419, arg_420) }; if linked_413 == nil { return ifn_414.Invoke_O__O(arg_415) } else { return linked_413.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_412, arg_415) } } else { var tmp17 any; var root_457 any = A_arbace_repl_A_const_62.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_459 lang.IFn

			if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any = name__2; if linked_458 == nil { tmp17 = ifn_459.Invoke_O__O(arg_460) } else { tmp17 = linked_458.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_457, arg_460) }
//line :138:1
			if jrt.J2g_Truth(tmp17) { var root_461 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_461, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_463 lang.IFn; if linked_462 == nil { ifn_463 = lang.IFn_Cast(root_461) } else { ifn_463 = nil }; var arg_464 any; var root_465 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_465, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_467 lang.IFn; if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp19 any; var root_470 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_472 lang.IFn; if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any; var root_474 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_476 lang.IFn; if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_56); var arg_478 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_63); if linked_475 == nil { arg_473 = ifn_476.Invoke_O_O__O(arg_477, arg_478) } else { arg_473 = linked_475.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_474, arg_477, arg_478) }; if linked_471 == nil { tmp19 = ifn_472.Invoke_O__O(arg_473) } else { tmp19 = linked_471.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_470, arg_473) }; arg_468 = tmp18.Invoke_O__O(tmp19); var arg_469 any; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp21 any; var root_479 any = A_arbace_repl_A_const_64.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = A_arbace_repl_A_const_65.GetRawRoot__O(); var arg_483 any; var root_484 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_484, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_486 lang.IFn; if linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()); var tmp23 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_25); var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp25 any; var root_495 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_495, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_497 lang.IFn; if linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any; var root_499 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_500 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_499, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_501 lang.IFn; if linked_500 == nil { ifn_501 = lang.IFn_Cast(root_499) } else { ifn_501 = nil }; var arg_502 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_59); var arg_503 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(name__2); if linked_500 == nil { arg_498 = ifn_501.Invoke_O_O__O(arg_502, arg_503) } else { arg_498 = linked_500.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_499, arg_502, arg_503) }; if linked_496 == nil { tmp25 = ifn_497.Invoke_O__O(arg_498) } else { tmp25 = linked_496.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_495, arg_498) }; var tmp26 any = tmp24.Invoke_O__O(tmp25); var tmp27 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_22); var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp29 any; var root_504 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_504, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_506 lang.IFn; if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any; var root_508 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_508, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_510 lang.IFn; if linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_59); var arg_512 any; var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp31 any; var root_513 any = A_arbace_repl_A_const_38.GetRawRoot__O(); var linked_514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_513, aot_arbace_spec_alpha.A_arbace_spec_alpha_describe_A_fn_class); var ifn_515 lang.IFn

				if linked_514 == nil { ifn_515 = lang.IFn_Cast(root_513) } else { ifn_515 = nil }; var arg_516 any = name__2; if linked_514 == nil { tmp31 = ifn_515.Invoke_O__O(arg_516) } else { tmp31 = linked_514.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_describe_A).Invoke_O_O__O(root_513, arg_516) }
//line :138:1
				arg_512 = tmp30.Invoke_O__O(tmp31); if linked_509 == nil { arg_507 = ifn_510.Invoke_O_O__O(arg_511, arg_512) } else { arg_507 = linked_509.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_508, arg_511, arg_512) }; if linked_505 == nil { tmp29 = ifn_506.Invoke_O__O(arg_507) } else { tmp29 = linked_505.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_504, arg_507) }; arg_487 = tmp22.Invoke_O_O_O_O__O(tmp23, tmp26, tmp27, tmp28.Invoke_O__O(tmp29)); if linked_485 == nil { arg_483 = ifn_486.Invoke_O__O(arg_487) } else { arg_483 = linked_485.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_484, arg_487) }; if linked_480 == nil { tmp21 = ifn_481.Invoke_O_O__O(arg_482, arg_483) } else { tmp21 = linked_480.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_479, arg_482, arg_483) }; arg_469 = tmp20.Invoke_O__O(tmp21); if linked_466 == nil { arg_464 = ifn_467.Invoke_O_O__O(arg_468, arg_469) } else { arg_464 = linked_466.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_465, arg_468, arg_469) }; if linked_462 == nil { return ifn_463.Invoke_O__O(arg_464) } else { return linked_462.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_461, arg_464) } } else { var tmp32 any; var root_517 any = A_arbace_repl_A_const_66.GetRawRoot__O(); var linked_518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_517, aot_arbace_core.A_arbace_core_find_ns_A_fn_class); var ifn_519 lang.IFn


					if linked_518 == nil { ifn_519 = lang.IFn_Cast(root_517) } else { ifn_519 = nil }; var arg_520 any = name__2; if linked_518 == nil { tmp32 = ifn_519.Invoke_O__O(arg_520) } else { tmp32 = linked_518.(*aot_arbace_core.A_arbace_core_find_ns_A).Invoke_O_O__O(root_517, arg_520) }
//line :138:1
					if jrt.J2g_Truth(tmp32) { var root_521 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_521, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_523 lang.IFn; if linked_522 == nil { ifn_523 = lang.IFn_Cast(root_521) } else { ifn_523 = nil }; var arg_524 any; var root_525 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_527 lang.IFn; if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any; var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp34 any; var root_530 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_530, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_532 lang.IFn; if linked_531 == nil { ifn_532 = lang.IFn_Cast(root_530) } else { ifn_532 = nil }; var arg_533 any; var root_534 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_534, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_536 lang.IFn; if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_56); var arg_538 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_67); if linked_535 == nil { arg_533 = ifn_536.Invoke_O_O__O(arg_537, arg_538) } else { arg_533 = linked_535.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_534, arg_537, arg_538) }; if linked_531 == nil { tmp34 = ifn_532.Invoke_O__O(arg_533) } else { tmp34 = linked_531.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_530, arg_533) }; arg_528 = tmp33.Invoke_O__O(tmp34); var arg_529 any; var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp36 any; var root_539 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_541 lang.IFn; if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any; var root_543 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_543, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any; var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp38 any; var root_548 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_550 lang.IFn; if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any; var root_552 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_552, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_56); var arg_556 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_68); if linked_553 == nil { arg_551 = ifn_554.Invoke_O_O__O(arg_555, arg_556) } else { arg_551 = linked_553.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_552, arg_555, arg_556) }; if linked_549 == nil { tmp38 = ifn_550.Invoke_O__O(arg_551) } else { tmp38 = linked_549.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_548, arg_551) }; arg_546 = tmp37.Invoke_O__O(tmp38); var arg_547 any; var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp40 any; var root_557 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any; var root_561 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_561, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_563 lang.IFn; if linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_69); var arg_565 any; var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp42 any; var root_566 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any; var root_570 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_570, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_572 lang.IFn; if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_59); var arg_574 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(name__2); if linked_571 == nil { arg_569 = ifn_572.Invoke_O_O__O(arg_573, arg_574) } else { arg_569 = linked_571.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_570, arg_573, arg_574) }; if linked_567 == nil { tmp42 = ifn_568.Invoke_O__O(arg_569) } else { tmp42 = linked_567.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_566, arg_569) }; arg_565 = tmp41.Invoke_O__O(tmp42); if linked_562 == nil { arg_560 = ifn_563.Invoke_O_O__O(arg_564, arg_565) } else { arg_560 = linked_562.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_561, arg_564, arg_565) }; if linked_558 == nil { tmp40 = ifn_559.Invoke_O__O(arg_560) } else { tmp40 = linked_558.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_557, arg_560) }; arg_547 = tmp39.Invoke_O__O(tmp40); if linked_544 == nil { arg_542 = ifn_545.Invoke_O_O__O(arg_546, arg_547) } else { arg_542 = linked_544.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_543, arg_546, arg_547) }; if linked_540 == nil { tmp36 = ifn_541.Invoke_O__O(arg_542) } else { tmp36 = linked_540.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_539, arg_542) }; arg_529 = tmp35.Invoke_O__O(tmp36); if linked_526 == nil { arg_524 = ifn_527.Invoke_O_O__O(arg_528, arg_529) } else { arg_524 = linked_526.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_525, arg_528, arg_529) }; if linked_522 == nil { return ifn_523.Invoke_O__O(arg_524) } else { return linked_522.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_521, arg_524) } } else { var tmp43 any; var root_575 any = A_arbace_repl_A_const_11.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_577 lang.IFn



						if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any = name__2; if linked_576 == nil { tmp43 = ifn_577.Invoke_O__O(arg_578) } else { tmp43 = linked_576.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_575, arg_578) }
//line :138:1
						if jrt.J2g_Truth(tmp43) { var root_579 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_579, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_581 lang.IFn; if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any; var root_583 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_583, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_585 lang.IFn; if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any; var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp45 any; var root_588 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_590 lang.IFn; if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any; var root_592 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_592, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_594 lang.IFn; if linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_56); var arg_596 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_70); if linked_593 == nil { arg_591 = ifn_594.Invoke_O_O__O(arg_595, arg_596) } else { arg_591 = linked_593.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_592, arg_595, arg_596) }; if linked_589 == nil { tmp45 = ifn_590.Invoke_O__O(arg_591) } else { tmp45 = linked_589.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_588, arg_591) }; arg_586 = tmp44.Invoke_O__O(tmp45); var arg_587 any; var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp47 any; var root_597 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any; var root_601 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_602 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_601, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_603 lang.IFn; if linked_602 == nil { ifn_603 = lang.IFn_Cast(root_601) } else { ifn_603 = nil }; var arg_604 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_71); var arg_605 any; var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp49 any; var root_606 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any; var root_610 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_72); var arg_614 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(name__2); if linked_611 == nil { arg_609 = ifn_612.Invoke_O_O__O(arg_613, arg_614) } else { arg_609 = linked_611.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_610, arg_613, arg_614) }; if linked_607 == nil { tmp49 = ifn_608.Invoke_O__O(arg_609) } else { tmp49 = linked_607.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_606, arg_609) }; arg_605 = tmp48.Invoke_O__O(tmp49); if linked_602 == nil { arg_600 = ifn_603.Invoke_O_O__O(arg_604, arg_605) } else { arg_600 = linked_602.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_601, arg_604, arg_605) }; if linked_598 == nil { tmp47 = ifn_599.Invoke_O__O(arg_600) } else { tmp47 = linked_598.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_597, arg_600) }; arg_587 = tmp46.Invoke_O__O(tmp47); if linked_584 == nil { arg_582 = ifn_585.Invoke_O_O__O(arg_586, arg_587) } else { arg_582 = linked_584.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_583, arg_586, arg_587) }; if linked_580 == nil { return ifn_581.Invoke_O__O(arg_582) } else { return linked_580.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_579, arg_582) } } else { return nil } } } } } }








func A_arbace_repl_source_fn_A_New() *A_arbace_repl_source_fn_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_source_fn_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_repl_source_fn_A) Ctor() {}
//line :147:1
func (t *A_arbace_repl_source_fn_A) Invoke_O_O__O(self, x__0 any) any { var temp__1927000414__auto____2 any; var root_615 any = A_arbace_repl_A_const_11.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_617 lang.IFn; if








	linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = x__0; if linked_616 == nil { temp__1927000414__auto____2 = ifn_617.Invoke_O__O(arg_618) } else { temp__1927000414__auto____2 = linked_616.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_615, arg_618) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var v__3 any = temp__1927000414__auto____2; var tmp1 *lang.Keyword = A_arbace_repl_A_const_73; var temp__1927000414__auto____4 any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__3))
		if jrt.J2g_Truth(temp__1927000414__auto____4) { var filepath__5 any = temp__1927000414__auto____4; var tmp2 any = lang.RT_BaseLoader__ClassLoader_NoInit(); var tmp3 *jrt.Class = A_arbace_repl_A_const_74; var temp__1927000414__auto____6 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp2, tmp3, Lit_34, jrt.RefArrayOf(jrt.Object_class, filepath__5))
			if jrt.J2g_Truth(temp__1927000414__auto____6) { var strm__7 any = temp__1927000414__auto____6; var rdr__8 any = jrt.LineNumberReader_New_Reader(jrt.InputStreamReader_New_InputStream(jrt.InputStream_Cast(strm__7))); var tmp4 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var n__1927000701__auto____11 int64; var tmp5 jrt.Number_I; var tmp6 *lang.Keyword = A_arbace_repl_A_const_76; var na_623 any = tmp6.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__3))

				if jrt.Long_InstanceOf(na_623) { var n0_624 int64 = jrt.NN(jrt.Long_Cast(na_623)).LongValue__J(); if n0_624 == -9223372036854775808 { tmp5 = lang.Numbers_Dec_O__Number_NoInit(na_623) } else { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_624 - 1)) } } else { if jrt.Double_InstanceOf(na_623) { var n0_624_2 float64 = jrt.NN(jrt.Double_Cast(na_623)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_624_2 - 1.0)) } else { tmp5 = lang.Numbers_Dec_O__Number_NoInit(na_623) } }; n__1927000701__auto____11 = lang.RT_LongCast_O__J_NoInit(tmp5)
//line :158:1
				var ___12 int64 = 0; L1: for {

					if lang.Numbers_Lt_J_J__Z_NoInit(___12, n__1927000701__auto____11) { jrt.NN(jrt.LineNumberReader_Cast(rdr__8)).ReadLine__String(); ___12 = lang.Numbers_Unchecked_inc_J__J_NoInit(___12); continue L1 }
//line :158:1
					break L1 }; var text__11 any = jrt.StringBuilder_New(); var pbr__12 any; var p__840000142__auto____12 any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_35), jrt.RefArrayOf(jrt.Object_class, rdr__8)); var root_625 any = A_arbace_repl_A_const_77.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_init_proxy_A_fn_class); var ifn_627 lang.IFn



				if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = p__840000142__auto____12; var arg_629 any; var tmp7 *lang.Compiler_AOTFn; var fnbody__639 any = A_arbace_repl_source_fn_fn__1239000039_A_New_O(text__11); var tmp8 *jrt.Class; var fncls__638 *jrt.Class = A_arbace_repl_source_fn_fn__1239000039_A_fn_class; if fncls__638 == nil { var fncls__638d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, fnbody__639); A_arbace_repl_source_fn_fn__1239000039_A_fn_class = fncls__638d; tmp8 = fncls__638d } else { tmp8 = fncls__638 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__639, tmp8, nil); arg_629 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_36, tmp7.Ref())); if linked_626 == nil { ifn_627.Invoke_O_O__O(arg_628, arg_629) } else { linked_626.(*aot_arbace_core.A_arbace_core_init_proxy_A).Invoke_O_O_O__O(root_625, arg_628, arg_629) }
//line :158:1
				pbr__12 = p__840000142__auto____12; var read_opts__13 any







				if jrt.NN(jrt.String_Cast(filepath__5)).EndsWith_String__Z(Lit_38) { read_opts__13 = A_arbace_repl_A_const_75 } else { read_opts__13 = lang.PersistentArrayMap_EMPTY.Ref() }
				var tmp9 any = A_arbace_repl_A_const_79; if lang.Util_Equiv_O_O__Z_NoInit(tmp9, A_arbace_repl_A_const_80.Get__O()) { panic(jrt.Thrown(jrt.IllegalStateException_New_String(Lit_39))) } else {

					var root_640 any = A_arbace_repl_A_const_81.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_642 lang.IFn; if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = read_opts__13; var arg_644 any = jrt.PushbackReader_New_Reader(jrt.Reader_Cast(pbr__12)); if linked_641 == nil { ifn_642.Invoke_O_O__O(arg_643, arg_644) } else { linked_641.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O__O(root_640, arg_643, arg_644) } }
				var root_619 any = A_arbace_repl_A_const_28.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_619, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = text__11; if linked_620 == nil { tmp4 = ifn_621.Invoke_O__O(arg_622) } else { tmp4 = linked_620.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_619, arg_622) } }; return nil }()
//line :159:1
				jrt.BufferedReader_Cast(rdr__8).Close__V()
//line :158:1
				if tmp10 != nil { panic(tmp10) }; return tmp4 } else { return nil } } else {
//line :157:1
					return nil } } else {
//line :156:1
						return nil } }





func A_arbace_repl_source_fn_fn__1239000039_A_New_O(p0 any) *A_arbace_repl_source_fn_fn__1239000039_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_source_fn_fn__1239000039_A{}; t.Ctor_O(p0); return t }
//line :162:1
func (t *A_arbace_repl_source_fn_fn__1239000039_A) Ctor_O(c__text any) { t.F_text = c__text }
//line :162:1
func (t *A_arbace_repl_source_fn_fn__1239000039_A) Invoke_O_O__O(self, this__1 any) any { var i__2 any; var root_630 any = A_arbace_repl_A_const_78.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_proxy_call_with_super_A_fn_class); var ifn_632 lang.IFn; if
											linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any; var fnbody__637 any = A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_New_O(this__1); var tmp1 *jrt.Class; var fncls__636 *jrt.Class = A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_fn_class; if fncls__636 == nil { var fncls__636d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, fnbody__637); A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_fn_class = fncls__636d; tmp1 = fncls__636d } else { tmp1 = fncls__636 }; arg_633 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__637, tmp1, nil); var arg_634 any = this__1; var arg_635 any = Lit_36; if linked_631 == nil { i__2 = ifn_632.Invoke_O_O_O__O(arg_633, arg_634, arg_635) } else { i__2 = linked_631.(*aot_arbace_core.A_arbace_core_proxy_call_with_super_A).Invoke_O_O_O_O__O(root_630, arg_633, arg_634, arg_635) }; var tmp2 /*line :164:1*/*jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_text); jrt.NN(tmp2).Append_C__StringBuilder(lang.RT_CharCast_O__C_NoInit(i__2)); return i__2 }
//line :163:1
func A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_New_O(p0 any) *A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A{}; t.Ctor_O(p0); return t }
//line :163:1
func (t *A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A) Ctor_O(c__this any) { t.F_this = c__this }
//line :163:1
func (t *A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A) Invoke_O__O(self any) any { return lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(t.F_this, Lit_36, false) }








func A_arbace_repl_source_A_New() *A_arbace_repl_source_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_source_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_repl_source_A) Ctor() {}
//line :172:1
func (t *A_arbace_repl_source_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, n__2 any) any { var root_645 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_645, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_647 lang.IFn; if linked_646 == nil { ifn_647 = lang.IFn_Cast(root_645) } else { ifn_647 = nil }; var arg_648 any; var root_649 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_649, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_651 lang.IFn; if linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_82); var arg_653 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp2 any; var root_654 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_654, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_656 lang.IFn; if linked_655 == nil { ifn_656 = lang.IFn_Cast(root_654) } else { ifn_656 = nil }; var arg_657 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()); var tmp4 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_83); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp6 any; var root_664 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_664, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_666 lang.IFn; if linked_665 == nil { ifn_666 = lang.IFn_Cast(root_664) } else { ifn_666 = nil }; var arg_667 any; var root_668 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_669 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_668, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_670 lang.IFn; if linked_669 == nil { ifn_670 = lang.IFn_Cast(root_668) } else { ifn_670 = nil }; var arg_671 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_84); var arg_672 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp8 any; var root_673 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_673, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_675 lang.IFn; if linked_674 == nil { ifn_675 = lang.IFn_Cast(root_673) } else { ifn_675 = nil }; var arg_676 any; var root_677 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_678 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_677, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_679 lang.IFn; if linked_678 == nil { ifn_679 = lang.IFn_Cast(root_677) } else { ifn_679 = nil }; var arg_680 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_59); var arg_681 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(n__2); if linked_678 == nil { arg_676 = ifn_679.Invoke_O_O__O(arg_680, arg_681) } else { arg_676 = linked_678.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_677, arg_680, arg_681) }; if linked_674 == nil { tmp8 = ifn_675.Invoke_O__O(arg_676) } else { tmp8 = linked_674.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_673, arg_676) }; arg_672 = tmp7.Invoke_O__O(tmp8); if linked_669 == nil { arg_667 = ifn_670.Invoke_O_O__O(arg_671, arg_672) } else { arg_667 = linked_669.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_668, arg_671, arg_672) }; if linked_665 == nil { tmp6 = ifn_666.Invoke_O__O(arg_667) } else { tmp6 = linked_665.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_664, arg_667) }; var tmp9 any = tmp5.Invoke_O__O(tmp6); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp11 any; var root_682 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_682, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_684 lang.IFn; if linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; var arg_685 any; var root_686 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_688 lang.IFn; if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var arg_689 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_85); var arg_690 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(Lit_33); if linked_687 == nil { arg_685 = ifn_688.Invoke_O_O__O(arg_689, arg_690) } else { arg_685 = linked_687.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_686, arg_689, arg_690) }; if linked_683 == nil { tmp11 = ifn_684.Invoke_O__O(arg_685) } else { tmp11 = linked_683.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_682, arg_685) }; arg_657 = tmp3.Invoke_O_O_O__O(tmp4, tmp9, tmp10.Invoke_O__O(tmp11)); if linked_655 == nil { tmp2 = ifn_656.Invoke_O__O(arg_657) } else { tmp2 = linked_655.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_654, arg_657) }; arg_653 = tmp1.Invoke_O__O(tmp2); if linked_650 == nil { arg_648 = ifn_651.Invoke_O_O__O(arg_652, arg_653) } else { arg_648 = linked_650.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_649, arg_652, arg_653) }; if linked_646 == nil { return ifn_647.Invoke_O__O(arg_648) } else { return linked_646.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_645, arg_648) } }








func A_arbace_repl_apropos_A_New() *A_arbace_repl_apropos_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_apropos_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_repl_apropos_A) Ctor() {}
//line :181:1
func (t *A_arbace_repl_apropos_A) Invoke_O_O__O(self, str_or_pattern__0 any) any { var matches_QMARK___2 any; if




	jrt.Pattern_InstanceOf(str_or_pattern__0) { var fnbody__701 any = A_arbace_repl_apropos_fn__1239000052_A_New_O(str_or_pattern__0); var tmp1 *jrt.Class; var fncls__700 *jrt.Class = A_arbace_repl_apropos_fn__1239000052_A_fn_class; if fncls__700 == nil { var fncls__700d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1, false, fnbody__701); A_arbace_repl_apropos_fn__1239000052_A_fn_class = fncls__700d; tmp1 = fncls__700d } else { tmp1 = fncls__700 }; matches_QMARK___2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__701, tmp1, nil) } else { var fnbody__711 any = A_arbace_repl_apropos_fn__1239000054_A_New_O(str_or_pattern__0); var tmp2 *jrt.Class; var fncls__710 *jrt.Class = A_arbace_repl_apropos_fn__1239000054_A_fn_class; if fncls__710 == nil { var fncls__710d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, fnbody__711); A_arbace_repl_apropos_fn__1239000054_A_fn_class = fncls__710d; tmp2 = fncls__710d } else { tmp2 = fncls__710 }; matches_QMARK___2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__711, tmp2, nil) }; var root_712 any =


	A_arbace_repl_A_const_86.GetRawRoot__O(); var linked_713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_712, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_714 lang.IFn; if linked_713 == nil { ifn_714 = lang.IFn_Cast(root_712) } else { ifn_714 = nil }; var arg_715 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_41.GetRawRoot__O()); var tmp4 *lang.Compiler_AOTFn; var fnbody__755 any = A_arbace_repl_apropos_fn__1239000056_A_New_O(matches_QMARK___2); var tmp5 *jrt.Class; var fncls__754 *jrt.Class = A_arbace_repl_apropos_fn__1239000056_A_fn_class; if fncls__754 == nil { var fncls__754d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, fnbody__755); A_arbace_repl_apropos_fn__1239000056_A_fn_class = fncls__754d; tmp5 = fncls__754d } else { tmp5 = fncls__754 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__755, tmp5, nil); var tmp6 any = tmp4.Ref(); var tmp7 any; var root_756 any = A_arbace_repl_A_const_47.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, aot_arbace_core.A_arbace_core_all_ns_A_fn_class); var ifn_758 lang.IFn; if



	linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; if linked_757 == nil { tmp7 = ifn_758.Invoke__O() } else { tmp7 = linked_757.(*aot_arbace_core.A_arbace_core_all_ns_A).Invoke_O__O(root_756) }; arg_715 = /*line :189:1*/tmp3.Invoke_O_O__O(tmp6, tmp7); if linked_713 == nil { return ifn_714.Invoke_O__O(arg_715) } else { return linked_713.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_712, arg_715) } }
//line :186:1
func A_arbace_repl_apropos_fn__1239000052_A_New_O(p0 any) *A_arbace_repl_apropos_fn__1239000052_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_apropos_fn__1239000052_A{}; t.Ctor_O(p0); return t }
//line :186:1
func (t *A_arbace_repl_apropos_fn__1239000052_A) Ctor_O(c__str_or_pattern any) { t.F_str_or_pattern = c__str_or_pattern }
//line :186:1
func (t *A_arbace_repl_apropos_fn__1239000052_A) Invoke_O_O__O(self, p1__1239000049_SHARP___1 any) any {
	var root_691 any = A_arbace_repl_A_const_51.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_693 lang.IFn; if linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any = t.F_str_or_pattern; var arg_695 any; var root_696 any = A_arbace_repl_A_const_28.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_696, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_698 lang.IFn; if linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any = p1__1239000049_SHARP___1; if linked_697 == nil { arg_695 = ifn_698.Invoke_O__O(arg_699) } else { arg_695 = linked_697.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_696, arg_699) }; if linked_692 == nil { return ifn_693.Invoke_O_O__O(arg_694, arg_695) } else { return linked_692.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_691, arg_694, arg_695) } }
//line :186:1
func A_arbace_repl_apropos_fn__1239000054_A_New_O(p0 any) *A_arbace_repl_apropos_fn__1239000054_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_apropos_fn__1239000054_A{}; t.Ctor_O(p0); return t }
//line :186:1
func (t *A_arbace_repl_apropos_fn__1239000054_A) Ctor_O(c__str_or_pattern any) { t.F_str_or_pattern = c__str_or_pattern }
//line :186:1
func (t *A_arbace_repl_apropos_fn__1239000054_A) Invoke_O_O__O(self, p1__1239000050_SHARP___1 any) any {

	var tmp1 any; var root_702 any = A_arbace_repl_A_const_28.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_704 lang.IFn; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any = p1__1239000050_SHARP___1; if linked_703 == nil { tmp1 = ifn_704.Invoke_O__O(arg_705) } else { tmp1 = linked_703.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_702, arg_705) }; var tmp2 *jrt.String = jrt.String_Cast(tmp1); var tmp3 any; var root_706 any = A_arbace_repl_A_const_28.GetRawRoot__O(); var linked_707 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_706, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_708 lang.IFn; if linked_707 == nil { ifn_708 = lang.IFn_Cast(root_706) } else { ifn_708 = nil }; var arg_709 any = t.F_str_or_pattern; if linked_707 == nil { tmp3 = ifn_708.Invoke_O__O(arg_709) } else { tmp3 = linked_707.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_706, arg_709) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(tmp2).Contains_CharSequence__Z(jrt.CharSequence_Cast(tmp3))).Ref() }
func A_arbace_repl_apropos_fn__1239000056_A_New_O(p0 any) *A_arbace_repl_apropos_fn__1239000056_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_apropos_fn__1239000056_A{}; t.Ctor_O(p0); return t }
//line :189:1
func (t *A_arbace_repl_apropos_fn__1239000056_A) Ctor_O(c__matches_QMARK_ any) { t.F_matches_QMARK_ = c__matches_QMARK_ }
//line :189:1
func (t *A_arbace_repl_apropos_fn__1239000056_A) Invoke_O_O__O(self, ns__1 any) any { var ns_name__2 any; var root_721 any = A_arbace_repl_A_const_28.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_721, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_723 lang.IFn; if
											linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any = ns__1; if linked_722 == nil { ns_name__2 = ifn_723.Invoke_O__O(arg_724) } else { ns_name__2 = linked_722.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_721, arg_724) }; var root_725 any =
											A_arbace_repl_A_const_43.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_725, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any; var fnbody__740 any = A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_New_O(ns_name__2); var tmp1 *jrt.Class; var fncls__739 *jrt.Class = A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_fn_class; if fncls__739 == nil { var fncls__739d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, fnbody__740); A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_fn_class = fncls__739d; tmp1 = fncls__739d } else { tmp1 = fncls__739 }; arg_728 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__740, tmp1, nil); var arg_729 any; var root_741 any = A_arbace_repl_A_const_87.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_741, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_743 lang.IFn; if
											linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any = t.F_matches_QMARK_; var arg_745 any; var root_746 any = A_arbace_repl_A_const_50.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_746, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_748 lang.IFn; if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any; var root_750 any = A_arbace_repl_A_const_88.GetRawRoot__O(); var linked_751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_750, aot_arbace_core.A_arbace_core_ns_publics_A_fn_class); var ifn_752 lang.IFn; if linked_751 == nil { ifn_752 = lang.IFn_Cast(root_750) } else { ifn_752 = nil }; var arg_753 any = ns__1; if linked_751 == nil { arg_749 = ifn_752.Invoke_O__O(arg_753) } else { arg_749 = linked_751.(*aot_arbace_core.A_arbace_core_ns_publics_A).Invoke_O_O__O(root_750, arg_753) }; if linked_747 == nil { arg_745 = ifn_748.Invoke_O__O(arg_749) } else { arg_745 = linked_747.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_746, arg_749) }; if linked_742 == nil { arg_729 = ifn_743.Invoke_O_O__O(arg_744, arg_745) } else { arg_729 = linked_742.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_741, arg_744, arg_745) }; if /*line :191:1*/ linked_726 == nil { return ifn_727.Invoke_O_O__O(arg_728, arg_729) } else { return linked_726.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_725, arg_728, arg_729) } }
//line :191:1
func A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_New_O(p0 any) *A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A{}; t.Ctor_O(p0); return t }
//line :191:1
func (t *A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A) Ctor_O(c__ns_name any) { t.F_ns_name = c__ns_name }
//line :191:1
func (t *A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A) Invoke_O_O__O(self, p1__1239000051_SHARP___1 any) any { var root_730 any = A_arbace_repl_A_const_27.GetRawRoot__O(); var linked_731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_730, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_732 lang.IFn; if linked_731 == nil { ifn_732 = lang.IFn_Cast(root_730) } else { ifn_732 = nil }; var arg_733 any = t.F_ns_name; var arg_734 any; var root_735 any = A_arbace_repl_A_const_28.GetRawRoot__O(); var linked_736 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_735, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_737 lang.IFn; if linked_736 == nil { ifn_737 = lang.IFn_Cast(root_735) } else { ifn_737 = nil }; var arg_738 any = p1__1239000051_SHARP___1; if linked_736 == nil { arg_734 = ifn_737.Invoke_O__O(arg_738) } else { arg_734 = linked_736.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_735, arg_738) }; if linked_731 == nil { return ifn_732.Invoke_O_O__O(arg_733, arg_734) } else { return linked_731.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_730, arg_733, arg_734) } }



func A_arbace_repl_dir_fn_A_New() *A_arbace_repl_dir_fn_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_dir_fn_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_repl_dir_fn_A) Ctor() {}
//line :195:1
func (t *A_arbace_repl_dir_fn_A) Invoke_O_O__O(self, ns__0 any) any {



	var root_759 any = A_arbace_repl_A_const_86.GetRawRoot__O(); var linked_760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_759, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_761 lang.IFn; if linked_760 == nil { ifn_761 = lang.IFn_Cast(root_759) } else { ifn_761 = nil }; var arg_762 any; var root_763 any = A_arbace_repl_A_const_43.GetRawRoot__O(); var linked_764 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_763, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_765 lang.IFn; if linked_764 == nil { ifn_765 = lang.IFn_Cast(root_763) } else { ifn_765 = nil }; var arg_766 any = A_arbace_repl_A_const_18.GetRawRoot__O(); var arg_767 any; var root_768 any = A_arbace_repl_A_const_88.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_768, aot_arbace_core.A_arbace_core_ns_publics_A_fn_class); var ifn_770 lang.IFn; if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any; var root_772 any = A_arbace_repl_A_const_89.GetRawRoot__O(); var linked_773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_772, aot_arbace_core.A_arbace_core_the_ns_A_fn_class); var ifn_774 lang.IFn; if linked_773 == nil { ifn_774 = lang.IFn_Cast(root_772) } else { ifn_774 = nil }; var arg_775 any; var tmp1 any; var root_776 any = A_arbace_repl_A_const_90.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_776, aot_arbace_core.A_arbace_core_ns_aliases_A_fn_class); var ifn_778 lang.IFn; if linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var arg_779 any = A_arbace_repl_A_const_91.Get__O(); if linked_777 == nil { tmp1 = ifn_778.Invoke_O__O(arg_779) } else { tmp1 = linked_777.(*aot_arbace_core.A_arbace_core_ns_aliases_A).Invoke_O_O__O(root_776, arg_779) }; arg_775 = lang.RT_Get_O_O_O__O_NoInit(tmp1, ns__0, ns__0); if linked_773 == nil { arg_771 = ifn_774.Invoke_O__O(arg_775) } else { arg_771 = linked_773.(*aot_arbace_core.A_arbace_core_the_ns_A).Invoke_O_O__O(root_772, arg_775) }; if linked_769 == nil { arg_767 = ifn_770.Invoke_O__O(arg_771) } else { arg_767 = linked_769.(*aot_arbace_core.A_arbace_core_ns_publics_A).Invoke_O_O__O(root_768, arg_771) }; if linked_764 == nil { arg_762 = ifn_765.Invoke_O_O__O(arg_766, arg_767) } else { arg_762 = linked_764.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_763, arg_766, arg_767) }; if linked_760 == nil { return ifn_761.Invoke_O__O(arg_762) } else { return linked_760.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_759, arg_762)
	} }
func A_arbace_repl_dir_A_New() *A_arbace_repl_dir_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_dir_A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_repl_dir_A) Ctor() {}
//line :201:1
func (t *A_arbace_repl_dir_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, nsname__2 any) any { var root_780 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_780, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_782 lang.IFn; if linked_781 == nil { ifn_782 = lang.IFn_Cast(root_780) } else { ifn_782 = nil }; var arg_783 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_92); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp4 any; var root_790 any = A_arbace_repl_A_const_64.GetRawRoot__O(); var linked_791 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_790, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_792 lang.IFn; if linked_791 == nil { ifn_792 = lang.IFn_Cast(root_790) } else { ifn_792 = nil }; var arg_793 any = A_arbace_repl_A_const_93.GetRawRoot__O(); var arg_794 any; var root_795 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_797 lang.IFn; if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any; var root_799 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_800 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_799, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_801 lang.IFn; if linked_800 == nil { ifn_801 = lang.IFn_Cast(root_799) } else { ifn_801 = nil }; var arg_802 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_94); var arg_803 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp6 any; var root_804 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_804, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_806 lang.IFn; if linked_805 == nil { ifn_806 = lang.IFn_Cast(root_804) } else { ifn_806 = nil }; var arg_807 any; var root_808 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_809 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_808, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_810 lang.IFn; if linked_809 == nil { ifn_810 = lang.IFn_Cast(root_808) } else { ifn_810 = nil }; var arg_811 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_95); var arg_812 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp8 any; var root_813 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_813, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_815 lang.IFn; if linked_814 == nil { ifn_815 = lang.IFn_Cast(root_813) } else { ifn_815 = nil }; var arg_816 any; var root_817 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_817, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_819 lang.IFn; if linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_59); var arg_821 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(nsname__2); if linked_818 == nil { arg_816 = ifn_819.Invoke_O_O__O(arg_820, arg_821) } else { arg_816 = linked_818.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_817, arg_820, arg_821) }; if linked_814 == nil { tmp8 = ifn_815.Invoke_O__O(arg_816) } else { tmp8 = linked_814.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_813, arg_816) }; arg_812 = tmp7.Invoke_O__O(tmp8); if linked_809 == nil { arg_807 = ifn_810.Invoke_O_O__O(arg_811, arg_812) } else { arg_807 = linked_809.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_808, arg_811, arg_812) }; if linked_805 == nil { tmp6 = ifn_806.Invoke_O__O(arg_807) } else { tmp6 = linked_805.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_804, arg_807) }; arg_803 = tmp5.Invoke_O__O(tmp6); if linked_800 == nil { arg_798 = ifn_801.Invoke_O_O__O(arg_802, arg_803) } else { arg_798 = linked_800.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_799, arg_802, arg_803) }; if linked_796 == nil { arg_794 = ifn_797.Invoke_O__O(arg_798) } else { arg_794 = linked_796.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_795, arg_798) }; if linked_791 == nil { tmp4 = ifn_792.Invoke_O_O__O(arg_793, arg_794) } else { tmp4 = linked_791.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_790, arg_793, arg_794) }; var tmp9 any = tmp3.Invoke_O__O(tmp4); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()); var tmp11 any; var root_822 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_822, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_824 lang.IFn; if linked_823 == nil { ifn_824 = lang.IFn_Cast(root_822) } else { ifn_824 = nil }; var arg_825 any; var root_826 any = A_arbace_repl_A_const_40.GetRawRoot__O(); var linked_827 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_826, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_828 lang.IFn; if linked_827 == nil { ifn_828 = lang.IFn_Cast(root_826) } else { ifn_828 = nil }; var arg_829 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_96); var arg_830 any = lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_94); if linked_827 == nil { arg_825 = ifn_828.Invoke_O_O__O(arg_829, arg_830) } else { arg_825 = linked_827.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_826, arg_829, arg_830) }; if linked_823 == nil { tmp11 = ifn_824.Invoke_O__O(arg_825) } else { tmp11 = linked_823.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_822, arg_825) }; arg_783 = tmp1.Invoke_O_O_O__O(tmp2, tmp9, tmp10.Invoke_O__O(tmp11)); if linked_781 == nil { return ifn_782.Invoke_O__O(arg_783) } else { return linked_781.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_780, arg_783) } }





func A_arbace_repl_demunge_A_New() *A_arbace_repl_demunge_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_demunge_A{}; t.Ctor(); return t }
//line :207:1
func (t *A_arbace_repl_demunge_A) Ctor() {}
//line :207:1
func (t *A_arbace_repl_demunge_A) Invoke_O_O__O(self, fn_name__0 any) any {




	return lang.Compiler_Demunge_String__String_NoInit(jrt.String_Cast(fn_name__0)).Ref()
}
func A_arbace_repl_root_cause_A_New() *A_arbace_repl_root_cause_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_root_cause_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_repl_root_cause_A) Ctor() {}
//line :214:1
func (t *A_arbace_repl_root_cause_A) Invoke_O_O__O(self, t__0 any) any { { var cause__2 any = t__0; L1: for {





	var tmp1 any; var and__1927000168__auto____3 bool = lang.Compiler_CompilerException_InstanceOf(cause__2); if and__1927000168__auto____3 {
		var root_831 any = A_arbace_repl_A_const_97.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_831, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any = lang.Compiler_CompilerException_Cast(cause__2).F_source.Ref(); var arg_835 any = Lit_26; if linked_832 == nil { tmp1 = ifn_833.Invoke_O_O__O(arg_834, arg_835) } else { tmp1 = linked_832.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_831, arg_834, arg_835) } } else {
//line :220:1
			tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) { return cause__2 } else { var temp__1927000408__auto____3 any = jrt.Throwable_Cast(cause__2).GetCause__Throwable()


				if jrt.J2g_Truth(temp__1927000408__auto____3) { var cause__4 any = temp__1927000408__auto____3
					cause__2 = cause__4; continue L1 } else {
//line :223:1
						return cause__2 } } } }; /*line :214:1*/panic("j2g: unreachable") }












func A_arbace_repl_stack_element_str_A_New() *A_arbace_repl_stack_element_str_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_stack_element_str_A{}; t.Ctor(); return t }
//line :227:1
func (t *A_arbace_repl_stack_element_str_A) Ctor() {}
//line :227:1
func (t *A_arbace_repl_stack_element_str_A) Invoke_O_O__O(self, el__0 any) any { var file__2 any = jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetFileName__String().Ref(); var clojure_fn_QMARK___3 any; var and__1927000168__auto____3 any = file__2; if




	jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 bool = jrt.NN(jrt.String_Cast(file__2)).EndsWith_String__Z(Lit_41); if or__1927000174__auto____4 { clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else { var or__1927000174__auto____5 bool = jrt.NN(jrt.String_Cast(file__2)).EndsWith_String__Z(Lit_42); if or__1927000174__auto____5 { clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool = jrt.NN(jrt.String_Cast(file__2)).EndsWith_String__Z(Lit_43); if or__1927000174__auto____6 { clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else {


		clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(file__2, Lit_26)).Ref() } } } } else {
//line :232:1
			clojure_fn_QMARK___3 = and__1927000168__auto____3 }; var tmp1 /*line :236:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_44, nil, Lit_20, nil, Lit_45); var tmp2 any; if jrt.J2g_Truth(clojure_fn_QMARK___3) {
				var root_836 any = A_arbace_repl_A_const_98.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_836, A_arbace_repl_demunge_A_fn_class); var ifn_838 lang.IFn; if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any = jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetClassName__String().Ref(); if linked_837 == nil { tmp2 = ifn_838.Invoke_O__O(arg_839) } else { tmp2 = linked_837.(*A_arbace_repl_demunge_A).Invoke_O_O__O(root_836, arg_839) } } else {
					tmp2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_46, nil), jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetClassName__String().Ref(), nil, jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetMethodName__String().Ref())).Ref() }; return /*line :236:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil, jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetFileName__String().Ref(), nil, jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetLineNumber__I()).Ref(), nil)).Ref() }




func A_arbace_repl_pst_A_New() *A_arbace_repl_pst_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_pst_A{}; t.Ctor(); return t }
//line :241:1
func (t *A_arbace_repl_pst_A) Ctor() {}
//line :241:1
func (t *A_arbace_repl_pst_A) Invoke_O_O_O__O(self, e__0, depth__1 any) any {










	var root_848 any = A_arbace_repl_A_const_101.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_848, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_850 lang.IFn; if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_65.GetRawRoot__O()); var tmp2 any = A_arbace_repl_A_const_102; var arg_851 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_repl_A_const_103.Get__O()); if linked_849 == nil { ifn_850.Invoke_O__O(arg_851) } else { linked_849.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_848, arg_851) }
//line :241:1
	var tmp3 any; tmp23 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)











		{ var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_104); var tmp5 *lang.Keyword = A_arbace_repl_A_const_108; var tmp6 any; var root_877 any = A_arbace_repl_A_const_106.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_879 lang.IFn
			if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any = e__0; if linked_878 == nil { tmp6 = ifn_879.Invoke_O__O(arg_880) } else { tmp6 = linked_878.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_877, arg_880) }
//line :253:1
			if jrt.J2g_Truth(tmp4.Invoke_O__O(tmp5.Invoke_O__O(tmp6))) {

				lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(Lit_21) }
			var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()); var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_17, nil, nil); var tmp9 any; var root_865 any = A_arbace_repl_A_const_105.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = e__0; if linked_866 == nil { tmp9 = ifn_867.Invoke_O__O(arg_868) } else { tmp9 = linked_866.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_865, arg_868) }; var tmp10 any = jrt.NN(jrt.Class_Cast(tmp9)).GetSimpleName__String().Ref(); var tmp11 any = jrt.Throwable_Cast(e__0).GetMessage__String().Ref(); var tmp12 *jrt.String; var temp__1927000414__auto____9 any; var root_869 any = A_arbace_repl_A_const_106.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_871 lang.IFn

			if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = e__0; if linked_870 == nil { temp__1927000414__auto____9 = ifn_871.Invoke_O__O(arg_872) } else { temp__1927000414__auto____9 = linked_870.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_869, arg_872) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var info__10 any = temp__1927000414__auto____9; tmp12 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repl_A_const_107.GetRawRoot__O()).Invoke_O__O(info__10))) } else { tmp12 = nil }
//line :256:1
			tmp7.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, tmp10, nil, tmp11, tmp12.Ref())).Ref())
//line :241:1
			var st__5 any = jrt.Throwable_Cast(e__0).GetStackTrace__StackTraceElement1().Ref(); var cause__6 any = jrt.Throwable_Cast(e__0).GetCause__Throwable(); var seq_1239000072__7 any; var root_881 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_883 lang.IFn



















			if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any; var root_885 any = A_arbace_repl_A_const_109.GetRawRoot__O(); var linked_886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_885, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_887 lang.IFn; if linked_886 == nil { ifn_887 = lang.IFn_Cast(root_885) } else { ifn_887 = nil }; var arg_888 any = depth__1; var arg_889 any; var root_890 any = A_arbace_repl_A_const_110.GetRawRoot__O(); var linked_891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_890, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_892 lang.IFn
			if linked_891 == nil { ifn_892 = lang.IFn_Cast(root_890) } else { ifn_892 = nil }; var arg_893 any; var fnbody__896 any = A_arbace_repl_pst_fn__1239000076_A_New(); var tmp13 *jrt.Class; var fncls__895 *jrt.Class = A_arbace_repl_pst_fn__1239000076_A_fn_class; if fncls__895 == nil { var fncls__895d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, nil); A_arbace_repl_pst_fn__1239000076_A_fn_class = fncls__895d; tmp13 = fncls__895d } else { tmp13 = fncls__895 }; arg_893 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__896, tmp13, nil); var arg_894 any = st__5; if linked_891 == nil { arg_889 = ifn_892.Invoke_O_O__O(arg_893, arg_894) } else { arg_889 = linked_891.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_890, arg_893, arg_894) }
//line :261:1
			if linked_886 == nil { arg_884 = ifn_887.Invoke_O_O__O(arg_888, arg_889) } else { arg_884 = linked_886.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_885, arg_888, arg_889) }; if linked_882 == nil { seq_1239000072__7 = ifn_883.Invoke_O__O(arg_884) } else { seq_1239000072__7 = linked_882.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_881, arg_884) }
//line :241:1
			var chunk_1239000073__8 any; var count_1239000074__9 int64 = 0; var i_1239000075__10 int64 = 0; L1: for {



















				if lang.Numbers_Lt_J_J__Z_NoInit(i_1239000075__10, count_1239000074__9) { var el__11 any = lang.Indexed_Cast(chunk_1239000073__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1239000075__10)); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()); var tmp15 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_23, nil); var tmp16 any; var root_917 any = A_arbace_repl_A_const_112.GetRawRoot__O(); var linked_918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_917, A_arbace_repl_stack_element_str_A_fn_class); var ifn_919 lang.IFn


					if linked_918 == nil { ifn_919 = lang.IFn_Cast(root_917) } else { ifn_919 = nil }; var arg_920 any = el__11; if linked_918 == nil { tmp16 = ifn_919.Invoke_O__O(arg_920) } else { tmp16 = linked_918.(*A_arbace_repl_stack_element_str_A).Invoke_O_O__O(root_917, arg_920) }; tmp14.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp15, jrt.RefArrayOf(jrt.Object_class, nil, tmp16)).Ref())
//line :261:1
					seq_1239000072__7, chunk_1239000073__8, count_1239000074__9, i_1239000075__10 = seq_1239000072__7, chunk_1239000073__8, count_1239000074__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1239000075__10); continue L1 } else { var temp__1927000414__auto____11 any; var root_897 any = A_arbace_repl_A_const_17.GetRawRoot__O(); var linked_898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_897, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_899 lang.IFn; if linked_898 == nil { ifn_899 = lang.IFn_Cast(root_897) } else { ifn_899 = nil }; var arg_900 any = seq_1239000072__7; if linked_898 == nil { temp__1927000414__auto____11 = ifn_899.Invoke_O__O(arg_900) } else { temp__1927000414__auto____11 = linked_898.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_897, arg_900) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1239000072__12 any = temp__1927000414__auto____11; var tmp17 any; var root_901 any = A_arbace_repl_A_const_31.GetRawRoot__O(); var linked_902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_901, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_903 lang.IFn; if linked_902 == nil { ifn_903 = lang.IFn_Cast(root_901) } else { ifn_903 = nil }; var arg_904 any = seq_1239000072__12; if linked_902 == nil { tmp17 = ifn_903.Invoke_O__O(arg_904) } else { tmp17 = linked_902.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_901, arg_904) }; if jrt.J2g_Truth(tmp17) { var c__1927000678__auto____13 any; var root_905 any = A_arbace_repl_A_const_32.GetRawRoot__O(); var linked_906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_905, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_907 lang.IFn; if linked_906 == nil { ifn_907 = lang.IFn_Cast(root_905) } else { ifn_907 = nil }; var arg_908 any = seq_1239000072__12; if linked_906 == nil { c__1927000678__auto____13 = ifn_907.Invoke_O__O(arg_908) } else { c__1927000678__auto____13 = linked_906.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_905, arg_908) }; var tmp18 any; var root_921 any = A_arbace_repl_A_const_37.GetRawRoot__O(); var linked_922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_921, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_923 lang.IFn; if linked_922 == nil { ifn_923 = lang.IFn_Cast(root_921) } else { ifn_923 = nil }; var arg_924 any = seq_1239000072__12; if linked_922 == nil { tmp18 = ifn_923.Invoke_O__O(arg_924) } else { tmp18 = linked_922.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_921, arg_924) }; seq_1239000072__7, chunk_1239000073__8, count_1239000074__9, i_1239000075__10 = tmp18, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var el__13 any; var root_909 any = A_arbace_repl_A_const_18.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_911 lang.IFn; if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any = seq_1239000072__12; if linked_910 == nil { el__13 = ifn_911.Invoke_O__O(arg_912) } else { el__13 = linked_910.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_909, arg_912)
					}

						var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()); var tmp20 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_23, nil); var tmp21 any; var root_929 any = A_arbace_repl_A_const_112.GetRawRoot__O(); var linked_930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_929, A_arbace_repl_stack_element_str_A_fn_class); var ifn_931 lang.IFn; if linked_930 == nil { ifn_931 = lang.IFn_Cast(root_929) } else { ifn_931 = nil }; var arg_932 any = el__13; if linked_930 == nil { tmp21 = ifn_931.Invoke_O__O(arg_932) } else { tmp21 = linked_930.(*A_arbace_repl_stack_element_str_A).Invoke_O_O__O(root_929, arg_932) }; tmp19.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, nil, tmp21)).Ref())
//line :261:1
						var tmp22 any; var root_933 any = A_arbace_repl_A_const_15.GetRawRoot__O(); var linked_934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_933, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_935 lang.IFn; if linked_934 == nil { ifn_935 = lang.IFn_Cast(root_933) } else { ifn_935 = nil }; var arg_936 any = seq_1239000072__12; if linked_934 == nil { tmp22 = ifn_935.Invoke_O__O(arg_936) } else { tmp22 = linked_934.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_933, arg_936) }; seq_1239000072__7, chunk_1239000073__8, count_1239000074__9, i_1239000075__10 = tmp22, nil, 0, 0; continue L1 } } }
//line :241:1
				break L1
			}






















			if jrt.J2g_Truth(cause__6) {
				lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(Lit_24)
				var root_840 any = A_arbace_repl_A_const_99.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_840, A_arbace_repl_pst_A_fn_class); var ifn_842 lang.IFn; if linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any = cause__6; var arg_844 any = lang.Numbers_Min_O_J__O_NoInit(depth__1, lang.Numbers_Add_J_J__J_NoInit(2, lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(jrt.Throwable_Cast(cause__6).GetStackTrace__StackTraceElement1().Ref())), int64(lang.RT_Count_O__I_NoInit(st__5))))); if linked_841 == nil { tmp3 = ifn_842.Invoke_O_O__O(arg_843, arg_844) } else { tmp3 = linked_841.(*A_arbace_repl_pst_A).Invoke_O_O_O__O(root_840, arg_843, arg_844) } } else {
//line :265:1
					tmp3 = nil } }
//line :241:1
		return nil }(); var root_845 any = A_arbace_repl_A_const_100.GetRawRoot__O(); var linked_846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_845, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_847 lang.IFn










	if linked_846 == nil { ifn_847 = lang.IFn_Cast(root_845) } else { ifn_847 = nil }; if linked_846 == nil { ifn_847.Invoke__O() } else { linked_846.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_845) }
//line :241:1
	if tmp23 != nil { panic(tmp23) }; return tmp3 }
//line :241:1
func (t *A_arbace_repl_pst_A) Invoke_O_O__O(self, e_or_depth__0 any) any {





	if jrt.Throwable_InstanceOf(e_or_depth__0) {
		var root_941 any = A_arbace_repl_A_const_99.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_941, A_arbace_repl_pst_A_fn_class); var ifn_943 lang.IFn; if linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any = e_or_depth__0; var arg_945 any = A_arbace_repl_A_const_113; if linked_942 == nil { return ifn_943.Invoke_O_O__O(arg_944, arg_945) } else { return linked_942.(*A_arbace_repl_pst_A).Invoke_O_O_O__O(root_941, arg_944, arg_945) } } else {
//line :247:1
			var temp__1927000414__auto____2 any = A_arbace_repl_A_const_114.Get__O()

			if jrt.J2g_Truth(temp__1927000414__auto____2) { var e__3 any = temp__1927000414__auto____2; var root_946 any = A_arbace_repl_A_const_99.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, A_arbace_repl_pst_A_fn_class); var ifn_948 lang.IFn
				if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any; var root_951 any = A_arbace_repl_A_const_115.GetRawRoot__O(); var linked_952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_951, A_arbace_repl_root_cause_A_fn_class); var ifn_953 lang.IFn; if linked_952 == nil { ifn_953 = lang.IFn_Cast(root_951) } else { ifn_953 = nil }; var arg_954 any = e__3; if linked_952 == nil { arg_949 = ifn_953.Invoke_O__O(arg_954) } else { arg_949 = linked_952.(*A_arbace_repl_root_cause_A).Invoke_O_O__O(root_951, arg_954) }; var arg_950 any = e_or_depth__0; if linked_947 == nil { return ifn_948.Invoke_O_O__O(arg_949, arg_950) } else { return linked_947.(*A_arbace_repl_pst_A).Invoke_O_O_O__O(root_946, arg_949, arg_950) } } else {
//line :249:1
					return nil } } }
//line :241:1
func (t *A_arbace_repl_pst_A) Invoke_O__O(self any) any {



	var root_955 any = A_arbace_repl_A_const_99.GetRawRoot__O(); var linked_956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_955, A_arbace_repl_pst_A_fn_class); var ifn_957 lang.IFn; if linked_956 == nil { ifn_957 = lang.IFn_Cast(root_955) } else { ifn_957 = nil }; var arg_958 any = A_arbace_repl_A_const_113; if linked_956 == nil { return ifn_957.Invoke_O__O(arg_958) } else { return linked_956.(*A_arbace_repl_pst_A).Invoke_O_O__O(root_955, arg_958)
	}
}














func A_arbace_repl_pst_fn__1239000076_A_New() *A_arbace_repl_pst_fn__1239000076_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_pst_fn__1239000076_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_repl_pst_fn__1239000076_A) Ctor() {}
//line :262:1
func (t *A_arbace_repl_pst_fn__1239000076_A) Invoke_O_O__O(self, p1__1239000071_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_111); return tmp1.Invoke_O__O(lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(p1__1239000071_SHARP___1, Lit_25, false)) }











func A_arbace_repl_thread_stopper_A_New() *A_arbace_repl_thread_stopper_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_thread_stopper_A{}; t.Ctor(); return t }
//line :274:1
func (t *A_arbace_repl_thread_stopper_A) Ctor() {}
//line :274:1
func (t *A_arbace_repl_thread_stopper_A) Invoke_O_O__O(self, thread__0 any) any {



	var fnbody__960 any = A_arbace_repl_thread_stopper_fn__1239000079_A_New_O(thread__0); var tmp1 *jrt.Class; var fncls__959 *jrt.Class = A_arbace_repl_thread_stopper_fn__1239000079_A_fn_class; if fncls__959 == nil { var fncls__959d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, fnbody__960); A_arbace_repl_thread_stopper_fn__1239000079_A_fn_class = fncls__959d; tmp1 = fncls__959d } else { tmp1 = fncls__959 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__960, tmp1, nil) }
//line :274:1
func (t *A_arbace_repl_thread_stopper_A) Invoke_O__O(self any) any {


	var root_961 any = A_arbace_repl_A_const_117.GetRawRoot__O(); var linked_962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_961, A_arbace_repl_thread_stopper_A_fn_class); var ifn_963 lang.IFn; if linked_962 == nil { ifn_963 = lang.IFn_Cast(root_961) } else { ifn_963 = nil }; var arg_964 any = jrt.Thread_CurrentThread__Thread(); if linked_962 == nil { return ifn_963.Invoke_O__O(arg_964) } else { return linked_962.(*A_arbace_repl_thread_stopper_A).Invoke_O_O__O(root_961, arg_964) } }
func A_arbace_repl_thread_stopper_fn__1239000079_A_New_O(p0 any) *A_arbace_repl_thread_stopper_fn__1239000079_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_thread_stopper_fn__1239000079_A{}; t.Ctor_O(p0); return t }
//line :278:1
func (t *A_arbace_repl_thread_stopper_fn__1239000079_A) Ctor_O(c__thread any) { t.F_thread = c__thread }
//line :278:1
func (t *A_arbace_repl_thread_stopper_fn__1239000079_A) Invoke_O_O__O(self, msg__1 any) any { var tmp1 any = t.F_thread; var tmp2 *jrt.Class = A_arbace_repl_A_const_116; return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(tmp1, Lit_48, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(tmp2, jrt.RefArrayOf(jrt.Object_class, msg__1)))) }

func A_arbace_repl_set_break_handler_BANG__A_New() *A_arbace_repl_set_break_handler_BANG__A { A_arbace_repl_A_Init(); t := &A_arbace_repl_set_break_handler_BANG__A{}; t.Ctor(); return t }
//line :280:1
func (t *A_arbace_repl_set_break_handler_BANG__A) Ctor() {}
//line :280:1
func (t *A_arbace_repl_set_break_handler_BANG__A) Invoke_O_O__O(self, f__0 any) any {





	var tmp1 *jrt.Class = lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_27); var tmp2 any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_27), jrt.RefArrayOf(jrt.Object_class, Lit_29)); var tmp3 any; var p__840000142__auto____2 any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_30), jrt.RefArrayOf(jrt.Object_class)); var root_965 any = A_arbace_repl_A_const_77.GetRawRoot__O(); var linked_966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_965, aot_arbace_core.A_arbace_core_init_proxy_A_fn_class); var ifn_967 lang.IFn

	if linked_966 == nil { ifn_967 = lang.IFn_Cast(root_965) } else { ifn_967 = nil }; var arg_968 any = p__840000142__auto____2; var arg_969 any; var tmp4 *lang.Compiler_AOTFn; var fnbody__971 any = A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_New_O(f__0); var tmp5 *jrt.Class; var fncls__970 *jrt.Class = A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_fn_class; if fncls__970 == nil { var fncls__970d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, fnbody__971); A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_fn_class = fncls__970d; tmp5 = fncls__970d } else { tmp5 = fncls__970 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__971, tmp5, nil); arg_969 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_28, tmp4.Ref())); if linked_966 == nil { ifn_967.Invoke_O_O__O(arg_968, arg_969) } else { linked_966.(*aot_arbace_core.A_arbace_core_init_proxy_A).Invoke_O_O_O__O(root_965, arg_968, arg_969) }
//line :286:1
	tmp3 = p__840000142__auto____2; return lang.Reflector_InvokeStaticMethod_Class_String_O1__O(tmp1, Lit_28, jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3)) }
//line :280:1
func (t *A_arbace_repl_set_break_handler_BANG__A) Invoke_O__O(self any) any {



	var root_972 any = A_arbace_repl_A_const_118.GetRawRoot__O(); var linked_973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_972, A_arbace_repl_set_break_handler_BANG__A_fn_class); var ifn_974 lang.IFn; if linked_973 == nil { ifn_974 = lang.IFn_Cast(root_972) } else { ifn_974 = nil }; var arg_975 any; var root_976 any = A_arbace_repl_A_const_117.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, A_arbace_repl_thread_stopper_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; if linked_977 == nil { arg_975 = ifn_978.Invoke__O() } else { arg_975 = linked_977.(*A_arbace_repl_thread_stopper_A).Invoke_O__O(root_976) }; if linked_973 == nil { return ifn_974.Invoke_O__O(arg_975) } else { return linked_973.(*A_arbace_repl_set_break_handler_BANG__A).Invoke_O_O__O(root_972, arg_975)
	}
}

func A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_New_O(p0 any) *A_arbace_repl_set_break_handler_BANG__fn__1239000082_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_set_break_handler_BANG__fn__1239000082_A{}; t.Ctor_O(p0); return t }
//line :288:1
func (t *A_arbace_repl_set_break_handler_BANG__fn__1239000082_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :288:1
func (t *A_arbace_repl_set_break_handler_BANG__fn__1239000082_A) Invoke_O_O_O__O(self, this__1, signal__2 any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(t.F_f); return tmp1.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_32, nil), jrt.RefArrayOf(jrt.Object_class, nil, signal__2)).Ref())
}












type A_arbace_repl_A struct{ jrt.Object }

var A_arbace_repl_A_const_pool *jrt.RefArray

var A_arbace_repl_A_const_0 *lang.Var

var A_arbace_repl_A_const_1 any

var A_arbace_repl_A_const_2 *lang.Var

var A_arbace_repl_A_const_3 any

var A_arbace_repl_A_const_4 *lang.Var

var A_arbace_repl_A_const_5 *lang.Var

var A_arbace_repl_A_const_6 *lang.Var

var A_arbace_repl_A_const_7 *lang.Var

var A_arbace_repl_A_const_8 any

var A_arbace_repl_A_const_9 *lang.Var

var A_arbace_repl_A_const_10 *lang.Var

var A_arbace_repl_A_const_11 *lang.Var

var A_arbace_repl_A_const_12 *lang.Keyword

var A_arbace_repl_A_const_13 *lang.Keyword

var A_arbace_repl_A_const_14 *lang.Var

var A_arbace_repl_A_const_15 *lang.Var

var A_arbace_repl_A_const_16 *lang.Var

var A_arbace_repl_A_const_17 *lang.Var

var A_arbace_repl_A_const_18 *lang.Var

var A_arbace_repl_A_const_19 *lang.Keyword

var A_arbace_repl_A_const_20 *lang.Keyword

var A_arbace_repl_A_const_21 *lang.Keyword

var A_arbace_repl_A_const_22 *lang.Keyword

var A_arbace_repl_A_const_23 *lang.Keyword

var A_arbace_repl_A_const_24 *lang.Keyword

var A_arbace_repl_A_const_25 *lang.Keyword

var A_arbace_repl_A_const_26 *lang.Var

var A_arbace_repl_A_const_27 *lang.Var

var A_arbace_repl_A_const_28 *lang.Var

var A_arbace_repl_A_const_29 *lang.Var

var A_arbace_repl_A_const_30 any

var A_arbace_repl_A_const_31 *lang.Var

var A_arbace_repl_A_const_32 *lang.Var

var A_arbace_repl_A_const_33 *lang.Var

var A_arbace_repl_A_const_34 *lang.Var

var A_arbace_repl_A_const_35 *lang.Var

var A_arbace_repl_A_const_36 *lang.Var

var A_arbace_repl_A_const_37 *lang.Var

var A_arbace_repl_A_const_38 *lang.Var

var A_arbace_repl_A_const_39 *lang.Var

var A_arbace_repl_A_const_40 *lang.Var

var A_arbace_repl_A_const_41 *lang.Var

var A_arbace_repl_A_const_42 *lang.Var

var A_arbace_repl_A_const_43 *lang.Var

var A_arbace_repl_A_const_44 *lang.Var

var A_arbace_repl_A_const_45 *lang.Var

var A_arbace_repl_A_const_46 *lang.Var

var A_arbace_repl_A_const_47 *lang.Var

var A_arbace_repl_A_const_48 *lang.Var

var A_arbace_repl_A_const_49 *lang.Var

var A_arbace_repl_A_const_50 *lang.Var

var A_arbace_repl_A_const_51 *lang.Var

var A_arbace_repl_A_const_52 *lang.Var

var A_arbace_repl_A_const_53 *lang.Var

var A_arbace_repl_A_const_54 any

var A_arbace_repl_A_const_55 *lang.Var

var A_arbace_repl_A_const_56 any

var A_arbace_repl_A_const_57 any

var A_arbace_repl_A_const_58 any

var A_arbace_repl_A_const_59 any

var A_arbace_repl_A_const_60 any

var A_arbace_repl_A_const_61 any

var A_arbace_repl_A_const_62 *lang.Var

var A_arbace_repl_A_const_63 any

var A_arbace_repl_A_const_64 *lang.Var

var A_arbace_repl_A_const_65 *lang.Var

var A_arbace_repl_A_const_66 *lang.Var

var A_arbace_repl_A_const_67 any

var A_arbace_repl_A_const_68 any

var A_arbace_repl_A_const_69 any

var A_arbace_repl_A_const_70 any

var A_arbace_repl_A_const_71 any

var A_arbace_repl_A_const_72 any

var A_arbace_repl_A_const_73 *lang.Keyword

var A_arbace_repl_A_const_74 *jrt.Class

var A_arbace_repl_A_const_75 any

var A_arbace_repl_A_const_76 *lang.Keyword

var A_arbace_repl_A_const_77 *lang.Var

var A_arbace_repl_A_const_78 *lang.Var

var A_arbace_repl_A_const_79 *lang.Keyword

var A_arbace_repl_A_const_80 *lang.Var

var A_arbace_repl_A_const_81 *lang.Var

var A_arbace_repl_A_const_82 any

var A_arbace_repl_A_const_83 any

var A_arbace_repl_A_const_84 any

var A_arbace_repl_A_const_85 any

var A_arbace_repl_A_const_86 *lang.Var

var A_arbace_repl_A_const_87 *lang.Var

var A_arbace_repl_A_const_88 *lang.Var

var A_arbace_repl_A_const_89 *lang.Var

var A_arbace_repl_A_const_90 *lang.Var

var A_arbace_repl_A_const_91 *lang.Var

var A_arbace_repl_A_const_92 any

var A_arbace_repl_A_const_93 *lang.Var

var A_arbace_repl_A_const_94 any

var A_arbace_repl_A_const_95 any

var A_arbace_repl_A_const_96 any

var A_arbace_repl_A_const_97 *lang.Var

var A_arbace_repl_A_const_98 *lang.Var

var A_arbace_repl_A_const_99 *lang.Var

var A_arbace_repl_A_const_100 *lang.Var

var A_arbace_repl_A_const_101 *lang.Var

var A_arbace_repl_A_const_102 *lang.Var

var A_arbace_repl_A_const_103 *lang.Var

var A_arbace_repl_A_const_104 any

var A_arbace_repl_A_const_105 *lang.Var

var A_arbace_repl_A_const_106 *lang.Var

var A_arbace_repl_A_const_107 *lang.Var

var A_arbace_repl_A_const_108 *lang.Keyword

var A_arbace_repl_A_const_109 *lang.Var

var A_arbace_repl_A_const_110 *lang.Var

var A_arbace_repl_A_const_111 any

var A_arbace_repl_A_const_112 *lang.Var

var A_arbace_repl_A_const_113 any

var A_arbace_repl_A_const_114 *lang.Var

var A_arbace_repl_A_const_115 *lang.Var

var A_arbace_repl_A_const_116 *jrt.Class

var A_arbace_repl_A_const_117 *lang.Var

var A_arbace_repl_A_const_118 *lang.Var

var A_arbace_repl_A_init jrt.ClassInit

func A_arbace_repl_A_Init() { if !A_arbace_repl_A_init.Done() { A_arbace_repl_A_init.Run(A_arbace_repl_A_clinit) } }

func A_arbace_repl_A_clinit() { A_arbace_repl_A_clinit_p0(); A_arbace_repl_A_clinit_p1(); A_arbace_repl_A_clinit_p2(); A_arbace_repl_A_clinit_p3(); A_arbace_repl_A_clinit_p4(); A_arbace_repl_A_clinit_p5(); A_arbace_repl_A_clinit_p6(); A_arbace_repl_A_clinit_p7(); A_arbace_repl_A_clinit_p8(); A_arbace_repl_A_clinit_p9() }

func A_arbace_repl_A_clinit_p0() { jrt.StartCheck(); A_arbace_repl_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 166); A_arbace_repl_A_const_0 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[47]); A_arbace_repl_A_const_1 = A_arbace_repl_A_const_pool.A[48]; A_arbace_repl_A_const_2 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[49]); A_arbace_repl_A_const_3 = A_arbace_repl_A_const_pool.A[50]; A_arbace_repl_A_const_4 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[51]); A_arbace_repl_A_const_5 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[52]); A_arbace_repl_A_const_6 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[53]); A_arbace_repl_A_const_7 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[54]); A_arbace_repl_A_const_8 = A_arbace_repl_A_const_pool.A[55]; A_arbace_repl_A_const_9 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[56]); A_arbace_repl_A_const_10 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[57]); A_arbace_repl_A_const_11 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[58]) }

func A_arbace_repl_A_clinit_p1() { A_arbace_repl_A_const_12 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[59]); A_arbace_repl_A_const_13 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[60]); A_arbace_repl_A_const_14 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[61]); A_arbace_repl_A_const_15 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[62]); A_arbace_repl_A_const_16 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[63]); A_arbace_repl_A_const_17 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[64]); A_arbace_repl_A_const_18 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[65]); A_arbace_repl_A_const_19 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[66]); A_arbace_repl_A_const_20 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[67]); A_arbace_repl_A_const_21 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[68]); A_arbace_repl_A_const_22 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[69]); A_arbace_repl_A_const_23 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[70]) }

func A_arbace_repl_A_clinit_p2() { A_arbace_repl_A_const_24 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[71]); A_arbace_repl_A_const_25 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[72]); A_arbace_repl_A_const_26 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[73]); A_arbace_repl_A_const_27 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[74]); A_arbace_repl_A_const_28 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[75]); A_arbace_repl_A_const_29 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[76]); A_arbace_repl_A_const_30 = A_arbace_repl_A_const_pool.A[77]; A_arbace_repl_A_const_31 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[78]); A_arbace_repl_A_const_32 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[79]); A_arbace_repl_A_const_33 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[80]); A_arbace_repl_A_const_34 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[81]); A_arbace_repl_A_const_35 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[82]) }

func A_arbace_repl_A_clinit_p3() { A_arbace_repl_A_const_36 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[83]); A_arbace_repl_A_const_37 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[84]); A_arbace_repl_A_const_38 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[85]); A_arbace_repl_A_const_39 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[86]); A_arbace_repl_A_const_40 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[87]); A_arbace_repl_A_const_41 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[88]); A_arbace_repl_A_const_42 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[89]); A_arbace_repl_A_const_43 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[90]); A_arbace_repl_A_const_44 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[91]); A_arbace_repl_A_const_45 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[92]); A_arbace_repl_A_const_46 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[93]); A_arbace_repl_A_const_47 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[94]) }

func A_arbace_repl_A_clinit_p4() { A_arbace_repl_A_const_48 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[95]); A_arbace_repl_A_const_49 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[96]); A_arbace_repl_A_const_50 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[97]); A_arbace_repl_A_const_51 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[98]); A_arbace_repl_A_const_52 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[99]); A_arbace_repl_A_const_53 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[100]); A_arbace_repl_A_const_54 = A_arbace_repl_A_const_pool.A[101]; A_arbace_repl_A_const_55 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[102]); A_arbace_repl_A_const_56 = A_arbace_repl_A_const_pool.A[103]; A_arbace_repl_A_const_57 = A_arbace_repl_A_const_pool.A[104]; A_arbace_repl_A_const_58 = A_arbace_repl_A_const_pool.A[105]; A_arbace_repl_A_const_59 = A_arbace_repl_A_const_pool.A[106]; A_arbace_repl_A_const_60 = A_arbace_repl_A_const_pool.A[107] }

func A_arbace_repl_A_clinit_p5() { A_arbace_repl_A_const_61 = A_arbace_repl_A_const_pool.A[108]; A_arbace_repl_A_const_62 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[109]); A_arbace_repl_A_const_63 = A_arbace_repl_A_const_pool.A[110]; A_arbace_repl_A_const_64 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[111]); A_arbace_repl_A_const_65 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[112]); A_arbace_repl_A_const_66 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[113]); A_arbace_repl_A_const_67 = A_arbace_repl_A_const_pool.A[114]; A_arbace_repl_A_const_68 = A_arbace_repl_A_const_pool.A[115]; A_arbace_repl_A_const_69 = A_arbace_repl_A_const_pool.A[116]; A_arbace_repl_A_const_70 = A_arbace_repl_A_const_pool.A[117]; A_arbace_repl_A_const_71 = A_arbace_repl_A_const_pool.A[118]; A_arbace_repl_A_const_72 = A_arbace_repl_A_const_pool.A[119]; A_arbace_repl_A_const_73 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[120]); A_arbace_repl_A_const_74 = jrt.Class_Cast(A_arbace_repl_A_const_pool.A[121]) }

func A_arbace_repl_A_clinit_p6() { A_arbace_repl_A_const_75 = A_arbace_repl_A_const_pool.A[122]; A_arbace_repl_A_const_76 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[123]); A_arbace_repl_A_const_77 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[124]); A_arbace_repl_A_const_78 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[125]); A_arbace_repl_A_const_79 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[126]); A_arbace_repl_A_const_80 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[127]); A_arbace_repl_A_const_81 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[128]); A_arbace_repl_A_const_82 = A_arbace_repl_A_const_pool.A[129]; A_arbace_repl_A_const_83 = A_arbace_repl_A_const_pool.A[130]; A_arbace_repl_A_const_84 = A_arbace_repl_A_const_pool.A[131]; A_arbace_repl_A_const_85 = A_arbace_repl_A_const_pool.A[132]; A_arbace_repl_A_const_86 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[133]); A_arbace_repl_A_const_87 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[134]) }

func A_arbace_repl_A_clinit_p7() { A_arbace_repl_A_const_88 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[135]); A_arbace_repl_A_const_89 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[136]); A_arbace_repl_A_const_90 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[137]); A_arbace_repl_A_const_91 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[138]); A_arbace_repl_A_const_92 = A_arbace_repl_A_const_pool.A[139]; A_arbace_repl_A_const_93 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[140]); A_arbace_repl_A_const_94 = A_arbace_repl_A_const_pool.A[141]; A_arbace_repl_A_const_95 = A_arbace_repl_A_const_pool.A[142]; A_arbace_repl_A_const_96 = A_arbace_repl_A_const_pool.A[143]; A_arbace_repl_A_const_97 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[144]); A_arbace_repl_A_const_98 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[145]); A_arbace_repl_A_const_99 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[146]); A_arbace_repl_A_const_100 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[147]) }

func A_arbace_repl_A_clinit_p8() { A_arbace_repl_A_const_101 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[148]); A_arbace_repl_A_const_102 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[149]); A_arbace_repl_A_const_103 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[150]); A_arbace_repl_A_const_104 = A_arbace_repl_A_const_pool.A[151]; A_arbace_repl_A_const_105 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[152]); A_arbace_repl_A_const_106 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[153]); A_arbace_repl_A_const_107 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[154]); A_arbace_repl_A_const_108 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[155]); A_arbace_repl_A_const_109 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[156]); A_arbace_repl_A_const_110 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[157]); A_arbace_repl_A_const_111 = A_arbace_repl_A_const_pool.A[158]; A_arbace_repl_A_const_112 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[159]) }

func A_arbace_repl_A_clinit_p9() { A_arbace_repl_A_const_113 = A_arbace_repl_A_const_pool.A[160]; A_arbace_repl_A_const_114 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[161]); A_arbace_repl_A_const_115 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[162]); A_arbace_repl_A_const_116 = jrt.Class_Cast(A_arbace_repl_A_const_pool.A[163]); A_arbace_repl_A_const_117 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[164]); A_arbace_repl_A_const_118 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[165]) }

func A_arbace_repl_A_New() *A_arbace_repl_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_A{}; t.Ctor(); return t }

func (t *A_arbace_repl_A) Ctor() {}

func (t *A_arbace_repl_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_A) GetClass__Class() *jrt.Class { return A_arbace_repl_A_class }

func (t *A_arbace_repl_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repl_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_A); return ok }

func A_arbace_repl_A_Cast(x any) *A_arbace_repl_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_A_class)) }; return v }



type A_arbace_repl_apropos_A struct{ j2g_header uint64 }

var A_arbace_repl_apropos_A_fn_class *jrt.Class



type A_arbace_repl_apropos_fn__1239000052_A struct{ j2g_header uint64; F_str_or_pattern any }

var A_arbace_repl_apropos_fn__1239000052_A_fn_class *jrt.Class



type A_arbace_repl_apropos_fn__1239000054_A struct{ j2g_header uint64; F_str_or_pattern any }

var A_arbace_repl_apropos_fn__1239000054_A_fn_class *jrt.Class



type A_arbace_repl_apropos_fn__1239000056_A struct{ j2g_header uint64; F_matches_QMARK_ any }

var A_arbace_repl_apropos_fn__1239000056_A_fn_class *jrt.Class



type A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A struct{ j2g_header uint64; F_ns_name any }

var A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_fn_class *jrt.Class



type A_arbace_repl_demunge_A struct{ j2g_header uint64 }

var A_arbace_repl_demunge_A_fn_class *jrt.Class



type A_arbace_repl_dir_A struct{ j2g_header uint64 }

var A_arbace_repl_dir_A_fn_class *jrt.Class



type A_arbace_repl_dir_fn_A struct{ j2g_header uint64 }

var A_arbace_repl_dir_fn_A_fn_class *jrt.Class



type A_arbace_repl_doc_A struct{ j2g_header uint64 }

var A_arbace_repl_doc_A_fn_class *jrt.Class



type A_arbace_repl_eval1239000004_A struct{ jrt.Object }

func A_arbace_repl_eval1239000004_A_New() *A_arbace_repl_eval1239000004_A { t := &A_arbace_repl_eval1239000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repl_eval1239000004_A) Ctor() {}

func (t *A_arbace_repl_eval1239000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_eval1239000004_A) GetClass__Class() *jrt.Class { return A_arbace_repl_eval1239000004_A_class }

func (t *A_arbace_repl_eval1239000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_eval1239000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repl_eval1239000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_eval1239000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_eval1239000004_A); return ok }

func A_arbace_repl_eval1239000004_A_Cast(x any) *A_arbace_repl_eval1239000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_eval1239000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_eval1239000004_A_class)) }; return v }



type A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A struct{ j2g_header uint64 }

var A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_fn_class *jrt.Class



type A_arbace_repl_eval1239000008_A struct{ jrt.Object }

func A_arbace_repl_eval1239000008_A_New() *A_arbace_repl_eval1239000008_A { t := &A_arbace_repl_eval1239000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repl_eval1239000008_A) Ctor() {}

func (t *A_arbace_repl_eval1239000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_eval1239000008_A) GetClass__Class() *jrt.Class { return A_arbace_repl_eval1239000008_A_class }

func (t *A_arbace_repl_eval1239000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_eval1239000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repl_eval1239000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_eval1239000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_eval1239000008_A); return ok }

func A_arbace_repl_eval1239000008_A_Cast(x any) *A_arbace_repl_eval1239000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_eval1239000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_eval1239000008_A_class)) }; return v }



type A_arbace_repl_eval1239000008_fn__1239000009_A struct{ j2g_header uint64 }

var A_arbace_repl_eval1239000008_fn__1239000009_A_fn_class *jrt.Class



type A_arbace_repl_find_doc_A struct{ j2g_header uint64 }

var A_arbace_repl_find_doc_A_fn_class *jrt.Class



type A_arbace_repl_find_doc_fn__1239000027_A struct{ j2g_header uint64 }

var A_arbace_repl_find_doc_fn__1239000027_A_fn_class *jrt.Class



type A_arbace_repl_namespace_doc_A struct{ j2g_header uint64 }

var A_arbace_repl_namespace_doc_A_fn_class *jrt.Class



type A_arbace_repl_print_doc_A struct{ j2g_header uint64 }

var A_arbace_repl_print_doc_A_fn_class *jrt.Class



type A_arbace_repl_pst_A struct{ j2g_header uint64 }

var A_arbace_repl_pst_A_fn_class *jrt.Class



type A_arbace_repl_pst_fn__1239000076_A struct{ j2g_header uint64 }

var A_arbace_repl_pst_fn__1239000076_A_fn_class *jrt.Class



type A_arbace_repl_root_cause_A struct{ j2g_header uint64 }

var A_arbace_repl_root_cause_A_fn_class *jrt.Class



type A_arbace_repl_set_break_handler_BANG__A struct{ j2g_header uint64 }

var A_arbace_repl_set_break_handler_BANG__A_fn_class *jrt.Class



type A_arbace_repl_set_break_handler_BANG__fn__1239000082_A struct{ j2g_header uint64; F_f any }

var A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_fn_class *jrt.Class



type A_arbace_repl_source_A struct{ j2g_header uint64 }

var A_arbace_repl_source_A_fn_class *jrt.Class



type A_arbace_repl_source_fn_A struct{ j2g_header uint64 }

var A_arbace_repl_source_fn_A_fn_class *jrt.Class



type A_arbace_repl_source_fn_fn__1239000039_A struct{ j2g_header uint64; F_text any }

var A_arbace_repl_source_fn_fn__1239000039_A_fn_class *jrt.Class



type A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A struct{ j2g_header uint64; F_this any }

var A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_fn_class *jrt.Class



type A_arbace_repl_special_doc_A struct{ j2g_header uint64 }

var A_arbace_repl_special_doc_A_fn_class *jrt.Class



type A_arbace_repl_stack_element_str_A struct{ j2g_header uint64 }

var A_arbace_repl_stack_element_str_A_fn_class *jrt.Class



type A_arbace_repl_thread_stopper_A struct{ j2g_header uint64 }

var A_arbace_repl_thread_stopper_A_fn_class *jrt.Class



type A_arbace_repl_thread_stopper_fn__1239000079_A struct{ j2g_header uint64; F_thread any }

var A_arbace_repl_thread_stopper_fn__1239000079_A_fn_class *jrt.Class
