//line aot_arbace_repl.ae:1
package aot_arbace_repl

import (
	"arbace/jrt"
	"arbace/lang"
)




func A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_New() *A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A{}; t.Ctor(); return t }
//line :11:1
func (t *A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A) Ctor() {}
//line :11:1
func (t *A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repl_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_2); lang.IFn_Cast(A_arbace_repl_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_3); { var tmp4 *lang.Var; lang.RT_Init(); tmp4 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp4).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_5)); var tmp5 *lang.Var; lang.RT_Init(); tmp5 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp5).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_6)); var tmp6 *lang.Var; lang.RT_Init(); tmp6 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp6).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_7)); var tmp7 *lang.Var; lang.RT_Init(); tmp7 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp7).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_8)); var tmp8 *lang.Var; lang.RT_Init(); tmp8 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp8).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_9)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp9 != nil { panic(tmp9) }; return tmp3 }
//line :11:1
func A_arbace_repl_eval1239000008_fn__1239000009_A_New() *A_arbace_repl_eval1239000008_fn__1239000009_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_eval1239000008_fn__1239000009_A{}; t.Ctor(); return t }
//line :11:1
func (t *A_arbace_repl_eval1239000008_fn__1239000009_A) Ctor() {}
//line :11:1
func (t *A_arbace_repl_eval1239000008_fn__1239000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repl_A_const_4.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_8), A_arbace_repl_A_const_6.GetRawRoot__O(), A_arbace_repl_A_const_7) }































































func A_arbace_repl_special_doc_A_New() *A_arbace_repl_special_doc_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_special_doc_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_repl_special_doc_A) Ctor() {}
//line :75:1
func (t *A_arbace_repl_special_doc_A) Invoke_O_O__O(self, name_symbol__0 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_9.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_repl_A_const_10.GetRawRoot__O()).Invoke_O__O(name_symbol__0); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp2 = or__1927000174__auto____2 } else { tmp2 = lang.RT_Meta_O__IPersistentMap(lang.IFn_Cast(A_arbace_repl_A_const_11.GetRawRoot__O()).Invoke_O__O(name_symbol__0)) }; var tmp3 any = tmp2; var tmp4 any = A_arbace_repl_A_const_12; var tmp5 any = A_arbace_repl_A_const_13; var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; return tmp1.Invoke_O_O_O_O_O__O(tmp3, tmp4, name_symbol__0, tmp5, tmp6.Ref())
}


func A_arbace_repl_namespace_doc_A_New() *A_arbace_repl_namespace_doc_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_namespace_doc_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_repl_namespace_doc_A) Ctor() {}
//line :80:1
func (t *A_arbace_repl_namespace_doc_A) Invoke_O_O__O(self, nspace__0 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_9.GetRawRoot__O()); var tmp2 any = lang.RT_Meta_O__IPersistentMap(nspace__0); var tmp3 any = A_arbace_repl_A_const_12; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.IFn_Cast(A_arbace_repl_A_const_14.GetRawRoot__O()).Invoke_O__O(nspace__0))
}
func A_arbace_repl_print_doc_A_New() *A_arbace_repl_print_doc_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_print_doc_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_repl_print_doc_A) Ctor() {}
//line :83:1
func (t *A_arbace_repl_print_doc_A) Invoke_O_O__O(self, p__1239000014__0 any) any { { var map__1239000015__2 any = p__1239000014__0; var map__1239000015__3 any; if lang.ISeq_InstanceOf(map__1239000015__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repl_A_const_15.GetRawRoot__O()).Invoke_O__O(map__1239000015__2)) { map__1239000015__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repl_A_const_16.GetRawRoot__O()).Invoke_O__O(map__1239000015__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(map__1239000015__2)) { map__1239000015__3 = lang.IFn_Cast(A_arbace_repl_A_const_18.GetRawRoot__O()).Invoke_O__O(map__1239000015__2) } else { lang.PersistentArrayMap_Init(); map__1239000015__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1239000015__3 = map__1239000015__2 }; var m__4 any = map__1239000015__3; var n__5 any = lang.RT_Get_O_O__O(map__1239000015__3, A_arbace_repl_A_const_19); var nm__6 any = lang.RT_Get_O_O__O(map__1239000015__3, A_arbace_repl_A_const_12); var forms__7 any = lang.RT_Get_O_O__O(map__1239000015__3, A_arbace_repl_A_const_20); var arglists__8 any = lang.RT_Get_O_O__O(map__1239000015__3, A_arbace_repl_A_const_21); var special_form__9 any = lang.RT_Get_O_O__O(map__1239000015__3, A_arbace_repl_A_const_13); var doc__10 any = lang.RT_Get_O_O__O(map__1239000015__3, A_arbace_repl_A_const_22); var url__11 any = lang.RT_Get_O_O__O(map__1239000015__3, A_arbace_repl_A_const_23); var macro__12 any = lang.RT_Get_O_O__O(map__1239000015__3, A_arbace_repl_A_const_24); var spec__13 any = lang.RT_Get_O_O__O(map__1239000015__3, A_arbace_repl_A_const_25)



	lang.IFn_Cast(A_arbace_repl_A_const_29.GetRawRoot__O()).Invoke_O__O(Lit_11)
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_29.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____14 any = spec__13; if jrt.J2g_Truth(or__1927000174__auto____14) { tmp2 = or__1927000174__auto____14 } else { var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp4 *jrt.String; if jrt.J2g_Truth(n__5) { tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_12), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_repl_A_const_14.GetRawRoot__O()).Invoke_O__O(n__5), nil)) } else { tmp4 = nil }; tmp2 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp4.Ref(), nm__6)).Ref() }; tmp1.Invoke_O__O(tmp2)
	if jrt.J2g_Truth(forms__7) { var seq_1239000017__14 any = lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(forms__7); var chunk_1239000018__15 any; var count_1239000019__16 int64 = 0; var i_1239000020__17 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z(i_1239000020__17, count_1239000019__16) { var f__18 any = lang.Indexed_Cast(chunk_1239000018__15).Nth_I__O(lang.RT_IntCast_J__I(i_1239000020__17))
			lang.IFn_Cast(A_arbace_repl_A_const_32.GetRawRoot__O()).Invoke_O__O(Lit_13)
			lang.IFn_Cast(A_arbace_repl_A_const_30.GetRawRoot__O()).Invoke_O__O(f__18)
//line :90:1
			seq_1239000017__14, chunk_1239000018__15, count_1239000019__16, i_1239000020__17 = seq_1239000017__14, chunk_1239000018__15, count_1239000019__16, lang.Numbers_Unchecked_inc_J__J(i_1239000020__17); continue L1 } else { var temp__1927000414__auto____18 any = lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(seq_1239000017__14); if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_1239000017__19 any = temp__1927000414__auto____18; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repl_A_const_27.GetRawRoot__O()).Invoke_O__O(seq_1239000017__19)) { var c__1927000678__auto____20 any = lang.IFn_Cast(A_arbace_repl_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1239000017__19); seq_1239000017__14, chunk_1239000018__15, count_1239000019__16, i_1239000020__17 = lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1239000017__19), c__1927000678__auto____20, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var f__20 any = lang.IFn_Cast(A_arbace_repl_A_const_18.GetRawRoot__O()).Invoke_O__O(seq_1239000017__19)
				lang.IFn_Cast(A_arbace_repl_A_const_32.GetRawRoot__O()).Invoke_O__O(Lit_13)
				lang.IFn_Cast(A_arbace_repl_A_const_30.GetRawRoot__O()).Invoke_O__O(f__20)
//line :90:1
				seq_1239000017__14, chunk_1239000018__15, count_1239000019__16, i_1239000020__17 = lang.IFn_Cast(A_arbace_repl_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1239000017__19), nil, 0, 0; continue L1 } } }
//line :89:1
		break L1
	}
	}

	if jrt.J2g_Truth(arglists__8) {
		lang.IFn_Cast(A_arbace_repl_A_const_30.GetRawRoot__O()).Invoke_O__O(arglists__8) }
	if jrt.J2g_Truth(special_form__9) {

		lang.IFn_Cast(A_arbace_repl_A_const_29.GetRawRoot__O()).Invoke_O__O(Lit_14) } else {
//line :95:1
			if jrt.J2g_Truth(macro__12) {



				lang.IFn_Cast(A_arbace_repl_A_const_29.GetRawRoot__O()).Invoke_O__O(Lit_15) } else {
//line :95:1
					if jrt.J2g_Truth(spec__13) {





						lang.IFn_Cast(A_arbace_repl_A_const_29.GetRawRoot__O()).Invoke_O__O(Lit_16) } } }
	if jrt.J2g_Truth(doc__10) { lang.IFn_Cast(A_arbace_repl_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_17, doc__10) }
	if jrt.J2g_Truth(special_form__9) {
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repl_A_const_31.GetRawRoot__O()).Invoke_O_O__O(m__4, A_arbace_repl_A_const_23)) {
			if jrt.J2g_Truth(url__11) {
				lang.IFn_Cast(A_arbace_repl_A_const_29.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_18, nil), jrt.RefArrayOf(jrt.Object_class, nil, url__11)).Ref()) } } else {
					lang.IFn_Cast(A_arbace_repl_A_const_29.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, nm__6)).Ref()) } }
	if jrt.J2g_Truth(n__5) { var temp__1927000414__auto____14 any = lang.IFn_Cast(A_arbace_repl_A_const_26.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_34.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_35.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_14.GetRawRoot__O()).Invoke_O__O(n__5)), lang.IFn_Cast(A_arbace_repl_A_const_36.GetRawRoot__O()).Invoke_O__O(nm__6)))
		if jrt.J2g_Truth(temp__1927000414__auto____14) { var fnspec__15 any = temp__1927000414__auto____14
			lang.IFn_Cast(A_arbace_repl_A_const_29.GetRawRoot__O()).Invoke_O__O(Lit_16)
//line :109:1
			var seq_1239000021__16 any = lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_37); var chunk_1239000022__17 any; var count_1239000023__18 int64 = 0; var i_1239000024__19 int64 = 0; L2: for {

				if lang.Numbers_Lt_J_J__Z(i_1239000024__19, count_1239000023__18) { var role__20 any = lang.Indexed_Cast(chunk_1239000022__17).Nth_I__O(lang.RT_IntCast_J__I(i_1239000024__19)); var temp__1927000414__auto____21 any = lang.RT_Get_O_O__O(fnspec__15, role__20)
					if jrt.J2g_Truth(temp__1927000414__auto____21) { var spec__22 any = temp__1927000414__auto____21
						lang.IFn_Cast(A_arbace_repl_A_const_29.GetRawRoot__O()).Invoke_O_O_O__O(Lit_17, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_20), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_repl_A_const_36.GetRawRoot__O()).Invoke_O__O(role__20), nil)).Ref(), lang.IFn_Cast(A_arbace_repl_A_const_38.GetRawRoot__O()).Invoke_O__O(spec__22)) }
//line :111:1
					seq_1239000021__16, chunk_1239000022__17, count_1239000023__18, i_1239000024__19 = seq_1239000021__16, chunk_1239000022__17, count_1239000023__18, lang.Numbers_Unchecked_inc_J__J(i_1239000024__19); continue L2 } else { var temp__1927000414__auto____20 any = lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(seq_1239000021__16); if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1239000021__21 any = temp__1927000414__auto____20; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repl_A_const_27.GetRawRoot__O()).Invoke_O__O(seq_1239000021__21)) { var c__1927000678__auto____22 any = lang.IFn_Cast(A_arbace_repl_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1239000021__21); seq_1239000021__16, chunk_1239000022__17, count_1239000023__18, i_1239000024__19 = lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1239000021__21), c__1927000678__auto____22, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var role__22 any = lang.IFn_Cast(A_arbace_repl_A_const_18.GetRawRoot__O()).Invoke_O__O(seq_1239000021__21); var temp__1927000414__auto____23 any = lang.RT_Get_O_O__O(fnspec__15, role__22)
						if jrt.J2g_Truth(temp__1927000414__auto____23) { var spec__24 any = temp__1927000414__auto____23
							lang.IFn_Cast(A_arbace_repl_A_const_29.GetRawRoot__O()).Invoke_O_O_O__O(Lit_17, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_20), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_repl_A_const_36.GetRawRoot__O()).Invoke_O__O(role__22), nil)).Ref(), lang.IFn_Cast(A_arbace_repl_A_const_38.GetRawRoot__O()).Invoke_O__O(spec__24)) }
//line :111:1
						seq_1239000021__16, chunk_1239000022__17, count_1239000023__18, i_1239000024__19 = lang.IFn_Cast(A_arbace_repl_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1239000021__21), nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :109:1
							return nil } } else {
//line :108:1
								return nil } }; /*line :83:1*/panic("j2g: unreachable") }































func A_arbace_repl_find_doc_A_New() *A_arbace_repl_find_doc_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_find_doc_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_repl_find_doc_A) Ctor() {}
//line :115:1
func (t *A_arbace_repl_find_doc_A) Invoke_O_O__O(self, re_string_or_pattern__0 any) any { { var re__2 any = lang.IFn_Cast(A_arbace_repl_A_const_39.GetRawRoot__O()).Invoke_O__O(re_string_or_pattern__0); var ms__3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_42.GetRawRoot__O()); var tmp3 any = A_arbace_repl_find_doc_fn__1239000027_A_New(); var tmp4 *jrt.Class
											var fncls__1 /*line :115:1*/*jrt.Class = A_arbace_repl_find_doc_fn__1239000027_A_fn_class





	if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_10, false); A_arbace_repl_find_doc_fn__1239000027_A_fn_class = fncls__1d; tmp4 = fncls__1d } else { tmp4 = fncls__1 }; ms__3 = tmp1.Invoke_O_O_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), lang.IFn_Cast(A_arbace_repl_A_const_48.GetRawRoot__O()).Invoke__O()), lang.IFn_Cast(A_arbace_repl_A_const_43.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repl_A_const_49.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repl_A_const_48.GetRawRoot__O()).Invoke__O()), lang.IFn_Cast(A_arbace_repl_A_const_43.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repl_A_const_50.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repl_A_const_51.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_10.GetRawRoot__O())))
//line :115:1
	var seq_1239000029__4 any = lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(ms__3); var chunk_1239000030__5 any; var count_1239000031__6 int64 = 0; var i_1239000032__7 int64 = 0; L1: for {









		if lang.Numbers_Lt_J_J__Z(i_1239000032__7, count_1239000031__6) { var m__8 any = lang.Indexed_Cast(chunk_1239000030__5).Nth_I__O(lang.RT_IntCast_J__I(i_1239000032__7)); var tmp5 any; var and__1927000168__auto____9 any = A_arbace_repl_A_const_22.Invoke_O__O(m__8)
			if jrt.J2g_Truth(and__1927000168__auto____9) { var or__1927000174__auto____10 any = lang.IFn_Cast(A_arbace_repl_A_const_41.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_52.GetRawRoot__O()).Invoke_O_O__O(re__2, A_arbace_repl_A_const_22.Invoke_O__O(m__8)))
				if jrt.J2g_Truth(or__1927000174__auto____10) { tmp5 = or__1927000174__auto____10 } else {
					tmp5 = lang.IFn_Cast(A_arbace_repl_A_const_41.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_52.GetRawRoot__O()).Invoke_O_O__O(re__2, lang.IFn_Cast(A_arbace_repl_A_const_35.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_12.Invoke_O__O(m__8)))) } } else {
//line :126:1
						tmp5 = and__1927000168__auto____9 }
//line :125:1
			if jrt.J2g_Truth(tmp5) {



				lang.IFn_Cast(A_arbace_repl_A_const_53.GetRawRoot__O()).Invoke_O__O(m__8)
//line :125:1
				seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, i_1239000032__7 = seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, lang.Numbers_Unchecked_inc_J__J(i_1239000032__7); continue L1 } else { seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, i_1239000032__7 = seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, lang.Numbers_Unchecked_inc_J__J(i_1239000032__7); continue L1 } } else { var temp__1927000414__auto____8 any = lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(seq_1239000029__4); if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1239000029__9 any = temp__1927000414__auto____8; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repl_A_const_27.GetRawRoot__O()).Invoke_O__O(seq_1239000029__9)) { var c__1927000678__auto____10 any = lang.IFn_Cast(A_arbace_repl_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1239000029__9); seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, i_1239000032__7 = lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1239000029__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var m__10 any = lang.IFn_Cast(A_arbace_repl_A_const_18.GetRawRoot__O()).Invoke_O__O(seq_1239000029__9); var tmp6 any; var and__1927000168__auto____11 any = A_arbace_repl_A_const_22.Invoke_O__O(m__10)
					if jrt.J2g_Truth(and__1927000168__auto____11) { var or__1927000174__auto____12 any = lang.IFn_Cast(A_arbace_repl_A_const_41.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_52.GetRawRoot__O()).Invoke_O_O__O(re__2, A_arbace_repl_A_const_22.Invoke_O__O(m__10)))
						if jrt.J2g_Truth(or__1927000174__auto____12) { tmp6 = or__1927000174__auto____12 } else {
							tmp6 = lang.IFn_Cast(A_arbace_repl_A_const_41.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_52.GetRawRoot__O()).Invoke_O_O__O(re__2, lang.IFn_Cast(A_arbace_repl_A_const_35.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_12.Invoke_O__O(m__10)))) } } else {
//line :126:1
								tmp6 = and__1927000168__auto____11 }
//line :125:1
					if jrt.J2g_Truth(tmp6) {



						lang.IFn_Cast(A_arbace_repl_A_const_53.GetRawRoot__O()).Invoke_O__O(m__10)
//line :125:1
						seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, i_1239000032__7 = lang.IFn_Cast(A_arbace_repl_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1239000029__9), nil, 0, 0; continue L1 } else { seq_1239000029__4, chunk_1239000030__5, count_1239000031__6, i_1239000032__7 = lang.IFn_Cast(A_arbace_repl_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1239000029__9), nil, 0, 0; continue L1 } } } else { return nil } } } }; /*line :115:1*/panic("j2g: unreachable") }





func A_arbace_repl_find_doc_fn__1239000027_A_New() *A_arbace_repl_find_doc_fn__1239000027_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_find_doc_fn__1239000027_A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_repl_find_doc_fn__1239000027_A) Ctor() {}
//line :121:1
func (t *A_arbace_repl_find_doc_fn__1239000027_A) Invoke_O_O__O(self, p1__1239000026_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_44.GetRawRoot__O()); var tmp2 any = A_arbace_repl_A_const_12; return tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_repl_A_const_43.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repl_A_const_45.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repl_A_const_46.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_47.GetRawRoot__O()).Invoke_O__O(p1__1239000026_SHARP___1)))) }









func A_arbace_repl_doc_A_New() *A_arbace_repl_doc_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_doc_A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_repl_doc_A) Ctor() {}
//line :131:1
func (t *A_arbace_repl_doc_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, name__2 any) any { var temp__1927000408__auto____4 any = lang.IFn_Cast(A_arbace_repl_A_const_54).Invoke_O__O(name__2); if




	jrt.J2g_Truth(temp__1927000408__auto____4) { var special_name__5 any = temp__1927000408__auto____4; return lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_58), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_59)))), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_58), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_60)))), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_61), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(special_name__5))))))))) } else {

		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repl_A_const_10.GetRawRoot__O()).Invoke_O__O(name__2)) { return lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_58), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_62)))), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_58), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_63)))), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_61), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(name__2))))))))) } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repl_A_const_55.GetRawRoot__O()).Invoke_O__O(name__2)) { return lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_58), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_64)))), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_65.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repl_A_const_66.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_25), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_61), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(name__2)))), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_22), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_61), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_38.GetRawRoot__O()).Invoke_O__O(name__2))))))))))) } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repl_A_const_56.GetRawRoot__O()).Invoke_O__O(name__2)) { return lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_58), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_67)))), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_58), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_68)))), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_69), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_61), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(name__2)))))))))))) } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repl_A_const_11.GetRawRoot__O()).Invoke_O__O(name__2)) { return lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_58), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_70)))), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_71), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_72), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(name__2))))))))) } else { return nil } } } } } }








func A_arbace_repl_source_fn_A_New() *A_arbace_repl_source_fn_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_source_fn_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_repl_source_fn_A) Ctor() {}
//line :147:1
func (t *A_arbace_repl_source_fn_A) Invoke_O_O__O(self, x__0 any) any { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repl_A_const_11.GetRawRoot__O()).Invoke_O__O(x__0); if








	jrt.J2g_Truth(temp__1927000414__auto____2) { var v__3 any = temp__1927000414__auto____2; var tmp1 *lang.Keyword = A_arbace_repl_A_const_73; var temp__1927000414__auto____4 any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(v__3))
		if jrt.J2g_Truth(temp__1927000414__auto____4) { var filepath__5 any = temp__1927000414__auto____4; var tmp2 any = lang.RT_BaseLoader__ClassLoader(); var tmp3 *jrt.Class = A_arbace_repl_A_const_74; var temp__1927000414__auto____6 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp2, tmp3, Lit_34, jrt.RefArrayOf(jrt.Object_class, filepath__5))
			if jrt.J2g_Truth(temp__1927000414__auto____6) { var strm__7 any = temp__1927000414__auto____6; var rdr__8 any = jrt.LineNumberReader_New_Reader(jrt.InputStreamReader_New_InputStream(jrt.InputStream_Cast(strm__7))); var tmp4 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp5 *lang.Keyword = A_arbace_repl_A_const_76; var n__1927000701__auto____11 int64 = lang.RT_LongCast_O__J(lang.Numbers_Dec_O__Number(tmp5.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(v__3)))); var ___12 int64 = 0; L1: for {

				if lang.Numbers_Lt_J_J__Z(___12, n__1927000701__auto____11) { jrt.NN(jrt.LineNumberReader_Cast(rdr__8)).ReadLine__String(); ___12 = lang.Numbers_Unchecked_inc_J__J(___12); continue L1 }
//line :158:1
				break L1 }; var text__11 any = jrt.StringBuilder_New(); var pbr__12 any; var p__840000142__auto____12 any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class(Lit_35), jrt.RefArrayOf(jrt.Object_class, rdr__8)); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_77.GetRawRoot__O()); var tmp7 any = A_arbace_repl_source_fn_fn__1239000039_A_New_O(text__11); var tmp8 *jrt.Class
				var fncls__3 /*line :158:1*/*jrt.Class = A_arbace_repl_source_fn_fn__1239000039_A_fn_class



				if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_37, false); A_arbace_repl_source_fn_fn__1239000039_A_fn_class = fncls__3d; tmp8 = fncls__3d } else { tmp8 = fncls__3 }; tmp6.Invoke_O_O__O(p__840000142__auto____12, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_36, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil))))
//line :158:1
				pbr__12 = p__840000142__auto____12; var read_opts__13 any







				if jrt.NN(jrt.String_Cast(filepath__5)).EndsWith_String__Z(Lit_38) { read_opts__13 = A_arbace_repl_A_const_75 } else { lang.PersistentArrayMap_Init(); read_opts__13 = lang.PersistentArrayMap_EMPTY.Ref() }
				var tmp9 any = A_arbace_repl_A_const_79; if lang.Util_Equiv_O_O__Z(tmp9, A_arbace_repl_A_const_80.Get__O()) { panic(jrt.Thrown(jrt.IllegalStateException_New_String(Lit_39))) } else {

					lang.IFn_Cast(A_arbace_repl_A_const_81.GetRawRoot__O()).Invoke_O_O__O(read_opts__13, jrt.PushbackReader_New_Reader(jrt.Reader_Cast(pbr__12))) }
				tmp4 = lang.IFn_Cast(A_arbace_repl_A_const_35.GetRawRoot__O()).Invoke_O__O(text__11) }; return nil }()
//line :159:1
				jrt.BufferedReader_Cast(rdr__8).Close__V()
//line :158:1
				if tmp10 != nil { panic(tmp10) }; return tmp4 } else { return nil } } else {
//line :157:1
					return nil } } else {
//line :156:1
						return nil } }





func A_arbace_repl_source_fn_fn__1239000039_A_New_O(p0 any) *A_arbace_repl_source_fn_fn__1239000039_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_source_fn_fn__1239000039_A{}; t.Ctor_O(p0); return t }
//line :162:1
func (t *A_arbace_repl_source_fn_fn__1239000039_A) Ctor_O(c__text any) { t.F_text = c__text }
//line :162:1
func (t *A_arbace_repl_source_fn_fn__1239000039_A) Invoke_O_O__O(self, this__1 any) any { var i__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_78.GetRawRoot__O()); var tmp2 any = A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_New_O(this__1); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_fn_class; if
											fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_40, false); A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; i__2 = tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), this__1, Lit_36); var tmp4 /*line :164:1*/*jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_text); jrt.NN(tmp4).Append_C__StringBuilder(lang.RT_CharCast_O__C(i__2)); return i__2 }
//line :163:1
func A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_New_O(p0 any) *A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A{}; t.Ctor_O(p0); return t }
//line :163:1
func (t *A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A) Ctor_O(c__this any) { t.F_this = c__this }
//line :163:1
func (t *A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A) Invoke_O__O(self any) any { return lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(t.F_this, Lit_36, false) }








func A_arbace_repl_source_A_New() *A_arbace_repl_source_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_source_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_repl_source_A) Ctor() {}
//line :172:1
func (t *A_arbace_repl_source_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, n__2 any) any { return lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_82), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_83), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_84), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_61), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(n__2))))))), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_85), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(Lit_33))))))))) }








func A_arbace_repl_apropos_A_New() *A_arbace_repl_apropos_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_apropos_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_repl_apropos_A) Ctor() {}
//line :181:1
func (t *A_arbace_repl_apropos_A) Invoke_O_O__O(self, str_or_pattern__0 any) any { var matches_QMARK___2 any; if




	jrt.Pattern_InstanceOf(str_or_pattern__0) { var tmp1 any = A_arbace_repl_apropos_fn__1239000052_A_New_O(str_or_pattern__0); var tmp2 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_repl_apropos_fn__1239000052_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1, false); A_arbace_repl_apropos_fn__1239000052_A_fn_class = fncls__4d; tmp2 = fncls__4d } else { tmp2 = fncls__4 }; matches_QMARK___2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) } else { var tmp3 any = A_arbace_repl_apropos_fn__1239000054_A_New_O(str_or_pattern__0); var tmp4 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_repl_apropos_fn__1239000054_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_2, false); A_arbace_repl_apropos_fn__1239000054_A_fn_class = fncls__5d; tmp4 = fncls__5d } else { tmp4 = fncls__5 }; matches_QMARK___2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil) }; var tmp5 lang.IFn =


	lang.IFn_Cast(A_arbace_repl_A_const_86.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_42.GetRawRoot__O()); var tmp7 any = A_arbace_repl_apropos_fn__1239000056_A_New_O(matches_QMARK___2); var tmp8 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_repl_apropos_fn__1239000056_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, false); A_arbace_repl_apropos_fn__1239000056_A_fn_class = fncls__7d; tmp8 = fncls__7d } else { tmp8 = fncls__7 }; return tmp5.Invoke_O__O(tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), lang.IFn_Cast(A_arbace_repl_A_const_48.GetRawRoot__O()).Invoke__O())) }
//line :186:1
func A_arbace_repl_apropos_fn__1239000052_A_New_O(p0 any) *A_arbace_repl_apropos_fn__1239000052_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_apropos_fn__1239000052_A{}; t.Ctor_O(p0); return t }
//line :186:1
func (t *A_arbace_repl_apropos_fn__1239000052_A) Ctor_O(c__str_or_pattern any) { t.F_str_or_pattern = c__str_or_pattern }
//line :186:1
func (t *A_arbace_repl_apropos_fn__1239000052_A) Invoke_O_O__O(self, p1__1239000049_SHARP___1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_41.GetRawRoot__O()); var tmp2 any = t.F_str_or_pattern; return tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_repl_A_const_35.GetRawRoot__O()).Invoke_O__O(p1__1239000049_SHARP___1)) }
//line :186:1
func A_arbace_repl_apropos_fn__1239000054_A_New_O(p0 any) *A_arbace_repl_apropos_fn__1239000054_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_apropos_fn__1239000054_A{}; t.Ctor_O(p0); return t }
//line :186:1
func (t *A_arbace_repl_apropos_fn__1239000054_A) Ctor_O(c__str_or_pattern any) { t.F_str_or_pattern = c__str_or_pattern }
//line :186:1
func (t *A_arbace_repl_apropos_fn__1239000054_A) Invoke_O_O__O(self, p1__1239000050_SHARP___1 any) any {

	return jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.String_Cast(lang.IFn_Cast(A_arbace_repl_A_const_35.GetRawRoot__O()).Invoke_O__O(p1__1239000050_SHARP___1))).Contains_CharSequence__Z(jrt.CharSequence_Cast(lang.IFn_Cast(A_arbace_repl_A_const_35.GetRawRoot__O()).Invoke_O__O(t.F_str_or_pattern)))).Ref() }
func A_arbace_repl_apropos_fn__1239000056_A_New_O(p0 any) *A_arbace_repl_apropos_fn__1239000056_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_apropos_fn__1239000056_A{}; t.Ctor_O(p0); return t }
//line :189:1
func (t *A_arbace_repl_apropos_fn__1239000056_A) Ctor_O(c__matches_QMARK_ any) { t.F_matches_QMARK_ = c__matches_QMARK_ }
//line :189:1
func (t *A_arbace_repl_apropos_fn__1239000056_A) Invoke_O_O__O(self, ns__1 any) any { var ns_name__2 any = lang.IFn_Cast(A_arbace_repl_A_const_35.GetRawRoot__O()).Invoke_O__O(ns__1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_43.GetRawRoot__O()); var tmp2 any = A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_New_O(ns_name__2); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_fn_class; if

	fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_4, false); A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_87.GetRawRoot__O()); var tmp5 any = t.F_matches_QMARK_; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_repl_A_const_51.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_88.GetRawRoot__O()).Invoke_O__O(ns__1)))) }
//line :191:1
func A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_New_O(p0 any) *A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A{}; t.Ctor_O(p0); return t }
//line :191:1
func (t *A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A) Ctor_O(c__ns_name any) { t.F_ns_name = c__ns_name }
//line :191:1
func (t *A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A) Invoke_O_O__O(self, p1__1239000051_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_34.GetRawRoot__O()); var tmp2 any = t.F_ns_name; return tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_repl_A_const_35.GetRawRoot__O()).Invoke_O__O(p1__1239000051_SHARP___1)) }



func A_arbace_repl_dir_fn_A_New() *A_arbace_repl_dir_fn_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_dir_fn_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_repl_dir_fn_A) Ctor() {}
//line :195:1
func (t *A_arbace_repl_dir_fn_A) Invoke_O_O__O(self, ns__0 any) any {



	return lang.IFn_Cast(A_arbace_repl_A_const_86.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_43.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repl_A_const_18.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repl_A_const_88.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.RT_Get_O_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_90.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_91.Get__O()), ns__0, ns__0)))))
}
func A_arbace_repl_dir_A_New() *A_arbace_repl_dir_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_dir_A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_repl_dir_A) Ctor() {}
//line :201:1
func (t *A_arbace_repl_dir_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, nsname__2 any) any { return lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_92), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_65.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repl_A_const_93.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_94), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_95), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_61), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(nsname__2))))))))))), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_96), lang.IFn_Cast(A_arbace_repl_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_94)))))) }





func A_arbace_repl_demunge_A_New() *A_arbace_repl_demunge_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_demunge_A{}; t.Ctor(); return t }
//line :207:1
func (t *A_arbace_repl_demunge_A) Ctor() {}
//line :207:1
func (t *A_arbace_repl_demunge_A) Invoke_O_O__O(self, fn_name__0 any) any {




	return lang.Compiler_Demunge_String__String(jrt.String_Cast(fn_name__0)).Ref()
}
func A_arbace_repl_root_cause_A_New() *A_arbace_repl_root_cause_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_root_cause_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_repl_root_cause_A) Ctor() {}
//line :214:1
func (t *A_arbace_repl_root_cause_A) Invoke_O_O__O(self, t__0 any) any { { var cause__2 any = t__0; L1: for {





	var tmp1 any; var and__1927000168__auto____3 bool = lang.Compiler_CompilerException_InstanceOf(cause__2); if and__1927000168__auto____3 {
		tmp1 = lang.IFn_Cast(A_arbace_repl_A_const_97.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_CompilerException_Cast(cause__2).F_source.Ref(), Lit_26) } else {
//line :220:1
			tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) { return cause__2 } else { var temp__1927000408__auto____3 any = jrt.Throwable_Cast(cause__2).GetCause__Throwable()


				if jrt.J2g_Truth(temp__1927000408__auto____3) { var cause__4 any = temp__1927000408__auto____3
					cause__2 = cause__4; continue L1 } else {
//line :223:1
						return cause__2 } } } }; /*line :214:1*/panic("j2g: unreachable") }












func A_arbace_repl_stack_element_str_A_New() *A_arbace_repl_stack_element_str_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_stack_element_str_A{}; t.Ctor(); return t }
//line :227:1
func (t *A_arbace_repl_stack_element_str_A) Ctor() {}
//line :227:1
func (t *A_arbace_repl_stack_element_str_A) Invoke_O_O__O(self, el__0 any) any { var file__2 any = jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetFileName__String().Ref(); var clojure_fn_QMARK___3 any; var and__1927000168__auto____3 any = file__2; if




	jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 bool = jrt.NN(jrt.String_Cast(file__2)).EndsWith_String__Z(Lit_41); if or__1927000174__auto____4 { clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____4).Ref() } else { var or__1927000174__auto____5 bool = jrt.NN(jrt.String_Cast(file__2)).EndsWith_String__Z(Lit_42); if or__1927000174__auto____5 { clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool = jrt.NN(jrt.String_Cast(file__2)).EndsWith_String__Z(Lit_43); if or__1927000174__auto____6 { clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____6).Ref() } else {


		clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(file__2, Lit_26)).Ref() } } } } else {
//line :232:1
			clojure_fn_QMARK___3 = and__1927000168__auto____3 }; var tmp1 /*line :236:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_44, nil, Lit_20, nil, Lit_45); var tmp2 any; if jrt.J2g_Truth(clojure_fn_QMARK___3) {
				tmp2 = lang.IFn_Cast(A_arbace_repl_A_const_98.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetClassName__String().Ref()) } else {
					tmp2 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_46, nil), jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetClassName__String().Ref(), nil, jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetMethodName__String().Ref())).Ref() }; return /*line :236:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil, jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetFileName__String().Ref(), nil, jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetLineNumber__I()).Ref(), nil)).Ref() }




func A_arbace_repl_pst_A_New() *A_arbace_repl_pst_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_pst_A{}; t.Ctor(); return t }
//line :241:1
func (t *A_arbace_repl_pst_A) Ctor() {}
//line :241:1
func (t *A_arbace_repl_pst_A) Invoke_O_O_O__O(self, e__0, depth__1 any) any {










	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_66.GetRawRoot__O()); var tmp2 any = A_arbace_repl_A_const_102; lang.IFn_Cast(A_arbace_repl_A_const_101.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_repl_A_const_103.Get__O()))
//line :241:1
	var tmp3 any; tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)











		{ var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_104); var tmp5 *lang.Keyword = A_arbace_repl_A_const_105; if jrt.J2g_Truth(tmp4.Invoke_O__O(tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_106.GetRawRoot__O()).Invoke_O__O(e__0)))) {

			lang.IFn_Cast(A_arbace_repl_A_const_29.GetRawRoot__O()).Invoke_O__O(Lit_21) }
			var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_29.GetRawRoot__O()); var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_17, nil, nil); var tmp8 any = jrt.NN(jrt.Class_Cast(lang.IFn_Cast(A_arbace_repl_A_const_107.GetRawRoot__O()).Invoke_O__O(e__0))).GetSimpleName__String().Ref(); var tmp9 any = jrt.Throwable_Cast(e__0).GetMessage__String().Ref(); var tmp10 *jrt.String; var temp__1927000414__auto____9 any = lang.IFn_Cast(A_arbace_repl_A_const_106.GetRawRoot__O()).Invoke_O__O(e__0)

			if jrt.J2g_Truth(temp__1927000414__auto____9) { var info__10 any = temp__1927000414__auto____9; tmp10 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repl_A_const_108.GetRawRoot__O()).Invoke_O__O(info__10))) } else { tmp10 = nil }
//line :256:1
			tmp6.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9, tmp10.Ref())).Ref())
//line :241:1
			var st__5 any = jrt.Throwable_Cast(e__0).GetStackTrace__StackTraceElement1().Ref(); var cause__6 any = jrt.Throwable_Cast(e__0).GetCause__Throwable(); var seq_1239000072__7 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_109.GetRawRoot__O()); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_110.GetRawRoot__O()); var tmp14 any = A_arbace_repl_pst_fn__1239000076_A_New(); var tmp15 *jrt.Class
			var fncls__8 /*line :241:1*/*jrt.Class = A_arbace_repl_pst_fn__1239000076_A_fn_class




















			if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_22, false); A_arbace_repl_pst_fn__1239000076_A_fn_class = fncls__8d; tmp15 = fncls__8d } else { tmp15 = fncls__8 }
//line :261:1
			seq_1239000072__7 = tmp11.Invoke_O__O(tmp12.Invoke_O_O__O(depth__1, tmp13.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil), st__5)))
//line :241:1
			var chunk_1239000073__8 any; var count_1239000074__9 int64 = 0; var i_1239000075__10 int64 = 0; L1: for {



















				if lang.Numbers_Lt_J_J__Z(i_1239000075__10, count_1239000074__9) { var el__11 any = lang.Indexed_Cast(chunk_1239000073__8).Nth_I__O(lang.RT_IntCast_J__I(i_1239000075__10))


					lang.IFn_Cast(A_arbace_repl_A_const_29.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_23, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repl_A_const_112.GetRawRoot__O()).Invoke_O__O(el__11))).Ref())
//line :261:1
					seq_1239000072__7, chunk_1239000073__8, count_1239000074__9, i_1239000075__10 = seq_1239000072__7, chunk_1239000073__8, count_1239000074__9, lang.Numbers_Unchecked_inc_J__J(i_1239000075__10); continue L1 } else { var temp__1927000414__auto____11 any = lang.IFn_Cast(A_arbace_repl_A_const_17.GetRawRoot__O()).Invoke_O__O(seq_1239000072__7); if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1239000072__12 any = temp__1927000414__auto____11; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repl_A_const_27.GetRawRoot__O()).Invoke_O__O(seq_1239000072__12)) { var c__1927000678__auto____13 any = lang.IFn_Cast(A_arbace_repl_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1239000072__12); seq_1239000072__7, chunk_1239000073__8, count_1239000074__9, i_1239000075__10 = lang.IFn_Cast(A_arbace_repl_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1239000072__12), c__1927000678__auto____13, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var el__13 any = lang.IFn_Cast(A_arbace_repl_A_const_18.GetRawRoot__O()).Invoke_O__O(seq_1239000072__12)


						lang.IFn_Cast(A_arbace_repl_A_const_29.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_23, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repl_A_const_112.GetRawRoot__O()).Invoke_O__O(el__13))).Ref())
//line :261:1
						seq_1239000072__7, chunk_1239000073__8, count_1239000074__9, i_1239000075__10 = lang.IFn_Cast(A_arbace_repl_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1239000072__12), nil, 0, 0; continue L1 } } }
//line :241:1
				break L1
			}






















			if jrt.J2g_Truth(cause__6) {
				lang.IFn_Cast(A_arbace_repl_A_const_29.GetRawRoot__O()).Invoke_O__O(Lit_24)
				tmp3 = lang.IFn_Cast(A_arbace_repl_A_const_99.GetRawRoot__O()).Invoke_O_O__O(cause__6, lang.Numbers_Min_O_J__O(depth__1, lang.Numbers_Add_J_J__J(2, lang.Numbers_Minus_J_J__J(int64(lang.RT_Count_O__I(jrt.Throwable_Cast(cause__6).GetStackTrace__StackTraceElement1().Ref())), int64(lang.RT_Count_O__I(st__5)))))) } else {
//line :265:1
					tmp3 = nil } }
//line :241:1
		return nil
	}()









	lang.IFn_Cast(A_arbace_repl_A_const_100.GetRawRoot__O()).Invoke__O()
//line :241:1
	if tmp16 != nil { panic(tmp16) }; return tmp3 }
//line :241:1
func (t *A_arbace_repl_pst_A) Invoke_O_O__O(self, e_or_depth__0 any) any {





	if jrt.Throwable_InstanceOf(e_or_depth__0) {
		return lang.IFn_Cast(A_arbace_repl_A_const_99.GetRawRoot__O()).Invoke_O_O__O(e_or_depth__0, A_arbace_repl_A_const_114) } else {
//line :247:1
			var temp__1927000414__auto____2 any = A_arbace_repl_A_const_113.Get__O()

			if jrt.J2g_Truth(temp__1927000414__auto____2) { var e__3 any = temp__1927000414__auto____2
				return lang.IFn_Cast(A_arbace_repl_A_const_99.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repl_A_const_115.GetRawRoot__O()).Invoke_O__O(e__3), e_or_depth__0) } else {
//line :249:1
					return nil } } }
//line :241:1
func (t *A_arbace_repl_pst_A) Invoke_O__O(self any) any {



	return lang.IFn_Cast(A_arbace_repl_A_const_99.GetRawRoot__O()).Invoke_O__O(A_arbace_repl_A_const_114)
}















func A_arbace_repl_pst_fn__1239000076_A_New() *A_arbace_repl_pst_fn__1239000076_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_pst_fn__1239000076_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_repl_pst_fn__1239000076_A) Ctor() {}
//line :262:1
func (t *A_arbace_repl_pst_fn__1239000076_A) Invoke_O_O__O(self, p1__1239000071_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_111); return tmp1.Invoke_O__O(lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(p1__1239000071_SHARP___1, Lit_25, false)) }











func A_arbace_repl_thread_stopper_A_New() *A_arbace_repl_thread_stopper_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_thread_stopper_A{}; t.Ctor(); return t }
//line :274:1
func (t *A_arbace_repl_thread_stopper_A) Ctor() {}
//line :274:1
func (t *A_arbace_repl_thread_stopper_A) Invoke_O_O__O(self, thread__0 any) any {



	var tmp1 any = A_arbace_repl_thread_stopper_fn__1239000079_A_New_O(thread__0); var tmp2 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_repl_thread_stopper_fn__1239000079_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_47, false); A_arbace_repl_thread_stopper_fn__1239000079_A_fn_class = fncls__9d; tmp2 = fncls__9d } else { tmp2 = fncls__9 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :274:1
func (t *A_arbace_repl_thread_stopper_A) Invoke_O__O(self any) any {


	return lang.IFn_Cast(A_arbace_repl_A_const_117.GetRawRoot__O()).Invoke_O__O(jrt.Thread_CurrentThread__Thread()) }
func A_arbace_repl_thread_stopper_fn__1239000079_A_New_O(p0 any) *A_arbace_repl_thread_stopper_fn__1239000079_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_thread_stopper_fn__1239000079_A{}; t.Ctor_O(p0); return t }
//line :278:1
func (t *A_arbace_repl_thread_stopper_fn__1239000079_A) Ctor_O(c__thread any) { t.F_thread = c__thread }
//line :278:1
func (t *A_arbace_repl_thread_stopper_fn__1239000079_A) Invoke_O_O__O(self, msg__1 any) any { var tmp1 any = t.F_thread; var tmp2 *jrt.Class = A_arbace_repl_A_const_116; return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(tmp1, Lit_48, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(tmp2, jrt.RefArrayOf(jrt.Object_class, msg__1)))) }

func A_arbace_repl_set_break_handler_BANG__A_New() *A_arbace_repl_set_break_handler_BANG__A { A_arbace_repl_A_Init(); t := &A_arbace_repl_set_break_handler_BANG__A{}; t.Ctor(); return t }
//line :280:1
func (t *A_arbace_repl_set_break_handler_BANG__A) Ctor() {}
//line :280:1
func (t *A_arbace_repl_set_break_handler_BANG__A) Invoke_O_O__O(self, f__0 any) any {





	var tmp1 *jrt.Class = lang.RT_ClassForNameNonLoading_String__Class(Lit_27); var tmp2 any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class(Lit_27), jrt.RefArrayOf(jrt.Object_class, Lit_29)); var tmp3 any; var p__840000142__auto____2 any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class(Lit_30), jrt.RefArrayOf(jrt.Object_class)); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repl_A_const_77.GetRawRoot__O()); var tmp5 any = A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_New_O(f__0); var tmp6 *jrt.Class
	var fncls__10 /*line :286:1*/*jrt.Class = A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_fn_class

	if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_31, false); A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_fn_class = fncls__10d; tmp6 = fncls__10d } else { tmp6 = fncls__10 }; tmp4.Invoke_O_O__O(p__840000142__auto____2, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_28, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil))))
//line :286:1
	tmp3 = p__840000142__auto____2; return lang.Reflector_InvokeStaticMethod_Class_String_O1__O(tmp1, Lit_28, jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3)) }
//line :280:1
func (t *A_arbace_repl_set_break_handler_BANG__A) Invoke_O__O(self any) any {



	return lang.IFn_Cast(A_arbace_repl_A_const_118.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repl_A_const_117.GetRawRoot__O()).Invoke__O())
}


func A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_New_O(p0 any) *A_arbace_repl_set_break_handler_BANG__fn__1239000082_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_set_break_handler_BANG__fn__1239000082_A{}; t.Ctor_O(p0); return t }
//line :288:1
func (t *A_arbace_repl_set_break_handler_BANG__fn__1239000082_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :288:1
func (t *A_arbace_repl_set_break_handler_BANG__fn__1239000082_A) Invoke_O_O_O__O(self, this__1, signal__2 any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(t.F_f); return tmp1.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_32, nil), jrt.RefArrayOf(jrt.Object_class, nil, signal__2)).Ref())
}












type A_arbace_repl_A struct{ jrt.Object }

var A_arbace_repl_A_const_pool *jrt.RefArray

var A_arbace_repl_A_const_0 *lang.Var

var A_arbace_repl_A_const_1 *lang.Var

var A_arbace_repl_A_const_2 any

var A_arbace_repl_A_const_3 any

var A_arbace_repl_A_const_4 *lang.Var

var A_arbace_repl_A_const_5 *lang.Var

var A_arbace_repl_A_const_6 *lang.Var

var A_arbace_repl_A_const_7 any

var A_arbace_repl_A_const_8 *lang.Var

var A_arbace_repl_A_const_9 *lang.Var

var A_arbace_repl_A_const_10 *lang.Var

var A_arbace_repl_A_const_11 *lang.Var

var A_arbace_repl_A_const_12 *lang.Keyword

var A_arbace_repl_A_const_13 *lang.Keyword

var A_arbace_repl_A_const_14 *lang.Var

var A_arbace_repl_A_const_15 *lang.Var

var A_arbace_repl_A_const_16 *lang.Var

var A_arbace_repl_A_const_17 *lang.Var

var A_arbace_repl_A_const_18 *lang.Var

var A_arbace_repl_A_const_19 *lang.Keyword

var A_arbace_repl_A_const_20 *lang.Keyword

var A_arbace_repl_A_const_21 *lang.Keyword

var A_arbace_repl_A_const_22 *lang.Keyword

var A_arbace_repl_A_const_23 *lang.Keyword

var A_arbace_repl_A_const_24 *lang.Keyword

var A_arbace_repl_A_const_25 *lang.Keyword

var A_arbace_repl_A_const_26 *lang.Var

var A_arbace_repl_A_const_27 *lang.Var

var A_arbace_repl_A_const_28 *lang.Var

var A_arbace_repl_A_const_29 *lang.Var

var A_arbace_repl_A_const_30 *lang.Var

var A_arbace_repl_A_const_31 *lang.Var

var A_arbace_repl_A_const_32 *lang.Var

var A_arbace_repl_A_const_33 *lang.Var

var A_arbace_repl_A_const_34 *lang.Var

var A_arbace_repl_A_const_35 *lang.Var

var A_arbace_repl_A_const_36 *lang.Var

var A_arbace_repl_A_const_37 any

var A_arbace_repl_A_const_38 *lang.Var

var A_arbace_repl_A_const_39 *lang.Var

var A_arbace_repl_A_const_40 *lang.Var

var A_arbace_repl_A_const_41 *lang.Var

var A_arbace_repl_A_const_42 *lang.Var

var A_arbace_repl_A_const_43 *lang.Var

var A_arbace_repl_A_const_44 *lang.Var

var A_arbace_repl_A_const_45 *lang.Var

var A_arbace_repl_A_const_46 *lang.Var

var A_arbace_repl_A_const_47 *lang.Var

var A_arbace_repl_A_const_48 *lang.Var

var A_arbace_repl_A_const_49 *lang.Var

var A_arbace_repl_A_const_50 *lang.Var

var A_arbace_repl_A_const_51 *lang.Var

var A_arbace_repl_A_const_52 *lang.Var

var A_arbace_repl_A_const_53 *lang.Var

var A_arbace_repl_A_const_54 any

var A_arbace_repl_A_const_55 *lang.Var

var A_arbace_repl_A_const_56 *lang.Var

var A_arbace_repl_A_const_57 *lang.Var

var A_arbace_repl_A_const_58 any

var A_arbace_repl_A_const_59 any

var A_arbace_repl_A_const_60 any

var A_arbace_repl_A_const_61 any

var A_arbace_repl_A_const_62 any

var A_arbace_repl_A_const_63 any

var A_arbace_repl_A_const_64 any

var A_arbace_repl_A_const_65 *lang.Var

var A_arbace_repl_A_const_66 *lang.Var

var A_arbace_repl_A_const_67 any

var A_arbace_repl_A_const_68 any

var A_arbace_repl_A_const_69 any

var A_arbace_repl_A_const_70 any

var A_arbace_repl_A_const_71 any

var A_arbace_repl_A_const_72 any

var A_arbace_repl_A_const_73 *lang.Keyword

var A_arbace_repl_A_const_74 *jrt.Class

var A_arbace_repl_A_const_75 any

var A_arbace_repl_A_const_76 *lang.Keyword

var A_arbace_repl_A_const_77 *lang.Var

var A_arbace_repl_A_const_78 *lang.Var

var A_arbace_repl_A_const_79 *lang.Keyword

var A_arbace_repl_A_const_80 *lang.Var

var A_arbace_repl_A_const_81 *lang.Var

var A_arbace_repl_A_const_82 any

var A_arbace_repl_A_const_83 any

var A_arbace_repl_A_const_84 any

var A_arbace_repl_A_const_85 any

var A_arbace_repl_A_const_86 *lang.Var

var A_arbace_repl_A_const_87 *lang.Var

var A_arbace_repl_A_const_88 *lang.Var

var A_arbace_repl_A_const_89 *lang.Var

var A_arbace_repl_A_const_90 *lang.Var

var A_arbace_repl_A_const_91 *lang.Var

var A_arbace_repl_A_const_92 any

var A_arbace_repl_A_const_93 *lang.Var

var A_arbace_repl_A_const_94 any

var A_arbace_repl_A_const_95 any

var A_arbace_repl_A_const_96 any

var A_arbace_repl_A_const_97 *lang.Var

var A_arbace_repl_A_const_98 *lang.Var

var A_arbace_repl_A_const_99 *lang.Var

var A_arbace_repl_A_const_100 *lang.Var

var A_arbace_repl_A_const_101 *lang.Var

var A_arbace_repl_A_const_102 *lang.Var

var A_arbace_repl_A_const_103 *lang.Var

var A_arbace_repl_A_const_104 any

var A_arbace_repl_A_const_105 *lang.Keyword

var A_arbace_repl_A_const_106 *lang.Var

var A_arbace_repl_A_const_107 *lang.Var

var A_arbace_repl_A_const_108 *lang.Var

var A_arbace_repl_A_const_109 *lang.Var

var A_arbace_repl_A_const_110 *lang.Var

var A_arbace_repl_A_const_111 any

var A_arbace_repl_A_const_112 *lang.Var

var A_arbace_repl_A_const_113 *lang.Var

var A_arbace_repl_A_const_114 any

var A_arbace_repl_A_const_115 *lang.Var

var A_arbace_repl_A_const_116 *jrt.Class

var A_arbace_repl_A_const_117 *lang.Var

var A_arbace_repl_A_const_118 *lang.Var

var A_arbace_repl_A_init jrt.ClassInit

func A_arbace_repl_A_Init() { if !A_arbace_repl_A_init.Done() { A_arbace_repl_A_init.Run(A_arbace_repl_A_clinit) } }

func A_arbace_repl_A_clinit() { A_arbace_repl_A_clinit_p0(); A_arbace_repl_A_clinit_p1(); A_arbace_repl_A_clinit_p2(); A_arbace_repl_A_clinit_p3(); A_arbace_repl_A_clinit_p4(); A_arbace_repl_A_clinit_p5(); A_arbace_repl_A_clinit_p6(); A_arbace_repl_A_clinit_p7(); A_arbace_repl_A_clinit_p8(); A_arbace_repl_A_clinit_p9() }

func A_arbace_repl_A_clinit_p0() { A_arbace_repl_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 166); A_arbace_repl_A_const_0 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[47]); A_arbace_repl_A_const_1 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[48]); A_arbace_repl_A_const_2 = A_arbace_repl_A_const_pool.A[49]; A_arbace_repl_A_const_3 = A_arbace_repl_A_const_pool.A[50]; A_arbace_repl_A_const_4 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[51]); A_arbace_repl_A_const_5 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[52]); A_arbace_repl_A_const_6 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[53]); A_arbace_repl_A_const_7 = A_arbace_repl_A_const_pool.A[54]; A_arbace_repl_A_const_8 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[55]); A_arbace_repl_A_const_9 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[56]); A_arbace_repl_A_const_10 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[57]); A_arbace_repl_A_const_11 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[58]) }

func A_arbace_repl_A_clinit_p1() { A_arbace_repl_A_const_12 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[59]); A_arbace_repl_A_const_13 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[60]); A_arbace_repl_A_const_14 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[61]); A_arbace_repl_A_const_15 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[62]); A_arbace_repl_A_const_16 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[63]); A_arbace_repl_A_const_17 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[64]); A_arbace_repl_A_const_18 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[65]); A_arbace_repl_A_const_19 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[66]); A_arbace_repl_A_const_20 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[67]); A_arbace_repl_A_const_21 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[68]); A_arbace_repl_A_const_22 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[69]); A_arbace_repl_A_const_23 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[70]) }

func A_arbace_repl_A_clinit_p2() { A_arbace_repl_A_const_24 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[71]); A_arbace_repl_A_const_25 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[72]); A_arbace_repl_A_const_26 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[73]); A_arbace_repl_A_const_27 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[74]); A_arbace_repl_A_const_28 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[75]); A_arbace_repl_A_const_29 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[76]); A_arbace_repl_A_const_30 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[77]); A_arbace_repl_A_const_31 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[78]); A_arbace_repl_A_const_32 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[79]); A_arbace_repl_A_const_33 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[80]); A_arbace_repl_A_const_34 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[81]); A_arbace_repl_A_const_35 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[82]) }

func A_arbace_repl_A_clinit_p3() { A_arbace_repl_A_const_36 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[83]); A_arbace_repl_A_const_37 = A_arbace_repl_A_const_pool.A[84]; A_arbace_repl_A_const_38 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[85]); A_arbace_repl_A_const_39 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[86]); A_arbace_repl_A_const_40 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[87]); A_arbace_repl_A_const_41 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[88]); A_arbace_repl_A_const_42 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[89]); A_arbace_repl_A_const_43 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[90]); A_arbace_repl_A_const_44 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[91]); A_arbace_repl_A_const_45 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[92]); A_arbace_repl_A_const_46 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[93]); A_arbace_repl_A_const_47 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[94]) }

func A_arbace_repl_A_clinit_p4() { A_arbace_repl_A_const_48 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[95]); A_arbace_repl_A_const_49 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[96]); A_arbace_repl_A_const_50 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[97]); A_arbace_repl_A_const_51 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[98]); A_arbace_repl_A_const_52 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[99]); A_arbace_repl_A_const_53 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[100]); A_arbace_repl_A_const_54 = A_arbace_repl_A_const_pool.A[101]; A_arbace_repl_A_const_55 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[102]); A_arbace_repl_A_const_56 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[103]); A_arbace_repl_A_const_57 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[104]); A_arbace_repl_A_const_58 = A_arbace_repl_A_const_pool.A[105]; A_arbace_repl_A_const_59 = A_arbace_repl_A_const_pool.A[106]; A_arbace_repl_A_const_60 = A_arbace_repl_A_const_pool.A[107] }

func A_arbace_repl_A_clinit_p5() { A_arbace_repl_A_const_61 = A_arbace_repl_A_const_pool.A[108]; A_arbace_repl_A_const_62 = A_arbace_repl_A_const_pool.A[109]; A_arbace_repl_A_const_63 = A_arbace_repl_A_const_pool.A[110]; A_arbace_repl_A_const_64 = A_arbace_repl_A_const_pool.A[111]; A_arbace_repl_A_const_65 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[112]); A_arbace_repl_A_const_66 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[113]); A_arbace_repl_A_const_67 = A_arbace_repl_A_const_pool.A[114]; A_arbace_repl_A_const_68 = A_arbace_repl_A_const_pool.A[115]; A_arbace_repl_A_const_69 = A_arbace_repl_A_const_pool.A[116]; A_arbace_repl_A_const_70 = A_arbace_repl_A_const_pool.A[117]; A_arbace_repl_A_const_71 = A_arbace_repl_A_const_pool.A[118]; A_arbace_repl_A_const_72 = A_arbace_repl_A_const_pool.A[119]; A_arbace_repl_A_const_73 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[120]); A_arbace_repl_A_const_74 = jrt.Class_Cast(A_arbace_repl_A_const_pool.A[121]) }

func A_arbace_repl_A_clinit_p6() { A_arbace_repl_A_const_75 = A_arbace_repl_A_const_pool.A[122]; A_arbace_repl_A_const_76 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[123]); A_arbace_repl_A_const_77 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[124]); A_arbace_repl_A_const_78 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[125]); A_arbace_repl_A_const_79 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[126]); A_arbace_repl_A_const_80 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[127]); A_arbace_repl_A_const_81 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[128]); A_arbace_repl_A_const_82 = A_arbace_repl_A_const_pool.A[129]; A_arbace_repl_A_const_83 = A_arbace_repl_A_const_pool.A[130]; A_arbace_repl_A_const_84 = A_arbace_repl_A_const_pool.A[131]; A_arbace_repl_A_const_85 = A_arbace_repl_A_const_pool.A[132]; A_arbace_repl_A_const_86 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[133]); A_arbace_repl_A_const_87 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[134]) }

func A_arbace_repl_A_clinit_p7() { A_arbace_repl_A_const_88 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[135]); A_arbace_repl_A_const_89 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[136]); A_arbace_repl_A_const_90 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[137]); A_arbace_repl_A_const_91 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[138]); A_arbace_repl_A_const_92 = A_arbace_repl_A_const_pool.A[139]; A_arbace_repl_A_const_93 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[140]); A_arbace_repl_A_const_94 = A_arbace_repl_A_const_pool.A[141]; A_arbace_repl_A_const_95 = A_arbace_repl_A_const_pool.A[142]; A_arbace_repl_A_const_96 = A_arbace_repl_A_const_pool.A[143]; A_arbace_repl_A_const_97 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[144]); A_arbace_repl_A_const_98 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[145]); A_arbace_repl_A_const_99 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[146]); A_arbace_repl_A_const_100 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[147]) }

func A_arbace_repl_A_clinit_p8() { A_arbace_repl_A_const_101 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[148]); A_arbace_repl_A_const_102 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[149]); A_arbace_repl_A_const_103 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[150]); A_arbace_repl_A_const_104 = A_arbace_repl_A_const_pool.A[151]; A_arbace_repl_A_const_105 = lang.Keyword_Cast(A_arbace_repl_A_const_pool.A[152]); A_arbace_repl_A_const_106 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[153]); A_arbace_repl_A_const_107 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[154]); A_arbace_repl_A_const_108 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[155]); A_arbace_repl_A_const_109 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[156]); A_arbace_repl_A_const_110 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[157]); A_arbace_repl_A_const_111 = A_arbace_repl_A_const_pool.A[158]; A_arbace_repl_A_const_112 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[159]) }

func A_arbace_repl_A_clinit_p9() { A_arbace_repl_A_const_113 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[160]); A_arbace_repl_A_const_114 = A_arbace_repl_A_const_pool.A[161]; A_arbace_repl_A_const_115 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[162]); A_arbace_repl_A_const_116 = jrt.Class_Cast(A_arbace_repl_A_const_pool.A[163]); A_arbace_repl_A_const_117 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[164]); A_arbace_repl_A_const_118 = lang.Var_Cast(A_arbace_repl_A_const_pool.A[165]) }

func A_arbace_repl_A_New() *A_arbace_repl_A { A_arbace_repl_A_Init(); t := &A_arbace_repl_A{}; t.Ctor(); return t }

func (t *A_arbace_repl_A) Ctor() {}

func (t *A_arbace_repl_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_A) GetClass__Class() *jrt.Class { return A_arbace_repl_A_class }

func (t *A_arbace_repl_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repl_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_A); return ok }

func A_arbace_repl_A_Cast(x any) *A_arbace_repl_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_A_class)) }; return v }



type A_arbace_repl_apropos_A struct{ j2g_header uint64 }

var A_arbace_repl_apropos_A_fn_class *jrt.Class



type A_arbace_repl_apropos_fn__1239000052_A struct{ j2g_header uint64; F_str_or_pattern any }

var A_arbace_repl_apropos_fn__1239000052_A_fn_class *jrt.Class



type A_arbace_repl_apropos_fn__1239000054_A struct{ j2g_header uint64; F_str_or_pattern any }

var A_arbace_repl_apropos_fn__1239000054_A_fn_class *jrt.Class



type A_arbace_repl_apropos_fn__1239000056_A struct{ j2g_header uint64; F_matches_QMARK_ any }

var A_arbace_repl_apropos_fn__1239000056_A_fn_class *jrt.Class



type A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A struct{ j2g_header uint64; F_ns_name any }

var A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_fn_class *jrt.Class



type A_arbace_repl_demunge_A struct{ j2g_header uint64 }

var A_arbace_repl_demunge_A_fn_class *jrt.Class



type A_arbace_repl_dir_A struct{ j2g_header uint64 }

var A_arbace_repl_dir_A_fn_class *jrt.Class



type A_arbace_repl_dir_fn_A struct{ j2g_header uint64 }

var A_arbace_repl_dir_fn_A_fn_class *jrt.Class



type A_arbace_repl_doc_A struct{ j2g_header uint64 }

var A_arbace_repl_doc_A_fn_class *jrt.Class



type A_arbace_repl_eval1239000004_A struct{ jrt.Object }

func A_arbace_repl_eval1239000004_A_New() *A_arbace_repl_eval1239000004_A { t := &A_arbace_repl_eval1239000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repl_eval1239000004_A) Ctor() {}

func (t *A_arbace_repl_eval1239000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_eval1239000004_A) GetClass__Class() *jrt.Class { return A_arbace_repl_eval1239000004_A_class }

func (t *A_arbace_repl_eval1239000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_eval1239000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repl_eval1239000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_eval1239000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_eval1239000004_A); return ok }

func A_arbace_repl_eval1239000004_A_Cast(x any) *A_arbace_repl_eval1239000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_eval1239000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_eval1239000004_A_class)) }; return v }



type A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A struct{ j2g_header uint64 }

var A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_fn_class *jrt.Class



type A_arbace_repl_eval1239000008_A struct{ jrt.Object }

func A_arbace_repl_eval1239000008_A_New() *A_arbace_repl_eval1239000008_A { t := &A_arbace_repl_eval1239000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repl_eval1239000008_A) Ctor() {}

func (t *A_arbace_repl_eval1239000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl_eval1239000008_A) GetClass__Class() *jrt.Class { return A_arbace_repl_eval1239000008_A_class }

func (t *A_arbace_repl_eval1239000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl_eval1239000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repl_eval1239000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl_eval1239000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl_eval1239000008_A); return ok }

func A_arbace_repl_eval1239000008_A_Cast(x any) *A_arbace_repl_eval1239000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl_eval1239000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl_eval1239000008_A_class)) }; return v }



type A_arbace_repl_eval1239000008_fn__1239000009_A struct{ j2g_header uint64 }

var A_arbace_repl_eval1239000008_fn__1239000009_A_fn_class *jrt.Class



type A_arbace_repl_find_doc_A struct{ j2g_header uint64 }

var A_arbace_repl_find_doc_A_fn_class *jrt.Class



type A_arbace_repl_find_doc_fn__1239000027_A struct{ j2g_header uint64 }

var A_arbace_repl_find_doc_fn__1239000027_A_fn_class *jrt.Class



type A_arbace_repl_namespace_doc_A struct{ j2g_header uint64 }

var A_arbace_repl_namespace_doc_A_fn_class *jrt.Class



type A_arbace_repl_print_doc_A struct{ j2g_header uint64 }

var A_arbace_repl_print_doc_A_fn_class *jrt.Class



type A_arbace_repl_pst_A struct{ j2g_header uint64 }

var A_arbace_repl_pst_A_fn_class *jrt.Class



type A_arbace_repl_pst_fn__1239000076_A struct{ j2g_header uint64 }

var A_arbace_repl_pst_fn__1239000076_A_fn_class *jrt.Class



type A_arbace_repl_root_cause_A struct{ j2g_header uint64 }

var A_arbace_repl_root_cause_A_fn_class *jrt.Class



type A_arbace_repl_set_break_handler_BANG__A struct{ j2g_header uint64 }

var A_arbace_repl_set_break_handler_BANG__A_fn_class *jrt.Class



type A_arbace_repl_set_break_handler_BANG__fn__1239000082_A struct{ j2g_header uint64; F_f any }

var A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_fn_class *jrt.Class



type A_arbace_repl_source_A struct{ j2g_header uint64 }

var A_arbace_repl_source_A_fn_class *jrt.Class



type A_arbace_repl_source_fn_A struct{ j2g_header uint64 }

var A_arbace_repl_source_fn_A_fn_class *jrt.Class



type A_arbace_repl_source_fn_fn__1239000039_A struct{ j2g_header uint64; F_text any }

var A_arbace_repl_source_fn_fn__1239000039_A_fn_class *jrt.Class



type A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A struct{ j2g_header uint64; F_this any }

var A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_fn_class *jrt.Class



type A_arbace_repl_special_doc_A struct{ j2g_header uint64 }

var A_arbace_repl_special_doc_A_fn_class *jrt.Class



type A_arbace_repl_stack_element_str_A struct{ j2g_header uint64 }

var A_arbace_repl_stack_element_str_A_fn_class *jrt.Class



type A_arbace_repl_thread_stopper_A struct{ j2g_header uint64 }

var A_arbace_repl_thread_stopper_A_fn_class *jrt.Class



type A_arbace_repl_thread_stopper_fn__1239000079_A struct{ j2g_header uint64; F_thread any }

var A_arbace_repl_thread_stopper_fn__1239000079_A_fn_class *jrt.Class
