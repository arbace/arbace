//line j2g_strings.ae:1
package aot_arbace_repl

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn17,arbace.spec.alphakn2,asyn4,speckn6,authorkn3,dockn4,namekn12,special-formkn2,nskn5,formskn8,arglistskn3,urlkn5,macrokn4,speckn4,argskn3,retkn2,fnyn1,&yn2,fnyn5,catchyn3,tryyn7,finallyyn3,varys11,arbace.repl9,print-docys11,arbace.repl11,special-docyn5,quoteys11,arbace.repl13,namespace-docys11,arbace.core7,find-nsys11,arbace.core4,metakn4,filekn9,read-condkn5,allowkn4,linekn7,unknownys11,arbace.core7,printlnys11,arbace.core2,orys11,arbace.repl9,source-fnys11,arbace.core3,strys11,arbace.core5,doseqyn21,v__1239000062__auto__ys11,arbace.repl6,dir-fnkn18,macro-syntax-checkkn20,compile-syntax-checkkn11,read-sourcekn14,macroexpansionkn11,compilationks12,arbace.error5,phasev11,arbace.core5,referv11,arbace.core7,requireR0,V3,R1,R2,R3,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn11,arbace.replm4,R4,s61,Chris Houser, Christophe Grand, Stephen Gilardi, Michel SalimR5,s52,Utilities meant to be used interactively at the REPLv11,arbace.core13,*loaded-libs*v11,arbace.core5,assocv11,arbace.repl15,special-doc-mapv11,arbace.core7,resolveR6,R7,v11,arbace.core7,ns-namev11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core3,seqv11,arbace.core5,firstR8,R9,R10,R5,R11,R12,R13,v17,arbace.spec.alpha8,get-specv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core7,printlnv11,arbace.core3,prnv11,arbace.core9,contains?v11,arbace.core5,printv11,arbace.core10,chunk-restv11,arbace.core6,symbolv11,arbace.core3,strv11,arbace.core4,nameV3,R14,R15,R16,v17,arbace.spec.alpha8,describev11,arbace.core10,re-patternv11,arbace.core6,concatv11,arbace.core7,re-findv11,arbace.core6,mapcatv11,arbace.core3,mapv11,arbace.core7,sort-byv11,arbace.core4,metav11,arbace.core4,valsv11,arbace.core10,ns-internsv11,arbace.core6,all-nsv11,arbace.repl13,namespace-docv11,arbace.repl11,special-docv11,arbace.core4,keysv11,arbace.core10,re-matcherv11,arbace.repl9,print-docm6,R17,R18,R19,R20,R21,R20,v11,arbace.core8,keyword?v11,arbace.core7,find-nsv11,arbace.core4,listR22,R23,R24,R25,R23,R24,R23,v11,arbace.core5,applyv11,arbace.core8,hash-mapR23,R26,R27,R23,R28,R22,R29,C21,java.lang.ClassLoaderm2,R30,R31,R32,v11,arbace.core10,init-proxyv11,arbace.core21,proxy-call-with-superR33,v11,arbace.core11,*read-eval*v11,arbace.core4,readR34,R35,R36,R37,v11,arbace.core4,sortv11,arbace.core6,filterv11,arbace.core10,ns-publicsv11,arbace.core6,the-nsv11,arbace.core10,ns-aliasesv11,arbace.core4,*ns*R38,v11,arbace.core6,vectorR39,R40,R34,v11,arbace.core4,not=v11,arbace.repl7,demungev11,arbace.repl3,pstv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core5,*out*v11,arbace.core5,*err*S5,R41,R42,R43,R44,R45,R46,v11,arbace.core7,ex-datav11,arbace.core5,classv11,arbace.core6,pr-strv11,arbace.core4,takev11,arbace.core6,removeS2,s15,arbace.lang.AFns18,arbace.lang.RestFnv11,arbace.repl17,stack-element-strv11,arbace.core2,*el12,v11,arbace.repl10,root-causeC15,java.lang.Errorv11,arbace.repl14,thread-stopperv11,arbace.repl18,set-break-handler!")

var Lit_1 *jrt.String = jrt.Intern("arbace.repl$apropos$fn__1239000052")

var Lit_2 *jrt.String = jrt.Intern("arbace.repl$apropos$fn__1239000054")

var Lit_3 *jrt.String = jrt.Intern("arbace.repl$apropos$fn__1239000056")

var Lit_4 *jrt.String = jrt.Intern("arbace.repl$apropos$fn__1239000056$fn__1239000057")

var Lit_5 *jrt.String = jrt.Intern("java.io.LineNumberReader")

var Lit_6 *jrt.String = jrt.Intern("java.io.InputStreamReader")

var Lit_7 *jrt.String = jrt.Intern("java.io.PushbackReader")

var Lit_8 *jrt.String = jrt.Intern("arbace.lang.RT")

var Lit_9 *jrt.String = jrt.Intern("arbace.lang.Reflector")

var Lit_10 *jrt.String = jrt.Intern("arbace.repl$find_doc$fn__1239000027")

var Lit_11 *jrt.String = jrt.Intern("-------------------------")

var Lit_12 *jrt.String = jrt.Intern("/")

var Lit_13 *jrt.String = jrt.Intern("  ")

var Lit_14 *jrt.String = jrt.Intern("Special Form")

var Lit_15 *jrt.String = jrt.Intern("Macro")

var Lit_16 *jrt.String = jrt.Intern("Spec")

var Lit_17 *jrt.String = jrt.Intern(" ")

var Lit_18 *jrt.String = jrt.Intern("\n  Please see http://clojure.org/")

var Lit_19 *jrt.String = jrt.Intern("\n  Please see http://clojure.org/special_forms#")

var Lit_20 *jrt.String = jrt.Intern(":")

var Lit_21 *jrt.String = jrt.Intern("Note: The following stack trace applies to the reader or compiler, your code was not executed.")

var Lit_22 *jrt.String = jrt.Intern("arbace.repl$pst$fn__1239000076")

var Lit_23 *jrt.String = jrt.Intern("\t")

var Lit_24 *jrt.String = jrt.Intern("Caused by:")

var Lit_25 *jrt.String = jrt.Intern("getClassName")

var Lit_26 *jrt.String = jrt.Intern("NO_SOURCE_FILE")

var Lit_27 *jrt.String = jrt.Intern("sun.misc.Signal")

var Lit_28 *jrt.String = jrt.Intern("handle")

var Lit_29 *jrt.String = jrt.Intern("INT")

var Lit_30 *jrt.String = jrt.Intern("arbace.repl.proxy$java.lang.Object$SignalHandler$d8c00ec7")

var Lit_31 *jrt.String = jrt.Intern("arbace.repl$set_break_handler_BANG_$fn__1239000082")

var Lit_32 *jrt.String = jrt.Intern("-- caught signal ")

var Lit_33 *jrt.String = jrt.Intern("Source not found")

var Lit_34 *jrt.String = jrt.Intern("getResourceAsStream")

var Lit_35 *jrt.String = jrt.Intern("arbace.repl.proxy$java.io.PushbackReader$ff19274a")

var Lit_36 *jrt.String = jrt.Intern("read")

var Lit_37 *jrt.String = jrt.Intern("arbace.repl$source_fn$fn__1239000039")

var Lit_38 *jrt.String = jrt.Intern("cljc")

var Lit_39 *jrt.String = jrt.Intern("Unable to read source while *read-eval* is :unknown.")

var Lit_40 *jrt.String = jrt.Intern("arbace.repl$source_fn$fn__1239000039$fn__1239000040")

var Lit_41 *jrt.String = jrt.Intern(".ae")

var Lit_42 *jrt.String = jrt.Intern(".clj")

var Lit_43 *jrt.String = jrt.Intern(".cljc")

var Lit_44 *jrt.String = jrt.Intern(" (")

var Lit_45 *jrt.String = jrt.Intern(")")

var Lit_46 *jrt.String = jrt.Intern(".")

var Lit_47 *jrt.String = jrt.Intern("arbace.repl$thread_stopper$fn__1239000079")

var Lit_48 *jrt.String = jrt.Intern("stop")

var Lit_49 *jrt.String = jrt.Intern("kn6,authorkn3,docyn11,arbace.coreyn12,monitor-exitkn5,formsyn1,xkn4,linekn6,columnyn3,tryyn5,expr*yn13,catch-clause*yn15,finally-clause?yn2,doyn6,exprs*yn2,ifyn4,testyn4,thenyn5,else?yn3,newyn10,Classname.yn5,args*yn9,Classnamekn3,urlyn5,recuryn4,set!yn10,var-symbolyn4,expryn1,.yn13,instance-expryn24,instanceFieldName-symbolyn16,Classname-symbolyn22,staticFieldName-symbolyn15,.instanceMemberyn8,instanceys9,Classname12,staticMethodys9,Classname11,staticFieldyn3,varyn6,symbolyn5,quoteyn4,formyn5,throwyn13,monitor-enteryn3,defyn11,doc-string?yn5,init?kn7,privatekn4,filekn8,arglistsyn11,name-symbolyn6,nspaceyn1,nkn2,nsyn2,nmkn4,namekn4,keysyn5,formsyn8,arglistsyn12,special-formyn3,docyn3,urlyn5,macroyn4,speckn2,asyn1,myn20,re-string-or-patternkn5,addedyn4,nameyn14,str-or-patternyn2,nsyn6,nsnameyn7,fn-namekn3,tagyn9,Throwableyn17,StackTraceElementyn10,e-or-depthyn5,depthyn6,threadyn1,fv11,arbace.core5,in-nsMyn11,arbace.replm4,R0,s61,Chris Houser, Christophe Grand, Stephen Gilardi, Michel SalimR1,s52,Utilities meant to be used interactively at the REPLm4,R0,s61,Chris Houser, Christophe Grand, Stephen Gilardi, Michel SalimR1,s52,Utilities meant to be used interactively at the REPLR2,v11,arbace.repl15,special-doc-mapm26,R3,m4,R4,V1,ML2,R3,R5,m4,R6,i43,R7,i27,R1,s89,Synchronization primitive that should be avoided\n  in user code. Use the 'locking' macro.R8,m4,R4,V1,ML4,R8,R9,R10,R11,m4,R6,i66,R7,i18,R1,s120,catch-clause => (catch classname name expr*)\n  finally-clause => (finally expr*)\n\n  Catches and handles Java exceptions.R12,m4,R4,V1,ML2,R12,R13,m4,R6,i33,R7,i17,R1,s116,Evaluates the expressions in order and returns the value of\n  the last. If no expressions are supplied, returns nil.R14,m4,R4,V1,ML4,R14,R15,R16,R17,m4,R6,i36,R7,i17,R1,s169,Evaluates test. If not the singular values nil or false,\n  evaluates and yields then, otherwise, evaluates and yields else. If\n  else is not supplied it defaults to nil.R18,m6,R4,V2,ML2,R19,R20,m4,R6,i46,R7,i18,ML3,R18,R21,R20,m4,R6,i46,R7,i37,R22,s16,java_interop#newR1,s154,The args, if any, are evaluated from left to right, and\n  passed to the constructor of the class named by Classname. The\n  constructed object is returned.R23,m4,R4,V1,ML2,R23,R13,m4,R6,i53,R7,i20,R1,s195,Evaluates the exprs in order, then, in parallel, rebinds\n  the bindings of the recursion point to the values of the exprs.\n  Execution then jumps back to the recursion point, a loop or fn method.R24,m6,R4,V3,ML3,R24,R25,R26,m4,R6,i57,R7,i18,ML3,R24,ML3,R27,R28,R29,m4,R6,i58,R7,i24,R26,m4,R6,i58,R7,i18,ML3,R24,ML3,R27,R30,R31,m4,R6,i59,R7,i24,R26,m4,R6,i59,R7,i18,R22,s8,vars#setR1,s95,Used to set thread-local-bound vars, Java object instance\nfields, and Java class static fields.R27,m6,R22,s16,java_interop#dotR4,V4,ML3,R32,R33,R20,m4,R6,i21,R7,i16,ML3,R32,R21,R20,m4,R6,i22,R7,i16,ML2,R34,R20,m4,R6,i23,R7,i16,R35,R1,s132,The instance member form works for both fields and methods.\n  They all expand into calls to the dot operator at macroexpansion time.R36,m4,R4,V1,ML2,R36,R37,m4,R6,i71,R7,i18,R1,s129,The symbol must resolve to a var, and the Var object\nitself (not its value) is returned. The reader macro #'x expands to (var x).R38,m4,R4,V1,ML2,R38,R39,m4,R6,i51,R7,i20,R1,s28,Yields the unevaluated form.R40,m4,R4,V1,ML2,R40,R26,m4,R6,i63,R7,i20,R1,s103,The expr is evaluated and thrown, therefore it should\n  yield an instance of some derivee of Throwable.R41,m4,R4,V1,ML2,R41,R5,m4,R6,i40,R7,i28,R1,s89,Synchronization primitive that should be avoided\n  in user code. Use the 'locking' macro.R42,m4,R4,V1,ML4,R42,R37,R43,R44,m4,R6,i27,R7,i18,R1,s311,Creates and interns a global var with the name\n  of symbol in the current namespace (*ns*) or locates such a var if\n  it already exists.  If init is supplied, it is evaluated, and the\n  root binding of the var is set to the resulting value.  If init is\n  not supplied, the root binding of the var is unaffected.m8,R45,TR6,i19,R7,i1,R46,s14,arbace/repl.aev11,arbace.repl11,special-docm10,R45,TR47,L1,V1,R48,R6,i75,R7,i1,R46,s14,arbace/repl.aev11,arbace.repl13,namespace-docm10,R45,TR47,L1,V1,R49,R6,i80,R7,i1,R46,s14,arbace/repl.aev11,arbace.repl9,print-docm10,R45,TR47,L1,V1,m8,R50,R51,R52,R53,R54,V7,R55,R56,R57,R58,R59,R60,R61,R62,R63,R6,i83,R7,i1,R46,s14,arbace/repl.aev11,arbace.repl8,find-docm12,R47,L1,V1,R64,R1,s103,Prints documentation for any var whose documentation or name\n contains a match for re-string-or-patternR65,s3,1.0R6,i115,R7,i1,R46,s14,arbace/repl.aev11,arbace.repl3,docm12,R47,L1,V1,R66,R1,s98,Prints documentation for a var or special form given its name,\n   or for a spec if given a keywordR65,s3,1.0R6,i131,R7,i1,R46,s14,arbace/repl.aev11,arbace.repl9,source-fnm10,R47,L1,V1,R5,R1,s329,Returns a string of the source code for the given symbol, if it can\n  find it.  This requires that the symbol resolve to a Var defined in\n  a namespace for which the .ae (or .clj) is in the classpath.  Returns nil if\n  it can't find the source.  For most REPL usage, 'source' is more\n  convenient.\n\n  Example: (source-fn 'filter)R6,i147,R7,i1,R46,s14,arbace/repl.aev11,arbace.core15,get-proxy-classC22,java.io.PushbackReaderv11,arbace.repl6,sourcem10,R47,L1,V1,R50,R1,s214,Prints the source code for the given symbol, if it can find it.\n  This requires that the symbol resolve to a Var defined in a\n  namespace for which the .ae (or .clj) is in the classpath.\n\n  Example: (source filter)R6,i172,R7,i1,R46,s14,arbace/repl.aev11,arbace.repl7,aproposm10,R47,L1,V1,R67,R1,s152,Given a regular expression or stringable thing, return a seq of all\npublic definitions in all currently-loaded namespaces that match the\nstr-or-pattern.R6,i181,R7,i1,R46,s14,arbace/repl.aev11,arbace.repl6,dir-fnm10,R47,L1,V1,R68,R1,s113,Returns a sorted seq of symbols naming public vars in\n  a namespace or namespace alias. Looks for aliases in *ns*R6,i195,R7,i1,R46,s14,arbace/repl.aev11,arbace.repl3,dirm10,R47,L1,V1,R69,R1,s55,Prints a sorted directory of public vars in a namespaceR6,i201,R7,i1,R46,s14,arbace/repl.aev11,arbace.repl7,demungem12,R47,L1,V1,R70,R1,s103,Given a string representation of a fn class,\n  as in a stack trace element, returns a readable version.R65,s3,1.3R6,i207,R7,i1,R46,s14,arbace/repl.aev11,arbace.repl10,root-causem12,R47,L1,V1,Myn1,tm2,R71,R72,R1,s87,Returns the initial cause of an exception or error by peeling off all of\n  its wrappersR65,s3,1.3R6,i214,R7,i1,R46,s14,arbace/repl.aev11,arbace.repl17,stack-element-strm12,R47,L1,V1,Myn2,elm2,R71,R73,R1,s74,Returns a (possibly unmunged) string representation of a StackTraceElementR65,s3,1.3R6,i227,R7,i1,R46,s14,arbace/repl.aev11,arbace.repl3,pstm12,R47,L3,V0,V1,R74,V2,Myn1,em2,R71,R72,R75,R1,s161,Prints a stack trace of the exception, to the depth requested. If none supplied, uses the root cause of the\n  most recent repl exception (*e), and a depth of 12.R65,s3,1.3R6,i241,R7,i1,R46,s14,arbace/repl.aev11,arbace.repl14,thread-stopperm10,R47,L2,V0,V1,R76,R1,s135,Returns a function that takes one arg and uses that as an exception message\n  to stop the given thread.  Defaults to the current threadR6,i274,R7,i1,R46,s14,arbace/repl.aev11,arbace.repl18,set-break-handler!m10,R47,L2,V0,V1,R77,R1,s183,Register INT signal handler.  After calling this, Ctrl-C will cause\n  the given function f to be called with a single argument, the signal.\n  Uses thread-stopper if no function given.R6,i280,R7,i1,R46,s14,arbace/repl.aeC16,java.lang.Object")

var Lit_50 *jrt.String = jrt.Intern("arbace.repl$eval1239000004$loading__1927001464__auto____1239000005")

var Lit_51 *jrt.String = jrt.Intern("arbace.repl$eval1239000008$fn__1239000009")

var Lit_52 *jrt.String = jrt.Intern("arbace.repl$special_doc")

var Lit_53 *jrt.String = jrt.Intern("arbace.repl$namespace_doc")

var Lit_54 *jrt.String = jrt.Intern("arbace.repl$print_doc")

var Lit_55 *jrt.String = jrt.Intern("arbace.repl$find_doc")

var Lit_56 *jrt.String = jrt.Intern("arbace.repl$doc")

var Lit_57 *jrt.String = jrt.Intern("arbace.repl$source_fn")

var Lit_58 *jrt.String = jrt.Intern("arbace.repl$source")

var Lit_59 *jrt.String = jrt.Intern("arbace.repl$apropos")

var Lit_60 *jrt.String = jrt.Intern("arbace.repl$dir_fn")

var Lit_61 *jrt.String = jrt.Intern("arbace.repl$dir")

var Lit_62 *jrt.String = jrt.Intern("arbace.repl$demunge")

var Lit_63 *jrt.String = jrt.Intern("arbace.repl$root_cause")

var Lit_64 *jrt.String = jrt.Intern("arbace.repl$stack_element_str")

var Lit_65 *jrt.String = jrt.Intern("arbace.repl$pst")

var Lit_66 *jrt.String = jrt.Intern("arbace.repl$thread_stopper")

var Lit_67 *jrt.String = jrt.Intern("sun.misc.SignalHandler")

var Lit_68 *jrt.String = jrt.Intern("arbace.repl$set_break_handler_BANG_")
