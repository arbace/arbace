//line a2g_strings.ae:1
package aot_arbace_repl

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("require")

var Lit_3 *jrt.String = jrt.Intern("arbace.spec.alpha")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("spec")

var Lit_6 *jrt.String = jrt.Intern("commute")

var Lit_7 *jrt.String = jrt.Intern("deref")

var Lit_8 *jrt.String = jrt.Intern("conj")

var Lit_9 *jrt.String = jrt.Intern("arbace.repl")

var Lit_10 *jrt.String = jrt.Intern("author")

var Lit_11 *jrt.String = jrt.Intern("Chris Houser, Christophe Grand, Stephen Gilardi, Michel Salim")

var Lit_12 *jrt.String = jrt.Intern("doc")

var Lit_13 *jrt.String = jrt.Intern("Utilities meant to be used interactively at the REPL")

var Lit_14 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_15 *jrt.String = jrt.Intern("assoc")

var Lit_16 *jrt.String = jrt.Intern("special-doc-map")

var Lit_17 *jrt.String = jrt.Intern("resolve")

var Lit_18 *jrt.String = jrt.Intern("name")

var Lit_19 *jrt.String = jrt.Intern("special-form")

var Lit_20 *jrt.String = jrt.Intern("ns-name")

var Lit_21 *jrt.String = jrt.Intern("next")

var Lit_22 *jrt.String = jrt.Intern("to-array")

var Lit_23 *jrt.String = jrt.Intern("seq")

var Lit_24 *jrt.String = jrt.Intern("first")

var Lit_25 *jrt.String = jrt.Intern("ns")

var Lit_26 *jrt.String = jrt.Intern("forms")

var Lit_27 *jrt.String = jrt.Intern("arglists")

var Lit_28 *jrt.String = jrt.Intern("url")

var Lit_29 *jrt.String = jrt.Intern("macro")

var Lit_30 *jrt.String = jrt.Intern("get-spec")

var Lit_31 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_32 *jrt.String = jrt.Intern("chunk-first")

var Lit_33 *jrt.String = jrt.Intern("println")

var Lit_34 *jrt.String = jrt.Intern("prn")

var Lit_35 *jrt.String = jrt.Intern("contains?")

var Lit_36 *jrt.String = jrt.Intern("print")

var Lit_37 *jrt.String = jrt.Intern("chunk-rest")

var Lit_38 *jrt.String = jrt.Intern("symbol")

var Lit_39 *jrt.String = jrt.Intern("str")

var Lit_40 *jrt.String = jrt.Intern("args")

var Lit_41 *jrt.String = jrt.Intern("ret")

var Lit_42 *jrt.String = jrt.Intern("fn")

var Lit_43 *jrt.String = jrt.Intern("describe")

var Lit_44 *jrt.String = jrt.Intern("re-pattern")

var Lit_45 *jrt.String = jrt.Intern("concat")

var Lit_46 *jrt.String = jrt.Intern("re-find")

var Lit_47 *jrt.String = jrt.Intern("mapcat")

var Lit_48 *jrt.String = jrt.Intern("map")

var Lit_49 *jrt.String = jrt.Intern("sort-by")

var Lit_50 *jrt.String = jrt.Intern("meta")

var Lit_51 *jrt.String = jrt.Intern("vals")

var Lit_52 *jrt.String = jrt.Intern("ns-interns")

var Lit_53 *jrt.String = jrt.Intern("all-ns")

var Lit_54 *jrt.String = jrt.Intern("namespace-doc")

var Lit_55 *jrt.String = jrt.Intern("special-doc")

var Lit_56 *jrt.String = jrt.Intern("keys")

var Lit_57 *jrt.String = jrt.Intern("re-matcher")

var Lit_58 *jrt.String = jrt.Intern("print-doc")

var Lit_59 *jrt.String = jrt.Intern("&")

var Lit_60 *jrt.String = jrt.Intern("catch")

var Lit_61 *jrt.String = jrt.Intern("try")

var Lit_62 *jrt.String = jrt.Intern("finally")

var Lit_63 *jrt.String = jrt.Intern("keyword?")

var Lit_64 *jrt.String = jrt.Intern("find-ns")

var Lit_65 *jrt.String = jrt.Intern("list")

var Lit_66 *jrt.String = jrt.Intern("var")

var Lit_67 *jrt.String = jrt.Intern("quote")

var Lit_68 *jrt.String = jrt.Intern("apply")

var Lit_69 *jrt.String = jrt.Intern("hash-map")

var Lit_70 *jrt.String = jrt.Intern("file")

var Lit_71 *jrt.String = jrt.Intern("java.lang.ClassLoader")

var Lit_72 *jrt.String = jrt.Intern("read-cond")

var Lit_73 *jrt.String = jrt.Intern("allow")

var Lit_74 *jrt.String = jrt.Intern("line")

var Lit_75 *jrt.String = jrt.Intern("init-proxy")

var Lit_76 *jrt.String = jrt.Intern("proxy-call-with-super")

var Lit_77 *jrt.String = jrt.Intern("unknown")

var Lit_78 *jrt.String = jrt.Intern("*read-eval*")

var Lit_79 *jrt.String = jrt.Intern("read")

var Lit_80 *jrt.String = jrt.Intern("or")

var Lit_81 *jrt.String = jrt.Intern("source-fn")

var Lit_82 *jrt.String = jrt.Intern("sort")

var Lit_83 *jrt.String = jrt.Intern("filter")

var Lit_84 *jrt.String = jrt.Intern("ns-publics")

var Lit_85 *jrt.String = jrt.Intern("the-ns")

var Lit_86 *jrt.String = jrt.Intern("ns-aliases")

var Lit_87 *jrt.String = jrt.Intern("*ns*")

var Lit_88 *jrt.String = jrt.Intern("doseq")

var Lit_89 *jrt.String = jrt.Intern("vector")

var Lit_90 *jrt.String = jrt.Intern("v__1239000062__auto__")

var Lit_91 *jrt.String = jrt.Intern("dir-fn")

var Lit_92 *jrt.String = jrt.Intern("not=")

var Lit_93 *jrt.String = jrt.Intern("demunge")

var Lit_94 *jrt.String = jrt.Intern("pst")

var Lit_95 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_96 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_97 *jrt.String = jrt.Intern("*out*")

var Lit_98 *jrt.String = jrt.Intern("*err*")

var Lit_99 *jrt.String = jrt.Intern("macro-syntax-check")

var Lit_100 *jrt.String = jrt.Intern("compile-syntax-check")

var Lit_101 *jrt.String = jrt.Intern("read-source")

var Lit_102 *jrt.String = jrt.Intern("macroexpansion")

var Lit_103 *jrt.String = jrt.Intern("compilation")

var Lit_104 *jrt.String = jrt.Intern("arbace.error")

var Lit_105 *jrt.String = jrt.Intern("phase")

var Lit_106 *jrt.String = jrt.Intern("ex-data")

var Lit_107 *jrt.String = jrt.Intern("class")

var Lit_108 *jrt.String = jrt.Intern("pr-str")

var Lit_109 *jrt.String = jrt.Intern("take")

var Lit_110 *jrt.String = jrt.Intern("remove")

var Lit_111 *jrt.String = jrt.Intern("arbace.lang.AFn")

var Lit_112 *jrt.String = jrt.Intern("arbace.lang.RestFn")

var Lit_113 *jrt.String = jrt.Intern("stack-element-str")

var Lit_114 *jrt.String = jrt.Intern("*e")

var Lit_115 *jrt.String = jrt.Intern("root-cause")

var Lit_116 *jrt.String = jrt.Intern("java.lang.Error")

var Lit_117 *jrt.String = jrt.Intern("thread-stopper")

var Lit_118 *jrt.String = jrt.Intern("set-break-handler!")

var Lit_119 *jrt.String = jrt.Intern("arbace.repl$apropos")

var Lit_120 *jrt.String = jrt.Intern("arbace.repl$apropos$fn__1239000052")

var Lit_121 *jrt.String = jrt.Intern("arbace.repl$apropos$fn__1239000054")

var Lit_122 *jrt.String = jrt.Intern("arbace.repl$apropos$fn__1239000056")

var Lit_123 *jrt.String = jrt.Intern("arbace.repl$apropos$fn__1239000056$fn__1239000057")

var Lit_124 *jrt.String = jrt.Intern("arbace.repl$demunge")

var Lit_125 *jrt.String = jrt.Intern("arbace.repl$dir")

var Lit_126 *jrt.String = jrt.Intern("arbace.repl$dir_fn")

var Lit_127 *jrt.String = jrt.Intern("arbace.repl$doc")

var Lit_128 *jrt.String = jrt.Intern("arbace.repl$eval1239000004$loading__1927001464__auto____1239000005")

var Lit_129 *jrt.String = jrt.Intern("java.io.LineNumberReader")

var Lit_130 *jrt.String = jrt.Intern("java.io.InputStreamReader")

var Lit_131 *jrt.String = jrt.Intern("java.io.PushbackReader")

var Lit_132 *jrt.String = jrt.Intern("arbace.lang.RT")

var Lit_133 *jrt.String = jrt.Intern("arbace.lang.Reflector")

var Lit_134 *jrt.String = jrt.Intern("arbace.repl$eval1239000008$fn__1239000009")

var Lit_135 *jrt.String = jrt.Intern("arbace.repl$find_doc")

var Lit_136 *jrt.String = jrt.Intern("arbace.repl$find_doc$fn__1239000027")

var Lit_137 *jrt.String = jrt.Intern("arbace.repl$namespace_doc")

var Lit_138 *jrt.String = jrt.Intern("arbace.repl$print_doc")

var Lit_139 *jrt.String = jrt.Intern("-------------------------")

var Lit_140 *jrt.String = jrt.Intern("/")

var Lit_141 *jrt.String = jrt.Intern("  ")

var Lit_142 *jrt.String = jrt.Intern("Special Form")

var Lit_143 *jrt.String = jrt.Intern("Macro")

var Lit_144 *jrt.String = jrt.Intern("Spec")

var Lit_145 *jrt.String = jrt.Intern(" ")

var Lit_146 *jrt.String = jrt.Intern("\n  Please see http://clojure.org/")

var Lit_147 *jrt.String = jrt.Intern("\n  Please see http://clojure.org/special_forms#")

var Lit_148 *jrt.String = jrt.Intern(":")

var Lit_149 *jrt.String = jrt.Intern("arbace.repl$pst")

var Lit_150 *jrt.String = jrt.Intern("Note: The following stack trace applies to the reader or compiler, your code was not executed.")

var Lit_151 *jrt.String = jrt.Intern("\t")

var Lit_152 *jrt.String = jrt.Intern("Caused by:")

var Lit_153 *jrt.String = jrt.Intern("arbace.repl$pst$fn__1239000076")

var Lit_154 *jrt.String = jrt.Intern("getClassName")

var Lit_155 *jrt.String = jrt.Intern("arbace.repl$root_cause")

var Lit_156 *jrt.String = jrt.Intern("NO_SOURCE_FILE")

var Lit_157 *jrt.String = jrt.Intern("arbace.repl$set_break_handler_BANG_")

var Lit_158 *jrt.String = jrt.Intern("sun.misc.Signal")

var Lit_159 *jrt.String = jrt.Intern("handle")

var Lit_160 *jrt.String = jrt.Intern("INT")

var Lit_161 *jrt.String = jrt.Intern("arbace.repl.proxy$java.lang.Object$SignalHandler$d8c00ec7")

var Lit_162 *jrt.String = jrt.Intern("arbace.repl$set_break_handler_BANG_$fn__1239000082")

var Lit_163 *jrt.String = jrt.Intern("-- caught signal ")

var Lit_164 *jrt.String = jrt.Intern("arbace.repl$source")

var Lit_165 *jrt.String = jrt.Intern("Source not found")

var Lit_166 *jrt.String = jrt.Intern("arbace.repl$source_fn")

var Lit_167 *jrt.String = jrt.Intern("getResourceAsStream")

var Lit_168 *jrt.String = jrt.Intern("arbace.repl.proxy$java.io.PushbackReader$ff19274a")

var Lit_169 *jrt.String = jrt.Intern("cljc")

var Lit_170 *jrt.String = jrt.Intern("Unable to read source while *read-eval* is :unknown.")

var Lit_171 *jrt.String = jrt.Intern("arbace.repl$source_fn$fn__1239000039")

var Lit_172 *jrt.String = jrt.Intern("arbace.repl$source_fn$fn__1239000039$fn__1239000040")

var Lit_173 *jrt.String = jrt.Intern("arbace.repl$special_doc")

var Lit_174 *jrt.String = jrt.Intern("arbace.repl$stack_element_str")

var Lit_175 *jrt.String = jrt.Intern(".ae")

var Lit_176 *jrt.String = jrt.Intern(".clj")

var Lit_177 *jrt.String = jrt.Intern(".cljc")

var Lit_178 *jrt.String = jrt.Intern(" (")

var Lit_179 *jrt.String = jrt.Intern(")")

var Lit_180 *jrt.String = jrt.Intern(".")

var Lit_181 *jrt.String = jrt.Intern("arbace.repl$thread_stopper")

var Lit_182 *jrt.String = jrt.Intern("arbace.repl$thread_stopper$fn__1239000079")

var Lit_183 *jrt.String = jrt.Intern("stop")

var Lit_184 *jrt.String = jrt.Intern("in-ns")

var Lit_185 *jrt.String = jrt.Intern("monitor-exit")

var Lit_186 *jrt.String = jrt.Intern("x")

var Lit_187 *jrt.String = jrt.Intern("column")

var Lit_188 *jrt.String = jrt.Intern("Synchronization primitive that should be avoided\n  in user code. Use the 'locking' macro.")

var Lit_189 *jrt.String = jrt.Intern("expr*")

var Lit_190 *jrt.String = jrt.Intern("catch-clause*")

var Lit_191 *jrt.String = jrt.Intern("finally-clause?")

var Lit_192 *jrt.String = jrt.Intern("catch-clause => (catch classname name expr*)\n  finally-clause => (finally expr*)\n\n  Catches and handles Java exceptions.")

var Lit_193 *jrt.String = jrt.Intern("do")

var Lit_194 *jrt.String = jrt.Intern("exprs*")

var Lit_195 *jrt.String = jrt.Intern("Evaluates the expressions in order and returns the value of\n  the last. If no expressions are supplied, returns nil.")

var Lit_196 *jrt.String = jrt.Intern("if")

var Lit_197 *jrt.String = jrt.Intern("test")

var Lit_198 *jrt.String = jrt.Intern("then")

var Lit_199 *jrt.String = jrt.Intern("else?")

var Lit_200 *jrt.String = jrt.Intern("Evaluates test. If not the singular values nil or false,\n  evaluates and yields then, otherwise, evaluates and yields else. If\n  else is not supplied it defaults to nil.")

var Lit_201 *jrt.String = jrt.Intern("new")

var Lit_202 *jrt.String = jrt.Intern("Classname.")

var Lit_203 *jrt.String = jrt.Intern("args*")

var Lit_204 *jrt.String = jrt.Intern("Classname")

var Lit_205 *jrt.String = jrt.Intern("java_interop#new")

var Lit_206 *jrt.String = jrt.Intern("The args, if any, are evaluated from left to right, and\n  passed to the constructor of the class named by Classname. The\n  constructed object is returned.")

var Lit_207 *jrt.String = jrt.Intern("recur")

var Lit_208 *jrt.String = jrt.Intern("Evaluates the exprs in order, then, in parallel, rebinds\n  the bindings of the recursion point to the values of the exprs.\n  Execution then jumps back to the recursion point, a loop or fn method.")

var Lit_209 *jrt.String = jrt.Intern("set!")

var Lit_210 *jrt.String = jrt.Intern("var-symbol")

var Lit_211 *jrt.String = jrt.Intern("expr")

var Lit_212 *jrt.String = jrt.Intern("instance-expr")

var Lit_213 *jrt.String = jrt.Intern("instanceFieldName-symbol")

var Lit_214 *jrt.String = jrt.Intern("Classname-symbol")

var Lit_215 *jrt.String = jrt.Intern("staticFieldName-symbol")

var Lit_216 *jrt.String = jrt.Intern("vars#set")

var Lit_217 *jrt.String = jrt.Intern("Used to set thread-local-bound vars, Java object instance\nfields, and Java class static fields.")

var Lit_218 *jrt.String = jrt.Intern("java_interop#dot")

var Lit_219 *jrt.String = jrt.Intern(".instanceMember")

var Lit_220 *jrt.String = jrt.Intern("instance")

var Lit_221 *jrt.String = jrt.Intern("staticMethod")

var Lit_222 *jrt.String = jrt.Intern("staticField")

var Lit_223 *jrt.String = jrt.Intern("The instance member form works for both fields and methods.\n  They all expand into calls to the dot operator at macroexpansion time.")

var Lit_224 *jrt.String = jrt.Intern("The symbol must resolve to a var, and the Var object\nitself (not its value) is returned. The reader macro #'x expands to (var x).")

var Lit_225 *jrt.String = jrt.Intern("form")

var Lit_226 *jrt.String = jrt.Intern("Yields the unevaluated form.")

var Lit_227 *jrt.String = jrt.Intern("throw")

var Lit_228 *jrt.String = jrt.Intern("The expr is evaluated and thrown, therefore it should\n  yield an instance of some derivee of Throwable.")

var Lit_229 *jrt.String = jrt.Intern("monitor-enter")

var Lit_230 *jrt.String = jrt.Intern("def")

var Lit_231 *jrt.String = jrt.Intern("doc-string?")

var Lit_232 *jrt.String = jrt.Intern("init?")

var Lit_233 *jrt.String = jrt.Intern("Creates and interns a global var with the name\n  of symbol in the current namespace (*ns*) or locates such a var if\n  it already exists.  If init is supplied, it is evaluated, and the\n  root binding of the var is set to the resulting value.  If init is\n  not supplied, the root binding of the var is unaffected.")

var Lit_234 *jrt.String = jrt.Intern("private")

var Lit_235 *jrt.String = jrt.Intern("arbace/repl.ae")

var Lit_236 *jrt.String = jrt.Intern("name-symbol")

var Lit_237 *jrt.String = jrt.Intern("nspace")

var Lit_238 *jrt.String = jrt.Intern("n")

var Lit_239 *jrt.String = jrt.Intern("nm")

var Lit_240 *jrt.String = jrt.Intern("m")

var Lit_241 *jrt.String = jrt.Intern("find-doc")

var Lit_242 *jrt.String = jrt.Intern("re-string-or-pattern")

var Lit_243 *jrt.String = jrt.Intern("Prints documentation for any var whose documentation or name\n contains a match for re-string-or-pattern")

var Lit_244 *jrt.String = jrt.Intern("added")

var Lit_245 *jrt.String = jrt.Intern("1.0")

var Lit_246 *jrt.String = jrt.Intern("Prints documentation for a var or special form given its name,\n   or for a spec if given a keyword")

var Lit_247 *jrt.String = jrt.Intern("Returns a string of the source code for the given symbol, if it can\n  find it.  This requires that the symbol resolve to a Var defined in\n  a namespace for which the .ae (or .clj) is in the classpath.  Returns nil if\n  it can't find the source.  For most REPL usage, 'source' is more\n  convenient.\n\n  Example: (source-fn 'filter)")

var Lit_248 *jrt.String = jrt.Intern("get-proxy-class")

var Lit_249 *jrt.String = jrt.Intern("source")

var Lit_250 *jrt.String = jrt.Intern("Prints the source code for the given symbol, if it can find it.\n  This requires that the symbol resolve to a Var defined in a\n  namespace for which the .ae (or .clj) is in the classpath.\n\n  Example: (source filter)")

var Lit_251 *jrt.String = jrt.Intern("apropos")

var Lit_252 *jrt.String = jrt.Intern("str-or-pattern")

var Lit_253 *jrt.String = jrt.Intern("Given a regular expression or stringable thing, return a seq of all\npublic definitions in all currently-loaded namespaces that match the\nstr-or-pattern.")

var Lit_254 *jrt.String = jrt.Intern("Returns a sorted seq of symbols naming public vars in\n  a namespace or namespace alias. Looks for aliases in *ns*")

var Lit_255 *jrt.String = jrt.Intern("dir")

var Lit_256 *jrt.String = jrt.Intern("nsname")

var Lit_257 *jrt.String = jrt.Intern("Prints a sorted directory of public vars in a namespace")

var Lit_258 *jrt.String = jrt.Intern("fn-name")

var Lit_259 *jrt.String = jrt.Intern("Given a string representation of a fn class,\n  as in a stack trace element, returns a readable version.")

var Lit_260 *jrt.String = jrt.Intern("1.3")

var Lit_261 *jrt.String = jrt.Intern("t")

var Lit_262 *jrt.String = jrt.Intern("tag")

var Lit_263 *jrt.String = jrt.Intern("Throwable")

var Lit_264 *jrt.String = jrt.Intern("Returns the initial cause of an exception or error by peeling off all of\n  its wrappers")

var Lit_265 *jrt.String = jrt.Intern("el")

var Lit_266 *jrt.String = jrt.Intern("StackTraceElement")

var Lit_267 *jrt.String = jrt.Intern("Returns a (possibly unmunged) string representation of a StackTraceElement")

var Lit_268 *jrt.String = jrt.Intern("e-or-depth")

var Lit_269 *jrt.String = jrt.Intern("e")

var Lit_270 *jrt.String = jrt.Intern("depth")

var Lit_271 *jrt.String = jrt.Intern("Prints a stack trace of the exception, to the depth requested. If none supplied, uses the root cause of the\n  most recent repl exception (*e), and a depth of 12.")

var Lit_272 *jrt.String = jrt.Intern("thread")

var Lit_273 *jrt.String = jrt.Intern("Returns a function that takes one arg and uses that as an exception message\n  to stop the given thread.  Defaults to the current thread")

var Lit_274 *jrt.String = jrt.Intern("f")

var Lit_275 *jrt.String = jrt.Intern("Register INT signal handler.  After calling this, Ctrl-C will cause\n  the given function f to be called with a single argument, the signal.\n  Uses thread-stopper if no function given.")

var Lit_276 *jrt.String = jrt.Intern("java.lang.Object")

var Lit_277 *jrt.String = jrt.Intern("sun.misc.SignalHandler")
