//line aot_arbace_repl__init.ae:1
package aot_arbace_repl

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_repl__init_A_Load__O() any { A_arbace_repl__init_A_Init(); A_arbace_repl__init_A_Unit0__O(); A_arbace_repl__init_A_Unit1__O(); A_arbace_repl__init_A_Unit2__O(); A_arbace_repl__init_A_Unit3__O(); A_arbace_repl__init_A_Unit4__O(); A_arbace_repl__init_A_Unit5__O(); A_arbace_repl__init_A_Unit6__O(); A_arbace_repl__init_A_Unit7__O(); A_arbace_repl__init_A_Unit8__O(); A_arbace_repl__init_A_Unit9__O(); A_arbace_repl__init_A_Unit10__O(); A_arbace_repl__init_A_Unit11__O(); A_arbace_repl__init_A_Unit12__O(); A_arbace_repl__init_A_Unit13__O(); A_arbace_repl__init_A_Unit14__O(); A_arbace_repl__init_A_Unit15__O(); A_arbace_repl__init_A_Unit16__O(); A_arbace_repl__init_A_Unit17__O(); A_arbace_repl__init_A_Unit18__O(); A_arbace_repl__init_A_Unit19__O(); A_arbace_repl__init_A_Unit20__O(); A_arbace_repl__init_A_Unit21__O(); A_arbace_repl__init_A_Unit22__O(); A_arbace_repl__init_A_Unit23__O(); A_arbace_repl__init_A_Unit24__O(); A_arbace_repl__init_A_Unit25__O(); A_arbace_repl__init_A_Unit26__O(); return nil }





func A_arbace_repl__init_A_Unit0__O() any { A_arbace_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V(11, 1); return lang.IFn_Cast(A_arbace_repl__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repl__init_A_const_1) }
//line :11:1
func A_arbace_repl__init_A_Unit1__O() any { A_arbace_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V(11, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_repl__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_repl__init_A_const_2)) }
//line :11:1
func A_arbace_repl__init_A_Unit2__O() any { A_arbace_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V(11, 1); var tmp1 any = A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_50, false); A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :11:1
func A_arbace_repl__init_A_Unit3__O() any { A_arbace_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V(11, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_repl__init_A_const_1)).Equals_O__Z(A_arbace_repl__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_repl_eval1239000008_fn__1239000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_repl_eval1239000008_fn__1239000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_51, false); A_arbace_repl_eval1239000008_fn__1239000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }







func A_arbace_repl__init_A_Unit4__O() any { A_arbace_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); A_arbace_repl__init_A_const_4.BindRoot_O__V(A_arbace_repl__init_A_const_5); var tmp1 *lang.Var = A_arbace_repl__init_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repl__init_A_const_6)); return A_arbace_repl__init_A_const_4 }























































func A_arbace_repl__init_A_Unit5__O() any { A_arbace_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V(75, 1); var tmp1 *lang.Var = A_arbace_repl__init_A_const_7; var tmp2 any = A_arbace_repl_special_doc_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_repl_special_doc_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_52, false); A_arbace_repl_special_doc_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repl__init_A_const_7; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repl__init_A_const_8)); return A_arbace_repl__init_A_const_7 }




func A_arbace_repl__init_A_Unit6__O() any { A_arbace_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V(80, 1); var tmp1 *lang.Var = A_arbace_repl__init_A_const_9; var tmp2 any = A_arbace_repl_namespace_doc_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_repl_namespace_doc_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_53, false); A_arbace_repl_namespace_doc_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repl__init_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repl__init_A_const_10)); return A_arbace_repl__init_A_const_9 }


func A_arbace_repl__init_A_Unit7__O() any { A_arbace_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V(83, 1); var tmp1 *lang.Var = A_arbace_repl__init_A_const_11; var tmp2 any = A_arbace_repl_print_doc_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_repl_print_doc_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_54, false); A_arbace_repl_print_doc_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repl__init_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repl__init_A_const_12)); return A_arbace_repl__init_A_const_11 }































func A_arbace_repl__init_A_Unit8__O() any { A_arbace_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V(115, 1); var tmp1 *lang.Var = A_arbace_repl__init_A_const_13; var tmp2 any = A_arbace_repl_find_doc_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_repl_find_doc_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_55, false); A_arbace_repl_find_doc_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repl__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repl__init_A_const_14)); return A_arbace_repl__init_A_const_13 }















func A_arbace_repl__init_A_Unit9__O() any { A_arbace_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V(131, 1); var tmp1 *lang.Var = A_arbace_repl__init_A_const_15; var tmp2 any = A_arbace_repl_doc_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_repl_doc_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_56, false); A_arbace_repl_doc_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repl__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repl__init_A_const_16)); return A_arbace_repl__init_A_const_15 }
//line :131:1
func A_arbace_repl__init_A_Unit10__O() any { A_arbace_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V(131, 1); A_arbace_repl__init_A_const_15.SetMacro__V(); return nil }
//line :131:1
func A_arbace_repl__init_A_Unit11__O() any { A_arbace_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V(131, 1); return A_arbace_repl__init_A_const_15 }















func A_arbace_repl__init_A_Unit12__O() any { A_arbace_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V(147, 1); var tmp1 any = A_arbace_repl__init_A_const_20; lang.IFn_Cast(A_arbace_repl__init_A_const_19.GetRawRoot__O()).ApplyTo_ISeq__O(lang.RT_Cons_O_O__ISeq(tmp1, lang.RT_Seq_O__ISeq(jrt.RefArrayOf(jrt.Object_class)))); var tmp2 *lang.Var = A_arbace_repl__init_A_const_17; var tmp3 any = A_arbace_repl_source_fn_A_New(); var tmp4 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_repl_source_fn_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_57, false); A_arbace_repl_source_fn_A_fn_class = fncls__8d; tmp4 = fncls__8d } else { tmp4 = fncls__8 }; tmp2.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)); var tmp5 *lang.Var = A_arbace_repl__init_A_const_17; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repl__init_A_const_18)); return A_arbace_repl__init_A_const_17 }
























func A_arbace_repl__init_A_Unit13__O() any { A_arbace_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V(172, 1); var tmp1 *lang.Var = A_arbace_repl__init_A_const_21; var tmp2 any = A_arbace_repl_source_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_repl_source_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_58, false); A_arbace_repl_source_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repl__init_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repl__init_A_const_22)); return A_arbace_repl__init_A_const_21 }
//line :172:1
func A_arbace_repl__init_A_Unit14__O() any { A_arbace_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V(172, 1); A_arbace_repl__init_A_const_21.SetMacro__V(); return nil }
//line :172:1
func A_arbace_repl__init_A_Unit15__O() any { A_arbace_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V(172, 1); return A_arbace_repl__init_A_const_21 }








func A_arbace_repl__init_A_Unit16__O() any { A_arbace_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V(181, 1); var tmp1 *lang.Var = A_arbace_repl__init_A_const_23; var tmp2 any = A_arbace_repl_apropos_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_repl_apropos_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_59, false); A_arbace_repl_apropos_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repl__init_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repl__init_A_const_24)); return A_arbace_repl__init_A_const_23 }













func A_arbace_repl__init_A_Unit17__O() any { A_arbace_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V(195, 1); var tmp1 *lang.Var = A_arbace_repl__init_A_const_25; var tmp2 any = A_arbace_repl_dir_fn_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_repl_dir_fn_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_60, false); A_arbace_repl_dir_fn_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repl__init_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repl__init_A_const_26)); return A_arbace_repl__init_A_const_25 }





func A_arbace_repl__init_A_Unit18__O() any { A_arbace_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V(201, 1); var tmp1 *lang.Var = A_arbace_repl__init_A_const_27; var tmp2 any = A_arbace_repl_dir_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_repl_dir_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_61, false); A_arbace_repl_dir_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repl__init_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repl__init_A_const_28)); return A_arbace_repl__init_A_const_27 }
//line :201:1
func A_arbace_repl__init_A_Unit19__O() any { A_arbace_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V(201, 1); A_arbace_repl__init_A_const_27.SetMacro__V(); return nil }
//line :201:1
func A_arbace_repl__init_A_Unit20__O() any { A_arbace_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V(201, 1); return A_arbace_repl__init_A_const_27 }





func A_arbace_repl__init_A_Unit21__O() any { A_arbace_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V(207, 1); var tmp1 *lang.Var = A_arbace_repl__init_A_const_29; var tmp2 any = A_arbace_repl_demunge_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_repl_demunge_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_62, false); A_arbace_repl_demunge_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repl__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repl__init_A_const_30)); return A_arbace_repl__init_A_const_29 }






func A_arbace_repl__init_A_Unit22__O() any { A_arbace_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V(214, 1); var tmp1 *lang.Var = A_arbace_repl__init_A_const_31; var tmp2 any = A_arbace_repl_root_cause_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_repl_root_cause_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_63, false); A_arbace_repl_root_cause_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repl__init_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repl__init_A_const_32)); return A_arbace_repl__init_A_const_31 }












func A_arbace_repl__init_A_Unit23__O() any { A_arbace_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V(227, 1); var tmp1 *lang.Var = A_arbace_repl__init_A_const_33; var tmp2 any = A_arbace_repl_stack_element_str_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_repl_stack_element_str_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_64, false); A_arbace_repl_stack_element_str_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repl__init_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repl__init_A_const_34)); return A_arbace_repl__init_A_const_33 }













func A_arbace_repl__init_A_Unit24__O() any { A_arbace_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V(241, 1); var tmp1 *lang.Var = A_arbace_repl__init_A_const_35; var tmp2 any = A_arbace_repl_pst_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_repl_pst_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_65, false); A_arbace_repl_pst_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repl__init_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repl__init_A_const_36)); return A_arbace_repl__init_A_const_35 }
































func A_arbace_repl__init_A_Unit25__O() any { A_arbace_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V(274, 1); var tmp1 *lang.Var = A_arbace_repl__init_A_const_37; var tmp2 any = A_arbace_repl_thread_stopper_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_repl_thread_stopper_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_66, false); A_arbace_repl_thread_stopper_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repl__init_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repl__init_A_const_38)); return A_arbace_repl__init_A_const_37 }





func A_arbace_repl__init_A_Unit26__O() any { A_arbace_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V(280, 1); var tmp1 any = A_arbace_repl__init_A_const_41; lang.IFn_Cast(A_arbace_repl__init_A_const_19.GetRawRoot__O()).ApplyTo_ISeq__O(lang.RT_Cons_O_O__ISeq(tmp1, lang.RT_Seq_O__ISeq(jrt.RefArrayOf(jrt.Object_class, lang.RT_ClassForNameNonLoading_String__Class(Lit_67).Ref())))); var tmp2 *lang.Var = A_arbace_repl__init_A_const_39; var tmp3 any = A_arbace_repl_set_break_handler_BANG__A_New(); var tmp4 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_repl_set_break_handler_BANG__A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_68, false); A_arbace_repl_set_break_handler_BANG__A_fn_class = fncls__18d; tmp4 = fncls__18d } else { tmp4 = fncls__18 }; tmp2.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)); var tmp5 *lang.Var = A_arbace_repl__init_A_const_39; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repl__init_A_const_40)); return A_arbace_repl__init_A_const_39 }



type A_arbace_repl__init_A struct{ jrt.Object }

var A_arbace_repl__init_A_const_pool *jrt.RefArray

var A_arbace_repl__init_A_const_0 *lang.Var

var A_arbace_repl__init_A_const_1 any

var A_arbace_repl__init_A_const_2 any

var A_arbace_repl__init_A_const_3 any

var A_arbace_repl__init_A_const_4 *lang.Var

var A_arbace_repl__init_A_const_5 any

var A_arbace_repl__init_A_const_6 any

var A_arbace_repl__init_A_const_7 *lang.Var

var A_arbace_repl__init_A_const_8 any

var A_arbace_repl__init_A_const_9 *lang.Var

var A_arbace_repl__init_A_const_10 any

var A_arbace_repl__init_A_const_11 *lang.Var

var A_arbace_repl__init_A_const_12 any

var A_arbace_repl__init_A_const_13 *lang.Var

var A_arbace_repl__init_A_const_14 any

var A_arbace_repl__init_A_const_15 *lang.Var

var A_arbace_repl__init_A_const_16 any

var A_arbace_repl__init_A_const_17 *lang.Var

var A_arbace_repl__init_A_const_18 any

var A_arbace_repl__init_A_const_19 *lang.Var

var A_arbace_repl__init_A_const_20 *jrt.Class

var A_arbace_repl__init_A_const_21 *lang.Var

var A_arbace_repl__init_A_const_22 any

var A_arbace_repl__init_A_const_23 *lang.Var

var A_arbace_repl__init_A_const_24 any

var A_arbace_repl__init_A_const_25 *lang.Var

var A_arbace_repl__init_A_const_26 any

var A_arbace_repl__init_A_const_27 *lang.Var

var A_arbace_repl__init_A_const_28 any

var A_arbace_repl__init_A_const_29 *lang.Var

var A_arbace_repl__init_A_const_30 any

var A_arbace_repl__init_A_const_31 *lang.Var

var A_arbace_repl__init_A_const_32 any

var A_arbace_repl__init_A_const_33 *lang.Var

var A_arbace_repl__init_A_const_34 any

var A_arbace_repl__init_A_const_35 *lang.Var

var A_arbace_repl__init_A_const_36 any

var A_arbace_repl__init_A_const_37 *lang.Var

var A_arbace_repl__init_A_const_38 any

var A_arbace_repl__init_A_const_39 *lang.Var

var A_arbace_repl__init_A_const_40 any

var A_arbace_repl__init_A_const_41 *jrt.Class

var A_arbace_repl__init_A_init jrt.ClassInit

func A_arbace_repl__init_A_Init() { if !A_arbace_repl__init_A_init.Done() { A_arbace_repl__init_A_init.Run(A_arbace_repl__init_A_clinit) } }

func A_arbace_repl__init_A_clinit() { A_arbace_repl__init_A_clinit_p0(); A_arbace_repl__init_A_clinit_p1(); A_arbace_repl__init_A_clinit_p2(); A_arbace_repl__init_A_clinit_p3() }

func A_arbace_repl__init_A_clinit_p0() { A_arbace_repl__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_49, 120); A_arbace_repl__init_A_const_0 = lang.Var_Cast(A_arbace_repl__init_A_const_pool.A[78]); A_arbace_repl__init_A_const_1 = A_arbace_repl__init_A_const_pool.A[79]; A_arbace_repl__init_A_const_2 = A_arbace_repl__init_A_const_pool.A[80]; A_arbace_repl__init_A_const_3 = A_arbace_repl__init_A_const_pool.A[81]; A_arbace_repl__init_A_const_4 = lang.Var_Cast(A_arbace_repl__init_A_const_pool.A[82]); A_arbace_repl__init_A_const_5 = A_arbace_repl__init_A_const_pool.A[83]; A_arbace_repl__init_A_const_6 = A_arbace_repl__init_A_const_pool.A[84]; A_arbace_repl__init_A_const_7 = lang.Var_Cast(A_arbace_repl__init_A_const_pool.A[85]); A_arbace_repl__init_A_const_8 = A_arbace_repl__init_A_const_pool.A[86]; A_arbace_repl__init_A_const_9 = lang.Var_Cast(A_arbace_repl__init_A_const_pool.A[87]); A_arbace_repl__init_A_const_10 = A_arbace_repl__init_A_const_pool.A[88]; A_arbace_repl__init_A_const_11 = lang.Var_Cast(A_arbace_repl__init_A_const_pool.A[89]); A_arbace_repl__init_A_const_12 = A_arbace_repl__init_A_const_pool.A[90] }

func A_arbace_repl__init_A_clinit_p1() { A_arbace_repl__init_A_const_13 = lang.Var_Cast(A_arbace_repl__init_A_const_pool.A[91]); A_arbace_repl__init_A_const_14 = A_arbace_repl__init_A_const_pool.A[92]; A_arbace_repl__init_A_const_15 = lang.Var_Cast(A_arbace_repl__init_A_const_pool.A[93]); A_arbace_repl__init_A_const_16 = A_arbace_repl__init_A_const_pool.A[94]; A_arbace_repl__init_A_const_17 = lang.Var_Cast(A_arbace_repl__init_A_const_pool.A[95]); A_arbace_repl__init_A_const_18 = A_arbace_repl__init_A_const_pool.A[96]; A_arbace_repl__init_A_const_19 = lang.Var_Cast(A_arbace_repl__init_A_const_pool.A[97]); A_arbace_repl__init_A_const_20 = jrt.Class_Cast(A_arbace_repl__init_A_const_pool.A[98]); A_arbace_repl__init_A_const_21 = lang.Var_Cast(A_arbace_repl__init_A_const_pool.A[99]); A_arbace_repl__init_A_const_22 = A_arbace_repl__init_A_const_pool.A[100]; A_arbace_repl__init_A_const_23 = lang.Var_Cast(A_arbace_repl__init_A_const_pool.A[101]); A_arbace_repl__init_A_const_24 = A_arbace_repl__init_A_const_pool.A[102]; A_arbace_repl__init_A_const_25 = lang.Var_Cast(A_arbace_repl__init_A_const_pool.A[103]) }

func A_arbace_repl__init_A_clinit_p2() { A_arbace_repl__init_A_const_26 = A_arbace_repl__init_A_const_pool.A[104]; A_arbace_repl__init_A_const_27 = lang.Var_Cast(A_arbace_repl__init_A_const_pool.A[105]); A_arbace_repl__init_A_const_28 = A_arbace_repl__init_A_const_pool.A[106]; A_arbace_repl__init_A_const_29 = lang.Var_Cast(A_arbace_repl__init_A_const_pool.A[107]); A_arbace_repl__init_A_const_30 = A_arbace_repl__init_A_const_pool.A[108]; A_arbace_repl__init_A_const_31 = lang.Var_Cast(A_arbace_repl__init_A_const_pool.A[109]); A_arbace_repl__init_A_const_32 = A_arbace_repl__init_A_const_pool.A[110]; A_arbace_repl__init_A_const_33 = lang.Var_Cast(A_arbace_repl__init_A_const_pool.A[111]); A_arbace_repl__init_A_const_34 = A_arbace_repl__init_A_const_pool.A[112]; A_arbace_repl__init_A_const_35 = lang.Var_Cast(A_arbace_repl__init_A_const_pool.A[113]); A_arbace_repl__init_A_const_36 = A_arbace_repl__init_A_const_pool.A[114]; A_arbace_repl__init_A_const_37 = lang.Var_Cast(A_arbace_repl__init_A_const_pool.A[115]); A_arbace_repl__init_A_const_38 = A_arbace_repl__init_A_const_pool.A[116] }

func A_arbace_repl__init_A_clinit_p3() { A_arbace_repl__init_A_const_39 = lang.Var_Cast(A_arbace_repl__init_A_const_pool.A[117]); A_arbace_repl__init_A_const_40 = A_arbace_repl__init_A_const_pool.A[118]; A_arbace_repl__init_A_const_41 = jrt.Class_Cast(A_arbace_repl__init_A_const_pool.A[119]) }

func A_arbace_repl__init_A_New() *A_arbace_repl__init_A { A_arbace_repl__init_A_Init(); t := &A_arbace_repl__init_A{}; t.Ctor(); return t }

func (t *A_arbace_repl__init_A) Ctor() {}

func (t *A_arbace_repl__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repl__init_A) GetClass__Class() *jrt.Class { return A_arbace_repl__init_A_class }

func (t *A_arbace_repl__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repl__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_repl__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repl__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repl__init_A); return ok }

func A_arbace_repl__init_A_Cast(x any) *A_arbace_repl__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repl__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repl__init_A_class)) }; return v }
