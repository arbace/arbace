//line a2g_classes.ae:1
package aot_arbace_repl

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_repl_apropos_A_class, Name: "arbace.repl$apropos", Modifiers: 25, Simple: "apropos", Go: "arbace/aot_arbace_repl.A_arbace_repl_apropos_A", Source: "repl.ae", Declaring: &A_arbace_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repl_apropos_fn__1239000052_A_class, Name: "arbace.repl$apropos$fn__1239000052", Modifiers: 25, Simple: "fn__1239000052", Go: "arbace/aot_arbace_repl.A_arbace_repl_apropos_fn__1239000052_A", Source: "repl.ae", Declaring: &A_arbace_repl_apropos_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repl_apropos_fn__1239000054_A_class, Name: "arbace.repl$apropos$fn__1239000054", Modifiers: 25, Simple: "fn__1239000054", Go: "arbace/aot_arbace_repl.A_arbace_repl_apropos_fn__1239000054_A", Source: "repl.ae", Declaring: &A_arbace_repl_apropos_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repl_apropos_fn__1239000056_A_class, Name: "arbace.repl$apropos$fn__1239000056", Modifiers: 25, Simple: "fn__1239000056", Go: "arbace/aot_arbace_repl.A_arbace_repl_apropos_fn__1239000056_A", Source: "repl.ae", Declaring: &A_arbace_repl_apropos_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_class, Name: "arbace.repl$apropos$fn__1239000056$fn__1239000057", Modifiers: 25, Simple: "fn__1239000057", Go: "arbace/aot_arbace_repl.A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A", Source: "repl.ae", Declaring: &A_arbace_repl_apropos_fn__1239000056_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repl_demunge_A_class, Name: "arbace.repl$demunge", Modifiers: 25, Simple: "demunge", Go: "arbace/aot_arbace_repl.A_arbace_repl_demunge_A", Source: "repl.ae", Declaring: &A_arbace_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repl_dir_A_class, Name: "arbace.repl$dir", Modifiers: 25, Simple: "dir", Go: "arbace/aot_arbace_repl.A_arbace_repl_dir_A", Source: "repl.ae", Declaring: &A_arbace_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_repl_dir_fn_A_class, Name: "arbace.repl$dir_fn", Modifiers: 25, Simple: "dir_fn", Go: "arbace/aot_arbace_repl.A_arbace_repl_dir_fn_A", Source: "repl.ae", Declaring: &A_arbace_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repl_doc_A_class, Name: "arbace.repl$doc", Modifiers: 25, Simple: "doc", Go: "arbace/aot_arbace_repl.A_arbace_repl_doc_A", Source: "repl.ae", Declaring: &A_arbace_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_class, Name: "arbace.repl$eval1239000004$loading__1927001464__auto____1239000005", Modifiers: 25, Simple: "loading__1927001464__auto____1239000005", Go: "arbace/aot_arbace_repl.A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A", Source: "repl.ae", Declaring: &A_arbace_repl_eval1239000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repl_eval1239000008_fn__1239000009_A_class, Name: "arbace.repl$eval1239000008$fn__1239000009", Modifiers: 25, Simple: "fn__1239000009", Go: "arbace/aot_arbace_repl.A_arbace_repl_eval1239000008_fn__1239000009_A", Source: "repl.ae", Declaring: &A_arbace_repl_eval1239000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repl_find_doc_A_class, Name: "arbace.repl$find_doc", Modifiers: 25, Simple: "find_doc", Go: "arbace/aot_arbace_repl.A_arbace_repl_find_doc_A", Source: "repl.ae", Declaring: &A_arbace_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repl_find_doc_fn__1239000027_A_class, Name: "arbace.repl$find_doc$fn__1239000027", Modifiers: 25, Simple: "fn__1239000027", Go: "arbace/aot_arbace_repl.A_arbace_repl_find_doc_fn__1239000027_A", Source: "repl.ae", Declaring: &A_arbace_repl_find_doc_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repl_namespace_doc_A_class, Name: "arbace.repl$namespace_doc", Modifiers: 25, Simple: "namespace_doc", Go: "arbace/aot_arbace_repl.A_arbace_repl_namespace_doc_A", Source: "repl.ae", Declaring: &A_arbace_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repl_print_doc_A_class, Name: "arbace.repl$print_doc", Modifiers: 25, Simple: "print_doc", Go: "arbace/aot_arbace_repl.A_arbace_repl_print_doc_A", Source: "repl.ae", Declaring: &A_arbace_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repl_pst_A_class, Name: "arbace.repl$pst", Modifiers: 25, Simple: "pst", Go: "arbace/aot_arbace_repl.A_arbace_repl_pst_A", Source: "repl.ae", Declaring: &A_arbace_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class, &lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repl_pst_fn__1239000076_A_class, Name: "arbace.repl$pst$fn__1239000076", Modifiers: 25, Simple: "fn__1239000076", Go: "arbace/aot_arbace_repl.A_arbace_repl_pst_fn__1239000076_A", Source: "repl.ae", Declaring: &A_arbace_repl_pst_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repl_root_cause_A_class, Name: "arbace.repl$root_cause", Modifiers: 25, Simple: "root_cause", Go: "arbace/aot_arbace_repl.A_arbace_repl_root_cause_A", Source: "repl.ae", Declaring: &A_arbace_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repl_set_break_handler_BANG__A_class, Name: "arbace.repl$set_break_handler_BANG_", Modifiers: 25, Simple: "set_break_handler_BANG_", Go: "arbace/aot_arbace_repl.A_arbace_repl_set_break_handler_BANG__A", Source: "repl.ae", Declaring: &A_arbace_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class, &lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_class, Name: "arbace.repl$set_break_handler_BANG_$fn__1239000082", Modifiers: 25, Simple: "fn__1239000082", Go: "arbace/aot_arbace_repl.A_arbace_repl_set_break_handler_BANG__fn__1239000082_A", Source: "repl.ae", Declaring: &A_arbace_repl_set_break_handler_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repl_source_A_class, Name: "arbace.repl$source", Modifiers: 25, Simple: "source", Go: "arbace/aot_arbace_repl.A_arbace_repl_source_A", Source: "repl.ae", Declaring: &A_arbace_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_repl_source_fn_A_class, Name: "arbace.repl$source_fn", Modifiers: 25, Simple: "source_fn", Go: "arbace/aot_arbace_repl.A_arbace_repl_source_fn_A", Source: "repl.ae", Declaring: &A_arbace_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repl_source_fn_fn__1239000039_A_class, Name: "arbace.repl$source_fn$fn__1239000039", Modifiers: 25, Simple: "fn__1239000039", Go: "arbace/aot_arbace_repl.A_arbace_repl_source_fn_fn__1239000039_A", Source: "repl.ae", Declaring: &A_arbace_repl_source_fn_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_class, Name: "arbace.repl$source_fn$fn__1239000039$fn__1239000040", Modifiers: 25, Simple: "fn__1239000040", Go: "arbace/aot_arbace_repl.A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A", Source: "repl.ae", Declaring: &A_arbace_repl_source_fn_fn__1239000039_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repl_special_doc_A_class, Name: "arbace.repl$special_doc", Modifiers: 25, Simple: "special_doc", Go: "arbace/aot_arbace_repl.A_arbace_repl_special_doc_A", Source: "repl.ae", Declaring: &A_arbace_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repl_stack_element_str_A_class, Name: "arbace.repl$stack_element_str", Modifiers: 25, Simple: "stack_element_str", Go: "arbace/aot_arbace_repl.A_arbace_repl_stack_element_str_A", Source: "repl.ae", Declaring: &A_arbace_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repl_thread_stopper_A_class, Name: "arbace.repl$thread_stopper", Modifiers: 25, Simple: "thread_stopper", Go: "arbace/aot_arbace_repl.A_arbace_repl_thread_stopper_A", Source: "repl.ae", Declaring: &A_arbace_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class, &lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repl_thread_stopper_fn__1239000079_A_class, Name: "arbace.repl$thread_stopper$fn__1239000079", Modifiers: 25, Simple: "fn__1239000079", Go: "arbace/aot_arbace_repl.A_arbace_repl_thread_stopper_fn__1239000079_A", Source: "repl.ae", Declaring: &A_arbace_repl_thread_stopper_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_repl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_A_New()}; return nil }

var A_arbace_repl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repl_A_new}

var A_arbace_repl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_repl.A_arbace_repl_A"})

func init() { i := A_arbace_repl_A_class.Info(); i.IsInstance = A_arbace_repl_A_InstanceOf; i.Init = A_arbace_repl_A_Init; i.Table = A_arbace_repl_A_members }

var A_arbace_repl_apropos_A_class *jrt.Class

var A_arbace_repl_apropos_fn__1239000052_A_class *jrt.Class

var A_arbace_repl_apropos_fn__1239000054_A_class *jrt.Class

var A_arbace_repl_apropos_fn__1239000056_A_class *jrt.Class

var A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_class *jrt.Class

var A_arbace_repl_demunge_A_class *jrt.Class

var A_arbace_repl_dir_A_class *jrt.Class

var A_arbace_repl_dir_fn_A_class *jrt.Class

var A_arbace_repl_doc_A_class *jrt.Class

func A_arbace_repl_eval1239000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_eval1239000004_A_New()}; return nil }

var A_arbace_repl_eval1239000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repl_eval1239000004_A_new}

var A_arbace_repl_eval1239000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$eval1239000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_repl_A_class, Simple: "eval1239000004", Go: "arbace/aot_arbace_repl.A_arbace_repl_eval1239000004_A"})

func init() { i := A_arbace_repl_eval1239000004_A_class.Info(); i.IsInstance = A_arbace_repl_eval1239000004_A_InstanceOf; i.Table = A_arbace_repl_eval1239000004_A_members }

var A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_class *jrt.Class

func A_arbace_repl_eval1239000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_eval1239000008_A_New()}; return nil }

var A_arbace_repl_eval1239000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repl_eval1239000008_A_new}

var A_arbace_repl_eval1239000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$eval1239000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_repl_A_class, Simple: "eval1239000008", Go: "arbace/aot_arbace_repl.A_arbace_repl_eval1239000008_A"})

func init() { i := A_arbace_repl_eval1239000008_A_class.Info(); i.IsInstance = A_arbace_repl_eval1239000008_A_InstanceOf; i.Table = A_arbace_repl_eval1239000008_A_members }

var A_arbace_repl_eval1239000008_fn__1239000009_A_class *jrt.Class

var A_arbace_repl_find_doc_A_class *jrt.Class

var A_arbace_repl_find_doc_fn__1239000027_A_class *jrt.Class

var A_arbace_repl_namespace_doc_A_class *jrt.Class

var A_arbace_repl_print_doc_A_class *jrt.Class

var A_arbace_repl_pst_A_class *jrt.Class

var A_arbace_repl_pst_fn__1239000076_A_class *jrt.Class

var A_arbace_repl_root_cause_A_class *jrt.Class

var A_arbace_repl_set_break_handler_BANG__A_class *jrt.Class

var A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_class *jrt.Class

var A_arbace_repl_source_A_class *jrt.Class

var A_arbace_repl_source_fn_A_class *jrt.Class

var A_arbace_repl_source_fn_fn__1239000039_A_class *jrt.Class

var A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_class *jrt.Class

var A_arbace_repl_special_doc_A_class *jrt.Class

var A_arbace_repl_stack_element_str_A_class *jrt.Class

var A_arbace_repl_thread_stopper_A_class *jrt.Class

var A_arbace_repl_thread_stopper_fn__1239000079_A_class *jrt.Class

func A_arbace_repl__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_repl__init_A_Load__O()}; return nil }

func A_arbace_repl__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl__init_A_New()}; return nil }

var A_arbace_repl__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_repl__init_A_invoke, New: A_arbace_repl__init_A_new}

var A_arbace_repl__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_repl.A_arbace_repl__init_A", Source: "repl.ae"})

func init() { i := A_arbace_repl__init_A_class.Info(); i.IsInstance = A_arbace_repl__init_A_InstanceOf; i.Init = A_arbace_repl__init_A_Init; i.Table = A_arbace_repl__init_A_members }
