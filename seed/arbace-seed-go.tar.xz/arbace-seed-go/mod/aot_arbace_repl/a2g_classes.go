//line a2g_classes.ae:1
package aot_arbace_repl

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_repl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_A_New()}; return nil }

var A_arbace_repl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repl_A_new}

var A_arbace_repl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_repl.A_arbace_repl_A"})

func init() { i := A_arbace_repl_A_class.Info(); i.IsInstance = A_arbace_repl_A_InstanceOf; i.Init = A_arbace_repl_A_Init; i.Table = A_arbace_repl_A_members; jrt.RegisterGoType(A_arbace_repl_A_class, reflect.TypeFor[A_arbace_repl_A]()) }

func A_arbace_repl_apropos_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_apropos_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_repl_apropos_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_apropos_A_New()}; return nil }

func A_arbace_repl_apropos_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_apropos_A_fn_class)}; return nil }

var A_arbace_repl_apropos_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_apropos_A_invoke, New: A_arbace_repl_apropos_A_new, Get: A_arbace_repl_apropos_A_get}

var A_arbace_repl_apropos_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$apropos", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_repl_A_class, Simple: "apropos", Go: "arbace/aot_arbace_repl.A_arbace_repl_apropos_A", Source: "repl.ae"})

func init() { i := A_arbace_repl_apropos_A_class.Info(); i.IsInstance = A_arbace_repl_apropos_A_InstanceOf; i.Init = A_arbace_repl_apropos_A_Init; i.Table = A_arbace_repl_apropos_A_members; jrt.RegisterGoType(A_arbace_repl_apropos_A_class, reflect.TypeFor[A_arbace_repl_apropos_A]()) }

func A_arbace_repl_apropos_fn__1239000052_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_apropos_fn__1239000052_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_repl_apropos_fn__1239000052_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_apropos_fn__1239000052_A_New_O(args[0])}; return nil }

func A_arbace_repl_apropos_fn__1239000052_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_apropos_fn__1239000052_A_fn_class)}; return nil }

var A_arbace_repl_apropos_fn__1239000052_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_apropos_fn__1239000052_A_invoke, New: A_arbace_repl_apropos_fn__1239000052_A_new, Get: A_arbace_repl_apropos_fn__1239000052_A_get}

var A_arbace_repl_apropos_fn__1239000052_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$apropos$fn__1239000052", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_repl_apropos_A_class, Simple: "fn__1239000052", Go: "arbace/aot_arbace_repl.A_arbace_repl_apropos_fn__1239000052_A", Source: "repl.ae"})

func init() { i := A_arbace_repl_apropos_fn__1239000052_A_class.Info(); i.IsInstance = A_arbace_repl_apropos_fn__1239000052_A_InstanceOf; i.Init = A_arbace_repl_apropos_fn__1239000052_A_Init; i.Table = A_arbace_repl_apropos_fn__1239000052_A_members; jrt.RegisterGoType(A_arbace_repl_apropos_fn__1239000052_A_class, reflect.TypeFor[A_arbace_repl_apropos_fn__1239000052_A]()) }

func A_arbace_repl_apropos_fn__1239000054_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_apropos_fn__1239000054_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_repl_apropos_fn__1239000054_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_apropos_fn__1239000054_A_New_O(args[0])}; return nil }

func A_arbace_repl_apropos_fn__1239000054_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_apropos_fn__1239000054_A_fn_class)}; return nil }

var A_arbace_repl_apropos_fn__1239000054_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_apropos_fn__1239000054_A_invoke, New: A_arbace_repl_apropos_fn__1239000054_A_new, Get: A_arbace_repl_apropos_fn__1239000054_A_get}

var A_arbace_repl_apropos_fn__1239000054_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$apropos$fn__1239000054", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_repl_apropos_A_class, Simple: "fn__1239000054", Go: "arbace/aot_arbace_repl.A_arbace_repl_apropos_fn__1239000054_A", Source: "repl.ae"})

func init() { i := A_arbace_repl_apropos_fn__1239000054_A_class.Info(); i.IsInstance = A_arbace_repl_apropos_fn__1239000054_A_InstanceOf; i.Init = A_arbace_repl_apropos_fn__1239000054_A_Init; i.Table = A_arbace_repl_apropos_fn__1239000054_A_members; jrt.RegisterGoType(A_arbace_repl_apropos_fn__1239000054_A_class, reflect.TypeFor[A_arbace_repl_apropos_fn__1239000054_A]()) }

func A_arbace_repl_apropos_fn__1239000056_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_apropos_fn__1239000056_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_repl_apropos_fn__1239000056_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_apropos_fn__1239000056_A_New_O(args[0])}; return nil }

func A_arbace_repl_apropos_fn__1239000056_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_apropos_fn__1239000056_A_fn_class)}; return nil }

var A_arbace_repl_apropos_fn__1239000056_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_apropos_fn__1239000056_A_invoke, New: A_arbace_repl_apropos_fn__1239000056_A_new, Get: A_arbace_repl_apropos_fn__1239000056_A_get}

var A_arbace_repl_apropos_fn__1239000056_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$apropos$fn__1239000056", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_repl_apropos_A_class, Simple: "fn__1239000056", Go: "arbace/aot_arbace_repl.A_arbace_repl_apropos_fn__1239000056_A", Source: "repl.ae"})

func init() { i := A_arbace_repl_apropos_fn__1239000056_A_class.Info(); i.IsInstance = A_arbace_repl_apropos_fn__1239000056_A_InstanceOf; i.Init = A_arbace_repl_apropos_fn__1239000056_A_Init; i.Table = A_arbace_repl_apropos_fn__1239000056_A_members; jrt.RegisterGoType(A_arbace_repl_apropos_fn__1239000056_A_class, reflect.TypeFor[A_arbace_repl_apropos_fn__1239000056_A]()) }

func A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_New_O(args[0])}; return nil }

func A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_fn_class)}; return nil }

var A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_invoke, New: A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_new, Get: A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_get}

var A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$apropos$fn__1239000056$fn__1239000057", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_repl_apropos_fn__1239000056_A_class, Simple: "fn__1239000057", Go: "arbace/aot_arbace_repl.A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A", Source: "repl.ae"})

func init() { i := A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_class.Info(); i.IsInstance = A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_InstanceOf; i.Init = A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_Init; i.Table = A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_members; jrt.RegisterGoType(A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A_class, reflect.TypeFor[A_arbace_repl_apropos_fn__1239000056_fn__1239000057_A]()) }

func A_arbace_repl_demunge_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_demunge_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_repl_demunge_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_demunge_A_New()}; return nil }

func A_arbace_repl_demunge_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_demunge_A_fn_class)}; return nil }

var A_arbace_repl_demunge_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_demunge_A_invoke, New: A_arbace_repl_demunge_A_new, Get: A_arbace_repl_demunge_A_get}

var A_arbace_repl_demunge_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$demunge", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_repl_A_class, Simple: "demunge", Go: "arbace/aot_arbace_repl.A_arbace_repl_demunge_A", Source: "repl.ae"})

func init() { i := A_arbace_repl_demunge_A_class.Info(); i.IsInstance = A_arbace_repl_demunge_A_InstanceOf; i.Init = A_arbace_repl_demunge_A_Init; i.Table = A_arbace_repl_demunge_A_members; jrt.RegisterGoType(A_arbace_repl_demunge_A_class, reflect.TypeFor[A_arbace_repl_demunge_A]()) }

func A_arbace_repl_dir_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_dir_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_repl_dir_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_dir_A_New()}; return nil }

func A_arbace_repl_dir_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_dir_A_fn_class)}; return nil }

var A_arbace_repl_dir_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_dir_A_invoke, New: A_arbace_repl_dir_A_new, Get: A_arbace_repl_dir_A_get}

var A_arbace_repl_dir_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$dir", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_repl_A_class, Simple: "dir", Go: "arbace/aot_arbace_repl.A_arbace_repl_dir_A", Source: "repl.ae"})

func init() { i := A_arbace_repl_dir_A_class.Info(); i.IsInstance = A_arbace_repl_dir_A_InstanceOf; i.Init = A_arbace_repl_dir_A_Init; i.Table = A_arbace_repl_dir_A_members; jrt.RegisterGoType(A_arbace_repl_dir_A_class, reflect.TypeFor[A_arbace_repl_dir_A]()) }

func A_arbace_repl_dir_fn_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_dir_fn_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_repl_dir_fn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_dir_fn_A_New()}; return nil }

func A_arbace_repl_dir_fn_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_dir_fn_A_fn_class)}; return nil }

var A_arbace_repl_dir_fn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_dir_fn_A_invoke, New: A_arbace_repl_dir_fn_A_new, Get: A_arbace_repl_dir_fn_A_get}

var A_arbace_repl_dir_fn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$dir_fn", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_repl_A_class, Simple: "dir_fn", Go: "arbace/aot_arbace_repl.A_arbace_repl_dir_fn_A", Source: "repl.ae"})

func init() { i := A_arbace_repl_dir_fn_A_class.Info(); i.IsInstance = A_arbace_repl_dir_fn_A_InstanceOf; i.Init = A_arbace_repl_dir_fn_A_Init; i.Table = A_arbace_repl_dir_fn_A_members; jrt.RegisterGoType(A_arbace_repl_dir_fn_A_class, reflect.TypeFor[A_arbace_repl_dir_fn_A]()) }

func A_arbace_repl_doc_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_doc_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_repl_doc_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_doc_A_New()}; return nil }

func A_arbace_repl_doc_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_doc_A_fn_class)}; return nil }

var A_arbace_repl_doc_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_doc_A_invoke, New: A_arbace_repl_doc_A_new, Get: A_arbace_repl_doc_A_get}

var A_arbace_repl_doc_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$doc", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_repl_A_class, Simple: "doc", Go: "arbace/aot_arbace_repl.A_arbace_repl_doc_A", Source: "repl.ae"})

func init() { i := A_arbace_repl_doc_A_class.Info(); i.IsInstance = A_arbace_repl_doc_A_InstanceOf; i.Init = A_arbace_repl_doc_A_Init; i.Table = A_arbace_repl_doc_A_members; jrt.RegisterGoType(A_arbace_repl_doc_A_class, reflect.TypeFor[A_arbace_repl_doc_A]()) }

func A_arbace_repl_eval1239000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_eval1239000004_A_New()}; return nil }

var A_arbace_repl_eval1239000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repl_eval1239000004_A_new}

var A_arbace_repl_eval1239000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$eval1239000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_repl_A_class, Simple: "eval1239000004", Go: "arbace/aot_arbace_repl.A_arbace_repl_eval1239000004_A"})

func init() { i := A_arbace_repl_eval1239000004_A_class.Info(); i.IsInstance = A_arbace_repl_eval1239000004_A_InstanceOf; i.Table = A_arbace_repl_eval1239000004_A_members; jrt.RegisterGoType(A_arbace_repl_eval1239000004_A_class, reflect.TypeFor[A_arbace_repl_eval1239000004_A]()) }

func A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_New()}; return nil }

func A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_fn_class)}; return nil }

var A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_invoke, New: A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_new, Get: A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_get}

var A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$eval1239000004$loading__1927001464__auto____1239000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_repl_eval1239000004_A_class, Simple: "loading__1927001464__auto____1239000005", Go: "arbace/aot_arbace_repl.A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A", Source: "repl.ae"})

func init() { i := A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_class.Info(); i.IsInstance = A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_InstanceOf; i.Init = A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_Init; i.Table = A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_members; jrt.RegisterGoType(A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A_class, reflect.TypeFor[A_arbace_repl_eval1239000004_loading__1927001464__auto____1239000005_A]()) }

func A_arbace_repl_eval1239000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_eval1239000008_A_New()}; return nil }

var A_arbace_repl_eval1239000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repl_eval1239000008_A_new}

var A_arbace_repl_eval1239000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$eval1239000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_repl_A_class, Simple: "eval1239000008", Go: "arbace/aot_arbace_repl.A_arbace_repl_eval1239000008_A"})

func init() { i := A_arbace_repl_eval1239000008_A_class.Info(); i.IsInstance = A_arbace_repl_eval1239000008_A_InstanceOf; i.Table = A_arbace_repl_eval1239000008_A_members; jrt.RegisterGoType(A_arbace_repl_eval1239000008_A_class, reflect.TypeFor[A_arbace_repl_eval1239000008_A]()) }

func A_arbace_repl_eval1239000008_fn__1239000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_eval1239000008_fn__1239000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_repl_eval1239000008_fn__1239000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_eval1239000008_fn__1239000009_A_New()}; return nil }

func A_arbace_repl_eval1239000008_fn__1239000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_eval1239000008_fn__1239000009_A_fn_class)}; return nil }

var A_arbace_repl_eval1239000008_fn__1239000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_eval1239000008_fn__1239000009_A_invoke, New: A_arbace_repl_eval1239000008_fn__1239000009_A_new, Get: A_arbace_repl_eval1239000008_fn__1239000009_A_get}

var A_arbace_repl_eval1239000008_fn__1239000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$eval1239000008$fn__1239000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_repl_eval1239000008_A_class, Simple: "fn__1239000009", Go: "arbace/aot_arbace_repl.A_arbace_repl_eval1239000008_fn__1239000009_A", Source: "repl.ae"})

func init() { i := A_arbace_repl_eval1239000008_fn__1239000009_A_class.Info(); i.IsInstance = A_arbace_repl_eval1239000008_fn__1239000009_A_InstanceOf; i.Init = A_arbace_repl_eval1239000008_fn__1239000009_A_Init; i.Table = A_arbace_repl_eval1239000008_fn__1239000009_A_members; jrt.RegisterGoType(A_arbace_repl_eval1239000008_fn__1239000009_A_class, reflect.TypeFor[A_arbace_repl_eval1239000008_fn__1239000009_A]()) }

func A_arbace_repl_find_doc_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_find_doc_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_repl_find_doc_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_find_doc_A_New()}; return nil }

func A_arbace_repl_find_doc_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_find_doc_A_fn_class)}; return nil }

var A_arbace_repl_find_doc_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_find_doc_A_invoke, New: A_arbace_repl_find_doc_A_new, Get: A_arbace_repl_find_doc_A_get}

var A_arbace_repl_find_doc_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$find_doc", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_repl_A_class, Simple: "find_doc", Go: "arbace/aot_arbace_repl.A_arbace_repl_find_doc_A", Source: "repl.ae"})

func init() { i := A_arbace_repl_find_doc_A_class.Info(); i.IsInstance = A_arbace_repl_find_doc_A_InstanceOf; i.Init = A_arbace_repl_find_doc_A_Init; i.Table = A_arbace_repl_find_doc_A_members; jrt.RegisterGoType(A_arbace_repl_find_doc_A_class, reflect.TypeFor[A_arbace_repl_find_doc_A]()) }

func A_arbace_repl_find_doc_fn__1239000027_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_find_doc_fn__1239000027_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_repl_find_doc_fn__1239000027_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_find_doc_fn__1239000027_A_New()}; return nil }

func A_arbace_repl_find_doc_fn__1239000027_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_find_doc_fn__1239000027_A_fn_class)}; return nil }

var A_arbace_repl_find_doc_fn__1239000027_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_find_doc_fn__1239000027_A_invoke, New: A_arbace_repl_find_doc_fn__1239000027_A_new, Get: A_arbace_repl_find_doc_fn__1239000027_A_get}

var A_arbace_repl_find_doc_fn__1239000027_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$find_doc$fn__1239000027", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_repl_find_doc_A_class, Simple: "fn__1239000027", Go: "arbace/aot_arbace_repl.A_arbace_repl_find_doc_fn__1239000027_A", Source: "repl.ae"})

func init() { i := A_arbace_repl_find_doc_fn__1239000027_A_class.Info(); i.IsInstance = A_arbace_repl_find_doc_fn__1239000027_A_InstanceOf; i.Init = A_arbace_repl_find_doc_fn__1239000027_A_Init; i.Table = A_arbace_repl_find_doc_fn__1239000027_A_members; jrt.RegisterGoType(A_arbace_repl_find_doc_fn__1239000027_A_class, reflect.TypeFor[A_arbace_repl_find_doc_fn__1239000027_A]()) }

func A_arbace_repl_namespace_doc_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_namespace_doc_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_repl_namespace_doc_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_namespace_doc_A_New()}; return nil }

func A_arbace_repl_namespace_doc_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_namespace_doc_A_fn_class)}; return nil }

var A_arbace_repl_namespace_doc_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_namespace_doc_A_invoke, New: A_arbace_repl_namespace_doc_A_new, Get: A_arbace_repl_namespace_doc_A_get}

var A_arbace_repl_namespace_doc_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$namespace_doc", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_repl_A_class, Simple: "namespace_doc", Go: "arbace/aot_arbace_repl.A_arbace_repl_namespace_doc_A", Source: "repl.ae"})

func init() { i := A_arbace_repl_namespace_doc_A_class.Info(); i.IsInstance = A_arbace_repl_namespace_doc_A_InstanceOf; i.Init = A_arbace_repl_namespace_doc_A_Init; i.Table = A_arbace_repl_namespace_doc_A_members; jrt.RegisterGoType(A_arbace_repl_namespace_doc_A_class, reflect.TypeFor[A_arbace_repl_namespace_doc_A]()) }

func A_arbace_repl_print_doc_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_print_doc_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_repl_print_doc_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_print_doc_A_New()}; return nil }

func A_arbace_repl_print_doc_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_print_doc_A_fn_class)}; return nil }

var A_arbace_repl_print_doc_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_print_doc_A_invoke, New: A_arbace_repl_print_doc_A_new, Get: A_arbace_repl_print_doc_A_get}

var A_arbace_repl_print_doc_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$print_doc", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_repl_A_class, Simple: "print_doc", Go: "arbace/aot_arbace_repl.A_arbace_repl_print_doc_A", Source: "repl.ae"})

func init() { i := A_arbace_repl_print_doc_A_class.Info(); i.IsInstance = A_arbace_repl_print_doc_A_InstanceOf; i.Init = A_arbace_repl_print_doc_A_Init; i.Table = A_arbace_repl_print_doc_A_members; jrt.RegisterGoType(A_arbace_repl_print_doc_A_class, reflect.TypeFor[A_arbace_repl_print_doc_A]()) }

func A_arbace_repl_pst_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_pst_A).Invoke_O__O(args[0]); case 1: return this.(*A_arbace_repl_pst_A).Invoke_O_O__O(args[0], args[1]); case 2: return this.(*A_arbace_repl_pst_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_repl_pst_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_pst_A_New()}; return nil }

func A_arbace_repl_pst_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_pst_A_fn_class)}; return nil }

var A_arbace_repl_pst_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_pst_A_invoke, New: A_arbace_repl_pst_A_new, Get: A_arbace_repl_pst_A_get}

var A_arbace_repl_pst_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$pst", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class, lang.Compiler_AOTF0_class}, Declaring: A_arbace_repl_A_class, Simple: "pst", Go: "arbace/aot_arbace_repl.A_arbace_repl_pst_A", Source: "repl.ae"})

func init() { i := A_arbace_repl_pst_A_class.Info(); i.IsInstance = A_arbace_repl_pst_A_InstanceOf; i.Init = A_arbace_repl_pst_A_Init; i.Table = A_arbace_repl_pst_A_members; jrt.RegisterGoType(A_arbace_repl_pst_A_class, reflect.TypeFor[A_arbace_repl_pst_A]()) }

func A_arbace_repl_pst_fn__1239000076_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_pst_fn__1239000076_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_repl_pst_fn__1239000076_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_pst_fn__1239000076_A_New()}; return nil }

func A_arbace_repl_pst_fn__1239000076_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_pst_fn__1239000076_A_fn_class)}; return nil }

var A_arbace_repl_pst_fn__1239000076_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_pst_fn__1239000076_A_invoke, New: A_arbace_repl_pst_fn__1239000076_A_new, Get: A_arbace_repl_pst_fn__1239000076_A_get}

var A_arbace_repl_pst_fn__1239000076_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$pst$fn__1239000076", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_repl_pst_A_class, Simple: "fn__1239000076", Go: "arbace/aot_arbace_repl.A_arbace_repl_pst_fn__1239000076_A", Source: "repl.ae"})

func init() { i := A_arbace_repl_pst_fn__1239000076_A_class.Info(); i.IsInstance = A_arbace_repl_pst_fn__1239000076_A_InstanceOf; i.Init = A_arbace_repl_pst_fn__1239000076_A_Init; i.Table = A_arbace_repl_pst_fn__1239000076_A_members; jrt.RegisterGoType(A_arbace_repl_pst_fn__1239000076_A_class, reflect.TypeFor[A_arbace_repl_pst_fn__1239000076_A]()) }

func A_arbace_repl_root_cause_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_root_cause_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_repl_root_cause_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_root_cause_A_New()}; return nil }

func A_arbace_repl_root_cause_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_root_cause_A_fn_class)}; return nil }

var A_arbace_repl_root_cause_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_root_cause_A_invoke, New: A_arbace_repl_root_cause_A_new, Get: A_arbace_repl_root_cause_A_get}

var A_arbace_repl_root_cause_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$root_cause", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_repl_A_class, Simple: "root_cause", Go: "arbace/aot_arbace_repl.A_arbace_repl_root_cause_A", Source: "repl.ae"})

func init() { i := A_arbace_repl_root_cause_A_class.Info(); i.IsInstance = A_arbace_repl_root_cause_A_InstanceOf; i.Init = A_arbace_repl_root_cause_A_Init; i.Table = A_arbace_repl_root_cause_A_members; jrt.RegisterGoType(A_arbace_repl_root_cause_A_class, reflect.TypeFor[A_arbace_repl_root_cause_A]()) }

func A_arbace_repl_set_break_handler_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_set_break_handler_BANG__A).Invoke_O__O(args[0]); case 1: return this.(*A_arbace_repl_set_break_handler_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_repl_set_break_handler_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_set_break_handler_BANG__A_New()}; return nil }

func A_arbace_repl_set_break_handler_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_set_break_handler_BANG__A_fn_class)}; return nil }

var A_arbace_repl_set_break_handler_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_set_break_handler_BANG__A_invoke, New: A_arbace_repl_set_break_handler_BANG__A_new, Get: A_arbace_repl_set_break_handler_BANG__A_get}

var A_arbace_repl_set_break_handler_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$set_break_handler_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class, lang.Compiler_AOTF0_class}, Declaring: A_arbace_repl_A_class, Simple: "set_break_handler_BANG_", Go: "arbace/aot_arbace_repl.A_arbace_repl_set_break_handler_BANG__A", Source: "repl.ae"})

func init() { i := A_arbace_repl_set_break_handler_BANG__A_class.Info(); i.IsInstance = A_arbace_repl_set_break_handler_BANG__A_InstanceOf; i.Init = A_arbace_repl_set_break_handler_BANG__A_Init; i.Table = A_arbace_repl_set_break_handler_BANG__A_members; jrt.RegisterGoType(A_arbace_repl_set_break_handler_BANG__A_class, reflect.TypeFor[A_arbace_repl_set_break_handler_BANG__A]()) }

func A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_set_break_handler_BANG__fn__1239000082_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_New_O(args[0])}; return nil }

func A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_fn_class)}; return nil }

var A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_invoke, New: A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_new, Get: A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_get}

var A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$set_break_handler_BANG_$fn__1239000082", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_repl_set_break_handler_BANG__A_class, Simple: "fn__1239000082", Go: "arbace/aot_arbace_repl.A_arbace_repl_set_break_handler_BANG__fn__1239000082_A", Source: "repl.ae"})

func init() { i := A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_class.Info(); i.IsInstance = A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_InstanceOf; i.Init = A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_Init; i.Table = A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_members; jrt.RegisterGoType(A_arbace_repl_set_break_handler_BANG__fn__1239000082_A_class, reflect.TypeFor[A_arbace_repl_set_break_handler_BANG__fn__1239000082_A]()) }

func A_arbace_repl_source_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_source_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_repl_source_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_source_A_New()}; return nil }

func A_arbace_repl_source_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_source_A_fn_class)}; return nil }

var A_arbace_repl_source_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_source_A_invoke, New: A_arbace_repl_source_A_new, Get: A_arbace_repl_source_A_get}

var A_arbace_repl_source_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$source", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_repl_A_class, Simple: "source", Go: "arbace/aot_arbace_repl.A_arbace_repl_source_A", Source: "repl.ae"})

func init() { i := A_arbace_repl_source_A_class.Info(); i.IsInstance = A_arbace_repl_source_A_InstanceOf; i.Init = A_arbace_repl_source_A_Init; i.Table = A_arbace_repl_source_A_members; jrt.RegisterGoType(A_arbace_repl_source_A_class, reflect.TypeFor[A_arbace_repl_source_A]()) }

func A_arbace_repl_source_fn_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_source_fn_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_repl_source_fn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_source_fn_A_New()}; return nil }

func A_arbace_repl_source_fn_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_source_fn_A_fn_class)}; return nil }

var A_arbace_repl_source_fn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_source_fn_A_invoke, New: A_arbace_repl_source_fn_A_new, Get: A_arbace_repl_source_fn_A_get}

var A_arbace_repl_source_fn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$source_fn", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_repl_A_class, Simple: "source_fn", Go: "arbace/aot_arbace_repl.A_arbace_repl_source_fn_A", Source: "repl.ae"})

func init() { i := A_arbace_repl_source_fn_A_class.Info(); i.IsInstance = A_arbace_repl_source_fn_A_InstanceOf; i.Init = A_arbace_repl_source_fn_A_Init; i.Table = A_arbace_repl_source_fn_A_members; jrt.RegisterGoType(A_arbace_repl_source_fn_A_class, reflect.TypeFor[A_arbace_repl_source_fn_A]()) }

func A_arbace_repl_source_fn_fn__1239000039_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_source_fn_fn__1239000039_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_repl_source_fn_fn__1239000039_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_source_fn_fn__1239000039_A_New_O(args[0])}; return nil }

func A_arbace_repl_source_fn_fn__1239000039_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_source_fn_fn__1239000039_A_fn_class)}; return nil }

var A_arbace_repl_source_fn_fn__1239000039_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_source_fn_fn__1239000039_A_invoke, New: A_arbace_repl_source_fn_fn__1239000039_A_new, Get: A_arbace_repl_source_fn_fn__1239000039_A_get}

var A_arbace_repl_source_fn_fn__1239000039_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$source_fn$fn__1239000039", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_repl_source_fn_A_class, Simple: "fn__1239000039", Go: "arbace/aot_arbace_repl.A_arbace_repl_source_fn_fn__1239000039_A", Source: "repl.ae"})

func init() { i := A_arbace_repl_source_fn_fn__1239000039_A_class.Info(); i.IsInstance = A_arbace_repl_source_fn_fn__1239000039_A_InstanceOf; i.Init = A_arbace_repl_source_fn_fn__1239000039_A_Init; i.Table = A_arbace_repl_source_fn_fn__1239000039_A_members; jrt.RegisterGoType(A_arbace_repl_source_fn_fn__1239000039_A_class, reflect.TypeFor[A_arbace_repl_source_fn_fn__1239000039_A]()) }

func A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_New_O(args[0])}; return nil }

func A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_fn_class)}; return nil }

var A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_invoke, New: A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_new, Get: A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_get}

var A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$source_fn$fn__1239000039$fn__1239000040", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_repl_source_fn_fn__1239000039_A_class, Simple: "fn__1239000040", Go: "arbace/aot_arbace_repl.A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A", Source: "repl.ae"})

func init() { i := A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_class.Info(); i.IsInstance = A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_InstanceOf; i.Init = A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_Init; i.Table = A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_members; jrt.RegisterGoType(A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A_class, reflect.TypeFor[A_arbace_repl_source_fn_fn__1239000039_fn__1239000040_A]()) }

func A_arbace_repl_special_doc_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_special_doc_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_repl_special_doc_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_special_doc_A_New()}; return nil }

func A_arbace_repl_special_doc_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_special_doc_A_fn_class)}; return nil }

var A_arbace_repl_special_doc_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_special_doc_A_invoke, New: A_arbace_repl_special_doc_A_new, Get: A_arbace_repl_special_doc_A_get}

var A_arbace_repl_special_doc_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$special_doc", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_repl_A_class, Simple: "special_doc", Go: "arbace/aot_arbace_repl.A_arbace_repl_special_doc_A", Source: "repl.ae"})

func init() { i := A_arbace_repl_special_doc_A_class.Info(); i.IsInstance = A_arbace_repl_special_doc_A_InstanceOf; i.Init = A_arbace_repl_special_doc_A_Init; i.Table = A_arbace_repl_special_doc_A_members; jrt.RegisterGoType(A_arbace_repl_special_doc_A_class, reflect.TypeFor[A_arbace_repl_special_doc_A]()) }

func A_arbace_repl_stack_element_str_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_stack_element_str_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_repl_stack_element_str_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_stack_element_str_A_New()}; return nil }

func A_arbace_repl_stack_element_str_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_stack_element_str_A_fn_class)}; return nil }

var A_arbace_repl_stack_element_str_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_stack_element_str_A_invoke, New: A_arbace_repl_stack_element_str_A_new, Get: A_arbace_repl_stack_element_str_A_get}

var A_arbace_repl_stack_element_str_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$stack_element_str", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_repl_A_class, Simple: "stack_element_str", Go: "arbace/aot_arbace_repl.A_arbace_repl_stack_element_str_A", Source: "repl.ae"})

func init() { i := A_arbace_repl_stack_element_str_A_class.Info(); i.IsInstance = A_arbace_repl_stack_element_str_A_InstanceOf; i.Init = A_arbace_repl_stack_element_str_A_Init; i.Table = A_arbace_repl_stack_element_str_A_members; jrt.RegisterGoType(A_arbace_repl_stack_element_str_A_class, reflect.TypeFor[A_arbace_repl_stack_element_str_A]()) }

func A_arbace_repl_thread_stopper_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_thread_stopper_A).Invoke_O__O(args[0]); case 1: return this.(*A_arbace_repl_thread_stopper_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_repl_thread_stopper_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_thread_stopper_A_New()}; return nil }

func A_arbace_repl_thread_stopper_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_thread_stopper_A_fn_class)}; return nil }

var A_arbace_repl_thread_stopper_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_thread_stopper_A_invoke, New: A_arbace_repl_thread_stopper_A_new, Get: A_arbace_repl_thread_stopper_A_get}

var A_arbace_repl_thread_stopper_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$thread_stopper", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class, lang.Compiler_AOTF0_class}, Declaring: A_arbace_repl_A_class, Simple: "thread_stopper", Go: "arbace/aot_arbace_repl.A_arbace_repl_thread_stopper_A", Source: "repl.ae"})

func init() { i := A_arbace_repl_thread_stopper_A_class.Info(); i.IsInstance = A_arbace_repl_thread_stopper_A_InstanceOf; i.Init = A_arbace_repl_thread_stopper_A_Init; i.Table = A_arbace_repl_thread_stopper_A_members; jrt.RegisterGoType(A_arbace_repl_thread_stopper_A_class, reflect.TypeFor[A_arbace_repl_thread_stopper_A]()) }

func A_arbace_repl_thread_stopper_fn__1239000079_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repl_thread_stopper_fn__1239000079_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_repl_thread_stopper_fn__1239000079_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl_thread_stopper_fn__1239000079_A_New_O(args[0])}; return nil }

func A_arbace_repl_thread_stopper_fn__1239000079_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_repl_thread_stopper_fn__1239000079_A_fn_class)}; return nil }

var A_arbace_repl_thread_stopper_fn__1239000079_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_repl_thread_stopper_fn__1239000079_A_invoke, New: A_arbace_repl_thread_stopper_fn__1239000079_A_new, Get: A_arbace_repl_thread_stopper_fn__1239000079_A_get}

var A_arbace_repl_thread_stopper_fn__1239000079_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl$thread_stopper$fn__1239000079", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_repl_thread_stopper_A_class, Simple: "fn__1239000079", Go: "arbace/aot_arbace_repl.A_arbace_repl_thread_stopper_fn__1239000079_A", Source: "repl.ae"})

func init() { i := A_arbace_repl_thread_stopper_fn__1239000079_A_class.Info(); i.IsInstance = A_arbace_repl_thread_stopper_fn__1239000079_A_InstanceOf; i.Init = A_arbace_repl_thread_stopper_fn__1239000079_A_Init; i.Table = A_arbace_repl_thread_stopper_fn__1239000079_A_members; jrt.RegisterGoType(A_arbace_repl_thread_stopper_fn__1239000079_A_class, reflect.TypeFor[A_arbace_repl_thread_stopper_fn__1239000079_A]()) }

func A_arbace_repl__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_repl__init_A_Load__O(); case 1: return A_arbace_repl__init_A_Unit0__O(); case 2: return A_arbace_repl__init_A_Unit1__O(); case 3: return A_arbace_repl__init_A_Unit10__O(); case 4: return A_arbace_repl__init_A_Unit11__O(); case 5: return A_arbace_repl__init_A_Unit12__O(); case 6: return A_arbace_repl__init_A_Unit13__O(); case 7: return A_arbace_repl__init_A_Unit14__O(); case 8: return A_arbace_repl__init_A_Unit15__O(); case 9: return A_arbace_repl__init_A_Unit16__O(); case 10: return A_arbace_repl__init_A_Unit17__O(); case 11: return A_arbace_repl__init_A_Unit18__O(); case 12: return A_arbace_repl__init_A_Unit19__O(); case 13: return A_arbace_repl__init_A_Unit2__O(); case 14: return A_arbace_repl__init_A_Unit20__O(); case 15: return A_arbace_repl__init_A_Unit21__O(); case 16: return A_arbace_repl__init_A_Unit22__O(); case 17: return A_arbace_repl__init_A_Unit23__O(); case 18: return A_arbace_repl__init_A_Unit24__O(); case 19: return A_arbace_repl__init_A_Unit25__O(); case 20: return A_arbace_repl__init_A_Unit26__O(); case 21: return A_arbace_repl__init_A_Unit3__O(); case 22: return A_arbace_repl__init_A_Unit4__O(); case 23: return A_arbace_repl__init_A_Unit5__O(); case 24: return A_arbace_repl__init_A_Unit6__O(); case 25: return A_arbace_repl__init_A_Unit7__O(); case 26: return A_arbace_repl__init_A_Unit8__O(); case 27: return A_arbace_repl__init_A_Unit9__O()}; return nil }

func A_arbace_repl__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repl__init_A_New()}; return nil }

var A_arbace_repl__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_repl__init_A_invoke, New: A_arbace_repl__init_A_new}

var A_arbace_repl__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repl__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_repl.A_arbace_repl__init_A", Source: "repl.ae"})

func init() { i := A_arbace_repl__init_A_class.Info(); i.IsInstance = A_arbace_repl__init_A_InstanceOf; i.Init = A_arbace_repl__init_A_Init; i.Table = A_arbace_repl__init_A_members; jrt.RegisterGoType(A_arbace_repl__init_A_class, reflect.TypeFor[A_arbace_repl__init_A]()) }
