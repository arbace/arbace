//line aot_arbace_go_repl__init.ae:1
package aot_arbace_go_repl

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_repl__init_A_Unit0__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_go_repl__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_repl__init_A_const_1) }
//line :1:1
func A_arbace_go_repl__init_A_Unit1__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_go_repl__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_2)) }
//line :1:1
func A_arbace_go_repl__init_A_Unit2__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_go_repl_eval794000004_loading__1927001464__auto____794000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_repl_eval794000004_loading__1927001464__auto____794000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_295, false, nil); A_arbace_go_repl_eval794000004_loading__1927001464__auto____794000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_go_repl__init_A_Unit3__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_go_repl__init_A_const_1)).Equals_O__Z(A_arbace_go_repl__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_go_repl_eval794000008_fn__794000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_repl_eval794000008_fn__794000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_296, false, nil); A_arbace_go_repl_eval794000008_fn__794000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_go_repl__init_A_Load__O() any { A_arbace_go_repl__init_A_Init(); jrt.StartCheck(); A_arbace_go_repl__init_A_Unit0__O(); A_arbace_go_repl__init_A_Unit1__O(); A_arbace_go_repl__init_A_Unit2__O(); A_arbace_go_repl__init_A_Unit3__O(); A_arbace_go_repl__init_A_Unit4__O(); A_arbace_go_repl__init_A_Unit5__O(); A_arbace_go_repl__init_A_Unit6__O(); A_arbace_go_repl__init_A_Unit7__O(); A_arbace_go_repl__init_A_Unit8__O(); A_arbace_go_repl__init_A_Unit9__O(); A_arbace_go_repl__init_A_Unit10__O(); A_arbace_go_repl__init_A_Unit11__O(); A_arbace_go_repl__init_A_Unit12__O(); A_arbace_go_repl__init_A_Unit13__O(); A_arbace_go_repl__init_A_Unit14__O(); A_arbace_go_repl__init_A_Unit15__O(); A_arbace_go_repl__init_A_Unit16__O(); A_arbace_go_repl__init_A_Unit17__O(); A_arbace_go_repl__init_A_Unit18__O(); A_arbace_go_repl__init_A_Unit19__O(); A_arbace_go_repl__init_A_Unit20__O(); A_arbace_go_repl__init_A_Unit21__O(); A_arbace_go_repl__init_A_Unit22__O(); A_arbace_go_repl__init_A_Unit23__O(); A_arbace_go_repl__init_A_Unit24__O(); A_arbace_go_repl__init_A_Unit25__O(); A_arbace_go_repl__init_A_Unit26__O(); A_arbace_go_repl__init_A_Unit27__O(); A_arbace_go_repl__init_A_Unit28__O(); A_arbace_go_repl__init_A_Unit29__O(); A_arbace_go_repl__init_A_Unit30__O(); A_arbace_go_repl__init_A_Unit31__O(); A_arbace_go_repl__init_A_Unit32__O(); A_arbace_go_repl__init_A_Unit33__O(); A_arbace_go_repl__init_A_Unit34__O(); A_arbace_go_repl__init_A_Unit35__O(); A_arbace_go_repl__init_A_Unit36__O(); A_arbace_go_repl__init_A_Unit37__O(); A_arbace_go_repl__init_A_Unit38__O(); A_arbace_go_repl__init_A_Unit39__O(); A_arbace_go_repl__init_A_Unit40__O(); A_arbace_go_repl__init_A_Unit41__O(); A_arbace_go_repl__init_A_Unit42__O(); A_arbace_go_repl__init_A_Unit43__O(); A_arbace_go_repl__init_A_Unit44__O(); A_arbace_go_repl__init_A_Unit45__O(); A_arbace_go_repl__init_A_Unit46__O(); A_arbace_go_repl__init_A_Unit47__O(); A_arbace_go_repl__init_A_Unit48__O(); A_arbace_go_repl__init_A_Unit49__O(); A_arbace_go_repl__init_A_Unit50__O(); A_arbace_go_repl__init_A_Unit51__O(); A_arbace_go_repl__init_A_Unit52__O(); A_arbace_go_repl__init_A_Unit53__O(); A_arbace_go_repl__init_A_Unit54__O(); A_arbace_go_repl__init_A_Unit55__O(); A_arbace_go_repl__init_A_Unit56__O(); A_arbace_go_repl__init_A_Unit57__O(); A_arbace_go_repl__init_A_Unit58__O(); A_arbace_go_repl__init_A_Unit59__O(); A_arbace_go_repl__init_A_Unit60__O(); A_arbace_go_repl__init_A_Unit61__O(); A_arbace_go_repl__init_A_Unit62__O(); A_arbace_go_repl__init_A_Unit63__O(); A_arbace_go_repl__init_A_Unit64__O(); A_arbace_go_repl__init_A_Unit65__O(); A_arbace_go_repl__init_A_Unit66__O(); A_arbace_go_repl__init_A_Unit67__O(); A_arbace_go_repl__init_A_Unit68__O(); A_arbace_go_repl__init_A_Unit69__O(); A_arbace_go_repl__init_A_Unit70__O(); A_arbace_go_repl__init_A_Unit71__O(); return nil }






















func A_arbace_go_repl__init_A_Unit4__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(28, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_go_repl_fn__794000012_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_repl_fn__794000012_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_297, false, nil); A_arbace_go_repl_fn__794000012_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp2))); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_5)); return A_arbace_go_repl__init_A_const_4 }

func A_arbace_go_repl__init_A_Unit5__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(30, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_go_repl_listed_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_repl_listed_QMARK__A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_298, false, nil); A_arbace_go_repl_listed_QMARK__A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_7)); return A_arbace_go_repl__init_A_const_6 }




func A_arbace_go_repl__init_A_Unit6__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(35, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_go_repl_fn__794000015_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_repl_fn__794000015_A_fn_class; if
						fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_299, false, nil); A_arbace_go_repl_fn__794000015_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); /*line :35:1*/tmp1.BindRoot_O__V(lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp2))); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_9)); return A_arbace_go_repl__init_A_const_8 }





func A_arbace_go_repl__init_A_Unit7__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(41, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_go_repl_digest_forms_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_repl_digest_forms_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_300, false, nil); A_arbace_go_repl_digest_forms_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_11)); return A_arbace_go_repl__init_A_const_10 }






func A_arbace_go_repl__init_A_Unit8__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_go_repl_fn__794000024_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_repl_fn__794000024_A_fn_class; if

	fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_301, false, nil); A_arbace_go_repl_fn__794000024_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); /*line :48:1*/tmp1.BindRoot_O__V(lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp2))); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_13)); return A_arbace_go_repl__init_A_const_12 }







func A_arbace_go_repl__init_A_Unit9__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(56, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_go_repl_interpretable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_repl_interpretable_QMARK__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_302, false, nil); A_arbace_go_repl_interpretable_QMARK__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_15)); return A_arbace_go_repl__init_A_const_14 }





func A_arbace_go_repl__init_A_Unit10__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(62, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_go_repl_fn__794000030_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_repl_fn__794000030_A_fn_class; if

	fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_303, false, nil); A_arbace_go_repl_fn__794000030_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); /*line :62:1*/tmp1.BindRoot_O__V(lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp2))); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_17)); return A_arbace_go_repl__init_A_const_16 }





func A_arbace_go_repl__init_A_Unit11__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(68, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_go_repl_refusal_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_repl_refusal_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_304, false, nil); A_arbace_go_repl_refusal_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_19)); return A_arbace_go_repl__init_A_const_18 }
















func A_arbace_go_repl__init_A_Unit12__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(85, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_go_repl_fn__794000034_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_repl_fn__794000034_A_fn_class; if




	fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_305, false, nil); A_arbace_go_repl_fn__794000034_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); /*line :85:1*/tmp1.BindRoot_O__V(lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp2))); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_21)); return A_arbace_go_repl__init_A_const_20 }













func A_arbace_go_repl__init_A_Unit13__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(99, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_22; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_23)); v__1927001498__auto____1 = A_arbace_go_repl__init_A_const_22; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_go_repl__init_A_const_22; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_25)); var tmp3 *lang.Var = A_arbace_go_repl__init_A_const_22; var tmp4 any; var root_23 any = A_arbace_go_repl__init_A_const_24.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_23, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_25 lang.IFn; if linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_24 == nil { tmp4 = ifn_25.Invoke_O__O(arg_26) } else { tmp4 = linked_24.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_23, arg_26) }; tmp3.BindRoot_O__V(tmp4); return A_arbace_go_repl__init_A_const_22 } }

func A_arbace_go_repl__init_A_Unit14__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_26; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_go_repl_path__GT_ns_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_go_repl_path__GT_ns_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_306, false, nil); A_arbace_go_repl_path__GT_ns_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_27)); return A_arbace_go_repl__init_A_const_26 }




func A_arbace_go_repl__init_A_Unit15__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(106, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_28; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_go_repl_ns__GT_path_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_go_repl_ns__GT_path_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_307, false, nil); A_arbace_go_repl_ns__GT_path_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_29)); return A_arbace_go_repl__init_A_const_28 }




func A_arbace_go_repl__init_A_Unit16__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(111, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_go_repl_new_state_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_repl_new_state_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_308, false, nil); A_arbace_go_repl_new_state_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_31)); return A_arbace_go_repl__init_A_const_30 }



func A_arbace_go_repl__init_A_Unit17__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(115, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_go_repl_package_state_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_go_repl_package_state_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_309, false, nil); A_arbace_go_repl_package_state_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_33)); return A_arbace_go_repl__init_A_const_32 }















func A_arbace_go_repl__init_A_Unit18__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(131, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_go_repl_package_BANG__A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_go_repl_package_BANG__A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_310, false, nil); A_arbace_go_repl_package_BANG__A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_35)); return A_arbace_go_repl__init_A_const_34 }















func A_arbace_go_repl__init_A_Unit19__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(147, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_go_repl_file_entry_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_go_repl_file_entry_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_311, false, nil); A_arbace_go_repl_file_entry_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_37)); return A_arbace_go_repl__init_A_const_36 }


func A_arbace_go_repl__init_A_Unit20__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(150, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_go_repl_update_file_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_go_repl_update_file_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_312, false, nil); A_arbace_go_repl_update_file_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_39)); return A_arbace_go_repl__init_A_const_38 }






func A_arbace_go_repl__init_A_Unit21__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(157, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_go_repl_file_BANG__A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_go_repl_file_BANG__A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_313, false, nil); A_arbace_go_repl_file_BANG__A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_41)); return A_arbace_go_repl__init_A_const_40 }








func A_arbace_go_repl__init_A_Unit22__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(166, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_go_repl_import_BANG__A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_go_repl_import_BANG__A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_314, false, nil); A_arbace_go_repl_import_BANG__A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_43)); return A_arbace_go_repl__init_A_const_42 }










func A_arbace_go_repl__init_A_Unit23__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(177, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_go_repl_decl_names_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_go_repl_decl_names_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_315, false, nil); A_arbace_go_repl_decl_names_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_45)); return A_arbace_go_repl__init_A_const_44 }



























func A_arbace_go_repl__init_A_Unit24__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(205, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_go_repl_error_text_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_go_repl_error_text_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_316, false, nil); A_arbace_go_repl_error_text_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_47)); return A_arbace_go_repl__init_A_const_46 }







func A_arbace_go_repl__init_A_Unit25__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(213, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_go_repl_repl_source_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_go_repl_repl_source_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_317, false, nil); A_arbace_go_repl_repl_source_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_49)); return A_arbace_go_repl__init_A_const_48 }

func A_arbace_go_repl__init_A_Unit26__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(215, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_go_repl_source_of_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_go_repl_source_of_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_318, false, nil); A_arbace_go_repl_source_of_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_51)); return A_arbace_go_repl__init_A_const_50 }








func A_arbace_go_repl__init_A_Unit27__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(224, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_52; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_53)); return A_arbace_go_repl__init_A_const_52 }

func A_arbace_go_repl__init_A_Unit28__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(226, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_54; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_go_repl_session_for_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_go_repl_session_for_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_319, false, nil); A_arbace_go_repl_session_for_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_55)); return A_arbace_go_repl__init_A_const_54 }











func A_arbace_go_repl__init_A_Unit29__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(238, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_56; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_57)); return A_arbace_go_repl__init_A_const_56 }

func A_arbace_go_repl__init_A_Unit30__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(240, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_58; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_go_repl_define_digest_imports_BANG__A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_go_repl_define_digest_imports_BANG__A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_320, false, nil); A_arbace_go_repl_define_digest_imports_BANG__A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_59)); return A_arbace_go_repl__init_A_const_58 }










func A_arbace_go_repl__init_A_Unit31__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(251, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_60; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_go_repl_check_source_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_go_repl_check_source_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_321, false, nil); A_arbace_go_repl_check_source_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_61)); return A_arbace_go_repl__init_A_const_60 }













func A_arbace_go_repl__init_A_Unit32__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(265, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_62; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_go_repl_package_file_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_go_repl_package_file_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_322, false, nil); A_arbace_go_repl_package_file_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_63)); return A_arbace_go_repl__init_A_const_62 }












func A_arbace_go_repl__init_A_Unit33__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(278, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_64; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_go_repl_embed_kind_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_go_repl_embed_kind_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_323, false, nil); A_arbace_go_repl_embed_kind_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_65)); return A_arbace_go_repl__init_A_const_64 }









func A_arbace_go_repl__init_A_Unit34__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(288, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_66; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_go_repl_embed_trees_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_go_repl_embed_trees_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_324, false, nil); A_arbace_go_repl_embed_trees_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_67)); return A_arbace_go_repl__init_A_const_66 }













































func A_arbace_go_repl__init_A_Unit35__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(334, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_68; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_go_repl_type_key_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_go_repl_type_key_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_325, false, nil); A_arbace_go_repl_type_key_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_69)); return A_arbace_go_repl__init_A_const_68 }
















func A_arbace_go_repl__init_A_Unit36__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(351, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_70; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_go_repl_state_of_path_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_go_repl_state_of_path_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_326, false, nil); A_arbace_go_repl_state_of_path_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_71)); return A_arbace_go_repl__init_A_const_70 }

func A_arbace_go_repl__init_A_Unit37__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(353, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_72; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_go_repl_method_name_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_go_repl_method_name_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_327, false, nil); A_arbace_go_repl_method_name_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_73)); return A_arbace_go_repl__init_A_const_72 }





func A_arbace_go_repl__init_A_Unit38__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(359, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_74; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_go_repl_display_file_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_go_repl_display_file_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_328, false, nil); A_arbace_go_repl_display_file_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_75)); return A_arbace_go_repl__init_A_const_74 }





func A_arbace_go_repl__init_A_Unit39__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(365, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_76; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_77)); return A_arbace_go_repl__init_A_const_76 }

func A_arbace_go_repl__init_A_Unit40__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(367, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_78; var tmp2 any; var root_73 any = A_arbace_go_repl__init_A_const_24.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_74 == nil { tmp2 = ifn_75.Invoke_O__O(arg_76) } else { tmp2 = linked_74.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_73, arg_76) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_go_repl__init_A_const_78; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_79)); return A_arbace_go_repl__init_A_const_78 }

func A_arbace_go_repl__init_A_Unit41__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(369, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_80; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_go_repl_table_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_go_repl_table_type_QMARK__A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_329, false, nil); A_arbace_go_repl_table_type_QMARK__A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_81)); return A_arbace_go_repl__init_A_const_80 }









func A_arbace_go_repl__init_A_Unit42__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(379, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_82; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_go_repl_digest_scope_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_go_repl_digest_scope_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_330, false, nil); A_arbace_go_repl_digest_scope_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_83)); return A_arbace_go_repl__init_A_const_82 }




func A_arbace_go_repl__init_A_Unit43__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(384, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_84; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_go_repl_build_context_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_go_repl_build_context_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_331, false, nil); A_arbace_go_repl_build_context_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_85)); return A_arbace_go_repl__init_A_const_84 }




























func A_arbace_go_repl__init_A_Unit44__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(413, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_86; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_87)); v__1927001498__auto____1 = A_arbace_go_repl__init_A_const_86; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_go_repl__init_A_const_86; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_88)); var tmp3 *lang.Var = A_arbace_go_repl__init_A_const_86; var tmp4 any; var root_83 any = A_arbace_go_repl__init_A_const_24.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_85 lang.IFn
						if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_84 == nil { tmp4 = ifn_85.Invoke_O__O(arg_86) } else { tmp4 = linked_84.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_83, arg_86) }
//line :413:1
	tmp3.BindRoot_O__V(tmp4); return A_arbace_go_repl__init_A_const_86 } }


func A_arbace_go_repl__init_A_Unit45__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(416, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_89; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_go_repl_compiled_context_A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_go_repl_compiled_context_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_332, false, nil); A_arbace_go_repl_compiled_context_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_89; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_90)); return A_arbace_go_repl__init_A_const_89 }




















func A_arbace_go_repl__init_A_Unit46__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(437, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_76; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_go_repl_ctx_of_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_go_repl_ctx_of_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_333, false, nil); A_arbace_go_repl_ctx_of_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_91)); return A_arbace_go_repl__init_A_const_76 }






func A_arbace_go_repl__init_A_Unit47__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(444, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_92; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_go_repl_named_type_A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_go_repl_named_type_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_334, false, nil); A_arbace_go_repl_named_type_A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_93)); return A_arbace_go_repl__init_A_const_92 }












func A_arbace_go_repl__init_A_Unit48__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(457, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_94; var tmp2 any = A_arbace_go_repl__init_A_const_95; var tmp3 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_go_repl_fn__794000365_A_New(); var tmp4 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_go_repl_fn__794000365_A_fn_class; if

	fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_335, false, nil); A_arbace_go_repl_fn__794000365_A_fn_class = fncls__93d; tmp4 = fncls__93d } else { tmp4 = fncls__93 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp4, nil); var tmp5 any = /*line :457:1*/tmp3.Ref(); var tmp6 any = A_arbace_go_repl__init_A_const_96; var tmp7 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_go_repl_fn__794000367_A_New(); var tmp8 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_go_repl_fn__794000367_A_fn_class; if

	fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_336, false, nil); A_arbace_go_repl_fn__794000367_A_fn_class = fncls__95d; tmp8 = fncls__95d } else { tmp8 = fncls__95 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp8, nil); /*line :457:1*/tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp5, tmp6, tmp7.Ref()))); var tmp9 *lang.Var = A_arbace_go_repl__init_A_const_94; tmp9.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_97)); return A_arbace_go_repl__init_A_const_94 }



func A_arbace_go_repl__init_A_Unit49__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(461, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_98; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_go_repl_const_arbace_A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_go_repl_const_arbace_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_337, false, nil); A_arbace_go_repl_const_arbace_A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_99)); return A_arbace_go_repl__init_A_const_98 }











func A_arbace_go_repl__init_A_Unit50__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(473, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_52; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_100)); return A_arbace_go_repl__init_A_const_52 }

func A_arbace_go_repl__init_A_Unit51__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(475, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_101; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_go_repl_linkname_cell_A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_go_repl_linkname_cell_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_338, false, nil); A_arbace_go_repl_linkname_cell_A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_102)); return A_arbace_go_repl__init_A_const_101 }
















func A_arbace_go_repl__init_A_Unit52__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(492, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_103; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_go_repl_intern_go_A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_go_repl_intern_go_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_339, false, nil); A_arbace_go_repl_intern_go_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_104)); return A_arbace_go_repl__init_A_const_103 }








func A_arbace_go_repl__init_A_Unit53__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(501, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_105; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_go_repl_define_BANG__A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_go_repl_define_BANG__A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_340, false, nil); A_arbace_go_repl_define_BANG__A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_106)); return A_arbace_go_repl__init_A_const_105 }
























































































































































































func A_arbace_go_repl__init_A_Unit54__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(686, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_107; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_go_repl_call0_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_go_repl_call0_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_341, false, nil); A_arbace_go_repl_call0_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_107; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_108)); return A_arbace_go_repl__init_A_const_107 }





func A_arbace_go_repl__init_A_Unit55__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(692, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_109; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_go_repl_complete_BANG__A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_go_repl_complete_BANG__A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_342, false, nil); A_arbace_go_repl_complete_BANG__A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_109; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_110)); return A_arbace_go_repl__init_A_const_109 }














func A_arbace_go_repl__init_A_Unit56__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(707, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_111; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_go_repl_after_load_A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_go_repl_after_load_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_343, false, nil); A_arbace_go_repl_after_load_A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_112)); return A_arbace_go_repl__init_A_const_111 }












func A_arbace_go_repl__init_A_Unit57__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(720, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_113; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_114)); v__1927001498__auto____1 = A_arbace_go_repl__init_A_const_113; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_go_repl__init_A_const_113; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_115)); var tmp3 *lang.Var = A_arbace_go_repl__init_A_const_113; var tmp4 *jrt.Boolean; var root_111 any = A_arbace_go_repl__init_A_const_116.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_113 lang.IFn
						if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = lang.RT_AFTER_LOAD.Ref(); var arg_115 any = A_arbace_go_repl__init_A_const_117.GetRawRoot__O(); var arg_116 any = A_arbace_go_repl__init_A_const_111; if linked_112 == nil { ifn_113.Invoke_O_O_O__O(arg_114, arg_115, arg_116) } else { linked_112.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_111, arg_114, arg_115, arg_116) }
//line :720:1
	tmp4 = jrt.Boolean_TRUE; tmp3.BindRoot_O__V(tmp4.Ref()); return A_arbace_go_repl__init_A_const_113 } }


func A_arbace_go_repl__init_A_Unit58__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(723, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_56; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_go_repl_load_digest_package_BANG__A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_go_repl_load_digest_package_BANG__A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_344, false, nil); A_arbace_go_repl_load_digest_package_BANG__A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_118)); return A_arbace_go_repl__init_A_const_56 }






































func A_arbace_go_repl__init_A_Unit59__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(762, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_52; var tmp2 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_go_repl_load_import_A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_go_repl_load_import_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_345, false, nil); A_arbace_go_repl_load_import_A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_119)); return A_arbace_go_repl__init_A_const_52 }















func A_arbace_go_repl__init_A_Unit60__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(778, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_120; var tmp2 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_go_repl_declare_BANG__A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_go_repl_declare_BANG__A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_346, false, nil); A_arbace_go_repl_declare_BANG__A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_121)); return A_arbace_go_repl__init_A_const_120 }

















































func A_arbace_go_repl__init_A_Unit61__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(828, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_122; var tmp2 any; var root_123 any = A_arbace_go_repl__init_A_const_24.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = A_arbace_go_repl__init_A_const_123; if linked_124 == nil { tmp2 = ifn_125.Invoke_O__O(arg_126) } else { tmp2 = linked_124.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_123, arg_126) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_go_repl__init_A_const_122; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_124)); return A_arbace_go_repl__init_A_const_122 }

func A_arbace_go_repl__init_A_Unit62__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(830, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_125; var tmp2 *lang.Compiler_AOTFn; var fnbody__128 any = A_arbace_go_repl_eval_BANG__A_New(); var tmp3 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_go_repl_eval_BANG__A_fn_class; if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_347, false, nil); A_arbace_go_repl_eval_BANG__A_fn_class = fncls__127d; tmp3 = fncls__127d } else { tmp3 = fncls__127 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__128, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_126)); return A_arbace_go_repl__init_A_const_125 }



















































func A_arbace_go_repl__init_A_Unit63__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(882, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_127; var tmp2 *lang.Compiler_AOTFn; var fnbody__130 any = A_arbace_go_repl_run_main_BANG__A_New(); var tmp3 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_go_repl_run_main_BANG__A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_348, false, nil); A_arbace_go_repl_run_main_BANG__A_fn_class = fncls__129d; tmp3 = fncls__129d } else { tmp3 = fncls__129 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__130, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_128)); return A_arbace_go_repl__init_A_const_127 }









func A_arbace_go_repl__init_A_Unit64__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(892, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_129; var tmp2 *lang.Compiler_AOTFn; var fnbody__132 any = A_arbace_go_repl_check_BANG__A_New(); var tmp3 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_go_repl_check_BANG__A_fn_class; if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_349, false, nil); A_arbace_go_repl_check_BANG__A_fn_class = fncls__131d; tmp3 = fncls__131d } else { tmp3 = fncls__131 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__132, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_130)); return A_arbace_go_repl__init_A_const_129 }







func A_arbace_go_repl__init_A_Unit65__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(900, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_131; var tmp2 *lang.Compiler_AOTFn; var fnbody__134 any = A_arbace_go_repl_resolve_types_A_New(); var tmp3 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_go_repl_resolve_types_A_fn_class; if fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_350, false, nil); A_arbace_go_repl_resolve_types_A_fn_class = fncls__133d; tmp3 = fncls__133d } else { tmp3 = fncls__133 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__134, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_132)); return A_arbace_go_repl__init_A_const_131 }
























func A_arbace_go_repl__init_A_Unit66__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(925, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_133; var tmp2 *lang.Compiler_AOTFn; var fnbody__136 any = A_arbace_go_repl_inst_BANG__A_New(); var tmp3 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_go_repl_inst_BANG__A_fn_class; if fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_351, false, nil); A_arbace_go_repl_inst_BANG__A_fn_class = fncls__135d; tmp3 = fncls__135d } else { tmp3 = fncls__135 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__136, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_134)); return A_arbace_go_repl__init_A_const_133 }
































func A_arbace_go_repl__init_A_Unit67__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(958, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_135; var tmp2 *lang.Compiler_AOTFn; var fnbody__138 any = A_arbace_go_repl_listed_generic_BANG__A_New(); var tmp3 *jrt.Class; var fncls__137 *jrt.Class = A_arbace_go_repl_listed_generic_BANG__A_fn_class; if fncls__137 == nil { var fncls__137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_352, false, nil); A_arbace_go_repl_listed_generic_BANG__A_fn_class = fncls__137d; tmp3 = fncls__137d } else { tmp3 = fncls__137 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__138, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_136)); return A_arbace_go_repl__init_A_const_135 }



















func A_arbace_go_repl__init_A_Unit68__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(978, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_137; var tmp2 *lang.Compiler_AOTFn; var fnbody__140 any = A_arbace_go_repl_form_text_A_New(); var tmp3 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_go_repl_form_text_A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_353, false, nil); A_arbace_go_repl_form_text_A_fn_class = fncls__139d; tmp3 = fncls__139d } else { tmp3 = fncls__139 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__140, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_138)); return A_arbace_go_repl__init_A_const_137 }





func A_arbace_go_repl__init_A_Unit69__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(984, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_139; var tmp2 *lang.Compiler_AOTFn; var fnbody__142 any = A_arbace_go_repl_write_package_BANG__A_New(); var tmp3 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_go_repl_write_package_BANG__A_fn_class; if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_354, false, nil); A_arbace_go_repl_write_package_BANG__A_fn_class = fncls__141d; tmp3 = fncls__141d } else { tmp3 = fncls__141 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__142, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_139; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_140)); return A_arbace_go_repl__init_A_const_139 }
























func A_arbace_go_repl__init_A_Unit70__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1009, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_141; var tmp2 *lang.Compiler_AOTFn; var fnbody__144 any = A_arbace_go_repl_interpreted_closure_A_New(); var tmp3 *jrt.Class; var fncls__143 *jrt.Class = A_arbace_go_repl_interpreted_closure_A_fn_class; if fncls__143 == nil { var fncls__143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_355, false, nil); A_arbace_go_repl_interpreted_closure_A_fn_class = fncls__143d; tmp3 = fncls__143d } else { tmp3 = fncls__143 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__144, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_141; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_142)); return A_arbace_go_repl__init_A_const_141 }












func A_arbace_go_repl__init_A_Unit71__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1022, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_143; var tmp2 *lang.Compiler_AOTFn; var fnbody__146 any = A_arbace_go_repl_run_compiled_BANG__A_New(); var tmp3 *jrt.Class; var fncls__145 *jrt.Class = A_arbace_go_repl_run_compiled_BANG__A_fn_class; if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_356, false, nil); A_arbace_go_repl_run_compiled_BANG__A_fn_class = fncls__145d; tmp3 = fncls__145d } else { tmp3 = fncls__145 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__146, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_143; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_144)); return A_arbace_go_repl__init_A_const_143 }



type A_arbace_go_repl__init_A struct{ jrt.Object }

var A_arbace_go_repl__init_A_const_pool *jrt.RefArray

var A_arbace_go_repl__init_A_const_0 *lang.Var

var A_arbace_go_repl__init_A_const_1 any

var A_arbace_go_repl__init_A_const_2 any

var A_arbace_go_repl__init_A_const_3 any

var A_arbace_go_repl__init_A_const_4 *lang.Var

var A_arbace_go_repl__init_A_const_5 any

var A_arbace_go_repl__init_A_const_6 *lang.Var

var A_arbace_go_repl__init_A_const_7 any

var A_arbace_go_repl__init_A_const_8 *lang.Var

var A_arbace_go_repl__init_A_const_9 any

var A_arbace_go_repl__init_A_const_10 *lang.Var

var A_arbace_go_repl__init_A_const_11 any

var A_arbace_go_repl__init_A_const_12 *lang.Var

var A_arbace_go_repl__init_A_const_13 any

var A_arbace_go_repl__init_A_const_14 *lang.Var

var A_arbace_go_repl__init_A_const_15 any

var A_arbace_go_repl__init_A_const_16 *lang.Var

var A_arbace_go_repl__init_A_const_17 any

var A_arbace_go_repl__init_A_const_18 *lang.Var

var A_arbace_go_repl__init_A_const_19 any

var A_arbace_go_repl__init_A_const_20 *lang.Var

var A_arbace_go_repl__init_A_const_21 any

var A_arbace_go_repl__init_A_const_22 *lang.Var

var A_arbace_go_repl__init_A_const_23 any

var A_arbace_go_repl__init_A_const_24 *lang.Var

var A_arbace_go_repl__init_A_const_25 any

var A_arbace_go_repl__init_A_const_26 *lang.Var

var A_arbace_go_repl__init_A_const_27 any

var A_arbace_go_repl__init_A_const_28 *lang.Var

var A_arbace_go_repl__init_A_const_29 any

var A_arbace_go_repl__init_A_const_30 *lang.Var

var A_arbace_go_repl__init_A_const_31 any

var A_arbace_go_repl__init_A_const_32 *lang.Var

var A_arbace_go_repl__init_A_const_33 any

var A_arbace_go_repl__init_A_const_34 *lang.Var

var A_arbace_go_repl__init_A_const_35 any

var A_arbace_go_repl__init_A_const_36 *lang.Var

var A_arbace_go_repl__init_A_const_37 any

var A_arbace_go_repl__init_A_const_38 *lang.Var

var A_arbace_go_repl__init_A_const_39 any

var A_arbace_go_repl__init_A_const_40 *lang.Var

var A_arbace_go_repl__init_A_const_41 any

var A_arbace_go_repl__init_A_const_42 *lang.Var

var A_arbace_go_repl__init_A_const_43 any

var A_arbace_go_repl__init_A_const_44 *lang.Var

var A_arbace_go_repl__init_A_const_45 any

var A_arbace_go_repl__init_A_const_46 *lang.Var

var A_arbace_go_repl__init_A_const_47 any

var A_arbace_go_repl__init_A_const_48 *lang.Var

var A_arbace_go_repl__init_A_const_49 any

var A_arbace_go_repl__init_A_const_50 *lang.Var

var A_arbace_go_repl__init_A_const_51 any

var A_arbace_go_repl__init_A_const_52 *lang.Var

var A_arbace_go_repl__init_A_const_53 any

var A_arbace_go_repl__init_A_const_54 *lang.Var

var A_arbace_go_repl__init_A_const_55 any

var A_arbace_go_repl__init_A_const_56 *lang.Var

var A_arbace_go_repl__init_A_const_57 any

var A_arbace_go_repl__init_A_const_58 *lang.Var

var A_arbace_go_repl__init_A_const_59 any

var A_arbace_go_repl__init_A_const_60 *lang.Var

var A_arbace_go_repl__init_A_const_61 any

var A_arbace_go_repl__init_A_const_62 *lang.Var

var A_arbace_go_repl__init_A_const_63 any

var A_arbace_go_repl__init_A_const_64 *lang.Var

var A_arbace_go_repl__init_A_const_65 any

var A_arbace_go_repl__init_A_const_66 *lang.Var

var A_arbace_go_repl__init_A_const_67 any

var A_arbace_go_repl__init_A_const_68 *lang.Var

var A_arbace_go_repl__init_A_const_69 any

var A_arbace_go_repl__init_A_const_70 *lang.Var

var A_arbace_go_repl__init_A_const_71 any

var A_arbace_go_repl__init_A_const_72 *lang.Var

var A_arbace_go_repl__init_A_const_73 any

var A_arbace_go_repl__init_A_const_74 *lang.Var

var A_arbace_go_repl__init_A_const_75 any

var A_arbace_go_repl__init_A_const_76 *lang.Var

var A_arbace_go_repl__init_A_const_77 any

var A_arbace_go_repl__init_A_const_78 *lang.Var

var A_arbace_go_repl__init_A_const_79 any

var A_arbace_go_repl__init_A_const_80 *lang.Var

var A_arbace_go_repl__init_A_const_81 any

var A_arbace_go_repl__init_A_const_82 *lang.Var

var A_arbace_go_repl__init_A_const_83 any

var A_arbace_go_repl__init_A_const_84 *lang.Var

var A_arbace_go_repl__init_A_const_85 any

var A_arbace_go_repl__init_A_const_86 *lang.Var

var A_arbace_go_repl__init_A_const_87 any

var A_arbace_go_repl__init_A_const_88 any

var A_arbace_go_repl__init_A_const_89 *lang.Var

var A_arbace_go_repl__init_A_const_90 any

var A_arbace_go_repl__init_A_const_91 any

var A_arbace_go_repl__init_A_const_92 *lang.Var

var A_arbace_go_repl__init_A_const_93 any

var A_arbace_go_repl__init_A_const_94 *lang.Var

var A_arbace_go_repl__init_A_const_95 *lang.Keyword

var A_arbace_go_repl__init_A_const_96 *lang.Keyword

var A_arbace_go_repl__init_A_const_97 any

var A_arbace_go_repl__init_A_const_98 *lang.Var

var A_arbace_go_repl__init_A_const_99 any

var A_arbace_go_repl__init_A_const_100 any

var A_arbace_go_repl__init_A_const_101 *lang.Var

var A_arbace_go_repl__init_A_const_102 any

var A_arbace_go_repl__init_A_const_103 *lang.Var

var A_arbace_go_repl__init_A_const_104 any

var A_arbace_go_repl__init_A_const_105 *lang.Var

var A_arbace_go_repl__init_A_const_106 any

var A_arbace_go_repl__init_A_const_107 *lang.Var

var A_arbace_go_repl__init_A_const_108 any

var A_arbace_go_repl__init_A_const_109 *lang.Var

var A_arbace_go_repl__init_A_const_110 any

var A_arbace_go_repl__init_A_const_111 *lang.Var

var A_arbace_go_repl__init_A_const_112 any

var A_arbace_go_repl__init_A_const_113 *lang.Var

var A_arbace_go_repl__init_A_const_114 any

var A_arbace_go_repl__init_A_const_115 any

var A_arbace_go_repl__init_A_const_116 *lang.Var

var A_arbace_go_repl__init_A_const_117 *lang.Var

var A_arbace_go_repl__init_A_const_118 any

var A_arbace_go_repl__init_A_const_119 any

var A_arbace_go_repl__init_A_const_120 *lang.Var

var A_arbace_go_repl__init_A_const_121 any

var A_arbace_go_repl__init_A_const_122 *lang.Var

var A_arbace_go_repl__init_A_const_123 any

var A_arbace_go_repl__init_A_const_124 any

var A_arbace_go_repl__init_A_const_125 *lang.Var

var A_arbace_go_repl__init_A_const_126 any

var A_arbace_go_repl__init_A_const_127 *lang.Var

var A_arbace_go_repl__init_A_const_128 any

var A_arbace_go_repl__init_A_const_129 *lang.Var

var A_arbace_go_repl__init_A_const_130 any

var A_arbace_go_repl__init_A_const_131 *lang.Var

var A_arbace_go_repl__init_A_const_132 any

var A_arbace_go_repl__init_A_const_133 *lang.Var

var A_arbace_go_repl__init_A_const_134 any

var A_arbace_go_repl__init_A_const_135 *lang.Var

var A_arbace_go_repl__init_A_const_136 any

var A_arbace_go_repl__init_A_const_137 *lang.Var

var A_arbace_go_repl__init_A_const_138 any

var A_arbace_go_repl__init_A_const_139 *lang.Var

var A_arbace_go_repl__init_A_const_140 any

var A_arbace_go_repl__init_A_const_141 *lang.Var

var A_arbace_go_repl__init_A_const_142 any

var A_arbace_go_repl__init_A_const_143 *lang.Var

var A_arbace_go_repl__init_A_const_144 any

var A_arbace_go_repl__init_A_init jrt.ClassInit

func A_arbace_go_repl__init_A_Init() { if !A_arbace_go_repl__init_A_init.Done() { A_arbace_go_repl__init_A_init.Run(A_arbace_go_repl__init_A_clinit) } }

func A_arbace_go_repl__init_A_clinit() { A_arbace_go_repl__init_A_clinit_p0(); A_arbace_go_repl__init_A_clinit_p1(); A_arbace_go_repl__init_A_clinit_p2(); A_arbace_go_repl__init_A_clinit_p3(); A_arbace_go_repl__init_A_clinit_p4(); A_arbace_go_repl__init_A_clinit_p5(); A_arbace_go_repl__init_A_clinit_p6(); A_arbace_go_repl__init_A_clinit_p7(); A_arbace_go_repl__init_A_clinit_p8(); A_arbace_go_repl__init_A_clinit_p9(); A_arbace_go_repl__init_A_clinit_p10() }

func A_arbace_go_repl__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_repl__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_294, 197); A_arbace_go_repl__init_A_const_0 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[52]); A_arbace_go_repl__init_A_const_1 = A_arbace_go_repl__init_A_const_pool.A[53]; A_arbace_go_repl__init_A_const_2 = A_arbace_go_repl__init_A_const_pool.A[54]; A_arbace_go_repl__init_A_const_3 = A_arbace_go_repl__init_A_const_pool.A[55]; A_arbace_go_repl__init_A_const_4 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[56]); A_arbace_go_repl__init_A_const_5 = A_arbace_go_repl__init_A_const_pool.A[57]; A_arbace_go_repl__init_A_const_6 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[58]); A_arbace_go_repl__init_A_const_7 = A_arbace_go_repl__init_A_const_pool.A[59]; A_arbace_go_repl__init_A_const_8 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[60]); A_arbace_go_repl__init_A_const_9 = A_arbace_go_repl__init_A_const_pool.A[61]; A_arbace_go_repl__init_A_const_10 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[62]); A_arbace_go_repl__init_A_const_11 = A_arbace_go_repl__init_A_const_pool.A[63]; A_arbace_go_repl__init_A_const_12 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[64]) }

func A_arbace_go_repl__init_A_clinit_p1() { A_arbace_go_repl__init_A_const_13 = A_arbace_go_repl__init_A_const_pool.A[65]; A_arbace_go_repl__init_A_const_14 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[66]); A_arbace_go_repl__init_A_const_15 = A_arbace_go_repl__init_A_const_pool.A[67]; A_arbace_go_repl__init_A_const_16 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[68]); A_arbace_go_repl__init_A_const_17 = A_arbace_go_repl__init_A_const_pool.A[69]; A_arbace_go_repl__init_A_const_18 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[70]); A_arbace_go_repl__init_A_const_19 = A_arbace_go_repl__init_A_const_pool.A[71]; A_arbace_go_repl__init_A_const_20 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[72]); A_arbace_go_repl__init_A_const_21 = A_arbace_go_repl__init_A_const_pool.A[73]; A_arbace_go_repl__init_A_const_22 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[74]); A_arbace_go_repl__init_A_const_23 = A_arbace_go_repl__init_A_const_pool.A[75]; A_arbace_go_repl__init_A_const_24 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[76]); A_arbace_go_repl__init_A_const_25 = A_arbace_go_repl__init_A_const_pool.A[77] }

func A_arbace_go_repl__init_A_clinit_p2() { A_arbace_go_repl__init_A_const_26 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[78]); A_arbace_go_repl__init_A_const_27 = A_arbace_go_repl__init_A_const_pool.A[79]; A_arbace_go_repl__init_A_const_28 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[80]); A_arbace_go_repl__init_A_const_29 = A_arbace_go_repl__init_A_const_pool.A[81]; A_arbace_go_repl__init_A_const_30 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[82]); A_arbace_go_repl__init_A_const_31 = A_arbace_go_repl__init_A_const_pool.A[83]; A_arbace_go_repl__init_A_const_32 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[84]); A_arbace_go_repl__init_A_const_33 = A_arbace_go_repl__init_A_const_pool.A[85]; A_arbace_go_repl__init_A_const_34 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[86]); A_arbace_go_repl__init_A_const_35 = A_arbace_go_repl__init_A_const_pool.A[87]; A_arbace_go_repl__init_A_const_36 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[88]); A_arbace_go_repl__init_A_const_37 = A_arbace_go_repl__init_A_const_pool.A[89]; A_arbace_go_repl__init_A_const_38 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[90]) }

func A_arbace_go_repl__init_A_clinit_p3() { A_arbace_go_repl__init_A_const_39 = A_arbace_go_repl__init_A_const_pool.A[91]; A_arbace_go_repl__init_A_const_40 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[92]); A_arbace_go_repl__init_A_const_41 = A_arbace_go_repl__init_A_const_pool.A[93]; A_arbace_go_repl__init_A_const_42 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[94]); A_arbace_go_repl__init_A_const_43 = A_arbace_go_repl__init_A_const_pool.A[95]; A_arbace_go_repl__init_A_const_44 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[96]); A_arbace_go_repl__init_A_const_45 = A_arbace_go_repl__init_A_const_pool.A[97]; A_arbace_go_repl__init_A_const_46 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[98]); A_arbace_go_repl__init_A_const_47 = A_arbace_go_repl__init_A_const_pool.A[99]; A_arbace_go_repl__init_A_const_48 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[100]); A_arbace_go_repl__init_A_const_49 = A_arbace_go_repl__init_A_const_pool.A[101]; A_arbace_go_repl__init_A_const_50 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[102]); A_arbace_go_repl__init_A_const_51 = A_arbace_go_repl__init_A_const_pool.A[103] }

func A_arbace_go_repl__init_A_clinit_p4() { A_arbace_go_repl__init_A_const_52 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[104]); A_arbace_go_repl__init_A_const_53 = A_arbace_go_repl__init_A_const_pool.A[105]; A_arbace_go_repl__init_A_const_54 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[106]); A_arbace_go_repl__init_A_const_55 = A_arbace_go_repl__init_A_const_pool.A[107]; A_arbace_go_repl__init_A_const_56 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[108]); A_arbace_go_repl__init_A_const_57 = A_arbace_go_repl__init_A_const_pool.A[109]; A_arbace_go_repl__init_A_const_58 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[110]); A_arbace_go_repl__init_A_const_59 = A_arbace_go_repl__init_A_const_pool.A[111]; A_arbace_go_repl__init_A_const_60 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[112]); A_arbace_go_repl__init_A_const_61 = A_arbace_go_repl__init_A_const_pool.A[113]; A_arbace_go_repl__init_A_const_62 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[114]); A_arbace_go_repl__init_A_const_63 = A_arbace_go_repl__init_A_const_pool.A[115]; A_arbace_go_repl__init_A_const_64 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[116]) }

func A_arbace_go_repl__init_A_clinit_p5() { A_arbace_go_repl__init_A_const_65 = A_arbace_go_repl__init_A_const_pool.A[117]; A_arbace_go_repl__init_A_const_66 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[118]); A_arbace_go_repl__init_A_const_67 = A_arbace_go_repl__init_A_const_pool.A[119]; A_arbace_go_repl__init_A_const_68 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[120]); A_arbace_go_repl__init_A_const_69 = A_arbace_go_repl__init_A_const_pool.A[121]; A_arbace_go_repl__init_A_const_70 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[122]); A_arbace_go_repl__init_A_const_71 = A_arbace_go_repl__init_A_const_pool.A[123]; A_arbace_go_repl__init_A_const_72 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[124]); A_arbace_go_repl__init_A_const_73 = A_arbace_go_repl__init_A_const_pool.A[125]; A_arbace_go_repl__init_A_const_74 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[126]); A_arbace_go_repl__init_A_const_75 = A_arbace_go_repl__init_A_const_pool.A[127]; A_arbace_go_repl__init_A_const_76 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[128]); A_arbace_go_repl__init_A_const_77 = A_arbace_go_repl__init_A_const_pool.A[129] }

func A_arbace_go_repl__init_A_clinit_p6() { A_arbace_go_repl__init_A_const_78 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[130]); A_arbace_go_repl__init_A_const_79 = A_arbace_go_repl__init_A_const_pool.A[131]; A_arbace_go_repl__init_A_const_80 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[132]); A_arbace_go_repl__init_A_const_81 = A_arbace_go_repl__init_A_const_pool.A[133]; A_arbace_go_repl__init_A_const_82 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[134]); A_arbace_go_repl__init_A_const_83 = A_arbace_go_repl__init_A_const_pool.A[135]; A_arbace_go_repl__init_A_const_84 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[136]); A_arbace_go_repl__init_A_const_85 = A_arbace_go_repl__init_A_const_pool.A[137]; A_arbace_go_repl__init_A_const_86 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[138]); A_arbace_go_repl__init_A_const_87 = A_arbace_go_repl__init_A_const_pool.A[139]; A_arbace_go_repl__init_A_const_88 = A_arbace_go_repl__init_A_const_pool.A[140]; A_arbace_go_repl__init_A_const_89 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[141]); A_arbace_go_repl__init_A_const_90 = A_arbace_go_repl__init_A_const_pool.A[142]; A_arbace_go_repl__init_A_const_91 = A_arbace_go_repl__init_A_const_pool.A[143] }

func A_arbace_go_repl__init_A_clinit_p7() { A_arbace_go_repl__init_A_const_92 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[144]); A_arbace_go_repl__init_A_const_93 = A_arbace_go_repl__init_A_const_pool.A[145]; A_arbace_go_repl__init_A_const_94 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[146]); A_arbace_go_repl__init_A_const_95 = lang.Keyword_Cast(A_arbace_go_repl__init_A_const_pool.A[147]); A_arbace_go_repl__init_A_const_96 = lang.Keyword_Cast(A_arbace_go_repl__init_A_const_pool.A[148]); A_arbace_go_repl__init_A_const_97 = A_arbace_go_repl__init_A_const_pool.A[149]; A_arbace_go_repl__init_A_const_98 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[150]); A_arbace_go_repl__init_A_const_99 = A_arbace_go_repl__init_A_const_pool.A[151]; A_arbace_go_repl__init_A_const_100 = A_arbace_go_repl__init_A_const_pool.A[152]; A_arbace_go_repl__init_A_const_101 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[153]); A_arbace_go_repl__init_A_const_102 = A_arbace_go_repl__init_A_const_pool.A[154]; A_arbace_go_repl__init_A_const_103 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[155]); A_arbace_go_repl__init_A_const_104 = A_arbace_go_repl__init_A_const_pool.A[156] }

func A_arbace_go_repl__init_A_clinit_p8() { A_arbace_go_repl__init_A_const_105 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[157]); A_arbace_go_repl__init_A_const_106 = A_arbace_go_repl__init_A_const_pool.A[158]; A_arbace_go_repl__init_A_const_107 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[159]); A_arbace_go_repl__init_A_const_108 = A_arbace_go_repl__init_A_const_pool.A[160]; A_arbace_go_repl__init_A_const_109 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[161]); A_arbace_go_repl__init_A_const_110 = A_arbace_go_repl__init_A_const_pool.A[162]; A_arbace_go_repl__init_A_const_111 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[163]); A_arbace_go_repl__init_A_const_112 = A_arbace_go_repl__init_A_const_pool.A[164]; A_arbace_go_repl__init_A_const_113 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[165]); A_arbace_go_repl__init_A_const_114 = A_arbace_go_repl__init_A_const_pool.A[166]; A_arbace_go_repl__init_A_const_115 = A_arbace_go_repl__init_A_const_pool.A[167]; A_arbace_go_repl__init_A_const_116 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[168]); A_arbace_go_repl__init_A_const_117 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[169]) }

func A_arbace_go_repl__init_A_clinit_p9() { A_arbace_go_repl__init_A_const_118 = A_arbace_go_repl__init_A_const_pool.A[170]; A_arbace_go_repl__init_A_const_119 = A_arbace_go_repl__init_A_const_pool.A[171]; A_arbace_go_repl__init_A_const_120 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[172]); A_arbace_go_repl__init_A_const_121 = A_arbace_go_repl__init_A_const_pool.A[173]; A_arbace_go_repl__init_A_const_122 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[174]); A_arbace_go_repl__init_A_const_123 = A_arbace_go_repl__init_A_const_pool.A[175]; A_arbace_go_repl__init_A_const_124 = A_arbace_go_repl__init_A_const_pool.A[176]; A_arbace_go_repl__init_A_const_125 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[177]); A_arbace_go_repl__init_A_const_126 = A_arbace_go_repl__init_A_const_pool.A[178]; A_arbace_go_repl__init_A_const_127 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[179]); A_arbace_go_repl__init_A_const_128 = A_arbace_go_repl__init_A_const_pool.A[180]; A_arbace_go_repl__init_A_const_129 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[181]); A_arbace_go_repl__init_A_const_130 = A_arbace_go_repl__init_A_const_pool.A[182]; A_arbace_go_repl__init_A_const_131 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[183]) }

func A_arbace_go_repl__init_A_clinit_p10() { A_arbace_go_repl__init_A_const_132 = A_arbace_go_repl__init_A_const_pool.A[184]; A_arbace_go_repl__init_A_const_133 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[185]); A_arbace_go_repl__init_A_const_134 = A_arbace_go_repl__init_A_const_pool.A[186]; A_arbace_go_repl__init_A_const_135 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[187]); A_arbace_go_repl__init_A_const_136 = A_arbace_go_repl__init_A_const_pool.A[188]; A_arbace_go_repl__init_A_const_137 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[189]); A_arbace_go_repl__init_A_const_138 = A_arbace_go_repl__init_A_const_pool.A[190]; A_arbace_go_repl__init_A_const_139 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[191]); A_arbace_go_repl__init_A_const_140 = A_arbace_go_repl__init_A_const_pool.A[192]; A_arbace_go_repl__init_A_const_141 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[193]); A_arbace_go_repl__init_A_const_142 = A_arbace_go_repl__init_A_const_pool.A[194]; A_arbace_go_repl__init_A_const_143 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[195]); A_arbace_go_repl__init_A_const_144 = A_arbace_go_repl__init_A_const_pool.A[196] }

func A_arbace_go_repl__init_A_New() *A_arbace_go_repl__init_A { A_arbace_go_repl__init_A_Init(); t := &A_arbace_go_repl__init_A{}; t.Ctor(); return t }

func (t *A_arbace_go_repl__init_A) Ctor() {}

func (t *A_arbace_go_repl__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_repl__init_A) GetClass__Class() *jrt.Class { return A_arbace_go_repl__init_A_class }

func (t *A_arbace_go_repl__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_repl__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_repl__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_repl__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_repl__init_A); return ok }

func A_arbace_go_repl__init_A_Cast(x any) *A_arbace_go_repl__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_repl__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_repl__init_A_class)) }; return v }
