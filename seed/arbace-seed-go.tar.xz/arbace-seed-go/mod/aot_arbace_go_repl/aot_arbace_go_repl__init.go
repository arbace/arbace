//line aot_arbace_go_repl__init.ae:1
package aot_arbace_go_repl

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_repl__init_A_Unit0__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_go_repl__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_repl__init_A_const_1) }
//line :1:1
func A_arbace_go_repl__init_A_Unit1__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_go_repl__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_2)) }
//line :1:1
func A_arbace_go_repl__init_A_Unit2__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_go_repl_eval794000004_loading__1927001464__auto____794000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_repl_eval794000004_loading__1927001464__auto____794000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_215, false); A_arbace_go_repl_eval794000004_loading__1927001464__auto____794000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_go_repl__init_A_Unit3__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_go_repl__init_A_const_1)).Equals_O__Z(A_arbace_go_repl__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_go_repl_eval794000008_fn__794000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_go_repl_eval794000008_fn__794000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_216, false); A_arbace_go_repl_eval794000008_fn__794000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_go_repl__init_A_Load__O() any { A_arbace_go_repl__init_A_Init(); jrt.StartCheck(); A_arbace_go_repl__init_A_Unit0__O(); A_arbace_go_repl__init_A_Unit1__O(); A_arbace_go_repl__init_A_Unit2__O(); A_arbace_go_repl__init_A_Unit3__O(); A_arbace_go_repl__init_A_Unit4__O(); A_arbace_go_repl__init_A_Unit5__O(); A_arbace_go_repl__init_A_Unit6__O(); A_arbace_go_repl__init_A_Unit7__O(); A_arbace_go_repl__init_A_Unit8__O(); A_arbace_go_repl__init_A_Unit9__O(); A_arbace_go_repl__init_A_Unit10__O(); A_arbace_go_repl__init_A_Unit11__O(); A_arbace_go_repl__init_A_Unit12__O(); A_arbace_go_repl__init_A_Unit13__O(); A_arbace_go_repl__init_A_Unit14__O(); A_arbace_go_repl__init_A_Unit15__O(); A_arbace_go_repl__init_A_Unit16__O(); A_arbace_go_repl__init_A_Unit17__O(); A_arbace_go_repl__init_A_Unit18__O(); A_arbace_go_repl__init_A_Unit19__O(); A_arbace_go_repl__init_A_Unit20__O(); A_arbace_go_repl__init_A_Unit21__O(); A_arbace_go_repl__init_A_Unit22__O(); A_arbace_go_repl__init_A_Unit23__O(); A_arbace_go_repl__init_A_Unit24__O(); A_arbace_go_repl__init_A_Unit25__O(); A_arbace_go_repl__init_A_Unit26__O(); A_arbace_go_repl__init_A_Unit27__O(); A_arbace_go_repl__init_A_Unit28__O(); A_arbace_go_repl__init_A_Unit29__O(); A_arbace_go_repl__init_A_Unit30__O(); A_arbace_go_repl__init_A_Unit31__O(); A_arbace_go_repl__init_A_Unit32__O(); A_arbace_go_repl__init_A_Unit33__O(); A_arbace_go_repl__init_A_Unit34__O(); A_arbace_go_repl__init_A_Unit35__O(); A_arbace_go_repl__init_A_Unit36__O(); A_arbace_go_repl__init_A_Unit37__O(); A_arbace_go_repl__init_A_Unit38__O(); A_arbace_go_repl__init_A_Unit39__O(); A_arbace_go_repl__init_A_Unit40__O(); A_arbace_go_repl__init_A_Unit41__O(); A_arbace_go_repl__init_A_Unit42__O(); A_arbace_go_repl__init_A_Unit43__O(); A_arbace_go_repl__init_A_Unit44__O(); A_arbace_go_repl__init_A_Unit45__O(); A_arbace_go_repl__init_A_Unit46__O(); A_arbace_go_repl__init_A_Unit47__O(); A_arbace_go_repl__init_A_Unit48__O(); A_arbace_go_repl__init_A_Unit49__O(); A_arbace_go_repl__init_A_Unit50__O(); A_arbace_go_repl__init_A_Unit51__O(); A_arbace_go_repl__init_A_Unit52__O(); A_arbace_go_repl__init_A_Unit53__O(); return nil }




















func A_arbace_go_repl__init_A_Unit4__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_4; var tmp2 any = A_arbace_go_repl_fn__794000012_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_repl_fn__794000012_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_217, false); A_arbace_go_repl_fn__794000012_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_5)); return A_arbace_go_repl__init_A_const_4 }

func A_arbace_go_repl__init_A_Unit5__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(28, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_6; var tmp2 any = A_arbace_go_repl_listed_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_go_repl_listed_QMARK__A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_218, false); A_arbace_go_repl_listed_QMARK__A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_7)); return A_arbace_go_repl__init_A_const_6 }




func A_arbace_go_repl__init_A_Unit6__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_8; var tmp2 any = A_arbace_go_repl_fn__794000015_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_repl_fn__794000015_A_fn_class; if
						fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_219, false); A_arbace_go_repl_fn__794000015_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; /*line :33:1*/tmp1.BindRoot_O__V(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_9)); return A_arbace_go_repl__init_A_const_8 }





func A_arbace_go_repl__init_A_Unit7__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(39, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_10; var tmp2 any = A_arbace_go_repl_digest_forms_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_go_repl_digest_forms_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_220, false); A_arbace_go_repl_digest_forms_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_11)); return A_arbace_go_repl__init_A_const_10 }






func A_arbace_go_repl__init_A_Unit8__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(46, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_12; var tmp2 any = A_arbace_go_repl_fn__794000024_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_repl_fn__794000024_A_fn_class; if

	fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_221, false); A_arbace_go_repl_fn__794000024_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; /*line :46:1*/tmp1.BindRoot_O__V(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_13)); return A_arbace_go_repl__init_A_const_12 }







func A_arbace_go_repl__init_A_Unit9__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(54, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_14; var tmp2 any = A_arbace_go_repl_fn__794000028_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_go_repl_fn__794000028_A_fn_class; if

	fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_222, false); A_arbace_go_repl_fn__794000028_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; /*line :54:1*/tmp1.BindRoot_O__V(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_15)); return A_arbace_go_repl__init_A_const_14 }









func A_arbace_go_repl__init_A_Unit10__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(64, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_16; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_17)); v__1927001498__auto____1 = A_arbace_go_repl__init_A_const_16; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_go_repl__init_A_const_16; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_19)); var tmp3 *lang.Var = A_arbace_go_repl__init_A_const_16; var tmp4 any; var root_9 any = A_arbace_go_repl__init_A_const_18.GetRawRoot__O(); var linked_10 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_9, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_11 lang.IFn; if linked_10 == nil { ifn_11 = lang.IFn_Cast(root_9) } else { ifn_11 = nil }; var arg_12 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_10 == nil { tmp4 = ifn_11.Invoke_O__O(arg_12) } else { tmp4 = linked_10.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_9, arg_12) }; tmp3.BindRoot_O__V(tmp4); return A_arbace_go_repl__init_A_const_16 } }

func A_arbace_go_repl__init_A_Unit11__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(66, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_20; var tmp2 any = A_arbace_go_repl_path__GT_ns_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_repl_path__GT_ns_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_223, false); A_arbace_go_repl_path__GT_ns_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_21)); return A_arbace_go_repl__init_A_const_20 }




func A_arbace_go_repl__init_A_Unit12__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(71, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_22; var tmp2 any = A_arbace_go_repl_ns__GT_path_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_go_repl_ns__GT_path_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_224, false); A_arbace_go_repl_ns__GT_path_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_23)); return A_arbace_go_repl__init_A_const_22 }




func A_arbace_go_repl__init_A_Unit13__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(76, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_24; var tmp2 any = A_arbace_go_repl_new_state_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_repl_new_state_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_225, false); A_arbace_go_repl_new_state_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_25)); return A_arbace_go_repl__init_A_const_24 }



func A_arbace_go_repl__init_A_Unit14__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(80, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_26; var tmp2 any = A_arbace_go_repl_package_state_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_go_repl_package_state_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_226, false); A_arbace_go_repl_package_state_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_27)); return A_arbace_go_repl__init_A_const_26 }















func A_arbace_go_repl__init_A_Unit15__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(96, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_28; var tmp2 any = A_arbace_go_repl_package_BANG__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_repl_package_BANG__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_227, false); A_arbace_go_repl_package_BANG__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_29)); return A_arbace_go_repl__init_A_const_28 }












func A_arbace_go_repl__init_A_Unit16__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(109, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_30; var tmp2 any = A_arbace_go_repl_file_entry_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_go_repl_file_entry_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_228, false); A_arbace_go_repl_file_entry_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_31)); return A_arbace_go_repl__init_A_const_30 }


func A_arbace_go_repl__init_A_Unit17__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(112, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_32; var tmp2 any = A_arbace_go_repl_update_file_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_repl_update_file_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_229, false); A_arbace_go_repl_update_file_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_33)); return A_arbace_go_repl__init_A_const_32 }






func A_arbace_go_repl__init_A_Unit18__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(119, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_34; var tmp2 any = A_arbace_go_repl_file_BANG__A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_go_repl_file_BANG__A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_230, false); A_arbace_go_repl_file_BANG__A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_35)); return A_arbace_go_repl__init_A_const_34 }








func A_arbace_go_repl__init_A_Unit19__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(128, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_36; var tmp2 any = A_arbace_go_repl_import_BANG__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_repl_import_BANG__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_231, false); A_arbace_go_repl_import_BANG__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_37)); return A_arbace_go_repl__init_A_const_36 }










func A_arbace_go_repl__init_A_Unit20__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(139, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_38; var tmp2 any = A_arbace_go_repl_decl_names_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_go_repl_decl_names_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_232, false); A_arbace_go_repl_decl_names_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_39)); return A_arbace_go_repl__init_A_const_38 }



























func A_arbace_go_repl__init_A_Unit21__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(167, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_40; var tmp2 any = A_arbace_go_repl_error_text_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_repl_error_text_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_233, false); A_arbace_go_repl_error_text_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_41)); return A_arbace_go_repl__init_A_const_40 }







func A_arbace_go_repl__init_A_Unit22__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(175, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_42; var tmp2 any = A_arbace_go_repl_repl_source_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_go_repl_repl_source_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_234, false); A_arbace_go_repl_repl_source_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_43)); return A_arbace_go_repl__init_A_const_42 }

func A_arbace_go_repl__init_A_Unit23__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(177, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_44; var tmp2 any = A_arbace_go_repl_source_of_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_go_repl_source_of_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_235, false); A_arbace_go_repl_source_of_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_45)); return A_arbace_go_repl__init_A_const_44 }








func A_arbace_go_repl__init_A_Unit24__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(186, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_46; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_47)); return A_arbace_go_repl__init_A_const_46 }

func A_arbace_go_repl__init_A_Unit25__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(188, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_48; var tmp2 any = A_arbace_go_repl_session_for_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_go_repl_session_for_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_236, false); A_arbace_go_repl_session_for_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_49)); return A_arbace_go_repl__init_A_const_48 }










func A_arbace_go_repl__init_A_Unit26__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(199, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_50; var tmp2 any = A_arbace_go_repl_check_source_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_go_repl_check_source_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_237, false); A_arbace_go_repl_check_source_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_51)); return A_arbace_go_repl__init_A_const_50 }








func A_arbace_go_repl__init_A_Unit27__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(208, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_52; var tmp2 any = A_arbace_go_repl_type_key_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_go_repl_type_key_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_238, false); A_arbace_go_repl_type_key_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_53)); return A_arbace_go_repl__init_A_const_52 }
















func A_arbace_go_repl__init_A_Unit28__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(225, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_54; var tmp2 any = A_arbace_go_repl_state_of_path_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_go_repl_state_of_path_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_239, false); A_arbace_go_repl_state_of_path_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_55)); return A_arbace_go_repl__init_A_const_54 }

func A_arbace_go_repl__init_A_Unit29__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(227, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_56; var tmp2 any = A_arbace_go_repl_method_name_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_go_repl_method_name_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_240, false); A_arbace_go_repl_method_name_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_57)); return A_arbace_go_repl__init_A_const_56 }





func A_arbace_go_repl__init_A_Unit30__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(233, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_58; var tmp2 any = A_arbace_go_repl_display_file_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_repl_display_file_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_241, false); A_arbace_go_repl_display_file_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_59)); return A_arbace_go_repl__init_A_const_58 }





func A_arbace_go_repl__init_A_Unit31__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(239, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_60; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_61)); return A_arbace_go_repl__init_A_const_60 }

func A_arbace_go_repl__init_A_Unit32__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(241, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_62; var tmp2 any = A_arbace_go_repl_build_context_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_go_repl_build_context_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_242, false); A_arbace_go_repl_build_context_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_63)); return A_arbace_go_repl__init_A_const_62 }


























func A_arbace_go_repl__init_A_Unit33__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(268, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_64; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_65)); v__1927001498__auto____1 = A_arbace_go_repl__init_A_const_64; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_go_repl__init_A_const_64; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_66)); var tmp3 *lang.Var = A_arbace_go_repl__init_A_const_64; var tmp4 any; var root_33 any = A_arbace_go_repl__init_A_const_18.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_33, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_35 lang.IFn
						if linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_34 == nil { tmp4 = ifn_35.Invoke_O__O(arg_36) } else { tmp4 = linked_34.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_33, arg_36) }
//line :268:1
	tmp3.BindRoot_O__V(tmp4); return A_arbace_go_repl__init_A_const_64 } }


func A_arbace_go_repl__init_A_Unit34__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(271, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_67; var tmp2 any = A_arbace_go_repl_compiled_context_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_go_repl_compiled_context_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_243, false); A_arbace_go_repl_compiled_context_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_68)); return A_arbace_go_repl__init_A_const_67 }


















func A_arbace_go_repl__init_A_Unit35__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(290, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_60; var tmp2 any = A_arbace_go_repl_ctx_of_A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_go_repl_ctx_of_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_244, false); A_arbace_go_repl_ctx_of_A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_69)); return A_arbace_go_repl__init_A_const_60 }






func A_arbace_go_repl__init_A_Unit36__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(297, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_70; var tmp2 any = A_arbace_go_repl_const_arbace_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_go_repl_const_arbace_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_245, false); A_arbace_go_repl_const_arbace_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_71)); return A_arbace_go_repl__init_A_const_70 }











func A_arbace_go_repl__init_A_Unit37__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(309, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_72; var tmp2 any = A_arbace_go_repl_define_BANG__A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_go_repl_define_BANG__A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_246, false); A_arbace_go_repl_define_BANG__A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_73)); return A_arbace_go_repl__init_A_const_72 }
















































































































































func A_arbace_go_repl__init_A_Unit38__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(454, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_74; var tmp2 any = A_arbace_go_repl_call0_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_go_repl_call0_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_247, false); A_arbace_go_repl_call0_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_75)); return A_arbace_go_repl__init_A_const_74 }





func A_arbace_go_repl__init_A_Unit39__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(460, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_76; var tmp2 any = A_arbace_go_repl_complete_BANG__A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_go_repl_complete_BANG__A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_248, false); A_arbace_go_repl_complete_BANG__A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_77)); return A_arbace_go_repl__init_A_const_76 }














func A_arbace_go_repl__init_A_Unit40__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(475, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_78; var tmp2 any = A_arbace_go_repl_after_load_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_go_repl_after_load_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_249, false); A_arbace_go_repl_after_load_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_79)); return A_arbace_go_repl__init_A_const_78 }












func A_arbace_go_repl__init_A_Unit41__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(488, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_80; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_81)); v__1927001498__auto____1 = A_arbace_go_repl__init_A_const_80; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_go_repl__init_A_const_80; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_82)); var tmp3 *lang.Var = A_arbace_go_repl__init_A_const_80; var tmp4 *jrt.Boolean; var root_44 any = A_arbace_go_repl__init_A_const_83.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_44, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_46 lang.IFn
						if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any = lang.RT_AFTER_LOAD.Ref(); var arg_48 any = A_arbace_go_repl__init_A_const_84.GetRawRoot__O(); var arg_49 any = A_arbace_go_repl__init_A_const_78; if linked_45 == nil { ifn_46.Invoke_O_O_O__O(arg_47, arg_48, arg_49) } else { linked_45.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_44, arg_47, arg_48, arg_49) }
//line :488:1
	tmp4 = jrt.Boolean_TRUE; tmp3.BindRoot_O__V(tmp4.Ref()); return A_arbace_go_repl__init_A_const_80 } }


func A_arbace_go_repl__init_A_Unit42__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(491, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_85; var tmp2 any = A_arbace_go_repl_interpretable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_go_repl_interpretable_QMARK__A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_250, false); A_arbace_go_repl_interpretable_QMARK__A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_86)); return A_arbace_go_repl__init_A_const_85 }





func A_arbace_go_repl__init_A_Unit43__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(497, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_87; var tmp2 any = A_arbace_go_repl_load_digest_package_BANG__A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_go_repl_load_digest_package_BANG__A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_251, false); A_arbace_go_repl_load_digest_package_BANG__A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_88)); return A_arbace_go_repl__init_A_const_87 }























func A_arbace_go_repl__init_A_Unit44__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(521, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_46; var tmp2 any = A_arbace_go_repl_load_import_A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_go_repl_load_import_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_252, false); A_arbace_go_repl_load_import_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_89)); return A_arbace_go_repl__init_A_const_46 }















func A_arbace_go_repl__init_A_Unit45__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(537, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_90; var tmp2 any = A_arbace_go_repl_declare_BANG__A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_go_repl_declare_BANG__A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_253, false); A_arbace_go_repl_declare_BANG__A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_91)); return A_arbace_go_repl__init_A_const_90 }

















































func A_arbace_go_repl__init_A_Unit46__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(587, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_92; var tmp2 any; var root_54 any = A_arbace_go_repl__init_A_const_18.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = A_arbace_go_repl__init_A_const_93; if linked_55 == nil { tmp2 = ifn_56.Invoke_O__O(arg_57) } else { tmp2 = linked_55.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_54, arg_57) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_go_repl__init_A_const_92; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_94)); return A_arbace_go_repl__init_A_const_92 }

func A_arbace_go_repl__init_A_Unit47__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(589, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_95; var tmp2 any = A_arbace_go_repl_eval_BANG__A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_go_repl_eval_BANG__A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_254, false); A_arbace_go_repl_eval_BANG__A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_96)); return A_arbace_go_repl__init_A_const_95 }



















































func A_arbace_go_repl__init_A_Unit48__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(641, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_97; var tmp2 any = A_arbace_go_repl_run_main_BANG__A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_go_repl_run_main_BANG__A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_255, false); A_arbace_go_repl_run_main_BANG__A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_98)); return A_arbace_go_repl__init_A_const_97 }









func A_arbace_go_repl__init_A_Unit49__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(651, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_99; var tmp2 any = A_arbace_go_repl_check_BANG__A_New(); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_go_repl_check_BANG__A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_256, false); A_arbace_go_repl_check_BANG__A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_99; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_100)); return A_arbace_go_repl__init_A_const_99 }







func A_arbace_go_repl__init_A_Unit50__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(659, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_101; var tmp2 any = A_arbace_go_repl_form_text_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_go_repl_form_text_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_257, false); A_arbace_go_repl_form_text_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_102)); return A_arbace_go_repl__init_A_const_101 }





func A_arbace_go_repl__init_A_Unit51__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(665, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_103; var tmp2 any = A_arbace_go_repl_write_package_BANG__A_New(); var tmp3 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_go_repl_write_package_BANG__A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_258, false); A_arbace_go_repl_write_package_BANG__A_fn_class = fncls__62d; tmp3 = fncls__62d } else { tmp3 = fncls__62 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_104)); return A_arbace_go_repl__init_A_const_103 }
























func A_arbace_go_repl__init_A_Unit52__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(690, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_105; var tmp2 any = A_arbace_go_repl_interpreted_closure_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_go_repl_interpreted_closure_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_259, false); A_arbace_go_repl_interpreted_closure_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_106)); return A_arbace_go_repl__init_A_const_105 }












func A_arbace_go_repl__init_A_Unit53__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(703, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_107; var tmp2 any = A_arbace_go_repl_run_compiled_BANG__A_New(); var tmp3 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_go_repl_run_compiled_BANG__A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_260, false); A_arbace_go_repl_run_compiled_BANG__A_fn_class = fncls__64d; tmp3 = fncls__64d } else { tmp3 = fncls__64 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_107; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_108)); return A_arbace_go_repl__init_A_const_107 }



type A_arbace_go_repl__init_A struct{ jrt.Object }

var A_arbace_go_repl__init_A_const_pool *jrt.RefArray

var A_arbace_go_repl__init_A_const_0 *lang.Var

var A_arbace_go_repl__init_A_const_1 any

var A_arbace_go_repl__init_A_const_2 any

var A_arbace_go_repl__init_A_const_3 any

var A_arbace_go_repl__init_A_const_4 *lang.Var

var A_arbace_go_repl__init_A_const_5 any

var A_arbace_go_repl__init_A_const_6 *lang.Var

var A_arbace_go_repl__init_A_const_7 any

var A_arbace_go_repl__init_A_const_8 *lang.Var

var A_arbace_go_repl__init_A_const_9 any

var A_arbace_go_repl__init_A_const_10 *lang.Var

var A_arbace_go_repl__init_A_const_11 any

var A_arbace_go_repl__init_A_const_12 *lang.Var

var A_arbace_go_repl__init_A_const_13 any

var A_arbace_go_repl__init_A_const_14 *lang.Var

var A_arbace_go_repl__init_A_const_15 any

var A_arbace_go_repl__init_A_const_16 *lang.Var

var A_arbace_go_repl__init_A_const_17 any

var A_arbace_go_repl__init_A_const_18 *lang.Var

var A_arbace_go_repl__init_A_const_19 any

var A_arbace_go_repl__init_A_const_20 *lang.Var

var A_arbace_go_repl__init_A_const_21 any

var A_arbace_go_repl__init_A_const_22 *lang.Var

var A_arbace_go_repl__init_A_const_23 any

var A_arbace_go_repl__init_A_const_24 *lang.Var

var A_arbace_go_repl__init_A_const_25 any

var A_arbace_go_repl__init_A_const_26 *lang.Var

var A_arbace_go_repl__init_A_const_27 any

var A_arbace_go_repl__init_A_const_28 *lang.Var

var A_arbace_go_repl__init_A_const_29 any

var A_arbace_go_repl__init_A_const_30 *lang.Var

var A_arbace_go_repl__init_A_const_31 any

var A_arbace_go_repl__init_A_const_32 *lang.Var

var A_arbace_go_repl__init_A_const_33 any

var A_arbace_go_repl__init_A_const_34 *lang.Var

var A_arbace_go_repl__init_A_const_35 any

var A_arbace_go_repl__init_A_const_36 *lang.Var

var A_arbace_go_repl__init_A_const_37 any

var A_arbace_go_repl__init_A_const_38 *lang.Var

var A_arbace_go_repl__init_A_const_39 any

var A_arbace_go_repl__init_A_const_40 *lang.Var

var A_arbace_go_repl__init_A_const_41 any

var A_arbace_go_repl__init_A_const_42 *lang.Var

var A_arbace_go_repl__init_A_const_43 any

var A_arbace_go_repl__init_A_const_44 *lang.Var

var A_arbace_go_repl__init_A_const_45 any

var A_arbace_go_repl__init_A_const_46 *lang.Var

var A_arbace_go_repl__init_A_const_47 any

var A_arbace_go_repl__init_A_const_48 *lang.Var

var A_arbace_go_repl__init_A_const_49 any

var A_arbace_go_repl__init_A_const_50 *lang.Var

var A_arbace_go_repl__init_A_const_51 any

var A_arbace_go_repl__init_A_const_52 *lang.Var

var A_arbace_go_repl__init_A_const_53 any

var A_arbace_go_repl__init_A_const_54 *lang.Var

var A_arbace_go_repl__init_A_const_55 any

var A_arbace_go_repl__init_A_const_56 *lang.Var

var A_arbace_go_repl__init_A_const_57 any

var A_arbace_go_repl__init_A_const_58 *lang.Var

var A_arbace_go_repl__init_A_const_59 any

var A_arbace_go_repl__init_A_const_60 *lang.Var

var A_arbace_go_repl__init_A_const_61 any

var A_arbace_go_repl__init_A_const_62 *lang.Var

var A_arbace_go_repl__init_A_const_63 any

var A_arbace_go_repl__init_A_const_64 *lang.Var

var A_arbace_go_repl__init_A_const_65 any

var A_arbace_go_repl__init_A_const_66 any

var A_arbace_go_repl__init_A_const_67 *lang.Var

var A_arbace_go_repl__init_A_const_68 any

var A_arbace_go_repl__init_A_const_69 any

var A_arbace_go_repl__init_A_const_70 *lang.Var

var A_arbace_go_repl__init_A_const_71 any

var A_arbace_go_repl__init_A_const_72 *lang.Var

var A_arbace_go_repl__init_A_const_73 any

var A_arbace_go_repl__init_A_const_74 *lang.Var

var A_arbace_go_repl__init_A_const_75 any

var A_arbace_go_repl__init_A_const_76 *lang.Var

var A_arbace_go_repl__init_A_const_77 any

var A_arbace_go_repl__init_A_const_78 *lang.Var

var A_arbace_go_repl__init_A_const_79 any

var A_arbace_go_repl__init_A_const_80 *lang.Var

var A_arbace_go_repl__init_A_const_81 any

var A_arbace_go_repl__init_A_const_82 any

var A_arbace_go_repl__init_A_const_83 *lang.Var

var A_arbace_go_repl__init_A_const_84 *lang.Var

var A_arbace_go_repl__init_A_const_85 *lang.Var

var A_arbace_go_repl__init_A_const_86 any

var A_arbace_go_repl__init_A_const_87 *lang.Var

var A_arbace_go_repl__init_A_const_88 any

var A_arbace_go_repl__init_A_const_89 any

var A_arbace_go_repl__init_A_const_90 *lang.Var

var A_arbace_go_repl__init_A_const_91 any

var A_arbace_go_repl__init_A_const_92 *lang.Var

var A_arbace_go_repl__init_A_const_93 any

var A_arbace_go_repl__init_A_const_94 any

var A_arbace_go_repl__init_A_const_95 *lang.Var

var A_arbace_go_repl__init_A_const_96 any

var A_arbace_go_repl__init_A_const_97 *lang.Var

var A_arbace_go_repl__init_A_const_98 any

var A_arbace_go_repl__init_A_const_99 *lang.Var

var A_arbace_go_repl__init_A_const_100 any

var A_arbace_go_repl__init_A_const_101 *lang.Var

var A_arbace_go_repl__init_A_const_102 any

var A_arbace_go_repl__init_A_const_103 *lang.Var

var A_arbace_go_repl__init_A_const_104 any

var A_arbace_go_repl__init_A_const_105 *lang.Var

var A_arbace_go_repl__init_A_const_106 any

var A_arbace_go_repl__init_A_const_107 *lang.Var

var A_arbace_go_repl__init_A_const_108 any

var A_arbace_go_repl__init_A_init jrt.ClassInit

func A_arbace_go_repl__init_A_Init() { if !A_arbace_go_repl__init_A_init.Done() { A_arbace_go_repl__init_A_init.Run(A_arbace_go_repl__init_A_clinit) } }

func A_arbace_go_repl__init_A_clinit() { A_arbace_go_repl__init_A_clinit_p0(); A_arbace_go_repl__init_A_clinit_p1(); A_arbace_go_repl__init_A_clinit_p2(); A_arbace_go_repl__init_A_clinit_p3(); A_arbace_go_repl__init_A_clinit_p4(); A_arbace_go_repl__init_A_clinit_p5(); A_arbace_go_repl__init_A_clinit_p6(); A_arbace_go_repl__init_A_clinit_p7(); A_arbace_go_repl__init_A_clinit_p8() }

func A_arbace_go_repl__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_repl__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_214, 151); A_arbace_go_repl__init_A_const_0 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[42]); A_arbace_go_repl__init_A_const_1 = A_arbace_go_repl__init_A_const_pool.A[43]; A_arbace_go_repl__init_A_const_2 = A_arbace_go_repl__init_A_const_pool.A[44]; A_arbace_go_repl__init_A_const_3 = A_arbace_go_repl__init_A_const_pool.A[45]; A_arbace_go_repl__init_A_const_4 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[46]); A_arbace_go_repl__init_A_const_5 = A_arbace_go_repl__init_A_const_pool.A[47]; A_arbace_go_repl__init_A_const_6 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[48]); A_arbace_go_repl__init_A_const_7 = A_arbace_go_repl__init_A_const_pool.A[49]; A_arbace_go_repl__init_A_const_8 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[50]); A_arbace_go_repl__init_A_const_9 = A_arbace_go_repl__init_A_const_pool.A[51]; A_arbace_go_repl__init_A_const_10 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[52]); A_arbace_go_repl__init_A_const_11 = A_arbace_go_repl__init_A_const_pool.A[53]; A_arbace_go_repl__init_A_const_12 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[54]) }

func A_arbace_go_repl__init_A_clinit_p1() { A_arbace_go_repl__init_A_const_13 = A_arbace_go_repl__init_A_const_pool.A[55]; A_arbace_go_repl__init_A_const_14 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[56]); A_arbace_go_repl__init_A_const_15 = A_arbace_go_repl__init_A_const_pool.A[57]; A_arbace_go_repl__init_A_const_16 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[58]); A_arbace_go_repl__init_A_const_17 = A_arbace_go_repl__init_A_const_pool.A[59]; A_arbace_go_repl__init_A_const_18 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[60]); A_arbace_go_repl__init_A_const_19 = A_arbace_go_repl__init_A_const_pool.A[61]; A_arbace_go_repl__init_A_const_20 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[62]); A_arbace_go_repl__init_A_const_21 = A_arbace_go_repl__init_A_const_pool.A[63]; A_arbace_go_repl__init_A_const_22 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[64]); A_arbace_go_repl__init_A_const_23 = A_arbace_go_repl__init_A_const_pool.A[65]; A_arbace_go_repl__init_A_const_24 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[66]); A_arbace_go_repl__init_A_const_25 = A_arbace_go_repl__init_A_const_pool.A[67] }

func A_arbace_go_repl__init_A_clinit_p2() { A_arbace_go_repl__init_A_const_26 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[68]); A_arbace_go_repl__init_A_const_27 = A_arbace_go_repl__init_A_const_pool.A[69]; A_arbace_go_repl__init_A_const_28 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[70]); A_arbace_go_repl__init_A_const_29 = A_arbace_go_repl__init_A_const_pool.A[71]; A_arbace_go_repl__init_A_const_30 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[72]); A_arbace_go_repl__init_A_const_31 = A_arbace_go_repl__init_A_const_pool.A[73]; A_arbace_go_repl__init_A_const_32 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[74]); A_arbace_go_repl__init_A_const_33 = A_arbace_go_repl__init_A_const_pool.A[75]; A_arbace_go_repl__init_A_const_34 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[76]); A_arbace_go_repl__init_A_const_35 = A_arbace_go_repl__init_A_const_pool.A[77]; A_arbace_go_repl__init_A_const_36 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[78]); A_arbace_go_repl__init_A_const_37 = A_arbace_go_repl__init_A_const_pool.A[79]; A_arbace_go_repl__init_A_const_38 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[80]) }

func A_arbace_go_repl__init_A_clinit_p3() { A_arbace_go_repl__init_A_const_39 = A_arbace_go_repl__init_A_const_pool.A[81]; A_arbace_go_repl__init_A_const_40 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[82]); A_arbace_go_repl__init_A_const_41 = A_arbace_go_repl__init_A_const_pool.A[83]; A_arbace_go_repl__init_A_const_42 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[84]); A_arbace_go_repl__init_A_const_43 = A_arbace_go_repl__init_A_const_pool.A[85]; A_arbace_go_repl__init_A_const_44 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[86]); A_arbace_go_repl__init_A_const_45 = A_arbace_go_repl__init_A_const_pool.A[87]; A_arbace_go_repl__init_A_const_46 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[88]); A_arbace_go_repl__init_A_const_47 = A_arbace_go_repl__init_A_const_pool.A[89]; A_arbace_go_repl__init_A_const_48 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[90]); A_arbace_go_repl__init_A_const_49 = A_arbace_go_repl__init_A_const_pool.A[91]; A_arbace_go_repl__init_A_const_50 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[92]); A_arbace_go_repl__init_A_const_51 = A_arbace_go_repl__init_A_const_pool.A[93] }

func A_arbace_go_repl__init_A_clinit_p4() { A_arbace_go_repl__init_A_const_52 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[94]); A_arbace_go_repl__init_A_const_53 = A_arbace_go_repl__init_A_const_pool.A[95]; A_arbace_go_repl__init_A_const_54 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[96]); A_arbace_go_repl__init_A_const_55 = A_arbace_go_repl__init_A_const_pool.A[97]; A_arbace_go_repl__init_A_const_56 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[98]); A_arbace_go_repl__init_A_const_57 = A_arbace_go_repl__init_A_const_pool.A[99]; A_arbace_go_repl__init_A_const_58 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[100]); A_arbace_go_repl__init_A_const_59 = A_arbace_go_repl__init_A_const_pool.A[101]; A_arbace_go_repl__init_A_const_60 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[102]); A_arbace_go_repl__init_A_const_61 = A_arbace_go_repl__init_A_const_pool.A[103]; A_arbace_go_repl__init_A_const_62 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[104]); A_arbace_go_repl__init_A_const_63 = A_arbace_go_repl__init_A_const_pool.A[105]; A_arbace_go_repl__init_A_const_64 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[106]) }

func A_arbace_go_repl__init_A_clinit_p5() { A_arbace_go_repl__init_A_const_65 = A_arbace_go_repl__init_A_const_pool.A[107]; A_arbace_go_repl__init_A_const_66 = A_arbace_go_repl__init_A_const_pool.A[108]; A_arbace_go_repl__init_A_const_67 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[109]); A_arbace_go_repl__init_A_const_68 = A_arbace_go_repl__init_A_const_pool.A[110]; A_arbace_go_repl__init_A_const_69 = A_arbace_go_repl__init_A_const_pool.A[111]; A_arbace_go_repl__init_A_const_70 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[112]); A_arbace_go_repl__init_A_const_71 = A_arbace_go_repl__init_A_const_pool.A[113]; A_arbace_go_repl__init_A_const_72 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[114]); A_arbace_go_repl__init_A_const_73 = A_arbace_go_repl__init_A_const_pool.A[115]; A_arbace_go_repl__init_A_const_74 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[116]); A_arbace_go_repl__init_A_const_75 = A_arbace_go_repl__init_A_const_pool.A[117]; A_arbace_go_repl__init_A_const_76 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[118]); A_arbace_go_repl__init_A_const_77 = A_arbace_go_repl__init_A_const_pool.A[119]; A_arbace_go_repl__init_A_const_78 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[120]) }

func A_arbace_go_repl__init_A_clinit_p6() { A_arbace_go_repl__init_A_const_79 = A_arbace_go_repl__init_A_const_pool.A[121]; A_arbace_go_repl__init_A_const_80 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[122]); A_arbace_go_repl__init_A_const_81 = A_arbace_go_repl__init_A_const_pool.A[123]; A_arbace_go_repl__init_A_const_82 = A_arbace_go_repl__init_A_const_pool.A[124]; A_arbace_go_repl__init_A_const_83 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[125]); A_arbace_go_repl__init_A_const_84 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[126]); A_arbace_go_repl__init_A_const_85 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[127]); A_arbace_go_repl__init_A_const_86 = A_arbace_go_repl__init_A_const_pool.A[128]; A_arbace_go_repl__init_A_const_87 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[129]); A_arbace_go_repl__init_A_const_88 = A_arbace_go_repl__init_A_const_pool.A[130]; A_arbace_go_repl__init_A_const_89 = A_arbace_go_repl__init_A_const_pool.A[131]; A_arbace_go_repl__init_A_const_90 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[132]); A_arbace_go_repl__init_A_const_91 = A_arbace_go_repl__init_A_const_pool.A[133] }

func A_arbace_go_repl__init_A_clinit_p7() { A_arbace_go_repl__init_A_const_92 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[134]); A_arbace_go_repl__init_A_const_93 = A_arbace_go_repl__init_A_const_pool.A[135]; A_arbace_go_repl__init_A_const_94 = A_arbace_go_repl__init_A_const_pool.A[136]; A_arbace_go_repl__init_A_const_95 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[137]); A_arbace_go_repl__init_A_const_96 = A_arbace_go_repl__init_A_const_pool.A[138]; A_arbace_go_repl__init_A_const_97 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[139]); A_arbace_go_repl__init_A_const_98 = A_arbace_go_repl__init_A_const_pool.A[140]; A_arbace_go_repl__init_A_const_99 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[141]); A_arbace_go_repl__init_A_const_100 = A_arbace_go_repl__init_A_const_pool.A[142]; A_arbace_go_repl__init_A_const_101 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[143]); A_arbace_go_repl__init_A_const_102 = A_arbace_go_repl__init_A_const_pool.A[144]; A_arbace_go_repl__init_A_const_103 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[145]); A_arbace_go_repl__init_A_const_104 = A_arbace_go_repl__init_A_const_pool.A[146] }

func A_arbace_go_repl__init_A_clinit_p8() { A_arbace_go_repl__init_A_const_105 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[147]); A_arbace_go_repl__init_A_const_106 = A_arbace_go_repl__init_A_const_pool.A[148]; A_arbace_go_repl__init_A_const_107 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[149]); A_arbace_go_repl__init_A_const_108 = A_arbace_go_repl__init_A_const_pool.A[150] }

func A_arbace_go_repl__init_A_New() *A_arbace_go_repl__init_A { A_arbace_go_repl__init_A_Init(); t := &A_arbace_go_repl__init_A{}; t.Ctor(); return t }

func (t *A_arbace_go_repl__init_A) Ctor() {}

func (t *A_arbace_go_repl__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_repl__init_A) GetClass__Class() *jrt.Class { return A_arbace_go_repl__init_A_class }

func (t *A_arbace_go_repl__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_repl__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_repl__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_repl__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_repl__init_A); return ok }

func A_arbace_go_repl__init_A_Cast(x any) *A_arbace_go_repl__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_repl__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_repl__init_A_class)) }; return v }
