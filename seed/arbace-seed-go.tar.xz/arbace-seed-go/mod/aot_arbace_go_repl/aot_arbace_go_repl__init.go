//line aot_arbace_go_repl__init.ae:1
package aot_arbace_go_repl

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_repl__init_A_Unit0__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_go_repl__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_repl__init_A_const_1) }
//line :1:1
func A_arbace_go_repl__init_A_Unit1__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_go_repl__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_2)) }
//line :1:1
func A_arbace_go_repl__init_A_Unit2__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_go_repl_eval794000004_loading__1927001464__auto____794000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_repl_eval794000004_loading__1927001464__auto____794000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_308, false, nil); A_arbace_go_repl_eval794000004_loading__1927001464__auto____794000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_go_repl__init_A_Unit3__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_go_repl__init_A_const_1)).Equals_O__Z(A_arbace_go_repl__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_go_repl_eval794000008_fn__794000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_repl_eval794000008_fn__794000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_309, false, nil); A_arbace_go_repl_eval794000008_fn__794000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_go_repl__init_A_Load__O() any { A_arbace_go_repl__init_A_Init(); jrt.StartCheck(); A_arbace_go_repl__init_A_Unit0__O(); A_arbace_go_repl__init_A_Unit1__O(); A_arbace_go_repl__init_A_Unit2__O(); A_arbace_go_repl__init_A_Unit3__O(); A_arbace_go_repl__init_A_Unit4__O(); A_arbace_go_repl__init_A_Unit5__O(); A_arbace_go_repl__init_A_Unit6__O(); A_arbace_go_repl__init_A_Unit7__O(); A_arbace_go_repl__init_A_Unit8__O(); A_arbace_go_repl__init_A_Unit9__O(); A_arbace_go_repl__init_A_Unit10__O(); A_arbace_go_repl__init_A_Unit11__O(); A_arbace_go_repl__init_A_Unit12__O(); A_arbace_go_repl__init_A_Unit13__O(); A_arbace_go_repl__init_A_Unit14__O(); A_arbace_go_repl__init_A_Unit15__O(); A_arbace_go_repl__init_A_Unit16__O(); A_arbace_go_repl__init_A_Unit17__O(); A_arbace_go_repl__init_A_Unit18__O(); A_arbace_go_repl__init_A_Unit19__O(); A_arbace_go_repl__init_A_Unit20__O(); A_arbace_go_repl__init_A_Unit21__O(); A_arbace_go_repl__init_A_Unit22__O(); A_arbace_go_repl__init_A_Unit23__O(); A_arbace_go_repl__init_A_Unit24__O(); A_arbace_go_repl__init_A_Unit25__O(); A_arbace_go_repl__init_A_Unit26__O(); A_arbace_go_repl__init_A_Unit27__O(); A_arbace_go_repl__init_A_Unit28__O(); A_arbace_go_repl__init_A_Unit29__O(); A_arbace_go_repl__init_A_Unit30__O(); A_arbace_go_repl__init_A_Unit31__O(); A_arbace_go_repl__init_A_Unit32__O(); A_arbace_go_repl__init_A_Unit33__O(); A_arbace_go_repl__init_A_Unit34__O(); A_arbace_go_repl__init_A_Unit35__O(); A_arbace_go_repl__init_A_Unit36__O(); A_arbace_go_repl__init_A_Unit37__O(); A_arbace_go_repl__init_A_Unit38__O(); A_arbace_go_repl__init_A_Unit39__O(); A_arbace_go_repl__init_A_Unit40__O(); A_arbace_go_repl__init_A_Unit41__O(); A_arbace_go_repl__init_A_Unit42__O(); A_arbace_go_repl__init_A_Unit43__O(); A_arbace_go_repl__init_A_Unit44__O(); A_arbace_go_repl__init_A_Unit45__O(); A_arbace_go_repl__init_A_Unit46__O(); A_arbace_go_repl__init_A_Unit47__O(); A_arbace_go_repl__init_A_Unit48__O(); A_arbace_go_repl__init_A_Unit49__O(); A_arbace_go_repl__init_A_Unit50__O(); A_arbace_go_repl__init_A_Unit51__O(); A_arbace_go_repl__init_A_Unit52__O(); A_arbace_go_repl__init_A_Unit53__O(); A_arbace_go_repl__init_A_Unit54__O(); A_arbace_go_repl__init_A_Unit55__O(); A_arbace_go_repl__init_A_Unit56__O(); A_arbace_go_repl__init_A_Unit57__O(); A_arbace_go_repl__init_A_Unit58__O(); A_arbace_go_repl__init_A_Unit59__O(); A_arbace_go_repl__init_A_Unit60__O(); A_arbace_go_repl__init_A_Unit61__O(); A_arbace_go_repl__init_A_Unit62__O(); A_arbace_go_repl__init_A_Unit63__O(); A_arbace_go_repl__init_A_Unit64__O(); A_arbace_go_repl__init_A_Unit65__O(); A_arbace_go_repl__init_A_Unit66__O(); A_arbace_go_repl__init_A_Unit67__O(); A_arbace_go_repl__init_A_Unit68__O(); A_arbace_go_repl__init_A_Unit69__O(); A_arbace_go_repl__init_A_Unit70__O(); A_arbace_go_repl__init_A_Unit71__O(); A_arbace_go_repl__init_A_Unit72__O(); A_arbace_go_repl__init_A_Unit73__O(); A_arbace_go_repl__init_A_Unit74__O(); A_arbace_go_repl__init_A_Unit75__O(); A_arbace_go_repl__init_A_Unit76__O(); A_arbace_go_repl__init_A_Unit77__O(); A_arbace_go_repl__init_A_Unit78__O(); A_arbace_go_repl__init_A_Unit79__O(); A_arbace_go_repl__init_A_Unit80__O(); A_arbace_go_repl__init_A_Unit81__O(); A_arbace_go_repl__init_A_Unit82__O(); A_arbace_go_repl__init_A_Unit83__O(); return nil }






















func A_arbace_go_repl__init_A_Unit4__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(28, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_go_repl_fn__794000012_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_repl_fn__794000012_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_310, false, nil); A_arbace_go_repl_fn__794000012_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp2))); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_5)); return A_arbace_go_repl__init_A_const_4 }

func A_arbace_go_repl__init_A_Unit5__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(30, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_go_repl_listed_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_repl_listed_QMARK__A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_311, false, nil); A_arbace_go_repl_listed_QMARK__A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_7)); return A_arbace_go_repl__init_A_const_6 }




func A_arbace_go_repl__init_A_Unit6__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(35, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_go_repl_fn__794000015_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_repl_fn__794000015_A_fn_class; if
						fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_312, false, nil); A_arbace_go_repl_fn__794000015_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); /*line :35:1*/tmp1.BindRoot_O__V(lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp2))); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_9)); return A_arbace_go_repl__init_A_const_8 }





func A_arbace_go_repl__init_A_Unit7__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(41, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_go_repl_digest_forms_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_repl_digest_forms_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_313, false, nil); A_arbace_go_repl_digest_forms_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_11)); return A_arbace_go_repl__init_A_const_10 }






func A_arbace_go_repl__init_A_Unit8__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_go_repl_fn__794000024_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_repl_fn__794000024_A_fn_class; if

	fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_314, false, nil); A_arbace_go_repl_fn__794000024_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); /*line :48:1*/tmp1.BindRoot_O__V(lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp2))); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_13)); return A_arbace_go_repl__init_A_const_12 }







func A_arbace_go_repl__init_A_Unit9__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(56, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_go_repl_interpretable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_repl_interpretable_QMARK__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_315, false, nil); A_arbace_go_repl_interpretable_QMARK__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_15)); return A_arbace_go_repl__init_A_const_14 }





func A_arbace_go_repl__init_A_Unit10__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(62, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_go_repl_fn__794000030_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_repl_fn__794000030_A_fn_class; if

	fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_316, false, nil); A_arbace_go_repl_fn__794000030_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); /*line :62:1*/tmp1.BindRoot_O__V(lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp2))); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_17)); return A_arbace_go_repl__init_A_const_16 }





func A_arbace_go_repl__init_A_Unit11__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(68, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_go_repl_fn__794000033_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_repl_fn__794000033_A_fn_class; if


	fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_317, false, nil); A_arbace_go_repl_fn__794000033_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); /*line :68:1*/tmp1.BindRoot_O__V(lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp2))); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_19)); return A_arbace_go_repl__init_A_const_18 }





func A_arbace_go_repl__init_A_Unit12__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(74, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_go_repl_refusal_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_repl_refusal_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_318, false, nil); A_arbace_go_repl_refusal_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_21)); return A_arbace_go_repl__init_A_const_20 }


















func A_arbace_go_repl__init_A_Unit13__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(93, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_go_repl_fn__794000037_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_repl_fn__794000037_A_fn_class; if




	fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_319, false, nil); A_arbace_go_repl_fn__794000037_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); /*line :93:1*/tmp1.BindRoot_O__V(lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp2))); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_23)); return A_arbace_go_repl__init_A_const_22 }













func A_arbace_go_repl__init_A_Unit14__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(107, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_24; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_25)); v__1927001498__auto____1 = A_arbace_go_repl__init_A_const_24; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_go_repl__init_A_const_24; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_27)); var tmp3 *lang.Var = A_arbace_go_repl__init_A_const_24; var tmp4 any; var root_25 any = A_arbace_go_repl__init_A_const_26.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_26 == nil { tmp4 = ifn_27.Invoke_O__O(arg_28) } else { tmp4 = linked_26.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_25, arg_28) }; tmp3.BindRoot_O__V(tmp4); return A_arbace_go_repl__init_A_const_24 } }

func A_arbace_go_repl__init_A_Unit15__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(109, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_28; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_go_repl_path__GT_ns_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_go_repl_path__GT_ns_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_320, false, nil); A_arbace_go_repl_path__GT_ns_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_29)); return A_arbace_go_repl__init_A_const_28 }




func A_arbace_go_repl__init_A_Unit16__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(114, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_go_repl_ns__GT_path_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_repl_ns__GT_path_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_321, false, nil); A_arbace_go_repl_ns__GT_path_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_31)); return A_arbace_go_repl__init_A_const_30 }




func A_arbace_go_repl__init_A_Unit17__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(119, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_go_repl_new_state_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_go_repl_new_state_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_322, false, nil); A_arbace_go_repl_new_state_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_33)); return A_arbace_go_repl__init_A_const_32 }



func A_arbace_go_repl__init_A_Unit18__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(123, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_go_repl_package_state_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_go_repl_package_state_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_323, false, nil); A_arbace_go_repl_package_state_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_35)); return A_arbace_go_repl__init_A_const_34 }















func A_arbace_go_repl__init_A_Unit19__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(139, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_36; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_37)); return A_arbace_go_repl__init_A_const_36 }

func A_arbace_go_repl__init_A_Unit20__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(141, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_go_repl_package_BANG__A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_go_repl_package_BANG__A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_324, false, nil); A_arbace_go_repl_package_BANG__A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_39)); return A_arbace_go_repl__init_A_const_38 }
















func A_arbace_go_repl__init_A_Unit21__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(158, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_go_repl_file_entry_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_go_repl_file_entry_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_325, false, nil); A_arbace_go_repl_file_entry_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_41)); return A_arbace_go_repl__init_A_const_40 }


func A_arbace_go_repl__init_A_Unit22__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(161, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_go_repl_update_file_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_go_repl_update_file_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_326, false, nil); A_arbace_go_repl_update_file_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_43)); return A_arbace_go_repl__init_A_const_42 }






func A_arbace_go_repl__init_A_Unit23__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(168, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_go_repl_file_BANG__A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_go_repl_file_BANG__A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_327, false, nil); A_arbace_go_repl_file_BANG__A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_45)); return A_arbace_go_repl__init_A_const_44 }








func A_arbace_go_repl__init_A_Unit24__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(177, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_go_repl_import_BANG__A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_go_repl_import_BANG__A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_328, false, nil); A_arbace_go_repl_import_BANG__A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_47)); return A_arbace_go_repl__init_A_const_46 }










func A_arbace_go_repl__init_A_Unit25__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(188, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_go_repl_decl_names_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_go_repl_decl_names_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_329, false, nil); A_arbace_go_repl_decl_names_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_49)); return A_arbace_go_repl__init_A_const_48 }



























func A_arbace_go_repl__init_A_Unit26__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(216, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_go_repl_error_text_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_go_repl_error_text_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_330, false, nil); A_arbace_go_repl_error_text_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_51)); return A_arbace_go_repl__init_A_const_50 }







func A_arbace_go_repl__init_A_Unit27__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(224, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_52; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_go_repl_repl_source_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_go_repl_repl_source_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_331, false, nil); A_arbace_go_repl_repl_source_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_53)); return A_arbace_go_repl__init_A_const_52 }

func A_arbace_go_repl__init_A_Unit28__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(226, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_54; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_go_repl_source_of_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_go_repl_source_of_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_332, false, nil); A_arbace_go_repl_source_of_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_55)); return A_arbace_go_repl__init_A_const_54 }















func A_arbace_go_repl__init_A_Unit29__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(242, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_56; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_57)); return A_arbace_go_repl__init_A_const_56 }

func A_arbace_go_repl__init_A_Unit30__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(244, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_58; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_go_repl_session_for_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_go_repl_session_for_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_333, false, nil); A_arbace_go_repl_session_for_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_59)); return A_arbace_go_repl__init_A_const_58 }











func A_arbace_go_repl__init_A_Unit31__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(256, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_60; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_61)); return A_arbace_go_repl__init_A_const_60 }

func A_arbace_go_repl__init_A_Unit32__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(258, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_62; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_go_repl_define_digest_imports_BANG__A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_go_repl_define_digest_imports_BANG__A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_334, false, nil); A_arbace_go_repl_define_digest_imports_BANG__A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_63)); return A_arbace_go_repl__init_A_const_62 }










func A_arbace_go_repl__init_A_Unit33__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(269, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_64; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_go_repl_check_source_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_go_repl_check_source_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_335, false, nil); A_arbace_go_repl_check_source_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_65)); return A_arbace_go_repl__init_A_const_64 }













func A_arbace_go_repl__init_A_Unit34__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(283, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_66; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_go_repl_package_file_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_go_repl_package_file_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_336, false, nil); A_arbace_go_repl_package_file_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_67)); return A_arbace_go_repl__init_A_const_66 }














func A_arbace_go_repl__init_A_Unit35__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_68; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_69)); v__1927001498__auto____1 = A_arbace_go_repl__init_A_const_68; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_go_repl__init_A_const_68; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_70)); var tmp3 *lang.Var = A_arbace_go_repl__init_A_const_68; var tmp4 any; var root_63 any = A_arbace_go_repl__init_A_const_26.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_65 lang.IFn


	if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_64 == nil { tmp4 = ifn_65.Invoke_O__O(arg_66) } else { tmp4 = linked_64.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_63, arg_66) }
//line :298:1
	tmp3.BindRoot_O__V(tmp4); return A_arbace_go_repl__init_A_const_68 } }




func A_arbace_go_repl__init_A_Unit36__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(303, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_71; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_go_repl_read_forms_file_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_go_repl_read_forms_file_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_337, false, nil); A_arbace_go_repl_read_forms_file_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_72)); return A_arbace_go_repl__init_A_const_71 }











func A_arbace_go_repl__init_A_Unit37__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(315, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_go_repl_start_read_ahead_BANG__A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_go_repl_start_read_ahead_BANG__A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_338, false, nil); A_arbace_go_repl_start_read_ahead_BANG__A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_73)); return A_arbace_go_repl__init_A_const_36 }




























func A_arbace_go_repl__init_A_Unit38__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(344, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_74; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_go_repl_load_ahead_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_go_repl_load_ahead_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_339, false, nil); A_arbace_go_repl_load_ahead_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_75)); return A_arbace_go_repl__init_A_const_74 }












func A_arbace_go_repl__init_A_Unit39__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(357, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_76; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_77)); v__1927001498__auto____1 = A_arbace_go_repl__init_A_const_76; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_go_repl__init_A_const_76; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_78)); var tmp3 *lang.Var = A_arbace_go_repl__init_A_const_76; var tmp4 *jrt.Boolean; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_repl__init_A_const_79.GetRawRoot__O()); var tmp6 any = A_arbace_go_repl__init_A_const_80; var tmp7 *lang.Compiler_AOTFn; var fnbody__79 any = A_arbace_go_repl_eval794000218_fn__794000219_A_New(); var tmp8 *jrt.Class
						var fncls__78 /*line :357:1*/*jrt.Class = A_arbace_go_repl_eval794000218_fn__794000219_A_fn_class


	if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_340, false, nil); A_arbace_go_repl_eval794000218_fn__794000219_A_fn_class = fncls__78d; tmp8 = fncls__78d } else { tmp8 = fncls__78 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__79, tmp8, nil)
//line :359:1
	tmp5.Invoke_O_O__O(tmp6, tmp7.Ref())
//line :357:1
	tmp4 = jrt.Boolean_TRUE; tmp3.BindRoot_O__V(tmp4.Ref()); return A_arbace_go_repl__init_A_const_76 } }











func A_arbace_go_repl__init_A_Unit40__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(369, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_81; var tmp2 *lang.Compiler_AOTFn; var fnbody__81 any = A_arbace_go_repl_embed_kind_A_New(); var tmp3 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_go_repl_embed_kind_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_341, false, nil); A_arbace_go_repl_embed_kind_A_fn_class = fncls__80d; tmp3 = fncls__80d } else { tmp3 = fncls__80 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__81, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_82)); return A_arbace_go_repl__init_A_const_81 }









func A_arbace_go_repl__init_A_Unit41__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(379, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_83; var tmp2 *lang.Compiler_AOTFn; var fnbody__83 any = A_arbace_go_repl_embed_trees_A_New(); var tmp3 *jrt.Class; var fncls__82 *jrt.Class = A_arbace_go_repl_embed_trees_A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_342, false, nil); A_arbace_go_repl_embed_trees_A_fn_class = fncls__82d; tmp3 = fncls__82d } else { tmp3 = fncls__82 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__83, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_84)); return A_arbace_go_repl__init_A_const_83 }













































func A_arbace_go_repl__init_A_Unit42__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(425, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_85; var tmp2 *lang.Compiler_AOTFn; var fnbody__85 any = A_arbace_go_repl_type_key_A_New(); var tmp3 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_go_repl_type_key_A_fn_class; if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_343, false, nil); A_arbace_go_repl_type_key_A_fn_class = fncls__84d; tmp3 = fncls__84d } else { tmp3 = fncls__84 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__85, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_86)); return A_arbace_go_repl__init_A_const_85 }
















func A_arbace_go_repl__init_A_Unit43__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(442, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_87; var tmp2 *lang.Compiler_AOTFn; var fnbody__87 any = A_arbace_go_repl_state_of_path_A_New(); var tmp3 *jrt.Class; var fncls__86 *jrt.Class = A_arbace_go_repl_state_of_path_A_fn_class; if fncls__86 == nil { var fncls__86d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_344, false, nil); A_arbace_go_repl_state_of_path_A_fn_class = fncls__86d; tmp3 = fncls__86d } else { tmp3 = fncls__86 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__87, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_88)); return A_arbace_go_repl__init_A_const_87 }

func A_arbace_go_repl__init_A_Unit44__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(444, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_89; var tmp2 *lang.Compiler_AOTFn; var fnbody__89 any = A_arbace_go_repl_method_name_A_New(); var tmp3 *jrt.Class; var fncls__88 *jrt.Class = A_arbace_go_repl_method_name_A_fn_class; if fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_345, false, nil); A_arbace_go_repl_method_name_A_fn_class = fncls__88d; tmp3 = fncls__88d } else { tmp3 = fncls__88 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__89, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_89; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_90)); return A_arbace_go_repl__init_A_const_89 }





func A_arbace_go_repl__init_A_Unit45__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(450, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_91; var tmp2 *lang.Compiler_AOTFn; var fnbody__91 any = A_arbace_go_repl_display_file_A_New(); var tmp3 *jrt.Class; var fncls__90 *jrt.Class = A_arbace_go_repl_display_file_A_fn_class; if fncls__90 == nil { var fncls__90d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_346, false, nil); A_arbace_go_repl_display_file_A_fn_class = fncls__90d; tmp3 = fncls__90d } else { tmp3 = fncls__90 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__91, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_92)); return A_arbace_go_repl__init_A_const_91 }





func A_arbace_go_repl__init_A_Unit46__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(456, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_93; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_94)); return A_arbace_go_repl__init_A_const_93 }

func A_arbace_go_repl__init_A_Unit47__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(458, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_95; var tmp2 any; var root_92 any = A_arbace_go_repl__init_A_const_26.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_93 == nil { tmp2 = ifn_94.Invoke_O__O(arg_95) } else { tmp2 = linked_93.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_92, arg_95) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_go_repl__init_A_const_95; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_96)); return A_arbace_go_repl__init_A_const_95 }

func A_arbace_go_repl__init_A_Unit48__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(460, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_97; var tmp2 *lang.Compiler_AOTFn; var fnbody__97 any = A_arbace_go_repl_table_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__96 *jrt.Class = A_arbace_go_repl_table_type_QMARK__A_fn_class; if fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_347, false, nil); A_arbace_go_repl_table_type_QMARK__A_fn_class = fncls__96d; tmp3 = fncls__96d } else { tmp3 = fncls__96 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__97, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_98)); return A_arbace_go_repl__init_A_const_97 }









func A_arbace_go_repl__init_A_Unit49__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(470, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_99; var tmp2 *lang.Compiler_AOTFn; var fnbody__99 any = A_arbace_go_repl_digest_scope_A_New(); var tmp3 *jrt.Class; var fncls__98 *jrt.Class = A_arbace_go_repl_digest_scope_A_fn_class; if fncls__98 == nil { var fncls__98d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_348, false, nil); A_arbace_go_repl_digest_scope_A_fn_class = fncls__98d; tmp3 = fncls__98d } else { tmp3 = fncls__98 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__99, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_99; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_100)); return A_arbace_go_repl__init_A_const_99 }




func A_arbace_go_repl__init_A_Unit50__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(475, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_101; var tmp2 *lang.Compiler_AOTFn; var fnbody__101 any = A_arbace_go_repl_gen_of_A_New(); var tmp3 *jrt.Class; var fncls__100 *jrt.Class = A_arbace_go_repl_gen_of_A_fn_class; if fncls__100 == nil { var fncls__100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_349, false, nil); A_arbace_go_repl_gen_of_A_fn_class = fncls__100d; tmp3 = fncls__100d } else { tmp3 = fncls__100 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__101, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_102)); return A_arbace_go_repl__init_A_const_101 }





func A_arbace_go_repl__init_A_Unit51__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(481, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_103; var tmp2 *lang.Compiler_AOTFn; var fnbody__103 any = A_arbace_go_repl_func_cell_A_New(); var tmp3 *jrt.Class; var fncls__102 *jrt.Class = A_arbace_go_repl_func_cell_A_fn_class; if fncls__102 == nil { var fncls__102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_350, false, nil); A_arbace_go_repl_func_cell_A_fn_class = fncls__102d; tmp3 = fncls__102d } else { tmp3 = fncls__102 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__103, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_104)); return A_arbace_go_repl__init_A_const_103 }






func A_arbace_go_repl__init_A_Unit52__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(488, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_105; var tmp2 *lang.Compiler_AOTFn; var fnbody__105 any = A_arbace_go_repl_method_cell_A_New(); var tmp3 *jrt.Class; var fncls__104 *jrt.Class = A_arbace_go_repl_method_cell_A_fn_class; if fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_351, false, nil); A_arbace_go_repl_method_cell_A_fn_class = fncls__104d; tmp3 = fncls__104d } else { tmp3 = fncls__104 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__105, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_106)); return A_arbace_go_repl__init_A_const_105 }








func A_arbace_go_repl__init_A_Unit53__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(497, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_107; var tmp2 *lang.Compiler_AOTFn; var fnbody__107 any = A_arbace_go_repl_global_cell_A_New(); var tmp3 *jrt.Class; var fncls__106 *jrt.Class = A_arbace_go_repl_global_cell_A_fn_class; if fncls__106 == nil { var fncls__106d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_352, false, nil); A_arbace_go_repl_global_cell_A_fn_class = fncls__106d; tmp3 = fncls__106d } else { tmp3 = fncls__106 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__107, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_107; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_108)); return A_arbace_go_repl__init_A_const_107 }






func A_arbace_go_repl__init_A_Unit54__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(504, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_109; var tmp2 *lang.Compiler_AOTFn; var fnbody__109 any = A_arbace_go_repl_build_context_A_New(); var tmp3 *jrt.Class; var fncls__108 *jrt.Class = A_arbace_go_repl_build_context_A_fn_class; if fncls__108 == nil { var fncls__108d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_353, false, nil); A_arbace_go_repl_build_context_A_fn_class = fncls__108d; tmp3 = fncls__108d } else { tmp3 = fncls__108 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__109, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_109; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_110)); return A_arbace_go_repl__init_A_const_109 }
























func A_arbace_go_repl__init_A_Unit55__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(529, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_111; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_112)); v__1927001498__auto____1 = A_arbace_go_repl__init_A_const_111; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_go_repl__init_A_const_111; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_113)); var tmp3 *lang.Var = A_arbace_go_repl__init_A_const_111; var tmp4 any; var root_110 any = A_arbace_go_repl__init_A_const_26.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_110, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_112 lang.IFn
						if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_111 == nil { tmp4 = ifn_112.Invoke_O__O(arg_113) } else { tmp4 = linked_111.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_110, arg_113) }
//line :529:1
	tmp3.BindRoot_O__V(tmp4); return A_arbace_go_repl__init_A_const_111 } }


func A_arbace_go_repl__init_A_Unit56__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(532, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_114; var tmp2 *lang.Compiler_AOTFn; var fnbody__115 any = A_arbace_go_repl_compiled_context_A_New(); var tmp3 *jrt.Class; var fncls__114 *jrt.Class = A_arbace_go_repl_compiled_context_A_fn_class; if fncls__114 == nil { var fncls__114d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_354, false, nil); A_arbace_go_repl_compiled_context_A_fn_class = fncls__114d; tmp3 = fncls__114d } else { tmp3 = fncls__114 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__115, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_115)); return A_arbace_go_repl__init_A_const_114 }



























func A_arbace_go_repl__init_A_Unit57__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(560, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_93; var tmp2 *lang.Compiler_AOTFn; var fnbody__117 any = A_arbace_go_repl_ctx_of_A_New(); var tmp3 *jrt.Class; var fncls__116 *jrt.Class = A_arbace_go_repl_ctx_of_A_fn_class; if fncls__116 == nil { var fncls__116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_355, false, nil); A_arbace_go_repl_ctx_of_A_fn_class = fncls__116d; tmp3 = fncls__116d } else { tmp3 = fncls__116 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__117, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_116)); return A_arbace_go_repl__init_A_const_93 }






func A_arbace_go_repl__init_A_Unit58__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(567, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_117; var tmp2 *lang.Compiler_AOTFn; var fnbody__119 any = A_arbace_go_repl_named_type_A_New(); var tmp3 *jrt.Class; var fncls__118 *jrt.Class = A_arbace_go_repl_named_type_A_fn_class; if fncls__118 == nil { var fncls__118d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_356, false, nil); A_arbace_go_repl_named_type_A_fn_class = fncls__118d; tmp3 = fncls__118d } else { tmp3 = fncls__118 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__119, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_117; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_118)); return A_arbace_go_repl__init_A_const_117 }












func A_arbace_go_repl__init_A_Unit59__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(580, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_119; var tmp2 any = A_arbace_go_repl__init_A_const_120; var tmp3 *lang.Compiler_AOTFn; var fnbody__121 any = A_arbace_go_repl_fn__794000414_A_New(); var tmp4 *jrt.Class; var fncls__120 *jrt.Class = A_arbace_go_repl_fn__794000414_A_fn_class; if

	fncls__120 == nil { var fncls__120d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_357, false, nil); A_arbace_go_repl_fn__794000414_A_fn_class = fncls__120d; tmp4 = fncls__120d } else { tmp4 = fncls__120 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__121, tmp4, nil); var tmp5 any = /*line :580:1*/tmp3.Ref(); var tmp6 any = A_arbace_go_repl__init_A_const_121; var tmp7 *lang.Compiler_AOTFn; var fnbody__123 any = A_arbace_go_repl_fn__794000416_A_New(); var tmp8 *jrt.Class; var fncls__122 *jrt.Class = A_arbace_go_repl_fn__794000416_A_fn_class; if

	fncls__122 == nil { var fncls__122d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_358, false, nil); A_arbace_go_repl_fn__794000416_A_fn_class = fncls__122d; tmp8 = fncls__122d } else { tmp8 = fncls__122 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__123, tmp8, nil); /*line :580:1*/tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp5, tmp6, tmp7.Ref()))); var tmp9 *lang.Var = A_arbace_go_repl__init_A_const_119; tmp9.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_122)); return A_arbace_go_repl__init_A_const_119 }



func A_arbace_go_repl__init_A_Unit60__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(584, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_123; var tmp2 *lang.Compiler_AOTFn; var fnbody__125 any = A_arbace_go_repl_const_arbace_A_New(); var tmp3 *jrt.Class; var fncls__124 *jrt.Class = A_arbace_go_repl_const_arbace_A_fn_class; if fncls__124 == nil { var fncls__124d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_359, false, nil); A_arbace_go_repl_const_arbace_A_fn_class = fncls__124d; tmp3 = fncls__124d } else { tmp3 = fncls__124 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__125, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_124)); return A_arbace_go_repl__init_A_const_123 }











func A_arbace_go_repl__init_A_Unit61__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(596, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_56; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_125)); return A_arbace_go_repl__init_A_const_56 }

func A_arbace_go_repl__init_A_Unit62__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(598, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_126; var tmp2 *lang.Compiler_AOTFn; var fnbody__127 any = A_arbace_go_repl_linkname_cell_A_New(); var tmp3 *jrt.Class; var fncls__126 *jrt.Class = A_arbace_go_repl_linkname_cell_A_fn_class; if fncls__126 == nil { var fncls__126d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_360, false, nil); A_arbace_go_repl_linkname_cell_A_fn_class = fncls__126d; tmp3 = fncls__126d } else { tmp3 = fncls__126 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__127, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_126; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_127)); return A_arbace_go_repl__init_A_const_126 }
















func A_arbace_go_repl__init_A_Unit63__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(615, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_128; var tmp2 *lang.Compiler_AOTFn; var fnbody__129 any = A_arbace_go_repl_intern_go_A_New(); var tmp3 *jrt.Class; var fncls__128 *jrt.Class = A_arbace_go_repl_intern_go_A_fn_class; if fncls__128 == nil { var fncls__128d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_361, false, nil); A_arbace_go_repl_intern_go_A_fn_class = fncls__128d; tmp3 = fncls__128d } else { tmp3 = fncls__128 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__129, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_129)); return A_arbace_go_repl__init_A_const_128 }








func A_arbace_go_repl__init_A_Unit64__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(624, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_130; var tmp2 *lang.Compiler_AOTFn; var fnbody__131 any = A_arbace_go_repl_define_BANG__A_New(); var tmp3 *jrt.Class; var fncls__130 *jrt.Class = A_arbace_go_repl_define_BANG__A_fn_class; if fncls__130 == nil { var fncls__130d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_362, false, nil); A_arbace_go_repl_define_BANG__A_fn_class = fncls__130d; tmp3 = fncls__130d } else { tmp3 = fncls__130 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__131, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_130; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_131)); return A_arbace_go_repl__init_A_const_130 }








































































































































































































func A_arbace_go_repl__init_A_Unit65__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(825, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_132; var tmp2 *lang.Compiler_AOTFn; var fnbody__133 any = A_arbace_go_repl_call0_A_New(); var tmp3 *jrt.Class; var fncls__132 *jrt.Class = A_arbace_go_repl_call0_A_fn_class; if fncls__132 == nil { var fncls__132d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_363, false, nil); A_arbace_go_repl_call0_A_fn_class = fncls__132d; tmp3 = fncls__132d } else { tmp3 = fncls__132 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__133, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_132; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_133)); return A_arbace_go_repl__init_A_const_132 }





func A_arbace_go_repl__init_A_Unit66__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(831, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_134; var tmp2 *lang.Compiler_AOTFn; var fnbody__135 any = A_arbace_go_repl_complete_BANG__A_New(); var tmp3 *jrt.Class; var fncls__134 *jrt.Class = A_arbace_go_repl_complete_BANG__A_fn_class; if fncls__134 == nil { var fncls__134d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_364, false, nil); A_arbace_go_repl_complete_BANG__A_fn_class = fncls__134d; tmp3 = fncls__134d } else { tmp3 = fncls__134 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__135, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_134; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_135)); return A_arbace_go_repl__init_A_const_134 }





















func A_arbace_go_repl__init_A_Unit67__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(853, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_136; var tmp2 *lang.Compiler_AOTFn; var fnbody__137 any = A_arbace_go_repl_after_load_A_New(); var tmp3 *jrt.Class; var fncls__136 *jrt.Class = A_arbace_go_repl_after_load_A_fn_class; if fncls__136 == nil { var fncls__136d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_365, false, nil); A_arbace_go_repl_after_load_A_fn_class = fncls__136d; tmp3 = fncls__136d } else { tmp3 = fncls__136 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__137, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_136; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_137)); return A_arbace_go_repl__init_A_const_136 }












func A_arbace_go_repl__init_A_Unit68__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(866, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_138; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_139)); v__1927001498__auto____1 = A_arbace_go_repl__init_A_const_138; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_go_repl__init_A_const_138; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_140)); var tmp3 *lang.Var = A_arbace_go_repl__init_A_const_138; var tmp4 *jrt.Boolean; var root_138 any = A_arbace_go_repl__init_A_const_141.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_138, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_140 lang.IFn
						if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = lang.RT_AFTER_LOAD.Ref(); var arg_142 any = A_arbace_go_repl__init_A_const_142.GetRawRoot__O(); var arg_143 any = A_arbace_go_repl__init_A_const_136; if linked_139 == nil { ifn_140.Invoke_O_O_O__O(arg_141, arg_142, arg_143) } else { linked_139.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_138, arg_141, arg_142, arg_143) }
//line :866:1
	tmp4 = jrt.Boolean_TRUE; tmp3.BindRoot_O__V(tmp4.Ref()); return A_arbace_go_repl__init_A_const_138 } }


func A_arbace_go_repl__init_A_Unit69__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(869, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_60; var tmp2 *lang.Compiler_AOTFn; var fnbody__145 any = A_arbace_go_repl_load_digest_package_BANG__A_New(); var tmp3 *jrt.Class; var fncls__144 *jrt.Class = A_arbace_go_repl_load_digest_package_BANG__A_fn_class; if fncls__144 == nil { var fncls__144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_366, false, nil); A_arbace_go_repl_load_digest_package_BANG__A_fn_class = fncls__144d; tmp3 = fncls__144d } else { tmp3 = fncls__144 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__145, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_143)); return A_arbace_go_repl__init_A_const_60 }






































func A_arbace_go_repl__init_A_Unit70__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(908, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_56; var tmp2 *lang.Compiler_AOTFn; var fnbody__147 any = A_arbace_go_repl_load_import_A_New(); var tmp3 *jrt.Class; var fncls__146 *jrt.Class = A_arbace_go_repl_load_import_A_fn_class; if fncls__146 == nil { var fncls__146d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_367, false, nil); A_arbace_go_repl_load_import_A_fn_class = fncls__146d; tmp3 = fncls__146d } else { tmp3 = fncls__146 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__147, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_144)); return A_arbace_go_repl__init_A_const_56 }















func A_arbace_go_repl__init_A_Unit71__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(924, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_145; var tmp2 *lang.Compiler_AOTFn; var fnbody__149 any = A_arbace_go_repl_directive_BANG__A_New(); var tmp3 *jrt.Class; var fncls__148 *jrt.Class = A_arbace_go_repl_directive_BANG__A_fn_class; if fncls__148 == nil { var fncls__148d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_368, false, nil); A_arbace_go_repl_directive_BANG__A_fn_class = fncls__148d; tmp3 = fncls__148d } else { tmp3 = fncls__148 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__149, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_145; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_146)); return A_arbace_go_repl__init_A_const_145 }








func A_arbace_go_repl__init_A_Unit72__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(933, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_147; var tmp2 *lang.Compiler_AOTFn; var fnbody__151 any = A_arbace_go_repl_declare_BANG__A_New(); var tmp3 *jrt.Class; var fncls__150 *jrt.Class = A_arbace_go_repl_declare_BANG__A_fn_class; if fncls__150 == nil { var fncls__150d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_369, false, nil); A_arbace_go_repl_declare_BANG__A_fn_class = fncls__150d; tmp3 = fncls__150d } else { tmp3 = fncls__150 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__151, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_147; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_148)); return A_arbace_go_repl__init_A_const_147 }

















































func A_arbace_go_repl__init_A_Unit73__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(983, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_149; var tmp2 any; var root_152 any = A_arbace_go_repl__init_A_const_26.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = A_arbace_go_repl__init_A_const_150; if linked_153 == nil { tmp2 = ifn_154.Invoke_O__O(arg_155) } else { tmp2 = linked_153.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_152, arg_155) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_go_repl__init_A_const_149; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_151)); return A_arbace_go_repl__init_A_const_149 }

func A_arbace_go_repl__init_A_Unit74__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(985, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_152; var tmp2 *lang.Compiler_AOTFn; var fnbody__157 any = A_arbace_go_repl_eval_BANG__A_New(); var tmp3 *jrt.Class; var fncls__156 *jrt.Class = A_arbace_go_repl_eval_BANG__A_fn_class; if fncls__156 == nil { var fncls__156d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_370, false, nil); A_arbace_go_repl_eval_BANG__A_fn_class = fncls__156d; tmp3 = fncls__156d } else { tmp3 = fncls__156 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__157, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_152; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_153)); return A_arbace_go_repl__init_A_const_152 }



















































func A_arbace_go_repl__init_A_Unit75__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1037, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_154; var tmp2 *lang.Compiler_AOTFn; var fnbody__159 any = A_arbace_go_repl_run_main_BANG__A_New(); var tmp3 *jrt.Class; var fncls__158 *jrt.Class = A_arbace_go_repl_run_main_BANG__A_fn_class; if fncls__158 == nil { var fncls__158d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_371, false, nil); A_arbace_go_repl_run_main_BANG__A_fn_class = fncls__158d; tmp3 = fncls__158d } else { tmp3 = fncls__158 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__159, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_154; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_155)); return A_arbace_go_repl__init_A_const_154 }









func A_arbace_go_repl__init_A_Unit76__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1047, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_156; var tmp2 *lang.Compiler_AOTFn; var fnbody__161 any = A_arbace_go_repl_check_BANG__A_New(); var tmp3 *jrt.Class; var fncls__160 *jrt.Class = A_arbace_go_repl_check_BANG__A_fn_class; if fncls__160 == nil { var fncls__160d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_372, false, nil); A_arbace_go_repl_check_BANG__A_fn_class = fncls__160d; tmp3 = fncls__160d } else { tmp3 = fncls__160 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__161, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_156; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_157)); return A_arbace_go_repl__init_A_const_156 }







func A_arbace_go_repl__init_A_Unit77__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1055, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_158; var tmp2 *lang.Compiler_AOTFn; var fnbody__163 any = A_arbace_go_repl_resolve_types_A_New(); var tmp3 *jrt.Class; var fncls__162 *jrt.Class = A_arbace_go_repl_resolve_types_A_fn_class; if fncls__162 == nil { var fncls__162d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_373, false, nil); A_arbace_go_repl_resolve_types_A_fn_class = fncls__162d; tmp3 = fncls__162d } else { tmp3 = fncls__162 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__163, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_158; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_159)); return A_arbace_go_repl__init_A_const_158 }
























func A_arbace_go_repl__init_A_Unit78__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1080, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_160; var tmp2 *lang.Compiler_AOTFn; var fnbody__165 any = A_arbace_go_repl_inst_BANG__A_New(); var tmp3 *jrt.Class; var fncls__164 *jrt.Class = A_arbace_go_repl_inst_BANG__A_fn_class; if fncls__164 == nil { var fncls__164d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_374, false, nil); A_arbace_go_repl_inst_BANG__A_fn_class = fncls__164d; tmp3 = fncls__164d } else { tmp3 = fncls__164 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__165, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_160; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_161)); return A_arbace_go_repl__init_A_const_160 }
































func A_arbace_go_repl__init_A_Unit79__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1113, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_162; var tmp2 *lang.Compiler_AOTFn; var fnbody__167 any = A_arbace_go_repl_listed_generic_BANG__A_New(); var tmp3 *jrt.Class; var fncls__166 *jrt.Class = A_arbace_go_repl_listed_generic_BANG__A_fn_class; if fncls__166 == nil { var fncls__166d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_375, false, nil); A_arbace_go_repl_listed_generic_BANG__A_fn_class = fncls__166d; tmp3 = fncls__166d } else { tmp3 = fncls__166 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__167, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_162; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_163)); return A_arbace_go_repl__init_A_const_162 }



















func A_arbace_go_repl__init_A_Unit80__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1133, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_164; var tmp2 *lang.Compiler_AOTFn; var fnbody__169 any = A_arbace_go_repl_form_text_A_New(); var tmp3 *jrt.Class; var fncls__168 *jrt.Class = A_arbace_go_repl_form_text_A_fn_class; if fncls__168 == nil { var fncls__168d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_376, false, nil); A_arbace_go_repl_form_text_A_fn_class = fncls__168d; tmp3 = fncls__168d } else { tmp3 = fncls__168 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__169, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_164; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_165)); return A_arbace_go_repl__init_A_const_164 }





func A_arbace_go_repl__init_A_Unit81__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1139, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_166; var tmp2 *lang.Compiler_AOTFn; var fnbody__171 any = A_arbace_go_repl_write_package_BANG__A_New(); var tmp3 *jrt.Class; var fncls__170 *jrt.Class = A_arbace_go_repl_write_package_BANG__A_fn_class; if fncls__170 == nil { var fncls__170d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_377, false, nil); A_arbace_go_repl_write_package_BANG__A_fn_class = fncls__170d; tmp3 = fncls__170d } else { tmp3 = fncls__170 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__171, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_166; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_167)); return A_arbace_go_repl__init_A_const_166 }
























func A_arbace_go_repl__init_A_Unit82__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1164, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_168; var tmp2 *lang.Compiler_AOTFn; var fnbody__173 any = A_arbace_go_repl_interpreted_closure_A_New(); var tmp3 *jrt.Class; var fncls__172 *jrt.Class = A_arbace_go_repl_interpreted_closure_A_fn_class; if fncls__172 == nil { var fncls__172d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_378, false, nil); A_arbace_go_repl_interpreted_closure_A_fn_class = fncls__172d; tmp3 = fncls__172d } else { tmp3 = fncls__172 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__173, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_168; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_169)); return A_arbace_go_repl__init_A_const_168 }












func A_arbace_go_repl__init_A_Unit83__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1177, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_170; var tmp2 *lang.Compiler_AOTFn; var fnbody__175 any = A_arbace_go_repl_run_compiled_BANG__A_New(); var tmp3 *jrt.Class; var fncls__174 *jrt.Class = A_arbace_go_repl_run_compiled_BANG__A_fn_class; if fncls__174 == nil { var fncls__174d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_379, false, nil); A_arbace_go_repl_run_compiled_BANG__A_fn_class = fncls__174d; tmp3 = fncls__174d } else { tmp3 = fncls__174 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__175, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_170; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_171)); return A_arbace_go_repl__init_A_const_170 }



type A_arbace_go_repl__init_A struct{ jrt.Object }

var A_arbace_go_repl__init_A_const_pool *jrt.RefArray

var A_arbace_go_repl__init_A_const_0 *lang.Var

var A_arbace_go_repl__init_A_const_1 any

var A_arbace_go_repl__init_A_const_2 any

var A_arbace_go_repl__init_A_const_3 any

var A_arbace_go_repl__init_A_const_4 *lang.Var

var A_arbace_go_repl__init_A_const_5 any

var A_arbace_go_repl__init_A_const_6 *lang.Var

var A_arbace_go_repl__init_A_const_7 any

var A_arbace_go_repl__init_A_const_8 *lang.Var

var A_arbace_go_repl__init_A_const_9 any

var A_arbace_go_repl__init_A_const_10 *lang.Var

var A_arbace_go_repl__init_A_const_11 any

var A_arbace_go_repl__init_A_const_12 *lang.Var

var A_arbace_go_repl__init_A_const_13 any

var A_arbace_go_repl__init_A_const_14 *lang.Var

var A_arbace_go_repl__init_A_const_15 any

var A_arbace_go_repl__init_A_const_16 *lang.Var

var A_arbace_go_repl__init_A_const_17 any

var A_arbace_go_repl__init_A_const_18 *lang.Var

var A_arbace_go_repl__init_A_const_19 any

var A_arbace_go_repl__init_A_const_20 *lang.Var

var A_arbace_go_repl__init_A_const_21 any

var A_arbace_go_repl__init_A_const_22 *lang.Var

var A_arbace_go_repl__init_A_const_23 any

var A_arbace_go_repl__init_A_const_24 *lang.Var

var A_arbace_go_repl__init_A_const_25 any

var A_arbace_go_repl__init_A_const_26 *lang.Var

var A_arbace_go_repl__init_A_const_27 any

var A_arbace_go_repl__init_A_const_28 *lang.Var

var A_arbace_go_repl__init_A_const_29 any

var A_arbace_go_repl__init_A_const_30 *lang.Var

var A_arbace_go_repl__init_A_const_31 any

var A_arbace_go_repl__init_A_const_32 *lang.Var

var A_arbace_go_repl__init_A_const_33 any

var A_arbace_go_repl__init_A_const_34 *lang.Var

var A_arbace_go_repl__init_A_const_35 any

var A_arbace_go_repl__init_A_const_36 *lang.Var

var A_arbace_go_repl__init_A_const_37 any

var A_arbace_go_repl__init_A_const_38 *lang.Var

var A_arbace_go_repl__init_A_const_39 any

var A_arbace_go_repl__init_A_const_40 *lang.Var

var A_arbace_go_repl__init_A_const_41 any

var A_arbace_go_repl__init_A_const_42 *lang.Var

var A_arbace_go_repl__init_A_const_43 any

var A_arbace_go_repl__init_A_const_44 *lang.Var

var A_arbace_go_repl__init_A_const_45 any

var A_arbace_go_repl__init_A_const_46 *lang.Var

var A_arbace_go_repl__init_A_const_47 any

var A_arbace_go_repl__init_A_const_48 *lang.Var

var A_arbace_go_repl__init_A_const_49 any

var A_arbace_go_repl__init_A_const_50 *lang.Var

var A_arbace_go_repl__init_A_const_51 any

var A_arbace_go_repl__init_A_const_52 *lang.Var

var A_arbace_go_repl__init_A_const_53 any

var A_arbace_go_repl__init_A_const_54 *lang.Var

var A_arbace_go_repl__init_A_const_55 any

var A_arbace_go_repl__init_A_const_56 *lang.Var

var A_arbace_go_repl__init_A_const_57 any

var A_arbace_go_repl__init_A_const_58 *lang.Var

var A_arbace_go_repl__init_A_const_59 any

var A_arbace_go_repl__init_A_const_60 *lang.Var

var A_arbace_go_repl__init_A_const_61 any

var A_arbace_go_repl__init_A_const_62 *lang.Var

var A_arbace_go_repl__init_A_const_63 any

var A_arbace_go_repl__init_A_const_64 *lang.Var

var A_arbace_go_repl__init_A_const_65 any

var A_arbace_go_repl__init_A_const_66 *lang.Var

var A_arbace_go_repl__init_A_const_67 any

var A_arbace_go_repl__init_A_const_68 *lang.Var

var A_arbace_go_repl__init_A_const_69 any

var A_arbace_go_repl__init_A_const_70 any

var A_arbace_go_repl__init_A_const_71 *lang.Var

var A_arbace_go_repl__init_A_const_72 any

var A_arbace_go_repl__init_A_const_73 any

var A_arbace_go_repl__init_A_const_74 *lang.Var

var A_arbace_go_repl__init_A_const_75 any

var A_arbace_go_repl__init_A_const_76 *lang.Var

var A_arbace_go_repl__init_A_const_77 any

var A_arbace_go_repl__init_A_const_78 any

var A_arbace_go_repl__init_A_const_79 *lang.Var

var A_arbace_go_repl__init_A_const_80 *lang.Var

var A_arbace_go_repl__init_A_const_81 *lang.Var

var A_arbace_go_repl__init_A_const_82 any

var A_arbace_go_repl__init_A_const_83 *lang.Var

var A_arbace_go_repl__init_A_const_84 any

var A_arbace_go_repl__init_A_const_85 *lang.Var

var A_arbace_go_repl__init_A_const_86 any

var A_arbace_go_repl__init_A_const_87 *lang.Var

var A_arbace_go_repl__init_A_const_88 any

var A_arbace_go_repl__init_A_const_89 *lang.Var

var A_arbace_go_repl__init_A_const_90 any

var A_arbace_go_repl__init_A_const_91 *lang.Var

var A_arbace_go_repl__init_A_const_92 any

var A_arbace_go_repl__init_A_const_93 *lang.Var

var A_arbace_go_repl__init_A_const_94 any

var A_arbace_go_repl__init_A_const_95 *lang.Var

var A_arbace_go_repl__init_A_const_96 any

var A_arbace_go_repl__init_A_const_97 *lang.Var

var A_arbace_go_repl__init_A_const_98 any

var A_arbace_go_repl__init_A_const_99 *lang.Var

var A_arbace_go_repl__init_A_const_100 any

var A_arbace_go_repl__init_A_const_101 *lang.Var

var A_arbace_go_repl__init_A_const_102 any

var A_arbace_go_repl__init_A_const_103 *lang.Var

var A_arbace_go_repl__init_A_const_104 any

var A_arbace_go_repl__init_A_const_105 *lang.Var

var A_arbace_go_repl__init_A_const_106 any

var A_arbace_go_repl__init_A_const_107 *lang.Var

var A_arbace_go_repl__init_A_const_108 any

var A_arbace_go_repl__init_A_const_109 *lang.Var

var A_arbace_go_repl__init_A_const_110 any

var A_arbace_go_repl__init_A_const_111 *lang.Var

var A_arbace_go_repl__init_A_const_112 any

var A_arbace_go_repl__init_A_const_113 any

var A_arbace_go_repl__init_A_const_114 *lang.Var

var A_arbace_go_repl__init_A_const_115 any

var A_arbace_go_repl__init_A_const_116 any

var A_arbace_go_repl__init_A_const_117 *lang.Var

var A_arbace_go_repl__init_A_const_118 any

var A_arbace_go_repl__init_A_const_119 *lang.Var

var A_arbace_go_repl__init_A_const_120 *lang.Keyword

var A_arbace_go_repl__init_A_const_121 *lang.Keyword

var A_arbace_go_repl__init_A_const_122 any

var A_arbace_go_repl__init_A_const_123 *lang.Var

var A_arbace_go_repl__init_A_const_124 any

var A_arbace_go_repl__init_A_const_125 any

var A_arbace_go_repl__init_A_const_126 *lang.Var

var A_arbace_go_repl__init_A_const_127 any

var A_arbace_go_repl__init_A_const_128 *lang.Var

var A_arbace_go_repl__init_A_const_129 any

var A_arbace_go_repl__init_A_const_130 *lang.Var

var A_arbace_go_repl__init_A_const_131 any

var A_arbace_go_repl__init_A_const_132 *lang.Var

var A_arbace_go_repl__init_A_const_133 any

var A_arbace_go_repl__init_A_const_134 *lang.Var

var A_arbace_go_repl__init_A_const_135 any

var A_arbace_go_repl__init_A_const_136 *lang.Var

var A_arbace_go_repl__init_A_const_137 any

var A_arbace_go_repl__init_A_const_138 *lang.Var

var A_arbace_go_repl__init_A_const_139 any

var A_arbace_go_repl__init_A_const_140 any

var A_arbace_go_repl__init_A_const_141 *lang.Var

var A_arbace_go_repl__init_A_const_142 *lang.Var

var A_arbace_go_repl__init_A_const_143 any

var A_arbace_go_repl__init_A_const_144 any

var A_arbace_go_repl__init_A_const_145 *lang.Var

var A_arbace_go_repl__init_A_const_146 any

var A_arbace_go_repl__init_A_const_147 *lang.Var

var A_arbace_go_repl__init_A_const_148 any

var A_arbace_go_repl__init_A_const_149 *lang.Var

var A_arbace_go_repl__init_A_const_150 any

var A_arbace_go_repl__init_A_const_151 any

var A_arbace_go_repl__init_A_const_152 *lang.Var

var A_arbace_go_repl__init_A_const_153 any

var A_arbace_go_repl__init_A_const_154 *lang.Var

var A_arbace_go_repl__init_A_const_155 any

var A_arbace_go_repl__init_A_const_156 *lang.Var

var A_arbace_go_repl__init_A_const_157 any

var A_arbace_go_repl__init_A_const_158 *lang.Var

var A_arbace_go_repl__init_A_const_159 any

var A_arbace_go_repl__init_A_const_160 *lang.Var

var A_arbace_go_repl__init_A_const_161 any

var A_arbace_go_repl__init_A_const_162 *lang.Var

var A_arbace_go_repl__init_A_const_163 any

var A_arbace_go_repl__init_A_const_164 *lang.Var

var A_arbace_go_repl__init_A_const_165 any

var A_arbace_go_repl__init_A_const_166 *lang.Var

var A_arbace_go_repl__init_A_const_167 any

var A_arbace_go_repl__init_A_const_168 *lang.Var

var A_arbace_go_repl__init_A_const_169 any

var A_arbace_go_repl__init_A_const_170 *lang.Var

var A_arbace_go_repl__init_A_const_171 any

var A_arbace_go_repl__init_A_init jrt.ClassInit

func A_arbace_go_repl__init_A_Init() { if !A_arbace_go_repl__init_A_init.Done() { A_arbace_go_repl__init_A_init.Run(A_arbace_go_repl__init_A_clinit) } }

func A_arbace_go_repl__init_A_clinit() { A_arbace_go_repl__init_A_clinit_p0(); A_arbace_go_repl__init_A_clinit_p1(); A_arbace_go_repl__init_A_clinit_p2(); A_arbace_go_repl__init_A_clinit_p3(); A_arbace_go_repl__init_A_clinit_p4(); A_arbace_go_repl__init_A_clinit_p5(); A_arbace_go_repl__init_A_clinit_p6(); A_arbace_go_repl__init_A_clinit_p7(); A_arbace_go_repl__init_A_clinit_p8(); A_arbace_go_repl__init_A_clinit_p9(); A_arbace_go_repl__init_A_clinit_p10(); A_arbace_go_repl__init_A_clinit_p11(); A_arbace_go_repl__init_A_clinit_p12(); A_arbace_go_repl__init_A_clinit_p13() }

func A_arbace_go_repl__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_repl__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_307, 228); A_arbace_go_repl__init_A_const_0 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[56]); A_arbace_go_repl__init_A_const_1 = A_arbace_go_repl__init_A_const_pool.A[57]; A_arbace_go_repl__init_A_const_2 = A_arbace_go_repl__init_A_const_pool.A[58]; A_arbace_go_repl__init_A_const_3 = A_arbace_go_repl__init_A_const_pool.A[59]; A_arbace_go_repl__init_A_const_4 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[60]); A_arbace_go_repl__init_A_const_5 = A_arbace_go_repl__init_A_const_pool.A[61]; A_arbace_go_repl__init_A_const_6 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[62]); A_arbace_go_repl__init_A_const_7 = A_arbace_go_repl__init_A_const_pool.A[63]; A_arbace_go_repl__init_A_const_8 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[64]); A_arbace_go_repl__init_A_const_9 = A_arbace_go_repl__init_A_const_pool.A[65]; A_arbace_go_repl__init_A_const_10 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[66]); A_arbace_go_repl__init_A_const_11 = A_arbace_go_repl__init_A_const_pool.A[67]; A_arbace_go_repl__init_A_const_12 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[68]) }

func A_arbace_go_repl__init_A_clinit_p1() { A_arbace_go_repl__init_A_const_13 = A_arbace_go_repl__init_A_const_pool.A[69]; A_arbace_go_repl__init_A_const_14 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[70]); A_arbace_go_repl__init_A_const_15 = A_arbace_go_repl__init_A_const_pool.A[71]; A_arbace_go_repl__init_A_const_16 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[72]); A_arbace_go_repl__init_A_const_17 = A_arbace_go_repl__init_A_const_pool.A[73]; A_arbace_go_repl__init_A_const_18 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[74]); A_arbace_go_repl__init_A_const_19 = A_arbace_go_repl__init_A_const_pool.A[75]; A_arbace_go_repl__init_A_const_20 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[76]); A_arbace_go_repl__init_A_const_21 = A_arbace_go_repl__init_A_const_pool.A[77]; A_arbace_go_repl__init_A_const_22 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[78]); A_arbace_go_repl__init_A_const_23 = A_arbace_go_repl__init_A_const_pool.A[79]; A_arbace_go_repl__init_A_const_24 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[80]); A_arbace_go_repl__init_A_const_25 = A_arbace_go_repl__init_A_const_pool.A[81] }

func A_arbace_go_repl__init_A_clinit_p2() { A_arbace_go_repl__init_A_const_26 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[82]); A_arbace_go_repl__init_A_const_27 = A_arbace_go_repl__init_A_const_pool.A[83]; A_arbace_go_repl__init_A_const_28 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[84]); A_arbace_go_repl__init_A_const_29 = A_arbace_go_repl__init_A_const_pool.A[85]; A_arbace_go_repl__init_A_const_30 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[86]); A_arbace_go_repl__init_A_const_31 = A_arbace_go_repl__init_A_const_pool.A[87]; A_arbace_go_repl__init_A_const_32 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[88]); A_arbace_go_repl__init_A_const_33 = A_arbace_go_repl__init_A_const_pool.A[89]; A_arbace_go_repl__init_A_const_34 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[90]); A_arbace_go_repl__init_A_const_35 = A_arbace_go_repl__init_A_const_pool.A[91]; A_arbace_go_repl__init_A_const_36 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[92]); A_arbace_go_repl__init_A_const_37 = A_arbace_go_repl__init_A_const_pool.A[93]; A_arbace_go_repl__init_A_const_38 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[94]) }

func A_arbace_go_repl__init_A_clinit_p3() { A_arbace_go_repl__init_A_const_39 = A_arbace_go_repl__init_A_const_pool.A[95]; A_arbace_go_repl__init_A_const_40 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[96]); A_arbace_go_repl__init_A_const_41 = A_arbace_go_repl__init_A_const_pool.A[97]; A_arbace_go_repl__init_A_const_42 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[98]); A_arbace_go_repl__init_A_const_43 = A_arbace_go_repl__init_A_const_pool.A[99]; A_arbace_go_repl__init_A_const_44 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[100]); A_arbace_go_repl__init_A_const_45 = A_arbace_go_repl__init_A_const_pool.A[101]; A_arbace_go_repl__init_A_const_46 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[102]); A_arbace_go_repl__init_A_const_47 = A_arbace_go_repl__init_A_const_pool.A[103]; A_arbace_go_repl__init_A_const_48 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[104]); A_arbace_go_repl__init_A_const_49 = A_arbace_go_repl__init_A_const_pool.A[105]; A_arbace_go_repl__init_A_const_50 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[106]); A_arbace_go_repl__init_A_const_51 = A_arbace_go_repl__init_A_const_pool.A[107] }

func A_arbace_go_repl__init_A_clinit_p4() { A_arbace_go_repl__init_A_const_52 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[108]); A_arbace_go_repl__init_A_const_53 = A_arbace_go_repl__init_A_const_pool.A[109]; A_arbace_go_repl__init_A_const_54 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[110]); A_arbace_go_repl__init_A_const_55 = A_arbace_go_repl__init_A_const_pool.A[111]; A_arbace_go_repl__init_A_const_56 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[112]); A_arbace_go_repl__init_A_const_57 = A_arbace_go_repl__init_A_const_pool.A[113]; A_arbace_go_repl__init_A_const_58 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[114]); A_arbace_go_repl__init_A_const_59 = A_arbace_go_repl__init_A_const_pool.A[115]; A_arbace_go_repl__init_A_const_60 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[116]); A_arbace_go_repl__init_A_const_61 = A_arbace_go_repl__init_A_const_pool.A[117]; A_arbace_go_repl__init_A_const_62 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[118]); A_arbace_go_repl__init_A_const_63 = A_arbace_go_repl__init_A_const_pool.A[119]; A_arbace_go_repl__init_A_const_64 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[120]) }

func A_arbace_go_repl__init_A_clinit_p5() { A_arbace_go_repl__init_A_const_65 = A_arbace_go_repl__init_A_const_pool.A[121]; A_arbace_go_repl__init_A_const_66 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[122]); A_arbace_go_repl__init_A_const_67 = A_arbace_go_repl__init_A_const_pool.A[123]; A_arbace_go_repl__init_A_const_68 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[124]); A_arbace_go_repl__init_A_const_69 = A_arbace_go_repl__init_A_const_pool.A[125]; A_arbace_go_repl__init_A_const_70 = A_arbace_go_repl__init_A_const_pool.A[126]; A_arbace_go_repl__init_A_const_71 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[127]); A_arbace_go_repl__init_A_const_72 = A_arbace_go_repl__init_A_const_pool.A[128]; A_arbace_go_repl__init_A_const_73 = A_arbace_go_repl__init_A_const_pool.A[129]; A_arbace_go_repl__init_A_const_74 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[130]); A_arbace_go_repl__init_A_const_75 = A_arbace_go_repl__init_A_const_pool.A[131]; A_arbace_go_repl__init_A_const_76 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[132]); A_arbace_go_repl__init_A_const_77 = A_arbace_go_repl__init_A_const_pool.A[133]; A_arbace_go_repl__init_A_const_78 = A_arbace_go_repl__init_A_const_pool.A[134] }

func A_arbace_go_repl__init_A_clinit_p6() { A_arbace_go_repl__init_A_const_79 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[135]); A_arbace_go_repl__init_A_const_80 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[136]); A_arbace_go_repl__init_A_const_81 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[137]); A_arbace_go_repl__init_A_const_82 = A_arbace_go_repl__init_A_const_pool.A[138]; A_arbace_go_repl__init_A_const_83 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[139]); A_arbace_go_repl__init_A_const_84 = A_arbace_go_repl__init_A_const_pool.A[140]; A_arbace_go_repl__init_A_const_85 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[141]); A_arbace_go_repl__init_A_const_86 = A_arbace_go_repl__init_A_const_pool.A[142]; A_arbace_go_repl__init_A_const_87 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[143]); A_arbace_go_repl__init_A_const_88 = A_arbace_go_repl__init_A_const_pool.A[144]; A_arbace_go_repl__init_A_const_89 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[145]); A_arbace_go_repl__init_A_const_90 = A_arbace_go_repl__init_A_const_pool.A[146]; A_arbace_go_repl__init_A_const_91 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[147]) }

func A_arbace_go_repl__init_A_clinit_p7() { A_arbace_go_repl__init_A_const_92 = A_arbace_go_repl__init_A_const_pool.A[148]; A_arbace_go_repl__init_A_const_93 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[149]); A_arbace_go_repl__init_A_const_94 = A_arbace_go_repl__init_A_const_pool.A[150]; A_arbace_go_repl__init_A_const_95 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[151]); A_arbace_go_repl__init_A_const_96 = A_arbace_go_repl__init_A_const_pool.A[152]; A_arbace_go_repl__init_A_const_97 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[153]); A_arbace_go_repl__init_A_const_98 = A_arbace_go_repl__init_A_const_pool.A[154]; A_arbace_go_repl__init_A_const_99 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[155]); A_arbace_go_repl__init_A_const_100 = A_arbace_go_repl__init_A_const_pool.A[156]; A_arbace_go_repl__init_A_const_101 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[157]); A_arbace_go_repl__init_A_const_102 = A_arbace_go_repl__init_A_const_pool.A[158]; A_arbace_go_repl__init_A_const_103 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[159]); A_arbace_go_repl__init_A_const_104 = A_arbace_go_repl__init_A_const_pool.A[160] }

func A_arbace_go_repl__init_A_clinit_p8() { A_arbace_go_repl__init_A_const_105 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[161]); A_arbace_go_repl__init_A_const_106 = A_arbace_go_repl__init_A_const_pool.A[162]; A_arbace_go_repl__init_A_const_107 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[163]); A_arbace_go_repl__init_A_const_108 = A_arbace_go_repl__init_A_const_pool.A[164]; A_arbace_go_repl__init_A_const_109 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[165]); A_arbace_go_repl__init_A_const_110 = A_arbace_go_repl__init_A_const_pool.A[166]; A_arbace_go_repl__init_A_const_111 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[167]); A_arbace_go_repl__init_A_const_112 = A_arbace_go_repl__init_A_const_pool.A[168]; A_arbace_go_repl__init_A_const_113 = A_arbace_go_repl__init_A_const_pool.A[169]; A_arbace_go_repl__init_A_const_114 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[170]); A_arbace_go_repl__init_A_const_115 = A_arbace_go_repl__init_A_const_pool.A[171]; A_arbace_go_repl__init_A_const_116 = A_arbace_go_repl__init_A_const_pool.A[172]; A_arbace_go_repl__init_A_const_117 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[173]); A_arbace_go_repl__init_A_const_118 = A_arbace_go_repl__init_A_const_pool.A[174] }

func A_arbace_go_repl__init_A_clinit_p9() { A_arbace_go_repl__init_A_const_119 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[175]); A_arbace_go_repl__init_A_const_120 = lang.Keyword_Cast(A_arbace_go_repl__init_A_const_pool.A[176]); A_arbace_go_repl__init_A_const_121 = lang.Keyword_Cast(A_arbace_go_repl__init_A_const_pool.A[177]); A_arbace_go_repl__init_A_const_122 = A_arbace_go_repl__init_A_const_pool.A[178]; A_arbace_go_repl__init_A_const_123 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[179]); A_arbace_go_repl__init_A_const_124 = A_arbace_go_repl__init_A_const_pool.A[180]; A_arbace_go_repl__init_A_const_125 = A_arbace_go_repl__init_A_const_pool.A[181]; A_arbace_go_repl__init_A_const_126 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[182]); A_arbace_go_repl__init_A_const_127 = A_arbace_go_repl__init_A_const_pool.A[183]; A_arbace_go_repl__init_A_const_128 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[184]); A_arbace_go_repl__init_A_const_129 = A_arbace_go_repl__init_A_const_pool.A[185]; A_arbace_go_repl__init_A_const_130 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[186]); A_arbace_go_repl__init_A_const_131 = A_arbace_go_repl__init_A_const_pool.A[187] }

func A_arbace_go_repl__init_A_clinit_p10() { A_arbace_go_repl__init_A_const_132 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[188]); A_arbace_go_repl__init_A_const_133 = A_arbace_go_repl__init_A_const_pool.A[189]; A_arbace_go_repl__init_A_const_134 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[190]); A_arbace_go_repl__init_A_const_135 = A_arbace_go_repl__init_A_const_pool.A[191]; A_arbace_go_repl__init_A_const_136 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[192]); A_arbace_go_repl__init_A_const_137 = A_arbace_go_repl__init_A_const_pool.A[193]; A_arbace_go_repl__init_A_const_138 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[194]); A_arbace_go_repl__init_A_const_139 = A_arbace_go_repl__init_A_const_pool.A[195]; A_arbace_go_repl__init_A_const_140 = A_arbace_go_repl__init_A_const_pool.A[196]; A_arbace_go_repl__init_A_const_141 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[197]); A_arbace_go_repl__init_A_const_142 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[198]); A_arbace_go_repl__init_A_const_143 = A_arbace_go_repl__init_A_const_pool.A[199]; A_arbace_go_repl__init_A_const_144 = A_arbace_go_repl__init_A_const_pool.A[200] }

func A_arbace_go_repl__init_A_clinit_p11() { A_arbace_go_repl__init_A_const_145 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[201]); A_arbace_go_repl__init_A_const_146 = A_arbace_go_repl__init_A_const_pool.A[202]; A_arbace_go_repl__init_A_const_147 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[203]); A_arbace_go_repl__init_A_const_148 = A_arbace_go_repl__init_A_const_pool.A[204]; A_arbace_go_repl__init_A_const_149 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[205]); A_arbace_go_repl__init_A_const_150 = A_arbace_go_repl__init_A_const_pool.A[206]; A_arbace_go_repl__init_A_const_151 = A_arbace_go_repl__init_A_const_pool.A[207]; A_arbace_go_repl__init_A_const_152 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[208]); A_arbace_go_repl__init_A_const_153 = A_arbace_go_repl__init_A_const_pool.A[209]; A_arbace_go_repl__init_A_const_154 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[210]); A_arbace_go_repl__init_A_const_155 = A_arbace_go_repl__init_A_const_pool.A[211]; A_arbace_go_repl__init_A_const_156 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[212]); A_arbace_go_repl__init_A_const_157 = A_arbace_go_repl__init_A_const_pool.A[213] }

func A_arbace_go_repl__init_A_clinit_p12() { A_arbace_go_repl__init_A_const_158 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[214]); A_arbace_go_repl__init_A_const_159 = A_arbace_go_repl__init_A_const_pool.A[215]; A_arbace_go_repl__init_A_const_160 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[216]); A_arbace_go_repl__init_A_const_161 = A_arbace_go_repl__init_A_const_pool.A[217]; A_arbace_go_repl__init_A_const_162 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[218]); A_arbace_go_repl__init_A_const_163 = A_arbace_go_repl__init_A_const_pool.A[219]; A_arbace_go_repl__init_A_const_164 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[220]); A_arbace_go_repl__init_A_const_165 = A_arbace_go_repl__init_A_const_pool.A[221]; A_arbace_go_repl__init_A_const_166 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[222]); A_arbace_go_repl__init_A_const_167 = A_arbace_go_repl__init_A_const_pool.A[223]; A_arbace_go_repl__init_A_const_168 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[224]); A_arbace_go_repl__init_A_const_169 = A_arbace_go_repl__init_A_const_pool.A[225]; A_arbace_go_repl__init_A_const_170 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[226]) }

func A_arbace_go_repl__init_A_clinit_p13() { A_arbace_go_repl__init_A_const_171 = A_arbace_go_repl__init_A_const_pool.A[227] }

func A_arbace_go_repl__init_A_New() *A_arbace_go_repl__init_A { A_arbace_go_repl__init_A_Init(); t := &A_arbace_go_repl__init_A{}; t.Ctor(); return t }

func (t *A_arbace_go_repl__init_A) Ctor() {}

func (t *A_arbace_go_repl__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_repl__init_A) GetClass__Class() *jrt.Class { return A_arbace_go_repl__init_A_class }

func (t *A_arbace_go_repl__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_repl__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_repl__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_repl__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_repl__init_A); return ok }

func A_arbace_go_repl__init_A_Cast(x any) *A_arbace_go_repl__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_repl__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_repl__init_A_class)) }; return v }
