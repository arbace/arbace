//line aot_arbace_go_repl__init.ae:1
package aot_arbace_go_repl

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_repl__init_A_Unit0__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_go_repl__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_repl__init_A_const_1) }
//line :1:1
func A_arbace_go_repl__init_A_Unit1__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_go_repl__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_2)) }
//line :1:1
func A_arbace_go_repl__init_A_Unit2__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_go_repl_eval794000004_loading__1927001464__auto____794000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_repl_eval794000004_loading__1927001464__auto____794000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_258, false); A_arbace_go_repl_eval794000004_loading__1927001464__auto____794000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_go_repl__init_A_Unit3__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_go_repl__init_A_const_1)).Equals_O__Z(A_arbace_go_repl__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_go_repl_eval794000008_fn__794000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_go_repl_eval794000008_fn__794000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_259, false); A_arbace_go_repl_eval794000008_fn__794000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_go_repl__init_A_Load__O() any { A_arbace_go_repl__init_A_Init(); jrt.StartCheck(); A_arbace_go_repl__init_A_Unit0__O(); A_arbace_go_repl__init_A_Unit1__O(); A_arbace_go_repl__init_A_Unit2__O(); A_arbace_go_repl__init_A_Unit3__O(); A_arbace_go_repl__init_A_Unit4__O(); A_arbace_go_repl__init_A_Unit5__O(); A_arbace_go_repl__init_A_Unit6__O(); A_arbace_go_repl__init_A_Unit7__O(); A_arbace_go_repl__init_A_Unit8__O(); A_arbace_go_repl__init_A_Unit9__O(); A_arbace_go_repl__init_A_Unit10__O(); A_arbace_go_repl__init_A_Unit11__O(); A_arbace_go_repl__init_A_Unit12__O(); A_arbace_go_repl__init_A_Unit13__O(); A_arbace_go_repl__init_A_Unit14__O(); A_arbace_go_repl__init_A_Unit15__O(); A_arbace_go_repl__init_A_Unit16__O(); A_arbace_go_repl__init_A_Unit17__O(); A_arbace_go_repl__init_A_Unit18__O(); A_arbace_go_repl__init_A_Unit19__O(); A_arbace_go_repl__init_A_Unit20__O(); A_arbace_go_repl__init_A_Unit21__O(); A_arbace_go_repl__init_A_Unit22__O(); A_arbace_go_repl__init_A_Unit23__O(); A_arbace_go_repl__init_A_Unit24__O(); A_arbace_go_repl__init_A_Unit25__O(); A_arbace_go_repl__init_A_Unit26__O(); A_arbace_go_repl__init_A_Unit27__O(); A_arbace_go_repl__init_A_Unit28__O(); A_arbace_go_repl__init_A_Unit29__O(); A_arbace_go_repl__init_A_Unit30__O(); A_arbace_go_repl__init_A_Unit31__O(); A_arbace_go_repl__init_A_Unit32__O(); A_arbace_go_repl__init_A_Unit33__O(); A_arbace_go_repl__init_A_Unit34__O(); A_arbace_go_repl__init_A_Unit35__O(); A_arbace_go_repl__init_A_Unit36__O(); A_arbace_go_repl__init_A_Unit37__O(); A_arbace_go_repl__init_A_Unit38__O(); A_arbace_go_repl__init_A_Unit39__O(); A_arbace_go_repl__init_A_Unit40__O(); A_arbace_go_repl__init_A_Unit41__O(); A_arbace_go_repl__init_A_Unit42__O(); A_arbace_go_repl__init_A_Unit43__O(); A_arbace_go_repl__init_A_Unit44__O(); A_arbace_go_repl__init_A_Unit45__O(); A_arbace_go_repl__init_A_Unit46__O(); A_arbace_go_repl__init_A_Unit47__O(); A_arbace_go_repl__init_A_Unit48__O(); A_arbace_go_repl__init_A_Unit49__O(); A_arbace_go_repl__init_A_Unit50__O(); A_arbace_go_repl__init_A_Unit51__O(); A_arbace_go_repl__init_A_Unit52__O(); A_arbace_go_repl__init_A_Unit53__O(); A_arbace_go_repl__init_A_Unit54__O(); A_arbace_go_repl__init_A_Unit55__O(); A_arbace_go_repl__init_A_Unit56__O(); A_arbace_go_repl__init_A_Unit57__O(); A_arbace_go_repl__init_A_Unit58__O(); A_arbace_go_repl__init_A_Unit59__O(); A_arbace_go_repl__init_A_Unit60__O(); A_arbace_go_repl__init_A_Unit61__O(); A_arbace_go_repl__init_A_Unit62__O(); A_arbace_go_repl__init_A_Unit63__O(); A_arbace_go_repl__init_A_Unit64__O(); A_arbace_go_repl__init_A_Unit65__O(); A_arbace_go_repl__init_A_Unit66__O(); A_arbace_go_repl__init_A_Unit67__O(); A_arbace_go_repl__init_A_Unit68__O(); return nil }





















func A_arbace_go_repl__init_A_Unit4__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(27, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_4; var tmp2 any = A_arbace_go_repl_fn__794000012_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_repl_fn__794000012_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_260, false); A_arbace_go_repl_fn__794000012_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_5)); return A_arbace_go_repl__init_A_const_4 }

func A_arbace_go_repl__init_A_Unit5__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(29, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_6; var tmp2 any = A_arbace_go_repl_listed_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_go_repl_listed_QMARK__A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_261, false); A_arbace_go_repl_listed_QMARK__A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_7)); return A_arbace_go_repl__init_A_const_6 }




func A_arbace_go_repl__init_A_Unit6__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(34, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_8; var tmp2 any = A_arbace_go_repl_fn__794000015_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_repl_fn__794000015_A_fn_class; if
						fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_262, false); A_arbace_go_repl_fn__794000015_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; /*line :34:1*/tmp1.BindRoot_O__V(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_9)); return A_arbace_go_repl__init_A_const_8 }





func A_arbace_go_repl__init_A_Unit7__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(40, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_10; var tmp2 any = A_arbace_go_repl_digest_forms_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_go_repl_digest_forms_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_263, false); A_arbace_go_repl_digest_forms_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_11)); return A_arbace_go_repl__init_A_const_10 }






func A_arbace_go_repl__init_A_Unit8__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_12; var tmp2 any = A_arbace_go_repl_fn__794000024_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_repl_fn__794000024_A_fn_class; if

	fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_264, false); A_arbace_go_repl_fn__794000024_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; /*line :47:1*/tmp1.BindRoot_O__V(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_13)); return A_arbace_go_repl__init_A_const_12 }







func A_arbace_go_repl__init_A_Unit9__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(55, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_14; var tmp2 any = A_arbace_go_repl_interpretable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_go_repl_interpretable_QMARK__A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_265, false); A_arbace_go_repl_interpretable_QMARK__A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_15)); return A_arbace_go_repl__init_A_const_14 }





func A_arbace_go_repl__init_A_Unit10__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(61, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_16; var tmp2 any = A_arbace_go_repl_fn__794000030_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_repl_fn__794000030_A_fn_class; if

	fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_266, false); A_arbace_go_repl_fn__794000030_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; /*line :61:1*/tmp1.BindRoot_O__V(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_17)); return A_arbace_go_repl__init_A_const_16 }





func A_arbace_go_repl__init_A_Unit11__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(67, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_18; var tmp2 any = A_arbace_go_repl_refusal_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_go_repl_refusal_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_267, false); A_arbace_go_repl_refusal_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_19)); return A_arbace_go_repl__init_A_const_18 }
















func A_arbace_go_repl__init_A_Unit12__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(84, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_20; var tmp2 any = A_arbace_go_repl_fn__794000034_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_repl_fn__794000034_A_fn_class; if




	fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_268, false); A_arbace_go_repl_fn__794000034_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; /*line :84:1*/tmp1.BindRoot_O__V(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_21)); return A_arbace_go_repl__init_A_const_20 }













func A_arbace_go_repl__init_A_Unit13__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(98, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_22; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_23)); v__1927001498__auto____1 = A_arbace_go_repl__init_A_const_22; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_go_repl__init_A_const_22; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_25)); var tmp3 *lang.Var = A_arbace_go_repl__init_A_const_22; var tmp4 any; var root_12 any = A_arbace_go_repl__init_A_const_24.GetRawRoot__O(); var linked_13 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_12, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_14 lang.IFn; if linked_13 == nil { ifn_14 = lang.IFn_Cast(root_12) } else { ifn_14 = nil }; var arg_15 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_13 == nil { tmp4 = ifn_14.Invoke_O__O(arg_15) } else { tmp4 = linked_13.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_12, arg_15) }; tmp3.BindRoot_O__V(tmp4); return A_arbace_go_repl__init_A_const_22 } }

func A_arbace_go_repl__init_A_Unit14__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(100, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_26; var tmp2 any = A_arbace_go_repl_path__GT_ns_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_go_repl_path__GT_ns_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_269, false); A_arbace_go_repl_path__GT_ns_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_27)); return A_arbace_go_repl__init_A_const_26 }




func A_arbace_go_repl__init_A_Unit15__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(105, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_28; var tmp2 any = A_arbace_go_repl_ns__GT_path_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_repl_ns__GT_path_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_270, false); A_arbace_go_repl_ns__GT_path_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_29)); return A_arbace_go_repl__init_A_const_28 }




func A_arbace_go_repl__init_A_Unit16__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(110, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_30; var tmp2 any = A_arbace_go_repl_new_state_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_go_repl_new_state_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_271, false); A_arbace_go_repl_new_state_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_31)); return A_arbace_go_repl__init_A_const_30 }



func A_arbace_go_repl__init_A_Unit17__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(114, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_32; var tmp2 any = A_arbace_go_repl_package_state_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_repl_package_state_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_272, false); A_arbace_go_repl_package_state_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_33)); return A_arbace_go_repl__init_A_const_32 }















func A_arbace_go_repl__init_A_Unit18__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(130, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_34; var tmp2 any = A_arbace_go_repl_package_BANG__A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_go_repl_package_BANG__A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_273, false); A_arbace_go_repl_package_BANG__A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_35)); return A_arbace_go_repl__init_A_const_34 }












func A_arbace_go_repl__init_A_Unit19__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(143, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_36; var tmp2 any = A_arbace_go_repl_file_entry_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_repl_file_entry_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_274, false); A_arbace_go_repl_file_entry_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_37)); return A_arbace_go_repl__init_A_const_36 }


func A_arbace_go_repl__init_A_Unit20__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(146, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_38; var tmp2 any = A_arbace_go_repl_update_file_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_go_repl_update_file_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_275, false); A_arbace_go_repl_update_file_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_39)); return A_arbace_go_repl__init_A_const_38 }






func A_arbace_go_repl__init_A_Unit21__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(153, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_40; var tmp2 any = A_arbace_go_repl_file_BANG__A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_repl_file_BANG__A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_276, false); A_arbace_go_repl_file_BANG__A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_41)); return A_arbace_go_repl__init_A_const_40 }








func A_arbace_go_repl__init_A_Unit22__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(162, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_42; var tmp2 any = A_arbace_go_repl_import_BANG__A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_go_repl_import_BANG__A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_277, false); A_arbace_go_repl_import_BANG__A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_43)); return A_arbace_go_repl__init_A_const_42 }










func A_arbace_go_repl__init_A_Unit23__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(173, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_44; var tmp2 any = A_arbace_go_repl_decl_names_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_go_repl_decl_names_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_278, false); A_arbace_go_repl_decl_names_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_45)); return A_arbace_go_repl__init_A_const_44 }



























func A_arbace_go_repl__init_A_Unit24__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(201, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_46; var tmp2 any = A_arbace_go_repl_error_text_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_go_repl_error_text_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_279, false); A_arbace_go_repl_error_text_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_47)); return A_arbace_go_repl__init_A_const_46 }







func A_arbace_go_repl__init_A_Unit25__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(209, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_48; var tmp2 any = A_arbace_go_repl_repl_source_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_go_repl_repl_source_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_280, false); A_arbace_go_repl_repl_source_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_49)); return A_arbace_go_repl__init_A_const_48 }

func A_arbace_go_repl__init_A_Unit26__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(211, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_50; var tmp2 any = A_arbace_go_repl_source_of_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_go_repl_source_of_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_281, false); A_arbace_go_repl_source_of_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_51)); return A_arbace_go_repl__init_A_const_50 }








func A_arbace_go_repl__init_A_Unit27__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(220, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_52; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_53)); return A_arbace_go_repl__init_A_const_52 }

func A_arbace_go_repl__init_A_Unit28__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(222, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_54; var tmp2 any = A_arbace_go_repl_session_for_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_go_repl_session_for_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_282, false); A_arbace_go_repl_session_for_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_55)); return A_arbace_go_repl__init_A_const_54 }











func A_arbace_go_repl__init_A_Unit29__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(234, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_56; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_57)); return A_arbace_go_repl__init_A_const_56 }

func A_arbace_go_repl__init_A_Unit30__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(236, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_58; var tmp2 any = A_arbace_go_repl_define_digest_imports_BANG__A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_go_repl_define_digest_imports_BANG__A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_283, false); A_arbace_go_repl_define_digest_imports_BANG__A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_59)); return A_arbace_go_repl__init_A_const_58 }










func A_arbace_go_repl__init_A_Unit31__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(247, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_60; var tmp2 any = A_arbace_go_repl_check_source_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_repl_check_source_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_284, false); A_arbace_go_repl_check_source_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_61)); return A_arbace_go_repl__init_A_const_60 }













func A_arbace_go_repl__init_A_Unit32__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(261, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_62; var tmp2 any = A_arbace_go_repl_type_key_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_go_repl_type_key_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_285, false); A_arbace_go_repl_type_key_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_63)); return A_arbace_go_repl__init_A_const_62 }
















func A_arbace_go_repl__init_A_Unit33__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(278, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_64; var tmp2 any = A_arbace_go_repl_state_of_path_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_go_repl_state_of_path_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_286, false); A_arbace_go_repl_state_of_path_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_65)); return A_arbace_go_repl__init_A_const_64 }

func A_arbace_go_repl__init_A_Unit34__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(280, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_66; var tmp2 any = A_arbace_go_repl_method_name_A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_go_repl_method_name_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_287, false); A_arbace_go_repl_method_name_A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_67)); return A_arbace_go_repl__init_A_const_66 }





func A_arbace_go_repl__init_A_Unit35__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(286, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_68; var tmp2 any = A_arbace_go_repl_display_file_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_go_repl_display_file_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_288, false); A_arbace_go_repl_display_file_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_69)); return A_arbace_go_repl__init_A_const_68 }





func A_arbace_go_repl__init_A_Unit36__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(292, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_70; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_71)); return A_arbace_go_repl__init_A_const_70 }

func A_arbace_go_repl__init_A_Unit37__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(294, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_72; var tmp2 any; var root_36 any = A_arbace_go_repl__init_A_const_24.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_37 == nil { tmp2 = ifn_38.Invoke_O__O(arg_39) } else { tmp2 = linked_37.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_36, arg_39) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_go_repl__init_A_const_72; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_73)); return A_arbace_go_repl__init_A_const_72 }

func A_arbace_go_repl__init_A_Unit38__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(296, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_74; var tmp2 any = A_arbace_go_repl_table_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_go_repl_table_type_QMARK__A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_289, false); A_arbace_go_repl_table_type_QMARK__A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_75)); return A_arbace_go_repl__init_A_const_74 }









func A_arbace_go_repl__init_A_Unit39__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(306, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_76; var tmp2 any = A_arbace_go_repl_digest_scope_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_go_repl_digest_scope_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_290, false); A_arbace_go_repl_digest_scope_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_77)); return A_arbace_go_repl__init_A_const_76 }




func A_arbace_go_repl__init_A_Unit40__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(311, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_78; var tmp2 any = A_arbace_go_repl_build_context_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_go_repl_build_context_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_291, false); A_arbace_go_repl_build_context_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_79)); return A_arbace_go_repl__init_A_const_78 }




























func A_arbace_go_repl__init_A_Unit41__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(340, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_80; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_81)); v__1927001498__auto____1 = A_arbace_go_repl__init_A_const_80; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_go_repl__init_A_const_80; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_82)); var tmp3 *lang.Var = A_arbace_go_repl__init_A_const_80; var tmp4 any; var root_43 any = A_arbace_go_repl__init_A_const_24.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_45 lang.IFn
						if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_44 == nil { tmp4 = ifn_45.Invoke_O__O(arg_46) } else { tmp4 = linked_44.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_43, arg_46) }
//line :340:1
	tmp3.BindRoot_O__V(tmp4); return A_arbace_go_repl__init_A_const_80 } }


func A_arbace_go_repl__init_A_Unit42__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(343, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_83; var tmp2 any = A_arbace_go_repl_compiled_context_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_go_repl_compiled_context_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_292, false); A_arbace_go_repl_compiled_context_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_84)); return A_arbace_go_repl__init_A_const_83 }




















func A_arbace_go_repl__init_A_Unit43__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(364, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_70; var tmp2 any = A_arbace_go_repl_ctx_of_A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_go_repl_ctx_of_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_293, false); A_arbace_go_repl_ctx_of_A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_85)); return A_arbace_go_repl__init_A_const_70 }






func A_arbace_go_repl__init_A_Unit44__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(371, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_86; var tmp2 any = A_arbace_go_repl_named_type_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_go_repl_named_type_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_294, false); A_arbace_go_repl_named_type_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_87)); return A_arbace_go_repl__init_A_const_86 }












func A_arbace_go_repl__init_A_Unit45__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(384, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_88; var tmp2 any = A_arbace_go_repl__init_A_const_89; var tmp3 any = A_arbace_go_repl_fn__794000239_A_New(); var tmp4 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_go_repl_fn__794000239_A_fn_class; if

	fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_295, false); A_arbace_go_repl_fn__794000239_A_fn_class = fncls__50d; tmp4 = fncls__50d } else { tmp4 = fncls__50 }; var tmp5 any = /*line :384:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 any = A_arbace_go_repl__init_A_const_90; var tmp7 any = A_arbace_go_repl_fn__794000241_A_New(); var tmp8 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_go_repl_fn__794000241_A_fn_class; if

	fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_296, false); A_arbace_go_repl_fn__794000241_A_fn_class = fncls__51d; tmp8 = fncls__51d } else { tmp8 = fncls__51 }; /*line :384:1*/tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp5, tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)))); var tmp9 *lang.Var = A_arbace_go_repl__init_A_const_88; tmp9.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_91)); return A_arbace_go_repl__init_A_const_88 }



func A_arbace_go_repl__init_A_Unit46__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(388, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_92; var tmp2 any = A_arbace_go_repl_const_arbace_A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_go_repl_const_arbace_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_297, false); A_arbace_go_repl_const_arbace_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_93)); return A_arbace_go_repl__init_A_const_92 }











func A_arbace_go_repl__init_A_Unit47__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(400, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_52; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_94)); return A_arbace_go_repl__init_A_const_52 }

func A_arbace_go_repl__init_A_Unit48__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(402, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_95; var tmp2 any = A_arbace_go_repl_linkname_cell_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_go_repl_linkname_cell_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_298, false); A_arbace_go_repl_linkname_cell_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_96)); return A_arbace_go_repl__init_A_const_95 }
















func A_arbace_go_repl__init_A_Unit49__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(419, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_97; var tmp2 any = A_arbace_go_repl_intern_go_A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_go_repl_intern_go_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_299, false); A_arbace_go_repl_intern_go_A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_98)); return A_arbace_go_repl__init_A_const_97 }








func A_arbace_go_repl__init_A_Unit50__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(428, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_99; var tmp2 any = A_arbace_go_repl_define_BANG__A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_go_repl_define_BANG__A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_300, false); A_arbace_go_repl_define_BANG__A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_99; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_100)); return A_arbace_go_repl__init_A_const_99 }























































































































































































func A_arbace_go_repl__init_A_Unit51__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(612, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_101; var tmp2 any = A_arbace_go_repl_call0_A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_go_repl_call0_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_301, false); A_arbace_go_repl_call0_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_102)); return A_arbace_go_repl__init_A_const_101 }





func A_arbace_go_repl__init_A_Unit52__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(618, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_103; var tmp2 any = A_arbace_go_repl_complete_BANG__A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_go_repl_complete_BANG__A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_302, false); A_arbace_go_repl_complete_BANG__A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_104)); return A_arbace_go_repl__init_A_const_103 }














func A_arbace_go_repl__init_A_Unit53__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(633, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_105; var tmp2 any = A_arbace_go_repl_after_load_A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_go_repl_after_load_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_303, false); A_arbace_go_repl_after_load_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_106)); return A_arbace_go_repl__init_A_const_105 }












func A_arbace_go_repl__init_A_Unit54__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(646, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_107; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_108)); v__1927001498__auto____1 = A_arbace_go_repl__init_A_const_107; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_go_repl__init_A_const_107; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_109)); var tmp3 *lang.Var = A_arbace_go_repl__init_A_const_107; var tmp4 *jrt.Boolean; var root_59 any = A_arbace_go_repl__init_A_const_110.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_61 lang.IFn
						if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = lang.RT_AFTER_LOAD.Ref(); var arg_63 any = A_arbace_go_repl__init_A_const_111.GetRawRoot__O(); var arg_64 any = A_arbace_go_repl__init_A_const_105; if linked_60 == nil { ifn_61.Invoke_O_O_O__O(arg_62, arg_63, arg_64) } else { linked_60.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_59, arg_62, arg_63, arg_64) }
//line :646:1
	tmp4 = jrt.Boolean_TRUE; tmp3.BindRoot_O__V(tmp4.Ref()); return A_arbace_go_repl__init_A_const_107 } }


func A_arbace_go_repl__init_A_Unit55__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(649, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_56; var tmp2 any = A_arbace_go_repl_load_digest_package_BANG__A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_go_repl_load_digest_package_BANG__A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_304, false); A_arbace_go_repl_load_digest_package_BANG__A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_112)); return A_arbace_go_repl__init_A_const_56 }






































func A_arbace_go_repl__init_A_Unit56__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(688, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_52; var tmp2 any = A_arbace_go_repl_load_import_A_New(); var tmp3 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_go_repl_load_import_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_305, false); A_arbace_go_repl_load_import_A_fn_class = fncls__66d; tmp3 = fncls__66d } else { tmp3 = fncls__66 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_113)); return A_arbace_go_repl__init_A_const_52 }















func A_arbace_go_repl__init_A_Unit57__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(704, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_114; var tmp2 any = A_arbace_go_repl_declare_BANG__A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_go_repl_declare_BANG__A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_306, false); A_arbace_go_repl_declare_BANG__A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_115)); return A_arbace_go_repl__init_A_const_114 }

















































func A_arbace_go_repl__init_A_Unit58__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(754, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_116; var tmp2 any; var root_68 any = A_arbace_go_repl__init_A_const_24.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_68, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = A_arbace_go_repl__init_A_const_117; if linked_69 == nil { tmp2 = ifn_70.Invoke_O__O(arg_71) } else { tmp2 = linked_69.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_68, arg_71) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_go_repl__init_A_const_116; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_118)); return A_arbace_go_repl__init_A_const_116 }

func A_arbace_go_repl__init_A_Unit59__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(756, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_119; var tmp2 any = A_arbace_go_repl_eval_BANG__A_New(); var tmp3 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_go_repl_eval_BANG__A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_307, false); A_arbace_go_repl_eval_BANG__A_fn_class = fncls__72d; tmp3 = fncls__72d } else { tmp3 = fncls__72 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_119; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_120)); return A_arbace_go_repl__init_A_const_119 }



















































func A_arbace_go_repl__init_A_Unit60__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(808, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_121; var tmp2 any = A_arbace_go_repl_run_main_BANG__A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_go_repl_run_main_BANG__A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_308, false); A_arbace_go_repl_run_main_BANG__A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_122)); return A_arbace_go_repl__init_A_const_121 }









func A_arbace_go_repl__init_A_Unit61__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(818, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_123; var tmp2 any = A_arbace_go_repl_check_BANG__A_New(); var tmp3 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_go_repl_check_BANG__A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_309, false); A_arbace_go_repl_check_BANG__A_fn_class = fncls__74d; tmp3 = fncls__74d } else { tmp3 = fncls__74 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_124)); return A_arbace_go_repl__init_A_const_123 }







func A_arbace_go_repl__init_A_Unit62__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(826, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_125; var tmp2 any = A_arbace_go_repl_resolve_types_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_go_repl_resolve_types_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_310, false); A_arbace_go_repl_resolve_types_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_126)); return A_arbace_go_repl__init_A_const_125 }
























func A_arbace_go_repl__init_A_Unit63__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(851, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_127; var tmp2 any = A_arbace_go_repl_inst_BANG__A_New(); var tmp3 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_go_repl_inst_BANG__A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_311, false); A_arbace_go_repl_inst_BANG__A_fn_class = fncls__76d; tmp3 = fncls__76d } else { tmp3 = fncls__76 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_128)); return A_arbace_go_repl__init_A_const_127 }
































func A_arbace_go_repl__init_A_Unit64__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(884, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_129; var tmp2 any = A_arbace_go_repl_listed_generic_BANG__A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_go_repl_listed_generic_BANG__A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_312, false); A_arbace_go_repl_listed_generic_BANG__A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_130)); return A_arbace_go_repl__init_A_const_129 }



















func A_arbace_go_repl__init_A_Unit65__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(904, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_131; var tmp2 any = A_arbace_go_repl_form_text_A_New(); var tmp3 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_go_repl_form_text_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_313, false); A_arbace_go_repl_form_text_A_fn_class = fncls__78d; tmp3 = fncls__78d } else { tmp3 = fncls__78 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_132)); return A_arbace_go_repl__init_A_const_131 }





func A_arbace_go_repl__init_A_Unit66__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(910, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_133; var tmp2 any = A_arbace_go_repl_write_package_BANG__A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_go_repl_write_package_BANG__A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_314, false); A_arbace_go_repl_write_package_BANG__A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_134)); return A_arbace_go_repl__init_A_const_133 }
























func A_arbace_go_repl__init_A_Unit67__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(935, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_135; var tmp2 any = A_arbace_go_repl_interpreted_closure_A_New(); var tmp3 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_go_repl_interpreted_closure_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_315, false); A_arbace_go_repl_interpreted_closure_A_fn_class = fncls__80d; tmp3 = fncls__80d } else { tmp3 = fncls__80 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_136)); return A_arbace_go_repl__init_A_const_135 }












func A_arbace_go_repl__init_A_Unit68__O() any { A_arbace_go_repl__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(948, 1); var tmp1 *lang.Var = A_arbace_go_repl__init_A_const_137; var tmp2 any = A_arbace_go_repl_run_compiled_BANG__A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_go_repl_run_compiled_BANG__A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_316, false); A_arbace_go_repl_run_compiled_BANG__A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_repl__init_A_const_137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_repl__init_A_const_138)); return A_arbace_go_repl__init_A_const_137 }



type A_arbace_go_repl__init_A struct{ jrt.Object }

var A_arbace_go_repl__init_A_const_pool *jrt.RefArray

var A_arbace_go_repl__init_A_const_0 *lang.Var

var A_arbace_go_repl__init_A_const_1 any

var A_arbace_go_repl__init_A_const_2 any

var A_arbace_go_repl__init_A_const_3 any

var A_arbace_go_repl__init_A_const_4 *lang.Var

var A_arbace_go_repl__init_A_const_5 any

var A_arbace_go_repl__init_A_const_6 *lang.Var

var A_arbace_go_repl__init_A_const_7 any

var A_arbace_go_repl__init_A_const_8 *lang.Var

var A_arbace_go_repl__init_A_const_9 any

var A_arbace_go_repl__init_A_const_10 *lang.Var

var A_arbace_go_repl__init_A_const_11 any

var A_arbace_go_repl__init_A_const_12 *lang.Var

var A_arbace_go_repl__init_A_const_13 any

var A_arbace_go_repl__init_A_const_14 *lang.Var

var A_arbace_go_repl__init_A_const_15 any

var A_arbace_go_repl__init_A_const_16 *lang.Var

var A_arbace_go_repl__init_A_const_17 any

var A_arbace_go_repl__init_A_const_18 *lang.Var

var A_arbace_go_repl__init_A_const_19 any

var A_arbace_go_repl__init_A_const_20 *lang.Var

var A_arbace_go_repl__init_A_const_21 any

var A_arbace_go_repl__init_A_const_22 *lang.Var

var A_arbace_go_repl__init_A_const_23 any

var A_arbace_go_repl__init_A_const_24 *lang.Var

var A_arbace_go_repl__init_A_const_25 any

var A_arbace_go_repl__init_A_const_26 *lang.Var

var A_arbace_go_repl__init_A_const_27 any

var A_arbace_go_repl__init_A_const_28 *lang.Var

var A_arbace_go_repl__init_A_const_29 any

var A_arbace_go_repl__init_A_const_30 *lang.Var

var A_arbace_go_repl__init_A_const_31 any

var A_arbace_go_repl__init_A_const_32 *lang.Var

var A_arbace_go_repl__init_A_const_33 any

var A_arbace_go_repl__init_A_const_34 *lang.Var

var A_arbace_go_repl__init_A_const_35 any

var A_arbace_go_repl__init_A_const_36 *lang.Var

var A_arbace_go_repl__init_A_const_37 any

var A_arbace_go_repl__init_A_const_38 *lang.Var

var A_arbace_go_repl__init_A_const_39 any

var A_arbace_go_repl__init_A_const_40 *lang.Var

var A_arbace_go_repl__init_A_const_41 any

var A_arbace_go_repl__init_A_const_42 *lang.Var

var A_arbace_go_repl__init_A_const_43 any

var A_arbace_go_repl__init_A_const_44 *lang.Var

var A_arbace_go_repl__init_A_const_45 any

var A_arbace_go_repl__init_A_const_46 *lang.Var

var A_arbace_go_repl__init_A_const_47 any

var A_arbace_go_repl__init_A_const_48 *lang.Var

var A_arbace_go_repl__init_A_const_49 any

var A_arbace_go_repl__init_A_const_50 *lang.Var

var A_arbace_go_repl__init_A_const_51 any

var A_arbace_go_repl__init_A_const_52 *lang.Var

var A_arbace_go_repl__init_A_const_53 any

var A_arbace_go_repl__init_A_const_54 *lang.Var

var A_arbace_go_repl__init_A_const_55 any

var A_arbace_go_repl__init_A_const_56 *lang.Var

var A_arbace_go_repl__init_A_const_57 any

var A_arbace_go_repl__init_A_const_58 *lang.Var

var A_arbace_go_repl__init_A_const_59 any

var A_arbace_go_repl__init_A_const_60 *lang.Var

var A_arbace_go_repl__init_A_const_61 any

var A_arbace_go_repl__init_A_const_62 *lang.Var

var A_arbace_go_repl__init_A_const_63 any

var A_arbace_go_repl__init_A_const_64 *lang.Var

var A_arbace_go_repl__init_A_const_65 any

var A_arbace_go_repl__init_A_const_66 *lang.Var

var A_arbace_go_repl__init_A_const_67 any

var A_arbace_go_repl__init_A_const_68 *lang.Var

var A_arbace_go_repl__init_A_const_69 any

var A_arbace_go_repl__init_A_const_70 *lang.Var

var A_arbace_go_repl__init_A_const_71 any

var A_arbace_go_repl__init_A_const_72 *lang.Var

var A_arbace_go_repl__init_A_const_73 any

var A_arbace_go_repl__init_A_const_74 *lang.Var

var A_arbace_go_repl__init_A_const_75 any

var A_arbace_go_repl__init_A_const_76 *lang.Var

var A_arbace_go_repl__init_A_const_77 any

var A_arbace_go_repl__init_A_const_78 *lang.Var

var A_arbace_go_repl__init_A_const_79 any

var A_arbace_go_repl__init_A_const_80 *lang.Var

var A_arbace_go_repl__init_A_const_81 any

var A_arbace_go_repl__init_A_const_82 any

var A_arbace_go_repl__init_A_const_83 *lang.Var

var A_arbace_go_repl__init_A_const_84 any

var A_arbace_go_repl__init_A_const_85 any

var A_arbace_go_repl__init_A_const_86 *lang.Var

var A_arbace_go_repl__init_A_const_87 any

var A_arbace_go_repl__init_A_const_88 *lang.Var

var A_arbace_go_repl__init_A_const_89 *lang.Keyword

var A_arbace_go_repl__init_A_const_90 *lang.Keyword

var A_arbace_go_repl__init_A_const_91 any

var A_arbace_go_repl__init_A_const_92 *lang.Var

var A_arbace_go_repl__init_A_const_93 any

var A_arbace_go_repl__init_A_const_94 any

var A_arbace_go_repl__init_A_const_95 *lang.Var

var A_arbace_go_repl__init_A_const_96 any

var A_arbace_go_repl__init_A_const_97 *lang.Var

var A_arbace_go_repl__init_A_const_98 any

var A_arbace_go_repl__init_A_const_99 *lang.Var

var A_arbace_go_repl__init_A_const_100 any

var A_arbace_go_repl__init_A_const_101 *lang.Var

var A_arbace_go_repl__init_A_const_102 any

var A_arbace_go_repl__init_A_const_103 *lang.Var

var A_arbace_go_repl__init_A_const_104 any

var A_arbace_go_repl__init_A_const_105 *lang.Var

var A_arbace_go_repl__init_A_const_106 any

var A_arbace_go_repl__init_A_const_107 *lang.Var

var A_arbace_go_repl__init_A_const_108 any

var A_arbace_go_repl__init_A_const_109 any

var A_arbace_go_repl__init_A_const_110 *lang.Var

var A_arbace_go_repl__init_A_const_111 *lang.Var

var A_arbace_go_repl__init_A_const_112 any

var A_arbace_go_repl__init_A_const_113 any

var A_arbace_go_repl__init_A_const_114 *lang.Var

var A_arbace_go_repl__init_A_const_115 any

var A_arbace_go_repl__init_A_const_116 *lang.Var

var A_arbace_go_repl__init_A_const_117 any

var A_arbace_go_repl__init_A_const_118 any

var A_arbace_go_repl__init_A_const_119 *lang.Var

var A_arbace_go_repl__init_A_const_120 any

var A_arbace_go_repl__init_A_const_121 *lang.Var

var A_arbace_go_repl__init_A_const_122 any

var A_arbace_go_repl__init_A_const_123 *lang.Var

var A_arbace_go_repl__init_A_const_124 any

var A_arbace_go_repl__init_A_const_125 *lang.Var

var A_arbace_go_repl__init_A_const_126 any

var A_arbace_go_repl__init_A_const_127 *lang.Var

var A_arbace_go_repl__init_A_const_128 any

var A_arbace_go_repl__init_A_const_129 *lang.Var

var A_arbace_go_repl__init_A_const_130 any

var A_arbace_go_repl__init_A_const_131 *lang.Var

var A_arbace_go_repl__init_A_const_132 any

var A_arbace_go_repl__init_A_const_133 *lang.Var

var A_arbace_go_repl__init_A_const_134 any

var A_arbace_go_repl__init_A_const_135 *lang.Var

var A_arbace_go_repl__init_A_const_136 any

var A_arbace_go_repl__init_A_const_137 *lang.Var

var A_arbace_go_repl__init_A_const_138 any

var A_arbace_go_repl__init_A_init jrt.ClassInit

func A_arbace_go_repl__init_A_Init() { if !A_arbace_go_repl__init_A_init.Done() { A_arbace_go_repl__init_A_init.Run(A_arbace_go_repl__init_A_clinit) } }

func A_arbace_go_repl__init_A_clinit() { A_arbace_go_repl__init_A_clinit_p0(); A_arbace_go_repl__init_A_clinit_p1(); A_arbace_go_repl__init_A_clinit_p2(); A_arbace_go_repl__init_A_clinit_p3(); A_arbace_go_repl__init_A_clinit_p4(); A_arbace_go_repl__init_A_clinit_p5(); A_arbace_go_repl__init_A_clinit_p6(); A_arbace_go_repl__init_A_clinit_p7(); A_arbace_go_repl__init_A_clinit_p8(); A_arbace_go_repl__init_A_clinit_p9(); A_arbace_go_repl__init_A_clinit_p10() }

func A_arbace_go_repl__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_repl__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_257, 188); A_arbace_go_repl__init_A_const_0 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[49]); A_arbace_go_repl__init_A_const_1 = A_arbace_go_repl__init_A_const_pool.A[50]; A_arbace_go_repl__init_A_const_2 = A_arbace_go_repl__init_A_const_pool.A[51]; A_arbace_go_repl__init_A_const_3 = A_arbace_go_repl__init_A_const_pool.A[52]; A_arbace_go_repl__init_A_const_4 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[53]); A_arbace_go_repl__init_A_const_5 = A_arbace_go_repl__init_A_const_pool.A[54]; A_arbace_go_repl__init_A_const_6 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[55]); A_arbace_go_repl__init_A_const_7 = A_arbace_go_repl__init_A_const_pool.A[56]; A_arbace_go_repl__init_A_const_8 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[57]); A_arbace_go_repl__init_A_const_9 = A_arbace_go_repl__init_A_const_pool.A[58]; A_arbace_go_repl__init_A_const_10 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[59]); A_arbace_go_repl__init_A_const_11 = A_arbace_go_repl__init_A_const_pool.A[60]; A_arbace_go_repl__init_A_const_12 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[61]) }

func A_arbace_go_repl__init_A_clinit_p1() { A_arbace_go_repl__init_A_const_13 = A_arbace_go_repl__init_A_const_pool.A[62]; A_arbace_go_repl__init_A_const_14 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[63]); A_arbace_go_repl__init_A_const_15 = A_arbace_go_repl__init_A_const_pool.A[64]; A_arbace_go_repl__init_A_const_16 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[65]); A_arbace_go_repl__init_A_const_17 = A_arbace_go_repl__init_A_const_pool.A[66]; A_arbace_go_repl__init_A_const_18 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[67]); A_arbace_go_repl__init_A_const_19 = A_arbace_go_repl__init_A_const_pool.A[68]; A_arbace_go_repl__init_A_const_20 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[69]); A_arbace_go_repl__init_A_const_21 = A_arbace_go_repl__init_A_const_pool.A[70]; A_arbace_go_repl__init_A_const_22 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[71]); A_arbace_go_repl__init_A_const_23 = A_arbace_go_repl__init_A_const_pool.A[72]; A_arbace_go_repl__init_A_const_24 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[73]); A_arbace_go_repl__init_A_const_25 = A_arbace_go_repl__init_A_const_pool.A[74] }

func A_arbace_go_repl__init_A_clinit_p2() { A_arbace_go_repl__init_A_const_26 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[75]); A_arbace_go_repl__init_A_const_27 = A_arbace_go_repl__init_A_const_pool.A[76]; A_arbace_go_repl__init_A_const_28 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[77]); A_arbace_go_repl__init_A_const_29 = A_arbace_go_repl__init_A_const_pool.A[78]; A_arbace_go_repl__init_A_const_30 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[79]); A_arbace_go_repl__init_A_const_31 = A_arbace_go_repl__init_A_const_pool.A[80]; A_arbace_go_repl__init_A_const_32 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[81]); A_arbace_go_repl__init_A_const_33 = A_arbace_go_repl__init_A_const_pool.A[82]; A_arbace_go_repl__init_A_const_34 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[83]); A_arbace_go_repl__init_A_const_35 = A_arbace_go_repl__init_A_const_pool.A[84]; A_arbace_go_repl__init_A_const_36 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[85]); A_arbace_go_repl__init_A_const_37 = A_arbace_go_repl__init_A_const_pool.A[86]; A_arbace_go_repl__init_A_const_38 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[87]) }

func A_arbace_go_repl__init_A_clinit_p3() { A_arbace_go_repl__init_A_const_39 = A_arbace_go_repl__init_A_const_pool.A[88]; A_arbace_go_repl__init_A_const_40 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[89]); A_arbace_go_repl__init_A_const_41 = A_arbace_go_repl__init_A_const_pool.A[90]; A_arbace_go_repl__init_A_const_42 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[91]); A_arbace_go_repl__init_A_const_43 = A_arbace_go_repl__init_A_const_pool.A[92]; A_arbace_go_repl__init_A_const_44 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[93]); A_arbace_go_repl__init_A_const_45 = A_arbace_go_repl__init_A_const_pool.A[94]; A_arbace_go_repl__init_A_const_46 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[95]); A_arbace_go_repl__init_A_const_47 = A_arbace_go_repl__init_A_const_pool.A[96]; A_arbace_go_repl__init_A_const_48 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[97]); A_arbace_go_repl__init_A_const_49 = A_arbace_go_repl__init_A_const_pool.A[98]; A_arbace_go_repl__init_A_const_50 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[99]); A_arbace_go_repl__init_A_const_51 = A_arbace_go_repl__init_A_const_pool.A[100] }

func A_arbace_go_repl__init_A_clinit_p4() { A_arbace_go_repl__init_A_const_52 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[101]); A_arbace_go_repl__init_A_const_53 = A_arbace_go_repl__init_A_const_pool.A[102]; A_arbace_go_repl__init_A_const_54 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[103]); A_arbace_go_repl__init_A_const_55 = A_arbace_go_repl__init_A_const_pool.A[104]; A_arbace_go_repl__init_A_const_56 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[105]); A_arbace_go_repl__init_A_const_57 = A_arbace_go_repl__init_A_const_pool.A[106]; A_arbace_go_repl__init_A_const_58 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[107]); A_arbace_go_repl__init_A_const_59 = A_arbace_go_repl__init_A_const_pool.A[108]; A_arbace_go_repl__init_A_const_60 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[109]); A_arbace_go_repl__init_A_const_61 = A_arbace_go_repl__init_A_const_pool.A[110]; A_arbace_go_repl__init_A_const_62 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[111]); A_arbace_go_repl__init_A_const_63 = A_arbace_go_repl__init_A_const_pool.A[112]; A_arbace_go_repl__init_A_const_64 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[113]) }

func A_arbace_go_repl__init_A_clinit_p5() { A_arbace_go_repl__init_A_const_65 = A_arbace_go_repl__init_A_const_pool.A[114]; A_arbace_go_repl__init_A_const_66 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[115]); A_arbace_go_repl__init_A_const_67 = A_arbace_go_repl__init_A_const_pool.A[116]; A_arbace_go_repl__init_A_const_68 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[117]); A_arbace_go_repl__init_A_const_69 = A_arbace_go_repl__init_A_const_pool.A[118]; A_arbace_go_repl__init_A_const_70 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[119]); A_arbace_go_repl__init_A_const_71 = A_arbace_go_repl__init_A_const_pool.A[120]; A_arbace_go_repl__init_A_const_72 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[121]); A_arbace_go_repl__init_A_const_73 = A_arbace_go_repl__init_A_const_pool.A[122]; A_arbace_go_repl__init_A_const_74 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[123]); A_arbace_go_repl__init_A_const_75 = A_arbace_go_repl__init_A_const_pool.A[124]; A_arbace_go_repl__init_A_const_76 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[125]); A_arbace_go_repl__init_A_const_77 = A_arbace_go_repl__init_A_const_pool.A[126] }

func A_arbace_go_repl__init_A_clinit_p6() { A_arbace_go_repl__init_A_const_78 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[127]); A_arbace_go_repl__init_A_const_79 = A_arbace_go_repl__init_A_const_pool.A[128]; A_arbace_go_repl__init_A_const_80 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[129]); A_arbace_go_repl__init_A_const_81 = A_arbace_go_repl__init_A_const_pool.A[130]; A_arbace_go_repl__init_A_const_82 = A_arbace_go_repl__init_A_const_pool.A[131]; A_arbace_go_repl__init_A_const_83 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[132]); A_arbace_go_repl__init_A_const_84 = A_arbace_go_repl__init_A_const_pool.A[133]; A_arbace_go_repl__init_A_const_85 = A_arbace_go_repl__init_A_const_pool.A[134]; A_arbace_go_repl__init_A_const_86 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[135]); A_arbace_go_repl__init_A_const_87 = A_arbace_go_repl__init_A_const_pool.A[136]; A_arbace_go_repl__init_A_const_88 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[137]); A_arbace_go_repl__init_A_const_89 = lang.Keyword_Cast(A_arbace_go_repl__init_A_const_pool.A[138]); A_arbace_go_repl__init_A_const_90 = lang.Keyword_Cast(A_arbace_go_repl__init_A_const_pool.A[139]) }

func A_arbace_go_repl__init_A_clinit_p7() { A_arbace_go_repl__init_A_const_91 = A_arbace_go_repl__init_A_const_pool.A[140]; A_arbace_go_repl__init_A_const_92 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[141]); A_arbace_go_repl__init_A_const_93 = A_arbace_go_repl__init_A_const_pool.A[142]; A_arbace_go_repl__init_A_const_94 = A_arbace_go_repl__init_A_const_pool.A[143]; A_arbace_go_repl__init_A_const_95 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[144]); A_arbace_go_repl__init_A_const_96 = A_arbace_go_repl__init_A_const_pool.A[145]; A_arbace_go_repl__init_A_const_97 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[146]); A_arbace_go_repl__init_A_const_98 = A_arbace_go_repl__init_A_const_pool.A[147]; A_arbace_go_repl__init_A_const_99 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[148]); A_arbace_go_repl__init_A_const_100 = A_arbace_go_repl__init_A_const_pool.A[149]; A_arbace_go_repl__init_A_const_101 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[150]); A_arbace_go_repl__init_A_const_102 = A_arbace_go_repl__init_A_const_pool.A[151]; A_arbace_go_repl__init_A_const_103 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[152]); A_arbace_go_repl__init_A_const_104 = A_arbace_go_repl__init_A_const_pool.A[153] }

func A_arbace_go_repl__init_A_clinit_p8() { A_arbace_go_repl__init_A_const_105 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[154]); A_arbace_go_repl__init_A_const_106 = A_arbace_go_repl__init_A_const_pool.A[155]; A_arbace_go_repl__init_A_const_107 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[156]); A_arbace_go_repl__init_A_const_108 = A_arbace_go_repl__init_A_const_pool.A[157]; A_arbace_go_repl__init_A_const_109 = A_arbace_go_repl__init_A_const_pool.A[158]; A_arbace_go_repl__init_A_const_110 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[159]); A_arbace_go_repl__init_A_const_111 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[160]); A_arbace_go_repl__init_A_const_112 = A_arbace_go_repl__init_A_const_pool.A[161]; A_arbace_go_repl__init_A_const_113 = A_arbace_go_repl__init_A_const_pool.A[162]; A_arbace_go_repl__init_A_const_114 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[163]); A_arbace_go_repl__init_A_const_115 = A_arbace_go_repl__init_A_const_pool.A[164]; A_arbace_go_repl__init_A_const_116 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[165]); A_arbace_go_repl__init_A_const_117 = A_arbace_go_repl__init_A_const_pool.A[166]; A_arbace_go_repl__init_A_const_118 = A_arbace_go_repl__init_A_const_pool.A[167] }

func A_arbace_go_repl__init_A_clinit_p9() { A_arbace_go_repl__init_A_const_119 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[168]); A_arbace_go_repl__init_A_const_120 = A_arbace_go_repl__init_A_const_pool.A[169]; A_arbace_go_repl__init_A_const_121 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[170]); A_arbace_go_repl__init_A_const_122 = A_arbace_go_repl__init_A_const_pool.A[171]; A_arbace_go_repl__init_A_const_123 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[172]); A_arbace_go_repl__init_A_const_124 = A_arbace_go_repl__init_A_const_pool.A[173]; A_arbace_go_repl__init_A_const_125 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[174]); A_arbace_go_repl__init_A_const_126 = A_arbace_go_repl__init_A_const_pool.A[175]; A_arbace_go_repl__init_A_const_127 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[176]); A_arbace_go_repl__init_A_const_128 = A_arbace_go_repl__init_A_const_pool.A[177]; A_arbace_go_repl__init_A_const_129 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[178]); A_arbace_go_repl__init_A_const_130 = A_arbace_go_repl__init_A_const_pool.A[179]; A_arbace_go_repl__init_A_const_131 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[180]) }

func A_arbace_go_repl__init_A_clinit_p10() { A_arbace_go_repl__init_A_const_132 = A_arbace_go_repl__init_A_const_pool.A[181]; A_arbace_go_repl__init_A_const_133 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[182]); A_arbace_go_repl__init_A_const_134 = A_arbace_go_repl__init_A_const_pool.A[183]; A_arbace_go_repl__init_A_const_135 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[184]); A_arbace_go_repl__init_A_const_136 = A_arbace_go_repl__init_A_const_pool.A[185]; A_arbace_go_repl__init_A_const_137 = lang.Var_Cast(A_arbace_go_repl__init_A_const_pool.A[186]); A_arbace_go_repl__init_A_const_138 = A_arbace_go_repl__init_A_const_pool.A[187] }

func A_arbace_go_repl__init_A_New() *A_arbace_go_repl__init_A { A_arbace_go_repl__init_A_Init(); t := &A_arbace_go_repl__init_A{}; t.Ctor(); return t }

func (t *A_arbace_go_repl__init_A) Ctor() {}

func (t *A_arbace_go_repl__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_repl__init_A) GetClass__Class() *jrt.Class { return A_arbace_go_repl__init_A_class }

func (t *A_arbace_go_repl__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_repl__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_repl__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_repl__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_repl__init_A); return ok }

func A_arbace_go_repl__init_A_Cast(x any) *A_arbace_go_repl__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_repl__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_repl__init_A_class)) }; return v }
