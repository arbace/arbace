//line j2g_strings.ae:1
package aot_arbace_go_repl

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn15,arbace.go.checkyn2,ckyn19,arbace.go.check.envyn1,eyn21,arbace.go.check.typesyn1,tyn21,arbace.go.check.constyn1,cyn20,arbace.go.check.codeyn4,codeyn20,arbace.go.check.loadyn4,loadyn15,arbace.go.buildyn1,byn17,arbace.go.genericyn3,genyn15,arbace.go.embedyn5,embedyn20,arbace.repr.go.printyn2,rpkn3,dockn5,indexkn4,textkn5,startys2,go7,packagekn6,configkn4,gooskn6,goarchkn4,langkn4,elsekn10,keep-treeskn4,pathkn4,namekn2,nskn5,fileskn7,currentkn5,funcskn7,globalskn5,typeskn7,definedkn4,optskn12,package-pathkn9,load-filekn7,loadingkn7,importskn5,declskn11,type-paramskn3,tagyn1,*kn4,filekn4,linekn3,msgkn8,delegatekn5,localkn6,refusekn6,resultkn6,errorskn2,pfkn3,pkgkn2,fskn6,stringkn5,slicekn5,uint8kn5,byteskn3,objks2,go6,errorskn11,embed-fileskn3,varkn4,kindkn4,formks2,go5,embedkn15,embed-imported?kn5,nameskn3,lhskn5,init?kn8,var-initkn2,opkn4,treekn6,typed?kn5,minorkn4,typeks15,arbace.go.embed5,errorkn1,kkn1,Rkn4,nodekn1,Skn3,rhsks15,arbace.go.build4,nodekn4,chankn6,structkn5,arraykn4,funckn5,namedkn6,tparamkn9,interfacekn5,tuplekn10,recv-namedkn8,ptr-recvkn13,scope-entrieskn6,ctx-ofkn6,sourcekn9,compiled?kn11,table-type?kn9,pkg-scopekn12,methods-donekn9,lit-countkn3,genks3,goi3,genkn9,func-cellkn4,cellkn11,method-cellkn7,methodskn6,globalkn3,ctxkn7,checkedkn10,decl-infoskn5,scopekn7,float32kn7,float64kn13,untyped-floatks2,go8,linknamekn5,vars?kn5,eagerkn4,onlykn10,kept-nameskn10,init-nameskn11,unsupportedkn7,tparamskn8,rtparamskn6,methodkn4,speckn3,keykn4,keptkn5,aliaskn5,initskn3,ptrkn5,orderkn10,init-funcskn4,mainkn8,new-varsks3,goi11,unsupportedkn13,tparams-countkn5,constks2,go4,kindks2,go7,packagekn7,privateks2,go7,generickn3,valys2,go4,fileyn5,in-nskn12,UnusedImportkn4,codekn2,idkn4,declyn7,go.userys2,go4,funcyn3,anykn7,resultskn13,TooManyValuesys2,go4,typeyn6,structkn5,instskn8,arglistsyn2,nskn7,requireyn9,arbace.goyn2,gokn6,columnyn5,quoteys15,arbace.build.go5,buildys17,arbace.java.shell2,shkn3,outkn3,errkn4,exitkn6,gorootkn4,workks2,go6,statusv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,V3,R12,R2,R13,V3,R14,R2,R15,V3,R16,R2,R17,V3,R18,R2,R19,V3,R20,R2,R21,V3,R22,R2,R23,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn14,arbace.go.replm2,R24,s778,goi's REPL state (doc/go/GOI-SPEC.md §2): interpreted Go packages as namespaces, their files\n  and declarations, checking (arbace.go.check) against the table's digest and the other\n  interpreted packages, defining their vars (functions, variables, constants, types and their\n  generations), loading packages from ARBACE_PATH (the declarations queued, the package checked\n  when its package file's load ends: S6), initialization, go/eval, and running a program in\n  program mode (bin/goi run: arbace.go.run).\n\n  A package's state is an atom {:path :name :ns :config :files [{:name :imports :decls}]\n  :current (the REPL's file) :loading (the package file being loaded) :funcs {name *Func}\n  :globals {name {:ptr :key}} :types {name {:gen :key :desc}} :checked (the last result)}.v11,arbace.core3,setv11,arbace.core9,contains?v14,arbace.go.repl6,listedR25,v11,arbace.core11,read-stringv11,arbace.core4,subsl0,R26,R27,v14,arbace.go.repl12,digest-indexv11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core3,seqv11,arbace.core5,firstv15,arbace.go.check17,read-string-formsv14,arbace.go.repl12,digest-formsv11,arbace.core6,filterv11,arbace.core4,seq?R28,R29,v11,arbace.core5,applyv11,arbace.core8,hash-mapv11,arbace.core5,nnextv11,arbace.core5,mergem6,R30,s5,linuxR31,s5,amd64R32,s6,go1.27v11,arbace.core3,notv14,arbace.go.repl7,listed?v11,arbace.core4,not=v14,arbace.go.repl12,out-of-scopev14,arbace.go.repl14,interpretable?v11,arbace.core4,someS2,s6,vendors8,internalv13,arbace.string5,splitp1,/R33,v11,arbace.core5,assocv15,arbace.go.check7,sessionv15,arbace.go.check12,forms-sourcev14,arbace.go.repl6,configR34,v11,arbace.core6,symbolv20,arbace.go.check.load8,path->nsv13,arbace.string4,joinv11,arbace.core4,restv11,arbace.core3,strp2,\\.v11,arbace.core4,atomR35,R36,R37,R38,R39,R40,R41,R42,R43,v14,arbace.go.repl8,ns->pathv14,arbace.go.repl8,packagesv14,arbace.go.repl9,new-statev11,arbace.core4,lastp1,/v13,arbace.string12,starts-with?v11,arbace.core7,ex-infov11,arbace.core5,swap!v14,arbace.go.repl13,package-statev20,arbace.repr.go.print9,name-textR44,R45,R32,v11,arbace.core7,string?v11,arbace.core6,*file*S2,s14,NO_SOURCE_PATHs14,NO_SOURCE_FILER46,R47,v11,arbace.core6,updatev11,arbace.core4,mapvR48,R49,v14,arbace.go.repl11,update-filev11,arbace.core6,dissocR24,v11,arbace.core3,vecv11,arbace.core8,distinctv11,arbace.core4,intov20,arbace.go.check.code9,head-namev11,arbace.core6,every?v11,arbace.core7,vector?v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core6,concatv11,arbace.core3,mapv11,arbace.core6,secondv11,arbace.core4,dropl2,R50,v11,arbace.core7,symbol?R51,R52,R53,R54,R55,v11,arbace.core4,takel10,v14,arbace.go.repl10,error-textv14,arbace.go.repl11,load-importv14,arbace.go.repl9,source-ofR56,v14,arbace.go.repl14,digest-sessionR57,R58,v14,arbace.go.repl7,refusalv11,arbace.core6,get-inV2,R44,R48,v14,arbace.go.repl20,load-digest-package!V2,R44,R48,v14,arbace.go.repl11,session-forv15,arbace.go.check13,check-packagev15,arbace.go.check8,resolverv19,arbace.go.check.env1,oR59,v11,arbace.core6,empty?R60,v14,arbace.go.repl22,define-digest-imports!v14,arbace.go.repl12,check-sourceR61,v11,arbace.core6,removep1,:v21,arbace.go.check.types5,underv21,arbace.go.check.types6,named?R62,v21,arbace.go.check.types4,infoR63,R64,R65,R66,R67,R68,l1,R69,V2,R44,R70,R71,R72,R73,R74,v15,arbace.go.embed10,check-declR75,S1,s5,embedR76,R77,R78,R79,R80,R81,R82,R83,v15,arbace.go.embed18,directive-patternsR84,v14,arbace.go.repl10,embed-kindv14,arbace.go.repl12,package-filev13,arbace.string7,replacep5,\\.ae$v15,arbace.go.embed5,filesv21,arbace.go.check.types8,type-strR85,v11,arbace.core7,ex-datav11,arbace.core10,ex-messageR86,R87,R88,v15,arbace.go.build2,opv15,arbace.go.build4,descR89,R90,R91,S1,s5,embedv11,arbace.core8,keyword?v21,arbace.go.check.types8,canon-kwv21,arbace.go.check.types7,tparam?R92,R93,R94,R95,v14,arbace.go.repl8,type-keyR96,R97,R98,R99,V1,R99,R100,R101,v14,arbace.go.repl11,repl-sourcev14,arbace.go.repl11,table-typesv11,arbace.core9,partitionl3,v15,arbace.go.check14,ensure-packageR102,R103,v14,arbace.go.repl6,ctx-ofR104,v14,arbace.go.repl12,display-fileR105,R106,v14,arbace.go.repl11,table-type?R107,v14,arbace.go.repl12,digest-scopeR108,R109,R110,R111,v14,arbace.go.repl13,state-of-pathR112,R113,R114,v14,arbace.go.repl11,method-nameR115,R116,v14,arbace.go.repl17,compiled-contextsp1,/v14,arbace.go.repl8,path->nsR117,v14,arbace.go.repl13,build-contextv14,arbace.go.repl16,compiled-contextR118,R119,v19,arbace.go.check.env9,scope-getR120,v14,arbace.go.repl10,named-typev11,arbace.core8,boolean?v21,arbace.go.check.const10,value-textv21,arbace.go.check.const8,complex?v21,arbace.go.check.const9,to-doubleS3,R121,R122,R123,R121,v11,arbace.core8,integer?R124,v13,arbace.string4,trimp3,\\s+v11,arbace.core6,internv11,arbace.core6,ns-mapv11,arbace.core4,var?v11,arbace.core8,ns-unmapR125,R126,R127,R128,R129,R130,R131,R132,R133,v14,arbace.go.repl13,linkname-cellR134,R135,R136,R137,R138,v11,arbace.core9,volatile!R139,v14,arbace.go.repl11,embed-treesv11,arbace.core4,keepR140,R141,R142,V2,s4,mainR113,R143,v11,arbace.core19,pop-thread-bindingsR144,v11,arbace.core20,push-thread-bindingsv15,arbace.go.build5,*ctx*v21,arbace.go.check.types12,*method-obj*v15,arbace.go.build11,method-datav21,arbace.go.check.types14,*subst-method*v20,arbace.go.check.decl12,subst-methodv21,arbace.go.check.types15,*resolve-named*v15,arbace.go.build18,complete-instance!v11,arbace.core8,group-byv11,arbace.core4,sortv11,arbace.core6,pr-strv21,arbace.go.check.types12,update-info!v15,arbace.go.build8,with-ctxv15,arbace.go.build10,build-funcv15,arbace.go.build6,lazilyv15,arbace.go.build11,build-initsv11,arbace.core9,create-nsR145,v15,arbace.go.build15,method-callableR146,v21,arbace.go.check.types6,valid?v14,arbace.go.repl9,intern-gov11,arbace.core9,with-metaR147,R148,R149,v21,arbace.go.check.types9,exported?R150,v17,arbace.go.generic10,generic-fnv14,arbace.go.repl11,generic-envv14,arbace.go.repl12,const-arbaceR151,v14,arbace.go.repl7,define!m2,R125,Tv14,arbace.go.repl5,call0v14,arbace.go.repl9,complete!R28,R152,S2,R28,R153,m2,R125,Tv11,arbace.core7,ns-namev11,arbace.core4,*ns*v14,arbace.go.repl10,decl-namesR154,R155,v11,arbace.core4,juxtR156,R157,v11,arbace.core6,mapcatv11,arbace.core8,find-varv11,arbace.core7,printlnv11,arbace.core5,*out*v11,arbace.core5,*err*R158,v14,arbace.go.repl10,eval-countv11,arbace.core3,incS2,s3,lets8,let-typev20,arbace.go.check.code15,statement-headsv11,arbace.core4,listR159,m2,R51,R160,R161,v11,arbace.core6,repeatR160,R162,v13,arbace.string9,includes?v11,arbace.core7,re-findp25,value of type \\(([^)]*)\\)p1,,V3,R40,s4,mainR113,R158,R163,R164,v11,arbace.core11,map-indexedv11,arbace.core6,the-nsv11,arbace.core10,ns-resolveR165,v17,arbace.go.generic11,instantiatev14,arbace.go.repl13,resolve-typesv11,arbace.core9,namespacev11,arbace.core10,ns-aliasesv11,arbace.core4,namev17,arbace.go.generic13,type-instancep2,\\.R166,v11,arbace.core12,*print-meta*v11,arbace.core14,*print-length*v11,arbace.core13,*print-level*v11,arbace.core22,*print-namespace-maps*p1,/p5,\\.go$v11,arbace.core6,vectorv11,arbace.core4,spitv14,arbace.go.repl9,form-textR167,ML2,R168,V3,R169,R2,R170,m4,R54,i996,R171,i48,R28,v11,arbace.core8,identityR15,R153,R172,R152,v11,arbace.core10,make-arrayC37,java.nio.file.attribute.FileAttributev11,arbace.core17,requiring-resolveR173,R174,R175,R176,R177,v11,arbace.core7,reversev11,arbace.core8,file-seqv14,arbace.go.repl19,interpreted-closurev14,arbace.go.repl14,write-package!R31,R178,R179,R180,")

var Lit_1 *jrt.String = jrt.Intern("/")

var Lit_2 *jrt.String = jrt.Intern("go/")

var Lit_3 *jrt.String = jrt.Intern(".")

var Lit_4 *jrt.String = jrt.Intern("_")

var Lit_5 *jrt.String = jrt.Intern("-")

var Lit_6 *jrt.String = jrt.Intern("arbace.go.repl$build_context$fn__794000337")

var Lit_7 *jrt.String = jrt.Intern("arbace.go.repl$build_context$fn__794000339")

var Lit_8 *jrt.String = jrt.Intern("arbace.go.repl$build_context$fn__794000341")

var Lit_9 *jrt.String = jrt.Intern("arbace.go.repl$build_context$fn__794000343")

var Lit_10 *jrt.String = jrt.Intern("arbace.go.repl$build_context$fn__794000345")

var Lit_11 *jrt.String = jrt.Intern("goi: no function ")

var Lit_12 *jrt.String = jrt.Intern("goi: no method ")

var Lit_13 *jrt.String = jrt.Intern("goi: no variable ")

var Lit_14 *jrt.String = jrt.Intern("InterpCallable")

var Lit_15 *jrt.String = jrt.Intern("TFunc")

var Lit_16 *jrt.String = jrt.Intern("arbace.go.repl$compiled_context$fn__794000350")

var Lit_17 *jrt.String = jrt.Intern("arbace.go.repl$compiled_context$fn__794000352")

var Lit_18 *jrt.String = jrt.Intern("arbace.go.repl$compiled_context$fn__794000354")

var Lit_19 *jrt.String = jrt.Intern("arbace.go.repl$compiled_context$fn__794000356")

var Lit_20 *jrt.String = jrt.Intern("arbace.go.repl$compiled_context$fn__794000358")

var Lit_21 *jrt.String = jrt.Intern("")

var Lit_22 *jrt.String = jrt.Intern("Go check errors in package ")

var Lit_23 *jrt.String = jrt.Intern(":\n")

var Lit_24 *jrt.String = jrt.Intern("init")

var Lit_25 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$targets__794000068")

var Lit_26 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$group_QMARK___794000070")

var Lit_27 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$specs__794000072")

var Lit_28 *jrt.String = jrt.Intern("go/type")

var Lit_29 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$iter__794000075__794000079")

var Lit_30 *jrt.String = jrt.Intern("go/func")

var Lit_31 *jrt.String = jrt.Intern("go/const")

var Lit_32 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$iter__794000091__794000097")

var Lit_33 *jrt.String = jrt.Intern("go/var")

var Lit_34 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$iter__794000110__794000116")

var Lit_35 *jrt.String = jrt.Intern("go/method")

var Lit_36 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$iter__794000075__794000079$fn__794000080")

var Lit_37 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$iter__794000075__794000079$fn__794000080$fn__794000081")

var Lit_38 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$iter__794000091__794000097$fn__794000098")

var Lit_39 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$iter__794000091__794000097$fn__794000098$iter__794000093__794000102")

var Lit_40 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$iter__794000091__794000097$fn__794000098$iter__794000093__794000102$fn__794000103")

var Lit_41 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$iter__794000091__794000097$fn__794000098$iter__794000093__794000102$fn__794000103$fn__794000104")

var Lit_42 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$iter__794000110__794000116$fn__794000117")

var Lit_43 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$iter__794000110__794000116$fn__794000117$iter__794000112__794000121")

var Lit_44 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$iter__794000110__794000116$fn__794000117$iter__794000112__794000121$fn__794000122")

var Lit_45 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$iter__794000110__794000116$fn__794000117$iter__794000112__794000121$fn__794000122$fn__794000123")

var Lit_46 *jrt.String = jrt.Intern("values")

var Lit_47 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$fn__794000770")

var Lit_48 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$iter__794000772__794000776")

var Lit_49 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$fn__794000790")

var Lit_50 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$fn__794000792")

var Lit_51 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$fn__794000794")

var Lit_52 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$fn__794000796")

var Lit_53 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$own_QMARK___794000798")

var Lit_54 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$fn__794000800")

var Lit_55 *jrt.String = jrt.Intern("Go check errors:\n")

var Lit_56 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$fn__794000802")

var Lit_57 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$fn__794000806")

var Lit_58 *jrt.String = jrt.Intern("goi: warning: ")

var Lit_59 *jrt.String = jrt.Intern(" no longer check and keep their definitions:\n")

var Lit_60 *jrt.String = jrt.Intern(", ")

var Lit_61 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$iter__794000772__794000776$fn__794000777")

var Lit_62 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$iter__794000772__794000776$fn__794000777$fn__794000778")

var Lit_63 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$iter__794000772__794000776$fn__794000777$fn__794000784")

var Lit_64 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$iter__794000772__794000776$fn__794000777$fn__794000778$fn__794000779")

var Lit_65 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$iter__794000772__794000776$fn__794000777$fn__794000778$fn__794000779$fn__794000780")

var Lit_66 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$iter__794000772__794000776$fn__794000777$fn__794000784$fn__794000785")

var Lit_67 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$gen_of__794000385")

var Lit_68 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000387")

var Lit_69 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$generic_QMARK___794000389")

var Lit_70 *jrt.String = jrt.Intern("not supported by goi yet: ")

var Lit_71 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000391")

var Lit_72 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000393")

var Lit_73 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000395")

var Lit_74 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$keys_with__794000397")

var Lit_75 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000431")

var Lit_76 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000469")

var Lit_77 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000471")

var Lit_78 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000473__794000477")

var Lit_79 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000483__794000487")

var Lit_80 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000497__794000501")

var Lit_81 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fsrc__794000507")

var Lit_82 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000548__794000554")

var Lit_83 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000564__794000568")

var Lit_84 *jrt.String = jrt.Intern("SetCode")

var Lit_85 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000583")

var Lit_86 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000585")

var Lit_87 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000594")

var Lit_88 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000596")

var Lit_89 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000609")

var Lit_90 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000611")

var Lit_91 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000620")

var Lit_92 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000622")

var Lit_93 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000632")

var Lit_94 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000636")

var Lit_95 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000638__794000642")

var Lit_96 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000648")

var Lit_97 *jrt.String = jrt.Intern("FuncCell")

var Lit_98 *jrt.String = jrt.Intern("init.vars")

var Lit_99 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000650")

var Lit_100 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000663")

var Lit_101 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000671")

var Lit_102 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000683")

var Lit_103 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000690")

var Lit_104 *jrt.String = jrt.Intern("GlobalPtr")

var Lit_105 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000720")

var Lit_106 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000722")

var Lit_107 *jrt.String = jrt.Intern("main")

var Lit_108 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000431$iter__794000432__794000436")

var Lit_109 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000431$iter__794000448__794000452")

var Lit_110 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000431$iter__794000432__794000436$fn__794000437")

var Lit_111 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000431$iter__794000432__794000436$fn__794000437$fn__794000438")

var Lit_112 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000431$iter__794000448__794000452$fn__794000453")

var Lit_113 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000431$iter__794000448__794000452$fn__794000453$fn__794000454")

var Lit_114 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000585$fn__794000586")

var Lit_115 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000596$fn__794000597")

var Lit_116 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000611$fn__794000612")

var Lit_117 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000622$fn__794000623")

var Lit_118 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000650$fn__794000651")

var Lit_119 *jrt.String = jrt.Intern("FuncSource")

var Lit_120 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000473__794000477$fn__794000478")

var Lit_121 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000473__794000477$fn__794000478$fn__794000479")

var Lit_122 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000483__794000487$fn__794000488")

var Lit_123 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000483__794000487$fn__794000488$fn__794000489")

var Lit_124 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000483__794000487$fn__794000488$fn__794000493")

var Lit_125 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000483__794000487$fn__794000488$fn__794000489$fn__794000490")

var Lit_126 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000497__794000501$fn__794000502")

var Lit_127 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000497__794000501$fn__794000502$fn__794000503")

var Lit_128 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000548__794000554$fn__794000555")

var Lit_129 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000548__794000554$fn__794000555$iter__794000550__794000556")

var Lit_130 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000548__794000554$fn__794000555$iter__794000550__794000556$fn__794000557")

var Lit_131 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000548__794000554$fn__794000555$iter__794000550__794000556$fn__794000557$fn__794000558")

var Lit_132 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000564__794000568$fn__794000569")

var Lit_133 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000564__794000568$fn__794000569$fn__794000570")

var Lit_134 *jrt.String = jrt.Intern("NewGlobal")

var Lit_135 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000638__794000642$fn__794000643")

var Lit_136 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000638__794000642$fn__794000643$fn__794000644")

var Lit_137 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$keys_with__794000397$gen_of__794000398")

var Lit_138 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$keys_with__794000397$iter__794000400__794000404")

var Lit_139 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$keys_with__794000397$iter__794000400__794000404$fn__794000405")

var Lit_140 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$keys_with__794000397$iter__794000400__794000404$fn__794000405$fn__794000406")

var Lit_141 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$keys_with__794000397$iter__794000400__794000404$fn__794000405$iter__794000418__794000422")

var Lit_142 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$keys_with__794000397$iter__794000400__794000404$fn__794000405$fn__794000406$iter__794000407__794000411")

var Lit_143 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$keys_with__794000397$iter__794000400__794000404$fn__794000405$fn__794000406$iter__794000407__794000411$fn__794000412")

var Lit_144 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$keys_with__794000397$iter__794000400__794000404$fn__794000405$fn__794000406$iter__794000407__794000411$fn__794000412$fn__794000413")

var Lit_145 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$keys_with__794000397$iter__794000400__794000404$fn__794000405$iter__794000418__794000422$fn__794000423")

var Lit_146 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$keys_with__794000397$iter__794000400__794000404$fn__794000405$iter__794000418__794000422$fn__794000423$fn__794000424")

var Lit_147 *jrt.String = jrt.Intern("vendor/")

var Lit_148 *jrt.String = jrt.Intern("repl.go")

var Lit_149 *jrt.String = jrt.Intern("embed")

var Lit_150 *jrt.String = jrt.Intern("FS")

var Lit_151 *jrt.String = jrt.Intern("arbace.go.repl$embed_trees$fail__794000181")

var Lit_152 *jrt.String = jrt.Intern("arbace.go.repl$embed_trees$iter__794000183__794000187")

var Lit_153 *jrt.String = jrt.Intern("arbace.go.repl$embed_trees$iter__794000199__794000203")

var Lit_154 *jrt.String = jrt.Intern("arbace.go.repl$embed_trees$iter__794000183__794000187$fn__794000188")

var Lit_155 *jrt.String = jrt.Intern("arbace.go.repl$embed_trees$iter__794000183__794000187$fn__794000188$fn__794000189")

var Lit_156 *jrt.String = jrt.Intern("arbace.go.repl$embed_trees$iter__794000199__794000203$fn__794000204")

var Lit_157 *jrt.String = jrt.Intern("arbace.go.repl$embed_trees$iter__794000199__794000203$fn__794000204$fn__794000205")

var Lit_158 *jrt.String = jrt.Intern("arbace.go.repl$embed_trees$iter__794000199__794000203$fn__794000204$fn__794000251")

var Lit_159 *jrt.String = jrt.Intern("arbace.go.repl$embed_trees$iter__794000199__794000203$fn__794000204$iter__794000256__794000260")

var Lit_160 *jrt.String = jrt.Intern("go1.")

var Lit_161 *jrt.String = jrt.Intern("go:embed cannot apply to var of type ")

var Lit_162 *jrt.String = jrt.Intern("go:embed: the package has no forms directory (a package file's, GS14)")

var Lit_163 *jrt.String = jrt.Intern("arbace.go.repl$embed_trees$iter__794000199__794000203$fn__794000204$fn__794000266")

var Lit_164 *jrt.String = jrt.Intern("BytesFromStr")

var Lit_165 *jrt.String = jrt.Intern("ConstSB")

var Lit_166 *jrt.String = jrt.Intern("ConstR")

var Lit_167 *jrt.String = jrt.Intern("EmbedFS")

var Lit_168 *jrt.String = jrt.Intern("arbace.go.repl$embed_trees$iter__794000199__794000203$fn__794000204$iter__794000279__794000283")

var Lit_169 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_170 *jrt.String = jrt.Intern("arbace.go.repl$embed_trees$iter__794000199__794000203$fn__794000204$fn__794000205$fn__794000206")

var Lit_171 *jrt.String = jrt.Intern("arbace.go.repl$embed_trees$iter__794000199__794000203$fn__794000204$fn__794000205$iter__794000211__794000215")

var Lit_172 *jrt.String = jrt.Intern("arbace.go.repl$embed_trees$iter__794000199__794000203$fn__794000204$fn__794000205$fn__794000221")

var Lit_173 *jrt.String = jrt.Intern("arbace.go.repl$embed_trees$iter__794000199__794000203$fn__794000204$fn__794000205$iter__794000234__794000238")

var Lit_174 *jrt.String = jrt.Intern("arbace.go.repl$embed_trees$iter__794000199__794000203$fn__794000204$fn__794000205$iter__794000211__794000215$fn__794000216")

var Lit_175 *jrt.String = jrt.Intern("arbace.go.repl$embed_trees$iter__794000199__794000203$fn__794000204$fn__794000205$iter__794000211__794000215$fn__794000216$fn__794000217")

var Lit_176 *jrt.String = jrt.Intern("arbace.go.repl$embed_trees$iter__794000199__794000203$fn__794000204$fn__794000205$iter__794000234__794000238$fn__794000239")

var Lit_177 *jrt.String = jrt.Intern("arbace.go.repl$embed_trees$iter__794000199__794000203$fn__794000204$fn__794000205$iter__794000234__794000238$fn__794000239$fn__794000240")

var Lit_178 *jrt.String = jrt.Intern("arbace.go.repl$embed_trees$iter__794000199__794000203$fn__794000204$iter__794000256__794000260$fn__794000261")

var Lit_179 *jrt.String = jrt.Intern("arbace.go.repl$embed_trees$iter__794000199__794000203$fn__794000204$iter__794000256__794000260$fn__794000261$fn__794000262")

var Lit_180 *jrt.String = jrt.Intern("arbace.go.repl$embed_trees$iter__794000199__794000203$fn__794000204$iter__794000279__794000283$fn__794000284")

var Lit_181 *jrt.String = jrt.Intern("arbace.go.repl$embed_trees$iter__794000199__794000203$fn__794000204$iter__794000279__794000283$fn__794000284$fn__794000285")

var Lit_182 *jrt.String = jrt.Intern("\n")

var Lit_183 *jrt.String = jrt.Intern("arbace.go.repl$error_text$iter__794000130__794000134")

var Lit_184 *jrt.String = jrt.Intern("arbace.go.repl$error_text$iter__794000130__794000134$fn__794000135")

var Lit_185 *jrt.String = jrt.Intern("arbace.go.repl$error_text$iter__794000130__794000134$fn__794000135$fn__794000136")

var Lit_186 *jrt.String = jrt.Intern(":")

var Lit_187 *jrt.String = jrt.Intern(": ")

var Lit_188 *jrt.String = jrt.Intern("arbace.lang.GoInterp")

var Lit_189 *jrt.String = jrt.Intern("arbace.lang.GoFn")

var Lit_190 *jrt.String = jrt.Intern("arbace.lang.GoGenericFn")

var Lit_191 *jrt.String = jrt.Intern("arbace.lang.GoVar")

var Lit_192 *jrt.String = jrt.Intern("arbace.lang.GoType")

var Lit_193 *jrt.String = jrt.Intern("arbace.lang.Namespace")

var Lit_194 *jrt.String = jrt.Intern("java.io.File")

var Lit_195 *jrt.String = jrt.Intern("go.")

var Lit_196 *jrt.String = jrt.Intern("goi_eval")

var Lit_197 *jrt.String = jrt.Intern("arbace.go.repl$eval_BANG_$fn__794000824")

var Lit_198 *jrt.String = jrt.Intern("arbace.go.repl$eval_BANG_$attempt__794000826")

var Lit_199 *jrt.String = jrt.Intern("arbace.go.repl$eval_BANG_$fn__794000832")

var Lit_200 *jrt.String = jrt.Intern("arbace.go.repl$eval_BANG_$fn__794000834")

var Lit_201 *jrt.String = jrt.Intern("arbace.go.repl$eval_BANG_$fn__794000839")

var Lit_202 *jrt.String = jrt.Intern("arbace.go.repl$eval_BANG_$fn__794000841")

var Lit_203 *jrt.String = jrt.Intern("arbace.go.repl$eval_BANG_$fn__794000845")

var Lit_204 *jrt.String = jrt.Intern("arbace.go.repl$eval_BANG_$attempt__794000826$fn__794000827")

var Lit_205 *jrt.String = jrt.Intern("arbace.go.repl$eval_BANG_$attempt__794000826$fn__794000829")

var Lit_206 *jrt.String = jrt.Intern("multiple-value")

var Lit_207 *jrt.String = jrt.Intern("(no value) used as value")

var Lit_208 *jrt.String = jrt.Intern("arbace.go.repl$file_BANG_$fn__794000059")

var Lit_209 *jrt.String = jrt.Intern("arbace.go.repl$file_entry$fn__794000046")

var Lit_210 *jrt.String = jrt.Intern("fmt")

var Lit_211 *jrt.String = jrt.Intern("arbace.go.repl$fn__794000024$fn__794000025")

var Lit_212 *jrt.String = jrt.Intern("goi:out")

var Lit_213 *jrt.String = jrt.Intern("arbace.go.repl$fn__794000034$fn__794000035")

var Lit_214 *jrt.String = jrt.Intern("go/import in a package being loaded: a file's imports are its go/file's")

var Lit_215 *jrt.String = jrt.Intern("arbace.go.repl$import_BANG_$fn__794000063")

var Lit_216 *jrt.String = jrt.Intern("arbace.go.repl$import_BANG_$fn__794000063$fn__794000064")

var Lit_217 *jrt.String = jrt.Intern("arbace.go.repl$inst_BANG_$fn__794000865")

var Lit_218 *jrt.String = jrt.Intern("go/inst: ")

var Lit_219 *jrt.String = jrt.Intern(" is no generic function or type")

var Lit_220 *jrt.String = jrt.Intern("arbace.go.repl$interpreted_closure$iter__794000908__794000914")

var Lit_221 *jrt.String = jrt.Intern("arbace.go.repl$interpreted_closure$iter__794000908__794000914$fn__794000915")

var Lit_222 *jrt.String = jrt.Intern("arbace.go.repl$interpreted_closure$iter__794000908__794000914$fn__794000915$iter__794000910__794000916")

var Lit_223 *jrt.String = jrt.Intern("arbace.go.repl$interpreted_closure$iter__794000908__794000914$fn__794000915$iter__794000910__794000916$fn__794000917")

var Lit_224 *jrt.String = jrt.Intern("arbace.go.repl$interpreted_closure$iter__794000908__794000914$fn__794000915$iter__794000910__794000916$fn__794000917$fn__794000918")

var Lit_225 *jrt.String = jrt.Intern("arbace.go.repl$listed_generic_BANG_$fn__794000872")

var Lit_226 *jrt.String = jrt.Intern("goi: no forms of ")

var Lit_227 *jrt.String = jrt.Intern(" in the digest")

var Lit_228 *jrt.String = jrt.Intern("arbace.go.repl$load_digest_package_BANG_$fn__794000747")

var Lit_229 *jrt.String = jrt.Intern("arbace.go.repl$load_digest_package_BANG_$fn__794000749")

var Lit_230 *jrt.String = jrt.Intern("arbace.go.repl$load_import$fn__794000758")

var Lit_231 *jrt.String = jrt.Intern("(*")

var Lit_232 *jrt.String = jrt.Intern(").")

var Lit_233 *jrt.String = jrt.Intern("arbace.go.repl$named_type$fn__794000362")

var Lit_234 *jrt.String = jrt.Intern("arbace.go.repl$package_file$fn__794000173")

var Lit_235 *jrt.String = jrt.Intern("arbace.go.repl$package_file$fn__794000175")

var Lit_236 *jrt.String = jrt.Intern("ARBACE_PATH")

var Lit_237 *jrt.String = jrt.Intern("store:")

var Lit_238 *jrt.String = jrt.Intern("Go declarations belong in a go.* namespace (")

var Lit_239 *jrt.String = jrt.Intern(" is not one)")

var Lit_240 *jrt.String = jrt.Intern("the package ")

var Lit_241 *jrt.String = jrt.Intern(" is a compiled package of the table: it cannot be interpreted (S1)")

var Lit_242 *jrt.String = jrt.Intern("goi: ")

var Lit_243 *jrt.String = jrt.Intern("use of internal package ")

var Lit_244 *jrt.String = jrt.Intern(" not allowed")

var Lit_245 *jrt.String = jrt.Intern("package ")

var Lit_246 *jrt.String = jrt.Intern(" is std's vendored copy, not importable")

var Lit_247 *jrt.String = jrt.Intern("NO_SOURCE_PATH")

var Lit_248 *jrt.String = jrt.Intern("NO_SOURCE_FILE")

var Lit_249 *jrt.String = jrt.Intern("REPL")

var Lit_250 *jrt.String = jrt.Intern("goi_inst")

var Lit_251 *jrt.String = jrt.Intern("arbace.go.repl$resolve_types$fn__794000854")

var Lit_252 *jrt.String = jrt.Intern("arbace.go.repl$resolve_types$fn__794000856")

var Lit_253 *jrt.String = jrt.Intern("arbace.go.repl$resolve_types$fn__794000858")

var Lit_254 *jrt.String = jrt.Intern("arbace.go.repl$resolve_types$fn__794000860")

var Lit_255 *jrt.String = jrt.Intern("arbace.go.repl$resolve_types$fn__794000862")

var Lit_256 *jrt.String = jrt.Intern("F")

var Lit_257 *jrt.String = jrt.Intern(" is not an interpreted Go package")

var Lit_258 *jrt.String = jrt.Intern("goi-run-compiled")

var Lit_259 *jrt.String = jrt.Intern("src")

var Lit_260 *jrt.String = jrt.Intern("prog")

var Lit_261 *jrt.String = jrt.Intern("ARBACE_GOROOT")

var Lit_262 *jrt.String = jrt.Intern("/root/tamago-go")

var Lit_263 *jrt.String = jrt.Intern("amd64")

var Lit_264 *jrt.String = jrt.Intern("work")

var Lit_265 *jrt.String = jrt.Intern("go/run-compiled: go build of ")

var Lit_266 *jrt.String = jrt.Intern(" failed (status ")

var Lit_267 *jrt.String = jrt.Intern(")")

var Lit_268 *jrt.String = jrt.Intern(" has no main")

var Lit_269 *jrt.String = jrt.Intern("arbace.go.repl$session_for$fn__794000153")

var Lit_270 *jrt.String = jrt.Intern("arbace.go.repl$session_for$fn__794000155")

var Lit_271 *jrt.String = jrt.Intern("arbace.go.repl$source_of$iter__794000142__794000146")

var Lit_272 *jrt.String = jrt.Intern("arbace.go.repl$source_of$iter__794000142__794000146$fn__794000147")

var Lit_273 *jrt.String = jrt.Intern("arbace.go.repl$source_of$iter__794000142__794000146$fn__794000147$fn__794000148")

var Lit_274 *jrt.String = jrt.Intern("arbace.go.repl$table_type_QMARK_$iter__794000318__794000322")

var Lit_275 *jrt.String = jrt.Intern("arbace.go.repl$table_type_QMARK_$iter__794000318__794000322$fn__794000323")

var Lit_276 *jrt.String = jrt.Intern("arbace.go.repl$table_type_QMARK_$iter__794000318__794000322$fn__794000323$fn__794000324")

var Lit_277 *jrt.String = jrt.Intern("type")

var Lit_278 *jrt.String = jrt.Intern("arbace.go.repl$type_key$fn__794000304")

var Lit_279 *jrt.String = jrt.Intern("arbace.go.repl$type_key$fn__794000306")

var Lit_280 *jrt.String = jrt.Intern("arbace.go.repl$type_key$fn__794000308")

var Lit_281 *jrt.String = jrt.Intern("arbace.go.repl$type_key$fn__794000310")

var Lit_282 *jrt.String = jrt.Intern("arbace.go.repl$type_key$fn__794000312")

var Lit_283 *jrt.String = jrt.Intern("arbace.go.repl$update_file$fn__794000051")

var Lit_284 *jrt.String = jrt.Intern("arbace.go.repl$update_file$fn__794000051$fn__794000052")

var Lit_285 *jrt.String = jrt.Intern("arbace.go.repl$update_file$fn__794000051$fn__794000054")

var Lit_286 *jrt.String = jrt.Intern("arbace.go.repl$write_package_BANG_$iter__794000877__794000881")

var Lit_287 *jrt.String = jrt.Intern(".ae")

var Lit_288 *jrt.String = jrt.Intern("arbace.go.repl$write_package_BANG_$iter__794000887__794000891")

var Lit_289 *jrt.String = jrt.Intern("\n\n")

var Lit_290 *jrt.String = jrt.Intern("arbace.go.repl$write_package_BANG_$iter__794000877__794000881$fn__794000882")

var Lit_291 *jrt.String = jrt.Intern("arbace.go.repl$write_package_BANG_$iter__794000877__794000881$fn__794000882$fn__794000883")

var Lit_292 *jrt.String = jrt.Intern("arbace.go.repl$write_package_BANG_$iter__794000887__794000891$fn__794000892")

var Lit_293 *jrt.String = jrt.Intern("arbace.go.repl$write_package_BANG_$iter__794000887__794000891$fn__794000892$fn__794000893")

var Lit_294 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn4,linekn6,columnkn4,filekn8,arglistsyn1,pkn3,tagyn6,Stringyn7,ns-nameyn4,pathyn2,nmyn6,ns-symyn7,create?yn4,optsyn2,styn5,fnameyn1,fyn5,specsyn4,errsyn3,srckn8,declaredyn9,extra-srcyn7,define?yn1,syn12,java.io.Fileyn2,tyyn5,declsyn6,gen-ofyn1,mkn6,ctx-ofkn5,namedyn1,vyn4,specyn2,nsyn3,symyn1,rkn4,keysyn5,vars?yn5,eageryn4,onlyyn10,kept-namesyn10,init-namesyn2,okyn4,formyn4,lineyn5,stmtsyn6,tformsyn4,infoyn4,Fileyn4,argsv11,arbace.core5,in-nsMyn14,arbace.go.replm2,R0,s778,goi's REPL state (doc/go/GOI-SPEC.md §2): interpreted Go packages as namespaces, their files\n  and declarations, checking (arbace.go.check) against the table's digest and the other\n  interpreted packages, defining their vars (functions, variables, constants, types and their\n  generations), loading packages from ARBACE_PATH (the declarations queued, the package checked\n  when its package file's load ends: S6), initialization, go/eval, and running a program in\n  program mode (bin/goi run: arbace.go.run).\n\n  A package's state is an atom {:path :name :ns :config :files [{:name :imports :decls}]\n  :current (the REPL's file) :loading (the package file being loaded) :funcs {name *Func}\n  :globals {name {:ptr :key}} :types {name {:gen :key :desc}} :checked (the last result)}.m2,R0,s778,goi's REPL state (doc/go/GOI-SPEC.md §2): interpreted Go packages as namespaces, their files\n  and declarations, checking (arbace.go.check) against the table's digest and the other\n  interpreted packages, defining their vars (functions, variables, constants, types and their\n  generations), loading packages from ARBACE_PATH (the declarations queued, the package checked\n  when its package file's load ends: S6), initialization, go/eval, and running a program in\n  program mode (bin/goi run: arbace.go.run).\n\n  A package's state is an atom {:path :name :ns :config :files [{:name :imports :decls}]\n  :current (the REPL's file) :loading (the package file being loaded) :funcs {name *Func}\n  :globals {name {:ptr :key}} :types {name {:gen :key :desc}} :checked (the last result)}.R1,v14,arbace.go.repl6,listedm8,R2,TR3,i28,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl7,listed?m10,R6,L1,V1,R7,R0,s76,Whether import path p is a package of the table of compiled packages (§6.6).R3,i30,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl12,digest-indexm8,R2,TR3,i35,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl12,digest-formsm10,R6,L1,V1,R7,R0,s78,The digest's forms of listed package p (§6.5), read with line numbers, or nil.R3,i41,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl6,configm8,R3,i48,R4,i1,R5,s17,arbace/go/repl.aeR0,s78,The program's configuration (:goos, :goarch), as the digest's packages say it.v14,arbace.go.repl14,interpretable?m10,R6,L1,V1,R7,R0,s141,Whether import path p is an interpretable package of the digest (§9.3, GR8a): its forms there\n  whole, goi's to interpret under its std path.R3,i56,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl12,out-of-scopem10,R2,TR3,i62,R4,i1,R5,s17,arbace/go/repl.aeR0,s88,The std packages out of scope (GR8a): path -> the reason they are refused at the import.v14,arbace.go.repl7,refusalm10,R6,L1,V2,Myn4,pathm2,R8,R9,Myn13,importer-pathm2,R8,R9,R0,s196,Why package importer-path may not import path at the REPL (GR8a), or nil: a std package out of\n  scope (its reason), or an internal or vendored std package imported from outside std (Go's\n  rule).R3,i68,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl14,digest-sessionm10,R2,TR3,i85,R4,i1,R5,s17,arbace/go/repl.aeR0,s328,The checking session of the digest's packages (one per process): the table's packages and the\n  interpretable ones (GR8a: so that a listed member's type naming an interpretable package's,\n  iter.Seq[string], is the type interpreted code names, GC63), the latter with their trees, for\n  goi to define them (load-digest-package!).v14,arbace.go.repl8,packagesm8,R0,s63,The interpreted packages by import path: atoms of their states.R3,i99,R4,i1,R5,s17,arbace/go/repl.aev11,arbace.core4,atomm8,R0,s63,The interpreted packages by import path: atoms of their states.R3,i99,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl8,path->nsm10,R6,L1,V1,Myn1,pm2,R8,R9,R0,s46,The namespace of import path p (SPEC.md §4.1).R3,i101,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl8,ns->pathm10,R6,L1,V1,R10,R0,s82,The import path of a go.* namespace name (S2): the segments after go. joined by /.R3,i106,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl9,new-statem10,R2,TR6,L1,V3,R11,R12,R13,R3,i111,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl13,package-statem10,R6,L2,V1,R13,V2,R13,R14,R0,s88,The state of the package of namespace ns-sym, made implicitly (S2) for a go.* namespace.R3,i115,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl8,package!m10,R6,L1,V3,R13,R12,R15,R0,s95,go/package: the namespace's package (its name, :path, :files ...); in a load, the load's start.R3,i131,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl10,file-entrym10,R2,TR6,L1,V2,R16,R17,R3,i147,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl11,update-filem10,R2,TR6,L1,V3,R16,R17,R18,R3,i150,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl5,file!m10,R6,L1,V3,R13,R17,R15,R0,s65,go/file: the namespace's current file, its imports replaced (S5).R3,i157,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl7,import!m10,R6,L1,V2,R13,R19,R0,s67,go/import at the REPL: import specs added to the current file (S5).R3,i166,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl10,decl-namesm12,R2,TR6,L1,V1,R18,R0,s67,The package-level names a declaration form declares (methods: T.M).R3,i177,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl10,error-textm12,R2,TR6,L2,V1,R20,V2,R20,R21,R0,s142,Errors as go/types words them (§3.8): FILE:LINE: MESSAGE, at most ten; the REPL's implicit\n  file is the forms' source (REPL for typed forms).R3,i205,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl11,repl-sourcem10,R2,TR6,L1,V0,R3,i213,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl9,source-ofm10,R6,L1,V1,R16,R0,s67,The checker's source of package state st (its files as they stand).R3,i215,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl11,load-importm8,R22,TR3,i224,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl11,session-form12,R2,TR6,L1,V1,R23,R0,s161,A checking session for an interpreted package: listed imports from the digest, interpreted\n  ones from their states (loaded from ARBACE_PATH when not yet: §2.3).R3,i226,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl20,load-digest-package!m8,R22,TR3,i238,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl22,define-digest-imports!m12,R2,TR6,L1,V1,R21,R0,s88,Defines the interpretable packages src imports (GR8a), each once, its own imports first.R3,i240,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl12,check-sourcem10,R6,L2,V2,R21,R23,V3,R21,R23,R24,R0,s171,Checks src: the package's result (with its trees), its errors included; then defines the\n  interpretable packages it imports (GR8a; not when define? is false: errorcheck).R3,i251,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl12,package-filem12,R2,TR6,L1,MV1,R25,m2,R8,R26,R0,s153,The package file of state s: a program's (:pf), else the file its load read (:load-file: a\n  path, or a resource's on ARBACE_PATH's directories), or nil.R3,i265,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl10,embed-kindm12,R2,TR6,L1,V1,R27,R0,s86,The kind of a go:embed variable's type (gc's embedKind): :fs, :string, :bytes, or nil.R3,i278,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl11,embed-treesm12,R2,TR6,L1,V2,R25,R28,R0,s245,The initializers of the package's //go:embed variables (GS14 (a)): each its value from the\n  files of its package's forms directory, read now ({:op :var-init}, the value a builder node);\n  gc's and the go command's errors thrown as check errors.R3,i288,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl8,type-keym12,R2,TR6,L1,V2,R27,R29,R0,s137,The structure of a type, its interpreted named types by name and generation (a named type's\n  generation is new when this changes: §2.5).R3,i334,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl13,state-of-pathm10,R2,TR6,L1,V1,R7,R3,i351,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl11,method-namem10,R6,L1,V1,R30,R0,s77,Method object m's name as gc names it: T.M, or (*T).M for a pointer receiver.R3,i353,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl12,display-filem12,R2,TR6,L1,V1,R17,R0,s176,The file a frame of a declaration of Go file fname shows in traces (§10.6): the Go file of\n  converted forms, the forms' source for the REPL's implicit file (REPL at the REPL).R3,i359,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl6,ctx-ofm8,R22,TR3,i365,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl11,table-typesm8,R2,TR3,i367,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl11,table-type?m12,R2,TR6,L1,V2,R11,R12,R0,s144,Whether the table describes listed package path's named type nm (its exported types, and the\n  unexported ones of its exported variables: GR8a).R3,i369,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl12,digest-scopem12,R2,TR6,L1,V1,R11,R0,s92,The package-level objects of listed package path, as the digest's session checked it (GR8a).R3,i379,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl13,build-contextm10,R6,L1,V1,R16,R0,s50,The builder's context for the package of state st.R3,i384,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl17,compiled-contextsm10,R2,TR0,s115,The build contexts of compiled packages, for the instances of their\n  generic declarations (§9.3): path -> context.R3,i413,R4,i1,R5,s17,arbace/go/repl.aem10,R2,TR0,s115,The build contexts of compiled packages, for the instances of their\n  generic declarations (§9.3): path -> context.R3,i413,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl16,compiled-contextm10,R6,L1,V1,R11,R0,s156,The build context of listed (compiled) package path: its members compiled, its generic\n  declarations' instances interpreted from the digest's forms (§9.3).R3,i416,R4,i1,R5,s17,arbace/go/repl.aem10,R6,L1,V1,R11,R0,s89,The build context of package path (an interpreted package's last, else a compiled one's).R3,i437,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl10,named-typem10,R6,L1,V2,R11,R12,R0,s153,GR9d: the checker's type of package path's named type nm as the package stands: an\n  interpreted package's last check, a listed package's digest; or nil.R3,i444,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl11,generic-envR31,R32,m10,R2,TR3,i457,R4,i1,R5,s17,arbace/go/repl.aeR0,s48,What arbace.go.generic asks of the REPL's state.v14,arbace.go.repl12,const-arbacem12,R2,TR6,L1,V2,R27,R33,R0,s45,A constant's value as Arbace takes it (§5.6).R3,i461,R4,i1,R5,s17,arbace/go/repl.aem8,R22,TR3,i473,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl13,linkname-cellm12,R2,TR6,L1,V1,R34,R0,s228,The cell a body-less function declaration's go:linkname pull names (spec, its form), when its\n  target is a function of an interpreted package (GR8a, GC59: net/textproto.readMIMEHeader for\n  mime/multipart and net/http), or nil.R3,i475,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl9,intern-gom12,R2,TR6,L1,V3,R35,R36,R33,R0,s181,intern, a name that maps a class or another namespace's var (Package, Error of java.lang, a\n  core fn) unmapped first: a Go name shadows it without a warning (GR8a: std's packages).R3,i492,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl7,define!m10,R6,L1,V3,R16,R37,m2,R38,V5,R39,R40,R41,R42,R43,R0,s367,Defines the checked package result r in state st: function cells (their code built on first\n  call, S18, or now when eager), variables' cells, types' generations; with vars?, the\n  namespace's vars (§2.1). Returns {:inits (the initializers' code in order, a *goi.Func) :init-funcs\n  (init cells in order) :main (cell or nil) :new-vars (names of variables made anew)}.R3,i501,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl5,call0m10,R6,L1,V2,R18,Myn2,nmm2,R8,R9,R0,s87,Calls function cell f of no parameters and no results from Arbace (a panic: a GoPanic).R3,i686,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl9,complete!m12,R2,TR6,L1,V1,R16,R0,s141,Completes package state st after its load: checked whole (a CompilerException-like error\n  listing every error), defined, initialized (§2.6).R3,i692,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl10,after-loadm10,R6,L1,V2,Myn4,pathm2,R8,R9,R44,R0,s184,arbace.core/load's hook (§2.3, S6): the load of a resource (path, as load names it) ended\n  (ok: normally); a package whose package file it was is completed (a failed load forgets it).R3,i707,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl15,hook-registeredm8,R2,TR3,i720,R4,i1,R5,s17,arbace/go/repl.aem8,R2,TR3,i720,R4,i1,R5,s17,arbace/go/repl.aev11,arbace.core5,swap!v11,arbace.core4,conjm12,R2,TR6,L1,V1,R11,R0,s320,Defines interpretable package path from the digest's forms (§9.3): its state made, then\n  defined and initialized as a loaded package's (§2.3). GR8a: checked once per process, in the\n  digest's session (its imports' types are the ones the table's members name), its interpretable\n  imports defined and initialized first.R3,i723,R4,i1,R5,s17,arbace/go/repl.aem10,R6,L1,V1,R11,R0,s171,The state of interpreted package path, loaded from ARBACE_PATH (its namespace) when it is\n  not yet (§2.3), or from the digest for an interpretable package (§9.3), or nil.R3,i762,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl8,declare!m10,R6,L1,V2,R45,m2,R38,V2,R35,R46,R0,s165,A declaration macro's form (go/func, go/var ...): queued in a load, else checked against the\n  package and defined at once (§2.5); returns the var of its first name.R3,i778,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl10,eval-countl0,m8,R2,TR3,i828,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl5,eval!m10,R6,L1,V2,R47,m2,R38,V1,R35,R0,s156,go/eval: Go statements run as the body of a function of the namespace's package (go.user\n  outside go.*: S3); the last statement's value as Arbace's (§5.6).R3,i830,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl9,run-main!m10,R6,L1,V1,R13,R0,s95,go/run-main: package ns-sym's main (program mode's exit semantics in the REPL's process: §2.6).R3,i882,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl6,check!m10,R6,L1,V1,R13,R0,s70,go/check: the package's errors, checked again (data), nothing defined.R3,i892,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl13,resolve-typesm12,R2,TR6,L1,V2,R13,R48,R0,s218,Go type forms tforms resolved in the package of namespace ns-sym (go.user outside go.*), as\n  go/eval resolves names: the checker's types (of a check of the package with a struct type of\n  fields of those types added).R3,i900,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl5,inst!m10,R6,L1,V3,R13,R18,R48,R0,s298,(go/inst f T...) in namespace ns-sym (GR9d, GC73): f a generic function's var (a GoGenericFn)\n  or a generic type of an interpreted or listed package (go.main/List); the instance (a GoFn, a\n  GoType) or, with fewer type arguments, a GoGenericFn inferring the rest. Kept per GoGenericFn\n  and forms.R3,i925,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl15,listed-generic!m10,R6,L1,V4,R35,R11,Myn1,nm2,R8,R9,R49,R0,s241,GR9d: the var of listed package path's generic function or generic type's method n (T.M),\n  interned in ns (arbace.go/table-ns!'s, made on demand as the package's other vars, S9): a\n  GoGenericFn over the digest's declaration (§9.3), or nil.R3,i958,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl9,form-textm12,R2,TR6,L1,V1,R18,R0,s74,Form f as readable text with its metadata (the forms root build/go reads).R3,i978,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl14,write-package!m12,R2,TR6,L1,V2,Myn3,dirm2,R8,R50,R16,R0,s94,Writes package state st as a forms root's package file and its files under dir (SPEC.md §4.1).R3,i984,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl19,interpreted-closurem12,R2,TR6,L1,V1,R16,R0,s71,Package state st and the interpreted packages it imports, transitively.R3,i1009,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl13,run-compiled!m10,R6,L1,V2,R13,R51,R0,s324,go/run-compiled: package ns-sym's program (it and the interpreted packages it imports) as\n  Go forms, printed by repr/go and built by build/go (arbace.build.go) with the toolchain of\n  ARBACE_GOROOT (default /root/tamago-go), run with args as a child process (G15):\n  {:out :err :exit}; a build that fails throws its status.R3,i1022,R4,i1,R5,s17,arbace/go/repl.ae")

var Lit_295 *jrt.String = jrt.Intern("arbace.go.repl$eval794000004$loading__1927001464__auto____794000005")

var Lit_296 *jrt.String = jrt.Intern("arbace.go.repl$eval794000008$fn__794000009")

var Lit_297 *jrt.String = jrt.Intern("arbace.go.repl$fn__794000012")

var Lit_298 *jrt.String = jrt.Intern("arbace.go.repl$listed_QMARK_")

var Lit_299 *jrt.String = jrt.Intern("arbace.go.repl$fn__794000015")

var Lit_300 *jrt.String = jrt.Intern("arbace.go.repl$digest_forms")

var Lit_301 *jrt.String = jrt.Intern("arbace.go.repl$fn__794000024")

var Lit_302 *jrt.String = jrt.Intern("arbace.go.repl$interpretable_QMARK_")

var Lit_303 *jrt.String = jrt.Intern("arbace.go.repl$fn__794000030")

var Lit_304 *jrt.String = jrt.Intern("arbace.go.repl$refusal")

var Lit_305 *jrt.String = jrt.Intern("arbace.go.repl$fn__794000034")

var Lit_306 *jrt.String = jrt.Intern("arbace.go.repl$path__GT_ns")

var Lit_307 *jrt.String = jrt.Intern("arbace.go.repl$ns__GT_path")

var Lit_308 *jrt.String = jrt.Intern("arbace.go.repl$new_state")

var Lit_309 *jrt.String = jrt.Intern("arbace.go.repl$package_state")

var Lit_310 *jrt.String = jrt.Intern("arbace.go.repl$package_BANG_")

var Lit_311 *jrt.String = jrt.Intern("arbace.go.repl$file_entry")

var Lit_312 *jrt.String = jrt.Intern("arbace.go.repl$update_file")

var Lit_313 *jrt.String = jrt.Intern("arbace.go.repl$file_BANG_")

var Lit_314 *jrt.String = jrt.Intern("arbace.go.repl$import_BANG_")

var Lit_315 *jrt.String = jrt.Intern("arbace.go.repl$decl_names")

var Lit_316 *jrt.String = jrt.Intern("arbace.go.repl$error_text")

var Lit_317 *jrt.String = jrt.Intern("arbace.go.repl$repl_source")

var Lit_318 *jrt.String = jrt.Intern("arbace.go.repl$source_of")

var Lit_319 *jrt.String = jrt.Intern("arbace.go.repl$session_for")

var Lit_320 *jrt.String = jrt.Intern("arbace.go.repl$define_digest_imports_BANG_")

var Lit_321 *jrt.String = jrt.Intern("arbace.go.repl$check_source")

var Lit_322 *jrt.String = jrt.Intern("arbace.go.repl$package_file")

var Lit_323 *jrt.String = jrt.Intern("arbace.go.repl$embed_kind")

var Lit_324 *jrt.String = jrt.Intern("arbace.go.repl$embed_trees")

var Lit_325 *jrt.String = jrt.Intern("arbace.go.repl$type_key")

var Lit_326 *jrt.String = jrt.Intern("arbace.go.repl$state_of_path")

var Lit_327 *jrt.String = jrt.Intern("arbace.go.repl$method_name")

var Lit_328 *jrt.String = jrt.Intern("arbace.go.repl$display_file")

var Lit_329 *jrt.String = jrt.Intern("arbace.go.repl$table_type_QMARK_")

var Lit_330 *jrt.String = jrt.Intern("arbace.go.repl$digest_scope")

var Lit_331 *jrt.String = jrt.Intern("arbace.go.repl$build_context")

var Lit_332 *jrt.String = jrt.Intern("arbace.go.repl$compiled_context")

var Lit_333 *jrt.String = jrt.Intern("arbace.go.repl$ctx_of")

var Lit_334 *jrt.String = jrt.Intern("arbace.go.repl$named_type")

var Lit_335 *jrt.String = jrt.Intern("arbace.go.repl$fn__794000365")

var Lit_336 *jrt.String = jrt.Intern("arbace.go.repl$fn__794000367")

var Lit_337 *jrt.String = jrt.Intern("arbace.go.repl$const_arbace")

var Lit_338 *jrt.String = jrt.Intern("arbace.go.repl$linkname_cell")

var Lit_339 *jrt.String = jrt.Intern("arbace.go.repl$intern_go")

var Lit_340 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_")

var Lit_341 *jrt.String = jrt.Intern("arbace.go.repl$call0")

var Lit_342 *jrt.String = jrt.Intern("arbace.go.repl$complete_BANG_")

var Lit_343 *jrt.String = jrt.Intern("arbace.go.repl$after_load")

var Lit_344 *jrt.String = jrt.Intern("arbace.go.repl$load_digest_package_BANG_")

var Lit_345 *jrt.String = jrt.Intern("arbace.go.repl$load_import")

var Lit_346 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_")

var Lit_347 *jrt.String = jrt.Intern("arbace.go.repl$eval_BANG_")

var Lit_348 *jrt.String = jrt.Intern("arbace.go.repl$run_main_BANG_")

var Lit_349 *jrt.String = jrt.Intern("arbace.go.repl$check_BANG_")

var Lit_350 *jrt.String = jrt.Intern("arbace.go.repl$resolve_types")

var Lit_351 *jrt.String = jrt.Intern("arbace.go.repl$inst_BANG_")

var Lit_352 *jrt.String = jrt.Intern("arbace.go.repl$listed_generic_BANG_")

var Lit_353 *jrt.String = jrt.Intern("arbace.go.repl$form_text")

var Lit_354 *jrt.String = jrt.Intern("arbace.go.repl$write_package_BANG_")

var Lit_355 *jrt.String = jrt.Intern("arbace.go.repl$interpreted_closure")

var Lit_356 *jrt.String = jrt.Intern("arbace.go.repl$run_compiled_BANG_")
