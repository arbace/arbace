//line j2g_strings.ae:1
package aot_arbace_go_repl

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn15,arbace.go.checkyn2,ckyn19,arbace.go.check.envyn1,eyn21,arbace.go.check.typesyn1,tyn21,arbace.go.check.constyn1,cyn20,arbace.go.check.codeyn4,codeyn20,arbace.go.check.loadyn4,loadyn15,arbace.go.buildyn1,byn20,arbace.repr.go.printyn2,rpkn3,dockn5,indexkn4,textkn5,startys2,go7,packagekn6,configkn4,gooskn6,goarchkn4,langkn4,pathkn4,namekn2,nskn5,fileskn7,currentkn5,funcskn7,globalskn5,typeskn7,definedkn4,optskn12,package-pathkn7,loadingkn7,importskn5,declskn11,type-paramskn3,tagyn1,*kn4,filekn4,linekn3,msgkn8,delegatekn5,localkn10,keep-treeskn6,resultkn4,elsekn4,chankn6,structkn5,arraykn4,funckn5,namedkn3,pkgkn6,tparamkn4,typekn9,interfacekn5,tuplekn10,recv-namedkn8,ptr-recvkn6,sourcekn9,compiled?kn12,methods-donekn9,lit-countkn3,genkn9,func-cellkn4,cellkn11,method-cellkn7,methodskn6,globalkn7,float32kn7,float64kn13,untyped-floatkn5,vars?kn5,eagerkn4,onlykn10,kept-nameskn10,init-nameskn10,decl-infoskn11,unsupportedkn7,generickn4,kindkn6,methodkn3,objkn3,keykn4,keptkn4,treekn5,initskn3,varkn3,lhskn3,ptrkn8,var-initkn2,opkn5,orderkn10,init-funcskn4,mainkn8,new-varsks3,goi11,unsupportedkn5,aliaskn13,tparams-countkn7,checkedkn5,constkn4,specks2,go4,kindks2,go7,packagekn7,privatekn3,valkn6,errorsks2,go6,errorskn12,UnusedImportkn4,codekn2,idkn4,declyn7,go.userys2,go4,funcyn3,anykn7,resultskn13,TooManyValuesyn2,nskn7,requireyn9,arbace.goyn2,gokn6,columnyn5,in-nsyn5,quoteys2,go4,fileys15,arbace.build.go5,buildys17,arbace.java.shell2,shkn3,outkn3,errkn4,exitkn6,gorootkn4,workks2,go6,statusv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,V3,R12,R2,R13,V3,R14,R2,R15,V3,R16,R2,R17,V3,R18,R2,R19,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn14,arbace.go.replm2,R20,s778,goi's REPL state (doc/go/GOI-SPEC.md §2): interpreted Go packages as namespaces, their files\n  and declarations, checking (arbace.go.check) against the table's digest and the other\n  interpreted packages, defining their vars (functions, variables, constants, types and their\n  generations), loading packages from ARBACE_PATH (the declarations queued, the package checked\n  when its package file's load ends: S6), initialization, go/eval, and running a program in\n  program mode (bin/goi run: arbace.go.run).\n\n  A package's state is an atom {:path :name :ns :config :files [{:name :imports :decls}]\n  :current (the REPL's file) :loading (the package file being loaded) :funcs {name *Func}\n  :globals {name {:ptr :key}} :types {name {:gen :key :desc}} :checked (the last result)}.v11,arbace.core3,setv11,arbace.core9,contains?v14,arbace.go.repl6,listedR21,v11,arbace.core11,read-stringv11,arbace.core4,subsl0,R22,R23,v14,arbace.go.repl12,digest-indexv11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core3,seqv11,arbace.core5,firstv15,arbace.go.check17,read-string-formsv14,arbace.go.repl12,digest-formsv11,arbace.core6,filterv11,arbace.core4,seq?R24,R25,v11,arbace.core5,applyv11,arbace.core8,hash-mapv11,arbace.core5,nnextv11,arbace.core5,mergem6,R26,s5,linuxR27,s5,amd64R28,s6,go1.27v15,arbace.go.check7,sessionv14,arbace.go.repl7,listed?v15,arbace.go.check12,forms-sourcev14,arbace.go.repl6,configv11,arbace.core6,symbolv20,arbace.go.check.load8,path->nsv13,arbace.string4,joinv11,arbace.core4,restv13,arbace.string5,splitv11,arbace.core3,strp2,\\.v11,arbace.core4,atomR29,R30,R31,R32,R33,R34,R35,R36,R37,v14,arbace.go.repl8,ns->pathv14,arbace.go.repl8,packagesv14,arbace.go.repl9,new-statev11,arbace.core4,lastp1,/v13,arbace.string12,starts-with?v11,arbace.core7,ex-infov11,arbace.core5,swap!v11,arbace.core5,assocv14,arbace.go.repl13,package-statev20,arbace.repr.go.print9,name-textR38,R39,R28,R40,v11,arbace.core4,somev11,arbace.core6,updatev11,arbace.core4,mapvR41,R42,v14,arbace.go.repl11,update-filev11,arbace.core6,dissocR20,v11,arbace.core3,vecv11,arbace.core8,distinctv11,arbace.core4,intov20,arbace.go.check.code9,head-namev11,arbace.core7,string?v11,arbace.core6,every?v11,arbace.core7,vector?v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core6,concatv11,arbace.core3,mapv11,arbace.core6,secondv11,arbace.core4,dropl2,R43,v11,arbace.core7,symbol?R44,R45,R46,R47,R48,v11,arbace.core4,takel10,v14,arbace.go.repl10,error-textv11,arbace.core6,*file*v14,arbace.go.repl11,load-importv14,arbace.go.repl9,source-ofR49,v14,arbace.go.repl14,digest-sessionR50,v11,arbace.core3,notv14,arbace.go.repl11,session-forv15,arbace.go.check13,check-packagev15,arbace.go.check8,resolverR51,v19,arbace.go.check.env1,oR52,v11,arbace.core8,keyword?v21,arbace.go.check.types6,named?v21,arbace.go.check.types4,infov21,arbace.go.check.types7,tparam?R53,R54,R55,R56,R57,v14,arbace.go.repl8,type-keyR58,R59,R60,R61,R62,R63,V1,R63,R64,R65,v14,arbace.go.repl11,repl-sourceR66,v14,arbace.go.repl12,display-fileR67,R68,R69,R70,v14,arbace.go.repl13,state-of-pathv11,arbace.core6,get-inl1,R71,R72,R73,v14,arbace.go.repl11,method-nameR74,R75,v21,arbace.go.check.types5,underv11,arbace.core8,boolean?v21,arbace.go.check.const10,value-textv21,arbace.go.check.const8,complex?v21,arbace.go.check.const9,to-doubleS3,R76,R77,R78,R76,v11,arbace.core8,integer?R79,R80,R81,R82,R83,v14,arbace.go.repl13,build-contextR84,R85,R86,R87,R88,v11,arbace.core4,not=R89,R90,v15,arbace.go.build2,opR91,R92,R93,R94,R95,v11,arbace.core9,volatile!R96,v15,arbace.go.build4,descR97,R98,v11,arbace.core4,keepR99,R100,R101,V2,s4,mainR72,R102,v11,arbace.core19,pop-thread-bindingsR103,v11,arbace.core20,push-thread-bindingsv15,arbace.go.build5,*ctx*v21,arbace.go.check.types12,*method-obj*v15,arbace.go.build11,method-dataR104,v15,arbace.go.build8,with-ctxv15,arbace.go.build10,build-funcv15,arbace.go.build12,unsupported!v15,arbace.go.build11,build-initsv11,arbace.core9,create-nsR105,R106,v15,arbace.go.build15,method-callablev11,arbace.core7,ex-dataR107,v21,arbace.go.check.types6,valid?R108,v11,arbace.core6,internv11,arbace.core9,with-metaR109,R110,R111,v21,arbace.go.check.types9,exported?v14,arbace.go.repl12,const-arbaceR112,v14,arbace.go.repl12,check-sourcev14,arbace.go.repl7,define!m2,R79,TR113,R114,v14,arbace.go.repl5,call0v13,arbace.string7,replacev14,arbace.go.repl9,complete!v14,arbace.go.repl8,path->nsv11,arbace.core7,ns-namev11,arbace.core4,*ns*v14,arbace.go.repl10,decl-namesv11,arbace.core6,removeR115,R116,v11,arbace.core4,juxtR117,R118,v11,arbace.core6,mapcatv11,arbace.core8,find-varv11,arbace.core7,printlnv11,arbace.core4,sortv11,arbace.core5,*out*v11,arbace.core5,*err*R119,v14,arbace.go.repl10,eval-countv11,arbace.core3,incS2,s3,lets8,let-typev20,arbace.go.check.code15,statement-headsv11,arbace.core4,listR120,m2,R44,R121,R122,v11,arbace.core6,repeatR121,R123,v13,arbace.string9,includes?v11,arbace.core7,re-findp25,value of type \\(([^)]*)\\)p1,,V3,R34,s4,mainR72,v11,arbace.core6,pr-strv11,arbace.core12,*print-meta*v11,arbace.core14,*print-length*v11,arbace.core13,*print-level*v11,arbace.core22,*print-namespace-maps*p1,/p5,\\.go$v11,arbace.core6,vectorv11,arbace.core4,spitv14,arbace.go.repl9,form-textR124,ML2,R125,V3,R126,R2,R127,m4,R47,i612,R128,i48,R24,v11,arbace.core8,identityR15,R129,R130,R131,v11,arbace.core10,make-arrayC37,java.nio.file.attribute.FileAttributev11,arbace.core17,requiring-resolveR132,R133,R134,R135,R136,v11,arbace.core7,reversev11,arbace.core8,file-seqv14,arbace.go.repl19,interpreted-closurev14,arbace.go.repl14,write-package!R27,R137,R138,R139,")

var Lit_1 *jrt.String = jrt.Intern("/")

var Lit_2 *jrt.String = jrt.Intern("go/")

var Lit_3 *jrt.String = jrt.Intern(".")

var Lit_4 *jrt.String = jrt.Intern("_")

var Lit_5 *jrt.String = jrt.Intern("-")

var Lit_6 *jrt.String = jrt.Intern("arbace.go.repl$build_context$fn__794000173")

var Lit_7 *jrt.String = jrt.Intern("arbace.go.repl$build_context$fn__794000175")

var Lit_8 *jrt.String = jrt.Intern("arbace.go.repl$build_context$fn__794000177")

var Lit_9 *jrt.String = jrt.Intern("arbace.go.repl$build_context$fn__794000179")

var Lit_10 *jrt.String = jrt.Intern("arbace.go.repl$build_context$fn__794000181")

var Lit_11 *jrt.String = jrt.Intern("goi: no function ")

var Lit_12 *jrt.String = jrt.Intern("goi: no method ")

var Lit_13 *jrt.String = jrt.Intern("goi: no variable ")

var Lit_14 *jrt.String = jrt.Intern("InterpCallable")

var Lit_15 *jrt.String = jrt.Intern("TFunc")

var Lit_16 *jrt.String = jrt.Intern("Go check errors in package ")

var Lit_17 *jrt.String = jrt.Intern(":\n")

var Lit_18 *jrt.String = jrt.Intern("init")

var Lit_19 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$targets__794000062")

var Lit_20 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$group_QMARK___794000064")

var Lit_21 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$specs__794000066")

var Lit_22 *jrt.String = jrt.Intern("go/type")

var Lit_23 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$iter__794000069__794000073")

var Lit_24 *jrt.String = jrt.Intern("go/func")

var Lit_25 *jrt.String = jrt.Intern("go/const")

var Lit_26 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$iter__794000085__794000091")

var Lit_27 *jrt.String = jrt.Intern("go/var")

var Lit_28 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$iter__794000104__794000110")

var Lit_29 *jrt.String = jrt.Intern("go/method")

var Lit_30 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$iter__794000069__794000073$fn__794000074")

var Lit_31 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$iter__794000069__794000073$fn__794000074$fn__794000075")

var Lit_32 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$iter__794000085__794000091$fn__794000092")

var Lit_33 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$iter__794000085__794000091$fn__794000092$iter__794000087__794000096")

var Lit_34 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$iter__794000085__794000091$fn__794000092$iter__794000087__794000096$fn__794000097")

var Lit_35 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$iter__794000085__794000091$fn__794000092$iter__794000087__794000096$fn__794000097$fn__794000098")

var Lit_36 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$iter__794000104__794000110$fn__794000111")

var Lit_37 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$iter__794000104__794000110$fn__794000111$iter__794000106__794000115")

var Lit_38 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$iter__794000104__794000110$fn__794000111$iter__794000106__794000115$fn__794000116")

var Lit_39 *jrt.String = jrt.Intern("arbace.go.repl$decl_names$iter__794000104__794000110$fn__794000111$iter__794000106__794000115$fn__794000116$fn__794000117")

var Lit_40 *jrt.String = jrt.Intern("values")

var Lit_41 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$fn__794000499")

var Lit_42 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$iter__794000501__794000505")

var Lit_43 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$fn__794000519")

var Lit_44 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$fn__794000521")

var Lit_45 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$fn__794000523")

var Lit_46 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$fn__794000525")

var Lit_47 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$own_QMARK___794000527")

var Lit_48 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$fn__794000529")

var Lit_49 *jrt.String = jrt.Intern("Go check errors:\n")

var Lit_50 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$fn__794000531")

var Lit_51 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$fn__794000535")

var Lit_52 *jrt.String = jrt.Intern("goi: warning: ")

var Lit_53 *jrt.String = jrt.Intern(" no longer check and keep their definitions:\n")

var Lit_54 *jrt.String = jrt.Intern(", ")

var Lit_55 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$iter__794000501__794000505$fn__794000506")

var Lit_56 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$iter__794000501__794000505$fn__794000506$fn__794000507")

var Lit_57 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$iter__794000501__794000505$fn__794000506$fn__794000513")

var Lit_58 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$iter__794000501__794000505$fn__794000506$fn__794000507$fn__794000508")

var Lit_59 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$iter__794000501__794000505$fn__794000506$fn__794000507$fn__794000508$fn__794000509")

var Lit_60 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_$iter__794000501__794000505$fn__794000506$fn__794000513$fn__794000514")

var Lit_61 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$gen_of__794000196")

var Lit_62 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000198")

var Lit_63 *jrt.String = jrt.Intern(" (GR6)")

var Lit_64 *jrt.String = jrt.Intern("generics")

var Lit_65 *jrt.String = jrt.Intern("not supported by goi yet: ")

var Lit_66 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000200")

var Lit_67 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000202__794000206")

var Lit_68 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000212")

var Lit_69 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000214")

var Lit_70 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000216__794000220")

var Lit_71 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000226__794000230")

var Lit_72 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000240__794000244")

var Lit_73 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fsrc__794000250")

var Lit_74 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000291__794000297")

var Lit_75 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000307__794000311")

var Lit_76 *jrt.String = jrt.Intern("SetCode")

var Lit_77 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000326")

var Lit_78 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000328")

var Lit_79 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000337")

var Lit_80 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000339")

var Lit_81 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000352")

var Lit_82 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000354")

var Lit_83 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000356")

var Lit_84 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000365")

var Lit_85 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000367")

var Lit_86 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000369")

var Lit_87 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000379")

var Lit_88 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000383")

var Lit_89 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000385__794000389")

var Lit_90 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000395")

var Lit_91 *jrt.String = jrt.Intern("FuncCell")

var Lit_92 *jrt.String = jrt.Intern("init.vars")

var Lit_93 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000397")

var Lit_94 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000410")

var Lit_95 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000418")

var Lit_96 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000430")

var Lit_97 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000437")

var Lit_98 *jrt.String = jrt.Intern("GlobalPtr")

var Lit_99 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000461")

var Lit_100 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000463")

var Lit_101 *jrt.String = jrt.Intern("main")

var Lit_102 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000328$fn__794000329")

var Lit_103 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000339$fn__794000340")

var Lit_104 *jrt.String = jrt.Intern("methods of generic types")

var Lit_105 *jrt.String = jrt.Intern("GR6")

var Lit_106 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000356$fn__794000357")

var Lit_107 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000369$fn__794000370")

var Lit_108 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$fn__794000397$fn__794000398")

var Lit_109 *jrt.String = jrt.Intern("FuncSource")

var Lit_110 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000202__794000206$fn__794000207")

var Lit_111 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000202__794000206$fn__794000207$fn__794000208")

var Lit_112 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000216__794000220$fn__794000221")

var Lit_113 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000216__794000220$fn__794000221$fn__794000222")

var Lit_114 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000226__794000230$fn__794000231")

var Lit_115 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000226__794000230$fn__794000231$fn__794000232")

var Lit_116 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000226__794000230$fn__794000231$fn__794000236")

var Lit_117 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000226__794000230$fn__794000231$fn__794000232$fn__794000233")

var Lit_118 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000240__794000244$fn__794000245")

var Lit_119 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000240__794000244$fn__794000245$fn__794000246")

var Lit_120 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000291__794000297$fn__794000298")

var Lit_121 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000291__794000297$fn__794000298$iter__794000293__794000299")

var Lit_122 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000291__794000297$fn__794000298$iter__794000293__794000299$fn__794000300")

var Lit_123 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000291__794000297$fn__794000298$iter__794000293__794000299$fn__794000300$fn__794000301")

var Lit_124 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000307__794000311$fn__794000312")

var Lit_125 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000307__794000311$fn__794000312$fn__794000313")

var Lit_126 *jrt.String = jrt.Intern("NewGlobal")

var Lit_127 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000385__794000389$fn__794000390")

var Lit_128 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_$iter__794000385__794000389$fn__794000390$fn__794000391")

var Lit_129 *jrt.String = jrt.Intern("repl.go")

var Lit_130 *jrt.String = jrt.Intern("\n")

var Lit_131 *jrt.String = jrt.Intern("arbace.go.repl$error_text$iter__794000124__794000128")

var Lit_132 *jrt.String = jrt.Intern("arbace.go.repl$error_text$iter__794000124__794000128$fn__794000129")

var Lit_133 *jrt.String = jrt.Intern("arbace.go.repl$error_text$iter__794000124__794000128$fn__794000129$fn__794000130")

var Lit_134 *jrt.String = jrt.Intern(":")

var Lit_135 *jrt.String = jrt.Intern(": ")

var Lit_136 *jrt.String = jrt.Intern("arbace.lang.GoInterp")

var Lit_137 *jrt.String = jrt.Intern("arbace.lang.GoFn")

var Lit_138 *jrt.String = jrt.Intern("arbace.lang.GoVar")

var Lit_139 *jrt.String = jrt.Intern("arbace.lang.GoType")

var Lit_140 *jrt.String = jrt.Intern("arbace.lang.Namespace")

var Lit_141 *jrt.String = jrt.Intern("java.io.File")

var Lit_142 *jrt.String = jrt.Intern("go.")

var Lit_143 *jrt.String = jrt.Intern("goi_eval")

var Lit_144 *jrt.String = jrt.Intern("arbace.go.repl$eval_BANG_$fn__794000553")

var Lit_145 *jrt.String = jrt.Intern("arbace.go.repl$eval_BANG_$attempt__794000555")

var Lit_146 *jrt.String = jrt.Intern("arbace.go.repl$eval_BANG_$fn__794000561")

var Lit_147 *jrt.String = jrt.Intern("arbace.go.repl$eval_BANG_$fn__794000563")

var Lit_148 *jrt.String = jrt.Intern("arbace.go.repl$eval_BANG_$fn__794000568")

var Lit_149 *jrt.String = jrt.Intern("arbace.go.repl$eval_BANG_$fn__794000570")

var Lit_150 *jrt.String = jrt.Intern("arbace.go.repl$eval_BANG_$fn__794000574")

var Lit_151 *jrt.String = jrt.Intern("arbace.go.repl$eval_BANG_$attempt__794000555$fn__794000556")

var Lit_152 *jrt.String = jrt.Intern("arbace.go.repl$eval_BANG_$attempt__794000555$fn__794000558")

var Lit_153 *jrt.String = jrt.Intern("multiple-value")

var Lit_154 *jrt.String = jrt.Intern("(no value) used as value")

var Lit_155 *jrt.String = jrt.Intern("arbace.go.repl$file_BANG_$fn__794000053")

var Lit_156 *jrt.String = jrt.Intern("arbace.go.repl$file_entry$fn__794000040")

var Lit_157 *jrt.String = jrt.Intern("fmt")

var Lit_158 *jrt.String = jrt.Intern("arbace.go.repl$fn__794000024$fn__794000025")

var Lit_159 *jrt.String = jrt.Intern("arbace.go.repl$fn__794000028$fn__794000029")

var Lit_160 *jrt.String = jrt.Intern("go/import in a package being loaded: a file's imports are its go/file's")

var Lit_161 *jrt.String = jrt.Intern("arbace.go.repl$import_BANG_$fn__794000057")

var Lit_162 *jrt.String = jrt.Intern("arbace.go.repl$import_BANG_$fn__794000057$fn__794000058")

var Lit_163 *jrt.String = jrt.Intern("arbace.go.repl$interpreted_closure$iter__794000611__794000617")

var Lit_164 *jrt.String = jrt.Intern("arbace.go.repl$interpreted_closure$iter__794000611__794000617$fn__794000618")

var Lit_165 *jrt.String = jrt.Intern("arbace.go.repl$interpreted_closure$iter__794000611__794000617$fn__794000618$iter__794000613__794000619")

var Lit_166 *jrt.String = jrt.Intern("arbace.go.repl$interpreted_closure$iter__794000611__794000617$fn__794000618$iter__794000613__794000619$fn__794000620")

var Lit_167 *jrt.String = jrt.Intern("arbace.go.repl$interpreted_closure$iter__794000611__794000617$fn__794000618$iter__794000613__794000619$fn__794000620$fn__794000621")

var Lit_168 *jrt.String = jrt.Intern("arbace.go.repl$load_import$fn__794000487")

var Lit_169 *jrt.String = jrt.Intern("(*")

var Lit_170 *jrt.String = jrt.Intern(").")

var Lit_171 *jrt.String = jrt.Intern("Go declarations belong in a go.* namespace (")

var Lit_172 *jrt.String = jrt.Intern(" is not one)")

var Lit_173 *jrt.String = jrt.Intern("the package ")

var Lit_174 *jrt.String = jrt.Intern(" is a compiled package of the table: it cannot be interpreted (S1)")

var Lit_175 *jrt.String = jrt.Intern("NO_SOURCE_PATH")

var Lit_176 *jrt.String = jrt.Intern("NO_SOURCE_FILE")

var Lit_177 *jrt.String = jrt.Intern("REPL")

var Lit_178 *jrt.String = jrt.Intern(" is not an interpreted Go package")

var Lit_179 *jrt.String = jrt.Intern("goi-run-compiled")

var Lit_180 *jrt.String = jrt.Intern("src")

var Lit_181 *jrt.String = jrt.Intern("prog")

var Lit_182 *jrt.String = jrt.Intern("ARBACE_GOROOT")

var Lit_183 *jrt.String = jrt.Intern("/root/tamago-go")

var Lit_184 *jrt.String = jrt.Intern("amd64")

var Lit_185 *jrt.String = jrt.Intern("work")

var Lit_186 *jrt.String = jrt.Intern("go/run-compiled: go build of ")

var Lit_187 *jrt.String = jrt.Intern(" failed (status ")

var Lit_188 *jrt.String = jrt.Intern(")")

var Lit_189 *jrt.String = jrt.Intern(" has no main")

var Lit_190 *jrt.String = jrt.Intern("arbace.go.repl$session_for$fn__794000147")

var Lit_191 *jrt.String = jrt.Intern("arbace.go.repl$session_for$fn__794000149")

var Lit_192 *jrt.String = jrt.Intern("arbace.go.repl$source_of$iter__794000136__794000140")

var Lit_193 *jrt.String = jrt.Intern("arbace.go.repl$source_of$iter__794000136__794000140$fn__794000141")

var Lit_194 *jrt.String = jrt.Intern("arbace.go.repl$source_of$iter__794000136__794000140$fn__794000141$fn__794000142")

var Lit_195 *jrt.String = jrt.Intern("arbace.go.repl$type_key$fn__794000159")

var Lit_196 *jrt.String = jrt.Intern("arbace.go.repl$type_key$fn__794000161")

var Lit_197 *jrt.String = jrt.Intern("arbace.go.repl$type_key$fn__794000163")

var Lit_198 *jrt.String = jrt.Intern("arbace.go.repl$type_key$fn__794000165")

var Lit_199 *jrt.String = jrt.Intern("arbace.go.repl$type_key$fn__794000167")

var Lit_200 *jrt.String = jrt.Intern("arbace.go.repl$update_file$fn__794000045")

var Lit_201 *jrt.String = jrt.Intern("arbace.go.repl$update_file$fn__794000045$fn__794000046")

var Lit_202 *jrt.String = jrt.Intern("arbace.go.repl$update_file$fn__794000045$fn__794000048")

var Lit_203 *jrt.String = jrt.Intern("arbace.go.repl$write_package_BANG_$iter__794000580__794000584")

var Lit_204 *jrt.String = jrt.Intern(".ae")

var Lit_205 *jrt.String = jrt.Intern("arbace.go.repl$write_package_BANG_$iter__794000590__794000594")

var Lit_206 *jrt.String = jrt.Intern("\n\n")

var Lit_207 *jrt.String = jrt.Intern("arbace.go.repl$write_package_BANG_$iter__794000580__794000584$fn__794000585")

var Lit_208 *jrt.String = jrt.Intern("arbace.go.repl$write_package_BANG_$iter__794000580__794000584$fn__794000585$fn__794000586")

var Lit_209 *jrt.String = jrt.Intern("")

var Lit_210 *jrt.String = jrt.Intern("arbace.go.repl$write_package_BANG_$iter__794000590__794000594$fn__794000595")

var Lit_211 *jrt.String = jrt.Intern("arbace.go.repl$write_package_BANG_$iter__794000590__794000594$fn__794000595$fn__794000596")

var Lit_212 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn4,linekn6,columnkn4,filekn8,arglistsyn1,pkn3,tagyn6,Stringyn7,ns-nameyn4,pathyn2,nmyn6,ns-symyn7,create?yn4,optsyn2,styn5,fnameyn1,fyn5,specsyn4,errsyn3,srckn8,declaredyn9,extra-srcyn2,tyyn6,gen-ofyn1,myn1,vyn1,rkn4,keysyn5,vars?yn5,eageryn4,onlyyn10,kept-namesyn10,init-namesyn2,okyn4,formyn2,nsyn4,lineyn5,stmtsyn4,Fileyn4,argsv11,arbace.core5,in-nsMyn14,arbace.go.replm2,R0,s778,goi's REPL state (doc/go/GOI-SPEC.md §2): interpreted Go packages as namespaces, their files\n  and declarations, checking (arbace.go.check) against the table's digest and the other\n  interpreted packages, defining their vars (functions, variables, constants, types and their\n  generations), loading packages from ARBACE_PATH (the declarations queued, the package checked\n  when its package file's load ends: S6), initialization, go/eval, and running a program in\n  program mode (bin/goi run: arbace.go.run).\n\n  A package's state is an atom {:path :name :ns :config :files [{:name :imports :decls}]\n  :current (the REPL's file) :loading (the package file being loaded) :funcs {name *Func}\n  :globals {name {:ptr :key}} :types {name {:gen :key :desc}} :checked (the last result)}.m2,R0,s778,goi's REPL state (doc/go/GOI-SPEC.md §2): interpreted Go packages as namespaces, their files\n  and declarations, checking (arbace.go.check) against the table's digest and the other\n  interpreted packages, defining their vars (functions, variables, constants, types and their\n  generations), loading packages from ARBACE_PATH (the declarations queued, the package checked\n  when its package file's load ends: S6), initialization, go/eval, and running a program in\n  program mode (bin/goi run: arbace.go.run).\n\n  A package's state is an atom {:path :name :ns :config :files [{:name :imports :decls}]\n  :current (the REPL's file) :loading (the package file being loaded) :funcs {name *Func}\n  :globals {name {:ptr :key}} :types {name {:gen :key :desc}} :checked (the last result)}.R1,v14,arbace.go.repl6,listedm8,R2,TR3,i26,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl7,listed?m10,R6,L1,V1,R7,R0,s76,Whether import path p is a package of the table of compiled packages (§6.6).R3,i28,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl12,digest-indexm8,R2,TR3,i33,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl12,digest-formsm10,R6,L1,V1,R7,R0,s78,The digest's forms of listed package p (§6.5), read with line numbers, or nil.R3,i39,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl6,configm8,R3,i46,R4,i1,R5,s17,arbace/go/repl.aeR0,s78,The program's configuration (:goos, :goarch), as the digest's packages say it.v14,arbace.go.repl14,digest-sessionm10,R2,TR3,i54,R4,i1,R5,s17,arbace/go/repl.aeR0,s85,The checking session of the table's packages, read from the digest (one per process).v14,arbace.go.repl8,packagesm8,R0,s63,The interpreted packages by import path: atoms of their states.R3,i64,R4,i1,R5,s17,arbace/go/repl.aev11,arbace.core4,atomm8,R0,s63,The interpreted packages by import path: atoms of their states.R3,i64,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl8,path->nsm10,R6,L1,V1,Myn1,pm2,R8,R9,R0,s46,The namespace of import path p (SPEC.md §4.1).R3,i66,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl8,ns->pathm10,R6,L1,V1,R10,R0,s82,The import path of a go.* namespace name (S2): the segments after go. joined by /.R3,i71,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl9,new-statem10,R2,TR6,L1,V3,R11,R12,R13,R3,i76,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl13,package-statem10,R6,L2,V1,R13,V2,R13,R14,R0,s88,The state of the package of namespace ns-sym, made implicitly (S2) for a go.* namespace.R3,i80,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl8,package!m10,R6,L1,V3,R13,R12,R15,R0,s95,go/package: the namespace's package (its name, :path, :files ...); in a load, the load's start.R3,i96,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl10,file-entrym10,R2,TR6,L1,V2,R16,R17,R3,i109,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl11,update-filem10,R2,TR6,L1,V3,R16,R17,R18,R3,i112,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl5,file!m10,R6,L1,V3,R13,R17,R15,R0,s65,go/file: the namespace's current file, its imports replaced (S5).R3,i119,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl7,import!m10,R6,L1,V2,R13,R19,R0,s67,go/import at the REPL: import specs added to the current file (S5).R3,i128,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl10,decl-namesm12,R2,TR6,L1,V1,R18,R0,s67,The package-level names a declaration form declares (methods: T.M).R3,i139,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl10,error-textm12,R2,TR6,L2,V1,R20,V2,R20,R21,R0,s142,Errors as go/types words them (§3.8): FILE:LINE: MESSAGE, at most ten; the REPL's implicit\n  file is the forms' source (REPL for typed forms).R3,i167,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl11,repl-sourcem10,R2,TR6,L1,V0,R3,i175,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl9,source-ofm10,R6,L1,V1,R16,R0,s67,The checker's source of package state st (its files as they stand).R3,i177,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl11,load-importm8,R22,TR3,i186,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl11,session-form12,R2,TR6,L1,V1,R23,R0,s161,A checking session for an interpreted package: listed imports from the digest, interpreted\n  ones from their states (loaded from ARBACE_PATH when not yet: §2.3).R3,i188,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl12,check-sourcem10,R6,L1,V2,R21,R23,R0,s71,Checks src: the package's result (with its trees), its errors included.R3,i199,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl8,type-keym12,R2,TR6,L1,V2,R24,R25,R0,s137,The structure of a type, its interpreted named types by name and generation (a named type's\n  generation is new when this changes: §2.5).R3,i208,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl13,state-of-pathm10,R2,TR6,L1,V1,R7,R3,i225,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl11,method-namem10,R6,L1,V1,R26,R0,s77,Method object m's name as gc names it: T.M, or (*T).M for a pointer receiver.R3,i227,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl12,display-filem12,R2,TR6,L1,V1,R17,R0,s176,The file a frame of a declaration of Go file fname shows in traces (§10.6): the Go file of\n  converted forms, the forms' source for the REPL's implicit file (REPL at the REPL).R3,i233,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl13,build-contextm10,R6,L1,V1,R16,R0,s50,The builder's context for the package of state st.R3,i239,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl12,const-arbacem12,R2,TR6,L1,V2,R24,R27,R0,s45,A constant's value as Arbace takes it (§5.6).R3,i265,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl7,define!m10,R6,L1,V3,R16,R28,m2,R29,V5,R30,R31,R32,R33,R34,R0,s367,Defines the checked package result r in state st: function cells (their code built on first\n  call, S18, or now when eager), variables' cells, types' generations; with vars?, the\n  namespace's vars (§2.1). Returns {:inits (the initializers' code in order, a *goi.Func) :init-funcs\n  (init cells in order) :main (cell or nil) :new-vars (names of variables made anew)}.R3,i277,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl5,call0m10,R6,L1,V2,R18,Myn2,nmm2,R8,R9,R0,s87,Calls function cell f of no parameters and no results from Arbace (a panic: a GoPanic).R3,i420,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl9,complete!m12,R2,TR6,L1,V1,R16,R0,s141,Completes package state st after its load: checked whole (a CompilerException-like error\n  listing every error), defined, initialized (§2.6).R3,i426,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl10,after-loadm10,R6,L1,V2,Myn4,pathm2,R8,R9,R35,R0,s184,arbace.core/load's hook (§2.3, S6): the load of a resource (path, as load names it) ended\n  (ok: normally); a package whose package file it was is completed (a failed load forgets it).R3,i441,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl15,hook-registeredm8,R2,TR3,i454,R4,i1,R5,s17,arbace/go/repl.aem8,R2,TR3,i454,R4,i1,R5,s17,arbace/go/repl.aev11,arbace.core5,swap!v11,arbace.core4,conjm10,R6,L1,V1,R11,R0,s115,The state of interpreted package path, loaded from ARBACE_PATH (its namespace) when it is\n  not yet (§2.3), or nil.R3,i457,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl8,declare!m10,R6,L1,V2,R36,m2,R29,V2,R37,R38,R0,s165,A declaration macro's form (go/func, go/var ...): queued in a load, else checked against the\n  package and defined at once (§2.5); returns the var of its first name.R3,i472,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl10,eval-countl0,m8,R2,TR3,i522,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl5,eval!m10,R6,L1,V2,R39,m2,R29,V1,R37,R0,s156,go/eval: Go statements run as the body of a function of the namespace's package (go.user\n  outside go.*: S3); the last statement's value as Arbace's (§5.6).R3,i524,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl9,run-main!m10,R6,L1,V1,R13,R0,s95,go/run-main: package ns-sym's main (program mode's exit semantics in the REPL's process: §2.6).R3,i576,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl6,check!m10,R6,L1,V1,R13,R0,s70,go/check: the package's errors, checked again (data), nothing defined.R3,i586,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl9,form-textm12,R2,TR6,L1,V1,R18,R0,s74,Form f as readable text with its metadata (the forms root build/go reads).R3,i594,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl14,write-package!m12,R2,TR6,L1,V2,Myn3,dirm2,R8,R40,R16,R0,s94,Writes package state st as a forms root's package file and its files under dir (SPEC.md §4.1).R3,i600,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl19,interpreted-closurem12,R2,TR6,L1,V1,R16,R0,s71,Package state st and the interpreted packages it imports, transitively.R3,i625,R4,i1,R5,s17,arbace/go/repl.aev14,arbace.go.repl13,run-compiled!m10,R6,L1,V2,R13,R41,R0,s324,go/run-compiled: package ns-sym's program (it and the interpreted packages it imports) as\n  Go forms, printed by repr/go and built by build/go (arbace.build.go) with the toolchain of\n  ARBACE_GOROOT (default /root/tamago-go), run with args as a child process (G15):\n  {:out :err :exit}; a build that fails throws its status.R3,i638,R4,i1,R5,s17,arbace/go/repl.ae")

var Lit_213 *jrt.String = jrt.Intern("arbace.go.repl$eval794000004$loading__1927001464__auto____794000005")

var Lit_214 *jrt.String = jrt.Intern("arbace.go.repl$eval794000008$fn__794000009")

var Lit_215 *jrt.String = jrt.Intern("arbace.go.repl$fn__794000012")

var Lit_216 *jrt.String = jrt.Intern("arbace.go.repl$listed_QMARK_")

var Lit_217 *jrt.String = jrt.Intern("arbace.go.repl$fn__794000015")

var Lit_218 *jrt.String = jrt.Intern("arbace.go.repl$digest_forms")

var Lit_219 *jrt.String = jrt.Intern("arbace.go.repl$fn__794000024")

var Lit_220 *jrt.String = jrt.Intern("arbace.go.repl$fn__794000028")

var Lit_221 *jrt.String = jrt.Intern("arbace.go.repl$path__GT_ns")

var Lit_222 *jrt.String = jrt.Intern("arbace.go.repl$ns__GT_path")

var Lit_223 *jrt.String = jrt.Intern("arbace.go.repl$new_state")

var Lit_224 *jrt.String = jrt.Intern("arbace.go.repl$package_state")

var Lit_225 *jrt.String = jrt.Intern("arbace.go.repl$package_BANG_")

var Lit_226 *jrt.String = jrt.Intern("arbace.go.repl$file_entry")

var Lit_227 *jrt.String = jrt.Intern("arbace.go.repl$update_file")

var Lit_228 *jrt.String = jrt.Intern("arbace.go.repl$file_BANG_")

var Lit_229 *jrt.String = jrt.Intern("arbace.go.repl$import_BANG_")

var Lit_230 *jrt.String = jrt.Intern("arbace.go.repl$decl_names")

var Lit_231 *jrt.String = jrt.Intern("arbace.go.repl$error_text")

var Lit_232 *jrt.String = jrt.Intern("arbace.go.repl$repl_source")

var Lit_233 *jrt.String = jrt.Intern("arbace.go.repl$source_of")

var Lit_234 *jrt.String = jrt.Intern("arbace.go.repl$session_for")

var Lit_235 *jrt.String = jrt.Intern("arbace.go.repl$check_source")

var Lit_236 *jrt.String = jrt.Intern("arbace.go.repl$type_key")

var Lit_237 *jrt.String = jrt.Intern("arbace.go.repl$state_of_path")

var Lit_238 *jrt.String = jrt.Intern("arbace.go.repl$method_name")

var Lit_239 *jrt.String = jrt.Intern("arbace.go.repl$display_file")

var Lit_240 *jrt.String = jrt.Intern("arbace.go.repl$build_context")

var Lit_241 *jrt.String = jrt.Intern("arbace.go.repl$const_arbace")

var Lit_242 *jrt.String = jrt.Intern("arbace.go.repl$define_BANG_")

var Lit_243 *jrt.String = jrt.Intern("arbace.go.repl$call0")

var Lit_244 *jrt.String = jrt.Intern("arbace.go.repl$complete_BANG_")

var Lit_245 *jrt.String = jrt.Intern("arbace.go.repl$after_load")

var Lit_246 *jrt.String = jrt.Intern("arbace.go.repl$load_import")

var Lit_247 *jrt.String = jrt.Intern("arbace.go.repl$declare_BANG_")

var Lit_248 *jrt.String = jrt.Intern("arbace.go.repl$eval_BANG_")

var Lit_249 *jrt.String = jrt.Intern("arbace.go.repl$run_main_BANG_")

var Lit_250 *jrt.String = jrt.Intern("arbace.go.repl$check_BANG_")

var Lit_251 *jrt.String = jrt.Intern("arbace.go.repl$form_text")

var Lit_252 *jrt.String = jrt.Intern("arbace.go.repl$write_package_BANG_")

var Lit_253 *jrt.String = jrt.Intern("arbace.go.repl$interpreted_closure")

var Lit_254 *jrt.String = jrt.Intern("arbace.go.repl$run_compiled_BANG_")
