//line aot_arbace_go_repl.ae:1
package aot_arbace_go_repl

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_build"
	"arbace/aot_arbace_go_check"
	"arbace/aot_arbace_go_check_code"
	"arbace/aot_arbace_go_check_const"
	"arbace/aot_arbace_go_check_env"
	"arbace/aot_arbace_go_check_load"
	"arbace/aot_arbace_go_check_types"
	"arbace/aot_arbace_repr_go_print"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_repl_eval794000004_loading__1927001464__auto____794000005_A_New() *A_arbace_go_repl_eval794000004_loading__1927001464__auto____794000005_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_eval794000004_loading__1927001464__auto____794000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_repl_eval794000004_loading__1927001464__auto____794000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_repl_eval794000004_loading__1927001464__auto____794000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_repl_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_repl_A_const_1); lang.IFn_Cast(A_arbace_go_repl_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O__O(A_arbace_go_repl_A_const_3, A_arbace_go_repl_A_const_4, A_arbace_go_repl_A_const_5, A_arbace_go_repl_A_const_6, A_arbace_go_repl_A_const_7, A_arbace_go_repl_A_const_8, A_arbace_go_repl_A_const_9, A_arbace_go_repl_A_const_10, A_arbace_go_repl_A_const_11); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_116)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_117)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_118)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_119)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_120)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_121)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_repl_eval794000008_fn__794000009_A_New() *A_arbace_go_repl_eval794000008_fn__794000009_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_eval794000008_fn__794000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_repl_eval794000008_fn__794000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_repl_eval794000008_fn__794000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_12.GetRawRoot__O()); var tmp2 any; var root_23 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_25 lang.IFn; if linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = A_arbace_go_repl_A_const_14; if linked_24 == nil { tmp2 = ifn_25.Invoke_O__O(arg_26) } else { tmp2 = linked_24.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_23, arg_26) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_repl_A_const_15.GetRawRoot__O(), A_arbace_go_repl_A_const_16) }
























func A_arbace_go_repl_fn__794000012_A_New() *A_arbace_go_repl_fn__794000012_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_fn__794000012_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_go_repl_fn__794000012_A) Ctor() {}
//line :26:1
func (t *A_arbace_go_repl_fn__794000012_A) Invoke_O__O(self any) any { var root_27 any = A_arbace_go_repl_A_const_17.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = lang.GoInterp_Paths__O1().Ref(); if linked_28 == nil { return ifn_29.Invoke_O__O(arg_30) } else { return linked_28.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_27, arg_30) } }

func A_arbace_go_repl_listed_QMARK__A_New() *A_arbace_go_repl_listed_QMARK__A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_listed_QMARK__A{}; t.Ctor(); return t }
//line :28:1
func (t *A_arbace_go_repl_listed_QMARK__A) Ctor() {}
//line :28:1
func (t *A_arbace_go_repl_listed_QMARK__A) Invoke_O_O__O(self, p__0 any) any {


	var root_31 any = A_arbace_go_repl_A_const_18.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any; var root_36 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = A_arbace_go_repl_A_const_19.GetRawRoot__O(); if linked_37 == nil { arg_34 = ifn_38.Invoke_O__O(arg_39) } else { arg_34 = linked_37.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_36, arg_39) }; var arg_35 any = p__0; if linked_32 == nil { return ifn_33.Invoke_O_O__O(arg_34, arg_35) } else { return linked_32.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_31, arg_34, arg_35)
	}
}
func A_arbace_go_repl_fn__794000015_A_New() *A_arbace_go_repl_fn__794000015_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_fn__794000015_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_go_repl_fn__794000015_A) Ctor() {}
//line :34:1
func (t *A_arbace_go_repl_fn__794000015_A) Invoke_O__O(self any) any { var temp__1927000414__auto____1 any = lang.GoInterp_Digest__String().Ref(); if
									jrt.J2g_Truth(temp__1927000414__auto____1) { var s__2 any = temp__1927000414__auto____1; var nl__3 int32 = jrt.NN(jrt.String_Cast(s__2)).IndexOf_String__I(Lit_109); var tmp1 any = A_arbace_go_repl_A_const_20; var tmp2 any; var root_40 any = A_arbace_go_repl_A_const_21.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_42 lang.IFn

		if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any; var root_44 any = A_arbace_go_repl_A_const_22.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_44, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_46 lang.IFn; if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any = s__2; var arg_48 any = A_arbace_go_repl_A_const_23; var arg_49 any = jrt.Integer_ValueOf_I__Integer_NoInit(nl__3).Ref(); if linked_45 == nil { arg_43 = ifn_46.Invoke_O_O_O__O(arg_47, arg_48, arg_49) } else { arg_43 = linked_45.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_44, arg_47, arg_48, arg_49) }; if linked_41 == nil { tmp2 = ifn_42.Invoke_O__O(arg_43) } else { tmp2 = linked_41.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_40, arg_43) }
//line :35:1
		var tmp3 any = tmp2; var tmp4 any = A_arbace_go_repl_A_const_24; var tmp5 any = A_arbace_go_repl_A_const_25; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, tmp4, s__2, tmp5, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(nl__3))).Ref())) } else { return nil } }



func A_arbace_go_repl_digest_forms_A_New() *A_arbace_go_repl_digest_forms_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_digest_forms_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_go_repl_digest_forms_A) Ctor() {}
//line :39:1
func (t *A_arbace_go_repl_digest_forms_A) Invoke_O_O__O(self, p__0 any) any { var temp__1927000414__auto____2 any; var root_50 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_52 lang.IFn; if


	linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = A_arbace_go_repl_A_const_26.GetRawRoot__O(); if linked_51 == nil { temp__1927000414__auto____2 = ifn_52.Invoke_O__O(arg_53) } else { temp__1927000414__auto____2 = linked_51.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_50, arg_53) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var map__794000017__3 any = temp__1927000414__auto____2; var map__794000017__4 any; if lang.ISeq_InstanceOf(map__794000017__3) { var tmp1 any; var root_54 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = map__794000017__3; if linked_55 == nil { tmp1 = ifn_56.Invoke_O__O(arg_57) } else { tmp1 = linked_55.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_54, arg_57) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_58 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = map__794000017__3; if linked_59 == nil { tmp2 = ifn_60.Invoke_O__O(arg_61) } else { tmp2 = linked_59.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_58, arg_61) }; map__794000017__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_62 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_64 lang.IFn; if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any = map__794000017__3; if linked_63 == nil { tmp3 = ifn_64.Invoke_O__O(arg_65) } else { tmp3 = linked_63.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_62, arg_65) }; if jrt.J2g_Truth(tmp3) { var root_66 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = map__794000017__3; if linked_67 == nil { map__794000017__4 = ifn_68.Invoke_O__O(arg_69) } else { map__794000017__4 = linked_67.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_66, arg_69) } } else { map__794000017__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000017__4 = map__794000017__3 }; var index__5 any = lang.RT_Get_O_O__O_NoInit(map__794000017__4, A_arbace_go_repl_A_const_20); var text__6 any = lang.RT_Get_O_O__O_NoInit(map__794000017__4, A_arbace_go_repl_A_const_24); var start__7 any = lang.RT_Get_O_O__O_NoInit(map__794000017__4, A_arbace_go_repl_A_const_25); var temp__1927000414__auto____8 any = lang.RT_Get_O_O__O_NoInit(index__5, p__0)
		if jrt.J2g_Truth(temp__1927000414__auto____8) { var vec__794000019__9 any = temp__1927000414__auto____8; var a__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000019__9, lang.RT_IntCast_J__I_NoInit(0), nil); var b__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000019__9, lang.RT_IntCast_J__I_NoInit(1), nil); var root_70 any = A_arbace_go_repl_A_const_31.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_go_check.A_arbace_go_check_read_string_forms_A_fn_class); var ifn_72 lang.IFn
			if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any; var root_74 any = A_arbace_go_repl_A_const_22.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_76 lang.IFn; if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any = text__6; var arg_78 any; var na_80 any = start__7; var na_81 any = a__10; var tmp4 bool; var tmp5 bool; tmp5 = jrt.Long_InstanceOf(na_80); if tmp5 { tmp5 = jrt.Long_InstanceOf(na_81) }; tmp4 = tmp5; if tmp4 { var n0_82 int64 = jrt.NN(jrt.Long_Cast(na_80)).LongValue__J(); var n1_83 int64 = jrt.NN(jrt.Long_Cast(na_81)).LongValue__J(); var nr_84 int64 = n0_82 + n1_83; if (n0_82^nr_84)&(n1_83^nr_84) >= 0 { arg_78 = jrt.Long_ValueOf_J__Long_NoInit(nr_84).Ref() } else { arg_78 = lang.Numbers_Add_O_O__Number_NoInit(na_80, na_81) } } else { var tmp6 bool; var tmp7 bool; tmp7 = jrt.Double_InstanceOf(na_80); if tmp7 { tmp7 = jrt.Double_InstanceOf(na_81) }; tmp6 = tmp7; if tmp6 { var n0_82_2 float64 = jrt.NN(jrt.Double_Cast(na_80)).DoubleValue__D(); var n1_83_2 float64 = jrt.NN(jrt.Double_Cast(na_81)).DoubleValue__D(); arg_78 = jrt.Double_ValueOf_D__Double_NoInit(n0_82_2 + n1_83_2).Ref() } else { arg_78 = lang.Numbers_Add_O_O__Number_NoInit(na_80, na_81) } }; var arg_79 any; var na_85 any = start__7; var na_86 any = b__11; var tmp8 bool; var tmp9 bool; tmp9 = jrt.Long_InstanceOf(na_85); if tmp9 { tmp9 = jrt.Long_InstanceOf(na_86) }; tmp8 = tmp9; if tmp8 { var n0_87 int64 = jrt.NN(jrt.Long_Cast(na_85)).LongValue__J(); var n1_88 int64 = jrt.NN(jrt.Long_Cast(na_86)).LongValue__J(); var nr_89 int64 = n0_87 + n1_88; if (n0_87^nr_89)&(n1_88^nr_89) >= 0 { arg_79 = jrt.Long_ValueOf_J__Long_NoInit(nr_89).Ref() } else { arg_79 = lang.Numbers_Add_O_O__Number_NoInit(na_85, na_86) } } else { var tmp10 bool; var tmp11 bool; tmp11 = jrt.Double_InstanceOf(na_85); if tmp11 { tmp11 = jrt.Double_InstanceOf(na_86) }; tmp10 = tmp11; if tmp10 { var n0_87_2 float64 = jrt.NN(jrt.Double_Cast(na_85)).DoubleValue__D(); var n1_88_2 float64 = jrt.NN(jrt.Double_Cast(na_86)).DoubleValue__D(); arg_79 = jrt.Double_ValueOf_D__Double_NoInit(n0_87_2 + n1_88_2).Ref() } else { arg_79 = lang.Numbers_Add_O_O__Number_NoInit(na_85, na_86) } }; if linked_75 == nil { arg_73 = ifn_76.Invoke_O_O_O__O(arg_77, arg_78, arg_79) } else { arg_73 = linked_75.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_74, arg_77, arg_78, arg_79) }; if linked_71 == nil { return ifn_72.Invoke_O__O(arg_73) } else { return linked_71.(*aot_arbace_go_check.A_arbace_go_check_read_string_forms_A).Invoke_O_O__O(root_70, arg_73) } } else {
//line :43:1
				return nil } } else {
//line :42:1
					return nil } }





func A_arbace_go_repl_fn__794000024_A_New() *A_arbace_go_repl_fn__794000024_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_fn__794000024_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_go_repl_fn__794000024_A) Ctor() {}
//line :48:1
func (t *A_arbace_go_repl_fn__794000024_A) Invoke_O__O(self any) any { var fs__1 any; var root_90 any = A_arbace_go_repl_A_const_32.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, A_arbace_go_repl_digest_forms_A_fn_class); var ifn_92 lang.IFn; if
									linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = Lit_137; if linked_91 == nil { fs__1 = ifn_92.Invoke_O__O(arg_93) } else { fs__1 = linked_91.(*A_arbace_go_repl_digest_forms_A).Invoke_O_O__O(root_90, arg_93) }; var gp__2 any; var root_94 any = /*line :48:1*/A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_96 lang.IFn; if

	linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any; var root_98 any = A_arbace_go_repl_A_const_33.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any; var tmp1 any = A_arbace_go_repl_fn__794000024_fn__794000025_A_New(); var tmp2 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_go_repl_fn__794000024_fn__794000025_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_138, false); A_arbace_go_repl_fn__794000024_fn__794000025_A_fn_class = fncls__111d; tmp2 = fncls__111d } else { tmp2 = fncls__111 }; arg_101 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_102 any = fs__1; if linked_99 == nil { arg_97 = ifn_100.Invoke_O_O__O(arg_101, arg_102) } else { arg_97 = linked_99.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_98, arg_101, arg_102) }; if linked_95 == nil { gp__2 = ifn_96.Invoke_O__O(arg_97) } else { gp__2 = linked_95.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_94, arg_97) }; var cfg__3 any; var tmp3 /*line :48:1*/*lang.Keyword = A_arbace_go_repl_A_const_36; var tmp4 any; var root_112 any = A_arbace_go_repl_A_const_37.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_114 lang.IFn; if


	linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = A_arbace_go_repl_A_const_38.GetRawRoot__O(); var arg_116 any; var root_117 any = A_arbace_go_repl_A_const_39.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = gp__2; if linked_118 == nil { arg_116 = ifn_119.Invoke_O__O(arg_120) } else { arg_116 = linked_118.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_117, arg_120) }; if linked_113 == nil { tmp4 = ifn_114.Invoke_O_O__O(arg_115, arg_116) } else { tmp4 = linked_113.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_112, arg_115, arg_116) }; cfg__3 = tmp3.Invoke_O__O(tmp4); var root_121 any =
	A_arbace_go_repl_A_const_40.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_121, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = A_arbace_go_repl_A_const_41; var arg_125 any = cfg__3; if linked_122 == nil { return ifn_123.Invoke_O_O__O(arg_124, arg_125) } else { return linked_122.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_121, arg_124, arg_125) } }
//line :50:1
func A_arbace_go_repl_fn__794000024_fn__794000025_A_New() *A_arbace_go_repl_fn__794000024_fn__794000025_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_fn__794000024_fn__794000025_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_go_repl_fn__794000024_fn__794000025_A) Ctor() {}
//line :50:1
func (t *A_arbace_go_repl_fn__794000024_fn__794000025_A) Invoke_O_O__O(self, p1__794000023_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_103 any = A_arbace_go_repl_A_const_34.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = p1__794000023_SHARP___1; if linked_104 == nil { and__1927000168__auto____2 = ifn_105.Invoke_O__O(arg_106) } else { and__1927000168__auto____2 = linked_104.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_103, arg_106) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_repl_A_const_35; var tmp2 any; var root_107 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = p1__794000023_SHARP___1; if linked_108 == nil { tmp2 = ifn_109.Invoke_O__O(arg_110) } else { tmp2 = linked_108.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_107, arg_110) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() } else { return and__1927000168__auto____2 } }





func A_arbace_go_repl_fn__794000028_A_New() *A_arbace_go_repl_fn__794000028_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_fn__794000028_A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_go_repl_fn__794000028_A) Ctor() {}
//line :56:1
func (t *A_arbace_go_repl_fn__794000028_A) Invoke_O__O(self any) any {
	var root_126 any = A_arbace_go_repl_A_const_42.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, aot_arbace_go_check.A_arbace_go_check_session_A_fn_class); var ifn_128 lang.IFn; if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any; var tmp1 any = A_arbace_go_repl_fn__794000028_fn__794000029_A_New(); var tmp2 *jrt.Class; var fncls__147 *jrt.Class = A_arbace_go_repl_fn__794000028_fn__794000029_A_fn_class; if fncls__147 == nil { var fncls__147d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_139, false); A_arbace_go_repl_fn__794000028_fn__794000029_A_fn_class = fncls__147d; tmp2 = fncls__147d } else { tmp2 = fncls__147 }; arg_129 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_127 == nil { return ifn_128.Invoke_O__O(arg_129) } else { return linked_127.(*aot_arbace_go_check.A_arbace_go_check_session_A).Invoke_O_O__O(root_126, arg_129) } }
//line :57:1
func A_arbace_go_repl_fn__794000028_fn__794000029_A_New() *A_arbace_go_repl_fn__794000028_fn__794000029_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_fn__794000028_fn__794000029_A{}; t.Ctor(); return t }
//line :57:1
func (t *A_arbace_go_repl_fn__794000028_fn__794000029_A) Ctor() {}
//line :57:1
func (t *A_arbace_go_repl_fn__794000028_fn__794000029_A) Invoke_O_O_O__O(self, path__1, importer__2 any) any {
	var tmp1 any; var root_130 any = A_arbace_go_repl_A_const_43.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, A_arbace_go_repl_listed_QMARK__A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = path__1; if linked_131 == nil { tmp1 = ifn_132.Invoke_O__O(arg_133) } else { tmp1 = linked_131.(*A_arbace_go_repl_listed_QMARK__A).Invoke_O_O__O(root_130, arg_133) }; if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____3 any; var root_134 any = A_arbace_go_repl_A_const_32.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, A_arbace_go_repl_digest_forms_A_fn_class); var ifn_136 lang.IFn
		if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = path__1; if linked_135 == nil { temp__1927000414__auto____3 = ifn_136.Invoke_O__O(arg_137) } else { temp__1927000414__auto____3 = linked_135.(*A_arbace_go_repl_digest_forms_A).Invoke_O_O__O(root_134, arg_137) }; if jrt.J2g_Truth(temp__1927000414__auto____3) { var fs__4 any = temp__1927000414__auto____3; var root_138 any = A_arbace_go_repl_A_const_44.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_go_check.A_arbace_go_check_forms_source_A_fn_class); var ifn_140 lang.IFn
			if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = fs__4; var arg_142 any; var root_143 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_145 lang.IFn; if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = A_arbace_go_repl_A_const_45.GetRawRoot__O(); if linked_144 == nil { arg_142 = ifn_145.Invoke_O__O(arg_146) } else { arg_142 = linked_144.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_143, arg_146) }; if linked_139 == nil { return ifn_140.Invoke_O_O__O(arg_141, arg_142) } else { return linked_139.(*aot_arbace_go_check.A_arbace_go_check_forms_source_A).Invoke_O_O_O__O(root_138, arg_141, arg_142) } } else {
//line :59:1
				return nil } } else {
//line :58:1
					return nil
				}
}





func A_arbace_go_repl_path__GT_ns_A_New() *A_arbace_go_repl_path__GT_ns_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_path__GT_ns_A{}; t.Ctor(); return t }
//line :66:1
func (t *A_arbace_go_repl_path__GT_ns_A) Ctor() {}
//line :66:1
func (t *A_arbace_go_repl_path__GT_ns_A) Invoke_O_O__O(self, p__0 any) any {


	var root_148 any = A_arbace_go_repl_A_const_46.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any; var root_152 any = A_arbace_go_repl_A_const_47.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = p__0; if linked_153 == nil { arg_151 = ifn_154.Invoke_O__O(arg_155) } else { arg_151 = linked_153.(*aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A).Invoke_O_O__O(root_152, arg_155) }; if linked_149 == nil { return ifn_150.Invoke_O__O(arg_151) } else { return linked_149.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_148, arg_151)
	} }
func A_arbace_go_repl_ns__GT_path_A_New() *A_arbace_go_repl_ns__GT_path_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_ns__GT_path_A{}; t.Ctor(); return t }
//line :71:1
func (t *A_arbace_go_repl_ns__GT_path_A) Ctor() {}
//line :71:1
func (t *A_arbace_go_repl_ns__GT_path_A) Invoke_O_O__O(self, ns_name__0 any) any {


	var root_156 any = A_arbace_go_repl_A_const_48.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = Lit_1; var arg_160 any; var root_161 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_163 lang.IFn; if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any; var root_165 any = A_arbace_go_repl_A_const_50.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any; var root_170 any = A_arbace_go_repl_A_const_51.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_170, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = ns_name__0; if linked_171 == nil { arg_168 = ifn_172.Invoke_O__O(arg_173) } else { arg_168 = linked_171.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_170, arg_173) }; var arg_169 any = A_arbace_go_repl_A_const_52; if linked_166 == nil { arg_164 = ifn_167.Invoke_O_O__O(arg_168, arg_169) } else { arg_164 = linked_166.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_165, arg_168, arg_169) }; if linked_162 == nil { arg_160 = ifn_163.Invoke_O__O(arg_164) } else { arg_160 = linked_162.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_161, arg_164) }; if linked_157 == nil { return ifn_158.Invoke_O_O__O(arg_159, arg_160) } else { return linked_157.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_156, arg_159, arg_160)
	} }
func A_arbace_go_repl_new_state_A_New() *A_arbace_go_repl_new_state_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_new_state_A{}; t.Ctor(); return t }
//line :76:1
func (t *A_arbace_go_repl_new_state_A) Ctor() {}
//line :76:1
func (t *A_arbace_go_repl_new_state_A) Invoke_O_O_O_O__O(self, path__0, nm__1, ns_sym__2 any) any {
	var root_174 any = A_arbace_go_repl_A_const_53.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_174, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any; var tmp1 any = A_arbace_go_repl_A_const_54; var tmp2 any = A_arbace_go_repl_A_const_55; var tmp3 any = A_arbace_go_repl_A_const_56; var tmp4 any = A_arbace_go_repl_A_const_36; var tmp5 any; var root_178 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = A_arbace_go_repl_A_const_45.GetRawRoot__O(); if linked_179 == nil { tmp5 = ifn_180.Invoke_O__O(arg_181) } else { tmp5 = linked_179.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_178, arg_181) }; arg_177 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, path__0, tmp2, nm__1, tmp3, ns_sym__2, tmp4, tmp5, A_arbace_go_repl_A_const_57, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_repl_A_const_58, Lit_115, A_arbace_go_repl_A_const_59, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_repl_A_const_60, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_repl_A_const_61, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_repl_A_const_62, lang.PersistentHashSet_EMPTY.Ref())); if linked_175 == nil { return ifn_176.Invoke_O__O(arg_177) } else { return linked_175.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_174, arg_177)
	}
}
func A_arbace_go_repl_package_state_A_New() *A_arbace_go_repl_package_state_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_package_state_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_go_repl_package_state_A) Ctor() {}
//line :80:1
func (t *A_arbace_go_repl_package_state_A) Invoke_O_O_O__O(self, ns_sym__0, create_QMARK___1 any) any { var s__3 any; var root_182 any = A_arbace_go_repl_A_const_51.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_184 lang.IFn; if



	linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = ns_sym__0; if linked_183 == nil { s__3 = ifn_184.Invoke_O__O(arg_185) } else { s__3 = linked_183.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_182, arg_185) }; var tmp1 any; var root_209 any =
	A_arbace_go_repl_A_const_68.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = s__3; var arg_213 any = Lit_122; if linked_210 == nil { tmp1 = ifn_211.Invoke_O_O__O(arg_212, arg_213) } else { tmp1 = linked_210.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_209, arg_212, arg_213) }; if jrt.J2g_Truth(tmp1) { } else { var tmp2 any; var root_214 any = A_arbace_go_repl_A_const_69.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_216 lang.IFn
		if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_144, nil, Lit_145), jrt.RefArrayOf(jrt.Object_class, nil, s__3, nil)).Ref(); var arg_218 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_repl_A_const_56, ns_sym__0)); if linked_215 == nil { tmp2 = ifn_216.Invoke_O_O__O(arg_217, arg_218) } else { tmp2 = linked_215.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_214, arg_217, arg_218) }
//line :85:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) }; var path__4 any; var root_186 any = /*line :80:1*/A_arbace_go_repl_A_const_63.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, A_arbace_go_repl_ns__GT_path_A_fn_class); var ifn_188 lang.IFn; if






	linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = ns_sym__0; if linked_187 == nil { path__4 = ifn_188.Invoke_O__O(arg_189) } else { path__4 = linked_187.(*A_arbace_go_repl_ns__GT_path_A).Invoke_O_O__O(root_186, arg_189) }; var or__1927000174__auto____5 any; var tmp3 any; var root_190 any = /*line :80:1*/A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_192 lang.IFn; if







	linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = A_arbace_go_repl_A_const_64.GetRawRoot__O(); if linked_191 == nil { tmp3 = ifn_192.Invoke_O__O(arg_193) } else { tmp3 = linked_191.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_190, arg_193) }; or__1927000174__auto____5 = lang.RT_Get_O_O__O_NoInit(tmp3, path__4); if jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else {
		if jrt.J2g_Truth(create_QMARK___1) {
			var tmp4 any; var root_219 any = A_arbace_go_repl_A_const_43.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, A_arbace_go_repl_listed_QMARK__A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = path__4; if linked_220 == nil { tmp4 = ifn_221.Invoke_O__O(arg_222) } else { tmp4 = linked_220.(*A_arbace_go_repl_listed_QMARK__A).Invoke_O_O__O(root_219, arg_222) }; if jrt.J2g_Truth(tmp4) { var tmp5 any; var root_223 any = A_arbace_go_repl_A_const_69.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_225 lang.IFn
				if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_146, nil, Lit_147), jrt.RefArrayOf(jrt.Object_class, nil, path__4, nil)).Ref(); var arg_227 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_repl_A_const_54, path__4)); if linked_224 == nil { tmp5 = ifn_225.Invoke_O_O__O(arg_226, arg_227) } else { tmp5 = linked_224.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_223, arg_226, arg_227) }
//line :90:1
				panic(jrt.Thrown(jrt.Throwable_Cast(tmp5))) }
//line :89:1
			var st__6 any; var root_194 any = A_arbace_go_repl_A_const_65.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, A_arbace_go_repl_new_state_A_fn_class); var ifn_196 lang.IFn


			if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = path__4; var arg_198 any; var root_200 any = A_arbace_go_repl_A_const_66.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any; var root_204 any = A_arbace_go_repl_A_const_50.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = path__4; var arg_208 any = A_arbace_go_repl_A_const_67; if linked_205 == nil { arg_203 = ifn_206.Invoke_O_O__O(arg_207, arg_208) } else { arg_203 = linked_205.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_204, arg_207, arg_208) }; if linked_201 == nil { arg_198 = ifn_202.Invoke_O__O(arg_203) } else { arg_198 = linked_201.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_200, arg_203) }; var arg_199 any = ns_sym__0; if linked_195 == nil { st__6 = ifn_196.Invoke_O_O_O__O(arg_197, arg_198, arg_199) } else { st__6 = linked_195.(*A_arbace_go_repl_new_state_A).Invoke_O_O_O_O__O(root_194, arg_197, arg_198, arg_199) }
			var root_228 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_230 lang.IFn; if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = A_arbace_go_repl_A_const_64.GetRawRoot__O(); var arg_232 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_233 any = path__4; var arg_234 any = st__6; if linked_229 == nil { ifn_230.Invoke_O_O_O_O__O(arg_231, arg_232, arg_233, arg_234) } else { linked_229.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_228, arg_231, arg_232, arg_233, arg_234) }
//line :89:1
			return st__6 } else { return nil } } }
//line :80:1
func (t *A_arbace_go_repl_package_state_A) Invoke_O_O__O(self, ns_sym__0 any) any {

	var root_235 any = A_arbace_go_repl_A_const_72.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, A_arbace_go_repl_package_state_A_fn_class); var ifn_237 lang.IFn; if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any = ns_sym__0; var arg_239 any = jrt.Boolean_TRUE.Ref(); if linked_236 == nil { return ifn_237.Invoke_O_O__O(arg_238, arg_239) } else { return linked_236.(*A_arbace_go_repl_package_state_A).Invoke_O_O_O__O(root_235, arg_238, arg_239)
	}
}











func A_arbace_go_repl_package_BANG__A_New() *A_arbace_go_repl_package_BANG__A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_package_BANG__A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_go_repl_package_BANG__A) Ctor() {}
//line :96:1
func (t *A_arbace_go_repl_package_BANG__A) Invoke_O_O_O_O__O(self, ns_sym__0, nm__1, opts__2 any) any { var opts__4 any; var root_240 any = A_arbace_go_repl_A_const_37.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_242 lang.IFn; if


	linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = A_arbace_go_repl_A_const_38.GetRawRoot__O(); var arg_244 any = opts__2; if linked_241 == nil { opts__4 = ifn_242.Invoke_O_O__O(arg_243, arg_244) } else { opts__4 = linked_241.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_240, arg_243, arg_244) }; var path__5 any; var or__1927000174__auto____5 any = /*line :96:1*/A_arbace_go_repl_A_const_54.Invoke_O__O(opts__4); if



	jrt.J2g_Truth(or__1927000174__auto____5) { path__5 = or__1927000174__auto____5 } else { var root_245 any = A_arbace_go_repl_A_const_63.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, A_arbace_go_repl_ns__GT_path_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = ns_sym__0; if linked_246 == nil { path__5 = ifn_247.Invoke_O__O(arg_248) } else { path__5 = linked_246.(*A_arbace_go_repl_ns__GT_path_A).Invoke_O_O__O(root_245, arg_248) } }; var st__6 any; var or__1927000174__auto____6 any; var tmp1 any; var root_249 any = /*line :96:1*/A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_251 lang.IFn; if




	linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = A_arbace_go_repl_A_const_64.GetRawRoot__O(); if linked_250 == nil { tmp1 = ifn_251.Invoke_O__O(arg_252) } else { tmp1 = linked_250.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_249, arg_252) }; or__1927000174__auto____6 = lang.RT_Get_O_O__O_NoInit(tmp1, path__5); if jrt.J2g_Truth(or__1927000174__auto____6) { st__6 = or__1927000174__auto____6 } else { var st__7 any; var root_253 any = A_arbace_go_repl_A_const_65.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, A_arbace_go_repl_new_state_A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = path__5; var arg_257 any; var root_259 any = A_arbace_go_repl_A_const_51.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_259, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_261 lang.IFn; if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var arg_262 any = nm__1; if linked_260 == nil { arg_257 = ifn_261.Invoke_O__O(arg_262) } else { arg_257 = linked_260.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_259, arg_262) }; var arg_258 any = ns_sym__0; if linked_254 == nil { st__7 = ifn_255.Invoke_O_O_O__O(arg_256, arg_257, arg_258) } else { st__7 = linked_254.(*A_arbace_go_repl_new_state_A).Invoke_O_O_O_O__O(root_253, arg_256, arg_257, arg_258) }; var root_263 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_263, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_265 lang.IFn; if linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var arg_266 any = A_arbace_go_repl_A_const_64.GetRawRoot__O(); var arg_267 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_268 any = path__5; var arg_269 any = st__7; if linked_264 == nil { ifn_265.Invoke_O_O_O_O__O(arg_266, arg_267, arg_268, arg_269) } else { linked_264.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_263, arg_266, arg_267, arg_268, arg_269) }; st__6 = st__7 }; var tmp2 lang.IFn =
	lang.IFn_Cast(A_arbace_go_repl_A_const_70.GetRawRoot__O()); var tmp3 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var tmp4 any = A_arbace_go_repl_A_const_55; var tmp5 any; var root_285 any = A_arbace_go_repl_A_const_73.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_287 lang.IFn; if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = nm__1; if linked_286 == nil { tmp5 = ifn_287.Invoke_O__O(arg_288) } else { tmp5 = linked_286.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_285, arg_288) }; var tmp6 any = tmp5; var tmp7 any = A_arbace_go_repl_A_const_56; var tmp8 any = A_arbace_go_repl_A_const_74; var tmp9 any = A_arbace_go_repl_A_const_75; var tmp10 any = A_arbace_go_repl_A_const_36; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_40.GetRawRoot__O()); var tmp12 any; var root_295 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_297 lang.IFn; if
	linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = A_arbace_go_repl_A_const_45.GetRawRoot__O(); if linked_296 == nil { tmp12 = ifn_297.Invoke_O__O(arg_298) } else { tmp12 = linked_296.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_295, arg_298) }; var tmp13 any = tmp12; var tmp14 any = /*line :102:1*/A_arbace_go_repl_A_const_36.Invoke_O__O(opts__4); var tmp15 lang.IPersistentMap; if
	jrt.J2g_Truth(A_arbace_go_repl_A_const_76.Invoke_O__O(opts__4)) { var tmp16 any = A_arbace_go_repl_A_const_76; tmp15 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, A_arbace_go_repl_A_const_76.Invoke_O__O(opts__4))) } else { tmp15 = nil }; /*line :102:1*/tmp2.Invoke_O_O_O_O_O_O_O_O_O_O_O_O__O(st__6, tmp3, tmp4, tmp6, tmp7, ns_sym__0, tmp8, opts__4, tmp9, path__5, tmp10, tmp11.Invoke_O_O_O__O(tmp13, tmp14, tmp15)); if

	jrt.J2g_Truth(A_arbace_go_repl_A_const_57.Invoke_O__O(opts__4)) {

		lang.IFn_Cast(A_arbace_go_repl_A_const_70.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(st__6, A_arbace_go_repl_A_const_71.GetRawRoot__O(), A_arbace_go_repl_A_const_77, jrt.Boolean_TRUE.Ref(), A_arbace_go_repl_A_const_57, lang.PersistentVector_EMPTY.Ref()) }; return nil }


func A_arbace_go_repl_file_entry_A_New() *A_arbace_go_repl_file_entry_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_file_entry_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_go_repl_file_entry_A) Ctor() {}
//line :109:1
func (t *A_arbace_go_repl_file_entry_A) Invoke_O_O_O__O(self, st__0, fname__1 any) any {
	var root_308 any = A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any; var tmp1 any = A_arbace_go_repl_file_entry_fn__794000040_A_New_O(fname__1); var tmp2 *jrt.Class; var fncls__313 *jrt.Class = A_arbace_go_repl_file_entry_fn__794000040_A_fn_class; if fncls__313 == nil { var fncls__313d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_136, false); A_arbace_go_repl_file_entry_fn__794000040_A_fn_class = fncls__313d; tmp2 = fncls__313d } else { tmp2 = fncls__313 }; arg_311 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_312 any; var tmp3 *lang.Keyword = A_arbace_go_repl_A_const_57; var tmp4 any; var root_314 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_314, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_316 lang.IFn; if linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any = st__0; if linked_315 == nil { tmp4 = ifn_316.Invoke_O__O(arg_317) } else { tmp4 = linked_315.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_314, arg_317) }; arg_312 = tmp3.Invoke_O__O(tmp4); if linked_309 == nil { return ifn_310.Invoke_O_O__O(arg_311, arg_312) } else { return linked_309.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_308, arg_311, arg_312) } }
//line :110:1
func A_arbace_go_repl_file_entry_fn__794000040_A_New_O(p0 any) *A_arbace_go_repl_file_entry_fn__794000040_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_file_entry_fn__794000040_A{}; t.Ctor_O(p0); return t }
//line :110:1
func (t *A_arbace_go_repl_file_entry_fn__794000040_A) Ctor_O(c__fname any) { t.F_fname = c__fname }
//line :110:1
func (t *A_arbace_go_repl_file_entry_fn__794000040_A) Invoke_O_O__O(self, p1__794000039_SHARP___1 any) any { var tmp1 any = t.F_fname; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_repl_A_const_55.Invoke_O__O(p1__794000039_SHARP___1)) { return p1__794000039_SHARP___1 } else { return nil } }

func A_arbace_go_repl_update_file_A_New() *A_arbace_go_repl_update_file_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_update_file_A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_go_repl_update_file_A) Ctor() {}
//line :112:1
func (t *A_arbace_go_repl_update_file_A) Invoke_O_O_O_O__O(self, st__0, fname__1, f__2 any) any {
	var root_318 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_318, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any = st__0; var arg_322 any = A_arbace_go_repl_A_const_79.GetRawRoot__O(); var arg_323 any = A_arbace_go_repl_A_const_57; var arg_324 any; var tmp1 any = A_arbace_go_repl_update_file_fn__794000045_A_New_O_O(f__2, fname__1); var tmp2 *jrt.Class; var fncls__342 *jrt.Class = A_arbace_go_repl_update_file_fn__794000045_A_fn_class
	if fncls__342 == nil { var fncls__342d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_162, false); A_arbace_go_repl_update_file_fn__794000045_A_fn_class = fncls__342d; tmp2 = fncls__342d } else { tmp2 = fncls__342 }; arg_324 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :113:1
	if linked_319 == nil { return ifn_320.Invoke_O_O_O_O__O(arg_321, arg_322, arg_323, arg_324) } else { return linked_319.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_318, arg_321, arg_322, arg_323, arg_324) } }
func A_arbace_go_repl_update_file_fn__794000045_A_New_O_O(p0, p1 any) *A_arbace_go_repl_update_file_fn__794000045_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_update_file_fn__794000045_A{}; t.Ctor_O_O(p0, p1); return t }
//line :114:1
func (t *A_arbace_go_repl_update_file_fn__794000045_A) Ctor_O_O(c__f, c__fname any) { t.F_f = c__f; t.F_fname = c__fname }
//line :114:1
func (t *A_arbace_go_repl_update_file_fn__794000045_A) Invoke_O_O__O(self, fs__1 any) any {
	var tmp1 any; var root_325 any = A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any; var tmp2 any = A_arbace_go_repl_update_file_fn__794000045_fn__794000046_A_New_O(t.F_fname); var tmp3 *jrt.Class; var fncls__330 *jrt.Class = A_arbace_go_repl_update_file_fn__794000045_fn__794000046_A_fn_class; if fncls__330 == nil { var fncls__330d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_163, false); A_arbace_go_repl_update_file_fn__794000045_fn__794000046_A_fn_class = fncls__330d; tmp3 = fncls__330d } else { tmp3 = fncls__330 }; arg_328 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_329 any = fs__1; if linked_326 == nil { tmp1 = ifn_327.Invoke_O_O__O(arg_328, arg_329) } else { tmp1 = linked_326.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_325, arg_328, arg_329) }; if jrt.J2g_Truth(tmp1) {
		var root_331 any = A_arbace_go_repl_A_const_80.GetRawRoot__O(); var linked_332 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_331, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_333 lang.IFn; if linked_332 == nil { ifn_333 = lang.IFn_Cast(root_331) } else { ifn_333 = nil }; var arg_334 any; var tmp4 any = A_arbace_go_repl_update_file_fn__794000045_fn__794000048_A_New_O_O(t.F_f, t.F_fname); var tmp5 *jrt.Class; var fncls__336 *jrt.Class = A_arbace_go_repl_update_file_fn__794000045_fn__794000048_A_fn_class; if fncls__336 == nil { var fncls__336d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_164, false); A_arbace_go_repl_update_file_fn__794000045_fn__794000048_A_fn_class = fncls__336d; tmp5 = fncls__336d } else { tmp5 = fncls__336 }; arg_334 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_335 any = fs__1; if linked_332 == nil { return ifn_333.Invoke_O_O__O(arg_334, arg_335) } else { return linked_332.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_331, arg_334, arg_335) } } else {
			var root_337 any = A_arbace_go_repl_A_const_15.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_337, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = fs__1; var tmp6 lang.IFn = lang.IFn_Cast(t.F_f); var arg_341 any = tmp6.Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_repl_A_const_55, t.F_fname, A_arbace_go_repl_A_const_74, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_repl_A_const_81, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_repl_A_const_82, lang.PersistentVector_EMPTY.Ref()))); if linked_338 == nil { return ifn_339.Invoke_O_O__O(arg_340, arg_341) } else { return linked_338.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_337, arg_340, arg_341) } } }
//line :115:1
func A_arbace_go_repl_update_file_fn__794000045_fn__794000046_A_New_O(p0 any) *A_arbace_go_repl_update_file_fn__794000045_fn__794000046_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_update_file_fn__794000045_fn__794000046_A{}; t.Ctor_O(p0); return t }
//line :115:1
func (t *A_arbace_go_repl_update_file_fn__794000045_fn__794000046_A) Ctor_O(c__fname any) { t.F_fname = c__fname }
//line :115:1
func (t *A_arbace_go_repl_update_file_fn__794000045_fn__794000046_A) Invoke_O_O__O(self, p1__794000043_SHARP___1 any) any { var tmp1 any = t.F_fname; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_repl_A_const_55.Invoke_O__O(p1__794000043_SHARP___1))).Ref() }
func A_arbace_go_repl_update_file_fn__794000045_fn__794000048_A_New_O_O(p0, p1 any) *A_arbace_go_repl_update_file_fn__794000045_fn__794000048_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_update_file_fn__794000045_fn__794000048_A{}; t.Ctor_O_O(p0, p1); return t }
//line :116:1
func (t *A_arbace_go_repl_update_file_fn__794000045_fn__794000048_A) Ctor_O_O(c__f, c__fname any) { t.F_f = c__f; t.F_fname = c__fname }
//line :116:1
func (t *A_arbace_go_repl_update_file_fn__794000045_fn__794000048_A) Invoke_O_O__O(self, p1__794000044_SHARP___1 any) any { var tmp1 any = t.F_fname; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_repl_A_const_55.Invoke_O__O(p1__794000044_SHARP___1)) { return lang.IFn_Cast(t.F_f).Invoke_O__O(p1__794000044_SHARP___1) } else { return p1__794000044_SHARP___1 } }


func A_arbace_go_repl_file_BANG__A_New() *A_arbace_go_repl_file_BANG__A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_file_BANG__A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_go_repl_file_BANG__A) Ctor() {}
//line :119:1
func (t *A_arbace_go_repl_file_BANG__A) Invoke_O_O_O_O__O(self, ns_sym__0, fname__1, opts__2 any) any { var st__4 any; var root_343 any = A_arbace_go_repl_A_const_72.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, A_arbace_go_repl_package_state_A_fn_class); var ifn_345 lang.IFn; if


	linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = ns_sym__0; if linked_344 == nil { st__4 = ifn_345.Invoke_O__O(arg_346) } else { st__4 = linked_344.(*A_arbace_go_repl_package_state_A).Invoke_O_O__O(root_343, arg_346) }; var root_347 any =
	A_arbace_go_repl_A_const_83.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, A_arbace_go_repl_update_file_A_fn_class); var ifn_349 lang.IFn; if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any = st__4; var arg_351 any = fname__1; var arg_352 any; var tmp1 any = A_arbace_go_repl_file_BANG__fn__794000053_A_New_O_O(opts__2, st__4); var tmp2 *jrt.Class; var fncls__376 *jrt.Class = A_arbace_go_repl_file_BANG__fn__794000053_A_fn_class; if fncls__376 == nil { var fncls__376d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_135, false); A_arbace_go_repl_file_BANG__fn__794000053_A_fn_class = fncls__376d; tmp2 = fncls__376d } else { tmp2 = fncls__376 }; arg_352 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_348 == nil { ifn_349.Invoke_O_O_O__O(arg_350, arg_351, arg_352) } else { linked_348.(*A_arbace_go_repl_update_file_A).Invoke_O_O_O_O__O(root_347, arg_350, arg_351, arg_352) }; var root_377 any =

	A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_378 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_377, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_379 lang.IFn; if linked_378 == nil { ifn_379 = lang.IFn_Cast(root_377) } else { ifn_379 = nil }; var arg_380 any = st__4; var arg_381 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_382 any = A_arbace_go_repl_A_const_58; var arg_383 any = fname__1; if linked_378 == nil { ifn_379.Invoke_O_O_O_O__O(arg_380, arg_381, arg_382, arg_383) } else { linked_378.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_377, arg_380, arg_381, arg_382, arg_383) }; return nil }
//line :123:1
func A_arbace_go_repl_file_BANG__fn__794000053_A_New_O_O(p0, p1 any) *A_arbace_go_repl_file_BANG__fn__794000053_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_file_BANG__fn__794000053_A{}; t.Ctor_O_O(p0, p1); return t }
//line :123:1
func (t *A_arbace_go_repl_file_BANG__fn__794000053_A) Ctor_O_O(c__opts, c__st any) { t.F_opts = c__opts; t.F_st = c__st }
//line :123:1
func (t *A_arbace_go_repl_file_BANG__fn__794000053_A) Invoke_O_O__O(self, p1__794000052_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_71.GetRawRoot__O()); var tmp2 any = A_arbace_go_repl_A_const_74; var tmp3 any; var root_363 any = A_arbace_go_repl_A_const_84.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = t.F_opts; var arg_367 any = A_arbace_go_repl_A_const_85; if linked_364 == nil { tmp3 = ifn_365.Invoke_O_O__O(arg_366, arg_367) } else { tmp3 = linked_364.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_363, arg_366, arg_367) }; var tmp4 any = tmp3; var tmp5 any = A_arbace_go_repl_A_const_81; var tmp6 any; var root_368 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_368, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_370 lang.IFn; if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any = A_arbace_go_repl_A_const_81.Invoke_O__O(t.F_opts); if linked_369 == nil { tmp6 = ifn_370.Invoke_O__O(arg_371) } else { tmp6 = linked_369.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_368, arg_371) }; var tmp7 any = tmp6; var tmp8 any = A_arbace_go_repl_A_const_82; var tmp9 any; var tmp10 *lang.Keyword = A_arbace_go_repl_A_const_77; var tmp11 any; var root_372 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_374 lang.IFn; if
														linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any = t.F_st; if linked_373 == nil { tmp11 = ifn_374.Invoke_O__O(arg_375) } else { tmp11 = linked_373.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_372, arg_375) }; if jrt.J2g_Truth(tmp10.Invoke_O__O(tmp11)) { tmp9 = lang.PersistentVector_EMPTY.Ref() } else { tmp9 = A_arbace_go_repl_A_const_82.Invoke_O__O(p1__794000052_SHARP___1) }; return /*line :123:1*/ tmp1.Invoke_O_O_O_O_O_O_O__O(p1__794000052_SHARP___1, tmp2, tmp4, tmp5, tmp7, tmp8, tmp9) }




func A_arbace_go_repl_import_BANG__A_New() *A_arbace_go_repl_import_BANG__A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_import_BANG__A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_go_repl_import_BANG__A) Ctor() {}
//line :128:1
func (t *A_arbace_go_repl_import_BANG__A) Invoke_O_O_O__O(self, ns_sym__0, specs__1 any) any { var st__3 any; var root_384 any = A_arbace_go_repl_A_const_72.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, A_arbace_go_repl_package_state_A_fn_class); var ifn_386 lang.IFn; if


	linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any = ns_sym__0; if linked_385 == nil { st__3 = ifn_386.Invoke_O__O(arg_387) } else { st__3 = linked_385.(*A_arbace_go_repl_package_state_A).Invoke_O_O__O(root_384, arg_387) }; var tmp1 /*line :132:1*/*lang.Keyword = A_arbace_go_repl_A_const_77; var tmp2 any; var root_388 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_390 lang.IFn; if linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any = st__3; if linked_389 == nil { tmp2 = ifn_390.Invoke_O__O(arg_391) } else { tmp2 = linked_389.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_388, arg_391) }; if jrt.J2g_Truth(tmp1.Invoke_O__O(tmp2)) { var tmp3 any; var root_392 any = A_arbace_go_repl_A_const_69.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_394 lang.IFn
		if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = Lit_140; var arg_396 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_393 == nil { tmp3 = ifn_394.Invoke_O_O__O(arg_395, arg_396) } else { tmp3 = linked_393.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_392, arg_395, arg_396) }
//line :132:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp3))) }; var root_397 any =

	A_arbace_go_repl_A_const_83.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, A_arbace_go_repl_update_file_A_fn_class); var ifn_399 lang.IFn; if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = st__3; var arg_401 any; var tmp4 *lang.Keyword = A_arbace_go_repl_A_const_58; var tmp5 any; var root_403 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = st__3; if linked_404 == nil { tmp5 = ifn_405.Invoke_O__O(arg_406) } else { tmp5 = linked_404.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_403, arg_406) }; arg_401 = tmp4.Invoke_O__O(tmp5); var arg_402 any; var tmp6 any = A_arbace_go_repl_import_BANG__fn__794000057_A_New_O(specs__1); var tmp7 *jrt.Class; var fncls__427 *jrt.Class = A_arbace_go_repl_import_BANG__fn__794000057_A_fn_class; if fncls__427 == nil { var fncls__427d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_141, false); A_arbace_go_repl_import_BANG__fn__794000057_A_fn_class = fncls__427d; tmp7 = fncls__427d } else { tmp7 = fncls__427 }; arg_402 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_398 == nil { ifn_399.Invoke_O_O_O__O(arg_400, arg_401, arg_402) } else { linked_398.(*A_arbace_go_repl_update_file_A).Invoke_O_O_O_O__O(root_397, arg_400, arg_401, arg_402) }; return nil }
//line :134:1
func A_arbace_go_repl_import_BANG__fn__794000057_A_New_O(p0 any) *A_arbace_go_repl_import_BANG__fn__794000057_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_import_BANG__fn__794000057_A{}; t.Ctor_O(p0); return t }
//line :134:1
func (t *A_arbace_go_repl_import_BANG__fn__794000057_A) Ctor_O(c__specs any) { t.F_specs = c__specs }
//line :134:1
func (t *A_arbace_go_repl_import_BANG__fn__794000057_A) Invoke_O_O__O(self, fi__1 any) any { var root_407 any = A_arbace_go_repl_A_const_79.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = fi__1; var arg_411 any = A_arbace_go_repl_A_const_81; var arg_412 any; var tmp1 any = A_arbace_go_repl_import_BANG__fn__794000057_fn__794000058_A_New_O(t.F_specs); var tmp2 *jrt.Class; var fncls__426 *jrt.Class = A_arbace_go_repl_import_BANG__fn__794000057_fn__794000058_A_fn_class; if fncls__426 == nil { var fncls__426d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_142, false); A_arbace_go_repl_import_BANG__fn__794000057_fn__794000058_A_fn_class = fncls__426d; tmp2 = fncls__426d } else { tmp2 = fncls__426 }; arg_412 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_408 == nil { return ifn_409.Invoke_O_O_O__O(arg_410, arg_411, arg_412) } else { return linked_408.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_407, arg_410, arg_411, arg_412) } }
//line :134:1
func A_arbace_go_repl_import_BANG__fn__794000057_fn__794000058_A_New_O(p0 any) *A_arbace_go_repl_import_BANG__fn__794000057_fn__794000058_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_import_BANG__fn__794000057_fn__794000058_A{}; t.Ctor_O(p0); return t }
//line :134:1
func (t *A_arbace_go_repl_import_BANG__fn__794000057_fn__794000058_A) Ctor_O(c__specs any) { t.F_specs = c__specs }
//line :134:1
func (t *A_arbace_go_repl_import_BANG__fn__794000057_fn__794000058_A) Invoke_O_O__O(self, p1__794000056_SHARP___1 any) any { var root_413 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_413, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_415 lang.IFn; if linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any; var root_417 any = A_arbace_go_repl_A_const_87.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_419 lang.IFn; if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any; var root_421 any = A_arbace_go_repl_A_const_88.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_423 lang.IFn; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any; var or__1927000174__auto____2 any = p1__794000056_SHARP___1; if jrt.J2g_Truth(or__1927000174__auto____2) { arg_424 = or__1927000174__auto____2 } else { arg_424 = lang.PersistentVector_EMPTY.Ref() }; var arg_425 any = t.F_specs; if linked_422 == nil { arg_420 = ifn_423.Invoke_O_O__O(arg_424, arg_425) } else { arg_420 = linked_422.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_421, arg_424, arg_425) }; if linked_418 == nil { arg_416 = ifn_419.Invoke_O__O(arg_420) } else { arg_416 = linked_418.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_417, arg_420) }; if linked_414 == nil { return ifn_415.Invoke_O__O(arg_416) } else { return linked_414.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_413, arg_416) } }




func A_arbace_go_repl_decl_names_A_New() *A_arbace_go_repl_decl_names_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_go_repl_decl_names_A) Ctor() {}
//line :139:1
func (t *A_arbace_go_repl_decl_names_A) Invoke_O_O__O(self, f__0 any) any { var h__2 any; var root_428 any = A_arbace_go_repl_A_const_89.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_428, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_430 lang.IFn; if


	linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any = f__0; if linked_429 == nil { h__2 = ifn_430.Invoke_O__O(arg_431) } else { h__2 = linked_429.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_428, arg_431) }; var args__3 any; var root_432 any = /*line :139:1*/A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_432, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_434 lang.IFn; if



	linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = f__0; if linked_433 == nil { args__3 = ifn_434.Invoke_O__O(arg_435) } else { args__3 = linked_433.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_432, arg_435) }; var targets__4 any; var tmp1 any = /*line :139:1*/A_arbace_go_repl_decl_names_targets__794000062_A_New(); var tmp2 *jrt.Class; var fncls__444 *jrt.Class = A_arbace_go_repl_decl_names_targets__794000062_A_fn_class; if




	fncls__444 == nil { var fncls__444d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_go_repl_decl_names_targets__794000062_A_fn_class = fncls__444d; tmp2 = fncls__444d } else { tmp2 = fncls__444 }; targets__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var group_QMARK___5 any; var tmp3 any = /*line :139:1*/A_arbace_go_repl_decl_names_group_QMARK___794000064_A_New(); var tmp4 *jrt.Class; var fncls__462 *jrt.Class = A_arbace_go_repl_decl_names_group_QMARK___794000064_A_fn_class; if





	fncls__462 == nil { var fncls__462d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_go_repl_decl_names_group_QMARK___794000064_A_fn_class = fncls__462d; tmp4 = fncls__462d } else { tmp4 = fncls__462 }; group_QMARK___5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var specs__6 any; var tmp5 any = /*line :139:1*/A_arbace_go_repl_decl_names_specs__794000066_A_New(); var tmp6 *jrt.Class; var fncls__479 *jrt.Class = A_arbace_go_repl_decl_names_specs__794000066_A_fn_class; if






	fncls__479 == nil { var fncls__479d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_go_repl_decl_names_specs__794000066_A_fn_class = fncls__479d; tmp6 = fncls__479d } else { tmp6 = fncls__479 }; specs__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var G__794000068__7_ any = h__2; switch
	lang.Util_Hash_O__I_NoInit(G__794000068__7_) >> 9 & 7 { case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__794000068__7_, Lit_19) {












		if jrt.J2g_Truth(lang.IFn_Cast(group_QMARK___5).Invoke_O__O(args__3)) {
			var root_481 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_481, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_483 lang.IFn; if linked_482 == nil { ifn_483 = lang.IFn_Cast(root_481) } else { ifn_483 = nil }; var arg_484 any; var iter__1927001039__auto____8 any; var tmp7 any = A_arbace_go_repl_decl_names_iter__794000069__794000073_A_New(); var tmp8 *jrt.Class; var fncls__551 *jrt.Class = A_arbace_go_repl_decl_names_iter__794000069__794000073_A_fn_class; if fncls__551 == nil { var fncls__551d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_go_repl_decl_names_iter__794000069__794000073_A_fn_class = fncls__551d; tmp8 = fncls__551d } else { tmp8 = fncls__551 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); arg_484 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(lang.IFn_Cast(specs__6).Invoke_O__O(args__3)); if linked_482 == nil { return ifn_483.Invoke_O__O(arg_484) } else { return linked_482.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_481, arg_484) } } else {
//line :160:1
				var tmp9 any; var root_774 any = A_arbace_go_repl_A_const_73.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_776 lang.IFn

				if linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any; var root_778 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_778, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_780 lang.IFn; if linked_779 == nil { ifn_780 = lang.IFn_Cast(root_778) } else { ifn_780 = nil }; var arg_781 any = args__3; if linked_779 == nil { arg_777 = ifn_780.Invoke_O__O(arg_781) } else { arg_777 = linked_779.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_778, arg_781) }; if linked_775 == nil { tmp9 = ifn_776.Invoke_O__O(arg_777) } else { tmp9 = linked_775.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_774, arg_777) }
//line :160:1
				return lang.Tuple_Create_O__IPersistentVector(tmp9) } }
//line :147:1
	case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__794000068__7_, Lit_21) { var tmp10 any; var root_782 any = A_arbace_go_repl_A_const_73.GetRawRoot__O(); var linked_783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_782, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_784 lang.IFn
		if linked_783 == nil { ifn_784 = lang.IFn_Cast(root_782) } else { ifn_784 = nil }; var arg_785 any; var root_786 any = A_arbace_go_repl_A_const_103.GetRawRoot__O(); var linked_787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_786, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_788 lang.IFn; if linked_787 == nil { ifn_788 = lang.IFn_Cast(root_786) } else { ifn_788 = nil }; var arg_789 any = f__0; if linked_787 == nil { arg_785 = ifn_788.Invoke_O__O(arg_789) } else { arg_785 = linked_787.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_786, arg_789) }; if linked_783 == nil { tmp10 = ifn_784.Invoke_O__O(arg_785) } else { tmp10 = linked_783.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_782, arg_785) }
//line :147:1
		return lang.Tuple_Create_O__IPersistentVector(tmp10) }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__794000068__7_, Lit_22) {









			if jrt.J2g_Truth(lang.IFn_Cast(group_QMARK___5).Invoke_O__O(args__3)) {
				var root_552 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any; var iter__1927001039__auto____8_2 any; var tmp11 any = A_arbace_go_repl_decl_names_iter__794000085__794000091_A_New_O(targets__4); var tmp12 *jrt.Class; var fncls__649 *jrt.Class = A_arbace_go_repl_decl_names_iter__794000085__794000091_A_fn_class; if fncls__649 == nil { var fncls__649d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_go_repl_decl_names_iter__794000085__794000091_A_fn_class = fncls__649d; tmp12 = fncls__649d } else { tmp12 = fncls__649 }; iter__1927001039__auto____8_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); arg_555 = lang.IFn_Cast(iter__1927001039__auto____8_2).Invoke_O__O(lang.IFn_Cast(specs__6).Invoke_O__O(args__3)); if linked_553 == nil { return ifn_554.Invoke_O__O(arg_555) } else { return linked_553.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_552, arg_555) } } else {
					var root_650 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_650, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_652 lang.IFn; if linked_651 == nil { ifn_652 = lang.IFn_Cast(root_650) } else { ifn_652 = nil }; var arg_653 any; var root_654 any = A_arbace_go_repl_A_const_102.GetRawRoot__O(); var linked_655 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_654, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_656 lang.IFn; if linked_655 == nil { ifn_656 = lang.IFn_Cast(root_654) } else { ifn_656 = nil }; var arg_657 any = A_arbace_go_repl_A_const_73.GetRawRoot__O(); var arg_658 any; var tmp13 lang.IFn = lang.IFn_Cast(targets__4); var tmp14 any; var root_659 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_659, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_661 lang.IFn; if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any = args__3; if linked_660 == nil { tmp14 = ifn_661.Invoke_O__O(arg_662) } else { tmp14 = linked_660.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_659, arg_662) }; arg_658 = tmp13.Invoke_O__O(tmp14); if linked_655 == nil { arg_653 = ifn_656.Invoke_O_O__O(arg_657, arg_658) } else { arg_653 = linked_655.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_654, arg_657, arg_658) }; if linked_651 == nil { return ifn_652.Invoke_O__O(arg_653) } else { return linked_651.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_650, arg_653) } } }
//line :147:1
	case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__794000068__7_, Lit_24) {









		if jrt.J2g_Truth(lang.IFn_Cast(group_QMARK___5).Invoke_O__O(args__3)) {
			var root_663 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any; var iter__1927001039__auto____8_3 any; var tmp15 any = A_arbace_go_repl_decl_names_iter__794000104__794000110_A_New_O(targets__4); var tmp16 *jrt.Class; var fncls__760 *jrt.Class = A_arbace_go_repl_decl_names_iter__794000104__794000110_A_fn_class; if fncls__760 == nil { var fncls__760d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_go_repl_decl_names_iter__794000104__794000110_A_fn_class = fncls__760d; tmp16 = fncls__760d } else { tmp16 = fncls__760 }; iter__1927001039__auto____8_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); arg_666 = lang.IFn_Cast(iter__1927001039__auto____8_3).Invoke_O__O(lang.IFn_Cast(specs__6).Invoke_O__O(args__3)); if linked_664 == nil { return ifn_665.Invoke_O__O(arg_666) } else { return linked_664.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_663, arg_666) } } else {
				var root_761 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any; var root_765 any = A_arbace_go_repl_A_const_102.GetRawRoot__O(); var linked_766 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_765, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_767 lang.IFn; if linked_766 == nil { ifn_767 = lang.IFn_Cast(root_765) } else { ifn_767 = nil }; var arg_768 any = A_arbace_go_repl_A_const_73.GetRawRoot__O(); var arg_769 any; var tmp17 lang.IFn = lang.IFn_Cast(targets__4); var tmp18 any; var root_770 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_772 lang.IFn; if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any = args__3; if linked_771 == nil { tmp18 = ifn_772.Invoke_O__O(arg_773) } else { tmp18 = linked_771.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_770, arg_773) }; arg_769 = tmp17.Invoke_O__O(tmp18); if linked_766 == nil { arg_764 = ifn_767.Invoke_O_O__O(arg_768, arg_769) } else { arg_764 = linked_766.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_765, arg_768, arg_769) }; if linked_762 == nil { return ifn_763.Invoke_O__O(arg_764) } else { return linked_762.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_761, arg_764) } } }
//line :147:1
	case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__794000068__7_, Lit_26) { var more__8 any; var root_790 any = A_arbace_go_repl_A_const_104.GetRawRoot__O(); var linked_791 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_790, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_792 lang.IFn

		if linked_791 == nil { ifn_792 = lang.IFn_Cast(root_790) } else { ifn_792 = nil }; var arg_794 any = f__0; if linked_791 == nil { more__8 = ifn_792.Invoke_O_O__O(A_arbace_go_repl_A_const_105, arg_794) } else { more__8 = linked_791.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_790, 2, A_arbace_go_repl_A_const_105, arg_794) }
//line :147:1
		var more__9 any; var tmp19 any; var root_795 any = A_arbace_go_repl_A_const_90.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_797 lang.IFn


		if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any; var root_799 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_799, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_801 lang.IFn; if linked_800 == nil { ifn_801 = lang.IFn_Cast(root_799) } else { ifn_801 = nil }; var arg_802 any = more__8; if linked_800 == nil { arg_798 = ifn_801.Invoke_O__O(arg_802) } else { arg_798 = linked_800.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_799, arg_802) }; if linked_796 == nil { tmp19 = ifn_797.Invoke_O__O(arg_798) } else { tmp19 = linked_796.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_795, arg_798) }; if jrt.J2g_Truth(tmp19) { var root_803 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_803, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_805 lang.IFn; if linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any = more__8; if linked_804 == nil { more__9 = ifn_805.Invoke_O__O(arg_806) } else { more__9 = linked_804.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_803, arg_806) } } else { more__9 = more__8 }
//line :147:1
		var more__10 any; var tmp20 any = A_arbace_go_repl_A_const_106; var tmp21 any; var root_807 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_807, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_809 lang.IFn



		if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any = more__9; if linked_808 == nil { tmp21 = ifn_809.Invoke_O__O(arg_810) } else { tmp21 = linked_808.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_807, arg_810) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp20, tmp21) { var root_811 any = A_arbace_go_repl_A_const_104.GetRawRoot__O(); var linked_812 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_811, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_813 lang.IFn; if linked_812 == nil { ifn_813 = lang.IFn_Cast(root_811) } else { ifn_813 = nil }; var arg_815 any = more__9; if linked_812 == nil { more__10 = ifn_813.Invoke_O_O__O(A_arbace_go_repl_A_const_105, arg_815) } else { more__10 = linked_812.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_811, 2, A_arbace_go_repl_A_const_105, arg_815) } } else { more__10 = more__9 }
//line :147:1
		var rf__11 any; var root_816 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_818 lang.IFn




		if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any; var root_820 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_820, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_822 lang.IFn; if linked_821 == nil { ifn_822 = lang.IFn_Cast(root_820) } else { ifn_822 = nil }; var arg_823 any = more__10; if linked_821 == nil { arg_819 = ifn_822.Invoke_O__O(arg_823) } else { arg_819 = linked_821.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_820, arg_823) }; if linked_817 == nil { rf__11 = ifn_818.Invoke_O__O(arg_819) } else { rf__11 = linked_817.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_816, arg_819) }
//line :147:1
		var ty__12 any; var tmp22 any; var and__1927000168__auto____12 any; var root_824 any = A_arbace_go_repl_A_const_107.GetRawRoot__O(); var linked_825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_824, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_826 lang.IFn





		if linked_825 == nil { ifn_826 = lang.IFn_Cast(root_824) } else { ifn_826 = nil }; var arg_827 any = rf__11; if linked_825 == nil { and__1927000168__auto____12 = ifn_826.Invoke_O__O(arg_827) } else { and__1927000168__auto____12 = linked_825.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_824, arg_827) }; if jrt.J2g_Truth(and__1927000168__auto____12) { var tmp23 *lang.Keyword = A_arbace_go_repl_A_const_108; tmp22 = tmp23.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(rf__11)) } else { tmp22 = and__1927000168__auto____12 }; if jrt.J2g_Truth(tmp22) { var tmp24 *lang.Keyword = A_arbace_go_repl_A_const_108; ty__12 = tmp24.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(rf__11)) } else { ty__12 = rf__11 }
//line :147:1
		var ty__13 any; var tmp25 any; var and__1927000168__auto____13 any; var root_828 any = A_arbace_go_repl_A_const_34.GetRawRoot__O(); var linked_829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_828, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_830 lang.IFn






		if linked_829 == nil { ifn_830 = lang.IFn_Cast(root_828) } else { ifn_830 = nil }; var arg_831 any = ty__12; if linked_829 == nil { and__1927000168__auto____13 = ifn_830.Invoke_O__O(arg_831) } else { and__1927000168__auto____13 = linked_829.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_828, arg_831) }; if jrt.J2g_Truth(and__1927000168__auto____13) { var tmp26 any = A_arbace_go_repl_A_const_109; var tmp27 any; var root_832 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_832, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_834 lang.IFn; if linked_833 == nil { ifn_834 = lang.IFn_Cast(root_832) } else { ifn_834 = nil }; var arg_835 any = ty__12; if linked_833 == nil { tmp27 = ifn_834.Invoke_O__O(arg_835) } else { tmp27 = linked_833.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_832, arg_835) }; tmp25 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp26, tmp27)).Ref() } else { tmp25 = and__1927000168__auto____13 }; if jrt.J2g_Truth(tmp25) { var root_836 any = A_arbace_go_repl_A_const_103.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_836, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_838 lang.IFn; if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any = ty__12; if linked_837 == nil { ty__13 = ifn_838.Invoke_O__O(arg_839) } else { ty__13 = linked_837.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_836, arg_839) } } else { ty__13 = ty__12 }
//line :147:1
		var ty__14 any; var tmp28 any; var root_840 any = A_arbace_go_repl_A_const_34.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_840, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_842 lang.IFn







		if linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any = ty__13; if linked_841 == nil { tmp28 = ifn_842.Invoke_O__O(arg_843) } else { tmp28 = linked_841.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_840, arg_843) }; if jrt.J2g_Truth(tmp28) { var root_844 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_844, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_846 lang.IFn; if linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any = ty__13; if linked_845 == nil { ty__14 = ifn_846.Invoke_O__O(arg_847) } else { ty__14 = linked_845.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_844, arg_847) } } else { ty__14 = ty__13 }
//line :147:1
		var tmp29 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_3, nil); var tmp30 any; var root_848 any = A_arbace_go_repl_A_const_73.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_848, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_850 lang.IFn








		if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any; var root_852 any = A_arbace_go_repl_A_const_103.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_854 lang.IFn; if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any = f__0; if linked_853 == nil { arg_851 = ifn_854.Invoke_O__O(arg_855) } else { arg_851 = linked_853.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_852, arg_855) }; if linked_849 == nil { tmp30 = ifn_850.Invoke_O__O(arg_851) } else { tmp30 = linked_849.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_848, arg_851) }
//line :147:1
		return lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp29, jrt.RefArrayOf(jrt.Object_class, ty__14, nil, tmp30)).Ref()) }; default:}; return lang.PersistentVector_EMPTY.Ref() }
//line :144:1
func A_arbace_go_repl_decl_names_targets__794000062_A_New() *A_arbace_go_repl_decl_names_targets__794000062_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_targets__794000062_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_go_repl_decl_names_targets__794000062_A) Ctor() {}
//line :144:1
func (t *A_arbace_go_repl_decl_names_targets__794000062_A) Invoke_O_O__O(self, tf__1 any) any { var tmp1 any; var root_436 any = A_arbace_go_repl_A_const_89.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_436, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_438 lang.IFn; if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any = tf__1; if linked_437 == nil { tmp1 = ifn_438.Invoke_O__O(arg_439) } else { tmp1 = linked_437.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_436, arg_439) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_37, tmp1) { var root_440 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_440, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_442 lang.IFn; if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = tf__1; if linked_441 == nil { return ifn_442.Invoke_O__O(arg_443) } else { return linked_441.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_440, arg_443) } } else { return lang.Tuple_Create_O__IPersistentVector(tf__1) } }
func A_arbace_go_repl_decl_names_group_QMARK___794000064_A_New() *A_arbace_go_repl_decl_names_group_QMARK___794000064_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_group_QMARK___794000064_A{}; t.Ctor(); return t }
//line :145:1
func (t *A_arbace_go_repl_decl_names_group_QMARK___794000064_A) Ctor() {}
//line :145:1
func (t *A_arbace_go_repl_decl_names_group_QMARK___794000064_A) Invoke_O_O__O(self, args__1 any) any { var a__2 any; var tmp1 any; var root_445 any = A_arbace_go_repl_A_const_90.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_445, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_447 lang.IFn; if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any; var root_449 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_451 lang.IFn; if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any = args__1; if linked_450 == nil { arg_448 = ifn_451.Invoke_O__O(arg_452) } else { arg_448 = linked_450.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_449, arg_452) }; if linked_446 == nil { tmp1 = ifn_447.Invoke_O__O(arg_448) } else { tmp1 = linked_446.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_445, arg_448) }; if jrt.J2g_Truth(tmp1) { var root_453 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_453, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_455 lang.IFn; if linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any = args__1; if linked_454 == nil { a__2 = ifn_455.Invoke_O__O(arg_456) } else { a__2 = linked_454.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_453, arg_456) } } else { a__2 = args__1 }; var root_457 any = A_arbace_go_repl_A_const_91.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_459 lang.IFn; if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any = A_arbace_go_repl_A_const_92.GetRawRoot__O(); var arg_461 any = a__2; if linked_458 == nil { return ifn_459.Invoke_O_O__O(arg_460, arg_461) } else { return linked_458.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_457, arg_460, arg_461) } }
func A_arbace_go_repl_decl_names_specs__794000066_A_New() *A_arbace_go_repl_decl_names_specs__794000066_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_specs__794000066_A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_go_repl_decl_names_specs__794000066_A) Ctor() {}
//line :146:1
func (t *A_arbace_go_repl_decl_names_specs__794000066_A) Invoke_O_O__O(self, args__1 any) any { var root_463 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any; var tmp1 any; var root_467 any = A_arbace_go_repl_A_const_90.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_469 lang.IFn; if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any; var root_471 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_473 lang.IFn; if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = args__1; if linked_472 == nil { arg_470 = ifn_473.Invoke_O__O(arg_474) } else { arg_470 = linked_472.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_471, arg_474) }; if linked_468 == nil { tmp1 = ifn_469.Invoke_O__O(arg_470) } else { tmp1 = linked_468.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_467, arg_470) }; if jrt.J2g_Truth(tmp1) { var root_475 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = args__1; if linked_476 == nil { arg_466 = ifn_477.Invoke_O__O(arg_478) } else { arg_466 = linked_476.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_475, arg_478) } } else { arg_466 = args__1 }; if linked_464 == nil { return ifn_465.Invoke_O__O(arg_466) } else { return linked_464.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_463, arg_466) } }











func A_arbace_go_repl_decl_names_iter__794000085__794000091_A_New_O(p0 any) *A_arbace_go_repl_decl_names_iter__794000085__794000091_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_iter__794000085__794000091_A{}; t.Ctor_O(p0); return t }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000085__794000091_A) Ctor_O(c__targets any) { t.F_targets = c__targets }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000085__794000091_A) Invoke_O_O__O(self, s__794000086__1 any) any { var tmp1 any = A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_A_New_O_O_O(self, s__794000086__1, t.F_targets); var tmp2 *jrt.Class; var fncls__648 *jrt.Class = A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_A_fn_class; if fncls__648 == nil { var fncls__648d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_A_fn_class = fncls__648d; tmp2 = fncls__648d } else { tmp2 = fncls__648 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :158:1
func A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_A) Ctor_O_O_O(c__iter__794000085, c__s__794000086, c__targets any) { t.F_iter__794000085 = c__iter__794000085; t.F_s__794000086 = c__s__794000086; t.F_targets = c__targets }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_A) Invoke_O__O(self any) any { { var s__794000086__1 any; var t_ any = t.F_s__794000086; t.F_s__794000086 = nil; s__794000086__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_556 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_556, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_558 lang.IFn; if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any = s__794000086__1; if linked_557 == nil { temp__1927000414__auto____2 = ifn_558.Invoke_O__O(arg_559) } else { temp__1927000414__auto____2 = linked_557.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_556, arg_559) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__794000093__4 any; var root_560 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = xs__1927001018__auto____3; if linked_561 == nil { vec__794000093__4 = ifn_562.Invoke_O__O(arg_563) } else { vec__794000093__4 = linked_561.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_560, arg_563) }; var tf__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000093__4, lang.RT_IntCast_J__I_NoInit(0), nil); var iterys__1927001035__auto____6 any; var tmp1 any = A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_A_New(); var tmp2 *jrt.Class; var fncls__630 *jrt.Class = A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_A_fn_class; if fncls__630 == nil { var fncls__630d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_A_fn_class = fncls__630d; tmp2 = fncls__630d } else { tmp2 = fncls__630 }; iterys__1927001035__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____7 any; var root_631 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_633 lang.IFn; if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = lang.IFn_Cast(iterys__1927001035__auto____6).Invoke_O__O(lang.IFn_Cast(t.F_targets).Invoke_O__O(tf__5)); if linked_632 == nil { fs__1927001036__auto____7 = ifn_633.Invoke_O__O(arg_634) } else { fs__1927001036__auto____7 = linked_632.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_631, arg_634) }; if jrt.J2g_Truth(fs__1927001036__auto____7) { var root_635 any = A_arbace_go_repl_A_const_101.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_635, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_637 lang.IFn; if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any = fs__1927001036__auto____7; var arg_639 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__794000085); var tmp4 any; var root_640 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_642 lang.IFn; if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = s__794000086__1; if linked_641 == nil { tmp4 = ifn_642.Invoke_O__O(arg_643) } else { tmp4 = linked_641.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_640, arg_643) }; arg_639 = tmp3.Invoke_O__O(tmp4); if linked_636 == nil { return ifn_637.Invoke_O_O__O(arg_638, arg_639) } else { return linked_636.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_635, arg_638, arg_639) } } else { var tmp5 any; var root_644 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_644, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_646 lang.IFn; if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any = s__794000086__1; if linked_645 == nil { tmp5 = ifn_646.Invoke_O__O(arg_647) } else { tmp5 = linked_645.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_644, arg_647) }; s__794000086__1 = tmp5; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :158:1
func A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_A_New() *A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_A) Ctor() {}
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_A) Invoke_O_O__O(self, s__794000088__1 any) any { var tmp1 any = A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_A_New_O_O(self, s__794000088__1); var tmp2 *jrt.Class; var fncls__629 *jrt.Class = A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_A_fn_class; if fncls__629 == nil { var fncls__629d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_A_fn_class = fncls__629d; tmp2 = fncls__629d } else { tmp2 = fncls__629 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :158:1
func A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_A_New_O_O(p0, p1 any) *A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_A{}; t.Ctor_O_O(p0, p1); return t }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_A) Ctor_O_O(c__iter__794000087, c__s__794000088 any) { t.F_iter__794000087 = c__iter__794000087; t.F_s__794000088 = c__s__794000088 }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_A) Invoke_O__O(self any) any { { var s__794000088__1 any; var t_ any = t.F_s__794000088; t.F_s__794000088 = nil; s__794000088__1 = t_; for { var temp__1927000414__auto____2 any; var root_564 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_566 lang.IFn; if linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any = s__794000088__1; if linked_565 == nil { temp__1927000414__auto____2 = ifn_566.Invoke_O__O(arg_567) } else { temp__1927000414__auto____2 = linked_565.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_564, arg_567) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__794000088__3 any = temp__1927000414__auto____2; var tmp1 any; var root_568 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_570 lang.IFn; if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = s__794000088__3; if linked_569 == nil { tmp1 = ifn_570.Invoke_O__O(arg_571) } else { tmp1 = linked_569.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_568, arg_571) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_572 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_572, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_574 lang.IFn; if linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any = s__794000088__3; if linked_573 == nil { c__1927001037__auto____4 = ifn_574.Invoke_O__O(arg_575) } else { c__1927001037__auto____4 = linked_573.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_572, arg_575) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__794000090__6 any; var root_576 any = A_arbace_go_repl_A_const_95.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_576, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_578 lang.IFn; if linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_577 == nil { b__794000090__6 = ifn_578.Invoke_O__O(arg_579) } else { b__794000090__6 = linked_577.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_576, arg_579) }; var tmp2 any = A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_fn__794000098_A_New_O_I_O(b__794000090__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__589 *jrt.Class = A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_fn__794000098_A_fn_class; if fncls__589 == nil { var fncls__589d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_fn__794000098_A_fn_class = fncls__589d; tmp3 = fncls__589d } else { tmp3 = fncls__589 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_590 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_592 lang.IFn; if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any; var root_595 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_595, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_597 lang.IFn; if linked_596 == nil { ifn_597 = lang.IFn_Cast(root_595) } else { ifn_597 = nil }; var arg_598 any = b__794000090__6; if linked_596 == nil { arg_593 = ifn_597.Invoke_O__O(arg_598) } else { arg_593 = linked_596.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_595, arg_598) }; var arg_594 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__794000087); var tmp5 any; var root_599 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_599, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_601 lang.IFn; if linked_600 == nil { ifn_601 = lang.IFn_Cast(root_599) } else { ifn_601 = nil }; var arg_602 any = s__794000088__3; if linked_600 == nil { tmp5 = ifn_601.Invoke_O__O(arg_602) } else { tmp5 = linked_600.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_599, arg_602) }; arg_594 = tmp4.Invoke_O__O(tmp5); if linked_591 == nil { return ifn_592.Invoke_O_O__O(arg_593, arg_594) } else { return linked_591.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_590, arg_593, arg_594) } } else { var root_603 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_605 lang.IFn; if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any; var root_608 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_608, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_610 lang.IFn; if linked_609 == nil { ifn_610 = lang.IFn_Cast(root_608) } else { ifn_610 = nil }; var arg_611 any = b__794000090__6; if linked_609 == nil { arg_606 = ifn_610.Invoke_O__O(arg_611) } else { arg_606 = linked_609.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_608, arg_611) }; var arg_607 any; if linked_604 == nil { return ifn_605.Invoke_O_O__O(arg_606, arg_607) } else { return linked_604.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_603, arg_606, arg_607) } } } else { var x__4 any; var root_612 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_612, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_614 lang.IFn; if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any = s__794000088__3; if linked_613 == nil { x__4 = ifn_614.Invoke_O__O(arg_615) } else { x__4 = linked_613.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_612, arg_615) }; var root_616 any = A_arbace_go_repl_A_const_100.GetRawRoot__O(); var linked_617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_616, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_618 lang.IFn; if linked_617 == nil { ifn_618 = lang.IFn_Cast(root_616) } else { ifn_618 = nil }; var arg_619 any; var root_621 any = A_arbace_go_repl_A_const_73.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any = x__4; if linked_622 == nil { arg_619 = ifn_623.Invoke_O__O(arg_624) } else { arg_619 = linked_622.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_621, arg_624) }; var arg_620 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__794000087); var tmp7 any; var root_625 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = s__794000088__3; if linked_626 == nil { tmp7 = ifn_627.Invoke_O__O(arg_628) } else { tmp7 = linked_626.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_625, arg_628) }; arg_620 = tmp6.Invoke_O__O(tmp7); if linked_617 == nil { return ifn_618.Invoke_O_O__O(arg_619, arg_620) } else { return linked_617.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_616, arg_619, arg_620) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :158:1
func A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_fn__794000098_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_fn__794000098_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_fn__794000098_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_fn__794000098_A) Ctor_O_I_O(c__b__794000090 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__794000090 = c__b__794000090; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_fn__794000098_A) Invoke_O__O(self any) any { { var i__794000089__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__794000089__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var x__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__794000089__1)); var root_580 any = A_arbace_go_repl_A_const_96.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_580, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_582 lang.IFn; if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any = t.F_b__794000090; var arg_584 any; var root_585 any = A_arbace_go_repl_A_const_73.GetRawRoot__O(); var linked_586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_585, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_587 lang.IFn; if linked_586 == nil { ifn_587 = lang.IFn_Cast(root_585) } else { ifn_587 = nil }; var arg_588 any = x__2; if linked_586 == nil { arg_584 = ifn_587.Invoke_O__O(arg_588) } else { arg_584 = linked_586.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_585, arg_588) }; if linked_581 == nil { ifn_582.Invoke_O_O__O(arg_583, arg_584) } else { linked_581.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_580, arg_583, arg_584) }; i__794000089__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000089__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :158:1
func A_arbace_go_repl_decl_names_iter__794000104__794000110_A_New_O(p0 any) *A_arbace_go_repl_decl_names_iter__794000104__794000110_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_iter__794000104__794000110_A{}; t.Ctor_O(p0); return t }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000104__794000110_A) Ctor_O(c__targets any) { t.F_targets = c__targets }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000104__794000110_A) Invoke_O_O__O(self, s__794000105__1 any) any { var tmp1 any = A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_A_New_O_O_O(s__794000105__1, t.F_targets, self); var tmp2 *jrt.Class; var fncls__759 *jrt.Class = A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_A_fn_class; if fncls__759 == nil { var fncls__759d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_A_fn_class = fncls__759d; tmp2 = fncls__759d } else { tmp2 = fncls__759 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :158:1
func A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_A) Ctor_O_O_O(c__s__794000105, c__targets, c__iter__794000104 any) { t.F_s__794000105 = c__s__794000105; t.F_targets = c__targets; t.F_iter__794000104 = c__iter__794000104 }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_A) Invoke_O__O(self any) any { { var s__794000105__1 any; var t_ any = t.F_s__794000105; t.F_s__794000105 = nil; s__794000105__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_667 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_669 lang.IFn; if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = s__794000105__1; if linked_668 == nil { temp__1927000414__auto____2 = ifn_669.Invoke_O__O(arg_670) } else { temp__1927000414__auto____2 = linked_668.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_667, arg_670) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__794000112__4 any; var root_671 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_671, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_673 lang.IFn; if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any = xs__1927001018__auto____3; if linked_672 == nil { vec__794000112__4 = ifn_673.Invoke_O__O(arg_674) } else { vec__794000112__4 = linked_672.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_671, arg_674) }; var tf__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000112__4, lang.RT_IntCast_J__I_NoInit(0), nil); var iterys__1927001035__auto____6 any; var tmp1 any = A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_A_New(); var tmp2 *jrt.Class; var fncls__741 *jrt.Class = A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_A_fn_class; if fncls__741 == nil { var fncls__741d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_A_fn_class = fncls__741d; tmp2 = fncls__741d } else { tmp2 = fncls__741 }; iterys__1927001035__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____7 any; var root_742 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_742, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_744 lang.IFn; if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any = lang.IFn_Cast(iterys__1927001035__auto____6).Invoke_O__O(lang.IFn_Cast(t.F_targets).Invoke_O__O(tf__5)); if linked_743 == nil { fs__1927001036__auto____7 = ifn_744.Invoke_O__O(arg_745) } else { fs__1927001036__auto____7 = linked_743.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_742, arg_745) }; if jrt.J2g_Truth(fs__1927001036__auto____7) { var root_746 any = A_arbace_go_repl_A_const_101.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_746, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_748 lang.IFn; if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any = fs__1927001036__auto____7; var arg_750 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__794000104); var tmp4 any; var root_751 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_751, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_753 lang.IFn; if linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any = s__794000105__1; if linked_752 == nil { tmp4 = ifn_753.Invoke_O__O(arg_754) } else { tmp4 = linked_752.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_751, arg_754) }; arg_750 = tmp3.Invoke_O__O(tmp4); if linked_747 == nil { return ifn_748.Invoke_O_O__O(arg_749, arg_750) } else { return linked_747.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_746, arg_749, arg_750) } } else { var tmp5 any; var root_755 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_755, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_757 lang.IFn; if linked_756 == nil { ifn_757 = lang.IFn_Cast(root_755) } else { ifn_757 = nil }; var arg_758 any = s__794000105__1; if linked_756 == nil { tmp5 = ifn_757.Invoke_O__O(arg_758) } else { tmp5 = linked_756.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_755, arg_758) }; s__794000105__1 = tmp5; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :158:1
func A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_A_New() *A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_A) Ctor() {}
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_A) Invoke_O_O__O(self, s__794000107__1 any) any { var tmp1 any = A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_A_New_O_O(self, s__794000107__1); var tmp2 *jrt.Class; var fncls__740 *jrt.Class = A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_A_fn_class; if fncls__740 == nil { var fncls__740d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_A_fn_class = fncls__740d; tmp2 = fncls__740d } else { tmp2 = fncls__740 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :158:1
func A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_A_New_O_O(p0, p1 any) *A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_A{}; t.Ctor_O_O(p0, p1); return t }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_A) Ctor_O_O(c__iter__794000106, c__s__794000107 any) { t.F_iter__794000106 = c__iter__794000106; t.F_s__794000107 = c__s__794000107 }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_A) Invoke_O__O(self any) any { { var s__794000107__1 any; var t_ any = t.F_s__794000107; t.F_s__794000107 = nil; s__794000107__1 = t_; for { var temp__1927000414__auto____2 any; var root_675 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_677 lang.IFn; if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any = s__794000107__1; if linked_676 == nil { temp__1927000414__auto____2 = ifn_677.Invoke_O__O(arg_678) } else { temp__1927000414__auto____2 = linked_676.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_675, arg_678) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__794000107__3 any = temp__1927000414__auto____2; var tmp1 any; var root_679 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = s__794000107__3; if linked_680 == nil { tmp1 = ifn_681.Invoke_O__O(arg_682) } else { tmp1 = linked_680.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_679, arg_682) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_683 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_685 lang.IFn; if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any = s__794000107__3; if linked_684 == nil { c__1927001037__auto____4 = ifn_685.Invoke_O__O(arg_686) } else { c__1927001037__auto____4 = linked_684.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_683, arg_686) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__794000109__6 any; var root_687 any = A_arbace_go_repl_A_const_95.GetRawRoot__O(); var linked_688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_687, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_689 lang.IFn; if linked_688 == nil { ifn_689 = lang.IFn_Cast(root_687) } else { ifn_689 = nil }; var arg_690 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_688 == nil { b__794000109__6 = ifn_689.Invoke_O__O(arg_690) } else { b__794000109__6 = linked_688.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_687, arg_690) }; var tmp2 any = A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_fn__794000117_A_New_O_I_O(b__794000109__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__700 *jrt.Class = A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_fn__794000117_A_fn_class; if fncls__700 == nil { var fncls__700d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_fn__794000117_A_fn_class = fncls__700d; tmp3 = fncls__700d } else { tmp3 = fncls__700 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_701 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_701, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_703 lang.IFn; if linked_702 == nil { ifn_703 = lang.IFn_Cast(root_701) } else { ifn_703 = nil }; var arg_704 any; var root_706 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_706, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_708 lang.IFn; if linked_707 == nil { ifn_708 = lang.IFn_Cast(root_706) } else { ifn_708 = nil }; var arg_709 any = b__794000109__6; if linked_707 == nil { arg_704 = ifn_708.Invoke_O__O(arg_709) } else { arg_704 = linked_707.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_706, arg_709) }; var arg_705 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__794000106); var tmp5 any; var root_710 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_710, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_712 lang.IFn; if linked_711 == nil { ifn_712 = lang.IFn_Cast(root_710) } else { ifn_712 = nil }; var arg_713 any = s__794000107__3; if linked_711 == nil { tmp5 = ifn_712.Invoke_O__O(arg_713) } else { tmp5 = linked_711.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_710, arg_713) }; arg_705 = tmp4.Invoke_O__O(tmp5); if linked_702 == nil { return ifn_703.Invoke_O_O__O(arg_704, arg_705) } else { return linked_702.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_701, arg_704, arg_705) } } else { var root_714 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_714, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_716 lang.IFn; if linked_715 == nil { ifn_716 = lang.IFn_Cast(root_714) } else { ifn_716 = nil }; var arg_717 any; var root_719 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_721 lang.IFn; if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = b__794000109__6; if linked_720 == nil { arg_717 = ifn_721.Invoke_O__O(arg_722) } else { arg_717 = linked_720.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_719, arg_722) }; var arg_718 any; if linked_715 == nil { return ifn_716.Invoke_O_O__O(arg_717, arg_718) } else { return linked_715.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_714, arg_717, arg_718) } } } else { var x__4 any; var root_723 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_723, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_725 lang.IFn; if linked_724 == nil { ifn_725 = lang.IFn_Cast(root_723) } else { ifn_725 = nil }; var arg_726 any = s__794000107__3; if linked_724 == nil { x__4 = ifn_725.Invoke_O__O(arg_726) } else { x__4 = linked_724.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_723, arg_726) }; var root_727 any = A_arbace_go_repl_A_const_100.GetRawRoot__O(); var linked_728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_727, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_729 lang.IFn; if linked_728 == nil { ifn_729 = lang.IFn_Cast(root_727) } else { ifn_729 = nil }; var arg_730 any; var root_732 any = A_arbace_go_repl_A_const_73.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_732, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_734 lang.IFn; if linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = x__4; if linked_733 == nil { arg_730 = ifn_734.Invoke_O__O(arg_735) } else { arg_730 = linked_733.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_732, arg_735) }; var arg_731 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__794000106); var tmp7 any; var root_736 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_736, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_738 lang.IFn; if linked_737 == nil { ifn_738 = lang.IFn_Cast(root_736) } else { ifn_738 = nil }; var arg_739 any = s__794000107__3; if linked_737 == nil { tmp7 = ifn_738.Invoke_O__O(arg_739) } else { tmp7 = linked_737.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_736, arg_739) }; arg_731 = tmp6.Invoke_O__O(tmp7); if linked_728 == nil { return ifn_729.Invoke_O_O__O(arg_730, arg_731) } else { return linked_728.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_727, arg_730, arg_731) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :158:1
func A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_fn__794000117_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_fn__794000117_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_fn__794000117_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_fn__794000117_A) Ctor_O_I_O(c__b__794000109 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__794000109 = c__b__794000109; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_fn__794000117_A) Invoke_O__O(self any) any { { var i__794000108__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__794000108__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var x__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__794000108__1)); var root_691 any = A_arbace_go_repl_A_const_96.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_693 lang.IFn; if linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any = t.F_b__794000109; var arg_695 any; var root_696 any = A_arbace_go_repl_A_const_73.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_696, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_698 lang.IFn; if linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any = x__2; if linked_697 == nil { arg_695 = ifn_698.Invoke_O__O(arg_699) } else { arg_695 = linked_697.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_696, arg_699) }; if linked_692 == nil { ifn_693.Invoke_O_O__O(arg_694, arg_695) } else { linked_692.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_691, arg_694, arg_695) }; i__794000108__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000108__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_go_repl_decl_names_iter__794000069__794000073_A_New() *A_arbace_go_repl_decl_names_iter__794000069__794000073_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_iter__794000069__794000073_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_go_repl_decl_names_iter__794000069__794000073_A) Ctor() {}
//line :161:1
func (t *A_arbace_go_repl_decl_names_iter__794000069__794000073_A) Invoke_O_O__O(self, s__794000070__1 any) any { var tmp1 any = A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_A_New_O_O(s__794000070__1, self); var tmp2 *jrt.Class; var fncls__550 *jrt.Class = A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_A_fn_class; if fncls__550 == nil { var fncls__550d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_A_fn_class = fncls__550d; tmp2 = fncls__550d } else { tmp2 = fncls__550 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :161:1
func A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_A_New_O_O(p0, p1 any) *A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_A{}; t.Ctor_O_O(p0, p1); return t }
//line :161:1
func (t *A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_A) Ctor_O_O(c__s__794000070, c__iter__794000069 any) { t.F_s__794000070 = c__s__794000070; t.F_iter__794000069 = c__iter__794000069 }
//line :161:1
func (t *A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_A) Invoke_O__O(self any) any { { var s__794000070__1 any; var t_ any = t.F_s__794000070; t.F_s__794000070 = nil; s__794000070__1 = t_; for { var temp__1927000414__auto____2 any; var root_485 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_487 lang.IFn; if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = s__794000070__1; if linked_486 == nil { temp__1927000414__auto____2 = ifn_487.Invoke_O__O(arg_488) } else { temp__1927000414__auto____2 = linked_486.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_485, arg_488) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__794000070__3 any = temp__1927000414__auto____2; var tmp1 any; var root_489 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_489, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_491 lang.IFn; if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any = s__794000070__3; if linked_490 == nil { tmp1 = ifn_491.Invoke_O__O(arg_492) } else { tmp1 = linked_490.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_489, arg_492) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_493 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_493, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_495 lang.IFn; if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any = s__794000070__3; if linked_494 == nil { c__1927001037__auto____4 = ifn_495.Invoke_O__O(arg_496) } else { c__1927001037__auto____4 = linked_494.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_493, arg_496) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__794000072__6 any; var root_497 any = A_arbace_go_repl_A_const_95.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_499 lang.IFn; if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_498 == nil { b__794000072__6 = ifn_499.Invoke_O__O(arg_500) } else { b__794000072__6 = linked_498.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_497, arg_500) }; var tmp2 any = A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_fn__794000075_A_New_O_I_O(b__794000072__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__510 *jrt.Class = A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_fn__794000075_A_fn_class; if fncls__510 == nil { var fncls__510d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_fn__794000075_A_fn_class = fncls__510d; tmp3 = fncls__510d } else { tmp3 = fncls__510 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_511 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any; var root_516 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_516, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_518 lang.IFn; if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any = b__794000072__6; if linked_517 == nil { arg_514 = ifn_518.Invoke_O__O(arg_519) } else { arg_514 = linked_517.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_516, arg_519) }; var arg_515 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__794000069); var tmp5 any; var root_520 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_520, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_522 lang.IFn; if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any = s__794000070__3; if linked_521 == nil { tmp5 = ifn_522.Invoke_O__O(arg_523) } else { tmp5 = linked_521.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_520, arg_523) }; arg_515 = tmp4.Invoke_O__O(tmp5); if linked_512 == nil { return ifn_513.Invoke_O_O__O(arg_514, arg_515) } else { return linked_512.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_511, arg_514, arg_515) } } else { var root_524 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_524, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_526 lang.IFn; if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any; var root_529 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = b__794000072__6; if linked_530 == nil { arg_527 = ifn_531.Invoke_O__O(arg_532) } else { arg_527 = linked_530.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_529, arg_532) }; var arg_528 any; if linked_525 == nil { return ifn_526.Invoke_O_O__O(arg_527, arg_528) } else { return linked_525.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_524, arg_527, arg_528) } } } else { var vec__794000080__4 any; var root_533 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_535 lang.IFn; if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = s__794000070__3; if linked_534 == nil { vec__794000080__4 = ifn_535.Invoke_O__O(arg_536) } else { vec__794000080__4 = linked_534.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_533, arg_536) }; var nf__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000080__4, lang.RT_IntCast_J__I_NoInit(0), nil); var root_537 any = A_arbace_go_repl_A_const_100.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any; var root_542 any = A_arbace_go_repl_A_const_73.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any = nf__5; if linked_543 == nil { arg_540 = ifn_544.Invoke_O__O(arg_545) } else { arg_540 = linked_543.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_542, arg_545) }; var arg_541 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__794000069); var tmp7 any; var root_546 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_546, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_548 lang.IFn; if linked_547 == nil { ifn_548 = lang.IFn_Cast(root_546) } else { ifn_548 = nil }; var arg_549 any = s__794000070__3; if linked_547 == nil { tmp7 = ifn_548.Invoke_O__O(arg_549) } else { tmp7 = linked_547.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_546, arg_549) }; arg_541 = tmp6.Invoke_O__O(tmp7); if linked_538 == nil { return ifn_539.Invoke_O_O__O(arg_540, arg_541) } else { return linked_538.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_537, arg_540, arg_541) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :161:1
func A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_fn__794000075_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_fn__794000075_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_fn__794000075_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :161:1
func (t *A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_fn__794000075_A) Ctor_O_I_O(c__b__794000072 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__794000072 = c__b__794000072; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :161:1
func (t *A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_fn__794000075_A) Invoke_O__O(self any) any { { var i__794000071__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__794000071__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__794000076__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__794000071__1)); var nf__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000076__2, lang.RT_IntCast_J__I_NoInit(0), nil); var root_501 any = A_arbace_go_repl_A_const_96.GetRawRoot__O(); var linked_502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_501, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_503 lang.IFn; if linked_502 == nil { ifn_503 = lang.IFn_Cast(root_501) } else { ifn_503 = nil }; var arg_504 any = t.F_b__794000072; var arg_505 any; var root_506 any = A_arbace_go_repl_A_const_73.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_508 lang.IFn; if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = nf__3; if linked_507 == nil { arg_505 = ifn_508.Invoke_O__O(arg_509) } else { arg_505 = linked_507.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_506, arg_509) }; if linked_502 == nil { ifn_503.Invoke_O_O__O(arg_504, arg_505) } else { linked_502.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_501, arg_504, arg_505) }; i__794000071__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000071__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_go_repl_error_text_A_New() *A_arbace_go_repl_error_text_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_error_text_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_go_repl_error_text_A) Ctor() {}
//line :167:1
func (t *A_arbace_go_repl_error_text_A) Invoke_O_O_O__O(self, errs__0, src__1 any) any {




	var root_856 any = A_arbace_go_repl_A_const_48.GetRawRoot__O(); var linked_857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_856, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_858 lang.IFn; if linked_857 == nil { ifn_858 = lang.IFn_Cast(root_856) } else { ifn_858 = nil }; var arg_859 any = Lit_109; var arg_860 any; var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_go_repl_error_text_iter__794000124__794000128_A_New_O(src__1); var tmp2 *jrt.Class; var fncls__919 *jrt.Class = A_arbace_go_repl_error_text_iter__794000124__794000128_A_fn_class; if fncls__919 == nil { var fncls__919d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_110, false); A_arbace_go_repl_error_text_iter__794000124__794000128_A_fn_class = fncls__919d; tmp2 = fncls__919d } else { tmp2 = fncls__919 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var root_920 any = A_arbace_go_repl_A_const_113.GetRawRoot__O(); var linked_921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_920, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_922 lang.IFn; if linked_921 == nil { ifn_922 = lang.IFn_Cast(root_920) } else { ifn_922 = nil }; var arg_923 any = A_arbace_go_repl_A_const_114; var arg_924 any = errs__0; if linked_921 == nil { tmp4 = ifn_922.Invoke_O_O__O(arg_923, arg_924) } else { tmp4 = linked_921.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_920, arg_923, arg_924) }; arg_860 = tmp3.Invoke_O__O(tmp4); if linked_857 == nil { return ifn_858.Invoke_O_O__O(arg_859, arg_860) } else { return linked_857.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_856, arg_859, arg_860) } }
//line :167:1
func (t *A_arbace_go_repl_error_text_A) Invoke_O_O__O(self, errs__0 any) any {


	var root_925 any = A_arbace_go_repl_A_const_115.GetRawRoot__O(); var linked_926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_925, A_arbace_go_repl_error_text_A_fn_class); var ifn_927 lang.IFn; if linked_926 == nil { ifn_927 = lang.IFn_Cast(root_925) } else { ifn_927 = nil }; var arg_928 any = errs__0; var arg_929 any; if linked_926 == nil { return ifn_927.Invoke_O_O__O(arg_928, arg_929) } else { return linked_926.(*A_arbace_go_repl_error_text_A).Invoke_O_O_O__O(root_925, arg_928, arg_929)
	} }
func A_arbace_go_repl_error_text_iter__794000124__794000128_A_New_O(p0 any) *A_arbace_go_repl_error_text_iter__794000124__794000128_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_error_text_iter__794000124__794000128_A{}; t.Ctor_O(p0); return t }
//line :172:1
func (t *A_arbace_go_repl_error_text_iter__794000124__794000128_A) Ctor_O(c__src any) { t.F_src = c__src }
//line :172:1
func (t *A_arbace_go_repl_error_text_iter__794000124__794000128_A) Invoke_O_O__O(self, s__794000125__1 any) any { var tmp1 any = A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_A_New_O_O_O(s__794000125__1, t.F_src, self); var tmp2 *jrt.Class; var fncls__918 *jrt.Class = A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_A_fn_class; if fncls__918 == nil { var fncls__918d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_111, false); A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_A_fn_class = fncls__918d; tmp2 = fncls__918d } else { tmp2 = fncls__918 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :172:1
func A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :172:1
func (t *A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_A) Ctor_O_O_O(c__s__794000125, c__src, c__iter__794000124 any) { t.F_s__794000125 = c__s__794000125; t.F_src = c__src; t.F_iter__794000124 = c__iter__794000124 }
//line :172:1
func (t *A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_A) Invoke_O__O(self any) any { { var s__794000125__1 any; var t_ any = t.F_s__794000125; t.F_s__794000125 = nil; s__794000125__1 = t_; for { var temp__1927000414__auto____2 any; var root_861 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = s__794000125__1; if linked_862 == nil { temp__1927000414__auto____2 = ifn_863.Invoke_O__O(arg_864) } else { temp__1927000414__auto____2 = linked_862.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_861, arg_864) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__794000125__3 any = temp__1927000414__auto____2; var tmp1 any; var root_865 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = s__794000125__3; if linked_866 == nil { tmp1 = ifn_867.Invoke_O__O(arg_868) } else { tmp1 = linked_866.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_865, arg_868) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_869 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = s__794000125__3; if linked_870 == nil { c__1927001037__auto____4 = ifn_871.Invoke_O__O(arg_872) } else { c__1927001037__auto____4 = linked_870.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_869, arg_872) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__794000127__6 any; var root_873 any = A_arbace_go_repl_A_const_95.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_874 == nil { b__794000127__6 = ifn_875.Invoke_O__O(arg_876) } else { b__794000127__6 = linked_874.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_873, arg_876) }; var tmp2 any = A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_fn__794000130_A_New_O_O_I_O(t.F_src, b__794000127__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__882 *jrt.Class = A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_fn__794000130_A_fn_class; if fncls__882 == nil { var fncls__882d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_112, false); A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_fn__794000130_A_fn_class = fncls__882d; tmp3 = fncls__882d } else { tmp3 = fncls__882 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_883 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_883, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_885 lang.IFn; if linked_884 == nil { ifn_885 = lang.IFn_Cast(root_883) } else { ifn_885 = nil }; var arg_886 any; var root_888 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_888, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_890 lang.IFn; if linked_889 == nil { ifn_890 = lang.IFn_Cast(root_888) } else { ifn_890 = nil }; var arg_891 any = b__794000127__6; if linked_889 == nil { arg_886 = ifn_890.Invoke_O__O(arg_891) } else { arg_886 = linked_889.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_888, arg_891) }; var arg_887 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__794000124); var tmp5 any; var root_892 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_892, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_894 lang.IFn; if linked_893 == nil { ifn_894 = lang.IFn_Cast(root_892) } else { ifn_894 = nil }; var arg_895 any = s__794000125__3; if linked_893 == nil { tmp5 = ifn_894.Invoke_O__O(arg_895) } else { tmp5 = linked_893.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_892, arg_895) }; arg_887 = tmp4.Invoke_O__O(tmp5); if linked_884 == nil { return ifn_885.Invoke_O_O__O(arg_886, arg_887) } else { return linked_884.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_883, arg_886, arg_887) } } else { var root_896 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_896, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_898 lang.IFn; if linked_897 == nil { ifn_898 = lang.IFn_Cast(root_896) } else { ifn_898 = nil }; var arg_899 any; var root_901 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_901, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_903 lang.IFn; if linked_902 == nil { ifn_903 = lang.IFn_Cast(root_901) } else { ifn_903 = nil }; var arg_904 any = b__794000127__6; if linked_902 == nil { arg_899 = ifn_903.Invoke_O__O(arg_904) } else { arg_899 = linked_902.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_901, arg_904) }; var arg_900 any; if linked_897 == nil { return ifn_898.Invoke_O_O__O(arg_899, arg_900) } else { return linked_897.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_896, arg_899, arg_900) } } } else { var er__4 any; var root_905 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_905, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_907 lang.IFn; if linked_906 == nil { ifn_907 = lang.IFn_Cast(root_905) } else { ifn_907 = nil }; var arg_908 any = s__794000125__3; if linked_906 == nil { er__4 = ifn_907.Invoke_O__O(arg_908) } else { er__4 = linked_906.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_905, arg_908) }; var root_909 any = A_arbace_go_repl_A_const_100.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_911 lang.IFn; if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_113, nil, Lit_114, nil); var tmp7 any; var tmp8 any; var and__1927000168__auto____10 any = t.F_src
														if jrt.J2g_Truth(and__1927000168__auto____10) { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_115, A_arbace_go_repl_A_const_110.Invoke_O__O(er__4))).Ref() } else { tmp8 = and__1927000168__auto____10 }; if jrt.J2g_Truth(tmp8) { tmp7 = t.F_src } else { tmp7 = A_arbace_go_repl_A_const_110.Invoke_O__O(er__4) }; arg_912 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7, nil, A_arbace_go_repl_A_const_111.Invoke_O__O(er__4), nil, A_arbace_go_repl_A_const_112.Invoke_O__O(er__4))).Ref()
//line :172:1
	var arg_913 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__794000124); var tmp10 any; var root_914 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_914, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_916 lang.IFn; if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any = s__794000125__3; if linked_915 == nil { tmp10 = ifn_916.Invoke_O__O(arg_917) } else { tmp10 = linked_915.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_914, arg_917) }; arg_913 = tmp9.Invoke_O__O(tmp10); if linked_910 == nil { return ifn_911.Invoke_O_O__O(arg_912, arg_913) } else { return linked_910.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_909, arg_912, arg_913) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :172:1
func A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_fn__794000130_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_fn__794000130_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_fn__794000130_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :172:1
func (t *A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_fn__794000130_A) Ctor_O_O_I_O(c__src, c__b__794000127 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_src = c__src; t.F_b__794000127 = c__b__794000127; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :172:1
func (t *A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_fn__794000130_A) Invoke_O__O(self any) any { { var i__794000126__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__794000126__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var er__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__794000126__1)); var root_877 any = A_arbace_go_repl_A_const_96.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_879 lang.IFn; if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any = t.F_b__794000127; var arg_881 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_113, nil, Lit_114, nil); var tmp3 any; var tmp4 any; var and__1927000168__auto____8 any = t.F_src
																if jrt.J2g_Truth(and__1927000168__auto____8) { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_115, A_arbace_go_repl_A_const_110.Invoke_O__O(er__2))).Ref() } else { tmp4 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp4) { tmp3 = t.F_src } else { tmp3 = A_arbace_go_repl_A_const_110.Invoke_O__O(er__2) }; arg_881 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, A_arbace_go_repl_A_const_111.Invoke_O__O(er__2), nil, A_arbace_go_repl_A_const_112.Invoke_O__O(er__2))).Ref()
//line :172:1
	if linked_878 == nil { ifn_879.Invoke_O_O__O(arg_880, arg_881) } else { linked_878.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_877, arg_880, arg_881) }; i__794000126__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000126__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_go_repl_repl_source_A_New() *A_arbace_go_repl_repl_source_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_repl_source_A{}; t.Ctor(); return t }
//line :175:1
func (t *A_arbace_go_repl_repl_source_A) Ctor() {}
//line :175:1
func (t *A_arbace_go_repl_repl_source_A) Invoke_O__O(self any) any { var f__1 any; var root_930 any = A_arbace_go_repl_A_const_51.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_930, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_932 lang.IFn; if linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any = A_arbace_go_repl_A_const_116.Get__O(); if linked_931 == nil { f__1 = ifn_932.Invoke_O__O(arg_933) } else { f__1 = linked_931.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_930, arg_933) }; var tmp1 bool; var or__1927000174__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(f__1, Lit_148); if or__1927000174__auto____2 { tmp1 = or__1927000174__auto____2 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(f__1, Lit_149) }; if tmp1 { return Lit_150 } else { return f__1 } }

func A_arbace_go_repl_source_of_A_New() *A_arbace_go_repl_source_of_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_source_of_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_go_repl_source_of_A) Ctor() {}
//line :177:1
func (t *A_arbace_go_repl_source_of_A) Invoke_O_O__O(self, st__0 any) any { var s__2 any; var root_934 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_934, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_936 lang.IFn; if


	linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any = st__0; if linked_935 == nil { s__2 = ifn_936.Invoke_O__O(arg_937) } else { s__2 = linked_935.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_934, arg_937) }; var tmp1 any = A_arbace_go_repl_A_const_54; var tmp2 any = /*line :177:1*/A_arbace_go_repl_A_const_54.Invoke_O__O(s__2); var tmp3 any = A_arbace_go_repl_A_const_55; var tmp4 any = A_arbace_go_repl_A_const_55.Invoke_O__O(s__2); var tmp5 any = A_arbace_go_repl_A_const_36; var tmp6 any = A_arbace_go_repl_A_const_36.Invoke_O__O(s__2); var tmp7 any = A_arbace_go_repl_A_const_74; var tmp8 any; var or__1927000174__auto____3 any = A_arbace_go_repl_A_const_74.Invoke_O__O(s__2); if



	jrt.J2g_Truth(or__1927000174__auto____3) { tmp8 = or__1927000174__auto____3 } else { tmp8 = lang.PersistentArrayMap_EMPTY.Ref() }; var tmp9 any = tmp8; var tmp10 any = A_arbace_go_repl_A_const_57; var tmp11 any; var root_938 any = /*line :177:1*/A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_938, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_940 lang.IFn; if




	linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any; var iter__1927001039__auto____3 any; var tmp12 any = A_arbace_go_repl_source_of_iter__794000136__794000140_A_New(); var tmp13 *jrt.Class; var fncls__1012 *jrt.Class = A_arbace_go_repl_source_of_iter__794000136__794000140_A_fn_class; if fncls__1012 == nil { var fncls__1012d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_154, false); A_arbace_go_repl_source_of_iter__794000136__794000140_A_fn_class = fncls__1012d; tmp13 = fncls__1012d } else { tmp13 = fncls__1012 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); arg_941 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(A_arbace_go_repl_A_const_57.Invoke_O__O(s__2)); if linked_939 == nil { tmp11 = ifn_940.Invoke_O__O(arg_941) } else { tmp11 = linked_939.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_938, arg_941) }; return /*line :177:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp9, tmp10, tmp11)) }




func A_arbace_go_repl_source_of_iter__794000136__794000140_A_New() *A_arbace_go_repl_source_of_iter__794000136__794000140_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_source_of_iter__794000136__794000140_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_go_repl_source_of_iter__794000136__794000140_A) Ctor() {}
//line :182:1
func (t *A_arbace_go_repl_source_of_iter__794000136__794000140_A) Invoke_O_O__O(self, s__794000137__1 any) any { var tmp1 any = A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_A_New_O_O(s__794000137__1, self); var tmp2 *jrt.Class; var fncls__1011 *jrt.Class = A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_A_fn_class; if fncls__1011 == nil { var fncls__1011d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_155, false); A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_A_fn_class = fncls__1011d; tmp2 = fncls__1011d } else { tmp2 = fncls__1011 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :182:1
func A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_A_New_O_O(p0, p1 any) *A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_A{}; t.Ctor_O_O(p0, p1); return t }
//line :182:1
func (t *A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_A) Ctor_O_O(c__s__794000137, c__iter__794000136 any) { t.F_s__794000137 = c__s__794000137; t.F_iter__794000136 = c__iter__794000136 }
//line :182:1
func (t *A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_A) Invoke_O__O(self any) any { { var s__794000137__1 any; var t_ any = t.F_s__794000137; t.F_s__794000137 = nil; s__794000137__1 = t_; for { var temp__1927000414__auto____2 any; var root_942 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_942, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_944 lang.IFn; if linked_943 == nil { ifn_944 = lang.IFn_Cast(root_942) } else { ifn_944 = nil }; var arg_945 any = s__794000137__1; if linked_943 == nil { temp__1927000414__auto____2 = ifn_944.Invoke_O__O(arg_945) } else { temp__1927000414__auto____2 = linked_943.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_942, arg_945) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__794000137__3 any = temp__1927000414__auto____2; var tmp1 any; var root_946 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_948 lang.IFn; if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any = s__794000137__3; if linked_947 == nil { tmp1 = ifn_948.Invoke_O__O(arg_949) } else { tmp1 = linked_947.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_946, arg_949) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_950 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_950, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_952 lang.IFn; if linked_951 == nil { ifn_952 = lang.IFn_Cast(root_950) } else { ifn_952 = nil }; var arg_953 any = s__794000137__3; if linked_951 == nil { c__1927001037__auto____4 = ifn_952.Invoke_O__O(arg_953) } else { c__1927001037__auto____4 = linked_951.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_950, arg_953) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__794000139__6 any; var root_954 any = A_arbace_go_repl_A_const_95.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_954, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_956 lang.IFn; if linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; var arg_957 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_955 == nil { b__794000139__6 = ifn_956.Invoke_O__O(arg_957) } else { b__794000139__6 = linked_955.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_954, arg_957) }; var tmp2 any = A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_fn__794000142_A_New_O_I_O(b__794000139__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__969 *jrt.Class = A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_fn__794000142_A_fn_class; if fncls__969 == nil { var fncls__969d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_156, false); A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_fn__794000142_A_fn_class = fncls__969d; tmp3 = fncls__969d } else { tmp3 = fncls__969 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_970 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_970, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_972 lang.IFn; if linked_971 == nil { ifn_972 = lang.IFn_Cast(root_970) } else { ifn_972 = nil }; var arg_973 any; var root_975 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_975, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_977 lang.IFn; if linked_976 == nil { ifn_977 = lang.IFn_Cast(root_975) } else { ifn_977 = nil }; var arg_978 any = b__794000139__6; if linked_976 == nil { arg_973 = ifn_977.Invoke_O__O(arg_978) } else { arg_973 = linked_976.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_975, arg_978) }; var arg_974 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__794000136); var tmp5 any; var root_979 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_979, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_981 lang.IFn; if linked_980 == nil { ifn_981 = lang.IFn_Cast(root_979) } else { ifn_981 = nil }; var arg_982 any = s__794000137__3; if linked_980 == nil { tmp5 = ifn_981.Invoke_O__O(arg_982) } else { tmp5 = linked_980.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_979, arg_982) }; arg_974 = tmp4.Invoke_O__O(tmp5); if linked_971 == nil { return ifn_972.Invoke_O_O__O(arg_973, arg_974) } else { return linked_971.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_970, arg_973, arg_974) } } else { var root_983 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_983, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_985 lang.IFn; if linked_984 == nil { ifn_985 = lang.IFn_Cast(root_983) } else { ifn_985 = nil }; var arg_986 any; var root_988 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_990 lang.IFn; if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any = b__794000139__6; if linked_989 == nil { arg_986 = ifn_990.Invoke_O__O(arg_991) } else { arg_986 = linked_989.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_988, arg_991) }; var arg_987 any; if linked_984 == nil { return ifn_985.Invoke_O_O__O(arg_986, arg_987) } else { return linked_984.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_983, arg_986, arg_987) } } } else { var fi__4 any; var root_992 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_992, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_994 lang.IFn; if linked_993 == nil { ifn_994 = lang.IFn_Cast(root_992) } else { ifn_994 = nil }; var arg_995 any = s__794000137__3; if linked_993 == nil { fi__4 = ifn_994.Invoke_O__O(arg_995) } else { fi__4 = linked_993.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_992, arg_995) }; var root_996 any = A_arbace_go_repl_A_const_100.GetRawRoot__O(); var linked_997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_996, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_998 lang.IFn; if linked_997 == nil { ifn_998 = lang.IFn_Cast(root_996) } else { ifn_998 = nil }; var arg_999 any; var tmp6 any = A_arbace_go_repl_A_const_55; var tmp7 any = A_arbace_go_repl_A_const_55.Invoke_O__O(fi__4); var tmp8 any = A_arbace_go_repl_A_const_74; var tmp9 any; var root_1001 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var linked_1002 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1001, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1003 lang.IFn
														if linked_1002 == nil { ifn_1003 = lang.IFn_Cast(root_1001) } else { ifn_1003 = nil }; var arg_1004 any = A_arbace_go_repl_A_const_74.Invoke_O__O(fi__4); var arg_1005 any = A_arbace_go_repl_A_const_81; var arg_1006 any = A_arbace_go_repl_A_const_81.Invoke_O__O(fi__4); if linked_1002 == nil { tmp9 = ifn_1003.Invoke_O_O_O__O(arg_1004, arg_1005, arg_1006) } else { tmp9 = linked_1002.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1001, arg_1004, arg_1005, arg_1006) }
//line :182:1
	var tmp10 any = tmp9; var tmp11 any = A_arbace_go_repl_A_const_81; var tmp12 any = A_arbace_go_repl_A_const_81.Invoke_O__O(fi__4); var tmp13 any = A_arbace_go_repl_A_const_82; arg_999 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, tmp10, tmp11, tmp12, tmp13, A_arbace_go_repl_A_const_82.Invoke_O__O(fi__4))); var arg_1000 any; var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__794000136); var tmp15 any; var root_1007 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_1008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1007, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1009 lang.IFn; if linked_1008 == nil { ifn_1009 = lang.IFn_Cast(root_1007) } else { ifn_1009 = nil }; var arg_1010 any = s__794000137__3; if linked_1008 == nil { tmp15 = ifn_1009.Invoke_O__O(arg_1010) } else { tmp15 = linked_1008.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1007, arg_1010) }; arg_1000 = tmp14.Invoke_O__O(tmp15); if linked_997 == nil { return ifn_998.Invoke_O_O__O(arg_999, arg_1000) } else { return linked_997.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_996, arg_999, arg_1000) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :182:1
func A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_fn__794000142_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_fn__794000142_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_fn__794000142_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :182:1
func (t *A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_fn__794000142_A) Ctor_O_I_O(c__b__794000139 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__794000139 = c__b__794000139; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :182:1
func (t *A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_fn__794000142_A) Invoke_O__O(self any) any { { var i__794000138__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__794000138__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fi__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__794000138__1)); var root_958 any = A_arbace_go_repl_A_const_96.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_958, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any = t.F_b__794000139; var arg_962 any; var tmp2 any = A_arbace_go_repl_A_const_55; var tmp3 any = A_arbace_go_repl_A_const_55.Invoke_O__O(fi__2); var tmp4 any = A_arbace_go_repl_A_const_74; var tmp5 any; var root_963 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var linked_964 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_963, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_965 lang.IFn
															if linked_964 == nil { ifn_965 = lang.IFn_Cast(root_963) } else { ifn_965 = nil }; var arg_966 any = A_arbace_go_repl_A_const_74.Invoke_O__O(fi__2); var arg_967 any = A_arbace_go_repl_A_const_81; var arg_968 any = A_arbace_go_repl_A_const_81.Invoke_O__O(fi__2); if linked_964 == nil { tmp5 = ifn_965.Invoke_O_O_O__O(arg_966, arg_967, arg_968) } else { tmp5 = linked_964.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_963, arg_966, arg_967, arg_968) }
//line :182:1
	var tmp6 any = tmp5; var tmp7 any = A_arbace_go_repl_A_const_81; var tmp8 any = A_arbace_go_repl_A_const_81.Invoke_O__O(fi__2); var tmp9 any = A_arbace_go_repl_A_const_82; arg_962 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp6, tmp7, tmp8, tmp9, A_arbace_go_repl_A_const_82.Invoke_O__O(fi__2))); if linked_959 == nil { ifn_960.Invoke_O_O__O(arg_961, arg_962) } else { linked_959.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_958, arg_961, arg_962) }; i__794000138__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000138__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_go_repl_session_for_A_New() *A_arbace_go_repl_session_for_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_session_for_A{}; t.Ctor(); return t }
//line :188:1
func (t *A_arbace_go_repl_session_for_A) Ctor() {}
//line :188:1
func (t *A_arbace_go_repl_session_for_A) Invoke_O_O__O(self, extra_src__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_71.GetRawRoot__O()); var tmp2 any; var root_1021 any = A_arbace_go_repl_A_const_42.GetRawRoot__O(); var linked_1022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1021, aot_arbace_go_check.A_arbace_go_check_session_A_fn_class); var ifn_1023 lang.IFn; if linked_1022 == nil { ifn_1023 = lang.IFn_Cast(root_1021) } else { ifn_1023 = nil }; var arg_1024 any; var tmp3 any = A_arbace_go_repl_session_for_fn__794000147_A_New_O(extra_src__0); var tmp4 *jrt.Class; var fncls__1033 *jrt.Class = A_arbace_go_repl_session_for_fn__794000147_A_fn_class; if fncls__1033 == nil { var fncls__1033d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_152, false); A_arbace_go_repl_session_for_fn__794000147_A_fn_class = fncls__1033d; tmp4 = fncls__1033d } else { tmp4 = fncls__1033 }; arg_1024 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); if linked_1022 == nil { tmp2 = ifn_1023.Invoke_O__O(arg_1024) } else { tmp2 = linked_1022.(*aot_arbace_go_check.A_arbace_go_check_session_A).Invoke_O_O__O(root_1021, arg_1024) }; var tmp5 any = tmp2; var tmp6 any = A_arbace_go_repl_A_const_119; var tmp7 any; var root_1034 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_1035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1034, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1036 lang.IFn; if linked_1035 == nil { ifn_1036 = lang.IFn_Cast(root_1034) } else { ifn_1036 = nil }; var arg_1037 any = A_arbace_go_repl_A_const_120.GetRawRoot__O(); if linked_1035 == nil { tmp7 = ifn_1036.Invoke_O__O(arg_1037) } else { tmp7 = linked_1035.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1034, arg_1037) }; var tmp8 any = tmp7; var tmp9 any = A_arbace_go_repl_A_const_121; var tmp10 any = A_arbace_go_repl_session_for_fn__794000149_A_New(); var tmp11 *jrt.Class
	var fncls__1046 /*line :192:1*/*jrt.Class = A_arbace_go_repl_session_for_fn__794000149_A_fn_class




	if fncls__1046 == nil { var fncls__1046d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_153, false); A_arbace_go_repl_session_for_fn__794000149_A_fn_class = fncls__1046d; tmp11 = fncls__1046d } else { tmp11 = fncls__1046 }
//line :192:1
	return tmp1.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp8, tmp9, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)) }
//line :192:1
func A_arbace_go_repl_session_for_fn__794000147_A_New_O(p0 any) *A_arbace_go_repl_session_for_fn__794000147_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_session_for_fn__794000147_A{}; t.Ctor_O(p0); return t }
//line :192:1
func (t *A_arbace_go_repl_session_for_fn__794000147_A) Ctor_O(c__extra_src any) { t.F_extra_src = c__extra_src }
//line :192:1
func (t *A_arbace_go_repl_session_for_fn__794000147_A) Invoke_O_O_O__O(self, path__1, importer__2 any) any { var or__1927000174__auto____3 any; if
														jrt.J2g_Truth(t.F_extra_src) { or__1927000174__auto____3 = lang.IFn_Cast(t.F_extra_src).Invoke_O__O(path__1) } else { or__1927000174__auto____3 = nil }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var temp__1927000414__auto____4 any; var root_1025 any = A_arbace_go_repl_A_const_117.GetRawRoot__O(); var linked_1026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1025, A_arbace_go_repl_load_import_A_fn_class); var ifn_1027 lang.IFn
															if linked_1026 == nil { ifn_1027 = lang.IFn_Cast(root_1025) } else { ifn_1027 = nil }; var arg_1028 any = path__1; if linked_1026 == nil { temp__1927000414__auto____4 = ifn_1027.Invoke_O__O(arg_1028) } else { temp__1927000414__auto____4 = linked_1026.(*A_arbace_go_repl_load_import_A).Invoke_O_O__O(root_1025, arg_1028) }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var st__5 any = temp__1927000414__auto____4; var root_1029 any = A_arbace_go_repl_A_const_118.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1029, A_arbace_go_repl_source_of_A_fn_class); var ifn_1031 lang.IFn
																if linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any = st__5; if linked_1030 == nil { return ifn_1031.Invoke_O__O(arg_1032) } else { return linked_1030.(*A_arbace_go_repl_source_of_A).Invoke_O_O__O(root_1029, arg_1032) } } else {
//line :194:1
				return nil } } }


func A_arbace_go_repl_session_for_fn__794000149_A_New() *A_arbace_go_repl_session_for_fn__794000149_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_session_for_fn__794000149_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_go_repl_session_for_fn__794000149_A) Ctor() {}
//line :197:1
func (t *A_arbace_go_repl_session_for_fn__794000149_A) Invoke_O_O__O(self, path__1 any) any { var root_1038 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_1039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1038, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1040 lang.IFn; if linked_1039 == nil { ifn_1040 = lang.IFn_Cast(root_1038) } else { ifn_1040 = nil }; var arg_1041 any; var root_1042 any = A_arbace_go_repl_A_const_43.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1042, A_arbace_go_repl_listed_QMARK__A_fn_class); var ifn_1044 lang.IFn; if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any = path__1; if linked_1043 == nil { arg_1041 = ifn_1044.Invoke_O__O(arg_1045) } else { arg_1041 = linked_1043.(*A_arbace_go_repl_listed_QMARK__A).Invoke_O_O__O(root_1042, arg_1045) }; if linked_1039 == nil { return ifn_1040.Invoke_O__O(arg_1041) } else { return linked_1039.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1038, arg_1041) } }

func A_arbace_go_repl_check_source_A_New() *A_arbace_go_repl_check_source_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_check_source_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_go_repl_check_source_A) Ctor() {}
//line :199:1
func (t *A_arbace_go_repl_check_source_A) Invoke_O_O_O__O(self, src__0, extra_src__1 any) any { var s__3 any; var root_1047 any = A_arbace_go_repl_A_const_123.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1047, A_arbace_go_repl_session_for_A_fn_class); var ifn_1049 lang.IFn; if


	linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any = extra_src__1; if linked_1048 == nil { s__3 = ifn_1049.Invoke_O__O(arg_1050) } else { s__3 = linked_1048.(*A_arbace_go_repl_session_for_A).Invoke_O_O__O(root_1047, arg_1050) }; var pkg__4 any = /*line :199:1*/lang.IFn_Cast(A_arbace_go_repl_A_const_124.GetRawRoot__O()).Invoke_O_O_O_O__O(src__0, A_arbace_go_repl_A_const_125.Invoke_O_O_O__O(s__3, src__0, lang.PersistentVector_EMPTY.Ref()), A_arbace_go_repl_A_const_126, jrt.Boolean_TRUE.Ref()); var root_1058 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1058, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1060 lang.IFn; if




	linked_1059 == nil { ifn_1060 = lang.IFn_Cast(root_1058) } else { ifn_1060 = nil }; var arg_1061 any = pkg__4; var arg_1062 any = A_arbace_go_repl_A_const_128; if linked_1059 == nil { return ifn_1060.Invoke_O_O__O(arg_1061, arg_1062) } else { return linked_1059.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1058, arg_1061, arg_1062) } }



func A_arbace_go_repl_type_key_A_New() *A_arbace_go_repl_type_key_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_type_key_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_go_repl_type_key_A) Ctor() {}
//line :208:1
func (t *A_arbace_go_repl_type_key_A) Invoke_O_O_O__O(self, ty__0, gen_of__1 any) any {



	var tmp1 any; var root_1063 any = A_arbace_go_repl_A_const_129.GetRawRoot__O(); var linked_1064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1063, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_1065 lang.IFn
	if linked_1064 == nil { ifn_1065 = lang.IFn_Cast(root_1063) } else { ifn_1065 = nil }; var arg_1066 any = ty__0; if linked_1064 == nil { tmp1 = ifn_1065.Invoke_O__O(arg_1066) } else { tmp1 = linked_1064.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_1063, arg_1066) }
//line :212:1
	if jrt.J2g_Truth(tmp1) { return ty__0 } else { var tmp2 any; var root_1067 any = A_arbace_go_repl_A_const_130.GetRawRoot__O(); var linked_1068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1067, aot_arbace_go_check_types.A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_1069 lang.IFn

		if linked_1068 == nil { ifn_1069 = lang.IFn_Cast(root_1067) } else { ifn_1069 = nil }; var arg_1070 any = ty__0; if linked_1068 == nil { tmp2 = ifn_1069.Invoke_O__O(arg_1070) } else { tmp2 = linked_1068.(*aot_arbace_go_check_types.A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_1067, arg_1070) }
//line :212:1
		if jrt.J2g_Truth(tmp2) { var i__3 any; var root_1071 any = A_arbace_go_repl_A_const_131.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1071, aot_arbace_go_check_types.A_arbace_go_check_types_info_A_fn_class); var ifn_1073 lang.IFn

			if linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any = ty__0; if linked_1072 == nil { i__3 = ifn_1073.Invoke_O__O(arg_1074) } else { i__3 = linked_1072.(*aot_arbace_go_check_types.A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1071, arg_1074) }
//line :212:1
			var tmp3 any = A_arbace_go_repl_A_const_139; var tmp4 any = A_arbace_go_repl_A_const_140.Invoke_O__O(i__3); var tmp5 any = A_arbace_go_repl_A_const_55.Invoke_O__O(i__3); var tmp6 any

			if jrt.J2g_Truth(lang.IFn_Cast(gen_of__1).Invoke_O__O(ty__0)) { tmp6 = lang.IFn_Cast(gen_of__1).Invoke_O__O(ty__0) } else { tmp6 = nil }
//line :212:1
			return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp3, tmp4, tmp5, tmp6) } else { var tmp7 any; var root_1075 any = A_arbace_go_repl_A_const_132.GetRawRoot__O(); var linked_1076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1075, aot_arbace_go_check_types.A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_1077 lang.IFn


				if linked_1076 == nil { ifn_1077 = lang.IFn_Cast(root_1075) } else { ifn_1077 = nil }; var arg_1078 any = ty__0; if linked_1076 == nil { tmp7 = ifn_1077.Invoke_O__O(arg_1078) } else { tmp7 = linked_1076.(*aot_arbace_go_check_types.A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_1075, arg_1078) }
//line :212:1
				if jrt.J2g_Truth(tmp7) { var tmp8 any = A_arbace_go_repl_A_const_141; var tmp9 *lang.Keyword = A_arbace_go_repl_A_const_55; var tmp10 any; var root_1100 any = A_arbace_go_repl_A_const_131.GetRawRoot__O(); var linked_1101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1100, aot_arbace_go_check_types.A_arbace_go_check_types_info_A_fn_class); var ifn_1102 lang.IFn


					if linked_1101 == nil { ifn_1102 = lang.IFn_Cast(root_1100) } else { ifn_1102 = nil }; var arg_1103 any = ty__0; if linked_1101 == nil { tmp10 = ifn_1102.Invoke_O__O(arg_1103) } else { tmp10 = linked_1101.(*aot_arbace_go_check_types.A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1100, arg_1103) }
//line :212:1
					return lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9.Invoke_O__O(tmp10)) } else { if A_arbace_go_repl_A_const_133 != nil { var G__794000158__3_ any = lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(0))



						switch lang.Util_Hash_O__I_NoInit(G__794000158__3_) >> 16 & 7 { case 0: if any(G__794000158__3_) == any(A_arbace_go_repl_A_const_134) { var tmp11 any = A_arbace_go_repl_A_const_134; var tmp12 any = lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp13 any; var root_1104 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var linked_1105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1104, A_arbace_go_repl_type_key_A_fn_class); var ifn_1106 lang.IFn





							if linked_1105 == nil { ifn_1106 = lang.IFn_Cast(root_1104) } else { ifn_1106 = nil }; var arg_1107 any = lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(2)); var arg_1108 any = gen_of__1; if linked_1105 == nil { tmp13 = ifn_1106.Invoke_O_O__O(arg_1107, arg_1108) } else { tmp13 = linked_1105.(*A_arbace_go_repl_type_key_A).Invoke_O_O_O__O(root_1104, arg_1107, arg_1108) }
//line :216:1
							return lang.Tuple_Create_O_O_O__IPersistentVector(tmp11, tmp12, tmp13) }; case 1: if any(G__794000158__3_) == any(A_arbace_go_repl_A_const_135) { var tmp14 any = A_arbace_go_repl_A_const_135; var tmp15 any; var root_1109 any = A_arbace_go_repl_A_const_80.GetRawRoot__O(); var linked_1110 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1109, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1111 lang.IFn
								if linked_1110 == nil { ifn_1111 = lang.IFn_Cast(root_1109) } else { ifn_1111 = nil }; var arg_1112 any; var tmp16 any = A_arbace_go_repl_type_key_fn__794000159_A_New_O(gen_of__1); var tmp17 *jrt.Class; var fncls__1126 *jrt.Class = A_arbace_go_repl_type_key_fn__794000159_A_fn_class; if fncls__1126 == nil { var fncls__1126d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_157, false); A_arbace_go_repl_type_key_fn__794000159_A_fn_class = fncls__1126d; tmp17 = fncls__1126d } else { tmp17 = fncls__1126 }; arg_1112 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var arg_1113 any = lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1110 == nil { tmp15 = ifn_1111.Invoke_O_O__O(arg_1112, arg_1113) } else { tmp15 = linked_1110.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1109, arg_1112, arg_1113) }
//line :216:1
								return lang.Tuple_Create_O_O__IPersistentVector(tmp14, tmp15) }; case 2: if any(G__794000158__3_) == any(A_arbace_go_repl_A_const_136) { var tmp18 any = A_arbace_go_repl_A_const_136; var tmp19 any = lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp20 any; var root_1127 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var linked_1128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1127, A_arbace_go_repl_type_key_A_fn_class); var ifn_1129 lang.IFn




									if linked_1128 == nil { ifn_1129 = lang.IFn_Cast(root_1127) } else { ifn_1129 = nil }; var arg_1130 any = lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(2)); var arg_1131 any = gen_of__1; if linked_1128 == nil { tmp20 = ifn_1129.Invoke_O_O__O(arg_1130, arg_1131) } else { tmp20 = linked_1128.(*A_arbace_go_repl_type_key_A).Invoke_O_O_O__O(root_1127, arg_1130, arg_1131) }
//line :216:1
									return lang.Tuple_Create_O_O_O__IPersistentVector(tmp18, tmp19, tmp20) }; case 3: if any(G__794000158__3_) == any(A_arbace_go_repl_A_const_137) { var tmp21 any = A_arbace_go_repl_A_const_137; var tmp22 any; var root_1132 any = A_arbace_go_repl_A_const_80.GetRawRoot__O(); var linked_1133 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1132, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1134 lang.IFn


										if linked_1133 == nil { ifn_1134 = lang.IFn_Cast(root_1132) } else { ifn_1134 = nil }; var arg_1135 any; var tmp23 any = A_arbace_go_repl_type_key_fn__794000161_A_New_O(gen_of__1); var tmp24 *jrt.Class; var fncls__1142 *jrt.Class = A_arbace_go_repl_type_key_fn__794000161_A_fn_class; if fncls__1142 == nil { var fncls__1142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_158, false); A_arbace_go_repl_type_key_fn__794000161_A_fn_class = fncls__1142d; tmp24 = fncls__1142d } else { tmp24 = fncls__1142 }; arg_1135 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); var arg_1136 any = lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1133 == nil { tmp22 = ifn_1134.Invoke_O_O__O(arg_1135, arg_1136) } else { tmp22 = linked_1133.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1132, arg_1135, arg_1136) }
//line :216:1
										var tmp25 any = tmp22; var tmp26 any; var root_1143 any = A_arbace_go_repl_A_const_80.GetRawRoot__O(); var linked_1144 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1143, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1145 lang.IFn


										if linked_1144 == nil { ifn_1145 = lang.IFn_Cast(root_1143) } else { ifn_1145 = nil }; var arg_1146 any; var tmp27 any = A_arbace_go_repl_type_key_fn__794000163_A_New_O(gen_of__1); var tmp28 *jrt.Class; var fncls__1153 *jrt.Class = A_arbace_go_repl_type_key_fn__794000163_A_fn_class; if fncls__1153 == nil { var fncls__1153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_159, false); A_arbace_go_repl_type_key_fn__794000163_A_fn_class = fncls__1153d; tmp28 = fncls__1153d } else { tmp28 = fncls__1153 }; arg_1146 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil); var arg_1147 any = lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_1144 == nil { tmp26 = ifn_1145.Invoke_O_O__O(arg_1146, arg_1147) } else { tmp26 = linked_1144.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1143, arg_1146, arg_1147) }
//line :216:1
										return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp21, tmp25, tmp26, lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(3))) }; case 4: if any(G__794000158__3_) == any(A_arbace_go_repl_A_const_143) { var tmp29 any = A_arbace_go_repl_A_const_143; return lang.Tuple_Create_O_O__IPersistentVector(tmp29, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(1)))).Ref()) }; case 5: if any(G__794000158__3_) == any(A_arbace_go_repl_A_const_144) {



											var root_1154 any = A_arbace_go_repl_A_const_88.GetRawRoot__O(); var linked_1155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1154, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1156 lang.IFn; if linked_1155 == nil { ifn_1156 = lang.IFn_Cast(root_1154) } else { ifn_1156 = nil }; var arg_1157 any = A_arbace_go_repl_A_const_145; var arg_1158 any; var root_1159 any = A_arbace_go_repl_A_const_102.GetRawRoot__O(); var linked_1160 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1159, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1161 lang.IFn; if linked_1160 == nil { ifn_1161 = lang.IFn_Cast(root_1159) } else { ifn_1161 = nil }; var arg_1162 any; var tmp30 any = A_arbace_go_repl_type_key_fn__794000165_A_New_O(gen_of__1); var tmp31 *jrt.Class; var fncls__1169 *jrt.Class = A_arbace_go_repl_type_key_fn__794000165_A_fn_class; if fncls__1169 == nil { var fncls__1169d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_160, false); A_arbace_go_repl_type_key_fn__794000165_A_fn_class = fncls__1169d; tmp31 = fncls__1169d } else { tmp31 = fncls__1169 }; arg_1162 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp30, tmp31, nil); var arg_1163 any; var root_1170 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_1171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1170, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1172 lang.IFn; if linked_1171 == nil { ifn_1172 = lang.IFn_Cast(root_1170) } else { ifn_1172 = nil }; var arg_1173 any = ty__0; if linked_1171 == nil { arg_1163 = ifn_1172.Invoke_O__O(arg_1173) } else { arg_1163 = linked_1171.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1170, arg_1173) }; if linked_1160 == nil { arg_1158 = ifn_1161.Invoke_O_O__O(arg_1162, arg_1163) } else { arg_1158 = linked_1160.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1159, arg_1162, arg_1163) }; if linked_1155 == nil { return ifn_1156.Invoke_O_O__O(arg_1157, arg_1158) } else { return linked_1155.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1154, arg_1157, arg_1158) } }
//line :216:1
						default:
						}





						var root_1080 any = A_arbace_go_repl_A_const_88.GetRawRoot__O(); var linked_1081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1080, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1082 lang.IFn; if linked_1081 == nil { ifn_1082 = lang.IFn_Cast(root_1080) } else { ifn_1082 = nil }; var arg_1083 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(0))); var arg_1084 any; var root_1085 any = A_arbace_go_repl_A_const_102.GetRawRoot__O(); var linked_1086 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1085, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1087 lang.IFn; if linked_1086 == nil { ifn_1087 = lang.IFn_Cast(root_1085) } else { ifn_1087 = nil }; var arg_1088 any; var tmp32 any = A_arbace_go_repl_type_key_fn__794000167_A_New_O(gen_of__1); var tmp33 *jrt.Class; var fncls__1095 *jrt.Class = A_arbace_go_repl_type_key_fn__794000167_A_fn_class; if fncls__1095 == nil { var fncls__1095d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_161, false); A_arbace_go_repl_type_key_fn__794000167_A_fn_class = fncls__1095d; tmp33 = fncls__1095d } else { tmp33 = fncls__1095 }; arg_1088 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp32, tmp33, nil); var arg_1089 any; var root_1096 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1098 lang.IFn; if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any = ty__0; if linked_1097 == nil { arg_1089 = ifn_1098.Invoke_O__O(arg_1099) } else { arg_1089 = linked_1097.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1096, arg_1099) }; if linked_1086 == nil { arg_1084 = ifn_1087.Invoke_O_O__O(arg_1088, arg_1089) } else { arg_1084 = linked_1086.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1085, arg_1088, arg_1089) }; if linked_1081 == nil { return ifn_1082.Invoke_O_O__O(arg_1083, arg_1084) } else { return linked_1081.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1080, arg_1083, arg_1084) } } else {
//line :212:1
							return nil
						}
					}
			}
	} }
func A_arbace_go_repl_type_key_fn__794000159_A_New_O(p0 any) *A_arbace_go_repl_type_key_fn__794000159_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_type_key_fn__794000159_A{}; t.Ctor_O(p0); return t }
//line :217:1
func (t *A_arbace_go_repl_type_key_fn__794000159_A) Ctor_O(c__gen_of any) { t.F_gen_of = c__gen_of }
//line :217:1
func (t *A_arbace_go_repl_type_key_fn__794000159_A) Invoke_O_O__O(self, p1__794000153_SHARP___1 any) any { var root_1114 any = A_arbace_go_repl_A_const_84.GetRawRoot__O(); var linked_1115 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1114, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_1116 lang.IFn; if linked_1115 == nil { ifn_1116 = lang.IFn_Cast(root_1114) } else { ifn_1116 = nil }; var arg_1117 any; var root_1119 any = A_arbace_go_repl_A_const_79.GetRawRoot__O(); var linked_1120 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1119, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1121 lang.IFn; if linked_1120 == nil { ifn_1121 = lang.IFn_Cast(root_1119) } else { ifn_1121 = nil }; var arg_1122 any = p1__794000153_SHARP___1; var arg_1123 any = A_arbace_go_repl_A_const_142; var arg_1124 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var arg_1125 any = t.F_gen_of; if linked_1120 == nil { arg_1117 = ifn_1121.Invoke_O_O_O_O__O(arg_1122, arg_1123, arg_1124, arg_1125) } else { arg_1117 = linked_1120.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1119, arg_1122, arg_1123, arg_1124, arg_1125) }; var arg_1118 any = A_arbace_go_repl_A_const_140; if linked_1115 == nil { return ifn_1116.Invoke_O_O__O(arg_1117, arg_1118) } else { return linked_1115.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_1114, arg_1117, arg_1118) } }

func A_arbace_go_repl_type_key_fn__794000161_A_New_O(p0 any) *A_arbace_go_repl_type_key_fn__794000161_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_type_key_fn__794000161_A{}; t.Ctor_O(p0); return t }
//line :219:1
func (t *A_arbace_go_repl_type_key_fn__794000161_A) Ctor_O(c__gen_of any) { t.F_gen_of = c__gen_of }
//line :219:1
func (t *A_arbace_go_repl_type_key_fn__794000161_A) Invoke_O_O__O(self, p1__794000154_SHARP___1 any) any { var root_1137 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var linked_1138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1137, A_arbace_go_repl_type_key_A_fn_class); var ifn_1139 lang.IFn; if linked_1138 == nil { ifn_1139 = lang.IFn_Cast(root_1137) } else { ifn_1139 = nil }; var arg_1140 any = p1__794000154_SHARP___1; var arg_1141 any = t.F_gen_of; if linked_1138 == nil { return ifn_1139.Invoke_O_O__O(arg_1140, arg_1141) } else { return linked_1138.(*A_arbace_go_repl_type_key_A).Invoke_O_O_O__O(root_1137, arg_1140, arg_1141) } }
//line :219:1
func A_arbace_go_repl_type_key_fn__794000163_A_New_O(p0 any) *A_arbace_go_repl_type_key_fn__794000163_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_type_key_fn__794000163_A{}; t.Ctor_O(p0); return t }
//line :219:1
func (t *A_arbace_go_repl_type_key_fn__794000163_A) Ctor_O(c__gen_of any) { t.F_gen_of = c__gen_of }
//line :219:1
func (t *A_arbace_go_repl_type_key_fn__794000163_A) Invoke_O_O__O(self, p1__794000155_SHARP___1 any) any { var root_1148 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var linked_1149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1148, A_arbace_go_repl_type_key_A_fn_class); var ifn_1150 lang.IFn; if linked_1149 == nil { ifn_1150 = lang.IFn_Cast(root_1148) } else { ifn_1150 = nil }; var arg_1151 any = p1__794000155_SHARP___1; var arg_1152 any = t.F_gen_of; if linked_1149 == nil { return ifn_1150.Invoke_O_O__O(arg_1151, arg_1152) } else { return linked_1149.(*A_arbace_go_repl_type_key_A).Invoke_O_O_O__O(root_1148, arg_1151, arg_1152) } }
func A_arbace_go_repl_type_key_fn__794000165_A_New_O(p0 any) *A_arbace_go_repl_type_key_fn__794000165_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_type_key_fn__794000165_A{}; t.Ctor_O(p0); return t }
//line :220:1
func (t *A_arbace_go_repl_type_key_fn__794000165_A) Ctor_O(c__gen_of any) { t.F_gen_of = c__gen_of }
//line :220:1
func (t *A_arbace_go_repl_type_key_fn__794000165_A) Invoke_O_O__O(self, p1__794000156_SHARP___1 any) any { var root_1164 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var linked_1165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1164, A_arbace_go_repl_type_key_A_fn_class); var ifn_1166 lang.IFn; if linked_1165 == nil { ifn_1166 = lang.IFn_Cast(root_1164) } else { ifn_1166 = nil }; var arg_1167 any = p1__794000156_SHARP___1; var arg_1168 any = t.F_gen_of; if linked_1165 == nil { return ifn_1166.Invoke_O_O__O(arg_1167, arg_1168) } else { return linked_1165.(*A_arbace_go_repl_type_key_A).Invoke_O_O_O__O(root_1164, arg_1167, arg_1168) } }


func A_arbace_go_repl_type_key_fn__794000167_A_New_O(p0 any) *A_arbace_go_repl_type_key_fn__794000167_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_type_key_fn__794000167_A{}; t.Ctor_O(p0); return t }
//line :223:1
func (t *A_arbace_go_repl_type_key_fn__794000167_A) Ctor_O(c__gen_of any) { t.F_gen_of = c__gen_of }
//line :223:1
func (t *A_arbace_go_repl_type_key_fn__794000167_A) Invoke_O_O__O(self, p1__794000157_SHARP___1 any) any { var root_1090 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var linked_1091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1090, A_arbace_go_repl_type_key_A_fn_class); var ifn_1092 lang.IFn; if linked_1091 == nil { ifn_1092 = lang.IFn_Cast(root_1090) } else { ifn_1092 = nil }; var arg_1093 any = p1__794000157_SHARP___1; var arg_1094 any = t.F_gen_of; if linked_1091 == nil { return ifn_1092.Invoke_O_O__O(arg_1093, arg_1094) } else { return linked_1091.(*A_arbace_go_repl_type_key_A).Invoke_O_O_O__O(root_1090, arg_1093, arg_1094) } }

func A_arbace_go_repl_state_of_path_A_New() *A_arbace_go_repl_state_of_path_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_state_of_path_A{}; t.Ctor(); return t }
//line :225:1
func (t *A_arbace_go_repl_state_of_path_A) Ctor() {}
//line :225:1
func (t *A_arbace_go_repl_state_of_path_A) Invoke_O_O__O(self, p__0 any) any { var tmp1 any; var root_1174 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_1175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1174, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1176 lang.IFn; if linked_1175 == nil { ifn_1176 = lang.IFn_Cast(root_1174) } else { ifn_1176 = nil }; var arg_1177 any = A_arbace_go_repl_A_const_64.GetRawRoot__O(); if linked_1175 == nil { tmp1 = ifn_1176.Invoke_O__O(arg_1177) } else { tmp1 = linked_1175.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1174, arg_1177) }; return lang.RT_Get_O_O__O_NoInit(tmp1, p__0) }

func A_arbace_go_repl_build_context_A_New() *A_arbace_go_repl_build_context_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_build_context_A{}; t.Ctor(); return t }
//line :227:1
func (t *A_arbace_go_repl_build_context_A) Ctor() {}
//line :227:1
func (t *A_arbace_go_repl_build_context_A) Invoke_O_O__O(self, st__0 any) any { var tmp1 any = A_arbace_go_repl_A_const_54; var tmp2 *lang.Keyword = A_arbace_go_repl_A_const_54; var tmp3 any; var root_1178 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_1179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1178, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1180 lang.IFn; if


	linked_1179 == nil { ifn_1180 = lang.IFn_Cast(root_1178) } else { ifn_1180 = nil }; var arg_1181 any = st__0; if linked_1179 == nil { tmp3 = ifn_1180.Invoke_O__O(arg_1181) } else { tmp3 = linked_1179.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1178, arg_1181) }; var tmp4 any = /*line :227:1*/tmp2.Invoke_O__O(tmp3); var tmp5 any = A_arbace_go_repl_A_const_55; var tmp6 *lang.Keyword = A_arbace_go_repl_A_const_55; var tmp7 any; var root_1182 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_1183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1182, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1184 lang.IFn; if


	linked_1183 == nil { ifn_1184 = lang.IFn_Cast(root_1182) } else { ifn_1184 = nil }; var arg_1185 any = st__0; if linked_1183 == nil { tmp7 = ifn_1184.Invoke_O__O(arg_1185) } else { tmp7 = linked_1183.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1182, arg_1185) }; var tmp8 any = /*line :227:1*/tmp6.Invoke_O__O(tmp7); var tmp9 any = A_arbace_go_repl_A_const_146; var tmp10 any = A_arbace_go_repl_A_const_43.GetRawRoot__O(); var tmp11 any = A_arbace_go_repl_A_const_61; var tmp12 any = jrt.HashMap_New(); var tmp13 any = A_arbace_go_repl_A_const_147; var tmp14 any; var root_1186 any = A_arbace_go_repl_A_const_53.GetRawRoot__O(); var linked_1187 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1186, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1188 lang.IFn; if





	linked_1187 == nil { ifn_1188 = lang.IFn_Cast(root_1186) } else { ifn_1188 = nil }; var arg_1189 any = A_arbace_go_repl_A_const_23; if linked_1187 == nil { tmp14 = ifn_1188.Invoke_O__O(arg_1189) } else { tmp14 = linked_1187.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1186, arg_1189) }; var tmp15 any = tmp14; var tmp16 any = A_arbace_go_repl_A_const_148; var tmp17 any; var root_1190 any = /*line :227:1*/A_arbace_go_repl_A_const_53.GetRawRoot__O(); var linked_1191 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1190, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1192 lang.IFn; if





	linked_1191 == nil { ifn_1192 = lang.IFn_Cast(root_1190) } else { ifn_1192 = nil }; var arg_1193 any = A_arbace_go_repl_A_const_149; if linked_1191 == nil { tmp17 = ifn_1192.Invoke_O__O(arg_1193) } else { tmp17 = linked_1191.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1190, arg_1193) }; var tmp18 any = tmp17; var tmp19 any = A_arbace_go_repl_A_const_150; var tmp20 any = /*line :227:1*/A_arbace_go_repl_build_context_fn__794000171_A_New(); var tmp21 *jrt.Class; var fncls__1211 *jrt.Class = A_arbace_go_repl_build_context_fn__794000171_A_fn_class; if






	fncls__1211 == nil { var fncls__1211d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_go_repl_build_context_fn__794000171_A_fn_class = fncls__1211d; tmp21 = fncls__1211d } else { tmp21 = fncls__1211 }; var tmp22 any = /*line :227:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil); var tmp23 any = A_arbace_go_repl_A_const_154; var tmp24 any = A_arbace_go_repl_build_context_fn__794000173_A_New(); var tmp25 *jrt.Class; var fncls__1250 *jrt.Class = A_arbace_go_repl_build_context_fn__794000173_A_fn_class; if









	fncls__1250 == nil { var fncls__1250d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_go_repl_build_context_fn__794000173_A_fn_class = fncls__1250d; tmp25 = fncls__1250d } else { tmp25 = fncls__1250 }; var tmp26 any = /*line :227:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil); var tmp27 any = A_arbace_go_repl_A_const_156; var tmp28 any = A_arbace_go_repl_build_context_fn__794000175_A_New(); var tmp29 *jrt.Class; var fncls__1289 *jrt.Class = A_arbace_go_repl_build_context_fn__794000175_A_fn_class; if













	fncls__1289 == nil { var fncls__1289d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_go_repl_build_context_fn__794000175_A_fn_class = fncls__1289d; tmp29 = fncls__1289d } else { tmp29 = fncls__1289 }; return /*line :227:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp4, tmp5, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp15, tmp16, tmp18, tmp19, tmp22, tmp23, tmp26, tmp27, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil))) }






func A_arbace_go_repl_build_context_fn__794000171_A_New() *A_arbace_go_repl_build_context_fn__794000171_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_build_context_fn__794000171_A{}; t.Ctor(); return t }
//line :234:1
func (t *A_arbace_go_repl_build_context_fn__794000171_A) Ctor() {}
//line :234:1
func (t *A_arbace_go_repl_build_context_fn__794000171_A) Invoke_O_O__O(self, nt__1 any) any { var i__2 any; var root_1194 any = A_arbace_go_repl_A_const_131.GetRawRoot__O(); var linked_1195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1194, aot_arbace_go_check_types.A_arbace_go_check_types_info_A_fn_class); var ifn_1196 lang.IFn; if
												linked_1195 == nil { ifn_1196 = lang.IFn_Cast(root_1194) } else { ifn_1196 = nil }; var arg_1197 any = nt__1; if linked_1195 == nil { i__2 = ifn_1196.Invoke_O__O(arg_1197) } else { i__2 = linked_1195.(*aot_arbace_go_check_types.A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1194, arg_1197) }; var or__1927000174__auto____3 any; var temp__1927000414__auto____3 any; var root_1198 any = /*line :234:1*/A_arbace_go_repl_A_const_151.GetRawRoot__O(); var linked_1199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1198, A_arbace_go_repl_state_of_path_A_fn_class); var ifn_1200 lang.IFn; if

	linked_1199 == nil { ifn_1200 = lang.IFn_Cast(root_1198) } else { ifn_1200 = nil }; var arg_1201 any = A_arbace_go_repl_A_const_140.Invoke_O__O(i__2); if linked_1199 == nil { temp__1927000414__auto____3 = ifn_1200.Invoke_O__O(arg_1201) } else { temp__1927000414__auto____3 = linked_1199.(*A_arbace_go_repl_state_of_path_A).Invoke_O_O__O(root_1198, arg_1201) }; if jrt.J2g_Truth(temp__1927000414__auto____3) { var ps__4 any = temp__1927000414__auto____3; var root_1202 any = A_arbace_go_repl_A_const_152.GetRawRoot__O(); var linked_1203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1202, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1204 lang.IFn; if linked_1203 == nil { ifn_1204 = lang.IFn_Cast(root_1202) } else { ifn_1204 = nil }; var arg_1205 any; var root_1207 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_1208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1207, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1209 lang.IFn; if linked_1208 == nil { ifn_1209 = lang.IFn_Cast(root_1207) } else { ifn_1209 = nil }; var arg_1210 any = ps__4; if linked_1208 == nil { arg_1205 = ifn_1209.Invoke_O__O(arg_1210) } else { arg_1205 = linked_1208.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1207, arg_1210) }; var tmp1 any = A_arbace_go_repl_A_const_61; var arg_1206 any = lang.Tuple_Create_O_O_O__IPersistentVector(tmp1, A_arbace_go_repl_A_const_55.Invoke_O__O(i__2), A_arbace_go_repl_A_const_150); if linked_1203 == nil { or__1927000174__auto____3 = ifn_1204.Invoke_O_O__O(arg_1205, arg_1206) } else { or__1927000174__auto____3 = linked_1203.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1202, arg_1205, arg_1206) } } else { or__1927000174__auto____3 = nil }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { return A_arbace_go_repl_A_const_153 } }
func A_arbace_go_repl_build_context_fn__794000173_A_New() *A_arbace_go_repl_build_context_fn__794000173_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_build_context_fn__794000173_A{}; t.Ctor(); return t }
//line :237:1
func (t *A_arbace_go_repl_build_context_fn__794000173_A) Ctor() {}
//line :237:1
func (t *A_arbace_go_repl_build_context_fn__794000173_A) Invoke_O_O__O(self, x__1 any) any { var ps__2 any; var root_1212 any = A_arbace_go_repl_A_const_151.GetRawRoot__O(); var linked_1213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1212, A_arbace_go_repl_state_of_path_A_fn_class); var ifn_1214 lang.IFn; if
												linked_1213 == nil { ifn_1214 = lang.IFn_Cast(root_1212) } else { ifn_1214 = nil }; var arg_1215 any; var root_1216 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1216, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1218 lang.IFn; if linked_1217 == nil { ifn_1218 = lang.IFn_Cast(root_1216) } else { ifn_1218 = nil }; var arg_1219 any = x__1; var arg_1220 any = A_arbace_go_repl_A_const_140; if linked_1217 == nil { arg_1215 = ifn_1218.Invoke_O_O__O(arg_1219, arg_1220) } else { arg_1215 = linked_1217.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1216, arg_1219, arg_1220) }; if linked_1213 == nil { ps__2 = ifn_1214.Invoke_O__O(arg_1215) } else { ps__2 = linked_1213.(*A_arbace_go_repl_state_of_path_A).Invoke_O_O__O(root_1212, arg_1215) }; var or__1927000174__auto____3 any; var and__1927000168__auto____3 any = ps__2; if
												jrt.J2g_Truth(and__1927000168__auto____3) { var root_1221 any = A_arbace_go_repl_A_const_152.GetRawRoot__O(); var linked_1222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1221, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1223 lang.IFn; if linked_1222 == nil { ifn_1223 = lang.IFn_Cast(root_1221) } else { ifn_1223 = nil }; var arg_1224 any; var root_1226 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_1227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1226, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1228 lang.IFn; if linked_1227 == nil { ifn_1228 = lang.IFn_Cast(root_1226) } else { ifn_1228 = nil }; var arg_1229 any = ps__2; if linked_1227 == nil { arg_1224 = ifn_1228.Invoke_O__O(arg_1229) } else { arg_1224 = linked_1227.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1226, arg_1229) }; var arg_1225 any; var tmp1 any = A_arbace_go_repl_A_const_59; var tmp2 any; var root_1230 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1230, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1232 lang.IFn; if linked_1231 == nil { ifn_1232 = lang.IFn_Cast(root_1230) } else { ifn_1232 = nil }; var arg_1233 any = x__1; var arg_1234 any = A_arbace_go_repl_A_const_55; if linked_1231 == nil { tmp2 = ifn_1232.Invoke_O_O__O(arg_1233, arg_1234) } else { tmp2 = linked_1231.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1230, arg_1233, arg_1234) }; arg_1225 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp1, tmp2, A_arbace_go_repl_A_const_155); if linked_1222 == nil { or__1927000174__auto____3 = ifn_1223.Invoke_O_O__O(arg_1224, arg_1225) } else { or__1927000174__auto____3 = linked_1222.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1221, arg_1224, arg_1225) } } else { or__1927000174__auto____3 = and__1927000168__auto____3 }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var tmp3 any; var root_1235 any = A_arbace_go_repl_A_const_69.GetRawRoot__O(); var linked_1236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1235, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1237 lang.IFn
													if linked_1236 == nil { ifn_1237 = lang.IFn_Cast(root_1235) } else { ifn_1237 = nil }; var arg_1238 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_9, nil, Lit_3, nil); var tmp5 any; var root_1240 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1242 lang.IFn; if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any = x__1; var arg_1244 any = A_arbace_go_repl_A_const_140; if linked_1241 == nil { tmp5 = ifn_1242.Invoke_O_O__O(arg_1243, arg_1244) } else { tmp5 = linked_1241.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1240, arg_1243, arg_1244) }; var tmp6 any = tmp5; var tmp7 any; var root_1245 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1245, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1247 lang.IFn; if linked_1246 == nil { ifn_1247 = lang.IFn_Cast(root_1245) } else { ifn_1247 = nil }; var arg_1248 any = x__1; var arg_1249 any = A_arbace_go_repl_A_const_55; if linked_1246 == nil { tmp7 = ifn_1247.Invoke_O_O__O(arg_1248, arg_1249) } else { tmp7 = linked_1246.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1245, arg_1248, arg_1249) }; arg_1238 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp6, nil, tmp7)).Ref(); var arg_1239 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1236 == nil { tmp3 = ifn_1237.Invoke_O_O__O(arg_1238, arg_1239) } else { tmp3 = linked_1236.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1235, arg_1238, arg_1239) }
//line :239:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp3))) } }

func A_arbace_go_repl_build_context_fn__794000175_A_New() *A_arbace_go_repl_build_context_fn__794000175_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_build_context_fn__794000175_A{}; t.Ctor(); return t }
//line :241:1
func (t *A_arbace_go_repl_build_context_fn__794000175_A) Ctor() {}
//line :241:1
func (t *A_arbace_go_repl_build_context_fn__794000175_A) Invoke_O_O__O(self, x__1 any) any { var ps__2 any; var root_1251 any = A_arbace_go_repl_A_const_151.GetRawRoot__O(); var linked_1252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1251, A_arbace_go_repl_state_of_path_A_fn_class); var ifn_1253 lang.IFn; if
												linked_1252 == nil { ifn_1253 = lang.IFn_Cast(root_1251) } else { ifn_1253 = nil }; var arg_1254 any; var root_1255 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1255, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1257 lang.IFn; if linked_1256 == nil { ifn_1257 = lang.IFn_Cast(root_1255) } else { ifn_1257 = nil }; var arg_1258 any = x__1; var arg_1259 any = A_arbace_go_repl_A_const_140; if linked_1256 == nil { arg_1254 = ifn_1257.Invoke_O_O__O(arg_1258, arg_1259) } else { arg_1254 = linked_1256.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1255, arg_1258, arg_1259) }; if linked_1252 == nil { ps__2 = ifn_1253.Invoke_O__O(arg_1254) } else { ps__2 = linked_1252.(*A_arbace_go_repl_state_of_path_A).Invoke_O_O__O(root_1251, arg_1254) }; var or__1927000174__auto____3 any; var and__1927000168__auto____3 any = ps__2; if
												jrt.J2g_Truth(and__1927000168__auto____3) { var root_1260 any = A_arbace_go_repl_A_const_152.GetRawRoot__O(); var linked_1261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1260, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1262 lang.IFn; if linked_1261 == nil { ifn_1262 = lang.IFn_Cast(root_1260) } else { ifn_1262 = nil }; var arg_1263 any; var root_1265 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_1266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1265, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1267 lang.IFn; if linked_1266 == nil { ifn_1267 = lang.IFn_Cast(root_1265) } else { ifn_1267 = nil }; var arg_1268 any = ps__2; if linked_1266 == nil { arg_1263 = ifn_1267.Invoke_O__O(arg_1268) } else { arg_1263 = linked_1266.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1265, arg_1268) }; var arg_1264 any; var tmp1 any = A_arbace_go_repl_A_const_60; var tmp2 any; var root_1269 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1269, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1271 lang.IFn; if linked_1270 == nil { ifn_1271 = lang.IFn_Cast(root_1269) } else { ifn_1271 = nil }; var arg_1272 any = x__1; var arg_1273 any = A_arbace_go_repl_A_const_55; if linked_1270 == nil { tmp2 = ifn_1271.Invoke_O_O__O(arg_1272, arg_1273) } else { tmp2 = linked_1270.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1269, arg_1272, arg_1273) }; arg_1264 = lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2); if linked_1261 == nil { or__1927000174__auto____3 = ifn_1262.Invoke_O_O__O(arg_1263, arg_1264) } else { or__1927000174__auto____3 = linked_1261.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1260, arg_1263, arg_1264) } } else { or__1927000174__auto____3 = and__1927000168__auto____3 }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var tmp3 any; var root_1274 any = A_arbace_go_repl_A_const_69.GetRawRoot__O(); var linked_1275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1274, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1276 lang.IFn
													if linked_1275 == nil { ifn_1276 = lang.IFn_Cast(root_1274) } else { ifn_1276 = nil }; var arg_1277 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_10, nil, Lit_3, nil); var tmp5 any; var root_1279 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1279, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1281 lang.IFn; if linked_1280 == nil { ifn_1281 = lang.IFn_Cast(root_1279) } else { ifn_1281 = nil }; var arg_1282 any = x__1; var arg_1283 any = A_arbace_go_repl_A_const_140; if linked_1280 == nil { tmp5 = ifn_1281.Invoke_O_O__O(arg_1282, arg_1283) } else { tmp5 = linked_1280.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1279, arg_1282, arg_1283) }; var tmp6 any = tmp5; var tmp7 any; var root_1284 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1284, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1286 lang.IFn; if linked_1285 == nil { ifn_1286 = lang.IFn_Cast(root_1284) } else { ifn_1286 = nil }; var arg_1287 any = x__1; var arg_1288 any = A_arbace_go_repl_A_const_55; if linked_1285 == nil { tmp7 = ifn_1286.Invoke_O_O__O(arg_1287, arg_1288) } else { tmp7 = linked_1285.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1284, arg_1287, arg_1288) }; arg_1277 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp6, nil, tmp7)).Ref(); var arg_1278 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1275 == nil { tmp3 = ifn_1276.Invoke_O_O__O(arg_1277, arg_1278) } else { tmp3 = linked_1275.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1274, arg_1277, arg_1278) }
//line :243:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp3))) } }


func A_arbace_go_repl_const_arbace_A_New() *A_arbace_go_repl_const_arbace_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_const_arbace_A{}; t.Ctor(); return t }
//line :246:1
func (t *A_arbace_go_repl_const_arbace_A) Ctor() {}
//line :246:1
func (t *A_arbace_go_repl_const_arbace_A) Invoke_O_O_O__O(self, ty__0, v__1 any) any { var b__3 any; var root_1290 any = A_arbace_go_repl_A_const_157.GetRawRoot__O(); var linked_1291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1290, aot_arbace_go_check_types.A_arbace_go_check_types_under_A_fn_class); var ifn_1292 lang.IFn; if


	linked_1291 == nil { ifn_1292 = lang.IFn_Cast(root_1290) } else { ifn_1292 = nil }; var arg_1293 any = ty__0; if linked_1291 == nil { b__3 = ifn_1292.Invoke_O__O(arg_1293) } else { b__3 = linked_1291.(*aot_arbace_go_check_types.A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1290, arg_1293) }; var tmp1 any; var root_1294 any =
	A_arbace_go_repl_A_const_158.GetRawRoot__O(); var linked_1295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1294, aot_arbace_core.A_arbace_core_boolean_QMARK__A_fn_class); var ifn_1296 lang.IFn; if
	linked_1295 == nil { ifn_1296 = lang.IFn_Cast(root_1294) } else { ifn_1296 = nil }; var arg_1297 any = v__1; if linked_1295 == nil { tmp1 = ifn_1296.Invoke_O__O(arg_1297) } else { tmp1 = linked_1295.(*aot_arbace_core.A_arbace_core_boolean_QMARK__A).Invoke_O_O__O(root_1294, arg_1297) }; if /*line :250:1*/ jrt.J2g_Truth(tmp1) { return v__1 } else { var tmp2 any; var root_1298 any = A_arbace_go_repl_A_const_90.GetRawRoot__O(); var linked_1299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1298, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1300 lang.IFn

		if linked_1299 == nil { ifn_1300 = lang.IFn_Cast(root_1298) } else { ifn_1300 = nil }; var arg_1301 any = v__1; if linked_1299 == nil { tmp2 = ifn_1300.Invoke_O__O(arg_1301) } else { tmp2 = linked_1299.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1298, arg_1301) }
//line :250:1
		if jrt.J2g_Truth(tmp2) {

			var root_1302 any = A_arbace_go_repl_A_const_159.GetRawRoot__O(); var linked_1303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1302, aot_arbace_go_check_const.A_arbace_go_check_const_value_text_A_fn_class); var ifn_1304 lang.IFn; if linked_1303 == nil { ifn_1304 = lang.IFn_Cast(root_1302) } else { ifn_1304 = nil }; var arg_1305 any = v__1; if linked_1303 == nil { return ifn_1304.Invoke_O__O(arg_1305) } else { return linked_1303.(*aot_arbace_go_check_const.A_arbace_go_check_const_value_text_A).Invoke_O_O__O(root_1302, arg_1305) } } else {
//line :250:1
				var tmp3 any; var root_1306 any = A_arbace_go_repl_A_const_160.GetRawRoot__O(); var linked_1307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1306, aot_arbace_go_check_const.A_arbace_go_check_const_complex_QMARK__A_fn_class); var ifn_1308 lang.IFn


				if linked_1307 == nil { ifn_1308 = lang.IFn_Cast(root_1306) } else { ifn_1308 = nil }; var arg_1309 any = v__1; if linked_1307 == nil { tmp3 = ifn_1308.Invoke_O__O(arg_1309) } else { tmp3 = linked_1307.(*aot_arbace_go_check_const.A_arbace_go_check_const_complex_QMARK__A).Invoke_O_O__O(root_1306, arg_1309) }
//line :250:1
				if jrt.J2g_Truth(tmp3) {


					var tmp4 float64; var root_1310 any = A_arbace_go_repl_A_const_161.GetRawRoot__O(); var linked_1311 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1310, aot_arbace_go_check_const.A_arbace_go_check_const_to_double_A_fn_class); var ifn_1312 lang.IFn; if linked_1311 == nil { ifn_1312 = lang.IFn_Cast(root_1310) } else { ifn_1312 = nil }; var arg_1313 any = lang.RT_Nth_O_I__O_NoInit(v__1, lang.RT_IntCast_J__I_NoInit(1)); if linked_1311 == nil { tmp4 = lang.RT_DoubleCast_O__D_NoInit(ifn_1312.Invoke_O__O(arg_1313)) } else { tmp4 = linked_1311.(*aot_arbace_go_check_const.A_arbace_go_check_const_to_double_A).InvokePrim_O_O__D(root_1310, arg_1313) }; var tmp5 float64 = tmp4; var tmp6 float64; var root_1314 any = A_arbace_go_repl_A_const_161.GetRawRoot__O(); var linked_1315 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1314, aot_arbace_go_check_const.A_arbace_go_check_const_to_double_A_fn_class); var ifn_1316 lang.IFn; if linked_1315 == nil { ifn_1316 = lang.IFn_Cast(root_1314) } else { ifn_1316 = nil }; var arg_1317 any = lang.RT_Nth_O_I__O_NoInit(v__1, lang.RT_IntCast_J__I_NoInit(2)); if linked_1315 == nil { tmp6 = lang.RT_DoubleCast_O__D_NoInit(ifn_1316.Invoke_O__O(arg_1317)) } else { tmp6 = linked_1315.(*aot_arbace_go_check_const.A_arbace_go_check_const_to_double_A).InvokePrim_O_O__D(root_1314, arg_1317) }; return lang.GoInterp_Complex_D_D__O(tmp5, tmp6) } else {
//line :250:1
						var tmp7 any; var and__1927000168__auto____4 any; var root_1318 any = A_arbace_go_repl_A_const_129.GetRawRoot__O(); var linked_1319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1318, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_1320 lang.IFn



						if linked_1319 == nil { ifn_1320 = lang.IFn_Cast(root_1318) } else { ifn_1320 = nil }; var arg_1321 any = b__3; if linked_1319 == nil { and__1927000168__auto____4 = ifn_1320.Invoke_O__O(arg_1321) } else { and__1927000168__auto____4 = linked_1319.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_1318, arg_1321) }; if jrt.J2g_Truth(and__1927000168__auto____4) { tmp7 = lang.IFn_Cast(A_arbace_go_repl_A_const_162).Invoke_O__O(b__3) } else { tmp7 = and__1927000168__auto____4 }
//line :250:1
						if jrt.J2g_Truth(tmp7) {



							if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_repl_A_const_163, b__3) { var tmp8 float64; var root_1322 any = A_arbace_go_repl_A_const_161.GetRawRoot__O(); var linked_1323 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1322, aot_arbace_go_check_const.A_arbace_go_check_const_to_double_A_fn_class); var ifn_1324 lang.IFn; if linked_1323 == nil { ifn_1324 = lang.IFn_Cast(root_1322) } else { ifn_1324 = nil }; var arg_1325 any = v__1; if linked_1323 == nil { tmp8 = lang.RT_DoubleCast_O__D_NoInit(ifn_1324.Invoke_O__O(arg_1325)) } else { tmp8 = linked_1323.(*aot_arbace_go_check_const.A_arbace_go_check_const_to_double_A).InvokePrim_O_O__D(root_1322, arg_1325) }; return jrt.Float_ValueOf_F__Float_NoInit(lang.RT_FloatCast_D__F_NoInit(tmp8)).Ref() } else { var root_1326 any = A_arbace_go_repl_A_const_161.GetRawRoot__O(); var linked_1327 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1326, aot_arbace_go_check_const.A_arbace_go_check_const_to_double_A_fn_class); var ifn_1328 lang.IFn; if linked_1327 == nil { ifn_1328 = lang.IFn_Cast(root_1326) } else { ifn_1328 = nil }; var arg_1329 any = v__1; if linked_1327 == nil { return ifn_1328.Invoke_O__O(arg_1329) } else { return jrt.Double_ValueOf_D__Double_NoInit(linked_1327.(*aot_arbace_go_check_const.A_arbace_go_check_const_to_double_A).InvokePrim_O_O__D(root_1326, arg_1329)).Ref() } } } else {
//line :250:1
								var tmp9 any; var root_1330 any = A_arbace_go_repl_A_const_164.GetRawRoot__O(); var linked_1331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1330, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_1332 lang.IFn




								if linked_1331 == nil { ifn_1332 = lang.IFn_Cast(root_1330) } else { ifn_1332 = nil }; var arg_1333 any = v__1; if linked_1331 == nil { tmp9 = ifn_1332.Invoke_O__O(arg_1333) } else { tmp9 = linked_1331.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_1330, arg_1333) }
//line :250:1
								if jrt.J2g_Truth(tmp9) { return v__1 } else { if A_arbace_go_repl_A_const_133 != nil {





									var root_1334 any = A_arbace_go_repl_A_const_161.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1334, aot_arbace_go_check_const.A_arbace_go_check_const_to_double_A_fn_class); var ifn_1336 lang.IFn; if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var arg_1337 any = v__1; if linked_1335 == nil { return ifn_1336.Invoke_O__O(arg_1337) } else { return jrt.Double_ValueOf_D__Double_NoInit(linked_1335.(*aot_arbace_go_check_const.A_arbace_go_check_const_to_double_A).InvokePrim_O_O__D(root_1334, arg_1337)).Ref() } } else {
//line :250:1
										return nil } } } } } } }







func A_arbace_go_repl_define_BANG__A_New() *A_arbace_go_repl_define_BANG__A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__A{}; t.Ctor(); return t }
//line :258:1
func (t *A_arbace_go_repl_define_BANG__A) Ctor() {}
//line :258:1
func (t *A_arbace_go_repl_define_BANG__A) Invoke_O_O_O_O__O(self, st__0, r__1, p__794000187__2 any) any { var map__794000188__4 any = p__794000187__2; var map__794000188__5 any; if lang.ISeq_InstanceOf(map__794000188__4) { var tmp1 any; var root_1338 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_1339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1338, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1340 lang.IFn; if linked_1339 == nil { ifn_1340 = lang.IFn_Cast(root_1338) } else { ifn_1340 = nil }; var arg_1341 any = map__794000188__4; if linked_1339 == nil { tmp1 = ifn_1340.Invoke_O__O(arg_1341) } else { tmp1 = linked_1339.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1338, arg_1341) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1342 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_1343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1342, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1344 lang.IFn; if linked_1343 == nil { ifn_1344 = lang.IFn_Cast(root_1342) } else { ifn_1344 = nil }; var arg_1345 any = map__794000188__4; if linked_1343 == nil { tmp2 = ifn_1344.Invoke_O__O(arg_1345) } else { tmp2 = linked_1343.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1342, arg_1345) }; map__794000188__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_1346 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_1347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1346, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1348 lang.IFn; if linked_1347 == nil { ifn_1348 = lang.IFn_Cast(root_1346) } else { ifn_1348 = nil }; var arg_1349 any = map__794000188__4; if linked_1347 == nil { tmp3 = ifn_1348.Invoke_O__O(arg_1349) } else { tmp3 = linked_1347.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1346, arg_1349) }; if jrt.J2g_Truth(tmp3) { var root_1350 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_1351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1350, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1352 lang.IFn; if linked_1351 == nil { ifn_1352 = lang.IFn_Cast(root_1350) } else { ifn_1352 = nil }; var arg_1353 any = map__794000188__4; if linked_1351 == nil { map__794000188__5 = ifn_1352.Invoke_O__O(arg_1353) } else { map__794000188__5 = linked_1351.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1350, arg_1353) } } else { map__794000188__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000188__5 = map__794000188__4 }; var vars_QMARK___6 any = lang.RT_Get_O_O__O_NoInit(map__794000188__5, A_arbace_go_repl_A_const_165); var eager__7 any = lang.RT_Get_O_O__O_NoInit(map__794000188__5, A_arbace_go_repl_A_const_166); var only__8 any = lang.RT_Get_O_O__O_NoInit(map__794000188__5, A_arbace_go_repl_A_const_167); var kept_names__9 any = lang.RT_Get_O_O__O_NoInit(map__794000188__5, A_arbace_go_repl_A_const_168); var init_names__10 any = lang.RT_Get_O_O__O_NoInit(map__794000188__5, A_arbace_go_repl_A_const_169); var ctx__11 any; var root_1354 any = A_arbace_go_repl_A_const_170.GetRawRoot__O(); var linked_1355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1354, A_arbace_go_repl_build_context_A_fn_class); var ifn_1356 lang.IFn; if





	linked_1355 == nil { ifn_1356 = lang.IFn_Cast(root_1354) } else { ifn_1356 = nil }; var arg_1357 any = st__0; if linked_1355 == nil { ctx__11 = ifn_1356.Invoke_O__O(arg_1357) } else { ctx__11 = linked_1355.(*A_arbace_go_repl_build_context_A).Invoke_O_O__O(root_1354, arg_1357) }; var decls__12 any = /*line :258:1*/A_arbace_go_repl_A_const_171.Invoke_O__O(r__1); var old__13 any; var root_1358 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_1359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1358, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1360 lang.IFn; if





	linked_1359 == nil { ifn_1360 = lang.IFn_Cast(root_1358) } else { ifn_1360 = nil }; var arg_1361 any = st__0; if linked_1359 == nil { old__13 = ifn_1360.Invoke_O__O(arg_1361) } else { old__13 = linked_1359.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1358, arg_1361) }; var gen_of__14 any; var tmp4 any = /*line :258:1*/A_arbace_go_repl_define_BANG__gen_of__794000190_A_New_O(old__13); var tmp5 *jrt.Class; var fncls__1371 *jrt.Class = A_arbace_go_repl_define_BANG__gen_of__794000190_A_fn_class; if








	fncls__1371 == nil { var fncls__1371d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_go_repl_define_BANG__gen_of__794000190_A_fn_class = fncls__1371d; tmp5 = fncls__1371d } else { tmp5 = fncls__1371 }; gen_of__14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var unsupported__15 any; var root_1372 any = /*line :258:1*/A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_1373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1372, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1374 lang.IFn; if









	linked_1373 == nil { ifn_1374 = lang.IFn_Cast(root_1372) } else { ifn_1374 = nil }; var arg_1375 any; var tmp6 any = A_arbace_go_repl_define_BANG__fn__794000192_A_New(); var tmp7 *jrt.Class; var fncls__1377 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000192_A_fn_class; if fncls__1377 == nil { var fncls__1377d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_go_repl_define_BANG__fn__794000192_A_fn_class = fncls__1377d; tmp7 = fncls__1377d } else { tmp7 = fncls__1377 }; arg_1375 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_1376 any = decls__12; if linked_1373 == nil { unsupported__15 = ifn_1374.Invoke_O_O__O(arg_1375, arg_1376) } else { unsupported__15 = linked_1373.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1372, arg_1375, arg_1376) }; if

	jrt.J2g_Truth(unsupported__15) { var what__16 any; var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_60); var tmp9 any; var or__1927000174__auto____18 any = A_arbace_go_repl_A_const_172.Invoke_O__O(unsupported__15)
		if jrt.J2g_Truth(or__1927000174__auto____18) { tmp9 = or__1927000174__auto____18 } else { tmp9 = Lit_61 }; what__16 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, tmp9, nil)).Ref()
//line :270:1
		var tmp10 any; var root_2055 any = A_arbace_go_repl_A_const_69.GetRawRoot__O(); var linked_2056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2055, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2057 lang.IFn

		if linked_2056 == nil { ifn_2057 = lang.IFn_Cast(root_2055) } else { ifn_2057 = nil }; var arg_2058 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_62, nil), jrt.RefArrayOf(jrt.Object_class, nil, what__16)).Ref(); var arg_2059 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_repl_A_const_197, what__16)); if linked_2056 == nil { tmp10 = ifn_2057.Invoke_O_O__O(arg_2058, arg_2059) } else { tmp10 = linked_2056.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2055, arg_2058, arg_2059) }
//line :270:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp10))) }; var root_2060 any =


	A_arbace_go_repl_A_const_198.GetRawRoot__O(); var linked_2061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2060, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2062 lang.IFn; if linked_2061 == nil { ifn_2062 = lang.IFn_Cast(root_2060) } else { ifn_2062 = nil }; var arg_2063 any = lang.IFn_Cast(A_arbace_go_repl_A_const_38.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_repl_A_const_199, ctx__11); if linked_2061 == nil { ifn_2062.Invoke_O__O(arg_2063) } else { linked_2061.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2060, arg_2063) }; var tmp11 any; tmp199 := /*line :258:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var type_decls__18 any; var root_2069 any = A_arbace_go_repl_A_const_33.GetRawRoot__O(); var linked_2070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2069, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_2071 lang.IFn
















		if linked_2070 == nil { ifn_2071 = lang.IFn_Cast(root_2069) } else { ifn_2071 = nil }; var arg_2072 any; var tmp12 any = A_arbace_go_repl_define_BANG__fn__794000194_A_New(); var tmp13 *jrt.Class; var fncls__2083 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000194_A_fn_class; if fncls__2083 == nil { var fncls__2083d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_go_repl_define_BANG__fn__794000194_A_fn_class = fncls__2083d; tmp13 = fncls__2083d } else { tmp13 = fncls__2083 }; arg_2072 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); var arg_2073 any = decls__12; if linked_2070 == nil { type_decls__18 = ifn_2071.Invoke_O_O__O(arg_2072, arg_2073) } else { type_decls__18 = linked_2070.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_2069, arg_2072, arg_2073) }
//line :258:1
		var types__19 any; var root_2084 any = A_arbace_go_repl_A_const_88.GetRawRoot__O(); var linked_2085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2084, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2086 lang.IFn

















		if linked_2085 == nil { ifn_2086 = lang.IFn_Cast(root_2084) } else { ifn_2086 = nil }; var arg_2087 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2088 any; var iter__1927001039__auto____19 any; var tmp14 any = A_arbace_go_repl_define_BANG__iter__794000196__794000200_A_New_O_O(gen_of__14, old__13); var tmp15 *jrt.Class; var fncls__2199 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000196__794000200_A_fn_class
		if fncls__2199 == nil { var fncls__2199d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_go_repl_define_BANG__iter__794000196__794000200_A_fn_class = fncls__2199d; tmp15 = fncls__2199d } else { tmp15 = fncls__2199 }; iter__1927001039__auto____19 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); arg_2088 = lang.IFn_Cast(iter__1927001039__auto____19).Invoke_O__O(type_decls__18)
//line :276:1
		if linked_2085 == nil { types__19 = ifn_2086.Invoke_O_O__O(arg_2087, arg_2088) } else { types__19 = linked_2085.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2084, arg_2087, arg_2088)
		}




		var root_2200 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_2201 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2200, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2202 lang.IFn; if linked_2201 == nil { ifn_2202 = lang.IFn_Cast(root_2200) } else { ifn_2202 = nil }; var arg_2203 any = st__0; var arg_2204 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_2205 any = A_arbace_go_repl_A_const_61; var arg_2206 any = types__19; if linked_2201 == nil { ifn_2202.Invoke_O_O_O_O__O(arg_2203, arg_2204, arg_2205, arg_2206) } else { linked_2201.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2200, arg_2203, arg_2204, arg_2205, arg_2206) }
//line :258:1
		var funcs__18 any; var root_1378 any = A_arbace_go_repl_A_const_33.GetRawRoot__O(); var linked_1379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1378, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1380 lang.IFn

























		if linked_1379 == nil { ifn_1380 = lang.IFn_Cast(root_1378) } else { ifn_1380 = nil }; var arg_1381 any; var tmp16 any = A_arbace_go_repl_define_BANG__fn__794000206_A_New(); var tmp17 *jrt.Class; var fncls__1397 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000206_A_fn_class; if fncls__1397 == nil { var fncls__1397d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_go_repl_define_BANG__fn__794000206_A_fn_class = fncls__1397d; tmp17 = fncls__1397d } else { tmp17 = fncls__1397 }; arg_1381 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var arg_1382 any = decls__12; if linked_1379 == nil { funcs__18 = ifn_1380.Invoke_O_O__O(arg_1381, arg_1382) } else { funcs__18 = linked_1379.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1378, arg_1381, arg_1382) }
//line :258:1
		var methods__19 any; var root_1398 any = A_arbace_go_repl_A_const_33.GetRawRoot__O(); var linked_1399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1398, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1400 lang.IFn


























		if linked_1399 == nil { ifn_1400 = lang.IFn_Cast(root_1398) } else { ifn_1400 = nil }; var arg_1401 any; var tmp18 any = A_arbace_go_repl_define_BANG__fn__794000208_A_New(); var tmp19 *jrt.Class; var fncls__1403 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000208_A_fn_class; if fncls__1403 == nil { var fncls__1403d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_go_repl_define_BANG__fn__794000208_A_fn_class = fncls__1403d; tmp19 = fncls__1403d } else { tmp19 = fncls__1403 }; arg_1401 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); var arg_1402 any = decls__12; if linked_1399 == nil { methods__19 = ifn_1400.Invoke_O_O__O(arg_1401, arg_1402) } else { methods__19 = linked_1399.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1398, arg_1401, arg_1402) }
//line :258:1
		var new_funcs__20 any; var root_1404 any = A_arbace_go_repl_A_const_88.GetRawRoot__O(); var linked_1405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1404, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1406 lang.IFn



























		if linked_1405 == nil { ifn_1406 = lang.IFn_Cast(root_1404) } else { ifn_1406 = nil }; var arg_1407 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1408 any; var iter__1927001039__auto____20 any; var tmp20 any = A_arbace_go_repl_define_BANG__iter__794000210__794000214_A_New_O_O_O(old__13, ctx__11, kept_names__9); var tmp21 *jrt.Class; var fncls__1543 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000210__794000214_A_fn_class
		if fncls__1543 == nil { var fncls__1543d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_go_repl_define_BANG__iter__794000210__794000214_A_fn_class = fncls__1543d; tmp21 = fncls__1543d } else { tmp21 = fncls__1543 }; iter__1927001039__auto____20 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil); arg_1408 = lang.IFn_Cast(iter__1927001039__auto____20).Invoke_O__O(funcs__18)
//line :286:1
		if linked_1405 == nil { new_funcs__20 = ifn_1406.Invoke_O_O__O(arg_1407, arg_1408) } else { new_funcs__20 = linked_1405.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1404, arg_1407, arg_1408) }
//line :258:1
		var init_cells__21 any; var root_1544 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_1545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1544, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1546 lang.IFn




































		if linked_1545 == nil { ifn_1546 = lang.IFn_Cast(root_1544) } else { ifn_1546 = nil }; var arg_1547 any; var iter__1927001039__auto____21 any; var tmp22 any = A_arbace_go_repl_define_BANG__iter__794000220__794000224_A_New_O_O(old__13, decls__12); var tmp23 *jrt.Class; var fncls__1632 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000220__794000224_A_fn_class; if fncls__1632 == nil { var fncls__1632d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_go_repl_define_BANG__iter__794000220__794000224_A_fn_class = fncls__1632d; tmp23 = fncls__1632d } else { tmp23 = fncls__1632 }; iter__1927001039__auto____21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); arg_1547 = lang.IFn_Cast(iter__1927001039__auto____21).Invoke_O__O(A_arbace_go_repl_A_const_182.Invoke_O__O(r__1)); if linked_1545 == nil { init_cells__21 = ifn_1546.Invoke_O__O(arg_1547) } else { init_cells__21 = linked_1545.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1544, arg_1547)
		}

		var root_2207 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_2208 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2207, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2209 lang.IFn; if linked_2208 == nil { ifn_2209 = lang.IFn_Cast(root_2207) } else { ifn_2209 = nil }; var arg_2210 any = st__0; var arg_2211 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_2212 any = A_arbace_go_repl_A_const_59; var arg_2213 any = new_funcs__20; if linked_2208 == nil { ifn_2209.Invoke_O_O_O_O__O(arg_2210, arg_2211, arg_2212, arg_2213) } else { linked_2208.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2207, arg_2210, arg_2211, arg_2212, arg_2213) }
//line :258:1
		var var_objs__22 any; var iter__1927001039__auto____22 any; var tmp24 any = A_arbace_go_repl_define_BANG__iter__794000234__794000240_A_New(); var tmp25 *jrt.Class
		var fncls__1746 /*line :258:1*/*jrt.Class = A_arbace_go_repl_define_BANG__iter__794000234__794000240_A_fn_class









































		if fncls__1746 == nil { var fncls__1746d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_go_repl_define_BANG__iter__794000234__794000240_A_fn_class = fncls__1746d; tmp25 = fncls__1746d } else { tmp25 = fncls__1746 }; iter__1927001039__auto____22 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil); var_objs__22 = lang.IFn_Cast(iter__1927001039__auto____22).Invoke_O__O(decls__12)
//line :258:1
		var new_vars__23 any; var root_1747 any = A_arbace_go_repl_A_const_185.GetRawRoot__O(); var linked_1748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1747, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_1749 lang.IFn










































		if linked_1748 == nil { ifn_1749 = lang.IFn_Cast(root_1747) } else { ifn_1749 = nil }; var arg_1750 any = lang.PersistentVector_EMPTY.Ref(); if linked_1748 == nil { new_vars__23 = ifn_1749.Invoke_O__O(arg_1750) } else { new_vars__23 = linked_1748.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_1747, arg_1750) }
//line :258:1
		var globals__24 any; var root_1751 any = A_arbace_go_repl_A_const_88.GetRawRoot__O(); var linked_1752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1751, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1753 lang.IFn











































		if linked_1752 == nil { ifn_1753 = lang.IFn_Cast(root_1751) } else { ifn_1753 = nil }; var arg_1754 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1755 any; var iter__1927001039__auto____24 any; var tmp26 any = A_arbace_go_repl_define_BANG__iter__794000250__794000254_A_New_O_O_O(new_vars__23, old__13, ctx__11); var tmp27 *jrt.Class; var fncls__1914 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000250__794000254_A_fn_class
		if fncls__1914 == nil { var fncls__1914d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_go_repl_define_BANG__iter__794000250__794000254_A_fn_class = fncls__1914d; tmp27 = fncls__1914d } else { tmp27 = fncls__1914 }; iter__1927001039__auto____24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil); var tmp28 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____24); var tmp29 any; var root_1915 any = A_arbace_go_repl_A_const_87.GetRawRoot__O(); var linked_1916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1915, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1917 lang.IFn; if linked_1916 == nil { ifn_1917 = lang.IFn_Cast(root_1915) } else { ifn_1917 = nil }; var arg_1918 any = var_objs__22; if linked_1916 == nil { tmp29 = ifn_1917.Invoke_O__O(arg_1918) } else { tmp29 = linked_1916.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1915, arg_1918) }; arg_1755 = tmp28.Invoke_O__O(tmp29)
//line :302:1
		if linked_1752 == nil { globals__24 = ifn_1753.Invoke_O_O__O(arg_1754, arg_1755) } else { globals__24 = linked_1752.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1751, arg_1754, arg_1755)
		}







		var root_2214 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_2215 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2214, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2216 lang.IFn; if linked_2215 == nil { ifn_2216 = lang.IFn_Cast(root_2214) } else { ifn_2216 = nil }; var arg_2217 any = st__0; var arg_2218 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_2219 any = A_arbace_go_repl_A_const_60; var arg_2220 any = globals__24; if linked_2215 == nil { ifn_2216.Invoke_O_O_O_O__O(arg_2217, arg_2218, arg_2219, arg_2220) } else { linked_2215.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2214, arg_2217, arg_2218, arg_2219, arg_2220) }
//line :258:1
		var seq_794000260__25 any; var root_2221 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2221, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2223 lang.IFn






















































		if linked_2222 == nil { ifn_2223 = lang.IFn_Cast(root_2221) } else { ifn_2223 = nil }; var arg_2224 any = new_funcs__20; if linked_2222 == nil { seq_794000260__25 = ifn_2223.Invoke_O__O(arg_2224) } else { seq_794000260__25 = linked_2222.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2221, arg_2224) }
//line :258:1
		var chunk_794000261__26 any; var count_794000262__27 int64 = 0; var i_794000263__28 int64 = 0; L1: for {






















































			if lang.Numbers_Lt_J_J__Z_NoInit(i_794000263__28, count_794000262__27) { var vec__794000264__29 any = lang.Indexed_Cast(chunk_794000261__26).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_794000263__28)); var nm__30 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000264__29, lang.RT_IntCast_J__I_NoInit(0), nil); var map__794000267__31 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000264__29, lang.RT_IntCast_J__I_NoInit(1), nil); var map__794000267__32 any; if lang.ISeq_InstanceOf(map__794000267__31) { var tmp30 any; var root_2225 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2225, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2227 lang.IFn; if linked_2226 == nil { ifn_2227 = lang.IFn_Cast(root_2225) } else { ifn_2227 = nil }; var arg_2228 any = map__794000267__31; if linked_2226 == nil { tmp30 = ifn_2227.Invoke_O__O(arg_2228) } else { tmp30 = linked_2226.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2225, arg_2228) }; if jrt.J2g_Truth(tmp30) { var tmp31 any; var root_2229 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_2230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2229, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2231 lang.IFn; if linked_2230 == nil { ifn_2231 = lang.IFn_Cast(root_2229) } else { ifn_2231 = nil }; var arg_2232 any = map__794000267__31; if linked_2230 == nil { tmp31 = ifn_2231.Invoke_O__O(arg_2232) } else { tmp31 = linked_2230.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2229, arg_2232) }; map__794000267__32 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp31, jrt.Object_class.ArrayClass())).Ref() } else { var tmp32 any; var root_2233 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2233, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2235 lang.IFn; if linked_2234 == nil { ifn_2235 = lang.IFn_Cast(root_2233) } else { ifn_2235 = nil }; var arg_2236 any = map__794000267__31; if linked_2234 == nil { tmp32 = ifn_2235.Invoke_O__O(arg_2236) } else { tmp32 = linked_2234.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2233, arg_2236) }; if jrt.J2g_Truth(tmp32) { var root_2237 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2237, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2239 lang.IFn; if linked_2238 == nil { ifn_2239 = lang.IFn_Cast(root_2237) } else { ifn_2239 = nil }; var arg_2240 any = map__794000267__31; if linked_2238 == nil { map__794000267__32 = ifn_2239.Invoke_O__O(arg_2240) } else { map__794000267__32 = linked_2238.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2237, arg_2240) } } else { map__794000267__32 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000267__32 = map__794000267__31 }; var cell__33 any = lang.RT_Get_O_O__O_NoInit(map__794000267__32, A_arbace_go_repl_A_const_155); var tree__34 any = lang.RT_Get_O_O__O_NoInit(map__794000267__32, A_arbace_go_repl_A_const_181); var kept__35 any = lang.RT_Get_O_O__O_NoInit(map__794000267__32, A_arbace_go_repl_A_const_180); var tmp33 any; var root_2241 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_2242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2241, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2243 lang.IFn
				if linked_2242 == nil { ifn_2243 = lang.IFn_Cast(root_2241) } else { ifn_2243 = nil }; var arg_2244 any = kept__35; if linked_2242 == nil { tmp33 = ifn_2243.Invoke_O__O(arg_2244) } else { tmp33 = linked_2242.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2241, arg_2244) }
//line :313:1
				if jrt.J2g_Truth(tmp33) { var tmp34 any; var or__1927000174__auto____36 bool = lang.Util_Identical_O_O__Z_NoInit(only__8, nil)

					if or__1927000174__auto____36 { tmp34 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____36).Ref() } else { var root_2245 any = A_arbace_go_repl_A_const_18.GetRawRoot__O(); var linked_2246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2245, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2247 lang.IFn; if linked_2246 == nil { ifn_2247 = lang.IFn_Cast(root_2245) } else { ifn_2247 = nil }; var arg_2248 any = only__8; var arg_2249 any = nm__30; if linked_2246 == nil { tmp34 = ifn_2247.Invoke_O_O__O(arg_2248, arg_2249) } else { tmp34 = linked_2246.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2245, arg_2248, arg_2249) } }
//line :313:1
					if jrt.J2g_Truth(tmp34) {


						if jrt.J2g_Truth(eager__7) {
							var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_179.GetRawRoot__O()); var tmp36 any; var root_2367 any = A_arbace_go_repl_A_const_198.GetRawRoot__O(); var linked_2368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2367, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2369 lang.IFn; if linked_2368 == nil { ifn_2369 = lang.IFn_Cast(root_2367) } else { ifn_2369 = nil }; var arg_2370 any = lang.IFn_Cast(A_arbace_go_repl_A_const_38.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_repl_A_const_199, ctx__11); if linked_2368 == nil { ifn_2369.Invoke_O__O(arg_2370) } else { linked_2368.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2367, arg_2370) }; var tmp37 any = A_arbace_go_repl_define_BANG__fn__794000269_A_New_O(tree__34); var tmp38 *jrt.Class; var fncls__2366 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000269_A_fn_class; if fncls__2366 == nil { var fncls__2366d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_go_repl_define_BANG__fn__794000269_A_fn_class = fncls__2366d; tmp38 = fncls__2366d } else { tmp38 = fncls__2366 }; tmp36 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp37, tmp38, nil).Invoke__O(); tmp35.Invoke_O_O_O_O__O(Lit_71, cell__33, tmp36, nil) } else {
								var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_179.GetRawRoot__O()); var tmp40 any = A_arbace_go_repl_define_BANG__fn__794000271_A_New_O_O(ctx__11, tree__34); var tmp41 *jrt.Class; var fncls__2399 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000271_A_fn_class; if fncls__2399 == nil { var fncls__2399d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_go_repl_define_BANG__fn__794000271_A_fn_class = fncls__2399d; tmp41 = fncls__2399d } else { tmp41 = fncls__2399 }; tmp39.Invoke_O_O_O_O__O(Lit_71, cell__33, nil, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp40, tmp41, nil)) }
//line :313:1
						seq_794000260__25, chunk_794000261__26, count_794000262__27, i_794000263__28 = seq_794000260__25, chunk_794000261__26, count_794000262__27, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000263__28); continue L1 } else { seq_794000260__25, chunk_794000261__26, count_794000262__27, i_794000263__28 = seq_794000260__25, chunk_794000261__26, count_794000262__27, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000263__28); continue L1 } } else { seq_794000260__25, chunk_794000261__26, count_794000262__27, i_794000263__28 = seq_794000260__25, chunk_794000261__26, count_794000262__27, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000263__28); continue L1 } } else { var temp__1927000414__auto____29 any; var root_2250 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2250, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2252 lang.IFn; if linked_2251 == nil { ifn_2252 = lang.IFn_Cast(root_2250) } else { ifn_2252 = nil }; var arg_2253 any = seq_794000260__25; if linked_2251 == nil { temp__1927000414__auto____29 = ifn_2252.Invoke_O__O(arg_2253) } else { temp__1927000414__auto____29 = linked_2251.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2250, arg_2253) }; if jrt.J2g_Truth(temp__1927000414__auto____29) { var seq_794000260__30 any = temp__1927000414__auto____29; var tmp42 any; var root_2254 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_2255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2254, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2256 lang.IFn; if linked_2255 == nil { ifn_2256 = lang.IFn_Cast(root_2254) } else { ifn_2256 = nil }; var arg_2257 any = seq_794000260__30; if linked_2255 == nil { tmp42 = ifn_2256.Invoke_O__O(arg_2257) } else { tmp42 = linked_2255.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2254, arg_2257) }; if jrt.J2g_Truth(tmp42) { var c__1927000678__auto____31 any; var root_2258 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_2259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2258, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2260 lang.IFn; if linked_2259 == nil { ifn_2260 = lang.IFn_Cast(root_2258) } else { ifn_2260 = nil }; var arg_2261 any = seq_794000260__30; if linked_2259 == nil { c__1927000678__auto____31 = ifn_2260.Invoke_O__O(arg_2261) } else { c__1927000678__auto____31 = linked_2259.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2258, arg_2261) }; var tmp43 any; var root_2400 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_2401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2400, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2402 lang.IFn; if linked_2401 == nil { ifn_2402 = lang.IFn_Cast(root_2400) } else { ifn_2402 = nil }; var arg_2403 any = seq_794000260__30; if linked_2401 == nil { tmp43 = ifn_2402.Invoke_O__O(arg_2403) } else { tmp43 = linked_2401.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2400, arg_2403) }; seq_794000260__25, chunk_794000261__26, count_794000262__27, i_794000263__28 = tmp43, c__1927000678__auto____31, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____31))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__794000273__31 any; var root_2262 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2262, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2264 lang.IFn; if linked_2263 == nil { ifn_2264 = lang.IFn_Cast(root_2262) } else { ifn_2264 = nil }; var arg_2265 any = seq_794000260__30; if linked_2263 == nil { vec__794000273__31 = ifn_2264.Invoke_O__O(arg_2265) } else { vec__794000273__31 = linked_2263.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2262, arg_2265) }; var nm__32 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000273__31, lang.RT_IntCast_J__I_NoInit(0), nil); var map__794000276__33 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000273__31, lang.RT_IntCast_J__I_NoInit(1), nil); var map__794000276__34 any; if lang.ISeq_InstanceOf(map__794000276__33) { var tmp44 any; var root_2266 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2266, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2268 lang.IFn; if linked_2267 == nil { ifn_2268 = lang.IFn_Cast(root_2266) } else { ifn_2268 = nil }; var arg_2269 any = map__794000276__33; if linked_2267 == nil { tmp44 = ifn_2268.Invoke_O__O(arg_2269) } else { tmp44 = linked_2267.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2266, arg_2269) }; if jrt.J2g_Truth(tmp44) { var tmp45 any; var root_2270 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_2271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2270, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2272 lang.IFn; if linked_2271 == nil { ifn_2272 = lang.IFn_Cast(root_2270) } else { ifn_2272 = nil }; var arg_2273 any = map__794000276__33; if linked_2271 == nil { tmp45 = ifn_2272.Invoke_O__O(arg_2273) } else { tmp45 = linked_2271.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2270, arg_2273) }; map__794000276__34 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp45, jrt.Object_class.ArrayClass())).Ref() } else { var tmp46 any; var root_2274 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2274, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2276 lang.IFn; if linked_2275 == nil { ifn_2276 = lang.IFn_Cast(root_2274) } else { ifn_2276 = nil }; var arg_2277 any = map__794000276__33; if linked_2275 == nil { tmp46 = ifn_2276.Invoke_O__O(arg_2277) } else { tmp46 = linked_2275.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2274, arg_2277) }; if jrt.J2g_Truth(tmp46) { var root_2278 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2278, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2280 lang.IFn; if linked_2279 == nil { ifn_2280 = lang.IFn_Cast(root_2278) } else { ifn_2280 = nil }; var arg_2281 any = map__794000276__33; if linked_2279 == nil { map__794000276__34 = ifn_2280.Invoke_O__O(arg_2281) } else { map__794000276__34 = linked_2279.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2278, arg_2281) } } else { map__794000276__34 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000276__34 = map__794000276__33 }; var cell__35 any = lang.RT_Get_O_O__O_NoInit(map__794000276__34, A_arbace_go_repl_A_const_155); var tree__36 any = lang.RT_Get_O_O__O_NoInit(map__794000276__34, A_arbace_go_repl_A_const_181); var kept__37 any = lang.RT_Get_O_O__O_NoInit(map__794000276__34, A_arbace_go_repl_A_const_180); var tmp47 any; var root_2282 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_2283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2282, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2284 lang.IFn
							if linked_2283 == nil { ifn_2284 = lang.IFn_Cast(root_2282) } else { ifn_2284 = nil }; var arg_2285 any = kept__37; if linked_2283 == nil { tmp47 = ifn_2284.Invoke_O__O(arg_2285) } else { tmp47 = linked_2283.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2282, arg_2285) }
//line :313:1
							if jrt.J2g_Truth(tmp47) { var tmp48 any; var or__1927000174__auto____38 bool = lang.Util_Identical_O_O__Z_NoInit(only__8, nil)

								if or__1927000174__auto____38 { tmp48 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____38).Ref() } else { var root_2286 any = A_arbace_go_repl_A_const_18.GetRawRoot__O(); var linked_2287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2286, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2288 lang.IFn; if linked_2287 == nil { ifn_2288 = lang.IFn_Cast(root_2286) } else { ifn_2288 = nil }; var arg_2289 any = only__8; var arg_2290 any = nm__32; if linked_2287 == nil { tmp48 = ifn_2288.Invoke_O_O__O(arg_2289, arg_2290) } else { tmp48 = linked_2287.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2286, arg_2289, arg_2290) } }
//line :313:1
								if jrt.J2g_Truth(tmp48) {


									if jrt.J2g_Truth(eager__7) {
										var tmp49 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_179.GetRawRoot__O()); var tmp50 any; var root_2419 any = A_arbace_go_repl_A_const_198.GetRawRoot__O(); var linked_2420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2419, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2421 lang.IFn; if linked_2420 == nil { ifn_2421 = lang.IFn_Cast(root_2419) } else { ifn_2421 = nil }; var arg_2422 any = lang.IFn_Cast(A_arbace_go_repl_A_const_38.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_repl_A_const_199, ctx__11); if linked_2420 == nil { ifn_2421.Invoke_O__O(arg_2422) } else { linked_2420.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2419, arg_2422) }; var tmp51 any = A_arbace_go_repl_define_BANG__fn__794000278_A_New_O(tree__36); var tmp52 *jrt.Class; var fncls__2418 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000278_A_fn_class; if fncls__2418 == nil { var fncls__2418d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_go_repl_define_BANG__fn__794000278_A_fn_class = fncls__2418d; tmp52 = fncls__2418d } else { tmp52 = fncls__2418 }; tmp50 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp51, tmp52, nil).Invoke__O(); tmp49.Invoke_O_O_O_O__O(Lit_71, cell__35, tmp50, nil) } else {
											var tmp53 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_179.GetRawRoot__O()); var tmp54 any = A_arbace_go_repl_define_BANG__fn__794000280_A_New_O_O(tree__36, ctx__11); var tmp55 *jrt.Class; var fncls__2451 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000280_A_fn_class; if fncls__2451 == nil { var fncls__2451d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_go_repl_define_BANG__fn__794000280_A_fn_class = fncls__2451d; tmp55 = fncls__2451d } else { tmp55 = fncls__2451 }; tmp53.Invoke_O_O_O_O__O(Lit_71, cell__35, nil, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp54, tmp55, nil)) }
//line :313:1
									var tmp56 any; var root_2452 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2452, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2454 lang.IFn; if linked_2453 == nil { ifn_2454 = lang.IFn_Cast(root_2452) } else { ifn_2454 = nil }; var arg_2455 any = seq_794000260__30; if linked_2453 == nil { tmp56 = ifn_2454.Invoke_O__O(arg_2455) } else { tmp56 = linked_2453.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2452, arg_2455) }; seq_794000260__25, chunk_794000261__26, count_794000262__27, i_794000263__28 = tmp56, nil, 0, 0; continue L1 } else { var tmp57 any; var root_2456 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2456, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2458 lang.IFn; if linked_2457 == nil { ifn_2458 = lang.IFn_Cast(root_2456) } else { ifn_2458 = nil }; var arg_2459 any = seq_794000260__30; if linked_2457 == nil { tmp57 = ifn_2458.Invoke_O__O(arg_2459) } else { tmp57 = linked_2457.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2456, arg_2459) }; seq_794000260__25, chunk_794000261__26, count_794000262__27, i_794000263__28 = tmp57, nil, 0, 0; continue L1 } } else { var tmp58 any; var root_2460 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2460, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2462 lang.IFn; if linked_2461 == nil { ifn_2462 = lang.IFn_Cast(root_2460) } else { ifn_2462 = nil }; var arg_2463 any = seq_794000260__30; if linked_2461 == nil { tmp58 = ifn_2462.Invoke_O__O(arg_2463) } else { tmp58 = linked_2461.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2460, arg_2463) }; seq_794000260__25, chunk_794000261__26, count_794000262__27, i_794000263__28 = tmp58, nil, 0, 0; continue L1 } } } }
//line :258:1
			break L1 }; var seq_794000282__25 any; var root_2291 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2291, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2293 lang.IFn




























































		if linked_2292 == nil { ifn_2293 = lang.IFn_Cast(root_2291) } else { ifn_2293 = nil }; var arg_2294 any = init_cells__21; if linked_2292 == nil { seq_794000282__25 = ifn_2293.Invoke_O__O(arg_2294) } else { seq_794000282__25 = linked_2292.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2291, arg_2294) }
//line :258:1
		var chunk_794000283__26 any; var count_794000284__27 int64 = 0; var i_794000285__28 int64 = 0; L2: for {




























































			if lang.Numbers_Lt_J_J__Z_NoInit(i_794000285__28, count_794000284__27) { var map__794000286__29 any = lang.Indexed_Cast(chunk_794000283__26).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_794000285__28)); var map__794000286__30 any; if lang.ISeq_InstanceOf(map__794000286__29) { var tmp59 any; var root_2295 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2295, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2297 lang.IFn; if linked_2296 == nil { ifn_2297 = lang.IFn_Cast(root_2295) } else { ifn_2297 = nil }; var arg_2298 any = map__794000286__29; if linked_2296 == nil { tmp59 = ifn_2297.Invoke_O__O(arg_2298) } else { tmp59 = linked_2296.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2295, arg_2298) }; if jrt.J2g_Truth(tmp59) { var tmp60 any; var root_2299 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_2300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2299, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2301 lang.IFn; if linked_2300 == nil { ifn_2301 = lang.IFn_Cast(root_2299) } else { ifn_2301 = nil }; var arg_2302 any = map__794000286__29; if linked_2300 == nil { tmp60 = ifn_2301.Invoke_O__O(arg_2302) } else { tmp60 = linked_2300.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2299, arg_2302) }; map__794000286__30 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp60, jrt.Object_class.ArrayClass())).Ref() } else { var tmp61 any; var root_2303 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2303, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2305 lang.IFn; if linked_2304 == nil { ifn_2305 = lang.IFn_Cast(root_2303) } else { ifn_2305 = nil }; var arg_2306 any = map__794000286__29; if linked_2304 == nil { tmp61 = ifn_2305.Invoke_O__O(arg_2306) } else { tmp61 = linked_2304.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2303, arg_2306) }; if jrt.J2g_Truth(tmp61) { var root_2307 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2307, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2309 lang.IFn; if linked_2308 == nil { ifn_2309 = lang.IFn_Cast(root_2307) } else { ifn_2309 = nil }; var arg_2310 any = map__794000286__29; if linked_2308 == nil { map__794000286__30 = ifn_2309.Invoke_O__O(arg_2310) } else { map__794000286__30 = linked_2308.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2307, arg_2310) } } else { map__794000286__30 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000286__30 = map__794000286__29 }; var cell__31 any = lang.RT_Get_O_O__O_NoInit(map__794000286__30, A_arbace_go_repl_A_const_155); var tree__32 any = lang.RT_Get_O_O__O_NoInit(map__794000286__30, A_arbace_go_repl_A_const_181); var tmp62 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_179.GetRawRoot__O()); var tmp63 any; var root_2479 any = A_arbace_go_repl_A_const_198.GetRawRoot__O(); var linked_2480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2479, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2481 lang.IFn
				if linked_2480 == nil { ifn_2481 = lang.IFn_Cast(root_2479) } else { ifn_2481 = nil }; var arg_2482 any = lang.IFn_Cast(A_arbace_go_repl_A_const_38.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_repl_A_const_199, ctx__11); if linked_2480 == nil { ifn_2481.Invoke_O__O(arg_2482) } else { linked_2480.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2479, arg_2482) }; var tmp64 any = A_arbace_go_repl_define_BANG__fn__794000288_A_New_O(tree__32); var tmp65 *jrt.Class; var fncls__2478 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000288_A_fn_class; if fncls__2478 == nil { var fncls__2478d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_go_repl_define_BANG__fn__794000288_A_fn_class = fncls__2478d; tmp65 = fncls__2478d } else { tmp65 = fncls__2478 }; tmp63 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp64, tmp65, nil).Invoke__O(); tmp62.Invoke_O_O_O_O__O(Lit_71, cell__31, tmp63, nil)
//line :319:1
				seq_794000282__25, chunk_794000283__26, count_794000284__27, i_794000285__28 = seq_794000282__25, chunk_794000283__26, count_794000284__27, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000285__28); continue L2 } else { var temp__1927000414__auto____29_2 any; var root_2311 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2311, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2313 lang.IFn; if linked_2312 == nil { ifn_2313 = lang.IFn_Cast(root_2311) } else { ifn_2313 = nil }; var arg_2314 any = seq_794000282__25; if linked_2312 == nil { temp__1927000414__auto____29_2 = ifn_2313.Invoke_O__O(arg_2314) } else { temp__1927000414__auto____29_2 = linked_2312.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2311, arg_2314) }; if jrt.J2g_Truth(temp__1927000414__auto____29_2) { var seq_794000282__30 any = temp__1927000414__auto____29_2; var tmp66 any; var root_2315 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_2316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2315, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2317 lang.IFn; if linked_2316 == nil { ifn_2317 = lang.IFn_Cast(root_2315) } else { ifn_2317 = nil }; var arg_2318 any = seq_794000282__30; if linked_2316 == nil { tmp66 = ifn_2317.Invoke_O__O(arg_2318) } else { tmp66 = linked_2316.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2315, arg_2318) }; if jrt.J2g_Truth(tmp66) { var c__1927000678__auto____31_2 any; var root_2319 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_2320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2319, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2321 lang.IFn; if linked_2320 == nil { ifn_2321 = lang.IFn_Cast(root_2319) } else { ifn_2321 = nil }; var arg_2322 any = seq_794000282__30; if linked_2320 == nil { c__1927000678__auto____31_2 = ifn_2321.Invoke_O__O(arg_2322) } else { c__1927000678__auto____31_2 = linked_2320.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2319, arg_2322) }; var tmp67 any; var root_2488 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_2489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2488, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2490 lang.IFn; if linked_2489 == nil { ifn_2490 = lang.IFn_Cast(root_2488) } else { ifn_2490 = nil }; var arg_2491 any = seq_794000282__30; if linked_2489 == nil { tmp67 = ifn_2490.Invoke_O__O(arg_2491) } else { tmp67 = linked_2489.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2488, arg_2491) }; seq_794000282__25, chunk_794000283__26, count_794000284__27, i_794000285__28 = tmp67, c__1927000678__auto____31_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____31_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var map__794000290__31 any; var root_2323 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2323, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2325 lang.IFn; if linked_2324 == nil { ifn_2325 = lang.IFn_Cast(root_2323) } else { ifn_2325 = nil }; var arg_2326 any = seq_794000282__30; if linked_2324 == nil { map__794000290__31 = ifn_2325.Invoke_O__O(arg_2326) } else { map__794000290__31 = linked_2324.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2323, arg_2326) }; var map__794000290__32 any; if lang.ISeq_InstanceOf(map__794000290__31) { var tmp68 any; var root_2327 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2327, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2329 lang.IFn; if linked_2328 == nil { ifn_2329 = lang.IFn_Cast(root_2327) } else { ifn_2329 = nil }; var arg_2330 any = map__794000290__31; if linked_2328 == nil { tmp68 = ifn_2329.Invoke_O__O(arg_2330) } else { tmp68 = linked_2328.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2327, arg_2330) }; if jrt.J2g_Truth(tmp68) { var tmp69 any; var root_2331 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_2332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2331, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2333 lang.IFn; if linked_2332 == nil { ifn_2333 = lang.IFn_Cast(root_2331) } else { ifn_2333 = nil }; var arg_2334 any = map__794000290__31; if linked_2332 == nil { tmp69 = ifn_2333.Invoke_O__O(arg_2334) } else { tmp69 = linked_2332.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2331, arg_2334) }; map__794000290__32 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp69, jrt.Object_class.ArrayClass())).Ref() } else { var tmp70 any; var root_2335 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2335, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2337 lang.IFn; if linked_2336 == nil { ifn_2337 = lang.IFn_Cast(root_2335) } else { ifn_2337 = nil }; var arg_2338 any = map__794000290__31; if linked_2336 == nil { tmp70 = ifn_2337.Invoke_O__O(arg_2338) } else { tmp70 = linked_2336.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2335, arg_2338) }; if jrt.J2g_Truth(tmp70) { var root_2339 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2339, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2341 lang.IFn; if linked_2340 == nil { ifn_2341 = lang.IFn_Cast(root_2339) } else { ifn_2341 = nil }; var arg_2342 any = map__794000290__31; if linked_2340 == nil { map__794000290__32 = ifn_2341.Invoke_O__O(arg_2342) } else { map__794000290__32 = linked_2340.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2339, arg_2342) } } else { map__794000290__32 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000290__32 = map__794000290__31 }; var cell__33_2 any = lang.RT_Get_O_O__O_NoInit(map__794000290__32, A_arbace_go_repl_A_const_155); var tree__34_2 any = lang.RT_Get_O_O__O_NoInit(map__794000290__32, A_arbace_go_repl_A_const_181); var tmp71 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_179.GetRawRoot__O()); var tmp72 any; var root_2507 any = A_arbace_go_repl_A_const_198.GetRawRoot__O(); var linked_2508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2507, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2509 lang.IFn
					if linked_2508 == nil { ifn_2509 = lang.IFn_Cast(root_2507) } else { ifn_2509 = nil }; var arg_2510 any = lang.IFn_Cast(A_arbace_go_repl_A_const_38.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_repl_A_const_199, ctx__11); if linked_2508 == nil { ifn_2509.Invoke_O__O(arg_2510) } else { linked_2508.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2507, arg_2510) }; var tmp73 any = A_arbace_go_repl_define_BANG__fn__794000292_A_New_O(tree__34_2); var tmp74 *jrt.Class; var fncls__2506 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000292_A_fn_class; if fncls__2506 == nil { var fncls__2506d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_go_repl_define_BANG__fn__794000292_A_fn_class = fncls__2506d; tmp74 = fncls__2506d } else { tmp74 = fncls__2506 }; tmp72 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp73, tmp74, nil).Invoke__O(); tmp71.Invoke_O_O_O_O__O(Lit_71, cell__33_2, tmp72, nil)
//line :319:1
					var tmp75 any; var root_2516 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2516, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2518 lang.IFn; if linked_2517 == nil { ifn_2518 = lang.IFn_Cast(root_2516) } else { ifn_2518 = nil }; var arg_2519 any = seq_794000282__30; if linked_2517 == nil { tmp75 = ifn_2518.Invoke_O__O(arg_2519) } else { tmp75 = linked_2517.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2516, arg_2519) }; seq_794000282__25, chunk_794000283__26, count_794000284__27, i_794000285__28 = tmp75, nil, 0, 0; continue L2 } } }
//line :258:1
			break L2
		}





























































		var tmp76 any; var and__1927000168__auto____25 any = eager__7; if jrt.J2g_Truth(and__1927000168__auto____25) { var root_2343 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2343, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2345 lang.IFn; if linked_2344 == nil { ifn_2345 = lang.IFn_Cast(root_2343) } else { ifn_2345 = nil }; var arg_2346 any = methods__19; if linked_2344 == nil { tmp76 = ifn_2345.Invoke_O__O(arg_2346) } else { tmp76 = linked_2344.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2343, arg_2346) } } else { tmp76 = and__1927000168__auto____25 }; if jrt.J2g_Truth(tmp76) {
			var root_2347 any = A_arbace_go_repl_A_const_201.GetRawRoot__O(); var linked_2348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2347, aot_arbace_go_build.A_arbace_go_build_unsupported_BANG__A_fn_class); var ifn_2349 lang.IFn; if linked_2348 == nil { ifn_2349 = lang.IFn_Cast(root_2347) } else { ifn_2349 = nil }; var arg_2350 any = Lit_78; var arg_2351 any = Lit_79; if linked_2348 == nil { ifn_2349.Invoke_O_O__O(arg_2350, arg_2351) } else { linked_2348.(*aot_arbace_go_build.A_arbace_go_build_unsupported_BANG__A).Invoke_O_O_O__O(root_2347, arg_2350, arg_2351) } }
//line :258:1
		var var_trees__25 any; var root_1919 any = A_arbace_go_repl_A_const_88.GetRawRoot__O(); var linked_1920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1919, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1921 lang.IFn

































































		if linked_1920 == nil { ifn_1921 = lang.IFn_Cast(root_1919) } else { ifn_1921 = nil }; var arg_1922 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1923 any; var iter__1927001039__auto____25 any; var tmp77 any = A_arbace_go_repl_define_BANG__iter__794000294__794000298_A_New(); var tmp78 *jrt.Class; var fncls__1998 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000294__794000298_A_fn_class; if fncls__1998 == nil { var fncls__1998d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_go_repl_define_BANG__iter__794000294__794000298_A_fn_class = fncls__1998d; tmp78 = fncls__1998d } else { tmp78 = fncls__1998 }; iter__1927001039__auto____25 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp77, tmp78, nil); arg_1923 = lang.IFn_Cast(iter__1927001039__auto____25).Invoke_O__O(decls__12); if linked_1920 == nil { var_trees__25 = ifn_1921.Invoke_O_O__O(arg_1922, arg_1923) } else { var_trees__25 = linked_1920.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1919, arg_1922, arg_1923) }
//line :258:1
		var ordered__26 any; var root_1999 any = A_arbace_go_repl_A_const_190.GetRawRoot__O(); var linked_2000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1999, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2001 lang.IFn



































































		if linked_2000 == nil { ifn_2001 = lang.IFn_Cast(root_1999) } else { ifn_2001 = nil }; var arg_2002 any; var tmp79 any = A_arbace_go_repl_define_BANG__fn__794000304_A_New_O(var_trees__25); var tmp80 *jrt.Class; var fncls__2008 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000304_A_fn_class; if fncls__2008 == nil { var fncls__2008d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_go_repl_define_BANG__fn__794000304_A_fn_class = fncls__2008d; tmp80 = fncls__2008d } else { tmp80 = fncls__2008 }; arg_2002 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp79, tmp80, nil); var arg_2003 any = A_arbace_go_repl_A_const_191.Invoke_O__O(r__1); if linked_2000 == nil { ordered__26 = ifn_2001.Invoke_O_O__O(arg_2002, arg_2003) } else { ordered__26 = linked_2000.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1999, arg_2002, arg_2003) }
//line :258:1
		var inits__27 any = lang.IFn_Cast(A_arbace_go_repl_A_const_179.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_82, Lit_83, A_arbace_go_repl_A_const_55.Invoke_O__O(old__13), nil); var ordered__28 any; var temp__1927000408__auto____28 any
		var or__1927000174__auto____28 any = init_names__10




































































		if jrt.J2g_Truth(or__1927000174__auto____28) { temp__1927000408__auto____28 = or__1927000174__auto____28 } else { temp__1927000408__auto____28 = only__8 }; if jrt.J2g_Truth(temp__1927000408__auto____28) { var names__29 any = temp__1927000408__auto____28; var root_2016 any = A_arbace_go_repl_A_const_33.GetRawRoot__O(); var linked_2017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2016, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_2018 lang.IFn
			if linked_2017 == nil { ifn_2018 = lang.IFn_Cast(root_2016) } else { ifn_2018 = nil }; var arg_2019 any; var tmp81 any = A_arbace_go_repl_define_BANG__fn__794000306_A_New_O(names__29); var tmp82 *jrt.Class; var fncls__2037 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000306_A_fn_class; if fncls__2037 == nil { var fncls__2037d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_go_repl_define_BANG__fn__794000306_A_fn_class = fncls__2037d; tmp82 = fncls__2037d } else { tmp82 = fncls__2037 }; arg_2019 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp81, tmp82, nil); var arg_2020 any = ordered__26; if linked_2017 == nil { ordered__28 = ifn_2018.Invoke_O_O__O(arg_2019, arg_2020) } else { ordered__28 = linked_2017.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_2016, arg_2019, arg_2020) } } else {
//line :328:1
				ordered__28 = ordered__26
			}

		var tmp83 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_179.GetRawRoot__O()); var tmp84 any; var root_2527 any = A_arbace_go_repl_A_const_203.GetRawRoot__O(); var linked_2528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2527, aot_arbace_go_build.A_arbace_go_build_build_inits_A_fn_class); var ifn_2529 lang.IFn; if linked_2528 == nil { ifn_2529 = lang.IFn_Cast(root_2527) } else { ifn_2529 = nil }; var arg_2530 any = ordered__28; if linked_2528 == nil { tmp84 = ifn_2529.Invoke_O__O(arg_2530) } else { tmp84 = linked_2528.(*aot_arbace_go_build.A_arbace_go_build_build_inits_A).Invoke_O_O__O(root_2527, arg_2530) }; tmp83.Invoke_O_O_O_O__O(Lit_71, inits__27, tmp84, nil)

		if jrt.J2g_Truth(vars_QMARK___6) { var ns__29 any; var root_2531 any = A_arbace_go_repl_A_const_204.GetRawRoot__O(); var linked_2532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2531, aot_arbace_core.A_arbace_core_create_ns_A_fn_class); var ifn_2533 lang.IFn
			if linked_2532 == nil { ifn_2533 = lang.IFn_Cast(root_2531) } else { ifn_2533 = nil }; var arg_2534 any = A_arbace_go_repl_A_const_56.Invoke_O__O(old__13); if linked_2532 == nil { ns__29 = ifn_2533.Invoke_O__O(arg_2534) } else { ns__29 = linked_2532.(*aot_arbace_core.A_arbace_core_create_ns_A).Invoke_O_O__O(root_2531, arg_2534) }
//line :333:1
			var seq_794000310__30 any; var root_2580 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2580, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2582 lang.IFn

			if linked_2581 == nil { ifn_2582 = lang.IFn_Cast(root_2580) } else { ifn_2582 = nil }; var arg_2583 any = new_funcs__20; if linked_2581 == nil { seq_794000310__30 = ifn_2582.Invoke_O__O(arg_2583) } else { seq_794000310__30 = linked_2581.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2580, arg_2583) }
//line :333:1
			var chunk_794000311__31 any; var count_794000312__32 int64 = 0; var i_794000313__33 int64 = 0; L3: for {

				if lang.Numbers_Lt_J_J__Z_NoInit(i_794000313__33, count_794000312__32) { var vec__794000314__34 any = lang.Indexed_Cast(chunk_794000311__31).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_794000313__33)); var nm__35 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000314__34, lang.RT_IntCast_J__I_NoInit(0), nil); var map__794000317__36 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000314__34, lang.RT_IntCast_J__I_NoInit(1), nil); var map__794000317__37 any; if lang.ISeq_InstanceOf(map__794000317__36) { var tmp85 any; var root_2584 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2584, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2586 lang.IFn; if linked_2585 == nil { ifn_2586 = lang.IFn_Cast(root_2584) } else { ifn_2586 = nil }; var arg_2587 any = map__794000317__36; if linked_2585 == nil { tmp85 = ifn_2586.Invoke_O__O(arg_2587) } else { tmp85 = linked_2585.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2584, arg_2587) }; if jrt.J2g_Truth(tmp85) { var tmp86 any; var root_2588 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_2589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2588, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2590 lang.IFn; if linked_2589 == nil { ifn_2590 = lang.IFn_Cast(root_2588) } else { ifn_2590 = nil }; var arg_2591 any = map__794000317__36; if linked_2589 == nil { tmp86 = ifn_2590.Invoke_O__O(arg_2591) } else { tmp86 = linked_2589.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2588, arg_2591) }; map__794000317__37 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp86, jrt.Object_class.ArrayClass())).Ref() } else { var tmp87 any; var root_2592 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2592, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2594 lang.IFn; if linked_2593 == nil { ifn_2594 = lang.IFn_Cast(root_2592) } else { ifn_2594 = nil }; var arg_2595 any = map__794000317__36; if linked_2593 == nil { tmp87 = ifn_2594.Invoke_O__O(arg_2595) } else { tmp87 = linked_2593.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2592, arg_2595) }; if jrt.J2g_Truth(tmp87) { var root_2596 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2596, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2598 lang.IFn; if linked_2597 == nil { ifn_2598 = lang.IFn_Cast(root_2596) } else { ifn_2598 = nil }; var arg_2599 any = map__794000317__36; if linked_2597 == nil { map__794000317__37 = ifn_2598.Invoke_O__O(arg_2599) } else { map__794000317__37 = linked_2597.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2596, arg_2599) } } else { map__794000317__37 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000317__37 = map__794000317__36 }; var cell__38 any = lang.RT_Get_O_O__O_NoInit(map__794000317__37, A_arbace_go_repl_A_const_155); var obj__39 any = lang.RT_Get_O_O__O_NoInit(map__794000317__37, A_arbace_go_repl_A_const_177); var spec__40 any; var root_2742 any = A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_2743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2742, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2744 lang.IFn
					if linked_2743 == nil { ifn_2744 = lang.IFn_Cast(root_2742) } else { ifn_2744 = nil }; var arg_2745 any; var tmp88 any = A_arbace_go_repl_define_BANG__fn__794000319_A_New_O(obj__39); var tmp89 *jrt.Class; var fncls__2747 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000319_A_fn_class; if fncls__2747 == nil { var fncls__2747d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_go_repl_define_BANG__fn__794000319_A_fn_class = fncls__2747d; tmp89 = fncls__2747d } else { tmp89 = fncls__2747 }; arg_2745 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp88, tmp89, nil); var arg_2746 any = decls__12; if linked_2743 == nil { spec__40 = ifn_2744.Invoke_O_O__O(arg_2745, arg_2746) } else { spec__40 = linked_2743.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2742, arg_2745, arg_2746) }
//line :335:1
					var doc__41 any; var tmp90 any; var and__1927000168__auto____41 any; var root_2748 any = A_arbace_go_repl_A_const_34.GetRawRoot__O(); var linked_2749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2748, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_2750 lang.IFn

					if linked_2749 == nil { ifn_2750 = lang.IFn_Cast(root_2748) } else { ifn_2750 = nil }; var arg_2751 any = spec__40; if linked_2749 == nil { and__1927000168__auto____41 = ifn_2750.Invoke_O__O(arg_2751) } else { and__1927000168__auto____41 = linked_2749.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_2748, arg_2751) }; if jrt.J2g_Truth(and__1927000168__auto____41) { var root_2752 any = A_arbace_go_repl_A_const_90.GetRawRoot__O(); var linked_2753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2752, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_2754 lang.IFn; if linked_2753 == nil { ifn_2754 = lang.IFn_Cast(root_2752) } else { ifn_2754 = nil }; var arg_2755 any = lang.RT_Nth_O_I_O__O_NoInit(spec__40, lang.RT_IntCast_J__I_NoInit(2), nil); if linked_2753 == nil { tmp90 = ifn_2754.Invoke_O__O(arg_2755) } else { tmp90 = linked_2753.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_2752, arg_2755) } } else { tmp90 = and__1927000168__auto____41 }; if jrt.J2g_Truth(tmp90) { doc__41 = lang.RT_Nth_O_I__O_NoInit(spec__40, lang.RT_IntCast_J__I_NoInit(2)) } else { doc__41 = nil }
					var root_2756 any = A_arbace_go_repl_A_const_210.GetRawRoot__O(); var linked_2757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2756, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_2758 lang.IFn; if linked_2757 == nil { ifn_2758 = lang.IFn_Cast(root_2756) } else { ifn_2758 = nil }; var arg_2759 any = ns__29; var arg_2760 any; var root_2762 any = A_arbace_go_repl_A_const_211.GetRawRoot__O(); var linked_2763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2762, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2764 lang.IFn; if linked_2763 == nil { ifn_2764 = lang.IFn_Cast(root_2762) } else { ifn_2764 = nil }; var arg_2765 any; var root_2767 any = A_arbace_go_repl_A_const_46.GetRawRoot__O(); var linked_2768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2767, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2769 lang.IFn; if linked_2768 == nil { ifn_2769 = lang.IFn_Cast(root_2767) } else { ifn_2769 = nil }; var arg_2770 any = nm__35; if linked_2768 == nil { arg_2765 = ifn_2769.Invoke_O__O(arg_2770) } else { arg_2765 = linked_2768.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2767, arg_2770) }; var arg_2766 any; var G__794000321__42_ any; var tmp91 any = A_arbace_go_repl_A_const_212; var tmp92 any = A_arbace_go_repl_A_const_137; var tmp93 any = A_arbace_go_repl_A_const_213; var tmp94 any = A_arbace_go_repl_A_const_54.Invoke_O__O(old__13); var tmp95 any = A_arbace_go_repl_A_const_111; var tmp96 any; var root_2771 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2771, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2773 lang.IFn; if linked_2772 == nil { ifn_2773 = lang.IFn_Cast(root_2771) } else { ifn_2773 = nil }; var arg_2774 any = obj__39; var arg_2775 any = A_arbace_go_repl_A_const_111; if linked_2772 == nil { tmp96 = ifn_2773.Invoke_O_O__O(arg_2774, arg_2775) } else { tmp96 = linked_2772.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2771, arg_2774, arg_2775) }; var tmp97 any = tmp96; var tmp98 any = A_arbace_go_repl_A_const_110; var tmp99 any; var root_2776 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2776, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2778 lang.IFn
					if linked_2777 == nil { ifn_2778 = lang.IFn_Cast(root_2776) } else { ifn_2778 = nil }; var arg_2779 any = obj__39; var arg_2780 any = A_arbace_go_repl_A_const_110; if linked_2777 == nil { tmp99 = ifn_2778.Invoke_O_O__O(arg_2779, arg_2780) } else { tmp99 = linked_2777.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2776, arg_2779, arg_2780) }
//line :338:1
					var tmp100 any = tmp99; var tmp101 any = A_arbace_go_repl_A_const_214; var tmp102 any; var root_2781 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_2782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2781, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2783 lang.IFn
					if linked_2782 == nil { ifn_2783 = lang.IFn_Cast(root_2781) } else { ifn_2783 = nil }; var arg_2784 any; var root_2785 any = A_arbace_go_repl_A_const_215.GetRawRoot__O(); var linked_2786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2785, aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A_fn_class); var ifn_2787 lang.IFn; if linked_2786 == nil { ifn_2787 = lang.IFn_Cast(root_2785) } else { ifn_2787 = nil }; var arg_2788 any = nm__35; if linked_2786 == nil { arg_2784 = ifn_2787.Invoke_O__O(arg_2788) } else { arg_2784 = linked_2786.(*aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A).Invoke_O_O__O(root_2785, arg_2788) }; if linked_2782 == nil { tmp102 = ifn_2783.Invoke_O__O(arg_2784) } else { tmp102 = linked_2782.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2781, arg_2784) }
//line :338:1
					G__794000321__42_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp91, tmp92, tmp93, tmp94, tmp95, tmp97, tmp98, tmp100, tmp101, tmp102)); if jrt.J2g_Truth(doc__41) {

						var root_2789 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var linked_2790 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2789, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2791 lang.IFn; if linked_2790 == nil { ifn_2791 = lang.IFn_Cast(root_2789) } else { ifn_2791 = nil }; var arg_2792 any = G__794000321__42_; var arg_2793 any = A_arbace_go_repl_A_const_85; var arg_2794 any = doc__41; if linked_2790 == nil { arg_2766 = ifn_2791.Invoke_O_O_O__O(arg_2792, arg_2793, arg_2794) } else { arg_2766 = linked_2790.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2789, arg_2792, arg_2793, arg_2794) } } else {
//line :338:1
							arg_2766 = G__794000321__42_ }; if linked_2763 == nil { arg_2760 = ifn_2764.Invoke_O_O__O(arg_2765, arg_2766) } else { arg_2760 = linked_2763.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2762, arg_2765, arg_2766) }; var arg_2761 any; var tmp103 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_179.GetRawRoot__O()); var tmp104 any; var root_2802 any = A_arbace_go_repl_A_const_187.GetRawRoot__O(); var linked_2803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2802, aot_arbace_go_build.A_arbace_go_build_desc_A_fn_class); var ifn_2804 lang.IFn


					if linked_2803 == nil { ifn_2804 = lang.IFn_Cast(root_2802) } else { ifn_2804 = nil }; var arg_2805 any; var root_2806 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2806, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2808 lang.IFn; if linked_2807 == nil { ifn_2808 = lang.IFn_Cast(root_2806) } else { ifn_2808 = nil }; var arg_2809 any = obj__39; var arg_2810 any = A_arbace_go_repl_A_const_142; if linked_2807 == nil { arg_2805 = ifn_2808.Invoke_O_O__O(arg_2809, arg_2810) } else { arg_2805 = linked_2807.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2806, arg_2809, arg_2810) }; if linked_2803 == nil { tmp104 = ifn_2804.Invoke_O__O(arg_2805) } else { tmp104 = linked_2803.(*aot_arbace_go_build.A_arbace_go_build_desc_A).Invoke_O_O__O(root_2802, arg_2805) }
//line :338:1
					arg_2761 = lang.GoFn_New_O_String(tmp103.Invoke_O_O_O_O__O(Lit_11, cell__38, tmp104, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_repl_A_const_54.Invoke_O__O(old__13), nil, nm__35)).Ref()), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_repl_A_const_54.Invoke_O__O(old__13), nil, nm__35))); if linked_2757 == nil { ifn_2758.Invoke_O_O_O__O(arg_2759, arg_2760, arg_2761) } else { linked_2757.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O_O__O(root_2756, arg_2759, arg_2760, arg_2761) }
//line :335:1
					seq_794000310__30, chunk_794000311__31, count_794000312__32, i_794000313__33 = seq_794000310__30, chunk_794000311__31, count_794000312__32, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000313__33); continue L3 } else { var temp__1927000414__auto____34 any; var root_2600 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2600, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2602 lang.IFn; if linked_2601 == nil { ifn_2602 = lang.IFn_Cast(root_2600) } else { ifn_2602 = nil }; var arg_2603 any = seq_794000310__30; if linked_2601 == nil { temp__1927000414__auto____34 = ifn_2602.Invoke_O__O(arg_2603) } else { temp__1927000414__auto____34 = linked_2601.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2600, arg_2603) }; if jrt.J2g_Truth(temp__1927000414__auto____34) { var seq_794000310__35 any = temp__1927000414__auto____34; var tmp105 any; var root_2604 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_2605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2604, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2606 lang.IFn; if linked_2605 == nil { ifn_2606 = lang.IFn_Cast(root_2604) } else { ifn_2606 = nil }; var arg_2607 any = seq_794000310__35; if linked_2605 == nil { tmp105 = ifn_2606.Invoke_O__O(arg_2607) } else { tmp105 = linked_2605.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2604, arg_2607) }; if jrt.J2g_Truth(tmp105) { var c__1927000678__auto____36 any; var root_2608 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_2609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2608, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2610 lang.IFn; if linked_2609 == nil { ifn_2610 = lang.IFn_Cast(root_2608) } else { ifn_2610 = nil }; var arg_2611 any = seq_794000310__35; if linked_2609 == nil { c__1927000678__auto____36 = ifn_2610.Invoke_O__O(arg_2611) } else { c__1927000678__auto____36 = linked_2609.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2608, arg_2611) }; var tmp106 any; var root_2811 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_2812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2811, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2813 lang.IFn; if linked_2812 == nil { ifn_2813 = lang.IFn_Cast(root_2811) } else { ifn_2813 = nil }; var arg_2814 any = seq_794000310__35; if linked_2812 == nil { tmp106 = ifn_2813.Invoke_O__O(arg_2814) } else { tmp106 = linked_2812.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2811, arg_2814) }; seq_794000310__30, chunk_794000311__31, count_794000312__32, i_794000313__33 = tmp106, c__1927000678__auto____36, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____36))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__794000322__36 any; var root_2612 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2612, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2614 lang.IFn; if linked_2613 == nil { ifn_2614 = lang.IFn_Cast(root_2612) } else { ifn_2614 = nil }; var arg_2615 any = seq_794000310__35; if linked_2613 == nil { vec__794000322__36 = ifn_2614.Invoke_O__O(arg_2615) } else { vec__794000322__36 = linked_2613.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2612, arg_2615) }; var nm__37 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000322__36, lang.RT_IntCast_J__I_NoInit(0), nil); var map__794000325__38 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000322__36, lang.RT_IntCast_J__I_NoInit(1), nil); var map__794000325__39 any; if lang.ISeq_InstanceOf(map__794000325__38) { var tmp107 any; var root_2616 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2616, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2618 lang.IFn; if linked_2617 == nil { ifn_2618 = lang.IFn_Cast(root_2616) } else { ifn_2618 = nil }; var arg_2619 any = map__794000325__38; if linked_2617 == nil { tmp107 = ifn_2618.Invoke_O__O(arg_2619) } else { tmp107 = linked_2617.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2616, arg_2619) }; if jrt.J2g_Truth(tmp107) { var tmp108 any; var root_2620 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_2621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2620, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2622 lang.IFn; if linked_2621 == nil { ifn_2622 = lang.IFn_Cast(root_2620) } else { ifn_2622 = nil }; var arg_2623 any = map__794000325__38; if linked_2621 == nil { tmp108 = ifn_2622.Invoke_O__O(arg_2623) } else { tmp108 = linked_2621.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2620, arg_2623) }; map__794000325__39 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp108, jrt.Object_class.ArrayClass())).Ref() } else { var tmp109 any; var root_2624 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2624, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2626 lang.IFn; if linked_2625 == nil { ifn_2626 = lang.IFn_Cast(root_2624) } else { ifn_2626 = nil }; var arg_2627 any = map__794000325__38; if linked_2625 == nil { tmp109 = ifn_2626.Invoke_O__O(arg_2627) } else { tmp109 = linked_2625.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2624, arg_2627) }; if jrt.J2g_Truth(tmp109) { var root_2628 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2628, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2630 lang.IFn; if linked_2629 == nil { ifn_2630 = lang.IFn_Cast(root_2628) } else { ifn_2630 = nil }; var arg_2631 any = map__794000325__38; if linked_2629 == nil { map__794000325__39 = ifn_2630.Invoke_O__O(arg_2631) } else { map__794000325__39 = linked_2629.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2628, arg_2631) } } else { map__794000325__39 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000325__39 = map__794000325__38 }; var cell__40 any = lang.RT_Get_O_O__O_NoInit(map__794000325__39, A_arbace_go_repl_A_const_155); var obj__41 any = lang.RT_Get_O_O__O_NoInit(map__794000325__39, A_arbace_go_repl_A_const_177); var spec__42 any; var root_2815 any = A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_2816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2815, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2817 lang.IFn
						if linked_2816 == nil { ifn_2817 = lang.IFn_Cast(root_2815) } else { ifn_2817 = nil }; var arg_2818 any; var tmp110 any = A_arbace_go_repl_define_BANG__fn__794000327_A_New_O(obj__41); var tmp111 *jrt.Class; var fncls__2820 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000327_A_fn_class; if fncls__2820 == nil { var fncls__2820d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_go_repl_define_BANG__fn__794000327_A_fn_class = fncls__2820d; tmp111 = fncls__2820d } else { tmp111 = fncls__2820 }; arg_2818 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp110, tmp111, nil); var arg_2819 any = decls__12; if linked_2816 == nil { spec__42 = ifn_2817.Invoke_O_O__O(arg_2818, arg_2819) } else { spec__42 = linked_2816.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2815, arg_2818, arg_2819) }
//line :335:1
						var doc__43 any; var tmp112 any; var and__1927000168__auto____43 any; var root_2821 any = A_arbace_go_repl_A_const_34.GetRawRoot__O(); var linked_2822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2821, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_2823 lang.IFn

						if linked_2822 == nil { ifn_2823 = lang.IFn_Cast(root_2821) } else { ifn_2823 = nil }; var arg_2824 any = spec__42; if linked_2822 == nil { and__1927000168__auto____43 = ifn_2823.Invoke_O__O(arg_2824) } else { and__1927000168__auto____43 = linked_2822.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_2821, arg_2824) }; if jrt.J2g_Truth(and__1927000168__auto____43) { var root_2825 any = A_arbace_go_repl_A_const_90.GetRawRoot__O(); var linked_2826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2825, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_2827 lang.IFn; if linked_2826 == nil { ifn_2827 = lang.IFn_Cast(root_2825) } else { ifn_2827 = nil }; var arg_2828 any = lang.RT_Nth_O_I_O__O_NoInit(spec__42, lang.RT_IntCast_J__I_NoInit(2), nil); if linked_2826 == nil { tmp112 = ifn_2827.Invoke_O__O(arg_2828) } else { tmp112 = linked_2826.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_2825, arg_2828) } } else { tmp112 = and__1927000168__auto____43 }; if jrt.J2g_Truth(tmp112) { doc__43 = lang.RT_Nth_O_I__O_NoInit(spec__42, lang.RT_IntCast_J__I_NoInit(2)) } else { doc__43 = nil }
						var root_2829 any = A_arbace_go_repl_A_const_210.GetRawRoot__O(); var linked_2830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2829, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_2831 lang.IFn; if linked_2830 == nil { ifn_2831 = lang.IFn_Cast(root_2829) } else { ifn_2831 = nil }; var arg_2832 any = ns__29; var arg_2833 any; var root_2835 any = A_arbace_go_repl_A_const_211.GetRawRoot__O(); var linked_2836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2835, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2837 lang.IFn; if linked_2836 == nil { ifn_2837 = lang.IFn_Cast(root_2835) } else { ifn_2837 = nil }; var arg_2838 any; var root_2840 any = A_arbace_go_repl_A_const_46.GetRawRoot__O(); var linked_2841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2840, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2842 lang.IFn; if linked_2841 == nil { ifn_2842 = lang.IFn_Cast(root_2840) } else { ifn_2842 = nil }; var arg_2843 any = nm__37; if linked_2841 == nil { arg_2838 = ifn_2842.Invoke_O__O(arg_2843) } else { arg_2838 = linked_2841.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2840, arg_2843) }; var arg_2839 any; var G__794000329__44_ any; var tmp113 any = A_arbace_go_repl_A_const_212; var tmp114 any = A_arbace_go_repl_A_const_137; var tmp115 any = A_arbace_go_repl_A_const_213; var tmp116 any = A_arbace_go_repl_A_const_54.Invoke_O__O(old__13); var tmp117 any = A_arbace_go_repl_A_const_111; var tmp118 any; var root_2844 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2844, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2846 lang.IFn; if linked_2845 == nil { ifn_2846 = lang.IFn_Cast(root_2844) } else { ifn_2846 = nil }; var arg_2847 any = obj__41; var arg_2848 any = A_arbace_go_repl_A_const_111; if linked_2845 == nil { tmp118 = ifn_2846.Invoke_O_O__O(arg_2847, arg_2848) } else { tmp118 = linked_2845.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2844, arg_2847, arg_2848) }; var tmp119 any = tmp118; var tmp120 any = A_arbace_go_repl_A_const_110; var tmp121 any; var root_2849 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2849, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2851 lang.IFn
						if linked_2850 == nil { ifn_2851 = lang.IFn_Cast(root_2849) } else { ifn_2851 = nil }; var arg_2852 any = obj__41; var arg_2853 any = A_arbace_go_repl_A_const_110; if linked_2850 == nil { tmp121 = ifn_2851.Invoke_O_O__O(arg_2852, arg_2853) } else { tmp121 = linked_2850.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2849, arg_2852, arg_2853) }
//line :338:1
						var tmp122 any = tmp121; var tmp123 any = A_arbace_go_repl_A_const_214; var tmp124 any; var root_2854 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_2855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2854, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2856 lang.IFn
						if linked_2855 == nil { ifn_2856 = lang.IFn_Cast(root_2854) } else { ifn_2856 = nil }; var arg_2857 any; var root_2858 any = A_arbace_go_repl_A_const_215.GetRawRoot__O(); var linked_2859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2858, aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A_fn_class); var ifn_2860 lang.IFn; if linked_2859 == nil { ifn_2860 = lang.IFn_Cast(root_2858) } else { ifn_2860 = nil }; var arg_2861 any = nm__37; if linked_2859 == nil { arg_2857 = ifn_2860.Invoke_O__O(arg_2861) } else { arg_2857 = linked_2859.(*aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A).Invoke_O_O__O(root_2858, arg_2861) }; if linked_2855 == nil { tmp124 = ifn_2856.Invoke_O__O(arg_2857) } else { tmp124 = linked_2855.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2854, arg_2857) }
//line :338:1
						G__794000329__44_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp113, tmp114, tmp115, tmp116, tmp117, tmp119, tmp120, tmp122, tmp123, tmp124)); if jrt.J2g_Truth(doc__43) {

							var root_2862 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var linked_2863 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2862, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2864 lang.IFn; if linked_2863 == nil { ifn_2864 = lang.IFn_Cast(root_2862) } else { ifn_2864 = nil }; var arg_2865 any = G__794000329__44_; var arg_2866 any = A_arbace_go_repl_A_const_85; var arg_2867 any = doc__43; if linked_2863 == nil { arg_2839 = ifn_2864.Invoke_O_O_O__O(arg_2865, arg_2866, arg_2867) } else { arg_2839 = linked_2863.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2862, arg_2865, arg_2866, arg_2867) } } else {
//line :338:1
								arg_2839 = G__794000329__44_ }; if linked_2836 == nil { arg_2833 = ifn_2837.Invoke_O_O__O(arg_2838, arg_2839) } else { arg_2833 = linked_2836.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2835, arg_2838, arg_2839) }; var arg_2834 any; var tmp125 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_179.GetRawRoot__O()); var tmp126 any; var root_2875 any = A_arbace_go_repl_A_const_187.GetRawRoot__O(); var linked_2876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2875, aot_arbace_go_build.A_arbace_go_build_desc_A_fn_class); var ifn_2877 lang.IFn


						if linked_2876 == nil { ifn_2877 = lang.IFn_Cast(root_2875) } else { ifn_2877 = nil }; var arg_2878 any; var root_2879 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2879, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2881 lang.IFn; if linked_2880 == nil { ifn_2881 = lang.IFn_Cast(root_2879) } else { ifn_2881 = nil }; var arg_2882 any = obj__41; var arg_2883 any = A_arbace_go_repl_A_const_142; if linked_2880 == nil { arg_2878 = ifn_2881.Invoke_O_O__O(arg_2882, arg_2883) } else { arg_2878 = linked_2880.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2879, arg_2882, arg_2883) }; if linked_2876 == nil { tmp126 = ifn_2877.Invoke_O__O(arg_2878) } else { tmp126 = linked_2876.(*aot_arbace_go_build.A_arbace_go_build_desc_A).Invoke_O_O__O(root_2875, arg_2878) }
//line :338:1
						arg_2834 = lang.GoFn_New_O_String(tmp125.Invoke_O_O_O_O__O(Lit_11, cell__40, tmp126, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_repl_A_const_54.Invoke_O__O(old__13), nil, nm__37)).Ref()), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_repl_A_const_54.Invoke_O__O(old__13), nil, nm__37))); if linked_2830 == nil { ifn_2831.Invoke_O_O_O__O(arg_2832, arg_2833, arg_2834) } else { linked_2830.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O_O__O(root_2829, arg_2832, arg_2833, arg_2834) }
//line :335:1
						var tmp127 any; var root_2884 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2884, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2886 lang.IFn; if linked_2885 == nil { ifn_2886 = lang.IFn_Cast(root_2884) } else { ifn_2886 = nil }; var arg_2887 any = seq_794000310__35; if linked_2885 == nil { tmp127 = ifn_2886.Invoke_O__O(arg_2887) } else { tmp127 = linked_2885.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2884, arg_2887) }; seq_794000310__30, chunk_794000311__31, count_794000312__32, i_794000313__33 = tmp127, nil, 0, 0; continue L3 } } }
//line :333:1
				break L3 }; var seq_794000330__30 any; var root_2632 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2632, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2634 lang.IFn









			if linked_2633 == nil { ifn_2634 = lang.IFn_Cast(root_2632) } else { ifn_2634 = nil }; var arg_2635 any = globals__24; if linked_2633 == nil { seq_794000330__30 = ifn_2634.Invoke_O__O(arg_2635) } else { seq_794000330__30 = linked_2633.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2632, arg_2635) }
//line :333:1
			var chunk_794000331__31 any; var count_794000332__32 int64 = 0; var i_794000333__33 int64 = 0; L4: for {









				if lang.Numbers_Lt_J_J__Z_NoInit(i_794000333__33, count_794000332__32) { var vec__794000334__34 any = lang.Indexed_Cast(chunk_794000331__31).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_794000333__33)); var nm__35_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000334__34, lang.RT_IntCast_J__I_NoInit(0), nil); var map__794000337__36 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000334__34, lang.RT_IntCast_J__I_NoInit(1), nil); var map__794000337__37 any; if lang.ISeq_InstanceOf(map__794000337__36) { var tmp128 any; var root_2636 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2636, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2638 lang.IFn; if linked_2637 == nil { ifn_2638 = lang.IFn_Cast(root_2636) } else { ifn_2638 = nil }; var arg_2639 any = map__794000337__36; if linked_2637 == nil { tmp128 = ifn_2638.Invoke_O__O(arg_2639) } else { tmp128 = linked_2637.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2636, arg_2639) }; if jrt.J2g_Truth(tmp128) { var tmp129 any; var root_2640 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_2641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2640, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2642 lang.IFn; if linked_2641 == nil { ifn_2642 = lang.IFn_Cast(root_2640) } else { ifn_2642 = nil }; var arg_2643 any = map__794000337__36; if linked_2641 == nil { tmp129 = ifn_2642.Invoke_O__O(arg_2643) } else { tmp129 = linked_2641.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2640, arg_2643) }; map__794000337__37 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp129, jrt.Object_class.ArrayClass())).Ref() } else { var tmp130 any; var root_2644 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2644, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2646 lang.IFn; if linked_2645 == nil { ifn_2646 = lang.IFn_Cast(root_2644) } else { ifn_2646 = nil }; var arg_2647 any = map__794000337__36; if linked_2645 == nil { tmp130 = ifn_2646.Invoke_O__O(arg_2647) } else { tmp130 = linked_2645.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2644, arg_2647) }; if jrt.J2g_Truth(tmp130) { var root_2648 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2648, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2650 lang.IFn; if linked_2649 == nil { ifn_2650 = lang.IFn_Cast(root_2648) } else { ifn_2650 = nil }; var arg_2651 any = map__794000337__36; if linked_2649 == nil { map__794000337__37 = ifn_2650.Invoke_O__O(arg_2651) } else { map__794000337__37 = linked_2649.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2648, arg_2651) } } else { map__794000337__37 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000337__37 = map__794000337__36 }; var ptr__38 any = lang.RT_Get_O_O__O_NoInit(map__794000337__37, A_arbace_go_repl_A_const_186); var obj__39_2 any = lang.RT_Get_O_O__O_NoInit(map__794000337__37, A_arbace_go_repl_A_const_177); var root_2888 any = A_arbace_go_repl_A_const_210.GetRawRoot__O(); var linked_2889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2888, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_2890 lang.IFn
					if linked_2889 == nil { ifn_2890 = lang.IFn_Cast(root_2888) } else { ifn_2890 = nil }; var arg_2891 any = ns__29; var arg_2892 any; var root_2894 any = A_arbace_go_repl_A_const_211.GetRawRoot__O(); var linked_2895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2894, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2896 lang.IFn; if linked_2895 == nil { ifn_2896 = lang.IFn_Cast(root_2894) } else { ifn_2896 = nil }; var arg_2897 any; var root_2899 any = A_arbace_go_repl_A_const_46.GetRawRoot__O(); var linked_2900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2899, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2901 lang.IFn; if linked_2900 == nil { ifn_2901 = lang.IFn_Cast(root_2899) } else { ifn_2901 = nil }; var arg_2902 any = nm__35_2; if linked_2900 == nil { arg_2897 = ifn_2901.Invoke_O__O(arg_2902) } else { arg_2897 = linked_2900.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2899, arg_2902) }; var arg_2898 any; var tmp131 any = A_arbace_go_repl_A_const_212; var tmp132 any = A_arbace_go_repl_A_const_183; var tmp133 any = A_arbace_go_repl_A_const_213; var tmp134 any = A_arbace_go_repl_A_const_54.Invoke_O__O(old__13); var tmp135 any = A_arbace_go_repl_A_const_214; var tmp136 any; var root_2903 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_2904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2903, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2905 lang.IFn; if linked_2904 == nil { ifn_2905 = lang.IFn_Cast(root_2903) } else { ifn_2905 = nil }; var arg_2906 any; var root_2907 any = A_arbace_go_repl_A_const_215.GetRawRoot__O(); var linked_2908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2907, aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A_fn_class); var ifn_2909 lang.IFn; if linked_2908 == nil { ifn_2909 = lang.IFn_Cast(root_2907) } else { ifn_2909 = nil }; var arg_2910 any = nm__35_2; if linked_2908 == nil { arg_2906 = ifn_2909.Invoke_O__O(arg_2910) } else { arg_2906 = linked_2908.(*aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A).Invoke_O_O__O(root_2907, arg_2910) }; if linked_2904 == nil { tmp136 = ifn_2905.Invoke_O__O(arg_2906) } else { tmp136 = linked_2904.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2903, arg_2906) }; arg_2898 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp131, tmp132, tmp133, tmp134, tmp135, tmp136)); if linked_2895 == nil { arg_2892 = ifn_2896.Invoke_O_O__O(arg_2897, arg_2898) } else { arg_2892 = linked_2895.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2894, arg_2897, arg_2898) }; var arg_2893 any; var tmp137 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_179.GetRawRoot__O()); var tmp138 any; var root_2917 any = A_arbace_go_repl_A_const_187.GetRawRoot__O(); var linked_2918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2917, aot_arbace_go_build.A_arbace_go_build_desc_A_fn_class); var ifn_2919 lang.IFn
					if linked_2918 == nil { ifn_2919 = lang.IFn_Cast(root_2917) } else { ifn_2919 = nil }; var arg_2920 any; var root_2921 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2921, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2923 lang.IFn; if linked_2922 == nil { ifn_2923 = lang.IFn_Cast(root_2921) } else { ifn_2923 = nil }; var arg_2924 any = obj__39_2; var arg_2925 any = A_arbace_go_repl_A_const_142; if linked_2922 == nil { arg_2920 = ifn_2923.Invoke_O_O__O(arg_2924, arg_2925) } else { arg_2920 = linked_2922.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2921, arg_2924, arg_2925) }; if linked_2918 == nil { tmp138 = ifn_2919.Invoke_O__O(arg_2920) } else { tmp138 = linked_2918.(*aot_arbace_go_build.A_arbace_go_build_desc_A).Invoke_O_O__O(root_2917, arg_2920) }
//line :344:1
					arg_2893 = lang.GoVar_New_O_String(tmp137.Invoke_O_O_O__O(Lit_87, tmp138, ptr__38), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_repl_A_const_54.Invoke_O__O(old__13), nil, nm__35_2))); if linked_2889 == nil { ifn_2890.Invoke_O_O_O__O(arg_2891, arg_2892, arg_2893) } else { linked_2889.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O_O__O(root_2888, arg_2891, arg_2892, arg_2893) }
//line :343:1
					seq_794000330__30, chunk_794000331__31, count_794000332__32, i_794000333__33 = seq_794000330__30, chunk_794000331__31, count_794000332__32, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000333__33); continue L4 } else { var temp__1927000414__auto____34_2 any; var root_2652 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2652, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2654 lang.IFn; if linked_2653 == nil { ifn_2654 = lang.IFn_Cast(root_2652) } else { ifn_2654 = nil }; var arg_2655 any = seq_794000330__30; if linked_2653 == nil { temp__1927000414__auto____34_2 = ifn_2654.Invoke_O__O(arg_2655) } else { temp__1927000414__auto____34_2 = linked_2653.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2652, arg_2655) }; if jrt.J2g_Truth(temp__1927000414__auto____34_2) { var seq_794000330__35 any = temp__1927000414__auto____34_2; var tmp139 any; var root_2656 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_2657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2656, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2658 lang.IFn; if linked_2657 == nil { ifn_2658 = lang.IFn_Cast(root_2656) } else { ifn_2658 = nil }; var arg_2659 any = seq_794000330__35; if linked_2657 == nil { tmp139 = ifn_2658.Invoke_O__O(arg_2659) } else { tmp139 = linked_2657.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2656, arg_2659) }; if jrt.J2g_Truth(tmp139) { var c__1927000678__auto____36_2 any; var root_2660 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_2661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2660, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2662 lang.IFn; if linked_2661 == nil { ifn_2662 = lang.IFn_Cast(root_2660) } else { ifn_2662 = nil }; var arg_2663 any = seq_794000330__35; if linked_2661 == nil { c__1927000678__auto____36_2 = ifn_2662.Invoke_O__O(arg_2663) } else { c__1927000678__auto____36_2 = linked_2661.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2660, arg_2663) }; var tmp140 any; var root_2926 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_2927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2926, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2928 lang.IFn; if linked_2927 == nil { ifn_2928 = lang.IFn_Cast(root_2926) } else { ifn_2928 = nil }; var arg_2929 any = seq_794000330__35; if linked_2927 == nil { tmp140 = ifn_2928.Invoke_O__O(arg_2929) } else { tmp140 = linked_2927.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2926, arg_2929) }; seq_794000330__30, chunk_794000331__31, count_794000332__32, i_794000333__33 = tmp140, c__1927000678__auto____36_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____36_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var vec__794000339__36 any; var root_2664 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2664, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2666 lang.IFn; if linked_2665 == nil { ifn_2666 = lang.IFn_Cast(root_2664) } else { ifn_2666 = nil }; var arg_2667 any = seq_794000330__35; if linked_2665 == nil { vec__794000339__36 = ifn_2666.Invoke_O__O(arg_2667) } else { vec__794000339__36 = linked_2665.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2664, arg_2667) }; var nm__37_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000339__36, lang.RT_IntCast_J__I_NoInit(0), nil); var map__794000342__38 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000339__36, lang.RT_IntCast_J__I_NoInit(1), nil); var map__794000342__39 any; if lang.ISeq_InstanceOf(map__794000342__38) { var tmp141 any; var root_2668 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2668, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2670 lang.IFn; if linked_2669 == nil { ifn_2670 = lang.IFn_Cast(root_2668) } else { ifn_2670 = nil }; var arg_2671 any = map__794000342__38; if linked_2669 == nil { tmp141 = ifn_2670.Invoke_O__O(arg_2671) } else { tmp141 = linked_2669.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2668, arg_2671) }; if jrt.J2g_Truth(tmp141) { var tmp142 any; var root_2672 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_2673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2672, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2674 lang.IFn; if linked_2673 == nil { ifn_2674 = lang.IFn_Cast(root_2672) } else { ifn_2674 = nil }; var arg_2675 any = map__794000342__38; if linked_2673 == nil { tmp142 = ifn_2674.Invoke_O__O(arg_2675) } else { tmp142 = linked_2673.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2672, arg_2675) }; map__794000342__39 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp142, jrt.Object_class.ArrayClass())).Ref() } else { var tmp143 any; var root_2676 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2676, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2678 lang.IFn; if linked_2677 == nil { ifn_2678 = lang.IFn_Cast(root_2676) } else { ifn_2678 = nil }; var arg_2679 any = map__794000342__38; if linked_2677 == nil { tmp143 = ifn_2678.Invoke_O__O(arg_2679) } else { tmp143 = linked_2677.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2676, arg_2679) }; if jrt.J2g_Truth(tmp143) { var root_2680 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2680, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2682 lang.IFn; if linked_2681 == nil { ifn_2682 = lang.IFn_Cast(root_2680) } else { ifn_2682 = nil }; var arg_2683 any = map__794000342__38; if linked_2681 == nil { map__794000342__39 = ifn_2682.Invoke_O__O(arg_2683) } else { map__794000342__39 = linked_2681.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2680, arg_2683) } } else { map__794000342__39 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000342__39 = map__794000342__38 }; var ptr__40 any = lang.RT_Get_O_O__O_NoInit(map__794000342__39, A_arbace_go_repl_A_const_186); var obj__41_2 any = lang.RT_Get_O_O__O_NoInit(map__794000342__39, A_arbace_go_repl_A_const_177); var root_2930 any = A_arbace_go_repl_A_const_210.GetRawRoot__O(); var linked_2931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2930, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_2932 lang.IFn
						if linked_2931 == nil { ifn_2932 = lang.IFn_Cast(root_2930) } else { ifn_2932 = nil }; var arg_2933 any = ns__29; var arg_2934 any; var root_2936 any = A_arbace_go_repl_A_const_211.GetRawRoot__O(); var linked_2937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2936, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2938 lang.IFn; if linked_2937 == nil { ifn_2938 = lang.IFn_Cast(root_2936) } else { ifn_2938 = nil }; var arg_2939 any; var root_2941 any = A_arbace_go_repl_A_const_46.GetRawRoot__O(); var linked_2942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2941, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2943 lang.IFn; if linked_2942 == nil { ifn_2943 = lang.IFn_Cast(root_2941) } else { ifn_2943 = nil }; var arg_2944 any = nm__37_2; if linked_2942 == nil { arg_2939 = ifn_2943.Invoke_O__O(arg_2944) } else { arg_2939 = linked_2942.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2941, arg_2944) }; var arg_2940 any; var tmp144 any = A_arbace_go_repl_A_const_212; var tmp145 any = A_arbace_go_repl_A_const_183; var tmp146 any = A_arbace_go_repl_A_const_213; var tmp147 any = A_arbace_go_repl_A_const_54.Invoke_O__O(old__13); var tmp148 any = A_arbace_go_repl_A_const_214; var tmp149 any; var root_2945 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_2946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2945, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2947 lang.IFn; if linked_2946 == nil { ifn_2947 = lang.IFn_Cast(root_2945) } else { ifn_2947 = nil }; var arg_2948 any; var root_2949 any = A_arbace_go_repl_A_const_215.GetRawRoot__O(); var linked_2950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2949, aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A_fn_class); var ifn_2951 lang.IFn; if linked_2950 == nil { ifn_2951 = lang.IFn_Cast(root_2949) } else { ifn_2951 = nil }; var arg_2952 any = nm__37_2; if linked_2950 == nil { arg_2948 = ifn_2951.Invoke_O__O(arg_2952) } else { arg_2948 = linked_2950.(*aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A).Invoke_O_O__O(root_2949, arg_2952) }; if linked_2946 == nil { tmp149 = ifn_2947.Invoke_O__O(arg_2948) } else { tmp149 = linked_2946.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2945, arg_2948) }; arg_2940 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp144, tmp145, tmp146, tmp147, tmp148, tmp149)); if linked_2937 == nil { arg_2934 = ifn_2938.Invoke_O_O__O(arg_2939, arg_2940) } else { arg_2934 = linked_2937.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2936, arg_2939, arg_2940) }; var arg_2935 any; var tmp150 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_179.GetRawRoot__O()); var tmp151 any; var root_2959 any = A_arbace_go_repl_A_const_187.GetRawRoot__O(); var linked_2960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2959, aot_arbace_go_build.A_arbace_go_build_desc_A_fn_class); var ifn_2961 lang.IFn
						if linked_2960 == nil { ifn_2961 = lang.IFn_Cast(root_2959) } else { ifn_2961 = nil }; var arg_2962 any; var root_2963 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2963, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2965 lang.IFn; if linked_2964 == nil { ifn_2965 = lang.IFn_Cast(root_2963) } else { ifn_2965 = nil }; var arg_2966 any = obj__41_2; var arg_2967 any = A_arbace_go_repl_A_const_142; if linked_2964 == nil { arg_2962 = ifn_2965.Invoke_O_O__O(arg_2966, arg_2967) } else { arg_2962 = linked_2964.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2963, arg_2966, arg_2967) }; if linked_2960 == nil { tmp151 = ifn_2961.Invoke_O__O(arg_2962) } else { tmp151 = linked_2960.(*aot_arbace_go_build.A_arbace_go_build_desc_A).Invoke_O_O__O(root_2959, arg_2962) }
//line :344:1
						arg_2935 = lang.GoVar_New_O_String(tmp150.Invoke_O_O_O__O(Lit_87, tmp151, ptr__40), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_repl_A_const_54.Invoke_O__O(old__13), nil, nm__37_2))); if linked_2931 == nil { ifn_2932.Invoke_O_O_O__O(arg_2933, arg_2934, arg_2935) } else { linked_2931.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O_O__O(root_2930, arg_2933, arg_2934, arg_2935) }
//line :343:1
						var tmp152 any; var root_2968 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2968, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2970 lang.IFn; if linked_2969 == nil { ifn_2970 = lang.IFn_Cast(root_2968) } else { ifn_2970 = nil }; var arg_2971 any = seq_794000330__35; if linked_2969 == nil { tmp152 = ifn_2970.Invoke_O__O(arg_2971) } else { tmp152 = linked_2969.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2968, arg_2971) }; seq_794000330__30, chunk_794000331__31, count_794000332__32, i_794000333__33 = tmp152, nil, 0, 0; continue L4 } } }
//line :333:1
				break L4 }; var seq_794000344__30 any; var root_2684 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2684, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2686 lang.IFn












			if linked_2685 == nil { ifn_2686 = lang.IFn_Cast(root_2684) } else { ifn_2686 = nil }; var arg_2687 any = decls__12; if linked_2685 == nil { seq_794000344__30 = ifn_2686.Invoke_O__O(arg_2687) } else { seq_794000344__30 = linked_2685.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2684, arg_2687) }
//line :333:1
			var chunk_794000345__31 any; var count_794000346__32 int64 = 0; var i_794000347__33 int64 = 0; L5: for {












				if lang.Numbers_Lt_J_J__Z_NoInit(i_794000347__33, count_794000346__32) { var d__34 any = lang.Indexed_Cast(chunk_794000345__31).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_794000347__33)); var tmp153 any = A_arbace_go_repl_A_const_207; if lang.Util_Equiv_O_O__Z_NoInit(tmp153, A_arbace_go_repl_A_const_174.Invoke_O__O(d__34)) { var x__35 any = A_arbace_go_repl_A_const_177.Invoke_O__O(d__34); var tmp154 any; var root_2688 any = A_arbace_go_repl_A_const_176.GetRawRoot__O(); var linked_2689 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2688, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2690 lang.IFn
					if linked_2689 == nil { ifn_2690 = lang.IFn_Cast(root_2688) } else { ifn_2690 = nil }; var arg_2691 any = Lit_4; var arg_2692 any; var root_2693 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2693, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2695 lang.IFn; if linked_2694 == nil { ifn_2695 = lang.IFn_Cast(root_2693) } else { ifn_2695 = nil }; var arg_2696 any = x__35; var arg_2697 any = A_arbace_go_repl_A_const_55; if linked_2694 == nil { arg_2692 = ifn_2695.Invoke_O_O__O(arg_2696, arg_2697) } else { arg_2692 = linked_2694.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2693, arg_2696, arg_2697) }; if linked_2689 == nil { tmp154 = ifn_2690.Invoke_O_O__O(arg_2691, arg_2692) } else { tmp154 = linked_2689.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2688, arg_2691, arg_2692) }
//line :346:1
					if jrt.J2g_Truth(tmp154) { var tmp155 any; var root_2698 any = A_arbace_go_repl_A_const_208.GetRawRoot__O(); var linked_2699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2698, aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A_fn_class); var ifn_2700 lang.IFn

						if linked_2699 == nil { ifn_2700 = lang.IFn_Cast(root_2698) } else { ifn_2700 = nil }; var arg_2701 any; var root_2702 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2702, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2704 lang.IFn; if linked_2703 == nil { ifn_2704 = lang.IFn_Cast(root_2702) } else { ifn_2704 = nil }; var arg_2705 any = x__35; var arg_2706 any = A_arbace_go_repl_A_const_142; if linked_2703 == nil { arg_2701 = ifn_2704.Invoke_O_O__O(arg_2705, arg_2706) } else { arg_2701 = linked_2703.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2702, arg_2705, arg_2706) }; if linked_2699 == nil { tmp155 = ifn_2700.Invoke_O__O(arg_2701) } else { tmp155 = linked_2699.(*aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A).Invoke_O_O__O(root_2698, arg_2701) }
//line :346:1
						if jrt.J2g_Truth(tmp155) {


							var root_2972 any = A_arbace_go_repl_A_const_210.GetRawRoot__O(); var linked_2973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2972, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_2974 lang.IFn; if linked_2973 == nil { ifn_2974 = lang.IFn_Cast(root_2972) } else { ifn_2974 = nil }; var arg_2975 any = ns__29; var arg_2976 any; var root_2978 any = A_arbace_go_repl_A_const_211.GetRawRoot__O(); var linked_2979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2978, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2980 lang.IFn; if linked_2979 == nil { ifn_2980 = lang.IFn_Cast(root_2978) } else { ifn_2980 = nil }; var arg_2981 any; var root_2983 any = A_arbace_go_repl_A_const_46.GetRawRoot__O(); var linked_2984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2983, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2985 lang.IFn; if linked_2984 == nil { ifn_2985 = lang.IFn_Cast(root_2983) } else { ifn_2985 = nil }; var arg_2986 any; var root_2987 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2987, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2989 lang.IFn; if linked_2988 == nil { ifn_2989 = lang.IFn_Cast(root_2987) } else { ifn_2989 = nil }; var arg_2990 any = x__35; var arg_2991 any = A_arbace_go_repl_A_const_55; if linked_2988 == nil { arg_2986 = ifn_2989.Invoke_O_O__O(arg_2990, arg_2991) } else { arg_2986 = linked_2988.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2987, arg_2990, arg_2991) }; if linked_2984 == nil { arg_2981 = ifn_2985.Invoke_O__O(arg_2986) } else { arg_2981 = linked_2984.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2983, arg_2986) }; var arg_2982 any; var tmp156 any = A_arbace_go_repl_A_const_212; var tmp157 any = A_arbace_go_repl_A_const_207; var tmp158 any = A_arbace_go_repl_A_const_213; var tmp159 any = A_arbace_go_repl_A_const_54.Invoke_O__O(old__13); var tmp160 any = A_arbace_go_repl_A_const_214; var tmp161 any; var root_2992 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_2993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2992, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2994 lang.IFn
							if linked_2993 == nil { ifn_2994 = lang.IFn_Cast(root_2992) } else { ifn_2994 = nil }; var arg_2995 any; var root_2996 any = A_arbace_go_repl_A_const_215.GetRawRoot__O(); var linked_2997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2996, aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A_fn_class); var ifn_2998 lang.IFn; if linked_2997 == nil { ifn_2998 = lang.IFn_Cast(root_2996) } else { ifn_2998 = nil }; var arg_2999 any; var root_3000 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3000, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3002 lang.IFn; if linked_3001 == nil { ifn_3002 = lang.IFn_Cast(root_3000) } else { ifn_3002 = nil }; var arg_3003 any = x__35; var arg_3004 any = A_arbace_go_repl_A_const_55; if linked_3001 == nil { arg_2999 = ifn_3002.Invoke_O_O__O(arg_3003, arg_3004) } else { arg_2999 = linked_3001.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3000, arg_3003, arg_3004) }; if linked_2997 == nil { arg_2995 = ifn_2998.Invoke_O__O(arg_2999) } else { arg_2995 = linked_2997.(*aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A).Invoke_O_O__O(root_2996, arg_2999) }; if linked_2993 == nil { tmp161 = ifn_2994.Invoke_O__O(arg_2995) } else { tmp161 = linked_2993.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2992, arg_2995) }
//line :349:1
							arg_2982 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp156, tmp157, tmp158, tmp159, tmp160, tmp161)); if linked_2979 == nil { arg_2976 = ifn_2980.Invoke_O_O__O(arg_2981, arg_2982) } else { arg_2976 = linked_2979.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2978, arg_2981, arg_2982) }; var arg_2977 any; var root_3005 any = A_arbace_go_repl_A_const_216.GetRawRoot__O(); var linked_3006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3005, A_arbace_go_repl_const_arbace_A_fn_class); var ifn_3007 lang.IFn

							if linked_3006 == nil { ifn_3007 = lang.IFn_Cast(root_3005) } else { ifn_3007 = nil }; var arg_3008 any; var root_3010 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3010, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3012 lang.IFn; if linked_3011 == nil { ifn_3012 = lang.IFn_Cast(root_3010) } else { ifn_3012 = nil }; var arg_3013 any = x__35; var arg_3014 any = A_arbace_go_repl_A_const_142; if linked_3011 == nil { arg_3008 = ifn_3012.Invoke_O_O__O(arg_3013, arg_3014) } else { arg_3008 = linked_3011.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3010, arg_3013, arg_3014) }; var arg_3009 any; var root_3015 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3015, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3017 lang.IFn; if linked_3016 == nil { ifn_3017 = lang.IFn_Cast(root_3015) } else { ifn_3017 = nil }; var arg_3018 any = x__35; var arg_3019 any = A_arbace_go_repl_A_const_217; if linked_3016 == nil { arg_3009 = ifn_3017.Invoke_O_O__O(arg_3018, arg_3019) } else { arg_3009 = linked_3016.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3015, arg_3018, arg_3019) }; if linked_3006 == nil { arg_2977 = ifn_3007.Invoke_O_O__O(arg_3008, arg_3009) } else { arg_2977 = linked_3006.(*A_arbace_go_repl_const_arbace_A).Invoke_O_O_O__O(root_3005, arg_3008, arg_3009) }
//line :349:1
							if linked_2973 == nil { ifn_2974.Invoke_O_O_O__O(arg_2975, arg_2976, arg_2977) } else { linked_2973.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O_O__O(root_2972, arg_2975, arg_2976, arg_2977) }
//line :346:1
							seq_794000344__30, chunk_794000345__31, count_794000346__32, i_794000347__33 = seq_794000344__30, chunk_794000345__31, count_794000346__32, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000347__33); continue L5 } else { seq_794000344__30, chunk_794000345__31, count_794000346__32, i_794000347__33 = seq_794000344__30, chunk_794000345__31, count_794000346__32, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000347__33); continue L5 } } else { seq_794000344__30, chunk_794000345__31, count_794000346__32, i_794000347__33 = seq_794000344__30, chunk_794000345__31, count_794000346__32, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000347__33); continue L5 } } else { seq_794000344__30, chunk_794000345__31, count_794000346__32, i_794000347__33 = seq_794000344__30, chunk_794000345__31, count_794000346__32, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000347__33); continue L5 } } else { var temp__1927000414__auto____34_3 any; var root_2707 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2707, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2709 lang.IFn; if linked_2708 == nil { ifn_2709 = lang.IFn_Cast(root_2707) } else { ifn_2709 = nil }; var arg_2710 any = seq_794000344__30; if linked_2708 == nil { temp__1927000414__auto____34_3 = ifn_2709.Invoke_O__O(arg_2710) } else { temp__1927000414__auto____34_3 = linked_2708.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2707, arg_2710) }; if jrt.J2g_Truth(temp__1927000414__auto____34_3) { var seq_794000344__35 any = temp__1927000414__auto____34_3; var tmp162 any; var root_2711 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_2712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2711, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2713 lang.IFn; if linked_2712 == nil { ifn_2713 = lang.IFn_Cast(root_2711) } else { ifn_2713 = nil }; var arg_2714 any = seq_794000344__35; if linked_2712 == nil { tmp162 = ifn_2713.Invoke_O__O(arg_2714) } else { tmp162 = linked_2712.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2711, arg_2714) }; if jrt.J2g_Truth(tmp162) { var c__1927000678__auto____36_3 any; var root_2715 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_2716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2715, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2717 lang.IFn; if linked_2716 == nil { ifn_2717 = lang.IFn_Cast(root_2715) } else { ifn_2717 = nil }; var arg_2718 any = seq_794000344__35; if linked_2716 == nil { c__1927000678__auto____36_3 = ifn_2717.Invoke_O__O(arg_2718) } else { c__1927000678__auto____36_3 = linked_2716.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2715, arg_2718) }; var tmp163 any; var root_3020 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_3021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3020, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3022 lang.IFn; if linked_3021 == nil { ifn_3022 = lang.IFn_Cast(root_3020) } else { ifn_3022 = nil }; var arg_3023 any = seq_794000344__35; if linked_3021 == nil { tmp163 = ifn_3022.Invoke_O__O(arg_3023) } else { tmp163 = linked_3021.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3020, arg_3023) }; seq_794000344__30, chunk_794000345__31, count_794000346__32, i_794000347__33 = tmp163, c__1927000678__auto____36_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____36_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var d__36 any; var root_2719 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2719, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2721 lang.IFn; if linked_2720 == nil { ifn_2721 = lang.IFn_Cast(root_2719) } else { ifn_2721 = nil }; var arg_2722 any = seq_794000344__35; if linked_2720 == nil { d__36 = ifn_2721.Invoke_O__O(arg_2722) } else { d__36 = linked_2720.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2719, arg_2722) }; var tmp164 any = A_arbace_go_repl_A_const_207; if lang.Util_Equiv_O_O__Z_NoInit(tmp164, A_arbace_go_repl_A_const_174.Invoke_O__O(d__36)) { var x__37 any = A_arbace_go_repl_A_const_177.Invoke_O__O(d__36); var tmp165 any; var root_2723 any = A_arbace_go_repl_A_const_176.GetRawRoot__O(); var linked_2724 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2723, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2725 lang.IFn
								if linked_2724 == nil { ifn_2725 = lang.IFn_Cast(root_2723) } else { ifn_2725 = nil }; var arg_2726 any = Lit_4; var arg_2727 any; var root_2728 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2728, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2730 lang.IFn; if linked_2729 == nil { ifn_2730 = lang.IFn_Cast(root_2728) } else { ifn_2730 = nil }; var arg_2731 any = x__37; var arg_2732 any = A_arbace_go_repl_A_const_55; if linked_2729 == nil { arg_2727 = ifn_2730.Invoke_O_O__O(arg_2731, arg_2732) } else { arg_2727 = linked_2729.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2728, arg_2731, arg_2732) }; if linked_2724 == nil { tmp165 = ifn_2725.Invoke_O_O__O(arg_2726, arg_2727) } else { tmp165 = linked_2724.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2723, arg_2726, arg_2727) }
//line :346:1
								if jrt.J2g_Truth(tmp165) { var tmp166 any; var root_2733 any = A_arbace_go_repl_A_const_208.GetRawRoot__O(); var linked_2734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2733, aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A_fn_class); var ifn_2735 lang.IFn

									if linked_2734 == nil { ifn_2735 = lang.IFn_Cast(root_2733) } else { ifn_2735 = nil }; var arg_2736 any; var root_2737 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2737, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2739 lang.IFn; if linked_2738 == nil { ifn_2739 = lang.IFn_Cast(root_2737) } else { ifn_2739 = nil }; var arg_2740 any = x__37; var arg_2741 any = A_arbace_go_repl_A_const_142; if linked_2738 == nil { arg_2736 = ifn_2739.Invoke_O_O__O(arg_2740, arg_2741) } else { arg_2736 = linked_2738.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2737, arg_2740, arg_2741) }; if linked_2734 == nil { tmp166 = ifn_2735.Invoke_O__O(arg_2736) } else { tmp166 = linked_2734.(*aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A).Invoke_O_O__O(root_2733, arg_2736) }
//line :346:1
									if jrt.J2g_Truth(tmp166) {


										var root_3024 any = A_arbace_go_repl_A_const_210.GetRawRoot__O(); var linked_3025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3024, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_3026 lang.IFn; if linked_3025 == nil { ifn_3026 = lang.IFn_Cast(root_3024) } else { ifn_3026 = nil }; var arg_3027 any = ns__29; var arg_3028 any; var root_3030 any = A_arbace_go_repl_A_const_211.GetRawRoot__O(); var linked_3031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3030, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3032 lang.IFn; if linked_3031 == nil { ifn_3032 = lang.IFn_Cast(root_3030) } else { ifn_3032 = nil }; var arg_3033 any; var root_3035 any = A_arbace_go_repl_A_const_46.GetRawRoot__O(); var linked_3036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3035, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3037 lang.IFn; if linked_3036 == nil { ifn_3037 = lang.IFn_Cast(root_3035) } else { ifn_3037 = nil }; var arg_3038 any; var root_3039 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3039, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3041 lang.IFn; if linked_3040 == nil { ifn_3041 = lang.IFn_Cast(root_3039) } else { ifn_3041 = nil }; var arg_3042 any = x__37; var arg_3043 any = A_arbace_go_repl_A_const_55; if linked_3040 == nil { arg_3038 = ifn_3041.Invoke_O_O__O(arg_3042, arg_3043) } else { arg_3038 = linked_3040.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3039, arg_3042, arg_3043) }; if linked_3036 == nil { arg_3033 = ifn_3037.Invoke_O__O(arg_3038) } else { arg_3033 = linked_3036.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3035, arg_3038) }; var arg_3034 any; var tmp167 any = A_arbace_go_repl_A_const_212; var tmp168 any = A_arbace_go_repl_A_const_207; var tmp169 any = A_arbace_go_repl_A_const_213; var tmp170 any = A_arbace_go_repl_A_const_54.Invoke_O__O(old__13); var tmp171 any = A_arbace_go_repl_A_const_214; var tmp172 any; var root_3044 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_3045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3044, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3046 lang.IFn
										if linked_3045 == nil { ifn_3046 = lang.IFn_Cast(root_3044) } else { ifn_3046 = nil }; var arg_3047 any; var root_3048 any = A_arbace_go_repl_A_const_215.GetRawRoot__O(); var linked_3049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3048, aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A_fn_class); var ifn_3050 lang.IFn; if linked_3049 == nil { ifn_3050 = lang.IFn_Cast(root_3048) } else { ifn_3050 = nil }; var arg_3051 any; var root_3052 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3052, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3054 lang.IFn; if linked_3053 == nil { ifn_3054 = lang.IFn_Cast(root_3052) } else { ifn_3054 = nil }; var arg_3055 any = x__37; var arg_3056 any = A_arbace_go_repl_A_const_55; if linked_3053 == nil { arg_3051 = ifn_3054.Invoke_O_O__O(arg_3055, arg_3056) } else { arg_3051 = linked_3053.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3052, arg_3055, arg_3056) }; if linked_3049 == nil { arg_3047 = ifn_3050.Invoke_O__O(arg_3051) } else { arg_3047 = linked_3049.(*aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A).Invoke_O_O__O(root_3048, arg_3051) }; if linked_3045 == nil { tmp172 = ifn_3046.Invoke_O__O(arg_3047) } else { tmp172 = linked_3045.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3044, arg_3047) }
//line :349:1
										arg_3034 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp167, tmp168, tmp169, tmp170, tmp171, tmp172)); if linked_3031 == nil { arg_3028 = ifn_3032.Invoke_O_O__O(arg_3033, arg_3034) } else { arg_3028 = linked_3031.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3030, arg_3033, arg_3034) }; var arg_3029 any; var root_3057 any = A_arbace_go_repl_A_const_216.GetRawRoot__O(); var linked_3058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3057, A_arbace_go_repl_const_arbace_A_fn_class); var ifn_3059 lang.IFn

										if linked_3058 == nil { ifn_3059 = lang.IFn_Cast(root_3057) } else { ifn_3059 = nil }; var arg_3060 any; var root_3062 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3062, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3064 lang.IFn; if linked_3063 == nil { ifn_3064 = lang.IFn_Cast(root_3062) } else { ifn_3064 = nil }; var arg_3065 any = x__37; var arg_3066 any = A_arbace_go_repl_A_const_142; if linked_3063 == nil { arg_3060 = ifn_3064.Invoke_O_O__O(arg_3065, arg_3066) } else { arg_3060 = linked_3063.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3062, arg_3065, arg_3066) }; var arg_3061 any; var root_3067 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3067, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3069 lang.IFn; if linked_3068 == nil { ifn_3069 = lang.IFn_Cast(root_3067) } else { ifn_3069 = nil }; var arg_3070 any = x__37; var arg_3071 any = A_arbace_go_repl_A_const_217; if linked_3068 == nil { arg_3061 = ifn_3069.Invoke_O_O__O(arg_3070, arg_3071) } else { arg_3061 = linked_3068.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3067, arg_3070, arg_3071) }; if linked_3058 == nil { arg_3029 = ifn_3059.Invoke_O_O__O(arg_3060, arg_3061) } else { arg_3029 = linked_3058.(*A_arbace_go_repl_const_arbace_A).Invoke_O_O_O__O(root_3057, arg_3060, arg_3061) }
//line :349:1
										if linked_3025 == nil { ifn_3026.Invoke_O_O_O__O(arg_3027, arg_3028, arg_3029) } else { linked_3025.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O_O__O(root_3024, arg_3027, arg_3028, arg_3029) }
//line :346:1
										var tmp173 any; var root_3072 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_3073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3072, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3074 lang.IFn; if linked_3073 == nil { ifn_3074 = lang.IFn_Cast(root_3072) } else { ifn_3074 = nil }; var arg_3075 any = seq_794000344__35; if linked_3073 == nil { tmp173 = ifn_3074.Invoke_O__O(arg_3075) } else { tmp173 = linked_3073.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3072, arg_3075) }; seq_794000344__30, chunk_794000345__31, count_794000346__32, i_794000347__33 = tmp173, nil, 0, 0; continue L5 } else { var tmp174 any; var root_3076 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_3077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3076, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3078 lang.IFn; if linked_3077 == nil { ifn_3078 = lang.IFn_Cast(root_3076) } else { ifn_3078 = nil }; var arg_3079 any = seq_794000344__35; if linked_3077 == nil { tmp174 = ifn_3078.Invoke_O__O(arg_3079) } else { tmp174 = linked_3077.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3076, arg_3079) }; seq_794000344__30, chunk_794000345__31, count_794000346__32, i_794000347__33 = tmp174, nil, 0, 0; continue L5 } } else { var tmp175 any; var root_3080 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_3081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3080, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3082 lang.IFn; if linked_3081 == nil { ifn_3082 = lang.IFn_Cast(root_3080) } else { ifn_3082 = nil }; var arg_3083 any = seq_794000344__35; if linked_3081 == nil { tmp175 = ifn_3082.Invoke_O__O(arg_3083) } else { tmp175 = linked_3081.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3080, arg_3083) }; seq_794000344__30, chunk_794000345__31, count_794000346__32, i_794000347__33 = tmp175, nil, 0, 0; continue L5 } } else { var tmp176 any; var root_3084 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_3085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3084, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3086 lang.IFn; if linked_3085 == nil { ifn_3086 = lang.IFn_Cast(root_3084) } else { ifn_3086 = nil }; var arg_3087 any = seq_794000344__35; if linked_3085 == nil { tmp176 = ifn_3086.Invoke_O__O(arg_3087) } else { tmp176 = linked_3085.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3084, arg_3087) }; seq_794000344__30, chunk_794000345__31, count_794000346__32, i_794000347__33 = tmp176, nil, 0, 0; continue L5 } } } }
//line :333:1
				break L5 }; var seq_794000348__30 any; var root_2535 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2535, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2537 lang.IFn


















			if linked_2536 == nil { ifn_2537 = lang.IFn_Cast(root_2535) } else { ifn_2537 = nil }; var arg_2538 any = decls__12; if linked_2536 == nil { seq_794000348__30 = ifn_2537.Invoke_O__O(arg_2538) } else { seq_794000348__30 = linked_2536.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2535, arg_2538) }
//line :333:1
			var chunk_794000349__31 any; var count_794000350__32 int64 = 0; var i_794000351__33 int64 = 0; L6: for {


















				if lang.Numbers_Lt_J_J__Z_NoInit(i_794000351__33, count_794000350__32) { var d__34_2 any = lang.Indexed_Cast(chunk_794000349__31).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_794000351__33)); var tmp177 any = A_arbace_go_repl_A_const_142; if lang.Util_Equiv_O_O__Z_NoInit(tmp177, A_arbace_go_repl_A_const_174.Invoke_O__O(d__34_2)) { var x__35_2 any = A_arbace_go_repl_A_const_177.Invoke_O__O(d__34_2); var tmp178 any; var root_2539 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_2540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2539, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2541 lang.IFn
					if linked_2540 == nil { ifn_2541 = lang.IFn_Cast(root_2539) } else { ifn_2541 = nil }; var arg_2542 any; var root_2543 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2543, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2545 lang.IFn; if linked_2544 == nil { ifn_2545 = lang.IFn_Cast(root_2543) } else { ifn_2545 = nil }; var arg_2546 any = x__35_2; var arg_2547 any = A_arbace_go_repl_A_const_205; if linked_2544 == nil { arg_2542 = ifn_2545.Invoke_O_O__O(arg_2546, arg_2547) } else { arg_2542 = linked_2544.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2543, arg_2546, arg_2547) }; if linked_2540 == nil { tmp178 = ifn_2541.Invoke_O__O(arg_2542) } else { tmp178 = linked_2540.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2539, arg_2542) }
//line :352:1
					if jrt.J2g_Truth(tmp178) {

						var tmp179 any = A_arbace_go_repl_define_BANG__fn__794000352_A_New_O_O_O(ns__29, x__35_2, old__13); var tmp180 *jrt.Class; var fncls__3130 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000352_A_fn_class; if fncls__3130 == nil { var fncls__3130d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_go_repl_define_BANG__fn__794000352_A_fn_class = fncls__3130d; tmp180 = fncls__3130d } else { tmp180 = fncls__3130 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp179, tmp180, nil).Invoke__O()
//line :352:1
						seq_794000348__30, chunk_794000349__31, count_794000350__32, i_794000351__33 = seq_794000348__30, chunk_794000349__31, count_794000350__32, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000351__33); continue L6 } else { seq_794000348__30, chunk_794000349__31, count_794000350__32, i_794000351__33 = seq_794000348__30, chunk_794000349__31, count_794000350__32, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000351__33); continue L6 } } else { seq_794000348__30, chunk_794000349__31, count_794000350__32, i_794000351__33 = seq_794000348__30, chunk_794000349__31, count_794000350__32, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000351__33); continue L6 } } else { var temp__1927000414__auto____34_4 any; var root_2548 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2548, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2550 lang.IFn; if linked_2549 == nil { ifn_2550 = lang.IFn_Cast(root_2548) } else { ifn_2550 = nil }; var arg_2551 any = seq_794000348__30; if linked_2549 == nil { temp__1927000414__auto____34_4 = ifn_2550.Invoke_O__O(arg_2551) } else { temp__1927000414__auto____34_4 = linked_2549.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2548, arg_2551) }; if jrt.J2g_Truth(temp__1927000414__auto____34_4) { var seq_794000348__35 any = temp__1927000414__auto____34_4; var tmp181 any; var root_2552 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_2553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2552, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2554 lang.IFn; if linked_2553 == nil { ifn_2554 = lang.IFn_Cast(root_2552) } else { ifn_2554 = nil }; var arg_2555 any = seq_794000348__35; if linked_2553 == nil { tmp181 = ifn_2554.Invoke_O__O(arg_2555) } else { tmp181 = linked_2553.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2552, arg_2555) }; if jrt.J2g_Truth(tmp181) { var c__1927000678__auto____36_4 any; var root_2556 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_2557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2556, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2558 lang.IFn; if linked_2557 == nil { ifn_2558 = lang.IFn_Cast(root_2556) } else { ifn_2558 = nil }; var arg_2559 any = seq_794000348__35; if linked_2557 == nil { c__1927000678__auto____36_4 = ifn_2558.Invoke_O__O(arg_2559) } else { c__1927000678__auto____36_4 = linked_2557.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2556, arg_2559) }; var tmp182 any; var root_3131 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_3132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3131, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3133 lang.IFn; if linked_3132 == nil { ifn_3133 = lang.IFn_Cast(root_3131) } else { ifn_3133 = nil }; var arg_3134 any = seq_794000348__35; if linked_3132 == nil { tmp182 = ifn_3133.Invoke_O__O(arg_3134) } else { tmp182 = linked_3132.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3131, arg_3134) }; seq_794000348__30, chunk_794000349__31, count_794000350__32, i_794000351__33 = tmp182, c__1927000678__auto____36_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____36_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L6 } else { var d__36_2 any; var root_2560 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2560, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2562 lang.IFn; if linked_2561 == nil { ifn_2562 = lang.IFn_Cast(root_2560) } else { ifn_2562 = nil }; var arg_2563 any = seq_794000348__35; if linked_2561 == nil { d__36_2 = ifn_2562.Invoke_O__O(arg_2563) } else { d__36_2 = linked_2561.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2560, arg_2563) }; var tmp183 any = A_arbace_go_repl_A_const_142; if lang.Util_Equiv_O_O__Z_NoInit(tmp183, A_arbace_go_repl_A_const_174.Invoke_O__O(d__36_2)) { var x__37_2 any = A_arbace_go_repl_A_const_177.Invoke_O__O(d__36_2); var tmp184 any; var root_2564 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_2565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2564, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2566 lang.IFn
							if linked_2565 == nil { ifn_2566 = lang.IFn_Cast(root_2564) } else { ifn_2566 = nil }; var arg_2567 any; var root_2568 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2568, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2570 lang.IFn; if linked_2569 == nil { ifn_2570 = lang.IFn_Cast(root_2568) } else { ifn_2570 = nil }; var arg_2571 any = x__37_2; var arg_2572 any = A_arbace_go_repl_A_const_205; if linked_2569 == nil { arg_2567 = ifn_2570.Invoke_O_O__O(arg_2571, arg_2572) } else { arg_2567 = linked_2569.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2568, arg_2571, arg_2572) }; if linked_2565 == nil { tmp184 = ifn_2566.Invoke_O__O(arg_2567) } else { tmp184 = linked_2565.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2564, arg_2567) }
//line :352:1
							if jrt.J2g_Truth(tmp184) {

								var tmp185 any = A_arbace_go_repl_define_BANG__fn__794000354_A_New_O_O_O(ns__29, x__37_2, old__13); var tmp186 *jrt.Class; var fncls__3177 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000354_A_fn_class; if fncls__3177 == nil { var fncls__3177d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_go_repl_define_BANG__fn__794000354_A_fn_class = fncls__3177d; tmp186 = fncls__3177d } else { tmp186 = fncls__3177 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp185, tmp186, nil).Invoke__O()
//line :352:1
								var tmp187 any; var root_3178 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_3179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3178, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3180 lang.IFn; if linked_3179 == nil { ifn_3180 = lang.IFn_Cast(root_3178) } else { ifn_3180 = nil }; var arg_3181 any = seq_794000348__35; if linked_3179 == nil { tmp187 = ifn_3180.Invoke_O__O(arg_3181) } else { tmp187 = linked_3179.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3178, arg_3181) }; seq_794000348__30, chunk_794000349__31, count_794000350__32, i_794000351__33 = tmp187, nil, 0, 0; continue L6 } else { var tmp188 any; var root_3182 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_3183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3182, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3184 lang.IFn; if linked_3183 == nil { ifn_3184 = lang.IFn_Cast(root_3182) } else { ifn_3184 = nil }; var arg_3185 any = seq_794000348__35; if linked_3183 == nil { tmp188 = ifn_3184.Invoke_O__O(arg_3185) } else { tmp188 = linked_3183.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3182, arg_3185) }; seq_794000348__30, chunk_794000349__31, count_794000350__32, i_794000351__33 = tmp188, nil, 0, 0; continue L6 } } else { var tmp189 any; var root_3186 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_3187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3186, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3188 lang.IFn; if linked_3187 == nil { ifn_3188 = lang.IFn_Cast(root_3186) } else { ifn_3188 = nil }; var arg_3189 any = seq_794000348__35; if linked_3187 == nil { tmp189 = ifn_3188.Invoke_O__O(arg_3189) } else { tmp189 = linked_3187.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3186, arg_3189) }; seq_794000348__30, chunk_794000349__31, count_794000350__32, i_794000351__33 = tmp189, nil, 0, 0; continue L6 } } } }
//line :333:1
				break L6
			}
		}























		var root_2573 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_2574 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2573, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2575 lang.IFn; if linked_2574 == nil { ifn_2575 = lang.IFn_Cast(root_2573) } else { ifn_2575 = nil }; var arg_2576 any = st__0; var arg_2577 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_2578 any = A_arbace_go_repl_A_const_206; var arg_2579 any = r__1; if linked_2574 == nil { ifn_2575.Invoke_O_O_O_O__O(arg_2576, arg_2577, arg_2578, arg_2579) } else { linked_2574.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2573, arg_2576, arg_2577, arg_2578, arg_2579) }
//line :258:1
		var tmp190 any = A_arbace_go_repl_A_const_182; var tmp191 any = A_arbace_go_repl_A_const_192; var tmp192 any; var root_2038 any = A_arbace_go_repl_A_const_80.GetRawRoot__O(); var linked_2039 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2038, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2040 lang.IFn






































































































		if linked_2039 == nil { ifn_2040 = lang.IFn_Cast(root_2038) } else { ifn_2040 = nil }; var arg_2041 any = A_arbace_go_repl_A_const_155; var arg_2042 any = init_cells__21; if linked_2039 == nil { tmp192 = ifn_2040.Invoke_O_O__O(arg_2041, arg_2042) } else { tmp192 = linked_2039.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2038, arg_2041, arg_2042) }
//line :258:1
		var tmp193 any = tmp192; var tmp194 any = A_arbace_go_repl_A_const_193; var tmp195 any







































































































		if lang.Util_Equiv_O_O__Z_NoInit(Lit_90, A_arbace_go_repl_A_const_55.Invoke_O__O(old__13)) { var root_2043 any = A_arbace_go_repl_A_const_152.GetRawRoot__O(); var linked_2044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2043, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_2045 lang.IFn; if linked_2044 == nil { ifn_2045 = lang.IFn_Cast(root_2043) } else { ifn_2045 = nil }; var arg_2046 any = new_funcs__20; var arg_2047 any = A_arbace_go_repl_A_const_194; if linked_2044 == nil { tmp195 = ifn_2045.Invoke_O_O__O(arg_2046, arg_2047) } else { tmp195 = linked_2044.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_2043, arg_2046, arg_2047) } } else { tmp195 = nil }
//line :258:1
		var tmp196 any = tmp195; var tmp197 any = A_arbace_go_repl_A_const_195; var tmp198 any; var root_2048 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_2049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2048, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2050 lang.IFn

































































		if linked_2049 == nil { ifn_2050 = lang.IFn_Cast(root_2048) } else { ifn_2050 = nil }; var arg_2051 any = new_vars__23; if linked_2049 == nil { tmp198 = ifn_2050.Invoke_O__O(arg_2051) } else { tmp198 = linked_2049.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2048, arg_2051) }
//line :258:1
		tmp11 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp190, inits__27, tmp191, tmp193, tmp194, tmp196, tmp197, tmp198)) }; return nil }(); var root_2052 any = A_arbace_go_repl_A_const_196.GetRawRoot__O(); var linked_2053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2052, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2054 lang.IFn; if














	linked_2053 == nil { ifn_2054 = lang.IFn_Cast(root_2052) } else { ifn_2054 = nil }; if linked_2053 == nil { ifn_2054.Invoke__O() } else { linked_2053.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2052) }; if /*line :258:1*/ tmp199 != nil { panic(tmp199) }; return tmp11 }








func A_arbace_go_repl_define_BANG__gen_of__794000190_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__gen_of__794000190_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__gen_of__794000190_A{}; t.Ctor_O(p0); return t }
//line :267:1
func (t *A_arbace_go_repl_define_BANG__gen_of__794000190_A) Ctor_O(c__old any) { t.F_old = c__old }
//line :267:1
func (t *A_arbace_go_repl_define_BANG__gen_of__794000190_A) Invoke_O_O__O(self, nt__1 any) any { var i__2 any; var root_1362 any = A_arbace_go_repl_A_const_131.GetRawRoot__O(); var linked_1363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1362, aot_arbace_go_check_types.A_arbace_go_check_types_info_A_fn_class); var ifn_1364 lang.IFn; if linked_1363 == nil { ifn_1364 = lang.IFn_Cast(root_1362) } else { ifn_1364 = nil }; var arg_1365 any = nt__1; if linked_1363 == nil { i__2 = ifn_1364.Invoke_O__O(arg_1365) } else { i__2 = linked_1363.(*aot_arbace_go_check_types.A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1362, arg_1365) }; if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_repl_A_const_140.Invoke_O__O(i__2), A_arbace_go_repl_A_const_54.Invoke_O__O(t.F_old)) { var root_1366 any = A_arbace_go_repl_A_const_152.GetRawRoot__O(); var linked_1367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1366, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1368 lang.IFn; if linked_1367 == nil { ifn_1368 = lang.IFn_Cast(root_1366) } else { ifn_1368 = nil }; var arg_1369 any = t.F_old; var tmp1 any = A_arbace_go_repl_A_const_61; var arg_1370 any = lang.Tuple_Create_O_O_O__IPersistentVector(tmp1, A_arbace_go_repl_A_const_55.Invoke_O__O(i__2), A_arbace_go_repl_A_const_150); if linked_1367 == nil { return ifn_1368.Invoke_O_O__O(arg_1369, arg_1370) } else { return linked_1367.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1366, arg_1369, arg_1370) } } else { return nil } }
func A_arbace_go_repl_define_BANG__fn__794000192_A_New() *A_arbace_go_repl_define_BANG__fn__794000192_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000192_A{}; t.Ctor(); return t }
//line :268:1
func (t *A_arbace_go_repl_define_BANG__fn__794000192_A) Ctor() {}
//line :268:1
func (t *A_arbace_go_repl_define_BANG__fn__794000192_A) Invoke_O_O__O(self, p1__794000179_SHARP___1 any) any { var tmp1 any; var or__1927000174__auto____2 any = A_arbace_go_repl_A_const_172.Invoke_O__O(p1__794000179_SHARP___1); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { tmp1 = A_arbace_go_repl_A_const_173.Invoke_O__O(p1__794000179_SHARP___1) }; if jrt.J2g_Truth(tmp1) { return p1__794000179_SHARP___1 } else { return nil } }






func A_arbace_go_repl_define_BANG__fn__794000194_A_New() *A_arbace_go_repl_define_BANG__fn__794000194_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000194_A{}; t.Ctor(); return t }
//line :275:1
func (t *A_arbace_go_repl_define_BANG__fn__794000194_A) Ctor() {}
//line :275:1
func (t *A_arbace_go_repl_define_BANG__fn__794000194_A) Invoke_O_O__O(self, p1__794000180_SHARP___1 any) any { var tmp1 any = A_arbace_go_repl_A_const_142; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_repl_A_const_174.Invoke_O__O(p1__794000180_SHARP___1)); if and__1927000168__auto____2 { var root_2074 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_2075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2074, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2076 lang.IFn; if linked_2075 == nil { ifn_2076 = lang.IFn_Cast(root_2074) } else { ifn_2076 = nil }; var arg_2077 any; var root_2078 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2078, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2080 lang.IFn; if linked_2079 == nil { ifn_2080 = lang.IFn_Cast(root_2078) } else { ifn_2080 = nil }; var arg_2081 any = A_arbace_go_repl_A_const_177.Invoke_O__O(p1__794000180_SHARP___1); var arg_2082 any = A_arbace_go_repl_A_const_200; if linked_2079 == nil { arg_2077 = ifn_2080.Invoke_O_O__O(arg_2081, arg_2082) } else { arg_2077 = linked_2079.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2078, arg_2081, arg_2082) }; if linked_2075 == nil { return ifn_2076.Invoke_O__O(arg_2077) } else { return linked_2075.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2074, arg_2077) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_go_repl_define_BANG__iter__794000196__794000200_A_New_O_O(p0, p1 any) *A_arbace_go_repl_define_BANG__iter__794000196__794000200_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000196__794000200_A{}; t.Ctor_O_O(p0, p1); return t }
//line :277:1
func (t *A_arbace_go_repl_define_BANG__iter__794000196__794000200_A) Ctor_O_O(c__gen_of, c__old any) { t.F_gen_of = c__gen_of; t.F_old = c__old }
//line :277:1
func (t *A_arbace_go_repl_define_BANG__iter__794000196__794000200_A) Invoke_O_O__O(self, s__794000197__1 any) any { var tmp1 any = A_arbace_go_repl_define_BANG__iter__794000196__794000200_fn__794000201_A_New_O_O_O_O(self, t.F_gen_of, t.F_old, s__794000197__1); var tmp2 *jrt.Class; var fncls__2198 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000196__794000200_fn__794000201_A_fn_class; if fncls__2198 == nil { var fncls__2198d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_go_repl_define_BANG__iter__794000196__794000200_fn__794000201_A_fn_class = fncls__2198d; tmp2 = fncls__2198d } else { tmp2 = fncls__2198 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :277:1
func A_arbace_go_repl_define_BANG__iter__794000196__794000200_fn__794000201_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_repl_define_BANG__iter__794000196__794000200_fn__794000201_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000196__794000200_fn__794000201_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :277:1
func (t *A_arbace_go_repl_define_BANG__iter__794000196__794000200_fn__794000201_A) Ctor_O_O_O_O(c__iter__794000196, c__gen_of, c__old, c__s__794000197 any) { t.F_iter__794000196 = c__iter__794000196; t.F_gen_of = c__gen_of; t.F_old = c__old; t.F_s__794000197 = c__s__794000197 }
//line :277:1
func (t *A_arbace_go_repl_define_BANG__iter__794000196__794000200_fn__794000201_A) Invoke_O__O(self any) any { { var s__794000197__1 any; var t_ any = t.F_s__794000197; t.F_s__794000197 = nil; s__794000197__1 = t_; for { var temp__1927000414__auto____2 any; var root_2089 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2089, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2091 lang.IFn; if linked_2090 == nil { ifn_2091 = lang.IFn_Cast(root_2089) } else { ifn_2091 = nil }; var arg_2092 any = s__794000197__1; if linked_2090 == nil { temp__1927000414__auto____2 = ifn_2091.Invoke_O__O(arg_2092) } else { temp__1927000414__auto____2 = linked_2090.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2089, arg_2092) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__794000197__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2093 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_2094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2093, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2095 lang.IFn; if linked_2094 == nil { ifn_2095 = lang.IFn_Cast(root_2093) } else { ifn_2095 = nil }; var arg_2096 any = s__794000197__3; if linked_2094 == nil { tmp1 = ifn_2095.Invoke_O__O(arg_2096) } else { tmp1 = linked_2094.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2093, arg_2096) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2097 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_2098 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2097, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2099 lang.IFn; if linked_2098 == nil { ifn_2099 = lang.IFn_Cast(root_2097) } else { ifn_2099 = nil }; var arg_2100 any = s__794000197__3; if linked_2098 == nil { c__1927001037__auto____4 = ifn_2099.Invoke_O__O(arg_2100) } else { c__1927001037__auto____4 = linked_2098.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2097, arg_2100) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__794000199__6 any; var root_2101 any = A_arbace_go_repl_A_const_95.GetRawRoot__O(); var linked_2102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2101, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2103 lang.IFn; if linked_2102 == nil { ifn_2103 = lang.IFn_Cast(root_2101) } else { ifn_2103 = nil }; var arg_2104 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2102 == nil { b__794000199__6 = ifn_2103.Invoke_O__O(arg_2104) } else { b__794000199__6 = linked_2102.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2101, arg_2104) }; var tmp2 any = A_arbace_go_repl_define_BANG__iter__794000196__794000200_fn__794000201_fn__794000202_A_New_O_O_O_I_O(b__794000199__6, t.F_gen_of, t.F_old, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2136 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000196__794000200_fn__794000201_fn__794000202_A_fn_class; if fncls__2136 == nil { var fncls__2136d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_go_repl_define_BANG__iter__794000196__794000200_fn__794000201_fn__794000202_A_fn_class = fncls__2136d; tmp3 = fncls__2136d } else { tmp3 = fncls__2136 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2137 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_2138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2137, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2139 lang.IFn; if linked_2138 == nil { ifn_2139 = lang.IFn_Cast(root_2137) } else { ifn_2139 = nil }; var arg_2140 any; var root_2142 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_2143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2142, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2144 lang.IFn; if linked_2143 == nil { ifn_2144 = lang.IFn_Cast(root_2142) } else { ifn_2144 = nil }; var arg_2145 any = b__794000199__6; if linked_2143 == nil { arg_2140 = ifn_2144.Invoke_O__O(arg_2145) } else { arg_2140 = linked_2143.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2142, arg_2145) }; var arg_2141 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__794000196); var tmp5 any; var root_2146 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_2147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2146, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2148 lang.IFn; if linked_2147 == nil { ifn_2148 = lang.IFn_Cast(root_2146) } else { ifn_2148 = nil }; var arg_2149 any = s__794000197__3; if linked_2147 == nil { tmp5 = ifn_2148.Invoke_O__O(arg_2149) } else { tmp5 = linked_2147.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2146, arg_2149) }; arg_2141 = tmp4.Invoke_O__O(tmp5); if linked_2138 == nil { return ifn_2139.Invoke_O_O__O(arg_2140, arg_2141) } else { return linked_2138.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2137, arg_2140, arg_2141) } } else { var root_2150 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_2151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2150, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2152 lang.IFn; if linked_2151 == nil { ifn_2152 = lang.IFn_Cast(root_2150) } else { ifn_2152 = nil }; var arg_2153 any; var root_2155 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_2156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2155, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2157 lang.IFn; if linked_2156 == nil { ifn_2157 = lang.IFn_Cast(root_2155) } else { ifn_2157 = nil }; var arg_2158 any = b__794000199__6; if linked_2156 == nil { arg_2153 = ifn_2157.Invoke_O__O(arg_2158) } else { arg_2153 = linked_2156.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2155, arg_2158) }; var arg_2154 any; if linked_2151 == nil { return ifn_2152.Invoke_O_O__O(arg_2153, arg_2154) } else { return linked_2151.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2150, arg_2153, arg_2154) } } } else { var d__4 any; var root_2159 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2159, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2161 lang.IFn; if linked_2160 == nil { ifn_2161 = lang.IFn_Cast(root_2159) } else { ifn_2161 = nil }; var arg_2162 any = s__794000197__3; if linked_2160 == nil { d__4 = ifn_2161.Invoke_O__O(arg_2162) } else { d__4 = linked_2160.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2159, arg_2162) }; var x__5 any = A_arbace_go_repl_A_const_177.Invoke_O__O(d__4); var nm__6 any; var root_2163 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2163, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2165 lang.IFn
														if linked_2164 == nil { ifn_2165 = lang.IFn_Cast(root_2163) } else { ifn_2165 = nil }; var arg_2166 any = x__5; var arg_2167 any = A_arbace_go_repl_A_const_55; if linked_2164 == nil { nm__6 = ifn_2165.Invoke_O_O__O(arg_2166, arg_2167) } else { nm__6 = linked_2164.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2163, arg_2166, arg_2167) }
//line :277:1
	var nt__7 any; var root_2168 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2168, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2170 lang.IFn
	if linked_2169 == nil { ifn_2170 = lang.IFn_Cast(root_2168) } else { ifn_2170 = nil }; var arg_2171 any = x__5; var arg_2172 any = A_arbace_go_repl_A_const_142; if linked_2169 == nil { nt__7 = ifn_2170.Invoke_O_O__O(arg_2171, arg_2172) } else { nt__7 = linked_2169.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2168, arg_2171, arg_2172) }
//line :277:1
	var k__8 any; var root_2173 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var linked_2174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2173, A_arbace_go_repl_type_key_A_fn_class); var ifn_2175 lang.IFn

	if linked_2174 == nil { ifn_2175 = lang.IFn_Cast(root_2173) } else { ifn_2175 = nil }; var arg_2176 any; var root_2178 any = A_arbace_go_repl_A_const_157.GetRawRoot__O(); var linked_2179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2178, aot_arbace_go_check_types.A_arbace_go_check_types_under_A_fn_class); var ifn_2180 lang.IFn; if linked_2179 == nil { ifn_2180 = lang.IFn_Cast(root_2178) } else { ifn_2180 = nil }; var arg_2181 any = nt__7; if linked_2179 == nil { arg_2176 = ifn_2180.Invoke_O__O(arg_2181) } else { arg_2176 = linked_2179.(*aot_arbace_go_check_types.A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2178, arg_2181) }; var arg_2177 any = t.F_gen_of; if linked_2174 == nil { k__8 = ifn_2175.Invoke_O_O__O(arg_2176, arg_2177) } else { k__8 = linked_2174.(*A_arbace_go_repl_type_key_A).Invoke_O_O_O__O(root_2173, arg_2176, arg_2177) }
//line :277:1
	var prev__9 any; var root_2182 any = A_arbace_go_repl_A_const_152.GetRawRoot__O(); var linked_2183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2182, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_2184 lang.IFn


	if linked_2183 == nil { ifn_2184 = lang.IFn_Cast(root_2182) } else { ifn_2184 = nil }; var arg_2185 any = t.F_old; var arg_2186 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_repl_A_const_61, nm__6); if linked_2183 == nil { prev__9 = ifn_2184.Invoke_O_O__O(arg_2185, arg_2186) } else { prev__9 = linked_2183.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_2182, arg_2185, arg_2186) }
//line :277:1
	var root_2187 any = A_arbace_go_repl_A_const_100.GetRawRoot__O(); var linked_2188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2187, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2189 lang.IFn; if linked_2188 == nil { ifn_2189 = lang.IFn_Cast(root_2187) } else { ifn_2189 = nil }; var arg_2190 any; var tmp6 any = A_arbace_go_repl_A_const_178; var tmp7 any = A_arbace_go_repl_A_const_150; var tmp8 any



	if lang.Util_Identical_O_O__Z_NoInit(prev__9, nil) { tmp8 = A_arbace_go_repl_A_const_153 } else { if lang.Util_Equiv_O_O__Z_NoInit(k__8, A_arbace_go_repl_A_const_178.Invoke_O__O(prev__9)) { tmp8 = A_arbace_go_repl_A_const_150.Invoke_O__O(prev__9) } else { if A_arbace_go_repl_A_const_133 != nil { var na_2192 any = A_arbace_go_repl_A_const_150.Invoke_O__O(prev__9); if jrt.Long_InstanceOf(na_2192) { var n0_2193 int64 = jrt.NN(jrt.Long_Cast(na_2192)).LongValue__J(); if n0_2193 == 9223372036854775807 { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_2192) } else { tmp8 = jrt.Long_ValueOf_J__Long_NoInit(n0_2193 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_2192) { var n0_2193_2 float64 = jrt.NN(jrt.Double_Cast(na_2192)).DoubleValue__D(); tmp8 = jrt.Double_ValueOf_D__Double_NoInit(n0_2193_2 + 1.0).Ref() } else { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_2192) } } } else { tmp8 = nil } } }
//line :277:1
	arg_2190 = lang.Tuple_Create_O_O__IPersistentVector(nm__6, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, k__8, tmp7, tmp8))); var arg_2191 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__794000196); var tmp10 any; var root_2194 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_2195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2194, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2196 lang.IFn; if linked_2195 == nil { ifn_2196 = lang.IFn_Cast(root_2194) } else { ifn_2196 = nil }; var arg_2197 any = s__794000197__3; if linked_2195 == nil { tmp10 = ifn_2196.Invoke_O__O(arg_2197) } else { tmp10 = linked_2195.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2194, arg_2197) }; arg_2191 = tmp9.Invoke_O__O(tmp10); if linked_2188 == nil { return ifn_2189.Invoke_O_O__O(arg_2190, arg_2191) } else { return linked_2188.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2187, arg_2190, arg_2191) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :277:1
func A_arbace_go_repl_define_BANG__iter__794000196__794000200_fn__794000201_fn__794000202_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_go_repl_define_BANG__iter__794000196__794000200_fn__794000201_fn__794000202_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000196__794000200_fn__794000201_fn__794000202_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :277:1
func (t *A_arbace_go_repl_define_BANG__iter__794000196__794000200_fn__794000201_fn__794000202_A) Ctor_O_O_O_I_O(c__b__794000199, c__gen_of, c__old any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__794000199 = c__b__794000199; t.F_gen_of = c__gen_of; t.F_old = c__old; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :277:1
func (t *A_arbace_go_repl_define_BANG__iter__794000196__794000200_fn__794000201_fn__794000202_A) Invoke_O__O(self any) any { { var i__794000198__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__794000198__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var d__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__794000198__1)); var x__3 any = A_arbace_go_repl_A_const_177.Invoke_O__O(d__2); var nm__4 any; var root_2105 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2105, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2107 lang.IFn
																if linked_2106 == nil { ifn_2107 = lang.IFn_Cast(root_2105) } else { ifn_2107 = nil }; var arg_2108 any = x__3; var arg_2109 any = A_arbace_go_repl_A_const_55; if linked_2106 == nil { nm__4 = ifn_2107.Invoke_O_O__O(arg_2108, arg_2109) } else { nm__4 = linked_2106.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2105, arg_2108, arg_2109) }
//line :277:1
	var nt__5 any; var root_2110 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2110, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2112 lang.IFn
	if linked_2111 == nil { ifn_2112 = lang.IFn_Cast(root_2110) } else { ifn_2112 = nil }; var arg_2113 any = x__3; var arg_2114 any = A_arbace_go_repl_A_const_142; if linked_2111 == nil { nt__5 = ifn_2112.Invoke_O_O__O(arg_2113, arg_2114) } else { nt__5 = linked_2111.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2110, arg_2113, arg_2114) }
//line :277:1
	var k__6 any; var root_2115 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var linked_2116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2115, A_arbace_go_repl_type_key_A_fn_class); var ifn_2117 lang.IFn

	if linked_2116 == nil { ifn_2117 = lang.IFn_Cast(root_2115) } else { ifn_2117 = nil }; var arg_2118 any; var root_2120 any = A_arbace_go_repl_A_const_157.GetRawRoot__O(); var linked_2121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2120, aot_arbace_go_check_types.A_arbace_go_check_types_under_A_fn_class); var ifn_2122 lang.IFn; if linked_2121 == nil { ifn_2122 = lang.IFn_Cast(root_2120) } else { ifn_2122 = nil }; var arg_2123 any = nt__5; if linked_2121 == nil { arg_2118 = ifn_2122.Invoke_O__O(arg_2123) } else { arg_2118 = linked_2121.(*aot_arbace_go_check_types.A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2120, arg_2123) }; var arg_2119 any = t.F_gen_of; if linked_2116 == nil { k__6 = ifn_2117.Invoke_O_O__O(arg_2118, arg_2119) } else { k__6 = linked_2116.(*A_arbace_go_repl_type_key_A).Invoke_O_O_O__O(root_2115, arg_2118, arg_2119) }
//line :277:1
	var prev__7 any; var root_2124 any = A_arbace_go_repl_A_const_152.GetRawRoot__O(); var linked_2125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2124, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_2126 lang.IFn


	if linked_2125 == nil { ifn_2126 = lang.IFn_Cast(root_2124) } else { ifn_2126 = nil }; var arg_2127 any = t.F_old; var arg_2128 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_repl_A_const_61, nm__4); if linked_2125 == nil { prev__7 = ifn_2126.Invoke_O_O__O(arg_2127, arg_2128) } else { prev__7 = linked_2125.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_2124, arg_2127, arg_2128) }
//line :277:1
	var root_2129 any = A_arbace_go_repl_A_const_96.GetRawRoot__O(); var linked_2130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2129, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2131 lang.IFn; if linked_2130 == nil { ifn_2131 = lang.IFn_Cast(root_2129) } else { ifn_2131 = nil }; var arg_2132 any = t.F_b__794000199; var arg_2133 any; var tmp2 any = A_arbace_go_repl_A_const_178; var tmp3 any = A_arbace_go_repl_A_const_150; var tmp4 any



	if lang.Util_Identical_O_O__Z_NoInit(prev__7, nil) { tmp4 = A_arbace_go_repl_A_const_153 } else { if lang.Util_Equiv_O_O__Z_NoInit(k__6, A_arbace_go_repl_A_const_178.Invoke_O__O(prev__7)) { tmp4 = A_arbace_go_repl_A_const_150.Invoke_O__O(prev__7) } else { if A_arbace_go_repl_A_const_133 != nil { var na_2134 any = A_arbace_go_repl_A_const_150.Invoke_O__O(prev__7); if jrt.Long_InstanceOf(na_2134) { var n0_2135 int64 = jrt.NN(jrt.Long_Cast(na_2134)).LongValue__J(); if n0_2135 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_2134) } else { tmp4 = jrt.Long_ValueOf_J__Long_NoInit(n0_2135 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_2134) { var n0_2135_2 float64 = jrt.NN(jrt.Double_Cast(na_2134)).DoubleValue__D(); tmp4 = jrt.Double_ValueOf_D__Double_NoInit(n0_2135_2 + 1.0).Ref() } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_2134) } } } else { tmp4 = nil } } }
//line :277:1
	arg_2133 = lang.Tuple_Create_O_O__IPersistentVector(nm__4, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, k__6, tmp3, tmp4))); if linked_2130 == nil { ifn_2131.Invoke_O_O__O(arg_2132, arg_2133) } else { linked_2130.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2129, arg_2132, arg_2133) }; i__794000198__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000198__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_go_repl_define_BANG__fn__794000206_A_New() *A_arbace_go_repl_define_BANG__fn__794000206_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000206_A{}; t.Ctor(); return t }
//line :284:1
func (t *A_arbace_go_repl_define_BANG__fn__794000206_A) Ctor() {}
//line :284:1
func (t *A_arbace_go_repl_define_BANG__fn__794000206_A) Invoke_O_O__O(self, p1__794000181_SHARP___1 any) any { var tmp1 any = A_arbace_go_repl_A_const_137; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_repl_A_const_174.Invoke_O__O(p1__794000181_SHARP___1)); if and__1927000168__auto____2 { var and__1927000168__auto____3 any; var root_1383 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_1384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1383, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1385 lang.IFn; if linked_1384 == nil { ifn_1385 = lang.IFn_Cast(root_1383) } else { ifn_1385 = nil }; var arg_1386 any = A_arbace_go_repl_A_const_175.Invoke_O__O(p1__794000181_SHARP___1); if linked_1384 == nil { and__1927000168__auto____3 = ifn_1385.Invoke_O__O(arg_1386) } else { and__1927000168__auto____3 = linked_1384.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1383, arg_1386) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1387 any = A_arbace_go_repl_A_const_176.GetRawRoot__O(); var linked_1388 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1387, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1389 lang.IFn; if linked_1388 == nil { ifn_1389 = lang.IFn_Cast(root_1387) } else { ifn_1389 = nil }; var arg_1390 any = Lit_15; var arg_1391 any; var root_1392 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1392, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1394 lang.IFn; if linked_1393 == nil { ifn_1394 = lang.IFn_Cast(root_1392) } else { ifn_1394 = nil }; var arg_1395 any = A_arbace_go_repl_A_const_177.Invoke_O__O(p1__794000181_SHARP___1); var arg_1396 any = A_arbace_go_repl_A_const_55; if linked_1393 == nil { arg_1391 = ifn_1394.Invoke_O_O__O(arg_1395, arg_1396) } else { arg_1391 = linked_1393.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1392, arg_1395, arg_1396) }; if linked_1388 == nil { return ifn_1389.Invoke_O_O__O(arg_1390, arg_1391) } else { return linked_1388.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1387, arg_1390, arg_1391) } } else { return and__1927000168__auto____3 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }
func A_arbace_go_repl_define_BANG__fn__794000208_A_New() *A_arbace_go_repl_define_BANG__fn__794000208_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000208_A{}; t.Ctor(); return t }
//line :285:1
func (t *A_arbace_go_repl_define_BANG__fn__794000208_A) Ctor() {}
//line :285:1
func (t *A_arbace_go_repl_define_BANG__fn__794000208_A) Invoke_O_O__O(self, p1__794000182_SHARP___1 any) any { var tmp1 any = A_arbace_go_repl_A_const_137; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_repl_A_const_174.Invoke_O__O(p1__794000182_SHARP___1)); if and__1927000168__auto____2 { return A_arbace_go_repl_A_const_175.Invoke_O__O(p1__794000182_SHARP___1) } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_go_repl_define_BANG__iter__794000210__794000214_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_repl_define_BANG__iter__794000210__794000214_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000210__794000214_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :287:1
func (t *A_arbace_go_repl_define_BANG__iter__794000210__794000214_A) Ctor_O_O_O(c__old, c__ctx, c__kept_names any) { t.F_old = c__old; t.F_ctx = c__ctx; t.F_kept_names = c__kept_names }
//line :287:1
func (t *A_arbace_go_repl_define_BANG__iter__794000210__794000214_A) Invoke_O_O__O(self, s__794000211__1 any) any { var tmp1 any = A_arbace_go_repl_define_BANG__iter__794000210__794000214_fn__794000215_A_New_O_O_O_O_O(s__794000211__1, t.F_old, self, t.F_ctx, t.F_kept_names); var tmp2 *jrt.Class; var fncls__1542 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000210__794000214_fn__794000215_A_fn_class; if fncls__1542 == nil { var fncls__1542d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_94, false); A_arbace_go_repl_define_BANG__iter__794000210__794000214_fn__794000215_A_fn_class = fncls__1542d; tmp2 = fncls__1542d } else { tmp2 = fncls__1542 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :287:1
func A_arbace_go_repl_define_BANG__iter__794000210__794000214_fn__794000215_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_repl_define_BANG__iter__794000210__794000214_fn__794000215_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000210__794000214_fn__794000215_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :287:1
func (t *A_arbace_go_repl_define_BANG__iter__794000210__794000214_fn__794000215_A) Ctor_O_O_O_O_O(c__s__794000211, c__old, c__iter__794000210, c__ctx, c__kept_names any) { t.F_s__794000211 = c__s__794000211; t.F_old = c__old; t.F_iter__794000210 = c__iter__794000210; t.F_ctx = c__ctx; t.F_kept_names = c__kept_names }
//line :287:1
func (t *A_arbace_go_repl_define_BANG__iter__794000210__794000214_fn__794000215_A) Invoke_O__O(self any) any { { var s__794000211__1 any; var t_ any = t.F_s__794000211; t.F_s__794000211 = nil; s__794000211__1 = t_; for { var temp__1927000414__auto____2 any; var root_1409 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_1410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1409, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1411 lang.IFn; if linked_1410 == nil { ifn_1411 = lang.IFn_Cast(root_1409) } else { ifn_1411 = nil }; var arg_1412 any = s__794000211__1; if linked_1410 == nil { temp__1927000414__auto____2 = ifn_1411.Invoke_O__O(arg_1412) } else { temp__1927000414__auto____2 = linked_1410.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1409, arg_1412) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__794000211__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1413 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_1414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1413, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1415 lang.IFn; if linked_1414 == nil { ifn_1415 = lang.IFn_Cast(root_1413) } else { ifn_1415 = nil }; var arg_1416 any = s__794000211__3; if linked_1414 == nil { tmp1 = ifn_1415.Invoke_O__O(arg_1416) } else { tmp1 = linked_1414.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1413, arg_1416) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1417 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_1418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1417, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1419 lang.IFn; if linked_1418 == nil { ifn_1419 = lang.IFn_Cast(root_1417) } else { ifn_1419 = nil }; var arg_1420 any = s__794000211__3; if linked_1418 == nil { c__1927001037__auto____4 = ifn_1419.Invoke_O__O(arg_1420) } else { c__1927001037__auto____4 = linked_1418.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1417, arg_1420) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__794000213__6 any; var root_1421 any = A_arbace_go_repl_A_const_95.GetRawRoot__O(); var linked_1422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1421, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1423 lang.IFn; if linked_1422 == nil { ifn_1423 = lang.IFn_Cast(root_1421) } else { ifn_1423 = nil }; var arg_1424 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1422 == nil { b__794000213__6 = ifn_1423.Invoke_O__O(arg_1424) } else { b__794000213__6 = linked_1422.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1421, arg_1424) }; var tmp2 any = A_arbace_go_repl_define_BANG__iter__794000210__794000214_fn__794000215_fn__794000216_A_New_O_O_I_O_O_O(b__794000213__6, t.F_old, size__1927001038__auto____5, t.F_ctx, t.F_kept_names, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1468 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000210__794000214_fn__794000215_fn__794000216_A_fn_class; if fncls__1468 == nil { var fncls__1468d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_go_repl_define_BANG__iter__794000210__794000214_fn__794000215_fn__794000216_A_fn_class = fncls__1468d; tmp3 = fncls__1468d } else { tmp3 = fncls__1468 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1469 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_1470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1469, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1471 lang.IFn; if linked_1470 == nil { ifn_1471 = lang.IFn_Cast(root_1469) } else { ifn_1471 = nil }; var arg_1472 any; var root_1474 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_1475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1474, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1476 lang.IFn; if linked_1475 == nil { ifn_1476 = lang.IFn_Cast(root_1474) } else { ifn_1476 = nil }; var arg_1477 any = b__794000213__6; if linked_1475 == nil { arg_1472 = ifn_1476.Invoke_O__O(arg_1477) } else { arg_1472 = linked_1475.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1474, arg_1477) }; var arg_1473 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__794000210); var tmp5 any; var root_1478 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_1479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1478, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1480 lang.IFn; if linked_1479 == nil { ifn_1480 = lang.IFn_Cast(root_1478) } else { ifn_1480 = nil }; var arg_1481 any = s__794000211__3; if linked_1479 == nil { tmp5 = ifn_1480.Invoke_O__O(arg_1481) } else { tmp5 = linked_1479.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1478, arg_1481) }; arg_1473 = tmp4.Invoke_O__O(tmp5); if linked_1470 == nil { return ifn_1471.Invoke_O_O__O(arg_1472, arg_1473) } else { return linked_1470.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1469, arg_1472, arg_1473) } } else { var root_1482 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_1483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1482, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1484 lang.IFn; if linked_1483 == nil { ifn_1484 = lang.IFn_Cast(root_1482) } else { ifn_1484 = nil }; var arg_1485 any; var root_1487 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_1488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1487, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1489 lang.IFn; if linked_1488 == nil { ifn_1489 = lang.IFn_Cast(root_1487) } else { ifn_1489 = nil }; var arg_1490 any = b__794000213__6; if linked_1488 == nil { arg_1485 = ifn_1489.Invoke_O__O(arg_1490) } else { arg_1485 = linked_1488.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1487, arg_1490) }; var arg_1486 any; if linked_1483 == nil { return ifn_1484.Invoke_O_O__O(arg_1485, arg_1486) } else { return linked_1483.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1482, arg_1485, arg_1486) } } } else { var d__4 any; var root_1491 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_1492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1491, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1493 lang.IFn; if linked_1492 == nil { ifn_1493 = lang.IFn_Cast(root_1491) } else { ifn_1493 = nil }; var arg_1494 any = s__794000211__3; if linked_1492 == nil { d__4 = ifn_1493.Invoke_O__O(arg_1494) } else { d__4 = linked_1492.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1491, arg_1494) }; var x__5 any = A_arbace_go_repl_A_const_177.Invoke_O__O(d__4); var nm__6 any; var root_1495 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1495, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1497 lang.IFn
														if linked_1496 == nil { ifn_1497 = lang.IFn_Cast(root_1495) } else { ifn_1497 = nil }; var arg_1498 any = x__5; var arg_1499 any = A_arbace_go_repl_A_const_55; if linked_1496 == nil { nm__6 = ifn_1497.Invoke_O_O__O(arg_1498, arg_1499) } else { nm__6 = linked_1496.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1495, arg_1498, arg_1499) }
//line :287:1
	var k__7 any; var root_1500 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var linked_1501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1500, A_arbace_go_repl_type_key_A_fn_class); var ifn_1502 lang.IFn

	if linked_1501 == nil { ifn_1502 = lang.IFn_Cast(root_1500) } else { ifn_1502 = nil }; var arg_1503 any; var root_1505 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1505, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1507 lang.IFn; if linked_1506 == nil { ifn_1507 = lang.IFn_Cast(root_1505) } else { ifn_1507 = nil }; var arg_1508 any = x__5; var arg_1509 any = A_arbace_go_repl_A_const_142; if linked_1506 == nil { arg_1503 = ifn_1507.Invoke_O_O__O(arg_1508, arg_1509) } else { arg_1503 = linked_1506.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1505, arg_1508, arg_1509) }; var arg_1504 any = A_arbace_go_repl_A_const_150.Invoke_O__O(t.F_ctx); if linked_1501 == nil { k__7 = ifn_1502.Invoke_O_O__O(arg_1503, arg_1504) } else { k__7 = linked_1501.(*A_arbace_go_repl_type_key_A).Invoke_O_O_O__O(root_1500, arg_1503, arg_1504) }
//line :287:1
	var prev__8 any; var root_1510 any = A_arbace_go_repl_A_const_152.GetRawRoot__O(); var linked_1511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1510, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1512 lang.IFn


	if linked_1511 == nil { ifn_1512 = lang.IFn_Cast(root_1510) } else { ifn_1512 = nil }; var arg_1513 any = t.F_old; var arg_1514 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_repl_A_const_59, nm__6); if linked_1511 == nil { prev__8 = ifn_1512.Invoke_O_O__O(arg_1513, arg_1514) } else { prev__8 = linked_1511.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1510, arg_1513, arg_1514) }
//line :287:1
	var cell__9 any; var tmp6 any
	var and__1927000168__auto____9 any = prev__8


	if jrt.J2g_Truth(and__1927000168__auto____9) { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(k__7, A_arbace_go_repl_A_const_178.Invoke_O__O(prev__8))).Ref() } else { tmp6 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp6) { cell__9 = A_arbace_go_repl_A_const_155.Invoke_O__O(prev__8) } else { cell__9 = lang.IFn_Cast(A_arbace_go_repl_A_const_179.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_82, nm__6, A_arbace_go_repl_A_const_55.Invoke_O__O(t.F_old), nil) }
//line :287:1
	var root_1522 any = A_arbace_go_repl_A_const_100.GetRawRoot__O(); var linked_1523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1522, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1524 lang.IFn; if linked_1523 == nil { ifn_1524 = lang.IFn_Cast(root_1522) } else { ifn_1524 = nil }; var arg_1525 any; var tmp7 any
	var and__1927000168__auto____10 any = prev__8



	if jrt.J2g_Truth(and__1927000168__auto____10) { var root_1527 any = A_arbace_go_repl_A_const_18.GetRawRoot__O(); var linked_1528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1527, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1529 lang.IFn; if linked_1528 == nil { ifn_1529 = lang.IFn_Cast(root_1527) } else { ifn_1529 = nil }; var arg_1530 any = t.F_kept_names; var arg_1531 any = nm__6; if linked_1528 == nil { tmp7 = ifn_1529.Invoke_O_O__O(arg_1530, arg_1531) } else { tmp7 = linked_1528.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1527, arg_1530, arg_1531) } } else { tmp7 = and__1927000168__auto____10 }; if jrt.J2g_Truth(tmp7) { var tmp8 any; var root_1532 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var linked_1533 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1532, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1534 lang.IFn
		if linked_1533 == nil { ifn_1534 = lang.IFn_Cast(root_1532) } else { ifn_1534 = nil }; var arg_1535 any = prev__8; var arg_1536 any = A_arbace_go_repl_A_const_180; var arg_1537 any = jrt.Boolean_TRUE.Ref(); if linked_1533 == nil { tmp8 = ifn_1534.Invoke_O_O_O__O(arg_1535, arg_1536, arg_1537) } else { tmp8 = linked_1533.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1532, arg_1535, arg_1536, arg_1537) }
//line :292:1
		arg_1525 = lang.Tuple_Create_O_O__IPersistentVector(nm__6, tmp8) } else { var tmp9 any = A_arbace_go_repl_A_const_155; var tmp10 any = A_arbace_go_repl_A_const_178; var tmp11 any = A_arbace_go_repl_A_const_181; arg_1525 = lang.Tuple_Create_O_O__IPersistentVector(nm__6, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, cell__9, tmp10, k__7, tmp11, A_arbace_go_repl_A_const_181.Invoke_O__O(d__4), A_arbace_go_repl_A_const_177, x__5))) }
//line :287:1
	var arg_1526 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__794000210); var tmp13 any; var root_1538 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_1539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1538, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1540 lang.IFn; if linked_1539 == nil { ifn_1540 = lang.IFn_Cast(root_1538) } else { ifn_1540 = nil }; var arg_1541 any = s__794000211__3; if linked_1539 == nil { tmp13 = ifn_1540.Invoke_O__O(arg_1541) } else { tmp13 = linked_1539.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1538, arg_1541) }; arg_1526 = tmp12.Invoke_O__O(tmp13); if linked_1523 == nil { return ifn_1524.Invoke_O_O__O(arg_1525, arg_1526) } else { return linked_1523.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1522, arg_1525, arg_1526) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :287:1
func A_arbace_go_repl_define_BANG__iter__794000210__794000214_fn__794000215_fn__794000216_A_New_O_O_I_O_O_O(p0, p1 any, p2 int32, p3, p4, p5 any) *A_arbace_go_repl_define_BANG__iter__794000210__794000214_fn__794000215_fn__794000216_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000210__794000214_fn__794000215_fn__794000216_A{}; t.Ctor_O_O_I_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :287:1
func (t *A_arbace_go_repl_define_BANG__iter__794000210__794000214_fn__794000215_fn__794000216_A) Ctor_O_O_I_O_O_O(c__b__794000213, c__old any, c__size__1927001038__auto__ int32, c__ctx, c__kept_names, c__c__1927001037__auto__ any) { t.F_b__794000213 = c__b__794000213; t.F_old = c__old; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_ctx = c__ctx; t.F_kept_names = c__kept_names; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :287:1
func (t *A_arbace_go_repl_define_BANG__iter__794000210__794000214_fn__794000215_fn__794000216_A) Invoke_O__O(self any) any { { var i__794000212__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__794000212__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var d__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__794000212__1)); var x__3 any = A_arbace_go_repl_A_const_177.Invoke_O__O(d__2); var nm__4 any; var root_1425 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1425, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1427 lang.IFn
																if linked_1426 == nil { ifn_1427 = lang.IFn_Cast(root_1425) } else { ifn_1427 = nil }; var arg_1428 any = x__3; var arg_1429 any = A_arbace_go_repl_A_const_55; if linked_1426 == nil { nm__4 = ifn_1427.Invoke_O_O__O(arg_1428, arg_1429) } else { nm__4 = linked_1426.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1425, arg_1428, arg_1429) }
//line :287:1
	var k__5 any; var root_1430 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var linked_1431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1430, A_arbace_go_repl_type_key_A_fn_class); var ifn_1432 lang.IFn

	if linked_1431 == nil { ifn_1432 = lang.IFn_Cast(root_1430) } else { ifn_1432 = nil }; var arg_1433 any; var root_1435 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1435, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1437 lang.IFn; if linked_1436 == nil { ifn_1437 = lang.IFn_Cast(root_1435) } else { ifn_1437 = nil }; var arg_1438 any = x__3; var arg_1439 any = A_arbace_go_repl_A_const_142; if linked_1436 == nil { arg_1433 = ifn_1437.Invoke_O_O__O(arg_1438, arg_1439) } else { arg_1433 = linked_1436.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1435, arg_1438, arg_1439) }; var arg_1434 any = A_arbace_go_repl_A_const_150.Invoke_O__O(t.F_ctx); if linked_1431 == nil { k__5 = ifn_1432.Invoke_O_O__O(arg_1433, arg_1434) } else { k__5 = linked_1431.(*A_arbace_go_repl_type_key_A).Invoke_O_O_O__O(root_1430, arg_1433, arg_1434) }
//line :287:1
	var prev__6 any; var root_1440 any = A_arbace_go_repl_A_const_152.GetRawRoot__O(); var linked_1441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1440, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1442 lang.IFn


	if linked_1441 == nil { ifn_1442 = lang.IFn_Cast(root_1440) } else { ifn_1442 = nil }; var arg_1443 any = t.F_old; var arg_1444 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_repl_A_const_59, nm__4); if linked_1441 == nil { prev__6 = ifn_1442.Invoke_O_O__O(arg_1443, arg_1444) } else { prev__6 = linked_1441.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1440, arg_1443, arg_1444) }
//line :287:1
	var cell__7 any; var tmp2 any
	var and__1927000168__auto____7 any = prev__6


	if jrt.J2g_Truth(and__1927000168__auto____7) { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(k__5, A_arbace_go_repl_A_const_178.Invoke_O__O(prev__6))).Ref() } else { tmp2 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp2) { cell__7 = A_arbace_go_repl_A_const_155.Invoke_O__O(prev__6) } else { cell__7 = lang.IFn_Cast(A_arbace_go_repl_A_const_179.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_82, nm__4, A_arbace_go_repl_A_const_55.Invoke_O__O(t.F_old), nil) }
//line :287:1
	var root_1452 any = A_arbace_go_repl_A_const_96.GetRawRoot__O(); var linked_1453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1452, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1454 lang.IFn; if linked_1453 == nil { ifn_1454 = lang.IFn_Cast(root_1452) } else { ifn_1454 = nil }; var arg_1455 any = t.F_b__794000213; var arg_1456 any; var tmp3 any
	var and__1927000168__auto____8 any = prev__6



	if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1457 any = A_arbace_go_repl_A_const_18.GetRawRoot__O(); var linked_1458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1457, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1459 lang.IFn; if linked_1458 == nil { ifn_1459 = lang.IFn_Cast(root_1457) } else { ifn_1459 = nil }; var arg_1460 any = t.F_kept_names; var arg_1461 any = nm__4; if linked_1458 == nil { tmp3 = ifn_1459.Invoke_O_O__O(arg_1460, arg_1461) } else { tmp3 = linked_1458.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1457, arg_1460, arg_1461) } } else { tmp3 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp3) { var tmp4 any; var root_1462 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var linked_1463 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1462, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1464 lang.IFn
		if linked_1463 == nil { ifn_1464 = lang.IFn_Cast(root_1462) } else { ifn_1464 = nil }; var arg_1465 any = prev__6; var arg_1466 any = A_arbace_go_repl_A_const_180; var arg_1467 any = jrt.Boolean_TRUE.Ref(); if linked_1463 == nil { tmp4 = ifn_1464.Invoke_O_O_O__O(arg_1465, arg_1466, arg_1467) } else { tmp4 = linked_1463.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1462, arg_1465, arg_1466, arg_1467) }
//line :292:1
		arg_1456 = lang.Tuple_Create_O_O__IPersistentVector(nm__4, tmp4) } else { var tmp5 any = A_arbace_go_repl_A_const_155; var tmp6 any = A_arbace_go_repl_A_const_178; var tmp7 any = A_arbace_go_repl_A_const_181; arg_1456 = lang.Tuple_Create_O_O__IPersistentVector(nm__4, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, cell__7, tmp6, k__5, tmp7, A_arbace_go_repl_A_const_181.Invoke_O__O(d__2), A_arbace_go_repl_A_const_177, x__3))) }
//line :287:1
	if linked_1453 == nil { ifn_1454.Invoke_O_O__O(arg_1455, arg_1456) } else { linked_1453.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1452, arg_1455, arg_1456) }; i__794000212__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000212__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }







func A_arbace_go_repl_define_BANG__iter__794000220__794000224_A_New_O_O(p0, p1 any) *A_arbace_go_repl_define_BANG__iter__794000220__794000224_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000220__794000224_A{}; t.Ctor_O_O(p0, p1); return t }
//line :295:1
func (t *A_arbace_go_repl_define_BANG__iter__794000220__794000224_A) Ctor_O_O(c__old, c__decls any) { t.F_old = c__old; t.F_decls = c__decls }
//line :295:1
func (t *A_arbace_go_repl_define_BANG__iter__794000220__794000224_A) Invoke_O_O__O(self, s__794000221__1 any) any { var tmp1 any = A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_A_New_O_O_O_O(t.F_old, self, t.F_decls, s__794000221__1); var tmp2 *jrt.Class; var fncls__1631 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_A_fn_class; if fncls__1631 == nil { var fncls__1631d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_A_fn_class = fncls__1631d; tmp2 = fncls__1631d } else { tmp2 = fncls__1631 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :295:1
func A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :295:1
func (t *A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_A) Ctor_O_O_O_O(c__old, c__iter__794000220, c__decls, c__s__794000221 any) { t.F_old = c__old; t.F_iter__794000220 = c__iter__794000220; t.F_decls = c__decls; t.F_s__794000221 = c__s__794000221 }
//line :295:1
func (t *A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_A) Invoke_O__O(self any) any { { var s__794000221__1 any; var t_ any = t.F_s__794000221; t.F_s__794000221 = nil; s__794000221__1 = t_; for { var temp__1927000414__auto____2 any; var root_1548 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_1549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1548, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1550 lang.IFn; if linked_1549 == nil { ifn_1550 = lang.IFn_Cast(root_1548) } else { ifn_1550 = nil }; var arg_1551 any = s__794000221__1; if linked_1549 == nil { temp__1927000414__auto____2 = ifn_1550.Invoke_O__O(arg_1551) } else { temp__1927000414__auto____2 = linked_1549.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1548, arg_1551) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__794000221__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1552 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_1553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1552, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1554 lang.IFn; if linked_1553 == nil { ifn_1554 = lang.IFn_Cast(root_1552) } else { ifn_1554 = nil }; var arg_1555 any = s__794000221__3; if linked_1553 == nil { tmp1 = ifn_1554.Invoke_O__O(arg_1555) } else { tmp1 = linked_1553.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1552, arg_1555) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1556 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_1557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1556, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1558 lang.IFn; if linked_1557 == nil { ifn_1558 = lang.IFn_Cast(root_1556) } else { ifn_1558 = nil }; var arg_1559 any = s__794000221__3; if linked_1557 == nil { c__1927001037__auto____4 = ifn_1558.Invoke_O__O(arg_1559) } else { c__1927001037__auto____4 = linked_1557.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1556, arg_1559) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__794000223__6 any; var root_1560 any = A_arbace_go_repl_A_const_95.GetRawRoot__O(); var linked_1561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1560, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1562 lang.IFn; if linked_1561 == nil { ifn_1562 = lang.IFn_Cast(root_1560) } else { ifn_1562 = nil }; var arg_1563 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1561 == nil { b__794000223__6 = ifn_1562.Invoke_O__O(arg_1563) } else { b__794000223__6 = linked_1561.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1560, arg_1563) }; var tmp2 any = A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000226_A_New_O_O_I_O_O(b__794000223__6, t.F_old, size__1927001038__auto____5, t.F_decls, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1582 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000226_A_fn_class; if fncls__1582 == nil { var fncls__1582d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_97, false); A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000226_A_fn_class = fncls__1582d; tmp3 = fncls__1582d } else { tmp3 = fncls__1582 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1583 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_1584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1583, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1585 lang.IFn; if linked_1584 == nil { ifn_1585 = lang.IFn_Cast(root_1583) } else { ifn_1585 = nil }; var arg_1586 any; var root_1588 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_1589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1588, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1590 lang.IFn; if linked_1589 == nil { ifn_1590 = lang.IFn_Cast(root_1588) } else { ifn_1590 = nil }; var arg_1591 any = b__794000223__6; if linked_1589 == nil { arg_1586 = ifn_1590.Invoke_O__O(arg_1591) } else { arg_1586 = linked_1589.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1588, arg_1591) }; var arg_1587 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__794000220); var tmp5 any; var root_1592 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_1593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1592, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1594 lang.IFn; if linked_1593 == nil { ifn_1594 = lang.IFn_Cast(root_1592) } else { ifn_1594 = nil }; var arg_1595 any = s__794000221__3; if linked_1593 == nil { tmp5 = ifn_1594.Invoke_O__O(arg_1595) } else { tmp5 = linked_1593.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1592, arg_1595) }; arg_1587 = tmp4.Invoke_O__O(tmp5); if linked_1584 == nil { return ifn_1585.Invoke_O_O__O(arg_1586, arg_1587) } else { return linked_1584.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1583, arg_1586, arg_1587) } } else { var root_1596 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_1597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1596, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1598 lang.IFn; if linked_1597 == nil { ifn_1598 = lang.IFn_Cast(root_1596) } else { ifn_1598 = nil }; var arg_1599 any; var root_1601 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_1602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1601, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1603 lang.IFn; if linked_1602 == nil { ifn_1603 = lang.IFn_Cast(root_1601) } else { ifn_1603 = nil }; var arg_1604 any = b__794000223__6; if linked_1602 == nil { arg_1599 = ifn_1603.Invoke_O__O(arg_1604) } else { arg_1599 = linked_1602.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1601, arg_1604) }; var arg_1600 any; if linked_1597 == nil { return ifn_1598.Invoke_O_O__O(arg_1599, arg_1600) } else { return linked_1597.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1596, arg_1599, arg_1600) } } } else { var x__4 any; var root_1605 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_1606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1605, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1607 lang.IFn; if linked_1606 == nil { ifn_1607 = lang.IFn_Cast(root_1605) } else { ifn_1607 = nil }; var arg_1608 any = s__794000221__3; if linked_1606 == nil { x__4 = ifn_1607.Invoke_O__O(arg_1608) } else { x__4 = linked_1606.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1605, arg_1608) }; var root_1609 any = A_arbace_go_repl_A_const_100.GetRawRoot__O(); var linked_1610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1609, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1611 lang.IFn; if linked_1610 == nil { ifn_1611 = lang.IFn_Cast(root_1609) } else { ifn_1611 = nil }; var arg_1612 any; var d__5 any; var root_1614 any = A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_1615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1614, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1616 lang.IFn
														if linked_1615 == nil { ifn_1616 = lang.IFn_Cast(root_1614) } else { ifn_1616 = nil }; var arg_1617 any; var tmp6 any = A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000230_A_New_O(x__4); var tmp7 *jrt.Class; var fncls__1619 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000230_A_fn_class; if fncls__1619 == nil { var fncls__1619d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_98, false); A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000230_A_fn_class = fncls__1619d; tmp7 = fncls__1619d } else { tmp7 = fncls__1619 }; arg_1617 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_1618 any = t.F_decls; if linked_1615 == nil { d__5 = ifn_1616.Invoke_O_O__O(arg_1617, arg_1618) } else { d__5 = linked_1615.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1614, arg_1617, arg_1618) }
//line :295:1
	var tmp8 any = A_arbace_go_repl_A_const_155; var tmp9 any = lang.IFn_Cast(A_arbace_go_repl_A_const_179.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_82, Lit_15, A_arbace_go_repl_A_const_55.Invoke_O__O(t.F_old), nil); var tmp10 any = A_arbace_go_repl_A_const_181; arg_1612 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9, tmp10, A_arbace_go_repl_A_const_181.Invoke_O__O(d__5))); var arg_1613 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__794000220); var tmp12 any; var root_1627 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_1628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1627, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1629 lang.IFn; if linked_1628 == nil { ifn_1629 = lang.IFn_Cast(root_1627) } else { ifn_1629 = nil }; var arg_1630 any = s__794000221__3; if linked_1628 == nil { tmp12 = ifn_1629.Invoke_O__O(arg_1630) } else { tmp12 = linked_1628.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1627, arg_1630) }; arg_1613 = tmp11.Invoke_O__O(tmp12); if linked_1610 == nil { return ifn_1611.Invoke_O_O__O(arg_1612, arg_1613) } else { return linked_1610.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1609, arg_1612, arg_1613) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :295:1
func A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000226_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000226_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000226_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :295:1
func (t *A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000226_A) Ctor_O_O_I_O_O(c__b__794000223, c__old any, c__size__1927001038__auto__ int32, c__decls, c__c__1927001037__auto__ any) { t.F_b__794000223 = c__b__794000223; t.F_old = c__old; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_decls = c__decls; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :295:1
func (t *A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000226_A) Invoke_O__O(self any) any { { var i__794000222__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__794000222__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var x__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__794000222__1)); var root_1564 any = A_arbace_go_repl_A_const_96.GetRawRoot__O(); var linked_1565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1564, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1566 lang.IFn; if linked_1565 == nil { ifn_1566 = lang.IFn_Cast(root_1564) } else { ifn_1566 = nil }; var arg_1567 any = t.F_b__794000223; var arg_1568 any; var d__3 any; var root_1569 any = A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_1570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1569, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1571 lang.IFn
																if linked_1570 == nil { ifn_1571 = lang.IFn_Cast(root_1569) } else { ifn_1571 = nil }; var arg_1572 any; var tmp2 any = A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000226_fn__794000227_A_New_O(x__2); var tmp3 *jrt.Class; var fncls__1574 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000226_fn__794000227_A_fn_class; if fncls__1574 == nil { var fncls__1574d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_99, false); A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000226_fn__794000227_A_fn_class = fncls__1574d; tmp3 = fncls__1574d } else { tmp3 = fncls__1574 }; arg_1572 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_1573 any = t.F_decls; if linked_1570 == nil { d__3 = ifn_1571.Invoke_O_O__O(arg_1572, arg_1573) } else { d__3 = linked_1570.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1569, arg_1572, arg_1573) }
//line :295:1
	var tmp4 any = A_arbace_go_repl_A_const_155; var tmp5 any = lang.IFn_Cast(A_arbace_go_repl_A_const_179.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_82, Lit_15, A_arbace_go_repl_A_const_55.Invoke_O__O(t.F_old), nil); var tmp6 any = A_arbace_go_repl_A_const_181; arg_1568 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, A_arbace_go_repl_A_const_181.Invoke_O__O(d__3))); if linked_1565 == nil { ifn_1566.Invoke_O_O__O(arg_1567, arg_1568) } else { linked_1565.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1564, arg_1567, arg_1568) }; i__794000222__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000222__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000226_fn__794000227_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000226_fn__794000227_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000226_fn__794000227_A{}; t.Ctor_O(p0); return t }
//line :296:1
func (t *A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000226_fn__794000227_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :296:1
func (t *A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000226_fn__794000227_A) Invoke_O_O__O(self, p1__794000183_SHARP___1 any) any { if lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_repl_A_const_177.Invoke_O__O(p1__794000183_SHARP___1), t.F_x) { return p1__794000183_SHARP___1 } else { return nil } }
//line :296:1
func A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000230_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000230_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000230_A{}; t.Ctor_O(p0); return t }
//line :296:1
func (t *A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000230_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :296:1
func (t *A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000230_A) Invoke_O_O__O(self, p1__794000183_SHARP___1 any) any { if lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_repl_A_const_177.Invoke_O__O(p1__794000183_SHARP___1), t.F_x) { return p1__794000183_SHARP___1 } else { return nil } }



func A_arbace_go_repl_define_BANG__iter__794000234__794000240_A_New() *A_arbace_go_repl_define_BANG__iter__794000234__794000240_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000234__794000240_A{}; t.Ctor(); return t }
//line :300:1
func (t *A_arbace_go_repl_define_BANG__iter__794000234__794000240_A) Ctor() {}
//line :300:1
func (t *A_arbace_go_repl_define_BANG__iter__794000234__794000240_A) Invoke_O_O__O(self, s__794000235__1 any) any { var tmp1 any = A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_A_New_O_O(s__794000235__1, self); var tmp2 *jrt.Class; var fncls__1745 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_A_fn_class; if fncls__1745 == nil { var fncls__1745d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_100, false); A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_A_fn_class = fncls__1745d; tmp2 = fncls__1745d } else { tmp2 = fncls__1745 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :300:1
func A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_A_New_O_O(p0, p1 any) *A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_A{}; t.Ctor_O_O(p0, p1); return t }
//line :300:1
func (t *A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_A) Ctor_O_O(c__s__794000235, c__iter__794000234 any) { t.F_s__794000235 = c__s__794000235; t.F_iter__794000234 = c__iter__794000234 }
//line :300:1
func (t *A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_A) Invoke_O__O(self any) any { { var s__794000235__1 any; var t_ any = t.F_s__794000235; t.F_s__794000235 = nil; s__794000235__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1633 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_1634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1633, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1635 lang.IFn; if linked_1634 == nil { ifn_1635 = lang.IFn_Cast(root_1633) } else { ifn_1635 = nil }; var arg_1636 any = s__794000235__1; if linked_1634 == nil { temp__1927000414__auto____2 = ifn_1635.Invoke_O__O(arg_1636) } else { temp__1927000414__auto____2 = linked_1634.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1633, arg_1636) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var d__4 any; var root_1637 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_1638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1637, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1639 lang.IFn; if linked_1638 == nil { ifn_1639 = lang.IFn_Cast(root_1637) } else { ifn_1639 = nil }; var arg_1640 any = xs__1927001018__auto____3; if linked_1638 == nil { d__4 = ifn_1639.Invoke_O__O(arg_1640) } else { d__4 = linked_1638.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1637, arg_1640) }; var tmp1 any = A_arbace_go_repl_A_const_183; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_repl_A_const_174.Invoke_O__O(d__4)) { var iterys__1927001035__auto____5 any; var tmp2 any = A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_A_New(); var tmp3 *jrt.Class; var fncls__1723 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_A_fn_class; if fncls__1723 == nil { var fncls__1723d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_101, false); A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_A_fn_class = fncls__1723d; tmp3 = fncls__1723d } else { tmp3 = fncls__1723 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var fs__1927001036__auto____6 any; var root_1724 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_1725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1724, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1726 lang.IFn; if linked_1725 == nil { ifn_1726 = lang.IFn_Cast(root_1724) } else { ifn_1726 = nil }; var arg_1727 any; var tmp4 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp5 any; var or__1927000174__auto____6 any = A_arbace_go_repl_A_const_184.Invoke_O__O(d__4); if jrt.J2g_Truth(or__1927000174__auto____6) { tmp5 = or__1927000174__auto____6 } else { tmp5 = lang.Tuple_Create_O__IPersistentVector(A_arbace_go_repl_A_const_177.Invoke_O__O(d__4)) }; arg_1727 = tmp4.Invoke_O__O(tmp5); if linked_1725 == nil { fs__1927001036__auto____6 = ifn_1726.Invoke_O__O(arg_1727) } else { fs__1927001036__auto____6 = linked_1725.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1724, arg_1727) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1728 any = A_arbace_go_repl_A_const_101.GetRawRoot__O(); var linked_1729 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1728, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1730 lang.IFn; if linked_1729 == nil { ifn_1730 = lang.IFn_Cast(root_1728) } else { ifn_1730 = nil }; var arg_1731 any = fs__1927001036__auto____6; var arg_1732 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__794000234); var tmp7 any; var root_1733 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_1734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1733, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1735 lang.IFn; if linked_1734 == nil { ifn_1735 = lang.IFn_Cast(root_1733) } else { ifn_1735 = nil }; var arg_1736 any = s__794000235__1; if linked_1734 == nil { tmp7 = ifn_1735.Invoke_O__O(arg_1736) } else { tmp7 = linked_1734.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1733, arg_1736) }; arg_1732 = tmp6.Invoke_O__O(tmp7); if linked_1729 == nil { return ifn_1730.Invoke_O_O__O(arg_1731, arg_1732) } else { return linked_1729.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1728, arg_1731, arg_1732) } } else { var tmp8 any; var root_1737 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_1738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1737, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1739 lang.IFn; if linked_1738 == nil { ifn_1739 = lang.IFn_Cast(root_1737) } else { ifn_1739 = nil }; var arg_1740 any = s__794000235__1; if linked_1738 == nil { tmp8 = ifn_1739.Invoke_O__O(arg_1740) } else { tmp8 = linked_1738.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1737, arg_1740) }; s__794000235__1 = tmp8; continue L1 } } else { var tmp9 any; var root_1741 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_1742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1741, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1743 lang.IFn; if linked_1742 == nil { ifn_1743 = lang.IFn_Cast(root_1741) } else { ifn_1743 = nil }; var arg_1744 any = s__794000235__1; if linked_1742 == nil { tmp9 = ifn_1743.Invoke_O__O(arg_1744) } else { tmp9 = linked_1742.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1741, arg_1744) }; s__794000235__1 = tmp9; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :300:1
func A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_A_New() *A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_A{}; t.Ctor(); return t }
//line :300:1
func (t *A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_A) Ctor() {}
//line :300:1
func (t *A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_A) Invoke_O_O__O(self, s__794000237__1 any) any { var tmp1 any = A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_fn__794000243_A_New_O_O(s__794000237__1, self); var tmp2 *jrt.Class; var fncls__1722 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_fn__794000243_A_fn_class; if fncls__1722 == nil { var fncls__1722d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_102, false); A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_fn__794000243_A_fn_class = fncls__1722d; tmp2 = fncls__1722d } else { tmp2 = fncls__1722 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :300:1
func A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_fn__794000243_A_New_O_O(p0, p1 any) *A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_fn__794000243_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_fn__794000243_A{}; t.Ctor_O_O(p0, p1); return t }
//line :300:1
func (t *A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_fn__794000243_A) Ctor_O_O(c__s__794000237, c__iter__794000236 any) { t.F_s__794000237 = c__s__794000237; t.F_iter__794000236 = c__iter__794000236 }
//line :300:1
func (t *A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_fn__794000243_A) Invoke_O__O(self any) any { { var s__794000237__1 any; var t_ any = t.F_s__794000237; t.F_s__794000237 = nil; s__794000237__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1641 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_1642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1641, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1643 lang.IFn; if linked_1642 == nil { ifn_1643 = lang.IFn_Cast(root_1641) } else { ifn_1643 = nil }; var arg_1644 any = s__794000237__1; if linked_1642 == nil { temp__1927000414__auto____2 = ifn_1643.Invoke_O__O(arg_1644) } else { temp__1927000414__auto____2 = linked_1642.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1641, arg_1644) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__794000237__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1645 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_1646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1645, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1647 lang.IFn; if linked_1646 == nil { ifn_1647 = lang.IFn_Cast(root_1645) } else { ifn_1647 = nil }; var arg_1648 any = s__794000237__3; if linked_1646 == nil { tmp1 = ifn_1647.Invoke_O__O(arg_1648) } else { tmp1 = linked_1646.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1645, arg_1648) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1649 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_1650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1649, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1651 lang.IFn; if linked_1650 == nil { ifn_1651 = lang.IFn_Cast(root_1649) } else { ifn_1651 = nil }; var arg_1652 any = s__794000237__3; if linked_1650 == nil { c__1927001037__auto____4 = ifn_1651.Invoke_O__O(arg_1652) } else { c__1927001037__auto____4 = linked_1650.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1649, arg_1652) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__794000239__6 any; var root_1653 any = A_arbace_go_repl_A_const_95.GetRawRoot__O(); var linked_1654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1653, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1655 lang.IFn; if linked_1654 == nil { ifn_1655 = lang.IFn_Cast(root_1653) } else { ifn_1655 = nil }; var arg_1656 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1654 == nil { b__794000239__6 = ifn_1655.Invoke_O__O(arg_1656) } else { b__794000239__6 = linked_1654.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1653, arg_1656) }; var tmp2 any = A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_fn__794000243_fn__794000244_A_New_O_I_O(b__794000239__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1672 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_fn__794000243_fn__794000244_A_fn_class; if fncls__1672 == nil { var fncls__1672d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_103, false); A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_fn__794000243_fn__794000244_A_fn_class = fncls__1672d; tmp3 = fncls__1672d } else { tmp3 = fncls__1672 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1673 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_1674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1673, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1675 lang.IFn; if linked_1674 == nil { ifn_1675 = lang.IFn_Cast(root_1673) } else { ifn_1675 = nil }; var arg_1676 any; var root_1678 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_1679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1678, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1680 lang.IFn; if linked_1679 == nil { ifn_1680 = lang.IFn_Cast(root_1678) } else { ifn_1680 = nil }; var arg_1681 any = b__794000239__6; if linked_1679 == nil { arg_1676 = ifn_1680.Invoke_O__O(arg_1681) } else { arg_1676 = linked_1679.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1678, arg_1681) }; var arg_1677 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__794000236); var tmp5 any; var root_1682 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_1683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1682, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1684 lang.IFn; if linked_1683 == nil { ifn_1684 = lang.IFn_Cast(root_1682) } else { ifn_1684 = nil }; var arg_1685 any = s__794000237__3; if linked_1683 == nil { tmp5 = ifn_1684.Invoke_O__O(arg_1685) } else { tmp5 = linked_1683.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1682, arg_1685) }; arg_1677 = tmp4.Invoke_O__O(tmp5); if linked_1674 == nil { return ifn_1675.Invoke_O_O__O(arg_1676, arg_1677) } else { return linked_1674.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1673, arg_1676, arg_1677) } } else { var root_1686 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_1687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1686, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1688 lang.IFn; if linked_1687 == nil { ifn_1688 = lang.IFn_Cast(root_1686) } else { ifn_1688 = nil }; var arg_1689 any; var root_1691 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_1692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1691, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1693 lang.IFn; if linked_1692 == nil { ifn_1693 = lang.IFn_Cast(root_1691) } else { ifn_1693 = nil }; var arg_1694 any = b__794000239__6; if linked_1692 == nil { arg_1689 = ifn_1693.Invoke_O__O(arg_1694) } else { arg_1689 = linked_1692.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1691, arg_1694) }; var arg_1690 any; if linked_1687 == nil { return ifn_1688.Invoke_O_O__O(arg_1689, arg_1690) } else { return linked_1687.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1686, arg_1689, arg_1690) } } } else { var x__4 any; var root_1695 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_1696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1695, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1697 lang.IFn; if linked_1696 == nil { ifn_1697 = lang.IFn_Cast(root_1695) } else { ifn_1697 = nil }; var arg_1698 any = s__794000237__3; if linked_1696 == nil { x__4 = ifn_1697.Invoke_O__O(arg_1698) } else { x__4 = linked_1696.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1695, arg_1698) }; var tmp6 any; var root_1699 any = A_arbace_go_repl_A_const_176.GetRawRoot__O(); var linked_1700 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1699, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1701 lang.IFn; if linked_1700 == nil { ifn_1701 = lang.IFn_Cast(root_1699) } else { ifn_1701 = nil }; var arg_1702 any = Lit_4; var arg_1703 any; var root_1704 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1704, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1706 lang.IFn; if linked_1705 == nil { ifn_1706 = lang.IFn_Cast(root_1704) } else { ifn_1706 = nil }; var arg_1707 any = x__4; var arg_1708 any = A_arbace_go_repl_A_const_55; if linked_1705 == nil { arg_1703 = ifn_1706.Invoke_O_O__O(arg_1707, arg_1708) } else { arg_1703 = linked_1705.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1704, arg_1707, arg_1708) }; if linked_1700 == nil { tmp6 = ifn_1701.Invoke_O_O__O(arg_1702, arg_1703) } else { tmp6 = linked_1700.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1699, arg_1702, arg_1703) }; if jrt.J2g_Truth(tmp6) { var root_1709 any = A_arbace_go_repl_A_const_100.GetRawRoot__O(); var linked_1710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1709, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1711 lang.IFn; if linked_1710 == nil { ifn_1711 = lang.IFn_Cast(root_1709) } else { ifn_1711 = nil }; var arg_1712 any = x__4; var arg_1713 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__794000236); var tmp8 any; var root_1714 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_1715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1714, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1716 lang.IFn; if linked_1715 == nil { ifn_1716 = lang.IFn_Cast(root_1714) } else { ifn_1716 = nil }; var arg_1717 any = s__794000237__3; if linked_1715 == nil { tmp8 = ifn_1716.Invoke_O__O(arg_1717) } else { tmp8 = linked_1715.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1714, arg_1717) }; arg_1713 = tmp7.Invoke_O__O(tmp8); if linked_1710 == nil { return ifn_1711.Invoke_O_O__O(arg_1712, arg_1713) } else { return linked_1710.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1709, arg_1712, arg_1713) } } else { var tmp9 any; var root_1718 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_1719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1718, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1720 lang.IFn; if linked_1719 == nil { ifn_1720 = lang.IFn_Cast(root_1718) } else { ifn_1720 = nil }; var arg_1721 any = s__794000237__3; if linked_1719 == nil { tmp9 = ifn_1720.Invoke_O__O(arg_1721) } else { tmp9 = linked_1719.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1718, arg_1721) }; s__794000237__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :300:1
func A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_fn__794000243_fn__794000244_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_fn__794000243_fn__794000244_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_fn__794000243_fn__794000244_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :300:1
func (t *A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_fn__794000243_fn__794000244_A) Ctor_O_I_O(c__b__794000239 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__794000239 = c__b__794000239; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :300:1
func (t *A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_fn__794000243_fn__794000244_A) Invoke_O__O(self any) any { { var i__794000238__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__794000238__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var x__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__794000238__1)); var tmp2 any; var root_1657 any = A_arbace_go_repl_A_const_176.GetRawRoot__O(); var linked_1658 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1657, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1659 lang.IFn; if linked_1658 == nil { ifn_1659 = lang.IFn_Cast(root_1657) } else { ifn_1659 = nil }; var arg_1660 any = Lit_4; var arg_1661 any; var root_1662 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1662, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1664 lang.IFn; if linked_1663 == nil { ifn_1664 = lang.IFn_Cast(root_1662) } else { ifn_1664 = nil }; var arg_1665 any = x__2; var arg_1666 any = A_arbace_go_repl_A_const_55; if linked_1663 == nil { arg_1661 = ifn_1664.Invoke_O_O__O(arg_1665, arg_1666) } else { arg_1661 = linked_1663.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1662, arg_1665, arg_1666) }; if linked_1658 == nil { tmp2 = ifn_1659.Invoke_O_O__O(arg_1660, arg_1661) } else { tmp2 = linked_1658.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1657, arg_1660, arg_1661) }; if jrt.J2g_Truth(tmp2) { var root_1667 any = A_arbace_go_repl_A_const_96.GetRawRoot__O(); var linked_1668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1667, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1669 lang.IFn; if linked_1668 == nil { ifn_1669 = lang.IFn_Cast(root_1667) } else { ifn_1669 = nil }; var arg_1670 any = t.F_b__794000239; var arg_1671 any = x__2; if linked_1668 == nil { ifn_1669.Invoke_O_O__O(arg_1670, arg_1671) } else { linked_1668.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1667, arg_1670, arg_1671) }; i__794000238__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000238__1); continue L1 } else { i__794000238__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000238__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_go_repl_define_BANG__iter__794000250__794000254_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_repl_define_BANG__iter__794000250__794000254_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000250__794000254_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :303:1
func (t *A_arbace_go_repl_define_BANG__iter__794000250__794000254_A) Ctor_O_O_O(c__new_vars, c__old, c__ctx any) { t.F_new_vars = c__new_vars; t.F_old = c__old; t.F_ctx = c__ctx }
//line :303:1
func (t *A_arbace_go_repl_define_BANG__iter__794000250__794000254_A) Invoke_O_O__O(self, s__794000251__1 any) any { var tmp1 any = A_arbace_go_repl_define_BANG__iter__794000250__794000254_fn__794000255_A_New_O_O_O_O_O(t.F_new_vars, self, t.F_old, s__794000251__1, t.F_ctx); var tmp2 *jrt.Class; var fncls__1913 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000250__794000254_fn__794000255_A_fn_class; if fncls__1913 == nil { var fncls__1913d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_104, false); A_arbace_go_repl_define_BANG__iter__794000250__794000254_fn__794000255_A_fn_class = fncls__1913d; tmp2 = fncls__1913d } else { tmp2 = fncls__1913 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :303:1
func A_arbace_go_repl_define_BANG__iter__794000250__794000254_fn__794000255_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_repl_define_BANG__iter__794000250__794000254_fn__794000255_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000250__794000254_fn__794000255_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :303:1
func (t *A_arbace_go_repl_define_BANG__iter__794000250__794000254_fn__794000255_A) Ctor_O_O_O_O_O(c__new_vars, c__iter__794000250, c__old, c__s__794000251, c__ctx any) { t.F_new_vars = c__new_vars; t.F_iter__794000250 = c__iter__794000250; t.F_old = c__old; t.F_s__794000251 = c__s__794000251; t.F_ctx = c__ctx }
//line :303:1
func (t *A_arbace_go_repl_define_BANG__iter__794000250__794000254_fn__794000255_A) Invoke_O__O(self any) any { { var s__794000251__1 any; var t_ any = t.F_s__794000251; t.F_s__794000251 = nil; s__794000251__1 = t_; for { var temp__1927000414__auto____2 any; var root_1756 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_1757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1756, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1758 lang.IFn; if linked_1757 == nil { ifn_1758 = lang.IFn_Cast(root_1756) } else { ifn_1758 = nil }; var arg_1759 any = s__794000251__1; if linked_1757 == nil { temp__1927000414__auto____2 = ifn_1758.Invoke_O__O(arg_1759) } else { temp__1927000414__auto____2 = linked_1757.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1756, arg_1759) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__794000251__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1760 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_1761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1760, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1762 lang.IFn; if linked_1761 == nil { ifn_1762 = lang.IFn_Cast(root_1760) } else { ifn_1762 = nil }; var arg_1763 any = s__794000251__3; if linked_1761 == nil { tmp1 = ifn_1762.Invoke_O__O(arg_1763) } else { tmp1 = linked_1761.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1760, arg_1763) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1764 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_1765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1764, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1766 lang.IFn; if linked_1765 == nil { ifn_1766 = lang.IFn_Cast(root_1764) } else { ifn_1766 = nil }; var arg_1767 any = s__794000251__3; if linked_1765 == nil { c__1927001037__auto____4 = ifn_1766.Invoke_O__O(arg_1767) } else { c__1927001037__auto____4 = linked_1765.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1764, arg_1767) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__794000253__6 any; var root_1768 any = A_arbace_go_repl_A_const_95.GetRawRoot__O(); var linked_1769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1768, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1770 lang.IFn; if linked_1769 == nil { ifn_1770 = lang.IFn_Cast(root_1768) } else { ifn_1770 = nil }; var arg_1771 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1769 == nil { b__794000253__6 = ifn_1770.Invoke_O__O(arg_1771) } else { b__794000253__6 = linked_1769.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1768, arg_1771) }; var tmp2 any = A_arbace_go_repl_define_BANG__iter__794000250__794000254_fn__794000255_fn__794000256_A_New_O_O_O_I_O_O(b__794000253__6, t.F_new_vars, t.F_old, size__1927001038__auto____5, t.F_ctx, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1827 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000250__794000254_fn__794000255_fn__794000256_A_fn_class; if fncls__1827 == nil { var fncls__1827d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_105, false); A_arbace_go_repl_define_BANG__iter__794000250__794000254_fn__794000255_fn__794000256_A_fn_class = fncls__1827d; tmp3 = fncls__1827d } else { tmp3 = fncls__1827 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1828 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_1829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1828, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1830 lang.IFn; if linked_1829 == nil { ifn_1830 = lang.IFn_Cast(root_1828) } else { ifn_1830 = nil }; var arg_1831 any; var root_1833 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_1834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1833, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1835 lang.IFn; if linked_1834 == nil { ifn_1835 = lang.IFn_Cast(root_1833) } else { ifn_1835 = nil }; var arg_1836 any = b__794000253__6; if linked_1834 == nil { arg_1831 = ifn_1835.Invoke_O__O(arg_1836) } else { arg_1831 = linked_1834.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1833, arg_1836) }; var arg_1832 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__794000250); var tmp5 any; var root_1837 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_1838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1837, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1839 lang.IFn; if linked_1838 == nil { ifn_1839 = lang.IFn_Cast(root_1837) } else { ifn_1839 = nil }; var arg_1840 any = s__794000251__3; if linked_1838 == nil { tmp5 = ifn_1839.Invoke_O__O(arg_1840) } else { tmp5 = linked_1838.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1837, arg_1840) }; arg_1832 = tmp4.Invoke_O__O(tmp5); if linked_1829 == nil { return ifn_1830.Invoke_O_O__O(arg_1831, arg_1832) } else { return linked_1829.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1828, arg_1831, arg_1832) } } else { var root_1841 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_1842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1841, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1843 lang.IFn; if linked_1842 == nil { ifn_1843 = lang.IFn_Cast(root_1841) } else { ifn_1843 = nil }; var arg_1844 any; var root_1846 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_1847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1846, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1848 lang.IFn; if linked_1847 == nil { ifn_1848 = lang.IFn_Cast(root_1846) } else { ifn_1848 = nil }; var arg_1849 any = b__794000253__6; if linked_1847 == nil { arg_1844 = ifn_1848.Invoke_O__O(arg_1849) } else { arg_1844 = linked_1847.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1846, arg_1849) }; var arg_1845 any; if linked_1842 == nil { return ifn_1843.Invoke_O_O__O(arg_1844, arg_1845) } else { return linked_1842.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1841, arg_1844, arg_1845) } } } else { var x__4 any; var root_1850 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_1851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1850, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1852 lang.IFn; if linked_1851 == nil { ifn_1852 = lang.IFn_Cast(root_1850) } else { ifn_1852 = nil }; var arg_1853 any = s__794000251__3; if linked_1851 == nil { x__4 = ifn_1852.Invoke_O__O(arg_1853) } else { x__4 = linked_1851.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1850, arg_1853) }; var nm__5 any; var root_1854 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1854, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1856 lang.IFn
														if linked_1855 == nil { ifn_1856 = lang.IFn_Cast(root_1854) } else { ifn_1856 = nil }; var arg_1857 any = x__4; var arg_1858 any = A_arbace_go_repl_A_const_55; if linked_1855 == nil { nm__5 = ifn_1856.Invoke_O_O__O(arg_1857, arg_1858) } else { nm__5 = linked_1855.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1854, arg_1857, arg_1858) }
//line :303:1
	var k__6 any; var root_1859 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var linked_1860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1859, A_arbace_go_repl_type_key_A_fn_class); var ifn_1861 lang.IFn

	if linked_1860 == nil { ifn_1861 = lang.IFn_Cast(root_1859) } else { ifn_1861 = nil }; var arg_1862 any; var root_1864 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1864, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1866 lang.IFn; if linked_1865 == nil { ifn_1866 = lang.IFn_Cast(root_1864) } else { ifn_1866 = nil }; var arg_1867 any = x__4; var arg_1868 any = A_arbace_go_repl_A_const_142; if linked_1865 == nil { arg_1862 = ifn_1866.Invoke_O_O__O(arg_1867, arg_1868) } else { arg_1862 = linked_1865.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1864, arg_1867, arg_1868) }; var arg_1863 any = A_arbace_go_repl_A_const_150.Invoke_O__O(t.F_ctx); if linked_1860 == nil { k__6 = ifn_1861.Invoke_O_O__O(arg_1862, arg_1863) } else { k__6 = linked_1860.(*A_arbace_go_repl_type_key_A).Invoke_O_O_O__O(root_1859, arg_1862, arg_1863) }
//line :303:1
	var prev__7 any; var root_1869 any = A_arbace_go_repl_A_const_152.GetRawRoot__O(); var linked_1870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1869, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1871 lang.IFn


	if linked_1870 == nil { ifn_1871 = lang.IFn_Cast(root_1869) } else { ifn_1871 = nil }; var arg_1872 any = t.F_old; var arg_1873 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_repl_A_const_60, nm__5); if linked_1870 == nil { prev__7 = ifn_1871.Invoke_O_O__O(arg_1872, arg_1873) } else { prev__7 = linked_1870.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1869, arg_1872, arg_1873) }
//line :303:1
	var root_1874 any = A_arbace_go_repl_A_const_100.GetRawRoot__O(); var linked_1875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1874, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1876 lang.IFn; if linked_1875 == nil { ifn_1876 = lang.IFn_Cast(root_1874) } else { ifn_1876 = nil }; var arg_1877 any; var tmp6 any
	var and__1927000168__auto____8 any = prev__7


	if jrt.J2g_Truth(and__1927000168__auto____8) { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(k__6, A_arbace_go_repl_A_const_178.Invoke_O__O(prev__7))).Ref() } else { tmp6 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_1879 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var linked_1880 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1879, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1881 lang.IFn
		if linked_1880 == nil { ifn_1881 = lang.IFn_Cast(root_1879) } else { ifn_1881 = nil }; var arg_1882 any = prev__7; var arg_1883 any = A_arbace_go_repl_A_const_177; var arg_1884 any = x__4; if linked_1880 == nil { tmp7 = ifn_1881.Invoke_O_O_O__O(arg_1882, arg_1883, arg_1884) } else { tmp7 = linked_1880.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1879, arg_1882, arg_1883, arg_1884) }
//line :307:1
		arg_1877 = lang.Tuple_Create_O_O__IPersistentVector(nm__5, tmp7) } else {

			var tmp8 *lang.Volatile = lang.Volatile_Cast(t.F_new_vars); var tmp9 any; var root_1885 any = A_arbace_go_repl_A_const_15.GetRawRoot__O(); var linked_1886 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1885, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1887 lang.IFn; if linked_1886 == nil { ifn_1887 = lang.IFn_Cast(root_1885) } else { ifn_1887 = nil }; var arg_1888 any = jrt.NN(lang.Volatile_Cast(t.F_new_vars)).Deref__O(); var arg_1889 any = nm__5; if linked_1886 == nil { tmp9 = ifn_1887.Invoke_O_O__O(arg_1888, arg_1889) } else { tmp9 = linked_1886.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1885, arg_1888, arg_1889) }; jrt.NN(tmp8).Reset_O__O(tmp9)
//line :307:1
			var tmp10 any = A_arbace_go_repl_A_const_186; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_179.GetRawRoot__O()); var tmp12 any; var root_1895 any = A_arbace_go_repl_A_const_187.GetRawRoot__O(); var linked_1896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1895, aot_arbace_go_build.A_arbace_go_build_desc_A_fn_class); var ifn_1897 lang.IFn


			if linked_1896 == nil { ifn_1897 = lang.IFn_Cast(root_1895) } else { ifn_1897 = nil }; var arg_1898 any; var root_1899 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1899, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1901 lang.IFn; if linked_1900 == nil { ifn_1901 = lang.IFn_Cast(root_1899) } else { ifn_1901 = nil }; var arg_1902 any = x__4; var arg_1903 any = A_arbace_go_repl_A_const_142; if linked_1900 == nil { arg_1898 = ifn_1901.Invoke_O_O__O(arg_1902, arg_1903) } else { arg_1898 = linked_1900.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1899, arg_1902, arg_1903) }; if linked_1896 == nil { tmp12 = ifn_1897.Invoke_O__O(arg_1898) } else { tmp12 = linked_1896.(*aot_arbace_go_build.A_arbace_go_build_desc_A).Invoke_O_O__O(root_1895, arg_1898) }
//line :307:1
			var tmp13 any = tmp11.Invoke_O_O__O(Lit_106, tmp12); var tmp14 any = A_arbace_go_repl_A_const_178; var tmp15 any = A_arbace_go_repl_A_const_177; var tmp16 any = A_arbace_go_repl_A_const_142; var tmp17 any; var root_1904 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1904, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1906 lang.IFn


			if linked_1905 == nil { ifn_1906 = lang.IFn_Cast(root_1904) } else { ifn_1906 = nil }; var arg_1907 any = x__4; var arg_1908 any = A_arbace_go_repl_A_const_142; if linked_1905 == nil { tmp17 = ifn_1906.Invoke_O_O__O(arg_1907, arg_1908) } else { tmp17 = linked_1905.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1904, arg_1907, arg_1908) }
//line :307:1
			arg_1877 = lang.Tuple_Create_O_O__IPersistentVector(nm__5, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp13, tmp14, k__6, tmp15, x__4, tmp16, tmp17))) }
//line :303:1
	var arg_1878 any; var tmp18 lang.IFn = lang.IFn_Cast(t.F_iter__794000250); var tmp19 any; var root_1909 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_1910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1909, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1911 lang.IFn; if linked_1910 == nil { ifn_1911 = lang.IFn_Cast(root_1909) } else { ifn_1911 = nil }; var arg_1912 any = s__794000251__3; if linked_1910 == nil { tmp19 = ifn_1911.Invoke_O__O(arg_1912) } else { tmp19 = linked_1910.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1909, arg_1912) }; arg_1878 = tmp18.Invoke_O__O(tmp19); if linked_1875 == nil { return ifn_1876.Invoke_O_O__O(arg_1877, arg_1878) } else { return linked_1875.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1874, arg_1877, arg_1878) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :303:1
func A_arbace_go_repl_define_BANG__iter__794000250__794000254_fn__794000255_fn__794000256_A_New_O_O_O_I_O_O(p0, p1, p2 any, p3 int32, p4, p5 any) *A_arbace_go_repl_define_BANG__iter__794000250__794000254_fn__794000255_fn__794000256_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000250__794000254_fn__794000255_fn__794000256_A{}; t.Ctor_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :303:1
func (t *A_arbace_go_repl_define_BANG__iter__794000250__794000254_fn__794000255_fn__794000256_A) Ctor_O_O_O_I_O_O(c__b__794000253, c__new_vars, c__old any, c__size__1927001038__auto__ int32, c__ctx, c__c__1927001037__auto__ any) { t.F_b__794000253 = c__b__794000253; t.F_new_vars = c__new_vars; t.F_old = c__old; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_ctx = c__ctx; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :303:1
func (t *A_arbace_go_repl_define_BANG__iter__794000250__794000254_fn__794000255_fn__794000256_A) Invoke_O__O(self any) any { { var i__794000252__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__794000252__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var x__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__794000252__1)); var nm__3 any; var root_1772 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1772, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1774 lang.IFn
																if linked_1773 == nil { ifn_1774 = lang.IFn_Cast(root_1772) } else { ifn_1774 = nil }; var arg_1775 any = x__2; var arg_1776 any = A_arbace_go_repl_A_const_55; if linked_1773 == nil { nm__3 = ifn_1774.Invoke_O_O__O(arg_1775, arg_1776) } else { nm__3 = linked_1773.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1772, arg_1775, arg_1776) }
//line :303:1
	var k__4 any; var root_1777 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var linked_1778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1777, A_arbace_go_repl_type_key_A_fn_class); var ifn_1779 lang.IFn

	if linked_1778 == nil { ifn_1779 = lang.IFn_Cast(root_1777) } else { ifn_1779 = nil }; var arg_1780 any; var root_1782 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1782, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1784 lang.IFn; if linked_1783 == nil { ifn_1784 = lang.IFn_Cast(root_1782) } else { ifn_1784 = nil }; var arg_1785 any = x__2; var arg_1786 any = A_arbace_go_repl_A_const_142; if linked_1783 == nil { arg_1780 = ifn_1784.Invoke_O_O__O(arg_1785, arg_1786) } else { arg_1780 = linked_1783.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1782, arg_1785, arg_1786) }; var arg_1781 any = A_arbace_go_repl_A_const_150.Invoke_O__O(t.F_ctx); if linked_1778 == nil { k__4 = ifn_1779.Invoke_O_O__O(arg_1780, arg_1781) } else { k__4 = linked_1778.(*A_arbace_go_repl_type_key_A).Invoke_O_O_O__O(root_1777, arg_1780, arg_1781) }
//line :303:1
	var prev__5 any; var root_1787 any = A_arbace_go_repl_A_const_152.GetRawRoot__O(); var linked_1788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1787, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1789 lang.IFn


	if linked_1788 == nil { ifn_1789 = lang.IFn_Cast(root_1787) } else { ifn_1789 = nil }; var arg_1790 any = t.F_old; var arg_1791 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_repl_A_const_60, nm__3); if linked_1788 == nil { prev__5 = ifn_1789.Invoke_O_O__O(arg_1790, arg_1791) } else { prev__5 = linked_1788.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1787, arg_1790, arg_1791) }
//line :303:1
	var root_1792 any = A_arbace_go_repl_A_const_96.GetRawRoot__O(); var linked_1793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1792, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1794 lang.IFn; if linked_1793 == nil { ifn_1794 = lang.IFn_Cast(root_1792) } else { ifn_1794 = nil }; var arg_1795 any = t.F_b__794000253; var arg_1796 any; var tmp2 any
	var and__1927000168__auto____6 any = prev__5


	if jrt.J2g_Truth(and__1927000168__auto____6) { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(k__4, A_arbace_go_repl_A_const_178.Invoke_O__O(prev__5))).Ref() } else { tmp2 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_1797 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var linked_1798 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1797, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1799 lang.IFn
		if linked_1798 == nil { ifn_1799 = lang.IFn_Cast(root_1797) } else { ifn_1799 = nil }; var arg_1800 any = prev__5; var arg_1801 any = A_arbace_go_repl_A_const_177; var arg_1802 any = x__2; if linked_1798 == nil { tmp3 = ifn_1799.Invoke_O_O_O__O(arg_1800, arg_1801, arg_1802) } else { tmp3 = linked_1798.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1797, arg_1800, arg_1801, arg_1802) }
//line :307:1
		arg_1796 = lang.Tuple_Create_O_O__IPersistentVector(nm__3, tmp3) } else {

			var tmp4 *lang.Volatile = lang.Volatile_Cast(t.F_new_vars); var tmp5 any; var root_1803 any = A_arbace_go_repl_A_const_15.GetRawRoot__O(); var linked_1804 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1803, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1805 lang.IFn; if linked_1804 == nil { ifn_1805 = lang.IFn_Cast(root_1803) } else { ifn_1805 = nil }; var arg_1806 any = jrt.NN(lang.Volatile_Cast(t.F_new_vars)).Deref__O(); var arg_1807 any = nm__3; if linked_1804 == nil { tmp5 = ifn_1805.Invoke_O_O__O(arg_1806, arg_1807) } else { tmp5 = linked_1804.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1803, arg_1806, arg_1807) }; jrt.NN(tmp4).Reset_O__O(tmp5)
//line :307:1
			var tmp6 any = A_arbace_go_repl_A_const_186; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_179.GetRawRoot__O()); var tmp8 any; var root_1813 any = A_arbace_go_repl_A_const_187.GetRawRoot__O(); var linked_1814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1813, aot_arbace_go_build.A_arbace_go_build_desc_A_fn_class); var ifn_1815 lang.IFn


			if linked_1814 == nil { ifn_1815 = lang.IFn_Cast(root_1813) } else { ifn_1815 = nil }; var arg_1816 any; var root_1817 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1817, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1819 lang.IFn; if linked_1818 == nil { ifn_1819 = lang.IFn_Cast(root_1817) } else { ifn_1819 = nil }; var arg_1820 any = x__2; var arg_1821 any = A_arbace_go_repl_A_const_142; if linked_1818 == nil { arg_1816 = ifn_1819.Invoke_O_O__O(arg_1820, arg_1821) } else { arg_1816 = linked_1818.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1817, arg_1820, arg_1821) }; if linked_1814 == nil { tmp8 = ifn_1815.Invoke_O__O(arg_1816) } else { tmp8 = linked_1814.(*aot_arbace_go_build.A_arbace_go_build_desc_A).Invoke_O_O__O(root_1813, arg_1816) }
//line :307:1
			var tmp9 any = tmp7.Invoke_O_O__O(Lit_106, tmp8); var tmp10 any = A_arbace_go_repl_A_const_178; var tmp11 any = A_arbace_go_repl_A_const_177; var tmp12 any = A_arbace_go_repl_A_const_142; var tmp13 any; var root_1822 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1822, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1824 lang.IFn


			if linked_1823 == nil { ifn_1824 = lang.IFn_Cast(root_1822) } else { ifn_1824 = nil }; var arg_1825 any = x__2; var arg_1826 any = A_arbace_go_repl_A_const_142; if linked_1823 == nil { tmp13 = ifn_1824.Invoke_O_O__O(arg_1825, arg_1826) } else { tmp13 = linked_1823.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1822, arg_1825, arg_1826) }
//line :307:1
			arg_1796 = lang.Tuple_Create_O_O__IPersistentVector(nm__3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp9, tmp10, k__4, tmp11, x__2, tmp12, tmp13))) }
//line :303:1
	if linked_1793 == nil { ifn_1794.Invoke_O_O__O(arg_1795, arg_1796) } else { linked_1793.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1792, arg_1795, arg_1796) }; i__794000252__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000252__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }













func A_arbace_go_repl_define_BANG__fn__794000269_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__fn__794000269_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000269_A{}; t.Ctor_O(p0); return t }
//line :317:1
func (t *A_arbace_go_repl_define_BANG__fn__794000269_A) Ctor_O(c__tree any) { t.F_tree = c__tree }
//line :317:1
func (t *A_arbace_go_repl_define_BANG__fn__794000269_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_2359 any = A_arbace_go_repl_A_const_202.GetRawRoot__O(); var linked_2360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2359, aot_arbace_go_build.A_arbace_go_build_build_func_A_fn_class); var ifn_2361 lang.IFn; if linked_2360 == nil { ifn_2361 = lang.IFn_Cast(root_2359) } else { ifn_2361 = nil }; var arg_2362 any; var t_ any = t.F_tree; t.F_tree = nil; arg_2362 = t_; if linked_2360 == nil { tmp1 = ifn_2361.Invoke_O__O(arg_2362) } else { tmp1 = linked_2360.(*aot_arbace_go_build.A_arbace_go_build_build_func_A).Invoke_O_O__O(root_2359, arg_2362) } }; return nil }(); var root_2363 any = A_arbace_go_repl_A_const_196.GetRawRoot__O(); var linked_2364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2363, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2365 lang.IFn; if linked_2364 == nil { ifn_2365 = lang.IFn_Cast(root_2363) } else { ifn_2365 = nil }; if linked_2364 == nil { ifn_2365.Invoke__O() } else { linked_2364.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2363) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }
//line :317:1
func A_arbace_go_repl_define_BANG__fn__794000278_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__fn__794000278_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000278_A{}; t.Ctor_O(p0); return t }
//line :317:1
func (t *A_arbace_go_repl_define_BANG__fn__794000278_A) Ctor_O(c__tree any) { t.F_tree = c__tree }
//line :317:1
func (t *A_arbace_go_repl_define_BANG__fn__794000278_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_2411 any = A_arbace_go_repl_A_const_202.GetRawRoot__O(); var linked_2412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2411, aot_arbace_go_build.A_arbace_go_build_build_func_A_fn_class); var ifn_2413 lang.IFn; if linked_2412 == nil { ifn_2413 = lang.IFn_Cast(root_2411) } else { ifn_2413 = nil }; var arg_2414 any; var t_ any = t.F_tree; t.F_tree = nil; arg_2414 = t_; if linked_2412 == nil { tmp1 = ifn_2413.Invoke_O__O(arg_2414) } else { tmp1 = linked_2412.(*aot_arbace_go_build.A_arbace_go_build_build_func_A).Invoke_O_O__O(root_2411, arg_2414) } }; return nil }(); var root_2415 any = A_arbace_go_repl_A_const_196.GetRawRoot__O(); var linked_2416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2415, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2417 lang.IFn; if linked_2416 == nil { ifn_2417 = lang.IFn_Cast(root_2415) } else { ifn_2417 = nil }; if linked_2416 == nil { ifn_2417.Invoke__O() } else { linked_2416.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2415) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }
func A_arbace_go_repl_define_BANG__fn__794000271_A_New_O_O(p0, p1 any) *A_arbace_go_repl_define_BANG__fn__794000271_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000271_A{}; t.Ctor_O_O(p0, p1); return t }
//line :318:1
func (t *A_arbace_go_repl_define_BANG__fn__794000271_A) Ctor_O_O(c__ctx, c__tree any) { t.F_ctx = c__ctx; t.F_tree = c__tree }
//line :318:1
func (t *A_arbace_go_repl_define_BANG__fn__794000271_A) Invoke_O__O(self any) any { var root_2390 any = A_arbace_go_repl_A_const_198.GetRawRoot__O(); var linked_2391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2390, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2392 lang.IFn; if linked_2391 == nil { ifn_2392 = lang.IFn_Cast(root_2390) } else { ifn_2392 = nil }; var arg_2393 any = lang.IFn_Cast(A_arbace_go_repl_A_const_38.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_repl_A_const_199, t.F_ctx); if linked_2391 == nil { ifn_2392.Invoke_O__O(arg_2393) } else { linked_2391.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2390, arg_2393) }; var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_2383 any = A_arbace_go_repl_A_const_202.GetRawRoot__O(); var linked_2384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2383, aot_arbace_go_build.A_arbace_go_build_build_func_A_fn_class); var ifn_2385 lang.IFn; if linked_2384 == nil { ifn_2385 = lang.IFn_Cast(root_2383) } else { ifn_2385 = nil }; var arg_2386 any = t.F_tree; if linked_2384 == nil { tmp1 = ifn_2385.Invoke_O__O(arg_2386) } else { tmp1 = linked_2384.(*aot_arbace_go_build.A_arbace_go_build_build_func_A).Invoke_O_O__O(root_2383, arg_2386) } }; return nil }(); var root_2387 any = A_arbace_go_repl_A_const_196.GetRawRoot__O(); var linked_2388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2387, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2389 lang.IFn; if linked_2388 == nil { ifn_2389 = lang.IFn_Cast(root_2387) } else { ifn_2389 = nil }; if linked_2388 == nil { ifn_2389.Invoke__O() } else { linked_2388.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2387) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }
//line :318:1
func A_arbace_go_repl_define_BANG__fn__794000280_A_New_O_O(p0, p1 any) *A_arbace_go_repl_define_BANG__fn__794000280_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000280_A{}; t.Ctor_O_O(p0, p1); return t }
//line :318:1
func (t *A_arbace_go_repl_define_BANG__fn__794000280_A) Ctor_O_O(c__tree, c__ctx any) { t.F_tree = c__tree; t.F_ctx = c__ctx }
//line :318:1
func (t *A_arbace_go_repl_define_BANG__fn__794000280_A) Invoke_O__O(self any) any { var root_2442 any = A_arbace_go_repl_A_const_198.GetRawRoot__O(); var linked_2443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2442, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2444 lang.IFn; if linked_2443 == nil { ifn_2444 = lang.IFn_Cast(root_2442) } else { ifn_2444 = nil }; var arg_2445 any = lang.IFn_Cast(A_arbace_go_repl_A_const_38.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_repl_A_const_199, t.F_ctx); if linked_2443 == nil { ifn_2444.Invoke_O__O(arg_2445) } else { linked_2443.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2442, arg_2445) }; var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_2435 any = A_arbace_go_repl_A_const_202.GetRawRoot__O(); var linked_2436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2435, aot_arbace_go_build.A_arbace_go_build_build_func_A_fn_class); var ifn_2437 lang.IFn; if linked_2436 == nil { ifn_2437 = lang.IFn_Cast(root_2435) } else { ifn_2437 = nil }; var arg_2438 any = t.F_tree; if linked_2436 == nil { tmp1 = ifn_2437.Invoke_O__O(arg_2438) } else { tmp1 = linked_2436.(*aot_arbace_go_build.A_arbace_go_build_build_func_A).Invoke_O_O__O(root_2435, arg_2438) } }; return nil }(); var root_2439 any = A_arbace_go_repl_A_const_196.GetRawRoot__O(); var linked_2440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2439, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2441 lang.IFn; if linked_2440 == nil { ifn_2441 = lang.IFn_Cast(root_2439) } else { ifn_2441 = nil }; if linked_2440 == nil { ifn_2441.Invoke__O() } else { linked_2440.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2439) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }

func A_arbace_go_repl_define_BANG__fn__794000288_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__fn__794000288_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000288_A{}; t.Ctor_O(p0); return t }
//line :320:1
func (t *A_arbace_go_repl_define_BANG__fn__794000288_A) Ctor_O(c__tree any) { t.F_tree = c__tree }
//line :320:1
func (t *A_arbace_go_repl_define_BANG__fn__794000288_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_2471 any = A_arbace_go_repl_A_const_202.GetRawRoot__O(); var linked_2472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2471, aot_arbace_go_build.A_arbace_go_build_build_func_A_fn_class); var ifn_2473 lang.IFn; if linked_2472 == nil { ifn_2473 = lang.IFn_Cast(root_2471) } else { ifn_2473 = nil }; var arg_2474 any; var t_ any = t.F_tree; t.F_tree = nil; arg_2474 = t_; if linked_2472 == nil { tmp1 = ifn_2473.Invoke_O__O(arg_2474) } else { tmp1 = linked_2472.(*aot_arbace_go_build.A_arbace_go_build_build_func_A).Invoke_O_O__O(root_2471, arg_2474) } }; return nil }(); var root_2475 any = A_arbace_go_repl_A_const_196.GetRawRoot__O(); var linked_2476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2475, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2477 lang.IFn; if linked_2476 == nil { ifn_2477 = lang.IFn_Cast(root_2475) } else { ifn_2477 = nil }; if linked_2476 == nil { ifn_2477.Invoke__O() } else { linked_2476.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2475) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }
//line :320:1
func A_arbace_go_repl_define_BANG__fn__794000292_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__fn__794000292_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000292_A{}; t.Ctor_O(p0); return t }
//line :320:1
func (t *A_arbace_go_repl_define_BANG__fn__794000292_A) Ctor_O(c__tree any) { t.F_tree = c__tree }
//line :320:1
func (t *A_arbace_go_repl_define_BANG__fn__794000292_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_2499 any = A_arbace_go_repl_A_const_202.GetRawRoot__O(); var linked_2500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2499, aot_arbace_go_build.A_arbace_go_build_build_func_A_fn_class); var ifn_2501 lang.IFn; if linked_2500 == nil { ifn_2501 = lang.IFn_Cast(root_2499) } else { ifn_2501 = nil }; var arg_2502 any; var t_ any = t.F_tree; t.F_tree = nil; arg_2502 = t_; if linked_2500 == nil { tmp1 = ifn_2501.Invoke_O__O(arg_2502) } else { tmp1 = linked_2500.(*aot_arbace_go_build.A_arbace_go_build_build_func_A).Invoke_O_O__O(root_2499, arg_2502) } }; return nil }(); var root_2503 any = A_arbace_go_repl_A_const_196.GetRawRoot__O(); var linked_2504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2503, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2505 lang.IFn; if linked_2504 == nil { ifn_2505 = lang.IFn_Cast(root_2503) } else { ifn_2505 = nil }; if linked_2504 == nil { ifn_2505.Invoke__O() } else { linked_2504.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2503) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }



func A_arbace_go_repl_define_BANG__iter__794000294__794000298_A_New() *A_arbace_go_repl_define_BANG__iter__794000294__794000298_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000294__794000298_A{}; t.Ctor(); return t }
//line :324:1
func (t *A_arbace_go_repl_define_BANG__iter__794000294__794000298_A) Ctor() {}
//line :324:1
func (t *A_arbace_go_repl_define_BANG__iter__794000294__794000298_A) Invoke_O_O__O(self, s__794000295__1 any) any { var tmp1 any = A_arbace_go_repl_define_BANG__iter__794000294__794000298_fn__794000299_A_New_O_O(self, s__794000295__1); var tmp2 *jrt.Class; var fncls__1997 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000294__794000298_fn__794000299_A_fn_class; if fncls__1997 == nil { var fncls__1997d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_107, false); A_arbace_go_repl_define_BANG__iter__794000294__794000298_fn__794000299_A_fn_class = fncls__1997d; tmp2 = fncls__1997d } else { tmp2 = fncls__1997 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :324:1
func A_arbace_go_repl_define_BANG__iter__794000294__794000298_fn__794000299_A_New_O_O(p0, p1 any) *A_arbace_go_repl_define_BANG__iter__794000294__794000298_fn__794000299_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000294__794000298_fn__794000299_A{}; t.Ctor_O_O(p0, p1); return t }
//line :324:1
func (t *A_arbace_go_repl_define_BANG__iter__794000294__794000298_fn__794000299_A) Ctor_O_O(c__iter__794000294, c__s__794000295 any) { t.F_iter__794000294 = c__iter__794000294; t.F_s__794000295 = c__s__794000295 }
//line :324:1
func (t *A_arbace_go_repl_define_BANG__iter__794000294__794000298_fn__794000299_A) Invoke_O__O(self any) any { { var s__794000295__1 any; var t_ any = t.F_s__794000295; t.F_s__794000295 = nil; s__794000295__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1924 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_1925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1924, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1926 lang.IFn; if linked_1925 == nil { ifn_1926 = lang.IFn_Cast(root_1924) } else { ifn_1926 = nil }; var arg_1927 any = s__794000295__1; if linked_1925 == nil { temp__1927000414__auto____2 = ifn_1926.Invoke_O__O(arg_1927) } else { temp__1927000414__auto____2 = linked_1925.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1924, arg_1927) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__794000295__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1928 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_1929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1928, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1930 lang.IFn; if linked_1929 == nil { ifn_1930 = lang.IFn_Cast(root_1928) } else { ifn_1930 = nil }; var arg_1931 any = s__794000295__3; if linked_1929 == nil { tmp1 = ifn_1930.Invoke_O__O(arg_1931) } else { tmp1 = linked_1929.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1928, arg_1931) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1932 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_1933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1932, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1934 lang.IFn; if linked_1933 == nil { ifn_1934 = lang.IFn_Cast(root_1932) } else { ifn_1934 = nil }; var arg_1935 any = s__794000295__3; if linked_1933 == nil { c__1927001037__auto____4 = ifn_1934.Invoke_O__O(arg_1935) } else { c__1927001037__auto____4 = linked_1933.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1932, arg_1935) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__794000297__6 any; var root_1936 any = A_arbace_go_repl_A_const_95.GetRawRoot__O(); var linked_1937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1936, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1938 lang.IFn; if linked_1937 == nil { ifn_1938 = lang.IFn_Cast(root_1936) } else { ifn_1938 = nil }; var arg_1939 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1937 == nil { b__794000297__6 = ifn_1938.Invoke_O__O(arg_1939) } else { b__794000297__6 = linked_1937.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1936, arg_1939) }; var tmp2 any = A_arbace_go_repl_define_BANG__iter__794000294__794000298_fn__794000299_fn__794000300_A_New_O_I_O(b__794000297__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1949 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000294__794000298_fn__794000299_fn__794000300_A_fn_class; if fncls__1949 == nil { var fncls__1949d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_108, false); A_arbace_go_repl_define_BANG__iter__794000294__794000298_fn__794000299_fn__794000300_A_fn_class = fncls__1949d; tmp3 = fncls__1949d } else { tmp3 = fncls__1949 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1950 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_1951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1950, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1952 lang.IFn; if linked_1951 == nil { ifn_1952 = lang.IFn_Cast(root_1950) } else { ifn_1952 = nil }; var arg_1953 any; var root_1955 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_1956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1955, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1957 lang.IFn; if linked_1956 == nil { ifn_1957 = lang.IFn_Cast(root_1955) } else { ifn_1957 = nil }; var arg_1958 any = b__794000297__6; if linked_1956 == nil { arg_1953 = ifn_1957.Invoke_O__O(arg_1958) } else { arg_1953 = linked_1956.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1955, arg_1958) }; var arg_1954 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__794000294); var tmp5 any; var root_1959 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_1960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1959, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1961 lang.IFn; if linked_1960 == nil { ifn_1961 = lang.IFn_Cast(root_1959) } else { ifn_1961 = nil }; var arg_1962 any = s__794000295__3; if linked_1960 == nil { tmp5 = ifn_1961.Invoke_O__O(arg_1962) } else { tmp5 = linked_1960.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1959, arg_1962) }; arg_1954 = tmp4.Invoke_O__O(tmp5); if linked_1951 == nil { return ifn_1952.Invoke_O_O__O(arg_1953, arg_1954) } else { return linked_1951.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1950, arg_1953, arg_1954) } } else { var root_1963 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_1964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1963, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1965 lang.IFn; if linked_1964 == nil { ifn_1965 = lang.IFn_Cast(root_1963) } else { ifn_1965 = nil }; var arg_1966 any; var root_1968 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_1969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1968, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1970 lang.IFn; if linked_1969 == nil { ifn_1970 = lang.IFn_Cast(root_1968) } else { ifn_1970 = nil }; var arg_1971 any = b__794000297__6; if linked_1969 == nil { arg_1966 = ifn_1970.Invoke_O__O(arg_1971) } else { arg_1966 = linked_1969.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1968, arg_1971) }; var arg_1967 any; if linked_1964 == nil { return ifn_1965.Invoke_O_O__O(arg_1966, arg_1967) } else { return linked_1964.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1963, arg_1966, arg_1967) } } } else { var d__4 any; var root_1972 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_1973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1972, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1974 lang.IFn; if linked_1973 == nil { ifn_1974 = lang.IFn_Cast(root_1972) } else { ifn_1974 = nil }; var arg_1975 any = s__794000295__3; if linked_1973 == nil { d__4 = ifn_1974.Invoke_O__O(arg_1975) } else { d__4 = linked_1973.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1972, arg_1975) }; var tmp6 any = A_arbace_go_repl_A_const_183; if lang.Util_Equiv_O_O__Z_NoInit(tmp6, A_arbace_go_repl_A_const_174.Invoke_O__O(d__4)) { var tmp7 any = A_arbace_go_repl_A_const_188; var tmp8 *lang.Keyword = A_arbace_go_repl_A_const_189; if lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8.Invoke_O__O(A_arbace_go_repl_A_const_181.Invoke_O__O(d__4))) { var root_1976 any = A_arbace_go_repl_A_const_100.GetRawRoot__O(); var linked_1977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1976, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1978 lang.IFn; if linked_1977 == nil { ifn_1978 = lang.IFn_Cast(root_1976) } else { ifn_1978 = nil }; var arg_1979 any; var tmp9 any; var root_1981 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_1982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1981, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1983 lang.IFn
														if linked_1982 == nil { ifn_1983 = lang.IFn_Cast(root_1981) } else { ifn_1983 = nil }; var tmp10 *lang.Keyword = A_arbace_go_repl_A_const_184; var arg_1984 any = tmp10.Invoke_O__O(A_arbace_go_repl_A_const_181.Invoke_O__O(d__4)); if linked_1982 == nil { tmp9 = ifn_1983.Invoke_O__O(arg_1984) } else { tmp9 = linked_1982.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1981, arg_1984) }
//line :324:1
	arg_1979 = lang.Tuple_Create_O_O__IPersistentVector(tmp9, A_arbace_go_repl_A_const_181.Invoke_O__O(d__4)); var arg_1980 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__794000294); var tmp12 any; var root_1985 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_1986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1985, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1987 lang.IFn; if linked_1986 == nil { ifn_1987 = lang.IFn_Cast(root_1985) } else { ifn_1987 = nil }; var arg_1988 any = s__794000295__3; if linked_1986 == nil { tmp12 = ifn_1987.Invoke_O__O(arg_1988) } else { tmp12 = linked_1986.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1985, arg_1988) }; arg_1980 = tmp11.Invoke_O__O(tmp12); if linked_1977 == nil { return ifn_1978.Invoke_O_O__O(arg_1979, arg_1980) } else { return linked_1977.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1976, arg_1979, arg_1980) } } else { var tmp13 any; var root_1989 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_1990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1989, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1991 lang.IFn; if linked_1990 == nil { ifn_1991 = lang.IFn_Cast(root_1989) } else { ifn_1991 = nil }; var arg_1992 any = s__794000295__3; if linked_1990 == nil { tmp13 = ifn_1991.Invoke_O__O(arg_1992) } else { tmp13 = linked_1990.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1989, arg_1992) }; s__794000295__1 = tmp13; continue L1 } } else { var tmp14 any; var root_1993 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_1994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1993, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1995 lang.IFn; if linked_1994 == nil { ifn_1995 = lang.IFn_Cast(root_1993) } else { ifn_1995 = nil }; var arg_1996 any = s__794000295__3; if linked_1994 == nil { tmp14 = ifn_1995.Invoke_O__O(arg_1996) } else { tmp14 = linked_1994.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1993, arg_1996) }; s__794000295__1 = tmp14; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :324:1
func A_arbace_go_repl_define_BANG__iter__794000294__794000298_fn__794000299_fn__794000300_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_repl_define_BANG__iter__794000294__794000298_fn__794000299_fn__794000300_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000294__794000298_fn__794000299_fn__794000300_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :324:1
func (t *A_arbace_go_repl_define_BANG__iter__794000294__794000298_fn__794000299_fn__794000300_A) Ctor_O_I_O(c__b__794000297 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__794000297 = c__b__794000297; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :324:1
func (t *A_arbace_go_repl_define_BANG__iter__794000294__794000298_fn__794000299_fn__794000300_A) Invoke_O__O(self any) any { { var i__794000296__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__794000296__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var d__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__794000296__1)); var tmp2 any = A_arbace_go_repl_A_const_183; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_go_repl_A_const_174.Invoke_O__O(d__2)) { var tmp3 any = A_arbace_go_repl_A_const_188; var tmp4 *lang.Keyword = A_arbace_go_repl_A_const_189; if lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4.Invoke_O__O(A_arbace_go_repl_A_const_181.Invoke_O__O(d__2))) { var root_1940 any = A_arbace_go_repl_A_const_96.GetRawRoot__O(); var linked_1941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1940, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1942 lang.IFn; if linked_1941 == nil { ifn_1942 = lang.IFn_Cast(root_1940) } else { ifn_1942 = nil }; var arg_1943 any = t.F_b__794000297; var arg_1944 any; var tmp5 any; var root_1945 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_1946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1945, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1947 lang.IFn
																if linked_1946 == nil { ifn_1947 = lang.IFn_Cast(root_1945) } else { ifn_1947 = nil }; var tmp6 *lang.Keyword = A_arbace_go_repl_A_const_184; var arg_1948 any = tmp6.Invoke_O__O(A_arbace_go_repl_A_const_181.Invoke_O__O(d__2)); if linked_1946 == nil { tmp5 = ifn_1947.Invoke_O__O(arg_1948) } else { tmp5 = linked_1946.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1945, arg_1948) }
//line :324:1
	arg_1944 = lang.Tuple_Create_O_O__IPersistentVector(tmp5, A_arbace_go_repl_A_const_181.Invoke_O__O(d__2)); if linked_1941 == nil { ifn_1942.Invoke_O_O__O(arg_1943, arg_1944) } else { linked_1941.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1940, arg_1943, arg_1944) }; i__794000296__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000296__1); continue L1 } else { i__794000296__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000296__1); continue L1 } } else { i__794000296__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000296__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_repl_define_BANG__fn__794000304_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__fn__794000304_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000304_A{}; t.Ctor_O(p0); return t }
//line :326:1
func (t *A_arbace_go_repl_define_BANG__fn__794000304_A) Ctor_O(c__var_trees any) { t.F_var_trees = c__var_trees }
//line :326:1
func (t *A_arbace_go_repl_define_BANG__fn__794000304_A) Invoke_O_O__O(self, p1__794000184_SHARP___1 any) any { var tmp1 any = t.F_var_trees; var tmp2 any; var root_2004 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2004, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2006 lang.IFn; if linked_2005 == nil { ifn_2006 = lang.IFn_Cast(root_2004) } else { ifn_2006 = nil }; var arg_2007 any = p1__794000184_SHARP___1; if linked_2005 == nil { tmp2 = ifn_2006.Invoke_O__O(arg_2007) } else { tmp2 = linked_2005.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2004, arg_2007) }; return lang.RT_Get_O_O__O_NoInit(tmp1, tmp2) }


func A_arbace_go_repl_define_BANG__fn__794000306_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__fn__794000306_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000306_A{}; t.Ctor_O(p0); return t }
//line :329:1
func (t *A_arbace_go_repl_define_BANG__fn__794000306_A) Ctor_O(c__names any) { t.F_names = c__names }
//line :329:1
func (t *A_arbace_go_repl_define_BANG__fn__794000306_A) Invoke_O_O__O(self, p1__794000185_SHARP___1 any) any { var root_2021 any = A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_2022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2021, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2023 lang.IFn; if linked_2022 == nil { ifn_2023 = lang.IFn_Cast(root_2021) } else { ifn_2023 = nil }; var arg_2024 any; var tmp1 any = A_arbace_go_repl_define_BANG__fn__794000306_fn__794000307_A_New_O(t.F_names); var tmp2 *jrt.Class; var fncls__2036 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000306_fn__794000307_A_fn_class; if fncls__2036 == nil { var fncls__2036d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_go_repl_define_BANG__fn__794000306_fn__794000307_A_fn_class = fncls__2036d; tmp2 = fncls__2036d } else { tmp2 = fncls__2036 }; arg_2024 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_2025 any = A_arbace_go_repl_A_const_184.Invoke_O__O(p1__794000185_SHARP___1); if linked_2022 == nil { return ifn_2023.Invoke_O_O__O(arg_2024, arg_2025) } else { return linked_2022.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2021, arg_2024, arg_2025) } }
//line :329:1
func A_arbace_go_repl_define_BANG__fn__794000306_fn__794000307_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__fn__794000306_fn__794000307_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000306_fn__794000307_A{}; t.Ctor_O(p0); return t }
//line :329:1
func (t *A_arbace_go_repl_define_BANG__fn__794000306_fn__794000307_A) Ctor_O(c__names any) { t.F_names = c__names }
//line :329:1
func (t *A_arbace_go_repl_define_BANG__fn__794000306_fn__794000307_A) Invoke_O_O__O(self, x__1 any) any { var root_2026 any = A_arbace_go_repl_A_const_18.GetRawRoot__O(); var linked_2027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2026, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2028 lang.IFn; if linked_2027 == nil { ifn_2028 = lang.IFn_Cast(root_2026) } else { ifn_2028 = nil }; var arg_2029 any = t.F_names; var arg_2030 any; var root_2031 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2031, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2033 lang.IFn; if linked_2032 == nil { ifn_2033 = lang.IFn_Cast(root_2031) } else { ifn_2033 = nil }; var arg_2034 any = x__1; var arg_2035 any = A_arbace_go_repl_A_const_55; if linked_2032 == nil { arg_2030 = ifn_2033.Invoke_O_O__O(arg_2034, arg_2035) } else { arg_2030 = linked_2032.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2031, arg_2034, arg_2035) }; if linked_2027 == nil { return ifn_2028.Invoke_O_O__O(arg_2029, arg_2030) } else { return linked_2027.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2026, arg_2029, arg_2030) } }






func A_arbace_go_repl_define_BANG__fn__794000319_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__fn__794000319_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000319_A{}; t.Ctor_O(p0); return t }
//line :336:1
func (t *A_arbace_go_repl_define_BANG__fn__794000319_A) Ctor_O(c__obj any) { t.F_obj = c__obj }
//line :336:1
func (t *A_arbace_go_repl_define_BANG__fn__794000319_A) Invoke_O_O__O(self, p1__794000186_SHARP___1 any) any { if lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_repl_A_const_177.Invoke_O__O(p1__794000186_SHARP___1), t.F_obj) { return A_arbace_go_repl_A_const_209.Invoke_O__O(p1__794000186_SHARP___1) } else { return nil } }
//line :336:1
func A_arbace_go_repl_define_BANG__fn__794000327_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__fn__794000327_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000327_A{}; t.Ctor_O(p0); return t }
//line :336:1
func (t *A_arbace_go_repl_define_BANG__fn__794000327_A) Ctor_O(c__obj any) { t.F_obj = c__obj }
//line :336:1
func (t *A_arbace_go_repl_define_BANG__fn__794000327_A) Invoke_O_O__O(self, p1__794000186_SHARP___1 any) any { if lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_repl_A_const_177.Invoke_O__O(p1__794000186_SHARP___1), t.F_obj) { return A_arbace_go_repl_A_const_209.Invoke_O__O(p1__794000186_SHARP___1) } else { return nil } }

















func A_arbace_go_repl_define_BANG__fn__794000352_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_repl_define_BANG__fn__794000352_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000352_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :354:1
func (t *A_arbace_go_repl_define_BANG__fn__794000352_A) Ctor_O_O_O(c__ns, c__x, c__old any) { t.F_ns = c__ns; t.F_x = c__x; t.F_old = c__old }
//line :354:1
func (t *A_arbace_go_repl_define_BANG__fn__794000352_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_3088 any = A_arbace_go_repl_A_const_210.GetRawRoot__O(); var linked_3089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3088, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_3090 lang.IFn; if linked_3089 == nil { ifn_3090 = lang.IFn_Cast(root_3088) } else { ifn_3090 = nil }; var arg_3091 any; var t_ any = t.F_ns; t.F_ns = nil; arg_3091 = t_; var arg_3092 any; var root_3094 any = A_arbace_go_repl_A_const_211.GetRawRoot__O(); var linked_3095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3094, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3096 lang.IFn; if linked_3095 == nil { ifn_3096 = lang.IFn_Cast(root_3094) } else { ifn_3096 = nil }; var arg_3097 any; var root_3099 any = A_arbace_go_repl_A_const_46.GetRawRoot__O(); var linked_3100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3099, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3101 lang.IFn; if linked_3100 == nil { ifn_3101 = lang.IFn_Cast(root_3099) } else { ifn_3101 = nil }; var arg_3102 any; var root_3103 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3103, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3105 lang.IFn; if linked_3104 == nil { ifn_3105 = lang.IFn_Cast(root_3103) } else { ifn_3105 = nil }; var arg_3106 any = t.F_x; var arg_3107 any = A_arbace_go_repl_A_const_55; if linked_3104 == nil { arg_3102 = ifn_3105.Invoke_O_O__O(arg_3106, arg_3107) } else { arg_3102 = linked_3104.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3103, arg_3106, arg_3107) }; if linked_3100 == nil { arg_3097 = ifn_3101.Invoke_O__O(arg_3102) } else { arg_3097 = linked_3100.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3099, arg_3102) }; var arg_3098 any; var tmp2 any = A_arbace_go_repl_A_const_212; var tmp3 any = A_arbace_go_repl_A_const_142; var tmp4 any = A_arbace_go_repl_A_const_213; var tmp5 *lang.Keyword = A_arbace_go_repl_A_const_54; var tmp6 any; var t__2 any = t.F_old; t.F_old = nil; tmp6 = t__2; var tmp7 any = tmp5.Invoke_O__O(tmp6); var tmp8 any = A_arbace_go_repl_A_const_214; var tmp9 any; var root_3108 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_3109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3108, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3110 lang.IFn
												if linked_3109 == nil { ifn_3110 = lang.IFn_Cast(root_3108) } else { ifn_3110 = nil }; var arg_3111 any; var root_3112 any = A_arbace_go_repl_A_const_215.GetRawRoot__O(); var linked_3113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3112, aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A_fn_class); var ifn_3114 lang.IFn; if linked_3113 == nil { ifn_3114 = lang.IFn_Cast(root_3112) } else { ifn_3114 = nil }; var arg_3115 any; var root_3116 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3116, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3118 lang.IFn; if linked_3117 == nil { ifn_3118 = lang.IFn_Cast(root_3116) } else { ifn_3118 = nil }; var arg_3119 any = t.F_x; var arg_3120 any = A_arbace_go_repl_A_const_55; if linked_3117 == nil { arg_3115 = ifn_3118.Invoke_O_O__O(arg_3119, arg_3120) } else { arg_3115 = linked_3117.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3116, arg_3119, arg_3120) }; if linked_3113 == nil { arg_3111 = ifn_3114.Invoke_O__O(arg_3115) } else { arg_3111 = linked_3113.(*aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A).Invoke_O_O__O(root_3112, arg_3115) }; if linked_3109 == nil { tmp9 = ifn_3110.Invoke_O__O(arg_3111) } else { tmp9 = linked_3109.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3108, arg_3111) }
//line :355:1
		arg_3098 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp7, tmp8, tmp9)); if linked_3095 == nil { arg_3092 = ifn_3096.Invoke_O_O__O(arg_3097, arg_3098) } else { arg_3092 = linked_3095.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3094, arg_3097, arg_3098) }; var arg_3093 any; var tmp10 any; var root_3121 any = A_arbace_go_repl_A_const_187.GetRawRoot__O(); var linked_3122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3121, aot_arbace_go_build.A_arbace_go_build_desc_A_fn_class); var ifn_3123 lang.IFn

		if linked_3122 == nil { ifn_3123 = lang.IFn_Cast(root_3121) } else { ifn_3123 = nil }; var arg_3124 any; var root_3125 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3125, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3127 lang.IFn; if linked_3126 == nil { ifn_3127 = lang.IFn_Cast(root_3125) } else { ifn_3127 = nil }; var arg_3128 any; var t__3 any = t.F_x; t.F_x = nil; arg_3128 = t__3; var arg_3129 any = A_arbace_go_repl_A_const_142; if linked_3126 == nil { arg_3124 = ifn_3127.Invoke_O_O__O(arg_3128, arg_3129) } else { arg_3124 = linked_3126.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3125, arg_3128, arg_3129) }; if linked_3122 == nil { tmp10 = ifn_3123.Invoke_O__O(arg_3124) } else { tmp10 = linked_3122.(*aot_arbace_go_build.A_arbace_go_build_desc_A).Invoke_O_O__O(root_3121, arg_3124) }
//line :355:1
		arg_3093 = lang.GoType_New_O(tmp10); if linked_3089 == nil { tmp1 = ifn_3090.Invoke_O_O_O__O(arg_3091, arg_3092, arg_3093) } else { tmp1 = linked_3089.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O_O__O(root_3088, arg_3091, arg_3092, arg_3093) } }
//line :354:1
	return nil }(); if tmp11 != nil { if jrt.Exception_InstanceOf(tmp11) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp11); _ = ___3; tmp1 = nil } else { panic(tmp11) } }; return tmp1 }
//line :354:1
func A_arbace_go_repl_define_BANG__fn__794000354_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_repl_define_BANG__fn__794000354_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000354_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :354:1
func (t *A_arbace_go_repl_define_BANG__fn__794000354_A) Ctor_O_O_O(c__ns, c__x, c__old any) { t.F_ns = c__ns; t.F_x = c__x; t.F_old = c__old }
//line :354:1
func (t *A_arbace_go_repl_define_BANG__fn__794000354_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_3135 any = A_arbace_go_repl_A_const_210.GetRawRoot__O(); var linked_3136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3135, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_3137 lang.IFn; if linked_3136 == nil { ifn_3137 = lang.IFn_Cast(root_3135) } else { ifn_3137 = nil }; var arg_3138 any; var t_ any = t.F_ns; t.F_ns = nil; arg_3138 = t_; var arg_3139 any; var root_3141 any = A_arbace_go_repl_A_const_211.GetRawRoot__O(); var linked_3142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3141, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3143 lang.IFn; if linked_3142 == nil { ifn_3143 = lang.IFn_Cast(root_3141) } else { ifn_3143 = nil }; var arg_3144 any; var root_3146 any = A_arbace_go_repl_A_const_46.GetRawRoot__O(); var linked_3147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3146, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3148 lang.IFn; if linked_3147 == nil { ifn_3148 = lang.IFn_Cast(root_3146) } else { ifn_3148 = nil }; var arg_3149 any; var root_3150 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3150, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3152 lang.IFn; if linked_3151 == nil { ifn_3152 = lang.IFn_Cast(root_3150) } else { ifn_3152 = nil }; var arg_3153 any = t.F_x; var arg_3154 any = A_arbace_go_repl_A_const_55; if linked_3151 == nil { arg_3149 = ifn_3152.Invoke_O_O__O(arg_3153, arg_3154) } else { arg_3149 = linked_3151.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3150, arg_3153, arg_3154) }; if linked_3147 == nil { arg_3144 = ifn_3148.Invoke_O__O(arg_3149) } else { arg_3144 = linked_3147.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3146, arg_3149) }; var arg_3145 any; var tmp2 any = A_arbace_go_repl_A_const_212; var tmp3 any = A_arbace_go_repl_A_const_142; var tmp4 any = A_arbace_go_repl_A_const_213; var tmp5 *lang.Keyword = A_arbace_go_repl_A_const_54; var tmp6 any; var t__2 any = t.F_old; t.F_old = nil; tmp6 = t__2; var tmp7 any = tmp5.Invoke_O__O(tmp6); var tmp8 any = A_arbace_go_repl_A_const_214; var tmp9 any; var root_3155 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_3156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3155, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3157 lang.IFn
												if linked_3156 == nil { ifn_3157 = lang.IFn_Cast(root_3155) } else { ifn_3157 = nil }; var arg_3158 any; var root_3159 any = A_arbace_go_repl_A_const_215.GetRawRoot__O(); var linked_3160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3159, aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A_fn_class); var ifn_3161 lang.IFn; if linked_3160 == nil { ifn_3161 = lang.IFn_Cast(root_3159) } else { ifn_3161 = nil }; var arg_3162 any; var root_3163 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3163, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3165 lang.IFn; if linked_3164 == nil { ifn_3165 = lang.IFn_Cast(root_3163) } else { ifn_3165 = nil }; var arg_3166 any = t.F_x; var arg_3167 any = A_arbace_go_repl_A_const_55; if linked_3164 == nil { arg_3162 = ifn_3165.Invoke_O_O__O(arg_3166, arg_3167) } else { arg_3162 = linked_3164.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3163, arg_3166, arg_3167) }; if linked_3160 == nil { arg_3158 = ifn_3161.Invoke_O__O(arg_3162) } else { arg_3158 = linked_3160.(*aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A).Invoke_O_O__O(root_3159, arg_3162) }; if linked_3156 == nil { tmp9 = ifn_3157.Invoke_O__O(arg_3158) } else { tmp9 = linked_3156.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3155, arg_3158) }
//line :355:1
		arg_3145 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp7, tmp8, tmp9)); if linked_3142 == nil { arg_3139 = ifn_3143.Invoke_O_O__O(arg_3144, arg_3145) } else { arg_3139 = linked_3142.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3141, arg_3144, arg_3145) }; var arg_3140 any; var tmp10 any; var root_3168 any = A_arbace_go_repl_A_const_187.GetRawRoot__O(); var linked_3169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3168, aot_arbace_go_build.A_arbace_go_build_desc_A_fn_class); var ifn_3170 lang.IFn

		if linked_3169 == nil { ifn_3170 = lang.IFn_Cast(root_3168) } else { ifn_3170 = nil }; var arg_3171 any; var root_3172 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3172, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3174 lang.IFn; if linked_3173 == nil { ifn_3174 = lang.IFn_Cast(root_3172) } else { ifn_3174 = nil }; var arg_3175 any; var t__3 any = t.F_x; t.F_x = nil; arg_3175 = t__3; var arg_3176 any = A_arbace_go_repl_A_const_142; if linked_3173 == nil { arg_3171 = ifn_3174.Invoke_O_O__O(arg_3175, arg_3176) } else { arg_3171 = linked_3173.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3172, arg_3175, arg_3176) }; if linked_3169 == nil { tmp10 = ifn_3170.Invoke_O__O(arg_3171) } else { tmp10 = linked_3169.(*aot_arbace_go_build.A_arbace_go_build_desc_A).Invoke_O_O__O(root_3168, arg_3171) }
//line :355:1
		arg_3140 = lang.GoType_New_O(tmp10); if linked_3136 == nil { tmp1 = ifn_3137.Invoke_O_O_O__O(arg_3138, arg_3139, arg_3140) } else { tmp1 = linked_3136.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O_O__O(root_3135, arg_3138, arg_3139, arg_3140) } }
//line :354:1
	return nil }(); if tmp11 != nil { if jrt.Exception_InstanceOf(tmp11) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp11); _ = ___3; tmp1 = nil } else { panic(tmp11) } }; return tmp1 }












func A_arbace_go_repl_call0_A_New() *A_arbace_go_repl_call0_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_call0_A{}; t.Ctor(); return t }
//line :367:1
func (t *A_arbace_go_repl_call0_A) Ctor() {}
//line :367:1
func (t *A_arbace_go_repl_call0_A) Invoke_O_O_O__O(self, f__0, nm__1 any) any {


	return lang.GoInterp_Call_O_O1__O(lang.IFn_Cast(A_arbace_go_repl_A_const_179.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_11, f__0, lang.IFn_Cast(A_arbace_go_repl_A_const_179.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_12, lang.RT_Object_array_O__O1_NoInit(lang.PersistentVector_EMPTY.Ref()).Ref(), lang.RT_Object_array_O__O1_NoInit(lang.PersistentVector_EMPTY.Ref()).Ref(), jrt.Boolean_FALSE.Ref()), nm__1), lang.RT_Object_array_O__O1_NoInit(lang.PersistentVector_EMPTY.Ref()))
}

func A_arbace_go_repl_complete_BANG__A_New() *A_arbace_go_repl_complete_BANG__A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_complete_BANG__A{}; t.Ctor(); return t }
//line :373:1
func (t *A_arbace_go_repl_complete_BANG__A) Ctor() {}
//line :373:1
func (t *A_arbace_go_repl_complete_BANG__A) Invoke_O_O__O(self, st__0 any) any {



	var root_3235 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_3236 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3235, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3237 lang.IFn; if linked_3236 == nil { ifn_3237 = lang.IFn_Cast(root_3235) } else { ifn_3237 = nil }; var arg_3238 any = st__0; var arg_3239 any = A_arbace_go_repl_A_const_84.GetRawRoot__O(); var arg_3240 any = A_arbace_go_repl_A_const_77; if linked_3236 == nil { ifn_3237.Invoke_O_O_O__O(arg_3238, arg_3239, arg_3240) } else { linked_3236.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_3235, arg_3238, arg_3239, arg_3240) }
//line :373:1
	var r__2 any; var root_3204 any = A_arbace_go_repl_A_const_218.GetRawRoot__O(); var linked_3205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3204, A_arbace_go_repl_check_source_A_fn_class); var ifn_3206 lang.IFn




	if linked_3205 == nil { ifn_3206 = lang.IFn_Cast(root_3204) } else { ifn_3206 = nil }; var arg_3207 any; var root_3209 any = A_arbace_go_repl_A_const_118.GetRawRoot__O(); var linked_3210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3209, A_arbace_go_repl_source_of_A_fn_class); var ifn_3211 lang.IFn; if linked_3210 == nil { ifn_3211 = lang.IFn_Cast(root_3209) } else { ifn_3211 = nil }; var arg_3212 any = st__0; if linked_3210 == nil { arg_3207 = ifn_3211.Invoke_O__O(arg_3212) } else { arg_3207 = linked_3210.(*A_arbace_go_repl_source_of_A).Invoke_O_O__O(root_3209, arg_3212) }; var arg_3208 any; if linked_3205 == nil { r__2 = ifn_3206.Invoke_O_O__O(arg_3207, arg_3208) } else { r__2 = linked_3205.(*A_arbace_go_repl_check_source_A).Invoke_O_O_O__O(root_3204, arg_3207, arg_3208) }
	var tmp1 any; var root_3241 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_3242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3241, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3243 lang.IFn; if linked_3242 == nil { ifn_3243 = lang.IFn_Cast(root_3241) } else { ifn_3243 = nil }; var arg_3244 any = A_arbace_go_repl_A_const_221.Invoke_O__O(r__2); if linked_3242 == nil { tmp1 = ifn_3243.Invoke_O__O(arg_3244) } else { tmp1 = linked_3242.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3241, arg_3244) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_3245 any = A_arbace_go_repl_A_const_69.GetRawRoot__O(); var linked_3246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3245, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_3247 lang.IFn
		if linked_3246 == nil { ifn_3247 = lang.IFn_Cast(root_3245) } else { ifn_3247 = nil }; var arg_3248 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_13, nil, Lit_14, nil); var tmp4 *lang.Keyword = A_arbace_go_repl_A_const_54; var tmp5 any; var root_3250 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_3251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3250, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3252 lang.IFn; if linked_3251 == nil { ifn_3252 = lang.IFn_Cast(root_3250) } else { ifn_3252 = nil }; var arg_3253 any = st__0; if linked_3251 == nil { tmp5 = ifn_3252.Invoke_O__O(arg_3253) } else { tmp5 = linked_3251.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3250, arg_3253) }; var tmp6 any = tmp4.Invoke_O__O(tmp5); var tmp7 any; var root_3254 any = A_arbace_go_repl_A_const_115.GetRawRoot__O(); var linked_3255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3254, A_arbace_go_repl_error_text_A_fn_class); var ifn_3256 lang.IFn; if linked_3255 == nil { ifn_3256 = lang.IFn_Cast(root_3254) } else { ifn_3256 = nil }; var arg_3257 any = A_arbace_go_repl_A_const_221.Invoke_O__O(r__2); if linked_3255 == nil { tmp7 = ifn_3256.Invoke_O__O(arg_3257) } else { tmp7 = linked_3255.(*A_arbace_go_repl_error_text_A).Invoke_O_O__O(root_3254, arg_3257) }; arg_3248 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp6, nil, tmp7)).Ref(); var tmp8 any = A_arbace_go_repl_A_const_222; var arg_3249 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, A_arbace_go_repl_A_const_221.Invoke_O__O(r__2))); if linked_3246 == nil { tmp2 = ifn_3247.Invoke_O_O__O(arg_3248, arg_3249) } else { tmp2 = linked_3246.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_3245, arg_3248, arg_3249) }
//line :379:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) }
//line :373:1
	var map__794000358__3 any; var root_3213 any = A_arbace_go_repl_A_const_219.GetRawRoot__O(); var linked_3214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3213, A_arbace_go_repl_define_BANG__A_fn_class); var ifn_3215 lang.IFn








	if linked_3214 == nil { ifn_3215 = lang.IFn_Cast(root_3213) } else { ifn_3215 = nil }; var arg_3216 any = st__0; var arg_3217 any = r__2; var arg_3218 any = A_arbace_go_repl_A_const_220; if linked_3214 == nil { map__794000358__3 = ifn_3215.Invoke_O_O_O__O(arg_3216, arg_3217, arg_3218) } else { map__794000358__3 = linked_3214.(*A_arbace_go_repl_define_BANG__A).Invoke_O_O_O_O__O(root_3213, arg_3216, arg_3217, arg_3218) }
//line :373:1
	var map__794000358__4 any








	if lang.ISeq_InstanceOf(map__794000358__3) { var tmp9 any; var root_3219 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_3220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3219, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3221 lang.IFn; if linked_3220 == nil { ifn_3221 = lang.IFn_Cast(root_3219) } else { ifn_3221 = nil }; var arg_3222 any = map__794000358__3; if linked_3220 == nil { tmp9 = ifn_3221.Invoke_O__O(arg_3222) } else { tmp9 = linked_3220.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3219, arg_3222) }; if jrt.J2g_Truth(tmp9) { var tmp10 any; var root_3223 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_3224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3223, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3225 lang.IFn; if linked_3224 == nil { ifn_3225 = lang.IFn_Cast(root_3223) } else { ifn_3225 = nil }; var arg_3226 any = map__794000358__3; if linked_3224 == nil { tmp10 = ifn_3225.Invoke_O__O(arg_3226) } else { tmp10 = linked_3224.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3223, arg_3226) }; map__794000358__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp10, jrt.Object_class.ArrayClass())).Ref() } else { var tmp11 any; var root_3227 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_3228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3227, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3229 lang.IFn; if linked_3228 == nil { ifn_3229 = lang.IFn_Cast(root_3227) } else { ifn_3229 = nil }; var arg_3230 any = map__794000358__3; if linked_3228 == nil { tmp11 = ifn_3229.Invoke_O__O(arg_3230) } else { tmp11 = linked_3228.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3227, arg_3230) }; if jrt.J2g_Truth(tmp11) { var root_3231 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_3232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3231, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3233 lang.IFn; if linked_3232 == nil { ifn_3233 = lang.IFn_Cast(root_3231) } else { ifn_3233 = nil }; var arg_3234 any = map__794000358__3; if linked_3232 == nil { map__794000358__4 = ifn_3233.Invoke_O__O(arg_3234) } else { map__794000358__4 = linked_3232.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3231, arg_3234) } } else { map__794000358__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000358__4 = map__794000358__3 }
//line :373:1
	var inits__5 any = lang.RT_Get_O_O__O_NoInit(map__794000358__4, A_arbace_go_repl_A_const_182); var init_funcs__6 any = lang.RT_Get_O_O__O_NoInit(map__794000358__4, A_arbace_go_repl_A_const_192); var root_3258 any = A_arbace_go_repl_A_const_223.GetRawRoot__O(); var linked_3259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3258, A_arbace_go_repl_call0_A_fn_class); var ifn_3260 lang.IFn









	if linked_3259 == nil { ifn_3260 = lang.IFn_Cast(root_3258) } else { ifn_3260 = nil }; var arg_3261 any = inits__5; var arg_3262 any = Lit_15; if linked_3259 == nil { ifn_3260.Invoke_O_O__O(arg_3261, arg_3262) } else { linked_3259.(*A_arbace_go_repl_call0_A).Invoke_O_O_O__O(root_3258, arg_3261, arg_3262) }
//line :373:1
	var seq_794000360__7 any; var root_3263 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_3264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3263, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3265 lang.IFn










	if linked_3264 == nil { ifn_3265 = lang.IFn_Cast(root_3263) } else { ifn_3265 = nil }; var arg_3266 any = init_funcs__6; if linked_3264 == nil { seq_794000360__7 = ifn_3265.Invoke_O__O(arg_3266) } else { seq_794000360__7 = linked_3264.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3263, arg_3266) }
//line :373:1
	var chunk_794000361__8 any; var count_794000362__9 int64 = 0; var i_794000363__10 int64 = 0; L1: for {










		if lang.Numbers_Lt_J_J__Z_NoInit(i_794000363__10, count_794000362__9) { var f__11 any = lang.Indexed_Cast(chunk_794000361__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_794000363__10)); var root_3283 any = A_arbace_go_repl_A_const_223.GetRawRoot__O(); var linked_3284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3283, A_arbace_go_repl_call0_A_fn_class); var ifn_3285 lang.IFn
			if linked_3284 == nil { ifn_3285 = lang.IFn_Cast(root_3283) } else { ifn_3285 = nil }; var arg_3286 any = f__11; var arg_3287 any = Lit_15; if linked_3284 == nil { ifn_3285.Invoke_O_O__O(arg_3286, arg_3287) } else { linked_3284.(*A_arbace_go_repl_call0_A).Invoke_O_O_O__O(root_3283, arg_3286, arg_3287) }
//line :384:1
			seq_794000360__7, chunk_794000361__8, count_794000362__9, i_794000363__10 = seq_794000360__7, chunk_794000361__8, count_794000362__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000363__10); continue L1 } else { var temp__1927000414__auto____11 any; var root_3267 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_3268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3267, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3269 lang.IFn; if linked_3268 == nil { ifn_3269 = lang.IFn_Cast(root_3267) } else { ifn_3269 = nil }; var arg_3270 any = seq_794000360__7; if linked_3268 == nil { temp__1927000414__auto____11 = ifn_3269.Invoke_O__O(arg_3270) } else { temp__1927000414__auto____11 = linked_3268.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3267, arg_3270) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_794000360__12 any = temp__1927000414__auto____11; var tmp12 any; var root_3271 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_3272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3271, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3273 lang.IFn; if linked_3272 == nil { ifn_3273 = lang.IFn_Cast(root_3271) } else { ifn_3273 = nil }; var arg_3274 any = seq_794000360__12; if linked_3272 == nil { tmp12 = ifn_3273.Invoke_O__O(arg_3274) } else { tmp12 = linked_3272.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3271, arg_3274) }; if jrt.J2g_Truth(tmp12) { var c__1927000678__auto____13 any; var root_3275 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_3276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3275, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3277 lang.IFn; if linked_3276 == nil { ifn_3277 = lang.IFn_Cast(root_3275) } else { ifn_3277 = nil }; var arg_3278 any = seq_794000360__12; if linked_3276 == nil { c__1927000678__auto____13 = ifn_3277.Invoke_O__O(arg_3278) } else { c__1927000678__auto____13 = linked_3276.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3275, arg_3278) }; var tmp13 any; var root_3288 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_3289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3288, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3290 lang.IFn; if linked_3289 == nil { ifn_3290 = lang.IFn_Cast(root_3288) } else { ifn_3290 = nil }; var arg_3291 any = seq_794000360__12; if linked_3289 == nil { tmp13 = ifn_3290.Invoke_O__O(arg_3291) } else { tmp13 = linked_3289.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3288, arg_3291) }; seq_794000360__7, chunk_794000361__8, count_794000362__9, i_794000363__10 = tmp13, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__13 any; var root_3279 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_3280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3279, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3281 lang.IFn; if linked_3280 == nil { ifn_3281 = lang.IFn_Cast(root_3279) } else { ifn_3281 = nil }; var arg_3282 any = seq_794000360__12; if linked_3280 == nil { f__13 = ifn_3281.Invoke_O__O(arg_3282) } else { f__13 = linked_3280.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3279, arg_3282) }
				var root_3292 any = A_arbace_go_repl_A_const_223.GetRawRoot__O(); var linked_3293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3292, A_arbace_go_repl_call0_A_fn_class); var ifn_3294 lang.IFn; if linked_3293 == nil { ifn_3294 = lang.IFn_Cast(root_3292) } else { ifn_3294 = nil }; var arg_3295 any = f__13; var arg_3296 any = Lit_15; if linked_3293 == nil { ifn_3294.Invoke_O_O__O(arg_3295, arg_3296) } else { linked_3293.(*A_arbace_go_repl_call0_A).Invoke_O_O_O__O(root_3292, arg_3295, arg_3296) }
//line :384:1
				var tmp14 any; var root_3297 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_3298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3297, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3299 lang.IFn; if linked_3298 == nil { ifn_3299 = lang.IFn_Cast(root_3297) } else { ifn_3299 = nil }; var arg_3300 any = seq_794000360__12; if linked_3298 == nil { tmp14 = ifn_3299.Invoke_O__O(arg_3300) } else { tmp14 = linked_3298.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3297, arg_3300) }; seq_794000360__7, chunk_794000361__8, count_794000362__9, i_794000363__10 = tmp14, nil, 0, 0; continue L1 } } }
//line :373:1
		break L1 }; return st__0
}













func A_arbace_go_repl_after_load_A_New() *A_arbace_go_repl_after_load_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_after_load_A{}; t.Ctor(); return t }
//line :388:1
func (t *A_arbace_go_repl_after_load_A) Ctor() {}
//line :388:1
func (t *A_arbace_go_repl_after_load_A) Invoke_O_O_O__O(self, path__0, ok__1 any) any { { var p__3 any; var tmp1 any; var root_3301 any = A_arbace_go_repl_A_const_68.GetRawRoot__O(); var linked_3302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3301, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_3303 lang.IFn



	if linked_3302 == nil { ifn_3303 = lang.IFn_Cast(root_3301) } else { ifn_3303 = nil }; var arg_3304 any = path__0; var arg_3305 any = Lit_1; if linked_3302 == nil { tmp1 = ifn_3303.Invoke_O_O__O(arg_3304, arg_3305) } else { tmp1 = linked_3302.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_3301, arg_3304, arg_3305) }; if jrt.J2g_Truth(tmp1) { var root_3306 any = A_arbace_go_repl_A_const_22.GetRawRoot__O(); var linked_3307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3306, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3308 lang.IFn; if linked_3307 == nil { ifn_3308 = lang.IFn_Cast(root_3306) } else { ifn_3308 = nil }; var arg_3309 any = path__0; var arg_3310 any = A_arbace_go_repl_A_const_153; if linked_3307 == nil { p__3 = ifn_3308.Invoke_O_O__O(arg_3309, arg_3310) } else { p__3 = linked_3307.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_3306, arg_3309, arg_3310) } } else { p__3 = path__0 }
	var tmp2 any; var root_3311 any = A_arbace_go_repl_A_const_68.GetRawRoot__O(); var linked_3312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3311, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_3313 lang.IFn; if linked_3312 == nil { ifn_3313 = lang.IFn_Cast(root_3311) } else { ifn_3313 = nil }; var arg_3314 any = p__3; var arg_3315 any = Lit_2; if linked_3312 == nil { tmp2 = ifn_3313.Invoke_O_O__O(arg_3314, arg_3315) } else { tmp2 = linked_3312.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_3311, arg_3314, arg_3315) }; if jrt.J2g_Truth(tmp2) { var ns_name__4 any; var root_3316 any = A_arbace_go_repl_A_const_224.GetRawRoot__O(); var linked_3317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3316, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_3318 lang.IFn
		if linked_3317 == nil { ifn_3318 = lang.IFn_Cast(root_3316) } else { ifn_3318 = nil }; var arg_3319 any; var root_3322 any = A_arbace_go_repl_A_const_224.GetRawRoot__O(); var linked_3323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3322, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_3324 lang.IFn; if linked_3323 == nil { ifn_3324 = lang.IFn_Cast(root_3322) } else { ifn_3324 = nil }; var arg_3325 any = p__3; var arg_3326 any = Lit_1; var arg_3327 any = Lit_3; if linked_3323 == nil { arg_3319 = ifn_3324.Invoke_O_O_O__O(arg_3325, arg_3326, arg_3327) } else { arg_3319 = linked_3323.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_3322, arg_3325, arg_3326, arg_3327) }; var arg_3320 any = Lit_4; var arg_3321 any = Lit_5; if linked_3317 == nil { ns_name__4 = ifn_3318.Invoke_O_O_O__O(arg_3319, arg_3320, arg_3321) } else { ns_name__4 = linked_3317.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_3316, arg_3319, arg_3320, arg_3321) }
//line :393:1
		var seq_794000365__5 any; var root_3328 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_3329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3328, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3330 lang.IFn

		if linked_3329 == nil { ifn_3330 = lang.IFn_Cast(root_3328) } else { ifn_3330 = nil }; var arg_3331 any; var root_3332 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_3333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3332, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3334 lang.IFn; if linked_3333 == nil { ifn_3334 = lang.IFn_Cast(root_3332) } else { ifn_3334 = nil }; var arg_3335 any = A_arbace_go_repl_A_const_64.GetRawRoot__O(); if linked_3333 == nil { arg_3331 = ifn_3334.Invoke_O__O(arg_3335) } else { arg_3331 = linked_3333.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3332, arg_3335) }; if linked_3329 == nil { seq_794000365__5 = ifn_3330.Invoke_O__O(arg_3331) } else { seq_794000365__5 = linked_3329.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3328, arg_3331) }
//line :393:1
		var chunk_794000366__6 any; var count_794000367__7 int64 = 0; var i_794000368__8 int64 = 0; L1: for {

			if lang.Numbers_Lt_J_J__Z_NoInit(i_794000368__8, count_794000367__7) { var vec__794000369__9 any = lang.Indexed_Cast(chunk_794000366__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_794000368__8)); var path__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000369__9, lang.RT_IntCast_J__I_NoInit(0), nil); var st__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000369__9, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp3 any; var and__1927000168__auto____12 any; var tmp4 *lang.Keyword = A_arbace_go_repl_A_const_77; var tmp5 any; var root_3352 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_3353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3352, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3354 lang.IFn
				if linked_3353 == nil { ifn_3354 = lang.IFn_Cast(root_3352) } else { ifn_3354 = nil }; var arg_3355 any = st__11; if linked_3353 == nil { tmp5 = ifn_3354.Invoke_O__O(arg_3355) } else { tmp5 = linked_3353.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3352, arg_3355) }; and__1927000168__auto____12 = tmp4.Invoke_O__O(tmp5); if jrt.J2g_Truth(and__1927000168__auto____12) { var tmp6 any; var root_3356 any = A_arbace_go_repl_A_const_51.GetRawRoot__O(); var linked_3357 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3356, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_3358 lang.IFn; if linked_3357 == nil { ifn_3358 = lang.IFn_Cast(root_3356) } else { ifn_3358 = nil }; var arg_3359 any; var tmp7 *lang.Keyword = A_arbace_go_repl_A_const_56; var tmp8 any; var root_3360 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_3361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3360, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3362 lang.IFn; if linked_3361 == nil { ifn_3362 = lang.IFn_Cast(root_3360) } else { ifn_3362 = nil }; var arg_3363 any = st__11; if linked_3361 == nil { tmp8 = ifn_3362.Invoke_O__O(arg_3363) } else { tmp8 = linked_3361.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3360, arg_3363) }; arg_3359 = tmp7.Invoke_O__O(tmp8); if linked_3357 == nil { tmp6 = ifn_3358.Invoke_O__O(arg_3359) } else { tmp6 = linked_3357.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_3356, arg_3359) }; tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp6, ns_name__4)).Ref() } else { tmp3 = and__1927000168__auto____12 }; if jrt.J2g_Truth(tmp3) {
					if jrt.J2g_Truth(ok__1) {
						var root_3364 any = A_arbace_go_repl_A_const_225.GetRawRoot__O(); var linked_3365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3364, A_arbace_go_repl_complete_BANG__A_fn_class); var ifn_3366 lang.IFn; if linked_3365 == nil { ifn_3366 = lang.IFn_Cast(root_3364) } else { ifn_3366 = nil }; var arg_3367 any = st__11; if linked_3365 == nil { ifn_3366.Invoke_O__O(arg_3367) } else { linked_3365.(*A_arbace_go_repl_complete_BANG__A).Invoke_O_O__O(root_3364, arg_3367) } } else {
							var root_3368 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_3369 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3368, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3370 lang.IFn; if linked_3369 == nil { ifn_3370 = lang.IFn_Cast(root_3368) } else { ifn_3370 = nil }; var arg_3371 any = A_arbace_go_repl_A_const_64.GetRawRoot__O(); var arg_3372 any = A_arbace_go_repl_A_const_84.GetRawRoot__O(); var arg_3373 any = path__10; if linked_3369 == nil { ifn_3370.Invoke_O_O_O__O(arg_3371, arg_3372, arg_3373) } else { linked_3369.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_3368, arg_3371, arg_3372, arg_3373) } } }
//line :395:1
				seq_794000365__5, chunk_794000366__6, count_794000367__7, i_794000368__8 = seq_794000365__5, chunk_794000366__6, count_794000367__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000368__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_3336 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_3337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3336, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3338 lang.IFn; if linked_3337 == nil { ifn_3338 = lang.IFn_Cast(root_3336) } else { ifn_3338 = nil }; var arg_3339 any = seq_794000365__5; if linked_3337 == nil { temp__1927000414__auto____9 = ifn_3338.Invoke_O__O(arg_3339) } else { temp__1927000414__auto____9 = linked_3337.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3336, arg_3339) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_794000365__10 any = temp__1927000414__auto____9; var tmp9 any; var root_3340 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_3341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3340, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3342 lang.IFn; if linked_3341 == nil { ifn_3342 = lang.IFn_Cast(root_3340) } else { ifn_3342 = nil }; var arg_3343 any = seq_794000365__10; if linked_3341 == nil { tmp9 = ifn_3342.Invoke_O__O(arg_3343) } else { tmp9 = linked_3341.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3340, arg_3343) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____11 any; var root_3344 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_3345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3344, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3346 lang.IFn; if linked_3345 == nil { ifn_3346 = lang.IFn_Cast(root_3344) } else { ifn_3346 = nil }; var arg_3347 any = seq_794000365__10; if linked_3345 == nil { c__1927000678__auto____11 = ifn_3346.Invoke_O__O(arg_3347) } else { c__1927000678__auto____11 = linked_3345.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3344, arg_3347) }; var tmp10 any; var root_3374 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_3375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3374, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3376 lang.IFn; if linked_3375 == nil { ifn_3376 = lang.IFn_Cast(root_3374) } else { ifn_3376 = nil }; var arg_3377 any = seq_794000365__10; if linked_3375 == nil { tmp10 = ifn_3376.Invoke_O__O(arg_3377) } else { tmp10 = linked_3375.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3374, arg_3377) }; seq_794000365__5, chunk_794000366__6, count_794000367__7, i_794000368__8 = tmp10, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__794000372__11 any; var root_3348 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_3349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3348, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3350 lang.IFn; if linked_3349 == nil { ifn_3350 = lang.IFn_Cast(root_3348) } else { ifn_3350 = nil }; var arg_3351 any = seq_794000365__10; if linked_3349 == nil { vec__794000372__11 = ifn_3350.Invoke_O__O(arg_3351) } else { vec__794000372__11 = linked_3349.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3348, arg_3351) }; var path__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000372__11, lang.RT_IntCast_J__I_NoInit(0), nil); var st__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000372__11, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp11 any; var and__1927000168__auto____14 any; var tmp12 *lang.Keyword = A_arbace_go_repl_A_const_77; var tmp13 any; var root_3378 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_3379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3378, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3380 lang.IFn
					if linked_3379 == nil { ifn_3380 = lang.IFn_Cast(root_3378) } else { ifn_3380 = nil }; var arg_3381 any = st__13; if linked_3379 == nil { tmp13 = ifn_3380.Invoke_O__O(arg_3381) } else { tmp13 = linked_3379.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3378, arg_3381) }; and__1927000168__auto____14 = tmp12.Invoke_O__O(tmp13); if jrt.J2g_Truth(and__1927000168__auto____14) { var tmp14 any; var root_3382 any = A_arbace_go_repl_A_const_51.GetRawRoot__O(); var linked_3383 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3382, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_3384 lang.IFn; if linked_3383 == nil { ifn_3384 = lang.IFn_Cast(root_3382) } else { ifn_3384 = nil }; var arg_3385 any; var tmp15 *lang.Keyword = A_arbace_go_repl_A_const_56; var tmp16 any; var root_3386 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_3387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3386, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3388 lang.IFn; if linked_3387 == nil { ifn_3388 = lang.IFn_Cast(root_3386) } else { ifn_3388 = nil }; var arg_3389 any = st__13; if linked_3387 == nil { tmp16 = ifn_3388.Invoke_O__O(arg_3389) } else { tmp16 = linked_3387.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3386, arg_3389) }; arg_3385 = tmp15.Invoke_O__O(tmp16); if linked_3383 == nil { tmp14 = ifn_3384.Invoke_O__O(arg_3385) } else { tmp14 = linked_3383.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_3382, arg_3385) }; tmp11 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp14, ns_name__4)).Ref() } else { tmp11 = and__1927000168__auto____14 }; if jrt.J2g_Truth(tmp11) {
						if jrt.J2g_Truth(ok__1) {
							var root_3390 any = A_arbace_go_repl_A_const_225.GetRawRoot__O(); var linked_3391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3390, A_arbace_go_repl_complete_BANG__A_fn_class); var ifn_3392 lang.IFn; if linked_3391 == nil { ifn_3392 = lang.IFn_Cast(root_3390) } else { ifn_3392 = nil }; var arg_3393 any = st__13; if linked_3391 == nil { ifn_3392.Invoke_O__O(arg_3393) } else { linked_3391.(*A_arbace_go_repl_complete_BANG__A).Invoke_O_O__O(root_3390, arg_3393) } } else {
								var root_3394 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_3395 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3394, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3396 lang.IFn; if linked_3395 == nil { ifn_3396 = lang.IFn_Cast(root_3394) } else { ifn_3396 = nil }; var arg_3397 any = A_arbace_go_repl_A_const_64.GetRawRoot__O(); var arg_3398 any = A_arbace_go_repl_A_const_84.GetRawRoot__O(); var arg_3399 any = path__12; if linked_3395 == nil { ifn_3396.Invoke_O_O_O__O(arg_3397, arg_3398, arg_3399) } else { linked_3395.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_3394, arg_3397, arg_3398, arg_3399) } } }
//line :395:1
					var tmp17 any; var root_3400 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_3401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3400, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3402 lang.IFn; if linked_3401 == nil { ifn_3402 = lang.IFn_Cast(root_3400) } else { ifn_3402 = nil }; var arg_3403 any = seq_794000365__10; if linked_3401 == nil { tmp17 = ifn_3402.Invoke_O__O(arg_3403) } else { tmp17 = linked_3401.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3400, arg_3403) }; seq_794000365__5, chunk_794000366__6, count_794000367__7, i_794000368__8 = tmp17, nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :393:1
						return nil } }; /*line :388:1*/panic("j2g: unreachable") }















func A_arbace_go_repl_load_import_A_New() *A_arbace_go_repl_load_import_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_load_import_A{}; t.Ctor(); return t }
//line :404:1
func (t *A_arbace_go_repl_load_import_A) Ctor() {}
//line :404:1
func (t *A_arbace_go_repl_load_import_A) Invoke_O_O__O(self, path__0 any) any { var or__1927000174__auto____2 any; var temp__1927000414__auto____2 any; var tmp1 any; var root_3404 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_3405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3404, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3406 lang.IFn; if



	linked_3405 == nil { ifn_3406 = lang.IFn_Cast(root_3404) } else { ifn_3406 = nil }; var arg_3407 any = A_arbace_go_repl_A_const_64.GetRawRoot__O(); if linked_3405 == nil { tmp1 = ifn_3406.Invoke_O__O(arg_3407) } else { tmp1 = linked_3405.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3404, arg_3407) }; temp__1927000414__auto____2 = lang.RT_Get_O_O__O_NoInit(tmp1, path__0); if jrt.J2g_Truth(temp__1927000414__auto____2) { var st__3 any = temp__1927000414__auto____2; var tmp2 *lang.Keyword = A_arbace_go_repl_A_const_77; var tmp3 any; var root_3408 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_3409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3408, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3410 lang.IFn; if linked_3409 == nil { ifn_3410 = lang.IFn_Cast(root_3408) } else { ifn_3410 = nil }; var arg_3411 any = st__3; if linked_3409 == nil { tmp3 = ifn_3410.Invoke_O__O(arg_3411) } else { tmp3 = linked_3409.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3408, arg_3411) }; if jrt.J2g_Truth(tmp2.Invoke_O__O(tmp3)) { or__1927000174__auto____2 = nil } else { or__1927000174__auto____2 = st__3 } } else { or__1927000174__auto____2 = nil }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {
		var tmp4 any; var root_3412 any = A_arbace_go_repl_A_const_43.GetRawRoot__O(); var linked_3413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3412, A_arbace_go_repl_listed_QMARK__A_fn_class); var ifn_3414 lang.IFn; if linked_3413 == nil { ifn_3414 = lang.IFn_Cast(root_3412) } else { ifn_3414 = nil }; var arg_3415 any = path__0; if linked_3413 == nil { tmp4 = ifn_3414.Invoke_O__O(arg_3415) } else { tmp4 = linked_3413.(*A_arbace_go_repl_listed_QMARK__A).Invoke_O_O__O(root_3412, arg_3415) }; if jrt.J2g_Truth(tmp4) { return nil } else { var ns_sym__3 any; var root_3416 any = A_arbace_go_repl_A_const_226.GetRawRoot__O(); var linked_3417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3416, A_arbace_go_repl_path__GT_ns_A_fn_class); var ifn_3418 lang.IFn
			if linked_3417 == nil { ifn_3418 = lang.IFn_Cast(root_3416) } else { ifn_3418 = nil }; var arg_3419 any = path__0; if linked_3417 == nil { ns_sym__3 = ifn_3418.Invoke_O__O(arg_3419) } else { ns_sym__3 = linked_3417.(*A_arbace_go_repl_path__GT_ns_A).Invoke_O_O__O(root_3416, arg_3419) }
			var tmp5 any = A_arbace_go_repl_load_import_fn__794000378_A_New_O(ns_sym__3); var tmp6 *jrt.Class; var fncls__3432 *jrt.Class = A_arbace_go_repl_load_import_fn__794000378_A_fn_class; if fncls__3432 == nil { var fncls__3432d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_143, false); A_arbace_go_repl_load_import_fn__794000378_A_fn_class = fncls__3432d; tmp6 = fncls__3432d } else { tmp6 = fncls__3432 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()
//line :409:1
			var temp__1927000414__auto____4 any; var tmp7 any; var root_3420 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_3421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3420, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3422 lang.IFn




			if linked_3421 == nil { ifn_3422 = lang.IFn_Cast(root_3420) } else { ifn_3422 = nil }; var arg_3423 any = A_arbace_go_repl_A_const_64.GetRawRoot__O(); if linked_3421 == nil { tmp7 = ifn_3422.Invoke_O__O(arg_3423) } else { tmp7 = linked_3421.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3420, arg_3423) }; temp__1927000414__auto____4 = lang.RT_Get_O_O__O_NoInit(tmp7, path__0); if jrt.J2g_Truth(temp__1927000414__auto____4) { var st__5 any = temp__1927000414__auto____4; var tmp8 *lang.Keyword = A_arbace_go_repl_A_const_77; var tmp9 any; var root_3424 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_3425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3424, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3426 lang.IFn
				if linked_3425 == nil { ifn_3426 = lang.IFn_Cast(root_3424) } else { ifn_3426 = nil }; var arg_3427 any = st__5; if linked_3425 == nil { tmp9 = ifn_3426.Invoke_O__O(arg_3427) } else { tmp9 = linked_3425.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3424, arg_3427) }; if jrt.J2g_Truth(tmp8.Invoke_O__O(tmp9)) { return nil } else { return st__5 } } else {
//line :414:1
					return nil } } } }
//line :411:1
func A_arbace_go_repl_load_import_fn__794000378_A_New_O(p0 any) *A_arbace_go_repl_load_import_fn__794000378_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_load_import_fn__794000378_A{}; t.Ctor_O(p0); return t }
//line :411:1
func (t *A_arbace_go_repl_load_import_fn__794000378_A) Ctor_O(c__ns_sym any) { t.F_ns_sym = c__ns_sym }
//line :411:1
func (t *A_arbace_go_repl_load_import_fn__794000378_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_2.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_ns_sym; t.F_ns_sym = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }
//line :411:1
	return nil }(); if tmp4 != nil { if jrt.FileNotFoundException_InstanceOf(tmp4) { var ___3 *jrt.FileNotFoundException = jrt.FileNotFoundException_Cast(tmp4); _ = ___3; tmp1 = nil } else { panic(tmp4) } }; return tmp1 }







func A_arbace_go_repl_declare_BANG__A_New() *A_arbace_go_repl_declare_BANG__A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__A{}; t.Ctor(); return t }
//line :419:1
func (t *A_arbace_go_repl_declare_BANG__A) Ctor() {}
//line :419:1
func (t *A_arbace_go_repl_declare_BANG__A) Invoke_O_O_O__O(self, form__0, p__794000387__1 any) any { var map__794000388__3 any = p__794000387__1; var map__794000388__4 any; if lang.ISeq_InstanceOf(map__794000388__3) { var tmp1 any; var root_3433 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_3434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3433, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3435 lang.IFn; if linked_3434 == nil { ifn_3435 = lang.IFn_Cast(root_3433) } else { ifn_3435 = nil }; var arg_3436 any = map__794000388__3; if linked_3434 == nil { tmp1 = ifn_3435.Invoke_O__O(arg_3436) } else { tmp1 = linked_3434.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3433, arg_3436) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_3437 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_3438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3437, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3439 lang.IFn; if linked_3438 == nil { ifn_3439 = lang.IFn_Cast(root_3437) } else { ifn_3439 = nil }; var arg_3440 any = map__794000388__3; if linked_3438 == nil { tmp2 = ifn_3439.Invoke_O__O(arg_3440) } else { tmp2 = linked_3438.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3437, arg_3440) }; map__794000388__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_3441 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_3442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3441, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3443 lang.IFn; if linked_3442 == nil { ifn_3443 = lang.IFn_Cast(root_3441) } else { ifn_3443 = nil }; var arg_3444 any = map__794000388__3; if linked_3442 == nil { tmp3 = ifn_3443.Invoke_O__O(arg_3444) } else { tmp3 = linked_3442.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3441, arg_3444) }; if jrt.J2g_Truth(tmp3) { var root_3445 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_3446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3445, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3447 lang.IFn; if linked_3446 == nil { ifn_3447 = lang.IFn_Cast(root_3445) } else { ifn_3447 = nil }; var arg_3448 any = map__794000388__3; if linked_3446 == nil { map__794000388__4 = ifn_3447.Invoke_O__O(arg_3448) } else { map__794000388__4 = linked_3446.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3445, arg_3448) } } else { map__794000388__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000388__4 = map__794000388__3 }; var ns__5 any = lang.RT_Get_O_O__O_NoInit(map__794000388__4, A_arbace_go_repl_A_const_56); var line__6 any = lang.RT_Get_O_O__O_NoInit(map__794000388__4, A_arbace_go_repl_A_const_111); var ns_sym__7 any; var or__1927000174__auto____7 any = ns__5; _ = line__6; if



	jrt.J2g_Truth(or__1927000174__auto____7) { ns_sym__7 = or__1927000174__auto____7 } else { var root_3449 any = A_arbace_go_repl_A_const_227.GetRawRoot__O(); var linked_3450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3449, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_3451 lang.IFn; if linked_3450 == nil { ifn_3451 = lang.IFn_Cast(root_3449) } else { ifn_3451 = nil }; var arg_3452 any = A_arbace_go_repl_A_const_228.Get__O(); if linked_3450 == nil { ns_sym__7 = ifn_3451.Invoke_O__O(arg_3452) } else { ns_sym__7 = linked_3450.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_3449, arg_3452) } }; var st__8 any; var root_3453 any = /*line :419:1*/A_arbace_go_repl_A_const_72.GetRawRoot__O(); var linked_3454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3453, A_arbace_go_repl_package_state_A_fn_class); var ifn_3455 lang.IFn; if




	linked_3454 == nil { ifn_3455 = lang.IFn_Cast(root_3453) } else { ifn_3455 = nil }; var arg_3456 any = ns_sym__7; if linked_3454 == nil { st__8 = ifn_3455.Invoke_O__O(arg_3456) } else { st__8 = linked_3454.(*A_arbace_go_repl_package_state_A).Invoke_O_O__O(root_3453, arg_3456) }; var tmp4 /*line :425:1*/*lang.Keyword = A_arbace_go_repl_A_const_77; var tmp5 any; var root_3457 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_3458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3457, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3459 lang.IFn; if linked_3458 == nil { ifn_3459 = lang.IFn_Cast(root_3457) } else { ifn_3459 = nil }; var arg_3460 any = st__8; if linked_3458 == nil { tmp5 = ifn_3459.Invoke_O__O(arg_3460) } else { tmp5 = linked_3458.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3457, arg_3460) }; if jrt.J2g_Truth(tmp4.Invoke_O__O(tmp5)) {
		var root_3742 any = A_arbace_go_repl_A_const_83.GetRawRoot__O(); var linked_3743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3742, A_arbace_go_repl_update_file_A_fn_class); var ifn_3744 lang.IFn; if linked_3743 == nil { ifn_3744 = lang.IFn_Cast(root_3742) } else { ifn_3744 = nil }; var arg_3745 any = st__8; var arg_3746 any; var tmp6 *lang.Keyword = A_arbace_go_repl_A_const_58; var tmp7 any; var root_3748 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_3749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3748, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3750 lang.IFn; if linked_3749 == nil { ifn_3750 = lang.IFn_Cast(root_3748) } else { ifn_3750 = nil }; var arg_3751 any = st__8; if linked_3749 == nil { tmp7 = ifn_3750.Invoke_O__O(arg_3751) } else { tmp7 = linked_3749.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3748, arg_3751) }; arg_3746 = tmp6.Invoke_O__O(tmp7); var arg_3747 any; var tmp8 any = A_arbace_go_repl_declare_BANG__fn__794000390_A_New_O(form__0); var tmp9 *jrt.Class; var fncls__3759 *jrt.Class = A_arbace_go_repl_declare_BANG__fn__794000390_A_fn_class; if fncls__3759 == nil { var fncls__3759d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_go_repl_declare_BANG__fn__794000390_A_fn_class = fncls__3759d; tmp9 = fncls__3759d } else { tmp9 = fncls__3759 }; arg_3747 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); if linked_3743 == nil { ifn_3744.Invoke_O_O_O__O(arg_3745, arg_3746, arg_3747) } else { linked_3743.(*A_arbace_go_repl_update_file_A).Invoke_O_O_O_O__O(root_3742, arg_3745, arg_3746, arg_3747) }
//line :425:1
		return nil } else { var names__9 any; var root_3461 any = A_arbace_go_repl_A_const_17.GetRawRoot__O(); var linked_3462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3461, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_3463 lang.IFn

			if linked_3462 == nil { ifn_3463 = lang.IFn_Cast(root_3461) } else { ifn_3463 = nil }; var arg_3464 any; var root_3465 any = A_arbace_go_repl_A_const_229.GetRawRoot__O(); var linked_3466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3465, A_arbace_go_repl_decl_names_A_fn_class); var ifn_3467 lang.IFn; if linked_3466 == nil { ifn_3467 = lang.IFn_Cast(root_3465) } else { ifn_3467 = nil }; var arg_3468 any = form__0; if linked_3466 == nil { arg_3464 = ifn_3467.Invoke_O__O(arg_3468) } else { arg_3464 = linked_3466.(*A_arbace_go_repl_decl_names_A).Invoke_O_O__O(root_3465, arg_3468) }; if linked_3462 == nil { names__9 = ifn_3463.Invoke_O__O(arg_3464) } else { names__9 = linked_3462.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_3461, arg_3464) }
//line :425:1
			var old__10 any; var root_3469 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_3470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3469, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3471 lang.IFn

			if linked_3470 == nil { ifn_3471 = lang.IFn_Cast(root_3469) } else { ifn_3471 = nil }; var arg_3472 any = st__8; if linked_3470 == nil { old__10 = ifn_3471.Invoke_O__O(arg_3472) } else { old__10 = linked_3470.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3469, arg_3472) }
//line :425:1
			var files__11 any; var root_3473 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_3474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3473, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3475 lang.IFn




			if linked_3474 == nil { ifn_3475 = lang.IFn_Cast(root_3473) } else { ifn_3475 = nil }; var arg_3476 any; var iter__1927001039__auto____11 any; var tmp10 any = A_arbace_go_repl_declare_BANG__iter__794000392__794000396_A_New_O(names__9); var tmp11 *jrt.Class; var fncls__3587 *jrt.Class = A_arbace_go_repl_declare_BANG__iter__794000392__794000396_A_fn_class; if fncls__3587 == nil { var fncls__3587d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_go_repl_declare_BANG__iter__794000392__794000396_A_fn_class = fncls__3587d; tmp11 = fncls__3587d } else { tmp11 = fncls__3587 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); arg_3476 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(A_arbace_go_repl_A_const_57.Invoke_O__O(old__10)); if linked_3474 == nil { files__11 = ifn_3475.Invoke_O__O(arg_3476) } else { files__11 = linked_3474.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3473, arg_3476) }
//line :425:1
			var files__12 any; var tmp12 any; var root_3588 any = A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_3589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3588, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3590 lang.IFn






			if linked_3589 == nil { ifn_3590 = lang.IFn_Cast(root_3588) } else { ifn_3590 = nil }; var arg_3591 any; var tmp13 any = A_arbace_go_repl_declare_BANG__fn__794000410_A_New_O(old__10); var tmp14 *jrt.Class; var fncls__3593 *jrt.Class = A_arbace_go_repl_declare_BANG__fn__794000410_A_fn_class; if fncls__3593 == nil { var fncls__3593d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_go_repl_declare_BANG__fn__794000410_A_fn_class = fncls__3593d; tmp14 = fncls__3593d } else { tmp14 = fncls__3593 }; arg_3591 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var arg_3592 any = files__11; if linked_3589 == nil { tmp12 = ifn_3590.Invoke_O_O__O(arg_3591, arg_3592) } else { tmp12 = linked_3589.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3588, arg_3591, arg_3592) }; if jrt.J2g_Truth(tmp12) { files__12 = files__11 } else {

				var root_3594 any = A_arbace_go_repl_A_const_15.GetRawRoot__O(); var linked_3595 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3594, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_3596 lang.IFn; if linked_3595 == nil { ifn_3596 = lang.IFn_Cast(root_3594) } else { ifn_3596 = nil }; var arg_3597 any = files__11; var tmp15 any = A_arbace_go_repl_A_const_55; var arg_3598 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp15, A_arbace_go_repl_A_const_58.Invoke_O__O(old__10), A_arbace_go_repl_A_const_74, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_repl_A_const_81, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_repl_A_const_82, lang.PersistentVector_EMPTY.Ref())); if linked_3595 == nil { files__12 = ifn_3596.Invoke_O_O__O(arg_3597, arg_3598) } else { files__12 = linked_3595.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_3594, arg_3597, arg_3598) } }
//line :425:1
			var files__13 any; var root_3599 any = A_arbace_go_repl_A_const_80.GetRawRoot__O(); var linked_3600 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3599, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_3601 lang.IFn









			if linked_3600 == nil { ifn_3601 = lang.IFn_Cast(root_3599) } else { ifn_3601 = nil }; var arg_3602 any; var tmp16 any = A_arbace_go_repl_declare_BANG__fn__794000412_A_New_O_O(form__0, old__10); var tmp17 *jrt.Class; var fncls__3611 *jrt.Class = A_arbace_go_repl_declare_BANG__fn__794000412_A_fn_class; if fncls__3611 == nil { var fncls__3611d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_go_repl_declare_BANG__fn__794000412_A_fn_class = fncls__3611d; tmp17 = fncls__3611d } else { tmp17 = fncls__3611 }; arg_3602 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var arg_3603 any = files__12; if linked_3600 == nil { files__13 = ifn_3601.Invoke_O_O__O(arg_3602, arg_3603) } else { files__13 = linked_3600.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_3599, arg_3602, arg_3603) }
//line :425:1
			var ___14 any; var root_3612 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_3613 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3612, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3614 lang.IFn; _ = ___14










			if linked_3613 == nil { ifn_3614 = lang.IFn_Cast(root_3612) } else { ifn_3614 = nil }; var arg_3615 any = st__8; var arg_3616 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_3617 any = A_arbace_go_repl_A_const_57; var arg_3618 any = files__13; if linked_3613 == nil { ___14 = ifn_3614.Invoke_O_O_O_O__O(arg_3615, arg_3616, arg_3617, arg_3618) } else { ___14 = linked_3613.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_3612, arg_3615, arg_3616, arg_3617, arg_3618) }
//line :425:1
			var r__15 any; var tmp18 any = A_arbace_go_repl_declare_BANG__fn__794000414_A_New_O_O(st__8, old__10); var tmp19 *jrt.Class
			var fncls__3635 /*line :425:1*/*jrt.Class = A_arbace_go_repl_declare_BANG__fn__794000414_A_fn_class











			if fncls__3635 == nil { var fncls__3635d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_go_repl_declare_BANG__fn__794000414_A_fn_class = fncls__3635d; tmp19 = fncls__3635d } else { tmp19 = fncls__3635 }; r__15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil).Invoke__O()
//line :425:1
			var errs__16 any; var root_3636 any = A_arbace_go_repl_A_const_230.GetRawRoot__O(); var linked_3637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3636, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3638 lang.IFn













			if linked_3637 == nil { ifn_3638 = lang.IFn_Cast(root_3636) } else { ifn_3638 = nil }; var arg_3639 any; var tmp20 any = A_arbace_go_repl_declare_BANG__fn__794000416_A_New(); var tmp21 *jrt.Class; var fncls__3641 *jrt.Class = A_arbace_go_repl_declare_BANG__fn__794000416_A_fn_class; if fncls__3641 == nil { var fncls__3641d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_go_repl_declare_BANG__fn__794000416_A_fn_class = fncls__3641d; tmp21 = fncls__3641d } else { tmp21 = fncls__3641 }; arg_3639 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil); var arg_3640 any = A_arbace_go_repl_A_const_221.Invoke_O__O(r__15); if linked_3637 == nil { errs__16 = ifn_3638.Invoke_O_O__O(arg_3639, arg_3640) } else { errs__16 = linked_3637.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3636, arg_3639, arg_3640) }
//line :425:1
			var spec_of__17 any; var root_3642 any = A_arbace_go_repl_A_const_88.GetRawRoot__O(); var linked_3643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3642, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3644 lang.IFn
















			if linked_3643 == nil { ifn_3644 = lang.IFn_Cast(root_3642) } else { ifn_3644 = nil }; var arg_3645 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_3646 any; var root_3647 any = A_arbace_go_repl_A_const_102.GetRawRoot__O(); var linked_3648 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3647, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3649 lang.IFn; if linked_3648 == nil { ifn_3649 = lang.IFn_Cast(root_3647) } else { ifn_3649 = nil }; var arg_3650 any; var root_3652 any = A_arbace_go_repl_A_const_233.GetRawRoot__O(); var linked_3653 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3652, aot_arbace_core.A_arbace_core_juxt_A_fn_class); var ifn_3654 lang.IFn; if linked_3653 == nil { ifn_3654 = lang.IFn_Cast(root_3652) } else { ifn_3654 = nil }; var arg_3655 any = A_arbace_go_repl_A_const_234; var arg_3656 any = A_arbace_go_repl_A_const_209; if linked_3653 == nil { arg_3650 = ifn_3654.Invoke_O_O__O(arg_3655, arg_3656) } else { arg_3650 = linked_3653.(*aot_arbace_core.A_arbace_core_juxt_A).Invoke_O_O_O__O(root_3652, arg_3655, arg_3656) }; var arg_3651 any = A_arbace_go_repl_A_const_171.Invoke_O__O(r__15); if linked_3648 == nil { arg_3646 = ifn_3649.Invoke_O_O__O(arg_3650, arg_3651) } else { arg_3646 = linked_3648.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3647, arg_3650, arg_3651) }; if linked_3643 == nil { spec_of__17 = ifn_3644.Invoke_O_O__O(arg_3645, arg_3646) } else { spec_of__17 = linked_3643.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3642, arg_3645, arg_3646) }
//line :425:1
			var own_QMARK___18 any; var tmp22 any = A_arbace_go_repl_declare_BANG__own_QMARK___794000418_A_New_O_O(form__0, spec_of__17); var tmp23 *jrt.Class
			var fncls__3657 /*line :425:1*/*jrt.Class = A_arbace_go_repl_declare_BANG__own_QMARK___794000418_A_fn_class

















			if fncls__3657 == nil { var fncls__3657d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_go_repl_declare_BANG__own_QMARK___794000418_A_fn_class = fncls__3657d; tmp23 = fncls__3657d } else { tmp23 = fncls__3657 }; own_QMARK___18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil)
//line :425:1
			var own__19 any; var root_3658 any = A_arbace_go_repl_A_const_33.GetRawRoot__O(); var linked_3659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3658, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3660 lang.IFn


















			if linked_3659 == nil { ifn_3660 = lang.IFn_Cast(root_3658) } else { ifn_3660 = nil }; var arg_3661 any = own_QMARK___18; var arg_3662 any = errs__16; if linked_3659 == nil { own__19 = ifn_3660.Invoke_O_O__O(arg_3661, arg_3662) } else { own__19 = linked_3659.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3658, arg_3661, arg_3662) }
//line :425:1
			var others__20 any; var root_3663 any = A_arbace_go_repl_A_const_230.GetRawRoot__O(); var linked_3664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3663, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3665 lang.IFn



















			if linked_3664 == nil { ifn_3665 = lang.IFn_Cast(root_3663) } else { ifn_3665 = nil }; var arg_3666 any = own_QMARK___18; var arg_3667 any = errs__16; if linked_3664 == nil { others__20 = ifn_3665.Invoke_O_O__O(arg_3666, arg_3667) } else { others__20 = linked_3664.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3663, arg_3666, arg_3667) }
//line :425:1
			var broken__21 any; var root_3668 any = A_arbace_go_repl_A_const_17.GetRawRoot__O(); var linked_3669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3668, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_3670 lang.IFn




















			if linked_3669 == nil { ifn_3670 = lang.IFn_Cast(root_3668) } else { ifn_3670 = nil }; var arg_3671 any; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_236.GetRawRoot__O()); var tmp25 any = A_arbace_go_repl_A_const_229.GetRawRoot__O(); var tmp26 any; var root_3677 any = A_arbace_go_repl_A_const_87.GetRawRoot__O(); var linked_3678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3677, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_3679 lang.IFn; if linked_3678 == nil { ifn_3679 = lang.IFn_Cast(root_3677) } else { ifn_3679 = nil }; var arg_3680 any; var root_3681 any = A_arbace_go_repl_A_const_190.GetRawRoot__O(); var linked_3682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3681, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_3683 lang.IFn; if linked_3682 == nil { ifn_3683 = lang.IFn_Cast(root_3681) } else { ifn_3683 = nil }; var arg_3684 any; var tmp27 any = A_arbace_go_repl_declare_BANG__fn__794000420_A_New_O(spec_of__17); var tmp28 *jrt.Class; var fncls__3686 *jrt.Class = A_arbace_go_repl_declare_BANG__fn__794000420_A_fn_class; if fncls__3686 == nil { var fncls__3686d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_go_repl_declare_BANG__fn__794000420_A_fn_class = fncls__3686d; tmp28 = fncls__3686d } else { tmp28 = fncls__3686 }; arg_3684 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil); var arg_3685 any = others__20; if linked_3682 == nil { arg_3680 = ifn_3683.Invoke_O_O__O(arg_3684, arg_3685) } else { arg_3680 = linked_3682.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_3681, arg_3684, arg_3685) }; if linked_3678 == nil { tmp26 = ifn_3679.Invoke_O__O(arg_3680) } else { tmp26 = linked_3678.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_3677, arg_3680) }; arg_3671 = tmp24.Invoke_O_O__O(tmp25, tmp26); if linked_3669 == nil { broken__21 = ifn_3670.Invoke_O__O(arg_3671) } else { broken__21 = linked_3669.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_3668, arg_3671) }
			var tmp29 any; var root_3760 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_3761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3760, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3762 lang.IFn; if linked_3761 == nil { ifn_3762 = lang.IFn_Cast(root_3760) } else { ifn_3762 = nil }; var arg_3763 any = own__19; if linked_3761 == nil { tmp29 = ifn_3762.Invoke_O__O(arg_3763) } else { tmp29 = linked_3761.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3760, arg_3763) }; if jrt.J2g_Truth(tmp29) {
				var root_3810 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_3811 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3810, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3812 lang.IFn; if linked_3811 == nil { ifn_3812 = lang.IFn_Cast(root_3810) } else { ifn_3812 = nil }; var arg_3813 any = st__8; var arg_3814 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_3815 any = A_arbace_go_repl_A_const_57; var arg_3816 any = A_arbace_go_repl_A_const_57.Invoke_O__O(old__10); if linked_3811 == nil { ifn_3812.Invoke_O_O_O_O__O(arg_3813, arg_3814, arg_3815, arg_3816) } else { linked_3811.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_3810, arg_3813, arg_3814, arg_3815, arg_3816) }
//line :447:1
				var tmp30 any; var root_3764 any = A_arbace_go_repl_A_const_69.GetRawRoot__O(); var linked_3765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3764, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_3766 lang.IFn

				if linked_3765 == nil { ifn_3766 = lang.IFn_Cast(root_3764) } else { ifn_3766 = nil }; var arg_3767 any; var tmp31 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_46, nil); var tmp32 any; var root_3769 any = A_arbace_go_repl_A_const_115.GetRawRoot__O(); var linked_3770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3769, A_arbace_go_repl_error_text_A_fn_class); var ifn_3771 lang.IFn; if linked_3770 == nil { ifn_3771 = lang.IFn_Cast(root_3769) } else { ifn_3771 = nil }; var arg_3772 any = own__19; var arg_3773 any; var root_3774 any = A_arbace_go_repl_A_const_238.GetRawRoot__O(); var linked_3775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3774, A_arbace_go_repl_repl_source_A_fn_class); var ifn_3776 lang.IFn; if linked_3775 == nil { ifn_3776 = lang.IFn_Cast(root_3774) } else { ifn_3776 = nil }; if linked_3775 == nil { arg_3773 = ifn_3776.Invoke__O() } else { arg_3773 = linked_3775.(*A_arbace_go_repl_repl_source_A).Invoke_O__O(root_3774) }; if linked_3770 == nil { tmp32 = ifn_3771.Invoke_O_O__O(arg_3772, arg_3773) } else { tmp32 = linked_3770.(*A_arbace_go_repl_error_text_A).Invoke_O_O_O__O(root_3769, arg_3772, arg_3773) }; arg_3767 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp31, jrt.RefArrayOf(jrt.Object_class, nil, tmp32)).Ref(); var arg_3768 any; var tmp33 any = A_arbace_go_repl_A_const_222; var tmp34 any; var root_3777 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_3778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3777, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3779 lang.IFn; if linked_3778 == nil { ifn_3779 = lang.IFn_Cast(root_3777) } else { ifn_3779 = nil }; var arg_3780 any = own__19; if linked_3778 == nil { tmp34 = ifn_3779.Invoke_O__O(arg_3780) } else { tmp34 = linked_3778.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3777, arg_3780) }; arg_3768 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp33, tmp34)); if linked_3765 == nil { tmp30 = ifn_3766.Invoke_O_O__O(arg_3767, arg_3768) } else { tmp30 = linked_3765.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_3764, arg_3767, arg_3768) }
//line :447:1
				panic(jrt.Thrown(jrt.Throwable_Cast(tmp30)))
			}

			var tmp35 any; var root_3781 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_3782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3781, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3783 lang.IFn; if linked_3782 == nil { ifn_3783 = lang.IFn_Cast(root_3781) } else { ifn_3783 = nil }; var arg_3784 any = others__20; if linked_3782 == nil { tmp35 = ifn_3783.Invoke_O__O(arg_3784) } else { tmp35 = linked_3782.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3781, arg_3784) }; if jrt.J2g_Truth(tmp35) {
				var root_3817 any = A_arbace_go_repl_A_const_198.GetRawRoot__O(); var linked_3818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3817, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3819 lang.IFn; if linked_3818 == nil { ifn_3819 = lang.IFn_Cast(root_3817) } else { ifn_3819 = nil }; var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_38.GetRawRoot__O()); var tmp37 any = A_arbace_go_repl_A_const_241; var arg_3820 any = tmp36.Invoke_O_O__O(tmp37, A_arbace_go_repl_A_const_242.Get__O()); if linked_3818 == nil { ifn_3819.Invoke_O__O(arg_3820) } else { linked_3818.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3817, arg_3820) }; var tmp38 any = A_arbace_go_repl_declare_BANG__fn__794000422_A_New_O_O(broken__21, others__20); var tmp39 *jrt.Class; var fncls__3809 *jrt.Class = A_arbace_go_repl_declare_BANG__fn__794000422_A_fn_class; if fncls__3809 == nil { var fncls__3809d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_go_repl_declare_BANG__fn__794000422_A_fn_class = fncls__3809d; tmp39 = fncls__3809d } else { tmp39 = fncls__3809 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp38, tmp39, nil).Invoke__O() }
//line :425:1
			var var_QMARK___22 bool; var tmp40 any; var root_3687 any = A_arbace_go_repl_A_const_89.GetRawRoot__O(); var linked_3688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3687, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_3689 lang.IFn




























			if linked_3688 == nil { ifn_3689 = lang.IFn_Cast(root_3687) } else { ifn_3689 = nil }; var arg_3690 any = form__0; if linked_3688 == nil { tmp40 = ifn_3689.Invoke_O__O(arg_3690) } else { tmp40 = linked_3688.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_3687, arg_3690) }; var_QMARK___22 = lang.Util_Equiv_O_O__Z_NoInit(Lit_24, tmp40)
//line :425:1
			var map__794000424__23 any; var tmp41 any = A_arbace_go_repl_declare_BANG__fn__794000426_A_New_O_Z_O_O_O_O(broken__21, var_QMARK___22, r__15, st__8, old__10, names__9); var tmp42 *jrt.Class
			var fncls__3704 /*line :425:1*/*jrt.Class = A_arbace_go_repl_declare_BANG__fn__794000426_A_fn_class





























			if fncls__3704 == nil { var fncls__3704d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_go_repl_declare_BANG__fn__794000426_A_fn_class = fncls__3704d; tmp42 = fncls__3704d } else { tmp42 = fncls__3704 }; map__794000424__23 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp41, tmp42, nil).Invoke__O()
//line :425:1
			var map__794000424__24 any




























			if lang.ISeq_InstanceOf(map__794000424__23) { var tmp43 any; var root_3705 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_3706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3705, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3707 lang.IFn; if linked_3706 == nil { ifn_3707 = lang.IFn_Cast(root_3705) } else { ifn_3707 = nil }; var arg_3708 any = map__794000424__23; if linked_3706 == nil { tmp43 = ifn_3707.Invoke_O__O(arg_3708) } else { tmp43 = linked_3706.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3705, arg_3708) }; if jrt.J2g_Truth(tmp43) { var tmp44 any; var root_3709 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_3710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3709, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3711 lang.IFn; if linked_3710 == nil { ifn_3711 = lang.IFn_Cast(root_3709) } else { ifn_3711 = nil }; var arg_3712 any = map__794000424__23; if linked_3710 == nil { tmp44 = ifn_3711.Invoke_O__O(arg_3712) } else { tmp44 = linked_3710.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3709, arg_3712) }; map__794000424__24 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp44, jrt.Object_class.ArrayClass())).Ref() } else { var tmp45 any; var root_3713 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_3714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3713, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3715 lang.IFn; if linked_3714 == nil { ifn_3715 = lang.IFn_Cast(root_3713) } else { ifn_3715 = nil }; var arg_3716 any = map__794000424__23; if linked_3714 == nil { tmp45 = ifn_3715.Invoke_O__O(arg_3716) } else { tmp45 = linked_3714.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3713, arg_3716) }; if jrt.J2g_Truth(tmp45) { var root_3717 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_3718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3717, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3719 lang.IFn; if linked_3718 == nil { ifn_3719 = lang.IFn_Cast(root_3717) } else { ifn_3719 = nil }; var arg_3720 any = map__794000424__23; if linked_3718 == nil { map__794000424__24 = ifn_3719.Invoke_O__O(arg_3720) } else { map__794000424__24 = linked_3718.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3717, arg_3720) } } else { map__794000424__24 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000424__24 = map__794000424__23 }
//line :425:1
			var inits__25 any = lang.RT_Get_O_O__O_NoInit(map__794000424__24, A_arbace_go_repl_A_const_182); var new_vars__26 any = lang.RT_Get_O_O__O_NoInit(map__794000424__24, A_arbace_go_repl_A_const_195); var init_funcs__27 any = lang.RT_Get_O_O__O_NoInit(map__794000424__24, A_arbace_go_repl_A_const_192); _ = new_vars__26


































			if var_QMARK___22 {
				var root_3826 any = A_arbace_go_repl_A_const_223.GetRawRoot__O(); var linked_3827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3826, A_arbace_go_repl_call0_A_fn_class); var ifn_3828 lang.IFn; if linked_3827 == nil { ifn_3828 = lang.IFn_Cast(root_3826) } else { ifn_3828 = nil }; var arg_3829 any = inits__25; var arg_3830 any = Lit_15; if linked_3827 == nil { ifn_3828.Invoke_O_O__O(arg_3829, arg_3830) } else { linked_3827.(*A_arbace_go_repl_call0_A).Invoke_O_O_O__O(root_3826, arg_3829, arg_3830) } }
			var tmp46 bool; var and__1927000168__auto____28 bool; var tmp47 any; var root_3831 any = A_arbace_go_repl_A_const_89.GetRawRoot__O(); var linked_3832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3831, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_3833 lang.IFn; if linked_3832 == nil { ifn_3833 = lang.IFn_Cast(root_3831) } else { ifn_3833 = nil }; var arg_3834 any = form__0; if linked_3832 == nil { tmp47 = ifn_3833.Invoke_O__O(arg_3834) } else { tmp47 = linked_3832.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_3831, arg_3834) }; and__1927000168__auto____28 = lang.Util_Equiv_O_O__Z_NoInit(Lit_21, tmp47); if and__1927000168__auto____28 { var tmp48 any; var root_3835 any = A_arbace_go_repl_A_const_73.GetRawRoot__O(); var linked_3836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3835, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_3837 lang.IFn; if linked_3836 == nil { ifn_3837 = lang.IFn_Cast(root_3835) } else { ifn_3837 = nil }; var arg_3838 any; var root_3839 any = A_arbace_go_repl_A_const_103.GetRawRoot__O(); var linked_3840 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3839, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_3841 lang.IFn; if linked_3840 == nil { ifn_3841 = lang.IFn_Cast(root_3839) } else { ifn_3841 = nil }; var arg_3842 any = form__0; if linked_3840 == nil { arg_3838 = ifn_3841.Invoke_O__O(arg_3842) } else { arg_3838 = linked_3840.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_3839, arg_3842) }; if linked_3836 == nil { tmp48 = ifn_3837.Invoke_O__O(arg_3838) } else { tmp48 = linked_3836.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_3835, arg_3838) }; tmp46 = lang.Util_Equiv_O_O__Z_NoInit(Lit_15, tmp48) } else { tmp46 = and__1927000168__auto____28 }; if tmp46 {
				var root_3843 any = A_arbace_go_repl_A_const_223.GetRawRoot__O(); var linked_3844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3843, A_arbace_go_repl_call0_A_fn_class); var ifn_3845 lang.IFn; if linked_3844 == nil { ifn_3845 = lang.IFn_Cast(root_3843) } else { ifn_3845 = nil }; var arg_3846 any; var root_3848 any = A_arbace_go_repl_A_const_66.GetRawRoot__O(); var linked_3849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3848, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_3850 lang.IFn; if linked_3849 == nil { ifn_3850 = lang.IFn_Cast(root_3848) } else { ifn_3850 = nil }; var arg_3851 any = init_funcs__27; if linked_3849 == nil { arg_3846 = ifn_3850.Invoke_O__O(arg_3851) } else { arg_3846 = linked_3849.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_3848, arg_3851) }; var arg_3847 any = Lit_15; if linked_3844 == nil { ifn_3845.Invoke_O_O__O(arg_3846, arg_3847) } else { linked_3844.(*A_arbace_go_repl_call0_A).Invoke_O_O_O__O(root_3843, arg_3846, arg_3847) } }
//line :425:1
			var temp__1927000414__auto____28 any; var root_3721 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_3722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3721, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3723 lang.IFn






































			if linked_3722 == nil { ifn_3723 = lang.IFn_Cast(root_3721) } else { ifn_3723 = nil }; var arg_3724 any; var root_3725 any = A_arbace_go_repl_A_const_229.GetRawRoot__O(); var linked_3726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3725, A_arbace_go_repl_decl_names_A_fn_class); var ifn_3727 lang.IFn; if linked_3726 == nil { ifn_3727 = lang.IFn_Cast(root_3725) } else { ifn_3727 = nil }; var arg_3728 any = form__0; if linked_3726 == nil { arg_3724 = ifn_3727.Invoke_O__O(arg_3728) } else { arg_3724 = linked_3726.(*A_arbace_go_repl_decl_names_A).Invoke_O_O__O(root_3725, arg_3728) }; if linked_3722 == nil { temp__1927000414__auto____28 = ifn_3723.Invoke_O__O(arg_3724) } else { temp__1927000414__auto____28 = linked_3722.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3721, arg_3724) }; if jrt.J2g_Truth(temp__1927000414__auto____28) { var nm__29 any = temp__1927000414__auto____28; var root_3729 any = A_arbace_go_repl_A_const_237.GetRawRoot__O(); var linked_3730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3729, aot_arbace_core.A_arbace_core_find_var_A_fn_class); var ifn_3731 lang.IFn
				if linked_3730 == nil { ifn_3731 = lang.IFn_Cast(root_3729) } else { ifn_3731 = nil }; var arg_3732 any; var root_3733 any = A_arbace_go_repl_A_const_46.GetRawRoot__O(); var linked_3734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3733, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3735 lang.IFn; if linked_3734 == nil { ifn_3735 = lang.IFn_Cast(root_3733) } else { ifn_3735 = nil }; var arg_3736 any; var root_3738 any = A_arbace_go_repl_A_const_51.GetRawRoot__O(); var linked_3739 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3738, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_3740 lang.IFn; if linked_3739 == nil { ifn_3740 = lang.IFn_Cast(root_3738) } else { ifn_3740 = nil }; var arg_3741 any = A_arbace_go_repl_A_const_56.Invoke_O__O(old__10); if linked_3739 == nil { arg_3736 = ifn_3740.Invoke_O__O(arg_3741) } else { arg_3736 = linked_3739.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_3738, arg_3741) }; var arg_3737 any = nm__29; if linked_3734 == nil { arg_3732 = ifn_3735.Invoke_O_O__O(arg_3736, arg_3737) } else { arg_3732 = linked_3734.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_3733, arg_3736, arg_3737) }; if linked_3730 == nil { return ifn_3731.Invoke_O__O(arg_3732) } else { return linked_3730.(*aot_arbace_core.A_arbace_core_find_var_A).Invoke_O_O__O(root_3729, arg_3732) } } else {
//line :464:1
					return nil } } }
//line :426:1
func A_arbace_go_repl_declare_BANG__fn__794000390_A_New_O(p0 any) *A_arbace_go_repl_declare_BANG__fn__794000390_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__fn__794000390_A{}; t.Ctor_O(p0); return t }
//line :426:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000390_A) Ctor_O(c__form any) { t.F_form = c__form }
//line :426:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000390_A) Invoke_O_O__O(self, p1__794000381_SHARP___1 any) any { var root_3752 any = A_arbace_go_repl_A_const_79.GetRawRoot__O(); var linked_3753 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3752, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_3754 lang.IFn; if linked_3753 == nil { ifn_3754 = lang.IFn_Cast(root_3752) } else { ifn_3754 = nil }; var arg_3755 any = p1__794000381_SHARP___1; var arg_3756 any = A_arbace_go_repl_A_const_82; var arg_3757 any = A_arbace_go_repl_A_const_15.GetRawRoot__O(); var arg_3758 any = t.F_form; if linked_3753 == nil { return ifn_3754.Invoke_O_O_O_O__O(arg_3755, arg_3756, arg_3757, arg_3758) } else { return linked_3753.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_3752, arg_3755, arg_3756, arg_3757, arg_3758) } }



func A_arbace_go_repl_declare_BANG__iter__794000392__794000396_A_New_O(p0 any) *A_arbace_go_repl_declare_BANG__iter__794000392__794000396_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__iter__794000392__794000396_A{}; t.Ctor_O(p0); return t }
//line :430:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000392__794000396_A) Ctor_O(c__names any) { t.F_names = c__names }
//line :430:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000392__794000396_A) Invoke_O_O__O(self, s__794000393__1 any) any { var tmp1 any = A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_A_New_O_O_O(self, s__794000393__1, t.F_names); var tmp2 *jrt.Class; var fncls__3586 *jrt.Class = A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_A_fn_class; if fncls__3586 == nil { var fncls__3586d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_A_fn_class = fncls__3586d; tmp2 = fncls__3586d } else { tmp2 = fncls__3586 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :430:1
func A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :430:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_A) Ctor_O_O_O(c__iter__794000392, c__s__794000393, c__names any) { t.F_iter__794000392 = c__iter__794000392; t.F_s__794000393 = c__s__794000393; t.F_names = c__names }
//line :430:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_A) Invoke_O__O(self any) any { { var s__794000393__1 any; var t_ any = t.F_s__794000393; t.F_s__794000393 = nil; s__794000393__1 = t_; for { var temp__1927000414__auto____2 any; var root_3477 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_3478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3477, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3479 lang.IFn; if linked_3478 == nil { ifn_3479 = lang.IFn_Cast(root_3477) } else { ifn_3479 = nil }; var arg_3480 any = s__794000393__1; if linked_3478 == nil { temp__1927000414__auto____2 = ifn_3479.Invoke_O__O(arg_3480) } else { temp__1927000414__auto____2 = linked_3478.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3477, arg_3480) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__794000393__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3481 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_3482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3481, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3483 lang.IFn; if linked_3482 == nil { ifn_3483 = lang.IFn_Cast(root_3481) } else { ifn_3483 = nil }; var arg_3484 any = s__794000393__3; if linked_3482 == nil { tmp1 = ifn_3483.Invoke_O__O(arg_3484) } else { tmp1 = linked_3482.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3481, arg_3484) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3485 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_3486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3485, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3487 lang.IFn; if linked_3486 == nil { ifn_3487 = lang.IFn_Cast(root_3485) } else { ifn_3487 = nil }; var arg_3488 any = s__794000393__3; if linked_3486 == nil { c__1927001037__auto____4 = ifn_3487.Invoke_O__O(arg_3488) } else { c__1927001037__auto____4 = linked_3486.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3485, arg_3488) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__794000395__6 any; var root_3489 any = A_arbace_go_repl_A_const_95.GetRawRoot__O(); var linked_3490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3489, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3491 lang.IFn; if linked_3490 == nil { ifn_3491 = lang.IFn_Cast(root_3489) } else { ifn_3491 = nil }; var arg_3492 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3490 == nil { b__794000395__6 = ifn_3491.Invoke_O__O(arg_3492) } else { b__794000395__6 = linked_3490.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3489, arg_3492) }; var tmp2 any = A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_A_New_O_I_O_O(b__794000395__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_names); var tmp3 *jrt.Class; var fncls__3524 *jrt.Class = A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_A_fn_class; if fncls__3524 == nil { var fncls__3524d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_A_fn_class = fncls__3524d; tmp3 = fncls__3524d } else { tmp3 = fncls__3524 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3525 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_3526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3525, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3527 lang.IFn; if linked_3526 == nil { ifn_3527 = lang.IFn_Cast(root_3525) } else { ifn_3527 = nil }; var arg_3528 any; var root_3530 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_3531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3530, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3532 lang.IFn; if linked_3531 == nil { ifn_3532 = lang.IFn_Cast(root_3530) } else { ifn_3532 = nil }; var arg_3533 any = b__794000395__6; if linked_3531 == nil { arg_3528 = ifn_3532.Invoke_O__O(arg_3533) } else { arg_3528 = linked_3531.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3530, arg_3533) }; var arg_3529 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__794000392); var tmp5 any; var root_3534 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_3535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3534, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3536 lang.IFn; if linked_3535 == nil { ifn_3536 = lang.IFn_Cast(root_3534) } else { ifn_3536 = nil }; var arg_3537 any = s__794000393__3; if linked_3535 == nil { tmp5 = ifn_3536.Invoke_O__O(arg_3537) } else { tmp5 = linked_3535.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3534, arg_3537) }; arg_3529 = tmp4.Invoke_O__O(tmp5); if linked_3526 == nil { return ifn_3527.Invoke_O_O__O(arg_3528, arg_3529) } else { return linked_3526.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3525, arg_3528, arg_3529) } } else { var root_3538 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_3539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3538, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3540 lang.IFn; if linked_3539 == nil { ifn_3540 = lang.IFn_Cast(root_3538) } else { ifn_3540 = nil }; var arg_3541 any; var root_3543 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_3544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3543, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3545 lang.IFn; if linked_3544 == nil { ifn_3545 = lang.IFn_Cast(root_3543) } else { ifn_3545 = nil }; var arg_3546 any = b__794000395__6; if linked_3544 == nil { arg_3541 = ifn_3545.Invoke_O__O(arg_3546) } else { arg_3541 = linked_3544.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3543, arg_3546) }; var arg_3542 any; if linked_3539 == nil { return ifn_3540.Invoke_O_O__O(arg_3541, arg_3542) } else { return linked_3539.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3538, arg_3541, arg_3542) } } } else { var fi__4 any; var root_3547 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_3548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3547, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3549 lang.IFn; if linked_3548 == nil { ifn_3549 = lang.IFn_Cast(root_3547) } else { ifn_3549 = nil }; var arg_3550 any = s__794000393__3; if linked_3548 == nil { fi__4 = ifn_3549.Invoke_O__O(arg_3550) } else { fi__4 = linked_3548.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3547, arg_3550) }; var root_3551 any = A_arbace_go_repl_A_const_100.GetRawRoot__O(); var linked_3552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3551, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3553 lang.IFn; if linked_3552 == nil { ifn_3553 = lang.IFn_Cast(root_3551) } else { ifn_3553 = nil }; var arg_3554 any; var root_3556 any = A_arbace_go_repl_A_const_79.GetRawRoot__O(); var linked_3557 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3556, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_3558 lang.IFn
														if linked_3557 == nil { ifn_3558 = lang.IFn_Cast(root_3556) } else { ifn_3558 = nil }; var arg_3559 any = fi__4; var arg_3560 any = A_arbace_go_repl_A_const_82; var arg_3561 any; var tmp6 any = A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000404_A_New_O(t.F_names); var tmp7 *jrt.Class; var fncls__3581 *jrt.Class = A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000404_A_fn_class; if fncls__3581 == nil { var fncls__3581d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000404_A_fn_class = fncls__3581d; tmp7 = fncls__3581d } else { tmp7 = fncls__3581 }; arg_3561 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_3557 == nil { arg_3554 = ifn_3558.Invoke_O_O_O__O(arg_3559, arg_3560, arg_3561) } else { arg_3554 = linked_3557.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_3556, arg_3559, arg_3560, arg_3561) }
//line :430:1
	var arg_3555 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__794000392); var tmp9 any; var root_3582 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_3583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3582, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3584 lang.IFn; if linked_3583 == nil { ifn_3584 = lang.IFn_Cast(root_3582) } else { ifn_3584 = nil }; var arg_3585 any = s__794000393__3; if linked_3583 == nil { tmp9 = ifn_3584.Invoke_O__O(arg_3585) } else { tmp9 = linked_3583.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3582, arg_3585) }; arg_3555 = tmp8.Invoke_O__O(tmp9); if linked_3552 == nil { return ifn_3553.Invoke_O_O__O(arg_3554, arg_3555) } else { return linked_3552.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3551, arg_3554, arg_3555) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :430:1
func A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :430:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_A) Ctor_O_I_O_O(c__b__794000395 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__names any) { t.F_b__794000395 = c__b__794000395; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_names = c__names }
//line :430:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_A) Invoke_O__O(self any) any { { var i__794000394__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__794000394__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fi__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__794000394__1)); var root_3493 any = A_arbace_go_repl_A_const_96.GetRawRoot__O(); var linked_3494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3493, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3495 lang.IFn; if linked_3494 == nil { ifn_3495 = lang.IFn_Cast(root_3493) } else { ifn_3495 = nil }; var arg_3496 any = t.F_b__794000395; var arg_3497 any; var root_3498 any = A_arbace_go_repl_A_const_79.GetRawRoot__O(); var linked_3499 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3498, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_3500 lang.IFn
																if linked_3499 == nil { ifn_3500 = lang.IFn_Cast(root_3498) } else { ifn_3500 = nil }; var arg_3501 any = fi__2; var arg_3502 any = A_arbace_go_repl_A_const_82; var arg_3503 any; var tmp2 any = A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_fn__794000399_A_New_O(t.F_names); var tmp3 *jrt.Class; var fncls__3523 *jrt.Class = A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_fn__794000399_A_fn_class; if fncls__3523 == nil { var fncls__3523d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_fn__794000399_A_fn_class = fncls__3523d; tmp3 = fncls__3523d } else { tmp3 = fncls__3523 }; arg_3503 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); if linked_3499 == nil { arg_3497 = ifn_3500.Invoke_O_O_O__O(arg_3501, arg_3502, arg_3503) } else { arg_3497 = linked_3499.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_3498, arg_3501, arg_3502, arg_3503) }
//line :430:1
	if linked_3494 == nil { ifn_3495.Invoke_O_O__O(arg_3496, arg_3497) } else { linked_3494.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3493, arg_3496, arg_3497) }; i__794000394__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000394__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_fn__794000399_A_New_O(p0 any) *A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_fn__794000399_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_fn__794000399_A{}; t.Ctor_O(p0); return t }
//line :431:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_fn__794000399_A) Ctor_O(c__names any) { t.F_names = c__names }
//line :431:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_fn__794000399_A) Invoke_O_O__O(self, ds__1 any) any { var root_3504 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_3505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3504, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3506 lang.IFn; if linked_3505 == nil { ifn_3506 = lang.IFn_Cast(root_3504) } else { ifn_3506 = nil }; var arg_3507 any; var root_3508 any = A_arbace_go_repl_A_const_230.GetRawRoot__O(); var linked_3509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3508, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3510 lang.IFn; if linked_3509 == nil { ifn_3510 = lang.IFn_Cast(root_3508) } else { ifn_3510 = nil }; var arg_3511 any; var tmp1 any = A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_fn__794000399_fn__794000400_A_New_O(t.F_names); var tmp2 *jrt.Class; var fncls__3522 *jrt.Class = A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_fn__794000399_fn__794000400_A_fn_class; if fncls__3522 == nil { var fncls__3522d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_fn__794000399_fn__794000400_A_fn_class = fncls__3522d; tmp2 = fncls__3522d } else { tmp2 = fncls__3522 }; arg_3511 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_3512 any = ds__1; if linked_3509 == nil { arg_3507 = ifn_3510.Invoke_O_O__O(arg_3511, arg_3512) } else { arg_3507 = linked_3509.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3508, arg_3511, arg_3512) }; if linked_3505 == nil { return ifn_3506.Invoke_O__O(arg_3507) } else { return linked_3505.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3504, arg_3507) } }
//line :431:1
func A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_fn__794000399_fn__794000400_A_New_O(p0 any) *A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_fn__794000399_fn__794000400_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_fn__794000399_fn__794000400_A{}; t.Ctor_O(p0); return t }
//line :431:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_fn__794000399_fn__794000400_A) Ctor_O(c__names any) { t.F_names = c__names }
//line :431:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_fn__794000399_fn__794000400_A) Invoke_O_O__O(self, p1__794000382_SHARP___1 any) any { var root_3513 any = A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_3514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3513, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3515 lang.IFn; if linked_3514 == nil { ifn_3515 = lang.IFn_Cast(root_3513) } else { ifn_3515 = nil }; var arg_3516 any = t.F_names; var arg_3517 any; var root_3518 any = A_arbace_go_repl_A_const_229.GetRawRoot__O(); var linked_3519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3518, A_arbace_go_repl_decl_names_A_fn_class); var ifn_3520 lang.IFn; if linked_3519 == nil { ifn_3520 = lang.IFn_Cast(root_3518) } else { ifn_3520 = nil }; var arg_3521 any = p1__794000382_SHARP___1; if linked_3519 == nil { arg_3517 = ifn_3520.Invoke_O__O(arg_3521) } else { arg_3517 = linked_3519.(*A_arbace_go_repl_decl_names_A).Invoke_O_O__O(root_3518, arg_3521) }; if linked_3514 == nil { return ifn_3515.Invoke_O_O__O(arg_3516, arg_3517) } else { return linked_3514.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3513, arg_3516, arg_3517) } }
//line :431:1
func A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000404_A_New_O(p0 any) *A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000404_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000404_A{}; t.Ctor_O(p0); return t }
//line :431:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000404_A) Ctor_O(c__names any) { t.F_names = c__names }
//line :431:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000404_A) Invoke_O_O__O(self, ds__1 any) any { var root_3562 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_3563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3562, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3564 lang.IFn; if linked_3563 == nil { ifn_3564 = lang.IFn_Cast(root_3562) } else { ifn_3564 = nil }; var arg_3565 any; var root_3566 any = A_arbace_go_repl_A_const_230.GetRawRoot__O(); var linked_3567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3566, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3568 lang.IFn; if linked_3567 == nil { ifn_3568 = lang.IFn_Cast(root_3566) } else { ifn_3568 = nil }; var arg_3569 any; var tmp1 any = A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000404_fn__794000405_A_New_O(t.F_names); var tmp2 *jrt.Class; var fncls__3580 *jrt.Class = A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000404_fn__794000405_A_fn_class; if fncls__3580 == nil { var fncls__3580d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000404_fn__794000405_A_fn_class = fncls__3580d; tmp2 = fncls__3580d } else { tmp2 = fncls__3580 }; arg_3569 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_3570 any = ds__1; if linked_3567 == nil { arg_3565 = ifn_3568.Invoke_O_O__O(arg_3569, arg_3570) } else { arg_3565 = linked_3567.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3566, arg_3569, arg_3570) }; if linked_3563 == nil { return ifn_3564.Invoke_O__O(arg_3565) } else { return linked_3563.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3562, arg_3565) } }
//line :431:1
func A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000404_fn__794000405_A_New_O(p0 any) *A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000404_fn__794000405_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000404_fn__794000405_A{}; t.Ctor_O(p0); return t }
//line :431:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000404_fn__794000405_A) Ctor_O(c__names any) { t.F_names = c__names }
//line :431:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000404_fn__794000405_A) Invoke_O_O__O(self, p1__794000382_SHARP___1 any) any { var root_3571 any = A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_3572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3571, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3573 lang.IFn; if linked_3572 == nil { ifn_3573 = lang.IFn_Cast(root_3571) } else { ifn_3573 = nil }; var arg_3574 any = t.F_names; var arg_3575 any; var root_3576 any = A_arbace_go_repl_A_const_229.GetRawRoot__O(); var linked_3577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3576, A_arbace_go_repl_decl_names_A_fn_class); var ifn_3578 lang.IFn; if linked_3577 == nil { ifn_3578 = lang.IFn_Cast(root_3576) } else { ifn_3578 = nil }; var arg_3579 any = p1__794000382_SHARP___1; if linked_3577 == nil { arg_3575 = ifn_3578.Invoke_O__O(arg_3579) } else { arg_3575 = linked_3577.(*A_arbace_go_repl_decl_names_A).Invoke_O_O__O(root_3576, arg_3579) }; if linked_3572 == nil { return ifn_3573.Invoke_O_O__O(arg_3574, arg_3575) } else { return linked_3572.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3571, arg_3574, arg_3575) } }
func A_arbace_go_repl_declare_BANG__fn__794000410_A_New_O(p0 any) *A_arbace_go_repl_declare_BANG__fn__794000410_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__fn__794000410_A{}; t.Ctor_O(p0); return t }
//line :432:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000410_A) Ctor_O(c__old any) { t.F_old = c__old }
//line :432:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000410_A) Invoke_O_O__O(self, p1__794000383_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_repl_A_const_58.Invoke_O__O(t.F_old), A_arbace_go_repl_A_const_55.Invoke_O__O(p1__794000383_SHARP___1))).Ref() }


func A_arbace_go_repl_declare_BANG__fn__794000412_A_New_O_O(p0, p1 any) *A_arbace_go_repl_declare_BANG__fn__794000412_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__fn__794000412_A{}; t.Ctor_O_O(p0, p1); return t }
//line :435:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000412_A) Ctor_O_O(c__form, c__old any) { t.F_form = c__form; t.F_old = c__old }
//line :435:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000412_A) Invoke_O_O__O(self, p1__794000384_SHARP___1 any) any { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_repl_A_const_58.Invoke_O__O(t.F_old), A_arbace_go_repl_A_const_55.Invoke_O__O(p1__794000384_SHARP___1)) { var root_3604 any = A_arbace_go_repl_A_const_79.GetRawRoot__O(); var linked_3605 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3604, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_3606 lang.IFn; if linked_3605 == nil { ifn_3606 = lang.IFn_Cast(root_3604) } else { ifn_3606 = nil }; var arg_3607 any = p1__794000384_SHARP___1; var arg_3608 any = A_arbace_go_repl_A_const_82; var arg_3609 any = A_arbace_go_repl_A_const_15.GetRawRoot__O(); var arg_3610 any = t.F_form; if linked_3605 == nil { return ifn_3606.Invoke_O_O_O_O__O(arg_3607, arg_3608, arg_3609, arg_3610) } else { return linked_3605.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_3604, arg_3607, arg_3608, arg_3609, arg_3610) } } else { return p1__794000384_SHARP___1 } }

func A_arbace_go_repl_declare_BANG__fn__794000414_A_New_O_O(p0, p1 any) *A_arbace_go_repl_declare_BANG__fn__794000414_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__fn__794000414_A{}; t.Ctor_O_O(p0, p1); return t }
//line :437:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000414_A) Ctor_O_O(c__st, c__old any) { t.F_st = c__st; t.F_old = c__old }
//line :437:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000414_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3619 any = A_arbace_go_repl_A_const_218.GetRawRoot__O(); var linked_3620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3619, A_arbace_go_repl_check_source_A_fn_class); var ifn_3621 lang.IFn; if linked_3620 == nil { ifn_3621 = lang.IFn_Cast(root_3619) } else { ifn_3621 = nil }; var arg_3622 any; var root_3624 any = A_arbace_go_repl_A_const_118.GetRawRoot__O(); var linked_3625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3624, A_arbace_go_repl_source_of_A_fn_class); var ifn_3626 lang.IFn; if linked_3625 == nil { ifn_3626 = lang.IFn_Cast(root_3624) } else { ifn_3626 = nil }; var arg_3627 any = t.F_st; if linked_3625 == nil { arg_3622 = ifn_3626.Invoke_O__O(arg_3627) } else { arg_3622 = linked_3625.(*A_arbace_go_repl_source_of_A).Invoke_O_O__O(root_3624, arg_3627) }; var arg_3623 any; if linked_3620 == nil { tmp1 = ifn_3621.Invoke_O_O__O(arg_3622, arg_3623) } else { tmp1 = linked_3620.(*A_arbace_go_repl_check_source_A).Invoke_O_O_O__O(root_3619, arg_3622, arg_3623) } }; return nil }(); if tmp2 != nil { if true { var ex__3 jrt.Throwable_I = tmp2; var root_3628 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_3629 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3628, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3630 lang.IFn
											if linked_3629 == nil { ifn_3630 = lang.IFn_Cast(root_3628) } else { ifn_3630 = nil }; var arg_3631 any; var t_ any = t.F_st; t.F_st = nil; arg_3631 = t_; var arg_3632 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_3633 any = A_arbace_go_repl_A_const_57; var arg_3634 any; var tmp3 *lang.Keyword = A_arbace_go_repl_A_const_57; var tmp4 any; var t__2 any = t.F_old; t.F_old = nil; tmp4 = t__2; arg_3634 = tmp3.Invoke_O__O(tmp4); if linked_3629 == nil { ifn_3630.Invoke_O_O_O_O__O(arg_3631, arg_3632, arg_3633, arg_3634) } else { linked_3629.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_3628, arg_3631, arg_3632, arg_3633, arg_3634) }
//line :437:1
	panic(jrt.Thrown(ex__3)) } }; return tmp1 }

func A_arbace_go_repl_declare_BANG__fn__794000416_A_New() *A_arbace_go_repl_declare_BANG__fn__794000416_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__fn__794000416_A{}; t.Ctor(); return t }
//line :439:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000416_A) Ctor() {}
//line :439:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000416_A) Invoke_O_O__O(self, p1__794000385_SHARP___1 any) any { var tmp1 any = A_arbace_go_repl_A_const_231; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_repl_A_const_232.Invoke_O__O(p1__794000385_SHARP___1))).Ref() }



func A_arbace_go_repl_declare_BANG__own_QMARK___794000418_A_New_O_O(p0, p1 any) *A_arbace_go_repl_declare_BANG__own_QMARK___794000418_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__own_QMARK___794000418_A{}; t.Ctor_O_O(p0, p1); return t }
//line :443:1
func (t *A_arbace_go_repl_declare_BANG__own_QMARK___794000418_A) Ctor_O_O(c__form, c__spec_of any) { t.F_form = c__form; t.F_spec_of = c__spec_of }
//line :443:1
func (t *A_arbace_go_repl_declare_BANG__own_QMARK___794000418_A) Invoke_O_O__O(self, er__1 any) any { var or__1927000174__auto____2 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_repl_A_const_235.Invoke_O__O(er__1), nil); if or__1927000174__auto____2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { var tmp1 any = t.F_form; var tmp2 lang.IFn = lang.IFn_Cast(t.F_spec_of); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, tmp2.Invoke_O__O(A_arbace_go_repl_A_const_235.Invoke_O__O(er__1)))).Ref() } }


func A_arbace_go_repl_declare_BANG__fn__794000420_A_New_O(p0 any) *A_arbace_go_repl_declare_BANG__fn__794000420_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__fn__794000420_A{}; t.Ctor_O(p0); return t }
//line :446:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000420_A) Ctor_O(c__spec_of any) { t.F_spec_of = c__spec_of }
//line :446:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000420_A) Invoke_O_O__O(self, p1__794000386_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_spec_of); return tmp1.Invoke_O__O(A_arbace_go_repl_A_const_235.Invoke_O__O(p1__794000386_SHARP___1)) }




func A_arbace_go_repl_declare_BANG__fn__794000422_A_New_O_O(p0, p1 any) *A_arbace_go_repl_declare_BANG__fn__794000422_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__fn__794000422_A{}; t.Ctor_O_O(p0, p1); return t }
//line :451:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000422_A) Ctor_O_O(c__broken, c__others any) { t.F_broken = c__broken; t.F_others = c__others }
//line :451:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000422_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_239.GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_49, nil, Lit_50, nil); var tmp4 any; var root_3789 any = A_arbace_go_repl_A_const_48.GetRawRoot__O(); var linked_3790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3789, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_3791 lang.IFn; if linked_3790 == nil { ifn_3791 = lang.IFn_Cast(root_3789) } else { ifn_3791 = nil }; var arg_3792 any = Lit_51; var arg_3793 any; var root_3794 any = A_arbace_go_repl_A_const_240.GetRawRoot__O(); var linked_3795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3794, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_3796 lang.IFn; if linked_3795 == nil { ifn_3796 = lang.IFn_Cast(root_3794) } else { ifn_3796 = nil }; var arg_3797 any; var t_ any = t.F_broken; t.F_broken = nil; arg_3797 = t_; if linked_3795 == nil { arg_3793 = ifn_3796.Invoke_O__O(arg_3797) } else { arg_3793 = linked_3795.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_3794, arg_3797) }; if linked_3790 == nil { tmp4 = ifn_3791.Invoke_O_O__O(arg_3792, arg_3793) } else { tmp4 = linked_3790.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_3789, arg_3792, arg_3793) }; var tmp5 any = tmp4; var tmp6 any; var root_3798 any = A_arbace_go_repl_A_const_115.GetRawRoot__O(); var linked_3799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3798, A_arbace_go_repl_error_text_A_fn_class); var ifn_3800 lang.IFn
												if linked_3799 == nil { ifn_3800 = lang.IFn_Cast(root_3798) } else { ifn_3800 = nil }; var arg_3801 any; var t__2 any = t.F_others; t.F_others = nil; arg_3801 = t__2; var arg_3802 any; var root_3803 any = A_arbace_go_repl_A_const_238.GetRawRoot__O(); var linked_3804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3803, A_arbace_go_repl_repl_source_A_fn_class); var ifn_3805 lang.IFn; if linked_3804 == nil { ifn_3805 = lang.IFn_Cast(root_3803) } else { ifn_3805 = nil }; if linked_3804 == nil { arg_3802 = ifn_3805.Invoke__O() } else { arg_3802 = linked_3804.(*A_arbace_go_repl_repl_source_A).Invoke_O__O(root_3803) }; if linked_3799 == nil { tmp6 = ifn_3800.Invoke_O_O__O(arg_3801, arg_3802) } else { tmp6 = linked_3799.(*A_arbace_go_repl_error_text_A).Invoke_O_O_O__O(root_3798, arg_3801, arg_3802) }
//line :452:1
		tmp1 = tmp2.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp5, nil, tmp6)).Ref()) }
//line :451:1
	return nil }(); var root_3806 any = A_arbace_go_repl_A_const_196.GetRawRoot__O(); var linked_3807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3806, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3808 lang.IFn; if linked_3807 == nil { ifn_3808 = lang.IFn_Cast(root_3806) } else { ifn_3808 = nil }; if linked_3807 == nil { ifn_3808.Invoke__O() } else { linked_3807.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3806) }; if tmp7 != nil { panic(tmp7) }; return tmp1 }



func A_arbace_go_repl_declare_BANG__fn__794000426_A_New_O_Z_O_O_O_O(p0 any, p1 bool, p2, p3, p4, p5 any) *A_arbace_go_repl_declare_BANG__fn__794000426_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__fn__794000426_A{}; t.Ctor_O_Z_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :455:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000426_A) Ctor_O_Z_O_O_O_O(c__broken any, c__var_QMARK_ bool, c__r, c__st, c__old, c__names any) { t.F_broken = c__broken; t.F_var_QMARK_ = c__var_QMARK_; t.F_r = c__r; t.F_st = c__st; t.F_old = c__old; t.F_names = c__names }
//line :455:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000426_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3691 any = A_arbace_go_repl_A_const_219.GetRawRoot__O(); var linked_3692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3691, A_arbace_go_repl_define_BANG__A_fn_class); var ifn_3693 lang.IFn; if linked_3692 == nil { ifn_3693 = lang.IFn_Cast(root_3691) } else { ifn_3693 = nil }; var arg_3694 any = t.F_st; var arg_3695 any; var t_ any = t.F_r; t.F_r = nil; arg_3695 = t_; var arg_3696 any; var tmp2 any = A_arbace_go_repl_A_const_165; var tmp3 any = jrt.Boolean_TRUE.Ref(); var tmp4 any = A_arbace_go_repl_A_const_168; var tmp5 any; var t__2 any = t.F_broken; t.F_broken = nil; tmp5 = t__2; var tmp6 any = tmp5; var tmp7 any = A_arbace_go_repl_A_const_169; var tmp8 any
											if t.F_var_QMARK_ { var t__3 any = t.F_names; t.F_names = nil; tmp8 = t__3 } else { tmp8 = nil }
//line :455:1
	arg_3696 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp6, tmp7, tmp8)); if linked_3692 == nil { tmp1 = ifn_3693.Invoke_O_O_O__O(arg_3694, arg_3695, arg_3696) } else { tmp1 = linked_3692.(*A_arbace_go_repl_define_BANG__A).Invoke_O_O_O_O__O(root_3691, arg_3694, arg_3695, arg_3696) } }; return nil }(); if tmp9 != nil { if true { var ex__3 jrt.Throwable_I = tmp9; var root_3697 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_3698 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3697, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3699 lang.IFn

		if linked_3698 == nil { ifn_3699 = lang.IFn_Cast(root_3697) } else { ifn_3699 = nil }; var arg_3700 any; var t__4 any = t.F_st; t.F_st = nil; arg_3700 = t__4; var arg_3701 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_3702 any = A_arbace_go_repl_A_const_57; var arg_3703 any; var tmp10 *lang.Keyword = A_arbace_go_repl_A_const_57; var tmp11 any; var t__5 any = t.F_old; t.F_old = nil; tmp11 = t__5; arg_3703 = tmp10.Invoke_O__O(tmp11); if linked_3698 == nil { ifn_3699.Invoke_O_O_O_O__O(arg_3700, arg_3701, arg_3702, arg_3703) } else { linked_3698.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_3697, arg_3700, arg_3701, arg_3702, arg_3703) }
//line :455:1
		panic(jrt.Thrown(ex__3)) } }; return tmp1 }















func A_arbace_go_repl_eval_BANG__A_New() *A_arbace_go_repl_eval_BANG__A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_eval_BANG__A{}; t.Ctor(); return t }
//line :471:1
func (t *A_arbace_go_repl_eval_BANG__A) Ctor() {}
//line :471:1
func (t *A_arbace_go_repl_eval_BANG__A) Invoke_O_O_O__O(self, stmts__0, p__794000435__1 any) any { var map__794000436__3 any = p__794000435__1; var map__794000436__4 any; if lang.ISeq_InstanceOf(map__794000436__3) { var tmp1 any; var root_3852 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_3853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3852, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3854 lang.IFn; if linked_3853 == nil { ifn_3854 = lang.IFn_Cast(root_3852) } else { ifn_3854 = nil }; var arg_3855 any = map__794000436__3; if linked_3853 == nil { tmp1 = ifn_3854.Invoke_O__O(arg_3855) } else { tmp1 = linked_3853.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3852, arg_3855) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_3856 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_3857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3856, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3858 lang.IFn; if linked_3857 == nil { ifn_3858 = lang.IFn_Cast(root_3856) } else { ifn_3858 = nil }; var arg_3859 any = map__794000436__3; if linked_3857 == nil { tmp2 = ifn_3858.Invoke_O__O(arg_3859) } else { tmp2 = linked_3857.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3856, arg_3859) }; map__794000436__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_3860 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_3861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3860, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3862 lang.IFn; if linked_3861 == nil { ifn_3862 = lang.IFn_Cast(root_3860) } else { ifn_3862 = nil }; var arg_3863 any = map__794000436__3; if linked_3861 == nil { tmp3 = ifn_3862.Invoke_O__O(arg_3863) } else { tmp3 = linked_3861.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3860, arg_3863) }; if jrt.J2g_Truth(tmp3) { var root_3864 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_3865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3864, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3866 lang.IFn; if linked_3865 == nil { ifn_3866 = lang.IFn_Cast(root_3864) } else { ifn_3866 = nil }; var arg_3867 any = map__794000436__3; if linked_3865 == nil { map__794000436__4 = ifn_3866.Invoke_O__O(arg_3867) } else { map__794000436__4 = linked_3865.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3864, arg_3867) } } else { map__794000436__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000436__4 = map__794000436__3 }; var ns__5 any = lang.RT_Get_O_O__O_NoInit(map__794000436__4, A_arbace_go_repl_A_const_56); var ns_sym__6 any; var or__1927000174__auto____6 any = ns__5; if



	jrt.J2g_Truth(or__1927000174__auto____6) { ns_sym__6 = or__1927000174__auto____6 } else { var root_3868 any = A_arbace_go_repl_A_const_227.GetRawRoot__O(); var linked_3869 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3868, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_3870 lang.IFn; if linked_3869 == nil { ifn_3870 = lang.IFn_Cast(root_3868) } else { ifn_3870 = nil }; var arg_3871 any = A_arbace_go_repl_A_const_228.Get__O(); if linked_3869 == nil { ns_sym__6 = ifn_3870.Invoke_O__O(arg_3871) } else { ns_sym__6 = linked_3869.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_3868, arg_3871) } }; var ns_sym__7 any; var tmp4 any; var root_3872 any = /*line :471:1*/A_arbace_go_repl_A_const_68.GetRawRoot__O(); var linked_3873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3872, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_3874 lang.IFn; if




	linked_3873 == nil { ifn_3874 = lang.IFn_Cast(root_3872) } else { ifn_3874 = nil }; var arg_3875 any; var root_3877 any = A_arbace_go_repl_A_const_51.GetRawRoot__O(); var linked_3878 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3877, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_3879 lang.IFn; if linked_3878 == nil { ifn_3879 = lang.IFn_Cast(root_3877) } else { ifn_3879 = nil }; var arg_3880 any = ns_sym__6; if linked_3878 == nil { arg_3875 = ifn_3879.Invoke_O__O(arg_3880) } else { arg_3875 = linked_3878.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_3877, arg_3880) }; var arg_3876 any = Lit_122; if linked_3873 == nil { tmp4 = ifn_3874.Invoke_O_O__O(arg_3875, arg_3876) } else { tmp4 = linked_3873.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_3872, arg_3875, arg_3876) }; if jrt.J2g_Truth(tmp4) { ns_sym__7 = ns_sym__6 } else { ns_sym__7 = A_arbace_go_repl_A_const_243 }; var st__8 any; var root_3881 any = /*line :471:1*/A_arbace_go_repl_A_const_72.GetRawRoot__O(); var linked_3882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3881, A_arbace_go_repl_package_state_A_fn_class); var ifn_3883 lang.IFn; if





	linked_3882 == nil { ifn_3883 = lang.IFn_Cast(root_3881) } else { ifn_3883 = nil }; var arg_3884 any = ns_sym__7; if linked_3882 == nil { st__8 = ifn_3883.Invoke_O__O(arg_3884) } else { st__8 = linked_3882.(*A_arbace_go_repl_package_state_A).Invoke_O_O__O(root_3881, arg_3884) }; var nm__9 any; var tmp5 /*line :471:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_123, nil); var tmp6 any; var root_3885 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_3886 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3885, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3887 lang.IFn; if






	linked_3886 == nil { ifn_3887 = lang.IFn_Cast(root_3885) } else { ifn_3887 = nil }; var arg_3888 any = A_arbace_go_repl_A_const_244.GetRawRoot__O(); var arg_3889 any = A_arbace_go_repl_A_const_245.GetRawRoot__O(); if linked_3886 == nil { tmp6 = ifn_3887.Invoke_O_O__O(arg_3888, arg_3889) } else { tmp6 = linked_3886.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_3885, arg_3888, arg_3889) }; nm__9 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6)).Ref(); var last_f__10 any; var tmp7 any = /*line :471:1*/A_arbace_go_repl_eval_BANG__fn__794000444_A_New_O(stmts__0); var tmp8 *jrt.Class; var fncls__3906 *jrt.Class = A_arbace_go_repl_eval_BANG__fn__794000444_A_fn_class; if








	fncls__3906 == nil { var fncls__3906d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_124, false); A_arbace_go_repl_eval_BANG__fn__794000444_A_fn_class = fncls__3906d; tmp8 = fncls__3906d } else { tmp8 = fncls__3906 }; last_f__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O(); var stmt_QMARK___11 any; var and__1927000168__auto____11 any; var root_3907 any = /*line :471:1*/A_arbace_go_repl_A_const_34.GetRawRoot__O(); var linked_3908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3907, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_3909 lang.IFn; if












	linked_3908 == nil { ifn_3909 = lang.IFn_Cast(root_3907) } else { ifn_3909 = nil }; var arg_3910 any = last_f__10; if linked_3908 == nil { and__1927000168__auto____11 = ifn_3909.Invoke_O__O(arg_3910) } else { and__1927000168__auto____11 = linked_3908.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_3907, arg_3910) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var root_3911 any = A_arbace_go_repl_A_const_18.GetRawRoot__O(); var linked_3912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3911, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_3913 lang.IFn; if linked_3912 == nil { ifn_3913 = lang.IFn_Cast(root_3911) } else { ifn_3913 = nil }; var arg_3914 any = A_arbace_go_repl_A_const_247.GetRawRoot__O(); var arg_3915 any; var root_3916 any = A_arbace_go_repl_A_const_89.GetRawRoot__O(); var linked_3917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3916, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_3918 lang.IFn; if linked_3917 == nil { ifn_3918 = lang.IFn_Cast(root_3916) } else { ifn_3918 = nil }; var arg_3919 any = last_f__10; if linked_3917 == nil { arg_3915 = ifn_3918.Invoke_O__O(arg_3919) } else { arg_3915 = linked_3917.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_3916, arg_3919) }; if linked_3912 == nil { stmt_QMARK___11 = ifn_3913.Invoke_O_O__O(arg_3914, arg_3915) } else { stmt_QMARK___11 = linked_3912.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_3911, arg_3914, arg_3915) } } else { stmt_QMARK___11 = and__1927000168__auto____11 }; var attempt__12 any; var tmp9 any = /*line :471:1*/A_arbace_go_repl_eval_BANG__attempt__794000446_A_New_O_O_O(stmts__0, nm__9, st__8); var tmp10 *jrt.Class; var fncls__4001 *jrt.Class = A_arbace_go_repl_eval_BANG__attempt__794000446_A_fn_class; if













	fncls__4001 == nil { var fncls__4001d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_125, false); A_arbace_go_repl_eval_BANG__attempt__794000446_A_fn_class = fncls__4001d; tmp10 = fncls__4001d } else { tmp10 = fncls__4001 }; attempt__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var vec__794000438__13 any; if















	jrt.J2g_Truth(stmt_QMARK___11) { vec__794000438__13 = lang.IFn_Cast(attempt__12).Invoke_O__O(nil) } else { vec__794000438__13 = lang.IFn_Cast(attempt__12).Invoke_O__O(A_arbace_go_repl_A_const_153) }; var r__14 any = /*line :471:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__794000438__13, lang.RT_IntCast_J__I_NoInit(0), nil); var form__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000438__13, lang.RT_IntCast_J__I_NoInit(1), nil); var multi__16 any; var root_4002 any = A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_4003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4002, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_4004 lang.IFn; if






























	linked_4003 == nil { ifn_4004 = lang.IFn_Cast(root_4002) } else { ifn_4004 = nil }; var arg_4005 any; var tmp11 any = A_arbace_go_repl_eval_BANG__fn__794000452_A_New(); var tmp12 *jrt.Class; var fncls__4012 *jrt.Class = A_arbace_go_repl_eval_BANG__fn__794000452_A_fn_class; if fncls__4012 == nil { var fncls__4012d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_126, false); A_arbace_go_repl_eval_BANG__fn__794000452_A_fn_class = fncls__4012d; tmp12 = fncls__4012d } else { tmp12 = fncls__4012 }; arg_4005 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var arg_4006 any = A_arbace_go_repl_A_const_221.Invoke_O__O(r__14); if linked_4003 == nil { multi__16 = ifn_4004.Invoke_O_O__O(arg_4005, arg_4006) } else { multi__16 = linked_4003.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_4002, arg_4005, arg_4006) }; var novalue__17 any; var root_4013 any = /*line :471:1*/A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_4014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4013, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_4015 lang.IFn; if































	linked_4014 == nil { ifn_4015 = lang.IFn_Cast(root_4013) } else { ifn_4015 = nil }; var arg_4016 any; var tmp13 any = A_arbace_go_repl_eval_BANG__fn__794000454_A_New(); var tmp14 *jrt.Class; var fncls__4023 *jrt.Class = A_arbace_go_repl_eval_BANG__fn__794000454_A_fn_class; if fncls__4023 == nil { var fncls__4023d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_127, false); A_arbace_go_repl_eval_BANG__fn__794000454_A_fn_class = fncls__4023d; tmp14 = fncls__4023d } else { tmp14 = fncls__4023 }; arg_4016 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var arg_4017 any = A_arbace_go_repl_A_const_221.Invoke_O__O(r__14); if linked_4014 == nil { novalue__17 = ifn_4015.Invoke_O_O__O(arg_4016, arg_4017) } else { novalue__17 = linked_4014.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_4013, arg_4016, arg_4017) }; var vec__794000441__18 any; if
	jrt.J2g_Truth(multi__16) { var vec__794000456__18 any; var root_4024 any = A_arbace_go_repl_A_const_256.GetRawRoot__O(); var linked_4025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4024, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_4026 lang.IFn
		if linked_4025 == nil { ifn_4026 = lang.IFn_Cast(root_4024) } else { ifn_4026 = nil }; var arg_4027 any = A_arbace_go_repl_A_const_257; var arg_4028 any = A_arbace_go_repl_A_const_112.Invoke_O__O(multi__16); if linked_4025 == nil { vec__794000456__18 = ifn_4026.Invoke_O_O__O(arg_4027, arg_4028) } else { vec__794000456__18 = linked_4025.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_4024, arg_4027, arg_4028) }
//line :504:1
		var ___19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000456__18, lang.RT_IntCast_J__I_NoInit(0), nil); var ts__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000456__18, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp15 lang.IFn = lang.IFn_Cast(attempt__12); var tmp16 any; var root_4105 any = A_arbace_go_repl_A_const_50.GetRawRoot__O(); var linked_4106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4105, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_4107 lang.IFn; _ = ___19

		if linked_4106 == nil { ifn_4107 = lang.IFn_Cast(root_4105) } else { ifn_4107 = nil }; var arg_4108 any = ts__20; var arg_4109 any = A_arbace_go_repl_A_const_258; if linked_4106 == nil { tmp16 = ifn_4107.Invoke_O_O__O(arg_4108, arg_4109) } else { tmp16 = linked_4106.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_4105, arg_4108, arg_4109) }; vec__794000441__18 = tmp15.Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp16)).Ref()) } else {
//line :504:1
			if jrt.J2g_Truth(novalue__17) {


				vec__794000441__18 = lang.IFn_Cast(attempt__12).Invoke_O__O(nil) } else {
//line :504:1
					if A_arbace_go_repl_A_const_133 != nil { vec__794000441__18 = lang.Tuple_Create_O_O__IPersistentVector(r__14, form__15) } else { vec__794000441__18 = nil } } }; var r__19 any = /*line :471:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__794000441__18, lang.RT_IntCast_J__I_NoInit(0), nil); var form__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000441__18, lang.RT_IntCast_J__I_NoInit(1), nil); var errs__21 any; var root_4029 any = A_arbace_go_repl_A_const_230.GetRawRoot__O(); var linked_4030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4029, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_4031 lang.IFn; if





































	linked_4030 == nil { ifn_4031 = lang.IFn_Cast(root_4029) } else { ifn_4031 = nil }; var arg_4032 any; var tmp17 any = A_arbace_go_repl_eval_BANG__fn__794000459_A_New(); var tmp18 *jrt.Class; var fncls__4034 *jrt.Class = A_arbace_go_repl_eval_BANG__fn__794000459_A_fn_class; if fncls__4034 == nil { var fncls__4034d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_128, false); A_arbace_go_repl_eval_BANG__fn__794000459_A_fn_class = fncls__4034d; tmp18 = fncls__4034d } else { tmp18 = fncls__4034 }; arg_4032 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); var arg_4033 any = A_arbace_go_repl_A_const_221.Invoke_O__O(r__19); if linked_4030 == nil { errs__21 = ifn_4031.Invoke_O_O__O(arg_4032, arg_4033) } else { errs__21 = linked_4030.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_4029, arg_4032, arg_4033) }; var tmp19 any; var root_4110 any =
	A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_4111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4110, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4112 lang.IFn; if linked_4111 == nil { ifn_4112 = lang.IFn_Cast(root_4110) } else { ifn_4112 = nil }; var arg_4113 any = errs__21; if linked_4111 == nil { tmp19 = ifn_4112.Invoke_O__O(arg_4113) } else { tmp19 = linked_4111.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4110, arg_4113) }; if jrt.J2g_Truth(tmp19) { var tmp20 any; var root_4114 any = A_arbace_go_repl_A_const_69.GetRawRoot__O(); var linked_4115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4114, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_4116 lang.IFn
		if linked_4115 == nil { ifn_4116 = lang.IFn_Cast(root_4114) } else { ifn_4116 = nil }; var arg_4117 any; var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_46, nil); var tmp22 any; var root_4119 any = A_arbace_go_repl_A_const_115.GetRawRoot__O(); var linked_4120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4119, A_arbace_go_repl_error_text_A_fn_class); var ifn_4121 lang.IFn; if linked_4120 == nil { ifn_4121 = lang.IFn_Cast(root_4119) } else { ifn_4121 = nil }; var arg_4122 any = errs__21; var arg_4123 any; var root_4124 any = A_arbace_go_repl_A_const_238.GetRawRoot__O(); var linked_4125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4124, A_arbace_go_repl_repl_source_A_fn_class); var ifn_4126 lang.IFn; if linked_4125 == nil { ifn_4126 = lang.IFn_Cast(root_4124) } else { ifn_4126 = nil }; if linked_4125 == nil { arg_4123 = ifn_4126.Invoke__O() } else { arg_4123 = linked_4125.(*A_arbace_go_repl_repl_source_A).Invoke_O__O(root_4124) }; if linked_4120 == nil { tmp22 = ifn_4121.Invoke_O_O__O(arg_4122, arg_4123) } else { tmp22 = linked_4120.(*A_arbace_go_repl_error_text_A).Invoke_O_O_O__O(root_4119, arg_4122, arg_4123) }; arg_4117 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp21, jrt.RefArrayOf(jrt.Object_class, nil, tmp22)).Ref(); var arg_4118 any; var tmp23 any = A_arbace_go_repl_A_const_222; var tmp24 any; var root_4127 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_4128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4127, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_4129 lang.IFn; if linked_4128 == nil { ifn_4129 = lang.IFn_Cast(root_4127) } else { ifn_4129 = nil }; var arg_4130 any = errs__21; if linked_4128 == nil { tmp24 = ifn_4129.Invoke_O__O(arg_4130) } else { tmp24 = linked_4128.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_4127, arg_4130) }; arg_4118 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp23, tmp24)); if linked_4115 == nil { tmp20 = ifn_4116.Invoke_O_O__O(arg_4117, arg_4118) } else { tmp20 = linked_4115.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_4114, arg_4117, arg_4118) }
//line :510:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp20))) }; var old__22 any; var root_4035 any = /*line :471:1*/A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_4036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4035, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_4037 lang.IFn; if








































	linked_4036 == nil { ifn_4037 = lang.IFn_Cast(root_4035) } else { ifn_4037 = nil }; var arg_4038 any = st__8; if linked_4036 == nil { old__22 = ifn_4037.Invoke_O__O(arg_4038) } else { old__22 = linked_4036.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_4035, arg_4038) }; var root_4131 any =
	A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_4132 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4131, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_4133 lang.IFn; if linked_4132 == nil { ifn_4133 = lang.IFn_Cast(root_4131) } else { ifn_4133 = nil }; var arg_4134 any = st__8; var arg_4135 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_4136 any = A_arbace_go_repl_A_const_57; var arg_4137 any; var root_4138 any = A_arbace_go_repl_A_const_80.GetRawRoot__O(); var linked_4139 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4138, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_4140 lang.IFn; if linked_4139 == nil { ifn_4140 = lang.IFn_Cast(root_4138) } else { ifn_4140 = nil }; var arg_4141 any; var tmp25 any = A_arbace_go_repl_eval_BANG__fn__794000461_A_New_O_O(form__20, old__22); var tmp26 *jrt.Class; var fncls__4150 *jrt.Class = A_arbace_go_repl_eval_BANG__fn__794000461_A_fn_class; if fncls__4150 == nil { var fncls__4150d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_129, false); A_arbace_go_repl_eval_BANG__fn__794000461_A_fn_class = fncls__4150d; tmp26 = fncls__4150d } else { tmp26 = fncls__4150 }; arg_4141 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil); var arg_4142 any = A_arbace_go_repl_A_const_57.Invoke_O__O(old__22); if linked_4139 == nil { arg_4137 = ifn_4140.Invoke_O_O__O(arg_4141, arg_4142) } else { arg_4137 = linked_4139.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_4138, arg_4141, arg_4142) }; if linked_4132 == nil { ifn_4133.Invoke_O_O_O_O__O(arg_4134, arg_4135, arg_4136, arg_4137) } else { linked_4132.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_4131, arg_4134, arg_4135, arg_4136, arg_4137) }; var tmp27 any; tmp41 := /*line :471:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)











































		{ var root_4151 any = A_arbace_go_repl_A_const_219.GetRawRoot__O(); var linked_4152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4151, A_arbace_go_repl_define_BANG__A_fn_class); var ifn_4153 lang.IFn; if linked_4152 == nil { ifn_4153 = lang.IFn_Cast(root_4151) } else { ifn_4153 = nil }; var arg_4154 any = st__8; var arg_4155 any = r__19; var tmp28 any = A_arbace_go_repl_A_const_165; var tmp29 any = jrt.Boolean_FALSE.Ref(); var tmp30 any = A_arbace_go_repl_A_const_167; var arg_4156 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp29, tmp30, lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, nm__9)))); if linked_4152 == nil { ifn_4153.Invoke_O_O_O__O(arg_4154, arg_4155, arg_4156) } else { linked_4152.(*A_arbace_go_repl_define_BANG__A).Invoke_O_O_O_O__O(root_4151, arg_4154, arg_4155, arg_4156) }
//line :471:1
			var map__794000463__25 any; var root_4039 any = A_arbace_go_repl_A_const_152.GetRawRoot__O(); var linked_4040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4039, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4041 lang.IFn












































			if linked_4040 == nil { ifn_4041 = lang.IFn_Cast(root_4039) } else { ifn_4041 = nil }; var arg_4042 any; var root_4044 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_4045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4044, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_4046 lang.IFn; if linked_4045 == nil { ifn_4046 = lang.IFn_Cast(root_4044) } else { ifn_4046 = nil }; var arg_4047 any = st__8; if linked_4045 == nil { arg_4042 = ifn_4046.Invoke_O__O(arg_4047) } else { arg_4042 = linked_4045.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_4044, arg_4047) }; var arg_4043 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_repl_A_const_59, nm__9); if linked_4040 == nil { map__794000463__25 = ifn_4041.Invoke_O_O__O(arg_4042, arg_4043) } else { map__794000463__25 = linked_4040.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4039, arg_4042, arg_4043) }
//line :471:1
			var map__794000463__26 any












































			if lang.ISeq_InstanceOf(map__794000463__25) { var tmp31 any; var root_4048 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_4049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4048, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4050 lang.IFn; if linked_4049 == nil { ifn_4050 = lang.IFn_Cast(root_4048) } else { ifn_4050 = nil }; var arg_4051 any = map__794000463__25; if linked_4049 == nil { tmp31 = ifn_4050.Invoke_O__O(arg_4051) } else { tmp31 = linked_4049.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4048, arg_4051) }; if jrt.J2g_Truth(tmp31) { var tmp32 any; var root_4052 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_4053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4052, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_4054 lang.IFn; if linked_4053 == nil { ifn_4054 = lang.IFn_Cast(root_4052) } else { ifn_4054 = nil }; var arg_4055 any = map__794000463__25; if linked_4053 == nil { tmp32 = ifn_4054.Invoke_O__O(arg_4055) } else { tmp32 = linked_4053.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_4052, arg_4055) }; map__794000463__26 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp32, jrt.Object_class.ArrayClass())).Ref() } else { var tmp33 any; var root_4056 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_4057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4056, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4058 lang.IFn; if linked_4057 == nil { ifn_4058 = lang.IFn_Cast(root_4056) } else { ifn_4058 = nil }; var arg_4059 any = map__794000463__25; if linked_4057 == nil { tmp33 = ifn_4058.Invoke_O__O(arg_4059) } else { tmp33 = linked_4057.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4056, arg_4059) }; if jrt.J2g_Truth(tmp33) { var root_4060 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_4061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4060, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4062 lang.IFn; if linked_4061 == nil { ifn_4062 = lang.IFn_Cast(root_4060) } else { ifn_4062 = nil }; var arg_4063 any = map__794000463__25; if linked_4061 == nil { map__794000463__26 = ifn_4062.Invoke_O__O(arg_4063) } else { map__794000463__26 = linked_4061.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4060, arg_4063) } } else { map__794000463__26 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000463__26 = map__794000463__25 }
//line :471:1
			var cell__27 any = lang.RT_Get_O_O__O_NoInit(map__794000463__26, A_arbace_go_repl_A_const_155); var obj__28 any = lang.RT_Get_O_O__O_NoInit(map__794000463__26, A_arbace_go_repl_A_const_177); var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_179.GetRawRoot__O()); var tmp35 any; var root_4084 any = A_arbace_go_repl_A_const_198.GetRawRoot__O(); var linked_4085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4084, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_4086 lang.IFn













































			if linked_4085 == nil { ifn_4086 = lang.IFn_Cast(root_4084) } else { ifn_4086 = nil }; var arg_4087 any; var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_38.GetRawRoot__O()); var tmp37 any = A_arbace_go_repl_A_const_199; var tmp38 any; var root_4093 any = A_arbace_go_repl_A_const_170.GetRawRoot__O(); var linked_4094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4093, A_arbace_go_repl_build_context_A_fn_class); var ifn_4095 lang.IFn; if linked_4094 == nil { ifn_4095 = lang.IFn_Cast(root_4093) } else { ifn_4095 = nil }; var arg_4096 any = st__8; if linked_4094 == nil { tmp38 = ifn_4095.Invoke_O__O(arg_4096) } else { tmp38 = linked_4094.(*A_arbace_go_repl_build_context_A).Invoke_O_O__O(root_4093, arg_4096) }; arg_4087 = tmp36.Invoke_O_O__O(tmp37, tmp38); if linked_4085 == nil { ifn_4086.Invoke_O__O(arg_4087) } else { linked_4085.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_4084, arg_4087) }; var tmp39 any = A_arbace_go_repl_eval_BANG__fn__794000465_A_New_O(obj__28); var tmp40 *jrt.Class; var fncls__4083 *jrt.Class = A_arbace_go_repl_eval_BANG__fn__794000465_A_fn_class; if fncls__4083 == nil { var fncls__4083d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_130, false); A_arbace_go_repl_eval_BANG__fn__794000465_A_fn_class = fncls__4083d; tmp40 = fncls__4083d } else { tmp40 = fncls__4083 }; tmp35 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp39, tmp40, nil).Invoke__O(); tmp27 = lang.GoInterp_Call_O_O1__O(tmp34.Invoke_O_O_O_O__O(Lit_11, cell__27, tmp35, nm__9), lang.RT_Object_array_O__O1_NoInit(lang.PersistentVector_EMPTY.Ref())) }
//line :471:1
		return nil }(); var root_4157 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_4158 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4157, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_4159 lang.IFn; if
















































	linked_4158 == nil { ifn_4159 = lang.IFn_Cast(root_4157) } else { ifn_4159 = nil }; var arg_4160 any = st__8; var arg_4161 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_4162 any = A_arbace_go_repl_A_const_57; var arg_4163 any = A_arbace_go_repl_A_const_57.Invoke_O__O(old__22); if linked_4158 == nil { ifn_4159.Invoke_O_O_O_O__O(arg_4160, arg_4161, arg_4162, arg_4163) } else { linked_4158.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_4157, arg_4160, arg_4161, arg_4162, arg_4163) }; var tmp42 lang.IFn =
	lang.IFn_Cast(A_arbace_go_repl_A_const_70.GetRawRoot__O()); var tmp43 any = A_arbace_go_repl_A_const_79.GetRawRoot__O(); var tmp44 any = A_arbace_go_repl_A_const_59; tmp42.Invoke_O_O_O_O_O__O(st__8, tmp43, tmp44, A_arbace_go_repl_A_const_84.GetRawRoot__O(), nm__9); if /*line :471:1*/ tmp41 != nil { panic(tmp41) }; return tmp27 }








func A_arbace_go_repl_eval_BANG__fn__794000444_A_New_O(p0 any) *A_arbace_go_repl_eval_BANG__fn__794000444_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_eval_BANG__fn__794000444_A{}; t.Ctor_O(p0); return t }
//line :480:1
func (t *A_arbace_go_repl_eval_BANG__fn__794000444_A) Ctor_O(c__stmts any) { t.F_stmts = c__stmts }
//line :480:1
func (t *A_arbace_go_repl_eval_BANG__fn__794000444_A) Invoke_O__O(self any) any { { var f__1 any; var root_3890 any = A_arbace_go_repl_A_const_66.GetRawRoot__O(); var linked_3891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3890, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_3892 lang.IFn; if linked_3891 == nil { ifn_3892 = lang.IFn_Cast(root_3890) } else { ifn_3892 = nil }; var arg_3893 any; var t_ any = t.F_stmts; t.F_stmts = nil; arg_3893 = t_; if linked_3891 == nil { f__1 = ifn_3892.Invoke_O__O(arg_3893) } else { f__1 = linked_3891.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_3890, arg_3893) }; L1: for {
										var tmp1 any; var and__1927000168__auto____2 any; var root_3894 any = A_arbace_go_repl_A_const_34.GetRawRoot__O(); var linked_3895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3894, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_3896 lang.IFn; if linked_3895 == nil { ifn_3896 = lang.IFn_Cast(root_3894) } else { ifn_3896 = nil }; var arg_3897 any = f__1; if linked_3895 == nil { and__1927000168__auto____2 = ifn_3896.Invoke_O__O(arg_3897) } else { and__1927000168__auto____2 = linked_3895.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_3894, arg_3897) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_246); var tmp3 any; var root_3898 any = A_arbace_go_repl_A_const_89.GetRawRoot__O(); var linked_3899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3898, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_3900 lang.IFn; if linked_3899 == nil { ifn_3900 = lang.IFn_Cast(root_3898) } else { ifn_3900 = nil }; var arg_3901 any = f__1; if linked_3899 == nil { tmp3 = ifn_3900.Invoke_O__O(arg_3901) } else { tmp3 = linked_3899.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_3898, arg_3901) }; and__1927000168__auto____3 = tmp2.Invoke_O__O(tmp3); if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(f__1)), 2)).Ref() } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
											var tmp4 any; var root_3902 any = A_arbace_go_repl_A_const_66.GetRawRoot__O(); var linked_3903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3902, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_3904 lang.IFn; if linked_3903 == nil { ifn_3904 = lang.IFn_Cast(root_3902) } else { ifn_3904 = nil }; var arg_3905 any = f__1; if linked_3903 == nil { tmp4 = ifn_3904.Invoke_O__O(arg_3905) } else { tmp4 = linked_3903.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_3902, arg_3905) }; f__1 = tmp4; continue L1 } else {
//line :481:1
			return f__1 } } }; /*line :480:1*/panic("j2g: unreachable") }




func A_arbace_go_repl_eval_BANG__attempt__794000446_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_repl_eval_BANG__attempt__794000446_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_eval_BANG__attempt__794000446_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :485:1
func (t *A_arbace_go_repl_eval_BANG__attempt__794000446_A) Ctor_O_O_O(c__stmts, c__nm, c__st any) { t.F_stmts = c__stmts; t.F_nm = c__nm; t.F_st = c__st }
//line :485:1
func (t *A_arbace_go_repl_eval_BANG__attempt__794000446_A) Invoke_O_O__O(self, results__1 any) any { var form__2 any; var root_3920 any = A_arbace_go_repl_A_const_37.GetRawRoot__O(); var linked_3921 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3920, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3922 lang.IFn; if
													linked_3921 == nil { ifn_3922 = lang.IFn_Cast(root_3920) } else { ifn_3922 = nil }; var arg_3923 any = A_arbace_go_repl_A_const_248.GetRawRoot__O(); var arg_3924 any = A_arbace_go_repl_A_const_249; var arg_3925 any; var root_3927 any = A_arbace_go_repl_A_const_46.GetRawRoot__O(); var linked_3928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3927, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3929 lang.IFn; if linked_3928 == nil { ifn_3929 = lang.IFn_Cast(root_3927) } else { ifn_3929 = nil }; var arg_3930 any = t.F_nm; if linked_3928 == nil { arg_3925 = ifn_3929.Invoke_O__O(arg_3930) } else { arg_3925 = linked_3928.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3927, arg_3930) }; var arg_3926 any; var root_3931 any = A_arbace_go_repl_A_const_101.GetRawRoot__O(); var linked_3932 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3931, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3933 lang.IFn; if linked_3932 == nil { ifn_3933 = lang.IFn_Cast(root_3931) } else { ifn_3933 = nil }; var arg_3934 any; if lang.Util_Identical_O_O__Z_NoInit(results__1, nil) { arg_3934 = lang.Tuple_Create_O__IPersistentVector(lang.PersistentVector_EMPTY.Ref()) } else { if lang.Util_Equiv_J_O__Z_NoInit(1, results__1) { var tmp1 any; var root_3936 any = A_arbace_go_repl_A_const_211.GetRawRoot__O(); var linked_3937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3936, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3938 lang.IFn

		if linked_3937 == nil { ifn_3938 = lang.IFn_Cast(root_3936) } else { ifn_3938 = nil }; var arg_3939 any = lang.PersistentVector_EMPTY.Ref(); var arg_3940 any = A_arbace_go_repl_A_const_250; if linked_3937 == nil { tmp1 = ifn_3938.Invoke_O_O__O(arg_3939, arg_3940) } else { tmp1 = linked_3937.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3936, arg_3939, arg_3940) }
//line :486:1
		arg_3934 = lang.Tuple_Create_O__IPersistentVector(tmp1) } else { if A_arbace_go_repl_A_const_133 != nil { var tmp2 any = lang.PersistentVector_EMPTY.Ref(); var tmp3 any = A_arbace_go_repl_A_const_251; var tmp4 any; var root_3941 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_3942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3941, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3943 lang.IFn


			if linked_3942 == nil { ifn_3943 = lang.IFn_Cast(root_3941) } else { ifn_3943 = nil }; var arg_3944 any; var root_3945 any = A_arbace_go_repl_A_const_252.GetRawRoot__O(); var linked_3946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3945, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_3947 lang.IFn; if linked_3946 == nil { ifn_3947 = lang.IFn_Cast(root_3945) } else { ifn_3947 = nil }; var arg_3948 any = results__1; var arg_3949 any = A_arbace_go_repl_A_const_253; if linked_3946 == nil { arg_3944 = ifn_3947.Invoke_O_O__O(arg_3948, arg_3949) } else { arg_3944 = linked_3946.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O_O__O(root_3945, arg_3948, arg_3949) }; if linked_3942 == nil { tmp4 = ifn_3943.Invoke_O__O(arg_3944) } else { tmp4 = linked_3942.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3941, arg_3944) }
//line :486:1
			arg_3934 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, tmp3, tmp4) } else { arg_3934 = nil } } }; var arg_3935 any = t.F_stmts; if linked_3932 == nil { arg_3926 = ifn_3933.Invoke_O_O__O(arg_3934, arg_3935) } else { arg_3926 = linked_3932.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3931, arg_3934, arg_3935) }; if linked_3921 == nil { form__2 = ifn_3922.Invoke_O_O_O_O__O(arg_3923, arg_3924, arg_3925, arg_3926) } else { form__2 = linked_3921.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_3920, arg_3923, arg_3924, arg_3925, arg_3926) }; var old__3 any; var root_3950 any = /*line :485:1*/A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_3951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3950, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3952 lang.IFn; if
	linked_3951 == nil { ifn_3952 = lang.IFn_Cast(root_3950) } else { ifn_3952 = nil }; var arg_3953 any = t.F_st; if linked_3951 == nil { old__3 = ifn_3952.Invoke_O__O(arg_3953) } else { old__3 = linked_3951.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3950, arg_3953) }; var files__4 any; var root_3954 any = /*line :485:1*/A_arbace_go_repl_A_const_80.GetRawRoot__O(); var linked_3955 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3954, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_3956 lang.IFn; if






	linked_3955 == nil { ifn_3956 = lang.IFn_Cast(root_3954) } else { ifn_3956 = nil }; var arg_3957 any; var tmp5 any = A_arbace_go_repl_eval_BANG__attempt__794000446_fn__794000447_A_New_O_O(form__2, old__3); var tmp6 *jrt.Class; var fncls__3966 *jrt.Class = A_arbace_go_repl_eval_BANG__attempt__794000446_fn__794000447_A_fn_class; if fncls__3966 == nil { var fncls__3966d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_131, false); A_arbace_go_repl_eval_BANG__attempt__794000446_fn__794000447_A_fn_class = fncls__3966d; tmp6 = fncls__3966d } else { tmp6 = fncls__3966 }; arg_3957 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_3958 any; var tmp7 any; var root_3967 any = A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_3968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3967, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3969 lang.IFn; if
	linked_3968 == nil { ifn_3969 = lang.IFn_Cast(root_3967) } else { ifn_3969 = nil }; var arg_3970 any; var tmp8 any = A_arbace_go_repl_eval_BANG__attempt__794000446_fn__794000449_A_New_O(old__3); var tmp9 *jrt.Class; var fncls__3972 *jrt.Class = A_arbace_go_repl_eval_BANG__attempt__794000446_fn__794000449_A_fn_class; if fncls__3972 == nil { var fncls__3972d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_132, false); A_arbace_go_repl_eval_BANG__attempt__794000446_fn__794000449_A_fn_class = fncls__3972d; tmp9 = fncls__3972d } else { tmp9 = fncls__3972 }; arg_3970 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_3971 any = A_arbace_go_repl_A_const_57.Invoke_O__O(old__3); if linked_3968 == nil { tmp7 = ifn_3969.Invoke_O_O__O(arg_3970, arg_3971) } else { tmp7 = linked_3968.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3967, arg_3970, arg_3971) }; if jrt.J2g_Truth(tmp7) {
		arg_3958 = A_arbace_go_repl_A_const_57.Invoke_O__O(old__3) } else {
			var root_3973 any = A_arbace_go_repl_A_const_15.GetRawRoot__O(); var linked_3974 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3973, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_3975 lang.IFn; if linked_3974 == nil { ifn_3975 = lang.IFn_Cast(root_3973) } else { ifn_3975 = nil }; var arg_3976 any = A_arbace_go_repl_A_const_57.Invoke_O__O(old__3); var tmp10 any = A_arbace_go_repl_A_const_55; var arg_3977 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, A_arbace_go_repl_A_const_58.Invoke_O__O(old__3), A_arbace_go_repl_A_const_74, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_repl_A_const_81, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_repl_A_const_82, lang.PersistentVector_EMPTY.Ref())); if linked_3974 == nil { arg_3958 = ifn_3975.Invoke_O_O__O(arg_3976, arg_3977) } else { arg_3958 = linked_3974.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_3973, arg_3976, arg_3977) } }; if /*line :492:1*/ linked_3955 == nil { files__4 = ifn_3956.Invoke_O_O__O(arg_3957, arg_3958) } else { files__4 = linked_3955.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_3954, arg_3957, arg_3958) }; var root_3994 any =



	A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_3995 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3994, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3996 lang.IFn; if linked_3995 == nil { ifn_3996 = lang.IFn_Cast(root_3994) } else { ifn_3996 = nil }; var arg_3997 any = t.F_st; var arg_3998 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_3999 any = A_arbace_go_repl_A_const_57; var arg_4000 any = files__4; if linked_3995 == nil { ifn_3996.Invoke_O_O_O_O__O(arg_3997, arg_3998, arg_3999, arg_4000) } else { linked_3995.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_3994, arg_3997, arg_3998, arg_3999, arg_4000) }; var tmp11 any; tmp12 := /*line :485:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var r__7 any; var root_3978 any = A_arbace_go_repl_A_const_218.GetRawRoot__O(); var linked_3979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3978, A_arbace_go_repl_check_source_A_fn_class); var ifn_3980 lang.IFn












		if linked_3979 == nil { ifn_3980 = lang.IFn_Cast(root_3978) } else { ifn_3980 = nil }; var arg_3981 any; var root_3983 any = A_arbace_go_repl_A_const_118.GetRawRoot__O(); var linked_3984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3983, A_arbace_go_repl_source_of_A_fn_class); var ifn_3985 lang.IFn; if linked_3984 == nil { ifn_3985 = lang.IFn_Cast(root_3983) } else { ifn_3985 = nil }; var arg_3986 any = t.F_st; if linked_3984 == nil { arg_3981 = ifn_3985.Invoke_O__O(arg_3986) } else { arg_3981 = linked_3984.(*A_arbace_go_repl_source_of_A).Invoke_O_O__O(root_3983, arg_3986) }; var arg_3982 any; if linked_3979 == nil { r__7 = ifn_3980.Invoke_O_O__O(arg_3981, arg_3982) } else { r__7 = linked_3979.(*A_arbace_go_repl_check_source_A).Invoke_O_O_O__O(root_3978, arg_3981, arg_3982) }
//line :485:1
		tmp11 = lang.Tuple_Create_O_O__IPersistentVector(r__7, form__2) }; return nil }(); var root_3987 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_3988 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3987, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3989 lang.IFn; if














	linked_3988 == nil { ifn_3989 = lang.IFn_Cast(root_3987) } else { ifn_3989 = nil }; var arg_3990 any = t.F_st; var arg_3991 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_3992 any = A_arbace_go_repl_A_const_57; var arg_3993 any = A_arbace_go_repl_A_const_57.Invoke_O__O(old__3); if linked_3988 == nil { ifn_3989.Invoke_O_O_O_O__O(arg_3990, arg_3991, arg_3992, arg_3993) } else { linked_3988.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_3987, arg_3990, arg_3991, arg_3992, arg_3993) }; if /*line :485:1*/ tmp12 != nil { panic(tmp12) }; return tmp11 }






func A_arbace_go_repl_eval_BANG__attempt__794000446_fn__794000447_A_New_O_O(p0, p1 any) *A_arbace_go_repl_eval_BANG__attempt__794000446_fn__794000447_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_eval_BANG__attempt__794000446_fn__794000447_A{}; t.Ctor_O_O(p0, p1); return t }
//line :492:1
func (t *A_arbace_go_repl_eval_BANG__attempt__794000446_fn__794000447_A) Ctor_O_O(c__form, c__old any) { t.F_form = c__form; t.F_old = c__old }
//line :492:1
func (t *A_arbace_go_repl_eval_BANG__attempt__794000446_fn__794000447_A) Invoke_O_O__O(self, p1__794000429_SHARP___1 any) any { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_repl_A_const_58.Invoke_O__O(t.F_old), A_arbace_go_repl_A_const_55.Invoke_O__O(p1__794000429_SHARP___1)) { var root_3959 any = A_arbace_go_repl_A_const_79.GetRawRoot__O(); var linked_3960 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3959, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_3961 lang.IFn; if linked_3960 == nil { ifn_3961 = lang.IFn_Cast(root_3959) } else { ifn_3961 = nil }; var arg_3962 any = p1__794000429_SHARP___1; var arg_3963 any = A_arbace_go_repl_A_const_82; var arg_3964 any = A_arbace_go_repl_A_const_15.GetRawRoot__O(); var arg_3965 any = t.F_form; if linked_3960 == nil { return ifn_3961.Invoke_O_O_O_O__O(arg_3962, arg_3963, arg_3964, arg_3965) } else { return linked_3960.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_3959, arg_3962, arg_3963, arg_3964, arg_3965) } } else { return p1__794000429_SHARP___1 } }
func A_arbace_go_repl_eval_BANG__attempt__794000446_fn__794000449_A_New_O(p0 any) *A_arbace_go_repl_eval_BANG__attempt__794000446_fn__794000449_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_eval_BANG__attempt__794000446_fn__794000449_A{}; t.Ctor_O(p0); return t }
//line :493:1
func (t *A_arbace_go_repl_eval_BANG__attempt__794000446_fn__794000449_A) Ctor_O(c__old any) { t.F_old = c__old }
//line :493:1
func (t *A_arbace_go_repl_eval_BANG__attempt__794000446_fn__794000449_A) Invoke_O_O__O(self, p1__794000430_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_repl_A_const_58.Invoke_O__O(t.F_old), A_arbace_go_repl_A_const_55.Invoke_O__O(p1__794000430_SHARP___1))).Ref() }








func A_arbace_go_repl_eval_BANG__fn__794000452_A_New() *A_arbace_go_repl_eval_BANG__fn__794000452_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_eval_BANG__fn__794000452_A{}; t.Ctor(); return t }
//line :502:1
func (t *A_arbace_go_repl_eval_BANG__fn__794000452_A) Ctor() {}
//line :502:1
func (t *A_arbace_go_repl_eval_BANG__fn__794000452_A) Invoke_O_O__O(self, p1__794000431_SHARP___1 any) any { var tmp1 any; var tmp2 any = A_arbace_go_repl_A_const_254; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_go_repl_A_const_232.Invoke_O__O(p1__794000431_SHARP___1)); if and__1927000168__auto____2 { var root_4007 any = A_arbace_go_repl_A_const_255.GetRawRoot__O(); var linked_4008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4007, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_4009 lang.IFn; if linked_4008 == nil { ifn_4009 = lang.IFn_Cast(root_4007) } else { ifn_4009 = nil }; var arg_4010 any = A_arbace_go_repl_A_const_112.Invoke_O__O(p1__794000431_SHARP___1); var arg_4011 any = Lit_133; if linked_4008 == nil { tmp1 = ifn_4009.Invoke_O_O__O(arg_4010, arg_4011) } else { tmp1 = linked_4008.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_4007, arg_4010, arg_4011) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp1) { return p1__794000431_SHARP___1 } else { return nil } }
func A_arbace_go_repl_eval_BANG__fn__794000454_A_New() *A_arbace_go_repl_eval_BANG__fn__794000454_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_eval_BANG__fn__794000454_A{}; t.Ctor(); return t }
//line :503:1
func (t *A_arbace_go_repl_eval_BANG__fn__794000454_A) Ctor() {}
//line :503:1
func (t *A_arbace_go_repl_eval_BANG__fn__794000454_A) Invoke_O_O__O(self, p1__794000432_SHARP___1 any) any { var tmp1 any; var root_4018 any = A_arbace_go_repl_A_const_255.GetRawRoot__O(); var linked_4019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4018, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_4020 lang.IFn; if linked_4019 == nil { ifn_4020 = lang.IFn_Cast(root_4018) } else { ifn_4020 = nil }; var arg_4021 any = A_arbace_go_repl_A_const_112.Invoke_O__O(p1__794000432_SHARP___1); var arg_4022 any = Lit_134; if linked_4019 == nil { tmp1 = ifn_4020.Invoke_O_O__O(arg_4021, arg_4022) } else { tmp1 = linked_4019.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_4018, arg_4021, arg_4022) }; if jrt.J2g_Truth(tmp1) { return p1__794000432_SHARP___1 } else { return nil } }





func A_arbace_go_repl_eval_BANG__fn__794000459_A_New() *A_arbace_go_repl_eval_BANG__fn__794000459_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_eval_BANG__fn__794000459_A{}; t.Ctor(); return t }
//line :509:1
func (t *A_arbace_go_repl_eval_BANG__fn__794000459_A) Ctor() {}
//line :509:1
func (t *A_arbace_go_repl_eval_BANG__fn__794000459_A) Invoke_O_O__O(self, p1__794000433_SHARP___1 any) any { var tmp1 any = A_arbace_go_repl_A_const_231; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_repl_A_const_232.Invoke_O__O(p1__794000433_SHARP___1))).Ref() }



func A_arbace_go_repl_eval_BANG__fn__794000461_A_New_O_O(p0, p1 any) *A_arbace_go_repl_eval_BANG__fn__794000461_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_eval_BANG__fn__794000461_A{}; t.Ctor_O_O(p0, p1); return t }
//line :513:1
func (t *A_arbace_go_repl_eval_BANG__fn__794000461_A) Ctor_O_O(c__form, c__old any) { t.F_form = c__form; t.F_old = c__old }
//line :513:1
func (t *A_arbace_go_repl_eval_BANG__fn__794000461_A) Invoke_O_O__O(self, p1__794000434_SHARP___1 any) any { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_repl_A_const_58.Invoke_O__O(t.F_old), A_arbace_go_repl_A_const_55.Invoke_O__O(p1__794000434_SHARP___1)) { var root_4143 any = A_arbace_go_repl_A_const_79.GetRawRoot__O(); var linked_4144 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4143, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_4145 lang.IFn; if linked_4144 == nil { ifn_4145 = lang.IFn_Cast(root_4143) } else { ifn_4145 = nil }; var arg_4146 any = p1__794000434_SHARP___1; var arg_4147 any = A_arbace_go_repl_A_const_82; var arg_4148 any = A_arbace_go_repl_A_const_15.GetRawRoot__O(); var arg_4149 any = t.F_form; if linked_4144 == nil { return ifn_4145.Invoke_O_O_O_O__O(arg_4146, arg_4147, arg_4148, arg_4149) } else { return linked_4144.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_4143, arg_4146, arg_4147, arg_4148, arg_4149) } } else { return p1__794000434_SHARP___1 } }



func A_arbace_go_repl_eval_BANG__fn__794000465_A_New_O(p0 any) *A_arbace_go_repl_eval_BANG__fn__794000465_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_eval_BANG__fn__794000465_A{}; t.Ctor_O(p0); return t }
//line :517:1
func (t *A_arbace_go_repl_eval_BANG__fn__794000465_A) Ctor_O(c__obj any) { t.F_obj = c__obj }
//line :517:1
func (t *A_arbace_go_repl_eval_BANG__fn__794000465_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_4071 any = A_arbace_go_repl_A_const_187.GetRawRoot__O(); var linked_4072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4071, aot_arbace_go_build.A_arbace_go_build_desc_A_fn_class); var ifn_4073 lang.IFn; if linked_4072 == nil { ifn_4073 = lang.IFn_Cast(root_4071) } else { ifn_4073 = nil }; var arg_4074 any; var root_4075 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_4076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4075, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_4077 lang.IFn; if linked_4076 == nil { ifn_4077 = lang.IFn_Cast(root_4075) } else { ifn_4077 = nil }; var arg_4078 any; var t_ any = t.F_obj; t.F_obj = nil; arg_4078 = t_; var arg_4079 any = A_arbace_go_repl_A_const_142; if linked_4076 == nil { arg_4074 = ifn_4077.Invoke_O_O__O(arg_4078, arg_4079) } else { arg_4074 = linked_4076.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_4075, arg_4078, arg_4079) }; if linked_4072 == nil { tmp1 = ifn_4073.Invoke_O__O(arg_4074) } else { tmp1 = linked_4072.(*aot_arbace_go_build.A_arbace_go_build_desc_A).Invoke_O_O__O(root_4071, arg_4074) } }; return nil }(); var root_4080 any = A_arbace_go_repl_A_const_196.GetRawRoot__O(); var linked_4081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4080, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_4082 lang.IFn; if linked_4081 == nil { ifn_4082 = lang.IFn_Cast(root_4080) } else { ifn_4082 = nil }; if linked_4081 == nil { ifn_4082.Invoke__O() } else { linked_4081.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_4080) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }





func A_arbace_go_repl_run_main_BANG__A_New() *A_arbace_go_repl_run_main_BANG__A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_run_main_BANG__A{}; t.Ctor(); return t }
//line :523:1
func (t *A_arbace_go_repl_run_main_BANG__A) Ctor() {}
//line :523:1
func (t *A_arbace_go_repl_run_main_BANG__A) Invoke_O_O__O(self, ns_sym__0 any) any { var st__2 any; var root_4164 any = A_arbace_go_repl_A_const_72.GetRawRoot__O(); var linked_4165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4164, A_arbace_go_repl_package_state_A_fn_class); var ifn_4166 lang.IFn; if


	linked_4165 == nil { ifn_4166 = lang.IFn_Cast(root_4164) } else { ifn_4166 = nil }; var arg_4167 any = ns_sym__0; var arg_4168 any = jrt.Boolean_FALSE.Ref(); if linked_4165 == nil { st__2 = ifn_4166.Invoke_O_O__O(arg_4167, arg_4168) } else { st__2 = linked_4165.(*A_arbace_go_repl_package_state_A).Invoke_O_O_O__O(root_4164, arg_4167, arg_4168) }; var cell__3 any; var root_4169 any = /*line :523:1*/A_arbace_go_repl_A_const_152.GetRawRoot__O(); var linked_4170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4169, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4171 lang.IFn; if



	linked_4170 == nil { ifn_4171 = lang.IFn_Cast(root_4169) } else { ifn_4171 = nil }; var arg_4172 any; var root_4174 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_4175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4174, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_4176 lang.IFn; if linked_4175 == nil { ifn_4176 = lang.IFn_Cast(root_4174) } else { ifn_4176 = nil }; var arg_4177 any = st__2; if linked_4175 == nil { arg_4172 = ifn_4176.Invoke_O__O(arg_4177) } else { arg_4172 = linked_4175.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_4174, arg_4177) }; var arg_4173 any = A_arbace_go_repl_A_const_259; if linked_4170 == nil { cell__3 = ifn_4171.Invoke_O_O__O(arg_4172, arg_4173) } else { cell__3 = linked_4170.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4169, arg_4172, arg_4173) }; if
	jrt.J2g_Truth(cell__3) { } else { var tmp1 any; var root_4178 any = A_arbace_go_repl_A_const_69.GetRawRoot__O(); var linked_4179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4178, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_4180 lang.IFn
		if linked_4179 == nil { ifn_4180 = lang.IFn_Cast(root_4178) } else { ifn_4180 = nil }; var arg_4181 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_151), jrt.RefArrayOf(jrt.Object_class, ns_sym__0, nil)).Ref(); var arg_4182 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_4179 == nil { tmp1 = ifn_4180.Invoke_O_O__O(arg_4181, arg_4182) } else { tmp1 = linked_4179.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_4178, arg_4181, arg_4182) }
//line :528:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }; var root_4183 any =

	A_arbace_go_repl_A_const_223.GetRawRoot__O(); var linked_4184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4183, A_arbace_go_repl_call0_A_fn_class); var ifn_4185 lang.IFn; if linked_4184 == nil { ifn_4185 = lang.IFn_Cast(root_4183) } else { ifn_4185 = nil }; var arg_4186 any = cell__3; var arg_4187 any = Lit_90; if linked_4184 == nil { ifn_4185.Invoke_O_O__O(arg_4186, arg_4187) } else { linked_4184.(*A_arbace_go_repl_call0_A).Invoke_O_O_O__O(root_4183, arg_4186, arg_4187) }; return nil }


func A_arbace_go_repl_check_BANG__A_New() *A_arbace_go_repl_check_BANG__A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_check_BANG__A{}; t.Ctor(); return t }
//line :533:1
func (t *A_arbace_go_repl_check_BANG__A) Ctor() {}
//line :533:1
func (t *A_arbace_go_repl_check_BANG__A) Invoke_O_O__O(self, ns_sym__0 any) any { var st__2 any; var root_4188 any = A_arbace_go_repl_A_const_72.GetRawRoot__O(); var linked_4189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4188, A_arbace_go_repl_package_state_A_fn_class); var ifn_4190 lang.IFn; if


	linked_4189 == nil { ifn_4190 = lang.IFn_Cast(root_4188) } else { ifn_4190 = nil }; var arg_4191 any = ns_sym__0; var arg_4192 any = jrt.Boolean_FALSE.Ref(); if linked_4189 == nil { st__2 = ifn_4190.Invoke_O_O__O(arg_4191, arg_4192) } else { st__2 = linked_4189.(*A_arbace_go_repl_package_state_A).Invoke_O_O_O__O(root_4188, arg_4191, arg_4192) }; var tmp1 /*line :537:1*/*lang.Keyword = A_arbace_go_repl_A_const_221; var tmp2 any; var root_4193 any = A_arbace_go_repl_A_const_218.GetRawRoot__O(); var linked_4194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4193, A_arbace_go_repl_check_source_A_fn_class); var ifn_4195 lang.IFn; if linked_4194 == nil { ifn_4195 = lang.IFn_Cast(root_4193) } else { ifn_4195 = nil }; var arg_4196 any; var root_4198 any = A_arbace_go_repl_A_const_118.GetRawRoot__O(); var linked_4199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4198, A_arbace_go_repl_source_of_A_fn_class); var ifn_4200 lang.IFn; if linked_4199 == nil { ifn_4200 = lang.IFn_Cast(root_4198) } else { ifn_4200 = nil }; var arg_4201 any = st__2; if linked_4199 == nil { arg_4196 = ifn_4200.Invoke_O__O(arg_4201) } else { arg_4196 = linked_4199.(*A_arbace_go_repl_source_of_A).Invoke_O_O__O(root_4198, arg_4201) }; var arg_4197 any; if linked_4194 == nil { tmp2 = ifn_4195.Invoke_O_O__O(arg_4196, arg_4197) } else { tmp2 = linked_4194.(*A_arbace_go_repl_check_source_A).Invoke_O_O_O__O(root_4193, arg_4196, arg_4197) }; return tmp1.Invoke_O__O(tmp2) }























































































































































































































































































































































type A_arbace_go_repl_A struct{ jrt.Object }

var A_arbace_go_repl_A_const_pool *jrt.RefArray

var A_arbace_go_repl_A_const_0 *lang.Var

var A_arbace_go_repl_A_const_1 any

var A_arbace_go_repl_A_const_2 *lang.Var

var A_arbace_go_repl_A_const_3 any

var A_arbace_go_repl_A_const_4 any

var A_arbace_go_repl_A_const_5 any

var A_arbace_go_repl_A_const_6 any

var A_arbace_go_repl_A_const_7 any

var A_arbace_go_repl_A_const_8 any

var A_arbace_go_repl_A_const_9 any

var A_arbace_go_repl_A_const_10 any

var A_arbace_go_repl_A_const_11 any

var A_arbace_go_repl_A_const_12 *lang.Var

var A_arbace_go_repl_A_const_13 *lang.Var

var A_arbace_go_repl_A_const_14 *lang.Var

var A_arbace_go_repl_A_const_15 *lang.Var

var A_arbace_go_repl_A_const_16 any

var A_arbace_go_repl_A_const_17 *lang.Var

var A_arbace_go_repl_A_const_18 *lang.Var

var A_arbace_go_repl_A_const_19 *lang.Var

var A_arbace_go_repl_A_const_20 *lang.Keyword

var A_arbace_go_repl_A_const_21 *lang.Var

var A_arbace_go_repl_A_const_22 *lang.Var

var A_arbace_go_repl_A_const_23 any

var A_arbace_go_repl_A_const_24 *lang.Keyword

var A_arbace_go_repl_A_const_25 *lang.Keyword

var A_arbace_go_repl_A_const_26 *lang.Var

var A_arbace_go_repl_A_const_27 *lang.Var

var A_arbace_go_repl_A_const_28 *lang.Var

var A_arbace_go_repl_A_const_29 *lang.Var

var A_arbace_go_repl_A_const_30 *lang.Var

var A_arbace_go_repl_A_const_31 *lang.Var

var A_arbace_go_repl_A_const_32 *lang.Var

var A_arbace_go_repl_A_const_33 *lang.Var

var A_arbace_go_repl_A_const_34 *lang.Var

var A_arbace_go_repl_A_const_35 any

var A_arbace_go_repl_A_const_36 *lang.Keyword

var A_arbace_go_repl_A_const_37 *lang.Var

var A_arbace_go_repl_A_const_38 *lang.Var

var A_arbace_go_repl_A_const_39 *lang.Var

var A_arbace_go_repl_A_const_40 *lang.Var

var A_arbace_go_repl_A_const_41 any

var A_arbace_go_repl_A_const_42 *lang.Var

var A_arbace_go_repl_A_const_43 *lang.Var

var A_arbace_go_repl_A_const_44 *lang.Var

var A_arbace_go_repl_A_const_45 *lang.Var

var A_arbace_go_repl_A_const_46 *lang.Var

var A_arbace_go_repl_A_const_47 *lang.Var

var A_arbace_go_repl_A_const_48 *lang.Var

var A_arbace_go_repl_A_const_49 *lang.Var

var A_arbace_go_repl_A_const_50 *lang.Var

var A_arbace_go_repl_A_const_51 *lang.Var

var A_arbace_go_repl_A_const_52 any

var A_arbace_go_repl_A_const_53 *lang.Var

var A_arbace_go_repl_A_const_54 *lang.Keyword

var A_arbace_go_repl_A_const_55 *lang.Keyword

var A_arbace_go_repl_A_const_56 *lang.Keyword

var A_arbace_go_repl_A_const_57 *lang.Keyword

var A_arbace_go_repl_A_const_58 *lang.Keyword

var A_arbace_go_repl_A_const_59 *lang.Keyword

var A_arbace_go_repl_A_const_60 *lang.Keyword

var A_arbace_go_repl_A_const_61 *lang.Keyword

var A_arbace_go_repl_A_const_62 *lang.Keyword

var A_arbace_go_repl_A_const_63 *lang.Var

var A_arbace_go_repl_A_const_64 *lang.Var

var A_arbace_go_repl_A_const_65 *lang.Var

var A_arbace_go_repl_A_const_66 *lang.Var

var A_arbace_go_repl_A_const_67 any

var A_arbace_go_repl_A_const_68 *lang.Var

var A_arbace_go_repl_A_const_69 *lang.Var

var A_arbace_go_repl_A_const_70 *lang.Var

var A_arbace_go_repl_A_const_71 *lang.Var

var A_arbace_go_repl_A_const_72 *lang.Var

var A_arbace_go_repl_A_const_73 *lang.Var

var A_arbace_go_repl_A_const_74 *lang.Keyword

var A_arbace_go_repl_A_const_75 *lang.Keyword

var A_arbace_go_repl_A_const_76 *lang.Keyword

var A_arbace_go_repl_A_const_77 *lang.Keyword

var A_arbace_go_repl_A_const_78 *lang.Var

var A_arbace_go_repl_A_const_79 *lang.Var

var A_arbace_go_repl_A_const_80 *lang.Var

var A_arbace_go_repl_A_const_81 *lang.Keyword

var A_arbace_go_repl_A_const_82 *lang.Keyword

var A_arbace_go_repl_A_const_83 *lang.Var

var A_arbace_go_repl_A_const_84 *lang.Var

var A_arbace_go_repl_A_const_85 *lang.Keyword

var A_arbace_go_repl_A_const_86 *lang.Var

var A_arbace_go_repl_A_const_87 *lang.Var

var A_arbace_go_repl_A_const_88 *lang.Var

var A_arbace_go_repl_A_const_89 *lang.Var

var A_arbace_go_repl_A_const_90 *lang.Var

var A_arbace_go_repl_A_const_91 *lang.Var

var A_arbace_go_repl_A_const_92 *lang.Var

var A_arbace_go_repl_A_const_93 *lang.Var

var A_arbace_go_repl_A_const_94 *lang.Var

var A_arbace_go_repl_A_const_95 *lang.Var

var A_arbace_go_repl_A_const_96 *lang.Var

var A_arbace_go_repl_A_const_97 *lang.Var

var A_arbace_go_repl_A_const_98 *lang.Var

var A_arbace_go_repl_A_const_99 *lang.Var

var A_arbace_go_repl_A_const_100 *lang.Var

var A_arbace_go_repl_A_const_101 *lang.Var

var A_arbace_go_repl_A_const_102 *lang.Var

var A_arbace_go_repl_A_const_103 *lang.Var

var A_arbace_go_repl_A_const_104 *lang.Var

var A_arbace_go_repl_A_const_105 any

var A_arbace_go_repl_A_const_106 *lang.Keyword

var A_arbace_go_repl_A_const_107 *lang.Var

var A_arbace_go_repl_A_const_108 *lang.Keyword

var A_arbace_go_repl_A_const_109 any

var A_arbace_go_repl_A_const_110 *lang.Keyword

var A_arbace_go_repl_A_const_111 *lang.Keyword

var A_arbace_go_repl_A_const_112 *lang.Keyword

var A_arbace_go_repl_A_const_113 *lang.Var

var A_arbace_go_repl_A_const_114 any

var A_arbace_go_repl_A_const_115 *lang.Var

var A_arbace_go_repl_A_const_116 *lang.Var

var A_arbace_go_repl_A_const_117 *lang.Var

var A_arbace_go_repl_A_const_118 *lang.Var

var A_arbace_go_repl_A_const_119 *lang.Keyword

var A_arbace_go_repl_A_const_120 *lang.Var

var A_arbace_go_repl_A_const_121 *lang.Keyword

var A_arbace_go_repl_A_const_122 *lang.Var

var A_arbace_go_repl_A_const_123 *lang.Var

var A_arbace_go_repl_A_const_124 *lang.Var

var A_arbace_go_repl_A_const_125 *lang.Var

var A_arbace_go_repl_A_const_126 *lang.Keyword

var A_arbace_go_repl_A_const_127 *lang.Var

var A_arbace_go_repl_A_const_128 *lang.Keyword

var A_arbace_go_repl_A_const_129 *lang.Var

var A_arbace_go_repl_A_const_130 *lang.Var

var A_arbace_go_repl_A_const_131 *lang.Var

var A_arbace_go_repl_A_const_132 *lang.Var

var A_arbace_go_repl_A_const_133 *lang.Keyword

var A_arbace_go_repl_A_const_134 *lang.Keyword

var A_arbace_go_repl_A_const_135 *lang.Keyword

var A_arbace_go_repl_A_const_136 *lang.Keyword

var A_arbace_go_repl_A_const_137 *lang.Keyword

var A_arbace_go_repl_A_const_138 *lang.Var

var A_arbace_go_repl_A_const_139 *lang.Keyword

var A_arbace_go_repl_A_const_140 *lang.Keyword

var A_arbace_go_repl_A_const_141 *lang.Keyword

var A_arbace_go_repl_A_const_142 *lang.Keyword

var A_arbace_go_repl_A_const_143 *lang.Keyword

var A_arbace_go_repl_A_const_144 *lang.Keyword

var A_arbace_go_repl_A_const_145 any

var A_arbace_go_repl_A_const_146 *lang.Keyword

var A_arbace_go_repl_A_const_147 *lang.Keyword

var A_arbace_go_repl_A_const_148 *lang.Keyword

var A_arbace_go_repl_A_const_149 any

var A_arbace_go_repl_A_const_150 *lang.Keyword

var A_arbace_go_repl_A_const_151 *lang.Var

var A_arbace_go_repl_A_const_152 *lang.Var

var A_arbace_go_repl_A_const_153 any

var A_arbace_go_repl_A_const_154 *lang.Keyword

var A_arbace_go_repl_A_const_155 *lang.Keyword

var A_arbace_go_repl_A_const_156 *lang.Keyword

var A_arbace_go_repl_A_const_157 *lang.Var

var A_arbace_go_repl_A_const_158 *lang.Var

var A_arbace_go_repl_A_const_159 *lang.Var

var A_arbace_go_repl_A_const_160 *lang.Var

var A_arbace_go_repl_A_const_161 *lang.Var

var A_arbace_go_repl_A_const_162 any

var A_arbace_go_repl_A_const_163 *lang.Keyword

var A_arbace_go_repl_A_const_164 *lang.Var

var A_arbace_go_repl_A_const_165 *lang.Keyword

var A_arbace_go_repl_A_const_166 *lang.Keyword

var A_arbace_go_repl_A_const_167 *lang.Keyword

var A_arbace_go_repl_A_const_168 *lang.Keyword

var A_arbace_go_repl_A_const_169 *lang.Keyword

var A_arbace_go_repl_A_const_170 *lang.Var

var A_arbace_go_repl_A_const_171 *lang.Keyword

var A_arbace_go_repl_A_const_172 *lang.Keyword

var A_arbace_go_repl_A_const_173 *lang.Keyword

var A_arbace_go_repl_A_const_174 *lang.Keyword

var A_arbace_go_repl_A_const_175 *lang.Keyword

var A_arbace_go_repl_A_const_176 *lang.Var

var A_arbace_go_repl_A_const_177 *lang.Keyword

var A_arbace_go_repl_A_const_178 *lang.Keyword

var A_arbace_go_repl_A_const_179 *lang.Var

var A_arbace_go_repl_A_const_180 *lang.Keyword

var A_arbace_go_repl_A_const_181 *lang.Keyword

var A_arbace_go_repl_A_const_182 *lang.Keyword

var A_arbace_go_repl_A_const_183 *lang.Keyword

var A_arbace_go_repl_A_const_184 *lang.Keyword

var A_arbace_go_repl_A_const_185 *lang.Var

var A_arbace_go_repl_A_const_186 *lang.Keyword

var A_arbace_go_repl_A_const_187 *lang.Var

var A_arbace_go_repl_A_const_188 *lang.Keyword

var A_arbace_go_repl_A_const_189 *lang.Keyword

var A_arbace_go_repl_A_const_190 *lang.Var

var A_arbace_go_repl_A_const_191 *lang.Keyword

var A_arbace_go_repl_A_const_192 *lang.Keyword

var A_arbace_go_repl_A_const_193 *lang.Keyword

var A_arbace_go_repl_A_const_194 any

var A_arbace_go_repl_A_const_195 *lang.Keyword

var A_arbace_go_repl_A_const_196 *lang.Var

var A_arbace_go_repl_A_const_197 *lang.Keyword

var A_arbace_go_repl_A_const_198 *lang.Var

var A_arbace_go_repl_A_const_199 *lang.Var

var A_arbace_go_repl_A_const_200 *lang.Keyword

var A_arbace_go_repl_A_const_201 *lang.Var

var A_arbace_go_repl_A_const_202 *lang.Var

var A_arbace_go_repl_A_const_203 *lang.Var

var A_arbace_go_repl_A_const_204 *lang.Var

var A_arbace_go_repl_A_const_205 *lang.Keyword

var A_arbace_go_repl_A_const_206 *lang.Keyword

var A_arbace_go_repl_A_const_207 *lang.Keyword

var A_arbace_go_repl_A_const_208 *lang.Var

var A_arbace_go_repl_A_const_209 *lang.Keyword

var A_arbace_go_repl_A_const_210 *lang.Var

var A_arbace_go_repl_A_const_211 *lang.Var

var A_arbace_go_repl_A_const_212 *lang.Keyword

var A_arbace_go_repl_A_const_213 *lang.Keyword

var A_arbace_go_repl_A_const_214 *lang.Keyword

var A_arbace_go_repl_A_const_215 *lang.Var

var A_arbace_go_repl_A_const_216 *lang.Var

var A_arbace_go_repl_A_const_217 *lang.Keyword

var A_arbace_go_repl_A_const_218 *lang.Var

var A_arbace_go_repl_A_const_219 *lang.Var

var A_arbace_go_repl_A_const_220 any

var A_arbace_go_repl_A_const_221 *lang.Keyword

var A_arbace_go_repl_A_const_222 *lang.Keyword

var A_arbace_go_repl_A_const_223 *lang.Var

var A_arbace_go_repl_A_const_224 *lang.Var

var A_arbace_go_repl_A_const_225 *lang.Var

var A_arbace_go_repl_A_const_226 *lang.Var

var A_arbace_go_repl_A_const_227 *lang.Var

var A_arbace_go_repl_A_const_228 *lang.Var

var A_arbace_go_repl_A_const_229 *lang.Var

var A_arbace_go_repl_A_const_230 *lang.Var

var A_arbace_go_repl_A_const_231 *lang.Keyword

var A_arbace_go_repl_A_const_232 *lang.Keyword

var A_arbace_go_repl_A_const_233 *lang.Var

var A_arbace_go_repl_A_const_234 *lang.Keyword

var A_arbace_go_repl_A_const_235 *lang.Keyword

var A_arbace_go_repl_A_const_236 *lang.Var

var A_arbace_go_repl_A_const_237 *lang.Var

var A_arbace_go_repl_A_const_238 *lang.Var

var A_arbace_go_repl_A_const_239 *lang.Var

var A_arbace_go_repl_A_const_240 *lang.Var

var A_arbace_go_repl_A_const_241 *lang.Var

var A_arbace_go_repl_A_const_242 *lang.Var

var A_arbace_go_repl_A_const_243 any

var A_arbace_go_repl_A_const_244 *lang.Var

var A_arbace_go_repl_A_const_245 *lang.Var

var A_arbace_go_repl_A_const_246 any

var A_arbace_go_repl_A_const_247 *lang.Var

var A_arbace_go_repl_A_const_248 *lang.Var

var A_arbace_go_repl_A_const_249 any

var A_arbace_go_repl_A_const_250 any

var A_arbace_go_repl_A_const_251 *lang.Keyword

var A_arbace_go_repl_A_const_252 *lang.Var

var A_arbace_go_repl_A_const_253 any

var A_arbace_go_repl_A_const_254 *lang.Keyword

var A_arbace_go_repl_A_const_255 *lang.Var

var A_arbace_go_repl_A_const_256 *lang.Var

var A_arbace_go_repl_A_const_257 any

var A_arbace_go_repl_A_const_258 any

var A_arbace_go_repl_A_const_259 any

var A_arbace_go_repl_A_init jrt.ClassInit

func A_arbace_go_repl_A_Init() { if !A_arbace_go_repl_A_init.Done() { A_arbace_go_repl_A_init.Run(A_arbace_go_repl_A_clinit) } }

func A_arbace_go_repl_A_clinit() { A_arbace_go_repl_A_clinit_p0(); A_arbace_go_repl_A_clinit_p1(); A_arbace_go_repl_A_clinit_p2(); A_arbace_go_repl_A_clinit_p3(); A_arbace_go_repl_A_clinit_p4(); A_arbace_go_repl_A_clinit_p5(); A_arbace_go_repl_A_clinit_p6(); A_arbace_go_repl_A_clinit_p7(); A_arbace_go_repl_A_clinit_p8(); A_arbace_go_repl_A_clinit_p9(); A_arbace_go_repl_A_clinit_p10(); A_arbace_go_repl_A_clinit_p11(); A_arbace_go_repl_A_clinit_p12(); A_arbace_go_repl_A_clinit_p13(); A_arbace_go_repl_A_clinit_p14(); A_arbace_go_repl_A_clinit_p15(); A_arbace_go_repl_A_clinit_p16(); A_arbace_go_repl_A_clinit_p17(); A_arbace_go_repl_A_clinit_p18(); A_arbace_go_repl_A_clinit_p19(); A_arbace_go_repl_A_clinit_p20(); A_arbace_go_repl_A_clinit_p21() }

func A_arbace_go_repl_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_repl_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 379); A_arbace_go_repl_A_const_0 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[119]); A_arbace_go_repl_A_const_1 = A_arbace_go_repl_A_const_pool.A[120]; A_arbace_go_repl_A_const_2 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[121]); A_arbace_go_repl_A_const_3 = A_arbace_go_repl_A_const_pool.A[122]; A_arbace_go_repl_A_const_4 = A_arbace_go_repl_A_const_pool.A[123]; A_arbace_go_repl_A_const_5 = A_arbace_go_repl_A_const_pool.A[124]; A_arbace_go_repl_A_const_6 = A_arbace_go_repl_A_const_pool.A[125]; A_arbace_go_repl_A_const_7 = A_arbace_go_repl_A_const_pool.A[126]; A_arbace_go_repl_A_const_8 = A_arbace_go_repl_A_const_pool.A[127]; A_arbace_go_repl_A_const_9 = A_arbace_go_repl_A_const_pool.A[128]; A_arbace_go_repl_A_const_10 = A_arbace_go_repl_A_const_pool.A[129]; A_arbace_go_repl_A_const_11 = A_arbace_go_repl_A_const_pool.A[130]; A_arbace_go_repl_A_const_12 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[131]) }

func A_arbace_go_repl_A_clinit_p1() { A_arbace_go_repl_A_const_13 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[132]); A_arbace_go_repl_A_const_14 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[133]); A_arbace_go_repl_A_const_15 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[134]); A_arbace_go_repl_A_const_16 = A_arbace_go_repl_A_const_pool.A[135]; A_arbace_go_repl_A_const_17 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[136]); A_arbace_go_repl_A_const_18 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[137]); A_arbace_go_repl_A_const_19 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[138]); A_arbace_go_repl_A_const_20 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[139]); A_arbace_go_repl_A_const_21 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[140]); A_arbace_go_repl_A_const_22 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[141]); A_arbace_go_repl_A_const_23 = A_arbace_go_repl_A_const_pool.A[142]; A_arbace_go_repl_A_const_24 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[143]) }

func A_arbace_go_repl_A_clinit_p2() { A_arbace_go_repl_A_const_25 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[144]); A_arbace_go_repl_A_const_26 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[145]); A_arbace_go_repl_A_const_27 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[146]); A_arbace_go_repl_A_const_28 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[147]); A_arbace_go_repl_A_const_29 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[148]); A_arbace_go_repl_A_const_30 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[149]); A_arbace_go_repl_A_const_31 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[150]); A_arbace_go_repl_A_const_32 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[151]); A_arbace_go_repl_A_const_33 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[152]); A_arbace_go_repl_A_const_34 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[153]); A_arbace_go_repl_A_const_35 = A_arbace_go_repl_A_const_pool.A[154]; A_arbace_go_repl_A_const_36 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[155]) }

func A_arbace_go_repl_A_clinit_p3() { A_arbace_go_repl_A_const_37 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[156]); A_arbace_go_repl_A_const_38 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[157]); A_arbace_go_repl_A_const_39 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[158]); A_arbace_go_repl_A_const_40 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[159]); A_arbace_go_repl_A_const_41 = A_arbace_go_repl_A_const_pool.A[160]; A_arbace_go_repl_A_const_42 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[161]); A_arbace_go_repl_A_const_43 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[162]); A_arbace_go_repl_A_const_44 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[163]); A_arbace_go_repl_A_const_45 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[164]); A_arbace_go_repl_A_const_46 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[165]); A_arbace_go_repl_A_const_47 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[166]); A_arbace_go_repl_A_const_48 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[167]) }

func A_arbace_go_repl_A_clinit_p4() { A_arbace_go_repl_A_const_49 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[168]); A_arbace_go_repl_A_const_50 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[169]); A_arbace_go_repl_A_const_51 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[170]); A_arbace_go_repl_A_const_52 = A_arbace_go_repl_A_const_pool.A[171]; A_arbace_go_repl_A_const_53 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[172]); A_arbace_go_repl_A_const_54 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[173]); A_arbace_go_repl_A_const_55 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[174]); A_arbace_go_repl_A_const_56 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[175]); A_arbace_go_repl_A_const_57 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[176]); A_arbace_go_repl_A_const_58 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[177]); A_arbace_go_repl_A_const_59 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[178]); A_arbace_go_repl_A_const_60 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[179]) }

func A_arbace_go_repl_A_clinit_p5() { A_arbace_go_repl_A_const_61 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[180]); A_arbace_go_repl_A_const_62 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[181]); A_arbace_go_repl_A_const_63 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[182]); A_arbace_go_repl_A_const_64 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[183]); A_arbace_go_repl_A_const_65 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[184]); A_arbace_go_repl_A_const_66 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[185]); A_arbace_go_repl_A_const_67 = A_arbace_go_repl_A_const_pool.A[186]; A_arbace_go_repl_A_const_68 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[187]); A_arbace_go_repl_A_const_69 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[188]); A_arbace_go_repl_A_const_70 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[189]); A_arbace_go_repl_A_const_71 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[190]); A_arbace_go_repl_A_const_72 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[191]) }

func A_arbace_go_repl_A_clinit_p6() { A_arbace_go_repl_A_const_73 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[192]); A_arbace_go_repl_A_const_74 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[193]); A_arbace_go_repl_A_const_75 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[194]); A_arbace_go_repl_A_const_76 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[195]); A_arbace_go_repl_A_const_77 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[196]); A_arbace_go_repl_A_const_78 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[197]); A_arbace_go_repl_A_const_79 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[198]); A_arbace_go_repl_A_const_80 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[199]); A_arbace_go_repl_A_const_81 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[200]); A_arbace_go_repl_A_const_82 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[201]); A_arbace_go_repl_A_const_83 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[202]); A_arbace_go_repl_A_const_84 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[203]) }

func A_arbace_go_repl_A_clinit_p7() { A_arbace_go_repl_A_const_85 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[204]); A_arbace_go_repl_A_const_86 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[205]); A_arbace_go_repl_A_const_87 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[206]); A_arbace_go_repl_A_const_88 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[207]); A_arbace_go_repl_A_const_89 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[208]); A_arbace_go_repl_A_const_90 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[209]); A_arbace_go_repl_A_const_91 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[210]); A_arbace_go_repl_A_const_92 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[211]); A_arbace_go_repl_A_const_93 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[212]); A_arbace_go_repl_A_const_94 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[213]); A_arbace_go_repl_A_const_95 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[214]); A_arbace_go_repl_A_const_96 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[215]) }

func A_arbace_go_repl_A_clinit_p8() { A_arbace_go_repl_A_const_97 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[216]); A_arbace_go_repl_A_const_98 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[217]); A_arbace_go_repl_A_const_99 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[218]); A_arbace_go_repl_A_const_100 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[219]); A_arbace_go_repl_A_const_101 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[220]); A_arbace_go_repl_A_const_102 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[221]); A_arbace_go_repl_A_const_103 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[222]); A_arbace_go_repl_A_const_104 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[223]); A_arbace_go_repl_A_const_105 = A_arbace_go_repl_A_const_pool.A[224]; A_arbace_go_repl_A_const_106 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[225]); A_arbace_go_repl_A_const_107 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[226]); A_arbace_go_repl_A_const_108 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[227]) }

func A_arbace_go_repl_A_clinit_p9() { A_arbace_go_repl_A_const_109 = A_arbace_go_repl_A_const_pool.A[228]; A_arbace_go_repl_A_const_110 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[229]); A_arbace_go_repl_A_const_111 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[230]); A_arbace_go_repl_A_const_112 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[231]); A_arbace_go_repl_A_const_113 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[232]); A_arbace_go_repl_A_const_114 = A_arbace_go_repl_A_const_pool.A[233]; A_arbace_go_repl_A_const_115 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[234]); A_arbace_go_repl_A_const_116 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[235]); A_arbace_go_repl_A_const_117 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[236]); A_arbace_go_repl_A_const_118 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[237]); A_arbace_go_repl_A_const_119 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[238]); A_arbace_go_repl_A_const_120 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[239]) }

func A_arbace_go_repl_A_clinit_p10() { A_arbace_go_repl_A_const_121 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[240]); A_arbace_go_repl_A_const_122 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[241]); A_arbace_go_repl_A_const_123 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[242]); A_arbace_go_repl_A_const_124 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[243]); A_arbace_go_repl_A_const_125 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[244]); A_arbace_go_repl_A_const_126 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[245]); A_arbace_go_repl_A_const_127 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[246]); A_arbace_go_repl_A_const_128 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[247]); A_arbace_go_repl_A_const_129 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[248]); A_arbace_go_repl_A_const_130 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[249]); A_arbace_go_repl_A_const_131 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[250]); A_arbace_go_repl_A_const_132 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[251]) }

func A_arbace_go_repl_A_clinit_p11() { A_arbace_go_repl_A_const_133 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[252]); A_arbace_go_repl_A_const_134 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[253]); A_arbace_go_repl_A_const_135 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[254]); A_arbace_go_repl_A_const_136 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[255]); A_arbace_go_repl_A_const_137 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[256]); A_arbace_go_repl_A_const_138 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[257]); A_arbace_go_repl_A_const_139 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[258]); A_arbace_go_repl_A_const_140 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[259]); A_arbace_go_repl_A_const_141 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[260]); A_arbace_go_repl_A_const_142 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[261]); A_arbace_go_repl_A_const_143 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[262]); A_arbace_go_repl_A_const_144 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[263]) }

func A_arbace_go_repl_A_clinit_p12() { A_arbace_go_repl_A_const_145 = A_arbace_go_repl_A_const_pool.A[264]; A_arbace_go_repl_A_const_146 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[265]); A_arbace_go_repl_A_const_147 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[266]); A_arbace_go_repl_A_const_148 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[267]); A_arbace_go_repl_A_const_149 = A_arbace_go_repl_A_const_pool.A[268]; A_arbace_go_repl_A_const_150 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[269]); A_arbace_go_repl_A_const_151 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[270]); A_arbace_go_repl_A_const_152 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[271]); A_arbace_go_repl_A_const_153 = A_arbace_go_repl_A_const_pool.A[272]; A_arbace_go_repl_A_const_154 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[273]); A_arbace_go_repl_A_const_155 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[274]); A_arbace_go_repl_A_const_156 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[275]) }

func A_arbace_go_repl_A_clinit_p13() { A_arbace_go_repl_A_const_157 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[276]); A_arbace_go_repl_A_const_158 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[277]); A_arbace_go_repl_A_const_159 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[278]); A_arbace_go_repl_A_const_160 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[279]); A_arbace_go_repl_A_const_161 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[280]); A_arbace_go_repl_A_const_162 = A_arbace_go_repl_A_const_pool.A[281]; A_arbace_go_repl_A_const_163 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[282]); A_arbace_go_repl_A_const_164 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[283]); A_arbace_go_repl_A_const_165 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[284]); A_arbace_go_repl_A_const_166 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[285]); A_arbace_go_repl_A_const_167 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[286]); A_arbace_go_repl_A_const_168 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[287]) }

func A_arbace_go_repl_A_clinit_p14() { A_arbace_go_repl_A_const_169 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[288]); A_arbace_go_repl_A_const_170 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[289]); A_arbace_go_repl_A_const_171 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[290]); A_arbace_go_repl_A_const_172 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[291]); A_arbace_go_repl_A_const_173 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[292]); A_arbace_go_repl_A_const_174 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[293]); A_arbace_go_repl_A_const_175 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[294]); A_arbace_go_repl_A_const_176 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[295]); A_arbace_go_repl_A_const_177 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[296]); A_arbace_go_repl_A_const_178 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[297]); A_arbace_go_repl_A_const_179 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[298]); A_arbace_go_repl_A_const_180 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[299]) }

func A_arbace_go_repl_A_clinit_p15() { A_arbace_go_repl_A_const_181 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[300]); A_arbace_go_repl_A_const_182 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[301]); A_arbace_go_repl_A_const_183 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[302]); A_arbace_go_repl_A_const_184 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[303]); A_arbace_go_repl_A_const_185 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[304]); A_arbace_go_repl_A_const_186 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[305]); A_arbace_go_repl_A_const_187 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[306]); A_arbace_go_repl_A_const_188 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[307]); A_arbace_go_repl_A_const_189 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[308]); A_arbace_go_repl_A_const_190 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[309]); A_arbace_go_repl_A_const_191 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[310]); A_arbace_go_repl_A_const_192 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[311]) }

func A_arbace_go_repl_A_clinit_p16() { A_arbace_go_repl_A_const_193 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[312]); A_arbace_go_repl_A_const_194 = A_arbace_go_repl_A_const_pool.A[313]; A_arbace_go_repl_A_const_195 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[314]); A_arbace_go_repl_A_const_196 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[315]); A_arbace_go_repl_A_const_197 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[316]); A_arbace_go_repl_A_const_198 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[317]); A_arbace_go_repl_A_const_199 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[318]); A_arbace_go_repl_A_const_200 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[319]); A_arbace_go_repl_A_const_201 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[320]); A_arbace_go_repl_A_const_202 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[321]); A_arbace_go_repl_A_const_203 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[322]); A_arbace_go_repl_A_const_204 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[323]) }

func A_arbace_go_repl_A_clinit_p17() { A_arbace_go_repl_A_const_205 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[324]); A_arbace_go_repl_A_const_206 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[325]); A_arbace_go_repl_A_const_207 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[326]); A_arbace_go_repl_A_const_208 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[327]); A_arbace_go_repl_A_const_209 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[328]); A_arbace_go_repl_A_const_210 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[329]); A_arbace_go_repl_A_const_211 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[330]); A_arbace_go_repl_A_const_212 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[331]); A_arbace_go_repl_A_const_213 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[332]); A_arbace_go_repl_A_const_214 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[333]); A_arbace_go_repl_A_const_215 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[334]); A_arbace_go_repl_A_const_216 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[335]) }

func A_arbace_go_repl_A_clinit_p18() { A_arbace_go_repl_A_const_217 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[336]); A_arbace_go_repl_A_const_218 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[337]); A_arbace_go_repl_A_const_219 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[338]); A_arbace_go_repl_A_const_220 = A_arbace_go_repl_A_const_pool.A[339]; A_arbace_go_repl_A_const_221 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[340]); A_arbace_go_repl_A_const_222 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[341]); A_arbace_go_repl_A_const_223 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[342]); A_arbace_go_repl_A_const_224 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[343]); A_arbace_go_repl_A_const_225 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[344]); A_arbace_go_repl_A_const_226 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[345]); A_arbace_go_repl_A_const_227 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[346]); A_arbace_go_repl_A_const_228 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[347]) }

func A_arbace_go_repl_A_clinit_p19() { A_arbace_go_repl_A_const_229 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[348]); A_arbace_go_repl_A_const_230 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[349]); A_arbace_go_repl_A_const_231 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[350]); A_arbace_go_repl_A_const_232 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[351]); A_arbace_go_repl_A_const_233 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[352]); A_arbace_go_repl_A_const_234 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[353]); A_arbace_go_repl_A_const_235 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[354]); A_arbace_go_repl_A_const_236 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[355]); A_arbace_go_repl_A_const_237 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[356]); A_arbace_go_repl_A_const_238 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[357]); A_arbace_go_repl_A_const_239 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[358]); A_arbace_go_repl_A_const_240 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[359]) }

func A_arbace_go_repl_A_clinit_p20() { A_arbace_go_repl_A_const_241 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[360]); A_arbace_go_repl_A_const_242 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[361]); A_arbace_go_repl_A_const_243 = A_arbace_go_repl_A_const_pool.A[362]; A_arbace_go_repl_A_const_244 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[363]); A_arbace_go_repl_A_const_245 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[364]); A_arbace_go_repl_A_const_246 = A_arbace_go_repl_A_const_pool.A[365]; A_arbace_go_repl_A_const_247 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[366]); A_arbace_go_repl_A_const_248 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[367]); A_arbace_go_repl_A_const_249 = A_arbace_go_repl_A_const_pool.A[368]; A_arbace_go_repl_A_const_250 = A_arbace_go_repl_A_const_pool.A[369]; A_arbace_go_repl_A_const_251 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[370]); A_arbace_go_repl_A_const_252 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[371]); A_arbace_go_repl_A_const_253 = A_arbace_go_repl_A_const_pool.A[372] }

func A_arbace_go_repl_A_clinit_p21() { A_arbace_go_repl_A_const_254 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[373]); A_arbace_go_repl_A_const_255 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[374]); A_arbace_go_repl_A_const_256 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[375]); A_arbace_go_repl_A_const_257 = A_arbace_go_repl_A_const_pool.A[376]; A_arbace_go_repl_A_const_258 = A_arbace_go_repl_A_const_pool.A[377]; A_arbace_go_repl_A_const_259 = A_arbace_go_repl_A_const_pool.A[378] }

func A_arbace_go_repl_A_New() *A_arbace_go_repl_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_A{}; t.Ctor(); return t }

func (t *A_arbace_go_repl_A) Ctor() {}

func (t *A_arbace_go_repl_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_repl_A) GetClass__Class() *jrt.Class { return A_arbace_go_repl_A_class }

func (t *A_arbace_go_repl_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_repl_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_repl_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_repl_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_repl_A); return ok }

func A_arbace_go_repl_A_Cast(x any) *A_arbace_go_repl_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_repl_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_repl_A_class)) }; return v }



type A_arbace_go_repl_after_load_A struct{ j2g_header uint64 }

var A_arbace_go_repl_after_load_A_fn_class *jrt.Class



type A_arbace_go_repl_build_context_A struct{ j2g_header uint64 }

var A_arbace_go_repl_build_context_A_fn_class *jrt.Class



type A_arbace_go_repl_build_context_fn__794000171_A struct{ j2g_header uint64 }

var A_arbace_go_repl_build_context_fn__794000171_A_fn_class *jrt.Class



type A_arbace_go_repl_build_context_fn__794000173_A struct{ j2g_header uint64 }

var A_arbace_go_repl_build_context_fn__794000173_A_fn_class *jrt.Class



type A_arbace_go_repl_build_context_fn__794000175_A struct{ j2g_header uint64 }

var A_arbace_go_repl_build_context_fn__794000175_A_fn_class *jrt.Class



type A_arbace_go_repl_call0_A struct{ j2g_header uint64 }

var A_arbace_go_repl_call0_A_fn_class *jrt.Class



type A_arbace_go_repl_check_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_repl_check_BANG__A_fn_class *jrt.Class



type A_arbace_go_repl_check_source_A struct{ j2g_header uint64 }

var A_arbace_go_repl_check_source_A_fn_class *jrt.Class



type A_arbace_go_repl_complete_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_repl_complete_BANG__A_fn_class *jrt.Class



type A_arbace_go_repl_const_arbace_A struct{ j2g_header uint64 }

var A_arbace_go_repl_const_arbace_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_A struct{ j2g_header uint64 }

var A_arbace_go_repl_decl_names_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_group_QMARK___794000064_A struct{ j2g_header uint64 }

var A_arbace_go_repl_decl_names_group_QMARK___794000064_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_iter__794000069__794000073_A struct{ j2g_header uint64 }

var A_arbace_go_repl_decl_names_iter__794000069__794000073_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_A struct{ j2g_header uint64; F_s__794000070, F_iter__794000069 any }

var A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_fn__794000075_A struct{ j2g_header uint64; F_b__794000072 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_fn__794000075_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_iter__794000085__794000091_A struct{ j2g_header uint64; F_targets any }

var A_arbace_go_repl_decl_names_iter__794000085__794000091_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_A struct{ j2g_header uint64; F_iter__794000085, F_s__794000086, F_targets any }

var A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_A struct{ j2g_header uint64 }

var A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_A struct{ j2g_header uint64; F_iter__794000087, F_s__794000088 any }

var A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_fn__794000098_A struct{ j2g_header uint64; F_b__794000090 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_fn__794000098_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_iter__794000104__794000110_A struct{ j2g_header uint64; F_targets any }

var A_arbace_go_repl_decl_names_iter__794000104__794000110_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_A struct{ j2g_header uint64; F_s__794000105, F_targets, F_iter__794000104 any }

var A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_A struct{ j2g_header uint64 }

var A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_A struct{ j2g_header uint64; F_iter__794000106, F_s__794000107 any }

var A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_fn__794000117_A struct{ j2g_header uint64; F_b__794000109 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_fn__794000117_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_specs__794000066_A struct{ j2g_header uint64 }

var A_arbace_go_repl_decl_names_specs__794000066_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_targets__794000062_A struct{ j2g_header uint64 }

var A_arbace_go_repl_decl_names_targets__794000062_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_repl_declare_BANG__A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__fn__794000390_A struct{ j2g_header uint64; F_form any }

var A_arbace_go_repl_declare_BANG__fn__794000390_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__fn__794000410_A struct{ j2g_header uint64; F_old any }

var A_arbace_go_repl_declare_BANG__fn__794000410_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__fn__794000412_A struct{ j2g_header uint64; F_form, F_old any }

var A_arbace_go_repl_declare_BANG__fn__794000412_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__fn__794000414_A struct{ j2g_header uint64; F_st, F_old any }

var A_arbace_go_repl_declare_BANG__fn__794000414_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__fn__794000416_A struct{ j2g_header uint64 }

var A_arbace_go_repl_declare_BANG__fn__794000416_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__fn__794000420_A struct{ j2g_header uint64; F_spec_of any }

var A_arbace_go_repl_declare_BANG__fn__794000420_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__fn__794000422_A struct{ j2g_header uint64; F_broken, F_others any }

var A_arbace_go_repl_declare_BANG__fn__794000422_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__fn__794000426_A struct{ j2g_header uint64; F_broken any; F_var_QMARK_ bool; F_r, F_st, F_old, F_names any }

var A_arbace_go_repl_declare_BANG__fn__794000426_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__iter__794000392__794000396_A struct{ j2g_header uint64; F_names any }

var A_arbace_go_repl_declare_BANG__iter__794000392__794000396_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_A struct{ j2g_header uint64; F_iter__794000392, F_s__794000393, F_names any }

var A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_A struct{ j2g_header uint64; F_b__794000395 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_names any }

var A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_fn__794000399_A struct{ j2g_header uint64; F_names any }

var A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_fn__794000399_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_fn__794000399_fn__794000400_A struct{ j2g_header uint64; F_names any }

var A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000398_fn__794000399_fn__794000400_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000404_A struct{ j2g_header uint64; F_names any }

var A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000404_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000404_fn__794000405_A struct{ j2g_header uint64; F_names any }

var A_arbace_go_repl_declare_BANG__iter__794000392__794000396_fn__794000397_fn__794000404_fn__794000405_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__own_QMARK___794000418_A struct{ j2g_header uint64; F_form, F_spec_of any }

var A_arbace_go_repl_declare_BANG__own_QMARK___794000418_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_repl_define_BANG__A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000192_A struct{ j2g_header uint64 }

var A_arbace_go_repl_define_BANG__fn__794000192_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000194_A struct{ j2g_header uint64 }

var A_arbace_go_repl_define_BANG__fn__794000194_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000206_A struct{ j2g_header uint64 }

var A_arbace_go_repl_define_BANG__fn__794000206_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000208_A struct{ j2g_header uint64 }

var A_arbace_go_repl_define_BANG__fn__794000208_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000269_A struct{ j2g_header uint64; F_tree any }

var A_arbace_go_repl_define_BANG__fn__794000269_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000271_A struct{ j2g_header uint64; F_ctx, F_tree any }

var A_arbace_go_repl_define_BANG__fn__794000271_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000278_A struct{ j2g_header uint64; F_tree any }

var A_arbace_go_repl_define_BANG__fn__794000278_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000280_A struct{ j2g_header uint64; F_tree, F_ctx any }

var A_arbace_go_repl_define_BANG__fn__794000280_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000288_A struct{ j2g_header uint64; F_tree any }

var A_arbace_go_repl_define_BANG__fn__794000288_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000292_A struct{ j2g_header uint64; F_tree any }

var A_arbace_go_repl_define_BANG__fn__794000292_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000304_A struct{ j2g_header uint64; F_var_trees any }

var A_arbace_go_repl_define_BANG__fn__794000304_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000306_A struct{ j2g_header uint64; F_names any }

var A_arbace_go_repl_define_BANG__fn__794000306_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000306_fn__794000307_A struct{ j2g_header uint64; F_names any }

var A_arbace_go_repl_define_BANG__fn__794000306_fn__794000307_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000319_A struct{ j2g_header uint64; F_obj any }

var A_arbace_go_repl_define_BANG__fn__794000319_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000327_A struct{ j2g_header uint64; F_obj any }

var A_arbace_go_repl_define_BANG__fn__794000327_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000352_A struct{ j2g_header uint64; F_ns, F_x, F_old any }

var A_arbace_go_repl_define_BANG__fn__794000352_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000354_A struct{ j2g_header uint64; F_ns, F_x, F_old any }

var A_arbace_go_repl_define_BANG__fn__794000354_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__gen_of__794000190_A struct{ j2g_header uint64; F_old any }

var A_arbace_go_repl_define_BANG__gen_of__794000190_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000196__794000200_A struct{ j2g_header uint64; F_gen_of, F_old any }

var A_arbace_go_repl_define_BANG__iter__794000196__794000200_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000196__794000200_fn__794000201_A struct{ j2g_header uint64; F_iter__794000196, F_gen_of, F_old, F_s__794000197 any }

var A_arbace_go_repl_define_BANG__iter__794000196__794000200_fn__794000201_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000196__794000200_fn__794000201_fn__794000202_A struct{ j2g_header uint64; F_b__794000199, F_gen_of, F_old any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_repl_define_BANG__iter__794000196__794000200_fn__794000201_fn__794000202_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000210__794000214_A struct{ j2g_header uint64; F_old, F_ctx, F_kept_names any }

var A_arbace_go_repl_define_BANG__iter__794000210__794000214_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000210__794000214_fn__794000215_A struct{ j2g_header uint64; F_s__794000211, F_old, F_iter__794000210, F_ctx, F_kept_names any }

var A_arbace_go_repl_define_BANG__iter__794000210__794000214_fn__794000215_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000210__794000214_fn__794000215_fn__794000216_A struct{ j2g_header uint64; F_b__794000213, F_old any; F_size__1927001038__auto__ int32; F_ctx, F_kept_names, F_c__1927001037__auto__ any }

var A_arbace_go_repl_define_BANG__iter__794000210__794000214_fn__794000215_fn__794000216_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000220__794000224_A struct{ j2g_header uint64; F_old, F_decls any }

var A_arbace_go_repl_define_BANG__iter__794000220__794000224_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_A struct{ j2g_header uint64; F_old, F_iter__794000220, F_decls, F_s__794000221 any }

var A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000226_A struct{ j2g_header uint64; F_b__794000223, F_old any; F_size__1927001038__auto__ int32; F_decls, F_c__1927001037__auto__ any }

var A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000226_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000226_fn__794000227_A struct{ j2g_header uint64; F_x any }

var A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000226_fn__794000227_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000230_A struct{ j2g_header uint64; F_x any }

var A_arbace_go_repl_define_BANG__iter__794000220__794000224_fn__794000225_fn__794000230_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000234__794000240_A struct{ j2g_header uint64 }

var A_arbace_go_repl_define_BANG__iter__794000234__794000240_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_A struct{ j2g_header uint64; F_s__794000235, F_iter__794000234 any }

var A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_A struct{ j2g_header uint64 }

var A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_fn__794000243_A struct{ j2g_header uint64; F_s__794000237, F_iter__794000236 any }

var A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_fn__794000243_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_fn__794000243_fn__794000244_A struct{ j2g_header uint64; F_b__794000239 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_repl_define_BANG__iter__794000234__794000240_fn__794000241_iter__794000236__794000242_fn__794000243_fn__794000244_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000250__794000254_A struct{ j2g_header uint64; F_new_vars, F_old, F_ctx any }

var A_arbace_go_repl_define_BANG__iter__794000250__794000254_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000250__794000254_fn__794000255_A struct{ j2g_header uint64; F_new_vars, F_iter__794000250, F_old, F_s__794000251, F_ctx any }

var A_arbace_go_repl_define_BANG__iter__794000250__794000254_fn__794000255_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000250__794000254_fn__794000255_fn__794000256_A struct{ j2g_header uint64; F_b__794000253, F_new_vars, F_old any; F_size__1927001038__auto__ int32; F_ctx, F_c__1927001037__auto__ any }

var A_arbace_go_repl_define_BANG__iter__794000250__794000254_fn__794000255_fn__794000256_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000294__794000298_A struct{ j2g_header uint64 }

var A_arbace_go_repl_define_BANG__iter__794000294__794000298_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000294__794000298_fn__794000299_A struct{ j2g_header uint64; F_iter__794000294, F_s__794000295 any }

var A_arbace_go_repl_define_BANG__iter__794000294__794000298_fn__794000299_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000294__794000298_fn__794000299_fn__794000300_A struct{ j2g_header uint64; F_b__794000297 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_repl_define_BANG__iter__794000294__794000298_fn__794000299_fn__794000300_A_fn_class *jrt.Class



type A_arbace_go_repl_digest_forms_A struct{ j2g_header uint64 }

var A_arbace_go_repl_digest_forms_A_fn_class *jrt.Class



type A_arbace_go_repl_error_text_A struct{ j2g_header uint64 }

var A_arbace_go_repl_error_text_A_fn_class *jrt.Class



type A_arbace_go_repl_error_text_iter__794000124__794000128_A struct{ j2g_header uint64; F_src any }

var A_arbace_go_repl_error_text_iter__794000124__794000128_A_fn_class *jrt.Class



type A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_A struct{ j2g_header uint64; F_s__794000125, F_src, F_iter__794000124 any }

var A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_A_fn_class *jrt.Class



type A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_fn__794000130_A struct{ j2g_header uint64; F_src, F_b__794000127 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_fn__794000130_A_fn_class *jrt.Class



type A_arbace_go_repl_eval794000004_A struct{ jrt.Object }

func A_arbace_go_repl_eval794000004_A_New() *A_arbace_go_repl_eval794000004_A { t := &A_arbace_go_repl_eval794000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_repl_eval794000004_A) Ctor() {}

func (t *A_arbace_go_repl_eval794000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_repl_eval794000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_repl_eval794000004_A_class }

func (t *A_arbace_go_repl_eval794000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_repl_eval794000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_repl_eval794000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_repl_eval794000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_repl_eval794000004_A); return ok }

func A_arbace_go_repl_eval794000004_A_Cast(x any) *A_arbace_go_repl_eval794000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_repl_eval794000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_repl_eval794000004_A_class)) }; return v }



type A_arbace_go_repl_eval794000004_loading__1927001464__auto____794000005_A struct{ j2g_header uint64 }

var A_arbace_go_repl_eval794000004_loading__1927001464__auto____794000005_A_fn_class *jrt.Class



type A_arbace_go_repl_eval794000008_A struct{ jrt.Object }

func A_arbace_go_repl_eval794000008_A_New() *A_arbace_go_repl_eval794000008_A { t := &A_arbace_go_repl_eval794000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_repl_eval794000008_A) Ctor() {}

func (t *A_arbace_go_repl_eval794000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_repl_eval794000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_repl_eval794000008_A_class }

func (t *A_arbace_go_repl_eval794000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_repl_eval794000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_repl_eval794000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_repl_eval794000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_repl_eval794000008_A); return ok }

func A_arbace_go_repl_eval794000008_A_Cast(x any) *A_arbace_go_repl_eval794000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_repl_eval794000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_repl_eval794000008_A_class)) }; return v }



type A_arbace_go_repl_eval794000008_fn__794000009_A struct{ j2g_header uint64 }

var A_arbace_go_repl_eval794000008_fn__794000009_A_fn_class *jrt.Class



type A_arbace_go_repl_eval_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_repl_eval_BANG__A_fn_class *jrt.Class



type A_arbace_go_repl_eval_BANG__attempt__794000446_A struct{ j2g_header uint64; F_stmts, F_nm, F_st any }

var A_arbace_go_repl_eval_BANG__attempt__794000446_A_fn_class *jrt.Class



type A_arbace_go_repl_eval_BANG__attempt__794000446_fn__794000447_A struct{ j2g_header uint64; F_form, F_old any }

var A_arbace_go_repl_eval_BANG__attempt__794000446_fn__794000447_A_fn_class *jrt.Class



type A_arbace_go_repl_eval_BANG__attempt__794000446_fn__794000449_A struct{ j2g_header uint64; F_old any }

var A_arbace_go_repl_eval_BANG__attempt__794000446_fn__794000449_A_fn_class *jrt.Class



type A_arbace_go_repl_eval_BANG__fn__794000444_A struct{ j2g_header uint64; F_stmts any }

var A_arbace_go_repl_eval_BANG__fn__794000444_A_fn_class *jrt.Class



type A_arbace_go_repl_eval_BANG__fn__794000452_A struct{ j2g_header uint64 }

var A_arbace_go_repl_eval_BANG__fn__794000452_A_fn_class *jrt.Class



type A_arbace_go_repl_eval_BANG__fn__794000454_A struct{ j2g_header uint64 }

var A_arbace_go_repl_eval_BANG__fn__794000454_A_fn_class *jrt.Class



type A_arbace_go_repl_eval_BANG__fn__794000459_A struct{ j2g_header uint64 }

var A_arbace_go_repl_eval_BANG__fn__794000459_A_fn_class *jrt.Class



type A_arbace_go_repl_eval_BANG__fn__794000461_A struct{ j2g_header uint64; F_form, F_old any }

var A_arbace_go_repl_eval_BANG__fn__794000461_A_fn_class *jrt.Class



type A_arbace_go_repl_eval_BANG__fn__794000465_A struct{ j2g_header uint64; F_obj any }

var A_arbace_go_repl_eval_BANG__fn__794000465_A_fn_class *jrt.Class



type A_arbace_go_repl_file_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_repl_file_BANG__A_fn_class *jrt.Class



type A_arbace_go_repl_file_BANG__fn__794000053_A struct{ j2g_header uint64; F_opts, F_st any }

var A_arbace_go_repl_file_BANG__fn__794000053_A_fn_class *jrt.Class



type A_arbace_go_repl_file_entry_A struct{ j2g_header uint64 }

var A_arbace_go_repl_file_entry_A_fn_class *jrt.Class



type A_arbace_go_repl_file_entry_fn__794000040_A struct{ j2g_header uint64; F_fname any }

var A_arbace_go_repl_file_entry_fn__794000040_A_fn_class *jrt.Class



type A_arbace_go_repl_fn__794000012_A struct{ j2g_header uint64 }

var A_arbace_go_repl_fn__794000012_A_fn_class *jrt.Class



type A_arbace_go_repl_fn__794000015_A struct{ j2g_header uint64 }

var A_arbace_go_repl_fn__794000015_A_fn_class *jrt.Class



type A_arbace_go_repl_fn__794000024_A struct{ j2g_header uint64 }

var A_arbace_go_repl_fn__794000024_A_fn_class *jrt.Class



type A_arbace_go_repl_fn__794000024_fn__794000025_A struct{ j2g_header uint64 }

var A_arbace_go_repl_fn__794000024_fn__794000025_A_fn_class *jrt.Class



type A_arbace_go_repl_fn__794000028_A struct{ j2g_header uint64 }

var A_arbace_go_repl_fn__794000028_A_fn_class *jrt.Class



type A_arbace_go_repl_fn__794000028_fn__794000029_A struct{ j2g_header uint64 }

var A_arbace_go_repl_fn__794000028_fn__794000029_A_fn_class *jrt.Class



type A_arbace_go_repl_import_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_repl_import_BANG__A_fn_class *jrt.Class



type A_arbace_go_repl_import_BANG__fn__794000057_A struct{ j2g_header uint64; F_specs any }

var A_arbace_go_repl_import_BANG__fn__794000057_A_fn_class *jrt.Class



type A_arbace_go_repl_import_BANG__fn__794000057_fn__794000058_A struct{ j2g_header uint64; F_specs any }

var A_arbace_go_repl_import_BANG__fn__794000057_fn__794000058_A_fn_class *jrt.Class



type A_arbace_go_repl_listed_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_repl_listed_QMARK__A_fn_class *jrt.Class



type A_arbace_go_repl_load_import_A struct{ j2g_header uint64 }

var A_arbace_go_repl_load_import_A_fn_class *jrt.Class



type A_arbace_go_repl_load_import_fn__794000378_A struct{ j2g_header uint64; F_ns_sym any }

var A_arbace_go_repl_load_import_fn__794000378_A_fn_class *jrt.Class



type A_arbace_go_repl_new_state_A struct{ j2g_header uint64 }

var A_arbace_go_repl_new_state_A_fn_class *jrt.Class



type A_arbace_go_repl_ns__GT_path_A struct{ j2g_header uint64 }

var A_arbace_go_repl_ns__GT_path_A_fn_class *jrt.Class



type A_arbace_go_repl_package_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_repl_package_BANG__A_fn_class *jrt.Class



type A_arbace_go_repl_package_state_A struct{ j2g_header uint64 }

var A_arbace_go_repl_package_state_A_fn_class *jrt.Class



type A_arbace_go_repl_path__GT_ns_A struct{ j2g_header uint64 }

var A_arbace_go_repl_path__GT_ns_A_fn_class *jrt.Class



type A_arbace_go_repl_repl_source_A struct{ j2g_header uint64 }

var A_arbace_go_repl_repl_source_A_fn_class *jrt.Class



type A_arbace_go_repl_run_main_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_repl_run_main_BANG__A_fn_class *jrt.Class



type A_arbace_go_repl_session_for_A struct{ j2g_header uint64 }

var A_arbace_go_repl_session_for_A_fn_class *jrt.Class



type A_arbace_go_repl_session_for_fn__794000147_A struct{ j2g_header uint64; F_extra_src any }

var A_arbace_go_repl_session_for_fn__794000147_A_fn_class *jrt.Class



type A_arbace_go_repl_session_for_fn__794000149_A struct{ j2g_header uint64 }

var A_arbace_go_repl_session_for_fn__794000149_A_fn_class *jrt.Class



type A_arbace_go_repl_source_of_A struct{ j2g_header uint64 }

var A_arbace_go_repl_source_of_A_fn_class *jrt.Class



type A_arbace_go_repl_source_of_iter__794000136__794000140_A struct{ j2g_header uint64 }

var A_arbace_go_repl_source_of_iter__794000136__794000140_A_fn_class *jrt.Class



type A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_A struct{ j2g_header uint64; F_s__794000137, F_iter__794000136 any }

var A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_A_fn_class *jrt.Class



type A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_fn__794000142_A struct{ j2g_header uint64; F_b__794000139 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_fn__794000142_A_fn_class *jrt.Class



type A_arbace_go_repl_state_of_path_A struct{ j2g_header uint64 }

var A_arbace_go_repl_state_of_path_A_fn_class *jrt.Class



type A_arbace_go_repl_type_key_A struct{ j2g_header uint64 }

var A_arbace_go_repl_type_key_A_fn_class *jrt.Class



type A_arbace_go_repl_type_key_fn__794000159_A struct{ j2g_header uint64; F_gen_of any }

var A_arbace_go_repl_type_key_fn__794000159_A_fn_class *jrt.Class



type A_arbace_go_repl_type_key_fn__794000161_A struct{ j2g_header uint64; F_gen_of any }

var A_arbace_go_repl_type_key_fn__794000161_A_fn_class *jrt.Class



type A_arbace_go_repl_type_key_fn__794000163_A struct{ j2g_header uint64; F_gen_of any }

var A_arbace_go_repl_type_key_fn__794000163_A_fn_class *jrt.Class



type A_arbace_go_repl_type_key_fn__794000165_A struct{ j2g_header uint64; F_gen_of any }

var A_arbace_go_repl_type_key_fn__794000165_A_fn_class *jrt.Class



type A_arbace_go_repl_type_key_fn__794000167_A struct{ j2g_header uint64; F_gen_of any }

var A_arbace_go_repl_type_key_fn__794000167_A_fn_class *jrt.Class



type A_arbace_go_repl_update_file_A struct{ j2g_header uint64 }

var A_arbace_go_repl_update_file_A_fn_class *jrt.Class



type A_arbace_go_repl_update_file_fn__794000045_A struct{ j2g_header uint64; F_f, F_fname any }

var A_arbace_go_repl_update_file_fn__794000045_A_fn_class *jrt.Class



type A_arbace_go_repl_update_file_fn__794000045_fn__794000046_A struct{ j2g_header uint64; F_fname any }

var A_arbace_go_repl_update_file_fn__794000045_fn__794000046_A_fn_class *jrt.Class



type A_arbace_go_repl_update_file_fn__794000045_fn__794000048_A struct{ j2g_header uint64; F_f, F_fname any }

var A_arbace_go_repl_update_file_fn__794000045_fn__794000048_A_fn_class *jrt.Class
