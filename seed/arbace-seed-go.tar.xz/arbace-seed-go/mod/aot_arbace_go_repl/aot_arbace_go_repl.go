//line aot_arbace_go_repl.ae:1
package aot_arbace_go_repl

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_build"
	"arbace/aot_arbace_go_check"
	"arbace/aot_arbace_go_check_code"
	"arbace/aot_arbace_go_check_const"
	"arbace/aot_arbace_go_check_env"
	"arbace/aot_arbace_go_check_load"
	"arbace/aot_arbace_go_check_types"
	"arbace/aot_arbace_repr_go_print"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_repl_eval794000004_loading__1927001464__auto____794000005_A_New() *A_arbace_go_repl_eval794000004_loading__1927001464__auto____794000005_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_eval794000004_loading__1927001464__auto____794000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_repl_eval794000004_loading__1927001464__auto____794000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_repl_eval794000004_loading__1927001464__auto____794000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_repl_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_repl_A_const_1); lang.IFn_Cast(A_arbace_go_repl_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O__O(A_arbace_go_repl_A_const_3, A_arbace_go_repl_A_const_4, A_arbace_go_repl_A_const_5, A_arbace_go_repl_A_const_6, A_arbace_go_repl_A_const_7, A_arbace_go_repl_A_const_8, A_arbace_go_repl_A_const_9, A_arbace_go_repl_A_const_10, A_arbace_go_repl_A_const_11); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_131)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_132)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_133)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_134)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_135)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_136)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_repl_eval794000008_fn__794000009_A_New() *A_arbace_go_repl_eval794000008_fn__794000009_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_eval794000008_fn__794000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_repl_eval794000008_fn__794000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_repl_eval794000008_fn__794000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_12.GetRawRoot__O()); var tmp2 any; var root_23 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_25 lang.IFn; if linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = A_arbace_go_repl_A_const_14; if linked_24 == nil { tmp2 = ifn_25.Invoke_O__O(arg_26) } else { tmp2 = linked_24.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_23, arg_26) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_repl_A_const_15.GetRawRoot__O(), A_arbace_go_repl_A_const_16) }
























func A_arbace_go_repl_fn__794000012_A_New() *A_arbace_go_repl_fn__794000012_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_fn__794000012_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_go_repl_fn__794000012_A) Ctor() {}
//line :26:1
func (t *A_arbace_go_repl_fn__794000012_A) Invoke_O__O(self any) any { var root_27 any = A_arbace_go_repl_A_const_17.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = lang.GoInterp_Paths__O1().Ref(); if linked_28 == nil { return ifn_29.Invoke_O__O(arg_30) } else { return linked_28.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_27, arg_30) } }

func A_arbace_go_repl_listed_QMARK__A_New() *A_arbace_go_repl_listed_QMARK__A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_listed_QMARK__A{}; t.Ctor(); return t }
//line :28:1
func (t *A_arbace_go_repl_listed_QMARK__A) Ctor() {}
//line :28:1
func (t *A_arbace_go_repl_listed_QMARK__A) Invoke_O_O__O(self, p__0 any) any {


	var root_31 any = A_arbace_go_repl_A_const_18.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any; var root_36 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = A_arbace_go_repl_A_const_19.GetRawRoot__O(); if linked_37 == nil { arg_34 = ifn_38.Invoke_O__O(arg_39) } else { arg_34 = linked_37.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_36, arg_39) }; var arg_35 any = p__0; if linked_32 == nil { return ifn_33.Invoke_O_O__O(arg_34, arg_35) } else { return linked_32.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_31, arg_34, arg_35)
	}
}
func A_arbace_go_repl_fn__794000015_A_New() *A_arbace_go_repl_fn__794000015_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_fn__794000015_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_go_repl_fn__794000015_A) Ctor() {}
//line :34:1
func (t *A_arbace_go_repl_fn__794000015_A) Invoke_O__O(self any) any { var temp__1927000414__auto____1 any = lang.GoInterp_Digest__String().Ref(); if
									jrt.J2g_Truth(temp__1927000414__auto____1) { var s__2 any = temp__1927000414__auto____1; var nl__3 int32 = jrt.NN(jrt.String_Cast(s__2)).IndexOf_String__I(Lit_124); var tmp1 any = A_arbace_go_repl_A_const_20; var tmp2 any; var root_40 any = A_arbace_go_repl_A_const_21.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_42 lang.IFn

		if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any; var root_44 any = A_arbace_go_repl_A_const_22.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_44, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_46 lang.IFn; if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any = s__2; var arg_48 any = A_arbace_go_repl_A_const_23; var arg_49 any = jrt.Integer_ValueOf_I__Integer_NoInit(nl__3).Ref(); if linked_45 == nil { arg_43 = ifn_46.Invoke_O_O_O__O(arg_47, arg_48, arg_49) } else { arg_43 = linked_45.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_44, arg_47, arg_48, arg_49) }; if linked_41 == nil { tmp2 = ifn_42.Invoke_O__O(arg_43) } else { tmp2 = linked_41.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_40, arg_43) }
//line :35:1
		var tmp3 any = tmp2; var tmp4 any = A_arbace_go_repl_A_const_24; var tmp5 any = A_arbace_go_repl_A_const_25; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, tmp4, s__2, tmp5, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(nl__3))).Ref())) } else { return nil } }



func A_arbace_go_repl_digest_forms_A_New() *A_arbace_go_repl_digest_forms_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_digest_forms_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_go_repl_digest_forms_A) Ctor() {}
//line :39:1
func (t *A_arbace_go_repl_digest_forms_A) Invoke_O_O__O(self, p__0 any) any { var temp__1927000414__auto____2 any; var root_50 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_52 lang.IFn; if


	linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = A_arbace_go_repl_A_const_26.GetRawRoot__O(); if linked_51 == nil { temp__1927000414__auto____2 = ifn_52.Invoke_O__O(arg_53) } else { temp__1927000414__auto____2 = linked_51.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_50, arg_53) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var map__794000017__3 any = temp__1927000414__auto____2; var map__794000017__4 any; if lang.ISeq_InstanceOf(map__794000017__3) { var tmp1 any; var root_54 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = map__794000017__3; if linked_55 == nil { tmp1 = ifn_56.Invoke_O__O(arg_57) } else { tmp1 = linked_55.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_54, arg_57) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_58 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = map__794000017__3; if linked_59 == nil { tmp2 = ifn_60.Invoke_O__O(arg_61) } else { tmp2 = linked_59.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_58, arg_61) }; map__794000017__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_62 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_64 lang.IFn; if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any = map__794000017__3; if linked_63 == nil { tmp3 = ifn_64.Invoke_O__O(arg_65) } else { tmp3 = linked_63.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_62, arg_65) }; if jrt.J2g_Truth(tmp3) { var root_66 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = map__794000017__3; if linked_67 == nil { map__794000017__4 = ifn_68.Invoke_O__O(arg_69) } else { map__794000017__4 = linked_67.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_66, arg_69) } } else { map__794000017__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000017__4 = map__794000017__3 }; var index__5 any = lang.RT_Get_O_O__O_NoInit(map__794000017__4, A_arbace_go_repl_A_const_20); var text__6 any = lang.RT_Get_O_O__O_NoInit(map__794000017__4, A_arbace_go_repl_A_const_24); var start__7 any = lang.RT_Get_O_O__O_NoInit(map__794000017__4, A_arbace_go_repl_A_const_25); var temp__1927000414__auto____8 any = lang.RT_Get_O_O__O_NoInit(index__5, p__0)
		if jrt.J2g_Truth(temp__1927000414__auto____8) { var vec__794000019__9 any = temp__1927000414__auto____8; var a__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000019__9, lang.RT_IntCast_J__I_NoInit(0), nil); var b__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000019__9, lang.RT_IntCast_J__I_NoInit(1), nil); var root_70 any = A_arbace_go_repl_A_const_31.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_go_check.A_arbace_go_check_read_string_forms_A_fn_class); var ifn_72 lang.IFn
			if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any; var root_74 any = A_arbace_go_repl_A_const_22.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_76 lang.IFn; if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any = text__6; var arg_78 any; var na_80 any = start__7; var na_81 any = a__10; var tmp4 bool; var tmp5 bool; tmp5 = jrt.Long_InstanceOf(na_80); if tmp5 { tmp5 = jrt.Long_InstanceOf(na_81) }; tmp4 = tmp5; if tmp4 { var n0_82 int64 = jrt.NN(jrt.Long_Cast(na_80)).LongValue__J(); var n1_83 int64 = jrt.NN(jrt.Long_Cast(na_81)).LongValue__J(); var nr_84 int64 = n0_82 + n1_83; if (n0_82^nr_84)&(n1_83^nr_84) >= 0 { arg_78 = jrt.Long_ValueOf_J__Long_NoInit(nr_84).Ref() } else { arg_78 = lang.Numbers_Add_O_O__Number_NoInit(na_80, na_81) } } else { var tmp6 bool; var tmp7 bool; tmp7 = jrt.Double_InstanceOf(na_80); if tmp7 { tmp7 = jrt.Double_InstanceOf(na_81) }; tmp6 = tmp7; if tmp6 { var n0_82_2 float64 = jrt.NN(jrt.Double_Cast(na_80)).DoubleValue__D(); var n1_83_2 float64 = jrt.NN(jrt.Double_Cast(na_81)).DoubleValue__D(); arg_78 = jrt.Double_ValueOf_D__Double_NoInit(n0_82_2 + n1_83_2).Ref() } else { arg_78 = lang.Numbers_Add_O_O__Number_NoInit(na_80, na_81) } }; var arg_79 any; var na_85 any = start__7; var na_86 any = b__11; var tmp8 bool; var tmp9 bool; tmp9 = jrt.Long_InstanceOf(na_85); if tmp9 { tmp9 = jrt.Long_InstanceOf(na_86) }; tmp8 = tmp9; if tmp8 { var n0_87 int64 = jrt.NN(jrt.Long_Cast(na_85)).LongValue__J(); var n1_88 int64 = jrt.NN(jrt.Long_Cast(na_86)).LongValue__J(); var nr_89 int64 = n0_87 + n1_88; if (n0_87^nr_89)&(n1_88^nr_89) >= 0 { arg_79 = jrt.Long_ValueOf_J__Long_NoInit(nr_89).Ref() } else { arg_79 = lang.Numbers_Add_O_O__Number_NoInit(na_85, na_86) } } else { var tmp10 bool; var tmp11 bool; tmp11 = jrt.Double_InstanceOf(na_85); if tmp11 { tmp11 = jrt.Double_InstanceOf(na_86) }; tmp10 = tmp11; if tmp10 { var n0_87_2 float64 = jrt.NN(jrt.Double_Cast(na_85)).DoubleValue__D(); var n1_88_2 float64 = jrt.NN(jrt.Double_Cast(na_86)).DoubleValue__D(); arg_79 = jrt.Double_ValueOf_D__Double_NoInit(n0_87_2 + n1_88_2).Ref() } else { arg_79 = lang.Numbers_Add_O_O__Number_NoInit(na_85, na_86) } }; if linked_75 == nil { arg_73 = ifn_76.Invoke_O_O_O__O(arg_77, arg_78, arg_79) } else { arg_73 = linked_75.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_74, arg_77, arg_78, arg_79) }; if linked_71 == nil { return ifn_72.Invoke_O__O(arg_73) } else { return linked_71.(*aot_arbace_go_check.A_arbace_go_check_read_string_forms_A).Invoke_O_O__O(root_70, arg_73) } } else {
//line :43:1
				return nil } } else {
//line :42:1
					return nil } }





func A_arbace_go_repl_fn__794000024_A_New() *A_arbace_go_repl_fn__794000024_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_fn__794000024_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_go_repl_fn__794000024_A) Ctor() {}
//line :48:1
func (t *A_arbace_go_repl_fn__794000024_A) Invoke_O__O(self any) any { var fs__1 any; var root_90 any = A_arbace_go_repl_A_const_32.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, A_arbace_go_repl_digest_forms_A_fn_class); var ifn_92 lang.IFn; if
									linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = Lit_152; if linked_91 == nil { fs__1 = ifn_92.Invoke_O__O(arg_93) } else { fs__1 = linked_91.(*A_arbace_go_repl_digest_forms_A).Invoke_O_O__O(root_90, arg_93) }; var gp__2 any; var root_94 any = /*line :48:1*/A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_96 lang.IFn; if

	linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any; var root_98 any = A_arbace_go_repl_A_const_33.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any; var tmp1 any = A_arbace_go_repl_fn__794000024_fn__794000025_A_New(); var tmp2 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_go_repl_fn__794000024_fn__794000025_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_153, false); A_arbace_go_repl_fn__794000024_fn__794000025_A_fn_class = fncls__111d; tmp2 = fncls__111d } else { tmp2 = fncls__111 }; arg_101 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_102 any = fs__1; if linked_99 == nil { arg_97 = ifn_100.Invoke_O_O__O(arg_101, arg_102) } else { arg_97 = linked_99.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_98, arg_101, arg_102) }; if linked_95 == nil { gp__2 = ifn_96.Invoke_O__O(arg_97) } else { gp__2 = linked_95.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_94, arg_97) }; var cfg__3 any; var tmp3 /*line :48:1*/*lang.Keyword = A_arbace_go_repl_A_const_36; var tmp4 any; var root_112 any = A_arbace_go_repl_A_const_37.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_114 lang.IFn; if


	linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = A_arbace_go_repl_A_const_38.GetRawRoot__O(); var arg_116 any; var root_117 any = A_arbace_go_repl_A_const_39.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = gp__2; if linked_118 == nil { arg_116 = ifn_119.Invoke_O__O(arg_120) } else { arg_116 = linked_118.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_117, arg_120) }; if linked_113 == nil { tmp4 = ifn_114.Invoke_O_O__O(arg_115, arg_116) } else { tmp4 = linked_113.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_112, arg_115, arg_116) }; cfg__3 = tmp3.Invoke_O__O(tmp4); var root_121 any =
	A_arbace_go_repl_A_const_40.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_121, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = A_arbace_go_repl_A_const_41; var arg_125 any = cfg__3; if linked_122 == nil { return ifn_123.Invoke_O_O__O(arg_124, arg_125) } else { return linked_122.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_121, arg_124, arg_125) } }
//line :50:1
func A_arbace_go_repl_fn__794000024_fn__794000025_A_New() *A_arbace_go_repl_fn__794000024_fn__794000025_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_fn__794000024_fn__794000025_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_go_repl_fn__794000024_fn__794000025_A) Ctor() {}
//line :50:1
func (t *A_arbace_go_repl_fn__794000024_fn__794000025_A) Invoke_O_O__O(self, p1__794000023_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_103 any = A_arbace_go_repl_A_const_34.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = p1__794000023_SHARP___1; if linked_104 == nil { and__1927000168__auto____2 = ifn_105.Invoke_O__O(arg_106) } else { and__1927000168__auto____2 = linked_104.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_103, arg_106) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_repl_A_const_35; var tmp2 any; var root_107 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = p1__794000023_SHARP___1; if linked_108 == nil { tmp2 = ifn_109.Invoke_O__O(arg_110) } else { tmp2 = linked_108.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_107, arg_110) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() } else { return and__1927000168__auto____2 } }





func A_arbace_go_repl_fn__794000028_A_New() *A_arbace_go_repl_fn__794000028_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_fn__794000028_A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_go_repl_fn__794000028_A) Ctor() {}
//line :56:1
func (t *A_arbace_go_repl_fn__794000028_A) Invoke_O__O(self any) any {
	var root_126 any = A_arbace_go_repl_A_const_42.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, aot_arbace_go_check.A_arbace_go_check_session_A_fn_class); var ifn_128 lang.IFn; if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any; var tmp1 any = A_arbace_go_repl_fn__794000028_fn__794000029_A_New(); var tmp2 *jrt.Class; var fncls__147 *jrt.Class = A_arbace_go_repl_fn__794000028_fn__794000029_A_fn_class; if fncls__147 == nil { var fncls__147d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_154, false); A_arbace_go_repl_fn__794000028_fn__794000029_A_fn_class = fncls__147d; tmp2 = fncls__147d } else { tmp2 = fncls__147 }; arg_129 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_127 == nil { return ifn_128.Invoke_O__O(arg_129) } else { return linked_127.(*aot_arbace_go_check.A_arbace_go_check_session_A).Invoke_O_O__O(root_126, arg_129) } }
//line :57:1
func A_arbace_go_repl_fn__794000028_fn__794000029_A_New() *A_arbace_go_repl_fn__794000028_fn__794000029_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_fn__794000028_fn__794000029_A{}; t.Ctor(); return t }
//line :57:1
func (t *A_arbace_go_repl_fn__794000028_fn__794000029_A) Ctor() {}
//line :57:1
func (t *A_arbace_go_repl_fn__794000028_fn__794000029_A) Invoke_O_O_O__O(self, path__1, importer__2 any) any {
	var tmp1 any; var root_130 any = A_arbace_go_repl_A_const_43.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, A_arbace_go_repl_listed_QMARK__A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = path__1; if linked_131 == nil { tmp1 = ifn_132.Invoke_O__O(arg_133) } else { tmp1 = linked_131.(*A_arbace_go_repl_listed_QMARK__A).Invoke_O_O__O(root_130, arg_133) }; if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____3 any; var root_134 any = A_arbace_go_repl_A_const_32.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, A_arbace_go_repl_digest_forms_A_fn_class); var ifn_136 lang.IFn
		if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = path__1; if linked_135 == nil { temp__1927000414__auto____3 = ifn_136.Invoke_O__O(arg_137) } else { temp__1927000414__auto____3 = linked_135.(*A_arbace_go_repl_digest_forms_A).Invoke_O_O__O(root_134, arg_137) }; if jrt.J2g_Truth(temp__1927000414__auto____3) { var fs__4 any = temp__1927000414__auto____3; var root_138 any = A_arbace_go_repl_A_const_44.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_go_check.A_arbace_go_check_forms_source_A_fn_class); var ifn_140 lang.IFn
			if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = fs__4; var arg_142 any; var root_143 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_145 lang.IFn; if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = A_arbace_go_repl_A_const_45.GetRawRoot__O(); if linked_144 == nil { arg_142 = ifn_145.Invoke_O__O(arg_146) } else { arg_142 = linked_144.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_143, arg_146) }; if linked_139 == nil { return ifn_140.Invoke_O_O__O(arg_141, arg_142) } else { return linked_139.(*aot_arbace_go_check.A_arbace_go_check_forms_source_A).Invoke_O_O_O__O(root_138, arg_141, arg_142) } } else {
//line :59:1
				return nil } } else {
//line :58:1
					return nil
				}
}





func A_arbace_go_repl_path__GT_ns_A_New() *A_arbace_go_repl_path__GT_ns_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_path__GT_ns_A{}; t.Ctor(); return t }
//line :66:1
func (t *A_arbace_go_repl_path__GT_ns_A) Ctor() {}
//line :66:1
func (t *A_arbace_go_repl_path__GT_ns_A) Invoke_O_O__O(self, p__0 any) any {


	var root_148 any = A_arbace_go_repl_A_const_46.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any; var root_152 any = A_arbace_go_repl_A_const_47.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = p__0; if linked_153 == nil { arg_151 = ifn_154.Invoke_O__O(arg_155) } else { arg_151 = linked_153.(*aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A).Invoke_O_O__O(root_152, arg_155) }; if linked_149 == nil { return ifn_150.Invoke_O__O(arg_151) } else { return linked_149.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_148, arg_151)
	} }
func A_arbace_go_repl_ns__GT_path_A_New() *A_arbace_go_repl_ns__GT_path_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_ns__GT_path_A{}; t.Ctor(); return t }
//line :71:1
func (t *A_arbace_go_repl_ns__GT_path_A) Ctor() {}
//line :71:1
func (t *A_arbace_go_repl_ns__GT_path_A) Invoke_O_O__O(self, ns_name__0 any) any {


	var root_156 any = A_arbace_go_repl_A_const_48.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = Lit_1; var arg_160 any; var root_161 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_163 lang.IFn; if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any; var root_165 any = A_arbace_go_repl_A_const_50.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any; var root_170 any = A_arbace_go_repl_A_const_51.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_170, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = ns_name__0; if linked_171 == nil { arg_168 = ifn_172.Invoke_O__O(arg_173) } else { arg_168 = linked_171.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_170, arg_173) }; var arg_169 any = A_arbace_go_repl_A_const_52; if linked_166 == nil { arg_164 = ifn_167.Invoke_O_O__O(arg_168, arg_169) } else { arg_164 = linked_166.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_165, arg_168, arg_169) }; if linked_162 == nil { arg_160 = ifn_163.Invoke_O__O(arg_164) } else { arg_160 = linked_162.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_161, arg_164) }; if linked_157 == nil { return ifn_158.Invoke_O_O__O(arg_159, arg_160) } else { return linked_157.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_156, arg_159, arg_160)
	} }
func A_arbace_go_repl_new_state_A_New() *A_arbace_go_repl_new_state_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_new_state_A{}; t.Ctor(); return t }
//line :76:1
func (t *A_arbace_go_repl_new_state_A) Ctor() {}
//line :76:1
func (t *A_arbace_go_repl_new_state_A) Invoke_O_O_O_O__O(self, path__0, nm__1, ns_sym__2 any) any {
	var root_174 any = A_arbace_go_repl_A_const_53.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_174, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any; var tmp1 any = A_arbace_go_repl_A_const_54; var tmp2 any = A_arbace_go_repl_A_const_55; var tmp3 any = A_arbace_go_repl_A_const_56; var tmp4 any = A_arbace_go_repl_A_const_36; var tmp5 any; var root_178 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = A_arbace_go_repl_A_const_45.GetRawRoot__O(); if linked_179 == nil { tmp5 = ifn_180.Invoke_O__O(arg_181) } else { tmp5 = linked_179.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_178, arg_181) }; arg_177 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, path__0, tmp2, nm__1, tmp3, ns_sym__2, tmp4, tmp5, A_arbace_go_repl_A_const_57, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_repl_A_const_58, Lit_130, A_arbace_go_repl_A_const_59, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_repl_A_const_60, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_repl_A_const_61, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_repl_A_const_62, lang.PersistentHashSet_EMPTY.Ref())); if linked_175 == nil { return ifn_176.Invoke_O__O(arg_177) } else { return linked_175.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_174, arg_177)
	}
}
func A_arbace_go_repl_package_state_A_New() *A_arbace_go_repl_package_state_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_package_state_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_go_repl_package_state_A) Ctor() {}
//line :80:1
func (t *A_arbace_go_repl_package_state_A) Invoke_O_O_O__O(self, ns_sym__0, create_QMARK___1 any) any { var s__3 any; var root_182 any = A_arbace_go_repl_A_const_51.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_184 lang.IFn; if



	linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = ns_sym__0; if linked_183 == nil { s__3 = ifn_184.Invoke_O__O(arg_185) } else { s__3 = linked_183.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_182, arg_185) }; var tmp1 any; var root_209 any =
	A_arbace_go_repl_A_const_68.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = s__3; var arg_213 any = Lit_137; if linked_210 == nil { tmp1 = ifn_211.Invoke_O_O__O(arg_212, arg_213) } else { tmp1 = linked_210.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_209, arg_212, arg_213) }; if jrt.J2g_Truth(tmp1) { } else { var tmp2 any; var root_214 any = A_arbace_go_repl_A_const_69.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_216 lang.IFn
		if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_161, nil, Lit_162), jrt.RefArrayOf(jrt.Object_class, nil, s__3, nil)).Ref(); var arg_218 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_repl_A_const_56, ns_sym__0)); if linked_215 == nil { tmp2 = ifn_216.Invoke_O_O__O(arg_217, arg_218) } else { tmp2 = linked_215.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_214, arg_217, arg_218) }
//line :85:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) }; var path__4 any; var root_186 any = /*line :80:1*/A_arbace_go_repl_A_const_63.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, A_arbace_go_repl_ns__GT_path_A_fn_class); var ifn_188 lang.IFn; if






	linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = ns_sym__0; if linked_187 == nil { path__4 = ifn_188.Invoke_O__O(arg_189) } else { path__4 = linked_187.(*A_arbace_go_repl_ns__GT_path_A).Invoke_O_O__O(root_186, arg_189) }; var or__1927000174__auto____5 any; var tmp3 any; var root_190 any = /*line :80:1*/A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_192 lang.IFn; if







	linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = A_arbace_go_repl_A_const_64.GetRawRoot__O(); if linked_191 == nil { tmp3 = ifn_192.Invoke_O__O(arg_193) } else { tmp3 = linked_191.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_190, arg_193) }; or__1927000174__auto____5 = lang.RT_Get_O_O__O_NoInit(tmp3, path__4); if jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else {
		if jrt.J2g_Truth(create_QMARK___1) {
			var tmp4 any; var root_219 any = A_arbace_go_repl_A_const_43.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, A_arbace_go_repl_listed_QMARK__A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = path__4; if linked_220 == nil { tmp4 = ifn_221.Invoke_O__O(arg_222) } else { tmp4 = linked_220.(*A_arbace_go_repl_listed_QMARK__A).Invoke_O_O__O(root_219, arg_222) }; if jrt.J2g_Truth(tmp4) { var tmp5 any; var root_223 any = A_arbace_go_repl_A_const_69.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_225 lang.IFn
				if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_163, nil, Lit_164), jrt.RefArrayOf(jrt.Object_class, nil, path__4, nil)).Ref(); var arg_227 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_repl_A_const_54, path__4)); if linked_224 == nil { tmp5 = ifn_225.Invoke_O_O__O(arg_226, arg_227) } else { tmp5 = linked_224.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_223, arg_226, arg_227) }
//line :90:1
				panic(jrt.Thrown(jrt.Throwable_Cast(tmp5))) }
//line :89:1
			var st__6 any; var root_194 any = A_arbace_go_repl_A_const_65.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, A_arbace_go_repl_new_state_A_fn_class); var ifn_196 lang.IFn


			if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = path__4; var arg_198 any; var root_200 any = A_arbace_go_repl_A_const_66.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any; var root_204 any = A_arbace_go_repl_A_const_50.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = path__4; var arg_208 any = A_arbace_go_repl_A_const_67; if linked_205 == nil { arg_203 = ifn_206.Invoke_O_O__O(arg_207, arg_208) } else { arg_203 = linked_205.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_204, arg_207, arg_208) }; if linked_201 == nil { arg_198 = ifn_202.Invoke_O__O(arg_203) } else { arg_198 = linked_201.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_200, arg_203) }; var arg_199 any = ns_sym__0; if linked_195 == nil { st__6 = ifn_196.Invoke_O_O_O__O(arg_197, arg_198, arg_199) } else { st__6 = linked_195.(*A_arbace_go_repl_new_state_A).Invoke_O_O_O_O__O(root_194, arg_197, arg_198, arg_199) }
			var root_228 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_230 lang.IFn; if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = A_arbace_go_repl_A_const_64.GetRawRoot__O(); var arg_232 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_233 any = path__4; var arg_234 any = st__6; if linked_229 == nil { ifn_230.Invoke_O_O_O_O__O(arg_231, arg_232, arg_233, arg_234) } else { linked_229.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_228, arg_231, arg_232, arg_233, arg_234) }
//line :89:1
			return st__6 } else { return nil } } }
//line :80:1
func (t *A_arbace_go_repl_package_state_A) Invoke_O_O__O(self, ns_sym__0 any) any {

	var root_235 any = A_arbace_go_repl_A_const_72.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, A_arbace_go_repl_package_state_A_fn_class); var ifn_237 lang.IFn; if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any = ns_sym__0; var arg_239 any = jrt.Boolean_TRUE.Ref(); if linked_236 == nil { return ifn_237.Invoke_O_O__O(arg_238, arg_239) } else { return linked_236.(*A_arbace_go_repl_package_state_A).Invoke_O_O_O__O(root_235, arg_238, arg_239)
	}
}











func A_arbace_go_repl_package_BANG__A_New() *A_arbace_go_repl_package_BANG__A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_package_BANG__A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_go_repl_package_BANG__A) Ctor() {}
//line :96:1
func (t *A_arbace_go_repl_package_BANG__A) Invoke_O_O_O_O__O(self, ns_sym__0, nm__1, opts__2 any) any { var opts__4 any; var root_240 any = A_arbace_go_repl_A_const_37.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_242 lang.IFn; if


	linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = A_arbace_go_repl_A_const_38.GetRawRoot__O(); var arg_244 any = opts__2; if linked_241 == nil { opts__4 = ifn_242.Invoke_O_O__O(arg_243, arg_244) } else { opts__4 = linked_241.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_240, arg_243, arg_244) }; var path__5 any; var or__1927000174__auto____5 any = /*line :96:1*/A_arbace_go_repl_A_const_54.Invoke_O__O(opts__4); if



	jrt.J2g_Truth(or__1927000174__auto____5) { path__5 = or__1927000174__auto____5 } else { var root_245 any = A_arbace_go_repl_A_const_63.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, A_arbace_go_repl_ns__GT_path_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = ns_sym__0; if linked_246 == nil { path__5 = ifn_247.Invoke_O__O(arg_248) } else { path__5 = linked_246.(*A_arbace_go_repl_ns__GT_path_A).Invoke_O_O__O(root_245, arg_248) } }; var st__6 any; var or__1927000174__auto____6 any; var tmp1 any; var root_249 any = /*line :96:1*/A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_251 lang.IFn; if




	linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = A_arbace_go_repl_A_const_64.GetRawRoot__O(); if linked_250 == nil { tmp1 = ifn_251.Invoke_O__O(arg_252) } else { tmp1 = linked_250.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_249, arg_252) }; or__1927000174__auto____6 = lang.RT_Get_O_O__O_NoInit(tmp1, path__5); if jrt.J2g_Truth(or__1927000174__auto____6) { st__6 = or__1927000174__auto____6 } else { var st__7 any; var root_253 any = A_arbace_go_repl_A_const_65.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, A_arbace_go_repl_new_state_A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = path__5; var arg_257 any; var root_259 any = A_arbace_go_repl_A_const_51.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_259, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_261 lang.IFn; if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var arg_262 any = nm__1; if linked_260 == nil { arg_257 = ifn_261.Invoke_O__O(arg_262) } else { arg_257 = linked_260.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_259, arg_262) }; var arg_258 any = ns_sym__0; if linked_254 == nil { st__7 = ifn_255.Invoke_O_O_O__O(arg_256, arg_257, arg_258) } else { st__7 = linked_254.(*A_arbace_go_repl_new_state_A).Invoke_O_O_O_O__O(root_253, arg_256, arg_257, arg_258) }; var root_263 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_263, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_265 lang.IFn; if linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var arg_266 any = A_arbace_go_repl_A_const_64.GetRawRoot__O(); var arg_267 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_268 any = path__5; var arg_269 any = st__7; if linked_264 == nil { ifn_265.Invoke_O_O_O_O__O(arg_266, arg_267, arg_268, arg_269) } else { linked_264.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_263, arg_266, arg_267, arg_268, arg_269) }; st__6 = st__7 }; var tmp2 lang.IFn =
	lang.IFn_Cast(A_arbace_go_repl_A_const_70.GetRawRoot__O()); var tmp3 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var tmp4 any = A_arbace_go_repl_A_const_55; var tmp5 any; var root_285 any = A_arbace_go_repl_A_const_73.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_287 lang.IFn; if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = nm__1; if linked_286 == nil { tmp5 = ifn_287.Invoke_O__O(arg_288) } else { tmp5 = linked_286.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_285, arg_288) }; var tmp6 any = tmp5; var tmp7 any = A_arbace_go_repl_A_const_56; var tmp8 any = A_arbace_go_repl_A_const_74; var tmp9 any = A_arbace_go_repl_A_const_75; var tmp10 any = A_arbace_go_repl_A_const_36; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_40.GetRawRoot__O()); var tmp12 any; var root_295 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_297 lang.IFn; if
	linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = A_arbace_go_repl_A_const_45.GetRawRoot__O(); if linked_296 == nil { tmp12 = ifn_297.Invoke_O__O(arg_298) } else { tmp12 = linked_296.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_295, arg_298) }; var tmp13 any = tmp12; var tmp14 any = /*line :102:1*/A_arbace_go_repl_A_const_36.Invoke_O__O(opts__4); var tmp15 lang.IPersistentMap; if
	jrt.J2g_Truth(A_arbace_go_repl_A_const_76.Invoke_O__O(opts__4)) { var tmp16 any = A_arbace_go_repl_A_const_76; tmp15 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, A_arbace_go_repl_A_const_76.Invoke_O__O(opts__4))) } else { tmp15 = nil }; /*line :102:1*/tmp2.Invoke_O_O_O_O_O_O_O_O_O_O_O_O__O(st__6, tmp3, tmp4, tmp6, tmp7, ns_sym__0, tmp8, opts__4, tmp9, path__5, tmp10, tmp11.Invoke_O_O_O__O(tmp13, tmp14, tmp15)); if

	jrt.J2g_Truth(A_arbace_go_repl_A_const_57.Invoke_O__O(opts__4)) {

		lang.IFn_Cast(A_arbace_go_repl_A_const_70.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(st__6, A_arbace_go_repl_A_const_71.GetRawRoot__O(), A_arbace_go_repl_A_const_77, jrt.Boolean_TRUE.Ref(), A_arbace_go_repl_A_const_57, lang.PersistentVector_EMPTY.Ref()) }; return nil }


func A_arbace_go_repl_file_entry_A_New() *A_arbace_go_repl_file_entry_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_file_entry_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_go_repl_file_entry_A) Ctor() {}
//line :109:1
func (t *A_arbace_go_repl_file_entry_A) Invoke_O_O_O__O(self, st__0, fname__1 any) any {
	var root_308 any = A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any; var tmp1 any = A_arbace_go_repl_file_entry_fn__794000040_A_New_O(fname__1); var tmp2 *jrt.Class; var fncls__313 *jrt.Class = A_arbace_go_repl_file_entry_fn__794000040_A_fn_class; if fncls__313 == nil { var fncls__313d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_151, false); A_arbace_go_repl_file_entry_fn__794000040_A_fn_class = fncls__313d; tmp2 = fncls__313d } else { tmp2 = fncls__313 }; arg_311 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_312 any; var tmp3 *lang.Keyword = A_arbace_go_repl_A_const_57; var tmp4 any; var root_314 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_314, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_316 lang.IFn; if linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any = st__0; if linked_315 == nil { tmp4 = ifn_316.Invoke_O__O(arg_317) } else { tmp4 = linked_315.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_314, arg_317) }; arg_312 = tmp3.Invoke_O__O(tmp4); if linked_309 == nil { return ifn_310.Invoke_O_O__O(arg_311, arg_312) } else { return linked_309.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_308, arg_311, arg_312) } }
//line :110:1
func A_arbace_go_repl_file_entry_fn__794000040_A_New_O(p0 any) *A_arbace_go_repl_file_entry_fn__794000040_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_file_entry_fn__794000040_A{}; t.Ctor_O(p0); return t }
//line :110:1
func (t *A_arbace_go_repl_file_entry_fn__794000040_A) Ctor_O(c__fname any) { t.F_fname = c__fname }
//line :110:1
func (t *A_arbace_go_repl_file_entry_fn__794000040_A) Invoke_O_O__O(self, p1__794000039_SHARP___1 any) any { var tmp1 any = t.F_fname; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_repl_A_const_55.Invoke_O__O(p1__794000039_SHARP___1)) { return p1__794000039_SHARP___1 } else { return nil } }

func A_arbace_go_repl_update_file_A_New() *A_arbace_go_repl_update_file_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_update_file_A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_go_repl_update_file_A) Ctor() {}
//line :112:1
func (t *A_arbace_go_repl_update_file_A) Invoke_O_O_O_O__O(self, st__0, fname__1, f__2 any) any {
	var root_318 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_318, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any = st__0; var arg_322 any = A_arbace_go_repl_A_const_79.GetRawRoot__O(); var arg_323 any = A_arbace_go_repl_A_const_57; var arg_324 any; var tmp1 any = A_arbace_go_repl_update_file_fn__794000045_A_New_O_O(f__2, fname__1); var tmp2 *jrt.Class; var fncls__342 *jrt.Class = A_arbace_go_repl_update_file_fn__794000045_A_fn_class
	if fncls__342 == nil { var fncls__342d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_179, false); A_arbace_go_repl_update_file_fn__794000045_A_fn_class = fncls__342d; tmp2 = fncls__342d } else { tmp2 = fncls__342 }; arg_324 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :113:1
	if linked_319 == nil { return ifn_320.Invoke_O_O_O_O__O(arg_321, arg_322, arg_323, arg_324) } else { return linked_319.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_318, arg_321, arg_322, arg_323, arg_324) } }
func A_arbace_go_repl_update_file_fn__794000045_A_New_O_O(p0, p1 any) *A_arbace_go_repl_update_file_fn__794000045_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_update_file_fn__794000045_A{}; t.Ctor_O_O(p0, p1); return t }
//line :114:1
func (t *A_arbace_go_repl_update_file_fn__794000045_A) Ctor_O_O(c__f, c__fname any) { t.F_f = c__f; t.F_fname = c__fname }
//line :114:1
func (t *A_arbace_go_repl_update_file_fn__794000045_A) Invoke_O_O__O(self, fs__1 any) any {
	var tmp1 any; var root_325 any = A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any; var tmp2 any = A_arbace_go_repl_update_file_fn__794000045_fn__794000046_A_New_O(t.F_fname); var tmp3 *jrt.Class; var fncls__330 *jrt.Class = A_arbace_go_repl_update_file_fn__794000045_fn__794000046_A_fn_class; if fncls__330 == nil { var fncls__330d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_180, false); A_arbace_go_repl_update_file_fn__794000045_fn__794000046_A_fn_class = fncls__330d; tmp3 = fncls__330d } else { tmp3 = fncls__330 }; arg_328 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_329 any = fs__1; if linked_326 == nil { tmp1 = ifn_327.Invoke_O_O__O(arg_328, arg_329) } else { tmp1 = linked_326.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_325, arg_328, arg_329) }; if jrt.J2g_Truth(tmp1) {
		var root_331 any = A_arbace_go_repl_A_const_80.GetRawRoot__O(); var linked_332 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_331, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_333 lang.IFn; if linked_332 == nil { ifn_333 = lang.IFn_Cast(root_331) } else { ifn_333 = nil }; var arg_334 any; var tmp4 any = A_arbace_go_repl_update_file_fn__794000045_fn__794000048_A_New_O_O(t.F_f, t.F_fname); var tmp5 *jrt.Class; var fncls__336 *jrt.Class = A_arbace_go_repl_update_file_fn__794000045_fn__794000048_A_fn_class; if fncls__336 == nil { var fncls__336d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_181, false); A_arbace_go_repl_update_file_fn__794000045_fn__794000048_A_fn_class = fncls__336d; tmp5 = fncls__336d } else { tmp5 = fncls__336 }; arg_334 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_335 any = fs__1; if linked_332 == nil { return ifn_333.Invoke_O_O__O(arg_334, arg_335) } else { return linked_332.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_331, arg_334, arg_335) } } else {
			var root_337 any = A_arbace_go_repl_A_const_15.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_337, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = fs__1; var tmp6 lang.IFn = lang.IFn_Cast(t.F_f); var arg_341 any = tmp6.Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_repl_A_const_55, t.F_fname, A_arbace_go_repl_A_const_74, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_repl_A_const_81, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_repl_A_const_82, lang.PersistentVector_EMPTY.Ref()))); if linked_338 == nil { return ifn_339.Invoke_O_O__O(arg_340, arg_341) } else { return linked_338.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_337, arg_340, arg_341) } } }
//line :115:1
func A_arbace_go_repl_update_file_fn__794000045_fn__794000046_A_New_O(p0 any) *A_arbace_go_repl_update_file_fn__794000045_fn__794000046_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_update_file_fn__794000045_fn__794000046_A{}; t.Ctor_O(p0); return t }
//line :115:1
func (t *A_arbace_go_repl_update_file_fn__794000045_fn__794000046_A) Ctor_O(c__fname any) { t.F_fname = c__fname }
//line :115:1
func (t *A_arbace_go_repl_update_file_fn__794000045_fn__794000046_A) Invoke_O_O__O(self, p1__794000043_SHARP___1 any) any { var tmp1 any = t.F_fname; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_repl_A_const_55.Invoke_O__O(p1__794000043_SHARP___1))).Ref() }
func A_arbace_go_repl_update_file_fn__794000045_fn__794000048_A_New_O_O(p0, p1 any) *A_arbace_go_repl_update_file_fn__794000045_fn__794000048_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_update_file_fn__794000045_fn__794000048_A{}; t.Ctor_O_O(p0, p1); return t }
//line :116:1
func (t *A_arbace_go_repl_update_file_fn__794000045_fn__794000048_A) Ctor_O_O(c__f, c__fname any) { t.F_f = c__f; t.F_fname = c__fname }
//line :116:1
func (t *A_arbace_go_repl_update_file_fn__794000045_fn__794000048_A) Invoke_O_O__O(self, p1__794000044_SHARP___1 any) any { var tmp1 any = t.F_fname; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_repl_A_const_55.Invoke_O__O(p1__794000044_SHARP___1)) { return lang.IFn_Cast(t.F_f).Invoke_O__O(p1__794000044_SHARP___1) } else { return p1__794000044_SHARP___1 } }


func A_arbace_go_repl_file_BANG__A_New() *A_arbace_go_repl_file_BANG__A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_file_BANG__A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_go_repl_file_BANG__A) Ctor() {}
//line :119:1
func (t *A_arbace_go_repl_file_BANG__A) Invoke_O_O_O_O__O(self, ns_sym__0, fname__1, opts__2 any) any { var st__4 any; var root_343 any = A_arbace_go_repl_A_const_72.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, A_arbace_go_repl_package_state_A_fn_class); var ifn_345 lang.IFn; if


	linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = ns_sym__0; if linked_344 == nil { st__4 = ifn_345.Invoke_O__O(arg_346) } else { st__4 = linked_344.(*A_arbace_go_repl_package_state_A).Invoke_O_O__O(root_343, arg_346) }; var root_347 any =
	A_arbace_go_repl_A_const_83.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, A_arbace_go_repl_update_file_A_fn_class); var ifn_349 lang.IFn; if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any = st__4; var arg_351 any = fname__1; var arg_352 any; var tmp1 any = A_arbace_go_repl_file_BANG__fn__794000053_A_New_O_O(opts__2, st__4); var tmp2 *jrt.Class; var fncls__376 *jrt.Class = A_arbace_go_repl_file_BANG__fn__794000053_A_fn_class; if fncls__376 == nil { var fncls__376d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_150, false); A_arbace_go_repl_file_BANG__fn__794000053_A_fn_class = fncls__376d; tmp2 = fncls__376d } else { tmp2 = fncls__376 }; arg_352 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_348 == nil { ifn_349.Invoke_O_O_O__O(arg_350, arg_351, arg_352) } else { linked_348.(*A_arbace_go_repl_update_file_A).Invoke_O_O_O_O__O(root_347, arg_350, arg_351, arg_352) }; var root_377 any =

	A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_378 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_377, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_379 lang.IFn; if linked_378 == nil { ifn_379 = lang.IFn_Cast(root_377) } else { ifn_379 = nil }; var arg_380 any = st__4; var arg_381 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_382 any = A_arbace_go_repl_A_const_58; var arg_383 any = fname__1; if linked_378 == nil { ifn_379.Invoke_O_O_O_O__O(arg_380, arg_381, arg_382, arg_383) } else { linked_378.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_377, arg_380, arg_381, arg_382, arg_383) }; return nil }
//line :123:1
func A_arbace_go_repl_file_BANG__fn__794000053_A_New_O_O(p0, p1 any) *A_arbace_go_repl_file_BANG__fn__794000053_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_file_BANG__fn__794000053_A{}; t.Ctor_O_O(p0, p1); return t }
//line :123:1
func (t *A_arbace_go_repl_file_BANG__fn__794000053_A) Ctor_O_O(c__opts, c__st any) { t.F_opts = c__opts; t.F_st = c__st }
//line :123:1
func (t *A_arbace_go_repl_file_BANG__fn__794000053_A) Invoke_O_O__O(self, p1__794000052_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_71.GetRawRoot__O()); var tmp2 any = A_arbace_go_repl_A_const_74; var tmp3 any; var root_363 any = A_arbace_go_repl_A_const_84.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = t.F_opts; var arg_367 any = A_arbace_go_repl_A_const_85; if linked_364 == nil { tmp3 = ifn_365.Invoke_O_O__O(arg_366, arg_367) } else { tmp3 = linked_364.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_363, arg_366, arg_367) }; var tmp4 any = tmp3; var tmp5 any = A_arbace_go_repl_A_const_81; var tmp6 any; var root_368 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_368, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_370 lang.IFn; if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any = A_arbace_go_repl_A_const_81.Invoke_O__O(t.F_opts); if linked_369 == nil { tmp6 = ifn_370.Invoke_O__O(arg_371) } else { tmp6 = linked_369.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_368, arg_371) }; var tmp7 any = tmp6; var tmp8 any = A_arbace_go_repl_A_const_82; var tmp9 any; var tmp10 *lang.Keyword = A_arbace_go_repl_A_const_77; var tmp11 any; var root_372 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_374 lang.IFn; if
														linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any = t.F_st; if linked_373 == nil { tmp11 = ifn_374.Invoke_O__O(arg_375) } else { tmp11 = linked_373.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_372, arg_375) }; if jrt.J2g_Truth(tmp10.Invoke_O__O(tmp11)) { tmp9 = lang.PersistentVector_EMPTY.Ref() } else { tmp9 = A_arbace_go_repl_A_const_82.Invoke_O__O(p1__794000052_SHARP___1) }; return /*line :123:1*/ tmp1.Invoke_O_O_O_O_O_O_O__O(p1__794000052_SHARP___1, tmp2, tmp4, tmp5, tmp7, tmp8, tmp9) }




func A_arbace_go_repl_import_BANG__A_New() *A_arbace_go_repl_import_BANG__A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_import_BANG__A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_go_repl_import_BANG__A) Ctor() {}
//line :128:1
func (t *A_arbace_go_repl_import_BANG__A) Invoke_O_O_O__O(self, ns_sym__0, specs__1 any) any { var st__3 any; var root_384 any = A_arbace_go_repl_A_const_72.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, A_arbace_go_repl_package_state_A_fn_class); var ifn_386 lang.IFn; if


	linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any = ns_sym__0; if linked_385 == nil { st__3 = ifn_386.Invoke_O__O(arg_387) } else { st__3 = linked_385.(*A_arbace_go_repl_package_state_A).Invoke_O_O__O(root_384, arg_387) }; var tmp1 /*line :132:1*/*lang.Keyword = A_arbace_go_repl_A_const_77; var tmp2 any; var root_388 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_390 lang.IFn; if linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any = st__3; if linked_389 == nil { tmp2 = ifn_390.Invoke_O__O(arg_391) } else { tmp2 = linked_389.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_388, arg_391) }; if jrt.J2g_Truth(tmp1.Invoke_O__O(tmp2)) { var tmp3 any; var root_392 any = A_arbace_go_repl_A_const_69.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_394 lang.IFn
		if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = Lit_155; var arg_396 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_393 == nil { tmp3 = ifn_394.Invoke_O_O__O(arg_395, arg_396) } else { tmp3 = linked_393.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_392, arg_395, arg_396) }
//line :132:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp3))) }; var root_397 any =

	A_arbace_go_repl_A_const_83.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, A_arbace_go_repl_update_file_A_fn_class); var ifn_399 lang.IFn; if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = st__3; var arg_401 any; var tmp4 *lang.Keyword = A_arbace_go_repl_A_const_58; var tmp5 any; var root_403 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = st__3; if linked_404 == nil { tmp5 = ifn_405.Invoke_O__O(arg_406) } else { tmp5 = linked_404.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_403, arg_406) }; arg_401 = tmp4.Invoke_O__O(tmp5); var arg_402 any; var tmp6 any = A_arbace_go_repl_import_BANG__fn__794000057_A_New_O(specs__1); var tmp7 *jrt.Class; var fncls__427 *jrt.Class = A_arbace_go_repl_import_BANG__fn__794000057_A_fn_class; if fncls__427 == nil { var fncls__427d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_156, false); A_arbace_go_repl_import_BANG__fn__794000057_A_fn_class = fncls__427d; tmp7 = fncls__427d } else { tmp7 = fncls__427 }; arg_402 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_398 == nil { ifn_399.Invoke_O_O_O__O(arg_400, arg_401, arg_402) } else { linked_398.(*A_arbace_go_repl_update_file_A).Invoke_O_O_O_O__O(root_397, arg_400, arg_401, arg_402) }; return nil }
//line :134:1
func A_arbace_go_repl_import_BANG__fn__794000057_A_New_O(p0 any) *A_arbace_go_repl_import_BANG__fn__794000057_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_import_BANG__fn__794000057_A{}; t.Ctor_O(p0); return t }
//line :134:1
func (t *A_arbace_go_repl_import_BANG__fn__794000057_A) Ctor_O(c__specs any) { t.F_specs = c__specs }
//line :134:1
func (t *A_arbace_go_repl_import_BANG__fn__794000057_A) Invoke_O_O__O(self, fi__1 any) any { var root_407 any = A_arbace_go_repl_A_const_79.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = fi__1; var arg_411 any = A_arbace_go_repl_A_const_81; var arg_412 any; var tmp1 any = A_arbace_go_repl_import_BANG__fn__794000057_fn__794000058_A_New_O(t.F_specs); var tmp2 *jrt.Class; var fncls__426 *jrt.Class = A_arbace_go_repl_import_BANG__fn__794000057_fn__794000058_A_fn_class; if fncls__426 == nil { var fncls__426d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_157, false); A_arbace_go_repl_import_BANG__fn__794000057_fn__794000058_A_fn_class = fncls__426d; tmp2 = fncls__426d } else { tmp2 = fncls__426 }; arg_412 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_408 == nil { return ifn_409.Invoke_O_O_O__O(arg_410, arg_411, arg_412) } else { return linked_408.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_407, arg_410, arg_411, arg_412) } }
//line :134:1
func A_arbace_go_repl_import_BANG__fn__794000057_fn__794000058_A_New_O(p0 any) *A_arbace_go_repl_import_BANG__fn__794000057_fn__794000058_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_import_BANG__fn__794000057_fn__794000058_A{}; t.Ctor_O(p0); return t }
//line :134:1
func (t *A_arbace_go_repl_import_BANG__fn__794000057_fn__794000058_A) Ctor_O(c__specs any) { t.F_specs = c__specs }
//line :134:1
func (t *A_arbace_go_repl_import_BANG__fn__794000057_fn__794000058_A) Invoke_O_O__O(self, p1__794000056_SHARP___1 any) any { var root_413 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_413, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_415 lang.IFn; if linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any; var root_417 any = A_arbace_go_repl_A_const_87.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_419 lang.IFn; if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any; var root_421 any = A_arbace_go_repl_A_const_88.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_423 lang.IFn; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any; var or__1927000174__auto____2 any = p1__794000056_SHARP___1; if jrt.J2g_Truth(or__1927000174__auto____2) { arg_424 = or__1927000174__auto____2 } else { arg_424 = lang.PersistentVector_EMPTY.Ref() }; var arg_425 any = t.F_specs; if linked_422 == nil { arg_420 = ifn_423.Invoke_O_O__O(arg_424, arg_425) } else { arg_420 = linked_422.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_421, arg_424, arg_425) }; if linked_418 == nil { arg_416 = ifn_419.Invoke_O__O(arg_420) } else { arg_416 = linked_418.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_417, arg_420) }; if linked_414 == nil { return ifn_415.Invoke_O__O(arg_416) } else { return linked_414.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_413, arg_416) } }




func A_arbace_go_repl_decl_names_A_New() *A_arbace_go_repl_decl_names_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_go_repl_decl_names_A) Ctor() {}
//line :139:1
func (t *A_arbace_go_repl_decl_names_A) Invoke_O_O__O(self, f__0 any) any { var h__2 any; var root_428 any = A_arbace_go_repl_A_const_89.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_428, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_430 lang.IFn; if


	linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any = f__0; if linked_429 == nil { h__2 = ifn_430.Invoke_O__O(arg_431) } else { h__2 = linked_429.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_428, arg_431) }; var args__3 any; var root_432 any = /*line :139:1*/A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_432, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_434 lang.IFn; if



	linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = f__0; if linked_433 == nil { args__3 = ifn_434.Invoke_O__O(arg_435) } else { args__3 = linked_433.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_432, arg_435) }; var targets__4 any; var tmp1 any = /*line :139:1*/A_arbace_go_repl_decl_names_targets__794000062_A_New(); var tmp2 *jrt.Class; var fncls__444 *jrt.Class = A_arbace_go_repl_decl_names_targets__794000062_A_fn_class; if




	fncls__444 == nil { var fncls__444d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_go_repl_decl_names_targets__794000062_A_fn_class = fncls__444d; tmp2 = fncls__444d } else { tmp2 = fncls__444 }; targets__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var group_QMARK___5 any; var tmp3 any = /*line :139:1*/A_arbace_go_repl_decl_names_group_QMARK___794000064_A_New(); var tmp4 *jrt.Class; var fncls__462 *jrt.Class = A_arbace_go_repl_decl_names_group_QMARK___794000064_A_fn_class; if





	fncls__462 == nil { var fncls__462d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_go_repl_decl_names_group_QMARK___794000064_A_fn_class = fncls__462d; tmp4 = fncls__462d } else { tmp4 = fncls__462 }; group_QMARK___5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var specs__6 any; var tmp5 any = /*line :139:1*/A_arbace_go_repl_decl_names_specs__794000066_A_New(); var tmp6 *jrt.Class; var fncls__479 *jrt.Class = A_arbace_go_repl_decl_names_specs__794000066_A_fn_class; if






	fncls__479 == nil { var fncls__479d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_go_repl_decl_names_specs__794000066_A_fn_class = fncls__479d; tmp6 = fncls__479d } else { tmp6 = fncls__479 }; specs__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var G__794000068__7_ any = h__2; switch
	lang.Util_Hash_O__I_NoInit(G__794000068__7_) >> 9 & 7 { case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__794000068__7_, Lit_21) {












		if jrt.J2g_Truth(lang.IFn_Cast(group_QMARK___5).Invoke_O__O(args__3)) {
			var root_481 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_481, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_483 lang.IFn; if linked_482 == nil { ifn_483 = lang.IFn_Cast(root_481) } else { ifn_483 = nil }; var arg_484 any; var iter__1927001039__auto____8 any; var tmp7 any = A_arbace_go_repl_decl_names_iter__794000069__794000073_A_New(); var tmp8 *jrt.Class; var fncls__551 *jrt.Class = A_arbace_go_repl_decl_names_iter__794000069__794000073_A_fn_class; if fncls__551 == nil { var fncls__551d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_go_repl_decl_names_iter__794000069__794000073_A_fn_class = fncls__551d; tmp8 = fncls__551d } else { tmp8 = fncls__551 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); arg_484 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(lang.IFn_Cast(specs__6).Invoke_O__O(args__3)); if linked_482 == nil { return ifn_483.Invoke_O__O(arg_484) } else { return linked_482.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_481, arg_484) } } else {
//line :160:1
				var tmp9 any; var root_774 any = A_arbace_go_repl_A_const_73.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_776 lang.IFn

				if linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any; var root_778 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_778, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_780 lang.IFn; if linked_779 == nil { ifn_780 = lang.IFn_Cast(root_778) } else { ifn_780 = nil }; var arg_781 any = args__3; if linked_779 == nil { arg_777 = ifn_780.Invoke_O__O(arg_781) } else { arg_777 = linked_779.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_778, arg_781) }; if linked_775 == nil { tmp9 = ifn_776.Invoke_O__O(arg_777) } else { tmp9 = linked_775.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_774, arg_777) }
//line :160:1
				return lang.Tuple_Create_O__IPersistentVector(tmp9) } }
//line :147:1
	case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__794000068__7_, Lit_23) { var tmp10 any; var root_782 any = A_arbace_go_repl_A_const_73.GetRawRoot__O(); var linked_783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_782, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_784 lang.IFn
		if linked_783 == nil { ifn_784 = lang.IFn_Cast(root_782) } else { ifn_784 = nil }; var arg_785 any; var root_786 any = A_arbace_go_repl_A_const_103.GetRawRoot__O(); var linked_787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_786, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_788 lang.IFn; if linked_787 == nil { ifn_788 = lang.IFn_Cast(root_786) } else { ifn_788 = nil }; var arg_789 any = f__0; if linked_787 == nil { arg_785 = ifn_788.Invoke_O__O(arg_789) } else { arg_785 = linked_787.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_786, arg_789) }; if linked_783 == nil { tmp10 = ifn_784.Invoke_O__O(arg_785) } else { tmp10 = linked_783.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_782, arg_785) }
//line :147:1
		return lang.Tuple_Create_O__IPersistentVector(tmp10) }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__794000068__7_, Lit_24) {









			if jrt.J2g_Truth(lang.IFn_Cast(group_QMARK___5).Invoke_O__O(args__3)) {
				var root_552 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any; var iter__1927001039__auto____8_2 any; var tmp11 any = A_arbace_go_repl_decl_names_iter__794000085__794000091_A_New_O(targets__4); var tmp12 *jrt.Class; var fncls__649 *jrt.Class = A_arbace_go_repl_decl_names_iter__794000085__794000091_A_fn_class; if fncls__649 == nil { var fncls__649d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_go_repl_decl_names_iter__794000085__794000091_A_fn_class = fncls__649d; tmp12 = fncls__649d } else { tmp12 = fncls__649 }; iter__1927001039__auto____8_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); arg_555 = lang.IFn_Cast(iter__1927001039__auto____8_2).Invoke_O__O(lang.IFn_Cast(specs__6).Invoke_O__O(args__3)); if linked_553 == nil { return ifn_554.Invoke_O__O(arg_555) } else { return linked_553.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_552, arg_555) } } else {
					var root_650 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_650, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_652 lang.IFn; if linked_651 == nil { ifn_652 = lang.IFn_Cast(root_650) } else { ifn_652 = nil }; var arg_653 any; var root_654 any = A_arbace_go_repl_A_const_102.GetRawRoot__O(); var linked_655 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_654, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_656 lang.IFn; if linked_655 == nil { ifn_656 = lang.IFn_Cast(root_654) } else { ifn_656 = nil }; var arg_657 any = A_arbace_go_repl_A_const_73.GetRawRoot__O(); var arg_658 any; var tmp13 lang.IFn = lang.IFn_Cast(targets__4); var tmp14 any; var root_659 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_659, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_661 lang.IFn; if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any = args__3; if linked_660 == nil { tmp14 = ifn_661.Invoke_O__O(arg_662) } else { tmp14 = linked_660.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_659, arg_662) }; arg_658 = tmp13.Invoke_O__O(tmp14); if linked_655 == nil { arg_653 = ifn_656.Invoke_O_O__O(arg_657, arg_658) } else { arg_653 = linked_655.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_654, arg_657, arg_658) }; if linked_651 == nil { return ifn_652.Invoke_O__O(arg_653) } else { return linked_651.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_650, arg_653) } } }
//line :147:1
	case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__794000068__7_, Lit_26) {









		if jrt.J2g_Truth(lang.IFn_Cast(group_QMARK___5).Invoke_O__O(args__3)) {
			var root_663 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any; var iter__1927001039__auto____8_3 any; var tmp15 any = A_arbace_go_repl_decl_names_iter__794000104__794000110_A_New_O(targets__4); var tmp16 *jrt.Class; var fncls__760 *jrt.Class = A_arbace_go_repl_decl_names_iter__794000104__794000110_A_fn_class; if fncls__760 == nil { var fncls__760d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_go_repl_decl_names_iter__794000104__794000110_A_fn_class = fncls__760d; tmp16 = fncls__760d } else { tmp16 = fncls__760 }; iter__1927001039__auto____8_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); arg_666 = lang.IFn_Cast(iter__1927001039__auto____8_3).Invoke_O__O(lang.IFn_Cast(specs__6).Invoke_O__O(args__3)); if linked_664 == nil { return ifn_665.Invoke_O__O(arg_666) } else { return linked_664.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_663, arg_666) } } else {
				var root_761 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any; var root_765 any = A_arbace_go_repl_A_const_102.GetRawRoot__O(); var linked_766 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_765, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_767 lang.IFn; if linked_766 == nil { ifn_767 = lang.IFn_Cast(root_765) } else { ifn_767 = nil }; var arg_768 any = A_arbace_go_repl_A_const_73.GetRawRoot__O(); var arg_769 any; var tmp17 lang.IFn = lang.IFn_Cast(targets__4); var tmp18 any; var root_770 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_772 lang.IFn; if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any = args__3; if linked_771 == nil { tmp18 = ifn_772.Invoke_O__O(arg_773) } else { tmp18 = linked_771.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_770, arg_773) }; arg_769 = tmp17.Invoke_O__O(tmp18); if linked_766 == nil { arg_764 = ifn_767.Invoke_O_O__O(arg_768, arg_769) } else { arg_764 = linked_766.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_765, arg_768, arg_769) }; if linked_762 == nil { return ifn_763.Invoke_O__O(arg_764) } else { return linked_762.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_761, arg_764) } } }
//line :147:1
	case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__794000068__7_, Lit_28) { var more__8 any; var root_790 any = A_arbace_go_repl_A_const_104.GetRawRoot__O(); var linked_791 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_790, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_792 lang.IFn

		if linked_791 == nil { ifn_792 = lang.IFn_Cast(root_790) } else { ifn_792 = nil }; var arg_794 any = f__0; if linked_791 == nil { more__8 = ifn_792.Invoke_O_O__O(A_arbace_go_repl_A_const_105, arg_794) } else { more__8 = linked_791.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_790, 2, A_arbace_go_repl_A_const_105, arg_794) }
//line :147:1
		var more__9 any; var tmp19 any; var root_795 any = A_arbace_go_repl_A_const_90.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_797 lang.IFn


		if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any; var root_799 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_799, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_801 lang.IFn; if linked_800 == nil { ifn_801 = lang.IFn_Cast(root_799) } else { ifn_801 = nil }; var arg_802 any = more__8; if linked_800 == nil { arg_798 = ifn_801.Invoke_O__O(arg_802) } else { arg_798 = linked_800.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_799, arg_802) }; if linked_796 == nil { tmp19 = ifn_797.Invoke_O__O(arg_798) } else { tmp19 = linked_796.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_795, arg_798) }; if jrt.J2g_Truth(tmp19) { var root_803 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_803, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_805 lang.IFn; if linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any = more__8; if linked_804 == nil { more__9 = ifn_805.Invoke_O__O(arg_806) } else { more__9 = linked_804.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_803, arg_806) } } else { more__9 = more__8 }
//line :147:1
		var more__10 any; var tmp20 any = A_arbace_go_repl_A_const_106; var tmp21 any; var root_807 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_807, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_809 lang.IFn



		if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any = more__9; if linked_808 == nil { tmp21 = ifn_809.Invoke_O__O(arg_810) } else { tmp21 = linked_808.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_807, arg_810) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp20, tmp21) { var root_811 any = A_arbace_go_repl_A_const_104.GetRawRoot__O(); var linked_812 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_811, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_813 lang.IFn; if linked_812 == nil { ifn_813 = lang.IFn_Cast(root_811) } else { ifn_813 = nil }; var arg_815 any = more__9; if linked_812 == nil { more__10 = ifn_813.Invoke_O_O__O(A_arbace_go_repl_A_const_105, arg_815) } else { more__10 = linked_812.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_811, 2, A_arbace_go_repl_A_const_105, arg_815) } } else { more__10 = more__9 }
//line :147:1
		var rf__11 any; var root_816 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_818 lang.IFn




		if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any; var root_820 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_820, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_822 lang.IFn; if linked_821 == nil { ifn_822 = lang.IFn_Cast(root_820) } else { ifn_822 = nil }; var arg_823 any = more__10; if linked_821 == nil { arg_819 = ifn_822.Invoke_O__O(arg_823) } else { arg_819 = linked_821.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_820, arg_823) }; if linked_817 == nil { rf__11 = ifn_818.Invoke_O__O(arg_819) } else { rf__11 = linked_817.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_816, arg_819) }
//line :147:1
		var ty__12 any; var tmp22 any; var and__1927000168__auto____12 any; var root_824 any = A_arbace_go_repl_A_const_107.GetRawRoot__O(); var linked_825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_824, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_826 lang.IFn





		if linked_825 == nil { ifn_826 = lang.IFn_Cast(root_824) } else { ifn_826 = nil }; var arg_827 any = rf__11; if linked_825 == nil { and__1927000168__auto____12 = ifn_826.Invoke_O__O(arg_827) } else { and__1927000168__auto____12 = linked_825.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_824, arg_827) }; if jrt.J2g_Truth(and__1927000168__auto____12) { var tmp23 *lang.Keyword = A_arbace_go_repl_A_const_108; tmp22 = tmp23.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(rf__11)) } else { tmp22 = and__1927000168__auto____12 }; if jrt.J2g_Truth(tmp22) { var tmp24 *lang.Keyword = A_arbace_go_repl_A_const_108; ty__12 = tmp24.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(rf__11)) } else { ty__12 = rf__11 }
//line :147:1
		var ty__13 any; var tmp25 any; var and__1927000168__auto____13 any; var root_828 any = A_arbace_go_repl_A_const_34.GetRawRoot__O(); var linked_829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_828, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_830 lang.IFn






		if linked_829 == nil { ifn_830 = lang.IFn_Cast(root_828) } else { ifn_830 = nil }; var arg_831 any = ty__12; if linked_829 == nil { and__1927000168__auto____13 = ifn_830.Invoke_O__O(arg_831) } else { and__1927000168__auto____13 = linked_829.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_828, arg_831) }; if jrt.J2g_Truth(and__1927000168__auto____13) { var tmp26 any = A_arbace_go_repl_A_const_109; var tmp27 any; var root_832 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_832, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_834 lang.IFn; if linked_833 == nil { ifn_834 = lang.IFn_Cast(root_832) } else { ifn_834 = nil }; var arg_835 any = ty__12; if linked_833 == nil { tmp27 = ifn_834.Invoke_O__O(arg_835) } else { tmp27 = linked_833.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_832, arg_835) }; tmp25 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp26, tmp27)).Ref() } else { tmp25 = and__1927000168__auto____13 }; if jrt.J2g_Truth(tmp25) { var root_836 any = A_arbace_go_repl_A_const_103.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_836, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_838 lang.IFn; if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any = ty__12; if linked_837 == nil { ty__13 = ifn_838.Invoke_O__O(arg_839) } else { ty__13 = linked_837.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_836, arg_839) } } else { ty__13 = ty__12 }
//line :147:1
		var ty__14 any; var tmp28 any; var root_840 any = A_arbace_go_repl_A_const_34.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_840, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_842 lang.IFn







		if linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any = ty__13; if linked_841 == nil { tmp28 = ifn_842.Invoke_O__O(arg_843) } else { tmp28 = linked_841.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_840, arg_843) }; if jrt.J2g_Truth(tmp28) { var root_844 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_844, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_846 lang.IFn; if linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any = ty__13; if linked_845 == nil { ty__14 = ifn_846.Invoke_O__O(arg_847) } else { ty__14 = linked_845.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_844, arg_847) } } else { ty__14 = ty__13 }
//line :147:1
		var tmp29 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_3, nil); var tmp30 any; var root_848 any = A_arbace_go_repl_A_const_73.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_848, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_850 lang.IFn








		if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any; var root_852 any = A_arbace_go_repl_A_const_103.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_854 lang.IFn; if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any = f__0; if linked_853 == nil { arg_851 = ifn_854.Invoke_O__O(arg_855) } else { arg_851 = linked_853.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_852, arg_855) }; if linked_849 == nil { tmp30 = ifn_850.Invoke_O__O(arg_851) } else { tmp30 = linked_849.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_848, arg_851) }
//line :147:1
		return lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp29, jrt.RefArrayOf(jrt.Object_class, ty__14, nil, tmp30)).Ref()) }; default:}; return lang.PersistentVector_EMPTY.Ref() }
//line :144:1
func A_arbace_go_repl_decl_names_targets__794000062_A_New() *A_arbace_go_repl_decl_names_targets__794000062_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_targets__794000062_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_go_repl_decl_names_targets__794000062_A) Ctor() {}
//line :144:1
func (t *A_arbace_go_repl_decl_names_targets__794000062_A) Invoke_O_O__O(self, tf__1 any) any { var tmp1 any; var root_436 any = A_arbace_go_repl_A_const_89.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_436, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_438 lang.IFn; if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any = tf__1; if linked_437 == nil { tmp1 = ifn_438.Invoke_O__O(arg_439) } else { tmp1 = linked_437.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_436, arg_439) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_39, tmp1) { var root_440 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_440, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_442 lang.IFn; if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = tf__1; if linked_441 == nil { return ifn_442.Invoke_O__O(arg_443) } else { return linked_441.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_440, arg_443) } } else { return lang.Tuple_Create_O__IPersistentVector(tf__1) } }
func A_arbace_go_repl_decl_names_group_QMARK___794000064_A_New() *A_arbace_go_repl_decl_names_group_QMARK___794000064_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_group_QMARK___794000064_A{}; t.Ctor(); return t }
//line :145:1
func (t *A_arbace_go_repl_decl_names_group_QMARK___794000064_A) Ctor() {}
//line :145:1
func (t *A_arbace_go_repl_decl_names_group_QMARK___794000064_A) Invoke_O_O__O(self, args__1 any) any { var a__2 any; var tmp1 any; var root_445 any = A_arbace_go_repl_A_const_90.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_445, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_447 lang.IFn; if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any; var root_449 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_451 lang.IFn; if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any = args__1; if linked_450 == nil { arg_448 = ifn_451.Invoke_O__O(arg_452) } else { arg_448 = linked_450.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_449, arg_452) }; if linked_446 == nil { tmp1 = ifn_447.Invoke_O__O(arg_448) } else { tmp1 = linked_446.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_445, arg_448) }; if jrt.J2g_Truth(tmp1) { var root_453 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_453, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_455 lang.IFn; if linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any = args__1; if linked_454 == nil { a__2 = ifn_455.Invoke_O__O(arg_456) } else { a__2 = linked_454.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_453, arg_456) } } else { a__2 = args__1 }; var root_457 any = A_arbace_go_repl_A_const_91.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_459 lang.IFn; if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any = A_arbace_go_repl_A_const_92.GetRawRoot__O(); var arg_461 any = a__2; if linked_458 == nil { return ifn_459.Invoke_O_O__O(arg_460, arg_461) } else { return linked_458.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_457, arg_460, arg_461) } }
func A_arbace_go_repl_decl_names_specs__794000066_A_New() *A_arbace_go_repl_decl_names_specs__794000066_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_specs__794000066_A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_go_repl_decl_names_specs__794000066_A) Ctor() {}
//line :146:1
func (t *A_arbace_go_repl_decl_names_specs__794000066_A) Invoke_O_O__O(self, args__1 any) any { var root_463 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any; var tmp1 any; var root_467 any = A_arbace_go_repl_A_const_90.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_469 lang.IFn; if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any; var root_471 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_473 lang.IFn; if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = args__1; if linked_472 == nil { arg_470 = ifn_473.Invoke_O__O(arg_474) } else { arg_470 = linked_472.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_471, arg_474) }; if linked_468 == nil { tmp1 = ifn_469.Invoke_O__O(arg_470) } else { tmp1 = linked_468.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_467, arg_470) }; if jrt.J2g_Truth(tmp1) { var root_475 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = args__1; if linked_476 == nil { arg_466 = ifn_477.Invoke_O__O(arg_478) } else { arg_466 = linked_476.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_475, arg_478) } } else { arg_466 = args__1 }; if linked_464 == nil { return ifn_465.Invoke_O__O(arg_466) } else { return linked_464.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_463, arg_466) } }











func A_arbace_go_repl_decl_names_iter__794000085__794000091_A_New_O(p0 any) *A_arbace_go_repl_decl_names_iter__794000085__794000091_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_iter__794000085__794000091_A{}; t.Ctor_O(p0); return t }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000085__794000091_A) Ctor_O(c__targets any) { t.F_targets = c__targets }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000085__794000091_A) Invoke_O_O__O(self, s__794000086__1 any) any { var tmp1 any = A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_A_New_O_O_O(self, s__794000086__1, t.F_targets); var tmp2 *jrt.Class; var fncls__648 *jrt.Class = A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_A_fn_class; if fncls__648 == nil { var fncls__648d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_A_fn_class = fncls__648d; tmp2 = fncls__648d } else { tmp2 = fncls__648 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :158:1
func A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_A) Ctor_O_O_O(c__iter__794000085, c__s__794000086, c__targets any) { t.F_iter__794000085 = c__iter__794000085; t.F_s__794000086 = c__s__794000086; t.F_targets = c__targets }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_A) Invoke_O__O(self any) any { { var s__794000086__1 any; var t_ any = t.F_s__794000086; t.F_s__794000086 = nil; s__794000086__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_556 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_556, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_558 lang.IFn; if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any = s__794000086__1; if linked_557 == nil { temp__1927000414__auto____2 = ifn_558.Invoke_O__O(arg_559) } else { temp__1927000414__auto____2 = linked_557.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_556, arg_559) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__794000093__4 any; var root_560 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = xs__1927001018__auto____3; if linked_561 == nil { vec__794000093__4 = ifn_562.Invoke_O__O(arg_563) } else { vec__794000093__4 = linked_561.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_560, arg_563) }; var tf__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000093__4, lang.RT_IntCast_J__I_NoInit(0), nil); var iterys__1927001035__auto____6 any; var tmp1 any = A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_A_New(); var tmp2 *jrt.Class; var fncls__630 *jrt.Class = A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_A_fn_class; if fncls__630 == nil { var fncls__630d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_A_fn_class = fncls__630d; tmp2 = fncls__630d } else { tmp2 = fncls__630 }; iterys__1927001035__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____7 any; var root_631 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_633 lang.IFn; if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = lang.IFn_Cast(iterys__1927001035__auto____6).Invoke_O__O(lang.IFn_Cast(t.F_targets).Invoke_O__O(tf__5)); if linked_632 == nil { fs__1927001036__auto____7 = ifn_633.Invoke_O__O(arg_634) } else { fs__1927001036__auto____7 = linked_632.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_631, arg_634) }; if jrt.J2g_Truth(fs__1927001036__auto____7) { var root_635 any = A_arbace_go_repl_A_const_101.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_635, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_637 lang.IFn; if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any = fs__1927001036__auto____7; var arg_639 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__794000085); var tmp4 any; var root_640 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_642 lang.IFn; if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = s__794000086__1; if linked_641 == nil { tmp4 = ifn_642.Invoke_O__O(arg_643) } else { tmp4 = linked_641.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_640, arg_643) }; arg_639 = tmp3.Invoke_O__O(tmp4); if linked_636 == nil { return ifn_637.Invoke_O_O__O(arg_638, arg_639) } else { return linked_636.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_635, arg_638, arg_639) } } else { var tmp5 any; var root_644 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_644, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_646 lang.IFn; if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any = s__794000086__1; if linked_645 == nil { tmp5 = ifn_646.Invoke_O__O(arg_647) } else { tmp5 = linked_645.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_644, arg_647) }; s__794000086__1 = tmp5; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :158:1
func A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_A_New() *A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_A) Ctor() {}
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_A) Invoke_O_O__O(self, s__794000088__1 any) any { var tmp1 any = A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_A_New_O_O(self, s__794000088__1); var tmp2 *jrt.Class; var fncls__629 *jrt.Class = A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_A_fn_class; if fncls__629 == nil { var fncls__629d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_A_fn_class = fncls__629d; tmp2 = fncls__629d } else { tmp2 = fncls__629 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :158:1
func A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_A_New_O_O(p0, p1 any) *A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_A{}; t.Ctor_O_O(p0, p1); return t }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_A) Ctor_O_O(c__iter__794000087, c__s__794000088 any) { t.F_iter__794000087 = c__iter__794000087; t.F_s__794000088 = c__s__794000088 }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_A) Invoke_O__O(self any) any { { var s__794000088__1 any; var t_ any = t.F_s__794000088; t.F_s__794000088 = nil; s__794000088__1 = t_; for { var temp__1927000414__auto____2 any; var root_564 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_566 lang.IFn; if linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any = s__794000088__1; if linked_565 == nil { temp__1927000414__auto____2 = ifn_566.Invoke_O__O(arg_567) } else { temp__1927000414__auto____2 = linked_565.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_564, arg_567) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__794000088__3 any = temp__1927000414__auto____2; var tmp1 any; var root_568 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_570 lang.IFn; if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = s__794000088__3; if linked_569 == nil { tmp1 = ifn_570.Invoke_O__O(arg_571) } else { tmp1 = linked_569.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_568, arg_571) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_572 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_572, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_574 lang.IFn; if linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any = s__794000088__3; if linked_573 == nil { c__1927001037__auto____4 = ifn_574.Invoke_O__O(arg_575) } else { c__1927001037__auto____4 = linked_573.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_572, arg_575) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__794000090__6 any; var root_576 any = A_arbace_go_repl_A_const_95.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_576, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_578 lang.IFn; if linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_577 == nil { b__794000090__6 = ifn_578.Invoke_O__O(arg_579) } else { b__794000090__6 = linked_577.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_576, arg_579) }; var tmp2 any = A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_fn__794000098_A_New_O_I_O(b__794000090__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__589 *jrt.Class = A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_fn__794000098_A_fn_class; if fncls__589 == nil { var fncls__589d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_fn__794000098_A_fn_class = fncls__589d; tmp3 = fncls__589d } else { tmp3 = fncls__589 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_590 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_592 lang.IFn; if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any; var root_595 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_595, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_597 lang.IFn; if linked_596 == nil { ifn_597 = lang.IFn_Cast(root_595) } else { ifn_597 = nil }; var arg_598 any = b__794000090__6; if linked_596 == nil { arg_593 = ifn_597.Invoke_O__O(arg_598) } else { arg_593 = linked_596.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_595, arg_598) }; var arg_594 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__794000087); var tmp5 any; var root_599 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_599, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_601 lang.IFn; if linked_600 == nil { ifn_601 = lang.IFn_Cast(root_599) } else { ifn_601 = nil }; var arg_602 any = s__794000088__3; if linked_600 == nil { tmp5 = ifn_601.Invoke_O__O(arg_602) } else { tmp5 = linked_600.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_599, arg_602) }; arg_594 = tmp4.Invoke_O__O(tmp5); if linked_591 == nil { return ifn_592.Invoke_O_O__O(arg_593, arg_594) } else { return linked_591.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_590, arg_593, arg_594) } } else { var root_603 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_605 lang.IFn; if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any; var root_608 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_608, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_610 lang.IFn; if linked_609 == nil { ifn_610 = lang.IFn_Cast(root_608) } else { ifn_610 = nil }; var arg_611 any = b__794000090__6; if linked_609 == nil { arg_606 = ifn_610.Invoke_O__O(arg_611) } else { arg_606 = linked_609.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_608, arg_611) }; var arg_607 any; if linked_604 == nil { return ifn_605.Invoke_O_O__O(arg_606, arg_607) } else { return linked_604.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_603, arg_606, arg_607) } } } else { var x__4 any; var root_612 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_612, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_614 lang.IFn; if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any = s__794000088__3; if linked_613 == nil { x__4 = ifn_614.Invoke_O__O(arg_615) } else { x__4 = linked_613.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_612, arg_615) }; var root_616 any = A_arbace_go_repl_A_const_100.GetRawRoot__O(); var linked_617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_616, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_618 lang.IFn; if linked_617 == nil { ifn_618 = lang.IFn_Cast(root_616) } else { ifn_618 = nil }; var arg_619 any; var root_621 any = A_arbace_go_repl_A_const_73.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any = x__4; if linked_622 == nil { arg_619 = ifn_623.Invoke_O__O(arg_624) } else { arg_619 = linked_622.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_621, arg_624) }; var arg_620 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__794000087); var tmp7 any; var root_625 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = s__794000088__3; if linked_626 == nil { tmp7 = ifn_627.Invoke_O__O(arg_628) } else { tmp7 = linked_626.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_625, arg_628) }; arg_620 = tmp6.Invoke_O__O(tmp7); if linked_617 == nil { return ifn_618.Invoke_O_O__O(arg_619, arg_620) } else { return linked_617.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_616, arg_619, arg_620) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :158:1
func A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_fn__794000098_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_fn__794000098_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_fn__794000098_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_fn__794000098_A) Ctor_O_I_O(c__b__794000090 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__794000090 = c__b__794000090; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_fn__794000098_A) Invoke_O__O(self any) any { { var i__794000089__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__794000089__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var x__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__794000089__1)); var root_580 any = A_arbace_go_repl_A_const_96.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_580, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_582 lang.IFn; if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any = t.F_b__794000090; var arg_584 any; var root_585 any = A_arbace_go_repl_A_const_73.GetRawRoot__O(); var linked_586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_585, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_587 lang.IFn; if linked_586 == nil { ifn_587 = lang.IFn_Cast(root_585) } else { ifn_587 = nil }; var arg_588 any = x__2; if linked_586 == nil { arg_584 = ifn_587.Invoke_O__O(arg_588) } else { arg_584 = linked_586.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_585, arg_588) }; if linked_581 == nil { ifn_582.Invoke_O_O__O(arg_583, arg_584) } else { linked_581.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_580, arg_583, arg_584) }; i__794000089__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000089__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :158:1
func A_arbace_go_repl_decl_names_iter__794000104__794000110_A_New_O(p0 any) *A_arbace_go_repl_decl_names_iter__794000104__794000110_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_iter__794000104__794000110_A{}; t.Ctor_O(p0); return t }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000104__794000110_A) Ctor_O(c__targets any) { t.F_targets = c__targets }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000104__794000110_A) Invoke_O_O__O(self, s__794000105__1 any) any { var tmp1 any = A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_A_New_O_O_O(s__794000105__1, t.F_targets, self); var tmp2 *jrt.Class; var fncls__759 *jrt.Class = A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_A_fn_class; if fncls__759 == nil { var fncls__759d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_A_fn_class = fncls__759d; tmp2 = fncls__759d } else { tmp2 = fncls__759 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :158:1
func A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_A) Ctor_O_O_O(c__s__794000105, c__targets, c__iter__794000104 any) { t.F_s__794000105 = c__s__794000105; t.F_targets = c__targets; t.F_iter__794000104 = c__iter__794000104 }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_A) Invoke_O__O(self any) any { { var s__794000105__1 any; var t_ any = t.F_s__794000105; t.F_s__794000105 = nil; s__794000105__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_667 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_669 lang.IFn; if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = s__794000105__1; if linked_668 == nil { temp__1927000414__auto____2 = ifn_669.Invoke_O__O(arg_670) } else { temp__1927000414__auto____2 = linked_668.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_667, arg_670) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__794000112__4 any; var root_671 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_671, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_673 lang.IFn; if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any = xs__1927001018__auto____3; if linked_672 == nil { vec__794000112__4 = ifn_673.Invoke_O__O(arg_674) } else { vec__794000112__4 = linked_672.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_671, arg_674) }; var tf__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000112__4, lang.RT_IntCast_J__I_NoInit(0), nil); var iterys__1927001035__auto____6 any; var tmp1 any = A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_A_New(); var tmp2 *jrt.Class; var fncls__741 *jrt.Class = A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_A_fn_class; if fncls__741 == nil { var fncls__741d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_A_fn_class = fncls__741d; tmp2 = fncls__741d } else { tmp2 = fncls__741 }; iterys__1927001035__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____7 any; var root_742 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_742, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_744 lang.IFn; if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any = lang.IFn_Cast(iterys__1927001035__auto____6).Invoke_O__O(lang.IFn_Cast(t.F_targets).Invoke_O__O(tf__5)); if linked_743 == nil { fs__1927001036__auto____7 = ifn_744.Invoke_O__O(arg_745) } else { fs__1927001036__auto____7 = linked_743.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_742, arg_745) }; if jrt.J2g_Truth(fs__1927001036__auto____7) { var root_746 any = A_arbace_go_repl_A_const_101.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_746, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_748 lang.IFn; if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any = fs__1927001036__auto____7; var arg_750 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__794000104); var tmp4 any; var root_751 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_751, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_753 lang.IFn; if linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any = s__794000105__1; if linked_752 == nil { tmp4 = ifn_753.Invoke_O__O(arg_754) } else { tmp4 = linked_752.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_751, arg_754) }; arg_750 = tmp3.Invoke_O__O(tmp4); if linked_747 == nil { return ifn_748.Invoke_O_O__O(arg_749, arg_750) } else { return linked_747.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_746, arg_749, arg_750) } } else { var tmp5 any; var root_755 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_755, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_757 lang.IFn; if linked_756 == nil { ifn_757 = lang.IFn_Cast(root_755) } else { ifn_757 = nil }; var arg_758 any = s__794000105__1; if linked_756 == nil { tmp5 = ifn_757.Invoke_O__O(arg_758) } else { tmp5 = linked_756.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_755, arg_758) }; s__794000105__1 = tmp5; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :158:1
func A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_A_New() *A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_A) Ctor() {}
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_A) Invoke_O_O__O(self, s__794000107__1 any) any { var tmp1 any = A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_A_New_O_O(self, s__794000107__1); var tmp2 *jrt.Class; var fncls__740 *jrt.Class = A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_A_fn_class; if fncls__740 == nil { var fncls__740d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_A_fn_class = fncls__740d; tmp2 = fncls__740d } else { tmp2 = fncls__740 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :158:1
func A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_A_New_O_O(p0, p1 any) *A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_A{}; t.Ctor_O_O(p0, p1); return t }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_A) Ctor_O_O(c__iter__794000106, c__s__794000107 any) { t.F_iter__794000106 = c__iter__794000106; t.F_s__794000107 = c__s__794000107 }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_A) Invoke_O__O(self any) any { { var s__794000107__1 any; var t_ any = t.F_s__794000107; t.F_s__794000107 = nil; s__794000107__1 = t_; for { var temp__1927000414__auto____2 any; var root_675 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_677 lang.IFn; if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any = s__794000107__1; if linked_676 == nil { temp__1927000414__auto____2 = ifn_677.Invoke_O__O(arg_678) } else { temp__1927000414__auto____2 = linked_676.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_675, arg_678) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__794000107__3 any = temp__1927000414__auto____2; var tmp1 any; var root_679 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = s__794000107__3; if linked_680 == nil { tmp1 = ifn_681.Invoke_O__O(arg_682) } else { tmp1 = linked_680.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_679, arg_682) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_683 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_685 lang.IFn; if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any = s__794000107__3; if linked_684 == nil { c__1927001037__auto____4 = ifn_685.Invoke_O__O(arg_686) } else { c__1927001037__auto____4 = linked_684.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_683, arg_686) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__794000109__6 any; var root_687 any = A_arbace_go_repl_A_const_95.GetRawRoot__O(); var linked_688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_687, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_689 lang.IFn; if linked_688 == nil { ifn_689 = lang.IFn_Cast(root_687) } else { ifn_689 = nil }; var arg_690 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_688 == nil { b__794000109__6 = ifn_689.Invoke_O__O(arg_690) } else { b__794000109__6 = linked_688.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_687, arg_690) }; var tmp2 any = A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_fn__794000117_A_New_O_I_O(b__794000109__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__700 *jrt.Class = A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_fn__794000117_A_fn_class; if fncls__700 == nil { var fncls__700d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_fn__794000117_A_fn_class = fncls__700d; tmp3 = fncls__700d } else { tmp3 = fncls__700 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_701 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_701, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_703 lang.IFn; if linked_702 == nil { ifn_703 = lang.IFn_Cast(root_701) } else { ifn_703 = nil }; var arg_704 any; var root_706 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_706, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_708 lang.IFn; if linked_707 == nil { ifn_708 = lang.IFn_Cast(root_706) } else { ifn_708 = nil }; var arg_709 any = b__794000109__6; if linked_707 == nil { arg_704 = ifn_708.Invoke_O__O(arg_709) } else { arg_704 = linked_707.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_706, arg_709) }; var arg_705 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__794000106); var tmp5 any; var root_710 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_710, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_712 lang.IFn; if linked_711 == nil { ifn_712 = lang.IFn_Cast(root_710) } else { ifn_712 = nil }; var arg_713 any = s__794000107__3; if linked_711 == nil { tmp5 = ifn_712.Invoke_O__O(arg_713) } else { tmp5 = linked_711.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_710, arg_713) }; arg_705 = tmp4.Invoke_O__O(tmp5); if linked_702 == nil { return ifn_703.Invoke_O_O__O(arg_704, arg_705) } else { return linked_702.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_701, arg_704, arg_705) } } else { var root_714 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_714, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_716 lang.IFn; if linked_715 == nil { ifn_716 = lang.IFn_Cast(root_714) } else { ifn_716 = nil }; var arg_717 any; var root_719 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_721 lang.IFn; if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = b__794000109__6; if linked_720 == nil { arg_717 = ifn_721.Invoke_O__O(arg_722) } else { arg_717 = linked_720.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_719, arg_722) }; var arg_718 any; if linked_715 == nil { return ifn_716.Invoke_O_O__O(arg_717, arg_718) } else { return linked_715.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_714, arg_717, arg_718) } } } else { var x__4 any; var root_723 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_723, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_725 lang.IFn; if linked_724 == nil { ifn_725 = lang.IFn_Cast(root_723) } else { ifn_725 = nil }; var arg_726 any = s__794000107__3; if linked_724 == nil { x__4 = ifn_725.Invoke_O__O(arg_726) } else { x__4 = linked_724.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_723, arg_726) }; var root_727 any = A_arbace_go_repl_A_const_100.GetRawRoot__O(); var linked_728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_727, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_729 lang.IFn; if linked_728 == nil { ifn_729 = lang.IFn_Cast(root_727) } else { ifn_729 = nil }; var arg_730 any; var root_732 any = A_arbace_go_repl_A_const_73.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_732, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_734 lang.IFn; if linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = x__4; if linked_733 == nil { arg_730 = ifn_734.Invoke_O__O(arg_735) } else { arg_730 = linked_733.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_732, arg_735) }; var arg_731 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__794000106); var tmp7 any; var root_736 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_736, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_738 lang.IFn; if linked_737 == nil { ifn_738 = lang.IFn_Cast(root_736) } else { ifn_738 = nil }; var arg_739 any = s__794000107__3; if linked_737 == nil { tmp7 = ifn_738.Invoke_O__O(arg_739) } else { tmp7 = linked_737.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_736, arg_739) }; arg_731 = tmp6.Invoke_O__O(tmp7); if linked_728 == nil { return ifn_729.Invoke_O_O__O(arg_730, arg_731) } else { return linked_728.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_727, arg_730, arg_731) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :158:1
func A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_fn__794000117_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_fn__794000117_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_fn__794000117_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_fn__794000117_A) Ctor_O_I_O(c__b__794000109 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__794000109 = c__b__794000109; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :158:1
func (t *A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_fn__794000117_A) Invoke_O__O(self any) any { { var i__794000108__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__794000108__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var x__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__794000108__1)); var root_691 any = A_arbace_go_repl_A_const_96.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_693 lang.IFn; if linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any = t.F_b__794000109; var arg_695 any; var root_696 any = A_arbace_go_repl_A_const_73.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_696, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_698 lang.IFn; if linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any = x__2; if linked_697 == nil { arg_695 = ifn_698.Invoke_O__O(arg_699) } else { arg_695 = linked_697.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_696, arg_699) }; if linked_692 == nil { ifn_693.Invoke_O_O__O(arg_694, arg_695) } else { linked_692.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_691, arg_694, arg_695) }; i__794000108__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000108__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_go_repl_decl_names_iter__794000069__794000073_A_New() *A_arbace_go_repl_decl_names_iter__794000069__794000073_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_iter__794000069__794000073_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_go_repl_decl_names_iter__794000069__794000073_A) Ctor() {}
//line :161:1
func (t *A_arbace_go_repl_decl_names_iter__794000069__794000073_A) Invoke_O_O__O(self, s__794000070__1 any) any { var tmp1 any = A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_A_New_O_O(s__794000070__1, self); var tmp2 *jrt.Class; var fncls__550 *jrt.Class = A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_A_fn_class; if fncls__550 == nil { var fncls__550d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_A_fn_class = fncls__550d; tmp2 = fncls__550d } else { tmp2 = fncls__550 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :161:1
func A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_A_New_O_O(p0, p1 any) *A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_A{}; t.Ctor_O_O(p0, p1); return t }
//line :161:1
func (t *A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_A) Ctor_O_O(c__s__794000070, c__iter__794000069 any) { t.F_s__794000070 = c__s__794000070; t.F_iter__794000069 = c__iter__794000069 }
//line :161:1
func (t *A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_A) Invoke_O__O(self any) any { { var s__794000070__1 any; var t_ any = t.F_s__794000070; t.F_s__794000070 = nil; s__794000070__1 = t_; for { var temp__1927000414__auto____2 any; var root_485 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_487 lang.IFn; if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = s__794000070__1; if linked_486 == nil { temp__1927000414__auto____2 = ifn_487.Invoke_O__O(arg_488) } else { temp__1927000414__auto____2 = linked_486.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_485, arg_488) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__794000070__3 any = temp__1927000414__auto____2; var tmp1 any; var root_489 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_489, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_491 lang.IFn; if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any = s__794000070__3; if linked_490 == nil { tmp1 = ifn_491.Invoke_O__O(arg_492) } else { tmp1 = linked_490.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_489, arg_492) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_493 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_493, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_495 lang.IFn; if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any = s__794000070__3; if linked_494 == nil { c__1927001037__auto____4 = ifn_495.Invoke_O__O(arg_496) } else { c__1927001037__auto____4 = linked_494.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_493, arg_496) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__794000072__6 any; var root_497 any = A_arbace_go_repl_A_const_95.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_499 lang.IFn; if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_498 == nil { b__794000072__6 = ifn_499.Invoke_O__O(arg_500) } else { b__794000072__6 = linked_498.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_497, arg_500) }; var tmp2 any = A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_fn__794000075_A_New_O_I_O(b__794000072__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__510 *jrt.Class = A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_fn__794000075_A_fn_class; if fncls__510 == nil { var fncls__510d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_fn__794000075_A_fn_class = fncls__510d; tmp3 = fncls__510d } else { tmp3 = fncls__510 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_511 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any; var root_516 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_516, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_518 lang.IFn; if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any = b__794000072__6; if linked_517 == nil { arg_514 = ifn_518.Invoke_O__O(arg_519) } else { arg_514 = linked_517.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_516, arg_519) }; var arg_515 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__794000069); var tmp5 any; var root_520 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_520, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_522 lang.IFn; if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any = s__794000070__3; if linked_521 == nil { tmp5 = ifn_522.Invoke_O__O(arg_523) } else { tmp5 = linked_521.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_520, arg_523) }; arg_515 = tmp4.Invoke_O__O(tmp5); if linked_512 == nil { return ifn_513.Invoke_O_O__O(arg_514, arg_515) } else { return linked_512.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_511, arg_514, arg_515) } } else { var root_524 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_524, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_526 lang.IFn; if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any; var root_529 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = b__794000072__6; if linked_530 == nil { arg_527 = ifn_531.Invoke_O__O(arg_532) } else { arg_527 = linked_530.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_529, arg_532) }; var arg_528 any; if linked_525 == nil { return ifn_526.Invoke_O_O__O(arg_527, arg_528) } else { return linked_525.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_524, arg_527, arg_528) } } } else { var vec__794000080__4 any; var root_533 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_535 lang.IFn; if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = s__794000070__3; if linked_534 == nil { vec__794000080__4 = ifn_535.Invoke_O__O(arg_536) } else { vec__794000080__4 = linked_534.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_533, arg_536) }; var nf__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000080__4, lang.RT_IntCast_J__I_NoInit(0), nil); var root_537 any = A_arbace_go_repl_A_const_100.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any; var root_542 any = A_arbace_go_repl_A_const_73.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any = nf__5; if linked_543 == nil { arg_540 = ifn_544.Invoke_O__O(arg_545) } else { arg_540 = linked_543.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_542, arg_545) }; var arg_541 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__794000069); var tmp7 any; var root_546 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_546, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_548 lang.IFn; if linked_547 == nil { ifn_548 = lang.IFn_Cast(root_546) } else { ifn_548 = nil }; var arg_549 any = s__794000070__3; if linked_547 == nil { tmp7 = ifn_548.Invoke_O__O(arg_549) } else { tmp7 = linked_547.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_546, arg_549) }; arg_541 = tmp6.Invoke_O__O(tmp7); if linked_538 == nil { return ifn_539.Invoke_O_O__O(arg_540, arg_541) } else { return linked_538.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_537, arg_540, arg_541) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :161:1
func A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_fn__794000075_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_fn__794000075_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_fn__794000075_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :161:1
func (t *A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_fn__794000075_A) Ctor_O_I_O(c__b__794000072 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__794000072 = c__b__794000072; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :161:1
func (t *A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_fn__794000075_A) Invoke_O__O(self any) any { { var i__794000071__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__794000071__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__794000076__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__794000071__1)); var nf__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000076__2, lang.RT_IntCast_J__I_NoInit(0), nil); var root_501 any = A_arbace_go_repl_A_const_96.GetRawRoot__O(); var linked_502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_501, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_503 lang.IFn; if linked_502 == nil { ifn_503 = lang.IFn_Cast(root_501) } else { ifn_503 = nil }; var arg_504 any = t.F_b__794000072; var arg_505 any; var root_506 any = A_arbace_go_repl_A_const_73.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_508 lang.IFn; if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = nf__3; if linked_507 == nil { arg_505 = ifn_508.Invoke_O__O(arg_509) } else { arg_505 = linked_507.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_506, arg_509) }; if linked_502 == nil { ifn_503.Invoke_O_O__O(arg_504, arg_505) } else { linked_502.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_501, arg_504, arg_505) }; i__794000071__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000071__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_go_repl_error_text_A_New() *A_arbace_go_repl_error_text_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_error_text_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_go_repl_error_text_A) Ctor() {}
//line :167:1
func (t *A_arbace_go_repl_error_text_A) Invoke_O_O_O__O(self, errs__0, src__1 any) any {




	var root_856 any = A_arbace_go_repl_A_const_48.GetRawRoot__O(); var linked_857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_856, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_858 lang.IFn; if linked_857 == nil { ifn_858 = lang.IFn_Cast(root_856) } else { ifn_858 = nil }; var arg_859 any = Lit_124; var arg_860 any; var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_go_repl_error_text_iter__794000124__794000128_A_New_O(src__1); var tmp2 *jrt.Class; var fncls__919 *jrt.Class = A_arbace_go_repl_error_text_iter__794000124__794000128_A_fn_class; if fncls__919 == nil { var fncls__919d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_125, false); A_arbace_go_repl_error_text_iter__794000124__794000128_A_fn_class = fncls__919d; tmp2 = fncls__919d } else { tmp2 = fncls__919 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var root_920 any = A_arbace_go_repl_A_const_113.GetRawRoot__O(); var linked_921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_920, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_922 lang.IFn; if linked_921 == nil { ifn_922 = lang.IFn_Cast(root_920) } else { ifn_922 = nil }; var arg_923 any = A_arbace_go_repl_A_const_114; var arg_924 any = errs__0; if linked_921 == nil { tmp4 = ifn_922.Invoke_O_O__O(arg_923, arg_924) } else { tmp4 = linked_921.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_920, arg_923, arg_924) }; arg_860 = tmp3.Invoke_O__O(tmp4); if linked_857 == nil { return ifn_858.Invoke_O_O__O(arg_859, arg_860) } else { return linked_857.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_856, arg_859, arg_860) } }
//line :167:1
func (t *A_arbace_go_repl_error_text_A) Invoke_O_O__O(self, errs__0 any) any {


	var root_925 any = A_arbace_go_repl_A_const_115.GetRawRoot__O(); var linked_926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_925, A_arbace_go_repl_error_text_A_fn_class); var ifn_927 lang.IFn; if linked_926 == nil { ifn_927 = lang.IFn_Cast(root_925) } else { ifn_927 = nil }; var arg_928 any = errs__0; var arg_929 any; if linked_926 == nil { return ifn_927.Invoke_O_O__O(arg_928, arg_929) } else { return linked_926.(*A_arbace_go_repl_error_text_A).Invoke_O_O_O__O(root_925, arg_928, arg_929)
	} }
func A_arbace_go_repl_error_text_iter__794000124__794000128_A_New_O(p0 any) *A_arbace_go_repl_error_text_iter__794000124__794000128_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_error_text_iter__794000124__794000128_A{}; t.Ctor_O(p0); return t }
//line :172:1
func (t *A_arbace_go_repl_error_text_iter__794000124__794000128_A) Ctor_O(c__src any) { t.F_src = c__src }
//line :172:1
func (t *A_arbace_go_repl_error_text_iter__794000124__794000128_A) Invoke_O_O__O(self, s__794000125__1 any) any { var tmp1 any = A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_A_New_O_O_O(s__794000125__1, t.F_src, self); var tmp2 *jrt.Class; var fncls__918 *jrt.Class = A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_A_fn_class; if fncls__918 == nil { var fncls__918d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_126, false); A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_A_fn_class = fncls__918d; tmp2 = fncls__918d } else { tmp2 = fncls__918 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :172:1
func A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :172:1
func (t *A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_A) Ctor_O_O_O(c__s__794000125, c__src, c__iter__794000124 any) { t.F_s__794000125 = c__s__794000125; t.F_src = c__src; t.F_iter__794000124 = c__iter__794000124 }
//line :172:1
func (t *A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_A) Invoke_O__O(self any) any { { var s__794000125__1 any; var t_ any = t.F_s__794000125; t.F_s__794000125 = nil; s__794000125__1 = t_; for { var temp__1927000414__auto____2 any; var root_861 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = s__794000125__1; if linked_862 == nil { temp__1927000414__auto____2 = ifn_863.Invoke_O__O(arg_864) } else { temp__1927000414__auto____2 = linked_862.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_861, arg_864) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__794000125__3 any = temp__1927000414__auto____2; var tmp1 any; var root_865 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = s__794000125__3; if linked_866 == nil { tmp1 = ifn_867.Invoke_O__O(arg_868) } else { tmp1 = linked_866.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_865, arg_868) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_869 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = s__794000125__3; if linked_870 == nil { c__1927001037__auto____4 = ifn_871.Invoke_O__O(arg_872) } else { c__1927001037__auto____4 = linked_870.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_869, arg_872) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__794000127__6 any; var root_873 any = A_arbace_go_repl_A_const_95.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_874 == nil { b__794000127__6 = ifn_875.Invoke_O__O(arg_876) } else { b__794000127__6 = linked_874.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_873, arg_876) }; var tmp2 any = A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_fn__794000130_A_New_O_O_I_O(t.F_src, b__794000127__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__882 *jrt.Class = A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_fn__794000130_A_fn_class; if fncls__882 == nil { var fncls__882d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_127, false); A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_fn__794000130_A_fn_class = fncls__882d; tmp3 = fncls__882d } else { tmp3 = fncls__882 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_883 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_883, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_885 lang.IFn; if linked_884 == nil { ifn_885 = lang.IFn_Cast(root_883) } else { ifn_885 = nil }; var arg_886 any; var root_888 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_888, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_890 lang.IFn; if linked_889 == nil { ifn_890 = lang.IFn_Cast(root_888) } else { ifn_890 = nil }; var arg_891 any = b__794000127__6; if linked_889 == nil { arg_886 = ifn_890.Invoke_O__O(arg_891) } else { arg_886 = linked_889.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_888, arg_891) }; var arg_887 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__794000124); var tmp5 any; var root_892 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_892, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_894 lang.IFn; if linked_893 == nil { ifn_894 = lang.IFn_Cast(root_892) } else { ifn_894 = nil }; var arg_895 any = s__794000125__3; if linked_893 == nil { tmp5 = ifn_894.Invoke_O__O(arg_895) } else { tmp5 = linked_893.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_892, arg_895) }; arg_887 = tmp4.Invoke_O__O(tmp5); if linked_884 == nil { return ifn_885.Invoke_O_O__O(arg_886, arg_887) } else { return linked_884.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_883, arg_886, arg_887) } } else { var root_896 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_896, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_898 lang.IFn; if linked_897 == nil { ifn_898 = lang.IFn_Cast(root_896) } else { ifn_898 = nil }; var arg_899 any; var root_901 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_901, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_903 lang.IFn; if linked_902 == nil { ifn_903 = lang.IFn_Cast(root_901) } else { ifn_903 = nil }; var arg_904 any = b__794000127__6; if linked_902 == nil { arg_899 = ifn_903.Invoke_O__O(arg_904) } else { arg_899 = linked_902.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_901, arg_904) }; var arg_900 any; if linked_897 == nil { return ifn_898.Invoke_O_O__O(arg_899, arg_900) } else { return linked_897.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_896, arg_899, arg_900) } } } else { var er__4 any; var root_905 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_905, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_907 lang.IFn; if linked_906 == nil { ifn_907 = lang.IFn_Cast(root_905) } else { ifn_907 = nil }; var arg_908 any = s__794000125__3; if linked_906 == nil { er__4 = ifn_907.Invoke_O__O(arg_908) } else { er__4 = linked_906.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_905, arg_908) }; var root_909 any = A_arbace_go_repl_A_const_100.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_911 lang.IFn; if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_128, nil, Lit_129, nil); var tmp7 any; var tmp8 any; var and__1927000168__auto____10 any = t.F_src
														if jrt.J2g_Truth(and__1927000168__auto____10) { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_130, A_arbace_go_repl_A_const_110.Invoke_O__O(er__4))).Ref() } else { tmp8 = and__1927000168__auto____10 }; if jrt.J2g_Truth(tmp8) { tmp7 = t.F_src } else { tmp7 = A_arbace_go_repl_A_const_110.Invoke_O__O(er__4) }; arg_912 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7, nil, A_arbace_go_repl_A_const_111.Invoke_O__O(er__4), nil, A_arbace_go_repl_A_const_112.Invoke_O__O(er__4))).Ref()
//line :172:1
	var arg_913 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__794000124); var tmp10 any; var root_914 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_914, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_916 lang.IFn; if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any = s__794000125__3; if linked_915 == nil { tmp10 = ifn_916.Invoke_O__O(arg_917) } else { tmp10 = linked_915.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_914, arg_917) }; arg_913 = tmp9.Invoke_O__O(tmp10); if linked_910 == nil { return ifn_911.Invoke_O_O__O(arg_912, arg_913) } else { return linked_910.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_909, arg_912, arg_913) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :172:1
func A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_fn__794000130_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_fn__794000130_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_fn__794000130_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :172:1
func (t *A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_fn__794000130_A) Ctor_O_O_I_O(c__src, c__b__794000127 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_src = c__src; t.F_b__794000127 = c__b__794000127; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :172:1
func (t *A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_fn__794000130_A) Invoke_O__O(self any) any { { var i__794000126__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__794000126__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var er__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__794000126__1)); var root_877 any = A_arbace_go_repl_A_const_96.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_879 lang.IFn; if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any = t.F_b__794000127; var arg_881 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_128, nil, Lit_129, nil); var tmp3 any; var tmp4 any; var and__1927000168__auto____8 any = t.F_src
																if jrt.J2g_Truth(and__1927000168__auto____8) { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_130, A_arbace_go_repl_A_const_110.Invoke_O__O(er__2))).Ref() } else { tmp4 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp4) { tmp3 = t.F_src } else { tmp3 = A_arbace_go_repl_A_const_110.Invoke_O__O(er__2) }; arg_881 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, A_arbace_go_repl_A_const_111.Invoke_O__O(er__2), nil, A_arbace_go_repl_A_const_112.Invoke_O__O(er__2))).Ref()
//line :172:1
	if linked_878 == nil { ifn_879.Invoke_O_O__O(arg_880, arg_881) } else { linked_878.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_877, arg_880, arg_881) }; i__794000126__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000126__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_go_repl_repl_source_A_New() *A_arbace_go_repl_repl_source_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_repl_source_A{}; t.Ctor(); return t }
//line :175:1
func (t *A_arbace_go_repl_repl_source_A) Ctor() {}
//line :175:1
func (t *A_arbace_go_repl_repl_source_A) Invoke_O__O(self any) any { var f__1 any; var root_930 any = A_arbace_go_repl_A_const_51.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_930, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_932 lang.IFn; if linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any = A_arbace_go_repl_A_const_116.Get__O(); if linked_931 == nil { f__1 = ifn_932.Invoke_O__O(arg_933) } else { f__1 = linked_931.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_930, arg_933) }; var tmp1 bool; var or__1927000174__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(f__1, Lit_165); if or__1927000174__auto____2 { tmp1 = or__1927000174__auto____2 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(f__1, Lit_166) }; if tmp1 { return Lit_167 } else { return f__1 } }

func A_arbace_go_repl_source_of_A_New() *A_arbace_go_repl_source_of_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_source_of_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_go_repl_source_of_A) Ctor() {}
//line :177:1
func (t *A_arbace_go_repl_source_of_A) Invoke_O_O__O(self, st__0 any) any { var s__2 any; var root_934 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_934, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_936 lang.IFn; if


	linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any = st__0; if linked_935 == nil { s__2 = ifn_936.Invoke_O__O(arg_937) } else { s__2 = linked_935.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_934, arg_937) }; var tmp1 any = A_arbace_go_repl_A_const_54; var tmp2 any = /*line :177:1*/A_arbace_go_repl_A_const_54.Invoke_O__O(s__2); var tmp3 any = A_arbace_go_repl_A_const_55; var tmp4 any = A_arbace_go_repl_A_const_55.Invoke_O__O(s__2); var tmp5 any = A_arbace_go_repl_A_const_36; var tmp6 any = A_arbace_go_repl_A_const_36.Invoke_O__O(s__2); var tmp7 any = A_arbace_go_repl_A_const_74; var tmp8 any; var or__1927000174__auto____3 any = A_arbace_go_repl_A_const_74.Invoke_O__O(s__2); if



	jrt.J2g_Truth(or__1927000174__auto____3) { tmp8 = or__1927000174__auto____3 } else { tmp8 = lang.PersistentArrayMap_EMPTY.Ref() }; var tmp9 any = tmp8; var tmp10 any = A_arbace_go_repl_A_const_57; var tmp11 any; var root_938 any = /*line :177:1*/A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_938, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_940 lang.IFn; if




	linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any; var iter__1927001039__auto____3 any; var tmp12 any = A_arbace_go_repl_source_of_iter__794000136__794000140_A_New(); var tmp13 *jrt.Class; var fncls__1012 *jrt.Class = A_arbace_go_repl_source_of_iter__794000136__794000140_A_fn_class; if fncls__1012 == nil { var fncls__1012d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_171, false); A_arbace_go_repl_source_of_iter__794000136__794000140_A_fn_class = fncls__1012d; tmp13 = fncls__1012d } else { tmp13 = fncls__1012 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); arg_941 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(A_arbace_go_repl_A_const_57.Invoke_O__O(s__2)); if linked_939 == nil { tmp11 = ifn_940.Invoke_O__O(arg_941) } else { tmp11 = linked_939.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_938, arg_941) }; return /*line :177:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp9, tmp10, tmp11)) }




func A_arbace_go_repl_source_of_iter__794000136__794000140_A_New() *A_arbace_go_repl_source_of_iter__794000136__794000140_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_source_of_iter__794000136__794000140_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_go_repl_source_of_iter__794000136__794000140_A) Ctor() {}
//line :182:1
func (t *A_arbace_go_repl_source_of_iter__794000136__794000140_A) Invoke_O_O__O(self, s__794000137__1 any) any { var tmp1 any = A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_A_New_O_O(s__794000137__1, self); var tmp2 *jrt.Class; var fncls__1011 *jrt.Class = A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_A_fn_class; if fncls__1011 == nil { var fncls__1011d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_172, false); A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_A_fn_class = fncls__1011d; tmp2 = fncls__1011d } else { tmp2 = fncls__1011 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :182:1
func A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_A_New_O_O(p0, p1 any) *A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_A{}; t.Ctor_O_O(p0, p1); return t }
//line :182:1
func (t *A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_A) Ctor_O_O(c__s__794000137, c__iter__794000136 any) { t.F_s__794000137 = c__s__794000137; t.F_iter__794000136 = c__iter__794000136 }
//line :182:1
func (t *A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_A) Invoke_O__O(self any) any { { var s__794000137__1 any; var t_ any = t.F_s__794000137; t.F_s__794000137 = nil; s__794000137__1 = t_; for { var temp__1927000414__auto____2 any; var root_942 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_942, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_944 lang.IFn; if linked_943 == nil { ifn_944 = lang.IFn_Cast(root_942) } else { ifn_944 = nil }; var arg_945 any = s__794000137__1; if linked_943 == nil { temp__1927000414__auto____2 = ifn_944.Invoke_O__O(arg_945) } else { temp__1927000414__auto____2 = linked_943.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_942, arg_945) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__794000137__3 any = temp__1927000414__auto____2; var tmp1 any; var root_946 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_948 lang.IFn; if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any = s__794000137__3; if linked_947 == nil { tmp1 = ifn_948.Invoke_O__O(arg_949) } else { tmp1 = linked_947.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_946, arg_949) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_950 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_950, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_952 lang.IFn; if linked_951 == nil { ifn_952 = lang.IFn_Cast(root_950) } else { ifn_952 = nil }; var arg_953 any = s__794000137__3; if linked_951 == nil { c__1927001037__auto____4 = ifn_952.Invoke_O__O(arg_953) } else { c__1927001037__auto____4 = linked_951.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_950, arg_953) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__794000139__6 any; var root_954 any = A_arbace_go_repl_A_const_95.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_954, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_956 lang.IFn; if linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; var arg_957 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_955 == nil { b__794000139__6 = ifn_956.Invoke_O__O(arg_957) } else { b__794000139__6 = linked_955.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_954, arg_957) }; var tmp2 any = A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_fn__794000142_A_New_O_I_O(b__794000139__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__969 *jrt.Class = A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_fn__794000142_A_fn_class; if fncls__969 == nil { var fncls__969d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_173, false); A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_fn__794000142_A_fn_class = fncls__969d; tmp3 = fncls__969d } else { tmp3 = fncls__969 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_970 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_970, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_972 lang.IFn; if linked_971 == nil { ifn_972 = lang.IFn_Cast(root_970) } else { ifn_972 = nil }; var arg_973 any; var root_975 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_975, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_977 lang.IFn; if linked_976 == nil { ifn_977 = lang.IFn_Cast(root_975) } else { ifn_977 = nil }; var arg_978 any = b__794000139__6; if linked_976 == nil { arg_973 = ifn_977.Invoke_O__O(arg_978) } else { arg_973 = linked_976.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_975, arg_978) }; var arg_974 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__794000136); var tmp5 any; var root_979 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_979, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_981 lang.IFn; if linked_980 == nil { ifn_981 = lang.IFn_Cast(root_979) } else { ifn_981 = nil }; var arg_982 any = s__794000137__3; if linked_980 == nil { tmp5 = ifn_981.Invoke_O__O(arg_982) } else { tmp5 = linked_980.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_979, arg_982) }; arg_974 = tmp4.Invoke_O__O(tmp5); if linked_971 == nil { return ifn_972.Invoke_O_O__O(arg_973, arg_974) } else { return linked_971.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_970, arg_973, arg_974) } } else { var root_983 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_983, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_985 lang.IFn; if linked_984 == nil { ifn_985 = lang.IFn_Cast(root_983) } else { ifn_985 = nil }; var arg_986 any; var root_988 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_990 lang.IFn; if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any = b__794000139__6; if linked_989 == nil { arg_986 = ifn_990.Invoke_O__O(arg_991) } else { arg_986 = linked_989.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_988, arg_991) }; var arg_987 any; if linked_984 == nil { return ifn_985.Invoke_O_O__O(arg_986, arg_987) } else { return linked_984.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_983, arg_986, arg_987) } } } else { var fi__4 any; var root_992 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_992, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_994 lang.IFn; if linked_993 == nil { ifn_994 = lang.IFn_Cast(root_992) } else { ifn_994 = nil }; var arg_995 any = s__794000137__3; if linked_993 == nil { fi__4 = ifn_994.Invoke_O__O(arg_995) } else { fi__4 = linked_993.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_992, arg_995) }; var root_996 any = A_arbace_go_repl_A_const_100.GetRawRoot__O(); var linked_997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_996, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_998 lang.IFn; if linked_997 == nil { ifn_998 = lang.IFn_Cast(root_996) } else { ifn_998 = nil }; var arg_999 any; var tmp6 any = A_arbace_go_repl_A_const_55; var tmp7 any = A_arbace_go_repl_A_const_55.Invoke_O__O(fi__4); var tmp8 any = A_arbace_go_repl_A_const_74; var tmp9 any; var root_1001 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var linked_1002 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1001, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1003 lang.IFn
														if linked_1002 == nil { ifn_1003 = lang.IFn_Cast(root_1001) } else { ifn_1003 = nil }; var arg_1004 any = A_arbace_go_repl_A_const_74.Invoke_O__O(fi__4); var arg_1005 any = A_arbace_go_repl_A_const_81; var arg_1006 any = A_arbace_go_repl_A_const_81.Invoke_O__O(fi__4); if linked_1002 == nil { tmp9 = ifn_1003.Invoke_O_O_O__O(arg_1004, arg_1005, arg_1006) } else { tmp9 = linked_1002.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1001, arg_1004, arg_1005, arg_1006) }
//line :182:1
	var tmp10 any = tmp9; var tmp11 any = A_arbace_go_repl_A_const_81; var tmp12 any = A_arbace_go_repl_A_const_81.Invoke_O__O(fi__4); var tmp13 any = A_arbace_go_repl_A_const_82; arg_999 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, tmp10, tmp11, tmp12, tmp13, A_arbace_go_repl_A_const_82.Invoke_O__O(fi__4))); var arg_1000 any; var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__794000136); var tmp15 any; var root_1007 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_1008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1007, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1009 lang.IFn; if linked_1008 == nil { ifn_1009 = lang.IFn_Cast(root_1007) } else { ifn_1009 = nil }; var arg_1010 any = s__794000137__3; if linked_1008 == nil { tmp15 = ifn_1009.Invoke_O__O(arg_1010) } else { tmp15 = linked_1008.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1007, arg_1010) }; arg_1000 = tmp14.Invoke_O__O(tmp15); if linked_997 == nil { return ifn_998.Invoke_O_O__O(arg_999, arg_1000) } else { return linked_997.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_996, arg_999, arg_1000) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :182:1
func A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_fn__794000142_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_fn__794000142_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_fn__794000142_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :182:1
func (t *A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_fn__794000142_A) Ctor_O_I_O(c__b__794000139 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__794000139 = c__b__794000139; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :182:1
func (t *A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_fn__794000142_A) Invoke_O__O(self any) any { { var i__794000138__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__794000138__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fi__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__794000138__1)); var root_958 any = A_arbace_go_repl_A_const_96.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_958, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any = t.F_b__794000139; var arg_962 any; var tmp2 any = A_arbace_go_repl_A_const_55; var tmp3 any = A_arbace_go_repl_A_const_55.Invoke_O__O(fi__2); var tmp4 any = A_arbace_go_repl_A_const_74; var tmp5 any; var root_963 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var linked_964 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_963, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_965 lang.IFn
															if linked_964 == nil { ifn_965 = lang.IFn_Cast(root_963) } else { ifn_965 = nil }; var arg_966 any = A_arbace_go_repl_A_const_74.Invoke_O__O(fi__2); var arg_967 any = A_arbace_go_repl_A_const_81; var arg_968 any = A_arbace_go_repl_A_const_81.Invoke_O__O(fi__2); if linked_964 == nil { tmp5 = ifn_965.Invoke_O_O_O__O(arg_966, arg_967, arg_968) } else { tmp5 = linked_964.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_963, arg_966, arg_967, arg_968) }
//line :182:1
	var tmp6 any = tmp5; var tmp7 any = A_arbace_go_repl_A_const_81; var tmp8 any = A_arbace_go_repl_A_const_81.Invoke_O__O(fi__2); var tmp9 any = A_arbace_go_repl_A_const_82; arg_962 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp6, tmp7, tmp8, tmp9, A_arbace_go_repl_A_const_82.Invoke_O__O(fi__2))); if linked_959 == nil { ifn_960.Invoke_O_O__O(arg_961, arg_962) } else { linked_959.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_958, arg_961, arg_962) }; i__794000138__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000138__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_go_repl_session_for_A_New() *A_arbace_go_repl_session_for_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_session_for_A{}; t.Ctor(); return t }
//line :188:1
func (t *A_arbace_go_repl_session_for_A) Ctor() {}
//line :188:1
func (t *A_arbace_go_repl_session_for_A) Invoke_O_O__O(self, extra_src__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_71.GetRawRoot__O()); var tmp2 any; var root_1021 any = A_arbace_go_repl_A_const_42.GetRawRoot__O(); var linked_1022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1021, aot_arbace_go_check.A_arbace_go_check_session_A_fn_class); var ifn_1023 lang.IFn; if linked_1022 == nil { ifn_1023 = lang.IFn_Cast(root_1021) } else { ifn_1023 = nil }; var arg_1024 any; var tmp3 any = A_arbace_go_repl_session_for_fn__794000147_A_New_O(extra_src__0); var tmp4 *jrt.Class; var fncls__1033 *jrt.Class = A_arbace_go_repl_session_for_fn__794000147_A_fn_class; if fncls__1033 == nil { var fncls__1033d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_169, false); A_arbace_go_repl_session_for_fn__794000147_A_fn_class = fncls__1033d; tmp4 = fncls__1033d } else { tmp4 = fncls__1033 }; arg_1024 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); if linked_1022 == nil { tmp2 = ifn_1023.Invoke_O__O(arg_1024) } else { tmp2 = linked_1022.(*aot_arbace_go_check.A_arbace_go_check_session_A).Invoke_O_O__O(root_1021, arg_1024) }; var tmp5 any = tmp2; var tmp6 any = A_arbace_go_repl_A_const_119; var tmp7 any; var root_1034 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_1035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1034, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1036 lang.IFn; if linked_1035 == nil { ifn_1036 = lang.IFn_Cast(root_1034) } else { ifn_1036 = nil }; var arg_1037 any = A_arbace_go_repl_A_const_120.GetRawRoot__O(); if linked_1035 == nil { tmp7 = ifn_1036.Invoke_O__O(arg_1037) } else { tmp7 = linked_1035.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1034, arg_1037) }; var tmp8 any = tmp7; var tmp9 any = A_arbace_go_repl_A_const_121; var tmp10 any = A_arbace_go_repl_session_for_fn__794000149_A_New(); var tmp11 *jrt.Class
	var fncls__1046 /*line :192:1*/*jrt.Class = A_arbace_go_repl_session_for_fn__794000149_A_fn_class




	if fncls__1046 == nil { var fncls__1046d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_170, false); A_arbace_go_repl_session_for_fn__794000149_A_fn_class = fncls__1046d; tmp11 = fncls__1046d } else { tmp11 = fncls__1046 }
//line :192:1
	return tmp1.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp8, tmp9, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)) }
//line :192:1
func A_arbace_go_repl_session_for_fn__794000147_A_New_O(p0 any) *A_arbace_go_repl_session_for_fn__794000147_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_session_for_fn__794000147_A{}; t.Ctor_O(p0); return t }
//line :192:1
func (t *A_arbace_go_repl_session_for_fn__794000147_A) Ctor_O(c__extra_src any) { t.F_extra_src = c__extra_src }
//line :192:1
func (t *A_arbace_go_repl_session_for_fn__794000147_A) Invoke_O_O_O__O(self, path__1, importer__2 any) any { var or__1927000174__auto____3 any; if
														jrt.J2g_Truth(t.F_extra_src) { or__1927000174__auto____3 = lang.IFn_Cast(t.F_extra_src).Invoke_O__O(path__1) } else { or__1927000174__auto____3 = nil }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var temp__1927000414__auto____4 any; var root_1025 any = A_arbace_go_repl_A_const_117.GetRawRoot__O(); var linked_1026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1025, A_arbace_go_repl_load_import_A_fn_class); var ifn_1027 lang.IFn
															if linked_1026 == nil { ifn_1027 = lang.IFn_Cast(root_1025) } else { ifn_1027 = nil }; var arg_1028 any = path__1; if linked_1026 == nil { temp__1927000414__auto____4 = ifn_1027.Invoke_O__O(arg_1028) } else { temp__1927000414__auto____4 = linked_1026.(*A_arbace_go_repl_load_import_A).Invoke_O_O__O(root_1025, arg_1028) }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var st__5 any = temp__1927000414__auto____4; var root_1029 any = A_arbace_go_repl_A_const_118.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1029, A_arbace_go_repl_source_of_A_fn_class); var ifn_1031 lang.IFn
																if linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any = st__5; if linked_1030 == nil { return ifn_1031.Invoke_O__O(arg_1032) } else { return linked_1030.(*A_arbace_go_repl_source_of_A).Invoke_O_O__O(root_1029, arg_1032) } } else {
//line :194:1
				return nil } } }


func A_arbace_go_repl_session_for_fn__794000149_A_New() *A_arbace_go_repl_session_for_fn__794000149_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_session_for_fn__794000149_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_go_repl_session_for_fn__794000149_A) Ctor() {}
//line :197:1
func (t *A_arbace_go_repl_session_for_fn__794000149_A) Invoke_O_O__O(self, path__1 any) any { var root_1038 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_1039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1038, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1040 lang.IFn; if linked_1039 == nil { ifn_1040 = lang.IFn_Cast(root_1038) } else { ifn_1040 = nil }; var arg_1041 any; var root_1042 any = A_arbace_go_repl_A_const_43.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1042, A_arbace_go_repl_listed_QMARK__A_fn_class); var ifn_1044 lang.IFn; if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any = path__1; if linked_1043 == nil { arg_1041 = ifn_1044.Invoke_O__O(arg_1045) } else { arg_1041 = linked_1043.(*A_arbace_go_repl_listed_QMARK__A).Invoke_O_O__O(root_1042, arg_1045) }; if linked_1039 == nil { return ifn_1040.Invoke_O__O(arg_1041) } else { return linked_1039.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1038, arg_1041) } }

func A_arbace_go_repl_check_source_A_New() *A_arbace_go_repl_check_source_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_check_source_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_go_repl_check_source_A) Ctor() {}
//line :199:1
func (t *A_arbace_go_repl_check_source_A) Invoke_O_O_O__O(self, src__0, extra_src__1 any) any { var s__3 any; var root_1047 any = A_arbace_go_repl_A_const_123.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1047, A_arbace_go_repl_session_for_A_fn_class); var ifn_1049 lang.IFn; if


	linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any = extra_src__1; if linked_1048 == nil { s__3 = ifn_1049.Invoke_O__O(arg_1050) } else { s__3 = linked_1048.(*A_arbace_go_repl_session_for_A).Invoke_O_O__O(root_1047, arg_1050) }; var pkg__4 any = /*line :199:1*/lang.IFn_Cast(A_arbace_go_repl_A_const_124.GetRawRoot__O()).Invoke_O_O_O_O__O(src__0, A_arbace_go_repl_A_const_125.Invoke_O_O_O__O(s__3, src__0, lang.PersistentVector_EMPTY.Ref()), A_arbace_go_repl_A_const_126, jrt.Boolean_TRUE.Ref()); var root_1058 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1058, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1060 lang.IFn; if




	linked_1059 == nil { ifn_1060 = lang.IFn_Cast(root_1058) } else { ifn_1060 = nil }; var arg_1061 any = pkg__4; var arg_1062 any = A_arbace_go_repl_A_const_128; if linked_1059 == nil { return ifn_1060.Invoke_O_O__O(arg_1061, arg_1062) } else { return linked_1059.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1058, arg_1061, arg_1062) } }



func A_arbace_go_repl_type_key_A_New() *A_arbace_go_repl_type_key_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_type_key_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_go_repl_type_key_A) Ctor() {}
//line :208:1
func (t *A_arbace_go_repl_type_key_A) Invoke_O_O_O__O(self, ty__0, gen_of__1 any) any {



	var tmp1 any; var root_1063 any = A_arbace_go_repl_A_const_129.GetRawRoot__O(); var linked_1064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1063, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_1065 lang.IFn
	if linked_1064 == nil { ifn_1065 = lang.IFn_Cast(root_1063) } else { ifn_1065 = nil }; var arg_1066 any = ty__0; if linked_1064 == nil { tmp1 = ifn_1065.Invoke_O__O(arg_1066) } else { tmp1 = linked_1064.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_1063, arg_1066) }
//line :212:1
	if jrt.J2g_Truth(tmp1) { return ty__0 } else { var tmp2 any; var root_1067 any = A_arbace_go_repl_A_const_130.GetRawRoot__O(); var linked_1068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1067, aot_arbace_go_check_types.A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_1069 lang.IFn

		if linked_1068 == nil { ifn_1069 = lang.IFn_Cast(root_1067) } else { ifn_1069 = nil }; var arg_1070 any = ty__0; if linked_1068 == nil { tmp2 = ifn_1069.Invoke_O__O(arg_1070) } else { tmp2 = linked_1068.(*aot_arbace_go_check_types.A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_1067, arg_1070) }
//line :212:1
		if jrt.J2g_Truth(tmp2) { var i__3 any; var root_1071 any = A_arbace_go_repl_A_const_131.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1071, aot_arbace_go_check_types.A_arbace_go_check_types_info_A_fn_class); var ifn_1073 lang.IFn

			if linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any = ty__0; if linked_1072 == nil { i__3 = ifn_1073.Invoke_O__O(arg_1074) } else { i__3 = linked_1072.(*aot_arbace_go_check_types.A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1071, arg_1074) }
//line :212:1
			var tmp3 any = A_arbace_go_repl_A_const_139; var tmp4 any = A_arbace_go_repl_A_const_140.Invoke_O__O(i__3); var tmp5 any = A_arbace_go_repl_A_const_55.Invoke_O__O(i__3); var tmp6 any

			if jrt.J2g_Truth(lang.IFn_Cast(gen_of__1).Invoke_O__O(ty__0)) { tmp6 = lang.IFn_Cast(gen_of__1).Invoke_O__O(ty__0) } else { tmp6 = nil }
//line :212:1
			return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp3, tmp4, tmp5, tmp6) } else { var tmp7 any; var root_1075 any = A_arbace_go_repl_A_const_132.GetRawRoot__O(); var linked_1076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1075, aot_arbace_go_check_types.A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_1077 lang.IFn


				if linked_1076 == nil { ifn_1077 = lang.IFn_Cast(root_1075) } else { ifn_1077 = nil }; var arg_1078 any = ty__0; if linked_1076 == nil { tmp7 = ifn_1077.Invoke_O__O(arg_1078) } else { tmp7 = linked_1076.(*aot_arbace_go_check_types.A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_1075, arg_1078) }
//line :212:1
				if jrt.J2g_Truth(tmp7) { var tmp8 any = A_arbace_go_repl_A_const_141; var tmp9 *lang.Keyword = A_arbace_go_repl_A_const_55; var tmp10 any; var root_1100 any = A_arbace_go_repl_A_const_131.GetRawRoot__O(); var linked_1101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1100, aot_arbace_go_check_types.A_arbace_go_check_types_info_A_fn_class); var ifn_1102 lang.IFn


					if linked_1101 == nil { ifn_1102 = lang.IFn_Cast(root_1100) } else { ifn_1102 = nil }; var arg_1103 any = ty__0; if linked_1101 == nil { tmp10 = ifn_1102.Invoke_O__O(arg_1103) } else { tmp10 = linked_1101.(*aot_arbace_go_check_types.A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1100, arg_1103) }
//line :212:1
					return lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9.Invoke_O__O(tmp10)) } else { if A_arbace_go_repl_A_const_133 != nil { var G__794000158__3_ any = lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(0))



						switch lang.Util_Hash_O__I_NoInit(G__794000158__3_) >> 16 & 7 { case 0: if any(G__794000158__3_) == any(A_arbace_go_repl_A_const_134) { var tmp11 any = A_arbace_go_repl_A_const_134; var tmp12 any = lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp13 any; var root_1104 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var linked_1105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1104, A_arbace_go_repl_type_key_A_fn_class); var ifn_1106 lang.IFn





							if linked_1105 == nil { ifn_1106 = lang.IFn_Cast(root_1104) } else { ifn_1106 = nil }; var arg_1107 any = lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(2)); var arg_1108 any = gen_of__1; if linked_1105 == nil { tmp13 = ifn_1106.Invoke_O_O__O(arg_1107, arg_1108) } else { tmp13 = linked_1105.(*A_arbace_go_repl_type_key_A).Invoke_O_O_O__O(root_1104, arg_1107, arg_1108) }
//line :216:1
							return lang.Tuple_Create_O_O_O__IPersistentVector(tmp11, tmp12, tmp13) }; case 1: if any(G__794000158__3_) == any(A_arbace_go_repl_A_const_135) { var tmp14 any = A_arbace_go_repl_A_const_135; var tmp15 any; var root_1109 any = A_arbace_go_repl_A_const_80.GetRawRoot__O(); var linked_1110 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1109, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1111 lang.IFn
								if linked_1110 == nil { ifn_1111 = lang.IFn_Cast(root_1109) } else { ifn_1111 = nil }; var arg_1112 any; var tmp16 any = A_arbace_go_repl_type_key_fn__794000159_A_New_O(gen_of__1); var tmp17 *jrt.Class; var fncls__1126 *jrt.Class = A_arbace_go_repl_type_key_fn__794000159_A_fn_class; if fncls__1126 == nil { var fncls__1126d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_174, false); A_arbace_go_repl_type_key_fn__794000159_A_fn_class = fncls__1126d; tmp17 = fncls__1126d } else { tmp17 = fncls__1126 }; arg_1112 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var arg_1113 any = lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1110 == nil { tmp15 = ifn_1111.Invoke_O_O__O(arg_1112, arg_1113) } else { tmp15 = linked_1110.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1109, arg_1112, arg_1113) }
//line :216:1
								return lang.Tuple_Create_O_O__IPersistentVector(tmp14, tmp15) }; case 2: if any(G__794000158__3_) == any(A_arbace_go_repl_A_const_136) { var tmp18 any = A_arbace_go_repl_A_const_136; var tmp19 any = lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp20 any; var root_1127 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var linked_1128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1127, A_arbace_go_repl_type_key_A_fn_class); var ifn_1129 lang.IFn




									if linked_1128 == nil { ifn_1129 = lang.IFn_Cast(root_1127) } else { ifn_1129 = nil }; var arg_1130 any = lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(2)); var arg_1131 any = gen_of__1; if linked_1128 == nil { tmp20 = ifn_1129.Invoke_O_O__O(arg_1130, arg_1131) } else { tmp20 = linked_1128.(*A_arbace_go_repl_type_key_A).Invoke_O_O_O__O(root_1127, arg_1130, arg_1131) }
//line :216:1
									return lang.Tuple_Create_O_O_O__IPersistentVector(tmp18, tmp19, tmp20) }; case 3: if any(G__794000158__3_) == any(A_arbace_go_repl_A_const_137) { var tmp21 any = A_arbace_go_repl_A_const_137; var tmp22 any; var root_1132 any = A_arbace_go_repl_A_const_80.GetRawRoot__O(); var linked_1133 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1132, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1134 lang.IFn


										if linked_1133 == nil { ifn_1134 = lang.IFn_Cast(root_1132) } else { ifn_1134 = nil }; var arg_1135 any; var tmp23 any = A_arbace_go_repl_type_key_fn__794000161_A_New_O(gen_of__1); var tmp24 *jrt.Class; var fncls__1142 *jrt.Class = A_arbace_go_repl_type_key_fn__794000161_A_fn_class; if fncls__1142 == nil { var fncls__1142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_175, false); A_arbace_go_repl_type_key_fn__794000161_A_fn_class = fncls__1142d; tmp24 = fncls__1142d } else { tmp24 = fncls__1142 }; arg_1135 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); var arg_1136 any = lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1133 == nil { tmp22 = ifn_1134.Invoke_O_O__O(arg_1135, arg_1136) } else { tmp22 = linked_1133.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1132, arg_1135, arg_1136) }
//line :216:1
										var tmp25 any = tmp22; var tmp26 any; var root_1143 any = A_arbace_go_repl_A_const_80.GetRawRoot__O(); var linked_1144 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1143, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1145 lang.IFn


										if linked_1144 == nil { ifn_1145 = lang.IFn_Cast(root_1143) } else { ifn_1145 = nil }; var arg_1146 any; var tmp27 any = A_arbace_go_repl_type_key_fn__794000163_A_New_O(gen_of__1); var tmp28 *jrt.Class; var fncls__1153 *jrt.Class = A_arbace_go_repl_type_key_fn__794000163_A_fn_class; if fncls__1153 == nil { var fncls__1153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_176, false); A_arbace_go_repl_type_key_fn__794000163_A_fn_class = fncls__1153d; tmp28 = fncls__1153d } else { tmp28 = fncls__1153 }; arg_1146 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil); var arg_1147 any = lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_1144 == nil { tmp26 = ifn_1145.Invoke_O_O__O(arg_1146, arg_1147) } else { tmp26 = linked_1144.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1143, arg_1146, arg_1147) }
//line :216:1
										return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp21, tmp25, tmp26, lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(3))) }; case 4: if any(G__794000158__3_) == any(A_arbace_go_repl_A_const_143) { var tmp29 any = A_arbace_go_repl_A_const_143; return lang.Tuple_Create_O_O__IPersistentVector(tmp29, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(1)))).Ref()) }; case 5: if any(G__794000158__3_) == any(A_arbace_go_repl_A_const_144) {



											var root_1154 any = A_arbace_go_repl_A_const_88.GetRawRoot__O(); var linked_1155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1154, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1156 lang.IFn; if linked_1155 == nil { ifn_1156 = lang.IFn_Cast(root_1154) } else { ifn_1156 = nil }; var arg_1157 any = A_arbace_go_repl_A_const_145; var arg_1158 any; var root_1159 any = A_arbace_go_repl_A_const_102.GetRawRoot__O(); var linked_1160 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1159, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1161 lang.IFn; if linked_1160 == nil { ifn_1161 = lang.IFn_Cast(root_1159) } else { ifn_1161 = nil }; var arg_1162 any; var tmp30 any = A_arbace_go_repl_type_key_fn__794000165_A_New_O(gen_of__1); var tmp31 *jrt.Class; var fncls__1169 *jrt.Class = A_arbace_go_repl_type_key_fn__794000165_A_fn_class; if fncls__1169 == nil { var fncls__1169d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_177, false); A_arbace_go_repl_type_key_fn__794000165_A_fn_class = fncls__1169d; tmp31 = fncls__1169d } else { tmp31 = fncls__1169 }; arg_1162 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp30, tmp31, nil); var arg_1163 any; var root_1170 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_1171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1170, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1172 lang.IFn; if linked_1171 == nil { ifn_1172 = lang.IFn_Cast(root_1170) } else { ifn_1172 = nil }; var arg_1173 any = ty__0; if linked_1171 == nil { arg_1163 = ifn_1172.Invoke_O__O(arg_1173) } else { arg_1163 = linked_1171.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1170, arg_1173) }; if linked_1160 == nil { arg_1158 = ifn_1161.Invoke_O_O__O(arg_1162, arg_1163) } else { arg_1158 = linked_1160.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1159, arg_1162, arg_1163) }; if linked_1155 == nil { return ifn_1156.Invoke_O_O__O(arg_1157, arg_1158) } else { return linked_1155.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1154, arg_1157, arg_1158) } }
//line :216:1
						default:
						}





						var root_1080 any = A_arbace_go_repl_A_const_88.GetRawRoot__O(); var linked_1081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1080, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1082 lang.IFn; if linked_1081 == nil { ifn_1082 = lang.IFn_Cast(root_1080) } else { ifn_1082 = nil }; var arg_1083 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(0))); var arg_1084 any; var root_1085 any = A_arbace_go_repl_A_const_102.GetRawRoot__O(); var linked_1086 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1085, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1087 lang.IFn; if linked_1086 == nil { ifn_1087 = lang.IFn_Cast(root_1085) } else { ifn_1087 = nil }; var arg_1088 any; var tmp32 any = A_arbace_go_repl_type_key_fn__794000167_A_New_O(gen_of__1); var tmp33 *jrt.Class; var fncls__1095 *jrt.Class = A_arbace_go_repl_type_key_fn__794000167_A_fn_class; if fncls__1095 == nil { var fncls__1095d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_178, false); A_arbace_go_repl_type_key_fn__794000167_A_fn_class = fncls__1095d; tmp33 = fncls__1095d } else { tmp33 = fncls__1095 }; arg_1088 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp32, tmp33, nil); var arg_1089 any; var root_1096 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1098 lang.IFn; if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any = ty__0; if linked_1097 == nil { arg_1089 = ifn_1098.Invoke_O__O(arg_1099) } else { arg_1089 = linked_1097.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1096, arg_1099) }; if linked_1086 == nil { arg_1084 = ifn_1087.Invoke_O_O__O(arg_1088, arg_1089) } else { arg_1084 = linked_1086.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1085, arg_1088, arg_1089) }; if linked_1081 == nil { return ifn_1082.Invoke_O_O__O(arg_1083, arg_1084) } else { return linked_1081.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1080, arg_1083, arg_1084) } } else {
//line :212:1
							return nil
						}
					}
			}
	} }
func A_arbace_go_repl_type_key_fn__794000159_A_New_O(p0 any) *A_arbace_go_repl_type_key_fn__794000159_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_type_key_fn__794000159_A{}; t.Ctor_O(p0); return t }
//line :217:1
func (t *A_arbace_go_repl_type_key_fn__794000159_A) Ctor_O(c__gen_of any) { t.F_gen_of = c__gen_of }
//line :217:1
func (t *A_arbace_go_repl_type_key_fn__794000159_A) Invoke_O_O__O(self, p1__794000153_SHARP___1 any) any { var root_1114 any = A_arbace_go_repl_A_const_84.GetRawRoot__O(); var linked_1115 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1114, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_1116 lang.IFn; if linked_1115 == nil { ifn_1116 = lang.IFn_Cast(root_1114) } else { ifn_1116 = nil }; var arg_1117 any; var root_1119 any = A_arbace_go_repl_A_const_79.GetRawRoot__O(); var linked_1120 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1119, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1121 lang.IFn; if linked_1120 == nil { ifn_1121 = lang.IFn_Cast(root_1119) } else { ifn_1121 = nil }; var arg_1122 any = p1__794000153_SHARP___1; var arg_1123 any = A_arbace_go_repl_A_const_142; var arg_1124 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var arg_1125 any = t.F_gen_of; if linked_1120 == nil { arg_1117 = ifn_1121.Invoke_O_O_O_O__O(arg_1122, arg_1123, arg_1124, arg_1125) } else { arg_1117 = linked_1120.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1119, arg_1122, arg_1123, arg_1124, arg_1125) }; var arg_1118 any = A_arbace_go_repl_A_const_140; if linked_1115 == nil { return ifn_1116.Invoke_O_O__O(arg_1117, arg_1118) } else { return linked_1115.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_1114, arg_1117, arg_1118) } }

func A_arbace_go_repl_type_key_fn__794000161_A_New_O(p0 any) *A_arbace_go_repl_type_key_fn__794000161_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_type_key_fn__794000161_A{}; t.Ctor_O(p0); return t }
//line :219:1
func (t *A_arbace_go_repl_type_key_fn__794000161_A) Ctor_O(c__gen_of any) { t.F_gen_of = c__gen_of }
//line :219:1
func (t *A_arbace_go_repl_type_key_fn__794000161_A) Invoke_O_O__O(self, p1__794000154_SHARP___1 any) any { var root_1137 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var linked_1138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1137, A_arbace_go_repl_type_key_A_fn_class); var ifn_1139 lang.IFn; if linked_1138 == nil { ifn_1139 = lang.IFn_Cast(root_1137) } else { ifn_1139 = nil }; var arg_1140 any = p1__794000154_SHARP___1; var arg_1141 any = t.F_gen_of; if linked_1138 == nil { return ifn_1139.Invoke_O_O__O(arg_1140, arg_1141) } else { return linked_1138.(*A_arbace_go_repl_type_key_A).Invoke_O_O_O__O(root_1137, arg_1140, arg_1141) } }
//line :219:1
func A_arbace_go_repl_type_key_fn__794000163_A_New_O(p0 any) *A_arbace_go_repl_type_key_fn__794000163_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_type_key_fn__794000163_A{}; t.Ctor_O(p0); return t }
//line :219:1
func (t *A_arbace_go_repl_type_key_fn__794000163_A) Ctor_O(c__gen_of any) { t.F_gen_of = c__gen_of }
//line :219:1
func (t *A_arbace_go_repl_type_key_fn__794000163_A) Invoke_O_O__O(self, p1__794000155_SHARP___1 any) any { var root_1148 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var linked_1149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1148, A_arbace_go_repl_type_key_A_fn_class); var ifn_1150 lang.IFn; if linked_1149 == nil { ifn_1150 = lang.IFn_Cast(root_1148) } else { ifn_1150 = nil }; var arg_1151 any = p1__794000155_SHARP___1; var arg_1152 any = t.F_gen_of; if linked_1149 == nil { return ifn_1150.Invoke_O_O__O(arg_1151, arg_1152) } else { return linked_1149.(*A_arbace_go_repl_type_key_A).Invoke_O_O_O__O(root_1148, arg_1151, arg_1152) } }
func A_arbace_go_repl_type_key_fn__794000165_A_New_O(p0 any) *A_arbace_go_repl_type_key_fn__794000165_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_type_key_fn__794000165_A{}; t.Ctor_O(p0); return t }
//line :220:1
func (t *A_arbace_go_repl_type_key_fn__794000165_A) Ctor_O(c__gen_of any) { t.F_gen_of = c__gen_of }
//line :220:1
func (t *A_arbace_go_repl_type_key_fn__794000165_A) Invoke_O_O__O(self, p1__794000156_SHARP___1 any) any { var root_1164 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var linked_1165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1164, A_arbace_go_repl_type_key_A_fn_class); var ifn_1166 lang.IFn; if linked_1165 == nil { ifn_1166 = lang.IFn_Cast(root_1164) } else { ifn_1166 = nil }; var arg_1167 any = p1__794000156_SHARP___1; var arg_1168 any = t.F_gen_of; if linked_1165 == nil { return ifn_1166.Invoke_O_O__O(arg_1167, arg_1168) } else { return linked_1165.(*A_arbace_go_repl_type_key_A).Invoke_O_O_O__O(root_1164, arg_1167, arg_1168) } }


func A_arbace_go_repl_type_key_fn__794000167_A_New_O(p0 any) *A_arbace_go_repl_type_key_fn__794000167_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_type_key_fn__794000167_A{}; t.Ctor_O(p0); return t }
//line :223:1
func (t *A_arbace_go_repl_type_key_fn__794000167_A) Ctor_O(c__gen_of any) { t.F_gen_of = c__gen_of }
//line :223:1
func (t *A_arbace_go_repl_type_key_fn__794000167_A) Invoke_O_O__O(self, p1__794000157_SHARP___1 any) any { var root_1090 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var linked_1091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1090, A_arbace_go_repl_type_key_A_fn_class); var ifn_1092 lang.IFn; if linked_1091 == nil { ifn_1092 = lang.IFn_Cast(root_1090) } else { ifn_1092 = nil }; var arg_1093 any = p1__794000157_SHARP___1; var arg_1094 any = t.F_gen_of; if linked_1091 == nil { return ifn_1092.Invoke_O_O__O(arg_1093, arg_1094) } else { return linked_1091.(*A_arbace_go_repl_type_key_A).Invoke_O_O_O__O(root_1090, arg_1093, arg_1094) } }

func A_arbace_go_repl_state_of_path_A_New() *A_arbace_go_repl_state_of_path_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_state_of_path_A{}; t.Ctor(); return t }
//line :225:1
func (t *A_arbace_go_repl_state_of_path_A) Ctor() {}
//line :225:1
func (t *A_arbace_go_repl_state_of_path_A) Invoke_O_O__O(self, p__0 any) any { var tmp1 any; var root_1174 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_1175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1174, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1176 lang.IFn; if linked_1175 == nil { ifn_1176 = lang.IFn_Cast(root_1174) } else { ifn_1176 = nil }; var arg_1177 any = A_arbace_go_repl_A_const_64.GetRawRoot__O(); if linked_1175 == nil { tmp1 = ifn_1176.Invoke_O__O(arg_1177) } else { tmp1 = linked_1175.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1174, arg_1177) }; return lang.RT_Get_O_O__O_NoInit(tmp1, p__0) }

func A_arbace_go_repl_method_name_A_New() *A_arbace_go_repl_method_name_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_method_name_A{}; t.Ctor(); return t }
//line :227:1
func (t *A_arbace_go_repl_method_name_A) Ctor() {}
//line :227:1
func (t *A_arbace_go_repl_method_name_A) Invoke_O_O__O(self, m__0 any) any { var base__2 any; var tmp1 *lang.Keyword = A_arbace_go_repl_A_const_55; var tmp2 any; var root_1178 any = A_arbace_go_repl_A_const_131.GetRawRoot__O(); var linked_1179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1178, aot_arbace_go_check_types.A_arbace_go_check_types_info_A_fn_class); var ifn_1180 lang.IFn; if


	linked_1179 == nil { ifn_1180 = lang.IFn_Cast(root_1178) } else { ifn_1180 = nil }; var arg_1181 any; var root_1182 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1182, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1184 lang.IFn; if linked_1183 == nil { ifn_1184 = lang.IFn_Cast(root_1182) } else { ifn_1184 = nil }; var arg_1185 any = m__0; var arg_1186 any = A_arbace_go_repl_A_const_146; if linked_1183 == nil { arg_1181 = ifn_1184.Invoke_O_O__O(arg_1185, arg_1186) } else { arg_1181 = linked_1183.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1182, arg_1185, arg_1186) }; if linked_1179 == nil { tmp2 = ifn_1180.Invoke_O__O(arg_1181) } else { tmp2 = linked_1179.(*aot_arbace_go_check_types.A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1178, arg_1181) }; base__2 = tmp1.Invoke_O__O(tmp2); var tmp3 any; var root_1187 any =
	A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1187, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1189 lang.IFn; if linked_1188 == nil { ifn_1189 = lang.IFn_Cast(root_1187) } else { ifn_1189 = nil }; var arg_1190 any = m__0; var arg_1191 any = A_arbace_go_repl_A_const_147; if linked_1188 == nil { tmp3 = ifn_1189.Invoke_O_O__O(arg_1190, arg_1191) } else { tmp3 = linked_1188.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1187, arg_1190, arg_1191) }; if jrt.J2g_Truth(tmp3) { var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_159, nil, Lit_160, nil); var tmp5 any; var root_1192 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1192, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1194 lang.IFn; if linked_1193 == nil { ifn_1194 = lang.IFn_Cast(root_1192) } else { ifn_1194 = nil }; var arg_1195 any = m__0; var arg_1196 any = A_arbace_go_repl_A_const_55; if linked_1193 == nil { tmp5 = ifn_1194.Invoke_O_O__O(arg_1195, arg_1196) } else { tmp5 = linked_1193.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1192, arg_1195, arg_1196) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, base__2, nil, tmp5)).Ref() } else { var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_3, nil); var tmp7 any; var root_1197 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1197, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1199 lang.IFn; if linked_1198 == nil { ifn_1199 = lang.IFn_Cast(root_1197) } else { ifn_1199 = nil }; var arg_1200 any = m__0; var arg_1201 any = A_arbace_go_repl_A_const_55; if linked_1198 == nil { tmp7 = ifn_1199.Invoke_O_O__O(arg_1200, arg_1201) } else { tmp7 = linked_1198.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1197, arg_1200, arg_1201) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, base__2, nil, tmp7)).Ref() } }

func A_arbace_go_repl_build_context_A_New() *A_arbace_go_repl_build_context_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_build_context_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_go_repl_build_context_A) Ctor() {}
//line :233:1
func (t *A_arbace_go_repl_build_context_A) Invoke_O_O__O(self, st__0 any) any { var tmp1 any = A_arbace_go_repl_A_const_54; var tmp2 *lang.Keyword = A_arbace_go_repl_A_const_54; var tmp3 any; var root_1202 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_1203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1202, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1204 lang.IFn; if


	linked_1203 == nil { ifn_1204 = lang.IFn_Cast(root_1202) } else { ifn_1204 = nil }; var arg_1205 any = st__0; if linked_1203 == nil { tmp3 = ifn_1204.Invoke_O__O(arg_1205) } else { tmp3 = linked_1203.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1202, arg_1205) }; var tmp4 any = /*line :233:1*/tmp2.Invoke_O__O(tmp3); var tmp5 any = A_arbace_go_repl_A_const_55; var tmp6 *lang.Keyword = A_arbace_go_repl_A_const_55; var tmp7 any; var root_1206 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_1207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1206, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1208 lang.IFn; if


	linked_1207 == nil { ifn_1208 = lang.IFn_Cast(root_1206) } else { ifn_1208 = nil }; var arg_1209 any = st__0; if linked_1207 == nil { tmp7 = ifn_1208.Invoke_O__O(arg_1209) } else { tmp7 = linked_1207.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1206, arg_1209) }; var tmp8 any = /*line :233:1*/tmp6.Invoke_O__O(tmp7); var tmp9 any = A_arbace_go_repl_A_const_148; var tmp10 any = A_arbace_go_repl_A_const_43.GetRawRoot__O(); var tmp11 any = A_arbace_go_repl_A_const_61; var tmp12 any = jrt.HashMap_New(); var tmp13 any = A_arbace_go_repl_A_const_149; var tmp14 any = jrt.IdentityHashMap_New(); var tmp15 any = A_arbace_go_repl_A_const_150; var tmp16 any; var root_1210 any = A_arbace_go_repl_A_const_53.GetRawRoot__O(); var linked_1211 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1210, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1212 lang.IFn; if






	linked_1211 == nil { ifn_1212 = lang.IFn_Cast(root_1210) } else { ifn_1212 = nil }; var arg_1213 any = A_arbace_go_repl_A_const_23; if linked_1211 == nil { tmp16 = ifn_1212.Invoke_O__O(arg_1213) } else { tmp16 = linked_1211.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1210, arg_1213) }; var tmp17 any = tmp16; var tmp18 any = A_arbace_go_repl_A_const_151; var tmp19 any = /*line :233:1*/A_arbace_go_repl_build_context_fn__794000172_A_New(); var tmp20 *jrt.Class; var fncls__1231 *jrt.Class = A_arbace_go_repl_build_context_fn__794000172_A_fn_class; if







	fncls__1231 == nil { var fncls__1231d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_go_repl_build_context_fn__794000172_A_fn_class = fncls__1231d; tmp20 = fncls__1231d } else { tmp20 = fncls__1231 }; var tmp21 any = /*line :233:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil); var tmp22 any = A_arbace_go_repl_A_const_155; var tmp23 any = A_arbace_go_repl_build_context_fn__794000174_A_New(); var tmp24 *jrt.Class; var fncls__1270 *jrt.Class = A_arbace_go_repl_build_context_fn__794000174_A_fn_class; if










	fncls__1270 == nil { var fncls__1270d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_go_repl_build_context_fn__794000174_A_fn_class = fncls__1270d; tmp24 = fncls__1270d } else { tmp24 = fncls__1270 }; var tmp25 any = /*line :233:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); var tmp26 any = A_arbace_go_repl_A_const_157; var tmp27 any = A_arbace_go_repl_build_context_fn__794000176_A_New(); var tmp28 *jrt.Class; var fncls__1303 *jrt.Class = A_arbace_go_repl_build_context_fn__794000176_A_fn_class; if














	fncls__1303 == nil { var fncls__1303d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_go_repl_build_context_fn__794000176_A_fn_class = fncls__1303d; tmp28 = fncls__1303d } else { tmp28 = fncls__1303 }; var tmp29 any = /*line :233:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil); var tmp30 any = A_arbace_go_repl_A_const_160; var tmp31 any = A_arbace_go_repl_build_context_fn__794000178_A_New(); var tmp32 *jrt.Class; var fncls__1342 *jrt.Class = A_arbace_go_repl_build_context_fn__794000178_A_fn_class; if



















	fncls__1342 == nil { var fncls__1342d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_go_repl_build_context_fn__794000178_A_fn_class = fncls__1342d; tmp32 = fncls__1342d } else { tmp32 = fncls__1342 }; return /*line :233:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp4, tmp5, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp17, tmp18, tmp21, tmp22, tmp25, tmp26, tmp29, tmp30, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil))) }







func A_arbace_go_repl_build_context_fn__794000172_A_New() *A_arbace_go_repl_build_context_fn__794000172_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_build_context_fn__794000172_A{}; t.Ctor(); return t }
//line :241:1
func (t *A_arbace_go_repl_build_context_fn__794000172_A) Ctor() {}
//line :241:1
func (t *A_arbace_go_repl_build_context_fn__794000172_A) Invoke_O_O__O(self, nt__1 any) any { var i__2 any; var root_1214 any = A_arbace_go_repl_A_const_131.GetRawRoot__O(); var linked_1215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1214, aot_arbace_go_check_types.A_arbace_go_check_types_info_A_fn_class); var ifn_1216 lang.IFn; if
												linked_1215 == nil { ifn_1216 = lang.IFn_Cast(root_1214) } else { ifn_1216 = nil }; var arg_1217 any = nt__1; if linked_1215 == nil { i__2 = ifn_1216.Invoke_O__O(arg_1217) } else { i__2 = linked_1215.(*aot_arbace_go_check_types.A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1214, arg_1217) }; var or__1927000174__auto____3 any; var temp__1927000414__auto____3 any; var root_1218 any = /*line :241:1*/A_arbace_go_repl_A_const_152.GetRawRoot__O(); var linked_1219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1218, A_arbace_go_repl_state_of_path_A_fn_class); var ifn_1220 lang.IFn; if

	linked_1219 == nil { ifn_1220 = lang.IFn_Cast(root_1218) } else { ifn_1220 = nil }; var arg_1221 any = A_arbace_go_repl_A_const_140.Invoke_O__O(i__2); if linked_1219 == nil { temp__1927000414__auto____3 = ifn_1220.Invoke_O__O(arg_1221) } else { temp__1927000414__auto____3 = linked_1219.(*A_arbace_go_repl_state_of_path_A).Invoke_O_O__O(root_1218, arg_1221) }; if jrt.J2g_Truth(temp__1927000414__auto____3) { var ps__4 any = temp__1927000414__auto____3; var root_1222 any = A_arbace_go_repl_A_const_153.GetRawRoot__O(); var linked_1223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1222, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1224 lang.IFn; if linked_1223 == nil { ifn_1224 = lang.IFn_Cast(root_1222) } else { ifn_1224 = nil }; var arg_1225 any; var root_1227 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_1228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1227, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1229 lang.IFn; if linked_1228 == nil { ifn_1229 = lang.IFn_Cast(root_1227) } else { ifn_1229 = nil }; var arg_1230 any = ps__4; if linked_1228 == nil { arg_1225 = ifn_1229.Invoke_O__O(arg_1230) } else { arg_1225 = linked_1228.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1227, arg_1230) }; var tmp1 any = A_arbace_go_repl_A_const_61; var arg_1226 any = lang.Tuple_Create_O_O_O__IPersistentVector(tmp1, A_arbace_go_repl_A_const_55.Invoke_O__O(i__2), A_arbace_go_repl_A_const_151); if linked_1223 == nil { or__1927000174__auto____3 = ifn_1224.Invoke_O_O__O(arg_1225, arg_1226) } else { or__1927000174__auto____3 = linked_1223.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1222, arg_1225, arg_1226) } } else { or__1927000174__auto____3 = nil }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { return A_arbace_go_repl_A_const_154 } }
func A_arbace_go_repl_build_context_fn__794000174_A_New() *A_arbace_go_repl_build_context_fn__794000174_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_build_context_fn__794000174_A{}; t.Ctor(); return t }
//line :244:1
func (t *A_arbace_go_repl_build_context_fn__794000174_A) Ctor() {}
//line :244:1
func (t *A_arbace_go_repl_build_context_fn__794000174_A) Invoke_O_O__O(self, x__1 any) any { var ps__2 any; var root_1232 any = A_arbace_go_repl_A_const_152.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, A_arbace_go_repl_state_of_path_A_fn_class); var ifn_1234 lang.IFn; if
												linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any; var root_1236 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1236, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1238 lang.IFn; if linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any = x__1; var arg_1240 any = A_arbace_go_repl_A_const_140; if linked_1237 == nil { arg_1235 = ifn_1238.Invoke_O_O__O(arg_1239, arg_1240) } else { arg_1235 = linked_1237.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1236, arg_1239, arg_1240) }; if linked_1233 == nil { ps__2 = ifn_1234.Invoke_O__O(arg_1235) } else { ps__2 = linked_1233.(*A_arbace_go_repl_state_of_path_A).Invoke_O_O__O(root_1232, arg_1235) }; var or__1927000174__auto____3 any; var and__1927000168__auto____3 any = ps__2; if
												jrt.J2g_Truth(and__1927000168__auto____3) { var root_1241 any = A_arbace_go_repl_A_const_153.GetRawRoot__O(); var linked_1242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1241, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1243 lang.IFn; if linked_1242 == nil { ifn_1243 = lang.IFn_Cast(root_1241) } else { ifn_1243 = nil }; var arg_1244 any; var root_1246 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_1247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1246, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1248 lang.IFn; if linked_1247 == nil { ifn_1248 = lang.IFn_Cast(root_1246) } else { ifn_1248 = nil }; var arg_1249 any = ps__2; if linked_1247 == nil { arg_1244 = ifn_1248.Invoke_O__O(arg_1249) } else { arg_1244 = linked_1247.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1246, arg_1249) }; var arg_1245 any; var tmp1 any = A_arbace_go_repl_A_const_59; var tmp2 any; var root_1250 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1250, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1252 lang.IFn; if linked_1251 == nil { ifn_1252 = lang.IFn_Cast(root_1250) } else { ifn_1252 = nil }; var arg_1253 any = x__1; var arg_1254 any = A_arbace_go_repl_A_const_55; if linked_1251 == nil { tmp2 = ifn_1252.Invoke_O_O__O(arg_1253, arg_1254) } else { tmp2 = linked_1251.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1250, arg_1253, arg_1254) }; arg_1245 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp1, tmp2, A_arbace_go_repl_A_const_156); if linked_1242 == nil { or__1927000174__auto____3 = ifn_1243.Invoke_O_O__O(arg_1244, arg_1245) } else { or__1927000174__auto____3 = linked_1242.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1241, arg_1244, arg_1245) } } else { or__1927000174__auto____3 = and__1927000168__auto____3 }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var tmp3 any; var root_1255 any = A_arbace_go_repl_A_const_69.GetRawRoot__O(); var linked_1256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1255, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1257 lang.IFn
													if linked_1256 == nil { ifn_1257 = lang.IFn_Cast(root_1255) } else { ifn_1257 = nil }; var arg_1258 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_10, nil, Lit_3, nil); var tmp5 any; var root_1260 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1260, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1262 lang.IFn; if linked_1261 == nil { ifn_1262 = lang.IFn_Cast(root_1260) } else { ifn_1262 = nil }; var arg_1263 any = x__1; var arg_1264 any = A_arbace_go_repl_A_const_140; if linked_1261 == nil { tmp5 = ifn_1262.Invoke_O_O__O(arg_1263, arg_1264) } else { tmp5 = linked_1261.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1260, arg_1263, arg_1264) }; var tmp6 any = tmp5; var tmp7 any; var root_1265 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1265, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1267 lang.IFn; if linked_1266 == nil { ifn_1267 = lang.IFn_Cast(root_1265) } else { ifn_1267 = nil }; var arg_1268 any = x__1; var arg_1269 any = A_arbace_go_repl_A_const_55; if linked_1266 == nil { tmp7 = ifn_1267.Invoke_O_O__O(arg_1268, arg_1269) } else { tmp7 = linked_1266.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1265, arg_1268, arg_1269) }; arg_1258 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp6, nil, tmp7)).Ref(); var arg_1259 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1256 == nil { tmp3 = ifn_1257.Invoke_O_O__O(arg_1258, arg_1259) } else { tmp3 = linked_1256.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1255, arg_1258, arg_1259) }
//line :246:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp3))) } }

func A_arbace_go_repl_build_context_fn__794000176_A_New() *A_arbace_go_repl_build_context_fn__794000176_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_build_context_fn__794000176_A{}; t.Ctor(); return t }
//line :248:1
func (t *A_arbace_go_repl_build_context_fn__794000176_A) Ctor() {}
//line :248:1
func (t *A_arbace_go_repl_build_context_fn__794000176_A) Invoke_O_O__O(self, m__1 any) any { var ps__2 any; var root_1271 any = A_arbace_go_repl_A_const_152.GetRawRoot__O(); var linked_1272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1271, A_arbace_go_repl_state_of_path_A_fn_class); var ifn_1273 lang.IFn; if
												linked_1272 == nil { ifn_1273 = lang.IFn_Cast(root_1271) } else { ifn_1273 = nil }; var arg_1274 any; var root_1275 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1275, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1277 lang.IFn; if linked_1276 == nil { ifn_1277 = lang.IFn_Cast(root_1275) } else { ifn_1277 = nil }; var arg_1278 any = m__1; var arg_1279 any = A_arbace_go_repl_A_const_140; if linked_1276 == nil { arg_1274 = ifn_1277.Invoke_O_O__O(arg_1278, arg_1279) } else { arg_1274 = linked_1276.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1275, arg_1278, arg_1279) }; if linked_1272 == nil { ps__2 = ifn_1273.Invoke_O__O(arg_1274) } else { ps__2 = linked_1272.(*A_arbace_go_repl_state_of_path_A).Invoke_O_O__O(root_1271, arg_1274) }; var k__3 any; var root_1280 any = /*line :248:1*/A_arbace_go_repl_A_const_158.GetRawRoot__O(); var linked_1281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1280, A_arbace_go_repl_method_name_A_fn_class); var ifn_1282 lang.IFn; if

	linked_1281 == nil { ifn_1282 = lang.IFn_Cast(root_1280) } else { ifn_1282 = nil }; var arg_1283 any = m__1; if linked_1281 == nil { k__3 = ifn_1282.Invoke_O__O(arg_1283) } else { k__3 = linked_1281.(*A_arbace_go_repl_method_name_A).Invoke_O_O__O(root_1280, arg_1283) }; var or__1927000174__auto____4 any; var and__1927000168__auto____4 any = ps__2; if
	jrt.J2g_Truth(and__1927000168__auto____4) { var root_1284 any = A_arbace_go_repl_A_const_153.GetRawRoot__O(); var linked_1285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1284, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1286 lang.IFn; if linked_1285 == nil { ifn_1286 = lang.IFn_Cast(root_1284) } else { ifn_1286 = nil }; var arg_1287 any; var root_1289 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1291 lang.IFn; if linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = ps__2; if linked_1290 == nil { arg_1287 = ifn_1291.Invoke_O__O(arg_1292) } else { arg_1287 = linked_1290.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1289, arg_1292) }; var arg_1288 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_repl_A_const_159, k__3, A_arbace_go_repl_A_const_156); if linked_1285 == nil { or__1927000174__auto____4 = ifn_1286.Invoke_O_O__O(arg_1287, arg_1288) } else { or__1927000174__auto____4 = linked_1285.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1284, arg_1287, arg_1288) } } else { or__1927000174__auto____4 = and__1927000168__auto____4 }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var tmp1 any; var root_1293 any = A_arbace_go_repl_A_const_69.GetRawRoot__O(); var linked_1294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1293, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1295 lang.IFn
		if linked_1294 == nil { ifn_1295 = lang.IFn_Cast(root_1293) } else { ifn_1295 = nil }; var arg_1296 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_11, nil, Lit_3, nil); var tmp3 any; var root_1298 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1298, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1300 lang.IFn; if linked_1299 == nil { ifn_1300 = lang.IFn_Cast(root_1298) } else { ifn_1300 = nil }; var arg_1301 any = m__1; var arg_1302 any = A_arbace_go_repl_A_const_140; if linked_1299 == nil { tmp3 = ifn_1300.Invoke_O_O__O(arg_1301, arg_1302) } else { tmp3 = linked_1299.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1298, arg_1301, arg_1302) }; arg_1296 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil, k__3)).Ref(); var arg_1297 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1294 == nil { tmp1 = ifn_1295.Invoke_O_O__O(arg_1296, arg_1297) } else { tmp1 = linked_1294.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1293, arg_1296, arg_1297) }
//line :251:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) } }

func A_arbace_go_repl_build_context_fn__794000178_A_New() *A_arbace_go_repl_build_context_fn__794000178_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_build_context_fn__794000178_A{}; t.Ctor(); return t }
//line :253:1
func (t *A_arbace_go_repl_build_context_fn__794000178_A) Ctor() {}
//line :253:1
func (t *A_arbace_go_repl_build_context_fn__794000178_A) Invoke_O_O__O(self, x__1 any) any { var ps__2 any; var root_1304 any = A_arbace_go_repl_A_const_152.GetRawRoot__O(); var linked_1305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1304, A_arbace_go_repl_state_of_path_A_fn_class); var ifn_1306 lang.IFn; if
												linked_1305 == nil { ifn_1306 = lang.IFn_Cast(root_1304) } else { ifn_1306 = nil }; var arg_1307 any; var root_1308 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1308, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1310 lang.IFn; if linked_1309 == nil { ifn_1310 = lang.IFn_Cast(root_1308) } else { ifn_1310 = nil }; var arg_1311 any = x__1; var arg_1312 any = A_arbace_go_repl_A_const_140; if linked_1309 == nil { arg_1307 = ifn_1310.Invoke_O_O__O(arg_1311, arg_1312) } else { arg_1307 = linked_1309.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1308, arg_1311, arg_1312) }; if linked_1305 == nil { ps__2 = ifn_1306.Invoke_O__O(arg_1307) } else { ps__2 = linked_1305.(*A_arbace_go_repl_state_of_path_A).Invoke_O_O__O(root_1304, arg_1307) }; var or__1927000174__auto____3 any; var and__1927000168__auto____3 any = ps__2; if
												jrt.J2g_Truth(and__1927000168__auto____3) { var root_1313 any = A_arbace_go_repl_A_const_153.GetRawRoot__O(); var linked_1314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1313, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1315 lang.IFn; if linked_1314 == nil { ifn_1315 = lang.IFn_Cast(root_1313) } else { ifn_1315 = nil }; var arg_1316 any; var root_1318 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_1319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1318, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1320 lang.IFn; if linked_1319 == nil { ifn_1320 = lang.IFn_Cast(root_1318) } else { ifn_1320 = nil }; var arg_1321 any = ps__2; if linked_1319 == nil { arg_1316 = ifn_1320.Invoke_O__O(arg_1321) } else { arg_1316 = linked_1319.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1318, arg_1321) }; var arg_1317 any; var tmp1 any = A_arbace_go_repl_A_const_60; var tmp2 any; var root_1322 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1322, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1324 lang.IFn; if linked_1323 == nil { ifn_1324 = lang.IFn_Cast(root_1322) } else { ifn_1324 = nil }; var arg_1325 any = x__1; var arg_1326 any = A_arbace_go_repl_A_const_55; if linked_1323 == nil { tmp2 = ifn_1324.Invoke_O_O__O(arg_1325, arg_1326) } else { tmp2 = linked_1323.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1322, arg_1325, arg_1326) }; arg_1317 = lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2); if linked_1314 == nil { or__1927000174__auto____3 = ifn_1315.Invoke_O_O__O(arg_1316, arg_1317) } else { or__1927000174__auto____3 = linked_1314.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1313, arg_1316, arg_1317) } } else { or__1927000174__auto____3 = and__1927000168__auto____3 }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var tmp3 any; var root_1327 any = A_arbace_go_repl_A_const_69.GetRawRoot__O(); var linked_1328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1327, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1329 lang.IFn
													if linked_1328 == nil { ifn_1329 = lang.IFn_Cast(root_1327) } else { ifn_1329 = nil }; var arg_1330 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_12, nil, Lit_3, nil); var tmp5 any; var root_1332 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1332, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1334 lang.IFn; if linked_1333 == nil { ifn_1334 = lang.IFn_Cast(root_1332) } else { ifn_1334 = nil }; var arg_1335 any = x__1; var arg_1336 any = A_arbace_go_repl_A_const_140; if linked_1333 == nil { tmp5 = ifn_1334.Invoke_O_O__O(arg_1335, arg_1336) } else { tmp5 = linked_1333.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1332, arg_1335, arg_1336) }; var tmp6 any = tmp5; var tmp7 any; var root_1337 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1337, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1339 lang.IFn; if linked_1338 == nil { ifn_1339 = lang.IFn_Cast(root_1337) } else { ifn_1339 = nil }; var arg_1340 any = x__1; var arg_1341 any = A_arbace_go_repl_A_const_55; if linked_1338 == nil { tmp7 = ifn_1339.Invoke_O_O__O(arg_1340, arg_1341) } else { tmp7 = linked_1338.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1337, arg_1340, arg_1341) }; arg_1330 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp6, nil, tmp7)).Ref(); var arg_1331 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1328 == nil { tmp3 = ifn_1329.Invoke_O_O__O(arg_1330, arg_1331) } else { tmp3 = linked_1328.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1327, arg_1330, arg_1331) }
//line :255:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp3))) } }


func A_arbace_go_repl_const_arbace_A_New() *A_arbace_go_repl_const_arbace_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_const_arbace_A{}; t.Ctor(); return t }
//line :258:1
func (t *A_arbace_go_repl_const_arbace_A) Ctor() {}
//line :258:1
func (t *A_arbace_go_repl_const_arbace_A) Invoke_O_O_O__O(self, ty__0, v__1 any) any { var b__3 any; var root_1343 any = A_arbace_go_repl_A_const_161.GetRawRoot__O(); var linked_1344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1343, aot_arbace_go_check_types.A_arbace_go_check_types_under_A_fn_class); var ifn_1345 lang.IFn; if


	linked_1344 == nil { ifn_1345 = lang.IFn_Cast(root_1343) } else { ifn_1345 = nil }; var arg_1346 any = ty__0; if linked_1344 == nil { b__3 = ifn_1345.Invoke_O__O(arg_1346) } else { b__3 = linked_1344.(*aot_arbace_go_check_types.A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1343, arg_1346) }; var tmp1 any; var root_1347 any =
	A_arbace_go_repl_A_const_162.GetRawRoot__O(); var linked_1348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1347, aot_arbace_core.A_arbace_core_boolean_QMARK__A_fn_class); var ifn_1349 lang.IFn; if
	linked_1348 == nil { ifn_1349 = lang.IFn_Cast(root_1347) } else { ifn_1349 = nil }; var arg_1350 any = v__1; if linked_1348 == nil { tmp1 = ifn_1349.Invoke_O__O(arg_1350) } else { tmp1 = linked_1348.(*aot_arbace_core.A_arbace_core_boolean_QMARK__A).Invoke_O_O__O(root_1347, arg_1350) }; if /*line :262:1*/ jrt.J2g_Truth(tmp1) { return v__1 } else { var tmp2 any; var root_1351 any = A_arbace_go_repl_A_const_90.GetRawRoot__O(); var linked_1352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1351, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1353 lang.IFn

		if linked_1352 == nil { ifn_1353 = lang.IFn_Cast(root_1351) } else { ifn_1353 = nil }; var arg_1354 any = v__1; if linked_1352 == nil { tmp2 = ifn_1353.Invoke_O__O(arg_1354) } else { tmp2 = linked_1352.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1351, arg_1354) }
//line :262:1
		if jrt.J2g_Truth(tmp2) {

			var root_1355 any = A_arbace_go_repl_A_const_163.GetRawRoot__O(); var linked_1356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1355, aot_arbace_go_check_const.A_arbace_go_check_const_value_text_A_fn_class); var ifn_1357 lang.IFn; if linked_1356 == nil { ifn_1357 = lang.IFn_Cast(root_1355) } else { ifn_1357 = nil }; var arg_1358 any = v__1; if linked_1356 == nil { return ifn_1357.Invoke_O__O(arg_1358) } else { return linked_1356.(*aot_arbace_go_check_const.A_arbace_go_check_const_value_text_A).Invoke_O_O__O(root_1355, arg_1358) } } else {
//line :262:1
				var tmp3 any; var root_1359 any = A_arbace_go_repl_A_const_164.GetRawRoot__O(); var linked_1360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1359, aot_arbace_go_check_const.A_arbace_go_check_const_complex_QMARK__A_fn_class); var ifn_1361 lang.IFn


				if linked_1360 == nil { ifn_1361 = lang.IFn_Cast(root_1359) } else { ifn_1361 = nil }; var arg_1362 any = v__1; if linked_1360 == nil { tmp3 = ifn_1361.Invoke_O__O(arg_1362) } else { tmp3 = linked_1360.(*aot_arbace_go_check_const.A_arbace_go_check_const_complex_QMARK__A).Invoke_O_O__O(root_1359, arg_1362) }
//line :262:1
				if jrt.J2g_Truth(tmp3) {


					var tmp4 float64; var root_1363 any = A_arbace_go_repl_A_const_165.GetRawRoot__O(); var linked_1364 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1363, aot_arbace_go_check_const.A_arbace_go_check_const_to_double_A_fn_class); var ifn_1365 lang.IFn; if linked_1364 == nil { ifn_1365 = lang.IFn_Cast(root_1363) } else { ifn_1365 = nil }; var arg_1366 any = lang.RT_Nth_O_I__O_NoInit(v__1, lang.RT_IntCast_J__I_NoInit(1)); if linked_1364 == nil { tmp4 = lang.RT_DoubleCast_O__D_NoInit(ifn_1365.Invoke_O__O(arg_1366)) } else { tmp4 = linked_1364.(*aot_arbace_go_check_const.A_arbace_go_check_const_to_double_A).InvokePrim_O_O__D(root_1363, arg_1366) }; var tmp5 float64 = tmp4; var tmp6 float64; var root_1367 any = A_arbace_go_repl_A_const_165.GetRawRoot__O(); var linked_1368 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1367, aot_arbace_go_check_const.A_arbace_go_check_const_to_double_A_fn_class); var ifn_1369 lang.IFn; if linked_1368 == nil { ifn_1369 = lang.IFn_Cast(root_1367) } else { ifn_1369 = nil }; var arg_1370 any = lang.RT_Nth_O_I__O_NoInit(v__1, lang.RT_IntCast_J__I_NoInit(2)); if linked_1368 == nil { tmp6 = lang.RT_DoubleCast_O__D_NoInit(ifn_1369.Invoke_O__O(arg_1370)) } else { tmp6 = linked_1368.(*aot_arbace_go_check_const.A_arbace_go_check_const_to_double_A).InvokePrim_O_O__D(root_1367, arg_1370) }; return lang.GoInterp_Complex_D_D__O(tmp5, tmp6) } else {
//line :262:1
						var tmp7 any; var and__1927000168__auto____4 any; var root_1371 any = A_arbace_go_repl_A_const_129.GetRawRoot__O(); var linked_1372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1371, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_1373 lang.IFn



						if linked_1372 == nil { ifn_1373 = lang.IFn_Cast(root_1371) } else { ifn_1373 = nil }; var arg_1374 any = b__3; if linked_1372 == nil { and__1927000168__auto____4 = ifn_1373.Invoke_O__O(arg_1374) } else { and__1927000168__auto____4 = linked_1372.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_1371, arg_1374) }; if jrt.J2g_Truth(and__1927000168__auto____4) { tmp7 = lang.IFn_Cast(A_arbace_go_repl_A_const_166).Invoke_O__O(b__3) } else { tmp7 = and__1927000168__auto____4 }
//line :262:1
						if jrt.J2g_Truth(tmp7) {



							if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_repl_A_const_167, b__3) { var tmp8 float64; var root_1375 any = A_arbace_go_repl_A_const_165.GetRawRoot__O(); var linked_1376 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1375, aot_arbace_go_check_const.A_arbace_go_check_const_to_double_A_fn_class); var ifn_1377 lang.IFn; if linked_1376 == nil { ifn_1377 = lang.IFn_Cast(root_1375) } else { ifn_1377 = nil }; var arg_1378 any = v__1; if linked_1376 == nil { tmp8 = lang.RT_DoubleCast_O__D_NoInit(ifn_1377.Invoke_O__O(arg_1378)) } else { tmp8 = linked_1376.(*aot_arbace_go_check_const.A_arbace_go_check_const_to_double_A).InvokePrim_O_O__D(root_1375, arg_1378) }; return jrt.Float_ValueOf_F__Float_NoInit(lang.RT_FloatCast_D__F_NoInit(tmp8)).Ref() } else { var root_1379 any = A_arbace_go_repl_A_const_165.GetRawRoot__O(); var linked_1380 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1379, aot_arbace_go_check_const.A_arbace_go_check_const_to_double_A_fn_class); var ifn_1381 lang.IFn; if linked_1380 == nil { ifn_1381 = lang.IFn_Cast(root_1379) } else { ifn_1381 = nil }; var arg_1382 any = v__1; if linked_1380 == nil { return ifn_1381.Invoke_O__O(arg_1382) } else { return jrt.Double_ValueOf_D__Double_NoInit(linked_1380.(*aot_arbace_go_check_const.A_arbace_go_check_const_to_double_A).InvokePrim_O_O__D(root_1379, arg_1382)).Ref() } } } else {
//line :262:1
								var tmp9 any; var root_1383 any = A_arbace_go_repl_A_const_168.GetRawRoot__O(); var linked_1384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1383, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_1385 lang.IFn




								if linked_1384 == nil { ifn_1385 = lang.IFn_Cast(root_1383) } else { ifn_1385 = nil }; var arg_1386 any = v__1; if linked_1384 == nil { tmp9 = ifn_1385.Invoke_O__O(arg_1386) } else { tmp9 = linked_1384.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_1383, arg_1386) }
//line :262:1
								if jrt.J2g_Truth(tmp9) { return v__1 } else { if A_arbace_go_repl_A_const_133 != nil {





									var root_1387 any = A_arbace_go_repl_A_const_165.GetRawRoot__O(); var linked_1388 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1387, aot_arbace_go_check_const.A_arbace_go_check_const_to_double_A_fn_class); var ifn_1389 lang.IFn; if linked_1388 == nil { ifn_1389 = lang.IFn_Cast(root_1387) } else { ifn_1389 = nil }; var arg_1390 any = v__1; if linked_1388 == nil { return ifn_1389.Invoke_O__O(arg_1390) } else { return jrt.Double_ValueOf_D__Double_NoInit(linked_1388.(*aot_arbace_go_check_const.A_arbace_go_check_const_to_double_A).InvokePrim_O_O__D(root_1387, arg_1390)).Ref() } } else {
//line :262:1
										return nil } } } } } } }







func A_arbace_go_repl_define_BANG__A_New() *A_arbace_go_repl_define_BANG__A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_go_repl_define_BANG__A) Ctor() {}
//line :270:1
func (t *A_arbace_go_repl_define_BANG__A) Invoke_O_O_O_O__O(self, st__0, r__1, p__794000190__2 any) any { var map__794000191__4 any = p__794000190__2; var map__794000191__5 any; if lang.ISeq_InstanceOf(map__794000191__4) { var tmp1 any; var root_1391 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_1392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1391, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1393 lang.IFn; if linked_1392 == nil { ifn_1393 = lang.IFn_Cast(root_1391) } else { ifn_1393 = nil }; var arg_1394 any = map__794000191__4; if linked_1392 == nil { tmp1 = ifn_1393.Invoke_O__O(arg_1394) } else { tmp1 = linked_1392.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1391, arg_1394) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1395 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_1396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1395, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1397 lang.IFn; if linked_1396 == nil { ifn_1397 = lang.IFn_Cast(root_1395) } else { ifn_1397 = nil }; var arg_1398 any = map__794000191__4; if linked_1396 == nil { tmp2 = ifn_1397.Invoke_O__O(arg_1398) } else { tmp2 = linked_1396.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1395, arg_1398) }; map__794000191__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_1399 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_1400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1399, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1401 lang.IFn; if linked_1400 == nil { ifn_1401 = lang.IFn_Cast(root_1399) } else { ifn_1401 = nil }; var arg_1402 any = map__794000191__4; if linked_1400 == nil { tmp3 = ifn_1401.Invoke_O__O(arg_1402) } else { tmp3 = linked_1400.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1399, arg_1402) }; if jrt.J2g_Truth(tmp3) { var root_1403 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_1404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1403, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1405 lang.IFn; if linked_1404 == nil { ifn_1405 = lang.IFn_Cast(root_1403) } else { ifn_1405 = nil }; var arg_1406 any = map__794000191__4; if linked_1404 == nil { map__794000191__5 = ifn_1405.Invoke_O__O(arg_1406) } else { map__794000191__5 = linked_1404.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1403, arg_1406) } } else { map__794000191__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000191__5 = map__794000191__4 }; var vars_QMARK___6 any = lang.RT_Get_O_O__O_NoInit(map__794000191__5, A_arbace_go_repl_A_const_169); var eager__7 any = lang.RT_Get_O_O__O_NoInit(map__794000191__5, A_arbace_go_repl_A_const_170); var only__8 any = lang.RT_Get_O_O__O_NoInit(map__794000191__5, A_arbace_go_repl_A_const_171); var kept_names__9 any = lang.RT_Get_O_O__O_NoInit(map__794000191__5, A_arbace_go_repl_A_const_172); var init_names__10 any = lang.RT_Get_O_O__O_NoInit(map__794000191__5, A_arbace_go_repl_A_const_173); var ctx__11 any; var root_1407 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var linked_1408 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1407, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1409 lang.IFn; if





	linked_1408 == nil { ifn_1409 = lang.IFn_Cast(root_1407) } else { ifn_1409 = nil }; var arg_1410 any; var root_1413 any = A_arbace_go_repl_A_const_174.GetRawRoot__O(); var linked_1414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1413, A_arbace_go_repl_build_context_A_fn_class); var ifn_1415 lang.IFn; if linked_1414 == nil { ifn_1415 = lang.IFn_Cast(root_1413) } else { ifn_1415 = nil }; var arg_1416 any = st__0; if linked_1414 == nil { arg_1410 = ifn_1415.Invoke_O__O(arg_1416) } else { arg_1410 = linked_1414.(*A_arbace_go_repl_build_context_A).Invoke_O_O__O(root_1413, arg_1416) }; var arg_1411 any = A_arbace_go_repl_A_const_170; var arg_1412 any = eager__7; if linked_1408 == nil { ctx__11 = ifn_1409.Invoke_O_O_O__O(arg_1410, arg_1411, arg_1412) } else { ctx__11 = linked_1408.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1407, arg_1410, arg_1411, arg_1412) }; var decls__12 any = /*line :270:1*/A_arbace_go_repl_A_const_175.Invoke_O__O(r__1); var old__13 any; var root_1417 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_1418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1417, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1419 lang.IFn; if





	linked_1418 == nil { ifn_1419 = lang.IFn_Cast(root_1417) } else { ifn_1419 = nil }; var arg_1420 any = st__0; if linked_1418 == nil { old__13 = ifn_1419.Invoke_O__O(arg_1420) } else { old__13 = linked_1418.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1417, arg_1420) }; var gen_of__14 any; var tmp4 any = /*line :270:1*/A_arbace_go_repl_define_BANG__gen_of__794000193_A_New_O(old__13); var tmp5 *jrt.Class; var fncls__1430 *jrt.Class = A_arbace_go_repl_define_BANG__gen_of__794000193_A_fn_class; if








	fncls__1430 == nil { var fncls__1430d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_go_repl_define_BANG__gen_of__794000193_A_fn_class = fncls__1430d; tmp5 = fncls__1430d } else { tmp5 = fncls__1430 }; gen_of__14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var unsupported__15 any; var root_1431 any = /*line :270:1*/A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_1432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1431, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1433 lang.IFn; if









	linked_1432 == nil { ifn_1433 = lang.IFn_Cast(root_1431) } else { ifn_1433 = nil }; var arg_1434 any; var tmp6 any = A_arbace_go_repl_define_BANG__fn__794000195_A_New(); var tmp7 *jrt.Class; var fncls__1436 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000195_A_fn_class; if fncls__1436 == nil { var fncls__1436d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_go_repl_define_BANG__fn__794000195_A_fn_class = fncls__1436d; tmp7 = fncls__1436d } else { tmp7 = fncls__1436 }; arg_1434 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_1435 any = decls__12; if linked_1432 == nil { unsupported__15 = ifn_1433.Invoke_O_O__O(arg_1434, arg_1435) } else { unsupported__15 = linked_1432.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1431, arg_1434, arg_1435) }; if

	jrt.J2g_Truth(unsupported__15) { var what__16 any; var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_62); var tmp9 any; var or__1927000174__auto____18 any = A_arbace_go_repl_A_const_176.Invoke_O__O(unsupported__15)
		if jrt.J2g_Truth(or__1927000174__auto____18) { tmp9 = or__1927000174__auto____18 } else { tmp9 = Lit_63 }; what__16 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, tmp9, nil)).Ref()
//line :282:1
		var tmp10 any; var root_2114 any = A_arbace_go_repl_A_const_69.GetRawRoot__O(); var linked_2115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2114, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2116 lang.IFn

		if linked_2115 == nil { ifn_2116 = lang.IFn_Cast(root_2114) } else { ifn_2116 = nil }; var arg_2117 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_64, nil), jrt.RefArrayOf(jrt.Object_class, nil, what__16)).Ref(); var arg_2118 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_repl_A_const_201, what__16)); if linked_2115 == nil { tmp10 = ifn_2116.Invoke_O_O__O(arg_2117, arg_2118) } else { tmp10 = linked_2115.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2114, arg_2117, arg_2118) }
//line :282:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp10))) }; var root_2119 any =


	A_arbace_go_repl_A_const_202.GetRawRoot__O(); var linked_2120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2119, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2121 lang.IFn; if linked_2120 == nil { ifn_2121 = lang.IFn_Cast(root_2119) } else { ifn_2121 = nil }; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_38.GetRawRoot__O()); var tmp12 any = A_arbace_go_repl_A_const_203; var tmp13 any = A_arbace_go_repl_A_const_204; var arg_2122 any = tmp11.Invoke_O_O_O_O__O(tmp12, ctx__11, tmp13, A_arbace_go_repl_A_const_205.GetRawRoot__O()); if linked_2120 == nil { ifn_2121.Invoke_O__O(arg_2122) } else { linked_2120.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2119, arg_2122) }; var tmp14 any; tmp235 := /*line :270:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var type_decls__18 any; var root_2130 any = A_arbace_go_repl_A_const_33.GetRawRoot__O(); var linked_2131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2130, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_2132 lang.IFn
















		if linked_2131 == nil { ifn_2132 = lang.IFn_Cast(root_2130) } else { ifn_2132 = nil }; var arg_2133 any; var tmp15 any = A_arbace_go_repl_define_BANG__fn__794000197_A_New(); var tmp16 *jrt.Class; var fncls__2144 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000197_A_fn_class; if fncls__2144 == nil { var fncls__2144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_go_repl_define_BANG__fn__794000197_A_fn_class = fncls__2144d; tmp16 = fncls__2144d } else { tmp16 = fncls__2144 }; arg_2133 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); var arg_2134 any = decls__12; if linked_2131 == nil { type_decls__18 = ifn_2132.Invoke_O_O__O(arg_2133, arg_2134) } else { type_decls__18 = linked_2131.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_2130, arg_2133, arg_2134) }
//line :270:1
		var types__19 any; var root_2145 any = A_arbace_go_repl_A_const_88.GetRawRoot__O(); var linked_2146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2145, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2147 lang.IFn

















		if linked_2146 == nil { ifn_2147 = lang.IFn_Cast(root_2145) } else { ifn_2147 = nil }; var arg_2148 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2149 any; var iter__1927001039__auto____19 any; var tmp17 any = A_arbace_go_repl_define_BANG__iter__794000199__794000203_A_New_O_O(gen_of__14, old__13); var tmp18 *jrt.Class; var fncls__2260 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000199__794000203_A_fn_class
		if fncls__2260 == nil { var fncls__2260d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_go_repl_define_BANG__iter__794000199__794000203_A_fn_class = fncls__2260d; tmp18 = fncls__2260d } else { tmp18 = fncls__2260 }; iter__1927001039__auto____19 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); arg_2149 = lang.IFn_Cast(iter__1927001039__auto____19).Invoke_O__O(type_decls__18)
//line :288:1
		if linked_2146 == nil { types__19 = ifn_2147.Invoke_O_O__O(arg_2148, arg_2149) } else { types__19 = linked_2146.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2145, arg_2148, arg_2149)
		}




		var root_2261 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_2262 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2261, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2263 lang.IFn; if linked_2262 == nil { ifn_2263 = lang.IFn_Cast(root_2261) } else { ifn_2263 = nil }; var arg_2264 any = st__0; var arg_2265 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_2266 any = A_arbace_go_repl_A_const_61; var arg_2267 any = types__19; if linked_2262 == nil { ifn_2263.Invoke_O_O_O_O__O(arg_2264, arg_2265, arg_2266, arg_2267) } else { linked_2262.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2261, arg_2264, arg_2265, arg_2266, arg_2267) }
//line :270:1
		var funcs__18 any; var root_1437 any = A_arbace_go_repl_A_const_33.GetRawRoot__O(); var linked_1438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1437, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1439 lang.IFn

























		if linked_1438 == nil { ifn_1439 = lang.IFn_Cast(root_1437) } else { ifn_1439 = nil }; var arg_1440 any; var tmp19 any = A_arbace_go_repl_define_BANG__fn__794000209_A_New(); var tmp20 *jrt.Class; var fncls__1456 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000209_A_fn_class; if fncls__1456 == nil { var fncls__1456d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_go_repl_define_BANG__fn__794000209_A_fn_class = fncls__1456d; tmp20 = fncls__1456d } else { tmp20 = fncls__1456 }; arg_1440 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil); var arg_1441 any = decls__12; if linked_1438 == nil { funcs__18 = ifn_1439.Invoke_O_O__O(arg_1440, arg_1441) } else { funcs__18 = linked_1438.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1437, arg_1440, arg_1441) }
//line :270:1
		var methods__19 any; var root_1457 any = A_arbace_go_repl_A_const_33.GetRawRoot__O(); var linked_1458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1457, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1459 lang.IFn


























		if linked_1458 == nil { ifn_1459 = lang.IFn_Cast(root_1457) } else { ifn_1459 = nil }; var arg_1460 any; var tmp21 any = A_arbace_go_repl_define_BANG__fn__794000211_A_New(); var tmp22 *jrt.Class; var fncls__1462 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000211_A_fn_class; if fncls__1462 == nil { var fncls__1462d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_go_repl_define_BANG__fn__794000211_A_fn_class = fncls__1462d; tmp22 = fncls__1462d } else { tmp22 = fncls__1462 }; arg_1460 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil); var arg_1461 any = decls__12; if linked_1458 == nil { methods__19 = ifn_1459.Invoke_O_O__O(arg_1460, arg_1461) } else { methods__19 = linked_1458.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1457, arg_1460, arg_1461) }
//line :270:1
		var new_funcs__20 any; var root_1463 any = A_arbace_go_repl_A_const_88.GetRawRoot__O(); var linked_1464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1463, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1465 lang.IFn



























		if linked_1464 == nil { ifn_1465 = lang.IFn_Cast(root_1463) } else { ifn_1465 = nil }; var arg_1466 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1467 any; var iter__1927001039__auto____20 any; var tmp23 any = A_arbace_go_repl_define_BANG__iter__794000213__794000217_A_New_O_O_O(old__13, ctx__11, kept_names__9); var tmp24 *jrt.Class; var fncls__1602 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000213__794000217_A_fn_class
		if fncls__1602 == nil { var fncls__1602d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_go_repl_define_BANG__iter__794000213__794000217_A_fn_class = fncls__1602d; tmp24 = fncls__1602d } else { tmp24 = fncls__1602 }; iter__1927001039__auto____20 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); arg_1467 = lang.IFn_Cast(iter__1927001039__auto____20).Invoke_O__O(funcs__18)
//line :298:1
		if linked_1464 == nil { new_funcs__20 = ifn_1465.Invoke_O_O__O(arg_1466, arg_1467) } else { new_funcs__20 = linked_1464.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1463, arg_1466, arg_1467) }
//line :270:1
		var init_cells__21 any; var root_1603 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_1604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1603, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1605 lang.IFn




































		if linked_1604 == nil { ifn_1605 = lang.IFn_Cast(root_1603) } else { ifn_1605 = nil }; var arg_1606 any; var iter__1927001039__auto____21 any; var tmp25 any = A_arbace_go_repl_define_BANG__iter__794000223__794000227_A_New_O_O(old__13, decls__12); var tmp26 *jrt.Class; var fncls__1691 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000223__794000227_A_fn_class; if fncls__1691 == nil { var fncls__1691d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_go_repl_define_BANG__iter__794000223__794000227_A_fn_class = fncls__1691d; tmp26 = fncls__1691d } else { tmp26 = fncls__1691 }; iter__1927001039__auto____21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil); arg_1606 = lang.IFn_Cast(iter__1927001039__auto____21).Invoke_O__O(A_arbace_go_repl_A_const_186.Invoke_O__O(r__1)); if linked_1604 == nil { init_cells__21 = ifn_1605.Invoke_O__O(arg_1606) } else { init_cells__21 = linked_1604.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1603, arg_1606)
		}

		var root_2268 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_2269 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2268, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2270 lang.IFn; if linked_2269 == nil { ifn_2270 = lang.IFn_Cast(root_2268) } else { ifn_2270 = nil }; var arg_2271 any = st__0; var arg_2272 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_2273 any = A_arbace_go_repl_A_const_59; var arg_2274 any = new_funcs__20; if linked_2269 == nil { ifn_2270.Invoke_O_O_O_O__O(arg_2271, arg_2272, arg_2273, arg_2274) } else { linked_2269.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2268, arg_2271, arg_2272, arg_2273, arg_2274) }
//line :270:1
		var new_methods__22 any; var root_2275 any = A_arbace_go_repl_A_const_88.GetRawRoot__O(); var linked_2276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2275, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2277 lang.IFn









































		if linked_2276 == nil { ifn_2277 = lang.IFn_Cast(root_2275) } else { ifn_2277 = nil }; var arg_2278 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2279 any; var iter__1927001039__auto____22 any; var tmp27 any = A_arbace_go_repl_define_BANG__iter__794000237__794000241_A_New_O_O(old__13, ctx__11); var tmp28 *jrt.Class; var fncls__2424 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000237__794000241_A_fn_class
		if fncls__2424 == nil { var fncls__2424d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_go_repl_define_BANG__iter__794000237__794000241_A_fn_class = fncls__2424d; tmp28 = fncls__2424d } else { tmp28 = fncls__2424 }; iter__1927001039__auto____22 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil); arg_2279 = lang.IFn_Cast(iter__1927001039__auto____22).Invoke_O__O(methods__19)
//line :312:1
		if linked_2276 == nil { new_methods__22 = ifn_2277.Invoke_O_O__O(arg_2278, arg_2279) } else { new_methods__22 = linked_2276.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2275, arg_2278, arg_2279)
		}







		var root_2425 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_2426 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2425, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2427 lang.IFn; if linked_2426 == nil { ifn_2427 = lang.IFn_Cast(root_2425) } else { ifn_2427 = nil }; var arg_2428 any = st__0; var arg_2429 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_2430 any = A_arbace_go_repl_A_const_159; var arg_2431 any = new_methods__22; if linked_2426 == nil { ifn_2427.Invoke_O_O_O_O__O(arg_2428, arg_2429, arg_2430, arg_2431) } else { linked_2426.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2425, arg_2428, arg_2429, arg_2430, arg_2431) }
//line :270:1
		var var_objs__22 any; var iter__1927001039__auto____22_2 any; var tmp29 any = A_arbace_go_repl_define_BANG__iter__794000247__794000253_A_New(); var tmp30 *jrt.Class
		var fncls__1805 /*line :270:1*/*jrt.Class = A_arbace_go_repl_define_BANG__iter__794000247__794000253_A_fn_class




















































		if fncls__1805 == nil { var fncls__1805d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_go_repl_define_BANG__iter__794000247__794000253_A_fn_class = fncls__1805d; tmp30 = fncls__1805d } else { tmp30 = fncls__1805 }; iter__1927001039__auto____22_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp29, tmp30, nil); var_objs__22 = lang.IFn_Cast(iter__1927001039__auto____22_2).Invoke_O__O(decls__12)
//line :270:1
		var new_vars__23 any; var root_1806 any = A_arbace_go_repl_A_const_189.GetRawRoot__O(); var linked_1807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1806, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_1808 lang.IFn





















































		if linked_1807 == nil { ifn_1808 = lang.IFn_Cast(root_1806) } else { ifn_1808 = nil }; var arg_1809 any = lang.PersistentVector_EMPTY.Ref(); if linked_1807 == nil { new_vars__23 = ifn_1808.Invoke_O__O(arg_1809) } else { new_vars__23 = linked_1807.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_1806, arg_1809) }
//line :270:1
		var globals__24 any; var root_1810 any = A_arbace_go_repl_A_const_88.GetRawRoot__O(); var linked_1811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1810, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1812 lang.IFn






















































		if linked_1811 == nil { ifn_1812 = lang.IFn_Cast(root_1810) } else { ifn_1812 = nil }; var arg_1813 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1814 any; var iter__1927001039__auto____24 any; var tmp31 any = A_arbace_go_repl_define_BANG__iter__794000263__794000267_A_New_O_O_O(new_vars__23, old__13, ctx__11); var tmp32 *jrt.Class; var fncls__1973 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000263__794000267_A_fn_class
		if fncls__1973 == nil { var fncls__1973d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_go_repl_define_BANG__iter__794000263__794000267_A_fn_class = fncls__1973d; tmp32 = fncls__1973d } else { tmp32 = fncls__1973 }; iter__1927001039__auto____24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil); var tmp33 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____24); var tmp34 any; var root_1974 any = A_arbace_go_repl_A_const_87.GetRawRoot__O(); var linked_1975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1974, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1976 lang.IFn; if linked_1975 == nil { ifn_1976 = lang.IFn_Cast(root_1974) } else { ifn_1976 = nil }; var arg_1977 any = var_objs__22; if linked_1975 == nil { tmp34 = ifn_1976.Invoke_O__O(arg_1977) } else { tmp34 = linked_1975.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1974, arg_1977) }; arg_1814 = tmp33.Invoke_O__O(tmp34)
//line :325:1
		if linked_1811 == nil { globals__24 = ifn_1812.Invoke_O_O__O(arg_1813, arg_1814) } else { globals__24 = linked_1811.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1810, arg_1813, arg_1814)
		}







		var root_2432 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_2433 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2432, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2434 lang.IFn; if linked_2433 == nil { ifn_2434 = lang.IFn_Cast(root_2432) } else { ifn_2434 = nil }; var arg_2435 any = st__0; var arg_2436 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_2437 any = A_arbace_go_repl_A_const_60; var arg_2438 any = globals__24; if linked_2433 == nil { ifn_2434.Invoke_O_O_O_O__O(arg_2435, arg_2436, arg_2437, arg_2438) } else { linked_2433.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2432, arg_2435, arg_2436, arg_2437, arg_2438) }
//line :270:1
		var seq_794000273__25 any; var root_2439 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2439, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2441 lang.IFn

































































		if linked_2440 == nil { ifn_2441 = lang.IFn_Cast(root_2439) } else { ifn_2441 = nil }; var arg_2442 any = new_funcs__20; if linked_2440 == nil { seq_794000273__25 = ifn_2441.Invoke_O__O(arg_2442) } else { seq_794000273__25 = linked_2440.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2439, arg_2442) }
//line :270:1
		var chunk_794000274__26 any; var count_794000275__27 int64 = 0; var i_794000276__28 int64 = 0; L1: for {

































































			if lang.Numbers_Lt_J_J__Z_NoInit(i_794000276__28, count_794000275__27) { var vec__794000277__29 any = lang.Indexed_Cast(chunk_794000274__26).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_794000276__28)); var nm__30 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000277__29, lang.RT_IntCast_J__I_NoInit(0), nil); var map__794000280__31 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000277__29, lang.RT_IntCast_J__I_NoInit(1), nil); var map__794000280__32 any; if lang.ISeq_InstanceOf(map__794000280__31) { var tmp35 any; var root_2443 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2443, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2445 lang.IFn; if linked_2444 == nil { ifn_2445 = lang.IFn_Cast(root_2443) } else { ifn_2445 = nil }; var arg_2446 any = map__794000280__31; if linked_2444 == nil { tmp35 = ifn_2445.Invoke_O__O(arg_2446) } else { tmp35 = linked_2444.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2443, arg_2446) }; if jrt.J2g_Truth(tmp35) { var tmp36 any; var root_2447 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_2448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2447, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2449 lang.IFn; if linked_2448 == nil { ifn_2449 = lang.IFn_Cast(root_2447) } else { ifn_2449 = nil }; var arg_2450 any = map__794000280__31; if linked_2448 == nil { tmp36 = ifn_2449.Invoke_O__O(arg_2450) } else { tmp36 = linked_2448.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2447, arg_2450) }; map__794000280__32 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp36, jrt.Object_class.ArrayClass())).Ref() } else { var tmp37 any; var root_2451 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2451, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2453 lang.IFn; if linked_2452 == nil { ifn_2453 = lang.IFn_Cast(root_2451) } else { ifn_2453 = nil }; var arg_2454 any = map__794000280__31; if linked_2452 == nil { tmp37 = ifn_2453.Invoke_O__O(arg_2454) } else { tmp37 = linked_2452.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2451, arg_2454) }; if jrt.J2g_Truth(tmp37) { var root_2455 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2455, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2457 lang.IFn; if linked_2456 == nil { ifn_2457 = lang.IFn_Cast(root_2455) } else { ifn_2457 = nil }; var arg_2458 any = map__794000280__31; if linked_2456 == nil { map__794000280__32 = ifn_2457.Invoke_O__O(arg_2458) } else { map__794000280__32 = linked_2456.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2455, arg_2458) } } else { map__794000280__32 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000280__32 = map__794000280__31 }; var cell__33 any = lang.RT_Get_O_O__O_NoInit(map__794000280__32, A_arbace_go_repl_A_const_156); var tree__34 any = lang.RT_Get_O_O__O_NoInit(map__794000280__32, A_arbace_go_repl_A_const_185); var kept__35 any = lang.RT_Get_O_O__O_NoInit(map__794000280__32, A_arbace_go_repl_A_const_184); var tmp38 any; var root_2459 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_2460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2459, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2461 lang.IFn
				if linked_2460 == nil { ifn_2461 = lang.IFn_Cast(root_2459) } else { ifn_2461 = nil }; var arg_2462 any = kept__35; if linked_2460 == nil { tmp38 = ifn_2461.Invoke_O__O(arg_2462) } else { tmp38 = linked_2460.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2459, arg_2462) }
//line :336:1
				if jrt.J2g_Truth(tmp38) { var tmp39 any; var or__1927000174__auto____36 bool = lang.Util_Identical_O_O__Z_NoInit(only__8, nil)

					if or__1927000174__auto____36 { tmp39 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____36).Ref() } else { var root_2463 any = A_arbace_go_repl_A_const_18.GetRawRoot__O(); var linked_2464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2463, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2465 lang.IFn; if linked_2464 == nil { ifn_2465 = lang.IFn_Cast(root_2463) } else { ifn_2465 = nil }; var arg_2466 any = only__8; var arg_2467 any = nm__30; if linked_2464 == nil { tmp39 = ifn_2465.Invoke_O_O__O(arg_2466, arg_2467) } else { tmp39 = linked_2464.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2463, arg_2466, arg_2467) } }
//line :336:1
					if jrt.J2g_Truth(tmp39) {


						if jrt.J2g_Truth(eager__7) {
							var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()); var tmp41 any; var root_2624 any = A_arbace_go_repl_A_const_207.GetRawRoot__O(); var linked_2625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2624, aot_arbace_go_build.A_arbace_go_build_with_ctx_A_fn_class); var ifn_2626 lang.IFn; if linked_2625 == nil { ifn_2626 = lang.IFn_Cast(root_2624) } else { ifn_2626 = nil }; var arg_2627 any = ctx__11; var arg_2628 any; var tmp42 any = A_arbace_go_repl_define_BANG__fn__794000282_A_New_O(tree__34); var tmp43 *jrt.Class; var fncls__2633 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000282_A_fn_class; if fncls__2633 == nil { var fncls__2633d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_go_repl_define_BANG__fn__794000282_A_fn_class = fncls__2633d; tmp43 = fncls__2633d } else { tmp43 = fncls__2633 }; arg_2628 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp42, tmp43, nil); if linked_2625 == nil { tmp41 = ifn_2626.Invoke_O_O__O(arg_2627, arg_2628) } else { tmp41 = linked_2625.(*aot_arbace_go_build.A_arbace_go_build_with_ctx_A).Invoke_O_O_O__O(root_2624, arg_2627, arg_2628) }; tmp40.Invoke_O_O_O_O__O(Lit_74, cell__33, tmp41, nil) } else {
								var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()); var tmp45 any = A_arbace_go_repl_define_BANG__fn__794000284_A_New_O_O(ctx__11, tree__34); var tmp46 *jrt.Class; var fncls__2651 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000284_A_fn_class; if fncls__2651 == nil { var fncls__2651d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_go_repl_define_BANG__fn__794000284_A_fn_class = fncls__2651d; tmp46 = fncls__2651d } else { tmp46 = fncls__2651 }; tmp44.Invoke_O_O_O_O__O(Lit_74, cell__33, nil, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp45, tmp46, nil)) }
//line :336:1
						seq_794000273__25, chunk_794000274__26, count_794000275__27, i_794000276__28 = seq_794000273__25, chunk_794000274__26, count_794000275__27, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000276__28); continue L1 } else { seq_794000273__25, chunk_794000274__26, count_794000275__27, i_794000276__28 = seq_794000273__25, chunk_794000274__26, count_794000275__27, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000276__28); continue L1 } } else { seq_794000273__25, chunk_794000274__26, count_794000275__27, i_794000276__28 = seq_794000273__25, chunk_794000274__26, count_794000275__27, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000276__28); continue L1 } } else { var temp__1927000414__auto____29 any; var root_2468 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2468, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2470 lang.IFn; if linked_2469 == nil { ifn_2470 = lang.IFn_Cast(root_2468) } else { ifn_2470 = nil }; var arg_2471 any = seq_794000273__25; if linked_2469 == nil { temp__1927000414__auto____29 = ifn_2470.Invoke_O__O(arg_2471) } else { temp__1927000414__auto____29 = linked_2469.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2468, arg_2471) }; if jrt.J2g_Truth(temp__1927000414__auto____29) { var seq_794000273__30 any = temp__1927000414__auto____29; var tmp47 any; var root_2472 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_2473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2472, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2474 lang.IFn; if linked_2473 == nil { ifn_2474 = lang.IFn_Cast(root_2472) } else { ifn_2474 = nil }; var arg_2475 any = seq_794000273__30; if linked_2473 == nil { tmp47 = ifn_2474.Invoke_O__O(arg_2475) } else { tmp47 = linked_2473.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2472, arg_2475) }; if jrt.J2g_Truth(tmp47) { var c__1927000678__auto____31 any; var root_2476 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_2477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2476, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2478 lang.IFn; if linked_2477 == nil { ifn_2478 = lang.IFn_Cast(root_2476) } else { ifn_2478 = nil }; var arg_2479 any = seq_794000273__30; if linked_2477 == nil { c__1927000678__auto____31 = ifn_2478.Invoke_O__O(arg_2479) } else { c__1927000678__auto____31 = linked_2477.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2476, arg_2479) }; var tmp48 any; var root_2652 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_2653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2652, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2654 lang.IFn; if linked_2653 == nil { ifn_2654 = lang.IFn_Cast(root_2652) } else { ifn_2654 = nil }; var arg_2655 any = seq_794000273__30; if linked_2653 == nil { tmp48 = ifn_2654.Invoke_O__O(arg_2655) } else { tmp48 = linked_2653.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2652, arg_2655) }; seq_794000273__25, chunk_794000274__26, count_794000275__27, i_794000276__28 = tmp48, c__1927000678__auto____31, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____31))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__794000288__31 any; var root_2480 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2480, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2482 lang.IFn; if linked_2481 == nil { ifn_2482 = lang.IFn_Cast(root_2480) } else { ifn_2482 = nil }; var arg_2483 any = seq_794000273__30; if linked_2481 == nil { vec__794000288__31 = ifn_2482.Invoke_O__O(arg_2483) } else { vec__794000288__31 = linked_2481.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2480, arg_2483) }; var nm__32 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000288__31, lang.RT_IntCast_J__I_NoInit(0), nil); var map__794000291__33 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000288__31, lang.RT_IntCast_J__I_NoInit(1), nil); var map__794000291__34 any; if lang.ISeq_InstanceOf(map__794000291__33) { var tmp49 any; var root_2484 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2484, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2486 lang.IFn; if linked_2485 == nil { ifn_2486 = lang.IFn_Cast(root_2484) } else { ifn_2486 = nil }; var arg_2487 any = map__794000291__33; if linked_2485 == nil { tmp49 = ifn_2486.Invoke_O__O(arg_2487) } else { tmp49 = linked_2485.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2484, arg_2487) }; if jrt.J2g_Truth(tmp49) { var tmp50 any; var root_2488 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_2489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2488, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2490 lang.IFn; if linked_2489 == nil { ifn_2490 = lang.IFn_Cast(root_2488) } else { ifn_2490 = nil }; var arg_2491 any = map__794000291__33; if linked_2489 == nil { tmp50 = ifn_2490.Invoke_O__O(arg_2491) } else { tmp50 = linked_2489.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2488, arg_2491) }; map__794000291__34 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp50, jrt.Object_class.ArrayClass())).Ref() } else { var tmp51 any; var root_2492 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2492, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2494 lang.IFn; if linked_2493 == nil { ifn_2494 = lang.IFn_Cast(root_2492) } else { ifn_2494 = nil }; var arg_2495 any = map__794000291__33; if linked_2493 == nil { tmp51 = ifn_2494.Invoke_O__O(arg_2495) } else { tmp51 = linked_2493.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2492, arg_2495) }; if jrt.J2g_Truth(tmp51) { var root_2496 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2496, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2498 lang.IFn; if linked_2497 == nil { ifn_2498 = lang.IFn_Cast(root_2496) } else { ifn_2498 = nil }; var arg_2499 any = map__794000291__33; if linked_2497 == nil { map__794000291__34 = ifn_2498.Invoke_O__O(arg_2499) } else { map__794000291__34 = linked_2497.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2496, arg_2499) } } else { map__794000291__34 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000291__34 = map__794000291__33 }; var cell__35 any = lang.RT_Get_O_O__O_NoInit(map__794000291__34, A_arbace_go_repl_A_const_156); var tree__36 any = lang.RT_Get_O_O__O_NoInit(map__794000291__34, A_arbace_go_repl_A_const_185); var kept__37 any = lang.RT_Get_O_O__O_NoInit(map__794000291__34, A_arbace_go_repl_A_const_184); var tmp52 any; var root_2500 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_2501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2500, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2502 lang.IFn
							if linked_2501 == nil { ifn_2502 = lang.IFn_Cast(root_2500) } else { ifn_2502 = nil }; var arg_2503 any = kept__37; if linked_2501 == nil { tmp52 = ifn_2502.Invoke_O__O(arg_2503) } else { tmp52 = linked_2501.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2500, arg_2503) }
//line :336:1
							if jrt.J2g_Truth(tmp52) { var tmp53 any; var or__1927000174__auto____38 bool = lang.Util_Identical_O_O__Z_NoInit(only__8, nil)

								if or__1927000174__auto____38 { tmp53 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____38).Ref() } else { var root_2504 any = A_arbace_go_repl_A_const_18.GetRawRoot__O(); var linked_2505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2504, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2506 lang.IFn; if linked_2505 == nil { ifn_2506 = lang.IFn_Cast(root_2504) } else { ifn_2506 = nil }; var arg_2507 any = only__8; var arg_2508 any = nm__32; if linked_2505 == nil { tmp53 = ifn_2506.Invoke_O_O__O(arg_2507, arg_2508) } else { tmp53 = linked_2505.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2504, arg_2507, arg_2508) } }
//line :336:1
								if jrt.J2g_Truth(tmp53) {


									if jrt.J2g_Truth(eager__7) {
										var tmp54 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()); var tmp55 any; var root_2663 any = A_arbace_go_repl_A_const_207.GetRawRoot__O(); var linked_2664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2663, aot_arbace_go_build.A_arbace_go_build_with_ctx_A_fn_class); var ifn_2665 lang.IFn; if linked_2664 == nil { ifn_2665 = lang.IFn_Cast(root_2663) } else { ifn_2665 = nil }; var arg_2666 any = ctx__11; var arg_2667 any; var tmp56 any = A_arbace_go_repl_define_BANG__fn__794000293_A_New_O(tree__36); var tmp57 *jrt.Class; var fncls__2672 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000293_A_fn_class; if fncls__2672 == nil { var fncls__2672d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_go_repl_define_BANG__fn__794000293_A_fn_class = fncls__2672d; tmp57 = fncls__2672d } else { tmp57 = fncls__2672 }; arg_2667 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp56, tmp57, nil); if linked_2664 == nil { tmp55 = ifn_2665.Invoke_O_O__O(arg_2666, arg_2667) } else { tmp55 = linked_2664.(*aot_arbace_go_build.A_arbace_go_build_with_ctx_A).Invoke_O_O_O__O(root_2663, arg_2666, arg_2667) }; tmp54.Invoke_O_O_O_O__O(Lit_74, cell__35, tmp55, nil) } else {
											var tmp58 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()); var tmp59 any = A_arbace_go_repl_define_BANG__fn__794000295_A_New_O_O(tree__36, ctx__11); var tmp60 *jrt.Class; var fncls__2690 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000295_A_fn_class; if fncls__2690 == nil { var fncls__2690d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_go_repl_define_BANG__fn__794000295_A_fn_class = fncls__2690d; tmp60 = fncls__2690d } else { tmp60 = fncls__2690 }; tmp58.Invoke_O_O_O_O__O(Lit_74, cell__35, nil, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp59, tmp60, nil)) }
//line :336:1
									var tmp61 any; var root_2691 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2691, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2693 lang.IFn; if linked_2692 == nil { ifn_2693 = lang.IFn_Cast(root_2691) } else { ifn_2693 = nil }; var arg_2694 any = seq_794000273__30; if linked_2692 == nil { tmp61 = ifn_2693.Invoke_O__O(arg_2694) } else { tmp61 = linked_2692.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2691, arg_2694) }; seq_794000273__25, chunk_794000274__26, count_794000275__27, i_794000276__28 = tmp61, nil, 0, 0; continue L1 } else { var tmp62 any; var root_2695 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2695, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2697 lang.IFn; if linked_2696 == nil { ifn_2697 = lang.IFn_Cast(root_2695) } else { ifn_2697 = nil }; var arg_2698 any = seq_794000273__30; if linked_2696 == nil { tmp62 = ifn_2697.Invoke_O__O(arg_2698) } else { tmp62 = linked_2696.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2695, arg_2698) }; seq_794000273__25, chunk_794000274__26, count_794000275__27, i_794000276__28 = tmp62, nil, 0, 0; continue L1 } } else { var tmp63 any; var root_2699 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2699, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2701 lang.IFn; if linked_2700 == nil { ifn_2701 = lang.IFn_Cast(root_2699) } else { ifn_2701 = nil }; var arg_2702 any = seq_794000273__30; if linked_2700 == nil { tmp63 = ifn_2701.Invoke_O__O(arg_2702) } else { tmp63 = linked_2700.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2699, arg_2702) }; seq_794000273__25, chunk_794000274__26, count_794000275__27, i_794000276__28 = tmp63, nil, 0, 0; continue L1 } } } }
//line :270:1
			break L1 }; var seq_794000299__25 any; var root_2509 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2509, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2511 lang.IFn








































































		if linked_2510 == nil { ifn_2511 = lang.IFn_Cast(root_2509) } else { ifn_2511 = nil }; var arg_2512 any; var tmp64 *lang.Keyword = A_arbace_go_repl_A_const_159; var tmp65 any; var root_2513 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_2514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2513, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2515 lang.IFn; if linked_2514 == nil { ifn_2515 = lang.IFn_Cast(root_2513) } else { ifn_2515 = nil }; var arg_2516 any = st__0; if linked_2514 == nil { tmp65 = ifn_2515.Invoke_O__O(arg_2516) } else { tmp65 = linked_2514.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2513, arg_2516) }; arg_2512 = tmp64.Invoke_O__O(tmp65); if linked_2510 == nil { seq_794000299__25 = ifn_2511.Invoke_O__O(arg_2512) } else { seq_794000299__25 = linked_2510.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2509, arg_2512) }
//line :270:1
		var chunk_794000300__26 any; var count_794000301__27 int64 = 0; var i_794000302__28 int64 = 0; L2: for {








































































			if lang.Numbers_Lt_J_J__Z_NoInit(i_794000302__28, count_794000301__27) { var vec__794000303__29 any = lang.Indexed_Cast(chunk_794000300__26).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_794000302__28)); var nm__30_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000303__29, lang.RT_IntCast_J__I_NoInit(0), nil); var map__794000306__31 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000303__29, lang.RT_IntCast_J__I_NoInit(1), nil); var map__794000306__32 any; _ = nm__30_2; if lang.ISeq_InstanceOf(map__794000306__31) { var tmp66 any; var root_2517 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2517, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2519 lang.IFn; if linked_2518 == nil { ifn_2519 = lang.IFn_Cast(root_2517) } else { ifn_2519 = nil }; var arg_2520 any = map__794000306__31; if linked_2518 == nil { tmp66 = ifn_2519.Invoke_O__O(arg_2520) } else { tmp66 = linked_2518.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2517, arg_2520) }; if jrt.J2g_Truth(tmp66) { var tmp67 any; var root_2521 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_2522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2521, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2523 lang.IFn; if linked_2522 == nil { ifn_2523 = lang.IFn_Cast(root_2521) } else { ifn_2523 = nil }; var arg_2524 any = map__794000306__31; if linked_2522 == nil { tmp67 = ifn_2523.Invoke_O__O(arg_2524) } else { tmp67 = linked_2522.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2521, arg_2524) }; map__794000306__32 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp67, jrt.Object_class.ArrayClass())).Ref() } else { var tmp68 any; var root_2525 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2525, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2527 lang.IFn; if linked_2526 == nil { ifn_2527 = lang.IFn_Cast(root_2525) } else { ifn_2527 = nil }; var arg_2528 any = map__794000306__31; if linked_2526 == nil { tmp68 = ifn_2527.Invoke_O__O(arg_2528) } else { tmp68 = linked_2526.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2525, arg_2528) }; if jrt.J2g_Truth(tmp68) { var root_2529 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2529, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2531 lang.IFn; if linked_2530 == nil { ifn_2531 = lang.IFn_Cast(root_2529) } else { ifn_2531 = nil }; var arg_2532 any = map__794000306__31; if linked_2530 == nil { map__794000306__32 = ifn_2531.Invoke_O__O(arg_2532) } else { map__794000306__32 = linked_2530.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2529, arg_2532) } } else { map__794000306__32 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000306__32 = map__794000306__31 }; var cell__33_2 any = lang.RT_Get_O_O__O_NoInit(map__794000306__32, A_arbace_go_repl_A_const_156); var tree__34_2 any = lang.RT_Get_O_O__O_NoInit(map__794000306__32, A_arbace_go_repl_A_const_185); var generic__35 any = lang.RT_Get_O_O__O_NoInit(map__794000306__32, A_arbace_go_repl_A_const_177); if jrt.J2g_Truth(tree__34_2) {

				if jrt.J2g_Truth(generic__35) {
					var tmp69 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()); var tmp70 any = A_arbace_go_repl_define_BANG__fn__794000308_A_New(); var tmp71 *jrt.Class; var fncls__2715 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000308_A_fn_class; if fncls__2715 == nil { var fncls__2715d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_go_repl_define_BANG__fn__794000308_A_fn_class = fncls__2715d; tmp71 = fncls__2715d } else { tmp71 = fncls__2715 }; tmp69.Invoke_O_O_O_O__O(Lit_74, cell__33_2, nil, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp70, tmp71, nil)) } else {
//line :345:1
						if jrt.J2g_Truth(eager__7) {

							var tmp72 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()); var tmp73 any; var root_2723 any = A_arbace_go_repl_A_const_207.GetRawRoot__O(); var linked_2724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2723, aot_arbace_go_build.A_arbace_go_build_with_ctx_A_fn_class); var ifn_2725 lang.IFn; if linked_2724 == nil { ifn_2725 = lang.IFn_Cast(root_2723) } else { ifn_2725 = nil }; var arg_2726 any = ctx__11; var arg_2727 any; var tmp74 any = A_arbace_go_repl_define_BANG__fn__794000310_A_New_O(tree__34_2); var tmp75 *jrt.Class; var fncls__2732 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000310_A_fn_class; if fncls__2732 == nil { var fncls__2732d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_go_repl_define_BANG__fn__794000310_A_fn_class = fncls__2732d; tmp75 = fncls__2732d } else { tmp75 = fncls__2732 }; arg_2727 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp74, tmp75, nil); if linked_2724 == nil { tmp73 = ifn_2725.Invoke_O_O__O(arg_2726, arg_2727) } else { tmp73 = linked_2724.(*aot_arbace_go_build.A_arbace_go_build_with_ctx_A).Invoke_O_O_O__O(root_2723, arg_2726, arg_2727) }; tmp72.Invoke_O_O_O_O__O(Lit_74, cell__33_2, tmp73, nil) } else {
//line :345:1
								if A_arbace_go_repl_A_const_133 != nil {


									var tmp76 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()); var tmp77 any = A_arbace_go_repl_define_BANG__fn__794000312_A_New_O_O(ctx__11, tree__34_2); var tmp78 *jrt.Class; var fncls__2750 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000312_A_fn_class; if fncls__2750 == nil { var fncls__2750d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_go_repl_define_BANG__fn__794000312_A_fn_class = fncls__2750d; tmp78 = fncls__2750d } else { tmp78 = fncls__2750 }; tmp76.Invoke_O_O_O_O__O(Lit_74, cell__33_2, nil, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp77, tmp78, nil)) } } }
//line :343:1
				seq_794000299__25, chunk_794000300__26, count_794000301__27, i_794000302__28 = seq_794000299__25, chunk_794000300__26, count_794000301__27, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000302__28); continue L2 } else { seq_794000299__25, chunk_794000300__26, count_794000301__27, i_794000302__28 = seq_794000299__25, chunk_794000300__26, count_794000301__27, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000302__28); continue L2 } } else { var temp__1927000414__auto____29_2 any; var root_2533 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2533, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2535 lang.IFn; if linked_2534 == nil { ifn_2535 = lang.IFn_Cast(root_2533) } else { ifn_2535 = nil }; var arg_2536 any = seq_794000299__25; if linked_2534 == nil { temp__1927000414__auto____29_2 = ifn_2535.Invoke_O__O(arg_2536) } else { temp__1927000414__auto____29_2 = linked_2534.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2533, arg_2536) }; if jrt.J2g_Truth(temp__1927000414__auto____29_2) { var seq_794000299__30 any = temp__1927000414__auto____29_2; var tmp79 any; var root_2537 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_2538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2537, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2539 lang.IFn; if linked_2538 == nil { ifn_2539 = lang.IFn_Cast(root_2537) } else { ifn_2539 = nil }; var arg_2540 any = seq_794000299__30; if linked_2538 == nil { tmp79 = ifn_2539.Invoke_O__O(arg_2540) } else { tmp79 = linked_2538.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2537, arg_2540) }; if jrt.J2g_Truth(tmp79) { var c__1927000678__auto____31_2 any; var root_2541 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_2542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2541, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2543 lang.IFn; if linked_2542 == nil { ifn_2543 = lang.IFn_Cast(root_2541) } else { ifn_2543 = nil }; var arg_2544 any = seq_794000299__30; if linked_2542 == nil { c__1927000678__auto____31_2 = ifn_2543.Invoke_O__O(arg_2544) } else { c__1927000678__auto____31_2 = linked_2542.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2541, arg_2544) }; var tmp80 any; var root_2751 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_2752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2751, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2753 lang.IFn; if linked_2752 == nil { ifn_2753 = lang.IFn_Cast(root_2751) } else { ifn_2753 = nil }; var arg_2754 any = seq_794000299__30; if linked_2752 == nil { tmp80 = ifn_2753.Invoke_O__O(arg_2754) } else { tmp80 = linked_2752.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2751, arg_2754) }; seq_794000299__25, chunk_794000300__26, count_794000301__27, i_794000302__28 = tmp80, c__1927000678__auto____31_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____31_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var vec__794000316__31 any; var root_2545 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2545, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2547 lang.IFn; if linked_2546 == nil { ifn_2547 = lang.IFn_Cast(root_2545) } else { ifn_2547 = nil }; var arg_2548 any = seq_794000299__30; if linked_2546 == nil { vec__794000316__31 = ifn_2547.Invoke_O__O(arg_2548) } else { vec__794000316__31 = linked_2546.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2545, arg_2548) }; var nm__32_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000316__31, lang.RT_IntCast_J__I_NoInit(0), nil); var map__794000319__33 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000316__31, lang.RT_IntCast_J__I_NoInit(1), nil); var map__794000319__34 any; _ = nm__32_2; if lang.ISeq_InstanceOf(map__794000319__33) { var tmp81 any; var root_2549 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2549, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2551 lang.IFn; if linked_2550 == nil { ifn_2551 = lang.IFn_Cast(root_2549) } else { ifn_2551 = nil }; var arg_2552 any = map__794000319__33; if linked_2550 == nil { tmp81 = ifn_2551.Invoke_O__O(arg_2552) } else { tmp81 = linked_2550.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2549, arg_2552) }; if jrt.J2g_Truth(tmp81) { var tmp82 any; var root_2553 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_2554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2553, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2555 lang.IFn; if linked_2554 == nil { ifn_2555 = lang.IFn_Cast(root_2553) } else { ifn_2555 = nil }; var arg_2556 any = map__794000319__33; if linked_2554 == nil { tmp82 = ifn_2555.Invoke_O__O(arg_2556) } else { tmp82 = linked_2554.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2553, arg_2556) }; map__794000319__34 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp82, jrt.Object_class.ArrayClass())).Ref() } else { var tmp83 any; var root_2557 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2557, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2559 lang.IFn; if linked_2558 == nil { ifn_2559 = lang.IFn_Cast(root_2557) } else { ifn_2559 = nil }; var arg_2560 any = map__794000319__33; if linked_2558 == nil { tmp83 = ifn_2559.Invoke_O__O(arg_2560) } else { tmp83 = linked_2558.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2557, arg_2560) }; if jrt.J2g_Truth(tmp83) { var root_2561 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2561, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2563 lang.IFn; if linked_2562 == nil { ifn_2563 = lang.IFn_Cast(root_2561) } else { ifn_2563 = nil }; var arg_2564 any = map__794000319__33; if linked_2562 == nil { map__794000319__34 = ifn_2563.Invoke_O__O(arg_2564) } else { map__794000319__34 = linked_2562.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2561, arg_2564) } } else { map__794000319__34 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000319__34 = map__794000319__33 }; var cell__35_2 any = lang.RT_Get_O_O__O_NoInit(map__794000319__34, A_arbace_go_repl_A_const_156); var tree__36_2 any = lang.RT_Get_O_O__O_NoInit(map__794000319__34, A_arbace_go_repl_A_const_185); var generic__37 any = lang.RT_Get_O_O__O_NoInit(map__794000319__34, A_arbace_go_repl_A_const_177); if jrt.J2g_Truth(tree__36_2) {

					if jrt.J2g_Truth(generic__37) {
						var tmp84 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()); var tmp85 any = A_arbace_go_repl_define_BANG__fn__794000321_A_New(); var tmp86 *jrt.Class; var fncls__2767 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000321_A_fn_class; if fncls__2767 == nil { var fncls__2767d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_go_repl_define_BANG__fn__794000321_A_fn_class = fncls__2767d; tmp86 = fncls__2767d } else { tmp86 = fncls__2767 }; tmp84.Invoke_O_O_O_O__O(Lit_74, cell__35_2, nil, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp85, tmp86, nil)) } else {
//line :345:1
							if jrt.J2g_Truth(eager__7) {

								var tmp87 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()); var tmp88 any; var root_2775 any = A_arbace_go_repl_A_const_207.GetRawRoot__O(); var linked_2776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2775, aot_arbace_go_build.A_arbace_go_build_with_ctx_A_fn_class); var ifn_2777 lang.IFn; if linked_2776 == nil { ifn_2777 = lang.IFn_Cast(root_2775) } else { ifn_2777 = nil }; var arg_2778 any = ctx__11; var arg_2779 any; var tmp89 any = A_arbace_go_repl_define_BANG__fn__794000323_A_New_O(tree__36_2); var tmp90 *jrt.Class; var fncls__2784 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000323_A_fn_class; if fncls__2784 == nil { var fncls__2784d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_go_repl_define_BANG__fn__794000323_A_fn_class = fncls__2784d; tmp90 = fncls__2784d } else { tmp90 = fncls__2784 }; arg_2779 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp89, tmp90, nil); if linked_2776 == nil { tmp88 = ifn_2777.Invoke_O_O__O(arg_2778, arg_2779) } else { tmp88 = linked_2776.(*aot_arbace_go_build.A_arbace_go_build_with_ctx_A).Invoke_O_O_O__O(root_2775, arg_2778, arg_2779) }; tmp87.Invoke_O_O_O_O__O(Lit_74, cell__35_2, tmp88, nil) } else {
//line :345:1
									if A_arbace_go_repl_A_const_133 != nil {


										var tmp91 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()); var tmp92 any = A_arbace_go_repl_define_BANG__fn__794000325_A_New_O_O(tree__36_2, ctx__11); var tmp93 *jrt.Class; var fncls__2802 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000325_A_fn_class; if fncls__2802 == nil { var fncls__2802d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_go_repl_define_BANG__fn__794000325_A_fn_class = fncls__2802d; tmp93 = fncls__2802d } else { tmp93 = fncls__2802 }; tmp91.Invoke_O_O_O_O__O(Lit_74, cell__35_2, nil, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp92, tmp93, nil)) } } }
//line :343:1
					var tmp94 any; var root_2803 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2803, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2805 lang.IFn; if linked_2804 == nil { ifn_2805 = lang.IFn_Cast(root_2803) } else { ifn_2805 = nil }; var arg_2806 any = seq_794000299__30; if linked_2804 == nil { tmp94 = ifn_2805.Invoke_O__O(arg_2806) } else { tmp94 = linked_2804.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2803, arg_2806) }; seq_794000299__25, chunk_794000300__26, count_794000301__27, i_794000302__28 = tmp94, nil, 0, 0; continue L2 } else { var tmp95 any; var root_2807 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2807, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2809 lang.IFn; if linked_2808 == nil { ifn_2809 = lang.IFn_Cast(root_2807) } else { ifn_2809 = nil }; var arg_2810 any = seq_794000299__30; if linked_2808 == nil { tmp95 = ifn_2809.Invoke_O__O(arg_2810) } else { tmp95 = linked_2808.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2807, arg_2810) }; seq_794000299__25, chunk_794000300__26, count_794000301__27, i_794000302__28 = tmp95, nil, 0, 0; continue L2 } } } }
//line :270:1
			break L2 }; var seq_794000329__25 any; var root_2565 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2565, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2567 lang.IFn














































































		if linked_2566 == nil { ifn_2567 = lang.IFn_Cast(root_2565) } else { ifn_2567 = nil }; var arg_2568 any = init_cells__21; if linked_2566 == nil { seq_794000329__25 = ifn_2567.Invoke_O__O(arg_2568) } else { seq_794000329__25 = linked_2566.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2565, arg_2568) }
//line :270:1
		var chunk_794000330__26 any; var count_794000331__27 int64 = 0; var i_794000332__28 int64 = 0; L3: for {














































































			if lang.Numbers_Lt_J_J__Z_NoInit(i_794000332__28, count_794000331__27) { var map__794000333__29 any = lang.Indexed_Cast(chunk_794000330__26).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_794000332__28)); var map__794000333__30 any; if lang.ISeq_InstanceOf(map__794000333__29) { var tmp96 any; var root_2569 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2569, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2571 lang.IFn; if linked_2570 == nil { ifn_2571 = lang.IFn_Cast(root_2569) } else { ifn_2571 = nil }; var arg_2572 any = map__794000333__29; if linked_2570 == nil { tmp96 = ifn_2571.Invoke_O__O(arg_2572) } else { tmp96 = linked_2570.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2569, arg_2572) }; if jrt.J2g_Truth(tmp96) { var tmp97 any; var root_2573 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_2574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2573, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2575 lang.IFn; if linked_2574 == nil { ifn_2575 = lang.IFn_Cast(root_2573) } else { ifn_2575 = nil }; var arg_2576 any = map__794000333__29; if linked_2574 == nil { tmp97 = ifn_2575.Invoke_O__O(arg_2576) } else { tmp97 = linked_2574.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2573, arg_2576) }; map__794000333__30 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp97, jrt.Object_class.ArrayClass())).Ref() } else { var tmp98 any; var root_2577 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2577, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2579 lang.IFn; if linked_2578 == nil { ifn_2579 = lang.IFn_Cast(root_2577) } else { ifn_2579 = nil }; var arg_2580 any = map__794000333__29; if linked_2578 == nil { tmp98 = ifn_2579.Invoke_O__O(arg_2580) } else { tmp98 = linked_2578.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2577, arg_2580) }; if jrt.J2g_Truth(tmp98) { var root_2581 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2581, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2583 lang.IFn; if linked_2582 == nil { ifn_2583 = lang.IFn_Cast(root_2581) } else { ifn_2583 = nil }; var arg_2584 any = map__794000333__29; if linked_2582 == nil { map__794000333__30 = ifn_2583.Invoke_O__O(arg_2584) } else { map__794000333__30 = linked_2582.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2581, arg_2584) } } else { map__794000333__30 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000333__30 = map__794000333__29 }; var cell__31 any = lang.RT_Get_O_O__O_NoInit(map__794000333__30, A_arbace_go_repl_A_const_156); var tree__32 any = lang.RT_Get_O_O__O_NoInit(map__794000333__30, A_arbace_go_repl_A_const_185); var tmp99 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()); var tmp100 any; var root_2818 any = A_arbace_go_repl_A_const_207.GetRawRoot__O(); var linked_2819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2818, aot_arbace_go_build.A_arbace_go_build_with_ctx_A_fn_class); var ifn_2820 lang.IFn
				if linked_2819 == nil { ifn_2820 = lang.IFn_Cast(root_2818) } else { ifn_2820 = nil }; var arg_2821 any = ctx__11; var arg_2822 any; var tmp101 any = A_arbace_go_repl_define_BANG__fn__794000335_A_New_O(tree__32); var tmp102 *jrt.Class; var fncls__2827 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000335_A_fn_class; if fncls__2827 == nil { var fncls__2827d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_go_repl_define_BANG__fn__794000335_A_fn_class = fncls__2827d; tmp102 = fncls__2827d } else { tmp102 = fncls__2827 }; arg_2822 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp101, tmp102, nil); if linked_2819 == nil { tmp100 = ifn_2820.Invoke_O_O__O(arg_2821, arg_2822) } else { tmp100 = linked_2819.(*aot_arbace_go_build.A_arbace_go_build_with_ctx_A).Invoke_O_O_O__O(root_2818, arg_2821, arg_2822) }; tmp99.Invoke_O_O_O_O__O(Lit_74, cell__31, tmp100, nil)
//line :349:1
				seq_794000329__25, chunk_794000330__26, count_794000331__27, i_794000332__28 = seq_794000329__25, chunk_794000330__26, count_794000331__27, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000332__28); continue L3 } else { var temp__1927000414__auto____29_3 any; var root_2585 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2585, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2587 lang.IFn; if linked_2586 == nil { ifn_2587 = lang.IFn_Cast(root_2585) } else { ifn_2587 = nil }; var arg_2588 any = seq_794000329__25; if linked_2586 == nil { temp__1927000414__auto____29_3 = ifn_2587.Invoke_O__O(arg_2588) } else { temp__1927000414__auto____29_3 = linked_2586.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2585, arg_2588) }; if jrt.J2g_Truth(temp__1927000414__auto____29_3) { var seq_794000329__30 any = temp__1927000414__auto____29_3; var tmp103 any; var root_2589 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_2590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2589, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2591 lang.IFn; if linked_2590 == nil { ifn_2591 = lang.IFn_Cast(root_2589) } else { ifn_2591 = nil }; var arg_2592 any = seq_794000329__30; if linked_2590 == nil { tmp103 = ifn_2591.Invoke_O__O(arg_2592) } else { tmp103 = linked_2590.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2589, arg_2592) }; if jrt.J2g_Truth(tmp103) { var c__1927000678__auto____31_3 any; var root_2593 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_2594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2593, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2595 lang.IFn; if linked_2594 == nil { ifn_2595 = lang.IFn_Cast(root_2593) } else { ifn_2595 = nil }; var arg_2596 any = seq_794000329__30; if linked_2594 == nil { c__1927000678__auto____31_3 = ifn_2595.Invoke_O__O(arg_2596) } else { c__1927000678__auto____31_3 = linked_2594.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2593, arg_2596) }; var tmp104 any; var root_2828 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_2829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2828, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2830 lang.IFn; if linked_2829 == nil { ifn_2830 = lang.IFn_Cast(root_2828) } else { ifn_2830 = nil }; var arg_2831 any = seq_794000329__30; if linked_2829 == nil { tmp104 = ifn_2830.Invoke_O__O(arg_2831) } else { tmp104 = linked_2829.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2828, arg_2831) }; seq_794000329__25, chunk_794000330__26, count_794000331__27, i_794000332__28 = tmp104, c__1927000678__auto____31_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____31_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var map__794000337__31 any; var root_2597 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2597, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2599 lang.IFn; if linked_2598 == nil { ifn_2599 = lang.IFn_Cast(root_2597) } else { ifn_2599 = nil }; var arg_2600 any = seq_794000329__30; if linked_2598 == nil { map__794000337__31 = ifn_2599.Invoke_O__O(arg_2600) } else { map__794000337__31 = linked_2598.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2597, arg_2600) }; var map__794000337__32 any; if lang.ISeq_InstanceOf(map__794000337__31) { var tmp105 any; var root_2601 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2601, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2603 lang.IFn; if linked_2602 == nil { ifn_2603 = lang.IFn_Cast(root_2601) } else { ifn_2603 = nil }; var arg_2604 any = map__794000337__31; if linked_2602 == nil { tmp105 = ifn_2603.Invoke_O__O(arg_2604) } else { tmp105 = linked_2602.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2601, arg_2604) }; if jrt.J2g_Truth(tmp105) { var tmp106 any; var root_2605 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_2606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2605, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2607 lang.IFn; if linked_2606 == nil { ifn_2607 = lang.IFn_Cast(root_2605) } else { ifn_2607 = nil }; var arg_2608 any = map__794000337__31; if linked_2606 == nil { tmp106 = ifn_2607.Invoke_O__O(arg_2608) } else { tmp106 = linked_2606.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2605, arg_2608) }; map__794000337__32 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp106, jrt.Object_class.ArrayClass())).Ref() } else { var tmp107 any; var root_2609 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2609, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2611 lang.IFn; if linked_2610 == nil { ifn_2611 = lang.IFn_Cast(root_2609) } else { ifn_2611 = nil }; var arg_2612 any = map__794000337__31; if linked_2610 == nil { tmp107 = ifn_2611.Invoke_O__O(arg_2612) } else { tmp107 = linked_2610.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2609, arg_2612) }; if jrt.J2g_Truth(tmp107) { var root_2613 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2613, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2615 lang.IFn; if linked_2614 == nil { ifn_2615 = lang.IFn_Cast(root_2613) } else { ifn_2615 = nil }; var arg_2616 any = map__794000337__31; if linked_2614 == nil { map__794000337__32 = ifn_2615.Invoke_O__O(arg_2616) } else { map__794000337__32 = linked_2614.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2613, arg_2616) } } else { map__794000337__32 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000337__32 = map__794000337__31 }; var cell__33_3 any = lang.RT_Get_O_O__O_NoInit(map__794000337__32, A_arbace_go_repl_A_const_156); var tree__34_3 any = lang.RT_Get_O_O__O_NoInit(map__794000337__32, A_arbace_go_repl_A_const_185); var tmp108 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()); var tmp109 any; var root_2839 any = A_arbace_go_repl_A_const_207.GetRawRoot__O(); var linked_2840 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2839, aot_arbace_go_build.A_arbace_go_build_with_ctx_A_fn_class); var ifn_2841 lang.IFn
					if linked_2840 == nil { ifn_2841 = lang.IFn_Cast(root_2839) } else { ifn_2841 = nil }; var arg_2842 any = ctx__11; var arg_2843 any; var tmp110 any = A_arbace_go_repl_define_BANG__fn__794000339_A_New_O(tree__34_3); var tmp111 *jrt.Class; var fncls__2848 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000339_A_fn_class; if fncls__2848 == nil { var fncls__2848d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_go_repl_define_BANG__fn__794000339_A_fn_class = fncls__2848d; tmp111 = fncls__2848d } else { tmp111 = fncls__2848 }; arg_2843 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp110, tmp111, nil); if linked_2840 == nil { tmp109 = ifn_2841.Invoke_O_O__O(arg_2842, arg_2843) } else { tmp109 = linked_2840.(*aot_arbace_go_build.A_arbace_go_build_with_ctx_A).Invoke_O_O_O__O(root_2839, arg_2842, arg_2843) }; tmp108.Invoke_O_O_O_O__O(Lit_74, cell__33_3, tmp109, nil)
//line :349:1
					var tmp112 any; var root_2849 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2849, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2851 lang.IFn; if linked_2850 == nil { ifn_2851 = lang.IFn_Cast(root_2849) } else { ifn_2851 = nil }; var arg_2852 any = seq_794000329__30; if linked_2850 == nil { tmp112 = ifn_2851.Invoke_O__O(arg_2852) } else { tmp112 = linked_2850.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2849, arg_2852) }; seq_794000329__25, chunk_794000330__26, count_794000331__27, i_794000332__28 = tmp112, nil, 0, 0; continue L3 } } }
//line :270:1
			break L3 }; var var_trees__25 any; var root_1978 any = A_arbace_go_repl_A_const_88.GetRawRoot__O(); var linked_1979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1978, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1980 lang.IFn

















































































		if linked_1979 == nil { ifn_1980 = lang.IFn_Cast(root_1978) } else { ifn_1980 = nil }; var arg_1981 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1982 any; var iter__1927001039__auto____25 any; var tmp113 any = A_arbace_go_repl_define_BANG__iter__794000341__794000345_A_New(); var tmp114 *jrt.Class; var fncls__2057 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000341__794000345_A_fn_class; if fncls__2057 == nil { var fncls__2057d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_go_repl_define_BANG__iter__794000341__794000345_A_fn_class = fncls__2057d; tmp114 = fncls__2057d } else { tmp114 = fncls__2057 }; iter__1927001039__auto____25 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp113, tmp114, nil); arg_1982 = lang.IFn_Cast(iter__1927001039__auto____25).Invoke_O__O(decls__12); if linked_1979 == nil { var_trees__25 = ifn_1980.Invoke_O_O__O(arg_1981, arg_1982) } else { var_trees__25 = linked_1979.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1978, arg_1981, arg_1982) }
//line :270:1
		var ordered__26 any; var root_2058 any = A_arbace_go_repl_A_const_194.GetRawRoot__O(); var linked_2059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2058, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2060 lang.IFn



















































































		if linked_2059 == nil { ifn_2060 = lang.IFn_Cast(root_2058) } else { ifn_2060 = nil }; var arg_2061 any; var tmp115 any = A_arbace_go_repl_define_BANG__fn__794000351_A_New_O(var_trees__25); var tmp116 *jrt.Class; var fncls__2067 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000351_A_fn_class; if fncls__2067 == nil { var fncls__2067d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_go_repl_define_BANG__fn__794000351_A_fn_class = fncls__2067d; tmp116 = fncls__2067d } else { tmp116 = fncls__2067 }; arg_2061 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp115, tmp116, nil); var arg_2062 any = A_arbace_go_repl_A_const_195.Invoke_O__O(r__1); if linked_2059 == nil { ordered__26 = ifn_2060.Invoke_O_O__O(arg_2061, arg_2062) } else { ordered__26 = linked_2059.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2058, arg_2061, arg_2062) }
//line :270:1
		var inits__27 any = lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_89, Lit_90, A_arbace_go_repl_A_const_55.Invoke_O__O(old__13), nil); var ordered__28 any; var temp__1927000408__auto____28 any
		var or__1927000174__auto____28 any = init_names__10




















































































		if jrt.J2g_Truth(or__1927000174__auto____28) { temp__1927000408__auto____28 = or__1927000174__auto____28 } else { temp__1927000408__auto____28 = only__8 }; if jrt.J2g_Truth(temp__1927000408__auto____28) { var names__29 any = temp__1927000408__auto____28; var root_2075 any = A_arbace_go_repl_A_const_33.GetRawRoot__O(); var linked_2076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2075, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_2077 lang.IFn
			if linked_2076 == nil { ifn_2077 = lang.IFn_Cast(root_2075) } else { ifn_2077 = nil }; var arg_2078 any; var tmp117 any = A_arbace_go_repl_define_BANG__fn__794000353_A_New_O(names__29); var tmp118 *jrt.Class; var fncls__2096 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000353_A_fn_class; if fncls__2096 == nil { var fncls__2096d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_go_repl_define_BANG__fn__794000353_A_fn_class = fncls__2096d; tmp118 = fncls__2096d } else { tmp118 = fncls__2096 }; arg_2078 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp117, tmp118, nil); var arg_2079 any = ordered__26; if linked_2076 == nil { ordered__28 = ifn_2077.Invoke_O_O__O(arg_2078, arg_2079) } else { ordered__28 = linked_2076.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_2075, arg_2078, arg_2079) } } else {
//line :356:1
				ordered__28 = ordered__26
			}

		var tmp119 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()); var tmp120 any; var root_2860 any = A_arbace_go_repl_A_const_210.GetRawRoot__O(); var linked_2861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2860, aot_arbace_go_build.A_arbace_go_build_build_inits_A_fn_class); var ifn_2862 lang.IFn; if linked_2861 == nil { ifn_2862 = lang.IFn_Cast(root_2860) } else { ifn_2862 = nil }; var arg_2863 any = ordered__28; if linked_2861 == nil { tmp120 = ifn_2862.Invoke_O__O(arg_2863) } else { tmp120 = linked_2861.(*aot_arbace_go_build.A_arbace_go_build_build_inits_A).Invoke_O_O__O(root_2860, arg_2863) }; tmp119.Invoke_O_O_O_O__O(Lit_74, inits__27, tmp120, nil)

		if jrt.J2g_Truth(vars_QMARK___6) { var ns__29 any; var root_2864 any = A_arbace_go_repl_A_const_211.GetRawRoot__O(); var linked_2865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2864, aot_arbace_core.A_arbace_core_create_ns_A_fn_class); var ifn_2866 lang.IFn
			if linked_2865 == nil { ifn_2866 = lang.IFn_Cast(root_2864) } else { ifn_2866 = nil }; var arg_2867 any = A_arbace_go_repl_A_const_56.Invoke_O__O(old__13); if linked_2865 == nil { ns__29 = ifn_2866.Invoke_O__O(arg_2867) } else { ns__29 = linked_2865.(*aot_arbace_core.A_arbace_core_create_ns_A).Invoke_O_O__O(root_2864, arg_2867) }
//line :361:1
			var seq_794000357__30 any; var root_2913 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2913, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2915 lang.IFn

			if linked_2914 == nil { ifn_2915 = lang.IFn_Cast(root_2913) } else { ifn_2915 = nil }; var arg_2916 any = new_funcs__20; if linked_2914 == nil { seq_794000357__30 = ifn_2915.Invoke_O__O(arg_2916) } else { seq_794000357__30 = linked_2914.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2913, arg_2916) }
//line :361:1
			var chunk_794000358__31 any; var count_794000359__32 int64 = 0; var i_794000360__33 int64 = 0; L4: for {

				if lang.Numbers_Lt_J_J__Z_NoInit(i_794000360__33, count_794000359__32) { var vec__794000361__34 any = lang.Indexed_Cast(chunk_794000358__31).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_794000360__33)); var nm__35 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000361__34, lang.RT_IntCast_J__I_NoInit(0), nil); var map__794000364__36 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000361__34, lang.RT_IntCast_J__I_NoInit(1), nil); var map__794000364__37 any; if lang.ISeq_InstanceOf(map__794000364__36) { var tmp121 any; var root_2917 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2917, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2919 lang.IFn; if linked_2918 == nil { ifn_2919 = lang.IFn_Cast(root_2917) } else { ifn_2919 = nil }; var arg_2920 any = map__794000364__36; if linked_2918 == nil { tmp121 = ifn_2919.Invoke_O__O(arg_2920) } else { tmp121 = linked_2918.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2917, arg_2920) }; if jrt.J2g_Truth(tmp121) { var tmp122 any; var root_2921 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_2922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2921, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2923 lang.IFn; if linked_2922 == nil { ifn_2923 = lang.IFn_Cast(root_2921) } else { ifn_2923 = nil }; var arg_2924 any = map__794000364__36; if linked_2922 == nil { tmp122 = ifn_2923.Invoke_O__O(arg_2924) } else { tmp122 = linked_2922.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2921, arg_2924) }; map__794000364__37 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp122, jrt.Object_class.ArrayClass())).Ref() } else { var tmp123 any; var root_2925 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2925, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2927 lang.IFn; if linked_2926 == nil { ifn_2927 = lang.IFn_Cast(root_2925) } else { ifn_2927 = nil }; var arg_2928 any = map__794000364__36; if linked_2926 == nil { tmp123 = ifn_2927.Invoke_O__O(arg_2928) } else { tmp123 = linked_2926.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2925, arg_2928) }; if jrt.J2g_Truth(tmp123) { var root_2929 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2929, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2931 lang.IFn; if linked_2930 == nil { ifn_2931 = lang.IFn_Cast(root_2929) } else { ifn_2931 = nil }; var arg_2932 any = map__794000364__36; if linked_2930 == nil { map__794000364__37 = ifn_2931.Invoke_O__O(arg_2932) } else { map__794000364__37 = linked_2930.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2929, arg_2932) } } else { map__794000364__37 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000364__37 = map__794000364__36 }; var cell__38 any = lang.RT_Get_O_O__O_NoInit(map__794000364__37, A_arbace_go_repl_A_const_156); var obj__39 any = lang.RT_Get_O_O__O_NoInit(map__794000364__37, A_arbace_go_repl_A_const_181); var spec__40 any; var root_3075 any = A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_3076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3075, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3077 lang.IFn
					if linked_3076 == nil { ifn_3077 = lang.IFn_Cast(root_3075) } else { ifn_3077 = nil }; var arg_3078 any; var tmp124 any = A_arbace_go_repl_define_BANG__fn__794000366_A_New_O(obj__39); var tmp125 *jrt.Class; var fncls__3080 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000366_A_fn_class; if fncls__3080 == nil { var fncls__3080d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_go_repl_define_BANG__fn__794000366_A_fn_class = fncls__3080d; tmp125 = fncls__3080d } else { tmp125 = fncls__3080 }; arg_3078 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp124, tmp125, nil); var arg_3079 any = decls__12; if linked_3076 == nil { spec__40 = ifn_3077.Invoke_O_O__O(arg_3078, arg_3079) } else { spec__40 = linked_3076.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3075, arg_3078, arg_3079) }
//line :363:1
					var doc__41 any; var tmp126 any; var and__1927000168__auto____41 any; var root_3081 any = A_arbace_go_repl_A_const_34.GetRawRoot__O(); var linked_3082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3081, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_3083 lang.IFn

					if linked_3082 == nil { ifn_3083 = lang.IFn_Cast(root_3081) } else { ifn_3083 = nil }; var arg_3084 any = spec__40; if linked_3082 == nil { and__1927000168__auto____41 = ifn_3083.Invoke_O__O(arg_3084) } else { and__1927000168__auto____41 = linked_3082.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_3081, arg_3084) }; if jrt.J2g_Truth(and__1927000168__auto____41) { var root_3085 any = A_arbace_go_repl_A_const_90.GetRawRoot__O(); var linked_3086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3085, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_3087 lang.IFn; if linked_3086 == nil { ifn_3087 = lang.IFn_Cast(root_3085) } else { ifn_3087 = nil }; var arg_3088 any = lang.RT_Nth_O_I_O__O_NoInit(spec__40, lang.RT_IntCast_J__I_NoInit(2), nil); if linked_3086 == nil { tmp126 = ifn_3087.Invoke_O__O(arg_3088) } else { tmp126 = linked_3086.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_3085, arg_3088) } } else { tmp126 = and__1927000168__auto____41 }; if jrt.J2g_Truth(tmp126) { doc__41 = lang.RT_Nth_O_I__O_NoInit(spec__40, lang.RT_IntCast_J__I_NoInit(2)) } else { doc__41 = nil }
					var root_3089 any = A_arbace_go_repl_A_const_217.GetRawRoot__O(); var linked_3090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3089, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_3091 lang.IFn; if linked_3090 == nil { ifn_3091 = lang.IFn_Cast(root_3089) } else { ifn_3091 = nil }; var arg_3092 any = ns__29; var arg_3093 any; var root_3095 any = A_arbace_go_repl_A_const_218.GetRawRoot__O(); var linked_3096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3095, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3097 lang.IFn; if linked_3096 == nil { ifn_3097 = lang.IFn_Cast(root_3095) } else { ifn_3097 = nil }; var arg_3098 any; var root_3100 any = A_arbace_go_repl_A_const_46.GetRawRoot__O(); var linked_3101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3100, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3102 lang.IFn; if linked_3101 == nil { ifn_3102 = lang.IFn_Cast(root_3100) } else { ifn_3102 = nil }; var arg_3103 any = nm__35; if linked_3101 == nil { arg_3098 = ifn_3102.Invoke_O__O(arg_3103) } else { arg_3098 = linked_3101.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3100, arg_3103) }; var arg_3099 any; var G__794000368__42_ any; var tmp127 any = A_arbace_go_repl_A_const_219; var tmp128 any = A_arbace_go_repl_A_const_137; var tmp129 any = A_arbace_go_repl_A_const_220; var tmp130 any = A_arbace_go_repl_A_const_54.Invoke_O__O(old__13); var tmp131 any = A_arbace_go_repl_A_const_111; var tmp132 any; var root_3104 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3104, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3106 lang.IFn; if linked_3105 == nil { ifn_3106 = lang.IFn_Cast(root_3104) } else { ifn_3106 = nil }; var arg_3107 any = obj__39; var arg_3108 any = A_arbace_go_repl_A_const_111; if linked_3105 == nil { tmp132 = ifn_3106.Invoke_O_O__O(arg_3107, arg_3108) } else { tmp132 = linked_3105.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3104, arg_3107, arg_3108) }; var tmp133 any = tmp132; var tmp134 any = A_arbace_go_repl_A_const_110; var tmp135 any; var root_3109 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3109, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3111 lang.IFn
					if linked_3110 == nil { ifn_3111 = lang.IFn_Cast(root_3109) } else { ifn_3111 = nil }; var arg_3112 any = obj__39; var arg_3113 any = A_arbace_go_repl_A_const_110; if linked_3110 == nil { tmp135 = ifn_3111.Invoke_O_O__O(arg_3112, arg_3113) } else { tmp135 = linked_3110.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3109, arg_3112, arg_3113) }
//line :366:1
					var tmp136 any = tmp135; var tmp137 any = A_arbace_go_repl_A_const_221; var tmp138 any; var root_3114 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_3115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3114, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3116 lang.IFn
					if linked_3115 == nil { ifn_3116 = lang.IFn_Cast(root_3114) } else { ifn_3116 = nil }; var arg_3117 any; var root_3118 any = A_arbace_go_repl_A_const_222.GetRawRoot__O(); var linked_3119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3118, aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A_fn_class); var ifn_3120 lang.IFn; if linked_3119 == nil { ifn_3120 = lang.IFn_Cast(root_3118) } else { ifn_3120 = nil }; var arg_3121 any = nm__35; if linked_3119 == nil { arg_3117 = ifn_3120.Invoke_O__O(arg_3121) } else { arg_3117 = linked_3119.(*aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A).Invoke_O_O__O(root_3118, arg_3121) }; if linked_3115 == nil { tmp138 = ifn_3116.Invoke_O__O(arg_3117) } else { tmp138 = linked_3115.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3114, arg_3117) }
//line :366:1
					G__794000368__42_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp127, tmp128, tmp129, tmp130, tmp131, tmp133, tmp134, tmp136, tmp137, tmp138)); if jrt.J2g_Truth(doc__41) {

						var root_3122 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var linked_3123 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3122, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3124 lang.IFn; if linked_3123 == nil { ifn_3124 = lang.IFn_Cast(root_3122) } else { ifn_3124 = nil }; var arg_3125 any = G__794000368__42_; var arg_3126 any = A_arbace_go_repl_A_const_85; var arg_3127 any = doc__41; if linked_3123 == nil { arg_3099 = ifn_3124.Invoke_O_O_O__O(arg_3125, arg_3126, arg_3127) } else { arg_3099 = linked_3123.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3122, arg_3125, arg_3126, arg_3127) } } else {
//line :366:1
							arg_3099 = G__794000368__42_ }; if linked_3096 == nil { arg_3093 = ifn_3097.Invoke_O_O__O(arg_3098, arg_3099) } else { arg_3093 = linked_3096.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3095, arg_3098, arg_3099) }; var arg_3094 any; var tmp139 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()); var tmp140 any; var root_3135 any = A_arbace_go_repl_A_const_191.GetRawRoot__O(); var linked_3136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3135, aot_arbace_go_build.A_arbace_go_build_desc_A_fn_class); var ifn_3137 lang.IFn


					if linked_3136 == nil { ifn_3137 = lang.IFn_Cast(root_3135) } else { ifn_3137 = nil }; var arg_3138 any; var root_3139 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3139, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3141 lang.IFn; if linked_3140 == nil { ifn_3141 = lang.IFn_Cast(root_3139) } else { ifn_3141 = nil }; var arg_3142 any = obj__39; var arg_3143 any = A_arbace_go_repl_A_const_142; if linked_3140 == nil { arg_3138 = ifn_3141.Invoke_O_O__O(arg_3142, arg_3143) } else { arg_3138 = linked_3140.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3139, arg_3142, arg_3143) }; if linked_3136 == nil { tmp140 = ifn_3137.Invoke_O__O(arg_3138) } else { tmp140 = linked_3136.(*aot_arbace_go_build.A_arbace_go_build_desc_A).Invoke_O_O__O(root_3135, arg_3138) }
//line :366:1
					arg_3094 = lang.GoFn_New_O_String(tmp139.Invoke_O_O_O_O__O(Lit_13, cell__38, tmp140, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_repl_A_const_54.Invoke_O__O(old__13), nil, nm__35)).Ref()), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_repl_A_const_54.Invoke_O__O(old__13), nil, nm__35))); if linked_3090 == nil { ifn_3091.Invoke_O_O_O__O(arg_3092, arg_3093, arg_3094) } else { linked_3090.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O_O__O(root_3089, arg_3092, arg_3093, arg_3094) }
//line :363:1
					seq_794000357__30, chunk_794000358__31, count_794000359__32, i_794000360__33 = seq_794000357__30, chunk_794000358__31, count_794000359__32, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000360__33); continue L4 } else { var temp__1927000414__auto____34 any; var root_2933 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2933, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2935 lang.IFn; if linked_2934 == nil { ifn_2935 = lang.IFn_Cast(root_2933) } else { ifn_2935 = nil }; var arg_2936 any = seq_794000357__30; if linked_2934 == nil { temp__1927000414__auto____34 = ifn_2935.Invoke_O__O(arg_2936) } else { temp__1927000414__auto____34 = linked_2934.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2933, arg_2936) }; if jrt.J2g_Truth(temp__1927000414__auto____34) { var seq_794000357__35 any = temp__1927000414__auto____34; var tmp141 any; var root_2937 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_2938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2937, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2939 lang.IFn; if linked_2938 == nil { ifn_2939 = lang.IFn_Cast(root_2937) } else { ifn_2939 = nil }; var arg_2940 any = seq_794000357__35; if linked_2938 == nil { tmp141 = ifn_2939.Invoke_O__O(arg_2940) } else { tmp141 = linked_2938.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2937, arg_2940) }; if jrt.J2g_Truth(tmp141) { var c__1927000678__auto____36 any; var root_2941 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_2942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2941, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2943 lang.IFn; if linked_2942 == nil { ifn_2943 = lang.IFn_Cast(root_2941) } else { ifn_2943 = nil }; var arg_2944 any = seq_794000357__35; if linked_2942 == nil { c__1927000678__auto____36 = ifn_2943.Invoke_O__O(arg_2944) } else { c__1927000678__auto____36 = linked_2942.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2941, arg_2944) }; var tmp142 any; var root_3144 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_3145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3144, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3146 lang.IFn; if linked_3145 == nil { ifn_3146 = lang.IFn_Cast(root_3144) } else { ifn_3146 = nil }; var arg_3147 any = seq_794000357__35; if linked_3145 == nil { tmp142 = ifn_3146.Invoke_O__O(arg_3147) } else { tmp142 = linked_3145.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3144, arg_3147) }; seq_794000357__30, chunk_794000358__31, count_794000359__32, i_794000360__33 = tmp142, c__1927000678__auto____36, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____36))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var vec__794000369__36 any; var root_2945 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2945, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2947 lang.IFn; if linked_2946 == nil { ifn_2947 = lang.IFn_Cast(root_2945) } else { ifn_2947 = nil }; var arg_2948 any = seq_794000357__35; if linked_2946 == nil { vec__794000369__36 = ifn_2947.Invoke_O__O(arg_2948) } else { vec__794000369__36 = linked_2946.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2945, arg_2948) }; var nm__37 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000369__36, lang.RT_IntCast_J__I_NoInit(0), nil); var map__794000372__38 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000369__36, lang.RT_IntCast_J__I_NoInit(1), nil); var map__794000372__39 any; if lang.ISeq_InstanceOf(map__794000372__38) { var tmp143 any; var root_2949 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2949, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2951 lang.IFn; if linked_2950 == nil { ifn_2951 = lang.IFn_Cast(root_2949) } else { ifn_2951 = nil }; var arg_2952 any = map__794000372__38; if linked_2950 == nil { tmp143 = ifn_2951.Invoke_O__O(arg_2952) } else { tmp143 = linked_2950.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2949, arg_2952) }; if jrt.J2g_Truth(tmp143) { var tmp144 any; var root_2953 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_2954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2953, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2955 lang.IFn; if linked_2954 == nil { ifn_2955 = lang.IFn_Cast(root_2953) } else { ifn_2955 = nil }; var arg_2956 any = map__794000372__38; if linked_2954 == nil { tmp144 = ifn_2955.Invoke_O__O(arg_2956) } else { tmp144 = linked_2954.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2953, arg_2956) }; map__794000372__39 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp144, jrt.Object_class.ArrayClass())).Ref() } else { var tmp145 any; var root_2957 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2957, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2959 lang.IFn; if linked_2958 == nil { ifn_2959 = lang.IFn_Cast(root_2957) } else { ifn_2959 = nil }; var arg_2960 any = map__794000372__38; if linked_2958 == nil { tmp145 = ifn_2959.Invoke_O__O(arg_2960) } else { tmp145 = linked_2958.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2957, arg_2960) }; if jrt.J2g_Truth(tmp145) { var root_2961 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2961, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2963 lang.IFn; if linked_2962 == nil { ifn_2963 = lang.IFn_Cast(root_2961) } else { ifn_2963 = nil }; var arg_2964 any = map__794000372__38; if linked_2962 == nil { map__794000372__39 = ifn_2963.Invoke_O__O(arg_2964) } else { map__794000372__39 = linked_2962.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2961, arg_2964) } } else { map__794000372__39 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000372__39 = map__794000372__38 }; var cell__40 any = lang.RT_Get_O_O__O_NoInit(map__794000372__39, A_arbace_go_repl_A_const_156); var obj__41 any = lang.RT_Get_O_O__O_NoInit(map__794000372__39, A_arbace_go_repl_A_const_181); var spec__42 any; var root_3148 any = A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_3149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3148, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3150 lang.IFn
						if linked_3149 == nil { ifn_3150 = lang.IFn_Cast(root_3148) } else { ifn_3150 = nil }; var arg_3151 any; var tmp146 any = A_arbace_go_repl_define_BANG__fn__794000374_A_New_O(obj__41); var tmp147 *jrt.Class; var fncls__3153 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000374_A_fn_class; if fncls__3153 == nil { var fncls__3153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_go_repl_define_BANG__fn__794000374_A_fn_class = fncls__3153d; tmp147 = fncls__3153d } else { tmp147 = fncls__3153 }; arg_3151 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp146, tmp147, nil); var arg_3152 any = decls__12; if linked_3149 == nil { spec__42 = ifn_3150.Invoke_O_O__O(arg_3151, arg_3152) } else { spec__42 = linked_3149.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3148, arg_3151, arg_3152) }
//line :363:1
						var doc__43 any; var tmp148 any; var and__1927000168__auto____43 any; var root_3154 any = A_arbace_go_repl_A_const_34.GetRawRoot__O(); var linked_3155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3154, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_3156 lang.IFn

						if linked_3155 == nil { ifn_3156 = lang.IFn_Cast(root_3154) } else { ifn_3156 = nil }; var arg_3157 any = spec__42; if linked_3155 == nil { and__1927000168__auto____43 = ifn_3156.Invoke_O__O(arg_3157) } else { and__1927000168__auto____43 = linked_3155.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_3154, arg_3157) }; if jrt.J2g_Truth(and__1927000168__auto____43) { var root_3158 any = A_arbace_go_repl_A_const_90.GetRawRoot__O(); var linked_3159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3158, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_3160 lang.IFn; if linked_3159 == nil { ifn_3160 = lang.IFn_Cast(root_3158) } else { ifn_3160 = nil }; var arg_3161 any = lang.RT_Nth_O_I_O__O_NoInit(spec__42, lang.RT_IntCast_J__I_NoInit(2), nil); if linked_3159 == nil { tmp148 = ifn_3160.Invoke_O__O(arg_3161) } else { tmp148 = linked_3159.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_3158, arg_3161) } } else { tmp148 = and__1927000168__auto____43 }; if jrt.J2g_Truth(tmp148) { doc__43 = lang.RT_Nth_O_I__O_NoInit(spec__42, lang.RT_IntCast_J__I_NoInit(2)) } else { doc__43 = nil }
						var root_3162 any = A_arbace_go_repl_A_const_217.GetRawRoot__O(); var linked_3163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3162, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_3164 lang.IFn; if linked_3163 == nil { ifn_3164 = lang.IFn_Cast(root_3162) } else { ifn_3164 = nil }; var arg_3165 any = ns__29; var arg_3166 any; var root_3168 any = A_arbace_go_repl_A_const_218.GetRawRoot__O(); var linked_3169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3168, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3170 lang.IFn; if linked_3169 == nil { ifn_3170 = lang.IFn_Cast(root_3168) } else { ifn_3170 = nil }; var arg_3171 any; var root_3173 any = A_arbace_go_repl_A_const_46.GetRawRoot__O(); var linked_3174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3173, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3175 lang.IFn; if linked_3174 == nil { ifn_3175 = lang.IFn_Cast(root_3173) } else { ifn_3175 = nil }; var arg_3176 any = nm__37; if linked_3174 == nil { arg_3171 = ifn_3175.Invoke_O__O(arg_3176) } else { arg_3171 = linked_3174.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3173, arg_3176) }; var arg_3172 any; var G__794000376__44_ any; var tmp149 any = A_arbace_go_repl_A_const_219; var tmp150 any = A_arbace_go_repl_A_const_137; var tmp151 any = A_arbace_go_repl_A_const_220; var tmp152 any = A_arbace_go_repl_A_const_54.Invoke_O__O(old__13); var tmp153 any = A_arbace_go_repl_A_const_111; var tmp154 any; var root_3177 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3177, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3179 lang.IFn; if linked_3178 == nil { ifn_3179 = lang.IFn_Cast(root_3177) } else { ifn_3179 = nil }; var arg_3180 any = obj__41; var arg_3181 any = A_arbace_go_repl_A_const_111; if linked_3178 == nil { tmp154 = ifn_3179.Invoke_O_O__O(arg_3180, arg_3181) } else { tmp154 = linked_3178.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3177, arg_3180, arg_3181) }; var tmp155 any = tmp154; var tmp156 any = A_arbace_go_repl_A_const_110; var tmp157 any; var root_3182 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3182, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3184 lang.IFn
						if linked_3183 == nil { ifn_3184 = lang.IFn_Cast(root_3182) } else { ifn_3184 = nil }; var arg_3185 any = obj__41; var arg_3186 any = A_arbace_go_repl_A_const_110; if linked_3183 == nil { tmp157 = ifn_3184.Invoke_O_O__O(arg_3185, arg_3186) } else { tmp157 = linked_3183.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3182, arg_3185, arg_3186) }
//line :366:1
						var tmp158 any = tmp157; var tmp159 any = A_arbace_go_repl_A_const_221; var tmp160 any; var root_3187 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_3188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3187, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3189 lang.IFn
						if linked_3188 == nil { ifn_3189 = lang.IFn_Cast(root_3187) } else { ifn_3189 = nil }; var arg_3190 any; var root_3191 any = A_arbace_go_repl_A_const_222.GetRawRoot__O(); var linked_3192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3191, aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A_fn_class); var ifn_3193 lang.IFn; if linked_3192 == nil { ifn_3193 = lang.IFn_Cast(root_3191) } else { ifn_3193 = nil }; var arg_3194 any = nm__37; if linked_3192 == nil { arg_3190 = ifn_3193.Invoke_O__O(arg_3194) } else { arg_3190 = linked_3192.(*aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A).Invoke_O_O__O(root_3191, arg_3194) }; if linked_3188 == nil { tmp160 = ifn_3189.Invoke_O__O(arg_3190) } else { tmp160 = linked_3188.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3187, arg_3190) }
//line :366:1
						G__794000376__44_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp149, tmp150, tmp151, tmp152, tmp153, tmp155, tmp156, tmp158, tmp159, tmp160)); if jrt.J2g_Truth(doc__43) {

							var root_3195 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var linked_3196 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3195, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3197 lang.IFn; if linked_3196 == nil { ifn_3197 = lang.IFn_Cast(root_3195) } else { ifn_3197 = nil }; var arg_3198 any = G__794000376__44_; var arg_3199 any = A_arbace_go_repl_A_const_85; var arg_3200 any = doc__43; if linked_3196 == nil { arg_3172 = ifn_3197.Invoke_O_O_O__O(arg_3198, arg_3199, arg_3200) } else { arg_3172 = linked_3196.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3195, arg_3198, arg_3199, arg_3200) } } else {
//line :366:1
								arg_3172 = G__794000376__44_ }; if linked_3169 == nil { arg_3166 = ifn_3170.Invoke_O_O__O(arg_3171, arg_3172) } else { arg_3166 = linked_3169.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3168, arg_3171, arg_3172) }; var arg_3167 any; var tmp161 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()); var tmp162 any; var root_3208 any = A_arbace_go_repl_A_const_191.GetRawRoot__O(); var linked_3209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3208, aot_arbace_go_build.A_arbace_go_build_desc_A_fn_class); var ifn_3210 lang.IFn


						if linked_3209 == nil { ifn_3210 = lang.IFn_Cast(root_3208) } else { ifn_3210 = nil }; var arg_3211 any; var root_3212 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3212, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3214 lang.IFn; if linked_3213 == nil { ifn_3214 = lang.IFn_Cast(root_3212) } else { ifn_3214 = nil }; var arg_3215 any = obj__41; var arg_3216 any = A_arbace_go_repl_A_const_142; if linked_3213 == nil { arg_3211 = ifn_3214.Invoke_O_O__O(arg_3215, arg_3216) } else { arg_3211 = linked_3213.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3212, arg_3215, arg_3216) }; if linked_3209 == nil { tmp162 = ifn_3210.Invoke_O__O(arg_3211) } else { tmp162 = linked_3209.(*aot_arbace_go_build.A_arbace_go_build_desc_A).Invoke_O_O__O(root_3208, arg_3211) }
//line :366:1
						arg_3167 = lang.GoFn_New_O_String(tmp161.Invoke_O_O_O_O__O(Lit_13, cell__40, tmp162, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_repl_A_const_54.Invoke_O__O(old__13), nil, nm__37)).Ref()), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_repl_A_const_54.Invoke_O__O(old__13), nil, nm__37))); if linked_3163 == nil { ifn_3164.Invoke_O_O_O__O(arg_3165, arg_3166, arg_3167) } else { linked_3163.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O_O__O(root_3162, arg_3165, arg_3166, arg_3167) }
//line :363:1
						var tmp163 any; var root_3217 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_3218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3217, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3219 lang.IFn; if linked_3218 == nil { ifn_3219 = lang.IFn_Cast(root_3217) } else { ifn_3219 = nil }; var arg_3220 any = seq_794000357__35; if linked_3218 == nil { tmp163 = ifn_3219.Invoke_O__O(arg_3220) } else { tmp163 = linked_3218.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3217, arg_3220) }; seq_794000357__30, chunk_794000358__31, count_794000359__32, i_794000360__33 = tmp163, nil, 0, 0; continue L4 } } }
//line :361:1
				break L4 }; var seq_794000377__30 any; var root_2965 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2965, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2967 lang.IFn









			if linked_2966 == nil { ifn_2967 = lang.IFn_Cast(root_2965) } else { ifn_2967 = nil }; var arg_2968 any = globals__24; if linked_2966 == nil { seq_794000377__30 = ifn_2967.Invoke_O__O(arg_2968) } else { seq_794000377__30 = linked_2966.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2965, arg_2968) }
//line :361:1
			var chunk_794000378__31 any; var count_794000379__32 int64 = 0; var i_794000380__33 int64 = 0; L5: for {









				if lang.Numbers_Lt_J_J__Z_NoInit(i_794000380__33, count_794000379__32) { var vec__794000381__34 any = lang.Indexed_Cast(chunk_794000378__31).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_794000380__33)); var nm__35_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000381__34, lang.RT_IntCast_J__I_NoInit(0), nil); var map__794000384__36 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000381__34, lang.RT_IntCast_J__I_NoInit(1), nil); var map__794000384__37 any; if lang.ISeq_InstanceOf(map__794000384__36) { var tmp164 any; var root_2969 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_2970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2969, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2971 lang.IFn; if linked_2970 == nil { ifn_2971 = lang.IFn_Cast(root_2969) } else { ifn_2971 = nil }; var arg_2972 any = map__794000384__36; if linked_2970 == nil { tmp164 = ifn_2971.Invoke_O__O(arg_2972) } else { tmp164 = linked_2970.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2969, arg_2972) }; if jrt.J2g_Truth(tmp164) { var tmp165 any; var root_2973 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_2974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2973, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2975 lang.IFn; if linked_2974 == nil { ifn_2975 = lang.IFn_Cast(root_2973) } else { ifn_2975 = nil }; var arg_2976 any = map__794000384__36; if linked_2974 == nil { tmp165 = ifn_2975.Invoke_O__O(arg_2976) } else { tmp165 = linked_2974.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2973, arg_2976) }; map__794000384__37 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp165, jrt.Object_class.ArrayClass())).Ref() } else { var tmp166 any; var root_2977 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2977, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2979 lang.IFn; if linked_2978 == nil { ifn_2979 = lang.IFn_Cast(root_2977) } else { ifn_2979 = nil }; var arg_2980 any = map__794000384__36; if linked_2978 == nil { tmp166 = ifn_2979.Invoke_O__O(arg_2980) } else { tmp166 = linked_2978.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2977, arg_2980) }; if jrt.J2g_Truth(tmp166) { var root_2981 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2981, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2983 lang.IFn; if linked_2982 == nil { ifn_2983 = lang.IFn_Cast(root_2981) } else { ifn_2983 = nil }; var arg_2984 any = map__794000384__36; if linked_2982 == nil { map__794000384__37 = ifn_2983.Invoke_O__O(arg_2984) } else { map__794000384__37 = linked_2982.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2981, arg_2984) } } else { map__794000384__37 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000384__37 = map__794000384__36 }; var ptr__38 any = lang.RT_Get_O_O__O_NoInit(map__794000384__37, A_arbace_go_repl_A_const_190); var obj__39_2 any = lang.RT_Get_O_O__O_NoInit(map__794000384__37, A_arbace_go_repl_A_const_181); var root_3221 any = A_arbace_go_repl_A_const_217.GetRawRoot__O(); var linked_3222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3221, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_3223 lang.IFn
					if linked_3222 == nil { ifn_3223 = lang.IFn_Cast(root_3221) } else { ifn_3223 = nil }; var arg_3224 any = ns__29; var arg_3225 any; var root_3227 any = A_arbace_go_repl_A_const_218.GetRawRoot__O(); var linked_3228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3227, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3229 lang.IFn; if linked_3228 == nil { ifn_3229 = lang.IFn_Cast(root_3227) } else { ifn_3229 = nil }; var arg_3230 any; var root_3232 any = A_arbace_go_repl_A_const_46.GetRawRoot__O(); var linked_3233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3232, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3234 lang.IFn; if linked_3233 == nil { ifn_3234 = lang.IFn_Cast(root_3232) } else { ifn_3234 = nil }; var arg_3235 any = nm__35_2; if linked_3233 == nil { arg_3230 = ifn_3234.Invoke_O__O(arg_3235) } else { arg_3230 = linked_3233.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3232, arg_3235) }; var arg_3231 any; var tmp167 any = A_arbace_go_repl_A_const_219; var tmp168 any = A_arbace_go_repl_A_const_187; var tmp169 any = A_arbace_go_repl_A_const_220; var tmp170 any = A_arbace_go_repl_A_const_54.Invoke_O__O(old__13); var tmp171 any = A_arbace_go_repl_A_const_221; var tmp172 any; var root_3236 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_3237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3236, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3238 lang.IFn; if linked_3237 == nil { ifn_3238 = lang.IFn_Cast(root_3236) } else { ifn_3238 = nil }; var arg_3239 any; var root_3240 any = A_arbace_go_repl_A_const_222.GetRawRoot__O(); var linked_3241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3240, aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A_fn_class); var ifn_3242 lang.IFn; if linked_3241 == nil { ifn_3242 = lang.IFn_Cast(root_3240) } else { ifn_3242 = nil }; var arg_3243 any = nm__35_2; if linked_3241 == nil { arg_3239 = ifn_3242.Invoke_O__O(arg_3243) } else { arg_3239 = linked_3241.(*aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A).Invoke_O_O__O(root_3240, arg_3243) }; if linked_3237 == nil { tmp172 = ifn_3238.Invoke_O__O(arg_3239) } else { tmp172 = linked_3237.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3236, arg_3239) }; arg_3231 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp167, tmp168, tmp169, tmp170, tmp171, tmp172)); if linked_3228 == nil { arg_3225 = ifn_3229.Invoke_O_O__O(arg_3230, arg_3231) } else { arg_3225 = linked_3228.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3227, arg_3230, arg_3231) }; var arg_3226 any; var tmp173 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()); var tmp174 any; var root_3250 any = A_arbace_go_repl_A_const_191.GetRawRoot__O(); var linked_3251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3250, aot_arbace_go_build.A_arbace_go_build_desc_A_fn_class); var ifn_3252 lang.IFn
					if linked_3251 == nil { ifn_3252 = lang.IFn_Cast(root_3250) } else { ifn_3252 = nil }; var arg_3253 any; var root_3254 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3254, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3256 lang.IFn; if linked_3255 == nil { ifn_3256 = lang.IFn_Cast(root_3254) } else { ifn_3256 = nil }; var arg_3257 any = obj__39_2; var arg_3258 any = A_arbace_go_repl_A_const_142; if linked_3255 == nil { arg_3253 = ifn_3256.Invoke_O_O__O(arg_3257, arg_3258) } else { arg_3253 = linked_3255.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3254, arg_3257, arg_3258) }; if linked_3251 == nil { tmp174 = ifn_3252.Invoke_O__O(arg_3253) } else { tmp174 = linked_3251.(*aot_arbace_go_build.A_arbace_go_build_desc_A).Invoke_O_O__O(root_3250, arg_3253) }
//line :372:1
					arg_3226 = lang.GoVar_New_O_String(tmp173.Invoke_O_O_O__O(Lit_94, tmp174, ptr__38), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_repl_A_const_54.Invoke_O__O(old__13), nil, nm__35_2))); if linked_3222 == nil { ifn_3223.Invoke_O_O_O__O(arg_3224, arg_3225, arg_3226) } else { linked_3222.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O_O__O(root_3221, arg_3224, arg_3225, arg_3226) }
//line :371:1
					seq_794000377__30, chunk_794000378__31, count_794000379__32, i_794000380__33 = seq_794000377__30, chunk_794000378__31, count_794000379__32, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000380__33); continue L5 } else { var temp__1927000414__auto____34_2 any; var root_2985 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2985, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2987 lang.IFn; if linked_2986 == nil { ifn_2987 = lang.IFn_Cast(root_2985) } else { ifn_2987 = nil }; var arg_2988 any = seq_794000377__30; if linked_2986 == nil { temp__1927000414__auto____34_2 = ifn_2987.Invoke_O__O(arg_2988) } else { temp__1927000414__auto____34_2 = linked_2986.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2985, arg_2988) }; if jrt.J2g_Truth(temp__1927000414__auto____34_2) { var seq_794000377__35 any = temp__1927000414__auto____34_2; var tmp175 any; var root_2989 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_2990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2989, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2991 lang.IFn; if linked_2990 == nil { ifn_2991 = lang.IFn_Cast(root_2989) } else { ifn_2991 = nil }; var arg_2992 any = seq_794000377__35; if linked_2990 == nil { tmp175 = ifn_2991.Invoke_O__O(arg_2992) } else { tmp175 = linked_2990.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2989, arg_2992) }; if jrt.J2g_Truth(tmp175) { var c__1927000678__auto____36_2 any; var root_2993 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_2994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2993, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2995 lang.IFn; if linked_2994 == nil { ifn_2995 = lang.IFn_Cast(root_2993) } else { ifn_2995 = nil }; var arg_2996 any = seq_794000377__35; if linked_2994 == nil { c__1927000678__auto____36_2 = ifn_2995.Invoke_O__O(arg_2996) } else { c__1927000678__auto____36_2 = linked_2994.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2993, arg_2996) }; var tmp176 any; var root_3259 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_3260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3259, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3261 lang.IFn; if linked_3260 == nil { ifn_3261 = lang.IFn_Cast(root_3259) } else { ifn_3261 = nil }; var arg_3262 any = seq_794000377__35; if linked_3260 == nil { tmp176 = ifn_3261.Invoke_O__O(arg_3262) } else { tmp176 = linked_3260.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3259, arg_3262) }; seq_794000377__30, chunk_794000378__31, count_794000379__32, i_794000380__33 = tmp176, c__1927000678__auto____36_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____36_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var vec__794000386__36 any; var root_2997 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2997, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2999 lang.IFn; if linked_2998 == nil { ifn_2999 = lang.IFn_Cast(root_2997) } else { ifn_2999 = nil }; var arg_3000 any = seq_794000377__35; if linked_2998 == nil { vec__794000386__36 = ifn_2999.Invoke_O__O(arg_3000) } else { vec__794000386__36 = linked_2998.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2997, arg_3000) }; var nm__37_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000386__36, lang.RT_IntCast_J__I_NoInit(0), nil); var map__794000389__38 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000386__36, lang.RT_IntCast_J__I_NoInit(1), nil); var map__794000389__39 any; if lang.ISeq_InstanceOf(map__794000389__38) { var tmp177 any; var root_3001 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_3002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3001, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3003 lang.IFn; if linked_3002 == nil { ifn_3003 = lang.IFn_Cast(root_3001) } else { ifn_3003 = nil }; var arg_3004 any = map__794000389__38; if linked_3002 == nil { tmp177 = ifn_3003.Invoke_O__O(arg_3004) } else { tmp177 = linked_3002.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3001, arg_3004) }; if jrt.J2g_Truth(tmp177) { var tmp178 any; var root_3005 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_3006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3005, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3007 lang.IFn; if linked_3006 == nil { ifn_3007 = lang.IFn_Cast(root_3005) } else { ifn_3007 = nil }; var arg_3008 any = map__794000389__38; if linked_3006 == nil { tmp178 = ifn_3007.Invoke_O__O(arg_3008) } else { tmp178 = linked_3006.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3005, arg_3008) }; map__794000389__39 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp178, jrt.Object_class.ArrayClass())).Ref() } else { var tmp179 any; var root_3009 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_3010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3009, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3011 lang.IFn; if linked_3010 == nil { ifn_3011 = lang.IFn_Cast(root_3009) } else { ifn_3011 = nil }; var arg_3012 any = map__794000389__38; if linked_3010 == nil { tmp179 = ifn_3011.Invoke_O__O(arg_3012) } else { tmp179 = linked_3010.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3009, arg_3012) }; if jrt.J2g_Truth(tmp179) { var root_3013 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_3014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3013, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3015 lang.IFn; if linked_3014 == nil { ifn_3015 = lang.IFn_Cast(root_3013) } else { ifn_3015 = nil }; var arg_3016 any = map__794000389__38; if linked_3014 == nil { map__794000389__39 = ifn_3015.Invoke_O__O(arg_3016) } else { map__794000389__39 = linked_3014.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3013, arg_3016) } } else { map__794000389__39 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000389__39 = map__794000389__38 }; var ptr__40 any = lang.RT_Get_O_O__O_NoInit(map__794000389__39, A_arbace_go_repl_A_const_190); var obj__41_2 any = lang.RT_Get_O_O__O_NoInit(map__794000389__39, A_arbace_go_repl_A_const_181); var root_3263 any = A_arbace_go_repl_A_const_217.GetRawRoot__O(); var linked_3264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3263, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_3265 lang.IFn
						if linked_3264 == nil { ifn_3265 = lang.IFn_Cast(root_3263) } else { ifn_3265 = nil }; var arg_3266 any = ns__29; var arg_3267 any; var root_3269 any = A_arbace_go_repl_A_const_218.GetRawRoot__O(); var linked_3270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3269, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3271 lang.IFn; if linked_3270 == nil { ifn_3271 = lang.IFn_Cast(root_3269) } else { ifn_3271 = nil }; var arg_3272 any; var root_3274 any = A_arbace_go_repl_A_const_46.GetRawRoot__O(); var linked_3275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3274, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3276 lang.IFn; if linked_3275 == nil { ifn_3276 = lang.IFn_Cast(root_3274) } else { ifn_3276 = nil }; var arg_3277 any = nm__37_2; if linked_3275 == nil { arg_3272 = ifn_3276.Invoke_O__O(arg_3277) } else { arg_3272 = linked_3275.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3274, arg_3277) }; var arg_3273 any; var tmp180 any = A_arbace_go_repl_A_const_219; var tmp181 any = A_arbace_go_repl_A_const_187; var tmp182 any = A_arbace_go_repl_A_const_220; var tmp183 any = A_arbace_go_repl_A_const_54.Invoke_O__O(old__13); var tmp184 any = A_arbace_go_repl_A_const_221; var tmp185 any; var root_3278 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_3279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3278, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3280 lang.IFn; if linked_3279 == nil { ifn_3280 = lang.IFn_Cast(root_3278) } else { ifn_3280 = nil }; var arg_3281 any; var root_3282 any = A_arbace_go_repl_A_const_222.GetRawRoot__O(); var linked_3283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3282, aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A_fn_class); var ifn_3284 lang.IFn; if linked_3283 == nil { ifn_3284 = lang.IFn_Cast(root_3282) } else { ifn_3284 = nil }; var arg_3285 any = nm__37_2; if linked_3283 == nil { arg_3281 = ifn_3284.Invoke_O__O(arg_3285) } else { arg_3281 = linked_3283.(*aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A).Invoke_O_O__O(root_3282, arg_3285) }; if linked_3279 == nil { tmp185 = ifn_3280.Invoke_O__O(arg_3281) } else { tmp185 = linked_3279.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3278, arg_3281) }; arg_3273 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp180, tmp181, tmp182, tmp183, tmp184, tmp185)); if linked_3270 == nil { arg_3267 = ifn_3271.Invoke_O_O__O(arg_3272, arg_3273) } else { arg_3267 = linked_3270.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3269, arg_3272, arg_3273) }; var arg_3268 any; var tmp186 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()); var tmp187 any; var root_3292 any = A_arbace_go_repl_A_const_191.GetRawRoot__O(); var linked_3293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3292, aot_arbace_go_build.A_arbace_go_build_desc_A_fn_class); var ifn_3294 lang.IFn
						if linked_3293 == nil { ifn_3294 = lang.IFn_Cast(root_3292) } else { ifn_3294 = nil }; var arg_3295 any; var root_3296 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3296, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3298 lang.IFn; if linked_3297 == nil { ifn_3298 = lang.IFn_Cast(root_3296) } else { ifn_3298 = nil }; var arg_3299 any = obj__41_2; var arg_3300 any = A_arbace_go_repl_A_const_142; if linked_3297 == nil { arg_3295 = ifn_3298.Invoke_O_O__O(arg_3299, arg_3300) } else { arg_3295 = linked_3297.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3296, arg_3299, arg_3300) }; if linked_3293 == nil { tmp187 = ifn_3294.Invoke_O__O(arg_3295) } else { tmp187 = linked_3293.(*aot_arbace_go_build.A_arbace_go_build_desc_A).Invoke_O_O__O(root_3292, arg_3295) }
//line :372:1
						arg_3268 = lang.GoVar_New_O_String(tmp186.Invoke_O_O_O__O(Lit_94, tmp187, ptr__40), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_repl_A_const_54.Invoke_O__O(old__13), nil, nm__37_2))); if linked_3264 == nil { ifn_3265.Invoke_O_O_O__O(arg_3266, arg_3267, arg_3268) } else { linked_3264.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O_O__O(root_3263, arg_3266, arg_3267, arg_3268) }
//line :371:1
						var tmp188 any; var root_3301 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_3302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3301, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3303 lang.IFn; if linked_3302 == nil { ifn_3303 = lang.IFn_Cast(root_3301) } else { ifn_3303 = nil }; var arg_3304 any = seq_794000377__35; if linked_3302 == nil { tmp188 = ifn_3303.Invoke_O__O(arg_3304) } else { tmp188 = linked_3302.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3301, arg_3304) }; seq_794000377__30, chunk_794000378__31, count_794000379__32, i_794000380__33 = tmp188, nil, 0, 0; continue L5 } } }
//line :361:1
				break L5 }; var seq_794000391__30 any; var root_3017 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_3018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3017, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3019 lang.IFn












			if linked_3018 == nil { ifn_3019 = lang.IFn_Cast(root_3017) } else { ifn_3019 = nil }; var arg_3020 any = decls__12; if linked_3018 == nil { seq_794000391__30 = ifn_3019.Invoke_O__O(arg_3020) } else { seq_794000391__30 = linked_3018.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3017, arg_3020) }
//line :361:1
			var chunk_794000392__31 any; var count_794000393__32 int64 = 0; var i_794000394__33 int64 = 0; L6: for {












				if lang.Numbers_Lt_J_J__Z_NoInit(i_794000394__33, count_794000393__32) { var d__34 any = lang.Indexed_Cast(chunk_794000392__31).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_794000394__33)); var tmp189 any = A_arbace_go_repl_A_const_214; if lang.Util_Equiv_O_O__Z_NoInit(tmp189, A_arbace_go_repl_A_const_178.Invoke_O__O(d__34)) { var x__35 any = A_arbace_go_repl_A_const_181.Invoke_O__O(d__34); var tmp190 any; var root_3021 any = A_arbace_go_repl_A_const_180.GetRawRoot__O(); var linked_3022 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3021, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_3023 lang.IFn
					if linked_3022 == nil { ifn_3023 = lang.IFn_Cast(root_3021) } else { ifn_3023 = nil }; var arg_3024 any = Lit_4; var arg_3025 any; var root_3026 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3026, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3028 lang.IFn; if linked_3027 == nil { ifn_3028 = lang.IFn_Cast(root_3026) } else { ifn_3028 = nil }; var arg_3029 any = x__35; var arg_3030 any = A_arbace_go_repl_A_const_55; if linked_3027 == nil { arg_3025 = ifn_3028.Invoke_O_O__O(arg_3029, arg_3030) } else { arg_3025 = linked_3027.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3026, arg_3029, arg_3030) }; if linked_3022 == nil { tmp190 = ifn_3023.Invoke_O_O__O(arg_3024, arg_3025) } else { tmp190 = linked_3022.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_3021, arg_3024, arg_3025) }
//line :374:1
					if jrt.J2g_Truth(tmp190) { var tmp191 any; var root_3031 any = A_arbace_go_repl_A_const_215.GetRawRoot__O(); var linked_3032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3031, aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A_fn_class); var ifn_3033 lang.IFn

						if linked_3032 == nil { ifn_3033 = lang.IFn_Cast(root_3031) } else { ifn_3033 = nil }; var arg_3034 any; var root_3035 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3035, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3037 lang.IFn; if linked_3036 == nil { ifn_3037 = lang.IFn_Cast(root_3035) } else { ifn_3037 = nil }; var arg_3038 any = x__35; var arg_3039 any = A_arbace_go_repl_A_const_142; if linked_3036 == nil { arg_3034 = ifn_3037.Invoke_O_O__O(arg_3038, arg_3039) } else { arg_3034 = linked_3036.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3035, arg_3038, arg_3039) }; if linked_3032 == nil { tmp191 = ifn_3033.Invoke_O__O(arg_3034) } else { tmp191 = linked_3032.(*aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A).Invoke_O_O__O(root_3031, arg_3034) }
//line :374:1
						if jrt.J2g_Truth(tmp191) {


							var root_3305 any = A_arbace_go_repl_A_const_217.GetRawRoot__O(); var linked_3306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3305, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_3307 lang.IFn; if linked_3306 == nil { ifn_3307 = lang.IFn_Cast(root_3305) } else { ifn_3307 = nil }; var arg_3308 any = ns__29; var arg_3309 any; var root_3311 any = A_arbace_go_repl_A_const_218.GetRawRoot__O(); var linked_3312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3311, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3313 lang.IFn; if linked_3312 == nil { ifn_3313 = lang.IFn_Cast(root_3311) } else { ifn_3313 = nil }; var arg_3314 any; var root_3316 any = A_arbace_go_repl_A_const_46.GetRawRoot__O(); var linked_3317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3316, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3318 lang.IFn; if linked_3317 == nil { ifn_3318 = lang.IFn_Cast(root_3316) } else { ifn_3318 = nil }; var arg_3319 any; var root_3320 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3320, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3322 lang.IFn; if linked_3321 == nil { ifn_3322 = lang.IFn_Cast(root_3320) } else { ifn_3322 = nil }; var arg_3323 any = x__35; var arg_3324 any = A_arbace_go_repl_A_const_55; if linked_3321 == nil { arg_3319 = ifn_3322.Invoke_O_O__O(arg_3323, arg_3324) } else { arg_3319 = linked_3321.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3320, arg_3323, arg_3324) }; if linked_3317 == nil { arg_3314 = ifn_3318.Invoke_O__O(arg_3319) } else { arg_3314 = linked_3317.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3316, arg_3319) }; var arg_3315 any; var tmp192 any = A_arbace_go_repl_A_const_219; var tmp193 any = A_arbace_go_repl_A_const_214; var tmp194 any = A_arbace_go_repl_A_const_220; var tmp195 any = A_arbace_go_repl_A_const_54.Invoke_O__O(old__13); var tmp196 any = A_arbace_go_repl_A_const_221; var tmp197 any; var root_3325 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_3326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3325, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3327 lang.IFn
							if linked_3326 == nil { ifn_3327 = lang.IFn_Cast(root_3325) } else { ifn_3327 = nil }; var arg_3328 any; var root_3329 any = A_arbace_go_repl_A_const_222.GetRawRoot__O(); var linked_3330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3329, aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A_fn_class); var ifn_3331 lang.IFn; if linked_3330 == nil { ifn_3331 = lang.IFn_Cast(root_3329) } else { ifn_3331 = nil }; var arg_3332 any; var root_3333 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3333, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3335 lang.IFn; if linked_3334 == nil { ifn_3335 = lang.IFn_Cast(root_3333) } else { ifn_3335 = nil }; var arg_3336 any = x__35; var arg_3337 any = A_arbace_go_repl_A_const_55; if linked_3334 == nil { arg_3332 = ifn_3335.Invoke_O_O__O(arg_3336, arg_3337) } else { arg_3332 = linked_3334.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3333, arg_3336, arg_3337) }; if linked_3330 == nil { arg_3328 = ifn_3331.Invoke_O__O(arg_3332) } else { arg_3328 = linked_3330.(*aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A).Invoke_O_O__O(root_3329, arg_3332) }; if linked_3326 == nil { tmp197 = ifn_3327.Invoke_O__O(arg_3328) } else { tmp197 = linked_3326.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3325, arg_3328) }
//line :377:1
							arg_3315 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp192, tmp193, tmp194, tmp195, tmp196, tmp197)); if linked_3312 == nil { arg_3309 = ifn_3313.Invoke_O_O__O(arg_3314, arg_3315) } else { arg_3309 = linked_3312.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3311, arg_3314, arg_3315) }; var arg_3310 any; var root_3338 any = A_arbace_go_repl_A_const_223.GetRawRoot__O(); var linked_3339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3338, A_arbace_go_repl_const_arbace_A_fn_class); var ifn_3340 lang.IFn

							if linked_3339 == nil { ifn_3340 = lang.IFn_Cast(root_3338) } else { ifn_3340 = nil }; var arg_3341 any; var root_3343 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3343, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3345 lang.IFn; if linked_3344 == nil { ifn_3345 = lang.IFn_Cast(root_3343) } else { ifn_3345 = nil }; var arg_3346 any = x__35; var arg_3347 any = A_arbace_go_repl_A_const_142; if linked_3344 == nil { arg_3341 = ifn_3345.Invoke_O_O__O(arg_3346, arg_3347) } else { arg_3341 = linked_3344.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3343, arg_3346, arg_3347) }; var arg_3342 any; var root_3348 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3348, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3350 lang.IFn; if linked_3349 == nil { ifn_3350 = lang.IFn_Cast(root_3348) } else { ifn_3350 = nil }; var arg_3351 any = x__35; var arg_3352 any = A_arbace_go_repl_A_const_224; if linked_3349 == nil { arg_3342 = ifn_3350.Invoke_O_O__O(arg_3351, arg_3352) } else { arg_3342 = linked_3349.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3348, arg_3351, arg_3352) }; if linked_3339 == nil { arg_3310 = ifn_3340.Invoke_O_O__O(arg_3341, arg_3342) } else { arg_3310 = linked_3339.(*A_arbace_go_repl_const_arbace_A).Invoke_O_O_O__O(root_3338, arg_3341, arg_3342) }
//line :377:1
							if linked_3306 == nil { ifn_3307.Invoke_O_O_O__O(arg_3308, arg_3309, arg_3310) } else { linked_3306.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O_O__O(root_3305, arg_3308, arg_3309, arg_3310) }
//line :374:1
							seq_794000391__30, chunk_794000392__31, count_794000393__32, i_794000394__33 = seq_794000391__30, chunk_794000392__31, count_794000393__32, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000394__33); continue L6 } else { seq_794000391__30, chunk_794000392__31, count_794000393__32, i_794000394__33 = seq_794000391__30, chunk_794000392__31, count_794000393__32, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000394__33); continue L6 } } else { seq_794000391__30, chunk_794000392__31, count_794000393__32, i_794000394__33 = seq_794000391__30, chunk_794000392__31, count_794000393__32, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000394__33); continue L6 } } else { seq_794000391__30, chunk_794000392__31, count_794000393__32, i_794000394__33 = seq_794000391__30, chunk_794000392__31, count_794000393__32, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000394__33); continue L6 } } else { var temp__1927000414__auto____34_3 any; var root_3040 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_3041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3040, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3042 lang.IFn; if linked_3041 == nil { ifn_3042 = lang.IFn_Cast(root_3040) } else { ifn_3042 = nil }; var arg_3043 any = seq_794000391__30; if linked_3041 == nil { temp__1927000414__auto____34_3 = ifn_3042.Invoke_O__O(arg_3043) } else { temp__1927000414__auto____34_3 = linked_3041.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3040, arg_3043) }; if jrt.J2g_Truth(temp__1927000414__auto____34_3) { var seq_794000391__35 any = temp__1927000414__auto____34_3; var tmp198 any; var root_3044 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_3045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3044, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3046 lang.IFn; if linked_3045 == nil { ifn_3046 = lang.IFn_Cast(root_3044) } else { ifn_3046 = nil }; var arg_3047 any = seq_794000391__35; if linked_3045 == nil { tmp198 = ifn_3046.Invoke_O__O(arg_3047) } else { tmp198 = linked_3045.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3044, arg_3047) }; if jrt.J2g_Truth(tmp198) { var c__1927000678__auto____36_3 any; var root_3048 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_3049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3048, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3050 lang.IFn; if linked_3049 == nil { ifn_3050 = lang.IFn_Cast(root_3048) } else { ifn_3050 = nil }; var arg_3051 any = seq_794000391__35; if linked_3049 == nil { c__1927000678__auto____36_3 = ifn_3050.Invoke_O__O(arg_3051) } else { c__1927000678__auto____36_3 = linked_3049.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3048, arg_3051) }; var tmp199 any; var root_3353 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_3354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3353, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3355 lang.IFn; if linked_3354 == nil { ifn_3355 = lang.IFn_Cast(root_3353) } else { ifn_3355 = nil }; var arg_3356 any = seq_794000391__35; if linked_3354 == nil { tmp199 = ifn_3355.Invoke_O__O(arg_3356) } else { tmp199 = linked_3354.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3353, arg_3356) }; seq_794000391__30, chunk_794000392__31, count_794000393__32, i_794000394__33 = tmp199, c__1927000678__auto____36_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____36_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L6 } else { var d__36 any; var root_3052 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_3053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3052, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3054 lang.IFn; if linked_3053 == nil { ifn_3054 = lang.IFn_Cast(root_3052) } else { ifn_3054 = nil }; var arg_3055 any = seq_794000391__35; if linked_3053 == nil { d__36 = ifn_3054.Invoke_O__O(arg_3055) } else { d__36 = linked_3053.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3052, arg_3055) }; var tmp200 any = A_arbace_go_repl_A_const_214; if lang.Util_Equiv_O_O__Z_NoInit(tmp200, A_arbace_go_repl_A_const_178.Invoke_O__O(d__36)) { var x__37 any = A_arbace_go_repl_A_const_181.Invoke_O__O(d__36); var tmp201 any; var root_3056 any = A_arbace_go_repl_A_const_180.GetRawRoot__O(); var linked_3057 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3056, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_3058 lang.IFn
								if linked_3057 == nil { ifn_3058 = lang.IFn_Cast(root_3056) } else { ifn_3058 = nil }; var arg_3059 any = Lit_4; var arg_3060 any; var root_3061 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3061, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3063 lang.IFn; if linked_3062 == nil { ifn_3063 = lang.IFn_Cast(root_3061) } else { ifn_3063 = nil }; var arg_3064 any = x__37; var arg_3065 any = A_arbace_go_repl_A_const_55; if linked_3062 == nil { arg_3060 = ifn_3063.Invoke_O_O__O(arg_3064, arg_3065) } else { arg_3060 = linked_3062.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3061, arg_3064, arg_3065) }; if linked_3057 == nil { tmp201 = ifn_3058.Invoke_O_O__O(arg_3059, arg_3060) } else { tmp201 = linked_3057.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_3056, arg_3059, arg_3060) }
//line :374:1
								if jrt.J2g_Truth(tmp201) { var tmp202 any; var root_3066 any = A_arbace_go_repl_A_const_215.GetRawRoot__O(); var linked_3067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3066, aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A_fn_class); var ifn_3068 lang.IFn

									if linked_3067 == nil { ifn_3068 = lang.IFn_Cast(root_3066) } else { ifn_3068 = nil }; var arg_3069 any; var root_3070 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3070, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3072 lang.IFn; if linked_3071 == nil { ifn_3072 = lang.IFn_Cast(root_3070) } else { ifn_3072 = nil }; var arg_3073 any = x__37; var arg_3074 any = A_arbace_go_repl_A_const_142; if linked_3071 == nil { arg_3069 = ifn_3072.Invoke_O_O__O(arg_3073, arg_3074) } else { arg_3069 = linked_3071.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3070, arg_3073, arg_3074) }; if linked_3067 == nil { tmp202 = ifn_3068.Invoke_O__O(arg_3069) } else { tmp202 = linked_3067.(*aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A).Invoke_O_O__O(root_3066, arg_3069) }
//line :374:1
									if jrt.J2g_Truth(tmp202) {


										var root_3357 any = A_arbace_go_repl_A_const_217.GetRawRoot__O(); var linked_3358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3357, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_3359 lang.IFn; if linked_3358 == nil { ifn_3359 = lang.IFn_Cast(root_3357) } else { ifn_3359 = nil }; var arg_3360 any = ns__29; var arg_3361 any; var root_3363 any = A_arbace_go_repl_A_const_218.GetRawRoot__O(); var linked_3364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3363, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3365 lang.IFn; if linked_3364 == nil { ifn_3365 = lang.IFn_Cast(root_3363) } else { ifn_3365 = nil }; var arg_3366 any; var root_3368 any = A_arbace_go_repl_A_const_46.GetRawRoot__O(); var linked_3369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3368, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3370 lang.IFn; if linked_3369 == nil { ifn_3370 = lang.IFn_Cast(root_3368) } else { ifn_3370 = nil }; var arg_3371 any; var root_3372 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3372, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3374 lang.IFn; if linked_3373 == nil { ifn_3374 = lang.IFn_Cast(root_3372) } else { ifn_3374 = nil }; var arg_3375 any = x__37; var arg_3376 any = A_arbace_go_repl_A_const_55; if linked_3373 == nil { arg_3371 = ifn_3374.Invoke_O_O__O(arg_3375, arg_3376) } else { arg_3371 = linked_3373.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3372, arg_3375, arg_3376) }; if linked_3369 == nil { arg_3366 = ifn_3370.Invoke_O__O(arg_3371) } else { arg_3366 = linked_3369.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3368, arg_3371) }; var arg_3367 any; var tmp203 any = A_arbace_go_repl_A_const_219; var tmp204 any = A_arbace_go_repl_A_const_214; var tmp205 any = A_arbace_go_repl_A_const_220; var tmp206 any = A_arbace_go_repl_A_const_54.Invoke_O__O(old__13); var tmp207 any = A_arbace_go_repl_A_const_221; var tmp208 any; var root_3377 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_3378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3377, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3379 lang.IFn
										if linked_3378 == nil { ifn_3379 = lang.IFn_Cast(root_3377) } else { ifn_3379 = nil }; var arg_3380 any; var root_3381 any = A_arbace_go_repl_A_const_222.GetRawRoot__O(); var linked_3382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3381, aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A_fn_class); var ifn_3383 lang.IFn; if linked_3382 == nil { ifn_3383 = lang.IFn_Cast(root_3381) } else { ifn_3383 = nil }; var arg_3384 any; var root_3385 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3385, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3387 lang.IFn; if linked_3386 == nil { ifn_3387 = lang.IFn_Cast(root_3385) } else { ifn_3387 = nil }; var arg_3388 any = x__37; var arg_3389 any = A_arbace_go_repl_A_const_55; if linked_3386 == nil { arg_3384 = ifn_3387.Invoke_O_O__O(arg_3388, arg_3389) } else { arg_3384 = linked_3386.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3385, arg_3388, arg_3389) }; if linked_3382 == nil { arg_3380 = ifn_3383.Invoke_O__O(arg_3384) } else { arg_3380 = linked_3382.(*aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A).Invoke_O_O__O(root_3381, arg_3384) }; if linked_3378 == nil { tmp208 = ifn_3379.Invoke_O__O(arg_3380) } else { tmp208 = linked_3378.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3377, arg_3380) }
//line :377:1
										arg_3367 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp203, tmp204, tmp205, tmp206, tmp207, tmp208)); if linked_3364 == nil { arg_3361 = ifn_3365.Invoke_O_O__O(arg_3366, arg_3367) } else { arg_3361 = linked_3364.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3363, arg_3366, arg_3367) }; var arg_3362 any; var root_3390 any = A_arbace_go_repl_A_const_223.GetRawRoot__O(); var linked_3391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3390, A_arbace_go_repl_const_arbace_A_fn_class); var ifn_3392 lang.IFn

										if linked_3391 == nil { ifn_3392 = lang.IFn_Cast(root_3390) } else { ifn_3392 = nil }; var arg_3393 any; var root_3395 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3395, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3397 lang.IFn; if linked_3396 == nil { ifn_3397 = lang.IFn_Cast(root_3395) } else { ifn_3397 = nil }; var arg_3398 any = x__37; var arg_3399 any = A_arbace_go_repl_A_const_142; if linked_3396 == nil { arg_3393 = ifn_3397.Invoke_O_O__O(arg_3398, arg_3399) } else { arg_3393 = linked_3396.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3395, arg_3398, arg_3399) }; var arg_3394 any; var root_3400 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3400, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3402 lang.IFn; if linked_3401 == nil { ifn_3402 = lang.IFn_Cast(root_3400) } else { ifn_3402 = nil }; var arg_3403 any = x__37; var arg_3404 any = A_arbace_go_repl_A_const_224; if linked_3401 == nil { arg_3394 = ifn_3402.Invoke_O_O__O(arg_3403, arg_3404) } else { arg_3394 = linked_3401.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3400, arg_3403, arg_3404) }; if linked_3391 == nil { arg_3362 = ifn_3392.Invoke_O_O__O(arg_3393, arg_3394) } else { arg_3362 = linked_3391.(*A_arbace_go_repl_const_arbace_A).Invoke_O_O_O__O(root_3390, arg_3393, arg_3394) }
//line :377:1
										if linked_3358 == nil { ifn_3359.Invoke_O_O_O__O(arg_3360, arg_3361, arg_3362) } else { linked_3358.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O_O__O(root_3357, arg_3360, arg_3361, arg_3362) }
//line :374:1
										var tmp209 any; var root_3405 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_3406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3405, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3407 lang.IFn; if linked_3406 == nil { ifn_3407 = lang.IFn_Cast(root_3405) } else { ifn_3407 = nil }; var arg_3408 any = seq_794000391__35; if linked_3406 == nil { tmp209 = ifn_3407.Invoke_O__O(arg_3408) } else { tmp209 = linked_3406.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3405, arg_3408) }; seq_794000391__30, chunk_794000392__31, count_794000393__32, i_794000394__33 = tmp209, nil, 0, 0; continue L6 } else { var tmp210 any; var root_3409 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_3410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3409, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3411 lang.IFn; if linked_3410 == nil { ifn_3411 = lang.IFn_Cast(root_3409) } else { ifn_3411 = nil }; var arg_3412 any = seq_794000391__35; if linked_3410 == nil { tmp210 = ifn_3411.Invoke_O__O(arg_3412) } else { tmp210 = linked_3410.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3409, arg_3412) }; seq_794000391__30, chunk_794000392__31, count_794000393__32, i_794000394__33 = tmp210, nil, 0, 0; continue L6 } } else { var tmp211 any; var root_3413 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_3414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3413, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3415 lang.IFn; if linked_3414 == nil { ifn_3415 = lang.IFn_Cast(root_3413) } else { ifn_3415 = nil }; var arg_3416 any = seq_794000391__35; if linked_3414 == nil { tmp211 = ifn_3415.Invoke_O__O(arg_3416) } else { tmp211 = linked_3414.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3413, arg_3416) }; seq_794000391__30, chunk_794000392__31, count_794000393__32, i_794000394__33 = tmp211, nil, 0, 0; continue L6 } } else { var tmp212 any; var root_3417 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_3418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3417, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3419 lang.IFn; if linked_3418 == nil { ifn_3419 = lang.IFn_Cast(root_3417) } else { ifn_3419 = nil }; var arg_3420 any = seq_794000391__35; if linked_3418 == nil { tmp212 = ifn_3419.Invoke_O__O(arg_3420) } else { tmp212 = linked_3418.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3417, arg_3420) }; seq_794000391__30, chunk_794000392__31, count_794000393__32, i_794000394__33 = tmp212, nil, 0, 0; continue L6 } } } }
//line :361:1
				break L6 }; var seq_794000395__30 any; var root_2868 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2869 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2868, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2870 lang.IFn


















			if linked_2869 == nil { ifn_2870 = lang.IFn_Cast(root_2868) } else { ifn_2870 = nil }; var arg_2871 any = decls__12; if linked_2869 == nil { seq_794000395__30 = ifn_2870.Invoke_O__O(arg_2871) } else { seq_794000395__30 = linked_2869.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2868, arg_2871) }
//line :361:1
			var chunk_794000396__31 any; var count_794000397__32 int64 = 0; var i_794000398__33 int64 = 0; L7: for {


















				if lang.Numbers_Lt_J_J__Z_NoInit(i_794000398__33, count_794000397__32) { var d__34_2 any = lang.Indexed_Cast(chunk_794000396__31).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_794000398__33)); var tmp213 any = A_arbace_go_repl_A_const_142; if lang.Util_Equiv_O_O__Z_NoInit(tmp213, A_arbace_go_repl_A_const_178.Invoke_O__O(d__34_2)) { var x__35_2 any = A_arbace_go_repl_A_const_181.Invoke_O__O(d__34_2); var tmp214 any; var root_2872 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_2873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2872, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2874 lang.IFn
					if linked_2873 == nil { ifn_2874 = lang.IFn_Cast(root_2872) } else { ifn_2874 = nil }; var arg_2875 any; var root_2876 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2876, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2878 lang.IFn; if linked_2877 == nil { ifn_2878 = lang.IFn_Cast(root_2876) } else { ifn_2878 = nil }; var arg_2879 any = x__35_2; var arg_2880 any = A_arbace_go_repl_A_const_212; if linked_2877 == nil { arg_2875 = ifn_2878.Invoke_O_O__O(arg_2879, arg_2880) } else { arg_2875 = linked_2877.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2876, arg_2879, arg_2880) }; if linked_2873 == nil { tmp214 = ifn_2874.Invoke_O__O(arg_2875) } else { tmp214 = linked_2873.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2872, arg_2875) }
//line :380:1
					if jrt.J2g_Truth(tmp214) {

						var tmp215 any = A_arbace_go_repl_define_BANG__fn__794000399_A_New_O_O_O(ns__29, x__35_2, old__13); var tmp216 *jrt.Class; var fncls__3463 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000399_A_fn_class; if fncls__3463 == nil { var fncls__3463d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_go_repl_define_BANG__fn__794000399_A_fn_class = fncls__3463d; tmp216 = fncls__3463d } else { tmp216 = fncls__3463 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp215, tmp216, nil).Invoke__O()
//line :380:1
						seq_794000395__30, chunk_794000396__31, count_794000397__32, i_794000398__33 = seq_794000395__30, chunk_794000396__31, count_794000397__32, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000398__33); continue L7 } else { seq_794000395__30, chunk_794000396__31, count_794000397__32, i_794000398__33 = seq_794000395__30, chunk_794000396__31, count_794000397__32, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000398__33); continue L7 } } else { seq_794000395__30, chunk_794000396__31, count_794000397__32, i_794000398__33 = seq_794000395__30, chunk_794000396__31, count_794000397__32, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000398__33); continue L7 } } else { var temp__1927000414__auto____34_4 any; var root_2881 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2881, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2883 lang.IFn; if linked_2882 == nil { ifn_2883 = lang.IFn_Cast(root_2881) } else { ifn_2883 = nil }; var arg_2884 any = seq_794000395__30; if linked_2882 == nil { temp__1927000414__auto____34_4 = ifn_2883.Invoke_O__O(arg_2884) } else { temp__1927000414__auto____34_4 = linked_2882.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2881, arg_2884) }; if jrt.J2g_Truth(temp__1927000414__auto____34_4) { var seq_794000395__35 any = temp__1927000414__auto____34_4; var tmp217 any; var root_2885 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_2886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2885, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2887 lang.IFn; if linked_2886 == nil { ifn_2887 = lang.IFn_Cast(root_2885) } else { ifn_2887 = nil }; var arg_2888 any = seq_794000395__35; if linked_2886 == nil { tmp217 = ifn_2887.Invoke_O__O(arg_2888) } else { tmp217 = linked_2886.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2885, arg_2888) }; if jrt.J2g_Truth(tmp217) { var c__1927000678__auto____36_4 any; var root_2889 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_2890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2889, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2891 lang.IFn; if linked_2890 == nil { ifn_2891 = lang.IFn_Cast(root_2889) } else { ifn_2891 = nil }; var arg_2892 any = seq_794000395__35; if linked_2890 == nil { c__1927000678__auto____36_4 = ifn_2891.Invoke_O__O(arg_2892) } else { c__1927000678__auto____36_4 = linked_2890.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2889, arg_2892) }; var tmp218 any; var root_3464 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_3465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3464, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3466 lang.IFn; if linked_3465 == nil { ifn_3466 = lang.IFn_Cast(root_3464) } else { ifn_3466 = nil }; var arg_3467 any = seq_794000395__35; if linked_3465 == nil { tmp218 = ifn_3466.Invoke_O__O(arg_3467) } else { tmp218 = linked_3465.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3464, arg_3467) }; seq_794000395__30, chunk_794000396__31, count_794000397__32, i_794000398__33 = tmp218, c__1927000678__auto____36_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____36_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L7 } else { var d__36_2 any; var root_2893 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2893, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2895 lang.IFn; if linked_2894 == nil { ifn_2895 = lang.IFn_Cast(root_2893) } else { ifn_2895 = nil }; var arg_2896 any = seq_794000395__35; if linked_2894 == nil { d__36_2 = ifn_2895.Invoke_O__O(arg_2896) } else { d__36_2 = linked_2894.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2893, arg_2896) }; var tmp219 any = A_arbace_go_repl_A_const_142; if lang.Util_Equiv_O_O__Z_NoInit(tmp219, A_arbace_go_repl_A_const_178.Invoke_O__O(d__36_2)) { var x__37_2 any = A_arbace_go_repl_A_const_181.Invoke_O__O(d__36_2); var tmp220 any; var root_2897 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_2898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2897, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2899 lang.IFn
							if linked_2898 == nil { ifn_2899 = lang.IFn_Cast(root_2897) } else { ifn_2899 = nil }; var arg_2900 any; var root_2901 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2901, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2903 lang.IFn; if linked_2902 == nil { ifn_2903 = lang.IFn_Cast(root_2901) } else { ifn_2903 = nil }; var arg_2904 any = x__37_2; var arg_2905 any = A_arbace_go_repl_A_const_212; if linked_2902 == nil { arg_2900 = ifn_2903.Invoke_O_O__O(arg_2904, arg_2905) } else { arg_2900 = linked_2902.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2901, arg_2904, arg_2905) }; if linked_2898 == nil { tmp220 = ifn_2899.Invoke_O__O(arg_2900) } else { tmp220 = linked_2898.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2897, arg_2900) }
//line :380:1
							if jrt.J2g_Truth(tmp220) {

								var tmp221 any = A_arbace_go_repl_define_BANG__fn__794000401_A_New_O_O_O(ns__29, x__37_2, old__13); var tmp222 *jrt.Class; var fncls__3510 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000401_A_fn_class; if fncls__3510 == nil { var fncls__3510d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_go_repl_define_BANG__fn__794000401_A_fn_class = fncls__3510d; tmp222 = fncls__3510d } else { tmp222 = fncls__3510 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp221, tmp222, nil).Invoke__O()
//line :380:1
								var tmp223 any; var root_3511 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_3512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3511, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3513 lang.IFn; if linked_3512 == nil { ifn_3513 = lang.IFn_Cast(root_3511) } else { ifn_3513 = nil }; var arg_3514 any = seq_794000395__35; if linked_3512 == nil { tmp223 = ifn_3513.Invoke_O__O(arg_3514) } else { tmp223 = linked_3512.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3511, arg_3514) }; seq_794000395__30, chunk_794000396__31, count_794000397__32, i_794000398__33 = tmp223, nil, 0, 0; continue L7 } else { var tmp224 any; var root_3515 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_3516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3515, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3517 lang.IFn; if linked_3516 == nil { ifn_3517 = lang.IFn_Cast(root_3515) } else { ifn_3517 = nil }; var arg_3518 any = seq_794000395__35; if linked_3516 == nil { tmp224 = ifn_3517.Invoke_O__O(arg_3518) } else { tmp224 = linked_3516.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3515, arg_3518) }; seq_794000395__30, chunk_794000396__31, count_794000397__32, i_794000398__33 = tmp224, nil, 0, 0; continue L7 } } else { var tmp225 any; var root_3519 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_3520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3519, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3521 lang.IFn; if linked_3520 == nil { ifn_3521 = lang.IFn_Cast(root_3519) } else { ifn_3521 = nil }; var arg_3522 any = seq_794000395__35; if linked_3520 == nil { tmp225 = ifn_3521.Invoke_O__O(arg_3522) } else { tmp225 = linked_3520.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3519, arg_3522) }; seq_794000395__30, chunk_794000396__31, count_794000397__32, i_794000398__33 = tmp225, nil, 0, 0; continue L7 } } } }
//line :361:1
				break L7
			}
		}























		var root_2906 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_2907 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2906, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2908 lang.IFn; if linked_2907 == nil { ifn_2908 = lang.IFn_Cast(root_2906) } else { ifn_2908 = nil }; var arg_2909 any = st__0; var arg_2910 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_2911 any = A_arbace_go_repl_A_const_213; var arg_2912 any = r__1; if linked_2907 == nil { ifn_2908.Invoke_O_O_O_O__O(arg_2909, arg_2910, arg_2911, arg_2912) } else { linked_2907.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2906, arg_2909, arg_2910, arg_2911, arg_2912) }
//line :270:1
		var tmp226 any = A_arbace_go_repl_A_const_186; var tmp227 any = A_arbace_go_repl_A_const_196; var tmp228 any; var root_2097 any = A_arbace_go_repl_A_const_80.GetRawRoot__O(); var linked_2098 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2097, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2099 lang.IFn






















































































































		if linked_2098 == nil { ifn_2099 = lang.IFn_Cast(root_2097) } else { ifn_2099 = nil }; var arg_2100 any = A_arbace_go_repl_A_const_156; var arg_2101 any = init_cells__21; if linked_2098 == nil { tmp228 = ifn_2099.Invoke_O_O__O(arg_2100, arg_2101) } else { tmp228 = linked_2098.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2097, arg_2100, arg_2101) }
//line :270:1
		var tmp229 any = tmp228; var tmp230 any = A_arbace_go_repl_A_const_197; var tmp231 any























































































































		if lang.Util_Equiv_O_O__Z_NoInit(Lit_97, A_arbace_go_repl_A_const_55.Invoke_O__O(old__13)) { var root_2102 any = A_arbace_go_repl_A_const_153.GetRawRoot__O(); var linked_2103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2102, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_2104 lang.IFn; if linked_2103 == nil { ifn_2104 = lang.IFn_Cast(root_2102) } else { ifn_2104 = nil }; var arg_2105 any = new_funcs__20; var arg_2106 any = A_arbace_go_repl_A_const_198; if linked_2103 == nil { tmp231 = ifn_2104.Invoke_O_O__O(arg_2105, arg_2106) } else { tmp231 = linked_2103.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_2102, arg_2105, arg_2106) } } else { tmp231 = nil }
//line :270:1
		var tmp232 any = tmp231; var tmp233 any = A_arbace_go_repl_A_const_199; var tmp234 any; var root_2107 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_2108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2107, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2109 lang.IFn

















































































		if linked_2108 == nil { ifn_2109 = lang.IFn_Cast(root_2107) } else { ifn_2109 = nil }; var arg_2110 any = new_vars__23; if linked_2108 == nil { tmp234 = ifn_2109.Invoke_O__O(arg_2110) } else { tmp234 = linked_2108.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2107, arg_2110) }
//line :270:1
		tmp14 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp226, inits__27, tmp227, tmp229, tmp230, tmp232, tmp233, tmp234)) }; return nil }(); var root_2111 any = A_arbace_go_repl_A_const_200.GetRawRoot__O(); var linked_2112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2111, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2113 lang.IFn; if














	linked_2112 == nil { ifn_2113 = lang.IFn_Cast(root_2111) } else { ifn_2113 = nil }; if linked_2112 == nil { ifn_2113.Invoke__O() } else { linked_2112.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2111) }; if /*line :270:1*/ tmp235 != nil { panic(tmp235) }; return tmp14 }








func A_arbace_go_repl_define_BANG__gen_of__794000193_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__gen_of__794000193_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__gen_of__794000193_A{}; t.Ctor_O(p0); return t }
//line :279:1
func (t *A_arbace_go_repl_define_BANG__gen_of__794000193_A) Ctor_O(c__old any) { t.F_old = c__old }
//line :279:1
func (t *A_arbace_go_repl_define_BANG__gen_of__794000193_A) Invoke_O_O__O(self, nt__1 any) any { var i__2 any; var root_1421 any = A_arbace_go_repl_A_const_131.GetRawRoot__O(); var linked_1422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1421, aot_arbace_go_check_types.A_arbace_go_check_types_info_A_fn_class); var ifn_1423 lang.IFn; if linked_1422 == nil { ifn_1423 = lang.IFn_Cast(root_1421) } else { ifn_1423 = nil }; var arg_1424 any = nt__1; if linked_1422 == nil { i__2 = ifn_1423.Invoke_O__O(arg_1424) } else { i__2 = linked_1422.(*aot_arbace_go_check_types.A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1421, arg_1424) }; if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_repl_A_const_140.Invoke_O__O(i__2), A_arbace_go_repl_A_const_54.Invoke_O__O(t.F_old)) { var root_1425 any = A_arbace_go_repl_A_const_153.GetRawRoot__O(); var linked_1426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1425, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1427 lang.IFn; if linked_1426 == nil { ifn_1427 = lang.IFn_Cast(root_1425) } else { ifn_1427 = nil }; var arg_1428 any = t.F_old; var tmp1 any = A_arbace_go_repl_A_const_61; var arg_1429 any = lang.Tuple_Create_O_O_O__IPersistentVector(tmp1, A_arbace_go_repl_A_const_55.Invoke_O__O(i__2), A_arbace_go_repl_A_const_151); if linked_1426 == nil { return ifn_1427.Invoke_O_O__O(arg_1428, arg_1429) } else { return linked_1426.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1425, arg_1428, arg_1429) } } else { return nil } }
func A_arbace_go_repl_define_BANG__fn__794000195_A_New() *A_arbace_go_repl_define_BANG__fn__794000195_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000195_A{}; t.Ctor(); return t }
//line :280:1
func (t *A_arbace_go_repl_define_BANG__fn__794000195_A) Ctor() {}
//line :280:1
func (t *A_arbace_go_repl_define_BANG__fn__794000195_A) Invoke_O_O__O(self, p1__794000182_SHARP___1 any) any { var tmp1 any; var or__1927000174__auto____2 any = A_arbace_go_repl_A_const_176.Invoke_O__O(p1__794000182_SHARP___1); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { tmp1 = A_arbace_go_repl_A_const_177.Invoke_O__O(p1__794000182_SHARP___1) }; if jrt.J2g_Truth(tmp1) { return p1__794000182_SHARP___1 } else { return nil } }






func A_arbace_go_repl_define_BANG__fn__794000197_A_New() *A_arbace_go_repl_define_BANG__fn__794000197_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000197_A{}; t.Ctor(); return t }
//line :287:1
func (t *A_arbace_go_repl_define_BANG__fn__794000197_A) Ctor() {}
//line :287:1
func (t *A_arbace_go_repl_define_BANG__fn__794000197_A) Invoke_O_O__O(self, p1__794000183_SHARP___1 any) any { var tmp1 any = A_arbace_go_repl_A_const_142; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_repl_A_const_178.Invoke_O__O(p1__794000183_SHARP___1)); if and__1927000168__auto____2 { var root_2135 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_2136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2135, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2137 lang.IFn; if linked_2136 == nil { ifn_2137 = lang.IFn_Cast(root_2135) } else { ifn_2137 = nil }; var arg_2138 any; var root_2139 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2139, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2141 lang.IFn; if linked_2140 == nil { ifn_2141 = lang.IFn_Cast(root_2139) } else { ifn_2141 = nil }; var arg_2142 any = A_arbace_go_repl_A_const_181.Invoke_O__O(p1__794000183_SHARP___1); var arg_2143 any = A_arbace_go_repl_A_const_206; if linked_2140 == nil { arg_2138 = ifn_2141.Invoke_O_O__O(arg_2142, arg_2143) } else { arg_2138 = linked_2140.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2139, arg_2142, arg_2143) }; if linked_2136 == nil { return ifn_2137.Invoke_O__O(arg_2138) } else { return linked_2136.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2135, arg_2138) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_go_repl_define_BANG__iter__794000199__794000203_A_New_O_O(p0, p1 any) *A_arbace_go_repl_define_BANG__iter__794000199__794000203_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000199__794000203_A{}; t.Ctor_O_O(p0, p1); return t }
//line :289:1
func (t *A_arbace_go_repl_define_BANG__iter__794000199__794000203_A) Ctor_O_O(c__gen_of, c__old any) { t.F_gen_of = c__gen_of; t.F_old = c__old }
//line :289:1
func (t *A_arbace_go_repl_define_BANG__iter__794000199__794000203_A) Invoke_O_O__O(self, s__794000200__1 any) any { var tmp1 any = A_arbace_go_repl_define_BANG__iter__794000199__794000203_fn__794000204_A_New_O_O_O_O(s__794000200__1, t.F_gen_of, t.F_old, self); var tmp2 *jrt.Class; var fncls__2259 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000199__794000203_fn__794000204_A_fn_class; if fncls__2259 == nil { var fncls__2259d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_105, false); A_arbace_go_repl_define_BANG__iter__794000199__794000203_fn__794000204_A_fn_class = fncls__2259d; tmp2 = fncls__2259d } else { tmp2 = fncls__2259 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :289:1
func A_arbace_go_repl_define_BANG__iter__794000199__794000203_fn__794000204_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_repl_define_BANG__iter__794000199__794000203_fn__794000204_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000199__794000203_fn__794000204_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :289:1
func (t *A_arbace_go_repl_define_BANG__iter__794000199__794000203_fn__794000204_A) Ctor_O_O_O_O(c__s__794000200, c__gen_of, c__old, c__iter__794000199 any) { t.F_s__794000200 = c__s__794000200; t.F_gen_of = c__gen_of; t.F_old = c__old; t.F_iter__794000199 = c__iter__794000199 }
//line :289:1
func (t *A_arbace_go_repl_define_BANG__iter__794000199__794000203_fn__794000204_A) Invoke_O__O(self any) any { { var s__794000200__1 any; var t_ any = t.F_s__794000200; t.F_s__794000200 = nil; s__794000200__1 = t_; for { var temp__1927000414__auto____2 any; var root_2150 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2150, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2152 lang.IFn; if linked_2151 == nil { ifn_2152 = lang.IFn_Cast(root_2150) } else { ifn_2152 = nil }; var arg_2153 any = s__794000200__1; if linked_2151 == nil { temp__1927000414__auto____2 = ifn_2152.Invoke_O__O(arg_2153) } else { temp__1927000414__auto____2 = linked_2151.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2150, arg_2153) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__794000200__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2154 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_2155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2154, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2156 lang.IFn; if linked_2155 == nil { ifn_2156 = lang.IFn_Cast(root_2154) } else { ifn_2156 = nil }; var arg_2157 any = s__794000200__3; if linked_2155 == nil { tmp1 = ifn_2156.Invoke_O__O(arg_2157) } else { tmp1 = linked_2155.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2154, arg_2157) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2158 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_2159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2158, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2160 lang.IFn; if linked_2159 == nil { ifn_2160 = lang.IFn_Cast(root_2158) } else { ifn_2160 = nil }; var arg_2161 any = s__794000200__3; if linked_2159 == nil { c__1927001037__auto____4 = ifn_2160.Invoke_O__O(arg_2161) } else { c__1927001037__auto____4 = linked_2159.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2158, arg_2161) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__794000202__6 any; var root_2162 any = A_arbace_go_repl_A_const_95.GetRawRoot__O(); var linked_2163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2162, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2164 lang.IFn; if linked_2163 == nil { ifn_2164 = lang.IFn_Cast(root_2162) } else { ifn_2164 = nil }; var arg_2165 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2163 == nil { b__794000202__6 = ifn_2164.Invoke_O__O(arg_2165) } else { b__794000202__6 = linked_2163.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2162, arg_2165) }; var tmp2 any = A_arbace_go_repl_define_BANG__iter__794000199__794000203_fn__794000204_fn__794000205_A_New_O_O_O_I_O(b__794000202__6, t.F_gen_of, t.F_old, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2197 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000199__794000203_fn__794000204_fn__794000205_A_fn_class; if fncls__2197 == nil { var fncls__2197d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_106, false); A_arbace_go_repl_define_BANG__iter__794000199__794000203_fn__794000204_fn__794000205_A_fn_class = fncls__2197d; tmp3 = fncls__2197d } else { tmp3 = fncls__2197 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2198 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_2199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2198, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2200 lang.IFn; if linked_2199 == nil { ifn_2200 = lang.IFn_Cast(root_2198) } else { ifn_2200 = nil }; var arg_2201 any; var root_2203 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_2204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2203, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2205 lang.IFn; if linked_2204 == nil { ifn_2205 = lang.IFn_Cast(root_2203) } else { ifn_2205 = nil }; var arg_2206 any = b__794000202__6; if linked_2204 == nil { arg_2201 = ifn_2205.Invoke_O__O(arg_2206) } else { arg_2201 = linked_2204.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2203, arg_2206) }; var arg_2202 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__794000199); var tmp5 any; var root_2207 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_2208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2207, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2209 lang.IFn; if linked_2208 == nil { ifn_2209 = lang.IFn_Cast(root_2207) } else { ifn_2209 = nil }; var arg_2210 any = s__794000200__3; if linked_2208 == nil { tmp5 = ifn_2209.Invoke_O__O(arg_2210) } else { tmp5 = linked_2208.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2207, arg_2210) }; arg_2202 = tmp4.Invoke_O__O(tmp5); if linked_2199 == nil { return ifn_2200.Invoke_O_O__O(arg_2201, arg_2202) } else { return linked_2199.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2198, arg_2201, arg_2202) } } else { var root_2211 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_2212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2211, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2213 lang.IFn; if linked_2212 == nil { ifn_2213 = lang.IFn_Cast(root_2211) } else { ifn_2213 = nil }; var arg_2214 any; var root_2216 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_2217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2216, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2218 lang.IFn; if linked_2217 == nil { ifn_2218 = lang.IFn_Cast(root_2216) } else { ifn_2218 = nil }; var arg_2219 any = b__794000202__6; if linked_2217 == nil { arg_2214 = ifn_2218.Invoke_O__O(arg_2219) } else { arg_2214 = linked_2217.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2216, arg_2219) }; var arg_2215 any; if linked_2212 == nil { return ifn_2213.Invoke_O_O__O(arg_2214, arg_2215) } else { return linked_2212.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2211, arg_2214, arg_2215) } } } else { var d__4 any; var root_2220 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2220, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2222 lang.IFn; if linked_2221 == nil { ifn_2222 = lang.IFn_Cast(root_2220) } else { ifn_2222 = nil }; var arg_2223 any = s__794000200__3; if linked_2221 == nil { d__4 = ifn_2222.Invoke_O__O(arg_2223) } else { d__4 = linked_2221.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2220, arg_2223) }; var x__5 any = A_arbace_go_repl_A_const_181.Invoke_O__O(d__4); var nm__6 any; var root_2224 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2224, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2226 lang.IFn
														if linked_2225 == nil { ifn_2226 = lang.IFn_Cast(root_2224) } else { ifn_2226 = nil }; var arg_2227 any = x__5; var arg_2228 any = A_arbace_go_repl_A_const_55; if linked_2225 == nil { nm__6 = ifn_2226.Invoke_O_O__O(arg_2227, arg_2228) } else { nm__6 = linked_2225.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2224, arg_2227, arg_2228) }
//line :289:1
	var nt__7 any; var root_2229 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2229, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2231 lang.IFn
	if linked_2230 == nil { ifn_2231 = lang.IFn_Cast(root_2229) } else { ifn_2231 = nil }; var arg_2232 any = x__5; var arg_2233 any = A_arbace_go_repl_A_const_142; if linked_2230 == nil { nt__7 = ifn_2231.Invoke_O_O__O(arg_2232, arg_2233) } else { nt__7 = linked_2230.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2229, arg_2232, arg_2233) }
//line :289:1
	var k__8 any; var root_2234 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var linked_2235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2234, A_arbace_go_repl_type_key_A_fn_class); var ifn_2236 lang.IFn

	if linked_2235 == nil { ifn_2236 = lang.IFn_Cast(root_2234) } else { ifn_2236 = nil }; var arg_2237 any; var root_2239 any = A_arbace_go_repl_A_const_161.GetRawRoot__O(); var linked_2240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2239, aot_arbace_go_check_types.A_arbace_go_check_types_under_A_fn_class); var ifn_2241 lang.IFn; if linked_2240 == nil { ifn_2241 = lang.IFn_Cast(root_2239) } else { ifn_2241 = nil }; var arg_2242 any = nt__7; if linked_2240 == nil { arg_2237 = ifn_2241.Invoke_O__O(arg_2242) } else { arg_2237 = linked_2240.(*aot_arbace_go_check_types.A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2239, arg_2242) }; var arg_2238 any = t.F_gen_of; if linked_2235 == nil { k__8 = ifn_2236.Invoke_O_O__O(arg_2237, arg_2238) } else { k__8 = linked_2235.(*A_arbace_go_repl_type_key_A).Invoke_O_O_O__O(root_2234, arg_2237, arg_2238) }
//line :289:1
	var prev__9 any; var root_2243 any = A_arbace_go_repl_A_const_153.GetRawRoot__O(); var linked_2244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2243, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_2245 lang.IFn


	if linked_2244 == nil { ifn_2245 = lang.IFn_Cast(root_2243) } else { ifn_2245 = nil }; var arg_2246 any = t.F_old; var arg_2247 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_repl_A_const_61, nm__6); if linked_2244 == nil { prev__9 = ifn_2245.Invoke_O_O__O(arg_2246, arg_2247) } else { prev__9 = linked_2244.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_2243, arg_2246, arg_2247) }
//line :289:1
	var root_2248 any = A_arbace_go_repl_A_const_100.GetRawRoot__O(); var linked_2249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2248, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2250 lang.IFn; if linked_2249 == nil { ifn_2250 = lang.IFn_Cast(root_2248) } else { ifn_2250 = nil }; var arg_2251 any; var tmp6 any = A_arbace_go_repl_A_const_182; var tmp7 any = A_arbace_go_repl_A_const_151; var tmp8 any



	if lang.Util_Identical_O_O__Z_NoInit(prev__9, nil) { tmp8 = A_arbace_go_repl_A_const_154 } else { if lang.Util_Equiv_O_O__Z_NoInit(k__8, A_arbace_go_repl_A_const_182.Invoke_O__O(prev__9)) { tmp8 = A_arbace_go_repl_A_const_151.Invoke_O__O(prev__9) } else { if A_arbace_go_repl_A_const_133 != nil { var na_2253 any = A_arbace_go_repl_A_const_151.Invoke_O__O(prev__9); if jrt.Long_InstanceOf(na_2253) { var n0_2254 int64 = jrt.NN(jrt.Long_Cast(na_2253)).LongValue__J(); if n0_2254 == 9223372036854775807 { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_2253) } else { tmp8 = jrt.Long_ValueOf_J__Long_NoInit(n0_2254 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_2253) { var n0_2254_2 float64 = jrt.NN(jrt.Double_Cast(na_2253)).DoubleValue__D(); tmp8 = jrt.Double_ValueOf_D__Double_NoInit(n0_2254_2 + 1.0).Ref() } else { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_2253) } } } else { tmp8 = nil } } }
//line :289:1
	arg_2251 = lang.Tuple_Create_O_O__IPersistentVector(nm__6, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, k__8, tmp7, tmp8))); var arg_2252 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__794000199); var tmp10 any; var root_2255 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_2256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2255, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2257 lang.IFn; if linked_2256 == nil { ifn_2257 = lang.IFn_Cast(root_2255) } else { ifn_2257 = nil }; var arg_2258 any = s__794000200__3; if linked_2256 == nil { tmp10 = ifn_2257.Invoke_O__O(arg_2258) } else { tmp10 = linked_2256.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2255, arg_2258) }; arg_2252 = tmp9.Invoke_O__O(tmp10); if linked_2249 == nil { return ifn_2250.Invoke_O_O__O(arg_2251, arg_2252) } else { return linked_2249.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2248, arg_2251, arg_2252) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :289:1
func A_arbace_go_repl_define_BANG__iter__794000199__794000203_fn__794000204_fn__794000205_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_go_repl_define_BANG__iter__794000199__794000203_fn__794000204_fn__794000205_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000199__794000203_fn__794000204_fn__794000205_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :289:1
func (t *A_arbace_go_repl_define_BANG__iter__794000199__794000203_fn__794000204_fn__794000205_A) Ctor_O_O_O_I_O(c__b__794000202, c__gen_of, c__old any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__794000202 = c__b__794000202; t.F_gen_of = c__gen_of; t.F_old = c__old; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :289:1
func (t *A_arbace_go_repl_define_BANG__iter__794000199__794000203_fn__794000204_fn__794000205_A) Invoke_O__O(self any) any { { var i__794000201__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__794000201__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var d__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__794000201__1)); var x__3 any = A_arbace_go_repl_A_const_181.Invoke_O__O(d__2); var nm__4 any; var root_2166 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2166, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2168 lang.IFn
																if linked_2167 == nil { ifn_2168 = lang.IFn_Cast(root_2166) } else { ifn_2168 = nil }; var arg_2169 any = x__3; var arg_2170 any = A_arbace_go_repl_A_const_55; if linked_2167 == nil { nm__4 = ifn_2168.Invoke_O_O__O(arg_2169, arg_2170) } else { nm__4 = linked_2167.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2166, arg_2169, arg_2170) }
//line :289:1
	var nt__5 any; var root_2171 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2171, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2173 lang.IFn
	if linked_2172 == nil { ifn_2173 = lang.IFn_Cast(root_2171) } else { ifn_2173 = nil }; var arg_2174 any = x__3; var arg_2175 any = A_arbace_go_repl_A_const_142; if linked_2172 == nil { nt__5 = ifn_2173.Invoke_O_O__O(arg_2174, arg_2175) } else { nt__5 = linked_2172.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2171, arg_2174, arg_2175) }
//line :289:1
	var k__6 any; var root_2176 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var linked_2177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2176, A_arbace_go_repl_type_key_A_fn_class); var ifn_2178 lang.IFn

	if linked_2177 == nil { ifn_2178 = lang.IFn_Cast(root_2176) } else { ifn_2178 = nil }; var arg_2179 any; var root_2181 any = A_arbace_go_repl_A_const_161.GetRawRoot__O(); var linked_2182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2181, aot_arbace_go_check_types.A_arbace_go_check_types_under_A_fn_class); var ifn_2183 lang.IFn; if linked_2182 == nil { ifn_2183 = lang.IFn_Cast(root_2181) } else { ifn_2183 = nil }; var arg_2184 any = nt__5; if linked_2182 == nil { arg_2179 = ifn_2183.Invoke_O__O(arg_2184) } else { arg_2179 = linked_2182.(*aot_arbace_go_check_types.A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2181, arg_2184) }; var arg_2180 any = t.F_gen_of; if linked_2177 == nil { k__6 = ifn_2178.Invoke_O_O__O(arg_2179, arg_2180) } else { k__6 = linked_2177.(*A_arbace_go_repl_type_key_A).Invoke_O_O_O__O(root_2176, arg_2179, arg_2180) }
//line :289:1
	var prev__7 any; var root_2185 any = A_arbace_go_repl_A_const_153.GetRawRoot__O(); var linked_2186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2185, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_2187 lang.IFn


	if linked_2186 == nil { ifn_2187 = lang.IFn_Cast(root_2185) } else { ifn_2187 = nil }; var arg_2188 any = t.F_old; var arg_2189 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_repl_A_const_61, nm__4); if linked_2186 == nil { prev__7 = ifn_2187.Invoke_O_O__O(arg_2188, arg_2189) } else { prev__7 = linked_2186.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_2185, arg_2188, arg_2189) }
//line :289:1
	var root_2190 any = A_arbace_go_repl_A_const_96.GetRawRoot__O(); var linked_2191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2190, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2192 lang.IFn; if linked_2191 == nil { ifn_2192 = lang.IFn_Cast(root_2190) } else { ifn_2192 = nil }; var arg_2193 any = t.F_b__794000202; var arg_2194 any; var tmp2 any = A_arbace_go_repl_A_const_182; var tmp3 any = A_arbace_go_repl_A_const_151; var tmp4 any



	if lang.Util_Identical_O_O__Z_NoInit(prev__7, nil) { tmp4 = A_arbace_go_repl_A_const_154 } else { if lang.Util_Equiv_O_O__Z_NoInit(k__6, A_arbace_go_repl_A_const_182.Invoke_O__O(prev__7)) { tmp4 = A_arbace_go_repl_A_const_151.Invoke_O__O(prev__7) } else { if A_arbace_go_repl_A_const_133 != nil { var na_2195 any = A_arbace_go_repl_A_const_151.Invoke_O__O(prev__7); if jrt.Long_InstanceOf(na_2195) { var n0_2196 int64 = jrt.NN(jrt.Long_Cast(na_2195)).LongValue__J(); if n0_2196 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_2195) } else { tmp4 = jrt.Long_ValueOf_J__Long_NoInit(n0_2196 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_2195) { var n0_2196_2 float64 = jrt.NN(jrt.Double_Cast(na_2195)).DoubleValue__D(); tmp4 = jrt.Double_ValueOf_D__Double_NoInit(n0_2196_2 + 1.0).Ref() } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_2195) } } } else { tmp4 = nil } } }
//line :289:1
	arg_2194 = lang.Tuple_Create_O_O__IPersistentVector(nm__4, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, k__6, tmp3, tmp4))); if linked_2191 == nil { ifn_2192.Invoke_O_O__O(arg_2193, arg_2194) } else { linked_2191.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2190, arg_2193, arg_2194) }; i__794000201__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000201__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_go_repl_define_BANG__fn__794000209_A_New() *A_arbace_go_repl_define_BANG__fn__794000209_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000209_A{}; t.Ctor(); return t }
//line :296:1
func (t *A_arbace_go_repl_define_BANG__fn__794000209_A) Ctor() {}
//line :296:1
func (t *A_arbace_go_repl_define_BANG__fn__794000209_A) Invoke_O_O__O(self, p1__794000184_SHARP___1 any) any { var tmp1 any = A_arbace_go_repl_A_const_137; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_repl_A_const_178.Invoke_O__O(p1__794000184_SHARP___1)); if and__1927000168__auto____2 { var and__1927000168__auto____3 any; var root_1442 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_1443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1442, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1444 lang.IFn; if linked_1443 == nil { ifn_1444 = lang.IFn_Cast(root_1442) } else { ifn_1444 = nil }; var arg_1445 any = A_arbace_go_repl_A_const_179.Invoke_O__O(p1__794000184_SHARP___1); if linked_1443 == nil { and__1927000168__auto____3 = ifn_1444.Invoke_O__O(arg_1445) } else { and__1927000168__auto____3 = linked_1443.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1442, arg_1445) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1446 any = A_arbace_go_repl_A_const_180.GetRawRoot__O(); var linked_1447 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1446, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1448 lang.IFn; if linked_1447 == nil { ifn_1448 = lang.IFn_Cast(root_1446) } else { ifn_1448 = nil }; var arg_1449 any = Lit_17; var arg_1450 any; var root_1451 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1451, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1453 lang.IFn; if linked_1452 == nil { ifn_1453 = lang.IFn_Cast(root_1451) } else { ifn_1453 = nil }; var arg_1454 any = A_arbace_go_repl_A_const_181.Invoke_O__O(p1__794000184_SHARP___1); var arg_1455 any = A_arbace_go_repl_A_const_55; if linked_1452 == nil { arg_1450 = ifn_1453.Invoke_O_O__O(arg_1454, arg_1455) } else { arg_1450 = linked_1452.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1451, arg_1454, arg_1455) }; if linked_1447 == nil { return ifn_1448.Invoke_O_O__O(arg_1449, arg_1450) } else { return linked_1447.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1446, arg_1449, arg_1450) } } else { return and__1927000168__auto____3 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }
func A_arbace_go_repl_define_BANG__fn__794000211_A_New() *A_arbace_go_repl_define_BANG__fn__794000211_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000211_A{}; t.Ctor(); return t }
//line :297:1
func (t *A_arbace_go_repl_define_BANG__fn__794000211_A) Ctor() {}
//line :297:1
func (t *A_arbace_go_repl_define_BANG__fn__794000211_A) Invoke_O_O__O(self, p1__794000185_SHARP___1 any) any { var tmp1 any = A_arbace_go_repl_A_const_137; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_repl_A_const_178.Invoke_O__O(p1__794000185_SHARP___1)); if and__1927000168__auto____2 { return A_arbace_go_repl_A_const_179.Invoke_O__O(p1__794000185_SHARP___1) } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_go_repl_define_BANG__iter__794000213__794000217_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_repl_define_BANG__iter__794000213__794000217_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000213__794000217_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :299:1
func (t *A_arbace_go_repl_define_BANG__iter__794000213__794000217_A) Ctor_O_O_O(c__old, c__ctx, c__kept_names any) { t.F_old = c__old; t.F_ctx = c__ctx; t.F_kept_names = c__kept_names }
//line :299:1
func (t *A_arbace_go_repl_define_BANG__iter__794000213__794000217_A) Invoke_O_O__O(self, s__794000214__1 any) any { var tmp1 any = A_arbace_go_repl_define_BANG__iter__794000213__794000217_fn__794000218_A_New_O_O_O_O_O(s__794000214__1, t.F_old, t.F_ctx, t.F_kept_names, self); var tmp2 *jrt.Class; var fncls__1601 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000213__794000217_fn__794000218_A_fn_class; if fncls__1601 == nil { var fncls__1601d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_107, false); A_arbace_go_repl_define_BANG__iter__794000213__794000217_fn__794000218_A_fn_class = fncls__1601d; tmp2 = fncls__1601d } else { tmp2 = fncls__1601 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :299:1
func A_arbace_go_repl_define_BANG__iter__794000213__794000217_fn__794000218_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_repl_define_BANG__iter__794000213__794000217_fn__794000218_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000213__794000217_fn__794000218_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :299:1
func (t *A_arbace_go_repl_define_BANG__iter__794000213__794000217_fn__794000218_A) Ctor_O_O_O_O_O(c__s__794000214, c__old, c__ctx, c__kept_names, c__iter__794000213 any) { t.F_s__794000214 = c__s__794000214; t.F_old = c__old; t.F_ctx = c__ctx; t.F_kept_names = c__kept_names; t.F_iter__794000213 = c__iter__794000213 }
//line :299:1
func (t *A_arbace_go_repl_define_BANG__iter__794000213__794000217_fn__794000218_A) Invoke_O__O(self any) any { { var s__794000214__1 any; var t_ any = t.F_s__794000214; t.F_s__794000214 = nil; s__794000214__1 = t_; for { var temp__1927000414__auto____2 any; var root_1468 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_1469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1468, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1470 lang.IFn; if linked_1469 == nil { ifn_1470 = lang.IFn_Cast(root_1468) } else { ifn_1470 = nil }; var arg_1471 any = s__794000214__1; if linked_1469 == nil { temp__1927000414__auto____2 = ifn_1470.Invoke_O__O(arg_1471) } else { temp__1927000414__auto____2 = linked_1469.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1468, arg_1471) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__794000214__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1472 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_1473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1472, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1474 lang.IFn; if linked_1473 == nil { ifn_1474 = lang.IFn_Cast(root_1472) } else { ifn_1474 = nil }; var arg_1475 any = s__794000214__3; if linked_1473 == nil { tmp1 = ifn_1474.Invoke_O__O(arg_1475) } else { tmp1 = linked_1473.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1472, arg_1475) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1476 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_1477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1476, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1478 lang.IFn; if linked_1477 == nil { ifn_1478 = lang.IFn_Cast(root_1476) } else { ifn_1478 = nil }; var arg_1479 any = s__794000214__3; if linked_1477 == nil { c__1927001037__auto____4 = ifn_1478.Invoke_O__O(arg_1479) } else { c__1927001037__auto____4 = linked_1477.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1476, arg_1479) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__794000216__6 any; var root_1480 any = A_arbace_go_repl_A_const_95.GetRawRoot__O(); var linked_1481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1480, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1482 lang.IFn; if linked_1481 == nil { ifn_1482 = lang.IFn_Cast(root_1480) } else { ifn_1482 = nil }; var arg_1483 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1481 == nil { b__794000216__6 = ifn_1482.Invoke_O__O(arg_1483) } else { b__794000216__6 = linked_1481.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1480, arg_1483) }; var tmp2 any = A_arbace_go_repl_define_BANG__iter__794000213__794000217_fn__794000218_fn__794000219_A_New_O_O_I_O_O_O(b__794000216__6, t.F_old, size__1927001038__auto____5, t.F_ctx, t.F_kept_names, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1527 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000213__794000217_fn__794000218_fn__794000219_A_fn_class; if fncls__1527 == nil { var fncls__1527d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_108, false); A_arbace_go_repl_define_BANG__iter__794000213__794000217_fn__794000218_fn__794000219_A_fn_class = fncls__1527d; tmp3 = fncls__1527d } else { tmp3 = fncls__1527 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1528 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_1529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1528, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1530 lang.IFn; if linked_1529 == nil { ifn_1530 = lang.IFn_Cast(root_1528) } else { ifn_1530 = nil }; var arg_1531 any; var root_1533 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_1534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1533, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1535 lang.IFn; if linked_1534 == nil { ifn_1535 = lang.IFn_Cast(root_1533) } else { ifn_1535 = nil }; var arg_1536 any = b__794000216__6; if linked_1534 == nil { arg_1531 = ifn_1535.Invoke_O__O(arg_1536) } else { arg_1531 = linked_1534.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1533, arg_1536) }; var arg_1532 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__794000213); var tmp5 any; var root_1537 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_1538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1537, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1539 lang.IFn; if linked_1538 == nil { ifn_1539 = lang.IFn_Cast(root_1537) } else { ifn_1539 = nil }; var arg_1540 any = s__794000214__3; if linked_1538 == nil { tmp5 = ifn_1539.Invoke_O__O(arg_1540) } else { tmp5 = linked_1538.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1537, arg_1540) }; arg_1532 = tmp4.Invoke_O__O(tmp5); if linked_1529 == nil { return ifn_1530.Invoke_O_O__O(arg_1531, arg_1532) } else { return linked_1529.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1528, arg_1531, arg_1532) } } else { var root_1541 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_1542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1541, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1543 lang.IFn; if linked_1542 == nil { ifn_1543 = lang.IFn_Cast(root_1541) } else { ifn_1543 = nil }; var arg_1544 any; var root_1546 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_1547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1546, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1548 lang.IFn; if linked_1547 == nil { ifn_1548 = lang.IFn_Cast(root_1546) } else { ifn_1548 = nil }; var arg_1549 any = b__794000216__6; if linked_1547 == nil { arg_1544 = ifn_1548.Invoke_O__O(arg_1549) } else { arg_1544 = linked_1547.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1546, arg_1549) }; var arg_1545 any; if linked_1542 == nil { return ifn_1543.Invoke_O_O__O(arg_1544, arg_1545) } else { return linked_1542.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1541, arg_1544, arg_1545) } } } else { var d__4 any; var root_1550 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_1551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1550, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1552 lang.IFn; if linked_1551 == nil { ifn_1552 = lang.IFn_Cast(root_1550) } else { ifn_1552 = nil }; var arg_1553 any = s__794000214__3; if linked_1551 == nil { d__4 = ifn_1552.Invoke_O__O(arg_1553) } else { d__4 = linked_1551.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1550, arg_1553) }; var x__5 any = A_arbace_go_repl_A_const_181.Invoke_O__O(d__4); var nm__6 any; var root_1554 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1554, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1556 lang.IFn
														if linked_1555 == nil { ifn_1556 = lang.IFn_Cast(root_1554) } else { ifn_1556 = nil }; var arg_1557 any = x__5; var arg_1558 any = A_arbace_go_repl_A_const_55; if linked_1555 == nil { nm__6 = ifn_1556.Invoke_O_O__O(arg_1557, arg_1558) } else { nm__6 = linked_1555.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1554, arg_1557, arg_1558) }
//line :299:1
	var k__7 any; var root_1559 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var linked_1560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1559, A_arbace_go_repl_type_key_A_fn_class); var ifn_1561 lang.IFn

	if linked_1560 == nil { ifn_1561 = lang.IFn_Cast(root_1559) } else { ifn_1561 = nil }; var arg_1562 any; var root_1564 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1564, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1566 lang.IFn; if linked_1565 == nil { ifn_1566 = lang.IFn_Cast(root_1564) } else { ifn_1566 = nil }; var arg_1567 any = x__5; var arg_1568 any = A_arbace_go_repl_A_const_142; if linked_1565 == nil { arg_1562 = ifn_1566.Invoke_O_O__O(arg_1567, arg_1568) } else { arg_1562 = linked_1565.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1564, arg_1567, arg_1568) }; var arg_1563 any = A_arbace_go_repl_A_const_151.Invoke_O__O(t.F_ctx); if linked_1560 == nil { k__7 = ifn_1561.Invoke_O_O__O(arg_1562, arg_1563) } else { k__7 = linked_1560.(*A_arbace_go_repl_type_key_A).Invoke_O_O_O__O(root_1559, arg_1562, arg_1563) }
//line :299:1
	var prev__8 any; var root_1569 any = A_arbace_go_repl_A_const_153.GetRawRoot__O(); var linked_1570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1569, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1571 lang.IFn


	if linked_1570 == nil { ifn_1571 = lang.IFn_Cast(root_1569) } else { ifn_1571 = nil }; var arg_1572 any = t.F_old; var arg_1573 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_repl_A_const_59, nm__6); if linked_1570 == nil { prev__8 = ifn_1571.Invoke_O_O__O(arg_1572, arg_1573) } else { prev__8 = linked_1570.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1569, arg_1572, arg_1573) }
//line :299:1
	var cell__9 any; var tmp6 any
	var and__1927000168__auto____9 any = prev__8


	if jrt.J2g_Truth(and__1927000168__auto____9) { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(k__7, A_arbace_go_repl_A_const_182.Invoke_O__O(prev__8))).Ref() } else { tmp6 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp6) { cell__9 = A_arbace_go_repl_A_const_156.Invoke_O__O(prev__8) } else { cell__9 = lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_89, nm__6, A_arbace_go_repl_A_const_55.Invoke_O__O(t.F_old), nil) }
//line :299:1
	var root_1581 any = A_arbace_go_repl_A_const_100.GetRawRoot__O(); var linked_1582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1581, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1583 lang.IFn; if linked_1582 == nil { ifn_1583 = lang.IFn_Cast(root_1581) } else { ifn_1583 = nil }; var arg_1584 any; var tmp7 any
	var and__1927000168__auto____10 any = prev__8



	if jrt.J2g_Truth(and__1927000168__auto____10) { var root_1586 any = A_arbace_go_repl_A_const_18.GetRawRoot__O(); var linked_1587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1586, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1588 lang.IFn; if linked_1587 == nil { ifn_1588 = lang.IFn_Cast(root_1586) } else { ifn_1588 = nil }; var arg_1589 any = t.F_kept_names; var arg_1590 any = nm__6; if linked_1587 == nil { tmp7 = ifn_1588.Invoke_O_O__O(arg_1589, arg_1590) } else { tmp7 = linked_1587.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1586, arg_1589, arg_1590) } } else { tmp7 = and__1927000168__auto____10 }; if jrt.J2g_Truth(tmp7) { var tmp8 any; var root_1591 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var linked_1592 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1591, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1593 lang.IFn
		if linked_1592 == nil { ifn_1593 = lang.IFn_Cast(root_1591) } else { ifn_1593 = nil }; var arg_1594 any = prev__8; var arg_1595 any = A_arbace_go_repl_A_const_184; var arg_1596 any = jrt.Boolean_TRUE.Ref(); if linked_1592 == nil { tmp8 = ifn_1593.Invoke_O_O_O__O(arg_1594, arg_1595, arg_1596) } else { tmp8 = linked_1592.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1591, arg_1594, arg_1595, arg_1596) }
//line :304:1
		arg_1584 = lang.Tuple_Create_O_O__IPersistentVector(nm__6, tmp8) } else { var tmp9 any = A_arbace_go_repl_A_const_156; var tmp10 any = A_arbace_go_repl_A_const_182; var tmp11 any = A_arbace_go_repl_A_const_185; arg_1584 = lang.Tuple_Create_O_O__IPersistentVector(nm__6, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, cell__9, tmp10, k__7, tmp11, A_arbace_go_repl_A_const_185.Invoke_O__O(d__4), A_arbace_go_repl_A_const_181, x__5))) }
//line :299:1
	var arg_1585 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__794000213); var tmp13 any; var root_1597 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_1598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1597, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1599 lang.IFn; if linked_1598 == nil { ifn_1599 = lang.IFn_Cast(root_1597) } else { ifn_1599 = nil }; var arg_1600 any = s__794000214__3; if linked_1598 == nil { tmp13 = ifn_1599.Invoke_O__O(arg_1600) } else { tmp13 = linked_1598.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1597, arg_1600) }; arg_1585 = tmp12.Invoke_O__O(tmp13); if linked_1582 == nil { return ifn_1583.Invoke_O_O__O(arg_1584, arg_1585) } else { return linked_1582.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1581, arg_1584, arg_1585) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :299:1
func A_arbace_go_repl_define_BANG__iter__794000213__794000217_fn__794000218_fn__794000219_A_New_O_O_I_O_O_O(p0, p1 any, p2 int32, p3, p4, p5 any) *A_arbace_go_repl_define_BANG__iter__794000213__794000217_fn__794000218_fn__794000219_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000213__794000217_fn__794000218_fn__794000219_A{}; t.Ctor_O_O_I_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :299:1
func (t *A_arbace_go_repl_define_BANG__iter__794000213__794000217_fn__794000218_fn__794000219_A) Ctor_O_O_I_O_O_O(c__b__794000216, c__old any, c__size__1927001038__auto__ int32, c__ctx, c__kept_names, c__c__1927001037__auto__ any) { t.F_b__794000216 = c__b__794000216; t.F_old = c__old; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_ctx = c__ctx; t.F_kept_names = c__kept_names; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :299:1
func (t *A_arbace_go_repl_define_BANG__iter__794000213__794000217_fn__794000218_fn__794000219_A) Invoke_O__O(self any) any { { var i__794000215__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__794000215__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var d__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__794000215__1)); var x__3 any = A_arbace_go_repl_A_const_181.Invoke_O__O(d__2); var nm__4 any; var root_1484 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1484, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1486 lang.IFn
																if linked_1485 == nil { ifn_1486 = lang.IFn_Cast(root_1484) } else { ifn_1486 = nil }; var arg_1487 any = x__3; var arg_1488 any = A_arbace_go_repl_A_const_55; if linked_1485 == nil { nm__4 = ifn_1486.Invoke_O_O__O(arg_1487, arg_1488) } else { nm__4 = linked_1485.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1484, arg_1487, arg_1488) }
//line :299:1
	var k__5 any; var root_1489 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var linked_1490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1489, A_arbace_go_repl_type_key_A_fn_class); var ifn_1491 lang.IFn

	if linked_1490 == nil { ifn_1491 = lang.IFn_Cast(root_1489) } else { ifn_1491 = nil }; var arg_1492 any; var root_1494 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1494, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1496 lang.IFn; if linked_1495 == nil { ifn_1496 = lang.IFn_Cast(root_1494) } else { ifn_1496 = nil }; var arg_1497 any = x__3; var arg_1498 any = A_arbace_go_repl_A_const_142; if linked_1495 == nil { arg_1492 = ifn_1496.Invoke_O_O__O(arg_1497, arg_1498) } else { arg_1492 = linked_1495.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1494, arg_1497, arg_1498) }; var arg_1493 any = A_arbace_go_repl_A_const_151.Invoke_O__O(t.F_ctx); if linked_1490 == nil { k__5 = ifn_1491.Invoke_O_O__O(arg_1492, arg_1493) } else { k__5 = linked_1490.(*A_arbace_go_repl_type_key_A).Invoke_O_O_O__O(root_1489, arg_1492, arg_1493) }
//line :299:1
	var prev__6 any; var root_1499 any = A_arbace_go_repl_A_const_153.GetRawRoot__O(); var linked_1500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1499, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1501 lang.IFn


	if linked_1500 == nil { ifn_1501 = lang.IFn_Cast(root_1499) } else { ifn_1501 = nil }; var arg_1502 any = t.F_old; var arg_1503 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_repl_A_const_59, nm__4); if linked_1500 == nil { prev__6 = ifn_1501.Invoke_O_O__O(arg_1502, arg_1503) } else { prev__6 = linked_1500.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1499, arg_1502, arg_1503) }
//line :299:1
	var cell__7 any; var tmp2 any
	var and__1927000168__auto____7 any = prev__6


	if jrt.J2g_Truth(and__1927000168__auto____7) { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(k__5, A_arbace_go_repl_A_const_182.Invoke_O__O(prev__6))).Ref() } else { tmp2 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp2) { cell__7 = A_arbace_go_repl_A_const_156.Invoke_O__O(prev__6) } else { cell__7 = lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_89, nm__4, A_arbace_go_repl_A_const_55.Invoke_O__O(t.F_old), nil) }
//line :299:1
	var root_1511 any = A_arbace_go_repl_A_const_96.GetRawRoot__O(); var linked_1512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1511, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1513 lang.IFn; if linked_1512 == nil { ifn_1513 = lang.IFn_Cast(root_1511) } else { ifn_1513 = nil }; var arg_1514 any = t.F_b__794000216; var arg_1515 any; var tmp3 any
	var and__1927000168__auto____8 any = prev__6



	if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1516 any = A_arbace_go_repl_A_const_18.GetRawRoot__O(); var linked_1517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1516, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1518 lang.IFn; if linked_1517 == nil { ifn_1518 = lang.IFn_Cast(root_1516) } else { ifn_1518 = nil }; var arg_1519 any = t.F_kept_names; var arg_1520 any = nm__4; if linked_1517 == nil { tmp3 = ifn_1518.Invoke_O_O__O(arg_1519, arg_1520) } else { tmp3 = linked_1517.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1516, arg_1519, arg_1520) } } else { tmp3 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp3) { var tmp4 any; var root_1521 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var linked_1522 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1521, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1523 lang.IFn
		if linked_1522 == nil { ifn_1523 = lang.IFn_Cast(root_1521) } else { ifn_1523 = nil }; var arg_1524 any = prev__6; var arg_1525 any = A_arbace_go_repl_A_const_184; var arg_1526 any = jrt.Boolean_TRUE.Ref(); if linked_1522 == nil { tmp4 = ifn_1523.Invoke_O_O_O__O(arg_1524, arg_1525, arg_1526) } else { tmp4 = linked_1522.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1521, arg_1524, arg_1525, arg_1526) }
//line :304:1
		arg_1515 = lang.Tuple_Create_O_O__IPersistentVector(nm__4, tmp4) } else { var tmp5 any = A_arbace_go_repl_A_const_156; var tmp6 any = A_arbace_go_repl_A_const_182; var tmp7 any = A_arbace_go_repl_A_const_185; arg_1515 = lang.Tuple_Create_O_O__IPersistentVector(nm__4, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, cell__7, tmp6, k__5, tmp7, A_arbace_go_repl_A_const_185.Invoke_O__O(d__2), A_arbace_go_repl_A_const_181, x__3))) }
//line :299:1
	if linked_1512 == nil { ifn_1513.Invoke_O_O__O(arg_1514, arg_1515) } else { linked_1512.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1511, arg_1514, arg_1515) }; i__794000215__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000215__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }







func A_arbace_go_repl_define_BANG__iter__794000223__794000227_A_New_O_O(p0, p1 any) *A_arbace_go_repl_define_BANG__iter__794000223__794000227_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000223__794000227_A{}; t.Ctor_O_O(p0, p1); return t }
//line :307:1
func (t *A_arbace_go_repl_define_BANG__iter__794000223__794000227_A) Ctor_O_O(c__old, c__decls any) { t.F_old = c__old; t.F_decls = c__decls }
//line :307:1
func (t *A_arbace_go_repl_define_BANG__iter__794000223__794000227_A) Invoke_O_O__O(self, s__794000224__1 any) any { var tmp1 any = A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_A_New_O_O_O_O(s__794000224__1, t.F_old, t.F_decls, self); var tmp2 *jrt.Class; var fncls__1690 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_A_fn_class; if fncls__1690 == nil { var fncls__1690d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_109, false); A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_A_fn_class = fncls__1690d; tmp2 = fncls__1690d } else { tmp2 = fncls__1690 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :307:1
func A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :307:1
func (t *A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_A) Ctor_O_O_O_O(c__s__794000224, c__old, c__decls, c__iter__794000223 any) { t.F_s__794000224 = c__s__794000224; t.F_old = c__old; t.F_decls = c__decls; t.F_iter__794000223 = c__iter__794000223 }
//line :307:1
func (t *A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_A) Invoke_O__O(self any) any { { var s__794000224__1 any; var t_ any = t.F_s__794000224; t.F_s__794000224 = nil; s__794000224__1 = t_; for { var temp__1927000414__auto____2 any; var root_1607 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_1608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1607, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1609 lang.IFn; if linked_1608 == nil { ifn_1609 = lang.IFn_Cast(root_1607) } else { ifn_1609 = nil }; var arg_1610 any = s__794000224__1; if linked_1608 == nil { temp__1927000414__auto____2 = ifn_1609.Invoke_O__O(arg_1610) } else { temp__1927000414__auto____2 = linked_1608.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1607, arg_1610) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__794000224__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1611 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_1612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1611, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1613 lang.IFn; if linked_1612 == nil { ifn_1613 = lang.IFn_Cast(root_1611) } else { ifn_1613 = nil }; var arg_1614 any = s__794000224__3; if linked_1612 == nil { tmp1 = ifn_1613.Invoke_O__O(arg_1614) } else { tmp1 = linked_1612.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1611, arg_1614) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1615 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_1616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1615, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1617 lang.IFn; if linked_1616 == nil { ifn_1617 = lang.IFn_Cast(root_1615) } else { ifn_1617 = nil }; var arg_1618 any = s__794000224__3; if linked_1616 == nil { c__1927001037__auto____4 = ifn_1617.Invoke_O__O(arg_1618) } else { c__1927001037__auto____4 = linked_1616.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1615, arg_1618) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__794000226__6 any; var root_1619 any = A_arbace_go_repl_A_const_95.GetRawRoot__O(); var linked_1620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1619, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1621 lang.IFn; if linked_1620 == nil { ifn_1621 = lang.IFn_Cast(root_1619) } else { ifn_1621 = nil }; var arg_1622 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1620 == nil { b__794000226__6 = ifn_1621.Invoke_O__O(arg_1622) } else { b__794000226__6 = linked_1620.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1619, arg_1622) }; var tmp2 any = A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000229_A_New_O_O_I_O_O(b__794000226__6, t.F_old, size__1927001038__auto____5, t.F_decls, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1641 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000229_A_fn_class; if fncls__1641 == nil { var fncls__1641d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_110, false); A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000229_A_fn_class = fncls__1641d; tmp3 = fncls__1641d } else { tmp3 = fncls__1641 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1642 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_1643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1642, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1644 lang.IFn; if linked_1643 == nil { ifn_1644 = lang.IFn_Cast(root_1642) } else { ifn_1644 = nil }; var arg_1645 any; var root_1647 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_1648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1647, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1649 lang.IFn; if linked_1648 == nil { ifn_1649 = lang.IFn_Cast(root_1647) } else { ifn_1649 = nil }; var arg_1650 any = b__794000226__6; if linked_1648 == nil { arg_1645 = ifn_1649.Invoke_O__O(arg_1650) } else { arg_1645 = linked_1648.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1647, arg_1650) }; var arg_1646 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__794000223); var tmp5 any; var root_1651 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_1652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1651, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1653 lang.IFn; if linked_1652 == nil { ifn_1653 = lang.IFn_Cast(root_1651) } else { ifn_1653 = nil }; var arg_1654 any = s__794000224__3; if linked_1652 == nil { tmp5 = ifn_1653.Invoke_O__O(arg_1654) } else { tmp5 = linked_1652.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1651, arg_1654) }; arg_1646 = tmp4.Invoke_O__O(tmp5); if linked_1643 == nil { return ifn_1644.Invoke_O_O__O(arg_1645, arg_1646) } else { return linked_1643.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1642, arg_1645, arg_1646) } } else { var root_1655 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_1656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1655, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1657 lang.IFn; if linked_1656 == nil { ifn_1657 = lang.IFn_Cast(root_1655) } else { ifn_1657 = nil }; var arg_1658 any; var root_1660 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_1661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1660, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1662 lang.IFn; if linked_1661 == nil { ifn_1662 = lang.IFn_Cast(root_1660) } else { ifn_1662 = nil }; var arg_1663 any = b__794000226__6; if linked_1661 == nil { arg_1658 = ifn_1662.Invoke_O__O(arg_1663) } else { arg_1658 = linked_1661.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1660, arg_1663) }; var arg_1659 any; if linked_1656 == nil { return ifn_1657.Invoke_O_O__O(arg_1658, arg_1659) } else { return linked_1656.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1655, arg_1658, arg_1659) } } } else { var x__4 any; var root_1664 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_1665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1664, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1666 lang.IFn; if linked_1665 == nil { ifn_1666 = lang.IFn_Cast(root_1664) } else { ifn_1666 = nil }; var arg_1667 any = s__794000224__3; if linked_1665 == nil { x__4 = ifn_1666.Invoke_O__O(arg_1667) } else { x__4 = linked_1665.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1664, arg_1667) }; var root_1668 any = A_arbace_go_repl_A_const_100.GetRawRoot__O(); var linked_1669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1668, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1670 lang.IFn; if linked_1669 == nil { ifn_1670 = lang.IFn_Cast(root_1668) } else { ifn_1670 = nil }; var arg_1671 any; var d__5 any; var root_1673 any = A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_1674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1673, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1675 lang.IFn
														if linked_1674 == nil { ifn_1675 = lang.IFn_Cast(root_1673) } else { ifn_1675 = nil }; var arg_1676 any; var tmp6 any = A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000233_A_New_O(x__4); var tmp7 *jrt.Class; var fncls__1678 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000233_A_fn_class; if fncls__1678 == nil { var fncls__1678d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_111, false); A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000233_A_fn_class = fncls__1678d; tmp7 = fncls__1678d } else { tmp7 = fncls__1678 }; arg_1676 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_1677 any = t.F_decls; if linked_1674 == nil { d__5 = ifn_1675.Invoke_O_O__O(arg_1676, arg_1677) } else { d__5 = linked_1674.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1673, arg_1676, arg_1677) }
//line :307:1
	var tmp8 any = A_arbace_go_repl_A_const_156; var tmp9 any = lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_89, Lit_17, A_arbace_go_repl_A_const_55.Invoke_O__O(t.F_old), nil); var tmp10 any = A_arbace_go_repl_A_const_185; arg_1671 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9, tmp10, A_arbace_go_repl_A_const_185.Invoke_O__O(d__5))); var arg_1672 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__794000223); var tmp12 any; var root_1686 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_1687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1686, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1688 lang.IFn; if linked_1687 == nil { ifn_1688 = lang.IFn_Cast(root_1686) } else { ifn_1688 = nil }; var arg_1689 any = s__794000224__3; if linked_1687 == nil { tmp12 = ifn_1688.Invoke_O__O(arg_1689) } else { tmp12 = linked_1687.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1686, arg_1689) }; arg_1672 = tmp11.Invoke_O__O(tmp12); if linked_1669 == nil { return ifn_1670.Invoke_O_O__O(arg_1671, arg_1672) } else { return linked_1669.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1668, arg_1671, arg_1672) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :307:1
func A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000229_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000229_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000229_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :307:1
func (t *A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000229_A) Ctor_O_O_I_O_O(c__b__794000226, c__old any, c__size__1927001038__auto__ int32, c__decls, c__c__1927001037__auto__ any) { t.F_b__794000226 = c__b__794000226; t.F_old = c__old; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_decls = c__decls; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :307:1
func (t *A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000229_A) Invoke_O__O(self any) any { { var i__794000225__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__794000225__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var x__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__794000225__1)); var root_1623 any = A_arbace_go_repl_A_const_96.GetRawRoot__O(); var linked_1624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1623, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1625 lang.IFn; if linked_1624 == nil { ifn_1625 = lang.IFn_Cast(root_1623) } else { ifn_1625 = nil }; var arg_1626 any = t.F_b__794000226; var arg_1627 any; var d__3 any; var root_1628 any = A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_1629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1628, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1630 lang.IFn
																if linked_1629 == nil { ifn_1630 = lang.IFn_Cast(root_1628) } else { ifn_1630 = nil }; var arg_1631 any; var tmp2 any = A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000229_fn__794000230_A_New_O(x__2); var tmp3 *jrt.Class; var fncls__1633 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000229_fn__794000230_A_fn_class; if fncls__1633 == nil { var fncls__1633d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_112, false); A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000229_fn__794000230_A_fn_class = fncls__1633d; tmp3 = fncls__1633d } else { tmp3 = fncls__1633 }; arg_1631 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_1632 any = t.F_decls; if linked_1629 == nil { d__3 = ifn_1630.Invoke_O_O__O(arg_1631, arg_1632) } else { d__3 = linked_1629.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1628, arg_1631, arg_1632) }
//line :307:1
	var tmp4 any = A_arbace_go_repl_A_const_156; var tmp5 any = lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_89, Lit_17, A_arbace_go_repl_A_const_55.Invoke_O__O(t.F_old), nil); var tmp6 any = A_arbace_go_repl_A_const_185; arg_1627 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, A_arbace_go_repl_A_const_185.Invoke_O__O(d__3))); if linked_1624 == nil { ifn_1625.Invoke_O_O__O(arg_1626, arg_1627) } else { linked_1624.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1623, arg_1626, arg_1627) }; i__794000225__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000225__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000229_fn__794000230_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000229_fn__794000230_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000229_fn__794000230_A{}; t.Ctor_O(p0); return t }
//line :308:1
func (t *A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000229_fn__794000230_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :308:1
func (t *A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000229_fn__794000230_A) Invoke_O_O__O(self, p1__794000186_SHARP___1 any) any { if lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_repl_A_const_181.Invoke_O__O(p1__794000186_SHARP___1), t.F_x) { return p1__794000186_SHARP___1 } else { return nil } }
//line :308:1
func A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000233_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000233_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000233_A{}; t.Ctor_O(p0); return t }
//line :308:1
func (t *A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000233_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :308:1
func (t *A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000233_A) Invoke_O_O__O(self, p1__794000186_SHARP___1 any) any { if lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_repl_A_const_181.Invoke_O__O(p1__794000186_SHARP___1), t.F_x) { return p1__794000186_SHARP___1 } else { return nil } }




func A_arbace_go_repl_define_BANG__iter__794000237__794000241_A_New_O_O(p0, p1 any) *A_arbace_go_repl_define_BANG__iter__794000237__794000241_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000237__794000241_A{}; t.Ctor_O_O(p0, p1); return t }
//line :313:1
func (t *A_arbace_go_repl_define_BANG__iter__794000237__794000241_A) Ctor_O_O(c__old, c__ctx any) { t.F_old = c__old; t.F_ctx = c__ctx }
//line :313:1
func (t *A_arbace_go_repl_define_BANG__iter__794000237__794000241_A) Invoke_O_O__O(self, s__794000238__1 any) any { var tmp1 any = A_arbace_go_repl_define_BANG__iter__794000237__794000241_fn__794000242_A_New_O_O_O_O(self, s__794000238__1, t.F_old, t.F_ctx); var tmp2 *jrt.Class; var fncls__2423 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000237__794000241_fn__794000242_A_fn_class; if fncls__2423 == nil { var fncls__2423d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_113, false); A_arbace_go_repl_define_BANG__iter__794000237__794000241_fn__794000242_A_fn_class = fncls__2423d; tmp2 = fncls__2423d } else { tmp2 = fncls__2423 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :313:1
func A_arbace_go_repl_define_BANG__iter__794000237__794000241_fn__794000242_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_repl_define_BANG__iter__794000237__794000241_fn__794000242_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000237__794000241_fn__794000242_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :313:1
func (t *A_arbace_go_repl_define_BANG__iter__794000237__794000241_fn__794000242_A) Ctor_O_O_O_O(c__iter__794000237, c__s__794000238, c__old, c__ctx any) { t.F_iter__794000237 = c__iter__794000237; t.F_s__794000238 = c__s__794000238; t.F_old = c__old; t.F_ctx = c__ctx }
//line :313:1
func (t *A_arbace_go_repl_define_BANG__iter__794000237__794000241_fn__794000242_A) Invoke_O__O(self any) any { { var s__794000238__1 any; var t_ any = t.F_s__794000238; t.F_s__794000238 = nil; s__794000238__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2280 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_2281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2280, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2282 lang.IFn; if linked_2281 == nil { ifn_2282 = lang.IFn_Cast(root_2280) } else { ifn_2282 = nil }; var arg_2283 any = s__794000238__1; if linked_2281 == nil { temp__1927000414__auto____2 = ifn_2282.Invoke_O__O(arg_2283) } else { temp__1927000414__auto____2 = linked_2281.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2280, arg_2283) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__794000238__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2284 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_2285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2284, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2286 lang.IFn; if linked_2285 == nil { ifn_2286 = lang.IFn_Cast(root_2284) } else { ifn_2286 = nil }; var arg_2287 any = s__794000238__3; if linked_2285 == nil { tmp1 = ifn_2286.Invoke_O__O(arg_2287) } else { tmp1 = linked_2285.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2284, arg_2287) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2288 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_2289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2288, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2290 lang.IFn; if linked_2289 == nil { ifn_2290 = lang.IFn_Cast(root_2288) } else { ifn_2290 = nil }; var arg_2291 any = s__794000238__3; if linked_2289 == nil { c__1927001037__auto____4 = ifn_2290.Invoke_O__O(arg_2291) } else { c__1927001037__auto____4 = linked_2289.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2288, arg_2291) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__794000240__6 any; var root_2292 any = A_arbace_go_repl_A_const_95.GetRawRoot__O(); var linked_2293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2292, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2294 lang.IFn; if linked_2293 == nil { ifn_2294 = lang.IFn_Cast(root_2292) } else { ifn_2294 = nil }; var arg_2295 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2293 == nil { b__794000240__6 = ifn_2294.Invoke_O__O(arg_2295) } else { b__794000240__6 = linked_2293.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2292, arg_2295) }; var tmp2 any = A_arbace_go_repl_define_BANG__iter__794000237__794000241_fn__794000242_fn__794000243_A_New_O_O_I_O_O(b__794000240__6, t.F_old, size__1927001038__auto____5, t.F_ctx, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2342 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000237__794000241_fn__794000242_fn__794000243_A_fn_class; if fncls__2342 == nil { var fncls__2342d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_114, false); A_arbace_go_repl_define_BANG__iter__794000237__794000241_fn__794000242_fn__794000243_A_fn_class = fncls__2342d; tmp3 = fncls__2342d } else { tmp3 = fncls__2342 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2343 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_2344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2343, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2345 lang.IFn; if linked_2344 == nil { ifn_2345 = lang.IFn_Cast(root_2343) } else { ifn_2345 = nil }; var arg_2346 any; var root_2348 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_2349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2348, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2350 lang.IFn; if linked_2349 == nil { ifn_2350 = lang.IFn_Cast(root_2348) } else { ifn_2350 = nil }; var arg_2351 any = b__794000240__6; if linked_2349 == nil { arg_2346 = ifn_2350.Invoke_O__O(arg_2351) } else { arg_2346 = linked_2349.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2348, arg_2351) }; var arg_2347 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__794000237); var tmp5 any; var root_2352 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_2353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2352, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2354 lang.IFn; if linked_2353 == nil { ifn_2354 = lang.IFn_Cast(root_2352) } else { ifn_2354 = nil }; var arg_2355 any = s__794000238__3; if linked_2353 == nil { tmp5 = ifn_2354.Invoke_O__O(arg_2355) } else { tmp5 = linked_2353.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2352, arg_2355) }; arg_2347 = tmp4.Invoke_O__O(tmp5); if linked_2344 == nil { return ifn_2345.Invoke_O_O__O(arg_2346, arg_2347) } else { return linked_2344.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2343, arg_2346, arg_2347) } } else { var root_2356 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_2357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2356, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2358 lang.IFn; if linked_2357 == nil { ifn_2358 = lang.IFn_Cast(root_2356) } else { ifn_2358 = nil }; var arg_2359 any; var root_2361 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_2362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2361, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2363 lang.IFn; if linked_2362 == nil { ifn_2363 = lang.IFn_Cast(root_2361) } else { ifn_2363 = nil }; var arg_2364 any = b__794000240__6; if linked_2362 == nil { arg_2359 = ifn_2363.Invoke_O__O(arg_2364) } else { arg_2359 = linked_2362.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2361, arg_2364) }; var arg_2360 any; if linked_2357 == nil { return ifn_2358.Invoke_O_O__O(arg_2359, arg_2360) } else { return linked_2357.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2356, arg_2359, arg_2360) } } } else { var d__4 any; var root_2365 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2365, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2367 lang.IFn; if linked_2366 == nil { ifn_2367 = lang.IFn_Cast(root_2365) } else { ifn_2367 = nil }; var arg_2368 any = s__794000238__3; if linked_2366 == nil { d__4 = ifn_2367.Invoke_O__O(arg_2368) } else { d__4 = linked_2366.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2365, arg_2368) }; var m__5 any = A_arbace_go_repl_A_const_181.Invoke_O__O(d__4); var tmp6 any; var and__1927000168__auto____6 any; var root_2369 any = A_arbace_go_repl_A_const_180.GetRawRoot__O(); var linked_2370 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2369, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2371 lang.IFn

	if linked_2370 == nil { ifn_2371 = lang.IFn_Cast(root_2369) } else { ifn_2371 = nil }; var arg_2372 any = Lit_4; var arg_2373 any; var root_2374 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2374, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2376 lang.IFn; if linked_2375 == nil { ifn_2376 = lang.IFn_Cast(root_2374) } else { ifn_2376 = nil }; var arg_2377 any = m__5; var arg_2378 any = A_arbace_go_repl_A_const_55; if linked_2375 == nil { arg_2373 = ifn_2376.Invoke_O_O__O(arg_2377, arg_2378) } else { arg_2373 = linked_2375.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2374, arg_2377, arg_2378) }; if linked_2370 == nil { and__1927000168__auto____6 = ifn_2371.Invoke_O_O__O(arg_2372, arg_2373) } else { and__1927000168__auto____6 = linked_2370.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2369, arg_2372, arg_2373) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_2379 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2379, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2381 lang.IFn; if linked_2380 == nil { ifn_2381 = lang.IFn_Cast(root_2379) } else { ifn_2381 = nil }; var arg_2382 any = m__5; var arg_2383 any = A_arbace_go_repl_A_const_146; if linked_2380 == nil { tmp6 = ifn_2381.Invoke_O_O__O(arg_2382, arg_2383) } else { tmp6 = linked_2380.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2379, arg_2382, arg_2383) } } else { tmp6 = and__1927000168__auto____6 }
//line :313:1
	if jrt.J2g_Truth(tmp6) { var nm__6 any; var root_2384 any = A_arbace_go_repl_A_const_158.GetRawRoot__O(); var linked_2385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2384, A_arbace_go_repl_method_name_A_fn_class); var ifn_2386 lang.IFn


		if linked_2385 == nil { ifn_2386 = lang.IFn_Cast(root_2384) } else { ifn_2386 = nil }; var arg_2387 any = m__5; if linked_2385 == nil { nm__6 = ifn_2386.Invoke_O__O(arg_2387) } else { nm__6 = linked_2385.(*A_arbace_go_repl_method_name_A).Invoke_O_O__O(root_2384, arg_2387) }
//line :313:1
		var k__7 any; var root_2388 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var linked_2389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2388, A_arbace_go_repl_type_key_A_fn_class); var ifn_2390 lang.IFn



		if linked_2389 == nil { ifn_2390 = lang.IFn_Cast(root_2388) } else { ifn_2390 = nil }; var arg_2391 any; var root_2393 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2393, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2395 lang.IFn; if linked_2394 == nil { ifn_2395 = lang.IFn_Cast(root_2393) } else { ifn_2395 = nil }; var arg_2396 any = m__5; var arg_2397 any = A_arbace_go_repl_A_const_142; if linked_2394 == nil { arg_2391 = ifn_2395.Invoke_O_O__O(arg_2396, arg_2397) } else { arg_2391 = linked_2394.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2393, arg_2396, arg_2397) }; var arg_2392 any = A_arbace_go_repl_A_const_151.Invoke_O__O(t.F_ctx); if linked_2389 == nil { k__7 = ifn_2390.Invoke_O_O__O(arg_2391, arg_2392) } else { k__7 = linked_2389.(*A_arbace_go_repl_type_key_A).Invoke_O_O_O__O(root_2388, arg_2391, arg_2392) }
//line :313:1
		var prev__8 any; var root_2398 any = A_arbace_go_repl_A_const_153.GetRawRoot__O(); var linked_2399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2398, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_2400 lang.IFn




		if linked_2399 == nil { ifn_2400 = lang.IFn_Cast(root_2398) } else { ifn_2400 = nil }; var arg_2401 any = t.F_old; var arg_2402 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_repl_A_const_159, nm__6); if linked_2399 == nil { prev__8 = ifn_2400.Invoke_O_O__O(arg_2401, arg_2402) } else { prev__8 = linked_2399.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_2398, arg_2401, arg_2402) }
//line :313:1
		var cell__9 any; var tmp7 any
		var and__1927000168__auto____9 any = prev__8




		if jrt.J2g_Truth(and__1927000168__auto____9) { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(k__7, A_arbace_go_repl_A_const_182.Invoke_O__O(prev__8))).Ref() } else { tmp7 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp7) { cell__9 = A_arbace_go_repl_A_const_156.Invoke_O__O(prev__8) } else { cell__9 = lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_89, nm__6, A_arbace_go_repl_A_const_55.Invoke_O__O(t.F_old), nil) }
//line :313:1
		var root_2410 any = A_arbace_go_repl_A_const_100.GetRawRoot__O(); var linked_2411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2410, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2412 lang.IFn; if linked_2411 == nil { ifn_2412 = lang.IFn_Cast(root_2410) } else { ifn_2412 = nil }; var tmp8 any = A_arbace_go_repl_A_const_156; var tmp9 any = A_arbace_go_repl_A_const_182; var tmp10 any = A_arbace_go_repl_A_const_185; var tmp11 any = A_arbace_go_repl_A_const_185.Invoke_O__O(d__4); var tmp12 any = A_arbace_go_repl_A_const_181; var tmp13 any = A_arbace_go_repl_A_const_177; var arg_2413 any = lang.Tuple_Create_O_O__IPersistentVector(nm__6, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, cell__9, tmp9, k__7, tmp10, tmp11, tmp12, m__5, tmp13, A_arbace_go_repl_A_const_177.Invoke_O__O(d__4)))); var arg_2414 any; var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__794000237); var tmp15 any; var root_2415 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_2416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2415, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2417 lang.IFn; if linked_2416 == nil { ifn_2417 = lang.IFn_Cast(root_2415) } else { ifn_2417 = nil }; var arg_2418 any = s__794000238__3; if linked_2416 == nil { tmp15 = ifn_2417.Invoke_O__O(arg_2418) } else { tmp15 = linked_2416.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2415, arg_2418) }; arg_2414 = tmp14.Invoke_O__O(tmp15); if linked_2411 == nil { return ifn_2412.Invoke_O_O__O(arg_2413, arg_2414) } else { return linked_2411.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2410, arg_2413, arg_2414) } } else { var tmp16 any; var root_2419 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_2420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2419, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2421 lang.IFn; if linked_2420 == nil { ifn_2421 = lang.IFn_Cast(root_2419) } else { ifn_2421 = nil }; var arg_2422 any = s__794000238__3; if linked_2420 == nil { tmp16 = ifn_2421.Invoke_O__O(arg_2422) } else { tmp16 = linked_2420.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2419, arg_2422) }; s__794000238__1 = tmp16; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :313:1
func A_arbace_go_repl_define_BANG__iter__794000237__794000241_fn__794000242_fn__794000243_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_go_repl_define_BANG__iter__794000237__794000241_fn__794000242_fn__794000243_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000237__794000241_fn__794000242_fn__794000243_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :313:1
func (t *A_arbace_go_repl_define_BANG__iter__794000237__794000241_fn__794000242_fn__794000243_A) Ctor_O_O_I_O_O(c__b__794000240, c__old any, c__size__1927001038__auto__ int32, c__ctx, c__c__1927001037__auto__ any) { t.F_b__794000240 = c__b__794000240; t.F_old = c__old; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_ctx = c__ctx; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :313:1
func (t *A_arbace_go_repl_define_BANG__iter__794000237__794000241_fn__794000242_fn__794000243_A) Invoke_O__O(self any) any { { var i__794000239__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__794000239__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var d__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__794000239__1)); var m__3 any = A_arbace_go_repl_A_const_181.Invoke_O__O(d__2); var tmp2 any; var and__1927000168__auto____4 any; var root_2296 any = A_arbace_go_repl_A_const_180.GetRawRoot__O(); var linked_2297 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2296, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2298 lang.IFn

	if linked_2297 == nil { ifn_2298 = lang.IFn_Cast(root_2296) } else { ifn_2298 = nil }; var arg_2299 any = Lit_4; var arg_2300 any; var root_2301 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2301, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2303 lang.IFn; if linked_2302 == nil { ifn_2303 = lang.IFn_Cast(root_2301) } else { ifn_2303 = nil }; var arg_2304 any = m__3; var arg_2305 any = A_arbace_go_repl_A_const_55; if linked_2302 == nil { arg_2300 = ifn_2303.Invoke_O_O__O(arg_2304, arg_2305) } else { arg_2300 = linked_2302.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2301, arg_2304, arg_2305) }; if linked_2297 == nil { and__1927000168__auto____4 = ifn_2298.Invoke_O_O__O(arg_2299, arg_2300) } else { and__1927000168__auto____4 = linked_2297.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2296, arg_2299, arg_2300) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_2306 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2306, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2308 lang.IFn; if linked_2307 == nil { ifn_2308 = lang.IFn_Cast(root_2306) } else { ifn_2308 = nil }; var arg_2309 any = m__3; var arg_2310 any = A_arbace_go_repl_A_const_146; if linked_2307 == nil { tmp2 = ifn_2308.Invoke_O_O__O(arg_2309, arg_2310) } else { tmp2 = linked_2307.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2306, arg_2309, arg_2310) } } else { tmp2 = and__1927000168__auto____4 }
//line :313:1
	if jrt.J2g_Truth(tmp2) { var nm__4 any; var root_2311 any = A_arbace_go_repl_A_const_158.GetRawRoot__O(); var linked_2312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2311, A_arbace_go_repl_method_name_A_fn_class); var ifn_2313 lang.IFn


		if linked_2312 == nil { ifn_2313 = lang.IFn_Cast(root_2311) } else { ifn_2313 = nil }; var arg_2314 any = m__3; if linked_2312 == nil { nm__4 = ifn_2313.Invoke_O__O(arg_2314) } else { nm__4 = linked_2312.(*A_arbace_go_repl_method_name_A).Invoke_O_O__O(root_2311, arg_2314) }
//line :313:1
		var k__5 any; var root_2315 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var linked_2316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2315, A_arbace_go_repl_type_key_A_fn_class); var ifn_2317 lang.IFn



		if linked_2316 == nil { ifn_2317 = lang.IFn_Cast(root_2315) } else { ifn_2317 = nil }; var arg_2318 any; var root_2320 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2320, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2322 lang.IFn; if linked_2321 == nil { ifn_2322 = lang.IFn_Cast(root_2320) } else { ifn_2322 = nil }; var arg_2323 any = m__3; var arg_2324 any = A_arbace_go_repl_A_const_142; if linked_2321 == nil { arg_2318 = ifn_2322.Invoke_O_O__O(arg_2323, arg_2324) } else { arg_2318 = linked_2321.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2320, arg_2323, arg_2324) }; var arg_2319 any = A_arbace_go_repl_A_const_151.Invoke_O__O(t.F_ctx); if linked_2316 == nil { k__5 = ifn_2317.Invoke_O_O__O(arg_2318, arg_2319) } else { k__5 = linked_2316.(*A_arbace_go_repl_type_key_A).Invoke_O_O_O__O(root_2315, arg_2318, arg_2319) }
//line :313:1
		var prev__6 any; var root_2325 any = A_arbace_go_repl_A_const_153.GetRawRoot__O(); var linked_2326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2325, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_2327 lang.IFn




		if linked_2326 == nil { ifn_2327 = lang.IFn_Cast(root_2325) } else { ifn_2327 = nil }; var arg_2328 any = t.F_old; var arg_2329 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_repl_A_const_159, nm__4); if linked_2326 == nil { prev__6 = ifn_2327.Invoke_O_O__O(arg_2328, arg_2329) } else { prev__6 = linked_2326.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_2325, arg_2328, arg_2329) }
//line :313:1
		var cell__7 any; var tmp3 any
		var and__1927000168__auto____7 any = prev__6




		if jrt.J2g_Truth(and__1927000168__auto____7) { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(k__5, A_arbace_go_repl_A_const_182.Invoke_O__O(prev__6))).Ref() } else { tmp3 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp3) { cell__7 = A_arbace_go_repl_A_const_156.Invoke_O__O(prev__6) } else { cell__7 = lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_89, nm__4, A_arbace_go_repl_A_const_55.Invoke_O__O(t.F_old), nil) }
//line :313:1
		var root_2337 any = A_arbace_go_repl_A_const_96.GetRawRoot__O(); var linked_2338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2337, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2339 lang.IFn; if linked_2338 == nil { ifn_2339 = lang.IFn_Cast(root_2337) } else { ifn_2339 = nil }; var arg_2340 any = t.F_b__794000240; var tmp4 any = A_arbace_go_repl_A_const_156; var tmp5 any = A_arbace_go_repl_A_const_182; var tmp6 any = A_arbace_go_repl_A_const_185; var tmp7 any = A_arbace_go_repl_A_const_185.Invoke_O__O(d__2); var tmp8 any = A_arbace_go_repl_A_const_181; var tmp9 any = A_arbace_go_repl_A_const_177; var arg_2341 any = lang.Tuple_Create_O_O__IPersistentVector(nm__4, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, cell__7, tmp5, k__5, tmp6, tmp7, tmp8, m__3, tmp9, A_arbace_go_repl_A_const_177.Invoke_O__O(d__2)))); if linked_2338 == nil { ifn_2339.Invoke_O_O__O(arg_2340, arg_2341) } else { linked_2338.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2337, arg_2340, arg_2341) }; i__794000239__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000239__1); continue L1 } else { i__794000239__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000239__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









func A_arbace_go_repl_define_BANG__iter__794000247__794000253_A_New() *A_arbace_go_repl_define_BANG__iter__794000247__794000253_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000247__794000253_A{}; t.Ctor(); return t }
//line :323:1
func (t *A_arbace_go_repl_define_BANG__iter__794000247__794000253_A) Ctor() {}
//line :323:1
func (t *A_arbace_go_repl_define_BANG__iter__794000247__794000253_A) Invoke_O_O__O(self, s__794000248__1 any) any { var tmp1 any = A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_A_New_O_O(s__794000248__1, self); var tmp2 *jrt.Class; var fncls__1804 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_A_fn_class; if fncls__1804 == nil { var fncls__1804d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_115, false); A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_A_fn_class = fncls__1804d; tmp2 = fncls__1804d } else { tmp2 = fncls__1804 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :323:1
func A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_A_New_O_O(p0, p1 any) *A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_A{}; t.Ctor_O_O(p0, p1); return t }
//line :323:1
func (t *A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_A) Ctor_O_O(c__s__794000248, c__iter__794000247 any) { t.F_s__794000248 = c__s__794000248; t.F_iter__794000247 = c__iter__794000247 }
//line :323:1
func (t *A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_A) Invoke_O__O(self any) any { { var s__794000248__1 any; var t_ any = t.F_s__794000248; t.F_s__794000248 = nil; s__794000248__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1692 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_1693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1692, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1694 lang.IFn; if linked_1693 == nil { ifn_1694 = lang.IFn_Cast(root_1692) } else { ifn_1694 = nil }; var arg_1695 any = s__794000248__1; if linked_1693 == nil { temp__1927000414__auto____2 = ifn_1694.Invoke_O__O(arg_1695) } else { temp__1927000414__auto____2 = linked_1693.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1692, arg_1695) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var d__4 any; var root_1696 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_1697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1696, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1698 lang.IFn; if linked_1697 == nil { ifn_1698 = lang.IFn_Cast(root_1696) } else { ifn_1698 = nil }; var arg_1699 any = xs__1927001018__auto____3; if linked_1697 == nil { d__4 = ifn_1698.Invoke_O__O(arg_1699) } else { d__4 = linked_1697.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1696, arg_1699) }; var tmp1 any = A_arbace_go_repl_A_const_187; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_repl_A_const_178.Invoke_O__O(d__4)) { var iterys__1927001035__auto____5 any; var tmp2 any = A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_A_New(); var tmp3 *jrt.Class; var fncls__1782 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_A_fn_class; if fncls__1782 == nil { var fncls__1782d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_116, false); A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_A_fn_class = fncls__1782d; tmp3 = fncls__1782d } else { tmp3 = fncls__1782 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var fs__1927001036__auto____6 any; var root_1783 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_1784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1783, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1785 lang.IFn; if linked_1784 == nil { ifn_1785 = lang.IFn_Cast(root_1783) } else { ifn_1785 = nil }; var arg_1786 any; var tmp4 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp5 any; var or__1927000174__auto____6 any = A_arbace_go_repl_A_const_188.Invoke_O__O(d__4); if jrt.J2g_Truth(or__1927000174__auto____6) { tmp5 = or__1927000174__auto____6 } else { tmp5 = lang.Tuple_Create_O__IPersistentVector(A_arbace_go_repl_A_const_181.Invoke_O__O(d__4)) }; arg_1786 = tmp4.Invoke_O__O(tmp5); if linked_1784 == nil { fs__1927001036__auto____6 = ifn_1785.Invoke_O__O(arg_1786) } else { fs__1927001036__auto____6 = linked_1784.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1783, arg_1786) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1787 any = A_arbace_go_repl_A_const_101.GetRawRoot__O(); var linked_1788 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1787, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1789 lang.IFn; if linked_1788 == nil { ifn_1789 = lang.IFn_Cast(root_1787) } else { ifn_1789 = nil }; var arg_1790 any = fs__1927001036__auto____6; var arg_1791 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__794000247); var tmp7 any; var root_1792 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_1793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1792, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1794 lang.IFn; if linked_1793 == nil { ifn_1794 = lang.IFn_Cast(root_1792) } else { ifn_1794 = nil }; var arg_1795 any = s__794000248__1; if linked_1793 == nil { tmp7 = ifn_1794.Invoke_O__O(arg_1795) } else { tmp7 = linked_1793.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1792, arg_1795) }; arg_1791 = tmp6.Invoke_O__O(tmp7); if linked_1788 == nil { return ifn_1789.Invoke_O_O__O(arg_1790, arg_1791) } else { return linked_1788.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1787, arg_1790, arg_1791) } } else { var tmp8 any; var root_1796 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_1797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1796, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1798 lang.IFn; if linked_1797 == nil { ifn_1798 = lang.IFn_Cast(root_1796) } else { ifn_1798 = nil }; var arg_1799 any = s__794000248__1; if linked_1797 == nil { tmp8 = ifn_1798.Invoke_O__O(arg_1799) } else { tmp8 = linked_1797.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1796, arg_1799) }; s__794000248__1 = tmp8; continue L1 } } else { var tmp9 any; var root_1800 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_1801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1800, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1802 lang.IFn; if linked_1801 == nil { ifn_1802 = lang.IFn_Cast(root_1800) } else { ifn_1802 = nil }; var arg_1803 any = s__794000248__1; if linked_1801 == nil { tmp9 = ifn_1802.Invoke_O__O(arg_1803) } else { tmp9 = linked_1801.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1800, arg_1803) }; s__794000248__1 = tmp9; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :323:1
func A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_A_New() *A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_A{}; t.Ctor(); return t }
//line :323:1
func (t *A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_A) Ctor() {}
//line :323:1
func (t *A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_A) Invoke_O_O__O(self, s__794000250__1 any) any { var tmp1 any = A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_fn__794000256_A_New_O_O(self, s__794000250__1); var tmp2 *jrt.Class; var fncls__1781 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_fn__794000256_A_fn_class; if fncls__1781 == nil { var fncls__1781d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_117, false); A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_fn__794000256_A_fn_class = fncls__1781d; tmp2 = fncls__1781d } else { tmp2 = fncls__1781 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :323:1
func A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_fn__794000256_A_New_O_O(p0, p1 any) *A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_fn__794000256_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_fn__794000256_A{}; t.Ctor_O_O(p0, p1); return t }
//line :323:1
func (t *A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_fn__794000256_A) Ctor_O_O(c__iter__794000249, c__s__794000250 any) { t.F_iter__794000249 = c__iter__794000249; t.F_s__794000250 = c__s__794000250 }
//line :323:1
func (t *A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_fn__794000256_A) Invoke_O__O(self any) any { { var s__794000250__1 any; var t_ any = t.F_s__794000250; t.F_s__794000250 = nil; s__794000250__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1700 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_1701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1700, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1702 lang.IFn; if linked_1701 == nil { ifn_1702 = lang.IFn_Cast(root_1700) } else { ifn_1702 = nil }; var arg_1703 any = s__794000250__1; if linked_1701 == nil { temp__1927000414__auto____2 = ifn_1702.Invoke_O__O(arg_1703) } else { temp__1927000414__auto____2 = linked_1701.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1700, arg_1703) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__794000250__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1704 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_1705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1704, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1706 lang.IFn; if linked_1705 == nil { ifn_1706 = lang.IFn_Cast(root_1704) } else { ifn_1706 = nil }; var arg_1707 any = s__794000250__3; if linked_1705 == nil { tmp1 = ifn_1706.Invoke_O__O(arg_1707) } else { tmp1 = linked_1705.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1704, arg_1707) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1708 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_1709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1708, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1710 lang.IFn; if linked_1709 == nil { ifn_1710 = lang.IFn_Cast(root_1708) } else { ifn_1710 = nil }; var arg_1711 any = s__794000250__3; if linked_1709 == nil { c__1927001037__auto____4 = ifn_1710.Invoke_O__O(arg_1711) } else { c__1927001037__auto____4 = linked_1709.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1708, arg_1711) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__794000252__6 any; var root_1712 any = A_arbace_go_repl_A_const_95.GetRawRoot__O(); var linked_1713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1712, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1714 lang.IFn; if linked_1713 == nil { ifn_1714 = lang.IFn_Cast(root_1712) } else { ifn_1714 = nil }; var arg_1715 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1713 == nil { b__794000252__6 = ifn_1714.Invoke_O__O(arg_1715) } else { b__794000252__6 = linked_1713.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1712, arg_1715) }; var tmp2 any = A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_fn__794000256_fn__794000257_A_New_O_I_O(b__794000252__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1731 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_fn__794000256_fn__794000257_A_fn_class; if fncls__1731 == nil { var fncls__1731d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_118, false); A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_fn__794000256_fn__794000257_A_fn_class = fncls__1731d; tmp3 = fncls__1731d } else { tmp3 = fncls__1731 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1732 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_1733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1732, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1734 lang.IFn; if linked_1733 == nil { ifn_1734 = lang.IFn_Cast(root_1732) } else { ifn_1734 = nil }; var arg_1735 any; var root_1737 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_1738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1737, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1739 lang.IFn; if linked_1738 == nil { ifn_1739 = lang.IFn_Cast(root_1737) } else { ifn_1739 = nil }; var arg_1740 any = b__794000252__6; if linked_1738 == nil { arg_1735 = ifn_1739.Invoke_O__O(arg_1740) } else { arg_1735 = linked_1738.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1737, arg_1740) }; var arg_1736 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__794000249); var tmp5 any; var root_1741 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_1742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1741, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1743 lang.IFn; if linked_1742 == nil { ifn_1743 = lang.IFn_Cast(root_1741) } else { ifn_1743 = nil }; var arg_1744 any = s__794000250__3; if linked_1742 == nil { tmp5 = ifn_1743.Invoke_O__O(arg_1744) } else { tmp5 = linked_1742.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1741, arg_1744) }; arg_1736 = tmp4.Invoke_O__O(tmp5); if linked_1733 == nil { return ifn_1734.Invoke_O_O__O(arg_1735, arg_1736) } else { return linked_1733.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1732, arg_1735, arg_1736) } } else { var root_1745 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_1746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1745, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1747 lang.IFn; if linked_1746 == nil { ifn_1747 = lang.IFn_Cast(root_1745) } else { ifn_1747 = nil }; var arg_1748 any; var root_1750 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_1751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1750, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1752 lang.IFn; if linked_1751 == nil { ifn_1752 = lang.IFn_Cast(root_1750) } else { ifn_1752 = nil }; var arg_1753 any = b__794000252__6; if linked_1751 == nil { arg_1748 = ifn_1752.Invoke_O__O(arg_1753) } else { arg_1748 = linked_1751.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1750, arg_1753) }; var arg_1749 any; if linked_1746 == nil { return ifn_1747.Invoke_O_O__O(arg_1748, arg_1749) } else { return linked_1746.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1745, arg_1748, arg_1749) } } } else { var x__4 any; var root_1754 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1754, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1756 lang.IFn; if linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var arg_1757 any = s__794000250__3; if linked_1755 == nil { x__4 = ifn_1756.Invoke_O__O(arg_1757) } else { x__4 = linked_1755.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1754, arg_1757) }; var tmp6 any; var root_1758 any = A_arbace_go_repl_A_const_180.GetRawRoot__O(); var linked_1759 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1758, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1760 lang.IFn; if linked_1759 == nil { ifn_1760 = lang.IFn_Cast(root_1758) } else { ifn_1760 = nil }; var arg_1761 any = Lit_4; var arg_1762 any; var root_1763 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1763, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1765 lang.IFn; if linked_1764 == nil { ifn_1765 = lang.IFn_Cast(root_1763) } else { ifn_1765 = nil }; var arg_1766 any = x__4; var arg_1767 any = A_arbace_go_repl_A_const_55; if linked_1764 == nil { arg_1762 = ifn_1765.Invoke_O_O__O(arg_1766, arg_1767) } else { arg_1762 = linked_1764.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1763, arg_1766, arg_1767) }; if linked_1759 == nil { tmp6 = ifn_1760.Invoke_O_O__O(arg_1761, arg_1762) } else { tmp6 = linked_1759.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1758, arg_1761, arg_1762) }; if jrt.J2g_Truth(tmp6) { var root_1768 any = A_arbace_go_repl_A_const_100.GetRawRoot__O(); var linked_1769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1768, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1770 lang.IFn; if linked_1769 == nil { ifn_1770 = lang.IFn_Cast(root_1768) } else { ifn_1770 = nil }; var arg_1771 any = x__4; var arg_1772 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__794000249); var tmp8 any; var root_1773 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_1774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1773, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1775 lang.IFn; if linked_1774 == nil { ifn_1775 = lang.IFn_Cast(root_1773) } else { ifn_1775 = nil }; var arg_1776 any = s__794000250__3; if linked_1774 == nil { tmp8 = ifn_1775.Invoke_O__O(arg_1776) } else { tmp8 = linked_1774.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1773, arg_1776) }; arg_1772 = tmp7.Invoke_O__O(tmp8); if linked_1769 == nil { return ifn_1770.Invoke_O_O__O(arg_1771, arg_1772) } else { return linked_1769.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1768, arg_1771, arg_1772) } } else { var tmp9 any; var root_1777 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_1778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1777, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1779 lang.IFn; if linked_1778 == nil { ifn_1779 = lang.IFn_Cast(root_1777) } else { ifn_1779 = nil }; var arg_1780 any = s__794000250__3; if linked_1778 == nil { tmp9 = ifn_1779.Invoke_O__O(arg_1780) } else { tmp9 = linked_1778.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1777, arg_1780) }; s__794000250__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :323:1
func A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_fn__794000256_fn__794000257_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_fn__794000256_fn__794000257_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_fn__794000256_fn__794000257_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :323:1
func (t *A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_fn__794000256_fn__794000257_A) Ctor_O_I_O(c__b__794000252 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__794000252 = c__b__794000252; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :323:1
func (t *A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_fn__794000256_fn__794000257_A) Invoke_O__O(self any) any { { var i__794000251__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__794000251__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var x__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__794000251__1)); var tmp2 any; var root_1716 any = A_arbace_go_repl_A_const_180.GetRawRoot__O(); var linked_1717 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1716, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1718 lang.IFn; if linked_1717 == nil { ifn_1718 = lang.IFn_Cast(root_1716) } else { ifn_1718 = nil }; var arg_1719 any = Lit_4; var arg_1720 any; var root_1721 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1721, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1723 lang.IFn; if linked_1722 == nil { ifn_1723 = lang.IFn_Cast(root_1721) } else { ifn_1723 = nil }; var arg_1724 any = x__2; var arg_1725 any = A_arbace_go_repl_A_const_55; if linked_1722 == nil { arg_1720 = ifn_1723.Invoke_O_O__O(arg_1724, arg_1725) } else { arg_1720 = linked_1722.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1721, arg_1724, arg_1725) }; if linked_1717 == nil { tmp2 = ifn_1718.Invoke_O_O__O(arg_1719, arg_1720) } else { tmp2 = linked_1717.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1716, arg_1719, arg_1720) }; if jrt.J2g_Truth(tmp2) { var root_1726 any = A_arbace_go_repl_A_const_96.GetRawRoot__O(); var linked_1727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1726, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1728 lang.IFn; if linked_1727 == nil { ifn_1728 = lang.IFn_Cast(root_1726) } else { ifn_1728 = nil }; var arg_1729 any = t.F_b__794000252; var arg_1730 any = x__2; if linked_1727 == nil { ifn_1728.Invoke_O_O__O(arg_1729, arg_1730) } else { linked_1727.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1726, arg_1729, arg_1730) }; i__794000251__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000251__1); continue L1 } else { i__794000251__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000251__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_go_repl_define_BANG__iter__794000263__794000267_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_repl_define_BANG__iter__794000263__794000267_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000263__794000267_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :326:1
func (t *A_arbace_go_repl_define_BANG__iter__794000263__794000267_A) Ctor_O_O_O(c__new_vars, c__old, c__ctx any) { t.F_new_vars = c__new_vars; t.F_old = c__old; t.F_ctx = c__ctx }
//line :326:1
func (t *A_arbace_go_repl_define_BANG__iter__794000263__794000267_A) Invoke_O_O__O(self, s__794000264__1 any) any { var tmp1 any = A_arbace_go_repl_define_BANG__iter__794000263__794000267_fn__794000268_A_New_O_O_O_O_O(t.F_new_vars, self, t.F_old, t.F_ctx, s__794000264__1); var tmp2 *jrt.Class; var fncls__1972 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000263__794000267_fn__794000268_A_fn_class; if fncls__1972 == nil { var fncls__1972d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_119, false); A_arbace_go_repl_define_BANG__iter__794000263__794000267_fn__794000268_A_fn_class = fncls__1972d; tmp2 = fncls__1972d } else { tmp2 = fncls__1972 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :326:1
func A_arbace_go_repl_define_BANG__iter__794000263__794000267_fn__794000268_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_repl_define_BANG__iter__794000263__794000267_fn__794000268_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000263__794000267_fn__794000268_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :326:1
func (t *A_arbace_go_repl_define_BANG__iter__794000263__794000267_fn__794000268_A) Ctor_O_O_O_O_O(c__new_vars, c__iter__794000263, c__old, c__ctx, c__s__794000264 any) { t.F_new_vars = c__new_vars; t.F_iter__794000263 = c__iter__794000263; t.F_old = c__old; t.F_ctx = c__ctx; t.F_s__794000264 = c__s__794000264 }
//line :326:1
func (t *A_arbace_go_repl_define_BANG__iter__794000263__794000267_fn__794000268_A) Invoke_O__O(self any) any { { var s__794000264__1 any; var t_ any = t.F_s__794000264; t.F_s__794000264 = nil; s__794000264__1 = t_; for { var temp__1927000414__auto____2 any; var root_1815 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_1816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1815, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1817 lang.IFn; if linked_1816 == nil { ifn_1817 = lang.IFn_Cast(root_1815) } else { ifn_1817 = nil }; var arg_1818 any = s__794000264__1; if linked_1816 == nil { temp__1927000414__auto____2 = ifn_1817.Invoke_O__O(arg_1818) } else { temp__1927000414__auto____2 = linked_1816.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1815, arg_1818) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__794000264__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1819 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_1820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1819, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1821 lang.IFn; if linked_1820 == nil { ifn_1821 = lang.IFn_Cast(root_1819) } else { ifn_1821 = nil }; var arg_1822 any = s__794000264__3; if linked_1820 == nil { tmp1 = ifn_1821.Invoke_O__O(arg_1822) } else { tmp1 = linked_1820.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1819, arg_1822) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1823 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_1824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1823, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1825 lang.IFn; if linked_1824 == nil { ifn_1825 = lang.IFn_Cast(root_1823) } else { ifn_1825 = nil }; var arg_1826 any = s__794000264__3; if linked_1824 == nil { c__1927001037__auto____4 = ifn_1825.Invoke_O__O(arg_1826) } else { c__1927001037__auto____4 = linked_1824.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1823, arg_1826) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__794000266__6 any; var root_1827 any = A_arbace_go_repl_A_const_95.GetRawRoot__O(); var linked_1828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1827, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1829 lang.IFn; if linked_1828 == nil { ifn_1829 = lang.IFn_Cast(root_1827) } else { ifn_1829 = nil }; var arg_1830 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1828 == nil { b__794000266__6 = ifn_1829.Invoke_O__O(arg_1830) } else { b__794000266__6 = linked_1828.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1827, arg_1830) }; var tmp2 any = A_arbace_go_repl_define_BANG__iter__794000263__794000267_fn__794000268_fn__794000269_A_New_O_O_O_I_O_O(b__794000266__6, t.F_new_vars, t.F_old, size__1927001038__auto____5, t.F_ctx, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1886 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000263__794000267_fn__794000268_fn__794000269_A_fn_class; if fncls__1886 == nil { var fncls__1886d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_120, false); A_arbace_go_repl_define_BANG__iter__794000263__794000267_fn__794000268_fn__794000269_A_fn_class = fncls__1886d; tmp3 = fncls__1886d } else { tmp3 = fncls__1886 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1887 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_1888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1887, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1889 lang.IFn; if linked_1888 == nil { ifn_1889 = lang.IFn_Cast(root_1887) } else { ifn_1889 = nil }; var arg_1890 any; var root_1892 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_1893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1892, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1894 lang.IFn; if linked_1893 == nil { ifn_1894 = lang.IFn_Cast(root_1892) } else { ifn_1894 = nil }; var arg_1895 any = b__794000266__6; if linked_1893 == nil { arg_1890 = ifn_1894.Invoke_O__O(arg_1895) } else { arg_1890 = linked_1893.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1892, arg_1895) }; var arg_1891 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__794000263); var tmp5 any; var root_1896 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_1897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1896, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1898 lang.IFn; if linked_1897 == nil { ifn_1898 = lang.IFn_Cast(root_1896) } else { ifn_1898 = nil }; var arg_1899 any = s__794000264__3; if linked_1897 == nil { tmp5 = ifn_1898.Invoke_O__O(arg_1899) } else { tmp5 = linked_1897.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1896, arg_1899) }; arg_1891 = tmp4.Invoke_O__O(tmp5); if linked_1888 == nil { return ifn_1889.Invoke_O_O__O(arg_1890, arg_1891) } else { return linked_1888.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1887, arg_1890, arg_1891) } } else { var root_1900 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_1901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1900, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1902 lang.IFn; if linked_1901 == nil { ifn_1902 = lang.IFn_Cast(root_1900) } else { ifn_1902 = nil }; var arg_1903 any; var root_1905 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_1906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1905, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1907 lang.IFn; if linked_1906 == nil { ifn_1907 = lang.IFn_Cast(root_1905) } else { ifn_1907 = nil }; var arg_1908 any = b__794000266__6; if linked_1906 == nil { arg_1903 = ifn_1907.Invoke_O__O(arg_1908) } else { arg_1903 = linked_1906.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1905, arg_1908) }; var arg_1904 any; if linked_1901 == nil { return ifn_1902.Invoke_O_O__O(arg_1903, arg_1904) } else { return linked_1901.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1900, arg_1903, arg_1904) } } } else { var x__4 any; var root_1909 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_1910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1909, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1911 lang.IFn; if linked_1910 == nil { ifn_1911 = lang.IFn_Cast(root_1909) } else { ifn_1911 = nil }; var arg_1912 any = s__794000264__3; if linked_1910 == nil { x__4 = ifn_1911.Invoke_O__O(arg_1912) } else { x__4 = linked_1910.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1909, arg_1912) }; var nm__5 any; var root_1913 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1913, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1915 lang.IFn
														if linked_1914 == nil { ifn_1915 = lang.IFn_Cast(root_1913) } else { ifn_1915 = nil }; var arg_1916 any = x__4; var arg_1917 any = A_arbace_go_repl_A_const_55; if linked_1914 == nil { nm__5 = ifn_1915.Invoke_O_O__O(arg_1916, arg_1917) } else { nm__5 = linked_1914.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1913, arg_1916, arg_1917) }
//line :326:1
	var k__6 any; var root_1918 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var linked_1919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1918, A_arbace_go_repl_type_key_A_fn_class); var ifn_1920 lang.IFn

	if linked_1919 == nil { ifn_1920 = lang.IFn_Cast(root_1918) } else { ifn_1920 = nil }; var arg_1921 any; var root_1923 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1923, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1925 lang.IFn; if linked_1924 == nil { ifn_1925 = lang.IFn_Cast(root_1923) } else { ifn_1925 = nil }; var arg_1926 any = x__4; var arg_1927 any = A_arbace_go_repl_A_const_142; if linked_1924 == nil { arg_1921 = ifn_1925.Invoke_O_O__O(arg_1926, arg_1927) } else { arg_1921 = linked_1924.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1923, arg_1926, arg_1927) }; var arg_1922 any = A_arbace_go_repl_A_const_151.Invoke_O__O(t.F_ctx); if linked_1919 == nil { k__6 = ifn_1920.Invoke_O_O__O(arg_1921, arg_1922) } else { k__6 = linked_1919.(*A_arbace_go_repl_type_key_A).Invoke_O_O_O__O(root_1918, arg_1921, arg_1922) }
//line :326:1
	var prev__7 any; var root_1928 any = A_arbace_go_repl_A_const_153.GetRawRoot__O(); var linked_1929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1928, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1930 lang.IFn


	if linked_1929 == nil { ifn_1930 = lang.IFn_Cast(root_1928) } else { ifn_1930 = nil }; var arg_1931 any = t.F_old; var arg_1932 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_repl_A_const_60, nm__5); if linked_1929 == nil { prev__7 = ifn_1930.Invoke_O_O__O(arg_1931, arg_1932) } else { prev__7 = linked_1929.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1928, arg_1931, arg_1932) }
//line :326:1
	var root_1933 any = A_arbace_go_repl_A_const_100.GetRawRoot__O(); var linked_1934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1933, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1935 lang.IFn; if linked_1934 == nil { ifn_1935 = lang.IFn_Cast(root_1933) } else { ifn_1935 = nil }; var arg_1936 any; var tmp6 any
	var and__1927000168__auto____8 any = prev__7


	if jrt.J2g_Truth(and__1927000168__auto____8) { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(k__6, A_arbace_go_repl_A_const_182.Invoke_O__O(prev__7))).Ref() } else { tmp6 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_1938 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var linked_1939 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1938, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1940 lang.IFn
		if linked_1939 == nil { ifn_1940 = lang.IFn_Cast(root_1938) } else { ifn_1940 = nil }; var arg_1941 any = prev__7; var arg_1942 any = A_arbace_go_repl_A_const_181; var arg_1943 any = x__4; if linked_1939 == nil { tmp7 = ifn_1940.Invoke_O_O_O__O(arg_1941, arg_1942, arg_1943) } else { tmp7 = linked_1939.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1938, arg_1941, arg_1942, arg_1943) }
//line :330:1
		arg_1936 = lang.Tuple_Create_O_O__IPersistentVector(nm__5, tmp7) } else {

			var tmp8 *lang.Volatile = lang.Volatile_Cast(t.F_new_vars); var tmp9 any; var root_1944 any = A_arbace_go_repl_A_const_15.GetRawRoot__O(); var linked_1945 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1944, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1946 lang.IFn; if linked_1945 == nil { ifn_1946 = lang.IFn_Cast(root_1944) } else { ifn_1946 = nil }; var arg_1947 any = jrt.NN(lang.Volatile_Cast(t.F_new_vars)).Deref__O(); var arg_1948 any = nm__5; if linked_1945 == nil { tmp9 = ifn_1946.Invoke_O_O__O(arg_1947, arg_1948) } else { tmp9 = linked_1945.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1944, arg_1947, arg_1948) }; jrt.NN(tmp8).Reset_O__O(tmp9)
//line :330:1
			var tmp10 any = A_arbace_go_repl_A_const_190; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()); var tmp12 any; var root_1954 any = A_arbace_go_repl_A_const_191.GetRawRoot__O(); var linked_1955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1954, aot_arbace_go_build.A_arbace_go_build_desc_A_fn_class); var ifn_1956 lang.IFn


			if linked_1955 == nil { ifn_1956 = lang.IFn_Cast(root_1954) } else { ifn_1956 = nil }; var arg_1957 any; var root_1958 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1958, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1960 lang.IFn; if linked_1959 == nil { ifn_1960 = lang.IFn_Cast(root_1958) } else { ifn_1960 = nil }; var arg_1961 any = x__4; var arg_1962 any = A_arbace_go_repl_A_const_142; if linked_1959 == nil { arg_1957 = ifn_1960.Invoke_O_O__O(arg_1961, arg_1962) } else { arg_1957 = linked_1959.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1958, arg_1961, arg_1962) }; if linked_1955 == nil { tmp12 = ifn_1956.Invoke_O__O(arg_1957) } else { tmp12 = linked_1955.(*aot_arbace_go_build.A_arbace_go_build_desc_A).Invoke_O_O__O(root_1954, arg_1957) }
//line :330:1
			var tmp13 any = tmp11.Invoke_O_O__O(Lit_121, tmp12); var tmp14 any = A_arbace_go_repl_A_const_182; var tmp15 any = A_arbace_go_repl_A_const_181; var tmp16 any = A_arbace_go_repl_A_const_142; var tmp17 any; var root_1963 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1963, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1965 lang.IFn


			if linked_1964 == nil { ifn_1965 = lang.IFn_Cast(root_1963) } else { ifn_1965 = nil }; var arg_1966 any = x__4; var arg_1967 any = A_arbace_go_repl_A_const_142; if linked_1964 == nil { tmp17 = ifn_1965.Invoke_O_O__O(arg_1966, arg_1967) } else { tmp17 = linked_1964.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1963, arg_1966, arg_1967) }
//line :330:1
			arg_1936 = lang.Tuple_Create_O_O__IPersistentVector(nm__5, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp13, tmp14, k__6, tmp15, x__4, tmp16, tmp17))) }
//line :326:1
	var arg_1937 any; var tmp18 lang.IFn = lang.IFn_Cast(t.F_iter__794000263); var tmp19 any; var root_1968 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_1969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1968, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1970 lang.IFn; if linked_1969 == nil { ifn_1970 = lang.IFn_Cast(root_1968) } else { ifn_1970 = nil }; var arg_1971 any = s__794000264__3; if linked_1969 == nil { tmp19 = ifn_1970.Invoke_O__O(arg_1971) } else { tmp19 = linked_1969.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1968, arg_1971) }; arg_1937 = tmp18.Invoke_O__O(tmp19); if linked_1934 == nil { return ifn_1935.Invoke_O_O__O(arg_1936, arg_1937) } else { return linked_1934.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1933, arg_1936, arg_1937) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :326:1
func A_arbace_go_repl_define_BANG__iter__794000263__794000267_fn__794000268_fn__794000269_A_New_O_O_O_I_O_O(p0, p1, p2 any, p3 int32, p4, p5 any) *A_arbace_go_repl_define_BANG__iter__794000263__794000267_fn__794000268_fn__794000269_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000263__794000267_fn__794000268_fn__794000269_A{}; t.Ctor_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :326:1
func (t *A_arbace_go_repl_define_BANG__iter__794000263__794000267_fn__794000268_fn__794000269_A) Ctor_O_O_O_I_O_O(c__b__794000266, c__new_vars, c__old any, c__size__1927001038__auto__ int32, c__ctx, c__c__1927001037__auto__ any) { t.F_b__794000266 = c__b__794000266; t.F_new_vars = c__new_vars; t.F_old = c__old; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_ctx = c__ctx; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :326:1
func (t *A_arbace_go_repl_define_BANG__iter__794000263__794000267_fn__794000268_fn__794000269_A) Invoke_O__O(self any) any { { var i__794000265__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__794000265__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var x__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__794000265__1)); var nm__3 any; var root_1831 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1831, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1833 lang.IFn
																if linked_1832 == nil { ifn_1833 = lang.IFn_Cast(root_1831) } else { ifn_1833 = nil }; var arg_1834 any = x__2; var arg_1835 any = A_arbace_go_repl_A_const_55; if linked_1832 == nil { nm__3 = ifn_1833.Invoke_O_O__O(arg_1834, arg_1835) } else { nm__3 = linked_1832.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1831, arg_1834, arg_1835) }
//line :326:1
	var k__4 any; var root_1836 any = A_arbace_go_repl_A_const_138.GetRawRoot__O(); var linked_1837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1836, A_arbace_go_repl_type_key_A_fn_class); var ifn_1838 lang.IFn

	if linked_1837 == nil { ifn_1838 = lang.IFn_Cast(root_1836) } else { ifn_1838 = nil }; var arg_1839 any; var root_1841 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1841, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1843 lang.IFn; if linked_1842 == nil { ifn_1843 = lang.IFn_Cast(root_1841) } else { ifn_1843 = nil }; var arg_1844 any = x__2; var arg_1845 any = A_arbace_go_repl_A_const_142; if linked_1842 == nil { arg_1839 = ifn_1843.Invoke_O_O__O(arg_1844, arg_1845) } else { arg_1839 = linked_1842.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1841, arg_1844, arg_1845) }; var arg_1840 any = A_arbace_go_repl_A_const_151.Invoke_O__O(t.F_ctx); if linked_1837 == nil { k__4 = ifn_1838.Invoke_O_O__O(arg_1839, arg_1840) } else { k__4 = linked_1837.(*A_arbace_go_repl_type_key_A).Invoke_O_O_O__O(root_1836, arg_1839, arg_1840) }
//line :326:1
	var prev__5 any; var root_1846 any = A_arbace_go_repl_A_const_153.GetRawRoot__O(); var linked_1847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1846, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1848 lang.IFn


	if linked_1847 == nil { ifn_1848 = lang.IFn_Cast(root_1846) } else { ifn_1848 = nil }; var arg_1849 any = t.F_old; var arg_1850 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_repl_A_const_60, nm__3); if linked_1847 == nil { prev__5 = ifn_1848.Invoke_O_O__O(arg_1849, arg_1850) } else { prev__5 = linked_1847.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1846, arg_1849, arg_1850) }
//line :326:1
	var root_1851 any = A_arbace_go_repl_A_const_96.GetRawRoot__O(); var linked_1852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1851, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1853 lang.IFn; if linked_1852 == nil { ifn_1853 = lang.IFn_Cast(root_1851) } else { ifn_1853 = nil }; var arg_1854 any = t.F_b__794000266; var arg_1855 any; var tmp2 any
	var and__1927000168__auto____6 any = prev__5


	if jrt.J2g_Truth(and__1927000168__auto____6) { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(k__4, A_arbace_go_repl_A_const_182.Invoke_O__O(prev__5))).Ref() } else { tmp2 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_1856 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var linked_1857 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1856, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1858 lang.IFn
		if linked_1857 == nil { ifn_1858 = lang.IFn_Cast(root_1856) } else { ifn_1858 = nil }; var arg_1859 any = prev__5; var arg_1860 any = A_arbace_go_repl_A_const_181; var arg_1861 any = x__2; if linked_1857 == nil { tmp3 = ifn_1858.Invoke_O_O_O__O(arg_1859, arg_1860, arg_1861) } else { tmp3 = linked_1857.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1856, arg_1859, arg_1860, arg_1861) }
//line :330:1
		arg_1855 = lang.Tuple_Create_O_O__IPersistentVector(nm__3, tmp3) } else {

			var tmp4 *lang.Volatile = lang.Volatile_Cast(t.F_new_vars); var tmp5 any; var root_1862 any = A_arbace_go_repl_A_const_15.GetRawRoot__O(); var linked_1863 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1862, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1864 lang.IFn; if linked_1863 == nil { ifn_1864 = lang.IFn_Cast(root_1862) } else { ifn_1864 = nil }; var arg_1865 any = jrt.NN(lang.Volatile_Cast(t.F_new_vars)).Deref__O(); var arg_1866 any = nm__3; if linked_1863 == nil { tmp5 = ifn_1864.Invoke_O_O__O(arg_1865, arg_1866) } else { tmp5 = linked_1863.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1862, arg_1865, arg_1866) }; jrt.NN(tmp4).Reset_O__O(tmp5)
//line :330:1
			var tmp6 any = A_arbace_go_repl_A_const_190; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()); var tmp8 any; var root_1872 any = A_arbace_go_repl_A_const_191.GetRawRoot__O(); var linked_1873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1872, aot_arbace_go_build.A_arbace_go_build_desc_A_fn_class); var ifn_1874 lang.IFn


			if linked_1873 == nil { ifn_1874 = lang.IFn_Cast(root_1872) } else { ifn_1874 = nil }; var arg_1875 any; var root_1876 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1876, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1878 lang.IFn; if linked_1877 == nil { ifn_1878 = lang.IFn_Cast(root_1876) } else { ifn_1878 = nil }; var arg_1879 any = x__2; var arg_1880 any = A_arbace_go_repl_A_const_142; if linked_1877 == nil { arg_1875 = ifn_1878.Invoke_O_O__O(arg_1879, arg_1880) } else { arg_1875 = linked_1877.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1876, arg_1879, arg_1880) }; if linked_1873 == nil { tmp8 = ifn_1874.Invoke_O__O(arg_1875) } else { tmp8 = linked_1873.(*aot_arbace_go_build.A_arbace_go_build_desc_A).Invoke_O_O__O(root_1872, arg_1875) }
//line :330:1
			var tmp9 any = tmp7.Invoke_O_O__O(Lit_121, tmp8); var tmp10 any = A_arbace_go_repl_A_const_182; var tmp11 any = A_arbace_go_repl_A_const_181; var tmp12 any = A_arbace_go_repl_A_const_142; var tmp13 any; var root_1881 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_1882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1881, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1883 lang.IFn


			if linked_1882 == nil { ifn_1883 = lang.IFn_Cast(root_1881) } else { ifn_1883 = nil }; var arg_1884 any = x__2; var arg_1885 any = A_arbace_go_repl_A_const_142; if linked_1882 == nil { tmp13 = ifn_1883.Invoke_O_O__O(arg_1884, arg_1885) } else { tmp13 = linked_1882.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1881, arg_1884, arg_1885) }
//line :330:1
			arg_1855 = lang.Tuple_Create_O_O__IPersistentVector(nm__3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp9, tmp10, k__4, tmp11, x__2, tmp12, tmp13))) }
//line :326:1
	if linked_1852 == nil { ifn_1853.Invoke_O_O__O(arg_1854, arg_1855) } else { linked_1852.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1851, arg_1854, arg_1855) }; i__794000265__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000265__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }













func A_arbace_go_repl_define_BANG__fn__794000282_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__fn__794000282_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000282_A{}; t.Ctor_O(p0); return t }
//line :340:1
func (t *A_arbace_go_repl_define_BANG__fn__794000282_A) Ctor_O(c__tree any) { t.F_tree = c__tree }
//line :340:1
func (t *A_arbace_go_repl_define_BANG__fn__794000282_A) Invoke_O__O(self any) any { var root_2629 any = A_arbace_go_repl_A_const_208.GetRawRoot__O(); var linked_2630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2629, aot_arbace_go_build.A_arbace_go_build_build_func_A_fn_class); var ifn_2631 lang.IFn; if linked_2630 == nil { ifn_2631 = lang.IFn_Cast(root_2629) } else { ifn_2631 = nil }; var arg_2632 any = t.F_tree; if linked_2630 == nil { return ifn_2631.Invoke_O__O(arg_2632) } else { return linked_2630.(*aot_arbace_go_build.A_arbace_go_build_build_func_A).Invoke_O_O__O(root_2629, arg_2632) } }
//line :340:1
func A_arbace_go_repl_define_BANG__fn__794000293_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__fn__794000293_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000293_A{}; t.Ctor_O(p0); return t }
//line :340:1
func (t *A_arbace_go_repl_define_BANG__fn__794000293_A) Ctor_O(c__tree any) { t.F_tree = c__tree }
//line :340:1
func (t *A_arbace_go_repl_define_BANG__fn__794000293_A) Invoke_O__O(self any) any { var root_2668 any = A_arbace_go_repl_A_const_208.GetRawRoot__O(); var linked_2669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2668, aot_arbace_go_build.A_arbace_go_build_build_func_A_fn_class); var ifn_2670 lang.IFn; if linked_2669 == nil { ifn_2670 = lang.IFn_Cast(root_2668) } else { ifn_2670 = nil }; var arg_2671 any = t.F_tree; if linked_2669 == nil { return ifn_2670.Invoke_O__O(arg_2671) } else { return linked_2669.(*aot_arbace_go_build.A_arbace_go_build_build_func_A).Invoke_O_O__O(root_2668, arg_2671) } }
func A_arbace_go_repl_define_BANG__fn__794000284_A_New_O_O(p0, p1 any) *A_arbace_go_repl_define_BANG__fn__794000284_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000284_A{}; t.Ctor_O_O(p0, p1); return t }
//line :341:1
func (t *A_arbace_go_repl_define_BANG__fn__794000284_A) Ctor_O_O(c__ctx, c__tree any) { t.F_ctx = c__ctx; t.F_tree = c__tree }
//line :341:1
func (t *A_arbace_go_repl_define_BANG__fn__794000284_A) Invoke_O__O(self any) any { var root_2641 any = A_arbace_go_repl_A_const_207.GetRawRoot__O(); var linked_2642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2641, aot_arbace_go_build.A_arbace_go_build_with_ctx_A_fn_class); var ifn_2643 lang.IFn; if linked_2642 == nil { ifn_2643 = lang.IFn_Cast(root_2641) } else { ifn_2643 = nil }; var arg_2644 any = t.F_ctx; var arg_2645 any; var tmp1 any = A_arbace_go_repl_define_BANG__fn__794000284_fn__794000285_A_New_O(t.F_tree); var tmp2 *jrt.Class; var fncls__2650 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000284_fn__794000285_A_fn_class; if fncls__2650 == nil { var fncls__2650d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_98, false); A_arbace_go_repl_define_BANG__fn__794000284_fn__794000285_A_fn_class = fncls__2650d; tmp2 = fncls__2650d } else { tmp2 = fncls__2650 }; arg_2645 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_2642 == nil { return ifn_2643.Invoke_O_O__O(arg_2644, arg_2645) } else { return linked_2642.(*aot_arbace_go_build.A_arbace_go_build_with_ctx_A).Invoke_O_O_O__O(root_2641, arg_2644, arg_2645) } }
//line :341:1
func A_arbace_go_repl_define_BANG__fn__794000284_fn__794000285_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__fn__794000284_fn__794000285_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000284_fn__794000285_A{}; t.Ctor_O(p0); return t }
//line :341:1
func (t *A_arbace_go_repl_define_BANG__fn__794000284_fn__794000285_A) Ctor_O(c__tree any) { t.F_tree = c__tree }
//line :341:1
func (t *A_arbace_go_repl_define_BANG__fn__794000284_fn__794000285_A) Invoke_O__O(self any) any { var root_2646 any = A_arbace_go_repl_A_const_208.GetRawRoot__O(); var linked_2647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2646, aot_arbace_go_build.A_arbace_go_build_build_func_A_fn_class); var ifn_2648 lang.IFn; if linked_2647 == nil { ifn_2648 = lang.IFn_Cast(root_2646) } else { ifn_2648 = nil }; var arg_2649 any = t.F_tree; if linked_2647 == nil { return ifn_2648.Invoke_O__O(arg_2649) } else { return linked_2647.(*aot_arbace_go_build.A_arbace_go_build_build_func_A).Invoke_O_O__O(root_2646, arg_2649) } }
//line :341:1
func A_arbace_go_repl_define_BANG__fn__794000295_A_New_O_O(p0, p1 any) *A_arbace_go_repl_define_BANG__fn__794000295_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000295_A{}; t.Ctor_O_O(p0, p1); return t }
//line :341:1
func (t *A_arbace_go_repl_define_BANG__fn__794000295_A) Ctor_O_O(c__tree, c__ctx any) { t.F_tree = c__tree; t.F_ctx = c__ctx }
//line :341:1
func (t *A_arbace_go_repl_define_BANG__fn__794000295_A) Invoke_O__O(self any) any { var root_2680 any = A_arbace_go_repl_A_const_207.GetRawRoot__O(); var linked_2681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2680, aot_arbace_go_build.A_arbace_go_build_with_ctx_A_fn_class); var ifn_2682 lang.IFn; if linked_2681 == nil { ifn_2682 = lang.IFn_Cast(root_2680) } else { ifn_2682 = nil }; var arg_2683 any = t.F_ctx; var arg_2684 any; var tmp1 any = A_arbace_go_repl_define_BANG__fn__794000295_fn__794000296_A_New_O(t.F_tree); var tmp2 *jrt.Class; var fncls__2689 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000295_fn__794000296_A_fn_class; if fncls__2689 == nil { var fncls__2689d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_99, false); A_arbace_go_repl_define_BANG__fn__794000295_fn__794000296_A_fn_class = fncls__2689d; tmp2 = fncls__2689d } else { tmp2 = fncls__2689 }; arg_2684 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_2681 == nil { return ifn_2682.Invoke_O_O__O(arg_2683, arg_2684) } else { return linked_2681.(*aot_arbace_go_build.A_arbace_go_build_with_ctx_A).Invoke_O_O_O__O(root_2680, arg_2683, arg_2684) } }
//line :341:1
func A_arbace_go_repl_define_BANG__fn__794000295_fn__794000296_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__fn__794000295_fn__794000296_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000295_fn__794000296_A{}; t.Ctor_O(p0); return t }
//line :341:1
func (t *A_arbace_go_repl_define_BANG__fn__794000295_fn__794000296_A) Ctor_O(c__tree any) { t.F_tree = c__tree }
//line :341:1
func (t *A_arbace_go_repl_define_BANG__fn__794000295_fn__794000296_A) Invoke_O__O(self any) any { var root_2685 any = A_arbace_go_repl_A_const_208.GetRawRoot__O(); var linked_2686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2685, aot_arbace_go_build.A_arbace_go_build_build_func_A_fn_class); var ifn_2687 lang.IFn; if linked_2686 == nil { ifn_2687 = lang.IFn_Cast(root_2685) } else { ifn_2687 = nil }; var arg_2688 any = t.F_tree; if linked_2686 == nil { return ifn_2687.Invoke_O__O(arg_2688) } else { return linked_2686.(*aot_arbace_go_build.A_arbace_go_build_build_func_A).Invoke_O_O__O(root_2685, arg_2688) } }




func A_arbace_go_repl_define_BANG__fn__794000308_A_New() *A_arbace_go_repl_define_BANG__fn__794000308_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000308_A{}; t.Ctor(); return t }
//line :346:1
func (t *A_arbace_go_repl_define_BANG__fn__794000308_A) Ctor() {}
//line :346:1
func (t *A_arbace_go_repl_define_BANG__fn__794000308_A) Invoke_O__O(self any) any { var root_2710 any = A_arbace_go_repl_A_const_209.GetRawRoot__O(); var linked_2711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2710, aot_arbace_go_build.A_arbace_go_build_unsupported_BANG__A_fn_class); var ifn_2712 lang.IFn; if linked_2711 == nil { ifn_2712 = lang.IFn_Cast(root_2710) } else { ifn_2712 = nil }; var arg_2713 any = Lit_100; var arg_2714 any = Lit_101; if linked_2711 == nil { return ifn_2712.Invoke_O_O__O(arg_2713, arg_2714) } else { return linked_2711.(*aot_arbace_go_build.A_arbace_go_build_unsupported_BANG__A).Invoke_O_O_O__O(root_2710, arg_2713, arg_2714) } }
//line :346:1
func A_arbace_go_repl_define_BANG__fn__794000321_A_New() *A_arbace_go_repl_define_BANG__fn__794000321_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000321_A{}; t.Ctor(); return t }
//line :346:1
func (t *A_arbace_go_repl_define_BANG__fn__794000321_A) Ctor() {}
//line :346:1
func (t *A_arbace_go_repl_define_BANG__fn__794000321_A) Invoke_O__O(self any) any { var root_2762 any = A_arbace_go_repl_A_const_209.GetRawRoot__O(); var linked_2763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2762, aot_arbace_go_build.A_arbace_go_build_unsupported_BANG__A_fn_class); var ifn_2764 lang.IFn; if linked_2763 == nil { ifn_2764 = lang.IFn_Cast(root_2762) } else { ifn_2764 = nil }; var arg_2765 any = Lit_100; var arg_2766 any = Lit_101; if linked_2763 == nil { return ifn_2764.Invoke_O_O__O(arg_2765, arg_2766) } else { return linked_2763.(*aot_arbace_go_build.A_arbace_go_build_unsupported_BANG__A).Invoke_O_O_O__O(root_2762, arg_2765, arg_2766) } }
func A_arbace_go_repl_define_BANG__fn__794000310_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__fn__794000310_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000310_A{}; t.Ctor_O(p0); return t }
//line :347:1
func (t *A_arbace_go_repl_define_BANG__fn__794000310_A) Ctor_O(c__tree any) { t.F_tree = c__tree }
//line :347:1
func (t *A_arbace_go_repl_define_BANG__fn__794000310_A) Invoke_O__O(self any) any { var root_2728 any = A_arbace_go_repl_A_const_208.GetRawRoot__O(); var linked_2729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2728, aot_arbace_go_build.A_arbace_go_build_build_func_A_fn_class); var ifn_2730 lang.IFn; if linked_2729 == nil { ifn_2730 = lang.IFn_Cast(root_2728) } else { ifn_2730 = nil }; var arg_2731 any = t.F_tree; if linked_2729 == nil { return ifn_2730.Invoke_O__O(arg_2731) } else { return linked_2729.(*aot_arbace_go_build.A_arbace_go_build_build_func_A).Invoke_O_O__O(root_2728, arg_2731) } }
//line :347:1
func A_arbace_go_repl_define_BANG__fn__794000323_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__fn__794000323_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000323_A{}; t.Ctor_O(p0); return t }
//line :347:1
func (t *A_arbace_go_repl_define_BANG__fn__794000323_A) Ctor_O(c__tree any) { t.F_tree = c__tree }
//line :347:1
func (t *A_arbace_go_repl_define_BANG__fn__794000323_A) Invoke_O__O(self any) any { var root_2780 any = A_arbace_go_repl_A_const_208.GetRawRoot__O(); var linked_2781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2780, aot_arbace_go_build.A_arbace_go_build_build_func_A_fn_class); var ifn_2782 lang.IFn; if linked_2781 == nil { ifn_2782 = lang.IFn_Cast(root_2780) } else { ifn_2782 = nil }; var arg_2783 any = t.F_tree; if linked_2781 == nil { return ifn_2782.Invoke_O__O(arg_2783) } else { return linked_2781.(*aot_arbace_go_build.A_arbace_go_build_build_func_A).Invoke_O_O__O(root_2780, arg_2783) } }
func A_arbace_go_repl_define_BANG__fn__794000312_A_New_O_O(p0, p1 any) *A_arbace_go_repl_define_BANG__fn__794000312_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000312_A{}; t.Ctor_O_O(p0, p1); return t }
//line :348:1
func (t *A_arbace_go_repl_define_BANG__fn__794000312_A) Ctor_O_O(c__ctx, c__tree any) { t.F_ctx = c__ctx; t.F_tree = c__tree }
//line :348:1
func (t *A_arbace_go_repl_define_BANG__fn__794000312_A) Invoke_O__O(self any) any { var root_2740 any = A_arbace_go_repl_A_const_207.GetRawRoot__O(); var linked_2741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2740, aot_arbace_go_build.A_arbace_go_build_with_ctx_A_fn_class); var ifn_2742 lang.IFn; if linked_2741 == nil { ifn_2742 = lang.IFn_Cast(root_2740) } else { ifn_2742 = nil }; var arg_2743 any = t.F_ctx; var arg_2744 any; var tmp1 any = A_arbace_go_repl_define_BANG__fn__794000312_fn__794000313_A_New_O(t.F_tree); var tmp2 *jrt.Class; var fncls__2749 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000312_fn__794000313_A_fn_class; if fncls__2749 == nil { var fncls__2749d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_102, false); A_arbace_go_repl_define_BANG__fn__794000312_fn__794000313_A_fn_class = fncls__2749d; tmp2 = fncls__2749d } else { tmp2 = fncls__2749 }; arg_2744 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_2741 == nil { return ifn_2742.Invoke_O_O__O(arg_2743, arg_2744) } else { return linked_2741.(*aot_arbace_go_build.A_arbace_go_build_with_ctx_A).Invoke_O_O_O__O(root_2740, arg_2743, arg_2744) } }
//line :348:1
func A_arbace_go_repl_define_BANG__fn__794000312_fn__794000313_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__fn__794000312_fn__794000313_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000312_fn__794000313_A{}; t.Ctor_O(p0); return t }
//line :348:1
func (t *A_arbace_go_repl_define_BANG__fn__794000312_fn__794000313_A) Ctor_O(c__tree any) { t.F_tree = c__tree }
//line :348:1
func (t *A_arbace_go_repl_define_BANG__fn__794000312_fn__794000313_A) Invoke_O__O(self any) any { var root_2745 any = A_arbace_go_repl_A_const_208.GetRawRoot__O(); var linked_2746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2745, aot_arbace_go_build.A_arbace_go_build_build_func_A_fn_class); var ifn_2747 lang.IFn; if linked_2746 == nil { ifn_2747 = lang.IFn_Cast(root_2745) } else { ifn_2747 = nil }; var arg_2748 any = t.F_tree; if linked_2746 == nil { return ifn_2747.Invoke_O__O(arg_2748) } else { return linked_2746.(*aot_arbace_go_build.A_arbace_go_build_build_func_A).Invoke_O_O__O(root_2745, arg_2748) } }
//line :348:1
func A_arbace_go_repl_define_BANG__fn__794000325_A_New_O_O(p0, p1 any) *A_arbace_go_repl_define_BANG__fn__794000325_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000325_A{}; t.Ctor_O_O(p0, p1); return t }
//line :348:1
func (t *A_arbace_go_repl_define_BANG__fn__794000325_A) Ctor_O_O(c__tree, c__ctx any) { t.F_tree = c__tree; t.F_ctx = c__ctx }
//line :348:1
func (t *A_arbace_go_repl_define_BANG__fn__794000325_A) Invoke_O__O(self any) any { var root_2792 any = A_arbace_go_repl_A_const_207.GetRawRoot__O(); var linked_2793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2792, aot_arbace_go_build.A_arbace_go_build_with_ctx_A_fn_class); var ifn_2794 lang.IFn; if linked_2793 == nil { ifn_2794 = lang.IFn_Cast(root_2792) } else { ifn_2794 = nil }; var arg_2795 any = t.F_ctx; var arg_2796 any; var tmp1 any = A_arbace_go_repl_define_BANG__fn__794000325_fn__794000326_A_New_O(t.F_tree); var tmp2 *jrt.Class; var fncls__2801 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000325_fn__794000326_A_fn_class; if fncls__2801 == nil { var fncls__2801d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_103, false); A_arbace_go_repl_define_BANG__fn__794000325_fn__794000326_A_fn_class = fncls__2801d; tmp2 = fncls__2801d } else { tmp2 = fncls__2801 }; arg_2796 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_2793 == nil { return ifn_2794.Invoke_O_O__O(arg_2795, arg_2796) } else { return linked_2793.(*aot_arbace_go_build.A_arbace_go_build_with_ctx_A).Invoke_O_O_O__O(root_2792, arg_2795, arg_2796) } }
//line :348:1
func A_arbace_go_repl_define_BANG__fn__794000325_fn__794000326_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__fn__794000325_fn__794000326_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000325_fn__794000326_A{}; t.Ctor_O(p0); return t }
//line :348:1
func (t *A_arbace_go_repl_define_BANG__fn__794000325_fn__794000326_A) Ctor_O(c__tree any) { t.F_tree = c__tree }
//line :348:1
func (t *A_arbace_go_repl_define_BANG__fn__794000325_fn__794000326_A) Invoke_O__O(self any) any { var root_2797 any = A_arbace_go_repl_A_const_208.GetRawRoot__O(); var linked_2798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2797, aot_arbace_go_build.A_arbace_go_build_build_func_A_fn_class); var ifn_2799 lang.IFn; if linked_2798 == nil { ifn_2799 = lang.IFn_Cast(root_2797) } else { ifn_2799 = nil }; var arg_2800 any = t.F_tree; if linked_2798 == nil { return ifn_2799.Invoke_O__O(arg_2800) } else { return linked_2798.(*aot_arbace_go_build.A_arbace_go_build_build_func_A).Invoke_O_O__O(root_2797, arg_2800) } }

func A_arbace_go_repl_define_BANG__fn__794000335_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__fn__794000335_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000335_A{}; t.Ctor_O(p0); return t }
//line :350:1
func (t *A_arbace_go_repl_define_BANG__fn__794000335_A) Ctor_O(c__tree any) { t.F_tree = c__tree }
//line :350:1
func (t *A_arbace_go_repl_define_BANG__fn__794000335_A) Invoke_O__O(self any) any { var root_2823 any = A_arbace_go_repl_A_const_208.GetRawRoot__O(); var linked_2824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2823, aot_arbace_go_build.A_arbace_go_build_build_func_A_fn_class); var ifn_2825 lang.IFn; if linked_2824 == nil { ifn_2825 = lang.IFn_Cast(root_2823) } else { ifn_2825 = nil }; var arg_2826 any = t.F_tree; if linked_2824 == nil { return ifn_2825.Invoke_O__O(arg_2826) } else { return linked_2824.(*aot_arbace_go_build.A_arbace_go_build_build_func_A).Invoke_O_O__O(root_2823, arg_2826) } }
//line :350:1
func A_arbace_go_repl_define_BANG__fn__794000339_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__fn__794000339_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000339_A{}; t.Ctor_O(p0); return t }
//line :350:1
func (t *A_arbace_go_repl_define_BANG__fn__794000339_A) Ctor_O(c__tree any) { t.F_tree = c__tree }
//line :350:1
func (t *A_arbace_go_repl_define_BANG__fn__794000339_A) Invoke_O__O(self any) any { var root_2844 any = A_arbace_go_repl_A_const_208.GetRawRoot__O(); var linked_2845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2844, aot_arbace_go_build.A_arbace_go_build_build_func_A_fn_class); var ifn_2846 lang.IFn; if linked_2845 == nil { ifn_2846 = lang.IFn_Cast(root_2844) } else { ifn_2846 = nil }; var arg_2847 any = t.F_tree; if linked_2845 == nil { return ifn_2846.Invoke_O__O(arg_2847) } else { return linked_2845.(*aot_arbace_go_build.A_arbace_go_build_build_func_A).Invoke_O_O__O(root_2844, arg_2847) } }

func A_arbace_go_repl_define_BANG__iter__794000341__794000345_A_New() *A_arbace_go_repl_define_BANG__iter__794000341__794000345_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000341__794000345_A{}; t.Ctor(); return t }
//line :352:1
func (t *A_arbace_go_repl_define_BANG__iter__794000341__794000345_A) Ctor() {}
//line :352:1
func (t *A_arbace_go_repl_define_BANG__iter__794000341__794000345_A) Invoke_O_O__O(self, s__794000342__1 any) any { var tmp1 any = A_arbace_go_repl_define_BANG__iter__794000341__794000345_fn__794000346_A_New_O_O(self, s__794000342__1); var tmp2 *jrt.Class; var fncls__2056 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000341__794000345_fn__794000346_A_fn_class; if fncls__2056 == nil { var fncls__2056d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_122, false); A_arbace_go_repl_define_BANG__iter__794000341__794000345_fn__794000346_A_fn_class = fncls__2056d; tmp2 = fncls__2056d } else { tmp2 = fncls__2056 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :352:1
func A_arbace_go_repl_define_BANG__iter__794000341__794000345_fn__794000346_A_New_O_O(p0, p1 any) *A_arbace_go_repl_define_BANG__iter__794000341__794000345_fn__794000346_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000341__794000345_fn__794000346_A{}; t.Ctor_O_O(p0, p1); return t }
//line :352:1
func (t *A_arbace_go_repl_define_BANG__iter__794000341__794000345_fn__794000346_A) Ctor_O_O(c__iter__794000341, c__s__794000342 any) { t.F_iter__794000341 = c__iter__794000341; t.F_s__794000342 = c__s__794000342 }
//line :352:1
func (t *A_arbace_go_repl_define_BANG__iter__794000341__794000345_fn__794000346_A) Invoke_O__O(self any) any { { var s__794000342__1 any; var t_ any = t.F_s__794000342; t.F_s__794000342 = nil; s__794000342__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1983 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_1984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1983, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1985 lang.IFn; if linked_1984 == nil { ifn_1985 = lang.IFn_Cast(root_1983) } else { ifn_1985 = nil }; var arg_1986 any = s__794000342__1; if linked_1984 == nil { temp__1927000414__auto____2 = ifn_1985.Invoke_O__O(arg_1986) } else { temp__1927000414__auto____2 = linked_1984.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1983, arg_1986) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__794000342__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1987 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_1988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1987, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1989 lang.IFn; if linked_1988 == nil { ifn_1989 = lang.IFn_Cast(root_1987) } else { ifn_1989 = nil }; var arg_1990 any = s__794000342__3; if linked_1988 == nil { tmp1 = ifn_1989.Invoke_O__O(arg_1990) } else { tmp1 = linked_1988.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1987, arg_1990) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1991 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_1992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1991, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1993 lang.IFn; if linked_1992 == nil { ifn_1993 = lang.IFn_Cast(root_1991) } else { ifn_1993 = nil }; var arg_1994 any = s__794000342__3; if linked_1992 == nil { c__1927001037__auto____4 = ifn_1993.Invoke_O__O(arg_1994) } else { c__1927001037__auto____4 = linked_1992.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1991, arg_1994) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__794000344__6 any; var root_1995 any = A_arbace_go_repl_A_const_95.GetRawRoot__O(); var linked_1996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1995, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1997 lang.IFn; if linked_1996 == nil { ifn_1997 = lang.IFn_Cast(root_1995) } else { ifn_1997 = nil }; var arg_1998 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1996 == nil { b__794000344__6 = ifn_1997.Invoke_O__O(arg_1998) } else { b__794000344__6 = linked_1996.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1995, arg_1998) }; var tmp2 any = A_arbace_go_repl_define_BANG__iter__794000341__794000345_fn__794000346_fn__794000347_A_New_O_I_O(b__794000344__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2008 *jrt.Class = A_arbace_go_repl_define_BANG__iter__794000341__794000345_fn__794000346_fn__794000347_A_fn_class; if fncls__2008 == nil { var fncls__2008d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_123, false); A_arbace_go_repl_define_BANG__iter__794000341__794000345_fn__794000346_fn__794000347_A_fn_class = fncls__2008d; tmp3 = fncls__2008d } else { tmp3 = fncls__2008 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2009 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_2010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2009, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2011 lang.IFn; if linked_2010 == nil { ifn_2011 = lang.IFn_Cast(root_2009) } else { ifn_2011 = nil }; var arg_2012 any; var root_2014 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_2015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2014, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2016 lang.IFn; if linked_2015 == nil { ifn_2016 = lang.IFn_Cast(root_2014) } else { ifn_2016 = nil }; var arg_2017 any = b__794000344__6; if linked_2015 == nil { arg_2012 = ifn_2016.Invoke_O__O(arg_2017) } else { arg_2012 = linked_2015.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2014, arg_2017) }; var arg_2013 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__794000341); var tmp5 any; var root_2018 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_2019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2018, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2020 lang.IFn; if linked_2019 == nil { ifn_2020 = lang.IFn_Cast(root_2018) } else { ifn_2020 = nil }; var arg_2021 any = s__794000342__3; if linked_2019 == nil { tmp5 = ifn_2020.Invoke_O__O(arg_2021) } else { tmp5 = linked_2019.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2018, arg_2021) }; arg_2013 = tmp4.Invoke_O__O(tmp5); if linked_2010 == nil { return ifn_2011.Invoke_O_O__O(arg_2012, arg_2013) } else { return linked_2010.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2009, arg_2012, arg_2013) } } else { var root_2022 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_2023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2022, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2024 lang.IFn; if linked_2023 == nil { ifn_2024 = lang.IFn_Cast(root_2022) } else { ifn_2024 = nil }; var arg_2025 any; var root_2027 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_2028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2027, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2029 lang.IFn; if linked_2028 == nil { ifn_2029 = lang.IFn_Cast(root_2027) } else { ifn_2029 = nil }; var arg_2030 any = b__794000344__6; if linked_2028 == nil { arg_2025 = ifn_2029.Invoke_O__O(arg_2030) } else { arg_2025 = linked_2028.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2027, arg_2030) }; var arg_2026 any; if linked_2023 == nil { return ifn_2024.Invoke_O_O__O(arg_2025, arg_2026) } else { return linked_2023.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2022, arg_2025, arg_2026) } } } else { var d__4 any; var root_2031 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2031, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2033 lang.IFn; if linked_2032 == nil { ifn_2033 = lang.IFn_Cast(root_2031) } else { ifn_2033 = nil }; var arg_2034 any = s__794000342__3; if linked_2032 == nil { d__4 = ifn_2033.Invoke_O__O(arg_2034) } else { d__4 = linked_2032.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2031, arg_2034) }; var tmp6 any = A_arbace_go_repl_A_const_187; if lang.Util_Equiv_O_O__Z_NoInit(tmp6, A_arbace_go_repl_A_const_178.Invoke_O__O(d__4)) { var tmp7 any = A_arbace_go_repl_A_const_192; var tmp8 *lang.Keyword = A_arbace_go_repl_A_const_193; if lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8.Invoke_O__O(A_arbace_go_repl_A_const_185.Invoke_O__O(d__4))) { var root_2035 any = A_arbace_go_repl_A_const_100.GetRawRoot__O(); var linked_2036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2035, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2037 lang.IFn; if linked_2036 == nil { ifn_2037 = lang.IFn_Cast(root_2035) } else { ifn_2037 = nil }; var arg_2038 any; var tmp9 any; var root_2040 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2040, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2042 lang.IFn
														if linked_2041 == nil { ifn_2042 = lang.IFn_Cast(root_2040) } else { ifn_2042 = nil }; var tmp10 *lang.Keyword = A_arbace_go_repl_A_const_188; var arg_2043 any = tmp10.Invoke_O__O(A_arbace_go_repl_A_const_185.Invoke_O__O(d__4)); if linked_2041 == nil { tmp9 = ifn_2042.Invoke_O__O(arg_2043) } else { tmp9 = linked_2041.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2040, arg_2043) }
//line :352:1
	arg_2038 = lang.Tuple_Create_O_O__IPersistentVector(tmp9, A_arbace_go_repl_A_const_185.Invoke_O__O(d__4)); var arg_2039 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__794000341); var tmp12 any; var root_2044 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_2045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2044, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2046 lang.IFn; if linked_2045 == nil { ifn_2046 = lang.IFn_Cast(root_2044) } else { ifn_2046 = nil }; var arg_2047 any = s__794000342__3; if linked_2045 == nil { tmp12 = ifn_2046.Invoke_O__O(arg_2047) } else { tmp12 = linked_2045.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2044, arg_2047) }; arg_2039 = tmp11.Invoke_O__O(tmp12); if linked_2036 == nil { return ifn_2037.Invoke_O_O__O(arg_2038, arg_2039) } else { return linked_2036.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2035, arg_2038, arg_2039) } } else { var tmp13 any; var root_2048 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_2049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2048, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2050 lang.IFn; if linked_2049 == nil { ifn_2050 = lang.IFn_Cast(root_2048) } else { ifn_2050 = nil }; var arg_2051 any = s__794000342__3; if linked_2049 == nil { tmp13 = ifn_2050.Invoke_O__O(arg_2051) } else { tmp13 = linked_2049.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2048, arg_2051) }; s__794000342__1 = tmp13; continue L1 } } else { var tmp14 any; var root_2052 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_2053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2052, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2054 lang.IFn; if linked_2053 == nil { ifn_2054 = lang.IFn_Cast(root_2052) } else { ifn_2054 = nil }; var arg_2055 any = s__794000342__3; if linked_2053 == nil { tmp14 = ifn_2054.Invoke_O__O(arg_2055) } else { tmp14 = linked_2053.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2052, arg_2055) }; s__794000342__1 = tmp14; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :352:1
func A_arbace_go_repl_define_BANG__iter__794000341__794000345_fn__794000346_fn__794000347_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_repl_define_BANG__iter__794000341__794000345_fn__794000346_fn__794000347_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__iter__794000341__794000345_fn__794000346_fn__794000347_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :352:1
func (t *A_arbace_go_repl_define_BANG__iter__794000341__794000345_fn__794000346_fn__794000347_A) Ctor_O_I_O(c__b__794000344 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__794000344 = c__b__794000344; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :352:1
func (t *A_arbace_go_repl_define_BANG__iter__794000341__794000345_fn__794000346_fn__794000347_A) Invoke_O__O(self any) any { { var i__794000343__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__794000343__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var d__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__794000343__1)); var tmp2 any = A_arbace_go_repl_A_const_187; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_go_repl_A_const_178.Invoke_O__O(d__2)) { var tmp3 any = A_arbace_go_repl_A_const_192; var tmp4 *lang.Keyword = A_arbace_go_repl_A_const_193; if lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4.Invoke_O__O(A_arbace_go_repl_A_const_185.Invoke_O__O(d__2))) { var root_1999 any = A_arbace_go_repl_A_const_96.GetRawRoot__O(); var linked_2000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1999, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2001 lang.IFn; if linked_2000 == nil { ifn_2001 = lang.IFn_Cast(root_1999) } else { ifn_2001 = nil }; var arg_2002 any = t.F_b__794000344; var arg_2003 any; var tmp5 any; var root_2004 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2004, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2006 lang.IFn
																if linked_2005 == nil { ifn_2006 = lang.IFn_Cast(root_2004) } else { ifn_2006 = nil }; var tmp6 *lang.Keyword = A_arbace_go_repl_A_const_188; var arg_2007 any = tmp6.Invoke_O__O(A_arbace_go_repl_A_const_185.Invoke_O__O(d__2)); if linked_2005 == nil { tmp5 = ifn_2006.Invoke_O__O(arg_2007) } else { tmp5 = linked_2005.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2004, arg_2007) }
//line :352:1
	arg_2003 = lang.Tuple_Create_O_O__IPersistentVector(tmp5, A_arbace_go_repl_A_const_185.Invoke_O__O(d__2)); if linked_2000 == nil { ifn_2001.Invoke_O_O__O(arg_2002, arg_2003) } else { linked_2000.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1999, arg_2002, arg_2003) }; i__794000343__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000343__1); continue L1 } else { i__794000343__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000343__1); continue L1 } } else { i__794000343__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000343__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_repl_define_BANG__fn__794000351_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__fn__794000351_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000351_A{}; t.Ctor_O(p0); return t }
//line :354:1
func (t *A_arbace_go_repl_define_BANG__fn__794000351_A) Ctor_O(c__var_trees any) { t.F_var_trees = c__var_trees }
//line :354:1
func (t *A_arbace_go_repl_define_BANG__fn__794000351_A) Invoke_O_O__O(self, p1__794000187_SHARP___1 any) any { var tmp1 any = t.F_var_trees; var tmp2 any; var root_2063 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_2064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2063, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2065 lang.IFn; if linked_2064 == nil { ifn_2065 = lang.IFn_Cast(root_2063) } else { ifn_2065 = nil }; var arg_2066 any = p1__794000187_SHARP___1; if linked_2064 == nil { tmp2 = ifn_2065.Invoke_O__O(arg_2066) } else { tmp2 = linked_2064.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2063, arg_2066) }; return lang.RT_Get_O_O__O_NoInit(tmp1, tmp2) }


func A_arbace_go_repl_define_BANG__fn__794000353_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__fn__794000353_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000353_A{}; t.Ctor_O(p0); return t }
//line :357:1
func (t *A_arbace_go_repl_define_BANG__fn__794000353_A) Ctor_O(c__names any) { t.F_names = c__names }
//line :357:1
func (t *A_arbace_go_repl_define_BANG__fn__794000353_A) Invoke_O_O__O(self, p1__794000188_SHARP___1 any) any { var root_2080 any = A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_2081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2080, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2082 lang.IFn; if linked_2081 == nil { ifn_2082 = lang.IFn_Cast(root_2080) } else { ifn_2082 = nil }; var arg_2083 any; var tmp1 any = A_arbace_go_repl_define_BANG__fn__794000353_fn__794000354_A_New_O(t.F_names); var tmp2 *jrt.Class; var fncls__2095 *jrt.Class = A_arbace_go_repl_define_BANG__fn__794000353_fn__794000354_A_fn_class; if fncls__2095 == nil { var fncls__2095d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_104, false); A_arbace_go_repl_define_BANG__fn__794000353_fn__794000354_A_fn_class = fncls__2095d; tmp2 = fncls__2095d } else { tmp2 = fncls__2095 }; arg_2083 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_2084 any = A_arbace_go_repl_A_const_188.Invoke_O__O(p1__794000188_SHARP___1); if linked_2081 == nil { return ifn_2082.Invoke_O_O__O(arg_2083, arg_2084) } else { return linked_2081.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2080, arg_2083, arg_2084) } }
//line :357:1
func A_arbace_go_repl_define_BANG__fn__794000353_fn__794000354_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__fn__794000353_fn__794000354_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000353_fn__794000354_A{}; t.Ctor_O(p0); return t }
//line :357:1
func (t *A_arbace_go_repl_define_BANG__fn__794000353_fn__794000354_A) Ctor_O(c__names any) { t.F_names = c__names }
//line :357:1
func (t *A_arbace_go_repl_define_BANG__fn__794000353_fn__794000354_A) Invoke_O_O__O(self, x__1 any) any { var root_2085 any = A_arbace_go_repl_A_const_18.GetRawRoot__O(); var linked_2086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2085, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2087 lang.IFn; if linked_2086 == nil { ifn_2087 = lang.IFn_Cast(root_2085) } else { ifn_2087 = nil }; var arg_2088 any = t.F_names; var arg_2089 any; var root_2090 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_2091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2090, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2092 lang.IFn; if linked_2091 == nil { ifn_2092 = lang.IFn_Cast(root_2090) } else { ifn_2092 = nil }; var arg_2093 any = x__1; var arg_2094 any = A_arbace_go_repl_A_const_55; if linked_2091 == nil { arg_2089 = ifn_2092.Invoke_O_O__O(arg_2093, arg_2094) } else { arg_2089 = linked_2091.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2090, arg_2093, arg_2094) }; if linked_2086 == nil { return ifn_2087.Invoke_O_O__O(arg_2088, arg_2089) } else { return linked_2086.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2085, arg_2088, arg_2089) } }






func A_arbace_go_repl_define_BANG__fn__794000366_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__fn__794000366_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000366_A{}; t.Ctor_O(p0); return t }
//line :364:1
func (t *A_arbace_go_repl_define_BANG__fn__794000366_A) Ctor_O(c__obj any) { t.F_obj = c__obj }
//line :364:1
func (t *A_arbace_go_repl_define_BANG__fn__794000366_A) Invoke_O_O__O(self, p1__794000189_SHARP___1 any) any { if lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_repl_A_const_181.Invoke_O__O(p1__794000189_SHARP___1), t.F_obj) { return A_arbace_go_repl_A_const_216.Invoke_O__O(p1__794000189_SHARP___1) } else { return nil } }
//line :364:1
func A_arbace_go_repl_define_BANG__fn__794000374_A_New_O(p0 any) *A_arbace_go_repl_define_BANG__fn__794000374_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000374_A{}; t.Ctor_O(p0); return t }
//line :364:1
func (t *A_arbace_go_repl_define_BANG__fn__794000374_A) Ctor_O(c__obj any) { t.F_obj = c__obj }
//line :364:1
func (t *A_arbace_go_repl_define_BANG__fn__794000374_A) Invoke_O_O__O(self, p1__794000189_SHARP___1 any) any { if lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_repl_A_const_181.Invoke_O__O(p1__794000189_SHARP___1), t.F_obj) { return A_arbace_go_repl_A_const_216.Invoke_O__O(p1__794000189_SHARP___1) } else { return nil } }

















func A_arbace_go_repl_define_BANG__fn__794000399_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_repl_define_BANG__fn__794000399_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000399_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :382:1
func (t *A_arbace_go_repl_define_BANG__fn__794000399_A) Ctor_O_O_O(c__ns, c__x, c__old any) { t.F_ns = c__ns; t.F_x = c__x; t.F_old = c__old }
//line :382:1
func (t *A_arbace_go_repl_define_BANG__fn__794000399_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_3421 any = A_arbace_go_repl_A_const_217.GetRawRoot__O(); var linked_3422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3421, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_3423 lang.IFn; if linked_3422 == nil { ifn_3423 = lang.IFn_Cast(root_3421) } else { ifn_3423 = nil }; var arg_3424 any; var t_ any = t.F_ns; t.F_ns = nil; arg_3424 = t_; var arg_3425 any; var root_3427 any = A_arbace_go_repl_A_const_218.GetRawRoot__O(); var linked_3428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3427, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3429 lang.IFn; if linked_3428 == nil { ifn_3429 = lang.IFn_Cast(root_3427) } else { ifn_3429 = nil }; var arg_3430 any; var root_3432 any = A_arbace_go_repl_A_const_46.GetRawRoot__O(); var linked_3433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3432, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3434 lang.IFn; if linked_3433 == nil { ifn_3434 = lang.IFn_Cast(root_3432) } else { ifn_3434 = nil }; var arg_3435 any; var root_3436 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3436, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3438 lang.IFn; if linked_3437 == nil { ifn_3438 = lang.IFn_Cast(root_3436) } else { ifn_3438 = nil }; var arg_3439 any = t.F_x; var arg_3440 any = A_arbace_go_repl_A_const_55; if linked_3437 == nil { arg_3435 = ifn_3438.Invoke_O_O__O(arg_3439, arg_3440) } else { arg_3435 = linked_3437.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3436, arg_3439, arg_3440) }; if linked_3433 == nil { arg_3430 = ifn_3434.Invoke_O__O(arg_3435) } else { arg_3430 = linked_3433.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3432, arg_3435) }; var arg_3431 any; var tmp2 any = A_arbace_go_repl_A_const_219; var tmp3 any = A_arbace_go_repl_A_const_142; var tmp4 any = A_arbace_go_repl_A_const_220; var tmp5 *lang.Keyword = A_arbace_go_repl_A_const_54; var tmp6 any; var t__2 any = t.F_old; t.F_old = nil; tmp6 = t__2; var tmp7 any = tmp5.Invoke_O__O(tmp6); var tmp8 any = A_arbace_go_repl_A_const_221; var tmp9 any; var root_3441 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_3442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3441, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3443 lang.IFn
												if linked_3442 == nil { ifn_3443 = lang.IFn_Cast(root_3441) } else { ifn_3443 = nil }; var arg_3444 any; var root_3445 any = A_arbace_go_repl_A_const_222.GetRawRoot__O(); var linked_3446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3445, aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A_fn_class); var ifn_3447 lang.IFn; if linked_3446 == nil { ifn_3447 = lang.IFn_Cast(root_3445) } else { ifn_3447 = nil }; var arg_3448 any; var root_3449 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3449, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3451 lang.IFn; if linked_3450 == nil { ifn_3451 = lang.IFn_Cast(root_3449) } else { ifn_3451 = nil }; var arg_3452 any = t.F_x; var arg_3453 any = A_arbace_go_repl_A_const_55; if linked_3450 == nil { arg_3448 = ifn_3451.Invoke_O_O__O(arg_3452, arg_3453) } else { arg_3448 = linked_3450.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3449, arg_3452, arg_3453) }; if linked_3446 == nil { arg_3444 = ifn_3447.Invoke_O__O(arg_3448) } else { arg_3444 = linked_3446.(*aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A).Invoke_O_O__O(root_3445, arg_3448) }; if linked_3442 == nil { tmp9 = ifn_3443.Invoke_O__O(arg_3444) } else { tmp9 = linked_3442.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3441, arg_3444) }
//line :383:1
		arg_3431 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp7, tmp8, tmp9)); if linked_3428 == nil { arg_3425 = ifn_3429.Invoke_O_O__O(arg_3430, arg_3431) } else { arg_3425 = linked_3428.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3427, arg_3430, arg_3431) }; var arg_3426 any; var tmp10 any; var root_3454 any = A_arbace_go_repl_A_const_191.GetRawRoot__O(); var linked_3455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3454, aot_arbace_go_build.A_arbace_go_build_desc_A_fn_class); var ifn_3456 lang.IFn

		if linked_3455 == nil { ifn_3456 = lang.IFn_Cast(root_3454) } else { ifn_3456 = nil }; var arg_3457 any; var root_3458 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3458, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3460 lang.IFn; if linked_3459 == nil { ifn_3460 = lang.IFn_Cast(root_3458) } else { ifn_3460 = nil }; var arg_3461 any; var t__3 any = t.F_x; t.F_x = nil; arg_3461 = t__3; var arg_3462 any = A_arbace_go_repl_A_const_142; if linked_3459 == nil { arg_3457 = ifn_3460.Invoke_O_O__O(arg_3461, arg_3462) } else { arg_3457 = linked_3459.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3458, arg_3461, arg_3462) }; if linked_3455 == nil { tmp10 = ifn_3456.Invoke_O__O(arg_3457) } else { tmp10 = linked_3455.(*aot_arbace_go_build.A_arbace_go_build_desc_A).Invoke_O_O__O(root_3454, arg_3457) }
//line :383:1
		arg_3426 = lang.GoType_New_O(tmp10); if linked_3422 == nil { tmp1 = ifn_3423.Invoke_O_O_O__O(arg_3424, arg_3425, arg_3426) } else { tmp1 = linked_3422.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O_O__O(root_3421, arg_3424, arg_3425, arg_3426) } }
//line :382:1
	return nil }(); if tmp11 != nil { if jrt.Exception_InstanceOf(tmp11) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp11); _ = ___3; tmp1 = nil } else { panic(tmp11) } }; return tmp1 }
//line :382:1
func A_arbace_go_repl_define_BANG__fn__794000401_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_repl_define_BANG__fn__794000401_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_define_BANG__fn__794000401_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :382:1
func (t *A_arbace_go_repl_define_BANG__fn__794000401_A) Ctor_O_O_O(c__ns, c__x, c__old any) { t.F_ns = c__ns; t.F_x = c__x; t.F_old = c__old }
//line :382:1
func (t *A_arbace_go_repl_define_BANG__fn__794000401_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_3468 any = A_arbace_go_repl_A_const_217.GetRawRoot__O(); var linked_3469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3468, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_3470 lang.IFn; if linked_3469 == nil { ifn_3470 = lang.IFn_Cast(root_3468) } else { ifn_3470 = nil }; var arg_3471 any; var t_ any = t.F_ns; t.F_ns = nil; arg_3471 = t_; var arg_3472 any; var root_3474 any = A_arbace_go_repl_A_const_218.GetRawRoot__O(); var linked_3475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3474, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3476 lang.IFn; if linked_3475 == nil { ifn_3476 = lang.IFn_Cast(root_3474) } else { ifn_3476 = nil }; var arg_3477 any; var root_3479 any = A_arbace_go_repl_A_const_46.GetRawRoot__O(); var linked_3480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3479, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3481 lang.IFn; if linked_3480 == nil { ifn_3481 = lang.IFn_Cast(root_3479) } else { ifn_3481 = nil }; var arg_3482 any; var root_3483 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3483, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3485 lang.IFn; if linked_3484 == nil { ifn_3485 = lang.IFn_Cast(root_3483) } else { ifn_3485 = nil }; var arg_3486 any = t.F_x; var arg_3487 any = A_arbace_go_repl_A_const_55; if linked_3484 == nil { arg_3482 = ifn_3485.Invoke_O_O__O(arg_3486, arg_3487) } else { arg_3482 = linked_3484.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3483, arg_3486, arg_3487) }; if linked_3480 == nil { arg_3477 = ifn_3481.Invoke_O__O(arg_3482) } else { arg_3477 = linked_3480.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3479, arg_3482) }; var arg_3478 any; var tmp2 any = A_arbace_go_repl_A_const_219; var tmp3 any = A_arbace_go_repl_A_const_142; var tmp4 any = A_arbace_go_repl_A_const_220; var tmp5 *lang.Keyword = A_arbace_go_repl_A_const_54; var tmp6 any; var t__2 any = t.F_old; t.F_old = nil; tmp6 = t__2; var tmp7 any = tmp5.Invoke_O__O(tmp6); var tmp8 any = A_arbace_go_repl_A_const_221; var tmp9 any; var root_3488 any = A_arbace_go_repl_A_const_122.GetRawRoot__O(); var linked_3489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3488, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3490 lang.IFn
												if linked_3489 == nil { ifn_3490 = lang.IFn_Cast(root_3488) } else { ifn_3490 = nil }; var arg_3491 any; var root_3492 any = A_arbace_go_repl_A_const_222.GetRawRoot__O(); var linked_3493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3492, aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A_fn_class); var ifn_3494 lang.IFn; if linked_3493 == nil { ifn_3494 = lang.IFn_Cast(root_3492) } else { ifn_3494 = nil }; var arg_3495 any; var root_3496 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3496, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3498 lang.IFn; if linked_3497 == nil { ifn_3498 = lang.IFn_Cast(root_3496) } else { ifn_3498 = nil }; var arg_3499 any = t.F_x; var arg_3500 any = A_arbace_go_repl_A_const_55; if linked_3497 == nil { arg_3495 = ifn_3498.Invoke_O_O__O(arg_3499, arg_3500) } else { arg_3495 = linked_3497.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3496, arg_3499, arg_3500) }; if linked_3493 == nil { arg_3491 = ifn_3494.Invoke_O__O(arg_3495) } else { arg_3491 = linked_3493.(*aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A).Invoke_O_O__O(root_3492, arg_3495) }; if linked_3489 == nil { tmp9 = ifn_3490.Invoke_O__O(arg_3491) } else { tmp9 = linked_3489.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3488, arg_3491) }
//line :383:1
		arg_3478 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp7, tmp8, tmp9)); if linked_3475 == nil { arg_3472 = ifn_3476.Invoke_O_O__O(arg_3477, arg_3478) } else { arg_3472 = linked_3475.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3474, arg_3477, arg_3478) }; var arg_3473 any; var tmp10 any; var root_3501 any = A_arbace_go_repl_A_const_191.GetRawRoot__O(); var linked_3502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3501, aot_arbace_go_build.A_arbace_go_build_desc_A_fn_class); var ifn_3503 lang.IFn

		if linked_3502 == nil { ifn_3503 = lang.IFn_Cast(root_3501) } else { ifn_3503 = nil }; var arg_3504 any; var root_3505 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_3506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3505, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3507 lang.IFn; if linked_3506 == nil { ifn_3507 = lang.IFn_Cast(root_3505) } else { ifn_3507 = nil }; var arg_3508 any; var t__3 any = t.F_x; t.F_x = nil; arg_3508 = t__3; var arg_3509 any = A_arbace_go_repl_A_const_142; if linked_3506 == nil { arg_3504 = ifn_3507.Invoke_O_O__O(arg_3508, arg_3509) } else { arg_3504 = linked_3506.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3505, arg_3508, arg_3509) }; if linked_3502 == nil { tmp10 = ifn_3503.Invoke_O__O(arg_3504) } else { tmp10 = linked_3502.(*aot_arbace_go_build.A_arbace_go_build_desc_A).Invoke_O_O__O(root_3501, arg_3504) }
//line :383:1
		arg_3473 = lang.GoType_New_O(tmp10); if linked_3469 == nil { tmp1 = ifn_3470.Invoke_O_O_O__O(arg_3471, arg_3472, arg_3473) } else { tmp1 = linked_3469.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O_O__O(root_3468, arg_3471, arg_3472, arg_3473) } }
//line :382:1
	return nil }(); if tmp11 != nil { if jrt.Exception_InstanceOf(tmp11) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp11); _ = ___3; tmp1 = nil } else { panic(tmp11) } }; return tmp1 }












func A_arbace_go_repl_call0_A_New() *A_arbace_go_repl_call0_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_call0_A{}; t.Ctor(); return t }
//line :395:1
func (t *A_arbace_go_repl_call0_A) Ctor() {}
//line :395:1
func (t *A_arbace_go_repl_call0_A) Invoke_O_O_O__O(self, f__0, nm__1 any) any {


	return lang.GoInterp_Call_O_O1__O(lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_13, f__0, lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_14, lang.RT_Object_array_O__O1_NoInit(lang.PersistentVector_EMPTY.Ref()).Ref(), lang.RT_Object_array_O__O1_NoInit(lang.PersistentVector_EMPTY.Ref()).Ref(), jrt.Boolean_FALSE.Ref()), nm__1), lang.RT_Object_array_O__O1_NoInit(lang.PersistentVector_EMPTY.Ref()))
}

func A_arbace_go_repl_complete_BANG__A_New() *A_arbace_go_repl_complete_BANG__A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_complete_BANG__A{}; t.Ctor(); return t }
//line :401:1
func (t *A_arbace_go_repl_complete_BANG__A) Ctor() {}
//line :401:1
func (t *A_arbace_go_repl_complete_BANG__A) Invoke_O_O__O(self, st__0 any) any {



	var root_3568 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_3569 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3568, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3570 lang.IFn; if linked_3569 == nil { ifn_3570 = lang.IFn_Cast(root_3568) } else { ifn_3570 = nil }; var arg_3571 any = st__0; var arg_3572 any = A_arbace_go_repl_A_const_84.GetRawRoot__O(); var arg_3573 any = A_arbace_go_repl_A_const_77; if linked_3569 == nil { ifn_3570.Invoke_O_O_O__O(arg_3571, arg_3572, arg_3573) } else { linked_3569.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_3568, arg_3571, arg_3572, arg_3573) }
//line :401:1
	var r__2 any; var root_3537 any = A_arbace_go_repl_A_const_225.GetRawRoot__O(); var linked_3538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3537, A_arbace_go_repl_check_source_A_fn_class); var ifn_3539 lang.IFn




	if linked_3538 == nil { ifn_3539 = lang.IFn_Cast(root_3537) } else { ifn_3539 = nil }; var arg_3540 any; var root_3542 any = A_arbace_go_repl_A_const_118.GetRawRoot__O(); var linked_3543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3542, A_arbace_go_repl_source_of_A_fn_class); var ifn_3544 lang.IFn; if linked_3543 == nil { ifn_3544 = lang.IFn_Cast(root_3542) } else { ifn_3544 = nil }; var arg_3545 any = st__0; if linked_3543 == nil { arg_3540 = ifn_3544.Invoke_O__O(arg_3545) } else { arg_3540 = linked_3543.(*A_arbace_go_repl_source_of_A).Invoke_O_O__O(root_3542, arg_3545) }; var arg_3541 any; if linked_3538 == nil { r__2 = ifn_3539.Invoke_O_O__O(arg_3540, arg_3541) } else { r__2 = linked_3538.(*A_arbace_go_repl_check_source_A).Invoke_O_O_O__O(root_3537, arg_3540, arg_3541) }
	var tmp1 any; var root_3574 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_3575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3574, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3576 lang.IFn; if linked_3575 == nil { ifn_3576 = lang.IFn_Cast(root_3574) } else { ifn_3576 = nil }; var arg_3577 any = A_arbace_go_repl_A_const_228.Invoke_O__O(r__2); if linked_3575 == nil { tmp1 = ifn_3576.Invoke_O__O(arg_3577) } else { tmp1 = linked_3575.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3574, arg_3577) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_3578 any = A_arbace_go_repl_A_const_69.GetRawRoot__O(); var linked_3579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3578, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_3580 lang.IFn
		if linked_3579 == nil { ifn_3580 = lang.IFn_Cast(root_3578) } else { ifn_3580 = nil }; var arg_3581 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_16, nil); var tmp4 *lang.Keyword = A_arbace_go_repl_A_const_54; var tmp5 any; var root_3583 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_3584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3583, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3585 lang.IFn; if linked_3584 == nil { ifn_3585 = lang.IFn_Cast(root_3583) } else { ifn_3585 = nil }; var arg_3586 any = st__0; if linked_3584 == nil { tmp5 = ifn_3585.Invoke_O__O(arg_3586) } else { tmp5 = linked_3584.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3583, arg_3586) }; var tmp6 any = tmp4.Invoke_O__O(tmp5); var tmp7 any; var root_3587 any = A_arbace_go_repl_A_const_115.GetRawRoot__O(); var linked_3588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3587, A_arbace_go_repl_error_text_A_fn_class); var ifn_3589 lang.IFn; if linked_3588 == nil { ifn_3589 = lang.IFn_Cast(root_3587) } else { ifn_3589 = nil }; var arg_3590 any = A_arbace_go_repl_A_const_228.Invoke_O__O(r__2); if linked_3588 == nil { tmp7 = ifn_3589.Invoke_O__O(arg_3590) } else { tmp7 = linked_3588.(*A_arbace_go_repl_error_text_A).Invoke_O_O__O(root_3587, arg_3590) }; arg_3581 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp6, nil, tmp7)).Ref(); var tmp8 any = A_arbace_go_repl_A_const_229; var arg_3582 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, A_arbace_go_repl_A_const_228.Invoke_O__O(r__2))); if linked_3579 == nil { tmp2 = ifn_3580.Invoke_O_O__O(arg_3581, arg_3582) } else { tmp2 = linked_3579.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_3578, arg_3581, arg_3582) }
//line :407:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) }
//line :401:1
	var map__794000405__3 any; var root_3546 any = A_arbace_go_repl_A_const_226.GetRawRoot__O(); var linked_3547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3546, A_arbace_go_repl_define_BANG__A_fn_class); var ifn_3548 lang.IFn








	if linked_3547 == nil { ifn_3548 = lang.IFn_Cast(root_3546) } else { ifn_3548 = nil }; var arg_3549 any = st__0; var arg_3550 any = r__2; var arg_3551 any = A_arbace_go_repl_A_const_227; if linked_3547 == nil { map__794000405__3 = ifn_3548.Invoke_O_O_O__O(arg_3549, arg_3550, arg_3551) } else { map__794000405__3 = linked_3547.(*A_arbace_go_repl_define_BANG__A).Invoke_O_O_O_O__O(root_3546, arg_3549, arg_3550, arg_3551) }
//line :401:1
	var map__794000405__4 any








	if lang.ISeq_InstanceOf(map__794000405__3) { var tmp9 any; var root_3552 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_3553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3552, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3554 lang.IFn; if linked_3553 == nil { ifn_3554 = lang.IFn_Cast(root_3552) } else { ifn_3554 = nil }; var arg_3555 any = map__794000405__3; if linked_3553 == nil { tmp9 = ifn_3554.Invoke_O__O(arg_3555) } else { tmp9 = linked_3553.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3552, arg_3555) }; if jrt.J2g_Truth(tmp9) { var tmp10 any; var root_3556 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_3557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3556, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3558 lang.IFn; if linked_3557 == nil { ifn_3558 = lang.IFn_Cast(root_3556) } else { ifn_3558 = nil }; var arg_3559 any = map__794000405__3; if linked_3557 == nil { tmp10 = ifn_3558.Invoke_O__O(arg_3559) } else { tmp10 = linked_3557.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3556, arg_3559) }; map__794000405__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp10, jrt.Object_class.ArrayClass())).Ref() } else { var tmp11 any; var root_3560 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_3561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3560, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3562 lang.IFn; if linked_3561 == nil { ifn_3562 = lang.IFn_Cast(root_3560) } else { ifn_3562 = nil }; var arg_3563 any = map__794000405__3; if linked_3561 == nil { tmp11 = ifn_3562.Invoke_O__O(arg_3563) } else { tmp11 = linked_3561.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3560, arg_3563) }; if jrt.J2g_Truth(tmp11) { var root_3564 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_3565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3564, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3566 lang.IFn; if linked_3565 == nil { ifn_3566 = lang.IFn_Cast(root_3564) } else { ifn_3566 = nil }; var arg_3567 any = map__794000405__3; if linked_3565 == nil { map__794000405__4 = ifn_3566.Invoke_O__O(arg_3567) } else { map__794000405__4 = linked_3565.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3564, arg_3567) } } else { map__794000405__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000405__4 = map__794000405__3 }
//line :401:1
	var inits__5 any = lang.RT_Get_O_O__O_NoInit(map__794000405__4, A_arbace_go_repl_A_const_186); var init_funcs__6 any = lang.RT_Get_O_O__O_NoInit(map__794000405__4, A_arbace_go_repl_A_const_196); var root_3591 any = A_arbace_go_repl_A_const_230.GetRawRoot__O(); var linked_3592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3591, A_arbace_go_repl_call0_A_fn_class); var ifn_3593 lang.IFn









	if linked_3592 == nil { ifn_3593 = lang.IFn_Cast(root_3591) } else { ifn_3593 = nil }; var arg_3594 any = inits__5; var arg_3595 any = Lit_17; if linked_3592 == nil { ifn_3593.Invoke_O_O__O(arg_3594, arg_3595) } else { linked_3592.(*A_arbace_go_repl_call0_A).Invoke_O_O_O__O(root_3591, arg_3594, arg_3595) }
//line :401:1
	var seq_794000407__7 any; var root_3596 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_3597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3596, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3598 lang.IFn










	if linked_3597 == nil { ifn_3598 = lang.IFn_Cast(root_3596) } else { ifn_3598 = nil }; var arg_3599 any = init_funcs__6; if linked_3597 == nil { seq_794000407__7 = ifn_3598.Invoke_O__O(arg_3599) } else { seq_794000407__7 = linked_3597.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3596, arg_3599) }
//line :401:1
	var chunk_794000408__8 any; var count_794000409__9 int64 = 0; var i_794000410__10 int64 = 0; L1: for {










		if lang.Numbers_Lt_J_J__Z_NoInit(i_794000410__10, count_794000409__9) { var f__11 any = lang.Indexed_Cast(chunk_794000408__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_794000410__10)); var root_3616 any = A_arbace_go_repl_A_const_230.GetRawRoot__O(); var linked_3617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3616, A_arbace_go_repl_call0_A_fn_class); var ifn_3618 lang.IFn
			if linked_3617 == nil { ifn_3618 = lang.IFn_Cast(root_3616) } else { ifn_3618 = nil }; var arg_3619 any = f__11; var arg_3620 any = Lit_17; if linked_3617 == nil { ifn_3618.Invoke_O_O__O(arg_3619, arg_3620) } else { linked_3617.(*A_arbace_go_repl_call0_A).Invoke_O_O_O__O(root_3616, arg_3619, arg_3620) }
//line :412:1
			seq_794000407__7, chunk_794000408__8, count_794000409__9, i_794000410__10 = seq_794000407__7, chunk_794000408__8, count_794000409__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000410__10); continue L1 } else { var temp__1927000414__auto____11 any; var root_3600 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_3601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3600, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3602 lang.IFn; if linked_3601 == nil { ifn_3602 = lang.IFn_Cast(root_3600) } else { ifn_3602 = nil }; var arg_3603 any = seq_794000407__7; if linked_3601 == nil { temp__1927000414__auto____11 = ifn_3602.Invoke_O__O(arg_3603) } else { temp__1927000414__auto____11 = linked_3601.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3600, arg_3603) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_794000407__12 any = temp__1927000414__auto____11; var tmp12 any; var root_3604 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_3605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3604, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3606 lang.IFn; if linked_3605 == nil { ifn_3606 = lang.IFn_Cast(root_3604) } else { ifn_3606 = nil }; var arg_3607 any = seq_794000407__12; if linked_3605 == nil { tmp12 = ifn_3606.Invoke_O__O(arg_3607) } else { tmp12 = linked_3605.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3604, arg_3607) }; if jrt.J2g_Truth(tmp12) { var c__1927000678__auto____13 any; var root_3608 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_3609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3608, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3610 lang.IFn; if linked_3609 == nil { ifn_3610 = lang.IFn_Cast(root_3608) } else { ifn_3610 = nil }; var arg_3611 any = seq_794000407__12; if linked_3609 == nil { c__1927000678__auto____13 = ifn_3610.Invoke_O__O(arg_3611) } else { c__1927000678__auto____13 = linked_3609.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3608, arg_3611) }; var tmp13 any; var root_3621 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_3622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3621, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3623 lang.IFn; if linked_3622 == nil { ifn_3623 = lang.IFn_Cast(root_3621) } else { ifn_3623 = nil }; var arg_3624 any = seq_794000407__12; if linked_3622 == nil { tmp13 = ifn_3623.Invoke_O__O(arg_3624) } else { tmp13 = linked_3622.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3621, arg_3624) }; seq_794000407__7, chunk_794000408__8, count_794000409__9, i_794000410__10 = tmp13, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__13 any; var root_3612 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_3613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3612, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3614 lang.IFn; if linked_3613 == nil { ifn_3614 = lang.IFn_Cast(root_3612) } else { ifn_3614 = nil }; var arg_3615 any = seq_794000407__12; if linked_3613 == nil { f__13 = ifn_3614.Invoke_O__O(arg_3615) } else { f__13 = linked_3613.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3612, arg_3615) }
				var root_3625 any = A_arbace_go_repl_A_const_230.GetRawRoot__O(); var linked_3626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3625, A_arbace_go_repl_call0_A_fn_class); var ifn_3627 lang.IFn; if linked_3626 == nil { ifn_3627 = lang.IFn_Cast(root_3625) } else { ifn_3627 = nil }; var arg_3628 any = f__13; var arg_3629 any = Lit_17; if linked_3626 == nil { ifn_3627.Invoke_O_O__O(arg_3628, arg_3629) } else { linked_3626.(*A_arbace_go_repl_call0_A).Invoke_O_O_O__O(root_3625, arg_3628, arg_3629) }
//line :412:1
				var tmp14 any; var root_3630 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_3631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3630, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3632 lang.IFn; if linked_3631 == nil { ifn_3632 = lang.IFn_Cast(root_3630) } else { ifn_3632 = nil }; var arg_3633 any = seq_794000407__12; if linked_3631 == nil { tmp14 = ifn_3632.Invoke_O__O(arg_3633) } else { tmp14 = linked_3631.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3630, arg_3633) }; seq_794000407__7, chunk_794000408__8, count_794000409__9, i_794000410__10 = tmp14, nil, 0, 0; continue L1 } } }
//line :401:1
		break L1 }; return st__0
}













func A_arbace_go_repl_after_load_A_New() *A_arbace_go_repl_after_load_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_after_load_A{}; t.Ctor(); return t }
//line :416:1
func (t *A_arbace_go_repl_after_load_A) Ctor() {}
//line :416:1
func (t *A_arbace_go_repl_after_load_A) Invoke_O_O_O__O(self, path__0, ok__1 any) any { { var p__3 any; var tmp1 any; var root_3634 any = A_arbace_go_repl_A_const_68.GetRawRoot__O(); var linked_3635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3634, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_3636 lang.IFn



	if linked_3635 == nil { ifn_3636 = lang.IFn_Cast(root_3634) } else { ifn_3636 = nil }; var arg_3637 any = path__0; var arg_3638 any = Lit_1; if linked_3635 == nil { tmp1 = ifn_3636.Invoke_O_O__O(arg_3637, arg_3638) } else { tmp1 = linked_3635.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_3634, arg_3637, arg_3638) }; if jrt.J2g_Truth(tmp1) { var root_3639 any = A_arbace_go_repl_A_const_22.GetRawRoot__O(); var linked_3640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3639, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3641 lang.IFn; if linked_3640 == nil { ifn_3641 = lang.IFn_Cast(root_3639) } else { ifn_3641 = nil }; var arg_3642 any = path__0; var arg_3643 any = A_arbace_go_repl_A_const_154; if linked_3640 == nil { p__3 = ifn_3641.Invoke_O_O__O(arg_3642, arg_3643) } else { p__3 = linked_3640.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_3639, arg_3642, arg_3643) } } else { p__3 = path__0 }
	var tmp2 any; var root_3644 any = A_arbace_go_repl_A_const_68.GetRawRoot__O(); var linked_3645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3644, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_3646 lang.IFn; if linked_3645 == nil { ifn_3646 = lang.IFn_Cast(root_3644) } else { ifn_3646 = nil }; var arg_3647 any = p__3; var arg_3648 any = Lit_2; if linked_3645 == nil { tmp2 = ifn_3646.Invoke_O_O__O(arg_3647, arg_3648) } else { tmp2 = linked_3645.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_3644, arg_3647, arg_3648) }; if jrt.J2g_Truth(tmp2) { var ns_name__4 any; var root_3649 any = A_arbace_go_repl_A_const_231.GetRawRoot__O(); var linked_3650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3649, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_3651 lang.IFn
		if linked_3650 == nil { ifn_3651 = lang.IFn_Cast(root_3649) } else { ifn_3651 = nil }; var arg_3652 any; var root_3655 any = A_arbace_go_repl_A_const_231.GetRawRoot__O(); var linked_3656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3655, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_3657 lang.IFn; if linked_3656 == nil { ifn_3657 = lang.IFn_Cast(root_3655) } else { ifn_3657 = nil }; var arg_3658 any = p__3; var arg_3659 any = Lit_1; var arg_3660 any = Lit_3; if linked_3656 == nil { arg_3652 = ifn_3657.Invoke_O_O_O__O(arg_3658, arg_3659, arg_3660) } else { arg_3652 = linked_3656.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_3655, arg_3658, arg_3659, arg_3660) }; var arg_3653 any = Lit_4; var arg_3654 any = Lit_5; if linked_3650 == nil { ns_name__4 = ifn_3651.Invoke_O_O_O__O(arg_3652, arg_3653, arg_3654) } else { ns_name__4 = linked_3650.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_3649, arg_3652, arg_3653, arg_3654) }
//line :421:1
		var seq_794000412__5 any; var root_3661 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_3662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3661, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3663 lang.IFn

		if linked_3662 == nil { ifn_3663 = lang.IFn_Cast(root_3661) } else { ifn_3663 = nil }; var arg_3664 any; var root_3665 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_3666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3665, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3667 lang.IFn; if linked_3666 == nil { ifn_3667 = lang.IFn_Cast(root_3665) } else { ifn_3667 = nil }; var arg_3668 any = A_arbace_go_repl_A_const_64.GetRawRoot__O(); if linked_3666 == nil { arg_3664 = ifn_3667.Invoke_O__O(arg_3668) } else { arg_3664 = linked_3666.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3665, arg_3668) }; if linked_3662 == nil { seq_794000412__5 = ifn_3663.Invoke_O__O(arg_3664) } else { seq_794000412__5 = linked_3662.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3661, arg_3664) }
//line :421:1
		var chunk_794000413__6 any; var count_794000414__7 int64 = 0; var i_794000415__8 int64 = 0; L1: for {

			if lang.Numbers_Lt_J_J__Z_NoInit(i_794000415__8, count_794000414__7) { var vec__794000416__9 any = lang.Indexed_Cast(chunk_794000413__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_794000415__8)); var path__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000416__9, lang.RT_IntCast_J__I_NoInit(0), nil); var st__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000416__9, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp3 any; var and__1927000168__auto____12 any; var tmp4 *lang.Keyword = A_arbace_go_repl_A_const_77; var tmp5 any; var root_3685 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_3686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3685, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3687 lang.IFn
				if linked_3686 == nil { ifn_3687 = lang.IFn_Cast(root_3685) } else { ifn_3687 = nil }; var arg_3688 any = st__11; if linked_3686 == nil { tmp5 = ifn_3687.Invoke_O__O(arg_3688) } else { tmp5 = linked_3686.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3685, arg_3688) }; and__1927000168__auto____12 = tmp4.Invoke_O__O(tmp5); if jrt.J2g_Truth(and__1927000168__auto____12) { var tmp6 any; var root_3689 any = A_arbace_go_repl_A_const_51.GetRawRoot__O(); var linked_3690 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3689, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_3691 lang.IFn; if linked_3690 == nil { ifn_3691 = lang.IFn_Cast(root_3689) } else { ifn_3691 = nil }; var arg_3692 any; var tmp7 *lang.Keyword = A_arbace_go_repl_A_const_56; var tmp8 any; var root_3693 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_3694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3693, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3695 lang.IFn; if linked_3694 == nil { ifn_3695 = lang.IFn_Cast(root_3693) } else { ifn_3695 = nil }; var arg_3696 any = st__11; if linked_3694 == nil { tmp8 = ifn_3695.Invoke_O__O(arg_3696) } else { tmp8 = linked_3694.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3693, arg_3696) }; arg_3692 = tmp7.Invoke_O__O(tmp8); if linked_3690 == nil { tmp6 = ifn_3691.Invoke_O__O(arg_3692) } else { tmp6 = linked_3690.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_3689, arg_3692) }; tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp6, ns_name__4)).Ref() } else { tmp3 = and__1927000168__auto____12 }; if jrt.J2g_Truth(tmp3) {
					if jrt.J2g_Truth(ok__1) {
						var root_3697 any = A_arbace_go_repl_A_const_232.GetRawRoot__O(); var linked_3698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3697, A_arbace_go_repl_complete_BANG__A_fn_class); var ifn_3699 lang.IFn; if linked_3698 == nil { ifn_3699 = lang.IFn_Cast(root_3697) } else { ifn_3699 = nil }; var arg_3700 any = st__11; if linked_3698 == nil { ifn_3699.Invoke_O__O(arg_3700) } else { linked_3698.(*A_arbace_go_repl_complete_BANG__A).Invoke_O_O__O(root_3697, arg_3700) } } else {
							var root_3701 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_3702 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3701, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3703 lang.IFn; if linked_3702 == nil { ifn_3703 = lang.IFn_Cast(root_3701) } else { ifn_3703 = nil }; var arg_3704 any = A_arbace_go_repl_A_const_64.GetRawRoot__O(); var arg_3705 any = A_arbace_go_repl_A_const_84.GetRawRoot__O(); var arg_3706 any = path__10; if linked_3702 == nil { ifn_3703.Invoke_O_O_O__O(arg_3704, arg_3705, arg_3706) } else { linked_3702.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_3701, arg_3704, arg_3705, arg_3706) } } }
//line :423:1
				seq_794000412__5, chunk_794000413__6, count_794000414__7, i_794000415__8 = seq_794000412__5, chunk_794000413__6, count_794000414__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_794000415__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_3669 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_3670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3669, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3671 lang.IFn; if linked_3670 == nil { ifn_3671 = lang.IFn_Cast(root_3669) } else { ifn_3671 = nil }; var arg_3672 any = seq_794000412__5; if linked_3670 == nil { temp__1927000414__auto____9 = ifn_3671.Invoke_O__O(arg_3672) } else { temp__1927000414__auto____9 = linked_3670.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3669, arg_3672) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_794000412__10 any = temp__1927000414__auto____9; var tmp9 any; var root_3673 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_3674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3673, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3675 lang.IFn; if linked_3674 == nil { ifn_3675 = lang.IFn_Cast(root_3673) } else { ifn_3675 = nil }; var arg_3676 any = seq_794000412__10; if linked_3674 == nil { tmp9 = ifn_3675.Invoke_O__O(arg_3676) } else { tmp9 = linked_3674.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3673, arg_3676) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____11 any; var root_3677 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_3678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3677, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3679 lang.IFn; if linked_3678 == nil { ifn_3679 = lang.IFn_Cast(root_3677) } else { ifn_3679 = nil }; var arg_3680 any = seq_794000412__10; if linked_3678 == nil { c__1927000678__auto____11 = ifn_3679.Invoke_O__O(arg_3680) } else { c__1927000678__auto____11 = linked_3678.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3677, arg_3680) }; var tmp10 any; var root_3707 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_3708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3707, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3709 lang.IFn; if linked_3708 == nil { ifn_3709 = lang.IFn_Cast(root_3707) } else { ifn_3709 = nil }; var arg_3710 any = seq_794000412__10; if linked_3708 == nil { tmp10 = ifn_3709.Invoke_O__O(arg_3710) } else { tmp10 = linked_3708.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3707, arg_3710) }; seq_794000412__5, chunk_794000413__6, count_794000414__7, i_794000415__8 = tmp10, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__794000419__11 any; var root_3681 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_3682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3681, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3683 lang.IFn; if linked_3682 == nil { ifn_3683 = lang.IFn_Cast(root_3681) } else { ifn_3683 = nil }; var arg_3684 any = seq_794000412__10; if linked_3682 == nil { vec__794000419__11 = ifn_3683.Invoke_O__O(arg_3684) } else { vec__794000419__11 = linked_3682.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3681, arg_3684) }; var path__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000419__11, lang.RT_IntCast_J__I_NoInit(0), nil); var st__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000419__11, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp11 any; var and__1927000168__auto____14 any; var tmp12 *lang.Keyword = A_arbace_go_repl_A_const_77; var tmp13 any; var root_3711 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_3712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3711, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3713 lang.IFn
					if linked_3712 == nil { ifn_3713 = lang.IFn_Cast(root_3711) } else { ifn_3713 = nil }; var arg_3714 any = st__13; if linked_3712 == nil { tmp13 = ifn_3713.Invoke_O__O(arg_3714) } else { tmp13 = linked_3712.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3711, arg_3714) }; and__1927000168__auto____14 = tmp12.Invoke_O__O(tmp13); if jrt.J2g_Truth(and__1927000168__auto____14) { var tmp14 any; var root_3715 any = A_arbace_go_repl_A_const_51.GetRawRoot__O(); var linked_3716 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3715, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_3717 lang.IFn; if linked_3716 == nil { ifn_3717 = lang.IFn_Cast(root_3715) } else { ifn_3717 = nil }; var arg_3718 any; var tmp15 *lang.Keyword = A_arbace_go_repl_A_const_56; var tmp16 any; var root_3719 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_3720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3719, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3721 lang.IFn; if linked_3720 == nil { ifn_3721 = lang.IFn_Cast(root_3719) } else { ifn_3721 = nil }; var arg_3722 any = st__13; if linked_3720 == nil { tmp16 = ifn_3721.Invoke_O__O(arg_3722) } else { tmp16 = linked_3720.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3719, arg_3722) }; arg_3718 = tmp15.Invoke_O__O(tmp16); if linked_3716 == nil { tmp14 = ifn_3717.Invoke_O__O(arg_3718) } else { tmp14 = linked_3716.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_3715, arg_3718) }; tmp11 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp14, ns_name__4)).Ref() } else { tmp11 = and__1927000168__auto____14 }; if jrt.J2g_Truth(tmp11) {
						if jrt.J2g_Truth(ok__1) {
							var root_3723 any = A_arbace_go_repl_A_const_232.GetRawRoot__O(); var linked_3724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3723, A_arbace_go_repl_complete_BANG__A_fn_class); var ifn_3725 lang.IFn; if linked_3724 == nil { ifn_3725 = lang.IFn_Cast(root_3723) } else { ifn_3725 = nil }; var arg_3726 any = st__13; if linked_3724 == nil { ifn_3725.Invoke_O__O(arg_3726) } else { linked_3724.(*A_arbace_go_repl_complete_BANG__A).Invoke_O_O__O(root_3723, arg_3726) } } else {
								var root_3727 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_3728 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3727, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3729 lang.IFn; if linked_3728 == nil { ifn_3729 = lang.IFn_Cast(root_3727) } else { ifn_3729 = nil }; var arg_3730 any = A_arbace_go_repl_A_const_64.GetRawRoot__O(); var arg_3731 any = A_arbace_go_repl_A_const_84.GetRawRoot__O(); var arg_3732 any = path__12; if linked_3728 == nil { ifn_3729.Invoke_O_O_O__O(arg_3730, arg_3731, arg_3732) } else { linked_3728.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_3727, arg_3730, arg_3731, arg_3732) } } }
//line :423:1
					var tmp17 any; var root_3733 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_3734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3733, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3735 lang.IFn; if linked_3734 == nil { ifn_3735 = lang.IFn_Cast(root_3733) } else { ifn_3735 = nil }; var arg_3736 any = seq_794000412__10; if linked_3734 == nil { tmp17 = ifn_3735.Invoke_O__O(arg_3736) } else { tmp17 = linked_3734.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3733, arg_3736) }; seq_794000412__5, chunk_794000413__6, count_794000414__7, i_794000415__8 = tmp17, nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :421:1
						return nil } }; /*line :416:1*/panic("j2g: unreachable") }















func A_arbace_go_repl_load_import_A_New() *A_arbace_go_repl_load_import_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_load_import_A{}; t.Ctor(); return t }
//line :432:1
func (t *A_arbace_go_repl_load_import_A) Ctor() {}
//line :432:1
func (t *A_arbace_go_repl_load_import_A) Invoke_O_O__O(self, path__0 any) any { var or__1927000174__auto____2 any; var temp__1927000414__auto____2 any; var tmp1 any; var root_3737 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_3738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3737, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3739 lang.IFn; if



	linked_3738 == nil { ifn_3739 = lang.IFn_Cast(root_3737) } else { ifn_3739 = nil }; var arg_3740 any = A_arbace_go_repl_A_const_64.GetRawRoot__O(); if linked_3738 == nil { tmp1 = ifn_3739.Invoke_O__O(arg_3740) } else { tmp1 = linked_3738.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3737, arg_3740) }; temp__1927000414__auto____2 = lang.RT_Get_O_O__O_NoInit(tmp1, path__0); if jrt.J2g_Truth(temp__1927000414__auto____2) { var st__3 any = temp__1927000414__auto____2; var tmp2 *lang.Keyword = A_arbace_go_repl_A_const_77; var tmp3 any; var root_3741 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_3742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3741, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3743 lang.IFn; if linked_3742 == nil { ifn_3743 = lang.IFn_Cast(root_3741) } else { ifn_3743 = nil }; var arg_3744 any = st__3; if linked_3742 == nil { tmp3 = ifn_3743.Invoke_O__O(arg_3744) } else { tmp3 = linked_3742.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3741, arg_3744) }; if jrt.J2g_Truth(tmp2.Invoke_O__O(tmp3)) { or__1927000174__auto____2 = nil } else { or__1927000174__auto____2 = st__3 } } else { or__1927000174__auto____2 = nil }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {
		var tmp4 any; var root_3745 any = A_arbace_go_repl_A_const_43.GetRawRoot__O(); var linked_3746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3745, A_arbace_go_repl_listed_QMARK__A_fn_class); var ifn_3747 lang.IFn; if linked_3746 == nil { ifn_3747 = lang.IFn_Cast(root_3745) } else { ifn_3747 = nil }; var arg_3748 any = path__0; if linked_3746 == nil { tmp4 = ifn_3747.Invoke_O__O(arg_3748) } else { tmp4 = linked_3746.(*A_arbace_go_repl_listed_QMARK__A).Invoke_O_O__O(root_3745, arg_3748) }; if jrt.J2g_Truth(tmp4) { return nil } else { var ns_sym__3 any; var root_3749 any = A_arbace_go_repl_A_const_233.GetRawRoot__O(); var linked_3750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3749, A_arbace_go_repl_path__GT_ns_A_fn_class); var ifn_3751 lang.IFn
			if linked_3750 == nil { ifn_3751 = lang.IFn_Cast(root_3749) } else { ifn_3751 = nil }; var arg_3752 any = path__0; if linked_3750 == nil { ns_sym__3 = ifn_3751.Invoke_O__O(arg_3752) } else { ns_sym__3 = linked_3750.(*A_arbace_go_repl_path__GT_ns_A).Invoke_O_O__O(root_3749, arg_3752) }
			var tmp5 any = A_arbace_go_repl_load_import_fn__794000425_A_New_O(ns_sym__3); var tmp6 *jrt.Class; var fncls__3765 *jrt.Class = A_arbace_go_repl_load_import_fn__794000425_A_fn_class; if fncls__3765 == nil { var fncls__3765d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_158, false); A_arbace_go_repl_load_import_fn__794000425_A_fn_class = fncls__3765d; tmp6 = fncls__3765d } else { tmp6 = fncls__3765 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()
//line :437:1
			var temp__1927000414__auto____4 any; var tmp7 any; var root_3753 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_3754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3753, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3755 lang.IFn




			if linked_3754 == nil { ifn_3755 = lang.IFn_Cast(root_3753) } else { ifn_3755 = nil }; var arg_3756 any = A_arbace_go_repl_A_const_64.GetRawRoot__O(); if linked_3754 == nil { tmp7 = ifn_3755.Invoke_O__O(arg_3756) } else { tmp7 = linked_3754.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3753, arg_3756) }; temp__1927000414__auto____4 = lang.RT_Get_O_O__O_NoInit(tmp7, path__0); if jrt.J2g_Truth(temp__1927000414__auto____4) { var st__5 any = temp__1927000414__auto____4; var tmp8 *lang.Keyword = A_arbace_go_repl_A_const_77; var tmp9 any; var root_3757 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_3758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3757, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3759 lang.IFn
				if linked_3758 == nil { ifn_3759 = lang.IFn_Cast(root_3757) } else { ifn_3759 = nil }; var arg_3760 any = st__5; if linked_3758 == nil { tmp9 = ifn_3759.Invoke_O__O(arg_3760) } else { tmp9 = linked_3758.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3757, arg_3760) }; if jrt.J2g_Truth(tmp8.Invoke_O__O(tmp9)) { return nil } else { return st__5 } } else {
//line :442:1
					return nil } } } }
//line :439:1
func A_arbace_go_repl_load_import_fn__794000425_A_New_O(p0 any) *A_arbace_go_repl_load_import_fn__794000425_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_load_import_fn__794000425_A{}; t.Ctor_O(p0); return t }
//line :439:1
func (t *A_arbace_go_repl_load_import_fn__794000425_A) Ctor_O(c__ns_sym any) { t.F_ns_sym = c__ns_sym }
//line :439:1
func (t *A_arbace_go_repl_load_import_fn__794000425_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_2.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_ns_sym; t.F_ns_sym = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }
//line :439:1
	return nil }(); if tmp4 != nil { if jrt.FileNotFoundException_InstanceOf(tmp4) { var ___3 *jrt.FileNotFoundException = jrt.FileNotFoundException_Cast(tmp4); _ = ___3; tmp1 = nil } else { panic(tmp4) } }; return tmp1 }







func A_arbace_go_repl_declare_BANG__A_New() *A_arbace_go_repl_declare_BANG__A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__A{}; t.Ctor(); return t }
//line :447:1
func (t *A_arbace_go_repl_declare_BANG__A) Ctor() {}
//line :447:1
func (t *A_arbace_go_repl_declare_BANG__A) Invoke_O_O_O__O(self, form__0, p__794000434__1 any) any { var map__794000435__3 any = p__794000434__1; var map__794000435__4 any; if lang.ISeq_InstanceOf(map__794000435__3) { var tmp1 any; var root_3766 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_3767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3766, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3768 lang.IFn; if linked_3767 == nil { ifn_3768 = lang.IFn_Cast(root_3766) } else { ifn_3768 = nil }; var arg_3769 any = map__794000435__3; if linked_3767 == nil { tmp1 = ifn_3768.Invoke_O__O(arg_3769) } else { tmp1 = linked_3767.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3766, arg_3769) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_3770 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_3771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3770, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3772 lang.IFn; if linked_3771 == nil { ifn_3772 = lang.IFn_Cast(root_3770) } else { ifn_3772 = nil }; var arg_3773 any = map__794000435__3; if linked_3771 == nil { tmp2 = ifn_3772.Invoke_O__O(arg_3773) } else { tmp2 = linked_3771.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3770, arg_3773) }; map__794000435__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_3774 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_3775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3774, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3776 lang.IFn; if linked_3775 == nil { ifn_3776 = lang.IFn_Cast(root_3774) } else { ifn_3776 = nil }; var arg_3777 any = map__794000435__3; if linked_3775 == nil { tmp3 = ifn_3776.Invoke_O__O(arg_3777) } else { tmp3 = linked_3775.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3774, arg_3777) }; if jrt.J2g_Truth(tmp3) { var root_3778 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_3779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3778, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3780 lang.IFn; if linked_3779 == nil { ifn_3780 = lang.IFn_Cast(root_3778) } else { ifn_3780 = nil }; var arg_3781 any = map__794000435__3; if linked_3779 == nil { map__794000435__4 = ifn_3780.Invoke_O__O(arg_3781) } else { map__794000435__4 = linked_3779.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3778, arg_3781) } } else { map__794000435__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000435__4 = map__794000435__3 }; var ns__5 any = lang.RT_Get_O_O__O_NoInit(map__794000435__4, A_arbace_go_repl_A_const_56); var line__6 any = lang.RT_Get_O_O__O_NoInit(map__794000435__4, A_arbace_go_repl_A_const_111); var ns_sym__7 any; var or__1927000174__auto____7 any = ns__5; _ = line__6; if



	jrt.J2g_Truth(or__1927000174__auto____7) { ns_sym__7 = or__1927000174__auto____7 } else { var root_3782 any = A_arbace_go_repl_A_const_234.GetRawRoot__O(); var linked_3783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3782, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_3784 lang.IFn; if linked_3783 == nil { ifn_3784 = lang.IFn_Cast(root_3782) } else { ifn_3784 = nil }; var arg_3785 any = A_arbace_go_repl_A_const_235.Get__O(); if linked_3783 == nil { ns_sym__7 = ifn_3784.Invoke_O__O(arg_3785) } else { ns_sym__7 = linked_3783.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_3782, arg_3785) } }; var st__8 any; var root_3786 any = /*line :447:1*/A_arbace_go_repl_A_const_72.GetRawRoot__O(); var linked_3787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3786, A_arbace_go_repl_package_state_A_fn_class); var ifn_3788 lang.IFn; if




	linked_3787 == nil { ifn_3788 = lang.IFn_Cast(root_3786) } else { ifn_3788 = nil }; var arg_3789 any = ns_sym__7; if linked_3787 == nil { st__8 = ifn_3788.Invoke_O__O(arg_3789) } else { st__8 = linked_3787.(*A_arbace_go_repl_package_state_A).Invoke_O_O__O(root_3786, arg_3789) }; var tmp4 /*line :453:1*/*lang.Keyword = A_arbace_go_repl_A_const_77; var tmp5 any; var root_3790 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_3791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3790, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3792 lang.IFn; if linked_3791 == nil { ifn_3792 = lang.IFn_Cast(root_3790) } else { ifn_3792 = nil }; var arg_3793 any = st__8; if linked_3791 == nil { tmp5 = ifn_3792.Invoke_O__O(arg_3793) } else { tmp5 = linked_3791.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3790, arg_3793) }; if jrt.J2g_Truth(tmp4.Invoke_O__O(tmp5)) {
		var root_4075 any = A_arbace_go_repl_A_const_83.GetRawRoot__O(); var linked_4076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4075, A_arbace_go_repl_update_file_A_fn_class); var ifn_4077 lang.IFn; if linked_4076 == nil { ifn_4077 = lang.IFn_Cast(root_4075) } else { ifn_4077 = nil }; var arg_4078 any = st__8; var arg_4079 any; var tmp6 *lang.Keyword = A_arbace_go_repl_A_const_58; var tmp7 any; var root_4081 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_4082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4081, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_4083 lang.IFn; if linked_4082 == nil { ifn_4083 = lang.IFn_Cast(root_4081) } else { ifn_4083 = nil }; var arg_4084 any = st__8; if linked_4082 == nil { tmp7 = ifn_4083.Invoke_O__O(arg_4084) } else { tmp7 = linked_4082.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_4081, arg_4084) }; arg_4079 = tmp6.Invoke_O__O(tmp7); var arg_4080 any; var tmp8 any = A_arbace_go_repl_declare_BANG__fn__794000437_A_New_O(form__0); var tmp9 *jrt.Class; var fncls__4092 *jrt.Class = A_arbace_go_repl_declare_BANG__fn__794000437_A_fn_class; if fncls__4092 == nil { var fncls__4092d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_go_repl_declare_BANG__fn__794000437_A_fn_class = fncls__4092d; tmp9 = fncls__4092d } else { tmp9 = fncls__4092 }; arg_4080 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); if linked_4076 == nil { ifn_4077.Invoke_O_O_O__O(arg_4078, arg_4079, arg_4080) } else { linked_4076.(*A_arbace_go_repl_update_file_A).Invoke_O_O_O_O__O(root_4075, arg_4078, arg_4079, arg_4080) }
//line :453:1
		return nil } else { var names__9 any; var root_3794 any = A_arbace_go_repl_A_const_17.GetRawRoot__O(); var linked_3795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3794, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_3796 lang.IFn

			if linked_3795 == nil { ifn_3796 = lang.IFn_Cast(root_3794) } else { ifn_3796 = nil }; var arg_3797 any; var root_3798 any = A_arbace_go_repl_A_const_236.GetRawRoot__O(); var linked_3799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3798, A_arbace_go_repl_decl_names_A_fn_class); var ifn_3800 lang.IFn; if linked_3799 == nil { ifn_3800 = lang.IFn_Cast(root_3798) } else { ifn_3800 = nil }; var arg_3801 any = form__0; if linked_3799 == nil { arg_3797 = ifn_3800.Invoke_O__O(arg_3801) } else { arg_3797 = linked_3799.(*A_arbace_go_repl_decl_names_A).Invoke_O_O__O(root_3798, arg_3801) }; if linked_3795 == nil { names__9 = ifn_3796.Invoke_O__O(arg_3797) } else { names__9 = linked_3795.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_3794, arg_3797) }
//line :453:1
			var old__10 any; var root_3802 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_3803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3802, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3804 lang.IFn

			if linked_3803 == nil { ifn_3804 = lang.IFn_Cast(root_3802) } else { ifn_3804 = nil }; var arg_3805 any = st__8; if linked_3803 == nil { old__10 = ifn_3804.Invoke_O__O(arg_3805) } else { old__10 = linked_3803.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3802, arg_3805) }
//line :453:1
			var files__11 any; var root_3806 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_3807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3806, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3808 lang.IFn




			if linked_3807 == nil { ifn_3808 = lang.IFn_Cast(root_3806) } else { ifn_3808 = nil }; var arg_3809 any; var iter__1927001039__auto____11 any; var tmp10 any = A_arbace_go_repl_declare_BANG__iter__794000439__794000443_A_New_O(names__9); var tmp11 *jrt.Class; var fncls__3920 *jrt.Class = A_arbace_go_repl_declare_BANG__iter__794000439__794000443_A_fn_class; if fncls__3920 == nil { var fncls__3920d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_go_repl_declare_BANG__iter__794000439__794000443_A_fn_class = fncls__3920d; tmp11 = fncls__3920d } else { tmp11 = fncls__3920 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); arg_3809 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(A_arbace_go_repl_A_const_57.Invoke_O__O(old__10)); if linked_3807 == nil { files__11 = ifn_3808.Invoke_O__O(arg_3809) } else { files__11 = linked_3807.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3806, arg_3809) }
//line :453:1
			var files__12 any; var tmp12 any; var root_3921 any = A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_3922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3921, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3923 lang.IFn






			if linked_3922 == nil { ifn_3923 = lang.IFn_Cast(root_3921) } else { ifn_3923 = nil }; var arg_3924 any; var tmp13 any = A_arbace_go_repl_declare_BANG__fn__794000457_A_New_O(old__10); var tmp14 *jrt.Class; var fncls__3926 *jrt.Class = A_arbace_go_repl_declare_BANG__fn__794000457_A_fn_class; if fncls__3926 == nil { var fncls__3926d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_go_repl_declare_BANG__fn__794000457_A_fn_class = fncls__3926d; tmp14 = fncls__3926d } else { tmp14 = fncls__3926 }; arg_3924 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var arg_3925 any = files__11; if linked_3922 == nil { tmp12 = ifn_3923.Invoke_O_O__O(arg_3924, arg_3925) } else { tmp12 = linked_3922.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3921, arg_3924, arg_3925) }; if jrt.J2g_Truth(tmp12) { files__12 = files__11 } else {

				var root_3927 any = A_arbace_go_repl_A_const_15.GetRawRoot__O(); var linked_3928 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3927, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_3929 lang.IFn; if linked_3928 == nil { ifn_3929 = lang.IFn_Cast(root_3927) } else { ifn_3929 = nil }; var arg_3930 any = files__11; var tmp15 any = A_arbace_go_repl_A_const_55; var arg_3931 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp15, A_arbace_go_repl_A_const_58.Invoke_O__O(old__10), A_arbace_go_repl_A_const_74, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_repl_A_const_81, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_repl_A_const_82, lang.PersistentVector_EMPTY.Ref())); if linked_3928 == nil { files__12 = ifn_3929.Invoke_O_O__O(arg_3930, arg_3931) } else { files__12 = linked_3928.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_3927, arg_3930, arg_3931) } }
//line :453:1
			var files__13 any; var root_3932 any = A_arbace_go_repl_A_const_80.GetRawRoot__O(); var linked_3933 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3932, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_3934 lang.IFn









			if linked_3933 == nil { ifn_3934 = lang.IFn_Cast(root_3932) } else { ifn_3934 = nil }; var arg_3935 any; var tmp16 any = A_arbace_go_repl_declare_BANG__fn__794000459_A_New_O_O(form__0, old__10); var tmp17 *jrt.Class; var fncls__3944 *jrt.Class = A_arbace_go_repl_declare_BANG__fn__794000459_A_fn_class; if fncls__3944 == nil { var fncls__3944d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_go_repl_declare_BANG__fn__794000459_A_fn_class = fncls__3944d; tmp17 = fncls__3944d } else { tmp17 = fncls__3944 }; arg_3935 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var arg_3936 any = files__12; if linked_3933 == nil { files__13 = ifn_3934.Invoke_O_O__O(arg_3935, arg_3936) } else { files__13 = linked_3933.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_3932, arg_3935, arg_3936) }
//line :453:1
			var ___14 any; var root_3945 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_3946 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3945, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3947 lang.IFn; _ = ___14










			if linked_3946 == nil { ifn_3947 = lang.IFn_Cast(root_3945) } else { ifn_3947 = nil }; var arg_3948 any = st__8; var arg_3949 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_3950 any = A_arbace_go_repl_A_const_57; var arg_3951 any = files__13; if linked_3946 == nil { ___14 = ifn_3947.Invoke_O_O_O_O__O(arg_3948, arg_3949, arg_3950, arg_3951) } else { ___14 = linked_3946.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_3945, arg_3948, arg_3949, arg_3950, arg_3951) }
//line :453:1
			var r__15 any; var tmp18 any = A_arbace_go_repl_declare_BANG__fn__794000461_A_New_O_O(st__8, old__10); var tmp19 *jrt.Class
			var fncls__3968 /*line :453:1*/*jrt.Class = A_arbace_go_repl_declare_BANG__fn__794000461_A_fn_class











			if fncls__3968 == nil { var fncls__3968d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_go_repl_declare_BANG__fn__794000461_A_fn_class = fncls__3968d; tmp19 = fncls__3968d } else { tmp19 = fncls__3968 }; r__15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil).Invoke__O()
//line :453:1
			var errs__16 any; var root_3969 any = A_arbace_go_repl_A_const_237.GetRawRoot__O(); var linked_3970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3969, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3971 lang.IFn













			if linked_3970 == nil { ifn_3971 = lang.IFn_Cast(root_3969) } else { ifn_3971 = nil }; var arg_3972 any; var tmp20 any = A_arbace_go_repl_declare_BANG__fn__794000463_A_New(); var tmp21 *jrt.Class; var fncls__3974 *jrt.Class = A_arbace_go_repl_declare_BANG__fn__794000463_A_fn_class; if fncls__3974 == nil { var fncls__3974d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_go_repl_declare_BANG__fn__794000463_A_fn_class = fncls__3974d; tmp21 = fncls__3974d } else { tmp21 = fncls__3974 }; arg_3972 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil); var arg_3973 any = A_arbace_go_repl_A_const_228.Invoke_O__O(r__15); if linked_3970 == nil { errs__16 = ifn_3971.Invoke_O_O__O(arg_3972, arg_3973) } else { errs__16 = linked_3970.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3969, arg_3972, arg_3973) }
//line :453:1
			var spec_of__17 any; var root_3975 any = A_arbace_go_repl_A_const_88.GetRawRoot__O(); var linked_3976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3975, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3977 lang.IFn
















			if linked_3976 == nil { ifn_3977 = lang.IFn_Cast(root_3975) } else { ifn_3977 = nil }; var arg_3978 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_3979 any; var root_3980 any = A_arbace_go_repl_A_const_102.GetRawRoot__O(); var linked_3981 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3980, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3982 lang.IFn; if linked_3981 == nil { ifn_3982 = lang.IFn_Cast(root_3980) } else { ifn_3982 = nil }; var arg_3983 any; var root_3985 any = A_arbace_go_repl_A_const_240.GetRawRoot__O(); var linked_3986 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3985, aot_arbace_core.A_arbace_core_juxt_A_fn_class); var ifn_3987 lang.IFn; if linked_3986 == nil { ifn_3987 = lang.IFn_Cast(root_3985) } else { ifn_3987 = nil }; var arg_3988 any = A_arbace_go_repl_A_const_241; var arg_3989 any = A_arbace_go_repl_A_const_216; if linked_3986 == nil { arg_3983 = ifn_3987.Invoke_O_O__O(arg_3988, arg_3989) } else { arg_3983 = linked_3986.(*aot_arbace_core.A_arbace_core_juxt_A).Invoke_O_O_O__O(root_3985, arg_3988, arg_3989) }; var arg_3984 any = A_arbace_go_repl_A_const_175.Invoke_O__O(r__15); if linked_3981 == nil { arg_3979 = ifn_3982.Invoke_O_O__O(arg_3983, arg_3984) } else { arg_3979 = linked_3981.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3980, arg_3983, arg_3984) }; if linked_3976 == nil { spec_of__17 = ifn_3977.Invoke_O_O__O(arg_3978, arg_3979) } else { spec_of__17 = linked_3976.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3975, arg_3978, arg_3979) }
//line :453:1
			var own_QMARK___18 any; var tmp22 any = A_arbace_go_repl_declare_BANG__own_QMARK___794000465_A_New_O_O(form__0, spec_of__17); var tmp23 *jrt.Class
			var fncls__3990 /*line :453:1*/*jrt.Class = A_arbace_go_repl_declare_BANG__own_QMARK___794000465_A_fn_class

















			if fncls__3990 == nil { var fncls__3990d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_go_repl_declare_BANG__own_QMARK___794000465_A_fn_class = fncls__3990d; tmp23 = fncls__3990d } else { tmp23 = fncls__3990 }; own_QMARK___18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil)
//line :453:1
			var own__19 any; var root_3991 any = A_arbace_go_repl_A_const_33.GetRawRoot__O(); var linked_3992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3991, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3993 lang.IFn


















			if linked_3992 == nil { ifn_3993 = lang.IFn_Cast(root_3991) } else { ifn_3993 = nil }; var arg_3994 any = own_QMARK___18; var arg_3995 any = errs__16; if linked_3992 == nil { own__19 = ifn_3993.Invoke_O_O__O(arg_3994, arg_3995) } else { own__19 = linked_3992.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3991, arg_3994, arg_3995) }
//line :453:1
			var others__20 any; var root_3996 any = A_arbace_go_repl_A_const_237.GetRawRoot__O(); var linked_3997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3996, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3998 lang.IFn



















			if linked_3997 == nil { ifn_3998 = lang.IFn_Cast(root_3996) } else { ifn_3998 = nil }; var arg_3999 any = own_QMARK___18; var arg_4000 any = errs__16; if linked_3997 == nil { others__20 = ifn_3998.Invoke_O_O__O(arg_3999, arg_4000) } else { others__20 = linked_3997.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3996, arg_3999, arg_4000) }
//line :453:1
			var broken__21 any; var root_4001 any = A_arbace_go_repl_A_const_17.GetRawRoot__O(); var linked_4002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4001, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_4003 lang.IFn




















			if linked_4002 == nil { ifn_4003 = lang.IFn_Cast(root_4001) } else { ifn_4003 = nil }; var arg_4004 any; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_243.GetRawRoot__O()); var tmp25 any = A_arbace_go_repl_A_const_236.GetRawRoot__O(); var tmp26 any; var root_4010 any = A_arbace_go_repl_A_const_87.GetRawRoot__O(); var linked_4011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4010, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_4012 lang.IFn; if linked_4011 == nil { ifn_4012 = lang.IFn_Cast(root_4010) } else { ifn_4012 = nil }; var arg_4013 any; var root_4014 any = A_arbace_go_repl_A_const_194.GetRawRoot__O(); var linked_4015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4014, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_4016 lang.IFn; if linked_4015 == nil { ifn_4016 = lang.IFn_Cast(root_4014) } else { ifn_4016 = nil }; var arg_4017 any; var tmp27 any = A_arbace_go_repl_declare_BANG__fn__794000467_A_New_O(spec_of__17); var tmp28 *jrt.Class; var fncls__4019 *jrt.Class = A_arbace_go_repl_declare_BANG__fn__794000467_A_fn_class; if fncls__4019 == nil { var fncls__4019d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_go_repl_declare_BANG__fn__794000467_A_fn_class = fncls__4019d; tmp28 = fncls__4019d } else { tmp28 = fncls__4019 }; arg_4017 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil); var arg_4018 any = others__20; if linked_4015 == nil { arg_4013 = ifn_4016.Invoke_O_O__O(arg_4017, arg_4018) } else { arg_4013 = linked_4015.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_4014, arg_4017, arg_4018) }; if linked_4011 == nil { tmp26 = ifn_4012.Invoke_O__O(arg_4013) } else { tmp26 = linked_4011.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_4010, arg_4013) }; arg_4004 = tmp24.Invoke_O_O__O(tmp25, tmp26); if linked_4002 == nil { broken__21 = ifn_4003.Invoke_O__O(arg_4004) } else { broken__21 = linked_4002.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_4001, arg_4004) }
			var tmp29 any; var root_4093 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_4094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4093, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4095 lang.IFn; if linked_4094 == nil { ifn_4095 = lang.IFn_Cast(root_4093) } else { ifn_4095 = nil }; var arg_4096 any = own__19; if linked_4094 == nil { tmp29 = ifn_4095.Invoke_O__O(arg_4096) } else { tmp29 = linked_4094.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4093, arg_4096) }; if jrt.J2g_Truth(tmp29) {
				var root_4143 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_4144 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4143, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_4145 lang.IFn; if linked_4144 == nil { ifn_4145 = lang.IFn_Cast(root_4143) } else { ifn_4145 = nil }; var arg_4146 any = st__8; var arg_4147 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_4148 any = A_arbace_go_repl_A_const_57; var arg_4149 any = A_arbace_go_repl_A_const_57.Invoke_O__O(old__10); if linked_4144 == nil { ifn_4145.Invoke_O_O_O_O__O(arg_4146, arg_4147, arg_4148, arg_4149) } else { linked_4144.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_4143, arg_4146, arg_4147, arg_4148, arg_4149) }
//line :475:1
				var tmp30 any; var root_4097 any = A_arbace_go_repl_A_const_69.GetRawRoot__O(); var linked_4098 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4097, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_4099 lang.IFn

				if linked_4098 == nil { ifn_4099 = lang.IFn_Cast(root_4097) } else { ifn_4099 = nil }; var arg_4100 any; var tmp31 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_48, nil); var tmp32 any; var root_4102 any = A_arbace_go_repl_A_const_115.GetRawRoot__O(); var linked_4103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4102, A_arbace_go_repl_error_text_A_fn_class); var ifn_4104 lang.IFn; if linked_4103 == nil { ifn_4104 = lang.IFn_Cast(root_4102) } else { ifn_4104 = nil }; var arg_4105 any = own__19; var arg_4106 any; var root_4107 any = A_arbace_go_repl_A_const_245.GetRawRoot__O(); var linked_4108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4107, A_arbace_go_repl_repl_source_A_fn_class); var ifn_4109 lang.IFn; if linked_4108 == nil { ifn_4109 = lang.IFn_Cast(root_4107) } else { ifn_4109 = nil }; if linked_4108 == nil { arg_4106 = ifn_4109.Invoke__O() } else { arg_4106 = linked_4108.(*A_arbace_go_repl_repl_source_A).Invoke_O__O(root_4107) }; if linked_4103 == nil { tmp32 = ifn_4104.Invoke_O_O__O(arg_4105, arg_4106) } else { tmp32 = linked_4103.(*A_arbace_go_repl_error_text_A).Invoke_O_O_O__O(root_4102, arg_4105, arg_4106) }; arg_4100 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp31, jrt.RefArrayOf(jrt.Object_class, nil, tmp32)).Ref(); var arg_4101 any; var tmp33 any = A_arbace_go_repl_A_const_229; var tmp34 any; var root_4110 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_4111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4110, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_4112 lang.IFn; if linked_4111 == nil { ifn_4112 = lang.IFn_Cast(root_4110) } else { ifn_4112 = nil }; var arg_4113 any = own__19; if linked_4111 == nil { tmp34 = ifn_4112.Invoke_O__O(arg_4113) } else { tmp34 = linked_4111.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_4110, arg_4113) }; arg_4101 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp33, tmp34)); if linked_4098 == nil { tmp30 = ifn_4099.Invoke_O_O__O(arg_4100, arg_4101) } else { tmp30 = linked_4098.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_4097, arg_4100, arg_4101) }
//line :475:1
				panic(jrt.Thrown(jrt.Throwable_Cast(tmp30)))
			}

			var tmp35 any; var root_4114 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_4115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4114, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4116 lang.IFn; if linked_4115 == nil { ifn_4116 = lang.IFn_Cast(root_4114) } else { ifn_4116 = nil }; var arg_4117 any = others__20; if linked_4115 == nil { tmp35 = ifn_4116.Invoke_O__O(arg_4117) } else { tmp35 = linked_4115.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4114, arg_4117) }; if jrt.J2g_Truth(tmp35) {
				var root_4150 any = A_arbace_go_repl_A_const_202.GetRawRoot__O(); var linked_4151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4150, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_4152 lang.IFn; if linked_4151 == nil { ifn_4152 = lang.IFn_Cast(root_4150) } else { ifn_4152 = nil }; var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_38.GetRawRoot__O()); var tmp37 any = A_arbace_go_repl_A_const_248; var arg_4153 any = tmp36.Invoke_O_O__O(tmp37, A_arbace_go_repl_A_const_249.Get__O()); if linked_4151 == nil { ifn_4152.Invoke_O__O(arg_4153) } else { linked_4151.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_4150, arg_4153) }; var tmp38 any = A_arbace_go_repl_declare_BANG__fn__794000469_A_New_O_O(broken__21, others__20); var tmp39 *jrt.Class; var fncls__4142 *jrt.Class = A_arbace_go_repl_declare_BANG__fn__794000469_A_fn_class; if fncls__4142 == nil { var fncls__4142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_go_repl_declare_BANG__fn__794000469_A_fn_class = fncls__4142d; tmp39 = fncls__4142d } else { tmp39 = fncls__4142 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp38, tmp39, nil).Invoke__O() }
//line :453:1
			var var_QMARK___22 bool; var tmp40 any; var root_4020 any = A_arbace_go_repl_A_const_89.GetRawRoot__O(); var linked_4021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4020, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_4022 lang.IFn




























			if linked_4021 == nil { ifn_4022 = lang.IFn_Cast(root_4020) } else { ifn_4022 = nil }; var arg_4023 any = form__0; if linked_4021 == nil { tmp40 = ifn_4022.Invoke_O__O(arg_4023) } else { tmp40 = linked_4021.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_4020, arg_4023) }; var_QMARK___22 = lang.Util_Equiv_O_O__Z_NoInit(Lit_26, tmp40)
//line :453:1
			var map__794000471__23 any; var tmp41 any = A_arbace_go_repl_declare_BANG__fn__794000473_A_New_O_Z_O_O_O_O(broken__21, var_QMARK___22, r__15, st__8, old__10, names__9); var tmp42 *jrt.Class
			var fncls__4037 /*line :453:1*/*jrt.Class = A_arbace_go_repl_declare_BANG__fn__794000473_A_fn_class





























			if fncls__4037 == nil { var fncls__4037d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_go_repl_declare_BANG__fn__794000473_A_fn_class = fncls__4037d; tmp42 = fncls__4037d } else { tmp42 = fncls__4037 }; map__794000471__23 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp41, tmp42, nil).Invoke__O()
//line :453:1
			var map__794000471__24 any




























			if lang.ISeq_InstanceOf(map__794000471__23) { var tmp43 any; var root_4038 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_4039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4038, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4040 lang.IFn; if linked_4039 == nil { ifn_4040 = lang.IFn_Cast(root_4038) } else { ifn_4040 = nil }; var arg_4041 any = map__794000471__23; if linked_4039 == nil { tmp43 = ifn_4040.Invoke_O__O(arg_4041) } else { tmp43 = linked_4039.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4038, arg_4041) }; if jrt.J2g_Truth(tmp43) { var tmp44 any; var root_4042 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_4043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4042, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_4044 lang.IFn; if linked_4043 == nil { ifn_4044 = lang.IFn_Cast(root_4042) } else { ifn_4044 = nil }; var arg_4045 any = map__794000471__23; if linked_4043 == nil { tmp44 = ifn_4044.Invoke_O__O(arg_4045) } else { tmp44 = linked_4043.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_4042, arg_4045) }; map__794000471__24 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp44, jrt.Object_class.ArrayClass())).Ref() } else { var tmp45 any; var root_4046 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_4047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4046, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4048 lang.IFn; if linked_4047 == nil { ifn_4048 = lang.IFn_Cast(root_4046) } else { ifn_4048 = nil }; var arg_4049 any = map__794000471__23; if linked_4047 == nil { tmp45 = ifn_4048.Invoke_O__O(arg_4049) } else { tmp45 = linked_4047.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4046, arg_4049) }; if jrt.J2g_Truth(tmp45) { var root_4050 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_4051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4050, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4052 lang.IFn; if linked_4051 == nil { ifn_4052 = lang.IFn_Cast(root_4050) } else { ifn_4052 = nil }; var arg_4053 any = map__794000471__23; if linked_4051 == nil { map__794000471__24 = ifn_4052.Invoke_O__O(arg_4053) } else { map__794000471__24 = linked_4051.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4050, arg_4053) } } else { map__794000471__24 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000471__24 = map__794000471__23 }
//line :453:1
			var inits__25 any = lang.RT_Get_O_O__O_NoInit(map__794000471__24, A_arbace_go_repl_A_const_186); var new_vars__26 any = lang.RT_Get_O_O__O_NoInit(map__794000471__24, A_arbace_go_repl_A_const_199); var init_funcs__27 any = lang.RT_Get_O_O__O_NoInit(map__794000471__24, A_arbace_go_repl_A_const_196); _ = new_vars__26


































			if var_QMARK___22 {
				var root_4159 any = A_arbace_go_repl_A_const_230.GetRawRoot__O(); var linked_4160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4159, A_arbace_go_repl_call0_A_fn_class); var ifn_4161 lang.IFn; if linked_4160 == nil { ifn_4161 = lang.IFn_Cast(root_4159) } else { ifn_4161 = nil }; var arg_4162 any = inits__25; var arg_4163 any = Lit_17; if linked_4160 == nil { ifn_4161.Invoke_O_O__O(arg_4162, arg_4163) } else { linked_4160.(*A_arbace_go_repl_call0_A).Invoke_O_O_O__O(root_4159, arg_4162, arg_4163) } }
			var tmp46 bool; var and__1927000168__auto____28 bool; var tmp47 any; var root_4164 any = A_arbace_go_repl_A_const_89.GetRawRoot__O(); var linked_4165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4164, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_4166 lang.IFn; if linked_4165 == nil { ifn_4166 = lang.IFn_Cast(root_4164) } else { ifn_4166 = nil }; var arg_4167 any = form__0; if linked_4165 == nil { tmp47 = ifn_4166.Invoke_O__O(arg_4167) } else { tmp47 = linked_4165.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_4164, arg_4167) }; and__1927000168__auto____28 = lang.Util_Equiv_O_O__Z_NoInit(Lit_23, tmp47); if and__1927000168__auto____28 { var tmp48 any; var root_4168 any = A_arbace_go_repl_A_const_73.GetRawRoot__O(); var linked_4169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4168, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_4170 lang.IFn; if linked_4169 == nil { ifn_4170 = lang.IFn_Cast(root_4168) } else { ifn_4170 = nil }; var arg_4171 any; var root_4172 any = A_arbace_go_repl_A_const_103.GetRawRoot__O(); var linked_4173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4172, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_4174 lang.IFn; if linked_4173 == nil { ifn_4174 = lang.IFn_Cast(root_4172) } else { ifn_4174 = nil }; var arg_4175 any = form__0; if linked_4173 == nil { arg_4171 = ifn_4174.Invoke_O__O(arg_4175) } else { arg_4171 = linked_4173.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_4172, arg_4175) }; if linked_4169 == nil { tmp48 = ifn_4170.Invoke_O__O(arg_4171) } else { tmp48 = linked_4169.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_4168, arg_4171) }; tmp46 = lang.Util_Equiv_O_O__Z_NoInit(Lit_17, tmp48) } else { tmp46 = and__1927000168__auto____28 }; if tmp46 {
				var root_4176 any = A_arbace_go_repl_A_const_230.GetRawRoot__O(); var linked_4177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4176, A_arbace_go_repl_call0_A_fn_class); var ifn_4178 lang.IFn; if linked_4177 == nil { ifn_4178 = lang.IFn_Cast(root_4176) } else { ifn_4178 = nil }; var arg_4179 any; var root_4181 any = A_arbace_go_repl_A_const_66.GetRawRoot__O(); var linked_4182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4181, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_4183 lang.IFn; if linked_4182 == nil { ifn_4183 = lang.IFn_Cast(root_4181) } else { ifn_4183 = nil }; var arg_4184 any = init_funcs__27; if linked_4182 == nil { arg_4179 = ifn_4183.Invoke_O__O(arg_4184) } else { arg_4179 = linked_4182.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_4181, arg_4184) }; var arg_4180 any = Lit_17; if linked_4177 == nil { ifn_4178.Invoke_O_O__O(arg_4179, arg_4180) } else { linked_4177.(*A_arbace_go_repl_call0_A).Invoke_O_O_O__O(root_4176, arg_4179, arg_4180) } }
//line :453:1
			var temp__1927000414__auto____28 any; var root_4054 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_4055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4054, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4056 lang.IFn






































			if linked_4055 == nil { ifn_4056 = lang.IFn_Cast(root_4054) } else { ifn_4056 = nil }; var arg_4057 any; var root_4058 any = A_arbace_go_repl_A_const_236.GetRawRoot__O(); var linked_4059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4058, A_arbace_go_repl_decl_names_A_fn_class); var ifn_4060 lang.IFn; if linked_4059 == nil { ifn_4060 = lang.IFn_Cast(root_4058) } else { ifn_4060 = nil }; var arg_4061 any = form__0; if linked_4059 == nil { arg_4057 = ifn_4060.Invoke_O__O(arg_4061) } else { arg_4057 = linked_4059.(*A_arbace_go_repl_decl_names_A).Invoke_O_O__O(root_4058, arg_4061) }; if linked_4055 == nil { temp__1927000414__auto____28 = ifn_4056.Invoke_O__O(arg_4057) } else { temp__1927000414__auto____28 = linked_4055.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4054, arg_4057) }; if jrt.J2g_Truth(temp__1927000414__auto____28) { var nm__29 any = temp__1927000414__auto____28; var root_4062 any = A_arbace_go_repl_A_const_244.GetRawRoot__O(); var linked_4063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4062, aot_arbace_core.A_arbace_core_find_var_A_fn_class); var ifn_4064 lang.IFn
				if linked_4063 == nil { ifn_4064 = lang.IFn_Cast(root_4062) } else { ifn_4064 = nil }; var arg_4065 any; var root_4066 any = A_arbace_go_repl_A_const_46.GetRawRoot__O(); var linked_4067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4066, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_4068 lang.IFn; if linked_4067 == nil { ifn_4068 = lang.IFn_Cast(root_4066) } else { ifn_4068 = nil }; var arg_4069 any; var root_4071 any = A_arbace_go_repl_A_const_51.GetRawRoot__O(); var linked_4072 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4071, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_4073 lang.IFn; if linked_4072 == nil { ifn_4073 = lang.IFn_Cast(root_4071) } else { ifn_4073 = nil }; var arg_4074 any = A_arbace_go_repl_A_const_56.Invoke_O__O(old__10); if linked_4072 == nil { arg_4069 = ifn_4073.Invoke_O__O(arg_4074) } else { arg_4069 = linked_4072.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_4071, arg_4074) }; var arg_4070 any = nm__29; if linked_4067 == nil { arg_4065 = ifn_4068.Invoke_O_O__O(arg_4069, arg_4070) } else { arg_4065 = linked_4067.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_4066, arg_4069, arg_4070) }; if linked_4063 == nil { return ifn_4064.Invoke_O__O(arg_4065) } else { return linked_4063.(*aot_arbace_core.A_arbace_core_find_var_A).Invoke_O_O__O(root_4062, arg_4065) } } else {
//line :492:1
					return nil } } }
//line :454:1
func A_arbace_go_repl_declare_BANG__fn__794000437_A_New_O(p0 any) *A_arbace_go_repl_declare_BANG__fn__794000437_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__fn__794000437_A{}; t.Ctor_O(p0); return t }
//line :454:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000437_A) Ctor_O(c__form any) { t.F_form = c__form }
//line :454:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000437_A) Invoke_O_O__O(self, p1__794000428_SHARP___1 any) any { var root_4085 any = A_arbace_go_repl_A_const_79.GetRawRoot__O(); var linked_4086 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4085, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_4087 lang.IFn; if linked_4086 == nil { ifn_4087 = lang.IFn_Cast(root_4085) } else { ifn_4087 = nil }; var arg_4088 any = p1__794000428_SHARP___1; var arg_4089 any = A_arbace_go_repl_A_const_82; var arg_4090 any = A_arbace_go_repl_A_const_15.GetRawRoot__O(); var arg_4091 any = t.F_form; if linked_4086 == nil { return ifn_4087.Invoke_O_O_O_O__O(arg_4088, arg_4089, arg_4090, arg_4091) } else { return linked_4086.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_4085, arg_4088, arg_4089, arg_4090, arg_4091) } }



func A_arbace_go_repl_declare_BANG__iter__794000439__794000443_A_New_O(p0 any) *A_arbace_go_repl_declare_BANG__iter__794000439__794000443_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__iter__794000439__794000443_A{}; t.Ctor_O(p0); return t }
//line :458:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000439__794000443_A) Ctor_O(c__names any) { t.F_names = c__names }
//line :458:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000439__794000443_A) Invoke_O_O__O(self, s__794000440__1 any) any { var tmp1 any = A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_A_New_O_O_O(self, s__794000440__1, t.F_names); var tmp2 *jrt.Class; var fncls__3919 *jrt.Class = A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_A_fn_class; if fncls__3919 == nil { var fncls__3919d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_A_fn_class = fncls__3919d; tmp2 = fncls__3919d } else { tmp2 = fncls__3919 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :458:1
func A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :458:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_A) Ctor_O_O_O(c__iter__794000439, c__s__794000440, c__names any) { t.F_iter__794000439 = c__iter__794000439; t.F_s__794000440 = c__s__794000440; t.F_names = c__names }
//line :458:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_A) Invoke_O__O(self any) any { { var s__794000440__1 any; var t_ any = t.F_s__794000440; t.F_s__794000440 = nil; s__794000440__1 = t_; for { var temp__1927000414__auto____2 any; var root_3810 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_3811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3810, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3812 lang.IFn; if linked_3811 == nil { ifn_3812 = lang.IFn_Cast(root_3810) } else { ifn_3812 = nil }; var arg_3813 any = s__794000440__1; if linked_3811 == nil { temp__1927000414__auto____2 = ifn_3812.Invoke_O__O(arg_3813) } else { temp__1927000414__auto____2 = linked_3811.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3810, arg_3813) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__794000440__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3814 any = A_arbace_go_repl_A_const_93.GetRawRoot__O(); var linked_3815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3814, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3816 lang.IFn; if linked_3815 == nil { ifn_3816 = lang.IFn_Cast(root_3814) } else { ifn_3816 = nil }; var arg_3817 any = s__794000440__3; if linked_3815 == nil { tmp1 = ifn_3816.Invoke_O__O(arg_3817) } else { tmp1 = linked_3815.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3814, arg_3817) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3818 any = A_arbace_go_repl_A_const_94.GetRawRoot__O(); var linked_3819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3818, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3820 lang.IFn; if linked_3819 == nil { ifn_3820 = lang.IFn_Cast(root_3818) } else { ifn_3820 = nil }; var arg_3821 any = s__794000440__3; if linked_3819 == nil { c__1927001037__auto____4 = ifn_3820.Invoke_O__O(arg_3821) } else { c__1927001037__auto____4 = linked_3819.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3818, arg_3821) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__794000442__6 any; var root_3822 any = A_arbace_go_repl_A_const_95.GetRawRoot__O(); var linked_3823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3822, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3824 lang.IFn; if linked_3823 == nil { ifn_3824 = lang.IFn_Cast(root_3822) } else { ifn_3824 = nil }; var arg_3825 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3823 == nil { b__794000442__6 = ifn_3824.Invoke_O__O(arg_3825) } else { b__794000442__6 = linked_3823.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3822, arg_3825) }; var tmp2 any = A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_A_New_O_I_O_O(b__794000442__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_names); var tmp3 *jrt.Class; var fncls__3857 *jrt.Class = A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_A_fn_class; if fncls__3857 == nil { var fncls__3857d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_A_fn_class = fncls__3857d; tmp3 = fncls__3857d } else { tmp3 = fncls__3857 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3858 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_3859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3858, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3860 lang.IFn; if linked_3859 == nil { ifn_3860 = lang.IFn_Cast(root_3858) } else { ifn_3860 = nil }; var arg_3861 any; var root_3863 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_3864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3863, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3865 lang.IFn; if linked_3864 == nil { ifn_3865 = lang.IFn_Cast(root_3863) } else { ifn_3865 = nil }; var arg_3866 any = b__794000442__6; if linked_3864 == nil { arg_3861 = ifn_3865.Invoke_O__O(arg_3866) } else { arg_3861 = linked_3864.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3863, arg_3866) }; var arg_3862 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__794000439); var tmp5 any; var root_3867 any = A_arbace_go_repl_A_const_99.GetRawRoot__O(); var linked_3868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3867, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3869 lang.IFn; if linked_3868 == nil { ifn_3869 = lang.IFn_Cast(root_3867) } else { ifn_3869 = nil }; var arg_3870 any = s__794000440__3; if linked_3868 == nil { tmp5 = ifn_3869.Invoke_O__O(arg_3870) } else { tmp5 = linked_3868.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3867, arg_3870) }; arg_3862 = tmp4.Invoke_O__O(tmp5); if linked_3859 == nil { return ifn_3860.Invoke_O_O__O(arg_3861, arg_3862) } else { return linked_3859.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3858, arg_3861, arg_3862) } } else { var root_3871 any = A_arbace_go_repl_A_const_97.GetRawRoot__O(); var linked_3872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3871, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3873 lang.IFn; if linked_3872 == nil { ifn_3873 = lang.IFn_Cast(root_3871) } else { ifn_3873 = nil }; var arg_3874 any; var root_3876 any = A_arbace_go_repl_A_const_98.GetRawRoot__O(); var linked_3877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3876, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3878 lang.IFn; if linked_3877 == nil { ifn_3878 = lang.IFn_Cast(root_3876) } else { ifn_3878 = nil }; var arg_3879 any = b__794000442__6; if linked_3877 == nil { arg_3874 = ifn_3878.Invoke_O__O(arg_3879) } else { arg_3874 = linked_3877.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3876, arg_3879) }; var arg_3875 any; if linked_3872 == nil { return ifn_3873.Invoke_O_O__O(arg_3874, arg_3875) } else { return linked_3872.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3871, arg_3874, arg_3875) } } } else { var fi__4 any; var root_3880 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_3881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3880, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3882 lang.IFn; if linked_3881 == nil { ifn_3882 = lang.IFn_Cast(root_3880) } else { ifn_3882 = nil }; var arg_3883 any = s__794000440__3; if linked_3881 == nil { fi__4 = ifn_3882.Invoke_O__O(arg_3883) } else { fi__4 = linked_3881.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3880, arg_3883) }; var root_3884 any = A_arbace_go_repl_A_const_100.GetRawRoot__O(); var linked_3885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3884, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3886 lang.IFn; if linked_3885 == nil { ifn_3886 = lang.IFn_Cast(root_3884) } else { ifn_3886 = nil }; var arg_3887 any; var root_3889 any = A_arbace_go_repl_A_const_79.GetRawRoot__O(); var linked_3890 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3889, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_3891 lang.IFn
														if linked_3890 == nil { ifn_3891 = lang.IFn_Cast(root_3889) } else { ifn_3891 = nil }; var arg_3892 any = fi__4; var arg_3893 any = A_arbace_go_repl_A_const_82; var arg_3894 any; var tmp6 any = A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000451_A_New_O(t.F_names); var tmp7 *jrt.Class; var fncls__3914 *jrt.Class = A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000451_A_fn_class; if fncls__3914 == nil { var fncls__3914d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000451_A_fn_class = fncls__3914d; tmp7 = fncls__3914d } else { tmp7 = fncls__3914 }; arg_3894 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_3890 == nil { arg_3887 = ifn_3891.Invoke_O_O_O__O(arg_3892, arg_3893, arg_3894) } else { arg_3887 = linked_3890.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_3889, arg_3892, arg_3893, arg_3894) }
//line :458:1
	var arg_3888 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__794000439); var tmp9 any; var root_3915 any = A_arbace_go_repl_A_const_49.GetRawRoot__O(); var linked_3916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3915, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3917 lang.IFn; if linked_3916 == nil { ifn_3917 = lang.IFn_Cast(root_3915) } else { ifn_3917 = nil }; var arg_3918 any = s__794000440__3; if linked_3916 == nil { tmp9 = ifn_3917.Invoke_O__O(arg_3918) } else { tmp9 = linked_3916.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3915, arg_3918) }; arg_3888 = tmp8.Invoke_O__O(tmp9); if linked_3885 == nil { return ifn_3886.Invoke_O_O__O(arg_3887, arg_3888) } else { return linked_3885.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3884, arg_3887, arg_3888) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :458:1
func A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :458:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_A) Ctor_O_I_O_O(c__b__794000442 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__names any) { t.F_b__794000442 = c__b__794000442; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_names = c__names }
//line :458:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_A) Invoke_O__O(self any) any { { var i__794000441__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__794000441__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fi__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__794000441__1)); var root_3826 any = A_arbace_go_repl_A_const_96.GetRawRoot__O(); var linked_3827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3826, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3828 lang.IFn; if linked_3827 == nil { ifn_3828 = lang.IFn_Cast(root_3826) } else { ifn_3828 = nil }; var arg_3829 any = t.F_b__794000442; var arg_3830 any; var root_3831 any = A_arbace_go_repl_A_const_79.GetRawRoot__O(); var linked_3832 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3831, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_3833 lang.IFn
																if linked_3832 == nil { ifn_3833 = lang.IFn_Cast(root_3831) } else { ifn_3833 = nil }; var arg_3834 any = fi__2; var arg_3835 any = A_arbace_go_repl_A_const_82; var arg_3836 any; var tmp2 any = A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_fn__794000446_A_New_O(t.F_names); var tmp3 *jrt.Class; var fncls__3856 *jrt.Class = A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_fn__794000446_A_fn_class; if fncls__3856 == nil { var fncls__3856d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_fn__794000446_A_fn_class = fncls__3856d; tmp3 = fncls__3856d } else { tmp3 = fncls__3856 }; arg_3836 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); if linked_3832 == nil { arg_3830 = ifn_3833.Invoke_O_O_O__O(arg_3834, arg_3835, arg_3836) } else { arg_3830 = linked_3832.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_3831, arg_3834, arg_3835, arg_3836) }
//line :458:1
	if linked_3827 == nil { ifn_3828.Invoke_O_O__O(arg_3829, arg_3830) } else { linked_3827.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3826, arg_3829, arg_3830) }; i__794000441__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__794000441__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_fn__794000446_A_New_O(p0 any) *A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_fn__794000446_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_fn__794000446_A{}; t.Ctor_O(p0); return t }
//line :459:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_fn__794000446_A) Ctor_O(c__names any) { t.F_names = c__names }
//line :459:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_fn__794000446_A) Invoke_O_O__O(self, ds__1 any) any { var root_3837 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_3838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3837, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3839 lang.IFn; if linked_3838 == nil { ifn_3839 = lang.IFn_Cast(root_3837) } else { ifn_3839 = nil }; var arg_3840 any; var root_3841 any = A_arbace_go_repl_A_const_237.GetRawRoot__O(); var linked_3842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3841, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3843 lang.IFn; if linked_3842 == nil { ifn_3843 = lang.IFn_Cast(root_3841) } else { ifn_3843 = nil }; var arg_3844 any; var tmp1 any = A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_fn__794000446_fn__794000447_A_New_O(t.F_names); var tmp2 *jrt.Class; var fncls__3855 *jrt.Class = A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_fn__794000446_fn__794000447_A_fn_class; if fncls__3855 == nil { var fncls__3855d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_fn__794000446_fn__794000447_A_fn_class = fncls__3855d; tmp2 = fncls__3855d } else { tmp2 = fncls__3855 }; arg_3844 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_3845 any = ds__1; if linked_3842 == nil { arg_3840 = ifn_3843.Invoke_O_O__O(arg_3844, arg_3845) } else { arg_3840 = linked_3842.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3841, arg_3844, arg_3845) }; if linked_3838 == nil { return ifn_3839.Invoke_O__O(arg_3840) } else { return linked_3838.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3837, arg_3840) } }
//line :459:1
func A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_fn__794000446_fn__794000447_A_New_O(p0 any) *A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_fn__794000446_fn__794000447_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_fn__794000446_fn__794000447_A{}; t.Ctor_O(p0); return t }
//line :459:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_fn__794000446_fn__794000447_A) Ctor_O(c__names any) { t.F_names = c__names }
//line :459:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_fn__794000446_fn__794000447_A) Invoke_O_O__O(self, p1__794000429_SHARP___1 any) any { var root_3846 any = A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_3847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3846, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3848 lang.IFn; if linked_3847 == nil { ifn_3848 = lang.IFn_Cast(root_3846) } else { ifn_3848 = nil }; var arg_3849 any = t.F_names; var arg_3850 any; var root_3851 any = A_arbace_go_repl_A_const_236.GetRawRoot__O(); var linked_3852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3851, A_arbace_go_repl_decl_names_A_fn_class); var ifn_3853 lang.IFn; if linked_3852 == nil { ifn_3853 = lang.IFn_Cast(root_3851) } else { ifn_3853 = nil }; var arg_3854 any = p1__794000429_SHARP___1; if linked_3852 == nil { arg_3850 = ifn_3853.Invoke_O__O(arg_3854) } else { arg_3850 = linked_3852.(*A_arbace_go_repl_decl_names_A).Invoke_O_O__O(root_3851, arg_3854) }; if linked_3847 == nil { return ifn_3848.Invoke_O_O__O(arg_3849, arg_3850) } else { return linked_3847.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3846, arg_3849, arg_3850) } }
//line :459:1
func A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000451_A_New_O(p0 any) *A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000451_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000451_A{}; t.Ctor_O(p0); return t }
//line :459:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000451_A) Ctor_O(c__names any) { t.F_names = c__names }
//line :459:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000451_A) Invoke_O_O__O(self, ds__1 any) any { var root_3895 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_3896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3895, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3897 lang.IFn; if linked_3896 == nil { ifn_3897 = lang.IFn_Cast(root_3895) } else { ifn_3897 = nil }; var arg_3898 any; var root_3899 any = A_arbace_go_repl_A_const_237.GetRawRoot__O(); var linked_3900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3899, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3901 lang.IFn; if linked_3900 == nil { ifn_3901 = lang.IFn_Cast(root_3899) } else { ifn_3901 = nil }; var arg_3902 any; var tmp1 any = A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000451_fn__794000452_A_New_O(t.F_names); var tmp2 *jrt.Class; var fncls__3913 *jrt.Class = A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000451_fn__794000452_A_fn_class; if fncls__3913 == nil { var fncls__3913d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000451_fn__794000452_A_fn_class = fncls__3913d; tmp2 = fncls__3913d } else { tmp2 = fncls__3913 }; arg_3902 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_3903 any = ds__1; if linked_3900 == nil { arg_3898 = ifn_3901.Invoke_O_O__O(arg_3902, arg_3903) } else { arg_3898 = linked_3900.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3899, arg_3902, arg_3903) }; if linked_3896 == nil { return ifn_3897.Invoke_O__O(arg_3898) } else { return linked_3896.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3895, arg_3898) } }
//line :459:1
func A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000451_fn__794000452_A_New_O(p0 any) *A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000451_fn__794000452_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000451_fn__794000452_A{}; t.Ctor_O(p0); return t }
//line :459:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000451_fn__794000452_A) Ctor_O(c__names any) { t.F_names = c__names }
//line :459:1
func (t *A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000451_fn__794000452_A) Invoke_O_O__O(self, p1__794000429_SHARP___1 any) any { var root_3904 any = A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_3905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3904, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3906 lang.IFn; if linked_3905 == nil { ifn_3906 = lang.IFn_Cast(root_3904) } else { ifn_3906 = nil }; var arg_3907 any = t.F_names; var arg_3908 any; var root_3909 any = A_arbace_go_repl_A_const_236.GetRawRoot__O(); var linked_3910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3909, A_arbace_go_repl_decl_names_A_fn_class); var ifn_3911 lang.IFn; if linked_3910 == nil { ifn_3911 = lang.IFn_Cast(root_3909) } else { ifn_3911 = nil }; var arg_3912 any = p1__794000429_SHARP___1; if linked_3910 == nil { arg_3908 = ifn_3911.Invoke_O__O(arg_3912) } else { arg_3908 = linked_3910.(*A_arbace_go_repl_decl_names_A).Invoke_O_O__O(root_3909, arg_3912) }; if linked_3905 == nil { return ifn_3906.Invoke_O_O__O(arg_3907, arg_3908) } else { return linked_3905.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3904, arg_3907, arg_3908) } }
func A_arbace_go_repl_declare_BANG__fn__794000457_A_New_O(p0 any) *A_arbace_go_repl_declare_BANG__fn__794000457_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__fn__794000457_A{}; t.Ctor_O(p0); return t }
//line :460:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000457_A) Ctor_O(c__old any) { t.F_old = c__old }
//line :460:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000457_A) Invoke_O_O__O(self, p1__794000430_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_repl_A_const_58.Invoke_O__O(t.F_old), A_arbace_go_repl_A_const_55.Invoke_O__O(p1__794000430_SHARP___1))).Ref() }


func A_arbace_go_repl_declare_BANG__fn__794000459_A_New_O_O(p0, p1 any) *A_arbace_go_repl_declare_BANG__fn__794000459_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__fn__794000459_A{}; t.Ctor_O_O(p0, p1); return t }
//line :463:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000459_A) Ctor_O_O(c__form, c__old any) { t.F_form = c__form; t.F_old = c__old }
//line :463:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000459_A) Invoke_O_O__O(self, p1__794000431_SHARP___1 any) any { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_repl_A_const_58.Invoke_O__O(t.F_old), A_arbace_go_repl_A_const_55.Invoke_O__O(p1__794000431_SHARP___1)) { var root_3937 any = A_arbace_go_repl_A_const_79.GetRawRoot__O(); var linked_3938 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3937, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_3939 lang.IFn; if linked_3938 == nil { ifn_3939 = lang.IFn_Cast(root_3937) } else { ifn_3939 = nil }; var arg_3940 any = p1__794000431_SHARP___1; var arg_3941 any = A_arbace_go_repl_A_const_82; var arg_3942 any = A_arbace_go_repl_A_const_15.GetRawRoot__O(); var arg_3943 any = t.F_form; if linked_3938 == nil { return ifn_3939.Invoke_O_O_O_O__O(arg_3940, arg_3941, arg_3942, arg_3943) } else { return linked_3938.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_3937, arg_3940, arg_3941, arg_3942, arg_3943) } } else { return p1__794000431_SHARP___1 } }

func A_arbace_go_repl_declare_BANG__fn__794000461_A_New_O_O(p0, p1 any) *A_arbace_go_repl_declare_BANG__fn__794000461_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__fn__794000461_A{}; t.Ctor_O_O(p0, p1); return t }
//line :465:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000461_A) Ctor_O_O(c__st, c__old any) { t.F_st = c__st; t.F_old = c__old }
//line :465:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000461_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3952 any = A_arbace_go_repl_A_const_225.GetRawRoot__O(); var linked_3953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3952, A_arbace_go_repl_check_source_A_fn_class); var ifn_3954 lang.IFn; if linked_3953 == nil { ifn_3954 = lang.IFn_Cast(root_3952) } else { ifn_3954 = nil }; var arg_3955 any; var root_3957 any = A_arbace_go_repl_A_const_118.GetRawRoot__O(); var linked_3958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3957, A_arbace_go_repl_source_of_A_fn_class); var ifn_3959 lang.IFn; if linked_3958 == nil { ifn_3959 = lang.IFn_Cast(root_3957) } else { ifn_3959 = nil }; var arg_3960 any = t.F_st; if linked_3958 == nil { arg_3955 = ifn_3959.Invoke_O__O(arg_3960) } else { arg_3955 = linked_3958.(*A_arbace_go_repl_source_of_A).Invoke_O_O__O(root_3957, arg_3960) }; var arg_3956 any; if linked_3953 == nil { tmp1 = ifn_3954.Invoke_O_O__O(arg_3955, arg_3956) } else { tmp1 = linked_3953.(*A_arbace_go_repl_check_source_A).Invoke_O_O_O__O(root_3952, arg_3955, arg_3956) } }; return nil }(); if tmp2 != nil { if true { var ex__3 jrt.Throwable_I = tmp2; var root_3961 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_3962 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3961, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3963 lang.IFn
											if linked_3962 == nil { ifn_3963 = lang.IFn_Cast(root_3961) } else { ifn_3963 = nil }; var arg_3964 any; var t_ any = t.F_st; t.F_st = nil; arg_3964 = t_; var arg_3965 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_3966 any = A_arbace_go_repl_A_const_57; var arg_3967 any; var tmp3 *lang.Keyword = A_arbace_go_repl_A_const_57; var tmp4 any; var t__2 any = t.F_old; t.F_old = nil; tmp4 = t__2; arg_3967 = tmp3.Invoke_O__O(tmp4); if linked_3962 == nil { ifn_3963.Invoke_O_O_O_O__O(arg_3964, arg_3965, arg_3966, arg_3967) } else { linked_3962.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_3961, arg_3964, arg_3965, arg_3966, arg_3967) }
//line :465:1
	panic(jrt.Thrown(ex__3)) } }; return tmp1 }

func A_arbace_go_repl_declare_BANG__fn__794000463_A_New() *A_arbace_go_repl_declare_BANG__fn__794000463_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__fn__794000463_A{}; t.Ctor(); return t }
//line :467:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000463_A) Ctor() {}
//line :467:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000463_A) Invoke_O_O__O(self, p1__794000432_SHARP___1 any) any { var tmp1 any = A_arbace_go_repl_A_const_238; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_repl_A_const_239.Invoke_O__O(p1__794000432_SHARP___1))).Ref() }



func A_arbace_go_repl_declare_BANG__own_QMARK___794000465_A_New_O_O(p0, p1 any) *A_arbace_go_repl_declare_BANG__own_QMARK___794000465_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__own_QMARK___794000465_A{}; t.Ctor_O_O(p0, p1); return t }
//line :471:1
func (t *A_arbace_go_repl_declare_BANG__own_QMARK___794000465_A) Ctor_O_O(c__form, c__spec_of any) { t.F_form = c__form; t.F_spec_of = c__spec_of }
//line :471:1
func (t *A_arbace_go_repl_declare_BANG__own_QMARK___794000465_A) Invoke_O_O__O(self, er__1 any) any { var or__1927000174__auto____2 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_repl_A_const_242.Invoke_O__O(er__1), nil); if or__1927000174__auto____2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { var tmp1 any = t.F_form; var tmp2 lang.IFn = lang.IFn_Cast(t.F_spec_of); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, tmp2.Invoke_O__O(A_arbace_go_repl_A_const_242.Invoke_O__O(er__1)))).Ref() } }


func A_arbace_go_repl_declare_BANG__fn__794000467_A_New_O(p0 any) *A_arbace_go_repl_declare_BANG__fn__794000467_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__fn__794000467_A{}; t.Ctor_O(p0); return t }
//line :474:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000467_A) Ctor_O(c__spec_of any) { t.F_spec_of = c__spec_of }
//line :474:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000467_A) Invoke_O_O__O(self, p1__794000433_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_spec_of); return tmp1.Invoke_O__O(A_arbace_go_repl_A_const_242.Invoke_O__O(p1__794000433_SHARP___1)) }




func A_arbace_go_repl_declare_BANG__fn__794000469_A_New_O_O(p0, p1 any) *A_arbace_go_repl_declare_BANG__fn__794000469_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__fn__794000469_A{}; t.Ctor_O_O(p0, p1); return t }
//line :479:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000469_A) Ctor_O_O(c__broken, c__others any) { t.F_broken = c__broken; t.F_others = c__others }
//line :479:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000469_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_246.GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_51, nil, Lit_52, nil); var tmp4 any; var root_4122 any = A_arbace_go_repl_A_const_48.GetRawRoot__O(); var linked_4123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4122, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_4124 lang.IFn; if linked_4123 == nil { ifn_4124 = lang.IFn_Cast(root_4122) } else { ifn_4124 = nil }; var arg_4125 any = Lit_53; var arg_4126 any; var root_4127 any = A_arbace_go_repl_A_const_247.GetRawRoot__O(); var linked_4128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4127, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_4129 lang.IFn; if linked_4128 == nil { ifn_4129 = lang.IFn_Cast(root_4127) } else { ifn_4129 = nil }; var arg_4130 any; var t_ any = t.F_broken; t.F_broken = nil; arg_4130 = t_; if linked_4128 == nil { arg_4126 = ifn_4129.Invoke_O__O(arg_4130) } else { arg_4126 = linked_4128.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_4127, arg_4130) }; if linked_4123 == nil { tmp4 = ifn_4124.Invoke_O_O__O(arg_4125, arg_4126) } else { tmp4 = linked_4123.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_4122, arg_4125, arg_4126) }; var tmp5 any = tmp4; var tmp6 any; var root_4131 any = A_arbace_go_repl_A_const_115.GetRawRoot__O(); var linked_4132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4131, A_arbace_go_repl_error_text_A_fn_class); var ifn_4133 lang.IFn
												if linked_4132 == nil { ifn_4133 = lang.IFn_Cast(root_4131) } else { ifn_4133 = nil }; var arg_4134 any; var t__2 any = t.F_others; t.F_others = nil; arg_4134 = t__2; var arg_4135 any; var root_4136 any = A_arbace_go_repl_A_const_245.GetRawRoot__O(); var linked_4137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4136, A_arbace_go_repl_repl_source_A_fn_class); var ifn_4138 lang.IFn; if linked_4137 == nil { ifn_4138 = lang.IFn_Cast(root_4136) } else { ifn_4138 = nil }; if linked_4137 == nil { arg_4135 = ifn_4138.Invoke__O() } else { arg_4135 = linked_4137.(*A_arbace_go_repl_repl_source_A).Invoke_O__O(root_4136) }; if linked_4132 == nil { tmp6 = ifn_4133.Invoke_O_O__O(arg_4134, arg_4135) } else { tmp6 = linked_4132.(*A_arbace_go_repl_error_text_A).Invoke_O_O_O__O(root_4131, arg_4134, arg_4135) }
//line :480:1
		tmp1 = tmp2.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp5, nil, tmp6)).Ref()) }
//line :479:1
	return nil }(); var root_4139 any = A_arbace_go_repl_A_const_200.GetRawRoot__O(); var linked_4140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4139, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_4141 lang.IFn; if linked_4140 == nil { ifn_4141 = lang.IFn_Cast(root_4139) } else { ifn_4141 = nil }; if linked_4140 == nil { ifn_4141.Invoke__O() } else { linked_4140.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_4139) }; if tmp7 != nil { panic(tmp7) }; return tmp1 }



func A_arbace_go_repl_declare_BANG__fn__794000473_A_New_O_Z_O_O_O_O(p0 any, p1 bool, p2, p3, p4, p5 any) *A_arbace_go_repl_declare_BANG__fn__794000473_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_declare_BANG__fn__794000473_A{}; t.Ctor_O_Z_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :483:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000473_A) Ctor_O_Z_O_O_O_O(c__broken any, c__var_QMARK_ bool, c__r, c__st, c__old, c__names any) { t.F_broken = c__broken; t.F_var_QMARK_ = c__var_QMARK_; t.F_r = c__r; t.F_st = c__st; t.F_old = c__old; t.F_names = c__names }
//line :483:1
func (t *A_arbace_go_repl_declare_BANG__fn__794000473_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_4024 any = A_arbace_go_repl_A_const_226.GetRawRoot__O(); var linked_4025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4024, A_arbace_go_repl_define_BANG__A_fn_class); var ifn_4026 lang.IFn; if linked_4025 == nil { ifn_4026 = lang.IFn_Cast(root_4024) } else { ifn_4026 = nil }; var arg_4027 any = t.F_st; var arg_4028 any; var t_ any = t.F_r; t.F_r = nil; arg_4028 = t_; var arg_4029 any; var tmp2 any = A_arbace_go_repl_A_const_169; var tmp3 any = jrt.Boolean_TRUE.Ref(); var tmp4 any = A_arbace_go_repl_A_const_172; var tmp5 any; var t__2 any = t.F_broken; t.F_broken = nil; tmp5 = t__2; var tmp6 any = tmp5; var tmp7 any = A_arbace_go_repl_A_const_173; var tmp8 any
											if t.F_var_QMARK_ { var t__3 any = t.F_names; t.F_names = nil; tmp8 = t__3 } else { tmp8 = nil }
//line :483:1
	arg_4029 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp6, tmp7, tmp8)); if linked_4025 == nil { tmp1 = ifn_4026.Invoke_O_O_O__O(arg_4027, arg_4028, arg_4029) } else { tmp1 = linked_4025.(*A_arbace_go_repl_define_BANG__A).Invoke_O_O_O_O__O(root_4024, arg_4027, arg_4028, arg_4029) } }; return nil }(); if tmp9 != nil { if true { var ex__3 jrt.Throwable_I = tmp9; var root_4030 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_4031 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4030, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_4032 lang.IFn

		if linked_4031 == nil { ifn_4032 = lang.IFn_Cast(root_4030) } else { ifn_4032 = nil }; var arg_4033 any; var t__4 any = t.F_st; t.F_st = nil; arg_4033 = t__4; var arg_4034 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_4035 any = A_arbace_go_repl_A_const_57; var arg_4036 any; var tmp10 *lang.Keyword = A_arbace_go_repl_A_const_57; var tmp11 any; var t__5 any = t.F_old; t.F_old = nil; tmp11 = t__5; arg_4036 = tmp10.Invoke_O__O(tmp11); if linked_4031 == nil { ifn_4032.Invoke_O_O_O_O__O(arg_4033, arg_4034, arg_4035, arg_4036) } else { linked_4031.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_4030, arg_4033, arg_4034, arg_4035, arg_4036) }
//line :483:1
		panic(jrt.Thrown(ex__3)) } }; return tmp1 }















func A_arbace_go_repl_eval_BANG__A_New() *A_arbace_go_repl_eval_BANG__A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_eval_BANG__A{}; t.Ctor(); return t }
//line :499:1
func (t *A_arbace_go_repl_eval_BANG__A) Ctor() {}
//line :499:1
func (t *A_arbace_go_repl_eval_BANG__A) Invoke_O_O_O__O(self, stmts__0, p__794000482__1 any) any { var map__794000483__3 any = p__794000482__1; var map__794000483__4 any; if lang.ISeq_InstanceOf(map__794000483__3) { var tmp1 any; var root_4185 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_4186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4185, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4187 lang.IFn; if linked_4186 == nil { ifn_4187 = lang.IFn_Cast(root_4185) } else { ifn_4187 = nil }; var arg_4188 any = map__794000483__3; if linked_4186 == nil { tmp1 = ifn_4187.Invoke_O__O(arg_4188) } else { tmp1 = linked_4186.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4185, arg_4188) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_4189 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_4190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4189, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_4191 lang.IFn; if linked_4190 == nil { ifn_4191 = lang.IFn_Cast(root_4189) } else { ifn_4191 = nil }; var arg_4192 any = map__794000483__3; if linked_4190 == nil { tmp2 = ifn_4191.Invoke_O__O(arg_4192) } else { tmp2 = linked_4190.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_4189, arg_4192) }; map__794000483__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_4193 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_4194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4193, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4195 lang.IFn; if linked_4194 == nil { ifn_4195 = lang.IFn_Cast(root_4193) } else { ifn_4195 = nil }; var arg_4196 any = map__794000483__3; if linked_4194 == nil { tmp3 = ifn_4195.Invoke_O__O(arg_4196) } else { tmp3 = linked_4194.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4193, arg_4196) }; if jrt.J2g_Truth(tmp3) { var root_4197 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_4198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4197, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4199 lang.IFn; if linked_4198 == nil { ifn_4199 = lang.IFn_Cast(root_4197) } else { ifn_4199 = nil }; var arg_4200 any = map__794000483__3; if linked_4198 == nil { map__794000483__4 = ifn_4199.Invoke_O__O(arg_4200) } else { map__794000483__4 = linked_4198.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4197, arg_4200) } } else { map__794000483__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000483__4 = map__794000483__3 }; var ns__5 any = lang.RT_Get_O_O__O_NoInit(map__794000483__4, A_arbace_go_repl_A_const_56); var ns_sym__6 any; var or__1927000174__auto____6 any = ns__5; if



	jrt.J2g_Truth(or__1927000174__auto____6) { ns_sym__6 = or__1927000174__auto____6 } else { var root_4201 any = A_arbace_go_repl_A_const_234.GetRawRoot__O(); var linked_4202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4201, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_4203 lang.IFn; if linked_4202 == nil { ifn_4203 = lang.IFn_Cast(root_4201) } else { ifn_4203 = nil }; var arg_4204 any = A_arbace_go_repl_A_const_235.Get__O(); if linked_4202 == nil { ns_sym__6 = ifn_4203.Invoke_O__O(arg_4204) } else { ns_sym__6 = linked_4202.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_4201, arg_4204) } }; var ns_sym__7 any; var tmp4 any; var root_4205 any = /*line :499:1*/A_arbace_go_repl_A_const_68.GetRawRoot__O(); var linked_4206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4205, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_4207 lang.IFn; if




	linked_4206 == nil { ifn_4207 = lang.IFn_Cast(root_4205) } else { ifn_4207 = nil }; var arg_4208 any; var root_4210 any = A_arbace_go_repl_A_const_51.GetRawRoot__O(); var linked_4211 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4210, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_4212 lang.IFn; if linked_4211 == nil { ifn_4212 = lang.IFn_Cast(root_4210) } else { ifn_4212 = nil }; var arg_4213 any = ns_sym__6; if linked_4211 == nil { arg_4208 = ifn_4212.Invoke_O__O(arg_4213) } else { arg_4208 = linked_4211.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_4210, arg_4213) }; var arg_4209 any = Lit_137; if linked_4206 == nil { tmp4 = ifn_4207.Invoke_O_O__O(arg_4208, arg_4209) } else { tmp4 = linked_4206.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_4205, arg_4208, arg_4209) }; if jrt.J2g_Truth(tmp4) { ns_sym__7 = ns_sym__6 } else { ns_sym__7 = A_arbace_go_repl_A_const_250 }; var st__8 any; var root_4214 any = /*line :499:1*/A_arbace_go_repl_A_const_72.GetRawRoot__O(); var linked_4215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4214, A_arbace_go_repl_package_state_A_fn_class); var ifn_4216 lang.IFn; if





	linked_4215 == nil { ifn_4216 = lang.IFn_Cast(root_4214) } else { ifn_4216 = nil }; var arg_4217 any = ns_sym__7; if linked_4215 == nil { st__8 = ifn_4216.Invoke_O__O(arg_4217) } else { st__8 = linked_4215.(*A_arbace_go_repl_package_state_A).Invoke_O_O__O(root_4214, arg_4217) }; var nm__9 any; var tmp5 /*line :499:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_138, nil); var tmp6 any; var root_4218 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_4219 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4218, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_4220 lang.IFn; if






	linked_4219 == nil { ifn_4220 = lang.IFn_Cast(root_4218) } else { ifn_4220 = nil }; var arg_4221 any = A_arbace_go_repl_A_const_251.GetRawRoot__O(); var arg_4222 any = A_arbace_go_repl_A_const_252.GetRawRoot__O(); if linked_4219 == nil { tmp6 = ifn_4220.Invoke_O_O__O(arg_4221, arg_4222) } else { tmp6 = linked_4219.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_4218, arg_4221, arg_4222) }; nm__9 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6)).Ref(); var last_f__10 any; var tmp7 any = /*line :499:1*/A_arbace_go_repl_eval_BANG__fn__794000491_A_New_O(stmts__0); var tmp8 *jrt.Class; var fncls__4239 *jrt.Class = A_arbace_go_repl_eval_BANG__fn__794000491_A_fn_class; if








	fncls__4239 == nil { var fncls__4239d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_139, false); A_arbace_go_repl_eval_BANG__fn__794000491_A_fn_class = fncls__4239d; tmp8 = fncls__4239d } else { tmp8 = fncls__4239 }; last_f__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O(); var stmt_QMARK___11 any; var and__1927000168__auto____11 any; var root_4240 any = /*line :499:1*/A_arbace_go_repl_A_const_34.GetRawRoot__O(); var linked_4241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4240, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_4242 lang.IFn; if












	linked_4241 == nil { ifn_4242 = lang.IFn_Cast(root_4240) } else { ifn_4242 = nil }; var arg_4243 any = last_f__10; if linked_4241 == nil { and__1927000168__auto____11 = ifn_4242.Invoke_O__O(arg_4243) } else { and__1927000168__auto____11 = linked_4241.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_4240, arg_4243) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var root_4244 any = A_arbace_go_repl_A_const_18.GetRawRoot__O(); var linked_4245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4244, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_4246 lang.IFn; if linked_4245 == nil { ifn_4246 = lang.IFn_Cast(root_4244) } else { ifn_4246 = nil }; var arg_4247 any = A_arbace_go_repl_A_const_254.GetRawRoot__O(); var arg_4248 any; var root_4249 any = A_arbace_go_repl_A_const_89.GetRawRoot__O(); var linked_4250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4249, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_4251 lang.IFn; if linked_4250 == nil { ifn_4251 = lang.IFn_Cast(root_4249) } else { ifn_4251 = nil }; var arg_4252 any = last_f__10; if linked_4250 == nil { arg_4248 = ifn_4251.Invoke_O__O(arg_4252) } else { arg_4248 = linked_4250.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_4249, arg_4252) }; if linked_4245 == nil { stmt_QMARK___11 = ifn_4246.Invoke_O_O__O(arg_4247, arg_4248) } else { stmt_QMARK___11 = linked_4245.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_4244, arg_4247, arg_4248) } } else { stmt_QMARK___11 = and__1927000168__auto____11 }; var attempt__12 any; var tmp9 any = /*line :499:1*/A_arbace_go_repl_eval_BANG__attempt__794000493_A_New_O_O_O(stmts__0, nm__9, st__8); var tmp10 *jrt.Class; var fncls__4334 *jrt.Class = A_arbace_go_repl_eval_BANG__attempt__794000493_A_fn_class; if













	fncls__4334 == nil { var fncls__4334d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_140, false); A_arbace_go_repl_eval_BANG__attempt__794000493_A_fn_class = fncls__4334d; tmp10 = fncls__4334d } else { tmp10 = fncls__4334 }; attempt__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var vec__794000485__13 any; if















	jrt.J2g_Truth(stmt_QMARK___11) { vec__794000485__13 = lang.IFn_Cast(attempt__12).Invoke_O__O(nil) } else { vec__794000485__13 = lang.IFn_Cast(attempt__12).Invoke_O__O(A_arbace_go_repl_A_const_154) }; var r__14 any = /*line :499:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__794000485__13, lang.RT_IntCast_J__I_NoInit(0), nil); var form__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000485__13, lang.RT_IntCast_J__I_NoInit(1), nil); var multi__16 any; var root_4335 any = A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_4336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4335, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_4337 lang.IFn; if






























	linked_4336 == nil { ifn_4337 = lang.IFn_Cast(root_4335) } else { ifn_4337 = nil }; var arg_4338 any; var tmp11 any = A_arbace_go_repl_eval_BANG__fn__794000499_A_New(); var tmp12 *jrt.Class; var fncls__4345 *jrt.Class = A_arbace_go_repl_eval_BANG__fn__794000499_A_fn_class; if fncls__4345 == nil { var fncls__4345d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_141, false); A_arbace_go_repl_eval_BANG__fn__794000499_A_fn_class = fncls__4345d; tmp12 = fncls__4345d } else { tmp12 = fncls__4345 }; arg_4338 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var arg_4339 any = A_arbace_go_repl_A_const_228.Invoke_O__O(r__14); if linked_4336 == nil { multi__16 = ifn_4337.Invoke_O_O__O(arg_4338, arg_4339) } else { multi__16 = linked_4336.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_4335, arg_4338, arg_4339) }; var novalue__17 any; var root_4346 any = /*line :499:1*/A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_4347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4346, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_4348 lang.IFn; if































	linked_4347 == nil { ifn_4348 = lang.IFn_Cast(root_4346) } else { ifn_4348 = nil }; var arg_4349 any; var tmp13 any = A_arbace_go_repl_eval_BANG__fn__794000501_A_New(); var tmp14 *jrt.Class; var fncls__4356 *jrt.Class = A_arbace_go_repl_eval_BANG__fn__794000501_A_fn_class; if fncls__4356 == nil { var fncls__4356d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_142, false); A_arbace_go_repl_eval_BANG__fn__794000501_A_fn_class = fncls__4356d; tmp14 = fncls__4356d } else { tmp14 = fncls__4356 }; arg_4349 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var arg_4350 any = A_arbace_go_repl_A_const_228.Invoke_O__O(r__14); if linked_4347 == nil { novalue__17 = ifn_4348.Invoke_O_O__O(arg_4349, arg_4350) } else { novalue__17 = linked_4347.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_4346, arg_4349, arg_4350) }; var vec__794000488__18 any; if
	jrt.J2g_Truth(multi__16) { var vec__794000503__18 any; var root_4357 any = A_arbace_go_repl_A_const_263.GetRawRoot__O(); var linked_4358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4357, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_4359 lang.IFn
		if linked_4358 == nil { ifn_4359 = lang.IFn_Cast(root_4357) } else { ifn_4359 = nil }; var arg_4360 any = A_arbace_go_repl_A_const_264; var arg_4361 any = A_arbace_go_repl_A_const_112.Invoke_O__O(multi__16); if linked_4358 == nil { vec__794000503__18 = ifn_4359.Invoke_O_O__O(arg_4360, arg_4361) } else { vec__794000503__18 = linked_4358.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_4357, arg_4360, arg_4361) }
//line :532:1
		var ___19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000503__18, lang.RT_IntCast_J__I_NoInit(0), nil); var ts__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000503__18, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp15 lang.IFn = lang.IFn_Cast(attempt__12); var tmp16 any; var root_4438 any = A_arbace_go_repl_A_const_50.GetRawRoot__O(); var linked_4439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4438, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_4440 lang.IFn; _ = ___19

		if linked_4439 == nil { ifn_4440 = lang.IFn_Cast(root_4438) } else { ifn_4440 = nil }; var arg_4441 any = ts__20; var arg_4442 any = A_arbace_go_repl_A_const_265; if linked_4439 == nil { tmp16 = ifn_4440.Invoke_O_O__O(arg_4441, arg_4442) } else { tmp16 = linked_4439.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_4438, arg_4441, arg_4442) }; vec__794000488__18 = tmp15.Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp16)).Ref()) } else {
//line :532:1
			if jrt.J2g_Truth(novalue__17) {


				vec__794000488__18 = lang.IFn_Cast(attempt__12).Invoke_O__O(nil) } else {
//line :532:1
					if A_arbace_go_repl_A_const_133 != nil { vec__794000488__18 = lang.Tuple_Create_O_O__IPersistentVector(r__14, form__15) } else { vec__794000488__18 = nil } } }; var r__19 any = /*line :499:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__794000488__18, lang.RT_IntCast_J__I_NoInit(0), nil); var form__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__794000488__18, lang.RT_IntCast_J__I_NoInit(1), nil); var errs__21 any; var root_4362 any = A_arbace_go_repl_A_const_237.GetRawRoot__O(); var linked_4363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4362, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_4364 lang.IFn; if





































	linked_4363 == nil { ifn_4364 = lang.IFn_Cast(root_4362) } else { ifn_4364 = nil }; var arg_4365 any; var tmp17 any = A_arbace_go_repl_eval_BANG__fn__794000506_A_New(); var tmp18 *jrt.Class; var fncls__4367 *jrt.Class = A_arbace_go_repl_eval_BANG__fn__794000506_A_fn_class; if fncls__4367 == nil { var fncls__4367d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_143, false); A_arbace_go_repl_eval_BANG__fn__794000506_A_fn_class = fncls__4367d; tmp18 = fncls__4367d } else { tmp18 = fncls__4367 }; arg_4365 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); var arg_4366 any = A_arbace_go_repl_A_const_228.Invoke_O__O(r__19); if linked_4363 == nil { errs__21 = ifn_4364.Invoke_O_O__O(arg_4365, arg_4366) } else { errs__21 = linked_4363.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_4362, arg_4365, arg_4366) }; var tmp19 any; var root_4443 any =
	A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_4444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4443, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4445 lang.IFn; if linked_4444 == nil { ifn_4445 = lang.IFn_Cast(root_4443) } else { ifn_4445 = nil }; var arg_4446 any = errs__21; if linked_4444 == nil { tmp19 = ifn_4445.Invoke_O__O(arg_4446) } else { tmp19 = linked_4444.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4443, arg_4446) }; if jrt.J2g_Truth(tmp19) { var tmp20 any; var root_4447 any = A_arbace_go_repl_A_const_69.GetRawRoot__O(); var linked_4448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4447, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_4449 lang.IFn
		if linked_4448 == nil { ifn_4449 = lang.IFn_Cast(root_4447) } else { ifn_4449 = nil }; var arg_4450 any; var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_48, nil); var tmp22 any; var root_4452 any = A_arbace_go_repl_A_const_115.GetRawRoot__O(); var linked_4453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4452, A_arbace_go_repl_error_text_A_fn_class); var ifn_4454 lang.IFn; if linked_4453 == nil { ifn_4454 = lang.IFn_Cast(root_4452) } else { ifn_4454 = nil }; var arg_4455 any = errs__21; var arg_4456 any; var root_4457 any = A_arbace_go_repl_A_const_245.GetRawRoot__O(); var linked_4458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4457, A_arbace_go_repl_repl_source_A_fn_class); var ifn_4459 lang.IFn; if linked_4458 == nil { ifn_4459 = lang.IFn_Cast(root_4457) } else { ifn_4459 = nil }; if linked_4458 == nil { arg_4456 = ifn_4459.Invoke__O() } else { arg_4456 = linked_4458.(*A_arbace_go_repl_repl_source_A).Invoke_O__O(root_4457) }; if linked_4453 == nil { tmp22 = ifn_4454.Invoke_O_O__O(arg_4455, arg_4456) } else { tmp22 = linked_4453.(*A_arbace_go_repl_error_text_A).Invoke_O_O_O__O(root_4452, arg_4455, arg_4456) }; arg_4450 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp21, jrt.RefArrayOf(jrt.Object_class, nil, tmp22)).Ref(); var arg_4451 any; var tmp23 any = A_arbace_go_repl_A_const_229; var tmp24 any; var root_4460 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_4461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4460, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_4462 lang.IFn; if linked_4461 == nil { ifn_4462 = lang.IFn_Cast(root_4460) } else { ifn_4462 = nil }; var arg_4463 any = errs__21; if linked_4461 == nil { tmp24 = ifn_4462.Invoke_O__O(arg_4463) } else { tmp24 = linked_4461.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_4460, arg_4463) }; arg_4451 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp23, tmp24)); if linked_4448 == nil { tmp20 = ifn_4449.Invoke_O_O__O(arg_4450, arg_4451) } else { tmp20 = linked_4448.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_4447, arg_4450, arg_4451) }
//line :538:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp20))) }; var old__22 any; var root_4368 any = /*line :499:1*/A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_4369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4368, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_4370 lang.IFn; if








































	linked_4369 == nil { ifn_4370 = lang.IFn_Cast(root_4368) } else { ifn_4370 = nil }; var arg_4371 any = st__8; if linked_4369 == nil { old__22 = ifn_4370.Invoke_O__O(arg_4371) } else { old__22 = linked_4369.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_4368, arg_4371) }; var root_4464 any =
	A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_4465 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4464, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_4466 lang.IFn; if linked_4465 == nil { ifn_4466 = lang.IFn_Cast(root_4464) } else { ifn_4466 = nil }; var arg_4467 any = st__8; var arg_4468 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_4469 any = A_arbace_go_repl_A_const_57; var arg_4470 any; var root_4471 any = A_arbace_go_repl_A_const_80.GetRawRoot__O(); var linked_4472 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4471, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_4473 lang.IFn; if linked_4472 == nil { ifn_4473 = lang.IFn_Cast(root_4471) } else { ifn_4473 = nil }; var arg_4474 any; var tmp25 any = A_arbace_go_repl_eval_BANG__fn__794000508_A_New_O_O(form__20, old__22); var tmp26 *jrt.Class; var fncls__4483 *jrt.Class = A_arbace_go_repl_eval_BANG__fn__794000508_A_fn_class; if fncls__4483 == nil { var fncls__4483d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_144, false); A_arbace_go_repl_eval_BANG__fn__794000508_A_fn_class = fncls__4483d; tmp26 = fncls__4483d } else { tmp26 = fncls__4483 }; arg_4474 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil); var arg_4475 any = A_arbace_go_repl_A_const_57.Invoke_O__O(old__22); if linked_4472 == nil { arg_4470 = ifn_4473.Invoke_O_O__O(arg_4474, arg_4475) } else { arg_4470 = linked_4472.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_4471, arg_4474, arg_4475) }; if linked_4465 == nil { ifn_4466.Invoke_O_O_O_O__O(arg_4467, arg_4468, arg_4469, arg_4470) } else { linked_4465.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_4464, arg_4467, arg_4468, arg_4469, arg_4470) }; var tmp27 any; tmp41 := /*line :499:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)











































		{ var root_4484 any = A_arbace_go_repl_A_const_226.GetRawRoot__O(); var linked_4485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4484, A_arbace_go_repl_define_BANG__A_fn_class); var ifn_4486 lang.IFn; if linked_4485 == nil { ifn_4486 = lang.IFn_Cast(root_4484) } else { ifn_4486 = nil }; var arg_4487 any = st__8; var arg_4488 any = r__19; var tmp28 any = A_arbace_go_repl_A_const_169; var tmp29 any = jrt.Boolean_FALSE.Ref(); var tmp30 any = A_arbace_go_repl_A_const_171; var arg_4489 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp29, tmp30, lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, nm__9)))); if linked_4485 == nil { ifn_4486.Invoke_O_O_O__O(arg_4487, arg_4488, arg_4489) } else { linked_4485.(*A_arbace_go_repl_define_BANG__A).Invoke_O_O_O_O__O(root_4484, arg_4487, arg_4488, arg_4489) }
//line :499:1
			var map__794000510__25 any; var root_4372 any = A_arbace_go_repl_A_const_153.GetRawRoot__O(); var linked_4373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4372, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4374 lang.IFn












































			if linked_4373 == nil { ifn_4374 = lang.IFn_Cast(root_4372) } else { ifn_4374 = nil }; var arg_4375 any; var root_4377 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_4378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4377, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_4379 lang.IFn; if linked_4378 == nil { ifn_4379 = lang.IFn_Cast(root_4377) } else { ifn_4379 = nil }; var arg_4380 any = st__8; if linked_4378 == nil { arg_4375 = ifn_4379.Invoke_O__O(arg_4380) } else { arg_4375 = linked_4378.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_4377, arg_4380) }; var arg_4376 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_repl_A_const_59, nm__9); if linked_4373 == nil { map__794000510__25 = ifn_4374.Invoke_O_O__O(arg_4375, arg_4376) } else { map__794000510__25 = linked_4373.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4372, arg_4375, arg_4376) }
//line :499:1
			var map__794000510__26 any












































			if lang.ISeq_InstanceOf(map__794000510__25) { var tmp31 any; var root_4381 any = A_arbace_go_repl_A_const_27.GetRawRoot__O(); var linked_4382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4381, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4383 lang.IFn; if linked_4382 == nil { ifn_4383 = lang.IFn_Cast(root_4381) } else { ifn_4383 = nil }; var arg_4384 any = map__794000510__25; if linked_4382 == nil { tmp31 = ifn_4383.Invoke_O__O(arg_4384) } else { tmp31 = linked_4382.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4381, arg_4384) }; if jrt.J2g_Truth(tmp31) { var tmp32 any; var root_4385 any = A_arbace_go_repl_A_const_28.GetRawRoot__O(); var linked_4386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4385, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_4387 lang.IFn; if linked_4386 == nil { ifn_4387 = lang.IFn_Cast(root_4385) } else { ifn_4387 = nil }; var arg_4388 any = map__794000510__25; if linked_4386 == nil { tmp32 = ifn_4387.Invoke_O__O(arg_4388) } else { tmp32 = linked_4386.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_4385, arg_4388) }; map__794000510__26 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp32, jrt.Object_class.ArrayClass())).Ref() } else { var tmp33 any; var root_4389 any = A_arbace_go_repl_A_const_29.GetRawRoot__O(); var linked_4390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4389, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4391 lang.IFn; if linked_4390 == nil { ifn_4391 = lang.IFn_Cast(root_4389) } else { ifn_4391 = nil }; var arg_4392 any = map__794000510__25; if linked_4390 == nil { tmp33 = ifn_4391.Invoke_O__O(arg_4392) } else { tmp33 = linked_4390.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4389, arg_4392) }; if jrt.J2g_Truth(tmp33) { var root_4393 any = A_arbace_go_repl_A_const_30.GetRawRoot__O(); var linked_4394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4393, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4395 lang.IFn; if linked_4394 == nil { ifn_4395 = lang.IFn_Cast(root_4393) } else { ifn_4395 = nil }; var arg_4396 any = map__794000510__25; if linked_4394 == nil { map__794000510__26 = ifn_4395.Invoke_O__O(arg_4396) } else { map__794000510__26 = linked_4394.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4393, arg_4396) } } else { map__794000510__26 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__794000510__26 = map__794000510__25 }
//line :499:1
			var cell__27 any = lang.RT_Get_O_O__O_NoInit(map__794000510__26, A_arbace_go_repl_A_const_156); var obj__28 any = lang.RT_Get_O_O__O_NoInit(map__794000510__26, A_arbace_go_repl_A_const_181); var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_183.GetRawRoot__O()); var tmp35 any; var root_4417 any = A_arbace_go_repl_A_const_202.GetRawRoot__O(); var linked_4418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4417, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_4419 lang.IFn













































			if linked_4418 == nil { ifn_4419 = lang.IFn_Cast(root_4417) } else { ifn_4419 = nil }; var arg_4420 any; var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_38.GetRawRoot__O()); var tmp37 any = A_arbace_go_repl_A_const_203; var tmp38 any; var root_4426 any = A_arbace_go_repl_A_const_174.GetRawRoot__O(); var linked_4427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4426, A_arbace_go_repl_build_context_A_fn_class); var ifn_4428 lang.IFn; if linked_4427 == nil { ifn_4428 = lang.IFn_Cast(root_4426) } else { ifn_4428 = nil }; var arg_4429 any = st__8; if linked_4427 == nil { tmp38 = ifn_4428.Invoke_O__O(arg_4429) } else { tmp38 = linked_4427.(*A_arbace_go_repl_build_context_A).Invoke_O_O__O(root_4426, arg_4429) }; arg_4420 = tmp36.Invoke_O_O__O(tmp37, tmp38); if linked_4418 == nil { ifn_4419.Invoke_O__O(arg_4420) } else { linked_4418.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_4417, arg_4420) }; var tmp39 any = A_arbace_go_repl_eval_BANG__fn__794000512_A_New_O(obj__28); var tmp40 *jrt.Class; var fncls__4416 *jrt.Class = A_arbace_go_repl_eval_BANG__fn__794000512_A_fn_class; if fncls__4416 == nil { var fncls__4416d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_145, false); A_arbace_go_repl_eval_BANG__fn__794000512_A_fn_class = fncls__4416d; tmp40 = fncls__4416d } else { tmp40 = fncls__4416 }; tmp35 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp39, tmp40, nil).Invoke__O(); tmp27 = lang.GoInterp_Call_O_O1__O(tmp34.Invoke_O_O_O_O__O(Lit_13, cell__27, tmp35, nm__9), lang.RT_Object_array_O__O1_NoInit(lang.PersistentVector_EMPTY.Ref())) }
//line :499:1
		return nil }(); var root_4490 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_4491 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4490, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_4492 lang.IFn; if
















































	linked_4491 == nil { ifn_4492 = lang.IFn_Cast(root_4490) } else { ifn_4492 = nil }; var arg_4493 any = st__8; var arg_4494 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_4495 any = A_arbace_go_repl_A_const_57; var arg_4496 any = A_arbace_go_repl_A_const_57.Invoke_O__O(old__22); if linked_4491 == nil { ifn_4492.Invoke_O_O_O_O__O(arg_4493, arg_4494, arg_4495, arg_4496) } else { linked_4491.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_4490, arg_4493, arg_4494, arg_4495, arg_4496) }; var tmp42 lang.IFn =
	lang.IFn_Cast(A_arbace_go_repl_A_const_70.GetRawRoot__O()); var tmp43 any = A_arbace_go_repl_A_const_79.GetRawRoot__O(); var tmp44 any = A_arbace_go_repl_A_const_59; tmp42.Invoke_O_O_O_O_O__O(st__8, tmp43, tmp44, A_arbace_go_repl_A_const_84.GetRawRoot__O(), nm__9); if /*line :499:1*/ tmp41 != nil { panic(tmp41) }; return tmp27 }








func A_arbace_go_repl_eval_BANG__fn__794000491_A_New_O(p0 any) *A_arbace_go_repl_eval_BANG__fn__794000491_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_eval_BANG__fn__794000491_A{}; t.Ctor_O(p0); return t }
//line :508:1
func (t *A_arbace_go_repl_eval_BANG__fn__794000491_A) Ctor_O(c__stmts any) { t.F_stmts = c__stmts }
//line :508:1
func (t *A_arbace_go_repl_eval_BANG__fn__794000491_A) Invoke_O__O(self any) any { { var f__1 any; var root_4223 any = A_arbace_go_repl_A_const_66.GetRawRoot__O(); var linked_4224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4223, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_4225 lang.IFn; if linked_4224 == nil { ifn_4225 = lang.IFn_Cast(root_4223) } else { ifn_4225 = nil }; var arg_4226 any; var t_ any = t.F_stmts; t.F_stmts = nil; arg_4226 = t_; if linked_4224 == nil { f__1 = ifn_4225.Invoke_O__O(arg_4226) } else { f__1 = linked_4224.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_4223, arg_4226) }; L1: for {
										var tmp1 any; var and__1927000168__auto____2 any; var root_4227 any = A_arbace_go_repl_A_const_34.GetRawRoot__O(); var linked_4228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4227, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_4229 lang.IFn; if linked_4228 == nil { ifn_4229 = lang.IFn_Cast(root_4227) } else { ifn_4229 = nil }; var arg_4230 any = f__1; if linked_4228 == nil { and__1927000168__auto____2 = ifn_4229.Invoke_O__O(arg_4230) } else { and__1927000168__auto____2 = linked_4228.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_4227, arg_4230) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_repl_A_const_253); var tmp3 any; var root_4231 any = A_arbace_go_repl_A_const_89.GetRawRoot__O(); var linked_4232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4231, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_4233 lang.IFn; if linked_4232 == nil { ifn_4233 = lang.IFn_Cast(root_4231) } else { ifn_4233 = nil }; var arg_4234 any = f__1; if linked_4232 == nil { tmp3 = ifn_4233.Invoke_O__O(arg_4234) } else { tmp3 = linked_4232.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_4231, arg_4234) }; and__1927000168__auto____3 = tmp2.Invoke_O__O(tmp3); if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(f__1)), 2)).Ref() } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
											var tmp4 any; var root_4235 any = A_arbace_go_repl_A_const_66.GetRawRoot__O(); var linked_4236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4235, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_4237 lang.IFn; if linked_4236 == nil { ifn_4237 = lang.IFn_Cast(root_4235) } else { ifn_4237 = nil }; var arg_4238 any = f__1; if linked_4236 == nil { tmp4 = ifn_4237.Invoke_O__O(arg_4238) } else { tmp4 = linked_4236.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_4235, arg_4238) }; f__1 = tmp4; continue L1 } else {
//line :509:1
			return f__1 } } }; /*line :508:1*/panic("j2g: unreachable") }




func A_arbace_go_repl_eval_BANG__attempt__794000493_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_repl_eval_BANG__attempt__794000493_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_eval_BANG__attempt__794000493_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :513:1
func (t *A_arbace_go_repl_eval_BANG__attempt__794000493_A) Ctor_O_O_O(c__stmts, c__nm, c__st any) { t.F_stmts = c__stmts; t.F_nm = c__nm; t.F_st = c__st }
//line :513:1
func (t *A_arbace_go_repl_eval_BANG__attempt__794000493_A) Invoke_O_O__O(self, results__1 any) any { var form__2 any; var root_4253 any = A_arbace_go_repl_A_const_37.GetRawRoot__O(); var linked_4254 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4253, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_4255 lang.IFn; if
													linked_4254 == nil { ifn_4255 = lang.IFn_Cast(root_4253) } else { ifn_4255 = nil }; var arg_4256 any = A_arbace_go_repl_A_const_255.GetRawRoot__O(); var arg_4257 any = A_arbace_go_repl_A_const_256; var arg_4258 any; var root_4260 any = A_arbace_go_repl_A_const_46.GetRawRoot__O(); var linked_4261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4260, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_4262 lang.IFn; if linked_4261 == nil { ifn_4262 = lang.IFn_Cast(root_4260) } else { ifn_4262 = nil }; var arg_4263 any = t.F_nm; if linked_4261 == nil { arg_4258 = ifn_4262.Invoke_O__O(arg_4263) } else { arg_4258 = linked_4261.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_4260, arg_4263) }; var arg_4259 any; var root_4264 any = A_arbace_go_repl_A_const_101.GetRawRoot__O(); var linked_4265 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4264, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_4266 lang.IFn; if linked_4265 == nil { ifn_4266 = lang.IFn_Cast(root_4264) } else { ifn_4266 = nil }; var arg_4267 any; if lang.Util_Identical_O_O__Z_NoInit(results__1, nil) { arg_4267 = lang.Tuple_Create_O__IPersistentVector(lang.PersistentVector_EMPTY.Ref()) } else { if lang.Util_Equiv_J_O__Z_NoInit(1, results__1) { var tmp1 any; var root_4269 any = A_arbace_go_repl_A_const_218.GetRawRoot__O(); var linked_4270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4269, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_4271 lang.IFn

		if linked_4270 == nil { ifn_4271 = lang.IFn_Cast(root_4269) } else { ifn_4271 = nil }; var arg_4272 any = lang.PersistentVector_EMPTY.Ref(); var arg_4273 any = A_arbace_go_repl_A_const_257; if linked_4270 == nil { tmp1 = ifn_4271.Invoke_O_O__O(arg_4272, arg_4273) } else { tmp1 = linked_4270.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_4269, arg_4272, arg_4273) }
//line :514:1
		arg_4267 = lang.Tuple_Create_O__IPersistentVector(tmp1) } else { if A_arbace_go_repl_A_const_133 != nil { var tmp2 any = lang.PersistentVector_EMPTY.Ref(); var tmp3 any = A_arbace_go_repl_A_const_258; var tmp4 any; var root_4274 any = A_arbace_go_repl_A_const_86.GetRawRoot__O(); var linked_4275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4274, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_4276 lang.IFn


			if linked_4275 == nil { ifn_4276 = lang.IFn_Cast(root_4274) } else { ifn_4276 = nil }; var arg_4277 any; var root_4278 any = A_arbace_go_repl_A_const_259.GetRawRoot__O(); var linked_4279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4278, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_4280 lang.IFn; if linked_4279 == nil { ifn_4280 = lang.IFn_Cast(root_4278) } else { ifn_4280 = nil }; var arg_4281 any = results__1; var arg_4282 any = A_arbace_go_repl_A_const_260; if linked_4279 == nil { arg_4277 = ifn_4280.Invoke_O_O__O(arg_4281, arg_4282) } else { arg_4277 = linked_4279.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O_O__O(root_4278, arg_4281, arg_4282) }; if linked_4275 == nil { tmp4 = ifn_4276.Invoke_O__O(arg_4277) } else { tmp4 = linked_4275.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_4274, arg_4277) }
//line :514:1
			arg_4267 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, tmp3, tmp4) } else { arg_4267 = nil } } }; var arg_4268 any = t.F_stmts; if linked_4265 == nil { arg_4259 = ifn_4266.Invoke_O_O__O(arg_4267, arg_4268) } else { arg_4259 = linked_4265.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_4264, arg_4267, arg_4268) }; if linked_4254 == nil { form__2 = ifn_4255.Invoke_O_O_O_O__O(arg_4256, arg_4257, arg_4258, arg_4259) } else { form__2 = linked_4254.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_4253, arg_4256, arg_4257, arg_4258, arg_4259) }; var old__3 any; var root_4283 any = /*line :513:1*/A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_4284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4283, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_4285 lang.IFn; if
	linked_4284 == nil { ifn_4285 = lang.IFn_Cast(root_4283) } else { ifn_4285 = nil }; var arg_4286 any = t.F_st; if linked_4284 == nil { old__3 = ifn_4285.Invoke_O__O(arg_4286) } else { old__3 = linked_4284.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_4283, arg_4286) }; var files__4 any; var root_4287 any = /*line :513:1*/A_arbace_go_repl_A_const_80.GetRawRoot__O(); var linked_4288 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4287, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_4289 lang.IFn; if






	linked_4288 == nil { ifn_4289 = lang.IFn_Cast(root_4287) } else { ifn_4289 = nil }; var arg_4290 any; var tmp5 any = A_arbace_go_repl_eval_BANG__attempt__794000493_fn__794000494_A_New_O_O(form__2, old__3); var tmp6 *jrt.Class; var fncls__4299 *jrt.Class = A_arbace_go_repl_eval_BANG__attempt__794000493_fn__794000494_A_fn_class; if fncls__4299 == nil { var fncls__4299d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_146, false); A_arbace_go_repl_eval_BANG__attempt__794000493_fn__794000494_A_fn_class = fncls__4299d; tmp6 = fncls__4299d } else { tmp6 = fncls__4299 }; arg_4290 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_4291 any; var tmp7 any; var root_4300 any = A_arbace_go_repl_A_const_78.GetRawRoot__O(); var linked_4301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4300, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_4302 lang.IFn; if
	linked_4301 == nil { ifn_4302 = lang.IFn_Cast(root_4300) } else { ifn_4302 = nil }; var arg_4303 any; var tmp8 any = A_arbace_go_repl_eval_BANG__attempt__794000493_fn__794000496_A_New_O(old__3); var tmp9 *jrt.Class; var fncls__4305 *jrt.Class = A_arbace_go_repl_eval_BANG__attempt__794000493_fn__794000496_A_fn_class; if fncls__4305 == nil { var fncls__4305d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_147, false); A_arbace_go_repl_eval_BANG__attempt__794000493_fn__794000496_A_fn_class = fncls__4305d; tmp9 = fncls__4305d } else { tmp9 = fncls__4305 }; arg_4303 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_4304 any = A_arbace_go_repl_A_const_57.Invoke_O__O(old__3); if linked_4301 == nil { tmp7 = ifn_4302.Invoke_O_O__O(arg_4303, arg_4304) } else { tmp7 = linked_4301.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_4300, arg_4303, arg_4304) }; if jrt.J2g_Truth(tmp7) {
		arg_4291 = A_arbace_go_repl_A_const_57.Invoke_O__O(old__3) } else {
			var root_4306 any = A_arbace_go_repl_A_const_15.GetRawRoot__O(); var linked_4307 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4306, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_4308 lang.IFn; if linked_4307 == nil { ifn_4308 = lang.IFn_Cast(root_4306) } else { ifn_4308 = nil }; var arg_4309 any = A_arbace_go_repl_A_const_57.Invoke_O__O(old__3); var tmp10 any = A_arbace_go_repl_A_const_55; var arg_4310 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, A_arbace_go_repl_A_const_58.Invoke_O__O(old__3), A_arbace_go_repl_A_const_74, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_repl_A_const_81, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_repl_A_const_82, lang.PersistentVector_EMPTY.Ref())); if linked_4307 == nil { arg_4291 = ifn_4308.Invoke_O_O__O(arg_4309, arg_4310) } else { arg_4291 = linked_4307.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_4306, arg_4309, arg_4310) } }; if /*line :520:1*/ linked_4288 == nil { files__4 = ifn_4289.Invoke_O_O__O(arg_4290, arg_4291) } else { files__4 = linked_4288.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_4287, arg_4290, arg_4291) }; var root_4327 any =



	A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_4328 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4327, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_4329 lang.IFn; if linked_4328 == nil { ifn_4329 = lang.IFn_Cast(root_4327) } else { ifn_4329 = nil }; var arg_4330 any = t.F_st; var arg_4331 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_4332 any = A_arbace_go_repl_A_const_57; var arg_4333 any = files__4; if linked_4328 == nil { ifn_4329.Invoke_O_O_O_O__O(arg_4330, arg_4331, arg_4332, arg_4333) } else { linked_4328.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_4327, arg_4330, arg_4331, arg_4332, arg_4333) }; var tmp11 any; tmp12 := /*line :513:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var r__7 any; var root_4311 any = A_arbace_go_repl_A_const_225.GetRawRoot__O(); var linked_4312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4311, A_arbace_go_repl_check_source_A_fn_class); var ifn_4313 lang.IFn












		if linked_4312 == nil { ifn_4313 = lang.IFn_Cast(root_4311) } else { ifn_4313 = nil }; var arg_4314 any; var root_4316 any = A_arbace_go_repl_A_const_118.GetRawRoot__O(); var linked_4317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4316, A_arbace_go_repl_source_of_A_fn_class); var ifn_4318 lang.IFn; if linked_4317 == nil { ifn_4318 = lang.IFn_Cast(root_4316) } else { ifn_4318 = nil }; var arg_4319 any = t.F_st; if linked_4317 == nil { arg_4314 = ifn_4318.Invoke_O__O(arg_4319) } else { arg_4314 = linked_4317.(*A_arbace_go_repl_source_of_A).Invoke_O_O__O(root_4316, arg_4319) }; var arg_4315 any; if linked_4312 == nil { r__7 = ifn_4313.Invoke_O_O__O(arg_4314, arg_4315) } else { r__7 = linked_4312.(*A_arbace_go_repl_check_source_A).Invoke_O_O_O__O(root_4311, arg_4314, arg_4315) }
//line :513:1
		tmp11 = lang.Tuple_Create_O_O__IPersistentVector(r__7, form__2) }; return nil }(); var root_4320 any = A_arbace_go_repl_A_const_70.GetRawRoot__O(); var linked_4321 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4320, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_4322 lang.IFn; if














	linked_4321 == nil { ifn_4322 = lang.IFn_Cast(root_4320) } else { ifn_4322 = nil }; var arg_4323 any = t.F_st; var arg_4324 any = A_arbace_go_repl_A_const_71.GetRawRoot__O(); var arg_4325 any = A_arbace_go_repl_A_const_57; var arg_4326 any = A_arbace_go_repl_A_const_57.Invoke_O__O(old__3); if linked_4321 == nil { ifn_4322.Invoke_O_O_O_O__O(arg_4323, arg_4324, arg_4325, arg_4326) } else { linked_4321.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_4320, arg_4323, arg_4324, arg_4325, arg_4326) }; if /*line :513:1*/ tmp12 != nil { panic(tmp12) }; return tmp11 }






func A_arbace_go_repl_eval_BANG__attempt__794000493_fn__794000494_A_New_O_O(p0, p1 any) *A_arbace_go_repl_eval_BANG__attempt__794000493_fn__794000494_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_eval_BANG__attempt__794000493_fn__794000494_A{}; t.Ctor_O_O(p0, p1); return t }
//line :520:1
func (t *A_arbace_go_repl_eval_BANG__attempt__794000493_fn__794000494_A) Ctor_O_O(c__form, c__old any) { t.F_form = c__form; t.F_old = c__old }
//line :520:1
func (t *A_arbace_go_repl_eval_BANG__attempt__794000493_fn__794000494_A) Invoke_O_O__O(self, p1__794000476_SHARP___1 any) any { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_repl_A_const_58.Invoke_O__O(t.F_old), A_arbace_go_repl_A_const_55.Invoke_O__O(p1__794000476_SHARP___1)) { var root_4292 any = A_arbace_go_repl_A_const_79.GetRawRoot__O(); var linked_4293 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4292, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_4294 lang.IFn; if linked_4293 == nil { ifn_4294 = lang.IFn_Cast(root_4292) } else { ifn_4294 = nil }; var arg_4295 any = p1__794000476_SHARP___1; var arg_4296 any = A_arbace_go_repl_A_const_82; var arg_4297 any = A_arbace_go_repl_A_const_15.GetRawRoot__O(); var arg_4298 any = t.F_form; if linked_4293 == nil { return ifn_4294.Invoke_O_O_O_O__O(arg_4295, arg_4296, arg_4297, arg_4298) } else { return linked_4293.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_4292, arg_4295, arg_4296, arg_4297, arg_4298) } } else { return p1__794000476_SHARP___1 } }
func A_arbace_go_repl_eval_BANG__attempt__794000493_fn__794000496_A_New_O(p0 any) *A_arbace_go_repl_eval_BANG__attempt__794000493_fn__794000496_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_eval_BANG__attempt__794000493_fn__794000496_A{}; t.Ctor_O(p0); return t }
//line :521:1
func (t *A_arbace_go_repl_eval_BANG__attempt__794000493_fn__794000496_A) Ctor_O(c__old any) { t.F_old = c__old }
//line :521:1
func (t *A_arbace_go_repl_eval_BANG__attempt__794000493_fn__794000496_A) Invoke_O_O__O(self, p1__794000477_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_repl_A_const_58.Invoke_O__O(t.F_old), A_arbace_go_repl_A_const_55.Invoke_O__O(p1__794000477_SHARP___1))).Ref() }








func A_arbace_go_repl_eval_BANG__fn__794000499_A_New() *A_arbace_go_repl_eval_BANG__fn__794000499_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_eval_BANG__fn__794000499_A{}; t.Ctor(); return t }
//line :530:1
func (t *A_arbace_go_repl_eval_BANG__fn__794000499_A) Ctor() {}
//line :530:1
func (t *A_arbace_go_repl_eval_BANG__fn__794000499_A) Invoke_O_O__O(self, p1__794000478_SHARP___1 any) any { var tmp1 any; var tmp2 any = A_arbace_go_repl_A_const_261; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_go_repl_A_const_239.Invoke_O__O(p1__794000478_SHARP___1)); if and__1927000168__auto____2 { var root_4340 any = A_arbace_go_repl_A_const_262.GetRawRoot__O(); var linked_4341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4340, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_4342 lang.IFn; if linked_4341 == nil { ifn_4342 = lang.IFn_Cast(root_4340) } else { ifn_4342 = nil }; var arg_4343 any = A_arbace_go_repl_A_const_112.Invoke_O__O(p1__794000478_SHARP___1); var arg_4344 any = Lit_148; if linked_4341 == nil { tmp1 = ifn_4342.Invoke_O_O__O(arg_4343, arg_4344) } else { tmp1 = linked_4341.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_4340, arg_4343, arg_4344) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp1) { return p1__794000478_SHARP___1 } else { return nil } }
func A_arbace_go_repl_eval_BANG__fn__794000501_A_New() *A_arbace_go_repl_eval_BANG__fn__794000501_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_eval_BANG__fn__794000501_A{}; t.Ctor(); return t }
//line :531:1
func (t *A_arbace_go_repl_eval_BANG__fn__794000501_A) Ctor() {}
//line :531:1
func (t *A_arbace_go_repl_eval_BANG__fn__794000501_A) Invoke_O_O__O(self, p1__794000479_SHARP___1 any) any { var tmp1 any; var root_4351 any = A_arbace_go_repl_A_const_262.GetRawRoot__O(); var linked_4352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4351, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_4353 lang.IFn; if linked_4352 == nil { ifn_4353 = lang.IFn_Cast(root_4351) } else { ifn_4353 = nil }; var arg_4354 any = A_arbace_go_repl_A_const_112.Invoke_O__O(p1__794000479_SHARP___1); var arg_4355 any = Lit_149; if linked_4352 == nil { tmp1 = ifn_4353.Invoke_O_O__O(arg_4354, arg_4355) } else { tmp1 = linked_4352.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_4351, arg_4354, arg_4355) }; if jrt.J2g_Truth(tmp1) { return p1__794000479_SHARP___1 } else { return nil } }





func A_arbace_go_repl_eval_BANG__fn__794000506_A_New() *A_arbace_go_repl_eval_BANG__fn__794000506_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_eval_BANG__fn__794000506_A{}; t.Ctor(); return t }
//line :537:1
func (t *A_arbace_go_repl_eval_BANG__fn__794000506_A) Ctor() {}
//line :537:1
func (t *A_arbace_go_repl_eval_BANG__fn__794000506_A) Invoke_O_O__O(self, p1__794000480_SHARP___1 any) any { var tmp1 any = A_arbace_go_repl_A_const_238; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_repl_A_const_239.Invoke_O__O(p1__794000480_SHARP___1))).Ref() }



func A_arbace_go_repl_eval_BANG__fn__794000508_A_New_O_O(p0, p1 any) *A_arbace_go_repl_eval_BANG__fn__794000508_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_eval_BANG__fn__794000508_A{}; t.Ctor_O_O(p0, p1); return t }
//line :541:1
func (t *A_arbace_go_repl_eval_BANG__fn__794000508_A) Ctor_O_O(c__form, c__old any) { t.F_form = c__form; t.F_old = c__old }
//line :541:1
func (t *A_arbace_go_repl_eval_BANG__fn__794000508_A) Invoke_O_O__O(self, p1__794000481_SHARP___1 any) any { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_repl_A_const_58.Invoke_O__O(t.F_old), A_arbace_go_repl_A_const_55.Invoke_O__O(p1__794000481_SHARP___1)) { var root_4476 any = A_arbace_go_repl_A_const_79.GetRawRoot__O(); var linked_4477 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4476, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_4478 lang.IFn; if linked_4477 == nil { ifn_4478 = lang.IFn_Cast(root_4476) } else { ifn_4478 = nil }; var arg_4479 any = p1__794000481_SHARP___1; var arg_4480 any = A_arbace_go_repl_A_const_82; var arg_4481 any = A_arbace_go_repl_A_const_15.GetRawRoot__O(); var arg_4482 any = t.F_form; if linked_4477 == nil { return ifn_4478.Invoke_O_O_O_O__O(arg_4479, arg_4480, arg_4481, arg_4482) } else { return linked_4477.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_4476, arg_4479, arg_4480, arg_4481, arg_4482) } } else { return p1__794000481_SHARP___1 } }



func A_arbace_go_repl_eval_BANG__fn__794000512_A_New_O(p0 any) *A_arbace_go_repl_eval_BANG__fn__794000512_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_eval_BANG__fn__794000512_A{}; t.Ctor_O(p0); return t }
//line :545:1
func (t *A_arbace_go_repl_eval_BANG__fn__794000512_A) Ctor_O(c__obj any) { t.F_obj = c__obj }
//line :545:1
func (t *A_arbace_go_repl_eval_BANG__fn__794000512_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_4404 any = A_arbace_go_repl_A_const_191.GetRawRoot__O(); var linked_4405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4404, aot_arbace_go_build.A_arbace_go_build_desc_A_fn_class); var ifn_4406 lang.IFn; if linked_4405 == nil { ifn_4406 = lang.IFn_Cast(root_4404) } else { ifn_4406 = nil }; var arg_4407 any; var root_4408 any = A_arbace_go_repl_A_const_127.GetRawRoot__O(); var linked_4409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4408, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_4410 lang.IFn; if linked_4409 == nil { ifn_4410 = lang.IFn_Cast(root_4408) } else { ifn_4410 = nil }; var arg_4411 any; var t_ any = t.F_obj; t.F_obj = nil; arg_4411 = t_; var arg_4412 any = A_arbace_go_repl_A_const_142; if linked_4409 == nil { arg_4407 = ifn_4410.Invoke_O_O__O(arg_4411, arg_4412) } else { arg_4407 = linked_4409.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_4408, arg_4411, arg_4412) }; if linked_4405 == nil { tmp1 = ifn_4406.Invoke_O__O(arg_4407) } else { tmp1 = linked_4405.(*aot_arbace_go_build.A_arbace_go_build_desc_A).Invoke_O_O__O(root_4404, arg_4407) } }; return nil }(); var root_4413 any = A_arbace_go_repl_A_const_200.GetRawRoot__O(); var linked_4414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4413, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_4415 lang.IFn; if linked_4414 == nil { ifn_4415 = lang.IFn_Cast(root_4413) } else { ifn_4415 = nil }; if linked_4414 == nil { ifn_4415.Invoke__O() } else { linked_4414.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_4413) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }





func A_arbace_go_repl_run_main_BANG__A_New() *A_arbace_go_repl_run_main_BANG__A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_run_main_BANG__A{}; t.Ctor(); return t }
//line :551:1
func (t *A_arbace_go_repl_run_main_BANG__A) Ctor() {}
//line :551:1
func (t *A_arbace_go_repl_run_main_BANG__A) Invoke_O_O__O(self, ns_sym__0 any) any { var st__2 any; var root_4497 any = A_arbace_go_repl_A_const_72.GetRawRoot__O(); var linked_4498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4497, A_arbace_go_repl_package_state_A_fn_class); var ifn_4499 lang.IFn; if


	linked_4498 == nil { ifn_4499 = lang.IFn_Cast(root_4497) } else { ifn_4499 = nil }; var arg_4500 any = ns_sym__0; var arg_4501 any = jrt.Boolean_FALSE.Ref(); if linked_4498 == nil { st__2 = ifn_4499.Invoke_O_O__O(arg_4500, arg_4501) } else { st__2 = linked_4498.(*A_arbace_go_repl_package_state_A).Invoke_O_O_O__O(root_4497, arg_4500, arg_4501) }; var cell__3 any; var root_4502 any = /*line :551:1*/A_arbace_go_repl_A_const_153.GetRawRoot__O(); var linked_4503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4502, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4504 lang.IFn; if



	linked_4503 == nil { ifn_4504 = lang.IFn_Cast(root_4502) } else { ifn_4504 = nil }; var arg_4505 any; var root_4507 any = A_arbace_go_repl_A_const_13.GetRawRoot__O(); var linked_4508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4507, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_4509 lang.IFn; if linked_4508 == nil { ifn_4509 = lang.IFn_Cast(root_4507) } else { ifn_4509 = nil }; var arg_4510 any = st__2; if linked_4508 == nil { arg_4505 = ifn_4509.Invoke_O__O(arg_4510) } else { arg_4505 = linked_4508.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_4507, arg_4510) }; var arg_4506 any = A_arbace_go_repl_A_const_266; if linked_4503 == nil { cell__3 = ifn_4504.Invoke_O_O__O(arg_4505, arg_4506) } else { cell__3 = linked_4503.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4502, arg_4505, arg_4506) }; if
	jrt.J2g_Truth(cell__3) { } else { var tmp1 any; var root_4511 any = A_arbace_go_repl_A_const_69.GetRawRoot__O(); var linked_4512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4511, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_4513 lang.IFn
		if linked_4512 == nil { ifn_4513 = lang.IFn_Cast(root_4511) } else { ifn_4513 = nil }; var arg_4514 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_168), jrt.RefArrayOf(jrt.Object_class, ns_sym__0, nil)).Ref(); var arg_4515 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_4512 == nil { tmp1 = ifn_4513.Invoke_O_O__O(arg_4514, arg_4515) } else { tmp1 = linked_4512.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_4511, arg_4514, arg_4515) }
//line :556:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }; var root_4516 any =

	A_arbace_go_repl_A_const_230.GetRawRoot__O(); var linked_4517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4516, A_arbace_go_repl_call0_A_fn_class); var ifn_4518 lang.IFn; if linked_4517 == nil { ifn_4518 = lang.IFn_Cast(root_4516) } else { ifn_4518 = nil }; var arg_4519 any = cell__3; var arg_4520 any = Lit_97; if linked_4517 == nil { ifn_4518.Invoke_O_O__O(arg_4519, arg_4520) } else { linked_4517.(*A_arbace_go_repl_call0_A).Invoke_O_O_O__O(root_4516, arg_4519, arg_4520) }; return nil }


func A_arbace_go_repl_check_BANG__A_New() *A_arbace_go_repl_check_BANG__A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_check_BANG__A{}; t.Ctor(); return t }
//line :561:1
func (t *A_arbace_go_repl_check_BANG__A) Ctor() {}
//line :561:1
func (t *A_arbace_go_repl_check_BANG__A) Invoke_O_O__O(self, ns_sym__0 any) any { var st__2 any; var root_4521 any = A_arbace_go_repl_A_const_72.GetRawRoot__O(); var linked_4522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4521, A_arbace_go_repl_package_state_A_fn_class); var ifn_4523 lang.IFn; if


	linked_4522 == nil { ifn_4523 = lang.IFn_Cast(root_4521) } else { ifn_4523 = nil }; var arg_4524 any = ns_sym__0; var arg_4525 any = jrt.Boolean_FALSE.Ref(); if linked_4522 == nil { st__2 = ifn_4523.Invoke_O_O__O(arg_4524, arg_4525) } else { st__2 = linked_4522.(*A_arbace_go_repl_package_state_A).Invoke_O_O_O__O(root_4521, arg_4524, arg_4525) }; var tmp1 /*line :565:1*/*lang.Keyword = A_arbace_go_repl_A_const_228; var tmp2 any; var root_4526 any = A_arbace_go_repl_A_const_225.GetRawRoot__O(); var linked_4527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4526, A_arbace_go_repl_check_source_A_fn_class); var ifn_4528 lang.IFn; if linked_4527 == nil { ifn_4528 = lang.IFn_Cast(root_4526) } else { ifn_4528 = nil }; var arg_4529 any; var root_4531 any = A_arbace_go_repl_A_const_118.GetRawRoot__O(); var linked_4532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4531, A_arbace_go_repl_source_of_A_fn_class); var ifn_4533 lang.IFn; if linked_4532 == nil { ifn_4533 = lang.IFn_Cast(root_4531) } else { ifn_4533 = nil }; var arg_4534 any = st__2; if linked_4532 == nil { arg_4529 = ifn_4533.Invoke_O__O(arg_4534) } else { arg_4529 = linked_4532.(*A_arbace_go_repl_source_of_A).Invoke_O_O__O(root_4531, arg_4534) }; var arg_4530 any; if linked_4527 == nil { tmp2 = ifn_4528.Invoke_O_O__O(arg_4529, arg_4530) } else { tmp2 = linked_4527.(*A_arbace_go_repl_check_source_A).Invoke_O_O_O__O(root_4526, arg_4529, arg_4530) }; return tmp1.Invoke_O__O(tmp2) }





















































































































































































































































































































































































































type A_arbace_go_repl_A struct{ jrt.Object }

var A_arbace_go_repl_A_const_pool *jrt.RefArray

var A_arbace_go_repl_A_const_0 *lang.Var

var A_arbace_go_repl_A_const_1 any

var A_arbace_go_repl_A_const_2 *lang.Var

var A_arbace_go_repl_A_const_3 any

var A_arbace_go_repl_A_const_4 any

var A_arbace_go_repl_A_const_5 any

var A_arbace_go_repl_A_const_6 any

var A_arbace_go_repl_A_const_7 any

var A_arbace_go_repl_A_const_8 any

var A_arbace_go_repl_A_const_9 any

var A_arbace_go_repl_A_const_10 any

var A_arbace_go_repl_A_const_11 any

var A_arbace_go_repl_A_const_12 *lang.Var

var A_arbace_go_repl_A_const_13 *lang.Var

var A_arbace_go_repl_A_const_14 *lang.Var

var A_arbace_go_repl_A_const_15 *lang.Var

var A_arbace_go_repl_A_const_16 any

var A_arbace_go_repl_A_const_17 *lang.Var

var A_arbace_go_repl_A_const_18 *lang.Var

var A_arbace_go_repl_A_const_19 *lang.Var

var A_arbace_go_repl_A_const_20 *lang.Keyword

var A_arbace_go_repl_A_const_21 *lang.Var

var A_arbace_go_repl_A_const_22 *lang.Var

var A_arbace_go_repl_A_const_23 any

var A_arbace_go_repl_A_const_24 *lang.Keyword

var A_arbace_go_repl_A_const_25 *lang.Keyword

var A_arbace_go_repl_A_const_26 *lang.Var

var A_arbace_go_repl_A_const_27 *lang.Var

var A_arbace_go_repl_A_const_28 *lang.Var

var A_arbace_go_repl_A_const_29 *lang.Var

var A_arbace_go_repl_A_const_30 *lang.Var

var A_arbace_go_repl_A_const_31 *lang.Var

var A_arbace_go_repl_A_const_32 *lang.Var

var A_arbace_go_repl_A_const_33 *lang.Var

var A_arbace_go_repl_A_const_34 *lang.Var

var A_arbace_go_repl_A_const_35 any

var A_arbace_go_repl_A_const_36 *lang.Keyword

var A_arbace_go_repl_A_const_37 *lang.Var

var A_arbace_go_repl_A_const_38 *lang.Var

var A_arbace_go_repl_A_const_39 *lang.Var

var A_arbace_go_repl_A_const_40 *lang.Var

var A_arbace_go_repl_A_const_41 any

var A_arbace_go_repl_A_const_42 *lang.Var

var A_arbace_go_repl_A_const_43 *lang.Var

var A_arbace_go_repl_A_const_44 *lang.Var

var A_arbace_go_repl_A_const_45 *lang.Var

var A_arbace_go_repl_A_const_46 *lang.Var

var A_arbace_go_repl_A_const_47 *lang.Var

var A_arbace_go_repl_A_const_48 *lang.Var

var A_arbace_go_repl_A_const_49 *lang.Var

var A_arbace_go_repl_A_const_50 *lang.Var

var A_arbace_go_repl_A_const_51 *lang.Var

var A_arbace_go_repl_A_const_52 any

var A_arbace_go_repl_A_const_53 *lang.Var

var A_arbace_go_repl_A_const_54 *lang.Keyword

var A_arbace_go_repl_A_const_55 *lang.Keyword

var A_arbace_go_repl_A_const_56 *lang.Keyword

var A_arbace_go_repl_A_const_57 *lang.Keyword

var A_arbace_go_repl_A_const_58 *lang.Keyword

var A_arbace_go_repl_A_const_59 *lang.Keyword

var A_arbace_go_repl_A_const_60 *lang.Keyword

var A_arbace_go_repl_A_const_61 *lang.Keyword

var A_arbace_go_repl_A_const_62 *lang.Keyword

var A_arbace_go_repl_A_const_63 *lang.Var

var A_arbace_go_repl_A_const_64 *lang.Var

var A_arbace_go_repl_A_const_65 *lang.Var

var A_arbace_go_repl_A_const_66 *lang.Var

var A_arbace_go_repl_A_const_67 any

var A_arbace_go_repl_A_const_68 *lang.Var

var A_arbace_go_repl_A_const_69 *lang.Var

var A_arbace_go_repl_A_const_70 *lang.Var

var A_arbace_go_repl_A_const_71 *lang.Var

var A_arbace_go_repl_A_const_72 *lang.Var

var A_arbace_go_repl_A_const_73 *lang.Var

var A_arbace_go_repl_A_const_74 *lang.Keyword

var A_arbace_go_repl_A_const_75 *lang.Keyword

var A_arbace_go_repl_A_const_76 *lang.Keyword

var A_arbace_go_repl_A_const_77 *lang.Keyword

var A_arbace_go_repl_A_const_78 *lang.Var

var A_arbace_go_repl_A_const_79 *lang.Var

var A_arbace_go_repl_A_const_80 *lang.Var

var A_arbace_go_repl_A_const_81 *lang.Keyword

var A_arbace_go_repl_A_const_82 *lang.Keyword

var A_arbace_go_repl_A_const_83 *lang.Var

var A_arbace_go_repl_A_const_84 *lang.Var

var A_arbace_go_repl_A_const_85 *lang.Keyword

var A_arbace_go_repl_A_const_86 *lang.Var

var A_arbace_go_repl_A_const_87 *lang.Var

var A_arbace_go_repl_A_const_88 *lang.Var

var A_arbace_go_repl_A_const_89 *lang.Var

var A_arbace_go_repl_A_const_90 *lang.Var

var A_arbace_go_repl_A_const_91 *lang.Var

var A_arbace_go_repl_A_const_92 *lang.Var

var A_arbace_go_repl_A_const_93 *lang.Var

var A_arbace_go_repl_A_const_94 *lang.Var

var A_arbace_go_repl_A_const_95 *lang.Var

var A_arbace_go_repl_A_const_96 *lang.Var

var A_arbace_go_repl_A_const_97 *lang.Var

var A_arbace_go_repl_A_const_98 *lang.Var

var A_arbace_go_repl_A_const_99 *lang.Var

var A_arbace_go_repl_A_const_100 *lang.Var

var A_arbace_go_repl_A_const_101 *lang.Var

var A_arbace_go_repl_A_const_102 *lang.Var

var A_arbace_go_repl_A_const_103 *lang.Var

var A_arbace_go_repl_A_const_104 *lang.Var

var A_arbace_go_repl_A_const_105 any

var A_arbace_go_repl_A_const_106 *lang.Keyword

var A_arbace_go_repl_A_const_107 *lang.Var

var A_arbace_go_repl_A_const_108 *lang.Keyword

var A_arbace_go_repl_A_const_109 any

var A_arbace_go_repl_A_const_110 *lang.Keyword

var A_arbace_go_repl_A_const_111 *lang.Keyword

var A_arbace_go_repl_A_const_112 *lang.Keyword

var A_arbace_go_repl_A_const_113 *lang.Var

var A_arbace_go_repl_A_const_114 any

var A_arbace_go_repl_A_const_115 *lang.Var

var A_arbace_go_repl_A_const_116 *lang.Var

var A_arbace_go_repl_A_const_117 *lang.Var

var A_arbace_go_repl_A_const_118 *lang.Var

var A_arbace_go_repl_A_const_119 *lang.Keyword

var A_arbace_go_repl_A_const_120 *lang.Var

var A_arbace_go_repl_A_const_121 *lang.Keyword

var A_arbace_go_repl_A_const_122 *lang.Var

var A_arbace_go_repl_A_const_123 *lang.Var

var A_arbace_go_repl_A_const_124 *lang.Var

var A_arbace_go_repl_A_const_125 *lang.Var

var A_arbace_go_repl_A_const_126 *lang.Keyword

var A_arbace_go_repl_A_const_127 *lang.Var

var A_arbace_go_repl_A_const_128 *lang.Keyword

var A_arbace_go_repl_A_const_129 *lang.Var

var A_arbace_go_repl_A_const_130 *lang.Var

var A_arbace_go_repl_A_const_131 *lang.Var

var A_arbace_go_repl_A_const_132 *lang.Var

var A_arbace_go_repl_A_const_133 *lang.Keyword

var A_arbace_go_repl_A_const_134 *lang.Keyword

var A_arbace_go_repl_A_const_135 *lang.Keyword

var A_arbace_go_repl_A_const_136 *lang.Keyword

var A_arbace_go_repl_A_const_137 *lang.Keyword

var A_arbace_go_repl_A_const_138 *lang.Var

var A_arbace_go_repl_A_const_139 *lang.Keyword

var A_arbace_go_repl_A_const_140 *lang.Keyword

var A_arbace_go_repl_A_const_141 *lang.Keyword

var A_arbace_go_repl_A_const_142 *lang.Keyword

var A_arbace_go_repl_A_const_143 *lang.Keyword

var A_arbace_go_repl_A_const_144 *lang.Keyword

var A_arbace_go_repl_A_const_145 any

var A_arbace_go_repl_A_const_146 *lang.Keyword

var A_arbace_go_repl_A_const_147 *lang.Keyword

var A_arbace_go_repl_A_const_148 *lang.Keyword

var A_arbace_go_repl_A_const_149 *lang.Keyword

var A_arbace_go_repl_A_const_150 *lang.Keyword

var A_arbace_go_repl_A_const_151 *lang.Keyword

var A_arbace_go_repl_A_const_152 *lang.Var

var A_arbace_go_repl_A_const_153 *lang.Var

var A_arbace_go_repl_A_const_154 any

var A_arbace_go_repl_A_const_155 *lang.Keyword

var A_arbace_go_repl_A_const_156 *lang.Keyword

var A_arbace_go_repl_A_const_157 *lang.Keyword

var A_arbace_go_repl_A_const_158 *lang.Var

var A_arbace_go_repl_A_const_159 *lang.Keyword

var A_arbace_go_repl_A_const_160 *lang.Keyword

var A_arbace_go_repl_A_const_161 *lang.Var

var A_arbace_go_repl_A_const_162 *lang.Var

var A_arbace_go_repl_A_const_163 *lang.Var

var A_arbace_go_repl_A_const_164 *lang.Var

var A_arbace_go_repl_A_const_165 *lang.Var

var A_arbace_go_repl_A_const_166 any

var A_arbace_go_repl_A_const_167 *lang.Keyword

var A_arbace_go_repl_A_const_168 *lang.Var

var A_arbace_go_repl_A_const_169 *lang.Keyword

var A_arbace_go_repl_A_const_170 *lang.Keyword

var A_arbace_go_repl_A_const_171 *lang.Keyword

var A_arbace_go_repl_A_const_172 *lang.Keyword

var A_arbace_go_repl_A_const_173 *lang.Keyword

var A_arbace_go_repl_A_const_174 *lang.Var

var A_arbace_go_repl_A_const_175 *lang.Keyword

var A_arbace_go_repl_A_const_176 *lang.Keyword

var A_arbace_go_repl_A_const_177 *lang.Keyword

var A_arbace_go_repl_A_const_178 *lang.Keyword

var A_arbace_go_repl_A_const_179 *lang.Keyword

var A_arbace_go_repl_A_const_180 *lang.Var

var A_arbace_go_repl_A_const_181 *lang.Keyword

var A_arbace_go_repl_A_const_182 *lang.Keyword

var A_arbace_go_repl_A_const_183 *lang.Var

var A_arbace_go_repl_A_const_184 *lang.Keyword

var A_arbace_go_repl_A_const_185 *lang.Keyword

var A_arbace_go_repl_A_const_186 *lang.Keyword

var A_arbace_go_repl_A_const_187 *lang.Keyword

var A_arbace_go_repl_A_const_188 *lang.Keyword

var A_arbace_go_repl_A_const_189 *lang.Var

var A_arbace_go_repl_A_const_190 *lang.Keyword

var A_arbace_go_repl_A_const_191 *lang.Var

var A_arbace_go_repl_A_const_192 *lang.Keyword

var A_arbace_go_repl_A_const_193 *lang.Keyword

var A_arbace_go_repl_A_const_194 *lang.Var

var A_arbace_go_repl_A_const_195 *lang.Keyword

var A_arbace_go_repl_A_const_196 *lang.Keyword

var A_arbace_go_repl_A_const_197 *lang.Keyword

var A_arbace_go_repl_A_const_198 any

var A_arbace_go_repl_A_const_199 *lang.Keyword

var A_arbace_go_repl_A_const_200 *lang.Var

var A_arbace_go_repl_A_const_201 *lang.Keyword

var A_arbace_go_repl_A_const_202 *lang.Var

var A_arbace_go_repl_A_const_203 *lang.Var

var A_arbace_go_repl_A_const_204 *lang.Var

var A_arbace_go_repl_A_const_205 *lang.Var

var A_arbace_go_repl_A_const_206 *lang.Keyword

var A_arbace_go_repl_A_const_207 *lang.Var

var A_arbace_go_repl_A_const_208 *lang.Var

var A_arbace_go_repl_A_const_209 *lang.Var

var A_arbace_go_repl_A_const_210 *lang.Var

var A_arbace_go_repl_A_const_211 *lang.Var

var A_arbace_go_repl_A_const_212 *lang.Keyword

var A_arbace_go_repl_A_const_213 *lang.Keyword

var A_arbace_go_repl_A_const_214 *lang.Keyword

var A_arbace_go_repl_A_const_215 *lang.Var

var A_arbace_go_repl_A_const_216 *lang.Keyword

var A_arbace_go_repl_A_const_217 *lang.Var

var A_arbace_go_repl_A_const_218 *lang.Var

var A_arbace_go_repl_A_const_219 *lang.Keyword

var A_arbace_go_repl_A_const_220 *lang.Keyword

var A_arbace_go_repl_A_const_221 *lang.Keyword

var A_arbace_go_repl_A_const_222 *lang.Var

var A_arbace_go_repl_A_const_223 *lang.Var

var A_arbace_go_repl_A_const_224 *lang.Keyword

var A_arbace_go_repl_A_const_225 *lang.Var

var A_arbace_go_repl_A_const_226 *lang.Var

var A_arbace_go_repl_A_const_227 any

var A_arbace_go_repl_A_const_228 *lang.Keyword

var A_arbace_go_repl_A_const_229 *lang.Keyword

var A_arbace_go_repl_A_const_230 *lang.Var

var A_arbace_go_repl_A_const_231 *lang.Var

var A_arbace_go_repl_A_const_232 *lang.Var

var A_arbace_go_repl_A_const_233 *lang.Var

var A_arbace_go_repl_A_const_234 *lang.Var

var A_arbace_go_repl_A_const_235 *lang.Var

var A_arbace_go_repl_A_const_236 *lang.Var

var A_arbace_go_repl_A_const_237 *lang.Var

var A_arbace_go_repl_A_const_238 *lang.Keyword

var A_arbace_go_repl_A_const_239 *lang.Keyword

var A_arbace_go_repl_A_const_240 *lang.Var

var A_arbace_go_repl_A_const_241 *lang.Keyword

var A_arbace_go_repl_A_const_242 *lang.Keyword

var A_arbace_go_repl_A_const_243 *lang.Var

var A_arbace_go_repl_A_const_244 *lang.Var

var A_arbace_go_repl_A_const_245 *lang.Var

var A_arbace_go_repl_A_const_246 *lang.Var

var A_arbace_go_repl_A_const_247 *lang.Var

var A_arbace_go_repl_A_const_248 *lang.Var

var A_arbace_go_repl_A_const_249 *lang.Var

var A_arbace_go_repl_A_const_250 any

var A_arbace_go_repl_A_const_251 *lang.Var

var A_arbace_go_repl_A_const_252 *lang.Var

var A_arbace_go_repl_A_const_253 any

var A_arbace_go_repl_A_const_254 *lang.Var

var A_arbace_go_repl_A_const_255 *lang.Var

var A_arbace_go_repl_A_const_256 any

var A_arbace_go_repl_A_const_257 any

var A_arbace_go_repl_A_const_258 *lang.Keyword

var A_arbace_go_repl_A_const_259 *lang.Var

var A_arbace_go_repl_A_const_260 any

var A_arbace_go_repl_A_const_261 *lang.Keyword

var A_arbace_go_repl_A_const_262 *lang.Var

var A_arbace_go_repl_A_const_263 *lang.Var

var A_arbace_go_repl_A_const_264 any

var A_arbace_go_repl_A_const_265 any

var A_arbace_go_repl_A_const_266 any

var A_arbace_go_repl_A_init jrt.ClassInit

func A_arbace_go_repl_A_Init() { if !A_arbace_go_repl_A_init.Done() { A_arbace_go_repl_A_init.Run(A_arbace_go_repl_A_clinit) } }

func A_arbace_go_repl_A_clinit() { A_arbace_go_repl_A_clinit_p0(); A_arbace_go_repl_A_clinit_p1(); A_arbace_go_repl_A_clinit_p2(); A_arbace_go_repl_A_clinit_p3(); A_arbace_go_repl_A_clinit_p4(); A_arbace_go_repl_A_clinit_p5(); A_arbace_go_repl_A_clinit_p6(); A_arbace_go_repl_A_clinit_p7(); A_arbace_go_repl_A_clinit_p8(); A_arbace_go_repl_A_clinit_p9(); A_arbace_go_repl_A_clinit_p10(); A_arbace_go_repl_A_clinit_p11(); A_arbace_go_repl_A_clinit_p12(); A_arbace_go_repl_A_clinit_p13(); A_arbace_go_repl_A_clinit_p14(); A_arbace_go_repl_A_clinit_p15(); A_arbace_go_repl_A_clinit_p16(); A_arbace_go_repl_A_clinit_p17(); A_arbace_go_repl_A_clinit_p18(); A_arbace_go_repl_A_clinit_p19(); A_arbace_go_repl_A_clinit_p20(); A_arbace_go_repl_A_clinit_p21(); A_arbace_go_repl_A_clinit_p22() }

func A_arbace_go_repl_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_repl_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 390); A_arbace_go_repl_A_const_0 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[123]); A_arbace_go_repl_A_const_1 = A_arbace_go_repl_A_const_pool.A[124]; A_arbace_go_repl_A_const_2 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[125]); A_arbace_go_repl_A_const_3 = A_arbace_go_repl_A_const_pool.A[126]; A_arbace_go_repl_A_const_4 = A_arbace_go_repl_A_const_pool.A[127]; A_arbace_go_repl_A_const_5 = A_arbace_go_repl_A_const_pool.A[128]; A_arbace_go_repl_A_const_6 = A_arbace_go_repl_A_const_pool.A[129]; A_arbace_go_repl_A_const_7 = A_arbace_go_repl_A_const_pool.A[130]; A_arbace_go_repl_A_const_8 = A_arbace_go_repl_A_const_pool.A[131]; A_arbace_go_repl_A_const_9 = A_arbace_go_repl_A_const_pool.A[132]; A_arbace_go_repl_A_const_10 = A_arbace_go_repl_A_const_pool.A[133]; A_arbace_go_repl_A_const_11 = A_arbace_go_repl_A_const_pool.A[134]; A_arbace_go_repl_A_const_12 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[135]) }

func A_arbace_go_repl_A_clinit_p1() { A_arbace_go_repl_A_const_13 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[136]); A_arbace_go_repl_A_const_14 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[137]); A_arbace_go_repl_A_const_15 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[138]); A_arbace_go_repl_A_const_16 = A_arbace_go_repl_A_const_pool.A[139]; A_arbace_go_repl_A_const_17 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[140]); A_arbace_go_repl_A_const_18 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[141]); A_arbace_go_repl_A_const_19 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[142]); A_arbace_go_repl_A_const_20 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[143]); A_arbace_go_repl_A_const_21 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[144]); A_arbace_go_repl_A_const_22 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[145]); A_arbace_go_repl_A_const_23 = A_arbace_go_repl_A_const_pool.A[146]; A_arbace_go_repl_A_const_24 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[147]) }

func A_arbace_go_repl_A_clinit_p2() { A_arbace_go_repl_A_const_25 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[148]); A_arbace_go_repl_A_const_26 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[149]); A_arbace_go_repl_A_const_27 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[150]); A_arbace_go_repl_A_const_28 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[151]); A_arbace_go_repl_A_const_29 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[152]); A_arbace_go_repl_A_const_30 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[153]); A_arbace_go_repl_A_const_31 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[154]); A_arbace_go_repl_A_const_32 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[155]); A_arbace_go_repl_A_const_33 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[156]); A_arbace_go_repl_A_const_34 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[157]); A_arbace_go_repl_A_const_35 = A_arbace_go_repl_A_const_pool.A[158]; A_arbace_go_repl_A_const_36 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[159]) }

func A_arbace_go_repl_A_clinit_p3() { A_arbace_go_repl_A_const_37 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[160]); A_arbace_go_repl_A_const_38 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[161]); A_arbace_go_repl_A_const_39 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[162]); A_arbace_go_repl_A_const_40 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[163]); A_arbace_go_repl_A_const_41 = A_arbace_go_repl_A_const_pool.A[164]; A_arbace_go_repl_A_const_42 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[165]); A_arbace_go_repl_A_const_43 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[166]); A_arbace_go_repl_A_const_44 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[167]); A_arbace_go_repl_A_const_45 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[168]); A_arbace_go_repl_A_const_46 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[169]); A_arbace_go_repl_A_const_47 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[170]); A_arbace_go_repl_A_const_48 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[171]) }

func A_arbace_go_repl_A_clinit_p4() { A_arbace_go_repl_A_const_49 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[172]); A_arbace_go_repl_A_const_50 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[173]); A_arbace_go_repl_A_const_51 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[174]); A_arbace_go_repl_A_const_52 = A_arbace_go_repl_A_const_pool.A[175]; A_arbace_go_repl_A_const_53 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[176]); A_arbace_go_repl_A_const_54 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[177]); A_arbace_go_repl_A_const_55 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[178]); A_arbace_go_repl_A_const_56 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[179]); A_arbace_go_repl_A_const_57 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[180]); A_arbace_go_repl_A_const_58 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[181]); A_arbace_go_repl_A_const_59 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[182]); A_arbace_go_repl_A_const_60 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[183]) }

func A_arbace_go_repl_A_clinit_p5() { A_arbace_go_repl_A_const_61 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[184]); A_arbace_go_repl_A_const_62 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[185]); A_arbace_go_repl_A_const_63 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[186]); A_arbace_go_repl_A_const_64 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[187]); A_arbace_go_repl_A_const_65 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[188]); A_arbace_go_repl_A_const_66 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[189]); A_arbace_go_repl_A_const_67 = A_arbace_go_repl_A_const_pool.A[190]; A_arbace_go_repl_A_const_68 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[191]); A_arbace_go_repl_A_const_69 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[192]); A_arbace_go_repl_A_const_70 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[193]); A_arbace_go_repl_A_const_71 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[194]); A_arbace_go_repl_A_const_72 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[195]) }

func A_arbace_go_repl_A_clinit_p6() { A_arbace_go_repl_A_const_73 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[196]); A_arbace_go_repl_A_const_74 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[197]); A_arbace_go_repl_A_const_75 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[198]); A_arbace_go_repl_A_const_76 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[199]); A_arbace_go_repl_A_const_77 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[200]); A_arbace_go_repl_A_const_78 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[201]); A_arbace_go_repl_A_const_79 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[202]); A_arbace_go_repl_A_const_80 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[203]); A_arbace_go_repl_A_const_81 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[204]); A_arbace_go_repl_A_const_82 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[205]); A_arbace_go_repl_A_const_83 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[206]); A_arbace_go_repl_A_const_84 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[207]) }

func A_arbace_go_repl_A_clinit_p7() { A_arbace_go_repl_A_const_85 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[208]); A_arbace_go_repl_A_const_86 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[209]); A_arbace_go_repl_A_const_87 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[210]); A_arbace_go_repl_A_const_88 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[211]); A_arbace_go_repl_A_const_89 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[212]); A_arbace_go_repl_A_const_90 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[213]); A_arbace_go_repl_A_const_91 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[214]); A_arbace_go_repl_A_const_92 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[215]); A_arbace_go_repl_A_const_93 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[216]); A_arbace_go_repl_A_const_94 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[217]); A_arbace_go_repl_A_const_95 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[218]); A_arbace_go_repl_A_const_96 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[219]) }

func A_arbace_go_repl_A_clinit_p8() { A_arbace_go_repl_A_const_97 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[220]); A_arbace_go_repl_A_const_98 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[221]); A_arbace_go_repl_A_const_99 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[222]); A_arbace_go_repl_A_const_100 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[223]); A_arbace_go_repl_A_const_101 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[224]); A_arbace_go_repl_A_const_102 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[225]); A_arbace_go_repl_A_const_103 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[226]); A_arbace_go_repl_A_const_104 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[227]); A_arbace_go_repl_A_const_105 = A_arbace_go_repl_A_const_pool.A[228]; A_arbace_go_repl_A_const_106 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[229]); A_arbace_go_repl_A_const_107 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[230]); A_arbace_go_repl_A_const_108 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[231]) }

func A_arbace_go_repl_A_clinit_p9() { A_arbace_go_repl_A_const_109 = A_arbace_go_repl_A_const_pool.A[232]; A_arbace_go_repl_A_const_110 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[233]); A_arbace_go_repl_A_const_111 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[234]); A_arbace_go_repl_A_const_112 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[235]); A_arbace_go_repl_A_const_113 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[236]); A_arbace_go_repl_A_const_114 = A_arbace_go_repl_A_const_pool.A[237]; A_arbace_go_repl_A_const_115 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[238]); A_arbace_go_repl_A_const_116 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[239]); A_arbace_go_repl_A_const_117 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[240]); A_arbace_go_repl_A_const_118 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[241]); A_arbace_go_repl_A_const_119 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[242]); A_arbace_go_repl_A_const_120 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[243]) }

func A_arbace_go_repl_A_clinit_p10() { A_arbace_go_repl_A_const_121 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[244]); A_arbace_go_repl_A_const_122 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[245]); A_arbace_go_repl_A_const_123 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[246]); A_arbace_go_repl_A_const_124 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[247]); A_arbace_go_repl_A_const_125 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[248]); A_arbace_go_repl_A_const_126 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[249]); A_arbace_go_repl_A_const_127 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[250]); A_arbace_go_repl_A_const_128 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[251]); A_arbace_go_repl_A_const_129 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[252]); A_arbace_go_repl_A_const_130 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[253]); A_arbace_go_repl_A_const_131 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[254]); A_arbace_go_repl_A_const_132 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[255]) }

func A_arbace_go_repl_A_clinit_p11() { A_arbace_go_repl_A_const_133 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[256]); A_arbace_go_repl_A_const_134 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[257]); A_arbace_go_repl_A_const_135 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[258]); A_arbace_go_repl_A_const_136 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[259]); A_arbace_go_repl_A_const_137 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[260]); A_arbace_go_repl_A_const_138 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[261]); A_arbace_go_repl_A_const_139 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[262]); A_arbace_go_repl_A_const_140 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[263]); A_arbace_go_repl_A_const_141 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[264]); A_arbace_go_repl_A_const_142 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[265]); A_arbace_go_repl_A_const_143 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[266]); A_arbace_go_repl_A_const_144 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[267]) }

func A_arbace_go_repl_A_clinit_p12() { A_arbace_go_repl_A_const_145 = A_arbace_go_repl_A_const_pool.A[268]; A_arbace_go_repl_A_const_146 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[269]); A_arbace_go_repl_A_const_147 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[270]); A_arbace_go_repl_A_const_148 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[271]); A_arbace_go_repl_A_const_149 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[272]); A_arbace_go_repl_A_const_150 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[273]); A_arbace_go_repl_A_const_151 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[274]); A_arbace_go_repl_A_const_152 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[275]); A_arbace_go_repl_A_const_153 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[276]); A_arbace_go_repl_A_const_154 = A_arbace_go_repl_A_const_pool.A[277]; A_arbace_go_repl_A_const_155 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[278]); A_arbace_go_repl_A_const_156 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[279]) }

func A_arbace_go_repl_A_clinit_p13() { A_arbace_go_repl_A_const_157 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[280]); A_arbace_go_repl_A_const_158 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[281]); A_arbace_go_repl_A_const_159 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[282]); A_arbace_go_repl_A_const_160 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[283]); A_arbace_go_repl_A_const_161 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[284]); A_arbace_go_repl_A_const_162 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[285]); A_arbace_go_repl_A_const_163 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[286]); A_arbace_go_repl_A_const_164 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[287]); A_arbace_go_repl_A_const_165 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[288]); A_arbace_go_repl_A_const_166 = A_arbace_go_repl_A_const_pool.A[289]; A_arbace_go_repl_A_const_167 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[290]); A_arbace_go_repl_A_const_168 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[291]) }

func A_arbace_go_repl_A_clinit_p14() { A_arbace_go_repl_A_const_169 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[292]); A_arbace_go_repl_A_const_170 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[293]); A_arbace_go_repl_A_const_171 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[294]); A_arbace_go_repl_A_const_172 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[295]); A_arbace_go_repl_A_const_173 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[296]); A_arbace_go_repl_A_const_174 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[297]); A_arbace_go_repl_A_const_175 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[298]); A_arbace_go_repl_A_const_176 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[299]); A_arbace_go_repl_A_const_177 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[300]); A_arbace_go_repl_A_const_178 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[301]); A_arbace_go_repl_A_const_179 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[302]); A_arbace_go_repl_A_const_180 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[303]) }

func A_arbace_go_repl_A_clinit_p15() { A_arbace_go_repl_A_const_181 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[304]); A_arbace_go_repl_A_const_182 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[305]); A_arbace_go_repl_A_const_183 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[306]); A_arbace_go_repl_A_const_184 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[307]); A_arbace_go_repl_A_const_185 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[308]); A_arbace_go_repl_A_const_186 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[309]); A_arbace_go_repl_A_const_187 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[310]); A_arbace_go_repl_A_const_188 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[311]); A_arbace_go_repl_A_const_189 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[312]); A_arbace_go_repl_A_const_190 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[313]); A_arbace_go_repl_A_const_191 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[314]); A_arbace_go_repl_A_const_192 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[315]) }

func A_arbace_go_repl_A_clinit_p16() { A_arbace_go_repl_A_const_193 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[316]); A_arbace_go_repl_A_const_194 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[317]); A_arbace_go_repl_A_const_195 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[318]); A_arbace_go_repl_A_const_196 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[319]); A_arbace_go_repl_A_const_197 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[320]); A_arbace_go_repl_A_const_198 = A_arbace_go_repl_A_const_pool.A[321]; A_arbace_go_repl_A_const_199 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[322]); A_arbace_go_repl_A_const_200 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[323]); A_arbace_go_repl_A_const_201 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[324]); A_arbace_go_repl_A_const_202 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[325]); A_arbace_go_repl_A_const_203 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[326]); A_arbace_go_repl_A_const_204 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[327]) }

func A_arbace_go_repl_A_clinit_p17() { A_arbace_go_repl_A_const_205 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[328]); A_arbace_go_repl_A_const_206 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[329]); A_arbace_go_repl_A_const_207 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[330]); A_arbace_go_repl_A_const_208 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[331]); A_arbace_go_repl_A_const_209 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[332]); A_arbace_go_repl_A_const_210 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[333]); A_arbace_go_repl_A_const_211 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[334]); A_arbace_go_repl_A_const_212 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[335]); A_arbace_go_repl_A_const_213 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[336]); A_arbace_go_repl_A_const_214 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[337]); A_arbace_go_repl_A_const_215 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[338]); A_arbace_go_repl_A_const_216 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[339]) }

func A_arbace_go_repl_A_clinit_p18() { A_arbace_go_repl_A_const_217 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[340]); A_arbace_go_repl_A_const_218 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[341]); A_arbace_go_repl_A_const_219 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[342]); A_arbace_go_repl_A_const_220 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[343]); A_arbace_go_repl_A_const_221 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[344]); A_arbace_go_repl_A_const_222 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[345]); A_arbace_go_repl_A_const_223 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[346]); A_arbace_go_repl_A_const_224 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[347]); A_arbace_go_repl_A_const_225 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[348]); A_arbace_go_repl_A_const_226 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[349]); A_arbace_go_repl_A_const_227 = A_arbace_go_repl_A_const_pool.A[350]; A_arbace_go_repl_A_const_228 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[351]) }

func A_arbace_go_repl_A_clinit_p19() { A_arbace_go_repl_A_const_229 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[352]); A_arbace_go_repl_A_const_230 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[353]); A_arbace_go_repl_A_const_231 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[354]); A_arbace_go_repl_A_const_232 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[355]); A_arbace_go_repl_A_const_233 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[356]); A_arbace_go_repl_A_const_234 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[357]); A_arbace_go_repl_A_const_235 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[358]); A_arbace_go_repl_A_const_236 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[359]); A_arbace_go_repl_A_const_237 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[360]); A_arbace_go_repl_A_const_238 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[361]); A_arbace_go_repl_A_const_239 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[362]); A_arbace_go_repl_A_const_240 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[363]) }

func A_arbace_go_repl_A_clinit_p20() { A_arbace_go_repl_A_const_241 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[364]); A_arbace_go_repl_A_const_242 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[365]); A_arbace_go_repl_A_const_243 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[366]); A_arbace_go_repl_A_const_244 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[367]); A_arbace_go_repl_A_const_245 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[368]); A_arbace_go_repl_A_const_246 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[369]); A_arbace_go_repl_A_const_247 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[370]); A_arbace_go_repl_A_const_248 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[371]); A_arbace_go_repl_A_const_249 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[372]); A_arbace_go_repl_A_const_250 = A_arbace_go_repl_A_const_pool.A[373]; A_arbace_go_repl_A_const_251 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[374]); A_arbace_go_repl_A_const_252 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[375]) }

func A_arbace_go_repl_A_clinit_p21() { A_arbace_go_repl_A_const_253 = A_arbace_go_repl_A_const_pool.A[376]; A_arbace_go_repl_A_const_254 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[377]); A_arbace_go_repl_A_const_255 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[378]); A_arbace_go_repl_A_const_256 = A_arbace_go_repl_A_const_pool.A[379]; A_arbace_go_repl_A_const_257 = A_arbace_go_repl_A_const_pool.A[380]; A_arbace_go_repl_A_const_258 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[381]); A_arbace_go_repl_A_const_259 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[382]); A_arbace_go_repl_A_const_260 = A_arbace_go_repl_A_const_pool.A[383]; A_arbace_go_repl_A_const_261 = lang.Keyword_Cast(A_arbace_go_repl_A_const_pool.A[384]); A_arbace_go_repl_A_const_262 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[385]); A_arbace_go_repl_A_const_263 = lang.Var_Cast(A_arbace_go_repl_A_const_pool.A[386]); A_arbace_go_repl_A_const_264 = A_arbace_go_repl_A_const_pool.A[387]; A_arbace_go_repl_A_const_265 = A_arbace_go_repl_A_const_pool.A[388] }

func A_arbace_go_repl_A_clinit_p22() { A_arbace_go_repl_A_const_266 = A_arbace_go_repl_A_const_pool.A[389] }

func A_arbace_go_repl_A_New() *A_arbace_go_repl_A { A_arbace_go_repl_A_Init(); t := &A_arbace_go_repl_A{}; t.Ctor(); return t }

func (t *A_arbace_go_repl_A) Ctor() {}

func (t *A_arbace_go_repl_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_repl_A) GetClass__Class() *jrt.Class { return A_arbace_go_repl_A_class }

func (t *A_arbace_go_repl_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_repl_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_repl_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_repl_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_repl_A); return ok }

func A_arbace_go_repl_A_Cast(x any) *A_arbace_go_repl_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_repl_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_repl_A_class)) }; return v }



type A_arbace_go_repl_after_load_A struct{ j2g_header uint64 }

var A_arbace_go_repl_after_load_A_fn_class *jrt.Class



type A_arbace_go_repl_build_context_A struct{ j2g_header uint64 }

var A_arbace_go_repl_build_context_A_fn_class *jrt.Class



type A_arbace_go_repl_build_context_fn__794000172_A struct{ j2g_header uint64 }

var A_arbace_go_repl_build_context_fn__794000172_A_fn_class *jrt.Class



type A_arbace_go_repl_build_context_fn__794000174_A struct{ j2g_header uint64 }

var A_arbace_go_repl_build_context_fn__794000174_A_fn_class *jrt.Class



type A_arbace_go_repl_build_context_fn__794000176_A struct{ j2g_header uint64 }

var A_arbace_go_repl_build_context_fn__794000176_A_fn_class *jrt.Class



type A_arbace_go_repl_build_context_fn__794000178_A struct{ j2g_header uint64 }

var A_arbace_go_repl_build_context_fn__794000178_A_fn_class *jrt.Class



type A_arbace_go_repl_call0_A struct{ j2g_header uint64 }

var A_arbace_go_repl_call0_A_fn_class *jrt.Class



type A_arbace_go_repl_check_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_repl_check_BANG__A_fn_class *jrt.Class



type A_arbace_go_repl_check_source_A struct{ j2g_header uint64 }

var A_arbace_go_repl_check_source_A_fn_class *jrt.Class



type A_arbace_go_repl_complete_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_repl_complete_BANG__A_fn_class *jrt.Class



type A_arbace_go_repl_const_arbace_A struct{ j2g_header uint64 }

var A_arbace_go_repl_const_arbace_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_A struct{ j2g_header uint64 }

var A_arbace_go_repl_decl_names_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_group_QMARK___794000064_A struct{ j2g_header uint64 }

var A_arbace_go_repl_decl_names_group_QMARK___794000064_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_iter__794000069__794000073_A struct{ j2g_header uint64 }

var A_arbace_go_repl_decl_names_iter__794000069__794000073_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_A struct{ j2g_header uint64; F_s__794000070, F_iter__794000069 any }

var A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_fn__794000075_A struct{ j2g_header uint64; F_b__794000072 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_repl_decl_names_iter__794000069__794000073_fn__794000074_fn__794000075_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_iter__794000085__794000091_A struct{ j2g_header uint64; F_targets any }

var A_arbace_go_repl_decl_names_iter__794000085__794000091_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_A struct{ j2g_header uint64; F_iter__794000085, F_s__794000086, F_targets any }

var A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_A struct{ j2g_header uint64 }

var A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_A struct{ j2g_header uint64; F_iter__794000087, F_s__794000088 any }

var A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_fn__794000098_A struct{ j2g_header uint64; F_b__794000090 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_repl_decl_names_iter__794000085__794000091_fn__794000092_iter__794000087__794000096_fn__794000097_fn__794000098_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_iter__794000104__794000110_A struct{ j2g_header uint64; F_targets any }

var A_arbace_go_repl_decl_names_iter__794000104__794000110_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_A struct{ j2g_header uint64; F_s__794000105, F_targets, F_iter__794000104 any }

var A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_A struct{ j2g_header uint64 }

var A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_A struct{ j2g_header uint64; F_iter__794000106, F_s__794000107 any }

var A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_fn__794000117_A struct{ j2g_header uint64; F_b__794000109 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_repl_decl_names_iter__794000104__794000110_fn__794000111_iter__794000106__794000115_fn__794000116_fn__794000117_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_specs__794000066_A struct{ j2g_header uint64 }

var A_arbace_go_repl_decl_names_specs__794000066_A_fn_class *jrt.Class



type A_arbace_go_repl_decl_names_targets__794000062_A struct{ j2g_header uint64 }

var A_arbace_go_repl_decl_names_targets__794000062_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_repl_declare_BANG__A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__fn__794000437_A struct{ j2g_header uint64; F_form any }

var A_arbace_go_repl_declare_BANG__fn__794000437_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__fn__794000457_A struct{ j2g_header uint64; F_old any }

var A_arbace_go_repl_declare_BANG__fn__794000457_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__fn__794000459_A struct{ j2g_header uint64; F_form, F_old any }

var A_arbace_go_repl_declare_BANG__fn__794000459_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__fn__794000461_A struct{ j2g_header uint64; F_st, F_old any }

var A_arbace_go_repl_declare_BANG__fn__794000461_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__fn__794000463_A struct{ j2g_header uint64 }

var A_arbace_go_repl_declare_BANG__fn__794000463_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__fn__794000467_A struct{ j2g_header uint64; F_spec_of any }

var A_arbace_go_repl_declare_BANG__fn__794000467_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__fn__794000469_A struct{ j2g_header uint64; F_broken, F_others any }

var A_arbace_go_repl_declare_BANG__fn__794000469_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__fn__794000473_A struct{ j2g_header uint64; F_broken any; F_var_QMARK_ bool; F_r, F_st, F_old, F_names any }

var A_arbace_go_repl_declare_BANG__fn__794000473_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__iter__794000439__794000443_A struct{ j2g_header uint64; F_names any }

var A_arbace_go_repl_declare_BANG__iter__794000439__794000443_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_A struct{ j2g_header uint64; F_iter__794000439, F_s__794000440, F_names any }

var A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_A struct{ j2g_header uint64; F_b__794000442 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_names any }

var A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_fn__794000446_A struct{ j2g_header uint64; F_names any }

var A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_fn__794000446_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_fn__794000446_fn__794000447_A struct{ j2g_header uint64; F_names any }

var A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000445_fn__794000446_fn__794000447_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000451_A struct{ j2g_header uint64; F_names any }

var A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000451_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000451_fn__794000452_A struct{ j2g_header uint64; F_names any }

var A_arbace_go_repl_declare_BANG__iter__794000439__794000443_fn__794000444_fn__794000451_fn__794000452_A_fn_class *jrt.Class



type A_arbace_go_repl_declare_BANG__own_QMARK___794000465_A struct{ j2g_header uint64; F_form, F_spec_of any }

var A_arbace_go_repl_declare_BANG__own_QMARK___794000465_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_repl_define_BANG__A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000195_A struct{ j2g_header uint64 }

var A_arbace_go_repl_define_BANG__fn__794000195_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000197_A struct{ j2g_header uint64 }

var A_arbace_go_repl_define_BANG__fn__794000197_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000209_A struct{ j2g_header uint64 }

var A_arbace_go_repl_define_BANG__fn__794000209_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000211_A struct{ j2g_header uint64 }

var A_arbace_go_repl_define_BANG__fn__794000211_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000282_A struct{ j2g_header uint64; F_tree any }

var A_arbace_go_repl_define_BANG__fn__794000282_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000284_A struct{ j2g_header uint64; F_ctx, F_tree any }

var A_arbace_go_repl_define_BANG__fn__794000284_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000284_fn__794000285_A struct{ j2g_header uint64; F_tree any }

var A_arbace_go_repl_define_BANG__fn__794000284_fn__794000285_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000293_A struct{ j2g_header uint64; F_tree any }

var A_arbace_go_repl_define_BANG__fn__794000293_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000295_A struct{ j2g_header uint64; F_tree, F_ctx any }

var A_arbace_go_repl_define_BANG__fn__794000295_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000295_fn__794000296_A struct{ j2g_header uint64; F_tree any }

var A_arbace_go_repl_define_BANG__fn__794000295_fn__794000296_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000308_A struct{ j2g_header uint64 }

var A_arbace_go_repl_define_BANG__fn__794000308_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000310_A struct{ j2g_header uint64; F_tree any }

var A_arbace_go_repl_define_BANG__fn__794000310_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000312_A struct{ j2g_header uint64; F_ctx, F_tree any }

var A_arbace_go_repl_define_BANG__fn__794000312_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000312_fn__794000313_A struct{ j2g_header uint64; F_tree any }

var A_arbace_go_repl_define_BANG__fn__794000312_fn__794000313_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000321_A struct{ j2g_header uint64 }

var A_arbace_go_repl_define_BANG__fn__794000321_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000323_A struct{ j2g_header uint64; F_tree any }

var A_arbace_go_repl_define_BANG__fn__794000323_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000325_A struct{ j2g_header uint64; F_tree, F_ctx any }

var A_arbace_go_repl_define_BANG__fn__794000325_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000325_fn__794000326_A struct{ j2g_header uint64; F_tree any }

var A_arbace_go_repl_define_BANG__fn__794000325_fn__794000326_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000335_A struct{ j2g_header uint64; F_tree any }

var A_arbace_go_repl_define_BANG__fn__794000335_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000339_A struct{ j2g_header uint64; F_tree any }

var A_arbace_go_repl_define_BANG__fn__794000339_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000351_A struct{ j2g_header uint64; F_var_trees any }

var A_arbace_go_repl_define_BANG__fn__794000351_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000353_A struct{ j2g_header uint64; F_names any }

var A_arbace_go_repl_define_BANG__fn__794000353_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000353_fn__794000354_A struct{ j2g_header uint64; F_names any }

var A_arbace_go_repl_define_BANG__fn__794000353_fn__794000354_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000366_A struct{ j2g_header uint64; F_obj any }

var A_arbace_go_repl_define_BANG__fn__794000366_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000374_A struct{ j2g_header uint64; F_obj any }

var A_arbace_go_repl_define_BANG__fn__794000374_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000399_A struct{ j2g_header uint64; F_ns, F_x, F_old any }

var A_arbace_go_repl_define_BANG__fn__794000399_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__fn__794000401_A struct{ j2g_header uint64; F_ns, F_x, F_old any }

var A_arbace_go_repl_define_BANG__fn__794000401_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__gen_of__794000193_A struct{ j2g_header uint64; F_old any }

var A_arbace_go_repl_define_BANG__gen_of__794000193_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000199__794000203_A struct{ j2g_header uint64; F_gen_of, F_old any }

var A_arbace_go_repl_define_BANG__iter__794000199__794000203_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000199__794000203_fn__794000204_A struct{ j2g_header uint64; F_s__794000200, F_gen_of, F_old, F_iter__794000199 any }

var A_arbace_go_repl_define_BANG__iter__794000199__794000203_fn__794000204_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000199__794000203_fn__794000204_fn__794000205_A struct{ j2g_header uint64; F_b__794000202, F_gen_of, F_old any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_repl_define_BANG__iter__794000199__794000203_fn__794000204_fn__794000205_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000213__794000217_A struct{ j2g_header uint64; F_old, F_ctx, F_kept_names any }

var A_arbace_go_repl_define_BANG__iter__794000213__794000217_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000213__794000217_fn__794000218_A struct{ j2g_header uint64; F_s__794000214, F_old, F_ctx, F_kept_names, F_iter__794000213 any }

var A_arbace_go_repl_define_BANG__iter__794000213__794000217_fn__794000218_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000213__794000217_fn__794000218_fn__794000219_A struct{ j2g_header uint64; F_b__794000216, F_old any; F_size__1927001038__auto__ int32; F_ctx, F_kept_names, F_c__1927001037__auto__ any }

var A_arbace_go_repl_define_BANG__iter__794000213__794000217_fn__794000218_fn__794000219_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000223__794000227_A struct{ j2g_header uint64; F_old, F_decls any }

var A_arbace_go_repl_define_BANG__iter__794000223__794000227_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_A struct{ j2g_header uint64; F_s__794000224, F_old, F_decls, F_iter__794000223 any }

var A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000229_A struct{ j2g_header uint64; F_b__794000226, F_old any; F_size__1927001038__auto__ int32; F_decls, F_c__1927001037__auto__ any }

var A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000229_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000229_fn__794000230_A struct{ j2g_header uint64; F_x any }

var A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000229_fn__794000230_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000233_A struct{ j2g_header uint64; F_x any }

var A_arbace_go_repl_define_BANG__iter__794000223__794000227_fn__794000228_fn__794000233_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000237__794000241_A struct{ j2g_header uint64; F_old, F_ctx any }

var A_arbace_go_repl_define_BANG__iter__794000237__794000241_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000237__794000241_fn__794000242_A struct{ j2g_header uint64; F_iter__794000237, F_s__794000238, F_old, F_ctx any }

var A_arbace_go_repl_define_BANG__iter__794000237__794000241_fn__794000242_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000237__794000241_fn__794000242_fn__794000243_A struct{ j2g_header uint64; F_b__794000240, F_old any; F_size__1927001038__auto__ int32; F_ctx, F_c__1927001037__auto__ any }

var A_arbace_go_repl_define_BANG__iter__794000237__794000241_fn__794000242_fn__794000243_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000247__794000253_A struct{ j2g_header uint64 }

var A_arbace_go_repl_define_BANG__iter__794000247__794000253_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_A struct{ j2g_header uint64; F_s__794000248, F_iter__794000247 any }

var A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_A struct{ j2g_header uint64 }

var A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_fn__794000256_A struct{ j2g_header uint64; F_iter__794000249, F_s__794000250 any }

var A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_fn__794000256_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_fn__794000256_fn__794000257_A struct{ j2g_header uint64; F_b__794000252 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_repl_define_BANG__iter__794000247__794000253_fn__794000254_iter__794000249__794000255_fn__794000256_fn__794000257_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000263__794000267_A struct{ j2g_header uint64; F_new_vars, F_old, F_ctx any }

var A_arbace_go_repl_define_BANG__iter__794000263__794000267_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000263__794000267_fn__794000268_A struct{ j2g_header uint64; F_new_vars, F_iter__794000263, F_old, F_ctx, F_s__794000264 any }

var A_arbace_go_repl_define_BANG__iter__794000263__794000267_fn__794000268_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000263__794000267_fn__794000268_fn__794000269_A struct{ j2g_header uint64; F_b__794000266, F_new_vars, F_old any; F_size__1927001038__auto__ int32; F_ctx, F_c__1927001037__auto__ any }

var A_arbace_go_repl_define_BANG__iter__794000263__794000267_fn__794000268_fn__794000269_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000341__794000345_A struct{ j2g_header uint64 }

var A_arbace_go_repl_define_BANG__iter__794000341__794000345_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000341__794000345_fn__794000346_A struct{ j2g_header uint64; F_iter__794000341, F_s__794000342 any }

var A_arbace_go_repl_define_BANG__iter__794000341__794000345_fn__794000346_A_fn_class *jrt.Class



type A_arbace_go_repl_define_BANG__iter__794000341__794000345_fn__794000346_fn__794000347_A struct{ j2g_header uint64; F_b__794000344 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_repl_define_BANG__iter__794000341__794000345_fn__794000346_fn__794000347_A_fn_class *jrt.Class



type A_arbace_go_repl_digest_forms_A struct{ j2g_header uint64 }

var A_arbace_go_repl_digest_forms_A_fn_class *jrt.Class



type A_arbace_go_repl_error_text_A struct{ j2g_header uint64 }

var A_arbace_go_repl_error_text_A_fn_class *jrt.Class



type A_arbace_go_repl_error_text_iter__794000124__794000128_A struct{ j2g_header uint64; F_src any }

var A_arbace_go_repl_error_text_iter__794000124__794000128_A_fn_class *jrt.Class



type A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_A struct{ j2g_header uint64; F_s__794000125, F_src, F_iter__794000124 any }

var A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_A_fn_class *jrt.Class



type A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_fn__794000130_A struct{ j2g_header uint64; F_src, F_b__794000127 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_repl_error_text_iter__794000124__794000128_fn__794000129_fn__794000130_A_fn_class *jrt.Class



type A_arbace_go_repl_eval794000004_A struct{ jrt.Object }

func A_arbace_go_repl_eval794000004_A_New() *A_arbace_go_repl_eval794000004_A { t := &A_arbace_go_repl_eval794000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_repl_eval794000004_A) Ctor() {}

func (t *A_arbace_go_repl_eval794000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_repl_eval794000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_repl_eval794000004_A_class }

func (t *A_arbace_go_repl_eval794000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_repl_eval794000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_repl_eval794000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_repl_eval794000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_repl_eval794000004_A); return ok }

func A_arbace_go_repl_eval794000004_A_Cast(x any) *A_arbace_go_repl_eval794000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_repl_eval794000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_repl_eval794000004_A_class)) }; return v }



type A_arbace_go_repl_eval794000004_loading__1927001464__auto____794000005_A struct{ j2g_header uint64 }

var A_arbace_go_repl_eval794000004_loading__1927001464__auto____794000005_A_fn_class *jrt.Class



type A_arbace_go_repl_eval794000008_A struct{ jrt.Object }

func A_arbace_go_repl_eval794000008_A_New() *A_arbace_go_repl_eval794000008_A { t := &A_arbace_go_repl_eval794000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_repl_eval794000008_A) Ctor() {}

func (t *A_arbace_go_repl_eval794000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_repl_eval794000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_repl_eval794000008_A_class }

func (t *A_arbace_go_repl_eval794000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_repl_eval794000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_repl_eval794000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_repl_eval794000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_repl_eval794000008_A); return ok }

func A_arbace_go_repl_eval794000008_A_Cast(x any) *A_arbace_go_repl_eval794000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_repl_eval794000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_repl_eval794000008_A_class)) }; return v }



type A_arbace_go_repl_eval794000008_fn__794000009_A struct{ j2g_header uint64 }

var A_arbace_go_repl_eval794000008_fn__794000009_A_fn_class *jrt.Class



type A_arbace_go_repl_eval_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_repl_eval_BANG__A_fn_class *jrt.Class



type A_arbace_go_repl_eval_BANG__attempt__794000493_A struct{ j2g_header uint64; F_stmts, F_nm, F_st any }

var A_arbace_go_repl_eval_BANG__attempt__794000493_A_fn_class *jrt.Class



type A_arbace_go_repl_eval_BANG__attempt__794000493_fn__794000494_A struct{ j2g_header uint64; F_form, F_old any }

var A_arbace_go_repl_eval_BANG__attempt__794000493_fn__794000494_A_fn_class *jrt.Class



type A_arbace_go_repl_eval_BANG__attempt__794000493_fn__794000496_A struct{ j2g_header uint64; F_old any }

var A_arbace_go_repl_eval_BANG__attempt__794000493_fn__794000496_A_fn_class *jrt.Class



type A_arbace_go_repl_eval_BANG__fn__794000491_A struct{ j2g_header uint64; F_stmts any }

var A_arbace_go_repl_eval_BANG__fn__794000491_A_fn_class *jrt.Class



type A_arbace_go_repl_eval_BANG__fn__794000499_A struct{ j2g_header uint64 }

var A_arbace_go_repl_eval_BANG__fn__794000499_A_fn_class *jrt.Class



type A_arbace_go_repl_eval_BANG__fn__794000501_A struct{ j2g_header uint64 }

var A_arbace_go_repl_eval_BANG__fn__794000501_A_fn_class *jrt.Class



type A_arbace_go_repl_eval_BANG__fn__794000506_A struct{ j2g_header uint64 }

var A_arbace_go_repl_eval_BANG__fn__794000506_A_fn_class *jrt.Class



type A_arbace_go_repl_eval_BANG__fn__794000508_A struct{ j2g_header uint64; F_form, F_old any }

var A_arbace_go_repl_eval_BANG__fn__794000508_A_fn_class *jrt.Class



type A_arbace_go_repl_eval_BANG__fn__794000512_A struct{ j2g_header uint64; F_obj any }

var A_arbace_go_repl_eval_BANG__fn__794000512_A_fn_class *jrt.Class



type A_arbace_go_repl_file_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_repl_file_BANG__A_fn_class *jrt.Class



type A_arbace_go_repl_file_BANG__fn__794000053_A struct{ j2g_header uint64; F_opts, F_st any }

var A_arbace_go_repl_file_BANG__fn__794000053_A_fn_class *jrt.Class



type A_arbace_go_repl_file_entry_A struct{ j2g_header uint64 }

var A_arbace_go_repl_file_entry_A_fn_class *jrt.Class



type A_arbace_go_repl_file_entry_fn__794000040_A struct{ j2g_header uint64; F_fname any }

var A_arbace_go_repl_file_entry_fn__794000040_A_fn_class *jrt.Class



type A_arbace_go_repl_fn__794000012_A struct{ j2g_header uint64 }

var A_arbace_go_repl_fn__794000012_A_fn_class *jrt.Class



type A_arbace_go_repl_fn__794000015_A struct{ j2g_header uint64 }

var A_arbace_go_repl_fn__794000015_A_fn_class *jrt.Class



type A_arbace_go_repl_fn__794000024_A struct{ j2g_header uint64 }

var A_arbace_go_repl_fn__794000024_A_fn_class *jrt.Class



type A_arbace_go_repl_fn__794000024_fn__794000025_A struct{ j2g_header uint64 }

var A_arbace_go_repl_fn__794000024_fn__794000025_A_fn_class *jrt.Class



type A_arbace_go_repl_fn__794000028_A struct{ j2g_header uint64 }

var A_arbace_go_repl_fn__794000028_A_fn_class *jrt.Class



type A_arbace_go_repl_fn__794000028_fn__794000029_A struct{ j2g_header uint64 }

var A_arbace_go_repl_fn__794000028_fn__794000029_A_fn_class *jrt.Class



type A_arbace_go_repl_import_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_repl_import_BANG__A_fn_class *jrt.Class



type A_arbace_go_repl_import_BANG__fn__794000057_A struct{ j2g_header uint64; F_specs any }

var A_arbace_go_repl_import_BANG__fn__794000057_A_fn_class *jrt.Class



type A_arbace_go_repl_import_BANG__fn__794000057_fn__794000058_A struct{ j2g_header uint64; F_specs any }

var A_arbace_go_repl_import_BANG__fn__794000057_fn__794000058_A_fn_class *jrt.Class



type A_arbace_go_repl_listed_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_repl_listed_QMARK__A_fn_class *jrt.Class



type A_arbace_go_repl_load_import_A struct{ j2g_header uint64 }

var A_arbace_go_repl_load_import_A_fn_class *jrt.Class



type A_arbace_go_repl_load_import_fn__794000425_A struct{ j2g_header uint64; F_ns_sym any }

var A_arbace_go_repl_load_import_fn__794000425_A_fn_class *jrt.Class



type A_arbace_go_repl_method_name_A struct{ j2g_header uint64 }

var A_arbace_go_repl_method_name_A_fn_class *jrt.Class



type A_arbace_go_repl_new_state_A struct{ j2g_header uint64 }

var A_arbace_go_repl_new_state_A_fn_class *jrt.Class



type A_arbace_go_repl_ns__GT_path_A struct{ j2g_header uint64 }

var A_arbace_go_repl_ns__GT_path_A_fn_class *jrt.Class



type A_arbace_go_repl_package_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_repl_package_BANG__A_fn_class *jrt.Class



type A_arbace_go_repl_package_state_A struct{ j2g_header uint64 }

var A_arbace_go_repl_package_state_A_fn_class *jrt.Class



type A_arbace_go_repl_path__GT_ns_A struct{ j2g_header uint64 }

var A_arbace_go_repl_path__GT_ns_A_fn_class *jrt.Class



type A_arbace_go_repl_repl_source_A struct{ j2g_header uint64 }

var A_arbace_go_repl_repl_source_A_fn_class *jrt.Class



type A_arbace_go_repl_run_main_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_repl_run_main_BANG__A_fn_class *jrt.Class



type A_arbace_go_repl_session_for_A struct{ j2g_header uint64 }

var A_arbace_go_repl_session_for_A_fn_class *jrt.Class



type A_arbace_go_repl_session_for_fn__794000147_A struct{ j2g_header uint64; F_extra_src any }

var A_arbace_go_repl_session_for_fn__794000147_A_fn_class *jrt.Class



type A_arbace_go_repl_session_for_fn__794000149_A struct{ j2g_header uint64 }

var A_arbace_go_repl_session_for_fn__794000149_A_fn_class *jrt.Class



type A_arbace_go_repl_source_of_A struct{ j2g_header uint64 }

var A_arbace_go_repl_source_of_A_fn_class *jrt.Class



type A_arbace_go_repl_source_of_iter__794000136__794000140_A struct{ j2g_header uint64 }

var A_arbace_go_repl_source_of_iter__794000136__794000140_A_fn_class *jrt.Class



type A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_A struct{ j2g_header uint64; F_s__794000137, F_iter__794000136 any }

var A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_A_fn_class *jrt.Class



type A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_fn__794000142_A struct{ j2g_header uint64; F_b__794000139 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_repl_source_of_iter__794000136__794000140_fn__794000141_fn__794000142_A_fn_class *jrt.Class



type A_arbace_go_repl_state_of_path_A struct{ j2g_header uint64 }

var A_arbace_go_repl_state_of_path_A_fn_class *jrt.Class



type A_arbace_go_repl_type_key_A struct{ j2g_header uint64 }

var A_arbace_go_repl_type_key_A_fn_class *jrt.Class



type A_arbace_go_repl_type_key_fn__794000159_A struct{ j2g_header uint64; F_gen_of any }

var A_arbace_go_repl_type_key_fn__794000159_A_fn_class *jrt.Class



type A_arbace_go_repl_type_key_fn__794000161_A struct{ j2g_header uint64; F_gen_of any }

var A_arbace_go_repl_type_key_fn__794000161_A_fn_class *jrt.Class



type A_arbace_go_repl_type_key_fn__794000163_A struct{ j2g_header uint64; F_gen_of any }

var A_arbace_go_repl_type_key_fn__794000163_A_fn_class *jrt.Class



type A_arbace_go_repl_type_key_fn__794000165_A struct{ j2g_header uint64; F_gen_of any }

var A_arbace_go_repl_type_key_fn__794000165_A_fn_class *jrt.Class



type A_arbace_go_repl_type_key_fn__794000167_A struct{ j2g_header uint64; F_gen_of any }

var A_arbace_go_repl_type_key_fn__794000167_A_fn_class *jrt.Class



type A_arbace_go_repl_update_file_A struct{ j2g_header uint64 }

var A_arbace_go_repl_update_file_A_fn_class *jrt.Class



type A_arbace_go_repl_update_file_fn__794000045_A struct{ j2g_header uint64; F_f, F_fname any }

var A_arbace_go_repl_update_file_fn__794000045_A_fn_class *jrt.Class



type A_arbace_go_repl_update_file_fn__794000045_fn__794000046_A struct{ j2g_header uint64; F_fname any }

var A_arbace_go_repl_update_file_fn__794000045_fn__794000046_A_fn_class *jrt.Class



type A_arbace_go_repl_update_file_fn__794000045_fn__794000048_A struct{ j2g_header uint64; F_f, F_fname any }

var A_arbace_go_repl_update_file_fn__794000045_fn__794000048_A_fn_class *jrt.Class
