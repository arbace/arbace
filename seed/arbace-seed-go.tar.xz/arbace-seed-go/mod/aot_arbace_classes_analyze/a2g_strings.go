//line a2g_strings.ae:1
package aot_arbace_classes_analyze

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("arbace.classes.types")

var Lit_7 *jrt.String = jrt.Intern("t")

var Lit_8 *jrt.String = jrt.Intern("arbace.classes.env")

var Lit_9 *jrt.String = jrt.Intern("env")

var Lit_10 *jrt.String = jrt.Intern("arbace.classes.parse")

var Lit_11 *jrt.String = jrt.Intern("p")

var Lit_12 *jrt.String = jrt.Intern("arbace.classes.lower")

var Lit_13 *jrt.String = jrt.Intern("lower")

var Lit_14 *jrt.String = jrt.Intern("arbace.classes.opcodes")

var Lit_15 *jrt.String = jrt.Intern("Opcodes")

var Lit_16 *jrt.String = jrt.Intern("arbace.classes.go")

var Lit_17 *jrt.String = jrt.Intern("TypeReference")

var Lit_18 *jrt.String = jrt.Intern("commute")

var Lit_19 *jrt.String = jrt.Intern("deref")

var Lit_20 *jrt.String = jrt.Intern("conj")

var Lit_21 *jrt.String = jrt.Intern("arbace.classes.analyze")

var Lit_22 *jrt.String = jrt.Intern("doc")

var Lit_23 *jrt.String = jrt.Intern("Entering class declarations (names, supertypes, members, what javac derives) and analyzing\n  code into typed nodes (SPEC §4 to §6), which the Go build's interpreter\n  (arbace.classes.interp) runs and a2g translates. (The bytecode back end, arbace.classes.emit,\n  is on the branch arbace-for-java-26.)")

var Lit_24 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_25 *jrt.String = jrt.Intern("swap!")

var Lit_26 *jrt.String = jrt.Intern("ids")

var Lit_27 *jrt.String = jrt.Intern("inc")

var Lit_28 *jrt.String = jrt.Intern("ex-info")

var Lit_29 *jrt.String = jrt.Intern("assoc")

var Lit_30 *jrt.String = jrt.Intern("arbace")

var Lit_31 *jrt.String = jrt.Intern("compile-error")

var Lit_32 *jrt.String = jrt.Intern("fail")

var Lit_33 *jrt.String = jrt.Intern("*compile-set*")

var Lit_34 *jrt.String = jrt.Intern("decl")

var Lit_35 *jrt.String = jrt.Intern("apply")

var Lit_36 *jrt.String = jrt.Intern("update")

var Lit_37 *jrt.String = jrt.Intern("state")

var Lit_38 *jrt.String = jrt.Intern("decl!")

var Lit_39 *jrt.String = jrt.Intern("not")

var Lit_40 *jrt.String = jrt.Intern("has?")

var Lit_41 *jrt.String = jrt.Intern("flags")

var Lit_42 *jrt.String = jrt.Intern("nest-host")

var Lit_43 *jrt.String = jrt.Intern("info")

var Lit_44 *jrt.String = jrt.Intern("outer-instance?")

var Lit_45 *jrt.String = jrt.Intern("outer-level")

var Lit_46 *jrt.String = jrt.Intern("outer")

var Lit_47 *jrt.String = jrt.Intern("parse-method-desc")

var Lit_48 *jrt.String = jrt.Intern("method-desc")

var Lit_49 *jrt.String = jrt.Intern("desc")

var Lit_50 *jrt.String = jrt.Intern("cons")

var Lit_51 *jrt.String = jrt.Intern("internal->desc")

var Lit_52 *jrt.String = jrt.Intern("concat")

var Lit_53 *jrt.String = jrt.Intern("super-outer")

var Lit_54 *jrt.String = jrt.Intern("enum")

var Lit_55 *jrt.String = jrt.Intern("kind")

var Lit_56 *jrt.String = jrt.Intern("enum-body")

var Lit_57 *jrt.String = jrt.Intern("Ljava/lang/String;")

var Lit_58 *jrt.String = jrt.Intern("I")

var Lit_59 *jrt.String = jrt.Intern("anon")

var Lit_60 *jrt.String = jrt.Intern("local")

var Lit_61 *jrt.String = jrt.Intern("map")

var Lit_62 *jrt.String = jrt.Intern("nesting")

var Lit_63 *jrt.String = jrt.Intern("type")

var Lit_64 *jrt.String = jrt.Intern("captures")

var Lit_65 *jrt.String = jrt.Intern("replace")

var Lit_66 *jrt.String = jrt.Intern("munge")

var Lit_67 *jrt.String = jrt.Intern("name")

var Lit_68 *jrt.String = jrt.Intern("ns-name")

var Lit_69 *jrt.String = jrt.Intern("known?")

var Lit_70 *jrt.String = jrt.Intern("*source-lookup*")

var Lit_71 *jrt.String = jrt.Intern("*unit*")

var Lit_72 *jrt.String = jrt.Intern("enter-from-source!")

var Lit_73 *jrt.String = jrt.Intern("symbol?")

var Lit_74 *jrt.String = jrt.Intern("namespace")

var Lit_75 *jrt.String = jrt.Intern("ns")

var Lit_76 *jrt.String = jrt.Intern("includes?")

var Lit_77 *jrt.String = jrt.Intern("ns-map")

var Lit_78 *jrt.String = jrt.Intern("class?")

var Lit_79 *jrt.String = jrt.Intern("get-in")

var Lit_80 *jrt.String = jrt.Intern("class-exists?")

var Lit_81 *jrt.String = jrt.Intern("split")

var Lit_82 *jrt.String = jrt.Intern("resolve-class-sym")

var Lit_83 *jrt.String = jrt.Intern("else")

var Lit_84 *jrt.String = jrt.Intern("local-classes")

var Lit_85 *jrt.String = jrt.Intern("class")

var Lit_86 *jrt.String = jrt.Intern("simple")

var Lit_87 *jrt.String = jrt.Intern("not=")

var Lit_88 *jrt.String = jrt.Intern("member-classes")

var Lit_89 *jrt.String = jrt.Intern("from-source?")

var Lit_90 *jrt.String = jrt.Intern("package-of")

var Lit_91 *jrt.String = jrt.Intern("ns-package")

var Lit_92 *jrt.String = jrt.Intern("starts-with?")

var Lit_93 *jrt.String = jrt.Intern("source-imports")

var Lit_94 *jrt.String = jrt.Intern("\\$")

var Lit_95 *jrt.String = jrt.Intern("symbol")

var Lit_96 *jrt.String = jrt.Intern("default-import?")

var Lit_97 *jrt.String = jrt.Intern("resolve")

var Lit_98 *jrt.String = jrt.Intern("tvars")

var Lit_99 *jrt.String = jrt.Intern("set")

var Lit_100 *jrt.String = jrt.Intern("implicit-outer")

var Lit_101 *jrt.String = jrt.Intern("keys")

var Lit_102 *jrt.String = jrt.Intern("bounds")

var Lit_103 *jrt.String = jrt.Intern("mapv")

var Lit_104 *jrt.String = jrt.Intern("reflected")

var Lit_105 *jrt.String = jrt.Intern("sym")

var Lit_106 *jrt.String = jrt.Intern("tparams")

var Lit_107 *jrt.String = jrt.Intern("first")

var Lit_108 *jrt.String = jrt.Intern("opts")

var Lit_109 *jrt.String = jrt.Intern("type-params")

var Lit_110 *jrt.String = jrt.Intern("load-class")

var Lit_111 *jrt.String = jrt.Intern("go-build?")

var Lit_112 *jrt.String = jrt.Intern("generics")

var Lit_113 *jrt.String = jrt.Intern("class-tparams")

var Lit_114 *jrt.String = jrt.Intern("seq")

var Lit_115 *jrt.String = jrt.Intern("every?")

var Lit_116 *jrt.String = jrt.Intern("args")

var Lit_117 *jrt.String = jrt.Intern("tvar")

var Lit_118 *jrt.String = jrt.Intern("parse-type")

var Lit_119 *jrt.String = jrt.Intern("type-scope")

var Lit_120 *jrt.String = jrt.Intern("erase")

var Lit_121 *jrt.String = jrt.Intern("some")

var Lit_122 *jrt.String = jrt.Intern("keyword")

var Lit_123 *jrt.String = jrt.Intern("class-scope")

var Lit_124 *jrt.String = jrt.Intern("meta")

var Lit_125 *jrt.String = jrt.Intern("lower-case")

var Lit_126 *jrt.String = jrt.Intern("retention")

var Lit_127 *jrt.String = jrt.Intern("subs")

var Lit_128 *jrt.String = jrt.Intern("methods")

var Lit_129 *jrt.String = jrt.Intern("info!")

var Lit_130 *jrt.String = jrt.Intern("array?")

var Lit_131 *jrt.String = jrt.Intern("array")

var Lit_132 *jrt.String = jrt.Intern("seq?")

var Lit_133 *jrt.String = jrt.Intern("annotation")

var Lit_134 *jrt.String = jrt.Intern("interface?")

var Lit_135 *jrt.String = jrt.Intern("type-desc")

var Lit_136 *jrt.String = jrt.Intern("class-desc?")

var Lit_137 *jrt.String = jrt.Intern("desc->internal")

var Lit_138 *jrt.String = jrt.Intern("analyze-const-form")

var Lit_139 *jrt.String = jrt.Intern("const")

var Lit_140 *jrt.String = jrt.Intern("ann-value")

var Lit_141 *jrt.String = jrt.Intern("elem-type")

var Lit_142 *jrt.String = jrt.Intern("vector?")

var Lit_143 *jrt.String = jrt.Intern("second")

var Lit_144 *jrt.String = jrt.Intern("values")

var Lit_145 *jrt.String = jrt.Intern("into")

var Lit_146 *jrt.String = jrt.Intern("nested")

var Lit_147 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_148 *jrt.String = jrt.Intern("chunk-first")

var Lit_149 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_150 *jrt.String = jrt.Intern("chunk-append")

var Lit_151 *jrt.String = jrt.Intern("element-type")

var Lit_152 *jrt.String = jrt.Intern("chunk-cons")

var Lit_153 *jrt.String = jrt.Intern("chunk")

var Lit_154 *jrt.String = jrt.Intern("chunk-rest")

var Lit_155 *jrt.String = jrt.Intern("rest")

var Lit_156 *jrt.String = jrt.Intern("map?")

var Lit_157 *jrt.String = jrt.Intern("value")

var Lit_158 *jrt.String = jrt.Intern("re-matches")

var Lit_159 *jrt.String = jrt.Intern("[0-9]")

var Lit_160 *jrt.String = jrt.Intern("string-desc")

var Lit_161 *jrt.String = jrt.Intern("annotations-now")

var Lit_162 *jrt.String = jrt.Intern("targets")

var Lit_163 *jrt.String = jrt.Intern("vec")

var Lit_164 *jrt.String = jrt.Intern("filter")

var Lit_165 *jrt.String = jrt.Intern("annotation-targets")

var Lit_166 *jrt.String = jrt.Intern("force")

var Lit_167 *jrt.String = jrt.Intern("ref")

var Lit_168 *jrt.String = jrt.Intern("path")

var Lit_169 *jrt.String = jrt.Intern("element-path")

var Lit_170 *jrt.String = jrt.Intern("type-anns")

var Lit_171 *jrt.String = jrt.Intern("map-indexed")

var Lit_172 *jrt.String = jrt.Intern("next")

var Lit_173 *jrt.String = jrt.Intern("to-array")

var Lit_174 *jrt.String = jrt.Intern("anns")

var Lit_175 *jrt.String = jrt.Intern("newTypeParameterReference")

var Lit_176 *jrt.String = jrt.Intern("CLASS_TYPE_PARAMETER")

var Lit_177 *jrt.String = jrt.Intern("METHOD_TYPE_PARAMETER")

var Lit_178 *jrt.String = jrt.Intern("comp")

var Lit_179 *jrt.String = jrt.Intern("key")

var Lit_180 *jrt.String = jrt.Intern("type-annotations")

var Lit_181 *jrt.String = jrt.Intern("newTypeParameterBoundReference")

var Lit_182 *jrt.String = jrt.Intern("CLASS_TYPE_PARAMETER_BOUND")

var Lit_183 *jrt.String = jrt.Intern("METHOD_TYPE_PARAMETER_BOUND")

var Lit_184 *jrt.String = jrt.Intern("source")

var Lit_185 *jrt.String = jrt.Intern("visible")

var Lit_186 *jrt.String = jrt.Intern("runtime")

var Lit_187 *jrt.String = jrt.Intern("true?")

var Lit_188 *jrt.String = jrt.Intern("some?")

var Lit_189 *jrt.String = jrt.Intern("package")

var Lit_190 *jrt.String = jrt.Intern("counters")

var Lit_191 *jrt.String = jrt.Intern("fnil")

var Lit_192 *jrt.String = jrt.Intern("top")

var Lit_193 *jrt.String = jrt.Intern("top-name")

var Lit_194 *jrt.String = jrt.Intern("member")

var Lit_195 *jrt.String = jrt.Intern("static?")

var Lit_196 *jrt.String = jrt.Intern("interface")

var Lit_197 *jrt.String = jrt.Intern("static-context")

var Lit_198 *jrt.String = jrt.Intern("doall")

var Lit_199 *jrt.String = jrt.Intern("update-decl!")

var Lit_200 *jrt.String = jrt.Intern("merge")

var Lit_201 *jrt.String = jrt.Intern("creation-bounds")

var Lit_202 *jrt.String = jrt.Intern("enclosing-method")

var Lit_203 *jrt.String = jrt.Intern("atom")

var Lit_204 *jrt.String = jrt.Intern("uses-this0")

var Lit_205 *jrt.String = jrt.Intern("lambdas")

var Lit_206 *jrt.String = jrt.Intern("extra")

var Lit_207 *jrt.String = jrt.Intern("anon-ctx")

var Lit_208 *jrt.String = jrt.Intern("order")

var Lit_209 *jrt.String = jrt.Intern("parse-class")

var Lit_210 *jrt.String = jrt.Intern("form")

var Lit_211 *jrt.String = jrt.Intern("declare-class!")

var Lit_212 *jrt.String = jrt.Intern("members")

var Lit_213 *jrt.String = jrt.Intern("own-bounds")

var Lit_214 *jrt.String = jrt.Intern("parse-type-params")

var Lit_215 *jrt.String = jrt.Intern("anon-super")

var Lit_216 *jrt.String = jrt.Intern("record")

var Lit_217 *jrt.String = jrt.Intern("generic?")

var Lit_218 *jrt.String = jrt.Intern("type-params-signature")

var Lit_219 *jrt.String = jrt.Intern("signature")

var Lit_220 *jrt.String = jrt.Intern("zipmap")

var Lit_221 *jrt.String = jrt.Intern("repeat")

var Lit_222 *jrt.String = jrt.Intern("bounds-of-scope")

var Lit_223 *jrt.String = jrt.Intern("bounds-map")

var Lit_224 *jrt.String = jrt.Intern("extends")

var Lit_225 *jrt.String = jrt.Intern("implements")

var Lit_226 *jrt.String = jrt.Intern("headers-done")

var Lit_227 *jrt.String = jrt.Intern("super")

var Lit_228 *jrt.String = jrt.Intern("interfaces")

var Lit_229 *jrt.String = jrt.Intern("super-t")

var Lit_230 *jrt.String = jrt.Intern("interfaces-t")

var Lit_231 *jrt.String = jrt.Intern("permits")

var Lit_232 *jrt.String = jrt.Intern("annotations")

var Lit_233 *jrt.String = jrt.Intern("decl-annotations")

var Lit_234 *jrt.String = jrt.Intern("tparam-type-annotations")

var Lit_235 *jrt.String = jrt.Intern("newSuperTypeReference")

var Lit_236 *jrt.String = jrt.Intern("deprecated")

var Lit_237 *jrt.String = jrt.Intern("java.lang.Deprecated")

var Lit_238 *jrt.String = jrt.Intern("Deprecated")

var Lit_239 *jrt.String = jrt.Intern("tag")

var Lit_240 *jrt.String = jrt.Intern("tn")

var Lit_241 *jrt.String = jrt.Intern("final")

var Lit_242 *jrt.String = jrt.Intern("tag-of")

var Lit_243 *jrt.String = jrt.Intern("java.lang.Object")

var Lit_244 *jrt.String = jrt.Intern("distinct")

var Lit_245 *jrt.String = jrt.Intern("all-supertypes")

var Lit_246 *jrt.String = jrt.Intern("<init>")

var Lit_247 *jrt.String = jrt.Intern("<clinit>")

var Lit_248 *jrt.String = jrt.Intern("owner")

var Lit_249 *jrt.String = jrt.Intern("vals")

var Lit_250 *jrt.String = jrt.Intern("reduce")

var Lit_251 *jrt.String = jrt.Intern("ref?")

var Lit_252 *jrt.String = jrt.Intern("assignable?")

var Lit_253 *jrt.String = jrt.Intern("array-map")

var Lit_254 *jrt.String = jrt.Intern("clojure-implementables")

var Lit_255 *jrt.String = jrt.Intern("bridge-of")

var Lit_256 *jrt.String = jrt.Intern("clojure-bridge")

var Lit_257 *jrt.String = jrt.Intern("derived")

var Lit_258 *jrt.String = jrt.Intern("bridge")

var Lit_259 *jrt.String = jrt.Intern("throws")

var Lit_260 *jrt.String = jrt.Intern("ret")

var Lit_261 *jrt.String = jrt.Intern("params")

var Lit_262 *jrt.String = jrt.Intern("clojure-overrideables")

var Lit_263 *jrt.String = jrt.Intern("object-desc")

var Lit_264 *jrt.String = jrt.Intern("class->desc")

var Lit_265 *jrt.String = jrt.Intern("string?")

var Lit_266 *jrt.String = jrt.Intern("prim-desc->name")

var Lit_267 *jrt.String = jrt.Intern("desc->class-name")

var Lit_268 *jrt.String = jrt.Intern("clojure-tag-desc")

var Lit_269 *jrt.String = jrt.Intern("class-name-of")

var Lit_270 *jrt.String = jrt.Intern("empty?")

var Lit_271 *jrt.String = jrt.Intern("newTypeReference")

var Lit_272 *jrt.String = jrt.Intern("METHOD_RECEIVER")

var Lit_273 *jrt.String = jrt.Intern("METHOD_RETURN")

var Lit_274 *jrt.String = jrt.Intern("newFormalParameterReference")

var Lit_275 *jrt.String = jrt.Intern("newExceptionReference")

var Lit_276 *jrt.String = jrt.Intern("static")

var Lit_277 *jrt.String = jrt.Intern("method-scope")

var Lit_278 *jrt.String = jrt.Intern("vmeta")

var Lit_279 *jrt.String = jrt.Intern("not-any?")

var Lit_280 *jrt.String = jrt.Intern("clojure-method")

var Lit_281 *jrt.String = jrt.Intern("clojure-override")

var Lit_282 *jrt.String = jrt.Intern("infer-signature")

var Lit_283 *jrt.String = jrt.Intern("desc->tnode")

var Lit_284 *jrt.String = jrt.Intern("prim?")

var Lit_285 *jrt.String = jrt.Intern("prim")

var Lit_286 *jrt.String = jrt.Intern("flags-of")

var Lit_287 *jrt.String = jrt.Intern("iface-kind?")

var Lit_288 *jrt.String = jrt.Intern("varargs")

var Lit_289 *jrt.String = jrt.Intern("deprecated-flag")

var Lit_290 *jrt.String = jrt.Intern("recv")

var Lit_291 *jrt.String = jrt.Intern("ret-tn")

var Lit_292 *jrt.String = jrt.Intern("sig")

var Lit_293 *jrt.String = jrt.Intern("method-signature")

var Lit_294 *jrt.String = jrt.Intern("param-annotations")

var Lit_295 *jrt.String = jrt.Intern("method-type-annotations")

var Lit_296 *jrt.String = jrt.Intern("default")

var Lit_297 *jrt.String = jrt.Intern("has-default")

var Lit_298 *jrt.String = jrt.Intern("contains?")

var Lit_299 *jrt.String = jrt.Intern("scope")

var Lit_300 *jrt.String = jrt.Intern("method")

var Lit_301 *jrt.String = jrt.Intern("param-info")

var Lit_302 *jrt.String = jrt.Intern("method-mods")

var Lit_303 *jrt.String = jrt.Intern("private")

var Lit_304 *jrt.String = jrt.Intern("has-body")

var Lit_305 *jrt.String = jrt.Intern("last")

var Lit_306 *jrt.String = jrt.Intern("inner-flags")

var Lit_307 *jrt.String = jrt.Intern("V")

var Lit_308 *jrt.String = jrt.Intern("compact")

var Lit_309 *jrt.String = jrt.Intern("ctor")

var Lit_310 *jrt.String = jrt.Intern("public")

var Lit_311 *jrt.String = jrt.Intern("protected")

var Lit_312 *jrt.String = jrt.Intern("synthetic")

var Lit_313 *jrt.String = jrt.Intern("has-init")

var Lit_314 *jrt.String = jrt.Intern("init")

var Lit_315 *jrt.String = jrt.Intern("val")

var Lit_316 *jrt.String = jrt.Intern("lenient")

var Lit_317 *jrt.String = jrt.Intern("field-init")

var Lit_318 *jrt.String = jrt.Intern("field-mods")

var Lit_319 *jrt.String = jrt.Intern("FIELD")

var Lit_320 *jrt.String = jrt.Intern("members-done")

var Lit_321 *jrt.String = jrt.Intern("for-target")

var Lit_322 *jrt.String = jrt.Intern("component")

var Lit_323 *jrt.String = jrt.Intern("class-access")

var Lit_324 *jrt.String = jrt.Intern("canonical")

var Lit_325 *jrt.String = jrt.Intern("anon-ctor-desc")

var Lit_326 *jrt.String = jrt.Intern("in-progress")

var Lit_327 *jrt.String = jrt.Intern("resolve-members!")

var Lit_328 *jrt.String = jrt.Intern("field")

var Lit_329 *jrt.String = jrt.Intern("enter-field")

var Lit_330 *jrt.String = jrt.Intern("enter-method")

var Lit_331 *jrt.String = jrt.Intern("enter-ctor")

var Lit_332 *jrt.String = jrt.Intern("enum-constant")

var Lit_333 *jrt.String = jrt.Intern("constants")

var Lit_334 *jrt.String = jrt.Intern("array-of")

var Lit_335 *jrt.String = jrt.Intern("enum-values-field")

var Lit_336 *jrt.String = jrt.Intern("derived-method")

var Lit_337 *jrt.String = jrt.Intern("enum-values")

var Lit_338 *jrt.String = jrt.Intern("enum-valueOf")

var Lit_339 *jrt.String = jrt.Intern("mparams")

var Lit_340 *jrt.String = jrt.Intern("enum-$values")

var Lit_341 *jrt.String = jrt.Intern("&")

var Lit_342 *jrt.String = jrt.Intern("components")

var Lit_343 *jrt.String = jrt.Intern("remove")

var Lit_344 *jrt.String = jrt.Intern("record-accessor")

var Lit_345 *jrt.String = jrt.Intern("record-object-method")

var Lit_346 *jrt.String = jrt.Intern("toString")

var Lit_347 *jrt.String = jrt.Intern("()Ljava/lang/String;")

var Lit_348 *jrt.String = jrt.Intern("hashCode")

var Lit_349 *jrt.String = jrt.Intern("()I")

var Lit_350 *jrt.String = jrt.Intern("equals")

var Lit_351 *jrt.String = jrt.Intern("(Ljava/lang/Object;)Z")

var Lit_352 *jrt.String = jrt.Intern("record-canonical")

var Lit_353 *jrt.String = jrt.Intern("anon-super-ctor")

var Lit_354 *jrt.String = jrt.Intern("anon-ctor")

var Lit_355 *jrt.String = jrt.Intern("default-ctor")

var Lit_356 *jrt.String = jrt.Intern("fields")

var Lit_357 *jrt.String = jrt.Intern("char?")

var Lit_358 *jrt.String = jrt.Intern("integer?")

var Lit_359 *jrt.String = jrt.Intern("<=")

var Lit_360 *jrt.String = jrt.Intern("op")

var Lit_361 *jrt.String = jrt.Intern("null")

var Lit_362 *jrt.String = jrt.Intern("widening")

var Lit_363 *jrt.String = jrt.Intern("box-of")

var Lit_364 *jrt.String = jrt.Intern("loose")

var Lit_365 *jrt.String = jrt.Intern("literal")

var Lit_366 *jrt.String = jrt.Intern("value-type")

var Lit_367 *jrt.String = jrt.Intern("none")

var Lit_368 *jrt.String = jrt.Intern("widens?")

var Lit_369 *jrt.String = jrt.Intern("widen")

var Lit_370 *jrt.String = jrt.Intern("fits?")

var Lit_371 *jrt.String = jrt.Intern("narrow-const")

var Lit_372 *jrt.String = jrt.Intern("literal-tail-vals")

var Lit_373 *jrt.String = jrt.Intern("box")

var Lit_374 *jrt.String = jrt.Intern("unbox-of")

var Lit_375 *jrt.String = jrt.Intern("unbox")

var Lit_376 *jrt.String = jrt.Intern("boxed-desc")

var Lit_377 *jrt.String = jrt.Intern("unify")

var Lit_378 *jrt.String = jrt.Intern("lub")

var Lit_379 *jrt.String = jrt.Intern("do")

var Lit_380 *jrt.String = jrt.Intern("literal-tail?")

var Lit_381 *jrt.String = jrt.Intern("if")

var Lit_382 *jrt.String = jrt.Intern("then")

var Lit_383 *jrt.String = jrt.Intern("switch")

var Lit_384 *jrt.String = jrt.Intern("try")

var Lit_385 *jrt.String = jrt.Intern("body")

var Lit_386 *jrt.String = jrt.Intern("cases")

var Lit_387 *jrt.String = jrt.Intern("let")

var Lit_388 *jrt.String = jrt.Intern("catches")

var Lit_389 *jrt.String = jrt.Intern("monitor")

var Lit_390 *jrt.String = jrt.Intern("mapcat")

var Lit_391 *jrt.String = jrt.Intern("convert-node")

var Lit_392 *jrt.String = jrt.Intern("S")

var Lit_393 *jrt.String = jrt.Intern("C")

var Lit_394 *jrt.String = jrt.Intern("B")

var Lit_395 *jrt.String = jrt.Intern("id")

var Lit_396 *jrt.String = jrt.Intern("next-id")

var Lit_397 *jrt.String = jrt.Intern("parent")

var Lit_398 *jrt.String = jrt.Intern("boundary")

var Lit_399 *jrt.String = jrt.Intern("ctor-prologue")

var Lit_400 *jrt.String = jrt.Intern("ctor-phase")

var Lit_401 *jrt.String = jrt.Intern("prologue")

var Lit_402 *jrt.String = jrt.Intern("frame")

var Lit_403 *jrt.String = jrt.Intern("assoc-in")

var Lit_404 *jrt.String = jrt.Intern("locals")

var Lit_405 *jrt.String = jrt.Intern("scope-of")

var Lit_406 *jrt.String = jrt.Intern("lambda")

var Lit_407 *jrt.String = jrt.Intern("cval")

var Lit_408 *jrt.String = jrt.Intern("receiver")

var Lit_409 *jrt.String = jrt.Intern("outer-this-node")

var Lit_410 *jrt.String = jrt.Intern("b")

var Lit_411 *jrt.String = jrt.Intern("captured")

var Lit_412 *jrt.String = jrt.Intern("mutable")

var Lit_413 *jrt.String = jrt.Intern("add-capture!")

var Lit_414 *jrt.String = jrt.Intern("take-while")

var Lit_415 *jrt.String = jrt.Intern("outer-param")

var Lit_416 *jrt.String = jrt.Intern("local-ref")

var Lit_417 *jrt.String = jrt.Intern("outer-param-path")

var Lit_418 *jrt.String = jrt.Intern("base")

var Lit_419 *jrt.String = jrt.Intern("outer-this-node*")

var Lit_420 *jrt.String = jrt.Intern("iterate")

var Lit_421 *jrt.String = jrt.Intern("this-path")

var Lit_422 *jrt.String = jrt.Intern("reset!")

var Lit_423 *jrt.String = jrt.Intern("uses-this")

var Lit_424 *jrt.String = jrt.Intern("creation-frame")

var Lit_425 *jrt.String = jrt.Intern("class-parent-frame")

var Lit_426 *jrt.String = jrt.Intern("var?")

var Lit_427 *jrt.String = jrt.Intern("ns-resolve")

var Lit_428 *jrt.String = jrt.Intern("resolve-var")

var Lit_429 *jrt.String = jrt.Intern("core-var?")

var Lit_430 *jrt.String = jrt.Intern("clojure-specials")

var Lit_431 *jrt.String = jrt.Intern("arbace-specials")

var Lit_432 *jrt.String = jrt.Intern("macro")

var Lit_433 *jrt.String = jrt.Intern("line")

var Lit_434 *jrt.String = jrt.Intern("ex-data")

var Lit_435 *jrt.String = jrt.Intern("ex-message")

var Lit_436 *jrt.String = jrt.Intern("with-form-info")

var Lit_437 *jrt.String = jrt.Intern("analyze-symbol")

var Lit_438 *jrt.String = jrt.Intern("analyze-op")

var Lit_439 *jrt.String = jrt.Intern("const-node")

var Lit_440 *jrt.String = jrt.Intern("boolean?")

var Lit_441 *jrt.String = jrt.Intern("keyword?")

var Lit_442 *jrt.String = jrt.Intern("clj-constant")

var Lit_443 *jrt.String = jrt.Intern("clj-collection")

var Lit_444 *jrt.String = jrt.Intern("set?")

var Lit_445 *jrt.String = jrt.Intern("accessorize")

var Lit_446 *jrt.String = jrt.Intern("coerce-hint")

var Lit_447 *jrt.String = jrt.Intern("lang-desc")

var Lit_448 *jrt.String = jrt.Intern("identity")

var Lit_449 *jrt.String = jrt.Intern("bigint")

var Lit_450 *jrt.String = jrt.Intern("actx-desc")

var Lit_451 *jrt.String = jrt.Intern("array-clone")

var Lit_452 *jrt.String = jrt.Intern("branching-tail?")

var Lit_453 *jrt.String = jrt.Intern("cast")

var Lit_454 *jrt.String = jrt.Intern("expr")

var Lit_455 *jrt.String = jrt.Intern("cast-to")

var Lit_456 *jrt.String = jrt.Intern("analyze")

var Lit_457 *jrt.String = jrt.Intern("statements")

var Lit_458 *jrt.String = jrt.Intern("butlast")

var Lit_459 *jrt.String = jrt.Intern("static-flag?")

var Lit_460 *jrt.String = jrt.Intern("const-value")

var Lit_461 *jrt.String = jrt.Intern("get-static")

var Lit_462 *jrt.String = jrt.Intern("get-field")

var Lit_463 *jrt.String = jrt.Intern("target")

var Lit_464 *jrt.String = jrt.Intern("const-only")

var Lit_465 *jrt.String = jrt.Intern("const-classes")

var Lit_466 *jrt.String = jrt.Intern("clojure")

var Lit_467 *jrt.String = jrt.Intern("class-lit")

var Lit_468 *jrt.String = jrt.Intern("find-own-field")

var Lit_469 *jrt.String = jrt.Intern("field-node")

var Lit_470 *jrt.String = jrt.Intern("resolve-class")

var Lit_471 *jrt.String = jrt.Intern("find-field")

var Lit_472 *jrt.String = jrt.Intern("prim-names")

var Lit_473 *jrt.String = jrt.Intern("re-find")

var Lit_474 *jrt.String = jrt.Intern("var-deref")

var Lit_475 *jrt.String = jrt.Intern("var")

var Lit_476 *jrt.String = jrt.Intern("clj-var-field")

var Lit_477 *jrt.String = jrt.Intern("subclass?")

var Lit_478 *jrt.String = jrt.Intern("declarer")

var Lit_479 *jrt.String = jrt.Intern("clojure-tag")

var Lit_480 *jrt.String = jrt.Intern("[1-9]")

var Lit_481 *jrt.String = jrt.Intern("accessible?")

var Lit_482 *jrt.String = jrt.Intern("\\.")

var Lit_483 *jrt.String = jrt.Intern("unresolved")

var Lit_484 *jrt.String = jrt.Intern("convert")

var Lit_485 *jrt.String = jrt.Intern("from")

var Lit_486 *jrt.String = jrt.Intern("to")

var Lit_487 *jrt.String = jrt.Intern("unboxed")

var Lit_488 *jrt.String = jrt.Intern("prim-type")

var Lit_489 *jrt.String = jrt.Intern("clone-tail?")

var Lit_490 *jrt.String = jrt.Intern("invoke")

var Lit_491 *jrt.String = jrt.Intern("retype-clone")

var Lit_492 *jrt.String = jrt.Intern("no-cast")

var Lit_493 *jrt.String = jrt.Intern("if-instance")

var Lit_494 *jrt.String = jrt.Intern("what")

var Lit_495 *jrt.String = jrt.Intern("conversion")

var Lit_496 *jrt.String = jrt.Intern("loop")

var Lit_497 *jrt.String = jrt.Intern("label")

var Lit_498 *jrt.String = jrt.Intern("breaks")

var Lit_499 *jrt.String = jrt.Intern("pr-str")

var Lit_500 *jrt.String = jrt.Intern("unify-nodes")

var Lit_501 *jrt.String = jrt.Intern("const-of-type")

var Lit_502 *jrt.String = jrt.Intern("lang-class")

var Lit_503 *jrt.String = jrt.Intern("itf")

var Lit_504 *jrt.String = jrt.Intern("operand")

var Lit_505 *jrt.String = jrt.Intern("rem")

var Lit_506 *jrt.String = jrt.Intern("fmod")

var Lit_507 *jrt.String = jrt.Intern("sub")

var Lit_508 *jrt.String = jrt.Intern("dec")

var Lit_509 *jrt.String = jrt.Intern("mul")

var Lit_510 *jrt.String = jrt.Intern("div")

var Lit_511 *jrt.String = jrt.Intern("neg")

var Lit_512 *jrt.String = jrt.Intern("ushr")

var Lit_513 *jrt.String = jrt.Intern("add")

var Lit_514 *jrt.String = jrt.Intern("or")

var Lit_515 *jrt.String = jrt.Intern("and")

var Lit_516 *jrt.String = jrt.Intern("shr")

var Lit_517 *jrt.String = jrt.Intern("xor")

var Lit_518 *jrt.String = jrt.Intern("shl")

var Lit_519 *jrt.String = jrt.Intern("andnot")

var Lit_520 *jrt.String = jrt.Intern("arith-ops")

var Lit_521 *jrt.String = jrt.Intern("exact")

var Lit_522 *jrt.String = jrt.Intern("numeric?")

var Lit_523 *jrt.String = jrt.Intern("longbits")

var Lit_524 *jrt.String = jrt.Intern("float")

var Lit_525 *jrt.String = jrt.Intern("long")

var Lit_526 *jrt.String = jrt.Intern("fold-arith")

var Lit_527 *jrt.String = jrt.Intern("arith")

var Lit_528 *jrt.String = jrt.Intern("family")

var Lit_529 *jrt.String = jrt.Intern("o")

var Lit_530 *jrt.String = jrt.Intern("F")

var Lit_531 *jrt.String = jrt.Intern("D")

var Lit_532 *jrt.String = jrt.Intern("int")

var Lit_533 *jrt.String = jrt.Intern("int-like?")

var Lit_534 *jrt.String = jrt.Intern("dissoc")

var Lit_535 *jrt.String = jrt.Intern("compare-type")

var Lit_536 *jrt.String = jrt.Intern("compare")

var Lit_537 *jrt.String = jrt.Intern("cmp")

var Lit_538 *jrt.String = jrt.Intern("lambda-form?")

var Lit_539 *jrt.String = jrt.Intern("bindings")

var Lit_540 *jrt.String = jrt.Intern("arbace.classes")

var Lit_541 *jrt.String = jrt.Intern("fn-body")

var Lit_542 *jrt.String = jrt.Intern("label-loop")

var Lit_543 *jrt.String = jrt.Intern("analyze-body")

var Lit_544 *jrt.String = jrt.Intern("even?")

var Lit_545 *jrt.String = jrt.Intern("binding-type")

var Lit_546 *jrt.String = jrt.Intern("bind-init")

var Lit_547 *jrt.String = jrt.Intern("make-binding")

var Lit_548 *jrt.String = jrt.Intern("pending-var")

var Lit_549 *jrt.String = jrt.Intern("loop-local")

var Lit_550 *jrt.String = jrt.Intern("local-type-anns")

var Lit_551 *jrt.String = jrt.Intern("with-local")

var Lit_552 *jrt.String = jrt.Intern("partition")

var Lit_553 *jrt.String = jrt.Intern("break-target")

var Lit_554 *jrt.String = jrt.Intern("labels")

var Lit_555 *jrt.String = jrt.Intern("letclass")

var Lit_556 *jrt.String = jrt.Intern("class*")

var Lit_557 *jrt.String = jrt.Intern("tree-seq")

var Lit_558 *jrt.String = jrt.Intern("coll?")

var Lit_559 *jrt.String = jrt.Intern("class-def-in?")

var Lit_560 *jrt.String = jrt.Intern("test")

var Lit_561 *jrt.String = jrt.Intern("literal-branch")

var Lit_562 *jrt.String = jrt.Intern("recur")

var Lit_563 *jrt.String = jrt.Intern("for-each*")

var Lit_564 *jrt.String = jrt.Intern("loop*")

var Lit_565 *jrt.String = jrt.Intern("macroexpand1")

var Lit_566 *jrt.String = jrt.Intern("kw")

var Lit_567 *jrt.String = jrt.Intern("expand-to-loop")

var Lit_568 *jrt.String = jrt.Intern("break")

var Lit_569 *jrt.String = jrt.Intern("return")

var Lit_570 *jrt.String = jrt.Intern("throw")

var Lit_571 *jrt.String = jrt.Intern("catch")

var Lit_572 *jrt.String = jrt.Intern("finally")

var Lit_573 *jrt.String = jrt.Intern("classes")

var Lit_574 *jrt.String = jrt.Intern("code-type-anns")

var Lit_575 *jrt.String = jrt.Intern("lock")

var Lit_576 *jrt.String = jrt.Intern("set-local")

var Lit_577 *jrt.String = jrt.Intern("set-static")

var Lit_578 *jrt.String = jrt.Intern("set-field")

var Lit_579 *jrt.String = jrt.Intern("super-node")

var Lit_580 *jrt.String = jrt.Intern("analyze-field-access")

var Lit_581 *jrt.String = jrt.Intern(".")

var Lit_582 *jrt.String = jrt.Intern("analyze-set!")

var Lit_583 *jrt.String = jrt.Intern("list")

var Lit_584 *jrt.String = jrt.Intern("^-")

var Lit_585 *jrt.String = jrt.Intern("set!")

var Lit_586 *jrt.String = jrt.Intern("strict")

var Lit_587 *jrt.String = jrt.Intern("_")

var Lit_588 *jrt.String = jrt.Intern("find-sam")

var Lit_589 *jrt.String = jrt.Intern("ps")

var Lit_590 *jrt.String = jrt.Intern("clj-fi-excluded")

var Lit_591 *jrt.String = jrt.Intern("fi-method")

var Lit_592 *jrt.String = jrt.Intern("unknown")

var Lit_593 *jrt.String = jrt.Intern("clj-fi-method")

var Lit_594 *jrt.String = jrt.Intern("clj-prim-args")

var Lit_595 *jrt.String = jrt.Intern("vector")

var Lit_596 *jrt.String = jrt.Intern("clj-param-arg-match?")

var Lit_597 *jrt.String = jrt.Intern("clj-subsumes?")

var Lit_598 *jrt.String = jrt.Intern("clj-arg-class")

var Lit_599 *jrt.String = jrt.Intern("no-reflect")

var Lit_600 *jrt.String = jrt.Intern("clj-ret-assignable?")

var Lit_601 *jrt.String = jrt.Intern("join")

var Lit_602 *jrt.String = jrt.Intern("clj-matching-index")

var Lit_603 *jrt.String = jrt.Intern("why")

var Lit_604 *jrt.String = jrt.Intern("no such method")

var Lit_605 *jrt.String = jrt.Intern("clojure-args")

var Lit_606 *jrt.String = jrt.Intern("clj-type-string")

var Lit_607 *jrt.String = jrt.Intern("more-specific?")

var Lit_608 *jrt.String = jrt.Intern("param-tags-match?")

var Lit_609 *jrt.String = jrt.Intern("applicable?")

var Lit_610 *jrt.String = jrt.Intern("expand-varargs")

var Lit_611 *jrt.String = jrt.Intern("member-methods")

var Lit_612 *jrt.String = jrt.Intern("constructors")

var Lit_613 *jrt.String = jrt.Intern("fi-adapter")

var Lit_614 *jrt.String = jrt.Intern("sam-name")

var Lit_615 *jrt.String = jrt.Intern("sam-desc")

var Lit_616 *jrt.String = jrt.Intern("invoker")

var Lit_617 *jrt.String = jrt.Intern("invoker-desc")

var Lit_618 *jrt.String = jrt.Intern("Z")

var Lit_619 *jrt.String = jrt.Intern("clj-arg-convert")

var Lit_620 *jrt.String = jrt.Intern("array-init")

var Lit_621 *jrt.String = jrt.Intern("elems")

var Lit_622 *jrt.String = jrt.Intern("take")

var Lit_623 *jrt.String = jrt.Intern("drop")

var Lit_624 *jrt.String = jrt.Intern("qualifying-owner")

var Lit_625 *jrt.String = jrt.Intern("special")

var Lit_626 *jrt.String = jrt.Intern("virtual")

var Lit_627 *jrt.String = jrt.Intern("convert-args")

var Lit_628 *jrt.String = jrt.Intern("java/lang/invoke/MethodHandle")

var Lit_629 *jrt.String = jrt.Intern("java/lang/invoke/VarHandle")

var Lit_630 *jrt.String = jrt.Intern("warn")

var Lit_631 *jrt.String = jrt.Intern("reflection")

var Lit_632 *jrt.String = jrt.Intern("*warn-on-reflection*")

var Lit_633 *jrt.String = jrt.Intern("println")

var Lit_634 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_635 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_636 *jrt.String = jrt.Intern("hash-map")

var Lit_637 *jrt.String = jrt.Intern("*out*")

var Lit_638 *jrt.String = jrt.Intern("*err*")

var Lit_639 *jrt.String = jrt.Intern("*file*")

var Lit_640 *jrt.String = jrt.Intern("reflective-node")

var Lit_641 *jrt.String = jrt.Intern("reflection-warning")

var Lit_642 *jrt.String = jrt.Intern("objects")

var Lit_643 *jrt.String = jrt.Intern("^(No accessible|No matching|Ambiguous call|No field|No static field|Field not accessible|Method call|Field access)")

var Lit_644 *jrt.String = jrt.Intern("reflect?")

var Lit_645 *jrt.String = jrt.Intern("unresolved?")

var Lit_646 *jrt.String = jrt.Intern("param-tags")

var Lit_647 *jrt.String = jrt.Intern("owner-override")

var Lit_648 *jrt.String = jrt.Intern("ret-tag")

var Lit_649 *jrt.String = jrt.Intern("type-args")

var Lit_650 *jrt.String = jrt.Intern("or-reflect")

var Lit_651 *jrt.String = jrt.Intern("analyze-method-call*")

var Lit_652 *jrt.String = jrt.Intern("analyze-method-call")

var Lit_653 *jrt.String = jrt.Intern("type-arg-anns")

var Lit_654 *jrt.String = jrt.Intern("arg-nodes")

var Lit_655 *jrt.String = jrt.Intern("reflective-call")

var Lit_656 *jrt.String = jrt.Intern("instance-candidates")

var Lit_657 *jrt.String = jrt.Intern("signature-polymorphic?")

var Lit_658 *jrt.String = jrt.Intern("clj-select")

var Lit_659 *jrt.String = jrt.Intern("select-method")

var Lit_660 *jrt.String = jrt.Intern("invoke-node")

var Lit_661 *jrt.String = jrt.Intern("instance")

var Lit_662 *jrt.String = jrt.Intern("static-candidates")

var Lit_663 *jrt.String = jrt.Intern("clj-inline")

var Lit_664 *jrt.String = jrt.Intern("analyze-field-access*")

var Lit_665 *jrt.String = jrt.Intern("alength")

var Lit_666 *jrt.String = jrt.Intern("null-checked")

var Lit_667 *jrt.String = jrt.Intern("this-node")

var Lit_668 *jrt.String = jrt.Intern("keep-indexed")

var Lit_669 *jrt.String = jrt.Intern("analyze-dot*")

var Lit_670 *jrt.String = jrt.Intern("in-ctor")

var Lit_671 *jrt.String = jrt.Intern("needs-outer-instance?")

var Lit_672 *jrt.String = jrt.Intern("ctor-call-node")

var Lit_673 *jrt.String = jrt.Intern("outer-super-call")

var Lit_674 *jrt.String = jrt.Intern("receiver-class")

var Lit_675 *jrt.String = jrt.Intern("analyze-static-call")

var Lit_676 *jrt.String = jrt.Intern("new")

var Lit_677 *jrt.String = jrt.Intern("ctor-candidates")

var Lit_678 *jrt.String = jrt.Intern("ctor-call")

var Lit_679 *jrt.String = jrt.Intern("array-dims")

var Lit_680 *jrt.String = jrt.Intern("new-array")

var Lit_681 *jrt.String = jrt.Intern("dims")

var Lit_682 *jrt.String = jrt.Intern("int-operand")

var Lit_683 *jrt.String = jrt.Intern("with-meta")

var Lit_684 *jrt.String = jrt.Intern("outer-instance-for")

var Lit_685 *jrt.String = jrt.Intern("array-new")

var Lit_686 *jrt.String = jrt.Intern("reverse")

var Lit_687 *jrt.String = jrt.Intern("aget")

var Lit_688 *jrt.String = jrt.Intern("index")

var Lit_689 *jrt.String = jrt.Intern("aset")

var Lit_690 *jrt.String = jrt.Intern("instance?")

var Lit_691 *jrt.String = jrt.Intern("analyze-conversion")

var Lit_692 *jrt.String = jrt.Intern("type-arg")

var Lit_693 *jrt.String = jrt.Intern("ends-with?")

var Lit_694 *jrt.String = jrt.Intern("list*")

var Lit_695 *jrt.String = jrt.Intern("class-literal*")

var Lit_696 *jrt.String = jrt.Intern("super.")

var Lit_697 *jrt.String = jrt.Intern("this.")

var Lit_698 *jrt.String = jrt.Intern("qualified-instance")

var Lit_699 *jrt.String = jrt.Intern("with-node-locals")

var Lit_700 *jrt.String = jrt.Intern("repeatedly")

var Lit_701 *jrt.String = jrt.Intern("gensym")

var Lit_702 *jrt.String = jrt.Intern("inline")

var Lit_703 *jrt.String = jrt.Intern("inline-arities")

var Lit_704 *jrt.String = jrt.Intern("var-invoke-node")

var Lit_705 *jrt.String = jrt.Intern("clj-call-node")

var Lit_706 *jrt.String = jrt.Intern("specialized")

var Lit_707 *jrt.String = jrt.Intern("conversions")

var Lit_708 *jrt.String = jrt.Intern("checked-conversions")

var Lit_709 *jrt.String = jrt.Intern("comparisons")

var Lit_710 *jrt.String = jrt.Intern("neg?")

var Lit_711 *jrt.String = jrt.Intern("pos?")

var Lit_712 *jrt.String = jrt.Intern("zero?")

var Lit_713 *jrt.String = jrt.Intern("bool=")

var Lit_714 *jrt.String = jrt.Intern("nil?")

var Lit_715 *jrt.String = jrt.Intern("identical?")

var Lit_716 *jrt.String = jrt.Intern("analyze-instance?")

var Lit_717 *jrt.String = jrt.Intern("analyze-cast")

var Lit_718 *jrt.String = jrt.Intern("analyze-aset")

var Lit_719 *jrt.String = jrt.Intern("analyze-aget")

var Lit_720 *jrt.String = jrt.Intern("analyze-locking")

var Lit_721 *jrt.String = jrt.Intern("analyze-arith")

var Lit_722 *jrt.String = jrt.Intern("analyze-compare")

var Lit_723 *jrt.String = jrt.Intern("=")

var Lit_724 *jrt.String = jrt.Intern("analyze-fn-call")

var Lit_725 *jrt.String = jrt.Intern("analyze-dot")

var Lit_726 *jrt.String = jrt.Intern("analyze-for-each")

var Lit_727 *jrt.String = jrt.Intern("switch*")

var Lit_728 *jrt.String = jrt.Intern("analyze-switch")

var Lit_729 *jrt.String = jrt.Intern("with-resources*")

var Lit_730 *jrt.String = jrt.Intern("analyze-with-resources")

var Lit_731 *jrt.String = jrt.Intern("import*")

var Lit_732 *jrt.String = jrt.Intern("analyze-clj-special")

var Lit_733 *jrt.String = jrt.Intern("core-op")

var Lit_734 *jrt.String = jrt.Intern("core-op-node")

var Lit_735 *jrt.String = jrt.Intern("method-sugar")

var Lit_736 *jrt.String = jrt.Intern("reify*")

var Lit_737 *jrt.String = jrt.Intern("java-str*")

var Lit_738 *jrt.String = jrt.Intern("analyze-java-str")

var Lit_739 *jrt.String = jrt.Intern("case*")

var Lit_740 *jrt.String = jrt.Intern("analyze-try")

var Lit_741 *jrt.String = jrt.Intern("analyze-ctor-call")

var Lit_742 *jrt.String = jrt.Intern("label*")

var Lit_743 *jrt.String = jrt.Intern("analyze-label")

var Lit_744 *jrt.String = jrt.Intern("break*")

var Lit_745 *jrt.String = jrt.Intern("analyze-break")

var Lit_746 *jrt.String = jrt.Intern("monitor-enter")

var Lit_747 *jrt.String = jrt.Intern("this")

var Lit_748 *jrt.String = jrt.Intern("lambda*")

var Lit_749 *jrt.String = jrt.Intern("analyze-lambda")

var Lit_750 *jrt.String = jrt.Intern("analyze-throw")

var Lit_751 *jrt.String = jrt.Intern("letfn*")

var Lit_752 *jrt.String = jrt.Intern("analyze-letclass")

var Lit_753 *jrt.String = jrt.Intern("analyze-anon")

var Lit_754 *jrt.String = jrt.Intern("continue*")

var Lit_755 *jrt.String = jrt.Intern("analyze-recur")

var Lit_756 *jrt.String = jrt.Intern("java-assert*")

var Lit_757 *jrt.String = jrt.Intern("analyze-java-assert")

var Lit_758 *jrt.String = jrt.Intern("analyze-if")

var Lit_759 *jrt.String = jrt.Intern("quote")

var Lit_760 *jrt.String = jrt.Intern("number?")

var Lit_761 *jrt.String = jrt.Intern("method-ref*")

var Lit_762 *jrt.String = jrt.Intern("analyze-method-ref")

var Lit_763 *jrt.String = jrt.Intern("monitor-exit")

var Lit_764 *jrt.String = jrt.Intern("let*")

var Lit_765 *jrt.String = jrt.Intern("analyze-let")

var Lit_766 *jrt.String = jrt.Intern("def")

var Lit_767 *jrt.String = jrt.Intern("analyze-new")

var Lit_768 *jrt.String = jrt.Intern("fn*")

var Lit_769 *jrt.String = jrt.Intern("return*")

var Lit_770 *jrt.String = jrt.Intern("analyze-return")

var Lit_771 *jrt.String = jrt.Intern("if-instance*")

var Lit_772 *jrt.String = jrt.Intern("analyze-if-instance")

var Lit_773 *jrt.String = jrt.Intern("deftype*")

var Lit_774 *jrt.String = jrt.Intern("var-invoke")

var Lit_775 *jrt.String = jrt.Intern("*ns*")

var Lit_776 *jrt.String = jrt.Intern("lower-reify")

var Lit_777 *jrt.String = jrt.Intern("lower-fn")

var Lit_778 *jrt.String = jrt.Intern("lower-letfn")

var Lit_779 *jrt.String = jrt.Intern("expand-fully")

var Lit_780 *jrt.String = jrt.Intern("intern")

var Lit_781 *jrt.String = jrt.Intern("importClass")

var Lit_782 *jrt.String = jrt.Intern("arbace.lang.Namespace")

var Lit_783 *jrt.String = jrt.Intern("arbace.lang.RT")

var Lit_784 *jrt.String = jrt.Intern("CURRENT_NS")

var Lit_785 *jrt.String = jrt.Intern("classForNameNonLoading")

var Lit_786 *jrt.String = jrt.Intern("dynamic")

var Lit_787 *jrt.String = jrt.Intern("lower-def")

var Lit_788 *jrt.String = jrt.Intern("column")

var Lit_789 *jrt.String = jrt.Intern("nnext")

var Lit_790 *jrt.String = jrt.Intern("non-constant-heads")

var Lit_791 *jrt.String = jrt.Intern("may-be-constant?")

var Lit_792 *jrt.String = jrt.Intern("new-frame")

var Lit_793 *jrt.String = jrt.Intern("class-init")

var Lit_794 *jrt.String = jrt.Intern("creation-actx")

var Lit_795 *jrt.String = jrt.Intern("method-info")

var Lit_796 *jrt.String = jrt.Intern("clojure-fn")

var Lit_797 *jrt.String = jrt.Intern("slot0")

var Lit_798 *jrt.String = jrt.Intern("param")

var Lit_799 *jrt.String = jrt.Intern("body-actx")

var Lit_800 *jrt.String = jrt.Intern("bind-params")

var Lit_801 *jrt.String = jrt.Intern("clj-convert")

var Lit_802 *jrt.String = jrt.Intern(".super")

var Lit_803 *jrt.String = jrt.Intern("ctor-call-form?")

var Lit_804 *jrt.String = jrt.Intern("nested-ctor-call?")

var Lit_805 *jrt.String = jrt.Intern("enum-args")

var Lit_806 *jrt.String = jrt.Intern("(Ljava/lang/String;I)V")

var Lit_807 *jrt.String = jrt.Intern("java/lang/Enum")

var Lit_808 *jrt.String = jrt.Intern("anon-args")

var Lit_809 *jrt.String = jrt.Intern("analyze-ctor-call*")

var Lit_810 *jrt.String = jrt.Intern("call")

var Lit_811 *jrt.String = jrt.Intern("nested-call")

var Lit_812 *jrt.String = jrt.Intern("outer-binding")

var Lit_813 *jrt.String = jrt.Intern("calls-super")

var Lit_814 *jrt.String = jrt.Intern("compact-locals")

var Lit_815 *jrt.String = jrt.Intern("implicit-super-call")

var Lit_816 *jrt.String = jrt.Intern("analyze-enum-body")

var Lit_817 *jrt.String = jrt.Intern("enum-const")

var Lit_818 *jrt.String = jrt.Intern("ordinal")

var Lit_819 *jrt.String = jrt.Intern("analyzed")

var Lit_820 *jrt.String = jrt.Intern("keep")

var Lit_821 *jrt.String = jrt.Intern("mid")

var Lit_822 *jrt.String = jrt.Intern("analyze-enum-constants")

var Lit_823 *jrt.String = jrt.Intern("analyze-class!")

var Lit_824 *jrt.String = jrt.Intern("analyze-method-body")

var Lit_825 *jrt.String = jrt.Intern("field-name")

var Lit_826 *jrt.String = jrt.Intern("clinit")

var Lit_827 *jrt.String = jrt.Intern("analyze-ctor-body")

var Lit_828 *jrt.String = jrt.Intern("this__")

var Lit_829 *jrt.String = jrt.Intern("bodies")

var Lit_830 *jrt.String = jrt.Intern("supers")

var Lit_831 *jrt.String = jrt.Intern("reflect->tnode")

var Lit_832 *jrt.String = jrt.Intern("subst")

var Lit_833 *jrt.String = jrt.Intern("class-generics")

var Lit_834 *jrt.String = jrt.Intern("bridges-done")

var Lit_835 *jrt.String = jrt.Intern("clojure-type")

var Lit_836 *jrt.String = jrt.Intern("supertype-envs")

var Lit_837 *jrt.String = jrt.Intern("memoize")

var Lit_838 *jrt.String = jrt.Intern("clojure-bridges")

var Lit_839 *jrt.String = jrt.Intern("superclass-chain")

var Lit_840 *jrt.String = jrt.Intern("erased-params")

var Lit_841 *jrt.String = jrt.Intern("impl-owner")

var Lit_842 *jrt.String = jrt.Intern("bit-or")

var Lit_843 *jrt.String = jrt.Intern("subvec")

var Lit_844 *jrt.String = jrt.Intern("resolve-header!")

var Lit_845 *jrt.String = jrt.Intern("supertypes-first")

var Lit_846 *jrt.String = jrt.Intern("add-bridges!")

var Lit_847 *jrt.String = jrt.Intern("mark-enum-abstract!")

var Lit_848 *jrt.String = jrt.Intern("declared-only")

var Lit_849 *jrt.String = jrt.Intern("local-class-name")

var Lit_850 *jrt.String = jrt.Intern("process-classes!")

var Lit_851 *jrt.String = jrt.Intern("select-keys")

var Lit_852 *jrt.String = jrt.Intern("prologue?")

var Lit_853 *jrt.String = jrt.Intern("super-outer-is-outer")

var Lit_854 *jrt.String = jrt.Intern("super-outer-path")

var Lit_855 *jrt.String = jrt.Intern("diamond")

var Lit_856 *jrt.String = jrt.Intern("class-flags")

var Lit_857 *jrt.String = jrt.Intern("accessible-class?")

var Lit_858 *jrt.String = jrt.Intern("sharpest-accessible")

var Lit_859 *jrt.String = jrt.Intern("java-str")

var Lit_860 *jrt.String = jrt.Intern("parts")

var Lit_861 *jrt.String = jrt.Intern("operands")

var Lit_862 *jrt.String = jrt.Intern("const-string")

var Lit_863 *jrt.String = jrt.Intern("tag-const")

var Lit_864 *jrt.String = jrt.Intern("node")

var Lit_865 *jrt.String = jrt.Intern("eager")

var Lit_866 *jrt.String = jrt.Intern("analyze-java-assert*")

var Lit_867 *jrt.String = jrt.Intern("assert")

var Lit_868 *jrt.String = jrt.Intern("msg")

var Lit_869 *jrt.String = jrt.Intern("holder-top")

var Lit_870 *jrt.String = jrt.Intern("msg-desc")

var Lit_871 *jrt.String = jrt.Intern("assert-holders")

var Lit_872 *jrt.String = jrt.Intern("holder-first")

var Lit_873 *jrt.String = jrt.Intern("interface-assert")

var Lit_874 *jrt.String = jrt.Intern("uses-assert")

var Lit_875 *jrt.String = jrt.Intern("arr")

var Lit_876 *jrt.String = jrt.Intern("len")

var Lit_877 *jrt.String = jrt.Intern("i")

var Lit_878 *jrt.String = jrt.Intern("it")

var Lit_879 *jrt.String = jrt.Intern("for-each")

var Lit_880 *jrt.String = jrt.Intern("coll")

var Lit_881 *jrt.String = jrt.Intern("hidden")

var Lit_882 *jrt.String = jrt.Intern("elem")

var Lit_883 *jrt.String = jrt.Intern("iterator")

var Lit_884 *jrt.String = jrt.Intern("normal-finally")

var Lit_885 *jrt.String = jrt.Intern("close")

var Lit_886 *jrt.String = jrt.Intern("java.lang.Throwable")

var Lit_887 *jrt.String = jrt.Intern("addSuppressed")

var Lit_888 *jrt.String = jrt.Intern("java/lang/Throwable")

var Lit_889 *jrt.String = jrt.Intern("object-methods")

var Lit_890 *jrt.String = jrt.Intern("inter")

var Lit_891 *jrt.String = jrt.Intern("types")

var Lit_892 *jrt.String = jrt.Intern("java/io/Serializable")

var Lit_893 *jrt.String = jrt.Intern("lambda-method-prefix")

var Lit_894 *jrt.String = jrt.Intern("update-in")

var Lit_895 *jrt.String = jrt.Intern("lambda-counters")

var Lit_896 *jrt.String = jrt.Intern("ref-lambda")

var Lit_897 *jrt.String = jrt.Intern("fi-types")

var Lit_898 *jrt.String = jrt.Intern("method-ref")

var Lit_899 *jrt.String = jrt.Intern("lambda-name!")

var Lit_900 *jrt.String = jrt.Intern("serial-lambda-name!")

var Lit_901 *jrt.String = jrt.Intern("fi")

var Lit_902 *jrt.String = jrt.Intern("markers")

var Lit_903 *jrt.String = jrt.Intern("serializable")

var Lit_904 *jrt.String = jrt.Intern("intersection")

var Lit_905 *jrt.String = jrt.Intern("sam")

var Lit_906 *jrt.String = jrt.Intern("inst-desc")

var Lit_907 *jrt.String = jrt.Intern("lambda-nodes")

var Lit_908 *jrt.String = jrt.Intern("serial-nodes")

var Lit_909 *jrt.String = jrt.Intern("qualifier-anns")

var Lit_910 *jrt.String = jrt.Intern("qualifier")

var Lit_911 *jrt.String = jrt.Intern("ref-as-lambda")

var Lit_912 *jrt.String = jrt.Intern("ref-owner")

var Lit_913 *jrt.String = jrt.Intern("arg-stub")

var Lit_914 *jrt.String = jrt.Intern("bound")

var Lit_915 *jrt.String = jrt.Intern("null-check")

var Lit_916 *jrt.String = jrt.Intern("unbound")

var Lit_917 *jrt.String = jrt.Intern("record-components")

var Lit_918 *jrt.String = jrt.Intern("analyze-pattern")

var Lit_919 *jrt.String = jrt.Intern("accessor")

var Lit_920 *jrt.String = jrt.Intern("pattern")

var Lit_921 *jrt.String = jrt.Intern("comps")

var Lit_922 *jrt.String = jrt.Intern("temp")

var Lit_923 *jrt.String = jrt.Intern("switch-maps")

var Lit_924 *jrt.String = jrt.Intern("prim-type-of")

var Lit_925 *jrt.String = jrt.Intern("odd?")

var Lit_926 *jrt.String = jrt.Intern("enum-class?")

var Lit_927 *jrt.String = jrt.Intern("string")

var Lit_928 *jrt.String = jrt.Intern("switch-map!")

var Lit_929 *jrt.String = jrt.Intern("sel")

var Lit_930 *jrt.String = jrt.Intern("sel-type")

var Lit_931 *jrt.String = jrt.Intern("enum-direct")

var Lit_932 *jrt.String = jrt.Intern("sel-binding")

var Lit_933 *jrt.String = jrt.Intern("restart")

var Lit_934 *jrt.String = jrt.Intern("when")

var Lit_935 *jrt.String = jrt.Intern("guard")

var Lit_936 *jrt.String = jrt.Intern("constant-label")

var Lit_937 *jrt.String = jrt.Intern("ctype")

var Lit_938 *jrt.String = jrt.Intern("*read-eval*")

var Lit_939 *jrt.String = jrt.Intern("eof")

var Lit_940 *jrt.String = jrt.Intern("read")

var Lit_941 *jrt.String = jrt.Intern("read-cond")

var Lit_942 *jrt.String = jrt.Intern("allow")

var Lit_943 *jrt.String = jrt.Intern("import-classes!")

var Lit_944 *jrt.String = jrt.Intern("eval")

var Lit_945 *jrt.String = jrt.Intern("create-ns")

var Lit_946 *jrt.String = jrt.Intern("defclass")

var Lit_947 *jrt.String = jrt.Intern("source-tried")

var Lit_948 *jrt.String = jrt.Intern("java.lang.ClassLoader")

var Lit_949 *jrt.String = jrt.Intern("read-source-forms")

var Lit_950 *jrt.String = jrt.Intern("import")

var Lit_951 *jrt.String = jrt.Intern("in-ns")

var Lit_952 *jrt.String = jrt.Intern("eval-ns-form!")

var Lit_953 *jrt.String = jrt.Intern("split-options")

var Lit_954 *jrt.String = jrt.Intern("access-count")

var Lit_955 *jrt.String = jrt.Intern("mod")

var Lit_956 *jrt.String = jrt.Intern("accessors")

var Lit_957 *jrt.String = jrt.Intern("accessor-owner")

var Lit_958 *jrt.String = jrt.Intern("add-accessor!")

var Lit_959 *jrt.String = jrt.Intern("insn")

var Lit_960 *jrt.String = jrt.Intern("putstatic")

var Lit_961 *jrt.String = jrt.Intern("getstatic")

var Lit_962 *jrt.String = jrt.Intern("putfield")

var Lit_963 *jrt.String = jrt.Intern("getfield")

var Lit_964 *jrt.String = jrt.Intern("invokestatic")

var Lit_965 *jrt.String = jrt.Intern("invokevirtual")

var Lit_966 *jrt.String = jrt.Intern("invokespecial")

var Lit_967 *jrt.String = jrt.Intern("clj-consts")

var Lit_968 *jrt.String = jrt.Intern("constant-field!")

var Lit_969 *jrt.String = jrt.Intern("text")

var Lit_970 *jrt.String = jrt.Intern("*print-meta*")

var Lit_971 *jrt.String = jrt.Intern("arbace.classes.analyze$accessible_class_QMARK_")

var Lit_972 *jrt.String = jrt.Intern("arbace.classes.analyze$accessor_owner")

var Lit_973 *jrt.String = jrt.Intern("arbace.classes.analyze$accessorize")

var Lit_974 *jrt.String = jrt.Intern("arbace.classes.analyze$actx_desc")

var Lit_975 *jrt.String = jrt.Intern("arbace.classes.analyze$add_accessor_BANG_")

var Lit_976 *jrt.String = jrt.Intern("access$")

var Lit_977 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_")

var Lit_978 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001639")

var Lit_979 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001673")

var Lit_980 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001673$fn__1549001674")

var Lit_981 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001680")

var Lit_982 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001682")

var Lit_983 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001682$fn__1549001683")

var Lit_984 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001689")

var Lit_985 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001694")

var Lit_986 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001694$fn__1549001695")

var Lit_987 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001701")

var Lit_988 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001703")

var Lit_989 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001703$fn__1549001704")

var Lit_990 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001710")

var Lit_991 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001724")

var Lit_992 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001724$fn__1549001725")

var Lit_993 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001728")

var Lit_994 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001730")

var Lit_995 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001735")

var Lit_996 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001737")

var Lit_997 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001737$fn__1549001738")

var Lit_998 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001741")

var Lit_999 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001743")

var Lit_1000 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001748")

var Lit_1001 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001750")

var Lit_1002 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001750$fn__1549001751")

var Lit_1003 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001754")

var Lit_1004 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001756")

var Lit_1005 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001761")

var Lit_1006 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001763")

var Lit_1007 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001763$fn__1549001764")

var Lit_1008 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001767")

var Lit_1009 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001769")

var Lit_1010 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001774")

var Lit_1011 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$members__1549001642")

var Lit_1012 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$present_QMARK___1549001644")

var Lit_1013 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$present_QMARK___1549001644$fn__1549001655")

var Lit_1014 *jrt.String = jrt.Intern("arbace.classes.analyze$add_capture_BANG_")

var Lit_1015 *jrt.String = jrt.Intern("arbace.classes.analyze$add_capture_BANG_$fn__1549000623")

var Lit_1016 *jrt.String = jrt.Intern("arbace.classes.analyze$add_capture_BANG_$fn__1549000623$fn__1549000624")

var Lit_1017 *jrt.String = jrt.Intern("arbace.classes.analyze$add_capture_BANG_$fn__1549000627")

var Lit_1018 *jrt.String = jrt.Intern("arbace.classes.analyze$add_capture_BANG_$fn__1549000627$fn__1549000628")

var Lit_1019 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze")

var Lit_1020 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze$fn__1549000650")

var Lit_1021 *jrt.String = jrt.Intern("Empty list in class body")

var Lit_1022 *jrt.String = jrt.Intern("J")

var Lit_1023 *jrt.String = jrt.Intern("IPersistentVector")

var Lit_1024 *jrt.String = jrt.Intern("IPersistentMap")

var Lit_1025 *jrt.String = jrt.Intern("IPersistentSet")

var Lit_1026 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_aget")

var Lit_1027 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_aget$fn__1549001217")

var Lit_1028 *jrt.String = jrt.Intern("aget on a non-array of type ")

var Lit_1029 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_anon")

var Lit_1030 *jrt.String = jrt.Intern("anon needs a vector of constructor arguments")

var Lit_1031 *jrt.String = jrt.Intern("anon: :outer needs a value")

var Lit_1032 *jrt.String = jrt.Intern("Bad anon supertype: ")

var Lit_1033 *jrt.String = jrt.Intern("anon: :outer needs an instance of the superclass's outer class")

var Lit_1034 *jrt.String = jrt.Intern("An anonymous class of an interface takes no arguments")

var Lit_1035 *jrt.String = jrt.Intern("anon: ")

var Lit_1036 *jrt.String = jrt.Intern(" is not an inner class, :outer is not allowed")

var Lit_1037 *jrt.String = jrt.Intern("/")

var Lit_1038 *jrt.String = jrt.Intern("constructor of ")

var Lit_1039 *jrt.String = jrt.Intern("()V")

var Lit_1040 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_anon$fn__1549001839")

var Lit_1041 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_anon$fn__1549001841")

var Lit_1042 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_arith")

var Lit_1043 *jrt.String = jrt.Intern(" takes ")

var Lit_1044 *jrt.String = jrt.Intern(" operand(s) in class bodies")

var Lit_1045 *jrt.String = jrt.Intern(": operand of type ")

var Lit_1046 *jrt.String = jrt.Intern(" is not integral")

var Lit_1047 *jrt.String = jrt.Intern(": a double operand needs explicit narrowing")

var Lit_1048 *jrt.String = jrt.Intern(" needs explicit narrowing")

var Lit_1049 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_1050 *jrt.String = jrt.Intern(" on doubles is not Java arithmetic; use unchecked-divide/remainder")

var Lit_1051 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_arith$fn__1549000729")

var Lit_1052 *jrt.String = jrt.Intern("Operand of ")

var Lit_1053 *jrt.String = jrt.Intern(" has non-primitive type ")

var Lit_1054 *jrt.String = jrt.Intern(" (only primitives and their wrappers are arithmetic in class bodies)")

var Lit_1055 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_arith$fn__1549000741")

var Lit_1056 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_arith$fn__1549000744")

var Lit_1057 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_arith$fn__1549000746")

var Lit_1058 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_arith$fn__1549000748")

var Lit_1059 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_aset")

var Lit_1060 *jrt.String = jrt.Intern("aset on a non-array of type ")

var Lit_1061 *jrt.String = jrt.Intern("array element")

var Lit_1062 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_aset$fn__1549001224")

var Lit_1063 *jrt.String = jrt.Intern("aset on a non-array")

var Lit_1064 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_body")

var Lit_1065 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_body$fn__1549000658")

var Lit_1066 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_body$fn__1549000660")

var Lit_1067 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_break")

var Lit_1068 *jrt.String = jrt.Intern("break: no label ")

var Lit_1069 *jrt.String = jrt.Intern("break outside a loop")

var Lit_1070 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_cast")

var Lit_1071 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_cast$fn__1549001257")

var Lit_1072 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_class_BANG_")

var Lit_1073 *jrt.String = jrt.Intern("initializer of field ")

var Lit_1074 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_class_BANG_$fn__1549001517")

var Lit_1075 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_class_BANG_$fn__1549001519")

var Lit_1076 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_class_BANG_$fn__1549001527")

var Lit_1077 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_class_BANG_$fn__1549001531")

var Lit_1078 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_clj_special")

var Lit_1079 *jrt.String = jrt.Intern("Unable to resolve var: ")

var Lit_1080 *jrt.String = jrt.Intern(" in this context")

var Lit_1081 *jrt.String = jrt.Intern("Var")

var Lit_1082 *jrt.String = jrt.Intern("First argument to def must be a Symbol")

var Lit_1083 *jrt.String = jrt.Intern("Can't create defs outside of current ns")

var Lit_1084 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_clj_special$fn__1549001403")

var Lit_1085 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_clj_special$fn__1549001405")

var Lit_1086 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_compare")

var Lit_1087 *jrt.String = jrt.Intern(" takes 2 operands in class bodies")

var Lit_1088 *jrt.String = jrt.Intern(" is not a number")

var Lit_1089 *jrt.String = jrt.Intern("<")

var Lit_1090 *jrt.String = jrt.Intern(">")

var Lit_1091 *jrt.String = jrt.Intern("==")

var Lit_1092 *jrt.String = jrt.Intern(">=")

var Lit_1093 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_compare$fn__1549000767")

var Lit_1094 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_compare$lit_int_QMARK___1549000773")

var Lit_1095 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_const_form")

var Lit_1096 *jrt.String = jrt.Intern("Constant of type ")

var Lit_1097 *jrt.String = jrt.Intern(" where ")

var Lit_1098 *jrt.String = jrt.Intern(" is needed")

var Lit_1099 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_const_form$fn__1549001413")

var Lit_1100 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_conversion")

var Lit_1101 *jrt.String = jrt.Intern("Literal out of range: ")

var Lit_1102 *jrt.String = jrt.Intern("Cannot convert ")

var Lit_1103 *jrt.String = jrt.Intern(" to ")

var Lit_1104 *jrt.String = jrt.Intern("Narrowing ")

var Lit_1105 *jrt.String = jrt.Intern(" needs unchecked-")

var Lit_1106 *jrt.String = jrt.Intern("Cannot convert boolean to a number")

var Lit_1107 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_ctor_body")

var Lit_1108 *jrt.String = jrt.Intern("this$0")

var Lit_1109 *jrt.String = jrt.Intern("Constructor call not reached")

var Lit_1110 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_ctor_body$fn__1549001463")

var Lit_1111 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_ctor_body$fn__1549001463$fn__1549001464")

var Lit_1112 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_ctor_body$fn__1549001467")

var Lit_1113 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_ctor_body$fn__1549001469")

var Lit_1114 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_ctor_call")

var Lit_1115 *jrt.String = jrt.Intern("A second constructor call")

var Lit_1116 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_ctor_call_STAR_")

var Lit_1117 *jrt.String = jrt.Intern(" outside a constructor")

var Lit_1118 *jrt.String = jrt.Intern("An enum constructor cannot call super.")

var Lit_1119 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_dot")

var Lit_1120 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_dot_STAR_")

var Lit_1121 *jrt.String = jrt.Intern(".super outside a constructor")

var Lit_1122 *jrt.String = jrt.Intern(" is not an inner class")

var Lit_1123 *jrt.String = jrt.Intern(".new needs an outer instance")

var Lit_1124 *jrt.String = jrt.Intern("$")

var Lit_1125 *jrt.String = jrt.Intern("Unknown class ")

var Lit_1126 *jrt.String = jrt.Intern("-")

var Lit_1127 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_body")

var Lit_1128 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants")

var Lit_1129 *jrt.String = jrt.Intern("$values")

var Lit_1130 *jrt.String = jrt.Intern("()")

var Lit_1131 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$fn__1549001477")

var Lit_1132 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$fn__1549001513")

var Lit_1133 *jrt.String = jrt.Intern("$VALUES")

var Lit_1134 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$iter__1549001479__1549001483")

var Lit_1135 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$iter__1549001479__1549001483$fn__1549001484")

var Lit_1136 *jrt.String = jrt.Intern("constructor of enum constant ")

var Lit_1137 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$iter__1549001479__1549001483$fn__1549001484$fn__1549001485")

var Lit_1138 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$iter__1549001479__1549001483$fn__1549001484$fn__1549001485$fn__1549001492")

var Lit_1139 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$iter__1549001479__1549001483$fn__1549001484$fn__1549001485$fn__1549001494")

var Lit_1140 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$iter__1549001479__1549001483$fn__1549001484$fn__1549001485$fn__1549001496")

var Lit_1141 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$iter__1549001479__1549001483$fn__1549001484$fn__1549001505")

var Lit_1142 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$iter__1549001479__1549001483$fn__1549001484$fn__1549001507")

var Lit_1143 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$iter__1549001479__1549001483$fn__1549001484$fn__1549001509")

var Lit_1144 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_field_access")

var Lit_1145 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_field_access$fn__1549001147")

var Lit_1146 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_field_access$fn__1549001149")

var Lit_1147 *jrt.String = jrt.Intern("reference to field ")

var Lit_1148 *jrt.String = jrt.Intern("getInstanceField")

var Lit_1149 *jrt.String = jrt.Intern("(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;")

var Lit_1150 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_field_access_STAR_")

var Lit_1151 *jrt.String = jrt.Intern("length")

var Lit_1152 *jrt.String = jrt.Intern("Field access .")

var Lit_1153 *jrt.String = jrt.Intern(" on a value of type ")

var Lit_1154 *jrt.String = jrt.Intern("No field ")

var Lit_1155 *jrt.String = jrt.Intern(" in ")

var Lit_1156 *jrt.String = jrt.Intern("Field not accessible: ")

var Lit_1157 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_fn_call")

var Lit_1158 *jrt.String = jrt.Intern("IFn")

var Lit_1159 *jrt.String = jrt.Intern("Cannot call a value of type ")

var Lit_1160 *jrt.String = jrt.Intern(" as a function")

var Lit_1161 *jrt.String = jrt.Intern("Can't call nil")

var Lit_1162 *jrt.String = jrt.Intern("IFn.invoke")

var Lit_1163 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_fn_call$fn__1549001397")

var Lit_1164 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_for_each")

var Lit_1165 *jrt.String = jrt.Intern("for-each needs a binding vector [x coll]")

var Lit_1166 *jrt.String = jrt.Intern("Ljava/lang/Iterable;")

var Lit_1167 *jrt.String = jrt.Intern("for-each over a value of type ")

var Lit_1168 *jrt.String = jrt.Intern(", neither an array nor Iterable")

var Lit_1169 *jrt.String = jrt.Intern("arr$")

var Lit_1170 *jrt.String = jrt.Intern("len$")

var Lit_1171 *jrt.String = jrt.Intern("i$")

var Lit_1172 *jrt.String = jrt.Intern("Ljava/util/Iterator;")

var Lit_1173 *jrt.String = jrt.Intern("java/util/Iterator")

var Lit_1174 *jrt.String = jrt.Intern("()Ljava/lang/Object;")

var Lit_1175 *jrt.String = jrt.Intern("for-each element")

var Lit_1176 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_for_each$aux__1549001907")

var Lit_1177 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_for_each$fn__1549001909")

var Lit_1178 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_if")

var Lit_1179 *jrt.String = jrt.Intern("Too many arguments to if")

var Lit_1180 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_if_instance")

var Lit_1181 *jrt.String = jrt.Intern("if-instance needs [pattern expr]")

var Lit_1182 *jrt.String = jrt.Intern("if-instance of a primitive")

var Lit_1183 *jrt.String = jrt.Intern("inst$")

var Lit_1184 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_instance_QMARK_")

var Lit_1185 *jrt.String = jrt.Intern("instance? needs a class")

var Lit_1186 *jrt.String = jrt.Intern("instance? of a primitive")

var Lit_1187 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_assert")

var Lit_1188 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_assert_STAR_")

var Lit_1189 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_assert_STAR_$fn__1549001895")

var Lit_1190 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_str")

var Lit_1191 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_str$fn__1549001866")

var Lit_1192 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_str$fn__1549001868")

var Lit_1193 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_str$fn__1549001870")

var Lit_1194 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_str$fn__1549001872")

var Lit_1195 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_str$iter__1549001874__1549001878")

var Lit_1196 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_str$iter__1549001874__1549001878$fn__1549001879")

var Lit_1197 *jrt.String = jrt.Intern("")

var Lit_1198 *jrt.String = jrt.Intern("\x01")

var Lit_1199 *jrt.String = jrt.Intern("\x02")

var Lit_1200 *jrt.String = jrt.Intern("java-str of a void expression")

var Lit_1201 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_str$iter__1549001874__1549001878$fn__1549001879$fn__1549001880")

var Lit_1202 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_label")

var Lit_1203 *jrt.String = jrt.Intern("label needs a keyword")

var Lit_1204 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_lambda")

var Lit_1205 *jrt.String = jrt.Intern("lambda needs a parameter vector")

var Lit_1206 *jrt.String = jrt.Intern("lambda for ")

var Lit_1207 *jrt.String = jrt.Intern(" needs ")

var Lit_1208 *jrt.String = jrt.Intern(" parameters")

var Lit_1209 *jrt.String = jrt.Intern("lambda value")

var Lit_1210 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_lambda$fn__1549001968")

var Lit_1211 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_lambda$fn__1549001973")

var Lit_1212 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_let")

var Lit_1213 *jrt.String = jrt.Intern("let/loop needs a vector of bindings")

var Lit_1214 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_let$fn__1549000825")

var Lit_1215 *jrt.String = jrt.Intern("Bad binding: ")

var Lit_1216 *jrt.String = jrt.Intern("^:const local needs a constant initializer: ")

var Lit_1217 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_letclass")

var Lit_1218 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_letclass$fn__1549001848")

var Lit_1219 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_locking")

var Lit_1220 *jrt.String = jrt.Intern("locking needs a reference")

var Lit_1221 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_body")

var Lit_1222 *jrt.String = jrt.Intern("value of method ")

var Lit_1223 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_call")

var Lit_1224 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_call$fn__1549001104")

var Lit_1225 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_call$fn__1549001106")

var Lit_1226 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_call$fn__1549001108")

var Lit_1227 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_call_STAR_")

var Lit_1228 *jrt.String = jrt.Intern("Method call .")

var Lit_1229 *jrt.String = jrt.Intern(" on nil")

var Lit_1230 *jrt.String = jrt.Intern("java/lang/Object")

var Lit_1231 *jrt.String = jrt.Intern("clone")

var Lit_1232 *jrt.String = jrt.Intern("No accessible method ")

var Lit_1233 *jrt.String = jrt.Intern("method ")

var Lit_1234 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_call_STAR_$fn__1549001119")

var Lit_1235 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_call_STAR_$fn__1549001121")

var Lit_1236 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_call_STAR_$fn__1549001123")

var Lit_1237 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_call_STAR_$fn__1549001125")

var Lit_1238 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref")

var Lit_1239 *jrt.String = jrt.Intern("method-ref takes FI, an optional signature, an optional receiver and a method")

var Lit_1240 *jrt.String = jrt.Intern("Bad method in method-ref: ")

var Lit_1241 *jrt.String = jrt.Intern("rec$")

var Lit_1242 *jrt.String = jrt.Intern("An unbound method reference needs the receiver as first parameter")

var Lit_1243 *jrt.String = jrt.Intern("static method ")

var Lit_1244 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002010")

var Lit_1245 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002016")

var Lit_1246 *jrt.String = jrt.Intern("a$")

var Lit_1247 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002021")

var Lit_1248 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002023")

var Lit_1249 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002028")

var Lit_1250 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002030")

var Lit_1251 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002035")

var Lit_1252 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002038")

var Lit_1253 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002046")

var Lit_1254 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002048")

var Lit_1255 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$register__1549002014")

var Lit_1256 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_new")

var Lit_1257 *jrt.String = jrt.Intern("Unable to resolve class: ")

var Lit_1258 *jrt.String = jrt.Intern("Cannot instantiate abstract class ")

var Lit_1259 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_new$anns__1549001200")

var Lit_1260 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_new$fn__1549001206")

var Lit_1261 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_new$fn__1549001208")

var Lit_1262 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_new$fn__1549001210")

var Lit_1263 *jrt.String = jrt.Intern("call to ")

var Lit_1264 *jrt.String = jrt.Intern(" ctor")

var Lit_1265 *jrt.String = jrt.Intern("invokeConstructor")

var Lit_1266 *jrt.String = jrt.Intern("(Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;")

var Lit_1267 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_op")

var Lit_1268 *jrt.String = jrt.Intern(" is not supported in code compiled by the class forms compiler")

var Lit_1269 *jrt.String = jrt.Intern(" (class bodies, and fns using the class forms; use locking)")

var Lit_1270 *jrt.String = jrt.Intern("class* ")

var Lit_1271 *jrt.String = jrt.Intern(" is not an expression")

var Lit_1272 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_op$fn__1549001385")

var Lit_1273 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_pattern")

var Lit_1274 *jrt.String = jrt.Intern("A type pattern needs a type: ")

var Lit_1275 *jrt.String = jrt.Intern("Primitive pattern of type ")

var Lit_1276 *jrt.String = jrt.Intern(" for a value of type ")

var Lit_1277 *jrt.String = jrt.Intern(" is not supported")

var Lit_1278 *jrt.String = jrt.Intern("Unknown record ")

var Lit_1279 *jrt.String = jrt.Intern(" is not a record")

var Lit_1280 *jrt.String = jrt.Intern("Record pattern ")

var Lit_1281 *jrt.String = jrt.Intern(" component patterns")

var Lit_1282 *jrt.String = jrt.Intern("Bad pattern: ")

var Lit_1283 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_pattern$fn__1549002058")

var Lit_1284 *jrt.String = jrt.Intern("getRecordComponents")

var Lit_1285 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_pattern$fn__1549002058$iter__1549002059__1549002063")

var Lit_1286 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_pattern$fn__1549002058$iter__1549002059__1549002063$fn__1549002064")

var Lit_1287 *jrt.String = jrt.Intern("java.lang.reflect.RecordComponent")

var Lit_1288 *jrt.String = jrt.Intern("getName")

var Lit_1289 *jrt.String = jrt.Intern("getType")

var Lit_1290 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_pattern$fn__1549002058$iter__1549002059__1549002063$fn__1549002064$fn__1549002065")

var Lit_1291 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_pattern$fn__1549002072")

var Lit_1292 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_recur")

var Lit_1293 *jrt.String = jrt.Intern("continue: no label ")

var Lit_1294 *jrt.String = jrt.Intern("continue: label ")

var Lit_1295 *jrt.String = jrt.Intern(" is not a loop")

var Lit_1296 *jrt.String = jrt.Intern("recur/continue outside a loop")

var Lit_1297 *jrt.String = jrt.Intern("Mismatched argument count to recur/continue, expected: ")

var Lit_1298 *jrt.String = jrt.Intern(" args, got: ")

var Lit_1299 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_recur$fn__1549000844")

var Lit_1300 *jrt.String = jrt.Intern("recur argument")

var Lit_1301 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_return")

var Lit_1302 *jrt.String = jrt.Intern("return outside a method")

var Lit_1303 *jrt.String = jrt.Intern("return value")

var Lit_1304 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_set_BANG_")

var Lit_1305 *jrt.String = jrt.Intern("Cannot assign captured local ")

var Lit_1306 *jrt.String = jrt.Intern("Cannot assign immutable local ")

var Lit_1307 *jrt.String = jrt.Intern(" (use ^:mutable)")

var Lit_1308 *jrt.String = jrt.Intern("value for ")

var Lit_1309 *jrt.String = jrt.Intern("Unknown class in set!: ")

var Lit_1310 *jrt.String = jrt.Intern("No static field ")

var Lit_1311 *jrt.String = jrt.Intern(".-")

var Lit_1312 *jrt.String = jrt.Intern("Bad set! target: ")

var Lit_1313 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_set_BANG_$fn__1549000926")

var Lit_1314 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_set_BANG_$fn__1549000931")

var Lit_1315 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_static_call")

var Lit_1316 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_static_call$fn__1549001135")

var Lit_1317 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_static_call$fn__1549001137")

var Lit_1318 *jrt.String = jrt.Intern("No accessible static method ")

var Lit_1319 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_static_call$fn__1549001137$fn__1549001141")

var Lit_1320 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_static_call$fn__1549001144")

var Lit_1321 *jrt.String = jrt.Intern("call to static method ")

var Lit_1322 *jrt.String = jrt.Intern(" on ")

var Lit_1323 *jrt.String = jrt.Intern("invokeStaticMethod")

var Lit_1324 *jrt.String = jrt.Intern("(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;")

var Lit_1325 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch")

var Lit_1326 *jrt.String = jrt.Intern("RT")

var Lit_1327 *jrt.String = jrt.Intern("intCast")

var Lit_1328 *jrt.String = jrt.Intern("(J)I")

var Lit_1329 *jrt.String = jrt.Intern("(Ljava/lang/Object;)I")

var Lit_1330 *jrt.String = jrt.Intern("switch on a value of type ")

var Lit_1331 *jrt.String = jrt.Intern("sel$")

var Lit_1332 *jrt.String = jrt.Intern("restart$")

var Lit_1333 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$enum_name__1549002122")

var Lit_1334 *jrt.String = jrt.Intern("Enum switch label must be a constant name: ")

var Lit_1335 *jrt.String = jrt.Intern("No enum constant ")

var Lit_1336 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$fn__1549002112")

var Lit_1337 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$fn__1549002117")

var Lit_1338 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$fn__1549002192")

var Lit_1339 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$fn__1549002194")

var Lit_1340 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$fn__1549002196")

var Lit_1341 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$iter__1549002124__1549002128")

var Lit_1342 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$iter__1549002124__1549002128$fn__1549002129")

var Lit_1343 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$iter__1549002124__1549002128$fn__1549002129$fn__1549002130")

var Lit_1344 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$iter__1549002124__1549002128$fn__1549002129$fn__1549002130$iter__1549002142__1549002146")

var Lit_1345 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$iter__1549002124__1549002128$fn__1549002129$fn__1549002130$iter__1549002142__1549002146$fn__1549002147")

var Lit_1346 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$iter__1549002124__1549002128$fn__1549002129$fn__1549002130$iter__1549002142__1549002146$fn__1549002147$fn__1549002148")

var Lit_1347 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$iter__1549002124__1549002128$fn__1549002129$iter__1549002166__1549002170")

var Lit_1348 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$iter__1549002124__1549002128$fn__1549002129$iter__1549002166__1549002170$fn__1549002171")

var Lit_1349 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$iter__1549002124__1549002128$fn__1549002129$iter__1549002166__1549002170$fn__1549002171$fn__1549002172")

var Lit_1350 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$null_label_QMARK___1549002114")

var Lit_1351 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_symbol")

var Lit_1352 *jrt.String = jrt.Intern("A primitive type is no value: ")

var Lit_1353 *jrt.String = jrt.Intern(" (use Integer/TYPE)")

var Lit_1354 *jrt.String = jrt.Intern("Unable to resolve symbol: ")

var Lit_1355 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_throw")

var Lit_1356 *jrt.String = jrt.Intern("Ljava/lang/Throwable;")

var Lit_1357 *jrt.String = jrt.Intern("throw of a non-Throwable: ")

var Lit_1358 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try")

var Lit_1359 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$catch_QMARK___1549000881")

var Lit_1360 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$fin_QMARK___1549000883")

var Lit_1361 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$fn__1549000885")

var Lit_1362 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$fn__1549000911")

var Lit_1363 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$iter__1549000887__1549000891")

var Lit_1364 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$iter__1549000887__1549000891$fn__1549000892")

var Lit_1365 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$iter__1549000887__1549000891$fn__1549000892$fn__1549000893")

var Lit_1366 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$iter__1549000887__1549000891$fn__1549000892$fn__1549000893$fn__1549000897")

var Lit_1367 *jrt.String = jrt.Intern("Unknown class: ")

var Lit_1368 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$iter__1549000887__1549000891$fn__1549000892$fn__1549000893$fn__1549000899")

var Lit_1369 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$iter__1549000887__1549000891$fn__1549000892$fn__1549000905")

var Lit_1370 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$iter__1549000887__1549000891$fn__1549000892$fn__1549000907")

var Lit_1371 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_with_resources")

var Lit_1372 *jrt.String = jrt.Intern("with-resources needs a vector of resource bindings")

var Lit_1373 *jrt.String = jrt.Intern("t$")

var Lit_1374 *jrt.String = jrt.Intern("x$")

var Lit_1375 *jrt.String = jrt.Intern("arbace.classes.analyze$ann_value")

var Lit_1376 *jrt.String = jrt.Intern("Unknown annotation: ")

var Lit_1377 *jrt.String = jrt.Intern("Ljava/lang/Class;")

var Lit_1378 *jrt.String = jrt.Intern("arbace.classes.analyze$ann_value$fn__1549000077")

var Lit_1379 *jrt.String = jrt.Intern("arbace.classes.analyze$ann_value$iter__1549000079__1549000083")

var Lit_1380 *jrt.String = jrt.Intern("arbace.classes.analyze$ann_value$iter__1549000079__1549000083$fn__1549000084")

var Lit_1381 *jrt.String = jrt.Intern("arbace.classes.analyze$ann_value$iter__1549000079__1549000083$fn__1549000084$fn__1549000085")

var Lit_1382 *jrt.String = jrt.Intern("arbace.classes.analyze$annotation_targets")

var Lit_1383 *jrt.String = jrt.Intern("arbace.classes.analyze$annotation_targets$fn__1549000100")

var Lit_1384 *jrt.String = jrt.Intern("java/lang/annotation/Target")

var Lit_1385 *jrt.String = jrt.Intern("arbace.classes.analyze$annotation_targets$fn__1549000105")

var Lit_1386 *jrt.String = jrt.Intern("getAnnotation")

var Lit_1387 *jrt.String = jrt.Intern("java.lang.annotation.Target")

var Lit_1388 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations")

var Lit_1389 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations$fn__1549000096")

var Lit_1390 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations_now")

var Lit_1391 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations_now$iter__1549000172__1549000176")

var Lit_1392 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations_now$iter__1549000172__1549000176$fn__1549000177")

var Lit_1393 *jrt.String = jrt.Intern("Unknown annotation type: ")

var Lit_1394 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations_now$iter__1549000172__1549000176$fn__1549000177$fn__1549000178")

var Lit_1395 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations_now$iter__1549000172__1549000176$fn__1549000177$fn__1549000178$iter__1549000182__1549000186")

var Lit_1396 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations_now$iter__1549000172__1549000176$fn__1549000177$fn__1549000178$iter__1549000182__1549000186$fn__1549000187")

var Lit_1397 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations_now$iter__1549000172__1549000176$fn__1549000177$fn__1549000178$iter__1549000182__1549000186$fn__1549000187$fn__1549000188")

var Lit_1398 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations_now$iter__1549000172__1549000176$fn__1549000177$iter__1549000202__1549000206")

var Lit_1399 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations_now$iter__1549000172__1549000176$fn__1549000177$iter__1549000202__1549000206$fn__1549000207")

var Lit_1400 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations_now$iter__1549000172__1549000176$fn__1549000177$iter__1549000202__1549000206$fn__1549000207$fn__1549000208")

var Lit_1401 *jrt.String = jrt.Intern("arbace.classes.analyze$applicable_QMARK_")

var Lit_1402 *jrt.String = jrt.Intern("arbace.classes.analyze$applicable_QMARK_$fn__1549000934")

var Lit_1403 *jrt.String = jrt.Intern("arbace.classes.analyze$arg_stub")

var Lit_1404 *jrt.String = jrt.Intern("arbace.classes.analyze$array_new")

var Lit_1405 *jrt.String = jrt.Intern("Bad dimensions for new ")

var Lit_1406 *jrt.String = jrt.Intern("arbace.classes.analyze$array_new$fn__1549001190")

var Lit_1407 *jrt.String = jrt.Intern("arbace.classes.analyze$array_new$init__1549001186")

var Lit_1408 *jrt.String = jrt.Intern("arbace.classes.analyze$array_new$init__1549001186$fn__1549001187")

var Lit_1409 *jrt.String = jrt.Intern("arbace.classes.analyze$bind_init")

var Lit_1410 *jrt.String = jrt.Intern("initializer of ")

var Lit_1411 *jrt.String = jrt.Intern("arbace.classes.analyze$bind_init$fn__1549000813")

var Lit_1412 *jrt.String = jrt.Intern("arbace.classes.analyze$bind_params")

var Lit_1413 *jrt.String = jrt.Intern("arbace.classes.analyze$bind_params$fn__1549001434")

var Lit_1414 *jrt.String = jrt.Intern("arbace.classes.analyze$binding_type")

var Lit_1415 *jrt.String = jrt.Intern("arbace.classes.analyze$body_actx")

var Lit_1416 *jrt.String = jrt.Intern("arbace.classes.analyze$body_actx$fn__1549001422")

var Lit_1417 *jrt.String = jrt.Intern("arbace.classes.analyze$body_actx$fn__1549001424")

var Lit_1418 *jrt.String = jrt.Intern("arbace.classes.analyze$body_actx$fn__1549001427")

var Lit_1419 *jrt.String = jrt.Intern("arbace.classes.analyze$body_actx$fn__1549001429")

var Lit_1420 *jrt.String = jrt.Intern("arbace.classes.analyze$bool_node")

var Lit_1421 *jrt.String = jrt.Intern("arbace.classes.analyze$bounds_of_scope")

var Lit_1422 *jrt.String = jrt.Intern("arbace.classes.analyze$boxed_desc")

var Lit_1423 *jrt.String = jrt.Intern("arbace.classes.analyze$branching_tail_QMARK_")

var Lit_1424 *jrt.String = jrt.Intern("arbace.classes.analyze$class_access")

var Lit_1425 *jrt.String = jrt.Intern("arbace.classes.analyze$class_def_in_QMARK_")

var Lit_1426 *jrt.String = jrt.Intern("arbace.classes.analyze$class_def_in_QMARK_$fn__1549000836")

var Lit_1427 *jrt.String = jrt.Intern("arbace.classes.analyze$class_exists_QMARK_")

var Lit_1428 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics")

var Lit_1429 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001561")

var Lit_1430 *jrt.String = jrt.Intern("getTypeParameters")

var Lit_1431 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001561$fn__1549001562")

var Lit_1432 *jrt.String = jrt.Intern("java.lang.reflect.TypeVariable")

var Lit_1433 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001561$iter__1549001565__1549001569")

var Lit_1434 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001561$iter__1549001565__1549001569$fn__1549001570")

var Lit_1435 *jrt.String = jrt.Intern("getGenericParameterTypes")

var Lit_1436 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001561$iter__1549001565__1549001569$fn__1549001570$fn__1549001571")

var Lit_1437 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001561$iter__1549001565__1549001569$fn__1549001570$fn__1549001571$fn__1549001572")

var Lit_1438 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001561$iter__1549001565__1549001569$fn__1549001570$fn__1549001571$iter__1549001574__1549001578")

var Lit_1439 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001561$iter__1549001565__1549001569$fn__1549001570$fn__1549001571$iter__1549001574__1549001578$fn__1549001579")

var Lit_1440 *jrt.String = jrt.Intern("getBounds")

var Lit_1441 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001561$iter__1549001565__1549001569$fn__1549001570$fn__1549001571$iter__1549001574__1549001578$fn__1549001579$fn__1549001580")

var Lit_1442 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001561$iter__1549001565__1549001569$fn__1549001570$fn__1549001585")

var Lit_1443 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001561$iter__1549001565__1549001569$fn__1549001570$iter__1549001587__1549001591")

var Lit_1444 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001561$iter__1549001565__1549001569$fn__1549001570$iter__1549001587__1549001591$fn__1549001592")

var Lit_1445 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001561$iter__1549001565__1549001569$fn__1549001570$iter__1549001587__1549001591$fn__1549001592$fn__1549001593")

var Lit_1446 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$iter__1549001547__1549001551")

var Lit_1447 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$iter__1549001547__1549001551$fn__1549001552")

var Lit_1448 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$iter__1549001547__1549001551$fn__1549001552$fn__1549001553")

var Lit_1449 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$iter__1549001547__1549001551$fn__1549001552$fn__1549001553$fn__1549001554")

var Lit_1450 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$iter__1549001547__1549001551$fn__1549001552$fn__1549001557")

var Lit_1451 *jrt.String = jrt.Intern("arbace.classes.analyze$class_lit")

var Lit_1452 *jrt.String = jrt.Intern("arbace.classes.analyze$class_name_of")

var Lit_1453 *jrt.String = jrt.Intern("arbace.classes.analyze$class_parent_frame")

var Lit_1454 *jrt.String = jrt.Intern("arbace.classes.analyze$class_scope")

var Lit_1455 *jrt.String = jrt.Intern("arbace.classes.analyze$class_tparams")

var Lit_1456 *jrt.String = jrt.Intern("arbace.classes.analyze$class_tparams$fn__1549000049")

var Lit_1457 *jrt.String = jrt.Intern("arbace.classes.analyze$class_tparams$fn__1549000051")

var Lit_1458 *jrt.String = jrt.Intern("arbace.classes.analyze$class_tparams$fn__1549000051$fn__1549000052")

var Lit_1459 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_arg_class")

var Lit_1460 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_arg_convert")

var Lit_1461 *jrt.String = jrt.Intern("argument")

var Lit_1462 *jrt.String = jrt.Intern("(")

var Lit_1463 *jrt.String = jrt.Intern(")")

var Lit_1464 *jrt.String = jrt.Intern("FnInvokers")

var Lit_1465 *jrt.String = jrt.Intern("No method ")

var Lit_1466 *jrt.String = jrt.Intern(" in FnInvokers")

var Lit_1467 *jrt.String = jrt.Intern("(Ljava/lang/Object;)")

var Lit_1468 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_arg_convert$code__1549001061")

var Lit_1469 *jrt.String = jrt.Intern("O")

var Lit_1470 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_arg_convert$fn__1549001063")

var Lit_1471 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_arg_convert$ip__1549001059")

var Lit_1472 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_call_node")

var Lit_1473 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_call_node$fn__1549001293")

var Lit_1474 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_collection")

var Lit_1475 *jrt.String = jrt.Intern("([Ljava/lang/Object;)")

var Lit_1476 *jrt.String = jrt.Intern("[Ljava/lang/Object;")

var Lit_1477 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_collection$fn__1549002339")

var Lit_1478 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_collection$fn__1549002341")

var Lit_1479 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_constant")

var Lit_1480 *jrt.String = jrt.Intern("Keyword")

var Lit_1481 *jrt.String = jrt.Intern("Symbol")

var Lit_1482 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_constant$fn__1549002333")

var Lit_1483 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_convert")

var Lit_1484 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_convert$fn__1549001270")

var Lit_1485 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_fi_method")

var Lit_1486 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_fi_method$fn__1549000949")

var Lit_1487 *jrt.String = jrt.Intern("java.lang.FunctionalInterface")

var Lit_1488 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_fi_method$fn__1549000949$fn__1549000950")

var Lit_1489 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_fi_method$fn__1549000953")

var Lit_1490 *jrt.String = jrt.Intern("Ljava/lang/FunctionalInterface;")

var Lit_1491 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_fi_method$fn__1549000955")

var Lit_1492 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_matching_index")

var Lit_1493 *jrt.String = jrt.Intern("More than one matching method found: ")

var Lit_1494 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_matching_index$fn__1549000987")

var Lit_1495 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_param_arg_match_QMARK_")

var Lit_1496 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_ret_assignable_QMARK_")

var Lit_1497 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_select")

var Lit_1498 *jrt.String = jrt.Intern("interface ")

var Lit_1499 *jrt.String = jrt.Intern("class ")

var Lit_1500 *jrt.String = jrt.Intern("No matching ctor found for ")

var Lit_1501 *jrt.String = jrt.Intern("No matching method ")

var Lit_1502 *jrt.String = jrt.Intern(" found taking ")

var Lit_1503 *jrt.String = jrt.Intern(" args for ")

var Lit_1504 *jrt.String = jrt.Intern(" of ")

var Lit_1505 *jrt.String = jrt.Intern(" args")

var Lit_1506 *jrt.String = jrt.Intern("No matching ")

var Lit_1507 *jrt.String = jrt.Intern(" for argument types ")

var Lit_1508 *jrt.String = jrt.Intern("constructor")

var Lit_1509 *jrt.String = jrt.Intern("argument types: ")

var Lit_1510 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_select$fn__1549000999")

var Lit_1511 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_select$fn__1549001003")

var Lit_1512 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_select$pdescs__1549000997")

var Lit_1513 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_subsumes_QMARK_")

var Lit_1514 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_type_string")

var Lit_1515 *jrt.String = jrt.Intern(", ")

var Lit_1516 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_type_string$fn__1549000991")

var Lit_1517 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_var_field")

var Lit_1518 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges")

var Lit_1519 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000309__1549000315")

var Lit_1520 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000309__1549000315$fn__1549000316")

var Lit_1521 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000309__1549000315$fn__1549000316$iter__1549000311__1549000320")

var Lit_1522 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000309__1549000315$fn__1549000316$iter__1549000311__1549000320$fn__1549000321")

var Lit_1523 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000309__1549000315$fn__1549000316$iter__1549000311__1549000320$fn__1549000321$fn__1549000322")

var Lit_1524 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000309__1549000315$fn__1549000316$iter__1549000311__1549000320$fn__1549000321$fn__1549000322$fn__1549000323")

var Lit_1525 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000309__1549000315$fn__1549000316$iter__1549000311__1549000320$fn__1549000321$fn__1549000326")

var Lit_1526 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000309__1549000315$fn__1549000316$iter__1549000330__1549000334")

var Lit_1527 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000309__1549000315$fn__1549000316$iter__1549000330__1549000334$fn__1549000335")

var Lit_1528 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000309__1549000315$fn__1549000316$iter__1549000330__1549000334$fn__1549000335$fn__1549000336")

var Lit_1529 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_implementables")

var Lit_1530 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_implementables$iter__1549000286__1549000292")

var Lit_1531 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_implementables$iter__1549000286__1549000292$fn__1549000293")

var Lit_1532 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_implementables$iter__1549000286__1549000292$fn__1549000293$iter__1549000288__1549000294")

var Lit_1533 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_implementables$iter__1549000286__1549000292$fn__1549000293$iter__1549000288__1549000294$fn__1549000295")

var Lit_1534 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_implementables$iter__1549000286__1549000292$fn__1549000293$iter__1549000288__1549000294$fn__1549000295$fn__1549000296")

var Lit_1535 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_override")

var Lit_1536 *jrt.String = jrt.Intern("Can't define method not in interfaces: ")

var Lit_1537 *jrt.String = jrt.Intern("Must hint overloaded method: ")

var Lit_1538 *jrt.String = jrt.Intern("Can't find matching overloaded method: ")

var Lit_1539 *jrt.String = jrt.Intern("Can't find matching method: ")

var Lit_1540 *jrt.String = jrt.Intern(", leave off hints for auto match.")

var Lit_1541 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_override$check_ret__1549000361")

var Lit_1542 *jrt.String = jrt.Intern("Mismatched return type: ")

var Lit_1543 *jrt.String = jrt.Intern(", expected: ")

var Lit_1544 *jrt.String = jrt.Intern(", had: ")

var Lit_1545 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_override$exact__1549000357")

var Lit_1546 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_override$exact__1549000357$fn__1549000358")

var Lit_1547 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_override$fn__1549000353")

var Lit_1548 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_override$fn__1549000355")

var Lit_1549 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_overrideables")

var Lit_1550 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_overrideables$fn__1549000303")

var Lit_1551 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_tag_desc")

var Lit_1552 *jrt.String = jrt.Intern("[")

var Lit_1553 *jrt.String = jrt.Intern("arbace.classes.analyze$clone_tail_QMARK_")

var Lit_1554 *jrt.String = jrt.Intern("arbace.classes.analyze$code_type_anns")

var Lit_1555 *jrt.String = jrt.Intern("arbace.classes.analyze$code_type_anns$iter__1549001227__1549001233")

var Lit_1556 *jrt.String = jrt.Intern("arbace.classes.analyze$code_type_anns$iter__1549001227__1549001233$fn__1549001234")

var Lit_1557 *jrt.String = jrt.Intern("arbace.classes.analyze$code_type_anns$iter__1549001227__1549001233$fn__1549001234$iter__1549001229__1549001238")

var Lit_1558 *jrt.String = jrt.Intern("arbace.classes.analyze$code_type_anns$iter__1549001227__1549001233$fn__1549001234$iter__1549001229__1549001238$fn__1549001239")

var Lit_1559 *jrt.String = jrt.Intern("arbace.classes.analyze$code_type_anns$iter__1549001227__1549001233$fn__1549001234$iter__1549001229__1549001238$fn__1549001239$fn__1549001240")

var Lit_1560 *jrt.String = jrt.Intern("arbace.classes.analyze$coerce_hint")

var Lit_1561 *jrt.String = jrt.Intern("arbace.classes.analyze$coerce_hint$fn__1549000653")

var Lit_1562 *jrt.String = jrt.Intern("arbace.classes.analyze$compare_type")

var Lit_1563 *jrt.String = jrt.Intern("arbace.classes.analyze$const_node")

var Lit_1564 *jrt.String = jrt.Intern("arbace.classes.analyze$const_of_type")

var Lit_1565 *jrt.String = jrt.Intern("arbace.classes.analyze$const_string")

var Lit_1566 *jrt.String = jrt.Intern("arbace.classes.analyze$constant_field_BANG_")

var Lit_1567 *jrt.String = jrt.Intern("const__")

var Lit_1568 *jrt.String = jrt.Intern("arbace.classes.analyze$constant_label")

var Lit_1569 *jrt.String = jrt.Intern("switch label is not a constant: ")

var Lit_1570 *jrt.String = jrt.Intern("arbace.classes.analyze$conversion")

var Lit_1571 *jrt.String = jrt.Intern("arbace.classes.analyze$conversion$fn__1549000582")

var Lit_1572 *jrt.String = jrt.Intern("arbace.classes.analyze$convert_args")

var Lit_1573 *jrt.String = jrt.Intern("arbace.classes.analyze$convert_args$fn__1549001074")

var Lit_1574 *jrt.String = jrt.Intern("arbace.classes.analyze$convert_args$fn__1549001076")

var Lit_1575 *jrt.String = jrt.Intern("arbace.classes.analyze$convert_args$fn__1549001078")

var Lit_1576 *jrt.String = jrt.Intern("arbace.classes.analyze$convert_node")

var Lit_1577 *jrt.String = jrt.Intern(" of type ")

var Lit_1578 *jrt.String = jrt.Intern("switch without default has no value of type ")

var Lit_1579 *jrt.String = jrt.Intern("arbace.classes.analyze$convert_node$fn__1549000692")

var Lit_1580 *jrt.String = jrt.Intern("arbace.classes.analyze$convert_node$fn__1549000698")

var Lit_1581 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op")

var Lit_1582 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node")

var Lit_1583 *jrt.String = jrt.Intern("locking")

var Lit_1584 *jrt.String = jrt.Intern("boolean")

var Lit_1585 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$call__1549001313")

var Lit_1586 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001315")

var Lit_1587 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001317")

var Lit_1588 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001319")

var Lit_1589 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001321")

var Lit_1590 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001323")

var Lit_1591 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001325")

var Lit_1592 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001327")

var Lit_1593 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001329")

var Lit_1594 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001334")

var Lit_1595 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001336")

var Lit_1596 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001338")

var Lit_1597 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001340")

var Lit_1598 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001342")

var Lit_1599 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001344")

var Lit_1600 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001349")

var Lit_1601 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001354")

var Lit_1602 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001357")

var Lit_1603 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001359")

var Lit_1604 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001361")

var Lit_1605 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001363")

var Lit_1606 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001365")

var Lit_1607 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001367")

var Lit_1608 *jrt.String = jrt.Intern("arbace.classes.analyze$core_var_QMARK_")

var Lit_1609 *jrt.String = jrt.Intern("arbace.classes.analyze$creation_actx")

var Lit_1610 *jrt.String = jrt.Intern("arbace.classes.analyze$ctor_call_form_QMARK_")

var Lit_1611 *jrt.String = jrt.Intern("arbace.classes.analyze$ctor_call_node")

var Lit_1612 *jrt.String = jrt.Intern("No accessible constructor of ")

var Lit_1613 *jrt.String = jrt.Intern("arbace.classes.analyze$ctor_call_node$fn__1549001180")

var Lit_1614 *jrt.String = jrt.Intern("arbace.classes.analyze$ctor_candidates")

var Lit_1615 *jrt.String = jrt.Intern("arbace.classes.analyze$ctor_candidates$fn__1549001055")

var Lit_1616 *jrt.String = jrt.Intern("arbace.classes.analyze$ctor_real_desc")

var Lit_1617 *jrt.String = jrt.Intern("arbace.classes.analyze$decl")

var Lit_1618 *jrt.String = jrt.Intern("arbace.classes.analyze$decl_BANG_")

var Lit_1619 *jrt.String = jrt.Intern("Not in the compilation: ")

var Lit_1620 *jrt.String = jrt.Intern("arbace.classes.analyze$decl_annotations")

var Lit_1621 *jrt.String = jrt.Intern("arbace.classes.analyze$decl_annotations$fn__1549000115")

var Lit_1622 *jrt.String = jrt.Intern("arbace.classes.analyze$decl_annotations$fn__1549000115$fn__1549000116")

var Lit_1623 *jrt.String = jrt.Intern("ANNOTATION_TYPE")

var Lit_1624 *jrt.String = jrt.Intern("TYPE")

var Lit_1625 *jrt.String = jrt.Intern("arbace.classes.analyze$declare_class_BANG_")

var Lit_1626 *jrt.String = jrt.Intern("Class defined twice in one form: ")

var Lit_1627 *jrt.String = jrt.Intern("arbace.classes.analyze$declare_class_BANG_$iter__1549000226__1549000230")

var Lit_1628 *jrt.String = jrt.Intern("arbace.classes.analyze$declare_class_BANG_$iter__1549000226__1549000230$fn__1549000231")

var Lit_1629 *jrt.String = jrt.Intern("arbace.classes.analyze$declare_class_BANG_$iter__1549000226__1549000230$fn__1549000231$fn__1549000232")

var Lit_1630 *jrt.String = jrt.Intern("arbace.classes.analyze$default_import_QMARK_")

var Lit_1631 *jrt.String = jrt.Intern("arbace.classes.analyze$deprecated_flag")

var Lit_1632 *jrt.String = jrt.Intern("arbace.classes.analyze$deprecated_flag$fn__1549000257")

var Lit_1633 *jrt.String = jrt.Intern("arbace.classes.analyze$derived_method")

var Lit_1634 *jrt.String = jrt.Intern("arbace.classes.analyze$derived_method$fn__1549000447")

var Lit_1635 *jrt.String = jrt.Intern("arbace.classes.analyze$element_type")

var Lit_1636 *jrt.String = jrt.Intern("arbace.classes.analyze$element_type$fn__1549000073")

var Lit_1637 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_ctor")

var Lit_1638 *jrt.String = jrt.Intern("A constructor needs a receiver parameter")

var Lit_1639 *jrt.String = jrt.Intern("CONSTRUCTOR")

var Lit_1640 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_ctor$fn__1549000430")

var Lit_1641 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_ctor$fn__1549000432")

var Lit_1642 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_ctor$fn__1549000435")

var Lit_1643 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_ctor$fn__1549000437")

var Lit_1644 *jrt.String = jrt.Intern("PARAMETER")

var Lit_1645 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_field")

var Lit_1646 *jrt.String = jrt.Intern("getValue")

var Lit_1647 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_field$fn__1549000441")

var Lit_1648 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_")

var Lit_1649 *jrt.String = jrt.Intern("getResource")

var Lit_1650 *jrt.String = jrt.Intern("_class.ae")

var Lit_1651 *jrt.String = jrt.Intern(".ae")

var Lit_1652 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$fn__1549002233")

var Lit_1653 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$fn__1549002252")

var Lit_1654 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$fn__1549002258")

var Lit_1655 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$iter__1549002235__1549002241")

var Lit_1656 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$iter__1549002235__1549002241$fn__1549002242")

var Lit_1657 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$iter__1549002235__1549002241$fn__1549002242$iter__1549002237__1549002243")

var Lit_1658 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$iter__1549002235__1549002241$fn__1549002242$iter__1549002237__1549002243$fn__1549002244")

var Lit_1659 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$iter__1549002235__1549002241$fn__1549002242$iter__1549002237__1549002243$fn__1549002244$fn__1549002245")

var Lit_1660 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$iter__1549002264__1549002270")

var Lit_1661 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$iter__1549002264__1549002270$fn__1549002271")

var Lit_1662 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$iter__1549002264__1549002270$fn__1549002271$iter__1549002266__1549002272")

var Lit_1663 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$iter__1549002264__1549002270$fn__1549002271$iter__1549002266__1549002272$fn__1549002273")

var Lit_1664 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$iter__1549002264__1549002270$fn__1549002271$iter__1549002266__1549002272$fn__1549002273$fn__1549002274")

var Lit_1665 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$iter__1549002280__1549002284")

var Lit_1666 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$iter__1549002280__1549002284$fn__1549002285")

var Lit_1667 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$iter__1549002280__1549002284$fn__1549002285$fn__1549002286")

var Lit_1668 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_method")

var Lit_1669 *jrt.String = jrt.Intern("Instance method ")

var Lit_1670 *jrt.String = jrt.Intern(" needs a receiver parameter")

var Lit_1671 *jrt.String = jrt.Intern("Variable arity parameter must be an array: ")

var Lit_1672 *jrt.String = jrt.Intern("METHOD")

var Lit_1673 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_method$fn__1549000399")

var Lit_1674 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_method$fn__1549000404")

var Lit_1675 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_method$fn__1549000406")

var Lit_1676 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_method$fn__1549000408")

var Lit_1677 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_method$fn__1549000410")

var Lit_1678 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_method$fn__1549000414")

var Lit_1679 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_method$fn__1549000416")

var Lit_1680 *jrt.String = jrt.Intern("arbace.classes.analyze$enum_class_QMARK_")

var Lit_1681 *jrt.String = jrt.Intern("arbace.classes.analyze$erase")

var Lit_1682 *jrt.String = jrt.Intern("arbace.classes.analyze$erased_params")

var Lit_1683 *jrt.String = jrt.Intern("arbace.classes.analyze$erased_params$fn__1549001631")

var Lit_1684 *jrt.String = jrt.Intern("arbace.classes.analyze$eval1549000004$loading__1927001464__auto____1549000005")

var Lit_1685 *jrt.String = jrt.Intern("arbace.classes.analyze$eval1549000008$fn__1549000009")

var Lit_1686 *jrt.String = jrt.Intern("arbace.classes.analyze$eval_ns_form_BANG_")

var Lit_1687 *jrt.String = jrt.Intern("arbace.classes.analyze$expand_fully")

var Lit_1688 *jrt.String = jrt.Intern("arbace.classes.analyze$expand_to_loop")

var Lit_1689 *jrt.String = jrt.Intern("arbace.classes.analyze$expand_varargs")

var Lit_1690 *jrt.String = jrt.Intern("arbace.classes.analyze$fail")

var Lit_1691 *jrt.String = jrt.Intern("arbace.classes.analyze$fi_types")

var Lit_1692 *jrt.String = jrt.Intern("arbace.classes.analyze$fi_types$fn__1549001939")

var Lit_1693 *jrt.String = jrt.Intern("Ljava/io/Serializable;")

var Lit_1694 *jrt.String = jrt.Intern("arbace.classes.analyze$field_node")

var Lit_1695 *jrt.String = jrt.Intern("arbace.classes.analyze$find_own_field")

var Lit_1696 *jrt.String = jrt.Intern("arbace.classes.analyze$find_own_field$fn__1549000665")

var Lit_1697 *jrt.String = jrt.Intern("arbace.classes.analyze$find_sam")

var Lit_1698 *jrt.String = jrt.Intern(" is not an interface")

var Lit_1699 *jrt.String = jrt.Intern(" is not a functional interface (abstract methods: ")

var Lit_1700 *jrt.String = jrt.Intern("arbace.classes.analyze$find_sam$iter__1549001921__1549001927")

var Lit_1701 *jrt.String = jrt.Intern("arbace.classes.analyze$find_sam$iter__1549001921__1549001927$fn__1549001928")

var Lit_1702 *jrt.String = jrt.Intern("arbace.classes.analyze$find_sam$iter__1549001921__1549001927$fn__1549001928$iter__1549001923__1549001929")

var Lit_1703 *jrt.String = jrt.Intern("arbace.classes.analyze$find_sam$iter__1549001921__1549001927$fn__1549001928$iter__1549001923__1549001929$fn__1549001930")

var Lit_1704 *jrt.String = jrt.Intern("arbace.classes.analyze$find_sam$iter__1549001921__1549001927$fn__1549001928$iter__1549001923__1549001929$fn__1549001930$fn__1549001931")

var Lit_1705 *jrt.String = jrt.Intern("arbace.classes.analyze$fits_QMARK_")

var Lit_1706 *jrt.String = jrt.Intern("arbace.classes.analyze$fmod")

var Lit_1707 *jrt.String = jrt.Intern("arbace.classes.analyze$fold_arith")

var Lit_1708 *jrt.String = jrt.Intern("arbace.classes.analyze$for_target")

var Lit_1709 *jrt.String = jrt.Intern("arbace.classes.analyze$for_target$fn__1549000109")

var Lit_1710 *jrt.String = jrt.Intern("arbace.classes.analyze$for_target$fn__1549000109$fn__1549000110")

var Lit_1711 *jrt.String = jrt.Intern("arbace.classes.analyze$has_QMARK_")

var Lit_1712 *jrt.String = jrt.Intern("arbace.classes.analyze$iface_kind_QMARK_")

var Lit_1713 *jrt.String = jrt.Intern("arbace.classes.analyze$implicit_outer")

var Lit_1714 *jrt.String = jrt.Intern("arbace.classes.analyze$implicit_outer$fn__1549000056")

var Lit_1715 *jrt.String = jrt.Intern("arbace.classes.analyze$implicit_super_call")

var Lit_1716 *jrt.String = jrt.Intern("arbace.classes.analyze$import_classes_BANG_")

var Lit_1717 *jrt.String = jrt.Intern("arbace.classes.analyze$import_classes_BANG_$iter__1549002207__1549002213")

var Lit_1718 *jrt.String = jrt.Intern("arbace.classes.analyze$import_classes_BANG_$iter__1549002207__1549002213$fn__1549002214")

var Lit_1719 *jrt.String = jrt.Intern("arbace.classes.analyze$import_classes_BANG_$iter__1549002207__1549002213$fn__1549002214$fn__1549002225")

var Lit_1720 *jrt.String = jrt.Intern("arbace.classes.analyze$import_classes_BANG_$iter__1549002207__1549002213$fn__1549002214$iter__1549002209__1549002215")

var Lit_1721 *jrt.String = jrt.Intern("arbace.classes.analyze$import_classes_BANG_$iter__1549002207__1549002213$fn__1549002214$iter__1549002209__1549002215$fn__1549002216")

var Lit_1722 *jrt.String = jrt.Intern("arbace.classes.analyze$import_classes_BANG_$iter__1549002207__1549002213$fn__1549002214$iter__1549002209__1549002215$fn__1549002216$fn__1549002217")

var Lit_1723 *jrt.String = jrt.Intern("arbace.classes.analyze$import_classes_BANG_$iter__1549002207__1549002213$fn__1549002214$iter__1549002209__1549002215$fn__1549002216$fn__1549002217$fn__1549002218")

var Lit_1724 *jrt.String = jrt.Intern("arbace.classes.analyze$import_classes_BANG_$iter__1549002207__1549002213$fn__1549002214$iter__1549002209__1549002215$fn__1549002216$fn__1549002221")

var Lit_1725 *jrt.String = jrt.Intern("arbace.classes.analyze$infer_signature")

var Lit_1726 *jrt.String = jrt.Intern("arbace.classes.analyze$infer_signature$iter__1549000263__1549000269")

var Lit_1727 *jrt.String = jrt.Intern("arbace.classes.analyze$infer_signature$iter__1549000263__1549000269$fn__1549000270")

var Lit_1728 *jrt.String = jrt.Intern("arbace.classes.analyze$infer_signature$iter__1549000263__1549000269$fn__1549000270$iter__1549000265__1549000271")

var Lit_1729 *jrt.String = jrt.Intern("arbace.classes.analyze$infer_signature$iter__1549000263__1549000269$fn__1549000270$iter__1549000265__1549000271$fn__1549000272")

var Lit_1730 *jrt.String = jrt.Intern("arbace.classes.analyze$infer_signature$iter__1549000263__1549000269$fn__1549000270$iter__1549000265__1549000271$fn__1549000272$fn__1549000273")

var Lit_1731 *jrt.String = jrt.Intern("arbace.classes.analyze$instance_candidates")

var Lit_1732 *jrt.String = jrt.Intern("arbace.classes.analyze$instance_candidates$fn__1549001047")

var Lit_1733 *jrt.String = jrt.Intern("arbace.classes.analyze$int_operand")

var Lit_1734 *jrt.String = jrt.Intern("arbace.classes.analyze$invoke_node")

var Lit_1735 *jrt.String = jrt.Intern("arbace.classes.analyze$lambda_form_QMARK_")

var Lit_1736 *jrt.String = jrt.Intern("arbace.classes.analyze$lambda_method_prefix")

var Lit_1737 *jrt.String = jrt.Intern("arbace.classes.analyze$lambda_name_BANG_")

var Lit_1738 *jrt.String = jrt.Intern("lambda$")

var Lit_1739 *jrt.String = jrt.Intern("arbace.classes.analyze$literal_branch")

var Lit_1740 *jrt.String = jrt.Intern("arbace.classes.analyze$literal_tail_QMARK_")

var Lit_1741 *jrt.String = jrt.Intern("arbace.classes.analyze$literal_tail_QMARK_$fn__1549000589")

var Lit_1742 *jrt.String = jrt.Intern("arbace.classes.analyze$literal_tail_QMARK_$fn__1549000591")

var Lit_1743 *jrt.String = jrt.Intern("arbace.classes.analyze$literal_tail_vals")

var Lit_1744 *jrt.String = jrt.Intern("arbace.classes.analyze$literal_tail_vals$fn__1549000597")

var Lit_1745 *jrt.String = jrt.Intern("arbace.classes.analyze$literal_tail_vals$fn__1549000599")

var Lit_1746 *jrt.String = jrt.Intern("arbace.classes.analyze$local_class_name")

var Lit_1747 *jrt.String = jrt.Intern("arbace.classes.analyze$local_ref")

var Lit_1748 *jrt.String = jrt.Intern("Cannot capture mutable local ")

var Lit_1749 *jrt.String = jrt.Intern("Local out of scope: ")

var Lit_1750 *jrt.String = jrt.Intern("arbace.classes.analyze$local_type_anns")

var Lit_1751 *jrt.String = jrt.Intern("arbace.classes.analyze$local_type_anns$iter__1549000782__1549000786")

var Lit_1752 *jrt.String = jrt.Intern("arbace.classes.analyze$local_type_anns$iter__1549000782__1549000786$fn__1549000787")

var Lit_1753 *jrt.String = jrt.Intern("TYPE_USE")

var Lit_1754 *jrt.String = jrt.Intern("arbace.classes.analyze$local_type_anns$iter__1549000782__1549000786$fn__1549000787$fn__1549000788")

var Lit_1755 *jrt.String = jrt.Intern("arbace.classes.analyze$local_type_anns$iter__1549000792__1549000798")

var Lit_1756 *jrt.String = jrt.Intern("arbace.classes.analyze$local_type_anns$iter__1549000792__1549000798$fn__1549000799")

var Lit_1757 *jrt.String = jrt.Intern("arbace.classes.analyze$local_type_anns$iter__1549000792__1549000798$fn__1549000799$iter__1549000794__1549000803")

var Lit_1758 *jrt.String = jrt.Intern("arbace.classes.analyze$local_type_anns$iter__1549000792__1549000798$fn__1549000799$iter__1549000794__1549000803$fn__1549000804")

var Lit_1759 *jrt.String = jrt.Intern("arbace.classes.analyze$local_type_anns$iter__1549000792__1549000798$fn__1549000799$iter__1549000794__1549000803$fn__1549000804$fn__1549000805")

var Lit_1760 *jrt.String = jrt.Intern("arbace.classes.analyze$macroexpand1")

var Lit_1761 *jrt.String = jrt.Intern("arbace.classes.analyze$make_binding")

var Lit_1762 *jrt.String = jrt.Intern("arbace.classes.analyze$mark_enum_abstract_BANG_")

var Lit_1763 *jrt.String = jrt.Intern("arbace.classes.analyze$mark_enum_abstract_BANG_$fn__1549001799")

var Lit_1764 *jrt.String = jrt.Intern("arbace.classes.analyze$mark_enum_abstract_BANG_$fn__1549001799$fn__1549001800")

var Lit_1765 *jrt.String = jrt.Intern("arbace.classes.analyze$mark_enum_abstract_BANG_$fn__1549001803")

var Lit_1766 *jrt.String = jrt.Intern("arbace.classes.analyze$mark_enum_abstract_BANG_$impl_QMARK___1549001793")

var Lit_1767 *jrt.String = jrt.Intern("arbace.classes.analyze$mark_enum_abstract_BANG_$impl_QMARK___1549001793$fn__1549001794")

var Lit_1768 *jrt.String = jrt.Intern("arbace.classes.analyze$mark_enum_abstract_BANG_$impl_QMARK___1549001793$fn__1549001794$fn__1549001795")

var Lit_1769 *jrt.String = jrt.Intern("arbace.classes.analyze$mark_enum_abstract_BANG_$pk__1549001791")

var Lit_1770 *jrt.String = jrt.Intern("arbace.classes.analyze$may_be_constant_QMARK_")

var Lit_1771 *jrt.String = jrt.Intern("arbace.classes.analyze$method_scope")

var Lit_1772 *jrt.String = jrt.Intern("arbace.classes.analyze$method_scope$fn__1549000365")

var Lit_1773 *jrt.String = jrt.Intern("arbace.classes.analyze$method_signature")

var Lit_1774 *jrt.String = jrt.Intern("arbace.classes.analyze$method_signature$fn__1549000369")

var Lit_1775 *jrt.String = jrt.Intern("^")

var Lit_1776 *jrt.String = jrt.Intern("arbace.classes.analyze$method_sugar")

var Lit_1777 *jrt.String = jrt.Intern("..")

var Lit_1778 *jrt.String = jrt.Intern("arbace.classes.analyze$method_type_annotations")

var Lit_1779 *jrt.String = jrt.Intern("arbace.classes.analyze$method_type_annotations$fn__1549000372")

var Lit_1780 *jrt.String = jrt.Intern("arbace.classes.analyze$method_type_annotations$fn__1549000372$fn__1549000383")

var Lit_1781 *jrt.String = jrt.Intern("arbace.classes.analyze$method_type_annotations$fn__1549000372$fn__1549000385")

var Lit_1782 *jrt.String = jrt.Intern("arbace.classes.analyze$method_type_annotations$fn__1549000372$iter__1549000373__1549000377")

var Lit_1783 *jrt.String = jrt.Intern("arbace.classes.analyze$method_type_annotations$fn__1549000372$iter__1549000373__1549000377$fn__1549000378")

var Lit_1784 *jrt.String = jrt.Intern("arbace.classes.analyze$method_type_annotations$fn__1549000372$iter__1549000373__1549000377$fn__1549000378$fn__1549000379")

var Lit_1785 *jrt.String = jrt.Intern("arbace.classes.analyze$more_specific_QMARK_")

var Lit_1786 *jrt.String = jrt.Intern("arbace.classes.analyze$more_specific_QMARK_$fn__1549000938")

var Lit_1787 *jrt.String = jrt.Intern("arbace.classes.analyze$needs_outer_instance_QMARK_")

var Lit_1788 *jrt.String = jrt.Intern("arbace.classes.analyze$nest_host")

var Lit_1789 *jrt.String = jrt.Intern("arbace.classes.analyze$nested_ctor_call_QMARK_")

var Lit_1790 *jrt.String = jrt.Intern("arbace.classes.analyze$new_frame")

var Lit_1791 *jrt.String = jrt.Intern("arbace.classes.analyze$next_id")

var Lit_1792 *jrt.String = jrt.Intern("arbace.classes.analyze$not_yet")

var Lit_1793 *jrt.String = jrt.Intern("arbace.classes.analyze$not_yet$fn__1549001851")

var Lit_1794 *jrt.String = jrt.Intern(" is not implemented yet")

var Lit_1795 *jrt.String = jrt.Intern("arbace.classes.analyze$ns_package")

var Lit_1796 *jrt.String = jrt.Intern("arbace.classes.analyze$objects")

var Lit_1797 *jrt.String = jrt.Intern("arbace.classes.analyze$objects$fn__1549001091")

var Lit_1798 *jrt.String = jrt.Intern("arbace.classes.analyze$operand")

var Lit_1799 *jrt.String = jrt.Intern("Operand of type ")

var Lit_1800 *jrt.String = jrt.Intern("arbace.classes.analyze$operand$fn__1549000708")

var Lit_1801 *jrt.String = jrt.Intern("arbace.classes.analyze$or_reflect")

var Lit_1802 *jrt.String = jrt.Intern("arbace.classes.analyze$outer_instance_for")

var Lit_1803 *jrt.String = jrt.Intern("No enclosing instance for ")

var Lit_1804 *jrt.String = jrt.Intern("arbace.classes.analyze$outer_level")

var Lit_1805 *jrt.String = jrt.Intern("arbace.classes.analyze$outer_super_call")

var Lit_1806 *jrt.String = jrt.Intern("arbace.classes.analyze$outer_super_call$fn__1549002329")

var Lit_1807 *jrt.String = jrt.Intern("arbace.classes.analyze$outer_this_node")

var Lit_1808 *jrt.String = jrt.Intern("arbace.classes.analyze$outer_this_node$fn__1549000634")

var Lit_1809 *jrt.String = jrt.Intern("arbace.classes.analyze$outer_this_node$fn__1549000637")

var Lit_1810 *jrt.String = jrt.Intern("No enclosing instance of type ")

var Lit_1811 *jrt.String = jrt.Intern(" in scope")

var Lit_1812 *jrt.String = jrt.Intern("arbace.classes.analyze$outer_this_node_STAR_")

var Lit_1813 *jrt.String = jrt.Intern(" in a static context")

var Lit_1814 *jrt.String = jrt.Intern("arbace.classes.analyze$param_info")

var Lit_1815 *jrt.String = jrt.Intern("arbace.classes.analyze$param_tags_match_QMARK_")

var Lit_1816 *jrt.String = jrt.Intern("arbace.classes.analyze$param_tags_match_QMARK_$fn__1549000945")

var Lit_1817 *jrt.String = jrt.Intern("arbace.classes.analyze$parse_type")

var Lit_1818 *jrt.String = jrt.Intern("arbace.classes.analyze$prim_type")

var Lit_1819 *jrt.String = jrt.Intern("arbace.classes.analyze$prim_type_of")

var Lit_1820 *jrt.String = jrt.Intern("arbace.classes.analyze$process_classes_BANG_")

var Lit_1821 *jrt.String = jrt.Intern("arbace.classes.analyze$prologue_QMARK_")

var Lit_1822 *jrt.String = jrt.Intern("arbace.classes.analyze$qualifying_owner")

var Lit_1823 *jrt.String = jrt.Intern("arbace.classes.analyze$read_source_forms")

var Lit_1824 *jrt.String = jrt.Intern("UTF-8")

var Lit_1825 *jrt.String = jrt.Intern("arbace.classes.analyze$read_source_forms$fn__1549002201")

var Lit_1826 *jrt.String = jrt.Intern("arbace.classes.analyze$read_source_forms$fn__1549002203")

var Lit_1827 *jrt.String = jrt.Intern("arbace.classes.analyze$receiver_class")

var Lit_1828 *jrt.String = jrt.Intern("arbace.classes.analyze$ref_as_lambda")

var Lit_1829 *jrt.String = jrt.Intern("arbace.classes.analyze$ref_as_lambda$fn__1549001983")

var Lit_1830 *jrt.String = jrt.Intern("arbace.classes.analyze$ref_node")

var Lit_1831 *jrt.String = jrt.Intern(" of a primitive")

var Lit_1832 *jrt.String = jrt.Intern("arbace.classes.analyze$ref_owner")

var Lit_1833 *jrt.String = jrt.Intern("arbace.classes.analyze$reflect_QMARK_")

var Lit_1834 *jrt.String = jrt.Intern("arbace.classes.analyze$reflection_warning")

var Lit_1835 *jrt.String = jrt.Intern("NO_SOURCE_PATH")

var Lit_1836 *jrt.String = jrt.Intern("arbace.classes.analyze$reflective_call")

var Lit_1837 *jrt.String = jrt.Intern("call to method ")

var Lit_1838 *jrt.String = jrt.Intern("invokeNoArgInstanceMember")

var Lit_1839 *jrt.String = jrt.Intern("(Ljava/lang/Object;Ljava/lang/String;Z)Ljava/lang/Object;")

var Lit_1840 *jrt.String = jrt.Intern("invokeInstanceMethod")

var Lit_1841 *jrt.String = jrt.Intern("(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;")

var Lit_1842 *jrt.String = jrt.Intern("arbace.classes.analyze$reflective_node")

var Lit_1843 *jrt.String = jrt.Intern("Reflector")

var Lit_1844 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_class")

var Lit_1845 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_class_sym")

var Lit_1846 *jrt.String = jrt.Intern("java/lang/")

var Lit_1847 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_class_sym$fn__1549000037")

var Lit_1848 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_header_BANG_")

var Lit_1849 *jrt.String = jrt.Intern("java/lang/annotation/Annotation")

var Lit_1850 *jrt.String = jrt.Intern("java/lang/Record")

var Lit_1851 *jrt.String = jrt.Intern("Cannot extend final class ")

var Lit_1852 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_header_BANG_$fn__1549000244")

var Lit_1853 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_header_BANG_$fn__1549000249")

var Lit_1854 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_header_BANG_$fn__1549000251")

var Lit_1855 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_header_BANG_$fn__1549000251$fn__1549000252")

var Lit_1856 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_header_BANG_$pt__1549000246")

var Lit_1857 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_")

var Lit_1858 *jrt.String = jrt.Intern("()[")

var Lit_1859 *jrt.String = jrt.Intern("valueOf")

var Lit_1860 *jrt.String = jrt.Intern("(Ljava/lang/String;)")

var Lit_1861 *jrt.String = jrt.Intern(")V")

var Lit_1862 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$declared_QMARK___1549000519")

var Lit_1863 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$declared_QMARK___1549000519$fn__1549000520")

var Lit_1864 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$fn__1549000551")

var Lit_1865 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$fn__1549000553")

var Lit_1866 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$fn__1549000555")

var Lit_1867 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$fn__1549000557")

var Lit_1868 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$fn__1549000559")

var Lit_1869 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$fn__1549000561")

var Lit_1870 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000459__1549000463")

var Lit_1871 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000459__1549000463$fn__1549000464")

var Lit_1872 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000459__1549000463$fn__1549000464$fn__1549000465")

var Lit_1873 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000469__1549000473")

var Lit_1874 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000469__1549000473$fn__1549000474")

var Lit_1875 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000469__1549000473$fn__1549000474$fn__1549000475")

var Lit_1876 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000479__1549000483")

var Lit_1877 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000479__1549000483$fn__1549000484")

var Lit_1878 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000479__1549000483$fn__1549000484$fn__1549000485")

var Lit_1879 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000489__1549000493")

var Lit_1880 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000489__1549000493$fn__1549000494")

var Lit_1881 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000489__1549000493$fn__1549000494$fn__1549000495")

var Lit_1882 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000499__1549000503")

var Lit_1883 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000499__1549000503$fn__1549000504")

var Lit_1884 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000499__1549000503$fn__1549000504$fn__1549000505")

var Lit_1885 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000509__1549000513")

var Lit_1886 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000509__1549000513$fn__1549000514")

var Lit_1887 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000509__1549000513$fn__1549000514$fn__1549000515")

var Lit_1888 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000523__1549000527")

var Lit_1889 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000523__1549000527$fn__1549000528")

var Lit_1890 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000523__1549000527$fn__1549000528$fn__1549000529")

var Lit_1891 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000535__1549000539")

var Lit_1892 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000535__1549000539$fn__1549000540")

var Lit_1893 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000535__1549000539$fn__1549000540$fn__1549000541")

var Lit_1894 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_var")

var Lit_1895 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_var$fn__1549000644")

var Lit_1896 *jrt.String = jrt.Intern("arbace.classes.analyze$retention")

var Lit_1897 *jrt.String = jrt.Intern("arbace.classes.analyze$retention$fn__1549000064")

var Lit_1898 *jrt.String = jrt.Intern("java/lang/annotation/Retention")

var Lit_1899 *jrt.String = jrt.Intern("arbace.classes.analyze$retention$fn__1549000069")

var Lit_1900 *jrt.String = jrt.Intern("java.lang.annotation.Retention")

var Lit_1901 *jrt.String = jrt.Intern("arbace.classes.analyze$retype_clone")

var Lit_1902 *jrt.String = jrt.Intern("arbace.classes.analyze$scope_of")

var Lit_1903 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method")

var Lit_1904 *jrt.String = jrt.Intern("No method matches the param-tags of ")

var Lit_1905 *jrt.String = jrt.Intern("; candidates: ")

var Lit_1906 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001017")

var Lit_1907 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001029")

var Lit_1908 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001031")

var Lit_1909 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001033")

var Lit_1910 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001035")

var Lit_1911 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001037")

var Lit_1912 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001039")

var Lit_1913 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001041")

var Lit_1914 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001043")

var Lit_1915 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$pdescs__1549001019")

var Lit_1916 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$pick__1549001023")

var Lit_1917 *jrt.String = jrt.Intern("Ambiguous call: ")

var Lit_1918 *jrt.String = jrt.Intern(" ")

var Lit_1919 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$pick__1549001023$fn__1549001024")

var Lit_1920 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$pick__1549001023$fn__1549001024$fn__1549001025")

var Lit_1921 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$varargs_QMARK___1549001021")

var Lit_1922 *jrt.String = jrt.Intern("arbace.classes.analyze$serial_lambda_name_BANG_")

var Lit_1923 *jrt.String = jrt.Intern(":")

var Lit_1924 *jrt.String = jrt.Intern("arbace.classes.analyze$serial_lambda_name_BANG_$iter__1549001942__1549001946")

var Lit_1925 *jrt.String = jrt.Intern("arbace.classes.analyze$serial_lambda_name_BANG_$iter__1549001942__1549001946$fn__1549001947")

var Lit_1926 *jrt.String = jrt.Intern(",")

var Lit_1927 *jrt.String = jrt.Intern("arbace.classes.analyze$serial_lambda_name_BANG_$iter__1549001942__1549001946$fn__1549001947$fn__1549001948")

var Lit_1928 *jrt.String = jrt.Intern("arbace.classes.analyze$sharpest_accessible")

var Lit_1929 *jrt.String = jrt.Intern("arbace.classes.analyze$signature_polymorphic_QMARK_")

var Lit_1930 *jrt.String = jrt.Intern("arbace.classes.analyze$specialized")

var Lit_1931 *jrt.String = jrt.Intern("arbace.classes.analyze$state")

var Lit_1932 *jrt.String = jrt.Intern("arbace.classes.analyze$static_candidates")

var Lit_1933 *jrt.String = jrt.Intern("arbace.classes.analyze$static_candidates$fn__1549001051")

var Lit_1934 *jrt.String = jrt.Intern("arbace.classes.analyze$static_flag_QMARK_")

var Lit_1935 *jrt.String = jrt.Intern("arbace.classes.analyze$super_node")

var Lit_1936 *jrt.String = jrt.Intern("super in a static context")

var Lit_1937 *jrt.String = jrt.Intern("arbace.classes.analyze$supertype_envs")

var Lit_1938 *jrt.String = jrt.Intern("arbace.classes.analyze$supertype_envs$iter__1549001601__1549001605")

var Lit_1939 *jrt.String = jrt.Intern("arbace.classes.analyze$supertype_envs$iter__1549001601__1549001605$fn__1549001606")

var Lit_1940 *jrt.String = jrt.Intern("arbace.classes.analyze$supertype_envs$iter__1549001601__1549001605$fn__1549001606$fn__1549001607")

var Lit_1941 *jrt.String = jrt.Intern("arbace.classes.analyze$supertype_envs$iter__1549001619__1549001623")

var Lit_1942 *jrt.String = jrt.Intern("arbace.classes.analyze$supertype_envs$iter__1549001619__1549001623$fn__1549001624")

var Lit_1943 *jrt.String = jrt.Intern("arbace.classes.analyze$supertype_envs$iter__1549001619__1549001623$fn__1549001624$fn__1549001625")

var Lit_1944 *jrt.String = jrt.Intern("arbace.classes.analyze$supertype_envs$outer_env__1549001617")

var Lit_1945 *jrt.String = jrt.Intern("arbace.classes.analyze$supertypes_first")

var Lit_1946 *jrt.String = jrt.Intern("arbace.classes.analyze$supertypes_first$visit__1549001777")

var Lit_1947 *jrt.String = jrt.Intern("arbace.classes.analyze$switch_map_BANG_")

var Lit_1948 *jrt.String = jrt.Intern("arbace.classes.analyze$switch_map_BANG_$fn__1549002096")

var Lit_1949 *jrt.String = jrt.Intern("arbace.classes.analyze$switch_map_BANG_$fn__1549002098")

var Lit_1950 *jrt.String = jrt.Intern("arbace.classes.analyze$tag_of")

var Lit_1951 *jrt.String = jrt.Intern("arbace.classes.analyze$this0_name")

var Lit_1952 *jrt.String = jrt.Intern("this$")

var Lit_1953 *jrt.String = jrt.Intern("arbace.classes.analyze$this_node")

var Lit_1954 *jrt.String = jrt.Intern("No this in a static context")

var Lit_1955 *jrt.String = jrt.Intern("arbace.classes.analyze$top_name")

var Lit_1956 *jrt.String = jrt.Intern("arbace.classes.analyze$tparam_type_annotations")

var Lit_1957 *jrt.String = jrt.Intern("arbace.classes.analyze$tparam_type_annotations$fn__1549000152")

var Lit_1958 *jrt.String = jrt.Intern("arbace.classes.analyze$tparam_type_annotations$fn__1549000152$fn__1549000154")

var Lit_1959 *jrt.String = jrt.Intern("arbace.classes.analyze$tparam_type_annotations$fn__1549000152$fn__1549000154$fn__1549000167")

var Lit_1960 *jrt.String = jrt.Intern("arbace.classes.analyze$tparam_type_annotations$fn__1549000152$fn__1549000154$iter__1549000157__1549000161")

var Lit_1961 *jrt.String = jrt.Intern("arbace.classes.analyze$tparam_type_annotations$fn__1549000152$fn__1549000154$iter__1549000157__1549000161$fn__1549000162")

var Lit_1962 *jrt.String = jrt.Intern("arbace.classes.analyze$tparam_type_annotations$fn__1549000152$fn__1549000154$iter__1549000157__1549000161$fn__1549000162$fn__1549000163")

var Lit_1963 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations")

var Lit_1964 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations$fn__1549000120")

var Lit_1965 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations$fn__1549000120$iter__1549000121__1549000125")

var Lit_1966 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations$fn__1549000120$iter__1549000121__1549000125$fn__1549000126")

var Lit_1967 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations$fn__1549000120$iter__1549000121__1549000125$fn__1549000126$fn__1549000127")

var Lit_1968 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations$fn__1549000120$iter__1549000131__1549000137")

var Lit_1969 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations$fn__1549000120$iter__1549000131__1549000137$fn__1549000138")

var Lit_1970 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations$fn__1549000120$iter__1549000131__1549000137$fn__1549000138$iter__1549000133__1549000142")

var Lit_1971 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations$fn__1549000120$iter__1549000131__1549000137$fn__1549000138$iter__1549000133__1549000142$fn__1549000143")

var Lit_1972 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations$fn__1549000120$iter__1549000131__1549000137$fn__1549000138$iter__1549000133__1549000142$fn__1549000143$fn__1549000144")

var Lit_1973 *jrt.String = jrt.Intern("arbace.classes.analyze$type_arg_anns")

var Lit_1974 *jrt.String = jrt.Intern("arbace.classes.analyze$type_arg_anns$fn__1549001155")

var Lit_1975 *jrt.String = jrt.Intern("arbace.classes.analyze$type_desc")

var Lit_1976 *jrt.String = jrt.Intern("arbace.classes.analyze$type_scope")

var Lit_1977 *jrt.String = jrt.Intern("arbace.classes.analyze$type_scope$fn__1549000042")

var Lit_1978 *jrt.String = jrt.Intern("arbace.classes.analyze$type_scope$fn__1549000044")

var Lit_1979 *jrt.String = jrt.Intern("arbace.classes.analyze$unboxed")

var Lit_1980 *jrt.String = jrt.Intern("arbace.classes.analyze$unify")

var Lit_1981 *jrt.String = jrt.Intern("arbace.classes.analyze$unify_nodes")

var Lit_1982 *jrt.String = jrt.Intern("arbace.classes.analyze$unify_nodes$fn__1549000604")

var Lit_1983 *jrt.String = jrt.Intern("arbace.classes.analyze$unify_nodes$fn__1549000604$fn__1549000605")

var Lit_1984 *jrt.String = jrt.Intern("arbace.classes.analyze$unresolved_QMARK_")

var Lit_1985 *jrt.String = jrt.Intern("arbace.classes.analyze$update_decl_BANG_")

var Lit_1986 *jrt.String = jrt.Intern("arbace.classes.analyze$value_type")

var Lit_1987 *jrt.String = jrt.Intern("arbace.classes.analyze$var_invoke_node")

var Lit_1988 *jrt.String = jrt.Intern("arbace.classes.analyze$widens_QMARK_")

var Lit_1989 *jrt.String = jrt.Intern("arbace.classes.analyze$with_form_info")

var Lit_1990 *jrt.String = jrt.Intern(" (line ")

var Lit_1991 *jrt.String = jrt.Intern("arbace.classes.analyze$with_local")

var Lit_1992 *jrt.String = jrt.Intern("arbace.classes.analyze$with_node_locals")

var Lit_1993 *jrt.String = jrt.Intern("arbace.classes.analyze$with_node_locals$fn__1549001279")

var Lit_1994 *jrt.String = jrt.Intern("arg__")

var Lit_1995 *jrt.String = jrt.Intern("arbace.classes.analyze$with_node_locals$fn__1549001283")

var Lit_1996 *jrt.String = jrt.Intern("file")

var Lit_1997 *jrt.String = jrt.Intern("arbace/classes/analyze.ae")

var Lit_1998 *jrt.String = jrt.Intern("The current compilation: {:order (atom [names in definition order]) :counters (atom {})}.")

var Lit_1999 *jrt.String = jrt.Intern("arglists")

var Lit_2000 *jrt.String = jrt.Intern("data")

var Lit_2001 *jrt.String = jrt.Intern("n")

var Lit_2002 *jrt.String = jrt.Intern("f")

var Lit_2003 *jrt.String = jrt.Intern("m")

var Lit_2004 *jrt.String = jrt.Intern("How many enclosing instances class o has (javac's nesting level of the outer type).")

var Lit_2005 *jrt.String = jrt.Intern("this0-name")

var Lit_2006 *jrt.String = jrt.Intern("javac's name of class n's outer instance field: this$N, N the outer class's nesting level.")

var Lit_2007 *jrt.String = jrt.Intern("ctor-real-desc")

var Lit_2008 *jrt.String = jrt.Intern("cn")

var Lit_2009 *jrt.String = jrt.Intern("The descriptor of a constructor of class cn with all implicit parameters.")

var Lit_2010 *jrt.String = jrt.Intern("declared")

var Lit_2011 *jrt.String = jrt.Intern("Whether class names that resolve to nothing are looked up as p/C.ae sources (§9.2): not in\n  the Go build yet (doc/go/CLASSFORMS-REPL.md).")

var Lit_2012 *jrt.String = jrt.Intern("c")

var Lit_2013 *jrt.String = jrt.Intern("Is class c the one namespaces map symbol sym to by default (RT/DEFAULT_IMPORTS)?")

var Lit_2014 *jrt.String = jrt.Intern("Resolves a class name symbol from `scope` {:class internal-name :ns ns :local-classes {}}:\n  member classes of the class and its enclosing classes, then the namespace's explicit imports,\n  then the class's own package, then Clojure's default imports and java.lang (SPEC §5.2).\n  Returns an internal name or nil.")

var Lit_2015 *jrt.String = jrt.Intern("A scope for types/parse-type: class name resolution plus type variables.")

var Lit_2016 *jrt.String = jrt.Intern("Inside a generic class, the simple name of one of its inner (non-static) member classes\n  denotes Outer<T...>.Inner (JLS 6.5.5.1): the outer type node, or nil.")

var Lit_2017 *jrt.String = jrt.Intern("The erased descriptor of a type form in scope.")

var Lit_2018 *jrt.String = jrt.Intern("The scope of the body of class n.")

var Lit_2019 *jrt.String = jrt.Intern("el")

var Lit_2020 *jrt.String = jrt.Intern("The return descriptor of annotation element `el` of annotation type n.")

var Lit_2021 *jrt.String = jrt.Intern("v")

var Lit_2022 *jrt.String = jrt.Intern("Annotations (delayed, as annotation types of the compilation may not be entered yet) in metadata m (symbol keys naming annotation types), in scope.\n  Returns [{:type desc :visible bool :values {name value}}], SOURCE ones dropped.")

var Lit_2023 *jrt.String = jrt.Intern("The ElementType names of annotation type n's @Target, or nil when it has none.")

var Lit_2024 *jrt.String = jrt.Intern("Annotations applicable to declaration context `target` (an ElementType name), as javac\n  propagates record component annotations.")

var Lit_2025 *jrt.String = jrt.Intern("context")

var Lit_2026 *jrt.String = jrt.Intern("Declaration annotations in metadata m for declaration context `context` (an ElementType\n  name): those without @Target or whose @Target includes it.")

var Lit_2027 *jrt.String = jrt.Intern("Type annotations of a declared type tn at type reference `ref` (an int): those inside the\n  type, and those of the declaration's metadata m whose @Target includes TYPE_USE.")

var Lit_2028 *jrt.String = jrt.Intern("tps")

var Lit_2029 *jrt.String = jrt.Intern("Type annotations of type parameters and their bounds (sort: class or method).")

var Lit_2030 *jrt.String = jrt.Intern("parsed")

var Lit_2031 *jrt.String = jrt.Intern("javac's name for a local (simple name given) or anonymous class in class `outer`.")

var Lit_2032 *jrt.String = jrt.Intern("ctx")

var Lit_2033 *jrt.String = jrt.Intern("Enters a parsed class form and its member classes into the compilation.\n  ctx: {:nesting :outer :name (for local and anonymous classes) :static-context bool\n        :local-classes {} :enclosing-method {:name :desc}}. Returns the internal name.")

var Lit_2034 *jrt.String = jrt.Intern("Type variable bounds visible in class n: its own, those of the method creating a local or\n  anonymous class, and, unless static, its outer classes'.")

var Lit_2035 *jrt.String = jrt.Intern("Resolves type parameters, superclass, interfaces and the class Signature of n.")

var Lit_2036 *jrt.String = jrt.Intern("transient")

var Lit_2037 *jrt.String = jrt.Intern("volatile")

var Lit_2038 *jrt.String = jrt.Intern("abstract")

var Lit_2039 *jrt.String = jrt.Intern("synchronized")

var Lit_2040 *jrt.String = jrt.Intern("native")

var Lit_2041 *jrt.String = jrt.Intern("d")

var Lit_2042 *jrt.String = jrt.Intern("x")

var Lit_2043 *jrt.String = jrt.Intern("arity")

var Lit_2044 *jrt.String = jrt.Intern("deftype's rule: an untyped instance method takes the erased signature of the unique method of\n  its supertypes with the same name and arity.")

var Lit_2045 *jrt.String = jrt.Intern("The methods of class n's supertypes that a reify or deftype class n can implement (public or\n  protected, neither static nor final), as arbace.lang.Compiler's NewInstanceExpr.considerMethod\n  takes them, each with its declaring class as :owner.")

var Lit_2046 *jrt.String = jrt.Intern("arbace.lang.Compiler's NewInstanceExpr.gatherMethods for class n (a reify or deftype class):\n  the methods of its supertypes it can implement (public or protected, neither static nor\n  final), one per name and parameter types, the one with the most specific return type.")

var Lit_2047 *jrt.String = jrt.Intern("The covariant bridges arbace.lang.Compiler gives a reify or deftype class n\n  (NewInstanceExpr.emitMethods over gatherMethods' covariants): for every method of the\n  supertypes that another one with the same name and parameter types but a more specific return\n  type overrides, whether n implements it or not, a public bridge (ACC_BRIDGE only, no\n  exceptions) with the overridden return type calling the most specific one through its\n  declaring interface.")

var Lit_2048 *jrt.String = jrt.Intern("The descriptor of arbace.lang.Compiler's tagClass of a hint: Object without one.")

var Lit_2049 *jrt.String = jrt.Intern("Class.getName of the class of descriptor d.")

var Lit_2050 *jrt.String = jrt.Intern("mname")

var Lit_2051 *jrt.String = jrt.Intern("The method of class n's supertypes that a method of reify or deftype named mname (munged)\n  with parameters params and return hint ret-tag implements, chosen as arbace.lang.Compiler's\n  NewInstanceMethod.parse chooses it, with its errors: the only method with that name and arity\n  when nothing is hinted; otherwise the one whose parameter types are the hinted classes\n  (Object where unhinted), whose return type must be the hinted class (Object when unhinted).")

var Lit_2052 *jrt.String = jrt.Intern("tparams-form")

var Lit_2053 *jrt.String = jrt.Intern("throws-tn")

var Lit_2054 *jrt.String = jrt.Intern("mmeta")

var Lit_2055 *jrt.String = jrt.Intern("pinfos")

var Lit_2056 *jrt.String = jrt.Intern("more")

var Lit_2057 *jrt.String = jrt.Intern("Enters the fields and methods of n, declared and derived (§6). Supertypes in the\n  compilation are entered first (for deftype-style signature inference).")

var Lit_2058 *jrt.String = jrt.Intern("Converts constant value v to the Java value of descriptor t.")

var Lit_2059 *jrt.String = jrt.Intern("How a value of type `from` converts to `to` in assignment and invocation contexts:\n  nil when it cannot, else a keyword: :none :widen :box :unbox :narrow-const :null.")

var Lit_2060 *jrt.String = jrt.Intern("a")

var Lit_2061 *jrt.String = jrt.Intern("The type of a value that is one of two branches' values.")

var Lit_2062 *jrt.String = jrt.Intern("Is the value of node an integer literal that fits an int (in every tail)?")

var Lit_2063 *jrt.String = jrt.Intern("The values of the integer literal tails of node, or nil if some tail is no literal.")

var Lit_2064 *jrt.String = jrt.Intern("A branch of integer literals takes the int-like type of the whole (as Java types them).")

var Lit_2065 *jrt.String = jrt.Intern("nodes")

var Lit_2066 *jrt.String = jrt.Intern("The type of a value that is one of the nodes' values.")

var Lit_2067 *jrt.String = jrt.Intern("cls")

var Lit_2068 *jrt.String = jrt.Intern("actx")

var Lit_2069 *jrt.String = jrt.Intern("Is code of actx before the constructor call (no instance yet)?")

var Lit_2070 *jrt.String = jrt.Intern("Java's T.this from actx: the path of this$0 hops from the current class to class T. In a\n  lambda in a constructor of an inner class, the constructor's outer instance parameter\n  captured by the lambda, as javac's Lower makes it before LambdaToMethod.")

var Lit_2071 *jrt.String = jrt.Intern("The frame enclosing the code of class n: where a local or anonymous class was declared, a\n  stand-in for the outer class's instance code for member classes, nil for top-level ones.")

var Lit_2072 *jrt.String = jrt.Intern("The name of the core var a head symbol resolves to, or nil.")

var Lit_2073 *jrt.String = jrt.Intern("analyze-invoke")

var Lit_2074 *jrt.String = jrt.Intern("analyze-class-form")

var Lit_2075 *jrt.String = jrt.Intern("Analyzes a form of code into a typed node.")

var Lit_2076 *jrt.String = jrt.Intern("A tag on an expression gives its static type, as in Clojure; a checkcast keeps the\n  verifier happy where the type is not already known.")

var Lit_2077 *jrt.String = jrt.Intern("forms")

var Lit_2078 *jrt.String = jrt.Intern("Analyzes forms as a `do`.")

var Lit_2079 *jrt.String = jrt.Intern("A field of the current class or an enclosing class body, innermost first:\n  [field class-name] or nil.")

var Lit_2080 *jrt.String = jrt.Intern("unchecked-negate")

var Lit_2081 *jrt.String = jrt.Intern("unchecked-divide")

var Lit_2082 *jrt.String = jrt.Intern("unchecked-subtract-float")

var Lit_2083 *jrt.String = jrt.Intern("*")

var Lit_2084 *jrt.String = jrt.Intern("bit-shift-right-int")

var Lit_2085 *jrt.String = jrt.Intern("unchecked-subtract")

var Lit_2086 *jrt.String = jrt.Intern("unchecked-divide-int")

var Lit_2087 *jrt.String = jrt.Intern("unchecked-negate-int")

var Lit_2088 *jrt.String = jrt.Intern("unchecked-add")

var Lit_2089 *jrt.String = jrt.Intern("unchecked-dec-int")

var Lit_2090 *jrt.String = jrt.Intern("bit-shift-left-int")

var Lit_2091 *jrt.String = jrt.Intern("bit-xor")

var Lit_2092 *jrt.String = jrt.Intern("bit-and")

var Lit_2093 *jrt.String = jrt.Intern("unchecked-add-int")

var Lit_2094 *jrt.String = jrt.Intern("unchecked-dec")

var Lit_2095 *jrt.String = jrt.Intern("bit-and-not")

var Lit_2096 *jrt.String = jrt.Intern("unchecked-negate-float")

var Lit_2097 *jrt.String = jrt.Intern("unchecked-inc")

var Lit_2098 *jrt.String = jrt.Intern("bit-not")

var Lit_2099 *jrt.String = jrt.Intern("unchecked-remainder-int")

var Lit_2100 *jrt.String = jrt.Intern("unsigned-bit-shift-right-int")

var Lit_2101 *jrt.String = jrt.Intern("unsigned-bit-shift-right")

var Lit_2102 *jrt.String = jrt.Intern("bit-and-int")

var Lit_2103 *jrt.String = jrt.Intern("bit-not-int")

var Lit_2104 *jrt.String = jrt.Intern("unchecked-multiply-float")

var Lit_2105 *jrt.String = jrt.Intern("unchecked-multiply")

var Lit_2106 *jrt.String = jrt.Intern("unchecked-subtract-int")

var Lit_2107 *jrt.String = jrt.Intern("bit-shift-right")

var Lit_2108 *jrt.String = jrt.Intern("unchecked-multiply-int")

var Lit_2109 *jrt.String = jrt.Intern("unchecked-remainder-float")

var Lit_2110 *jrt.String = jrt.Intern("unchecked-add-float")

var Lit_2111 *jrt.String = jrt.Intern("unchecked-inc-int")

var Lit_2112 *jrt.String = jrt.Intern("quot")

var Lit_2113 *jrt.String = jrt.Intern("bit-shift-left")

var Lit_2114 *jrt.String = jrt.Intern("bit-xor-int")

var Lit_2115 *jrt.String = jrt.Intern("unchecked-remainder")

var Lit_2116 *jrt.String = jrt.Intern("bit-or-int")

var Lit_2117 *jrt.String = jrt.Intern("unchecked-divide-float")

var Lit_2118 *jrt.String = jrt.Intern("+")

var Lit_2119 *jrt.String = jrt.Intern("The primitive type of a node's value (unboxing a wrapper), or nil.")

var Lit_2120 *jrt.String = jrt.Intern("Is the value of node (through do and let) an array's clone()?")

var Lit_2121 *jrt.String = jrt.Intern("Is the value of node (through do and let) that of a conditional, switch or try?")

var Lit_2122 *jrt.String = jrt.Intern("Converts node to type `to` (an assignment conversion; a const is converted at compile time).")

var Lit_2123 *jrt.String = jrt.Intern("Converts an operand to the operation type t: numeric promotion, literals narrowed.")

var Lit_2124 *jrt.String = jrt.Intern("An int operand (array dimension or index); in Clojure code (§5.13) also any other value,\n  converted by RT.intCast as Clojure converts it.")

var Lit_2125 *jrt.String = jrt.Intern("Java's % on doubles (drem: the remainder of the truncated quotient, exact), for folding.")

var Lit_2126 *jrt.String = jrt.Intern("opname")

var Lit_2127 *jrt.String = jrt.Intern("arg")

var Lit_2128 *jrt.String = jrt.Intern("checked?")

var Lit_2129 *jrt.String = jrt.Intern("bool-node")

var Lit_2130 *jrt.String = jrt.Intern("Is f a lambda or method reference, possibly under casts (javac's pending variable of\n  serializable lambda names sees through them)?")

var Lit_2131 *jrt.String = jrt.Intern("Type annotations of a local variable: TYPE_USE annotations on the binding symbol and those\n  inside its tag.")

var Lit_2132 *jrt.String = jrt.Intern("loop?")

var Lit_2133 *jrt.String = jrt.Intern("The type of a let/loop local: its tag, else its initializer's type (Clojure's loop widens\n  untagged int and float).")

var Lit_2134 *jrt.String = jrt.Intern("Does form declare a class (anon, letclass)?")

var Lit_2135 *jrt.String = jrt.Intern("Macroexpands form until it is a loop* (or for-each*) form; nil if it does not become one.")

var Lit_2136 *jrt.String = jrt.Intern("e")

var Lit_2137 *jrt.String = jrt.Intern("phase")

var Lit_2138 *jrt.String = jrt.Intern("param-descs")

var Lit_2139 *jrt.String = jrt.Intern("p1")

var Lit_2140 *jrt.String = jrt.Intern("p2")

var Lit_2141 *jrt.String = jrt.Intern("tags")

var Lit_2142 *jrt.String = jrt.Intern("java/util/Comparator")

var Lit_2143 *jrt.String = jrt.Intern("java/lang/Runnable")

var Lit_2144 *jrt.String = jrt.Intern("java/util/concurrent/Callable")

var Lit_2145 *jrt.String = jrt.Intern("Compiler's FISupport.maybeFIMethod: for a parameter of type desc that is a\n  @FunctionalInterface other than Callable, Runnable and Comparator, its method (an abstract\n  one, of at most 10 parameters, other than equals, toString and hashCode) that an IFn argument\n  is adapted to, as {:name :ps [param desc ...] :ret desc}; else nil. A class compiled from\n  source (*from-source*: a2g's world, where the JDK's classes have class forms) is asked\n  through its declaration: its annotations and its single abstract method.")

var Lit_2146 *jrt.String = jrt.Intern("The class arbace.lang.Compiler knows for an argument node (Expr.getJavaClass), as a\n  descriptor: nil for nil, ::unknown for Object (the type of what Clojure leaves untyped).")

var Lit_2147 *jrt.String = jrt.Intern("Ljava/lang/Float;")

var Lit_2148 *jrt.String = jrt.Intern("Ljava/lang/Double;")

var Lit_2149 *jrt.String = jrt.Intern("Ljava/lang/Character;")

var Lit_2150 *jrt.String = jrt.Intern("Ljava/lang/Short;")

var Lit_2151 *jrt.String = jrt.Intern("Ljava/lang/Byte;")

var Lit_2152 *jrt.String = jrt.Intern("Ljava/lang/Boolean;")

var Lit_2153 *jrt.String = jrt.Intern("Reflector.paramArgTypeMatch's conversions to primitive parameters.")

var Lit_2154 *jrt.String = jrt.Intern("Reflector.paramArgTypeMatch for parameter type p and argument class a (clj-arg-class).")

var Lit_2155 *jrt.String = jrt.Intern("c1")

var Lit_2156 *jrt.String = jrt.Intern("c2")

var Lit_2157 *jrt.String = jrt.Intern("Compiler.subsumes: is parameter list c1 more specific than c2?")

var Lit_2158 *jrt.String = jrt.Intern("r1")

var Lit_2159 *jrt.String = jrt.Intern("r2")

var Lit_2160 *jrt.String = jrt.Intern("Class.isAssignableFrom on return types: r1 from r2.")

var Lit_2161 *jrt.String = jrt.Intern("plists")

var Lit_2162 *jrt.String = jrt.Intern("rets")

var Lit_2163 *jrt.String = jrt.Intern("Compiler.getMatchingParams: the index of the parameter list (of plists, with return types\n  rets) chosen for the argument nodes, or -1; \"More than one matching method found\" on a tie.")

var Lit_2164 *jrt.String = jrt.Intern("Compiler.getTypeStringForArgs.")

var Lit_2165 *jrt.String = jrt.Intern("cands")

var Lit_2166 *jrt.String = jrt.Intern("The method (or constructor) of cands that arbace.lang.Compiler calls for the argument nodes,\n  marked :clojure-args (its arguments converted as Clojure converts them): the only one of that\n  arity, else the one Compiler.getMatchingParams chooses (kind :instance, :static or :ctor of\n  class cn), with the compiler's errors. When it chooses none an instance method or constructor\n  is called by reflection, as in Clojure (an unresolved failure, see or-reflect).")

var Lit_2167 *jrt.String = jrt.Intern("Chooses among candidate methods for argument nodes (JLS 15.12.2 on erased types: strict,\n  loose, then variable arity invocation; then literal narrowing). Returns [method varargs?].")

var Lit_2168 *jrt.String = jrt.Intern("The candidates of an instance method call (.mname x ...) from class `from` on a receiver of\n  class cn (§5.6).")

var Lit_2169 *jrt.String = jrt.Intern("The candidates of a static method call (C/mname ...) from class `from`.")

var Lit_2170 *jrt.String = jrt.Intern("The constructors of class cn accessible from class `from`.")

var Lit_2171 *jrt.String = jrt.Intern("An argument node converted to parameter type `to` as arbace.lang.Compiler converts it\n  (HostExpr.emitUnboxArg): references by RT's longCast, intCast..., Boolean and Character\n  unboxed, references of other types checked, long to int by RT.intCast.")

var Lit_2172 *jrt.String = jrt.Intern("varargs?")

var Lit_2173 *jrt.String = jrt.Intern("Converts argument nodes to the parameter types of method m (packing variable arity\n  arguments into an array); as Clojure converts them when m was chosen for Clojure's code\n  (:clojure-args).")

var Lit_2174 *jrt.String = jrt.Intern("static-type")

var Lit_2175 *jrt.String = jrt.Intern("JLS 13.1: the class named in the instruction is the receiver's static type, except for\n  members of Object.")

var Lit_2176 *jrt.String = jrt.Intern("owner-desc")

var Lit_2177 *jrt.String = jrt.Intern("JVMS 2.9.3: a native variable arity method of MethodHandle or VarHandle taking Object[].")

var Lit_2178 *jrt.String = jrt.Intern("Does a call the compiler cannot resolve go through arbace.lang.Reflector? With\n  ^{:reflection :warn} on the class (SPEC §12 question 7), and in the code of fns that\n  arbace.lang.Compiler hands over (^{:reflection :clojure}), as in Clojure.")

var Lit_2179 *jrt.String = jrt.Intern("A call through arbace.lang.Reflector at run time (see reflect?).")

var Lit_2180 *jrt.String = jrt.Intern("Is e the compiler's failure to resolve a member (so that reflection may apply)?")

var Lit_2181 *jrt.String = jrt.Intern("reflect")

var Lit_2182 *jrt.String = jrt.Intern("f's node, or when reflection applies and f fails to resolve a member, (reflect why).")

var Lit_2183 *jrt.String = jrt.Intern("(.name target args) where target is a node of static type `tt`.")

var Lit_2184 *jrt.String = jrt.Intern("fname")

var Lit_2185 *jrt.String = jrt.Intern("k")

var Lit_2186 *jrt.String = jrt.Intern("Field `fname` of target node; k is called with the field and owner (default: a read).")

var Lit_2187 *jrt.String = jrt.Intern("If form names a class (not a local), its internal name.")

var Lit_2188 *jrt.String = jrt.Intern("Type annotations of explicit type arguments (^{:type-args [types]} on a method symbol, SPEC\n  §8.4): [[index [[path annotation] ...]] ...].")

var Lit_2189 *jrt.String = jrt.Intern("(. target member args*) and (. target (member args*))")

var Lit_2190 *jrt.String = jrt.Intern("A call of constructor of class cn with args; kind :new, :super or :this.")

var Lit_2191 *jrt.String = jrt.Intern("tdesc")

var Lit_2192 *jrt.String = jrt.Intern("The implicit outer instance node for creating class cn from actx.")

var Lit_2193 *jrt.String = jrt.Intern("idxs")

var Lit_2194 *jrt.String = jrt.Intern("a-node")

var Lit_2195 *jrt.String = jrt.Intern("Type annotations of a type form in code, for the instruction it types: [[path ann] ...].")

var Lit_2196 *jrt.String = jrt.Intern("ref-node")

var Lit_2197 *jrt.String = jrt.Intern("Clojure's interop sugar as a `.` form, or nil.")

var Lit_2198 *jrt.String = jrt.Intern("The node of f, or nil when f fails to compile (the Clojure operation then applies).")

var Lit_2199 *jrt.String = jrt.Intern("convert-node; in Clojure code (§5.13) a value that no assignment conversion gives the\n  primitive type `to` is converted by RT's longCast, intCast... as Clojure converts it.")

var Lit_2200 *jrt.String = jrt.Intern("Analyzes (f syms) with the symbols bound to the already analyzed nodes, in order: a let.")

var Lit_2201 *jrt.String = jrt.Intern("A call of the function of var v on the analyzed argument nodes, as Clojure compiles it: its\n  :inline expansion if it has one for this arity, else a call of the var.")

var Lit_2202 *jrt.String = jrt.Intern("cop")

var Lit_2203 *jrt.String = jrt.Intern("A call of the core var named cop: an instruction where its operands allow (§5.4, §5.5),\n  else a call as Clojure compiles it (§5.13). Each argument is analyzed once.")

var Lit_2204 *jrt.String = jrt.Intern("A call of the function in var v with the argument nodes.")

var Lit_2205 *jrt.String = jrt.Intern("fnode")

var Lit_2206 *jrt.String = jrt.Intern("(f args*) where f is the node of any value: IFn.invoke (§5.13).")

var Lit_2207 *jrt.String = jrt.Intern("Macroexpands form until its head is no macro.")

var Lit_2208 *jrt.String = jrt.Intern("Clojure's fn*, letfn*, case*, def, var, reify*, deftype* and import* in code compiled by the\n  class forms compiler, rewritten by arbace.classes.lower (§5.13, §9.5), or (deftype*) compiled\n  by arbace.lang.Compiler.")

var Lit_2209 *jrt.String = jrt.Intern("deftype")

var Lit_2210 *jrt.String = jrt.Intern("fn")

var Lit_2211 *jrt.String = jrt.Intern("letfn")

var Lit_2212 *jrt.String = jrt.Intern("defrecord")

var Lit_2213 *jrt.String = jrt.Intern("Can form be a constant expression? Those declaring classes or lambdas cannot, and analyzing\n  them would declare those (an anonymous class number would be taken).")

var Lit_2214 *jrt.String = jrt.Intern("Analyzes a form expected to be a constant of type desc; returns the const node or nil.")

var Lit_2215 *jrt.String = jrt.Intern("The analysis context for code of class n.")

var Lit_2216 *jrt.String = jrt.Intern("Binds the receiver (unless static) and the parameters of method entry m.")

var Lit_2217 *jrt.String = jrt.Intern("Is the constructor call in form f at the statement level of (nested) let and do bodies?")

var Lit_2218 *jrt.String = jrt.Intern("(super. args) or (this. args); param-tags on the head pin the constructor (§4.7). In a\n  constructor whose call is nested in the prologue's let forms (:ctor-phase), the code after\n  it is past the prologue.")

var Lit_2219 *jrt.String = jrt.Intern("head")

var Lit_2220 *jrt.String = jrt.Intern("sactx")

var Lit_2221 *jrt.String = jrt.Intern("The <clinit> nodes creating the constants of enum n and $VALUES.")

var Lit_2222 *jrt.String = jrt.Intern("Analyzes all code of class n, in the textual order of its members (so anonymous classes are\n  numbered as javac numbers them). Results go to the class's :state.")

var Lit_2223 *jrt.String = jrt.Intern("Generic view of class n: {:tparams [sym] :supers [tnode] :methods [{:name :desc :params [tnode]\n  :bounds {}}]}.")

var Lit_2224 *jrt.String = jrt.Intern("For every supertype S of class n: S -> substitution of S's type variables in n's terms (nil\n  for raw or non-generic supertypes).")

var Lit_2225 *jrt.String = jrt.Intern("envs")

var Lit_2226 *jrt.String = jrt.Intern("Adds javac's bridge methods to class n (TransTypes.addBridgeIfNeeded): for each method meth\n  of a supertype whose implementation in n has another erasure, unless a bridge with meth's\n  erasure is already present at or below the implementation. Bridges of enclosing classes are\n  not yet present, as javac translates nested classes before adding the outer class's bridges.")

var Lit_2227 *jrt.String = jrt.Intern("names")

var Lit_2228 *jrt.String = jrt.Intern("Names ordered so that supertypes in the list come before their subtypes.")

var Lit_2229 *jrt.String = jrt.Intern("An enum with constant bodies that leaves an interface method unimplemented is abstract\n  (javac's markAbstractIfNeeded).")

var Lit_2230 *jrt.String = jrt.Intern("Resolves headers and members of the classes declared since position `from` of the unit's\n  order, then analyzes their code.")

var Lit_2231 *jrt.String = jrt.Intern("super-form")

var Lit_2232 *jrt.String = jrt.Intern("(anon Super [args] member*) and (anon Inner [args] :outer o member*) (§4.8); param-tags on\n  the argument vector pin the superclass constructor.")

var Lit_2233 *jrt.String = jrt.Intern("specs")

var Lit_2234 *jrt.String = jrt.Intern("not-yet")

var Lit_2235 *jrt.String = jrt.Intern("ector")

var Lit_2236 *jrt.String = jrt.Intern("The anonymous class E$n of an enum constant with a body; its constructor takes the enum\n  constructor's parameters (after name and ordinal) and passes them on.")

var Lit_2237 *jrt.String = jrt.Intern("Java's string conversion of a constant.")

var Lit_2238 *jrt.String = jrt.Intern("bv")

var Lit_2239 *jrt.String = jrt.Intern("hashCode()")

var Lit_2240 *jrt.String = jrt.Intern("toString()")

var Lit_2241 *jrt.String = jrt.Intern("equals(Ljava/lang/Object;)")

var Lit_2242 *jrt.String = jrt.Intern("The single abstract method of functional interface n: {:name :desc}.")

var Lit_2243 *jrt.String = jrt.Intern("[main-interface markers serializable? intersection] of a lambda's target type form. Serializable\n  is no marker: it makes the lambda serializable.")

var Lit_2244 *jrt.String = jrt.Intern("fin")

var Lit_2245 *jrt.String = jrt.Intern("javac's name for a serializable lambda: a hash of the enclosing method's signature, the\n  functional interface, the variable assigned and the captured locals (LambdaToMethod).")

var Lit_2246 *jrt.String = jrt.Intern("call-fn")

var Lit_2247 *jrt.String = jrt.Intern("javac makes a lambda method for references it cannot express as a method handle (variable\n  arity adaptation): the equivalent lambda form.")

var Lit_2248 *jrt.String = jrt.Intern("The class a method reference's handle names: the declaring class, except that Object's\n  methods referenced through an interface are named by the interface (javac's binaryQualifier).")

var Lit_2249 *jrt.String = jrt.Intern("st")

var Lit_2250 *jrt.String = jrt.Intern("Analyzes a pattern form against a value of static type st. Returns [pattern actx-with-bindings].")

var Lit_2251 *jrt.String = jrt.Intern("pat")

var Lit_2252 *jrt.String = jrt.Intern("Registers a use of enum constant `c` of enum e in the outermost class's $SwitchMap$; returns\n  its mapped value.")

var Lit_2253 *jrt.String = jrt.Intern("clauses")

var Lit_2254 *jrt.String = jrt.Intern("url")

var Lit_2255 *jrt.String = jrt.Intern("Imports the classes of an (import ...) form into namespace ns, without evaluating code (which\n  the frozen compiler would compile into ns's package, prohibited for java.*). Classes not on the\n  class path or compiled from source (env/*from-source*) go into env/source-imports, as their\n  sources are found by name (§9.2). Returns the class names that could not be imported (a name\n  already mapped to another class).")

var Lit_2256 *jrt.String = jrt.Intern("Evaluates a namespace form of a class forms file: in-ns and import without compiling code.")

var Lit_2257 *jrt.String = jrt.Intern("Looks up the top-level class of internal name n as a source p/C.ae on the class path. Its\n  namespace and import forms are evaluated and its class forms entered as declarations only\n  (headers and members), so code being compiled can refer to them. Returns n when found.")

var Lit_2258 *jrt.String = jrt.Intern("code")

var Lit_2259 *jrt.String = jrt.Intern("Registers an accessor of class o and, as data, the one member instruction it holds, target\n  {:insn :owner :name :desc :itf} (:insn :getfield, :putfield, :getstatic, :putstatic,\n  :invokevirtual, :invokestatic or :invokespecial: what a2g reads, arbace.a2g.access); returns\n  its name. (The JVM's back end also wrote the accessor's bytecode; it is on the branch\n  arbace-for-java-26.)")

var Lit_2260 *jrt.String = jrt.Intern("The enclosing class of the current class through which protected member m is accessible,\n  when the current class itself cannot access it; else nil (javac's needsProtectedAccess and\n  accessClass). `target` is the receiver node of an instance member.")

var Lit_2261 *jrt.String = jrt.Intern("Rewrites a member access that needs a javac accessor into a call of it.")

var Lit_2262 *jrt.String = jrt.Intern("(.m Outer/super args) from a nested class or lambda: javac's access$N01 accessor in Outer.")

var Lit_2263 *jrt.String = jrt.Intern("A static field of the current class holding a Clojure constant: returns {:owner :name :desc}.")

var Lit_2264 *jrt.String = jrt.Intern("A keyword or quoted datum as a constant node (read at class initialization).")

var Lit_2265 *jrt.String = jrt.Intern("A collection literal: built by arbace.lang.RT/vector, map or set from its boxed elements.")
