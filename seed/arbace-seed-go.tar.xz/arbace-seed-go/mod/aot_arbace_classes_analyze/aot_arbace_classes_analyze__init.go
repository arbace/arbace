//line aot_arbace_classes_analyze__init.ae:1
package aot_arbace_classes_analyze

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_analyze__init_part0_A_Unit0__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_classes_analyze__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_analyze__init_part0_A_const_1) }
//line :1:1
func A_arbace_classes_analyze__init_part0_A_Unit1__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_classes_analyze__init_part0_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_2)) }
//line :1:1
func A_arbace_classes_analyze__init_part0_A_Unit2__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_classes_analyze_eval1549000004_loading__1927001464__auto____1549000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_classes_analyze_eval1549000004_loading__1927001464__auto____1549000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_866, false, nil); A_arbace_classes_analyze_eval1549000004_loading__1927001464__auto____1549000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_classes_analyze__init_part0_A_Unit3__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_classes_analyze__init_part0_A_const_1)).Equals_O__Z(A_arbace_classes_analyze__init_part0_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_classes_analyze_eval1549000008_fn__1549000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_classes_analyze_eval1549000008_fn__1549000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_867, false, nil); A_arbace_classes_analyze_eval1549000008_fn__1549000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }
//line :1:1
func A_arbace_classes_analyze__init_part0_A_Init__O() any { A_arbace_classes_analyze__init_part0_A_Init(); return nil }
//line :1:1
func A_arbace_classes_analyze__init_part0_A_Load__O() any { A_arbace_classes_analyze__init_part0_A_Init(); A_arbace_classes_analyze__init_part0_A_Unit0__O(); A_arbace_classes_analyze__init_part0_A_Unit1__O(); A_arbace_classes_analyze__init_part0_A_Unit2__O(); A_arbace_classes_analyze__init_part0_A_Unit3__O(); A_arbace_classes_analyze__init_part0_A_Unit4__O(); A_arbace_classes_analyze__init_part0_A_Unit5__O(); A_arbace_classes_analyze__init_part0_A_Unit6__O(); A_arbace_classes_analyze__init_part0_A_Unit7__O(); A_arbace_classes_analyze__init_part0_A_Unit8__O(); A_arbace_classes_analyze__init_part0_A_Unit9__O(); A_arbace_classes_analyze__init_part0_A_Unit10__O(); A_arbace_classes_analyze__init_part0_A_Unit11__O(); A_arbace_classes_analyze__init_part0_A_Unit12__O(); A_arbace_classes_analyze__init_part0_A_Unit13__O(); A_arbace_classes_analyze__init_part0_A_Unit14__O(); A_arbace_classes_analyze__init_part0_A_Unit15__O(); A_arbace_classes_analyze__init_part0_A_Unit16__O(); A_arbace_classes_analyze__init_part0_A_Unit17__O(); A_arbace_classes_analyze__init_part0_A_Unit18__O(); A_arbace_classes_analyze__init_part0_A_Unit19__O(); A_arbace_classes_analyze__init_part0_A_Unit20__O(); A_arbace_classes_analyze__init_part0_A_Unit21__O(); A_arbace_classes_analyze__init_part0_A_Unit22__O(); A_arbace_classes_analyze__init_part0_A_Unit23__O(); A_arbace_classes_analyze__init_part0_A_Unit24__O(); A_arbace_classes_analyze__init_part0_A_Unit25__O(); A_arbace_classes_analyze__init_part0_A_Unit26__O(); A_arbace_classes_analyze__init_part0_A_Unit27__O(); A_arbace_classes_analyze__init_part0_A_Unit28__O(); A_arbace_classes_analyze__init_part0_A_Unit29__O(); A_arbace_classes_analyze__init_part0_A_Unit30__O(); A_arbace_classes_analyze__init_part0_A_Unit31__O(); A_arbace_classes_analyze__init_part0_A_Unit32__O(); A_arbace_classes_analyze__init_part0_A_Unit33__O(); A_arbace_classes_analyze__init_part0_A_Unit34__O(); A_arbace_classes_analyze__init_part0_A_Unit35__O(); A_arbace_classes_analyze__init_part0_A_Unit36__O(); A_arbace_classes_analyze__init_part0_A_Unit37__O(); A_arbace_classes_analyze__init_part0_A_Unit38__O(); A_arbace_classes_analyze__init_part0_A_Unit39__O(); A_arbace_classes_analyze__init_part0_A_Unit40__O(); A_arbace_classes_analyze__init_part0_A_Unit41__O(); A_arbace_classes_analyze__init_part0_A_Unit42__O(); A_arbace_classes_analyze__init_part0_A_Unit43__O(); A_arbace_classes_analyze__init_part0_A_Unit44__O(); A_arbace_classes_analyze__init_part0_A_Unit45__O(); A_arbace_classes_analyze__init_part0_A_Unit46__O(); A_arbace_classes_analyze__init_part0_A_Unit47__O(); A_arbace_classes_analyze__init_part0_A_Unit48__O(); A_arbace_classes_analyze__init_part0_A_Unit49__O(); A_arbace_classes_analyze__init_part0_A_Unit50__O(); A_arbace_classes_analyze__init_part0_A_Unit51__O(); A_arbace_classes_analyze__init_part0_A_Unit52__O(); A_arbace_classes_analyze__init_part0_A_Unit53__O(); A_arbace_classes_analyze__init_part0_A_Unit54__O(); A_arbace_classes_analyze__init_part0_A_Unit55__O(); A_arbace_classes_analyze__init_part0_A_Unit56__O(); A_arbace_classes_analyze__init_part0_A_Unit57__O(); A_arbace_classes_analyze__init_part0_A_Unit58__O(); A_arbace_classes_analyze__init_part0_A_Unit59__O(); A_arbace_classes_analyze__init_part0_A_Unit60__O(); A_arbace_classes_analyze__init_part0_A_Unit61__O(); A_arbace_classes_analyze__init_part0_A_Unit62__O(); A_arbace_classes_analyze__init_part0_A_Unit63__O(); A_arbace_classes_analyze__init_part0_A_Unit64__O(); A_arbace_classes_analyze__init_part0_A_Unit65__O(); A_arbace_classes_analyze__init_part0_A_Unit66__O(); A_arbace_classes_analyze__init_part0_A_Unit67__O(); A_arbace_classes_analyze__init_part0_A_Unit68__O(); A_arbace_classes_analyze__init_part0_A_Unit69__O(); A_arbace_classes_analyze__init_part0_A_Unit70__O(); A_arbace_classes_analyze__init_part0_A_Unit71__O(); A_arbace_classes_analyze__init_part0_A_Unit72__O(); A_arbace_classes_analyze__init_part0_A_Unit73__O(); A_arbace_classes_analyze__init_part0_A_Unit74__O(); A_arbace_classes_analyze__init_part0_A_Unit75__O(); A_arbace_classes_analyze__init_part0_A_Unit76__O(); A_arbace_classes_analyze__init_part0_A_Unit77__O(); A_arbace_classes_analyze__init_part0_A_Unit78__O(); A_arbace_classes_analyze__init_part0_A_Unit79__O(); A_arbace_classes_analyze__init_part0_A_Unit80__O(); A_arbace_classes_analyze__init_part0_A_Unit81__O(); A_arbace_classes_analyze__init_part0_A_Unit82__O(); A_arbace_classes_analyze__init_part0_A_Unit83__O(); A_arbace_classes_analyze__init_part0_A_Unit84__O(); A_arbace_classes_analyze__init_part0_A_Unit85__O(); A_arbace_classes_analyze__init_part0_A_Unit86__O(); A_arbace_classes_analyze__init_part0_A_Unit87__O(); A_arbace_classes_analyze__init_part0_A_Unit88__O(); A_arbace_classes_analyze__init_part0_A_Unit89__O(); A_arbace_classes_analyze__init_part0_A_Unit90__O(); A_arbace_classes_analyze__init_part0_A_Unit91__O(); A_arbace_classes_analyze__init_part0_A_Unit92__O(); A_arbace_classes_analyze__init_part0_A_Unit93__O(); A_arbace_classes_analyze__init_part0_A_Unit94__O(); A_arbace_classes_analyze__init_part0_A_Unit95__O(); A_arbace_classes_analyze__init_part0_A_Unit96__O(); A_arbace_classes_analyze__init_part0_A_Unit97__O(); A_arbace_classes_analyze__init_part0_A_Unit98__O(); A_arbace_classes_analyze__init_part0_A_Unit99__O(); return nil }



func A_arbace_classes_analyze__init_A_Load__O() any { jrt.StartCheck(); A_arbace_classes_analyze__init_part0_A_Init__O(); A_arbace_classes_analyze__init_part1_A_Init__O(); A_arbace_classes_analyze__init_part2_A_Init__O(); A_arbace_classes_analyze__init_part3_A_Init__O(); A_arbace_classes_analyze__init_part0_A_Load__O(); A_arbace_classes_analyze__init_part1_A_Load__O(); A_arbace_classes_analyze__init_part2_A_Load__O(); A_arbace_classes_analyze__init_part3_A_Load__O(); return nil }











func A_arbace_classes_analyze__init_part0_A_Unit4__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); A_arbace_classes_analyze__init_part0_A_const_4.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_5)); return A_arbace_classes_analyze__init_part0_A_const_4.SetDynamic_Z__Var(true).Ref() }



func A_arbace_classes_analyze__init_part0_A_Unit5__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(21, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_6; var tmp2 any; var root_5 any = A_arbace_classes_analyze__init_part0_A_const_7.GetRawRoot__O(); var linked_6 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_5, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_7 lang.IFn; if linked_6 == nil { ifn_7 = lang.IFn_Cast(root_5) } else { ifn_7 = nil }; var arg_8 any = A_arbace_classes_analyze__init_part0_A_const_8; if linked_6 == nil { tmp2 = ifn_7.Invoke_O__O(arg_8) } else { tmp2 = linked_6.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_5, arg_8) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_6; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_9)); return A_arbace_classes_analyze__init_part0_A_const_6 }
func A_arbace_classes_analyze__init_part0_A_Unit6__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(22, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_classes_analyze_next_id_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_classes_analyze_next_id_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_868, false, nil); A_arbace_classes_analyze_next_id_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_11)); return A_arbace_classes_analyze__init_part0_A_const_10 }

func A_arbace_classes_analyze__init_part0_A_Unit7__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(24, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_classes_analyze_fail_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_classes_analyze_fail_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_869, false, nil); A_arbace_classes_analyze_fail_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_13)); return A_arbace_classes_analyze__init_part0_A_const_12 }



func A_arbace_classes_analyze__init_part0_A_Unit8__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(28, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_classes_analyze_decl_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_classes_analyze_decl_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_870, false, nil); A_arbace_classes_analyze_decl_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_15)); return A_arbace_classes_analyze__init_part0_A_const_14 }
func A_arbace_classes_analyze__init_part0_A_Unit9__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(29, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_classes_analyze_decl_BANG__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_classes_analyze_decl_BANG__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_871, false, nil); A_arbace_classes_analyze_decl_BANG__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_17)); return A_arbace_classes_analyze__init_part0_A_const_16 }
func A_arbace_classes_analyze__init_part0_A_Unit10__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(30, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_18; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__18 any = A_arbace_classes_analyze_update_decl_BANG__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_classes_analyze_update_decl_BANG__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_872, true, nil); A_arbace_classes_analyze_update_decl_BANG__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__18, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_19)); return A_arbace_classes_analyze__init_part0_A_const_18 }
func A_arbace_classes_analyze__init_part0_A_Unit11__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(31, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_classes_analyze_state_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_classes_analyze_state_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_873, false, nil); A_arbace_classes_analyze_state_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_21)); return A_arbace_classes_analyze__init_part0_A_const_20 }

func A_arbace_classes_analyze__init_part0_A_Unit12__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_classes_analyze_has_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_classes_analyze_has_QMARK__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_874, false, nil); A_arbace_classes_analyze_has_QMARK__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_23)); return A_arbace_classes_analyze__init_part0_A_const_22 }
func A_arbace_classes_analyze__init_part0_A_Unit13__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(34, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_classes_analyze_static_flag_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_classes_analyze_static_flag_QMARK__A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_875, false, nil); A_arbace_classes_analyze_static_flag_QMARK__A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_25)); return A_arbace_classes_analyze__init_part0_A_const_24 }

func A_arbace_classes_analyze__init_part0_A_Unit14__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(36, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_26; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_classes_analyze_nest_host_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_classes_analyze_nest_host_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_876, false, nil); A_arbace_classes_analyze_nest_host_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_27)); return A_arbace_classes_analyze__init_part0_A_const_26 }




func A_arbace_classes_analyze__init_part0_A_Unit15__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(41, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_28; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_classes_analyze_outer_level_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_classes_analyze_outer_level_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_877, false, nil); A_arbace_classes_analyze_outer_level_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_29)); return A_arbace_classes_analyze__init_part0_A_const_28 }





func A_arbace_classes_analyze__init_part0_A_Unit16__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_classes_analyze_capture_field_name_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_classes_analyze_capture_field_name_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_878, false, nil); A_arbace_classes_analyze_capture_field_name_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_31)); return A_arbace_classes_analyze__init_part0_A_const_30 }








func A_arbace_classes_analyze__init_part0_A_Unit17__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(56, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_classes_analyze_this0_name_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_classes_analyze_this0_name_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_879, false, nil); A_arbace_classes_analyze_this0_name_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_33)); return A_arbace_classes_analyze__init_part0_A_const_32 }




func A_arbace_classes_analyze__init_part0_A_Unit18__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(61, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_classes_analyze_ctor_real_desc_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_classes_analyze_ctor_real_desc_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_880, false, nil); A_arbace_classes_analyze_ctor_real_desc_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_35)); return A_arbace_classes_analyze__init_part0_A_const_34 }


















func A_arbace_classes_analyze__init_part0_A_Unit19__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(80, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_classes_analyze_ns_package_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_classes_analyze_ns_package_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_881, false, nil); A_arbace_classes_analyze_ns_package_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_37)); return A_arbace_classes_analyze__init_part0_A_const_36 }




func A_arbace_classes_analyze__init_part0_A_Unit20__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(85, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_38; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_39)); return A_arbace_classes_analyze__init_part0_A_const_38 }

func A_arbace_classes_analyze__init_part0_A_Unit21__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(87, 1); A_arbace_classes_analyze__init_part0_A_const_40.BindRoot_O__V(jrt.Boolean_TRUE.Ref()); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_40; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_41)); return A_arbace_classes_analyze__init_part0_A_const_40.SetDynamic_Z__Var(true).Ref() }





func A_arbace_classes_analyze__init_part0_A_Unit22__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(93, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_classes_analyze_class_exists_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_classes_analyze_class_exists_QMARK__A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_882, false, nil); A_arbace_classes_analyze_class_exists_QMARK__A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_43)); return A_arbace_classes_analyze__init_part0_A_const_42 }



func A_arbace_classes_analyze__init_part0_A_Unit23__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(97, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_classes_analyze_default_import_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_classes_analyze_default_import_QMARK__A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_883, false, nil); A_arbace_classes_analyze_default_import_QMARK__A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_45)); return A_arbace_classes_analyze__init_part0_A_const_44 }




func A_arbace_classes_analyze__init_part0_A_Unit24__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(102, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_classes_analyze_resolve_class_sym_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_classes_analyze_resolve_class_sym_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_884, false, nil); A_arbace_classes_analyze_resolve_class_sym_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_47)); return A_arbace_classes_analyze__init_part0_A_const_46 }

























































func A_arbace_classes_analyze__init_part0_A_Unit25__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(160, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_48; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_49)); return A_arbace_classes_analyze__init_part0_A_const_48 }

func A_arbace_classes_analyze__init_part0_A_Unit26__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(162, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_classes_analyze_type_scope_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_classes_analyze_type_scope_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_885, false, nil); A_arbace_classes_analyze_type_scope_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_51)); return A_arbace_classes_analyze__init_part0_A_const_50 }







func A_arbace_classes_analyze__init_part0_A_Unit27__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(170, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_52; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_classes_analyze_class_tparams_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_classes_analyze_class_tparams_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_886, false, nil); A_arbace_classes_analyze_class_tparams_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_53)); return A_arbace_classes_analyze__init_part0_A_const_52 }










func A_arbace_classes_analyze__init_part0_A_Unit28__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(181, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_classes_analyze_implicit_outer_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_classes_analyze_implicit_outer_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_887, false, nil); A_arbace_classes_analyze_implicit_outer_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_54)); return A_arbace_classes_analyze__init_part0_A_const_48 }














func A_arbace_classes_analyze__init_part0_A_Unit29__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(196, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_55; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_classes_analyze_parse_type_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_classes_analyze_parse_type_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_888, false, nil); A_arbace_classes_analyze_parse_type_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_56)); return A_arbace_classes_analyze__init_part0_A_const_55 }
func A_arbace_classes_analyze__init_part0_A_Unit30__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(197, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_57; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_classes_analyze_erase_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_classes_analyze_erase_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_889, false, nil); A_arbace_classes_analyze_erase_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_58)); return A_arbace_classes_analyze__init_part0_A_const_57 }
func A_arbace_classes_analyze__init_part0_A_Unit31__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(198, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_59; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_classes_analyze_type_desc_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_classes_analyze_type_desc_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_890, false, nil); A_arbace_classes_analyze_type_desc_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_60)); return A_arbace_classes_analyze__init_part0_A_const_59 }




func A_arbace_classes_analyze__init_part0_A_Unit32__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(203, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_61; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_classes_analyze_class_scope_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_classes_analyze_class_scope_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_891, false, nil); A_arbace_classes_analyze_class_scope_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_62)); return A_arbace_classes_analyze__init_part0_A_const_61 }








func A_arbace_classes_analyze__init_part0_A_Unit33__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(212, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_63; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_classes_analyze_retention_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_classes_analyze_retention_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_892, false, nil); A_arbace_classes_analyze_retention_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_64)); return A_arbace_classes_analyze__init_part0_A_const_63 }













func A_arbace_classes_analyze__init_part0_A_Unit34__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(226, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_65; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_classes_analyze_element_type_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_classes_analyze_element_type_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_893, false, nil); A_arbace_classes_analyze_element_type_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_66)); return A_arbace_classes_analyze__init_part0_A_const_65 }





func A_arbace_classes_analyze__init_part0_A_Unit35__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(232, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_67; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_68)); return A_arbace_classes_analyze__init_part0_A_const_67 }

func A_arbace_classes_analyze__init_part0_A_Unit36__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(234, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_69; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_classes_analyze_ann_value_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_classes_analyze_ann_value_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_894, false, nil); A_arbace_classes_analyze_ann_value_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_70)); return A_arbace_classes_analyze__init_part0_A_const_69 }



























func A_arbace_classes_analyze__init_part0_A_Unit37__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(262, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_71; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_72)); return A_arbace_classes_analyze__init_part0_A_const_71 }

func A_arbace_classes_analyze__init_part0_A_Unit38__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(264, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_73; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_classes_analyze_annotations_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_classes_analyze_annotations_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_895, false, nil); A_arbace_classes_analyze_annotations_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_74)); return A_arbace_classes_analyze__init_part0_A_const_73 }





func A_arbace_classes_analyze__init_part0_A_Unit39__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(270, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_75; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_classes_analyze_annotation_targets_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_classes_analyze_annotation_targets_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_896, false, nil); A_arbace_classes_analyze_annotation_targets_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_76)); return A_arbace_classes_analyze__init_part0_A_const_75 }












func A_arbace_classes_analyze__init_part0_A_Unit40__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(283, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_77; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_classes_analyze_for_target_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_classes_analyze_for_target_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_897, false, nil); A_arbace_classes_analyze_for_target_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_78)); return A_arbace_classes_analyze__init_part0_A_const_77 }







func A_arbace_classes_analyze__init_part0_A_Unit41__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(291, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_71; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_79)); return A_arbace_classes_analyze__init_part0_A_const_71 }

func A_arbace_classes_analyze__init_part0_A_Unit42__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(293, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_80; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_classes_analyze_decl_annotations_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_classes_analyze_decl_annotations_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_898, false, nil); A_arbace_classes_analyze_decl_annotations_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_81)); return A_arbace_classes_analyze__init_part0_A_const_80 }









func A_arbace_classes_analyze__init_part0_A_Unit43__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(303, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_82; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_classes_analyze_type_annotations_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_classes_analyze_type_annotations_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_899, false, nil); A_arbace_classes_analyze_type_annotations_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_83)); return A_arbace_classes_analyze__init_part0_A_const_82 }















func A_arbace_classes_analyze__init_part0_A_Unit44__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(319, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_84; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_classes_analyze_tparam_type_annotations_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_classes_analyze_tparam_type_annotations_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_900, false, nil); A_arbace_classes_analyze_tparam_type_annotations_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_85)); return A_arbace_classes_analyze__init_part0_A_const_84 }



























func A_arbace_classes_analyze__init_part0_A_Unit45__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(347, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_71; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_classes_analyze_annotations_now_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_classes_analyze_annotations_now_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_901, false, nil); A_arbace_classes_analyze_annotations_now_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_86)); return A_arbace_classes_analyze__init_part0_A_const_71 }

















func A_arbace_classes_analyze__init_part0_A_Unit46__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(365, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_87; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_classes_analyze_top_name_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_classes_analyze_top_name_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_902, false, nil); A_arbace_classes_analyze_top_name_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_88)); return A_arbace_classes_analyze__init_part0_A_const_87 }







func A_arbace_classes_analyze__init_part0_A_Unit47__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(373, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_89; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_classes_analyze_local_class_name_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_classes_analyze_local_class_name_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_903, false, nil); A_arbace_classes_analyze_local_class_name_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_89; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_90)); return A_arbace_classes_analyze__init_part0_A_const_89 }






func A_arbace_classes_analyze__init_part0_A_Unit48__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(380, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_91; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_classes_analyze_declare_class_BANG__A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_classes_analyze_declare_class_BANG__A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_904, false, nil); A_arbace_classes_analyze_declare_class_BANG__A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_92)); return A_arbace_classes_analyze__init_part0_A_const_91 }









































func A_arbace_classes_analyze__init_part0_A_Unit49__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(422, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_93; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_classes_analyze_bounds_of_scope_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_classes_analyze_bounds_of_scope_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_905, false, nil); A_arbace_classes_analyze_bounds_of_scope_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_94)); return A_arbace_classes_analyze__init_part0_A_const_93 }








func A_arbace_classes_analyze__init_part0_A_Unit50__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(431, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_95; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__86 any = A_arbace_classes_analyze_set_own_bounds_BANG__A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_classes_analyze_set_own_bounds_BANG__A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_906, true, nil); A_arbace_classes_analyze_set_own_bounds_BANG__A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__86, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_96)); return A_arbace_classes_analyze__init_part0_A_const_95 }







func A_arbace_classes_analyze__init_part0_A_Unit51__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(439, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_97; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_classes_analyze_resolve_header_BANG__A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_classes_analyze_resolve_header_BANG__A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_907, false, nil); A_arbace_classes_analyze_resolve_header_BANG__A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_98)); return A_arbace_classes_analyze__init_part0_A_const_97 }























































func A_arbace_classes_analyze__init_part0_A_Unit52__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(495, 1); A_arbace_classes_analyze__init_part0_A_const_99.BindRoot_O__V(A_arbace_classes_analyze__init_part0_A_const_100); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_99; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_101)); return A_arbace_classes_analyze__init_part0_A_const_99 }
func A_arbace_classes_analyze__init_part0_A_Unit53__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(496, 1); A_arbace_classes_analyze__init_part0_A_const_102.BindRoot_O__V(A_arbace_classes_analyze__init_part0_A_const_103); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_102; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_104)); return A_arbace_classes_analyze__init_part0_A_const_102 }


func A_arbace_classes_analyze__init_part0_A_Unit54__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(499, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_105; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_classes_analyze_deprecated_flag_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_classes_analyze_deprecated_flag_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_908, false, nil); A_arbace_classes_analyze_deprecated_flag_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_106)); return A_arbace_classes_analyze__init_part0_A_const_105 }



func A_arbace_classes_analyze__init_part0_A_Unit55__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(503, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_107; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_classes_analyze_iface_kind_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_classes_analyze_iface_kind_QMARK__A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_909, false, nil); A_arbace_classes_analyze_iface_kind_QMARK__A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_107; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_108)); return A_arbace_classes_analyze__init_part0_A_const_107 }

func A_arbace_classes_analyze__init_part0_A_Unit56__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(505, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_109; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_classes_analyze_tag_of_A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_classes_analyze_tag_of_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_910, false, nil); A_arbace_classes_analyze_tag_of_A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_109; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_110)); return A_arbace_classes_analyze__init_part0_A_const_109 }

func A_arbace_classes_analyze__init_part0_A_Unit57__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(507, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_111; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_classes_analyze_param_info_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_classes_analyze_param_info_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_911, false, nil); A_arbace_classes_analyze_param_info_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_112)); return A_arbace_classes_analyze__init_part0_A_const_111 }




func A_arbace_classes_analyze__init_part0_A_Unit58__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(512, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_113; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_classes_analyze_infer_signature_A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_classes_analyze_infer_signature_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_912, false, nil); A_arbace_classes_analyze_infer_signature_A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_114)); return A_arbace_classes_analyze__init_part0_A_const_113 }














func A_arbace_classes_analyze__init_part0_A_Unit59__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(527, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_115; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_classes_analyze_clojure_implementables_A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_classes_analyze_clojure_implementables_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_913, false, nil); A_arbace_classes_analyze_clojure_implementables_A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_115; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_116)); return A_arbace_classes_analyze__init_part0_A_const_115 }











func A_arbace_classes_analyze__init_part0_A_Unit60__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(539, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_117; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_classes_analyze_clojure_overrideables_A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_classes_analyze_clojure_overrideables_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_914, false, nil); A_arbace_classes_analyze_clojure_overrideables_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_117; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_118)); return A_arbace_classes_analyze__init_part0_A_const_117 }

















func A_arbace_classes_analyze__init_part0_A_Unit61__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(557, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_119; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_classes_analyze_clojure_bridges_A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_classes_analyze_clojure_bridges_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_915, false, nil); A_arbace_classes_analyze_clojure_bridges_A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_119; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_120)); return A_arbace_classes_analyze__init_part0_A_const_119 }





















func A_arbace_classes_analyze__init_part0_A_Unit62__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(579, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_121; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_classes_analyze_clojure_tag_desc_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_classes_analyze_clojure_tag_desc_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_916, false, nil); A_arbace_classes_analyze_clojure_tag_desc_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_122)); return A_arbace_classes_analyze__init_part0_A_const_121 }







func A_arbace_classes_analyze__init_part0_A_Unit63__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(587, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_123; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_classes_analyze_class_name_of_A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_classes_analyze_class_name_of_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_917, false, nil); A_arbace_classes_analyze_class_name_of_A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_124)); return A_arbace_classes_analyze__init_part0_A_const_123 }




func A_arbace_classes_analyze__init_part0_A_Unit64__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(592, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_125; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_classes_analyze_clojure_override_A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_classes_analyze_clojure_override_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_918, false, nil); A_arbace_classes_analyze_clojure_override_A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_126)); return A_arbace_classes_analyze__init_part0_A_const_125 }



























func A_arbace_classes_analyze__init_part0_A_Unit65__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(620, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_127; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_classes_analyze_method_scope_A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_classes_analyze_method_scope_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_919, false, nil); A_arbace_classes_analyze_method_scope_A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_128)); return A_arbace_classes_analyze__init_part0_A_const_127 }





func A_arbace_classes_analyze__init_part0_A_Unit66__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(626, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_129; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_classes_analyze_method_signature_A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_classes_analyze_method_signature_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_920, false, nil); A_arbace_classes_analyze_method_signature_A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_130)); return A_arbace_classes_analyze__init_part0_A_const_129 }







func A_arbace_classes_analyze__init_part0_A_Unit67__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(634, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_131; var tmp2 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_classes_analyze_method_type_annotations_A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_classes_analyze_method_type_annotations_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_921, false, nil); A_arbace_classes_analyze_method_type_annotations_A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_132)); return A_arbace_classes_analyze__init_part0_A_const_131 }





















func A_arbace_classes_analyze__init_part0_A_Unit68__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(656, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_133; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_classes_analyze_enter_method_A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_classes_analyze_enter_method_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_922, false, nil); A_arbace_classes_analyze_enter_method_A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_134)); return A_arbace_classes_analyze__init_part0_A_const_133 }





















































func A_arbace_classes_analyze__init_part0_A_Unit69__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(710, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_135; var tmp2 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_classes_analyze_class_access_A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_classes_analyze_class_access_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_923, false, nil); A_arbace_classes_analyze_class_access_A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_136)); return A_arbace_classes_analyze__init_part0_A_const_135 }


func A_arbace_classes_analyze__init_part0_A_Unit70__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(713, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_137; var tmp2 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_classes_analyze_enter_ctor_A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_classes_analyze_enter_ctor_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_924, false, nil); A_arbace_classes_analyze_enter_ctor_A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_138)); return A_arbace_classes_analyze__init_part0_A_const_137 }























func A_arbace_classes_analyze__init_part0_A_Unit71__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(737, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_139; var tmp2 *lang.Compiler_AOTFn; var fnbody__124 any = A_arbace_classes_analyze_enter_field_A_New(); var tmp3 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_classes_analyze_enter_field_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_925, false, nil); A_arbace_classes_analyze_enter_field_A_fn_class = fncls__123d; tmp3 = fncls__123d } else { tmp3 = fncls__123 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__124, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_139; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_140)); return A_arbace_classes_analyze__init_part0_A_const_139 }
















func A_arbace_classes_analyze__init_part0_A_Unit72__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(754, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_141; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__126 any = A_arbace_classes_analyze_derived_method_A_New(); var tmp3 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_classes_analyze_derived_method_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_926, true, nil); A_arbace_classes_analyze_derived_method_A_fn_class = fncls__125d; tmp3 = fncls__125d } else { tmp3 = fncls__125 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__126, tmp3, nil, 5); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_141; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_142)); return A_arbace_classes_analyze__init_part0_A_const_141 }





func A_arbace_classes_analyze__init_part0_A_Unit73__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(760, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_143; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_144)); return A_arbace_classes_analyze__init_part0_A_const_143 }

func A_arbace_classes_analyze__init_part0_A_Unit74__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(762, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_143; var tmp2 *lang.Compiler_AOTFn; var fnbody__128 any = A_arbace_classes_analyze_resolve_members_BANG__A_New(); var tmp3 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_classes_analyze_resolve_members_BANG__A_fn_class; if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_927, false, nil); A_arbace_classes_analyze_resolve_members_BANG__A_fn_class = fncls__127d; tmp3 = fncls__127d } else { tmp3 = fncls__127 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__128, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_143; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_145)); return A_arbace_classes_analyze__init_part0_A_const_143 }












































































































func A_arbace_classes_analyze__init_part0_A_Unit75__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(871, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_146; var tmp2 *lang.Compiler_AOTFn; var fnbody__130 any = A_arbace_classes_analyze_const_of_type_A_New(); var tmp3 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_classes_analyze_const_of_type_A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_928, false, nil); A_arbace_classes_analyze_const_of_type_A_fn_class = fncls__129d; tmp3 = fncls__129d } else { tmp3 = fncls__129 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__130, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_146; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_147)); return A_arbace_classes_analyze__init_part0_A_const_146 }













func A_arbace_classes_analyze__init_part0_A_Unit76__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(885, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_148; var tmp2 *lang.Compiler_AOTFn; var fnbody__132 any = A_arbace_classes_analyze_fits_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_classes_analyze_fits_QMARK__A_fn_class; if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_929, false, nil); A_arbace_classes_analyze_fits_QMARK__A_fn_class = fncls__131d; tmp3 = fncls__131d } else { tmp3 = fncls__131 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__132, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_148; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_149)); return A_arbace_classes_analyze__init_part0_A_const_148 }









func A_arbace_classes_analyze__init_part0_A_Unit77__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(895, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_150; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__134 any = A_arbace_classes_analyze_const_node_A_New(); var tmp3 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_classes_analyze_const_node_A_fn_class; if fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_930, true, nil); A_arbace_classes_analyze_const_node_A_fn_class = fncls__133d; tmp3 = fncls__133d } else { tmp3 = fncls__133 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__134, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_150; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_151)); return A_arbace_classes_analyze__init_part0_A_const_150 }





func A_arbace_classes_analyze__init_part0_A_Unit78__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(901, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_152; var tmp2 *lang.Compiler_AOTFn; var fnbody__136 any = A_arbace_classes_analyze_value_type_A_New(); var tmp3 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_classes_analyze_value_type_A_fn_class; if fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_931, false, nil); A_arbace_classes_analyze_value_type_A_fn_class = fncls__135d; tmp3 = fncls__135d } else { tmp3 = fncls__135 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__136, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_152; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_153)); return A_arbace_classes_analyze__init_part0_A_const_152 }

func A_arbace_classes_analyze__init_part0_A_Unit79__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(903, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_154; tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_52, A_arbace_classes_analyze__init_part0_A_const_155, Lit_51, A_arbace_classes_analyze__init_part0_A_const_156, Lit_46, A_arbace_classes_analyze__init_part0_A_const_157, Lit_48, A_arbace_classes_analyze__init_part0_A_const_158, Lit_47, A_arbace_classes_analyze__init_part0_A_const_159, Lit_50, A_arbace_classes_analyze__init_part0_A_const_160, Lit_49, lang.PersistentHashSet_EMPTY.Ref(), Lit_45, lang.PersistentHashSet_EMPTY.Ref()))); var tmp2 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_154; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_161)); return A_arbace_classes_analyze__init_part0_A_const_154 }



func A_arbace_classes_analyze__init_part0_A_Unit80__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(907, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_162; var tmp2 *lang.Compiler_AOTFn; var fnbody__138 any = A_arbace_classes_analyze_widens_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__137 *jrt.Class = A_arbace_classes_analyze_widens_QMARK__A_fn_class; if fncls__137 == nil { var fncls__137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_932, false, nil); A_arbace_classes_analyze_widens_QMARK__A_fn_class = fncls__137d; tmp3 = fncls__137d } else { tmp3 = fncls__137 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__138, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_162; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_163)); return A_arbace_classes_analyze__init_part0_A_const_162 }

func A_arbace_classes_analyze__init_part0_A_Unit81__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(909, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_164; var tmp2 *lang.Compiler_AOTFn; var fnbody__140 any = A_arbace_classes_analyze_boxed_desc_A_New(); var tmp3 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_classes_analyze_boxed_desc_A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_933, false, nil); A_arbace_classes_analyze_boxed_desc_A_fn_class = fncls__139d; tmp3 = fncls__139d } else { tmp3 = fncls__139 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__140, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_164; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_165)); return A_arbace_classes_analyze__init_part0_A_const_164 }

func A_arbace_classes_analyze__init_part0_A_Unit82__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(911, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_166; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_167)); return A_arbace_classes_analyze__init_part0_A_const_166 }

func A_arbace_classes_analyze__init_part0_A_Unit83__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(913, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_168; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__142 any = A_arbace_classes_analyze_conversion_A_New(); var tmp3 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_classes_analyze_conversion_A_fn_class; if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_934, true, nil); A_arbace_classes_analyze_conversion_A_fn_class = fncls__141d; tmp3 = fncls__141d } else { tmp3 = fncls__141 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__142, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_168; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_169)); return A_arbace_classes_analyze__init_part0_A_const_168 }






























func A_arbace_classes_analyze__init_part0_A_Unit84__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(944, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_170; var tmp2 *lang.Compiler_AOTFn; var fnbody__144 any = A_arbace_classes_analyze_unify_A_New(); var tmp3 *jrt.Class; var fncls__143 *jrt.Class = A_arbace_classes_analyze_unify_A_fn_class; if fncls__143 == nil { var fncls__143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_935, false, nil); A_arbace_classes_analyze_unify_A_fn_class = fncls__143d; tmp3 = fncls__143d } else { tmp3 = fncls__143 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__144, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_170; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_171)); return A_arbace_classes_analyze__init_part0_A_const_170 }
















func A_arbace_classes_analyze__init_part0_A_Unit85__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(961, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_172; var tmp2 *lang.Compiler_AOTFn; var fnbody__146 any = A_arbace_classes_analyze_literal_tail_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__145 *jrt.Class = A_arbace_classes_analyze_literal_tail_QMARK__A_fn_class; if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_936, false, nil); A_arbace_classes_analyze_literal_tail_QMARK__A_fn_class = fncls__145d; tmp3 = fncls__145d } else { tmp3 = fncls__145 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__146, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_172; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_173)); return A_arbace_classes_analyze__init_part0_A_const_172 }
















func A_arbace_classes_analyze__init_part0_A_Unit86__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(978, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_166; var tmp2 *lang.Compiler_AOTFn; var fnbody__148 any = A_arbace_classes_analyze_literal_tail_vals_A_New(); var tmp3 *jrt.Class; var fncls__147 *jrt.Class = A_arbace_classes_analyze_literal_tail_vals_A_fn_class; if fncls__147 == nil { var fncls__147d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_937, false, nil); A_arbace_classes_analyze_literal_tail_vals_A_fn_class = fncls__147d; tmp3 = fncls__147d } else { tmp3 = fncls__147 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__148, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_166; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_174)); return A_arbace_classes_analyze__init_part0_A_const_166 }


















func A_arbace_classes_analyze__init_part0_A_Unit87__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(997, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_175; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_176)); return A_arbace_classes_analyze__init_part0_A_const_175 }

func A_arbace_classes_analyze__init_part0_A_Unit88__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(999, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_177; var tmp2 *lang.Compiler_AOTFn; var fnbody__150 any = A_arbace_classes_analyze_literal_branch_A_New(); var tmp3 *jrt.Class; var fncls__149 *jrt.Class = A_arbace_classes_analyze_literal_branch_A_fn_class; if fncls__149 == nil { var fncls__149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_938, false, nil); A_arbace_classes_analyze_literal_branch_A_fn_class = fncls__149d; tmp3 = fncls__149d } else { tmp3 = fncls__149 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__150, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_177; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_178)); return A_arbace_classes_analyze__init_part0_A_const_177 }






func A_arbace_classes_analyze__init_part0_A_Unit89__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1006, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_179; var tmp2 *lang.Compiler_AOTFn; var fnbody__152 any = A_arbace_classes_analyze_unify_nodes_A_New(); var tmp3 *jrt.Class; var fncls__151 *jrt.Class = A_arbace_classes_analyze_unify_nodes_A_fn_class; if fncls__151 == nil { var fncls__151d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_939, false, nil); A_arbace_classes_analyze_unify_nodes_A_fn_class = fncls__151d; tmp3 = fncls__151d } else { tmp3 = fncls__151 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__152, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_179; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_180)); return A_arbace_classes_analyze__init_part0_A_const_179 }




























func A_arbace_classes_analyze__init_part0_A_Unit90__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1035, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_181; var tmp2 *lang.Compiler_AOTFn; var fnbody__154 any = A_arbace_classes_analyze_new_frame_A_New(); var tmp3 *jrt.Class; var fncls__153 *jrt.Class = A_arbace_classes_analyze_new_frame_A_fn_class; if fncls__153 == nil { var fncls__153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_940, false, nil); A_arbace_classes_analyze_new_frame_A_fn_class = fncls__153d; tmp3 = fncls__153d } else { tmp3 = fncls__153 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__154, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_181; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_182)); return A_arbace_classes_analyze__init_part0_A_const_181 }


func A_arbace_classes_analyze__init_part0_A_Unit91__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1038, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_183; var tmp2 *lang.Compiler_AOTFn; var fnbody__156 any = A_arbace_classes_analyze_prologue_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__155 *jrt.Class = A_arbace_classes_analyze_prologue_QMARK__A_fn_class; if fncls__155 == nil { var fncls__155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_941, false, nil); A_arbace_classes_analyze_prologue_QMARK__A_fn_class = fncls__155d; tmp3 = fncls__155d } else { tmp3 = fncls__155 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__156, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_183; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_184)); return A_arbace_classes_analyze__init_part0_A_const_183 }




func A_arbace_classes_analyze__init_part0_A_Unit92__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1043, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_185; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__158 any = A_arbace_classes_analyze_make_binding_A_New(); var tmp3 *jrt.Class; var fncls__157 *jrt.Class = A_arbace_classes_analyze_make_binding_A_fn_class; if fncls__157 == nil { var fncls__157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_942, true, nil); A_arbace_classes_analyze_make_binding_A_fn_class = fncls__157d; tmp3 = fncls__157d } else { tmp3 = fncls__157 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__158, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_185; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_186)); return A_arbace_classes_analyze__init_part0_A_const_185 }


func A_arbace_classes_analyze__init_part0_A_Unit93__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1046, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_187; var tmp2 *lang.Compiler_AOTFn; var fnbody__160 any = A_arbace_classes_analyze_with_local_A_New(); var tmp3 *jrt.Class; var fncls__159 *jrt.Class = A_arbace_classes_analyze_with_local_A_fn_class; if fncls__159 == nil { var fncls__159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_943, false, nil); A_arbace_classes_analyze_with_local_A_fn_class = fncls__159d; tmp3 = fncls__159d } else { tmp3 = fncls__159 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__160, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_187; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_188)); return A_arbace_classes_analyze__init_part0_A_const_187 }

func A_arbace_classes_analyze__init_part0_A_Unit94__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1048, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_189; var tmp2 *lang.Compiler_AOTFn; var fnbody__162 any = A_arbace_classes_analyze_scope_of_A_New(); var tmp3 *jrt.Class; var fncls__161 *jrt.Class = A_arbace_classes_analyze_scope_of_A_fn_class; if fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_944, false, nil); A_arbace_classes_analyze_scope_of_A_fn_class = fncls__161d; tmp3 = fncls__161d } else { tmp3 = fncls__161 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__162, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_189; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_190)); return A_arbace_classes_analyze__init_part0_A_const_189 }


func A_arbace_classes_analyze__init_part0_A_Unit95__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1051, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_191; var tmp2 *lang.Compiler_AOTFn; var fnbody__164 any = A_arbace_classes_analyze_actx_desc_A_New(); var tmp3 *jrt.Class; var fncls__163 *jrt.Class = A_arbace_classes_analyze_actx_desc_A_fn_class; if fncls__163 == nil { var fncls__163d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_945, false, nil); A_arbace_classes_analyze_actx_desc_A_fn_class = fncls__163d; tmp3 = fncls__163d } else { tmp3 = fncls__163 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__164, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_191; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_192)); return A_arbace_classes_analyze__init_part0_A_const_191 }

func A_arbace_classes_analyze__init_part0_A_Unit96__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1053, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_193; var tmp2 *lang.Compiler_AOTFn; var fnbody__166 any = A_arbace_classes_analyze_resolve_class_A_New(); var tmp3 *jrt.Class; var fncls__165 *jrt.Class = A_arbace_classes_analyze_resolve_class_A_fn_class; if fncls__165 == nil { var fncls__165d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_946, false, nil); A_arbace_classes_analyze_resolve_class_A_fn_class = fncls__165d; tmp3 = fncls__165d } else { tmp3 = fncls__165 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__166, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_193; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_194)); return A_arbace_classes_analyze__init_part0_A_const_193 }


func A_arbace_classes_analyze__init_part0_A_Unit97__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1056, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_195; var tmp2 *lang.Compiler_AOTFn; var fnbody__168 any = A_arbace_classes_analyze_add_capture_BANG__A_New(); var tmp3 *jrt.Class; var fncls__167 *jrt.Class = A_arbace_classes_analyze_add_capture_BANG__A_fn_class; if fncls__167 == nil { var fncls__167d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_947, false, nil); A_arbace_classes_analyze_add_capture_BANG__A_fn_class = fncls__167d; tmp3 = fncls__167d } else { tmp3 = fncls__167 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__168, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_195; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_196)); return A_arbace_classes_analyze__init_part0_A_const_195 }







func A_arbace_classes_analyze__init_part0_A_Unit98__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1064, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_197; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_198)); return A_arbace_classes_analyze__init_part0_A_const_197 }

func A_arbace_classes_analyze__init_part0_A_Unit99__O() any { A_arbace_classes_analyze__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1066, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_199; var tmp2 *lang.Compiler_AOTFn; var fnbody__170 any = A_arbace_classes_analyze_local_ref_A_New(); var tmp3 *jrt.Class; var fncls__169 *jrt.Class = A_arbace_classes_analyze_local_ref_A_fn_class; if fncls__169 == nil { var fncls__169d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_948, false, nil); A_arbace_classes_analyze_local_ref_A_fn_class = fncls__169d; tmp3 = fncls__169d } else { tmp3 = fncls__169 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__170, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part0_A_const_199; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part0_A_const_200)); return A_arbace_classes_analyze__init_part0_A_const_199 }















func A_arbace_classes_analyze__init_part1_A_Unit100__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1082, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_0; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_1)); return A_arbace_classes_analyze__init_part1_A_const_0 }
//line :1082:1
func A_arbace_classes_analyze__init_part1_A_Init__O() any { A_arbace_classes_analyze__init_part1_A_Init(); return nil }
//line :1082:1
func A_arbace_classes_analyze__init_part1_A_Load__O() any { A_arbace_classes_analyze__init_part1_A_Init(); A_arbace_classes_analyze__init_part1_A_Unit100__O(); A_arbace_classes_analyze__init_part1_A_Unit101__O(); A_arbace_classes_analyze__init_part1_A_Unit102__O(); A_arbace_classes_analyze__init_part1_A_Unit103__O(); A_arbace_classes_analyze__init_part1_A_Unit104__O(); A_arbace_classes_analyze__init_part1_A_Unit105__O(); A_arbace_classes_analyze__init_part1_A_Unit106__O(); A_arbace_classes_analyze__init_part1_A_Unit107__O(); A_arbace_classes_analyze__init_part1_A_Unit108__O(); A_arbace_classes_analyze__init_part1_A_Unit109__O(); A_arbace_classes_analyze__init_part1_A_Unit110__O(); A_arbace_classes_analyze__init_part1_A_Unit111__O(); A_arbace_classes_analyze__init_part1_A_Unit112__O(); A_arbace_classes_analyze__init_part1_A_Unit113__O(); A_arbace_classes_analyze__init_part1_A_Unit114__O(); A_arbace_classes_analyze__init_part1_A_Unit115__O(); A_arbace_classes_analyze__init_part1_A_Unit116__O(); A_arbace_classes_analyze__init_part1_A_Unit117__O(); A_arbace_classes_analyze__init_part1_A_Unit118__O(); A_arbace_classes_analyze__init_part1_A_Unit119__O(); A_arbace_classes_analyze__init_part1_A_Unit120__O(); A_arbace_classes_analyze__init_part1_A_Unit121__O(); A_arbace_classes_analyze__init_part1_A_Unit122__O(); A_arbace_classes_analyze__init_part1_A_Unit123__O(); A_arbace_classes_analyze__init_part1_A_Unit124__O(); A_arbace_classes_analyze__init_part1_A_Unit125__O(); A_arbace_classes_analyze__init_part1_A_Unit126__O(); A_arbace_classes_analyze__init_part1_A_Unit127__O(); A_arbace_classes_analyze__init_part1_A_Unit128__O(); A_arbace_classes_analyze__init_part1_A_Unit129__O(); A_arbace_classes_analyze__init_part1_A_Unit130__O(); A_arbace_classes_analyze__init_part1_A_Unit131__O(); A_arbace_classes_analyze__init_part1_A_Unit132__O(); A_arbace_classes_analyze__init_part1_A_Unit133__O(); A_arbace_classes_analyze__init_part1_A_Unit134__O(); A_arbace_classes_analyze__init_part1_A_Unit135__O(); A_arbace_classes_analyze__init_part1_A_Unit136__O(); A_arbace_classes_analyze__init_part1_A_Unit137__O(); A_arbace_classes_analyze__init_part1_A_Unit138__O(); A_arbace_classes_analyze__init_part1_A_Unit139__O(); A_arbace_classes_analyze__init_part1_A_Unit140__O(); A_arbace_classes_analyze__init_part1_A_Unit141__O(); A_arbace_classes_analyze__init_part1_A_Unit142__O(); A_arbace_classes_analyze__init_part1_A_Unit143__O(); A_arbace_classes_analyze__init_part1_A_Unit144__O(); A_arbace_classes_analyze__init_part1_A_Unit145__O(); A_arbace_classes_analyze__init_part1_A_Unit146__O(); A_arbace_classes_analyze__init_part1_A_Unit147__O(); A_arbace_classes_analyze__init_part1_A_Unit148__O(); A_arbace_classes_analyze__init_part1_A_Unit149__O(); A_arbace_classes_analyze__init_part1_A_Unit150__O(); A_arbace_classes_analyze__init_part1_A_Unit151__O(); A_arbace_classes_analyze__init_part1_A_Unit152__O(); A_arbace_classes_analyze__init_part1_A_Unit153__O(); A_arbace_classes_analyze__init_part1_A_Unit154__O(); A_arbace_classes_analyze__init_part1_A_Unit155__O(); A_arbace_classes_analyze__init_part1_A_Unit156__O(); A_arbace_classes_analyze__init_part1_A_Unit157__O(); A_arbace_classes_analyze__init_part1_A_Unit158__O(); A_arbace_classes_analyze__init_part1_A_Unit159__O(); A_arbace_classes_analyze__init_part1_A_Unit160__O(); A_arbace_classes_analyze__init_part1_A_Unit161__O(); A_arbace_classes_analyze__init_part1_A_Unit162__O(); A_arbace_classes_analyze__init_part1_A_Unit163__O(); A_arbace_classes_analyze__init_part1_A_Unit164__O(); A_arbace_classes_analyze__init_part1_A_Unit165__O(); A_arbace_classes_analyze__init_part1_A_Unit166__O(); A_arbace_classes_analyze__init_part1_A_Unit167__O(); A_arbace_classes_analyze__init_part1_A_Unit168__O(); A_arbace_classes_analyze__init_part1_A_Unit169__O(); A_arbace_classes_analyze__init_part1_A_Unit170__O(); A_arbace_classes_analyze__init_part1_A_Unit171__O(); A_arbace_classes_analyze__init_part1_A_Unit172__O(); A_arbace_classes_analyze__init_part1_A_Unit173__O(); A_arbace_classes_analyze__init_part1_A_Unit174__O(); A_arbace_classes_analyze__init_part1_A_Unit175__O(); A_arbace_classes_analyze__init_part1_A_Unit176__O(); A_arbace_classes_analyze__init_part1_A_Unit177__O(); A_arbace_classes_analyze__init_part1_A_Unit178__O(); A_arbace_classes_analyze__init_part1_A_Unit179__O(); A_arbace_classes_analyze__init_part1_A_Unit180__O(); A_arbace_classes_analyze__init_part1_A_Unit181__O(); A_arbace_classes_analyze__init_part1_A_Unit182__O(); A_arbace_classes_analyze__init_part1_A_Unit183__O(); A_arbace_classes_analyze__init_part1_A_Unit184__O(); A_arbace_classes_analyze__init_part1_A_Unit185__O(); A_arbace_classes_analyze__init_part1_A_Unit186__O(); A_arbace_classes_analyze__init_part1_A_Unit187__O(); A_arbace_classes_analyze__init_part1_A_Unit188__O(); A_arbace_classes_analyze__init_part1_A_Unit189__O(); A_arbace_classes_analyze__init_part1_A_Unit190__O(); A_arbace_classes_analyze__init_part1_A_Unit191__O(); A_arbace_classes_analyze__init_part1_A_Unit192__O(); A_arbace_classes_analyze__init_part1_A_Unit193__O(); A_arbace_classes_analyze__init_part1_A_Unit194__O(); A_arbace_classes_analyze__init_part1_A_Unit195__O(); A_arbace_classes_analyze__init_part1_A_Unit196__O(); A_arbace_classes_analyze__init_part1_A_Unit197__O(); A_arbace_classes_analyze__init_part1_A_Unit198__O(); A_arbace_classes_analyze__init_part1_A_Unit199__O(); return nil }

func A_arbace_classes_analyze__init_part1_A_Unit101__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1084, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_2; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_classes_analyze_prologue_class_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_classes_analyze_prologue_class_QMARK__A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_950, false, nil); A_arbace_classes_analyze_prologue_class_QMARK__A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_3)); return A_arbace_classes_analyze__init_part1_A_const_2 }






func A_arbace_classes_analyze__init_part1_A_Unit102__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1091, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_classes_analyze_outer_this_node_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_classes_analyze_outer_this_node_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_951, false, nil); A_arbace_classes_analyze_outer_this_node_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_5)); return A_arbace_classes_analyze__init_part1_A_const_4 }












































func A_arbace_classes_analyze__init_part1_A_Unit103__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1136, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_0; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_classes_analyze_outer_this_node_STAR__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_classes_analyze_outer_this_node_STAR__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_952, false, nil); A_arbace_classes_analyze_outer_this_node_STAR__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_6)); return A_arbace_classes_analyze__init_part1_A_const_0 }
























func A_arbace_classes_analyze__init_part1_A_Unit104__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1161, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_7; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_classes_analyze_class_parent_frame_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_classes_analyze_class_parent_frame_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_953, false, nil); A_arbace_classes_analyze_class_parent_frame_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_7; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_8)); return A_arbace_classes_analyze__init_part1_A_const_7 }













func A_arbace_classes_analyze__init_part1_A_Unit105__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1175, 1); A_arbace_classes_analyze__init_part1_A_const_9.BindRoot_O__V(A_arbace_classes_analyze__init_part1_A_const_10); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_9; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_11)); return A_arbace_classes_analyze__init_part1_A_const_9 }



func A_arbace_classes_analyze__init_part1_A_Unit106__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1179, 1); A_arbace_classes_analyze__init_part1_A_const_12.BindRoot_O__V(A_arbace_classes_analyze__init_part1_A_const_13); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_14)); return A_arbace_classes_analyze__init_part1_A_const_12 }



func A_arbace_classes_analyze__init_part1_A_Unit107__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1183, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_15; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_classes_analyze_core_var_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_classes_analyze_core_var_QMARK__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_954, false, nil); A_arbace_classes_analyze_core_var_QMARK__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_16)); return A_arbace_classes_analyze__init_part1_A_const_15 }


func A_arbace_classes_analyze__init_part1_A_Unit108__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1186, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_17; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_classes_analyze_resolve_var_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_classes_analyze_resolve_var_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_955, false, nil); A_arbace_classes_analyze_resolve_var_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_18)); return A_arbace_classes_analyze__init_part1_A_const_17 }




func A_arbace_classes_analyze__init_part1_A_Unit109__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1191, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_19; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_classes_analyze_core_op_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_classes_analyze_core_op_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_956, false, nil); A_arbace_classes_analyze_core_op_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_20)); return A_arbace_classes_analyze__init_part1_A_const_19 }





func A_arbace_classes_analyze__init_part1_A_Unit110__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1197, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_21; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_classes_analyze_macroexpand1_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_classes_analyze_macroexpand1_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_957, false, nil); A_arbace_classes_analyze_macroexpand1_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_22)); return A_arbace_classes_analyze__init_part1_A_const_21 }


















func A_arbace_classes_analyze__init_part1_A_Unit111__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1216, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_23; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_24)); return A_arbace_classes_analyze__init_part1_A_const_23 }

func A_arbace_classes_analyze__init_part1_A_Unit112__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1218, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_25; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_26)); return A_arbace_classes_analyze__init_part1_A_const_25 }
//line :1218:1
func A_arbace_classes_analyze__init_part1_A_Unit113__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1218, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_27; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_28)); return A_arbace_classes_analyze__init_part1_A_const_27 }
//line :1218:1
func A_arbace_classes_analyze__init_part1_A_Unit114__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1218, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_29; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_30)); return A_arbace_classes_analyze__init_part1_A_const_29 }

func A_arbace_classes_analyze__init_part1_A_Unit115__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1220, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_31; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_32)); return A_arbace_classes_analyze__init_part1_A_const_31 }
//line :1220:1
func A_arbace_classes_analyze__init_part1_A_Unit116__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1220, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_33; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_34)); return A_arbace_classes_analyze__init_part1_A_const_33 }
//line :1220:1
func A_arbace_classes_analyze__init_part1_A_Unit117__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1220, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_35; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_36)); return A_arbace_classes_analyze__init_part1_A_const_35 }

func A_arbace_classes_analyze__init_part1_A_Unit118__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1222, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_37; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_38)); return A_arbace_classes_analyze__init_part1_A_const_37 }
//line :1222:1
func A_arbace_classes_analyze__init_part1_A_Unit119__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1222, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_39; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_40)); return A_arbace_classes_analyze__init_part1_A_const_39 }
//line :1222:1
func A_arbace_classes_analyze__init_part1_A_Unit120__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1222, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_41; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_42)); return A_arbace_classes_analyze__init_part1_A_const_41 }
//line :1222:1
func A_arbace_classes_analyze__init_part1_A_Unit121__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1222, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_43; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_44)); return A_arbace_classes_analyze__init_part1_A_const_43 }
//line :1222:1
func A_arbace_classes_analyze__init_part1_A_Unit122__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1222, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_45; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_46)); return A_arbace_classes_analyze__init_part1_A_const_45 }
//line :1222:1
func A_arbace_classes_analyze__init_part1_A_Unit123__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1222, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_47; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_48)); return A_arbace_classes_analyze__init_part1_A_const_47 }
//line :1222:1
func A_arbace_classes_analyze__init_part1_A_Unit124__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1222, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_49; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_50)); return A_arbace_classes_analyze__init_part1_A_const_49 }
//line :1222:1
func A_arbace_classes_analyze__init_part1_A_Unit125__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1222, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_51; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_52)); return A_arbace_classes_analyze__init_part1_A_const_51 }
//line :1222:1
func A_arbace_classes_analyze__init_part1_A_Unit126__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1222, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_53; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_54)); return A_arbace_classes_analyze__init_part1_A_const_53 }
//line :1222:1
func A_arbace_classes_analyze__init_part1_A_Unit127__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1222, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_55; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_56)); return A_arbace_classes_analyze__init_part1_A_const_55 }
//line :1222:1
func A_arbace_classes_analyze__init_part1_A_Unit128__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1222, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_57; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_58)); return A_arbace_classes_analyze__init_part1_A_const_57 }


func A_arbace_classes_analyze__init_part1_A_Unit129__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1225, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_59; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_classes_analyze_with_form_info_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_classes_analyze_with_form_info_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_958, false, nil); A_arbace_classes_analyze_with_form_info_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_60)); return A_arbace_classes_analyze__init_part1_A_const_59 }







func A_arbace_classes_analyze__init_part1_A_Unit130__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1233, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_37; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_classes_analyze_analyze_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_classes_analyze_analyze_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_959, false, nil); A_arbace_classes_analyze_analyze_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_61)); return A_arbace_classes_analyze__init_part1_A_const_37 }




































func A_arbace_classes_analyze__init_part1_A_Unit131__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1270, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_62; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_63)); return A_arbace_classes_analyze__init_part1_A_const_62 }
//line :1270:1
func A_arbace_classes_analyze__init_part1_A_Unit132__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1270, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_64; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_65)); return A_arbace_classes_analyze__init_part1_A_const_64 }

func A_arbace_classes_analyze__init_part1_A_Unit133__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1272, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_53; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_classes_analyze_coerce_hint_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_classes_analyze_coerce_hint_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_960, false, nil); A_arbace_classes_analyze_coerce_hint_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_66)); return A_arbace_classes_analyze__init_part1_A_const_53 }
























func A_arbace_classes_analyze__init_part1_A_Unit134__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1297, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_39; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_classes_analyze_analyze_body_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_classes_analyze_analyze_body_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_961, false, nil); A_arbace_classes_analyze_analyze_body_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_67)); return A_arbace_classes_analyze__init_part1_A_const_39 }













func A_arbace_classes_analyze__init_part1_A_Unit135__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1311, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_68; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_classes_analyze_field_node_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_classes_analyze_field_node_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_962, false, nil); A_arbace_classes_analyze_field_node_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_69)); return A_arbace_classes_analyze__init_part1_A_const_68 }















func A_arbace_classes_analyze__init_part1_A_Unit136__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1327, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_70; tmp1.BindRoot_O__V(jrt.ConcurrentHashMap_New()); var tmp2 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_70; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_71)); return A_arbace_classes_analyze__init_part1_A_const_70 }




func A_arbace_classes_analyze__init_part1_A_Unit137__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1332, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_72; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_classes_analyze_field_index_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_classes_analyze_field_index_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_963, false, nil); A_arbace_classes_analyze_field_index_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_73)); return A_arbace_classes_analyze__init_part1_A_const_72 }
















func A_arbace_classes_analyze__init_part1_A_Unit138__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1349, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_74; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_classes_analyze_find_own_field_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_classes_analyze_find_own_field_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_964, false, nil); A_arbace_classes_analyze_find_own_field_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_75)); return A_arbace_classes_analyze__init_part1_A_const_74 }





















func A_arbace_classes_analyze__init_part1_A_Unit139__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1371, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_76; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_classes_analyze_this_node_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_classes_analyze_this_node_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_965, false, nil); A_arbace_classes_analyze_this_node_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_77)); return A_arbace_classes_analyze__init_part1_A_const_76 }



func A_arbace_classes_analyze__init_part1_A_Unit140__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1375, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_78; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_classes_analyze_class_lit_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_classes_analyze_class_lit_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_966, false, nil); A_arbace_classes_analyze_class_lit_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_79)); return A_arbace_classes_analyze__init_part1_A_const_78 }


func A_arbace_classes_analyze__init_part1_A_Unit141__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1378, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_classes_analyze_analyze_symbol_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_classes_analyze_analyze_symbol_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_967, false, nil); A_arbace_classes_analyze_analyze_symbol_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_80)); return A_arbace_classes_analyze__init_part1_A_const_51 }

























































func A_arbace_classes_analyze__init_part1_A_Unit142__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1436, 1); A_arbace_classes_analyze__init_part1_A_const_81.BindRoot_O__V(A_arbace_classes_analyze__init_part1_A_const_82); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_81; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_83)); return A_arbace_classes_analyze__init_part1_A_const_81 }





















func A_arbace_classes_analyze__init_part1_A_Unit143__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1458, 1); A_arbace_classes_analyze__init_part1_A_const_84.BindRoot_O__V(A_arbace_classes_analyze__init_part1_A_const_85); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_84; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_86)); return A_arbace_classes_analyze__init_part1_A_const_84 }



func A_arbace_classes_analyze__init_part1_A_Unit144__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1462, 1); A_arbace_classes_analyze__init_part1_A_const_87.BindRoot_O__V(A_arbace_classes_analyze__init_part1_A_const_88); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_87; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_89)); return A_arbace_classes_analyze__init_part1_A_const_87 }


func A_arbace_classes_analyze__init_part1_A_Unit145__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1465, 1); A_arbace_classes_analyze__init_part1_A_const_90.BindRoot_O__V(A_arbace_classes_analyze__init_part1_A_const_91); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_90; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_92)); return A_arbace_classes_analyze__init_part1_A_const_90 }

func A_arbace_classes_analyze__init_part1_A_Unit146__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1467, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_93; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_classes_analyze_unboxed_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_classes_analyze_unboxed_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_968, false, nil); A_arbace_classes_analyze_unboxed_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_94)); return A_arbace_classes_analyze__init_part1_A_const_93 }





func A_arbace_classes_analyze__init_part1_A_Unit147__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1473, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_95; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_classes_analyze_prim_type_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_classes_analyze_prim_type_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_969, false, nil); A_arbace_classes_analyze_prim_type_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_96)); return A_arbace_classes_analyze__init_part1_A_const_95 }

func A_arbace_classes_analyze__init_part1_A_Unit148__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1475, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_97; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_classes_analyze_prim_type_of_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_classes_analyze_prim_type_of_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_970, false, nil); A_arbace_classes_analyze_prim_type_of_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_98)); return A_arbace_classes_analyze__init_part1_A_const_97 }




func A_arbace_classes_analyze__init_part1_A_Unit149__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1480, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_99; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_classes_analyze_clone_tail_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_classes_analyze_clone_tail_QMARK__A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_971, false, nil); A_arbace_classes_analyze_clone_tail_QMARK__A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_99; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_100)); return A_arbace_classes_analyze__init_part1_A_const_99 }








func A_arbace_classes_analyze__init_part1_A_Unit150__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1489, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_101; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_classes_analyze_retype_clone_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_classes_analyze_retype_clone_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_972, false, nil); A_arbace_classes_analyze_retype_clone_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_102)); return A_arbace_classes_analyze__init_part1_A_const_101 }







func A_arbace_classes_analyze__init_part1_A_Unit151__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1497, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_62; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_classes_analyze_branching_tail_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_classes_analyze_branching_tail_QMARK__A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_973, false, nil); A_arbace_classes_analyze_branching_tail_QMARK__A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_103)); return A_arbace_classes_analyze__init_part1_A_const_62 }









func A_arbace_classes_analyze__init_part1_A_Unit152__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1507, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_104; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_classes_analyze_bound_node_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_classes_analyze_bound_node_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_974, false, nil); A_arbace_classes_analyze_bound_node_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_104; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_105)); return A_arbace_classes_analyze__init_part1_A_const_104 }









func A_arbace_classes_analyze__init_part1_A_Unit153__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1517, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_64; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__52 any = A_arbace_classes_analyze_convert_node_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_classes_analyze_convert_node_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_975, true, nil); A_arbace_classes_analyze_convert_node_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__52, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_106)); return A_arbace_classes_analyze__init_part1_A_const_64 }
















































func A_arbace_classes_analyze__init_part1_A_Unit154__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1566, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_107; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_classes_analyze_operand_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_classes_analyze_operand_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_976, false, nil); A_arbace_classes_analyze_operand_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_107; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_108)); return A_arbace_classes_analyze__init_part1_A_const_107 }

















func A_arbace_classes_analyze__init_part1_A_Unit155__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1584, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_109; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_classes_analyze_int_operand_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_classes_analyze_int_operand_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_977, false, nil); A_arbace_classes_analyze_int_operand_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_109; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_110)); return A_arbace_classes_analyze__init_part1_A_const_109 }








func A_arbace_classes_analyze__init_part1_A_Unit156__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1593, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_111; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_classes_analyze_fmod_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_classes_analyze_fmod_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_978, false, nil); A_arbace_classes_analyze_fmod_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_112)); return A_arbace_classes_analyze__init_part1_A_const_111 }








func A_arbace_classes_analyze__init_part1_A_Unit157__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1602, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_113; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_classes_analyze_fold_arith_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_classes_analyze_fold_arith_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_979, false, nil); A_arbace_classes_analyze_fold_arith_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_114)); return A_arbace_classes_analyze__init_part1_A_const_113 }





























func A_arbace_classes_analyze__init_part1_A_Unit158__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1632, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_115; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_classes_analyze_analyze_arith_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_classes_analyze_analyze_arith_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_980, false, nil); A_arbace_classes_analyze_analyze_arith_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_115; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_116)); return A_arbace_classes_analyze__init_part1_A_const_115 }












































func A_arbace_classes_analyze__init_part1_A_Unit159__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1677, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_117; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__64 any = A_arbace_classes_analyze_analyze_conversion_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_classes_analyze_analyze_conversion_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_981, true, nil); A_arbace_classes_analyze_analyze_conversion_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__64, tmp3, nil, 4); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_117; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_118)); return A_arbace_classes_analyze__init_part1_A_const_117 }



























func A_arbace_classes_analyze__init_part1_A_Unit160__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1705, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_119; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_classes_analyze_compare_type_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_classes_analyze_compare_type_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_982, false, nil); A_arbace_classes_analyze_compare_type_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_119; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_120)); return A_arbace_classes_analyze__init_part1_A_const_119 }







func A_arbace_classes_analyze__init_part1_A_Unit161__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1713, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_121; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__68 any = A_arbace_classes_analyze_analyze_compare_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_classes_analyze_analyze_compare_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_983, true, nil); A_arbace_classes_analyze_analyze_compare_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__68, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_122)); return A_arbace_classes_analyze__init_part1_A_const_121 }






















func A_arbace_classes_analyze__init_part1_A_Unit162__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1736, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_123; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_classes_analyze_bool_node_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_classes_analyze_bool_node_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_984, false, nil); A_arbace_classes_analyze_bool_node_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_124)); return A_arbace_classes_analyze__init_part1_A_const_123 }




func A_arbace_classes_analyze__init_part1_A_Unit163__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1741, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_125; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_classes_analyze_lambda_form_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_classes_analyze_lambda_form_QMARK__A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_985, false, nil); A_arbace_classes_analyze_lambda_form_QMARK__A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_126)); return A_arbace_classes_analyze__init_part1_A_const_125 }







func A_arbace_classes_analyze__init_part1_A_Unit164__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1749, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_127; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_128)); return A_arbace_classes_analyze__init_part1_A_const_127 }
//line :1749:1
func A_arbace_classes_analyze__init_part1_A_Unit165__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1749, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_129; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_130)); return A_arbace_classes_analyze__init_part1_A_const_129 }

func A_arbace_classes_analyze__init_part1_A_Unit166__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1751, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_131; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_classes_analyze_local_type_anns_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_classes_analyze_local_type_anns_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_986, false, nil); A_arbace_classes_analyze_local_type_anns_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_132)); return A_arbace_classes_analyze__init_part1_A_const_131 }














func A_arbace_classes_analyze__init_part1_A_Unit167__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1766, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_133; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_classes_analyze_binding_type_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_classes_analyze_binding_type_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_987, false, nil); A_arbace_classes_analyze_binding_type_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_134)); return A_arbace_classes_analyze__init_part1_A_const_133 }













func A_arbace_classes_analyze__init_part1_A_Unit168__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1780, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_135; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_classes_analyze_bind_init_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_classes_analyze_bind_init_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_988, false, nil); A_arbace_classes_analyze_bind_init_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_136)); return A_arbace_classes_analyze__init_part1_A_const_135 }












func A_arbace_classes_analyze__init_part1_A_Unit169__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1793, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_137; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_classes_analyze_analyze_let_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_classes_analyze_analyze_let_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_989, false, nil); A_arbace_classes_analyze_analyze_let_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_138)); return A_arbace_classes_analyze__init_part1_A_const_137 }















































func A_arbace_classes_analyze__init_part1_A_Unit170__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1841, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_139; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_classes_analyze_class_def_in_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_classes_analyze_class_def_in_QMARK__A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_990, false, nil); A_arbace_classes_analyze_class_def_in_QMARK__A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_139; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_140)); return A_arbace_classes_analyze__init_part1_A_const_139 }





func A_arbace_classes_analyze__init_part1_A_Unit171__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1847, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_141; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_classes_analyze_analyze_if_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_classes_analyze_analyze_if_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_991, false, nil); A_arbace_classes_analyze_analyze_if_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_141; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_142)); return A_arbace_classes_analyze__init_part1_A_const_141 }















func A_arbace_classes_analyze__init_part1_A_Unit172__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1863, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_143; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_classes_analyze_analyze_recur_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_classes_analyze_analyze_recur_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_992, false, nil); A_arbace_classes_analyze_analyze_recur_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_143; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_144)); return A_arbace_classes_analyze__init_part1_A_const_143 }



















func A_arbace_classes_analyze__init_part1_A_Unit173__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1883, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_145; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_classes_analyze_expand_to_loop_A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_classes_analyze_expand_to_loop_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_993, false, nil); A_arbace_classes_analyze_expand_to_loop_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_145; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_146)); return A_arbace_classes_analyze__init_part1_A_const_145 }







func A_arbace_classes_analyze__init_part1_A_Unit174__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1891, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_147; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_classes_analyze_analyze_label_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_classes_analyze_analyze_label_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_994, false, nil); A_arbace_classes_analyze_analyze_label_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_147; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_148)); return A_arbace_classes_analyze__init_part1_A_const_147 }















func A_arbace_classes_analyze__init_part1_A_Unit175__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1907, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_149; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_classes_analyze_analyze_break_A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_classes_analyze_analyze_break_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_995, false, nil); A_arbace_classes_analyze_analyze_break_A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_149; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_150)); return A_arbace_classes_analyze__init_part1_A_const_149 }








func A_arbace_classes_analyze__init_part1_A_Unit176__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1916, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_151; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_classes_analyze_analyze_return_A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_classes_analyze_analyze_return_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_996, false, nil); A_arbace_classes_analyze_analyze_return_A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_151; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_152)); return A_arbace_classes_analyze__init_part1_A_const_151 }






func A_arbace_classes_analyze__init_part1_A_Unit177__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1923, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_153; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_classes_analyze_analyze_throw_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_classes_analyze_analyze_throw_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_997, false, nil); A_arbace_classes_analyze_analyze_throw_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_153; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_154)); return A_arbace_classes_analyze__init_part1_A_const_153 }












func A_arbace_classes_analyze__init_part1_A_Unit178__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1936, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_155; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_classes_analyze_analyze_try_A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_classes_analyze_analyze_try_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_998, false, nil); A_arbace_classes_analyze_analyze_try_A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_155; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_156)); return A_arbace_classes_analyze__init_part1_A_const_155 }


















func A_arbace_classes_analyze__init_part1_A_Unit179__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1955, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_157; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_classes_analyze_analyze_locking_A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_classes_analyze_analyze_locking_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_999, false, nil); A_arbace_classes_analyze_analyze_locking_A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_157; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_158)); return A_arbace_classes_analyze__init_part1_A_const_157 }







func A_arbace_classes_analyze__init_part1_A_Unit180__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1963, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_159; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_160)); return A_arbace_classes_analyze__init_part1_A_const_159 }
//line :1963:1
func A_arbace_classes_analyze__init_part1_A_Unit181__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1963, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_161; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_162)); return A_arbace_classes_analyze__init_part1_A_const_161 }
//line :1963:1
func A_arbace_classes_analyze__init_part1_A_Unit182__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1963, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_163; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_164)); return A_arbace_classes_analyze__init_part1_A_const_163 }

func A_arbace_classes_analyze__init_part1_A_Unit183__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1965, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_165; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_classes_analyze_analyze_set_BANG__A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_classes_analyze_analyze_set_BANG__A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1000, false, nil); A_arbace_classes_analyze_analyze_set_BANG__A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_165; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_166)); return A_arbace_classes_analyze__init_part1_A_const_165 }




















































func A_arbace_classes_analyze__init_part1_A_Unit184__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2018, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_167; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_classes_analyze_applicable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_classes_analyze_applicable_QMARK__A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1001, false, nil); A_arbace_classes_analyze_applicable_QMARK__A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_167; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_168)); return A_arbace_classes_analyze__init_part1_A_const_167 }









func A_arbace_classes_analyze__init_part1_A_Unit185__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2028, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_169; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_classes_analyze_more_specific_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_classes_analyze_more_specific_QMARK__A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1002, false, nil); A_arbace_classes_analyze_more_specific_QMARK__A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_169; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_170)); return A_arbace_classes_analyze__init_part1_A_const_169 }




func A_arbace_classes_analyze__init_part1_A_Unit186__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2033, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_171; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_classes_analyze_expand_varargs_A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_classes_analyze_expand_varargs_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1003, false, nil); A_arbace_classes_analyze_expand_varargs_A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_171; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_172)); return A_arbace_classes_analyze__init_part1_A_const_171 }




func A_arbace_classes_analyze__init_part1_A_Unit187__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2038, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_173; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_classes_analyze_param_tags_match_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_classes_analyze_param_tags_match_QMARK__A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1004, false, nil); A_arbace_classes_analyze_param_tags_match_QMARK__A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_173; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_174)); return A_arbace_classes_analyze__init_part1_A_const_173 }










func A_arbace_classes_analyze__init_part1_A_Unit188__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2049, 1); A_arbace_classes_analyze__init_part1_A_const_175.BindRoot_O__V(A_arbace_classes_analyze__init_part1_A_const_176); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_175; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_177)); return A_arbace_classes_analyze__init_part1_A_const_175 }

func A_arbace_classes_analyze__init_part1_A_Unit189__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2051, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_178; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_179)); return A_arbace_classes_analyze__init_part1_A_const_178 }

func A_arbace_classes_analyze__init_part1_A_Unit190__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2053, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_180; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_classes_analyze_clj_fi_method_A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_classes_analyze_clj_fi_method_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1005, false, nil); A_arbace_classes_analyze_clj_fi_method_A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_180; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_181)); return A_arbace_classes_analyze__init_part1_A_const_180 }




























func A_arbace_classes_analyze__init_part1_A_Unit191__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2082, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_182; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_classes_analyze_clj_arg_class_A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_classes_analyze_clj_arg_class_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1006, false, nil); A_arbace_classes_analyze_clj_arg_class_A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_182; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_183)); return A_arbace_classes_analyze__init_part1_A_const_182 }








func A_arbace_classes_analyze__init_part1_A_Unit192__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2091, 1); A_arbace_classes_analyze__init_part1_A_const_184.BindRoot_O__V(A_arbace_classes_analyze__init_part1_A_const_185); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_184; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_186)); return A_arbace_classes_analyze__init_part1_A_const_184 }










func A_arbace_classes_analyze__init_part1_A_Unit193__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2102, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_187; var tmp2 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_classes_analyze_clj_param_arg_match_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_classes_analyze_clj_param_arg_match_QMARK__A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1007, false, nil); A_arbace_classes_analyze_clj_param_arg_match_QMARK__A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_187; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_188)); return A_arbace_classes_analyze__init_part1_A_const_187 }










func A_arbace_classes_analyze__init_part1_A_Unit194__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2113, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_189; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_classes_analyze_clj_subsumes_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_classes_analyze_clj_subsumes_QMARK__A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1008, false, nil); A_arbace_classes_analyze_clj_subsumes_QMARK__A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_189; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_190)); return A_arbace_classes_analyze__init_part1_A_const_189 }








func A_arbace_classes_analyze__init_part1_A_Unit195__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2122, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_191; var tmp2 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_classes_analyze_clj_ret_assignable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_classes_analyze_clj_ret_assignable_QMARK__A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1009, false, nil); A_arbace_classes_analyze_clj_ret_assignable_QMARK__A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_191; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_192)); return A_arbace_classes_analyze__init_part1_A_const_191 }




func A_arbace_classes_analyze__init_part1_A_Unit196__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2127, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_193; var tmp2 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_classes_analyze_clj_matching_index_A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_classes_analyze_clj_matching_index_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1010, false, nil); A_arbace_classes_analyze_clj_matching_index_A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_193; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_194)); return A_arbace_classes_analyze__init_part1_A_const_193 }
































func A_arbace_classes_analyze__init_part1_A_Unit197__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2160, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_195; var tmp2 *lang.Compiler_AOTFn; var fnbody__124 any = A_arbace_classes_analyze_clj_type_string_A_New(); var tmp3 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_classes_analyze_clj_type_string_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1011, false, nil); A_arbace_classes_analyze_clj_type_string_A_fn_class = fncls__123d; tmp3 = fncls__123d } else { tmp3 = fncls__123 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__124, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_195; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_196)); return A_arbace_classes_analyze__init_part1_A_const_195 }




func A_arbace_classes_analyze__init_part1_A_Unit198__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2165, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_197; var tmp2 *lang.Compiler_AOTFn; var fnbody__126 any = A_arbace_classes_analyze_clj_select_A_New(); var tmp3 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_classes_analyze_clj_select_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1012, false, nil); A_arbace_classes_analyze_clj_select_A_fn_class = fncls__125d; tmp3 = fncls__125d } else { tmp3 = fncls__125 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__126, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_197; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_198)); return A_arbace_classes_analyze__init_part1_A_const_197 }
























func A_arbace_classes_analyze__init_part1_A_Unit199__O() any { A_arbace_classes_analyze__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2190, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_199; var tmp2 *lang.Compiler_AOTFn; var fnbody__128 any = A_arbace_classes_analyze_select_method_A_New(); var tmp3 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_classes_analyze_select_method_A_fn_class; if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1013, false, nil); A_arbace_classes_analyze_select_method_A_fn_class = fncls__127d; tmp3 = fncls__127d } else { tmp3 = fncls__127 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__128, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part1_A_const_199; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part1_A_const_200)); return A_arbace_classes_analyze__init_part1_A_const_199 }



































func A_arbace_classes_analyze__init_part2_A_Unit200__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2226, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_0; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_classes_analyze_instance_candidates_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_classes_analyze_instance_candidates_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1015, false, nil); A_arbace_classes_analyze_instance_candidates_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_1)); return A_arbace_classes_analyze__init_part2_A_const_0 }
//line :2226:1
func A_arbace_classes_analyze__init_part2_A_Init__O() any { A_arbace_classes_analyze__init_part2_A_Init(); return nil }
//line :2226:1
func A_arbace_classes_analyze__init_part2_A_Load__O() any { A_arbace_classes_analyze__init_part2_A_Init(); A_arbace_classes_analyze__init_part2_A_Unit200__O(); A_arbace_classes_analyze__init_part2_A_Unit201__O(); A_arbace_classes_analyze__init_part2_A_Unit202__O(); A_arbace_classes_analyze__init_part2_A_Unit203__O(); A_arbace_classes_analyze__init_part2_A_Unit204__O(); A_arbace_classes_analyze__init_part2_A_Unit205__O(); A_arbace_classes_analyze__init_part2_A_Unit206__O(); A_arbace_classes_analyze__init_part2_A_Unit207__O(); A_arbace_classes_analyze__init_part2_A_Unit208__O(); A_arbace_classes_analyze__init_part2_A_Unit209__O(); A_arbace_classes_analyze__init_part2_A_Unit210__O(); A_arbace_classes_analyze__init_part2_A_Unit211__O(); A_arbace_classes_analyze__init_part2_A_Unit212__O(); A_arbace_classes_analyze__init_part2_A_Unit213__O(); A_arbace_classes_analyze__init_part2_A_Unit214__O(); A_arbace_classes_analyze__init_part2_A_Unit215__O(); A_arbace_classes_analyze__init_part2_A_Unit216__O(); A_arbace_classes_analyze__init_part2_A_Unit217__O(); A_arbace_classes_analyze__init_part2_A_Unit218__O(); A_arbace_classes_analyze__init_part2_A_Unit219__O(); A_arbace_classes_analyze__init_part2_A_Unit220__O(); A_arbace_classes_analyze__init_part2_A_Unit221__O(); A_arbace_classes_analyze__init_part2_A_Unit222__O(); A_arbace_classes_analyze__init_part2_A_Unit223__O(); A_arbace_classes_analyze__init_part2_A_Unit224__O(); A_arbace_classes_analyze__init_part2_A_Unit225__O(); A_arbace_classes_analyze__init_part2_A_Unit226__O(); A_arbace_classes_analyze__init_part2_A_Unit227__O(); A_arbace_classes_analyze__init_part2_A_Unit228__O(); A_arbace_classes_analyze__init_part2_A_Unit229__O(); A_arbace_classes_analyze__init_part2_A_Unit230__O(); A_arbace_classes_analyze__init_part2_A_Unit231__O(); A_arbace_classes_analyze__init_part2_A_Unit232__O(); A_arbace_classes_analyze__init_part2_A_Unit233__O(); A_arbace_classes_analyze__init_part2_A_Unit234__O(); A_arbace_classes_analyze__init_part2_A_Unit235__O(); A_arbace_classes_analyze__init_part2_A_Unit236__O(); A_arbace_classes_analyze__init_part2_A_Unit237__O(); A_arbace_classes_analyze__init_part2_A_Unit238__O(); A_arbace_classes_analyze__init_part2_A_Unit239__O(); A_arbace_classes_analyze__init_part2_A_Unit240__O(); A_arbace_classes_analyze__init_part2_A_Unit241__O(); A_arbace_classes_analyze__init_part2_A_Unit242__O(); A_arbace_classes_analyze__init_part2_A_Unit243__O(); A_arbace_classes_analyze__init_part2_A_Unit244__O(); A_arbace_classes_analyze__init_part2_A_Unit245__O(); A_arbace_classes_analyze__init_part2_A_Unit246__O(); A_arbace_classes_analyze__init_part2_A_Unit247__O(); A_arbace_classes_analyze__init_part2_A_Unit248__O(); A_arbace_classes_analyze__init_part2_A_Unit249__O(); A_arbace_classes_analyze__init_part2_A_Unit250__O(); A_arbace_classes_analyze__init_part2_A_Unit251__O(); A_arbace_classes_analyze__init_part2_A_Unit252__O(); A_arbace_classes_analyze__init_part2_A_Unit253__O(); A_arbace_classes_analyze__init_part2_A_Unit254__O(); A_arbace_classes_analyze__init_part2_A_Unit255__O(); A_arbace_classes_analyze__init_part2_A_Unit256__O(); A_arbace_classes_analyze__init_part2_A_Unit257__O(); A_arbace_classes_analyze__init_part2_A_Unit258__O(); A_arbace_classes_analyze__init_part2_A_Unit259__O(); A_arbace_classes_analyze__init_part2_A_Unit260__O(); A_arbace_classes_analyze__init_part2_A_Unit261__O(); A_arbace_classes_analyze__init_part2_A_Unit262__O(); A_arbace_classes_analyze__init_part2_A_Unit263__O(); A_arbace_classes_analyze__init_part2_A_Unit264__O(); A_arbace_classes_analyze__init_part2_A_Unit265__O(); A_arbace_classes_analyze__init_part2_A_Unit266__O(); A_arbace_classes_analyze__init_part2_A_Unit267__O(); A_arbace_classes_analyze__init_part2_A_Unit268__O(); A_arbace_classes_analyze__init_part2_A_Unit269__O(); A_arbace_classes_analyze__init_part2_A_Unit270__O(); A_arbace_classes_analyze__init_part2_A_Unit271__O(); A_arbace_classes_analyze__init_part2_A_Unit272__O(); A_arbace_classes_analyze__init_part2_A_Unit273__O(); A_arbace_classes_analyze__init_part2_A_Unit274__O(); A_arbace_classes_analyze__init_part2_A_Unit275__O(); A_arbace_classes_analyze__init_part2_A_Unit276__O(); A_arbace_classes_analyze__init_part2_A_Unit277__O(); A_arbace_classes_analyze__init_part2_A_Unit278__O(); A_arbace_classes_analyze__init_part2_A_Unit279__O(); A_arbace_classes_analyze__init_part2_A_Unit280__O(); A_arbace_classes_analyze__init_part2_A_Unit281__O(); A_arbace_classes_analyze__init_part2_A_Unit282__O(); A_arbace_classes_analyze__init_part2_A_Unit283__O(); A_arbace_classes_analyze__init_part2_A_Unit284__O(); A_arbace_classes_analyze__init_part2_A_Unit285__O(); A_arbace_classes_analyze__init_part2_A_Unit286__O(); A_arbace_classes_analyze__init_part2_A_Unit287__O(); A_arbace_classes_analyze__init_part2_A_Unit288__O(); A_arbace_classes_analyze__init_part2_A_Unit289__O(); A_arbace_classes_analyze__init_part2_A_Unit290__O(); A_arbace_classes_analyze__init_part2_A_Unit291__O(); A_arbace_classes_analyze__init_part2_A_Unit292__O(); A_arbace_classes_analyze__init_part2_A_Unit293__O(); A_arbace_classes_analyze__init_part2_A_Unit294__O(); A_arbace_classes_analyze__init_part2_A_Unit295__O(); A_arbace_classes_analyze__init_part2_A_Unit296__O(); A_arbace_classes_analyze__init_part2_A_Unit297__O(); A_arbace_classes_analyze__init_part2_A_Unit298__O(); A_arbace_classes_analyze__init_part2_A_Unit299__O(); return nil }







func A_arbace_classes_analyze__init_part2_A_Unit201__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2234, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_2; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_classes_analyze_static_candidates_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_classes_analyze_static_candidates_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1016, false, nil); A_arbace_classes_analyze_static_candidates_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_3)); return A_arbace_classes_analyze__init_part2_A_const_2 }






func A_arbace_classes_analyze__init_part2_A_Unit202__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2241, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_classes_analyze_ctor_candidates_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_classes_analyze_ctor_candidates_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1017, false, nil); A_arbace_classes_analyze_ctor_candidates_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_5)); return A_arbace_classes_analyze__init_part2_A_const_4 }




func A_arbace_classes_analyze__init_part2_A_Unit203__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2246, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_classes_analyze_clj_arg_convert_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_classes_analyze_clj_arg_convert_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1018, false, nil); A_arbace_classes_analyze_clj_arg_convert_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_7)); return A_arbace_classes_analyze__init_part2_A_const_6 }



















































func A_arbace_classes_analyze__init_part2_A_Unit204__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2298, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_classes_analyze_convert_args_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_classes_analyze_convert_args_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1019, false, nil); A_arbace_classes_analyze_convert_args_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_9)); return A_arbace_classes_analyze__init_part2_A_const_8 }














func A_arbace_classes_analyze__init_part2_A_Unit205__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2313, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_classes_analyze_qualifying_owner_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_classes_analyze_qualifying_owner_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1020, false, nil); A_arbace_classes_analyze_qualifying_owner_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_11)); return A_arbace_classes_analyze__init_part2_A_const_10 }













func A_arbace_classes_analyze__init_part2_A_Unit206__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2327, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_classes_analyze_invoke_node_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_classes_analyze_invoke_node_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1021, false, nil); A_arbace_classes_analyze_invoke_node_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_13)); return A_arbace_classes_analyze__init_part2_A_const_12 }










func A_arbace_classes_analyze__init_part2_A_Unit207__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2338, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_classes_analyze_signature_polymorphic_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_classes_analyze_signature_polymorphic_QMARK__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1022, false, nil); A_arbace_classes_analyze_signature_polymorphic_QMARK__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_15)); return A_arbace_classes_analyze__init_part2_A_const_14 }







func A_arbace_classes_analyze__init_part2_A_Unit208__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2346, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_classes_analyze_reflect_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_classes_analyze_reflect_QMARK__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1023, false, nil); A_arbace_classes_analyze_reflect_QMARK__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_17)); return A_arbace_classes_analyze__init_part2_A_const_16 }






func A_arbace_classes_analyze__init_part2_A_Unit209__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2353, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_classes_analyze_reflection_warning_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_classes_analyze_reflection_warning_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1024, false, nil); A_arbace_classes_analyze_reflection_warning_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_19)); return A_arbace_classes_analyze__init_part2_A_const_18 }





func A_arbace_classes_analyze__init_part2_A_Unit210__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2359, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_classes_analyze_objects_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_classes_analyze_objects_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1025, false, nil); A_arbace_classes_analyze_objects_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_21)); return A_arbace_classes_analyze__init_part2_A_const_20 }


func A_arbace_classes_analyze__init_part2_A_Unit211__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2362, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_classes_analyze_reflective_node_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_classes_analyze_reflective_node_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1026, false, nil); A_arbace_classes_analyze_reflective_node_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_23)); return A_arbace_classes_analyze__init_part2_A_const_22 }



func A_arbace_classes_analyze__init_part2_A_Unit212__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2366, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_classes_analyze_reflective_call_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_classes_analyze_reflective_call_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1027, false, nil); A_arbace_classes_analyze_reflective_call_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_25)); return A_arbace_classes_analyze__init_part2_A_const_24 }










func A_arbace_classes_analyze__init_part2_A_Unit213__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2377, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_26; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_classes_analyze_unresolved_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_classes_analyze_unresolved_QMARK__A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1028, false, nil); A_arbace_classes_analyze_unresolved_QMARK__A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_27)); return A_arbace_classes_analyze__init_part2_A_const_26 }






func A_arbace_classes_analyze__init_part2_A_Unit214__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2384, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_28; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_classes_analyze_or_reflect_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_classes_analyze_or_reflect_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1029, false, nil); A_arbace_classes_analyze_or_reflect_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_29)); return A_arbace_classes_analyze__init_part2_A_const_28 }








func A_arbace_classes_analyze__init_part2_A_Unit215__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2393, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_30; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_31)); return A_arbace_classes_analyze__init_part2_A_const_30 }
//line :2393:1
func A_arbace_classes_analyze__init_part2_A_Unit216__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2393, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_32; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_33)); return A_arbace_classes_analyze__init_part2_A_const_32 }

func A_arbace_classes_analyze__init_part2_A_Unit217__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2395, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_34; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__32 any = A_arbace_classes_analyze_analyze_method_call_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_classes_analyze_analyze_method_call_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1030, true, nil); A_arbace_classes_analyze_analyze_method_call_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__32, tmp3, nil, 4); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_35)); return A_arbace_classes_analyze__init_part2_A_const_34 }














func A_arbace_classes_analyze__init_part2_A_Unit218__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2410, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_36; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__34 any = A_arbace_classes_analyze_analyze_method_call_STAR__A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_classes_analyze_analyze_method_call_STAR__A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1031, true, nil); A_arbace_classes_analyze_analyze_method_call_STAR__A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__34, tmp3, nil, 4); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_37)); return A_arbace_classes_analyze__init_part2_A_const_36 }



























func A_arbace_classes_analyze__init_part2_A_Unit219__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2438, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_38; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_39)); return A_arbace_classes_analyze__init_part2_A_const_38 }
//line :2438:1
func A_arbace_classes_analyze__init_part2_A_Unit220__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2438, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_30; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_40)); return A_arbace_classes_analyze__init_part2_A_const_30 }

func A_arbace_classes_analyze__init_part2_A_Unit221__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2440, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_41; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__36 any = A_arbace_classes_analyze_analyze_static_call_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_classes_analyze_analyze_static_call_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1032, true, nil); A_arbace_classes_analyze_analyze_static_call_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__36, tmp3, nil, 4); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_42)); return A_arbace_classes_analyze__init_part2_A_const_41 }

























func A_arbace_classes_analyze__init_part2_A_Unit222__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2466, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_43; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_44)); return A_arbace_classes_analyze__init_part2_A_const_43 }

func A_arbace_classes_analyze__init_part2_A_Unit223__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2468, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_45; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_classes_analyze_analyze_field_access_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_classes_analyze_analyze_field_access_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1033, false, nil); A_arbace_classes_analyze_analyze_field_access_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_46)); return A_arbace_classes_analyze__init_part2_A_const_45 }











func A_arbace_classes_analyze__init_part2_A_Unit224__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2480, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_43; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_classes_analyze_analyze_field_access_STAR__A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_classes_analyze_analyze_field_access_STAR__A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1034, false, nil); A_arbace_classes_analyze_analyze_field_access_STAR__A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_47)); return A_arbace_classes_analyze__init_part2_A_const_43 }



























func A_arbace_classes_analyze__init_part2_A_Unit225__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2508, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_classes_analyze_super_node_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_classes_analyze_super_node_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1035, false, nil); A_arbace_classes_analyze_super_node_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_49)); return A_arbace_classes_analyze__init_part2_A_const_48 }




func A_arbace_classes_analyze__init_part2_A_Unit226__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2513, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_classes_analyze_field_super_node_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_classes_analyze_field_super_node_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1036, false, nil); A_arbace_classes_analyze_field_super_node_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_51)); return A_arbace_classes_analyze__init_part2_A_const_50 }













func A_arbace_classes_analyze__init_part2_A_Unit227__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2527, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_52; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_classes_analyze_receiver_class_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_classes_analyze_receiver_class_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1037, false, nil); A_arbace_classes_analyze_receiver_class_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_53)); return A_arbace_classes_analyze__init_part2_A_const_52 }






func A_arbace_classes_analyze__init_part2_A_Unit228__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2534, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_54; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_55)); return A_arbace_classes_analyze__init_part2_A_const_54 }

func A_arbace_classes_analyze__init_part2_A_Unit229__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2536, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_classes_analyze_type_arg_anns_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_classes_analyze_type_arg_anns_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1038, false, nil); A_arbace_classes_analyze_type_arg_anns_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_56)); return A_arbace_classes_analyze__init_part2_A_const_30 }





func A_arbace_classes_analyze__init_part2_A_Unit230__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2542, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_57; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_classes_analyze_analyze_dot_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_classes_analyze_analyze_dot_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1039, false, nil); A_arbace_classes_analyze_analyze_dot_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_58)); return A_arbace_classes_analyze__init_part2_A_const_57 }








func A_arbace_classes_analyze__init_part2_A_Unit231__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2551, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_54; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_classes_analyze_analyze_dot_STAR__A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_classes_analyze_analyze_dot_STAR__A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1040, false, nil); A_arbace_classes_analyze_analyze_dot_STAR__A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_59)); return A_arbace_classes_analyze__init_part2_A_const_54 }











































































func A_arbace_classes_analyze__init_part2_A_Unit232__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2627, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_60; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_61)); return A_arbace_classes_analyze__init_part2_A_const_60 }

func A_arbace_classes_analyze__init_part2_A_Unit233__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2629, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_62; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_classes_analyze_capture_local_super_BANG__A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_classes_analyze_capture_local_super_BANG__A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1041, false, nil); A_arbace_classes_analyze_capture_local_super_BANG__A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_63)); return A_arbace_classes_analyze__init_part2_A_const_62 }














func A_arbace_classes_analyze__init_part2_A_Unit234__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2644, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_64; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__56 any = A_arbace_classes_analyze_ctor_call_node_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_classes_analyze_ctor_call_node_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1042, true, nil); A_arbace_classes_analyze_ctor_call_node_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__56, tmp3, nil, 4); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_65)); return A_arbace_classes_analyze__init_part2_A_const_64 }


















func A_arbace_classes_analyze__init_part2_A_Unit235__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2663, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_66; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_classes_analyze_array_new_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_classes_analyze_array_new_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1043, false, nil); A_arbace_classes_analyze_array_new_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_67)); return A_arbace_classes_analyze__init_part2_A_const_66 }











func A_arbace_classes_analyze__init_part2_A_Unit236__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2675, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_68; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_classes_analyze_needs_outer_instance_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_classes_analyze_needs_outer_instance_QMARK__A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1044, false, nil); A_arbace_classes_analyze_needs_outer_instance_QMARK__A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_69)); return A_arbace_classes_analyze__init_part2_A_const_68 }



func A_arbace_classes_analyze__init_part2_A_Unit237__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2679, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_60; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_classes_analyze_outer_instance_for_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_classes_analyze_outer_instance_for_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1045, false, nil); A_arbace_classes_analyze_outer_instance_for_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_70)); return A_arbace_classes_analyze__init_part2_A_const_60 }















func A_arbace_classes_analyze__init_part2_A_Unit238__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2695, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_71; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_classes_analyze_analyze_new_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_classes_analyze_analyze_new_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1046, false, nil); A_arbace_classes_analyze_analyze_new_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_72)); return A_arbace_classes_analyze__init_part2_A_const_71 }


















































func A_arbace_classes_analyze__init_part2_A_Unit239__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2746, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_73; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_classes_analyze_analyze_aget_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_classes_analyze_analyze_aget_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1047, false, nil); A_arbace_classes_analyze_analyze_aget_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_74)); return A_arbace_classes_analyze__init_part2_A_const_73 }






func A_arbace_classes_analyze__init_part2_A_Unit240__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2753, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_75; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_classes_analyze_analyze_aset_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_classes_analyze_analyze_aset_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1048, false, nil); A_arbace_classes_analyze_analyze_aset_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_76)); return A_arbace_classes_analyze__init_part2_A_const_75 }












func A_arbace_classes_analyze__init_part2_A_Unit241__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2766, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_classes_analyze_code_type_anns_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_classes_analyze_code_type_anns_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1049, false, nil); A_arbace_classes_analyze_code_type_anns_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_77)); return A_arbace_classes_analyze__init_part2_A_const_32 }






func A_arbace_classes_analyze__init_part2_A_Unit242__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2773, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_78; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_classes_analyze_analyze_instance_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_classes_analyze_analyze_instance_QMARK__A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1050, false, nil); A_arbace_classes_analyze_analyze_instance_QMARK__A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_79)); return A_arbace_classes_analyze__init_part2_A_const_78 }






func A_arbace_classes_analyze__init_part2_A_Unit243__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2780, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_80; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_classes_analyze_analyze_cast_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_classes_analyze_analyze_cast_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1051, false, nil); A_arbace_classes_analyze_analyze_cast_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_81)); return A_arbace_classes_analyze__init_part2_A_const_80 }



















func A_arbace_classes_analyze__init_part2_A_Unit244__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2800, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_82; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_classes_analyze_ref_node_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_classes_analyze_ref_node_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1052, false, nil); A_arbace_classes_analyze_ref_node_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_83)); return A_arbace_classes_analyze__init_part2_A_const_82 }






func A_arbace_classes_analyze__init_part2_A_Unit245__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2807, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_84; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_85)); return A_arbace_classes_analyze__init_part2_A_const_84 }
//line :2807:1
func A_arbace_classes_analyze__init_part2_A_Unit246__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2807, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_86; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_87)); return A_arbace_classes_analyze__init_part2_A_const_86 }
//line :2807:1
func A_arbace_classes_analyze__init_part2_A_Unit247__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2807, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_88; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_89)); return A_arbace_classes_analyze__init_part2_A_const_88 }
//line :2807:1
func A_arbace_classes_analyze__init_part2_A_Unit248__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2807, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_90; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_91)); return A_arbace_classes_analyze__init_part2_A_const_90 }
//line :2807:1
func A_arbace_classes_analyze__init_part2_A_Unit249__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2807, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_92; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_93)); return A_arbace_classes_analyze__init_part2_A_const_92 }
//line :2807:1
func A_arbace_classes_analyze__init_part2_A_Unit250__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2807, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_94; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_95)); return A_arbace_classes_analyze__init_part2_A_const_94 }
//line :2807:1
func A_arbace_classes_analyze__init_part2_A_Unit251__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2807, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_96; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_97)); return A_arbace_classes_analyze__init_part2_A_const_96 }
//line :2807:1
func A_arbace_classes_analyze__init_part2_A_Unit252__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2807, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_98; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_99)); return A_arbace_classes_analyze__init_part2_A_const_98 }
//line :2807:1
func A_arbace_classes_analyze__init_part2_A_Unit253__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2807, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_100; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_101)); return A_arbace_classes_analyze__init_part2_A_const_100 }
//line :2807:1
func A_arbace_classes_analyze__init_part2_A_Unit254__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2807, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_102; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_103)); return A_arbace_classes_analyze__init_part2_A_const_102 }
//line :2807:1
func A_arbace_classes_analyze__init_part2_A_Unit255__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2807, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_104; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_105)); return A_arbace_classes_analyze__init_part2_A_const_104 }



func A_arbace_classes_analyze__init_part2_A_Unit256__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2811, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_106; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_classes_analyze_method_sugar_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_classes_analyze_method_sugar_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1053, false, nil); A_arbace_classes_analyze_method_sugar_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_106; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_107)); return A_arbace_classes_analyze__init_part2_A_const_106 }































func A_arbace_classes_analyze__init_part2_A_Unit257__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2843, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_108; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_109)); return A_arbace_classes_analyze__init_part2_A_const_108 }
//line :2843:1
func A_arbace_classes_analyze__init_part2_A_Unit258__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2843, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_110; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_111)); return A_arbace_classes_analyze__init_part2_A_const_110 }
//line :2843:1
func A_arbace_classes_analyze__init_part2_A_Unit259__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2843, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_112; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_113)); return A_arbace_classes_analyze__init_part2_A_const_112 }

func A_arbace_classes_analyze__init_part2_A_Unit260__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2845, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_114; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_classes_analyze_specialized_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_classes_analyze_specialized_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1054, false, nil); A_arbace_classes_analyze_specialized_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_115)); return A_arbace_classes_analyze__init_part2_A_const_114 }






func A_arbace_classes_analyze__init_part2_A_Unit261__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2852, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_116; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_117)); return A_arbace_classes_analyze__init_part2_A_const_116 }

func A_arbace_classes_analyze__init_part2_A_Unit262__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2854, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_classes_analyze_clj_convert_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_classes_analyze_clj_convert_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1055, false, nil); A_arbace_classes_analyze_clj_convert_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_118)); return A_arbace_classes_analyze__init_part2_A_const_38 }

















func A_arbace_classes_analyze__init_part2_A_Unit263__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2872, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_116; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_classes_analyze_with_node_locals_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_classes_analyze_with_node_locals_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1056, false, nil); A_arbace_classes_analyze_with_node_locals_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_116; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_119)); return A_arbace_classes_analyze__init_part2_A_const_116 }











func A_arbace_classes_analyze__init_part2_A_Unit264__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2884, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_120; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_classes_analyze_clj_call_node_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_classes_analyze_clj_call_node_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1057, false, nil); A_arbace_classes_analyze_clj_call_node_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_121)); return A_arbace_classes_analyze__init_part2_A_const_120 }










func A_arbace_classes_analyze__init_part2_A_Unit265__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2895, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_122; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_classes_analyze_core_op_node_A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_classes_analyze_core_op_node_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1058, false, nil); A_arbace_classes_analyze_core_op_node_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_122; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_123)); return A_arbace_classes_analyze__init_part2_A_const_122 }












































































































func A_arbace_classes_analyze__init_part2_A_Unit266__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3004, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_124; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_classes_analyze_analyze_op_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_classes_analyze_analyze_op_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1059, false, nil); A_arbace_classes_analyze_analyze_op_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_124; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_125)); return A_arbace_classes_analyze__init_part2_A_const_124 }














































































func A_arbace_classes_analyze__init_part2_A_Unit267__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3083, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_110; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_classes_analyze_var_invoke_node_A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_classes_analyze_var_invoke_node_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1060, false, nil); A_arbace_classes_analyze_var_invoke_node_A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_110; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_126)); return A_arbace_classes_analyze__init_part2_A_const_110 }









func A_arbace_classes_analyze__init_part2_A_Unit268__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3093, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_108; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__94 any = A_arbace_classes_analyze_analyze_fn_call_A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_classes_analyze_analyze_fn_call_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1061, true, nil); A_arbace_classes_analyze_analyze_fn_call_A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__94, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_108; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_127)); return A_arbace_classes_analyze__init_part2_A_const_108 }












func A_arbace_classes_analyze__init_part2_A_Unit269__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3106, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_128; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_classes_analyze_expand_fully_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_classes_analyze_expand_fully_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1062, false, nil); A_arbace_classes_analyze_expand_fully_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_129)); return A_arbace_classes_analyze__init_part2_A_const_128 }






func A_arbace_classes_analyze__init_part2_A_Unit270__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3113, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_112; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_classes_analyze_analyze_clj_special_A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_classes_analyze_analyze_clj_special_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1063, false, nil); A_arbace_classes_analyze_analyze_clj_special_A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_112; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_130)); return A_arbace_classes_analyze__init_part2_A_const_112 }


















































func A_arbace_classes_analyze__init_part2_A_Unit271__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3164, 1); A_arbace_classes_analyze__init_part2_A_const_131.BindRoot_O__V(A_arbace_classes_analyze__init_part2_A_const_132); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_131; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_133)); return A_arbace_classes_analyze__init_part2_A_const_131 }



func A_arbace_classes_analyze__init_part2_A_Unit272__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3168, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_134; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_classes_analyze_may_be_constant_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_classes_analyze_may_be_constant_QMARK__A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1064, false, nil); A_arbace_classes_analyze_may_be_constant_QMARK__A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_134; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_135)); return A_arbace_classes_analyze__init_part2_A_const_134 }








func A_arbace_classes_analyze__init_part2_A_Unit273__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3177, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_136; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_classes_analyze_analyze_const_form_A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_classes_analyze_analyze_const_form_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1065, false, nil); A_arbace_classes_analyze_analyze_const_form_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_136; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_137)); return A_arbace_classes_analyze__init_part2_A_const_136 }




















func A_arbace_classes_analyze__init_part2_A_Unit274__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3198, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_138; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_classes_analyze_creation_actx_A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_classes_analyze_creation_actx_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1066, false, nil); A_arbace_classes_analyze_creation_actx_A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_138; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_139)); return A_arbace_classes_analyze__init_part2_A_const_138 }






func A_arbace_classes_analyze__init_part2_A_Unit275__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3205, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_140; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_classes_analyze_body_actx_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_classes_analyze_body_actx_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1067, false, nil); A_arbace_classes_analyze_body_actx_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_140; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_141)); return A_arbace_classes_analyze__init_part2_A_const_140 }














func A_arbace_classes_analyze__init_part2_A_Unit276__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3220, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_142; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_classes_analyze_bind_params_A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_classes_analyze_bind_params_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1068, false, nil); A_arbace_classes_analyze_bind_params_A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_142; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_143)); return A_arbace_classes_analyze__init_part2_A_const_142 }













func A_arbace_classes_analyze__init_part2_A_Unit277__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3234, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_144; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_classes_analyze_analyze_method_body_A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_classes_analyze_analyze_method_body_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1069, false, nil); A_arbace_classes_analyze_analyze_method_body_A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_144; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_145)); return A_arbace_classes_analyze__init_part2_A_const_144 }







func A_arbace_classes_analyze__init_part2_A_Unit278__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3242, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_146; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_classes_analyze_ctor_call_form_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_classes_analyze_ctor_call_form_QMARK__A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1070, false, nil); A_arbace_classes_analyze_ctor_call_form_QMARK__A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_146; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_147)); return A_arbace_classes_analyze__init_part2_A_const_146 }

func A_arbace_classes_analyze__init_part2_A_Unit279__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3244, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_148; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_classes_analyze_nested_ctor_call_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_classes_analyze_nested_ctor_call_QMARK__A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1071, false, nil); A_arbace_classes_analyze_nested_ctor_call_QMARK__A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_148; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_149)); return A_arbace_classes_analyze__init_part2_A_const_148 }









func A_arbace_classes_analyze__init_part2_A_Unit280__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3254, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_150; var tmp2 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_classes_analyze_implicit_super_call_A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_classes_analyze_implicit_super_call_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1072, false, nil); A_arbace_classes_analyze_implicit_super_call_A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_150; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_151)); return A_arbace_classes_analyze__init_part2_A_const_150 }















func A_arbace_classes_analyze__init_part2_A_Unit281__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3270, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_152; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_153)); return A_arbace_classes_analyze__init_part2_A_const_152 }

func A_arbace_classes_analyze__init_part2_A_Unit282__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3272, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_88; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_classes_analyze_analyze_ctor_call_A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_classes_analyze_analyze_ctor_call_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1073, false, nil); A_arbace_classes_analyze_analyze_ctor_call_A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_154)); return A_arbace_classes_analyze__init_part2_A_const_88 }










func A_arbace_classes_analyze__init_part2_A_Unit283__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3283, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_152; var tmp2 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_classes_analyze_analyze_ctor_call_STAR__A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_classes_analyze_analyze_ctor_call_STAR__A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1074, false, nil); A_arbace_classes_analyze_analyze_ctor_call_STAR__A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_152; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_155)); return A_arbace_classes_analyze__init_part2_A_const_152 }













func A_arbace_classes_analyze__init_part2_A_Unit284__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3297, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_156; var tmp2 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_classes_analyze_analyze_ctor_body_A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_classes_analyze_analyze_ctor_body_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1075, false, nil); A_arbace_classes_analyze_analyze_ctor_body_A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_156; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_157)); return A_arbace_classes_analyze__init_part2_A_const_156 }











































func A_arbace_classes_analyze__init_part2_A_Unit285__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3341, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_158; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_159)); return A_arbace_classes_analyze__init_part2_A_const_158 }

func A_arbace_classes_analyze__init_part2_A_Unit286__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3343, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_160; var tmp2 *lang.Compiler_AOTFn; var fnbody__124 any = A_arbace_classes_analyze_analyze_enum_constants_A_New(); var tmp3 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_classes_analyze_analyze_enum_constants_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1076, false, nil); A_arbace_classes_analyze_analyze_enum_constants_A_fn_class = fncls__123d; tmp3 = fncls__123d } else { tmp3 = fncls__123 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__124, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_160; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_161)); return A_arbace_classes_analyze__init_part2_A_const_160 }























func A_arbace_classes_analyze__init_part2_A_Unit287__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3367, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_162; var tmp2 *lang.Compiler_AOTFn; var fnbody__126 any = A_arbace_classes_analyze_analyze_class_BANG__A_New(); var tmp3 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_classes_analyze_analyze_class_BANG__A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1077, false, nil); A_arbace_classes_analyze_analyze_class_BANG__A_fn_class = fncls__125d; tmp3 = fncls__125d } else { tmp3 = fncls__125 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__126, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_162; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_163)); return A_arbace_classes_analyze__init_part2_A_const_162 }



































































func A_arbace_classes_analyze__init_part2_A_Unit288__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3435, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_164; var tmp2 *lang.Compiler_AOTFn; var fnbody__128 any = A_arbace_classes_analyze_class_generics_A_New(); var tmp3 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_classes_analyze_class_generics_A_fn_class; if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1078, false, nil); A_arbace_classes_analyze_class_generics_A_fn_class = fncls__127d; tmp3 = fncls__127d } else { tmp3 = fncls__127 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__128, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_164; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_165)); return A_arbace_classes_analyze__init_part2_A_const_164 }



































func A_arbace_classes_analyze__init_part2_A_Unit289__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3471, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_166; var tmp2 *lang.Compiler_AOTFn; var fnbody__130 any = A_arbace_classes_analyze_supertype_envs_A_New(); var tmp3 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_classes_analyze_supertype_envs_A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1079, false, nil); A_arbace_classes_analyze_supertype_envs_A_fn_class = fncls__129d; tmp3 = fncls__129d } else { tmp3 = fncls__129 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__130, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_166; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_167)); return A_arbace_classes_analyze__init_part2_A_const_166 }

























func A_arbace_classes_analyze__init_part2_A_Unit290__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3497, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_168; var tmp2 *lang.Compiler_AOTFn; var fnbody__132 any = A_arbace_classes_analyze_erased_params_A_New(); var tmp3 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_classes_analyze_erased_params_A_fn_class; if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1080, false, nil); A_arbace_classes_analyze_erased_params_A_fn_class = fncls__131d; tmp3 = fncls__131d } else { tmp3 = fncls__131 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__132, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_168; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_169)); return A_arbace_classes_analyze__init_part2_A_const_168 }











func A_arbace_classes_analyze__init_part2_A_Unit291__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3509, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_170; var tmp2 *lang.Compiler_AOTFn; var fnbody__134 any = A_arbace_classes_analyze_param_keys_A_New(); var tmp3 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_classes_analyze_param_keys_A_fn_class; if fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1081, false, nil); A_arbace_classes_analyze_param_keys_A_fn_class = fncls__133d; tmp3 = fncls__133d } else { tmp3 = fncls__133 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__134, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_170; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_171)); return A_arbace_classes_analyze__init_part2_A_const_170 }


















func A_arbace_classes_analyze__init_part2_A_Unit292__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3528, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_172; var tmp2 *lang.Compiler_AOTFn; var fnbody__136 any = A_arbace_classes_analyze_add_bridges_BANG__A_New(); var tmp3 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_classes_analyze_add_bridges_BANG__A_fn_class; if fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1082, false, nil); A_arbace_classes_analyze_add_bridges_BANG__A_fn_class = fncls__135d; tmp3 = fncls__135d } else { tmp3 = fncls__135 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__136, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_172; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_173)); return A_arbace_classes_analyze__init_part2_A_const_172 }








































































































func A_arbace_classes_analyze__init_part2_A_Unit293__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3633, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_174; var tmp2 *lang.Compiler_AOTFn; var fnbody__138 any = A_arbace_classes_analyze_supertypes_first_A_New(); var tmp3 *jrt.Class; var fncls__137 *jrt.Class = A_arbace_classes_analyze_supertypes_first_A_fn_class; if fncls__137 == nil { var fncls__137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1083, false, nil); A_arbace_classes_analyze_supertypes_first_A_fn_class = fncls__137d; tmp3 = fncls__137d } else { tmp3 = fncls__137 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__138, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_174; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_175)); return A_arbace_classes_analyze__init_part2_A_const_174 }












func A_arbace_classes_analyze__init_part2_A_Unit294__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3646, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_176; var tmp2 *lang.Compiler_AOTFn; var fnbody__140 any = A_arbace_classes_analyze_mark_enum_abstract_BANG__A_New(); var tmp3 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_classes_analyze_mark_enum_abstract_BANG__A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1084, false, nil); A_arbace_classes_analyze_mark_enum_abstract_BANG__A_fn_class = fncls__139d; tmp3 = fncls__139d } else { tmp3 = fncls__139 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__140, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_176; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_177)); return A_arbace_classes_analyze__init_part2_A_const_176 }




















func A_arbace_classes_analyze__init_part2_A_Unit295__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3667, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_178; var tmp2 *lang.Compiler_AOTFn; var fnbody__142 any = A_arbace_classes_analyze_process_classes_BANG__A_New(); var tmp3 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_classes_analyze_process_classes_BANG__A_fn_class; if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1085, false, nil); A_arbace_classes_analyze_process_classes_BANG__A_fn_class = fncls__141d; tmp3 = fncls__141d } else { tmp3 = fncls__141 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__142, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_178; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_179)); return A_arbace_classes_analyze__init_part2_A_const_178 }












func A_arbace_classes_analyze__init_part2_A_Unit296__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3680, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_84; var tmp2 *lang.Compiler_AOTFn; var fnbody__144 any = A_arbace_classes_analyze_analyze_anon_A_New(); var tmp3 *jrt.Class; var fncls__143 *jrt.Class = A_arbace_classes_analyze_analyze_anon_A_fn_class; if fncls__143 == nil { var fncls__143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1086, false, nil); A_arbace_classes_analyze_analyze_anon_A_fn_class = fncls__143d; tmp3 = fncls__143d } else { tmp3 = fncls__143 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__144, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_180)); return A_arbace_classes_analyze__init_part2_A_const_84 }























































































func A_arbace_classes_analyze__init_part2_A_Unit297__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3768, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_86; var tmp2 *lang.Compiler_AOTFn; var fnbody__146 any = A_arbace_classes_analyze_analyze_letclass_A_New(); var tmp3 *jrt.Class; var fncls__145 *jrt.Class = A_arbace_classes_analyze_analyze_letclass_A_fn_class; if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1087, false, nil); A_arbace_classes_analyze_analyze_letclass_A_fn_class = fncls__145d; tmp3 = fncls__145d } else { tmp3 = fncls__145 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__146, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_181)); return A_arbace_classes_analyze__init_part2_A_const_86 }



















func A_arbace_classes_analyze__init_part2_A_Unit298__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3788, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_182; var tmp2 *lang.Compiler_AOTFn; var fnbody__148 any = A_arbace_classes_analyze_not_yet_A_New(); var tmp3 *jrt.Class; var fncls__147 *jrt.Class = A_arbace_classes_analyze_not_yet_A_fn_class; if fncls__147 == nil { var fncls__147d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1088, false, nil); A_arbace_classes_analyze_not_yet_A_fn_class = fncls__147d; tmp3 = fncls__147d } else { tmp3 = fncls__147 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__148, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_182; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_183)); return A_arbace_classes_analyze__init_part2_A_const_182 }

func A_arbace_classes_analyze__init_part2_A_Unit299__O() any { A_arbace_classes_analyze__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3790, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_158; var tmp2 *lang.Compiler_AOTFn; var fnbody__150 any = A_arbace_classes_analyze_analyze_enum_body_A_New(); var tmp3 *jrt.Class; var fncls__149 *jrt.Class = A_arbace_classes_analyze_analyze_enum_body_A_fn_class; if fncls__149 == nil { var fncls__149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1089, false, nil); A_arbace_classes_analyze_analyze_enum_body_A_fn_class = fncls__149d; tmp3 = fncls__149d } else { tmp3 = fncls__149 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__150, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part2_A_const_158; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part2_A_const_184)); return A_arbace_classes_analyze__init_part2_A_const_158 }


















func A_arbace_classes_analyze__init_part3_A_Unit300__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3809, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_0; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_classes_analyze_const_string_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_classes_analyze_const_string_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1091, false, nil); A_arbace_classes_analyze_const_string_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_1)); return A_arbace_classes_analyze__init_part3_A_const_0 }
//line :3809:1
func A_arbace_classes_analyze__init_part3_A_Init__O() any { A_arbace_classes_analyze__init_part3_A_Init(); return nil }
//line :3809:1
func A_arbace_classes_analyze__init_part3_A_Load__O() any { A_arbace_classes_analyze__init_part3_A_Init(); A_arbace_classes_analyze__init_part3_A_Unit300__O(); A_arbace_classes_analyze__init_part3_A_Unit301__O(); A_arbace_classes_analyze__init_part3_A_Unit302__O(); A_arbace_classes_analyze__init_part3_A_Unit303__O(); A_arbace_classes_analyze__init_part3_A_Unit304__O(); A_arbace_classes_analyze__init_part3_A_Unit305__O(); A_arbace_classes_analyze__init_part3_A_Unit306__O(); A_arbace_classes_analyze__init_part3_A_Unit307__O(); A_arbace_classes_analyze__init_part3_A_Unit308__O(); A_arbace_classes_analyze__init_part3_A_Unit309__O(); A_arbace_classes_analyze__init_part3_A_Unit310__O(); A_arbace_classes_analyze__init_part3_A_Unit311__O(); A_arbace_classes_analyze__init_part3_A_Unit312__O(); A_arbace_classes_analyze__init_part3_A_Unit313__O(); A_arbace_classes_analyze__init_part3_A_Unit314__O(); A_arbace_classes_analyze__init_part3_A_Unit315__O(); A_arbace_classes_analyze__init_part3_A_Unit316__O(); A_arbace_classes_analyze__init_part3_A_Unit317__O(); A_arbace_classes_analyze__init_part3_A_Unit318__O(); A_arbace_classes_analyze__init_part3_A_Unit319__O(); A_arbace_classes_analyze__init_part3_A_Unit320__O(); A_arbace_classes_analyze__init_part3_A_Unit321__O(); A_arbace_classes_analyze__init_part3_A_Unit322__O(); A_arbace_classes_analyze__init_part3_A_Unit323__O(); A_arbace_classes_analyze__init_part3_A_Unit324__O(); A_arbace_classes_analyze__init_part3_A_Unit325__O(); A_arbace_classes_analyze__init_part3_A_Unit326__O(); A_arbace_classes_analyze__init_part3_A_Unit327__O(); A_arbace_classes_analyze__init_part3_A_Unit328__O(); A_arbace_classes_analyze__init_part3_A_Unit329__O(); A_arbace_classes_analyze__init_part3_A_Unit330__O(); A_arbace_classes_analyze__init_part3_A_Unit331__O(); A_arbace_classes_analyze__init_part3_A_Unit332__O(); A_arbace_classes_analyze__init_part3_A_Unit333__O(); A_arbace_classes_analyze__init_part3_A_Unit334__O(); A_arbace_classes_analyze__init_part3_A_Unit335__O(); A_arbace_classes_analyze__init_part3_A_Unit336__O(); A_arbace_classes_analyze__init_part3_A_Unit337__O(); A_arbace_classes_analyze__init_part3_A_Unit338__O(); A_arbace_classes_analyze__init_part3_A_Unit339__O(); A_arbace_classes_analyze__init_part3_A_Unit340__O(); A_arbace_classes_analyze__init_part3_A_Unit341__O(); A_arbace_classes_analyze__init_part3_A_Unit342__O(); A_arbace_classes_analyze__init_part3_A_Unit343__O(); A_arbace_classes_analyze__init_part3_A_Unit344__O(); return nil }









func A_arbace_classes_analyze__init_part3_A_Unit301__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3819, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_2; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_classes_analyze_accessible_class_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_classes_analyze_accessible_class_QMARK__A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1092, false, nil); A_arbace_classes_analyze_accessible_class_QMARK__A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_3)); return A_arbace_classes_analyze__init_part3_A_const_2 }




func A_arbace_classes_analyze__init_part3_A_Unit302__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3824, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_classes_analyze_sharpest_accessible_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_classes_analyze_sharpest_accessible_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1093, false, nil); A_arbace_classes_analyze_sharpest_accessible_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_5)); return A_arbace_classes_analyze__init_part3_A_const_4 }








func A_arbace_classes_analyze__init_part3_A_Unit303__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3833, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_classes_analyze_analyze_java_str_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_classes_analyze_analyze_java_str_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1094, false, nil); A_arbace_classes_analyze_analyze_java_str_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_7)); return A_arbace_classes_analyze__init_part3_A_const_6 }

























func A_arbace_classes_analyze__init_part3_A_Unit304__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3859, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_8; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_9)); return A_arbace_classes_analyze__init_part3_A_const_8 }

func A_arbace_classes_analyze__init_part3_A_Unit305__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3861, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_classes_analyze_analyze_java_assert_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_classes_analyze_analyze_java_assert_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1095, false, nil); A_arbace_classes_analyze_analyze_java_assert_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_11)); return A_arbace_classes_analyze__init_part3_A_const_10 }






func A_arbace_classes_analyze__init_part3_A_Unit306__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3868, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_classes_analyze_analyze_java_assert_STAR__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_classes_analyze_analyze_java_assert_STAR__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1096, false, nil); A_arbace_classes_analyze_analyze_java_assert_STAR__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_12)); return A_arbace_classes_analyze__init_part3_A_const_8 }


















func A_arbace_classes_analyze__init_part3_A_Unit307__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3887, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_13; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_classes_analyze_analyze_for_each_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_classes_analyze_analyze_for_each_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1097, false, nil); A_arbace_classes_analyze_analyze_for_each_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_14)); return A_arbace_classes_analyze__init_part3_A_const_13 }











































func A_arbace_classes_analyze__init_part3_A_Unit308__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3931, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_15; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_classes_analyze_analyze_with_resources_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_classes_analyze_analyze_with_resources_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1098, false, nil); A_arbace_classes_analyze_analyze_with_resources_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_16)); return A_arbace_classes_analyze__init_part3_A_const_15 }






































func A_arbace_classes_analyze__init_part3_A_Unit309__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3970, 1); A_arbace_classes_analyze__init_part3_A_const_17.BindRoot_O__V(A_arbace_classes_analyze__init_part3_A_const_18); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_17; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_19)); return A_arbace_classes_analyze__init_part3_A_const_17 }

func A_arbace_classes_analyze__init_part3_A_Unit310__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3972, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_classes_analyze_find_sam_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_classes_analyze_find_sam_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1099, false, nil); A_arbace_classes_analyze_find_sam_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_21)); return A_arbace_classes_analyze__init_part3_A_const_20 }





























func A_arbace_classes_analyze__init_part3_A_Unit311__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4002, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_22; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_23)); return A_arbace_classes_analyze__init_part3_A_const_22 }

func A_arbace_classes_analyze__init_part3_A_Unit312__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4004, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_classes_analyze_fi_types_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_classes_analyze_fi_types_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1100, false, nil); A_arbace_classes_analyze_fi_types_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_25)); return A_arbace_classes_analyze__init_part3_A_const_24 }









func A_arbace_classes_analyze__init_part3_A_Unit313__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4014, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_26; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_classes_analyze_serial_lambda_name_BANG__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_classes_analyze_serial_lambda_name_BANG__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1101, false, nil); A_arbace_classes_analyze_serial_lambda_name_BANG__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_27)); return A_arbace_classes_analyze__init_part3_A_const_26 }















func A_arbace_classes_analyze__init_part3_A_Unit314__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4030, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_classes_analyze_lambda_method_prefix_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_classes_analyze_lambda_method_prefix_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1102, false, nil); A_arbace_classes_analyze_lambda_method_prefix_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_28)); return A_arbace_classes_analyze__init_part3_A_const_22 }









func A_arbace_classes_analyze__init_part3_A_Unit315__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4040, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_29; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_classes_analyze_lambda_name_BANG__A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_classes_analyze_lambda_name_BANG__A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1103, false, nil); A_arbace_classes_analyze_lambda_name_BANG__A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_30)); return A_arbace_classes_analyze__init_part3_A_const_29 }






func A_arbace_classes_analyze__init_part3_A_Unit316__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4047, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_31; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_classes_analyze_lambda_ret_desc_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_classes_analyze_lambda_ret_desc_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1104, false, nil); A_arbace_classes_analyze_lambda_ret_desc_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_32)); return A_arbace_classes_analyze__init_part3_A_const_31 }










func A_arbace_classes_analyze__init_part3_A_Unit317__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4058, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_33; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_classes_analyze_analyze_lambda_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_classes_analyze_analyze_lambda_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1105, false, nil); A_arbace_classes_analyze_analyze_lambda_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_34)); return A_arbace_classes_analyze__init_part3_A_const_33 }








































func A_arbace_classes_analyze__init_part3_A_Unit318__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4099, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_35; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_classes_analyze_arg_stub_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_classes_analyze_arg_stub_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1106, false, nil); A_arbace_classes_analyze_arg_stub_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_36)); return A_arbace_classes_analyze__init_part3_A_const_35 }

func A_arbace_classes_analyze__init_part3_A_Unit319__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4101, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_37; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_classes_analyze_desc_tag_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_classes_analyze_desc_tag_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1107, false, nil); A_arbace_classes_analyze_desc_tag_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_38)); return A_arbace_classes_analyze__init_part3_A_const_37 }







func A_arbace_classes_analyze__init_part3_A_Unit320__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4109, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_39; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_classes_analyze_ref_as_lambda_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_classes_analyze_ref_as_lambda_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1108, false, nil); A_arbace_classes_analyze_ref_as_lambda_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_40)); return A_arbace_classes_analyze__init_part3_A_const_39 }







func A_arbace_classes_analyze__init_part3_A_Unit321__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4117, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_41; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_classes_analyze_ref_owner_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_classes_analyze_ref_owner_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1109, false, nil); A_arbace_classes_analyze_ref_owner_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_42)); return A_arbace_classes_analyze__init_part3_A_const_41 }





func A_arbace_classes_analyze__init_part3_A_Unit322__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4123, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_43; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_classes_analyze_select_ref_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_classes_analyze_select_ref_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1110, false, nil); A_arbace_classes_analyze_select_ref_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_44)); return A_arbace_classes_analyze__init_part3_A_const_43 }















func A_arbace_classes_analyze__init_part3_A_Unit323__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4139, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_45; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_classes_analyze_cast_args_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_classes_analyze_cast_args_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1111, false, nil); A_arbace_classes_analyze_cast_args_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_46)); return A_arbace_classes_analyze__init_part3_A_const_45 }





func A_arbace_classes_analyze__init_part3_A_Unit324__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4145, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_47; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_classes_analyze_analyze_method_ref_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_classes_analyze_analyze_method_ref_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1112, false, nil); A_arbace_classes_analyze_analyze_method_ref_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_48)); return A_arbace_classes_analyze__init_part3_A_const_47 }






















































































































func A_arbace_classes_analyze__init_part3_A_Unit325__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4264, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_49; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_classes_analyze_enum_class_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_classes_analyze_enum_class_QMARK__A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1113, false, nil); A_arbace_classes_analyze_enum_class_QMARK__A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_50)); return A_arbace_classes_analyze__init_part3_A_const_49 }


func A_arbace_classes_analyze__init_part3_A_Unit326__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4267, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_51; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__48 any = A_arbace_classes_analyze_analyze_pattern_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_classes_analyze_analyze_pattern_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1114, true, nil); A_arbace_classes_analyze_analyze_pattern_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__48, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_52)); return A_arbace_classes_analyze__init_part3_A_const_51 }




















































func A_arbace_classes_analyze__init_part3_A_Unit327__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4320, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_53; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_classes_analyze_analyze_if_instance_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_classes_analyze_analyze_if_instance_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1115, false, nil); A_arbace_classes_analyze_analyze_if_instance_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_54)); return A_arbace_classes_analyze__init_part3_A_const_53 }












func A_arbace_classes_analyze__init_part3_A_Unit328__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4333, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_55; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_classes_analyze_switch_map_BANG__A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_classes_analyze_switch_map_BANG__A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1116, false, nil); A_arbace_classes_analyze_switch_map_BANG__A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_56)); return A_arbace_classes_analyze__init_part3_A_const_55 }













func A_arbace_classes_analyze__init_part3_A_Unit329__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4347, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_57; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_classes_analyze_constant_label_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_classes_analyze_constant_label_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1117, false, nil); A_arbace_classes_analyze_constant_label_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_58)); return A_arbace_classes_analyze__init_part3_A_const_57 }







func A_arbace_classes_analyze__init_part3_A_Unit330__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4355, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_59; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_classes_analyze_analyze_switch_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_classes_analyze_analyze_switch_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1118, false, nil); A_arbace_classes_analyze_analyze_switch_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_60)); return A_arbace_classes_analyze__init_part3_A_const_59 }


















































































































func A_arbace_classes_analyze__init_part3_A_Unit331__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4470, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_61; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_classes_analyze_read_source_forms_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_classes_analyze_read_source_forms_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1119, false, nil); A_arbace_classes_analyze_read_source_forms_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_62)); return A_arbace_classes_analyze__init_part3_A_const_61 }





func A_arbace_classes_analyze__init_part3_A_Unit332__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4476, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_63; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_classes_analyze_import_classes_BANG__A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_classes_analyze_import_classes_BANG__A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1120, false, nil); A_arbace_classes_analyze_import_classes_BANG__A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_64)); return A_arbace_classes_analyze__init_part3_A_const_63 }





















func A_arbace_classes_analyze__init_part3_A_Unit333__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4498, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_65; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_classes_analyze_eval_ns_form_BANG__A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_classes_analyze_eval_ns_form_BANG__A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1121, false, nil); A_arbace_classes_analyze_eval_ns_form_BANG__A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_66)); return A_arbace_classes_analyze__init_part3_A_const_65 }









func A_arbace_classes_analyze__init_part3_A_Unit334__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4508, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_67; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_classes_analyze_enter_file_BANG__A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_classes_analyze_enter_file_BANG__A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1122, false, nil); A_arbace_classes_analyze_enter_file_BANG__A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_68)); return A_arbace_classes_analyze__init_part3_A_const_67 }















































func A_arbace_classes_analyze__init_part3_A_Unit335__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4556, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_69; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_classes_analyze_enter_from_source_BANG__A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_classes_analyze_enter_from_source_BANG__A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1123, false, nil); A_arbace_classes_analyze_enter_from_source_BANG__A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_70)); return A_arbace_classes_analyze__init_part3_A_const_69 }


























func A_arbace_classes_analyze__init_part3_A_Unit336__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4583, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_71; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_classes_analyze_add_accessor_BANG__A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_classes_analyze_add_accessor_BANG__A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1124, false, nil); A_arbace_classes_analyze_add_accessor_BANG__A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_72)); return A_arbace_classes_analyze__init_part3_A_const_71 }











func A_arbace_classes_analyze__init_part3_A_Unit337__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4595, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_73; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__70 any = A_arbace_classes_analyze_accessor_owner_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_classes_analyze_accessor_owner_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1125, true, nil); A_arbace_classes_analyze_accessor_owner_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__70, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_74)); return A_arbace_classes_analyze__init_part3_A_const_73 }





















func A_arbace_classes_analyze__init_part3_A_Unit338__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4617, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_75; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_classes_analyze_accessorize_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_classes_analyze_accessorize_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1126, false, nil); A_arbace_classes_analyze_accessorize_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_76)); return A_arbace_classes_analyze__init_part3_A_const_75 }






































func A_arbace_classes_analyze__init_part3_A_Unit339__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4656, 1); A_arbace_classes_analyze__init_part3_A_const_77.BindRoot_O__V(jrt.Boolean_TRUE.Ref()); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_77; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_78)); return A_arbace_classes_analyze__init_part3_A_const_77.SetDynamic_Z__Var(true).Ref() }




func A_arbace_classes_analyze__init_part3_A_Unit340__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4661, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_79; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_classes_analyze_outer_super_call_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_classes_analyze_outer_super_call_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1127, false, nil); A_arbace_classes_analyze_outer_super_call_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_80)); return A_arbace_classes_analyze__init_part3_A_const_79 }

























func A_arbace_classes_analyze__init_part3_A_Unit341__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4687, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_81; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_classes_analyze_constant_field_BANG__A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_classes_analyze_constant_field_BANG__A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1128, false, nil); A_arbace_classes_analyze_constant_field_BANG__A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_82)); return A_arbace_classes_analyze__init_part3_A_const_81 }
















func A_arbace_classes_analyze__init_part3_A_Unit342__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4704, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_83; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_classes_analyze_clj_constant_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_classes_analyze_clj_constant_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1129, false, nil); A_arbace_classes_analyze_clj_constant_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_84)); return A_arbace_classes_analyze__init_part3_A_const_83 }








func A_arbace_classes_analyze__init_part3_A_Unit343__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4713, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_85; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_classes_analyze_clj_var_field_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_classes_analyze_clj_var_field_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1130, false, nil); A_arbace_classes_analyze_clj_var_field_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_86)); return A_arbace_classes_analyze__init_part3_A_const_85 }



func A_arbace_classes_analyze__init_part3_A_Unit344__O() any { A_arbace_classes_analyze__init_part3_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(4717, 1); var tmp1 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_87; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_classes_analyze_clj_collection_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_classes_analyze_clj_collection_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1131, false, nil); A_arbace_classes_analyze_clj_collection_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_analyze__init_part3_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_analyze__init_part3_A_const_88)); return A_arbace_classes_analyze__init_part3_A_const_87 }



type A_arbace_classes_analyze__init_A struct{ jrt.Object }

func A_arbace_classes_analyze__init_A_New() *A_arbace_classes_analyze__init_A { t := &A_arbace_classes_analyze__init_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_analyze__init_A) Ctor() {}

func (t *A_arbace_classes_analyze__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_analyze__init_A) GetClass__Class() *jrt.Class { return A_arbace_classes_analyze__init_A_class }

func (t *A_arbace_classes_analyze__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_analyze__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_analyze__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_analyze__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_analyze__init_A); return ok }

func A_arbace_classes_analyze__init_A_Cast(x any) *A_arbace_classes_analyze__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_analyze__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_analyze__init_A_class)) }; return v }



type A_arbace_classes_analyze__init_part0_A struct{ jrt.Object }

var A_arbace_classes_analyze__init_part0_A_const_pool *jrt.RefArray

var A_arbace_classes_analyze__init_part0_A_const_0 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_1 any

var A_arbace_classes_analyze__init_part0_A_const_2 any

var A_arbace_classes_analyze__init_part0_A_const_3 any

var A_arbace_classes_analyze__init_part0_A_const_4 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_5 any

var A_arbace_classes_analyze__init_part0_A_const_6 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_7 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_8 any

var A_arbace_classes_analyze__init_part0_A_const_9 any

var A_arbace_classes_analyze__init_part0_A_const_10 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_11 any

var A_arbace_classes_analyze__init_part0_A_const_12 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_13 any

var A_arbace_classes_analyze__init_part0_A_const_14 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_15 any

var A_arbace_classes_analyze__init_part0_A_const_16 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_17 any

var A_arbace_classes_analyze__init_part0_A_const_18 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_19 any

var A_arbace_classes_analyze__init_part0_A_const_20 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_21 any

var A_arbace_classes_analyze__init_part0_A_const_22 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_23 any

var A_arbace_classes_analyze__init_part0_A_const_24 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_25 any

var A_arbace_classes_analyze__init_part0_A_const_26 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_27 any

var A_arbace_classes_analyze__init_part0_A_const_28 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_29 any

var A_arbace_classes_analyze__init_part0_A_const_30 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_31 any

var A_arbace_classes_analyze__init_part0_A_const_32 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_33 any

var A_arbace_classes_analyze__init_part0_A_const_34 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_35 any

var A_arbace_classes_analyze__init_part0_A_const_36 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_37 any

var A_arbace_classes_analyze__init_part0_A_const_38 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_39 any

var A_arbace_classes_analyze__init_part0_A_const_40 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_41 any

var A_arbace_classes_analyze__init_part0_A_const_42 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_43 any

var A_arbace_classes_analyze__init_part0_A_const_44 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_45 any

var A_arbace_classes_analyze__init_part0_A_const_46 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_47 any

var A_arbace_classes_analyze__init_part0_A_const_48 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_49 any

var A_arbace_classes_analyze__init_part0_A_const_50 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_51 any

var A_arbace_classes_analyze__init_part0_A_const_52 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_53 any

var A_arbace_classes_analyze__init_part0_A_const_54 any

var A_arbace_classes_analyze__init_part0_A_const_55 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_56 any

var A_arbace_classes_analyze__init_part0_A_const_57 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_58 any

var A_arbace_classes_analyze__init_part0_A_const_59 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_60 any

var A_arbace_classes_analyze__init_part0_A_const_61 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_62 any

var A_arbace_classes_analyze__init_part0_A_const_63 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_64 any

var A_arbace_classes_analyze__init_part0_A_const_65 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_66 any

var A_arbace_classes_analyze__init_part0_A_const_67 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_68 any

var A_arbace_classes_analyze__init_part0_A_const_69 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_70 any

var A_arbace_classes_analyze__init_part0_A_const_71 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_72 any

var A_arbace_classes_analyze__init_part0_A_const_73 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_74 any

var A_arbace_classes_analyze__init_part0_A_const_75 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_76 any

var A_arbace_classes_analyze__init_part0_A_const_77 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_78 any

var A_arbace_classes_analyze__init_part0_A_const_79 any

var A_arbace_classes_analyze__init_part0_A_const_80 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_81 any

var A_arbace_classes_analyze__init_part0_A_const_82 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_83 any

var A_arbace_classes_analyze__init_part0_A_const_84 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_85 any

var A_arbace_classes_analyze__init_part0_A_const_86 any

var A_arbace_classes_analyze__init_part0_A_const_87 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_88 any

var A_arbace_classes_analyze__init_part0_A_const_89 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_90 any

var A_arbace_classes_analyze__init_part0_A_const_91 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_92 any

var A_arbace_classes_analyze__init_part0_A_const_93 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_94 any

var A_arbace_classes_analyze__init_part0_A_const_95 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_96 any

var A_arbace_classes_analyze__init_part0_A_const_97 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_98 any

var A_arbace_classes_analyze__init_part0_A_const_99 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_100 any

var A_arbace_classes_analyze__init_part0_A_const_101 any

var A_arbace_classes_analyze__init_part0_A_const_102 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_103 any

var A_arbace_classes_analyze__init_part0_A_const_104 any

var A_arbace_classes_analyze__init_part0_A_const_105 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_106 any

var A_arbace_classes_analyze__init_part0_A_const_107 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_108 any

var A_arbace_classes_analyze__init_part0_A_const_109 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_110 any

var A_arbace_classes_analyze__init_part0_A_const_111 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_112 any

var A_arbace_classes_analyze__init_part0_A_const_113 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_114 any

var A_arbace_classes_analyze__init_part0_A_const_115 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_116 any

var A_arbace_classes_analyze__init_part0_A_const_117 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_118 any

var A_arbace_classes_analyze__init_part0_A_const_119 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_120 any

var A_arbace_classes_analyze__init_part0_A_const_121 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_122 any

var A_arbace_classes_analyze__init_part0_A_const_123 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_124 any

var A_arbace_classes_analyze__init_part0_A_const_125 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_126 any

var A_arbace_classes_analyze__init_part0_A_const_127 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_128 any

var A_arbace_classes_analyze__init_part0_A_const_129 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_130 any

var A_arbace_classes_analyze__init_part0_A_const_131 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_132 any

var A_arbace_classes_analyze__init_part0_A_const_133 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_134 any

var A_arbace_classes_analyze__init_part0_A_const_135 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_136 any

var A_arbace_classes_analyze__init_part0_A_const_137 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_138 any

var A_arbace_classes_analyze__init_part0_A_const_139 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_140 any

var A_arbace_classes_analyze__init_part0_A_const_141 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_142 any

var A_arbace_classes_analyze__init_part0_A_const_143 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_144 any

var A_arbace_classes_analyze__init_part0_A_const_145 any

var A_arbace_classes_analyze__init_part0_A_const_146 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_147 any

var A_arbace_classes_analyze__init_part0_A_const_148 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_149 any

var A_arbace_classes_analyze__init_part0_A_const_150 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_151 any

var A_arbace_classes_analyze__init_part0_A_const_152 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_153 any

var A_arbace_classes_analyze__init_part0_A_const_154 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_155 any

var A_arbace_classes_analyze__init_part0_A_const_156 any

var A_arbace_classes_analyze__init_part0_A_const_157 any

var A_arbace_classes_analyze__init_part0_A_const_158 any

var A_arbace_classes_analyze__init_part0_A_const_159 any

var A_arbace_classes_analyze__init_part0_A_const_160 any

var A_arbace_classes_analyze__init_part0_A_const_161 any

var A_arbace_classes_analyze__init_part0_A_const_162 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_163 any

var A_arbace_classes_analyze__init_part0_A_const_164 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_165 any

var A_arbace_classes_analyze__init_part0_A_const_166 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_167 any

var A_arbace_classes_analyze__init_part0_A_const_168 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_169 any

var A_arbace_classes_analyze__init_part0_A_const_170 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_171 any

var A_arbace_classes_analyze__init_part0_A_const_172 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_173 any

var A_arbace_classes_analyze__init_part0_A_const_174 any

var A_arbace_classes_analyze__init_part0_A_const_175 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_176 any

var A_arbace_classes_analyze__init_part0_A_const_177 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_178 any

var A_arbace_classes_analyze__init_part0_A_const_179 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_180 any

var A_arbace_classes_analyze__init_part0_A_const_181 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_182 any

var A_arbace_classes_analyze__init_part0_A_const_183 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_184 any

var A_arbace_classes_analyze__init_part0_A_const_185 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_186 any

var A_arbace_classes_analyze__init_part0_A_const_187 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_188 any

var A_arbace_classes_analyze__init_part0_A_const_189 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_190 any

var A_arbace_classes_analyze__init_part0_A_const_191 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_192 any

var A_arbace_classes_analyze__init_part0_A_const_193 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_194 any

var A_arbace_classes_analyze__init_part0_A_const_195 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_196 any

var A_arbace_classes_analyze__init_part0_A_const_197 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_198 any

var A_arbace_classes_analyze__init_part0_A_const_199 *lang.Var

var A_arbace_classes_analyze__init_part0_A_const_200 any

var A_arbace_classes_analyze__init_part0_A_init jrt.ClassInit

func A_arbace_classes_analyze__init_part0_A_Init() { if !A_arbace_classes_analyze__init_part0_A_init.Done() { A_arbace_classes_analyze__init_part0_A_init.Run(A_arbace_classes_analyze__init_part0_A_clinit) } }

func A_arbace_classes_analyze__init_part0_A_clinit() { A_arbace_classes_analyze__init_part0_A_clinit_p0(); A_arbace_classes_analyze__init_part0_A_clinit_p1(); A_arbace_classes_analyze__init_part0_A_clinit_p2(); A_arbace_classes_analyze__init_part0_A_clinit_p3(); A_arbace_classes_analyze__init_part0_A_clinit_p4(); A_arbace_classes_analyze__init_part0_A_clinit_p5(); A_arbace_classes_analyze__init_part0_A_clinit_p6(); A_arbace_classes_analyze__init_part0_A_clinit_p7(); A_arbace_classes_analyze__init_part0_A_clinit_p8(); A_arbace_classes_analyze__init_part0_A_clinit_p9(); A_arbace_classes_analyze__init_part0_A_clinit_p10(); A_arbace_classes_analyze__init_part0_A_clinit_p11(); A_arbace_classes_analyze__init_part0_A_clinit_p12(); A_arbace_classes_analyze__init_part0_A_clinit_p13(); A_arbace_classes_analyze__init_part0_A_clinit_p14(); A_arbace_classes_analyze__init_part0_A_clinit_p15() }

func A_arbace_classes_analyze__init_part0_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_analyze__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_865, 286); A_arbace_classes_analyze__init_part0_A_const_0 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[85]); A_arbace_classes_analyze__init_part0_A_const_1 = A_arbace_classes_analyze__init_part0_A_const_pool.A[86]; A_arbace_classes_analyze__init_part0_A_const_2 = A_arbace_classes_analyze__init_part0_A_const_pool.A[87]; A_arbace_classes_analyze__init_part0_A_const_3 = A_arbace_classes_analyze__init_part0_A_const_pool.A[88]; A_arbace_classes_analyze__init_part0_A_const_4 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[89]); A_arbace_classes_analyze__init_part0_A_const_5 = A_arbace_classes_analyze__init_part0_A_const_pool.A[90]; A_arbace_classes_analyze__init_part0_A_const_6 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[91]); A_arbace_classes_analyze__init_part0_A_const_7 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[92]); A_arbace_classes_analyze__init_part0_A_const_8 = A_arbace_classes_analyze__init_part0_A_const_pool.A[93]; A_arbace_classes_analyze__init_part0_A_const_9 = A_arbace_classes_analyze__init_part0_A_const_pool.A[94]; A_arbace_classes_analyze__init_part0_A_const_10 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[95]); A_arbace_classes_analyze__init_part0_A_const_11 = A_arbace_classes_analyze__init_part0_A_const_pool.A[96]; A_arbace_classes_analyze__init_part0_A_const_12 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[97]) }

func A_arbace_classes_analyze__init_part0_A_clinit_p1() { A_arbace_classes_analyze__init_part0_A_const_13 = A_arbace_classes_analyze__init_part0_A_const_pool.A[98]; A_arbace_classes_analyze__init_part0_A_const_14 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[99]); A_arbace_classes_analyze__init_part0_A_const_15 = A_arbace_classes_analyze__init_part0_A_const_pool.A[100]; A_arbace_classes_analyze__init_part0_A_const_16 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[101]); A_arbace_classes_analyze__init_part0_A_const_17 = A_arbace_classes_analyze__init_part0_A_const_pool.A[102]; A_arbace_classes_analyze__init_part0_A_const_18 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[103]); A_arbace_classes_analyze__init_part0_A_const_19 = A_arbace_classes_analyze__init_part0_A_const_pool.A[104]; A_arbace_classes_analyze__init_part0_A_const_20 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[105]); A_arbace_classes_analyze__init_part0_A_const_21 = A_arbace_classes_analyze__init_part0_A_const_pool.A[106]; A_arbace_classes_analyze__init_part0_A_const_22 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[107]); A_arbace_classes_analyze__init_part0_A_const_23 = A_arbace_classes_analyze__init_part0_A_const_pool.A[108]; A_arbace_classes_analyze__init_part0_A_const_24 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[109]); A_arbace_classes_analyze__init_part0_A_const_25 = A_arbace_classes_analyze__init_part0_A_const_pool.A[110] }

func A_arbace_classes_analyze__init_part0_A_clinit_p2() { A_arbace_classes_analyze__init_part0_A_const_26 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[111]); A_arbace_classes_analyze__init_part0_A_const_27 = A_arbace_classes_analyze__init_part0_A_const_pool.A[112]; A_arbace_classes_analyze__init_part0_A_const_28 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[113]); A_arbace_classes_analyze__init_part0_A_const_29 = A_arbace_classes_analyze__init_part0_A_const_pool.A[114]; A_arbace_classes_analyze__init_part0_A_const_30 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[115]); A_arbace_classes_analyze__init_part0_A_const_31 = A_arbace_classes_analyze__init_part0_A_const_pool.A[116]; A_arbace_classes_analyze__init_part0_A_const_32 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[117]); A_arbace_classes_analyze__init_part0_A_const_33 = A_arbace_classes_analyze__init_part0_A_const_pool.A[118]; A_arbace_classes_analyze__init_part0_A_const_34 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[119]); A_arbace_classes_analyze__init_part0_A_const_35 = A_arbace_classes_analyze__init_part0_A_const_pool.A[120]; A_arbace_classes_analyze__init_part0_A_const_36 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[121]); A_arbace_classes_analyze__init_part0_A_const_37 = A_arbace_classes_analyze__init_part0_A_const_pool.A[122]; A_arbace_classes_analyze__init_part0_A_const_38 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[123]) }

func A_arbace_classes_analyze__init_part0_A_clinit_p3() { A_arbace_classes_analyze__init_part0_A_const_39 = A_arbace_classes_analyze__init_part0_A_const_pool.A[124]; A_arbace_classes_analyze__init_part0_A_const_40 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[125]); A_arbace_classes_analyze__init_part0_A_const_41 = A_arbace_classes_analyze__init_part0_A_const_pool.A[126]; A_arbace_classes_analyze__init_part0_A_const_42 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[127]); A_arbace_classes_analyze__init_part0_A_const_43 = A_arbace_classes_analyze__init_part0_A_const_pool.A[128]; A_arbace_classes_analyze__init_part0_A_const_44 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[129]); A_arbace_classes_analyze__init_part0_A_const_45 = A_arbace_classes_analyze__init_part0_A_const_pool.A[130]; A_arbace_classes_analyze__init_part0_A_const_46 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[131]); A_arbace_classes_analyze__init_part0_A_const_47 = A_arbace_classes_analyze__init_part0_A_const_pool.A[132]; A_arbace_classes_analyze__init_part0_A_const_48 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[133]); A_arbace_classes_analyze__init_part0_A_const_49 = A_arbace_classes_analyze__init_part0_A_const_pool.A[134]; A_arbace_classes_analyze__init_part0_A_const_50 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[135]); A_arbace_classes_analyze__init_part0_A_const_51 = A_arbace_classes_analyze__init_part0_A_const_pool.A[136] }

func A_arbace_classes_analyze__init_part0_A_clinit_p4() { A_arbace_classes_analyze__init_part0_A_const_52 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[137]); A_arbace_classes_analyze__init_part0_A_const_53 = A_arbace_classes_analyze__init_part0_A_const_pool.A[138]; A_arbace_classes_analyze__init_part0_A_const_54 = A_arbace_classes_analyze__init_part0_A_const_pool.A[139]; A_arbace_classes_analyze__init_part0_A_const_55 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[140]); A_arbace_classes_analyze__init_part0_A_const_56 = A_arbace_classes_analyze__init_part0_A_const_pool.A[141]; A_arbace_classes_analyze__init_part0_A_const_57 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[142]); A_arbace_classes_analyze__init_part0_A_const_58 = A_arbace_classes_analyze__init_part0_A_const_pool.A[143]; A_arbace_classes_analyze__init_part0_A_const_59 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[144]); A_arbace_classes_analyze__init_part0_A_const_60 = A_arbace_classes_analyze__init_part0_A_const_pool.A[145]; A_arbace_classes_analyze__init_part0_A_const_61 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[146]); A_arbace_classes_analyze__init_part0_A_const_62 = A_arbace_classes_analyze__init_part0_A_const_pool.A[147]; A_arbace_classes_analyze__init_part0_A_const_63 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[148]); A_arbace_classes_analyze__init_part0_A_const_64 = A_arbace_classes_analyze__init_part0_A_const_pool.A[149] }

func A_arbace_classes_analyze__init_part0_A_clinit_p5() { A_arbace_classes_analyze__init_part0_A_const_65 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[150]); A_arbace_classes_analyze__init_part0_A_const_66 = A_arbace_classes_analyze__init_part0_A_const_pool.A[151]; A_arbace_classes_analyze__init_part0_A_const_67 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[152]); A_arbace_classes_analyze__init_part0_A_const_68 = A_arbace_classes_analyze__init_part0_A_const_pool.A[153]; A_arbace_classes_analyze__init_part0_A_const_69 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[154]); A_arbace_classes_analyze__init_part0_A_const_70 = A_arbace_classes_analyze__init_part0_A_const_pool.A[155]; A_arbace_classes_analyze__init_part0_A_const_71 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[156]); A_arbace_classes_analyze__init_part0_A_const_72 = A_arbace_classes_analyze__init_part0_A_const_pool.A[157]; A_arbace_classes_analyze__init_part0_A_const_73 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[158]); A_arbace_classes_analyze__init_part0_A_const_74 = A_arbace_classes_analyze__init_part0_A_const_pool.A[159]; A_arbace_classes_analyze__init_part0_A_const_75 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[160]); A_arbace_classes_analyze__init_part0_A_const_76 = A_arbace_classes_analyze__init_part0_A_const_pool.A[161]; A_arbace_classes_analyze__init_part0_A_const_77 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[162]) }

func A_arbace_classes_analyze__init_part0_A_clinit_p6() { A_arbace_classes_analyze__init_part0_A_const_78 = A_arbace_classes_analyze__init_part0_A_const_pool.A[163]; A_arbace_classes_analyze__init_part0_A_const_79 = A_arbace_classes_analyze__init_part0_A_const_pool.A[164]; A_arbace_classes_analyze__init_part0_A_const_80 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[165]); A_arbace_classes_analyze__init_part0_A_const_81 = A_arbace_classes_analyze__init_part0_A_const_pool.A[166]; A_arbace_classes_analyze__init_part0_A_const_82 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[167]); A_arbace_classes_analyze__init_part0_A_const_83 = A_arbace_classes_analyze__init_part0_A_const_pool.A[168]; A_arbace_classes_analyze__init_part0_A_const_84 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[169]); A_arbace_classes_analyze__init_part0_A_const_85 = A_arbace_classes_analyze__init_part0_A_const_pool.A[170]; A_arbace_classes_analyze__init_part0_A_const_86 = A_arbace_classes_analyze__init_part0_A_const_pool.A[171]; A_arbace_classes_analyze__init_part0_A_const_87 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[172]); A_arbace_classes_analyze__init_part0_A_const_88 = A_arbace_classes_analyze__init_part0_A_const_pool.A[173]; A_arbace_classes_analyze__init_part0_A_const_89 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[174]); A_arbace_classes_analyze__init_part0_A_const_90 = A_arbace_classes_analyze__init_part0_A_const_pool.A[175]; A_arbace_classes_analyze__init_part0_A_const_91 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[176]) }

func A_arbace_classes_analyze__init_part0_A_clinit_p7() { A_arbace_classes_analyze__init_part0_A_const_92 = A_arbace_classes_analyze__init_part0_A_const_pool.A[177]; A_arbace_classes_analyze__init_part0_A_const_93 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[178]); A_arbace_classes_analyze__init_part0_A_const_94 = A_arbace_classes_analyze__init_part0_A_const_pool.A[179]; A_arbace_classes_analyze__init_part0_A_const_95 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[180]); A_arbace_classes_analyze__init_part0_A_const_96 = A_arbace_classes_analyze__init_part0_A_const_pool.A[181]; A_arbace_classes_analyze__init_part0_A_const_97 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[182]); A_arbace_classes_analyze__init_part0_A_const_98 = A_arbace_classes_analyze__init_part0_A_const_pool.A[183]; A_arbace_classes_analyze__init_part0_A_const_99 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[184]); A_arbace_classes_analyze__init_part0_A_const_100 = A_arbace_classes_analyze__init_part0_A_const_pool.A[185]; A_arbace_classes_analyze__init_part0_A_const_101 = A_arbace_classes_analyze__init_part0_A_const_pool.A[186]; A_arbace_classes_analyze__init_part0_A_const_102 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[187]); A_arbace_classes_analyze__init_part0_A_const_103 = A_arbace_classes_analyze__init_part0_A_const_pool.A[188]; A_arbace_classes_analyze__init_part0_A_const_104 = A_arbace_classes_analyze__init_part0_A_const_pool.A[189]; A_arbace_classes_analyze__init_part0_A_const_105 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[190]) }

func A_arbace_classes_analyze__init_part0_A_clinit_p8() { A_arbace_classes_analyze__init_part0_A_const_106 = A_arbace_classes_analyze__init_part0_A_const_pool.A[191]; A_arbace_classes_analyze__init_part0_A_const_107 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[192]); A_arbace_classes_analyze__init_part0_A_const_108 = A_arbace_classes_analyze__init_part0_A_const_pool.A[193]; A_arbace_classes_analyze__init_part0_A_const_109 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[194]); A_arbace_classes_analyze__init_part0_A_const_110 = A_arbace_classes_analyze__init_part0_A_const_pool.A[195]; A_arbace_classes_analyze__init_part0_A_const_111 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[196]); A_arbace_classes_analyze__init_part0_A_const_112 = A_arbace_classes_analyze__init_part0_A_const_pool.A[197]; A_arbace_classes_analyze__init_part0_A_const_113 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[198]); A_arbace_classes_analyze__init_part0_A_const_114 = A_arbace_classes_analyze__init_part0_A_const_pool.A[199]; A_arbace_classes_analyze__init_part0_A_const_115 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[200]); A_arbace_classes_analyze__init_part0_A_const_116 = A_arbace_classes_analyze__init_part0_A_const_pool.A[201]; A_arbace_classes_analyze__init_part0_A_const_117 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[202]); A_arbace_classes_analyze__init_part0_A_const_118 = A_arbace_classes_analyze__init_part0_A_const_pool.A[203] }

func A_arbace_classes_analyze__init_part0_A_clinit_p9() { A_arbace_classes_analyze__init_part0_A_const_119 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[204]); A_arbace_classes_analyze__init_part0_A_const_120 = A_arbace_classes_analyze__init_part0_A_const_pool.A[205]; A_arbace_classes_analyze__init_part0_A_const_121 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[206]); A_arbace_classes_analyze__init_part0_A_const_122 = A_arbace_classes_analyze__init_part0_A_const_pool.A[207]; A_arbace_classes_analyze__init_part0_A_const_123 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[208]); A_arbace_classes_analyze__init_part0_A_const_124 = A_arbace_classes_analyze__init_part0_A_const_pool.A[209]; A_arbace_classes_analyze__init_part0_A_const_125 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[210]); A_arbace_classes_analyze__init_part0_A_const_126 = A_arbace_classes_analyze__init_part0_A_const_pool.A[211]; A_arbace_classes_analyze__init_part0_A_const_127 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[212]); A_arbace_classes_analyze__init_part0_A_const_128 = A_arbace_classes_analyze__init_part0_A_const_pool.A[213]; A_arbace_classes_analyze__init_part0_A_const_129 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[214]); A_arbace_classes_analyze__init_part0_A_const_130 = A_arbace_classes_analyze__init_part0_A_const_pool.A[215]; A_arbace_classes_analyze__init_part0_A_const_131 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[216]) }

func A_arbace_classes_analyze__init_part0_A_clinit_p10() { A_arbace_classes_analyze__init_part0_A_const_132 = A_arbace_classes_analyze__init_part0_A_const_pool.A[217]; A_arbace_classes_analyze__init_part0_A_const_133 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[218]); A_arbace_classes_analyze__init_part0_A_const_134 = A_arbace_classes_analyze__init_part0_A_const_pool.A[219]; A_arbace_classes_analyze__init_part0_A_const_135 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[220]); A_arbace_classes_analyze__init_part0_A_const_136 = A_arbace_classes_analyze__init_part0_A_const_pool.A[221]; A_arbace_classes_analyze__init_part0_A_const_137 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[222]); A_arbace_classes_analyze__init_part0_A_const_138 = A_arbace_classes_analyze__init_part0_A_const_pool.A[223]; A_arbace_classes_analyze__init_part0_A_const_139 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[224]); A_arbace_classes_analyze__init_part0_A_const_140 = A_arbace_classes_analyze__init_part0_A_const_pool.A[225]; A_arbace_classes_analyze__init_part0_A_const_141 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[226]); A_arbace_classes_analyze__init_part0_A_const_142 = A_arbace_classes_analyze__init_part0_A_const_pool.A[227]; A_arbace_classes_analyze__init_part0_A_const_143 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[228]); A_arbace_classes_analyze__init_part0_A_const_144 = A_arbace_classes_analyze__init_part0_A_const_pool.A[229]; A_arbace_classes_analyze__init_part0_A_const_145 = A_arbace_classes_analyze__init_part0_A_const_pool.A[230] }

func A_arbace_classes_analyze__init_part0_A_clinit_p11() { A_arbace_classes_analyze__init_part0_A_const_146 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[231]); A_arbace_classes_analyze__init_part0_A_const_147 = A_arbace_classes_analyze__init_part0_A_const_pool.A[232]; A_arbace_classes_analyze__init_part0_A_const_148 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[233]); A_arbace_classes_analyze__init_part0_A_const_149 = A_arbace_classes_analyze__init_part0_A_const_pool.A[234]; A_arbace_classes_analyze__init_part0_A_const_150 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[235]); A_arbace_classes_analyze__init_part0_A_const_151 = A_arbace_classes_analyze__init_part0_A_const_pool.A[236]; A_arbace_classes_analyze__init_part0_A_const_152 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[237]); A_arbace_classes_analyze__init_part0_A_const_153 = A_arbace_classes_analyze__init_part0_A_const_pool.A[238]; A_arbace_classes_analyze__init_part0_A_const_154 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[239]); A_arbace_classes_analyze__init_part0_A_const_155 = A_arbace_classes_analyze__init_part0_A_const_pool.A[240]; A_arbace_classes_analyze__init_part0_A_const_156 = A_arbace_classes_analyze__init_part0_A_const_pool.A[241]; A_arbace_classes_analyze__init_part0_A_const_157 = A_arbace_classes_analyze__init_part0_A_const_pool.A[242]; A_arbace_classes_analyze__init_part0_A_const_158 = A_arbace_classes_analyze__init_part0_A_const_pool.A[243]; A_arbace_classes_analyze__init_part0_A_const_159 = A_arbace_classes_analyze__init_part0_A_const_pool.A[244] }

func A_arbace_classes_analyze__init_part0_A_clinit_p12() { A_arbace_classes_analyze__init_part0_A_const_160 = A_arbace_classes_analyze__init_part0_A_const_pool.A[245]; A_arbace_classes_analyze__init_part0_A_const_161 = A_arbace_classes_analyze__init_part0_A_const_pool.A[246]; A_arbace_classes_analyze__init_part0_A_const_162 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[247]); A_arbace_classes_analyze__init_part0_A_const_163 = A_arbace_classes_analyze__init_part0_A_const_pool.A[248]; A_arbace_classes_analyze__init_part0_A_const_164 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[249]); A_arbace_classes_analyze__init_part0_A_const_165 = A_arbace_classes_analyze__init_part0_A_const_pool.A[250]; A_arbace_classes_analyze__init_part0_A_const_166 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[251]); A_arbace_classes_analyze__init_part0_A_const_167 = A_arbace_classes_analyze__init_part0_A_const_pool.A[252]; A_arbace_classes_analyze__init_part0_A_const_168 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[253]); A_arbace_classes_analyze__init_part0_A_const_169 = A_arbace_classes_analyze__init_part0_A_const_pool.A[254]; A_arbace_classes_analyze__init_part0_A_const_170 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[255]); A_arbace_classes_analyze__init_part0_A_const_171 = A_arbace_classes_analyze__init_part0_A_const_pool.A[256]; A_arbace_classes_analyze__init_part0_A_const_172 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[257]); A_arbace_classes_analyze__init_part0_A_const_173 = A_arbace_classes_analyze__init_part0_A_const_pool.A[258] }

func A_arbace_classes_analyze__init_part0_A_clinit_p13() { A_arbace_classes_analyze__init_part0_A_const_174 = A_arbace_classes_analyze__init_part0_A_const_pool.A[259]; A_arbace_classes_analyze__init_part0_A_const_175 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[260]); A_arbace_classes_analyze__init_part0_A_const_176 = A_arbace_classes_analyze__init_part0_A_const_pool.A[261]; A_arbace_classes_analyze__init_part0_A_const_177 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[262]); A_arbace_classes_analyze__init_part0_A_const_178 = A_arbace_classes_analyze__init_part0_A_const_pool.A[263]; A_arbace_classes_analyze__init_part0_A_const_179 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[264]); A_arbace_classes_analyze__init_part0_A_const_180 = A_arbace_classes_analyze__init_part0_A_const_pool.A[265]; A_arbace_classes_analyze__init_part0_A_const_181 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[266]); A_arbace_classes_analyze__init_part0_A_const_182 = A_arbace_classes_analyze__init_part0_A_const_pool.A[267]; A_arbace_classes_analyze__init_part0_A_const_183 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[268]); A_arbace_classes_analyze__init_part0_A_const_184 = A_arbace_classes_analyze__init_part0_A_const_pool.A[269]; A_arbace_classes_analyze__init_part0_A_const_185 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[270]); A_arbace_classes_analyze__init_part0_A_const_186 = A_arbace_classes_analyze__init_part0_A_const_pool.A[271] }

func A_arbace_classes_analyze__init_part0_A_clinit_p14() { A_arbace_classes_analyze__init_part0_A_const_187 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[272]); A_arbace_classes_analyze__init_part0_A_const_188 = A_arbace_classes_analyze__init_part0_A_const_pool.A[273]; A_arbace_classes_analyze__init_part0_A_const_189 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[274]); A_arbace_classes_analyze__init_part0_A_const_190 = A_arbace_classes_analyze__init_part0_A_const_pool.A[275]; A_arbace_classes_analyze__init_part0_A_const_191 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[276]); A_arbace_classes_analyze__init_part0_A_const_192 = A_arbace_classes_analyze__init_part0_A_const_pool.A[277]; A_arbace_classes_analyze__init_part0_A_const_193 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[278]); A_arbace_classes_analyze__init_part0_A_const_194 = A_arbace_classes_analyze__init_part0_A_const_pool.A[279]; A_arbace_classes_analyze__init_part0_A_const_195 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[280]); A_arbace_classes_analyze__init_part0_A_const_196 = A_arbace_classes_analyze__init_part0_A_const_pool.A[281]; A_arbace_classes_analyze__init_part0_A_const_197 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[282]); A_arbace_classes_analyze__init_part0_A_const_198 = A_arbace_classes_analyze__init_part0_A_const_pool.A[283]; A_arbace_classes_analyze__init_part0_A_const_199 = lang.Var_Cast(A_arbace_classes_analyze__init_part0_A_const_pool.A[284]) }

func A_arbace_classes_analyze__init_part0_A_clinit_p15() { A_arbace_classes_analyze__init_part0_A_const_200 = A_arbace_classes_analyze__init_part0_A_const_pool.A[285] }

func A_arbace_classes_analyze__init_part0_A_New() *A_arbace_classes_analyze__init_part0_A { A_arbace_classes_analyze__init_part0_A_Init(); t := &A_arbace_classes_analyze__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_analyze__init_part0_A) Ctor() {}

func (t *A_arbace_classes_analyze__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_analyze__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_classes_analyze__init_part0_A_class }

func (t *A_arbace_classes_analyze__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_analyze__init_part0_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_analyze__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_analyze__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_analyze__init_part0_A); return ok }

func A_arbace_classes_analyze__init_part0_A_Cast(x any) *A_arbace_classes_analyze__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_analyze__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_analyze__init_part0_A_class)) }; return v }



type A_arbace_classes_analyze__init_part1_A struct{ jrt.Object }

var A_arbace_classes_analyze__init_part1_A_const_pool *jrt.RefArray

var A_arbace_classes_analyze__init_part1_A_const_0 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_1 any

var A_arbace_classes_analyze__init_part1_A_const_2 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_3 any

var A_arbace_classes_analyze__init_part1_A_const_4 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_5 any

var A_arbace_classes_analyze__init_part1_A_const_6 any

var A_arbace_classes_analyze__init_part1_A_const_7 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_8 any

var A_arbace_classes_analyze__init_part1_A_const_9 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_10 any

var A_arbace_classes_analyze__init_part1_A_const_11 any

var A_arbace_classes_analyze__init_part1_A_const_12 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_13 any

var A_arbace_classes_analyze__init_part1_A_const_14 any

var A_arbace_classes_analyze__init_part1_A_const_15 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_16 any

var A_arbace_classes_analyze__init_part1_A_const_17 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_18 any

var A_arbace_classes_analyze__init_part1_A_const_19 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_20 any

var A_arbace_classes_analyze__init_part1_A_const_21 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_22 any

var A_arbace_classes_analyze__init_part1_A_const_23 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_24 any

var A_arbace_classes_analyze__init_part1_A_const_25 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_26 any

var A_arbace_classes_analyze__init_part1_A_const_27 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_28 any

var A_arbace_classes_analyze__init_part1_A_const_29 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_30 any

var A_arbace_classes_analyze__init_part1_A_const_31 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_32 any

var A_arbace_classes_analyze__init_part1_A_const_33 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_34 any

var A_arbace_classes_analyze__init_part1_A_const_35 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_36 any

var A_arbace_classes_analyze__init_part1_A_const_37 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_38 any

var A_arbace_classes_analyze__init_part1_A_const_39 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_40 any

var A_arbace_classes_analyze__init_part1_A_const_41 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_42 any

var A_arbace_classes_analyze__init_part1_A_const_43 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_44 any

var A_arbace_classes_analyze__init_part1_A_const_45 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_46 any

var A_arbace_classes_analyze__init_part1_A_const_47 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_48 any

var A_arbace_classes_analyze__init_part1_A_const_49 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_50 any

var A_arbace_classes_analyze__init_part1_A_const_51 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_52 any

var A_arbace_classes_analyze__init_part1_A_const_53 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_54 any

var A_arbace_classes_analyze__init_part1_A_const_55 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_56 any

var A_arbace_classes_analyze__init_part1_A_const_57 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_58 any

var A_arbace_classes_analyze__init_part1_A_const_59 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_60 any

var A_arbace_classes_analyze__init_part1_A_const_61 any

var A_arbace_classes_analyze__init_part1_A_const_62 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_63 any

var A_arbace_classes_analyze__init_part1_A_const_64 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_65 any

var A_arbace_classes_analyze__init_part1_A_const_66 any

var A_arbace_classes_analyze__init_part1_A_const_67 any

var A_arbace_classes_analyze__init_part1_A_const_68 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_69 any

var A_arbace_classes_analyze__init_part1_A_const_70 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_71 any

var A_arbace_classes_analyze__init_part1_A_const_72 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_73 any

var A_arbace_classes_analyze__init_part1_A_const_74 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_75 any

var A_arbace_classes_analyze__init_part1_A_const_76 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_77 any

var A_arbace_classes_analyze__init_part1_A_const_78 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_79 any

var A_arbace_classes_analyze__init_part1_A_const_80 any

var A_arbace_classes_analyze__init_part1_A_const_81 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_82 any

var A_arbace_classes_analyze__init_part1_A_const_83 any

var A_arbace_classes_analyze__init_part1_A_const_84 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_85 any

var A_arbace_classes_analyze__init_part1_A_const_86 any

var A_arbace_classes_analyze__init_part1_A_const_87 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_88 any

var A_arbace_classes_analyze__init_part1_A_const_89 any

var A_arbace_classes_analyze__init_part1_A_const_90 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_91 any

var A_arbace_classes_analyze__init_part1_A_const_92 any

var A_arbace_classes_analyze__init_part1_A_const_93 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_94 any

var A_arbace_classes_analyze__init_part1_A_const_95 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_96 any

var A_arbace_classes_analyze__init_part1_A_const_97 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_98 any

var A_arbace_classes_analyze__init_part1_A_const_99 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_100 any

var A_arbace_classes_analyze__init_part1_A_const_101 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_102 any

var A_arbace_classes_analyze__init_part1_A_const_103 any

var A_arbace_classes_analyze__init_part1_A_const_104 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_105 any

var A_arbace_classes_analyze__init_part1_A_const_106 any

var A_arbace_classes_analyze__init_part1_A_const_107 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_108 any

var A_arbace_classes_analyze__init_part1_A_const_109 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_110 any

var A_arbace_classes_analyze__init_part1_A_const_111 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_112 any

var A_arbace_classes_analyze__init_part1_A_const_113 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_114 any

var A_arbace_classes_analyze__init_part1_A_const_115 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_116 any

var A_arbace_classes_analyze__init_part1_A_const_117 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_118 any

var A_arbace_classes_analyze__init_part1_A_const_119 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_120 any

var A_arbace_classes_analyze__init_part1_A_const_121 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_122 any

var A_arbace_classes_analyze__init_part1_A_const_123 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_124 any

var A_arbace_classes_analyze__init_part1_A_const_125 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_126 any

var A_arbace_classes_analyze__init_part1_A_const_127 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_128 any

var A_arbace_classes_analyze__init_part1_A_const_129 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_130 any

var A_arbace_classes_analyze__init_part1_A_const_131 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_132 any

var A_arbace_classes_analyze__init_part1_A_const_133 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_134 any

var A_arbace_classes_analyze__init_part1_A_const_135 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_136 any

var A_arbace_classes_analyze__init_part1_A_const_137 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_138 any

var A_arbace_classes_analyze__init_part1_A_const_139 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_140 any

var A_arbace_classes_analyze__init_part1_A_const_141 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_142 any

var A_arbace_classes_analyze__init_part1_A_const_143 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_144 any

var A_arbace_classes_analyze__init_part1_A_const_145 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_146 any

var A_arbace_classes_analyze__init_part1_A_const_147 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_148 any

var A_arbace_classes_analyze__init_part1_A_const_149 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_150 any

var A_arbace_classes_analyze__init_part1_A_const_151 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_152 any

var A_arbace_classes_analyze__init_part1_A_const_153 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_154 any

var A_arbace_classes_analyze__init_part1_A_const_155 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_156 any

var A_arbace_classes_analyze__init_part1_A_const_157 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_158 any

var A_arbace_classes_analyze__init_part1_A_const_159 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_160 any

var A_arbace_classes_analyze__init_part1_A_const_161 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_162 any

var A_arbace_classes_analyze__init_part1_A_const_163 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_164 any

var A_arbace_classes_analyze__init_part1_A_const_165 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_166 any

var A_arbace_classes_analyze__init_part1_A_const_167 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_168 any

var A_arbace_classes_analyze__init_part1_A_const_169 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_170 any

var A_arbace_classes_analyze__init_part1_A_const_171 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_172 any

var A_arbace_classes_analyze__init_part1_A_const_173 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_174 any

var A_arbace_classes_analyze__init_part1_A_const_175 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_176 any

var A_arbace_classes_analyze__init_part1_A_const_177 any

var A_arbace_classes_analyze__init_part1_A_const_178 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_179 any

var A_arbace_classes_analyze__init_part1_A_const_180 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_181 any

var A_arbace_classes_analyze__init_part1_A_const_182 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_183 any

var A_arbace_classes_analyze__init_part1_A_const_184 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_185 any

var A_arbace_classes_analyze__init_part1_A_const_186 any

var A_arbace_classes_analyze__init_part1_A_const_187 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_188 any

var A_arbace_classes_analyze__init_part1_A_const_189 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_190 any

var A_arbace_classes_analyze__init_part1_A_const_191 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_192 any

var A_arbace_classes_analyze__init_part1_A_const_193 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_194 any

var A_arbace_classes_analyze__init_part1_A_const_195 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_196 any

var A_arbace_classes_analyze__init_part1_A_const_197 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_198 any

var A_arbace_classes_analyze__init_part1_A_const_199 *lang.Var

var A_arbace_classes_analyze__init_part1_A_const_200 any

var A_arbace_classes_analyze__init_part1_A_init jrt.ClassInit

func A_arbace_classes_analyze__init_part1_A_Init() { if !A_arbace_classes_analyze__init_part1_A_init.Done() { A_arbace_classes_analyze__init_part1_A_init.Run(A_arbace_classes_analyze__init_part1_A_clinit) } }

func A_arbace_classes_analyze__init_part1_A_clinit() { A_arbace_classes_analyze__init_part1_A_clinit_p0(); A_arbace_classes_analyze__init_part1_A_clinit_p1() }

func A_arbace_classes_analyze__init_part1_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_analyze__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_949, 328); A_arbace_classes_analyze__init_part1_A_const_0 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[131]); A_arbace_classes_analyze__init_part1_A_const_1 = A_arbace_classes_analyze__init_part1_A_const_pool.A[132]; A_arbace_classes_analyze__init_part1_A_const_2 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[133]); A_arbace_classes_analyze__init_part1_A_const_3 = A_arbace_classes_analyze__init_part1_A_const_pool.A[134] }

func A_arbace_classes_analyze__init_part1_A_clinit_p1() { var tmp1 *lang.Var; A_arbace_classes_analyze__init_part0_A_Init(); tmp1 = A_arbace_classes_analyze__init_part0_A_const_197; A_arbace_classes_analyze__init_part1_A_const_4 = tmp1; A_arbace_classes_analyze__init_part1_A_const_5 = A_arbace_classes_analyze__init_part1_A_const_pool.A[135]; A_arbace_classes_analyze__init_part1_A_const_6 = A_arbace_classes_analyze__init_part1_A_const_pool.A[136]; A_arbace_classes_analyze__init_part1_A_const_7 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[137]); A_arbace_classes_analyze__init_part1_A_const_8 = A_arbace_classes_analyze__init_part1_A_const_pool.A[138]; A_arbace_classes_analyze__init_part1_A_const_9 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[139]); A_arbace_classes_analyze__init_part1_A_const_10 = A_arbace_classes_analyze__init_part1_A_const_pool.A[140]; A_arbace_classes_analyze__init_part1_A_const_11 = A_arbace_classes_analyze__init_part1_A_const_pool.A[141]; A_arbace_classes_analyze__init_part1_A_const_12 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[142]); A_arbace_classes_analyze__init_part1_A_const_13 = A_arbace_classes_analyze__init_part1_A_const_pool.A[143]; A_arbace_classes_analyze__init_part1_A_const_14 = A_arbace_classes_analyze__init_part1_A_const_pool.A[144]; A_arbace_classes_analyze__init_part1_A_const_15 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[145]); A_arbace_classes_analyze__init_part1_A_const_16 = A_arbace_classes_analyze__init_part1_A_const_pool.A[146]; A_arbace_classes_analyze__init_part1_A_const_17 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[147]); A_arbace_classes_analyze__init_part1_A_const_18 = A_arbace_classes_analyze__init_part1_A_const_pool.A[148]; A_arbace_classes_analyze__init_part1_A_const_19 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[149]); A_arbace_classes_analyze__init_part1_A_const_20 = A_arbace_classes_analyze__init_part1_A_const_pool.A[150]; A_arbace_classes_analyze__init_part1_A_const_21 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[151]); A_arbace_classes_analyze__init_part1_A_const_22 = A_arbace_classes_analyze__init_part1_A_const_pool.A[152]; A_arbace_classes_analyze__init_part1_A_const_23 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[153]); A_arbace_classes_analyze__init_part1_A_const_24 = A_arbace_classes_analyze__init_part1_A_const_pool.A[154]; A_arbace_classes_analyze__init_part1_A_const_25 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[155]); A_arbace_classes_analyze__init_part1_A_const_26 = A_arbace_classes_analyze__init_part1_A_const_pool.A[156]; A_arbace_classes_analyze__init_part1_A_const_27 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[157]); A_arbace_classes_analyze__init_part1_A_const_28 = A_arbace_classes_analyze__init_part1_A_const_pool.A[158]; A_arbace_classes_analyze__init_part1_A_const_29 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[159]); A_arbace_classes_analyze__init_part1_A_const_30 = A_arbace_classes_analyze__init_part1_A_const_pool.A[160]; A_arbace_classes_analyze__init_part1_A_const_31 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[161]); A_arbace_classes_analyze__init_part1_A_const_32 = A_arbace_classes_analyze__init_part1_A_const_pool.A[162]; A_arbace_classes_analyze__init_part1_A_const_33 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[163]); A_arbace_classes_analyze__init_part1_A_const_34 = A_arbace_classes_analyze__init_part1_A_const_pool.A[164]; A_arbace_classes_analyze__init_part1_A_const_35 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[165]); A_arbace_classes_analyze__init_part1_A_const_36 = A_arbace_classes_analyze__init_part1_A_const_pool.A[166]; A_arbace_classes_analyze__init_part1_A_const_37 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[167]); A_arbace_classes_analyze__init_part1_A_const_38 = A_arbace_classes_analyze__init_part1_A_const_pool.A[168]; A_arbace_classes_analyze__init_part1_A_const_39 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[169]); A_arbace_classes_analyze__init_part1_A_const_40 = A_arbace_classes_analyze__init_part1_A_const_pool.A[170]; A_arbace_classes_analyze__init_part1_A_const_41 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[171]); A_arbace_classes_analyze__init_part1_A_const_42 = A_arbace_classes_analyze__init_part1_A_const_pool.A[172]; A_arbace_classes_analyze__init_part1_A_const_43 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[173]); A_arbace_classes_analyze__init_part1_A_const_44 = A_arbace_classes_analyze__init_part1_A_const_pool.A[174]; A_arbace_classes_analyze__init_part1_A_const_45 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[175]); A_arbace_classes_analyze__init_part1_A_const_46 = A_arbace_classes_analyze__init_part1_A_const_pool.A[176]; A_arbace_classes_analyze__init_part1_A_const_47 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[177]); A_arbace_classes_analyze__init_part1_A_const_48 = A_arbace_classes_analyze__init_part1_A_const_pool.A[178]; A_arbace_classes_analyze__init_part1_A_const_49 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[179]); A_arbace_classes_analyze__init_part1_A_const_50 = A_arbace_classes_analyze__init_part1_A_const_pool.A[180]; A_arbace_classes_analyze__init_part1_A_const_51 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[181]); A_arbace_classes_analyze__init_part1_A_const_52 = A_arbace_classes_analyze__init_part1_A_const_pool.A[182]; A_arbace_classes_analyze__init_part1_A_const_53 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[183]); A_arbace_classes_analyze__init_part1_A_const_54 = A_arbace_classes_analyze__init_part1_A_const_pool.A[184]; A_arbace_classes_analyze__init_part1_A_const_55 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[185]); A_arbace_classes_analyze__init_part1_A_const_56 = A_arbace_classes_analyze__init_part1_A_const_pool.A[186]; A_arbace_classes_analyze__init_part1_A_const_57 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[187]); A_arbace_classes_analyze__init_part1_A_const_58 = A_arbace_classes_analyze__init_part1_A_const_pool.A[188]; A_arbace_classes_analyze__init_part1_A_const_59 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[189]); A_arbace_classes_analyze__init_part1_A_const_60 = A_arbace_classes_analyze__init_part1_A_const_pool.A[190]; A_arbace_classes_analyze__init_part1_A_const_61 = A_arbace_classes_analyze__init_part1_A_const_pool.A[191]; A_arbace_classes_analyze__init_part1_A_const_62 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[192]); A_arbace_classes_analyze__init_part1_A_const_63 = A_arbace_classes_analyze__init_part1_A_const_pool.A[193]; var tmp2 *lang.Var; A_arbace_classes_analyze__init_part0_A_Init(); tmp2 = A_arbace_classes_analyze__init_part0_A_const_175; A_arbace_classes_analyze__init_part1_A_const_64 = tmp2; A_arbace_classes_analyze__init_part1_A_const_65 = A_arbace_classes_analyze__init_part1_A_const_pool.A[194]; A_arbace_classes_analyze__init_part1_A_const_66 = A_arbace_classes_analyze__init_part1_A_const_pool.A[195]; A_arbace_classes_analyze__init_part1_A_const_67 = A_arbace_classes_analyze__init_part1_A_const_pool.A[196]; A_arbace_classes_analyze__init_part1_A_const_68 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[197]); A_arbace_classes_analyze__init_part1_A_const_69 = A_arbace_classes_analyze__init_part1_A_const_pool.A[198]; A_arbace_classes_analyze__init_part1_A_const_70 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[199]); A_arbace_classes_analyze__init_part1_A_const_71 = A_arbace_classes_analyze__init_part1_A_const_pool.A[200]; A_arbace_classes_analyze__init_part1_A_const_72 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[201]); A_arbace_classes_analyze__init_part1_A_const_73 = A_arbace_classes_analyze__init_part1_A_const_pool.A[202]; A_arbace_classes_analyze__init_part1_A_const_74 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[203]); A_arbace_classes_analyze__init_part1_A_const_75 = A_arbace_classes_analyze__init_part1_A_const_pool.A[204]; A_arbace_classes_analyze__init_part1_A_const_76 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[205]); A_arbace_classes_analyze__init_part1_A_const_77 = A_arbace_classes_analyze__init_part1_A_const_pool.A[206]; A_arbace_classes_analyze__init_part1_A_const_78 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[207]); A_arbace_classes_analyze__init_part1_A_const_79 = A_arbace_classes_analyze__init_part1_A_const_pool.A[208]; A_arbace_classes_analyze__init_part1_A_const_80 = A_arbace_classes_analyze__init_part1_A_const_pool.A[209]; A_arbace_classes_analyze__init_part1_A_const_81 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[210]); A_arbace_classes_analyze__init_part1_A_const_82 = A_arbace_classes_analyze__init_part1_A_const_pool.A[211]; A_arbace_classes_analyze__init_part1_A_const_83 = A_arbace_classes_analyze__init_part1_A_const_pool.A[212]; A_arbace_classes_analyze__init_part1_A_const_84 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[213]); A_arbace_classes_analyze__init_part1_A_const_85 = A_arbace_classes_analyze__init_part1_A_const_pool.A[214]; A_arbace_classes_analyze__init_part1_A_const_86 = A_arbace_classes_analyze__init_part1_A_const_pool.A[215]; A_arbace_classes_analyze__init_part1_A_const_87 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[216]); A_arbace_classes_analyze__init_part1_A_const_88 = A_arbace_classes_analyze__init_part1_A_const_pool.A[217]; A_arbace_classes_analyze__init_part1_A_const_89 = A_arbace_classes_analyze__init_part1_A_const_pool.A[218]; A_arbace_classes_analyze__init_part1_A_const_90 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[219]); A_arbace_classes_analyze__init_part1_A_const_91 = A_arbace_classes_analyze__init_part1_A_const_pool.A[220]; A_arbace_classes_analyze__init_part1_A_const_92 = A_arbace_classes_analyze__init_part1_A_const_pool.A[221]; A_arbace_classes_analyze__init_part1_A_const_93 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[222]); A_arbace_classes_analyze__init_part1_A_const_94 = A_arbace_classes_analyze__init_part1_A_const_pool.A[223]; A_arbace_classes_analyze__init_part1_A_const_95 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[224]); A_arbace_classes_analyze__init_part1_A_const_96 = A_arbace_classes_analyze__init_part1_A_const_pool.A[225]; A_arbace_classes_analyze__init_part1_A_const_97 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[226]); A_arbace_classes_analyze__init_part1_A_const_98 = A_arbace_classes_analyze__init_part1_A_const_pool.A[227]; A_arbace_classes_analyze__init_part1_A_const_99 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[228]); A_arbace_classes_analyze__init_part1_A_const_100 = A_arbace_classes_analyze__init_part1_A_const_pool.A[229]; A_arbace_classes_analyze__init_part1_A_const_101 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[230]); A_arbace_classes_analyze__init_part1_A_const_102 = A_arbace_classes_analyze__init_part1_A_const_pool.A[231]; A_arbace_classes_analyze__init_part1_A_const_103 = A_arbace_classes_analyze__init_part1_A_const_pool.A[232]; A_arbace_classes_analyze__init_part1_A_const_104 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[233]); A_arbace_classes_analyze__init_part1_A_const_105 = A_arbace_classes_analyze__init_part1_A_const_pool.A[234]; A_arbace_classes_analyze__init_part1_A_const_106 = A_arbace_classes_analyze__init_part1_A_const_pool.A[235]; A_arbace_classes_analyze__init_part1_A_const_107 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[236]); A_arbace_classes_analyze__init_part1_A_const_108 = A_arbace_classes_analyze__init_part1_A_const_pool.A[237]; A_arbace_classes_analyze__init_part1_A_const_109 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[238]); A_arbace_classes_analyze__init_part1_A_const_110 = A_arbace_classes_analyze__init_part1_A_const_pool.A[239]; A_arbace_classes_analyze__init_part1_A_const_111 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[240]); A_arbace_classes_analyze__init_part1_A_const_112 = A_arbace_classes_analyze__init_part1_A_const_pool.A[241]; A_arbace_classes_analyze__init_part1_A_const_113 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[242]); A_arbace_classes_analyze__init_part1_A_const_114 = A_arbace_classes_analyze__init_part1_A_const_pool.A[243]; A_arbace_classes_analyze__init_part1_A_const_115 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[244]); A_arbace_classes_analyze__init_part1_A_const_116 = A_arbace_classes_analyze__init_part1_A_const_pool.A[245]; A_arbace_classes_analyze__init_part1_A_const_117 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[246]); A_arbace_classes_analyze__init_part1_A_const_118 = A_arbace_classes_analyze__init_part1_A_const_pool.A[247]; A_arbace_classes_analyze__init_part1_A_const_119 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[248]); A_arbace_classes_analyze__init_part1_A_const_120 = A_arbace_classes_analyze__init_part1_A_const_pool.A[249]; A_arbace_classes_analyze__init_part1_A_const_121 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[250]); A_arbace_classes_analyze__init_part1_A_const_122 = A_arbace_classes_analyze__init_part1_A_const_pool.A[251]; A_arbace_classes_analyze__init_part1_A_const_123 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[252]); A_arbace_classes_analyze__init_part1_A_const_124 = A_arbace_classes_analyze__init_part1_A_const_pool.A[253]; A_arbace_classes_analyze__init_part1_A_const_125 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[254]); A_arbace_classes_analyze__init_part1_A_const_126 = A_arbace_classes_analyze__init_part1_A_const_pool.A[255]; var tmp3 *lang.Var; A_arbace_classes_analyze__init_part0_A_Init(); tmp3 = A_arbace_classes_analyze__init_part0_A_const_71; A_arbace_classes_analyze__init_part1_A_const_127 = tmp3; A_arbace_classes_analyze__init_part1_A_const_128 = A_arbace_classes_analyze__init_part1_A_const_pool.A[256]; var tmp4 *lang.Var; A_arbace_classes_analyze__init_part0_A_Init(); tmp4 = A_arbace_classes_analyze__init_part0_A_const_75; A_arbace_classes_analyze__init_part1_A_const_129 = tmp4; A_arbace_classes_analyze__init_part1_A_const_130 = A_arbace_classes_analyze__init_part1_A_const_pool.A[257]; A_arbace_classes_analyze__init_part1_A_const_131 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[258]); A_arbace_classes_analyze__init_part1_A_const_132 = A_arbace_classes_analyze__init_part1_A_const_pool.A[259]; A_arbace_classes_analyze__init_part1_A_const_133 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[260]); A_arbace_classes_analyze__init_part1_A_const_134 = A_arbace_classes_analyze__init_part1_A_const_pool.A[261]; A_arbace_classes_analyze__init_part1_A_const_135 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[262]); A_arbace_classes_analyze__init_part1_A_const_136 = A_arbace_classes_analyze__init_part1_A_const_pool.A[263]; A_arbace_classes_analyze__init_part1_A_const_137 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[264]); A_arbace_classes_analyze__init_part1_A_const_138 = A_arbace_classes_analyze__init_part1_A_const_pool.A[265]; A_arbace_classes_analyze__init_part1_A_const_139 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[266]); A_arbace_classes_analyze__init_part1_A_const_140 = A_arbace_classes_analyze__init_part1_A_const_pool.A[267]; A_arbace_classes_analyze__init_part1_A_const_141 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[268]); A_arbace_classes_analyze__init_part1_A_const_142 = A_arbace_classes_analyze__init_part1_A_const_pool.A[269]; A_arbace_classes_analyze__init_part1_A_const_143 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[270]); A_arbace_classes_analyze__init_part1_A_const_144 = A_arbace_classes_analyze__init_part1_A_const_pool.A[271]; A_arbace_classes_analyze__init_part1_A_const_145 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[272]); A_arbace_classes_analyze__init_part1_A_const_146 = A_arbace_classes_analyze__init_part1_A_const_pool.A[273]; A_arbace_classes_analyze__init_part1_A_const_147 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[274]); A_arbace_classes_analyze__init_part1_A_const_148 = A_arbace_classes_analyze__init_part1_A_const_pool.A[275]; A_arbace_classes_analyze__init_part1_A_const_149 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[276]); A_arbace_classes_analyze__init_part1_A_const_150 = A_arbace_classes_analyze__init_part1_A_const_pool.A[277]; A_arbace_classes_analyze__init_part1_A_const_151 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[278]); A_arbace_classes_analyze__init_part1_A_const_152 = A_arbace_classes_analyze__init_part1_A_const_pool.A[279]; A_arbace_classes_analyze__init_part1_A_const_153 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[280]); A_arbace_classes_analyze__init_part1_A_const_154 = A_arbace_classes_analyze__init_part1_A_const_pool.A[281]; A_arbace_classes_analyze__init_part1_A_const_155 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[282]); A_arbace_classes_analyze__init_part1_A_const_156 = A_arbace_classes_analyze__init_part1_A_const_pool.A[283]; A_arbace_classes_analyze__init_part1_A_const_157 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[284]); A_arbace_classes_analyze__init_part1_A_const_158 = A_arbace_classes_analyze__init_part1_A_const_pool.A[285]; A_arbace_classes_analyze__init_part1_A_const_159 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[286]); A_arbace_classes_analyze__init_part1_A_const_160 = A_arbace_classes_analyze__init_part1_A_const_pool.A[287]; A_arbace_classes_analyze__init_part1_A_const_161 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[288]); A_arbace_classes_analyze__init_part1_A_const_162 = A_arbace_classes_analyze__init_part1_A_const_pool.A[289]; A_arbace_classes_analyze__init_part1_A_const_163 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[290]); A_arbace_classes_analyze__init_part1_A_const_164 = A_arbace_classes_analyze__init_part1_A_const_pool.A[291]; A_arbace_classes_analyze__init_part1_A_const_165 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[292]); A_arbace_classes_analyze__init_part1_A_const_166 = A_arbace_classes_analyze__init_part1_A_const_pool.A[293]; A_arbace_classes_analyze__init_part1_A_const_167 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[294]); A_arbace_classes_analyze__init_part1_A_const_168 = A_arbace_classes_analyze__init_part1_A_const_pool.A[295]; A_arbace_classes_analyze__init_part1_A_const_169 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[296]); A_arbace_classes_analyze__init_part1_A_const_170 = A_arbace_classes_analyze__init_part1_A_const_pool.A[297]; A_arbace_classes_analyze__init_part1_A_const_171 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[298]); A_arbace_classes_analyze__init_part1_A_const_172 = A_arbace_classes_analyze__init_part1_A_const_pool.A[299]; A_arbace_classes_analyze__init_part1_A_const_173 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[300]); A_arbace_classes_analyze__init_part1_A_const_174 = A_arbace_classes_analyze__init_part1_A_const_pool.A[301]; A_arbace_classes_analyze__init_part1_A_const_175 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[302]); A_arbace_classes_analyze__init_part1_A_const_176 = A_arbace_classes_analyze__init_part1_A_const_pool.A[303]; A_arbace_classes_analyze__init_part1_A_const_177 = A_arbace_classes_analyze__init_part1_A_const_pool.A[304]; A_arbace_classes_analyze__init_part1_A_const_178 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[305]); A_arbace_classes_analyze__init_part1_A_const_179 = A_arbace_classes_analyze__init_part1_A_const_pool.A[306]; A_arbace_classes_analyze__init_part1_A_const_180 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[307]); A_arbace_classes_analyze__init_part1_A_const_181 = A_arbace_classes_analyze__init_part1_A_const_pool.A[308]; A_arbace_classes_analyze__init_part1_A_const_182 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[309]); A_arbace_classes_analyze__init_part1_A_const_183 = A_arbace_classes_analyze__init_part1_A_const_pool.A[310]; A_arbace_classes_analyze__init_part1_A_const_184 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[311]); A_arbace_classes_analyze__init_part1_A_const_185 = A_arbace_classes_analyze__init_part1_A_const_pool.A[312]; A_arbace_classes_analyze__init_part1_A_const_186 = A_arbace_classes_analyze__init_part1_A_const_pool.A[313]; A_arbace_classes_analyze__init_part1_A_const_187 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[314]); A_arbace_classes_analyze__init_part1_A_const_188 = A_arbace_classes_analyze__init_part1_A_const_pool.A[315]; A_arbace_classes_analyze__init_part1_A_const_189 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[316]); A_arbace_classes_analyze__init_part1_A_const_190 = A_arbace_classes_analyze__init_part1_A_const_pool.A[317]; A_arbace_classes_analyze__init_part1_A_const_191 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[318]); A_arbace_classes_analyze__init_part1_A_const_192 = A_arbace_classes_analyze__init_part1_A_const_pool.A[319]; A_arbace_classes_analyze__init_part1_A_const_193 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[320]); A_arbace_classes_analyze__init_part1_A_const_194 = A_arbace_classes_analyze__init_part1_A_const_pool.A[321]; A_arbace_classes_analyze__init_part1_A_const_195 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[322]); A_arbace_classes_analyze__init_part1_A_const_196 = A_arbace_classes_analyze__init_part1_A_const_pool.A[323]; A_arbace_classes_analyze__init_part1_A_const_197 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[324]); A_arbace_classes_analyze__init_part1_A_const_198 = A_arbace_classes_analyze__init_part1_A_const_pool.A[325]; A_arbace_classes_analyze__init_part1_A_const_199 = lang.Var_Cast(A_arbace_classes_analyze__init_part1_A_const_pool.A[326]); A_arbace_classes_analyze__init_part1_A_const_200 = A_arbace_classes_analyze__init_part1_A_const_pool.A[327] }

func A_arbace_classes_analyze__init_part1_A_New() *A_arbace_classes_analyze__init_part1_A { A_arbace_classes_analyze__init_part1_A_Init(); t := &A_arbace_classes_analyze__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_analyze__init_part1_A) Ctor() {}

func (t *A_arbace_classes_analyze__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_analyze__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_classes_analyze__init_part1_A_class }

func (t *A_arbace_classes_analyze__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_analyze__init_part1_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_analyze__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_analyze__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_analyze__init_part1_A); return ok }

func A_arbace_classes_analyze__init_part1_A_Cast(x any) *A_arbace_classes_analyze__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_analyze__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_analyze__init_part1_A_class)) }; return v }



type A_arbace_classes_analyze__init_part2_A struct{ jrt.Object }

var A_arbace_classes_analyze__init_part2_A_const_pool *jrt.RefArray

var A_arbace_classes_analyze__init_part2_A_const_0 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_1 any

var A_arbace_classes_analyze__init_part2_A_const_2 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_3 any

var A_arbace_classes_analyze__init_part2_A_const_4 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_5 any

var A_arbace_classes_analyze__init_part2_A_const_6 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_7 any

var A_arbace_classes_analyze__init_part2_A_const_8 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_9 any

var A_arbace_classes_analyze__init_part2_A_const_10 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_11 any

var A_arbace_classes_analyze__init_part2_A_const_12 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_13 any

var A_arbace_classes_analyze__init_part2_A_const_14 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_15 any

var A_arbace_classes_analyze__init_part2_A_const_16 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_17 any

var A_arbace_classes_analyze__init_part2_A_const_18 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_19 any

var A_arbace_classes_analyze__init_part2_A_const_20 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_21 any

var A_arbace_classes_analyze__init_part2_A_const_22 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_23 any

var A_arbace_classes_analyze__init_part2_A_const_24 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_25 any

var A_arbace_classes_analyze__init_part2_A_const_26 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_27 any

var A_arbace_classes_analyze__init_part2_A_const_28 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_29 any

var A_arbace_classes_analyze__init_part2_A_const_30 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_31 any

var A_arbace_classes_analyze__init_part2_A_const_32 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_33 any

var A_arbace_classes_analyze__init_part2_A_const_34 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_35 any

var A_arbace_classes_analyze__init_part2_A_const_36 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_37 any

var A_arbace_classes_analyze__init_part2_A_const_38 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_39 any

var A_arbace_classes_analyze__init_part2_A_const_40 any

var A_arbace_classes_analyze__init_part2_A_const_41 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_42 any

var A_arbace_classes_analyze__init_part2_A_const_43 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_44 any

var A_arbace_classes_analyze__init_part2_A_const_45 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_46 any

var A_arbace_classes_analyze__init_part2_A_const_47 any

var A_arbace_classes_analyze__init_part2_A_const_48 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_49 any

var A_arbace_classes_analyze__init_part2_A_const_50 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_51 any

var A_arbace_classes_analyze__init_part2_A_const_52 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_53 any

var A_arbace_classes_analyze__init_part2_A_const_54 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_55 any

var A_arbace_classes_analyze__init_part2_A_const_56 any

var A_arbace_classes_analyze__init_part2_A_const_57 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_58 any

var A_arbace_classes_analyze__init_part2_A_const_59 any

var A_arbace_classes_analyze__init_part2_A_const_60 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_61 any

var A_arbace_classes_analyze__init_part2_A_const_62 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_63 any

var A_arbace_classes_analyze__init_part2_A_const_64 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_65 any

var A_arbace_classes_analyze__init_part2_A_const_66 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_67 any

var A_arbace_classes_analyze__init_part2_A_const_68 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_69 any

var A_arbace_classes_analyze__init_part2_A_const_70 any

var A_arbace_classes_analyze__init_part2_A_const_71 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_72 any

var A_arbace_classes_analyze__init_part2_A_const_73 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_74 any

var A_arbace_classes_analyze__init_part2_A_const_75 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_76 any

var A_arbace_classes_analyze__init_part2_A_const_77 any

var A_arbace_classes_analyze__init_part2_A_const_78 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_79 any

var A_arbace_classes_analyze__init_part2_A_const_80 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_81 any

var A_arbace_classes_analyze__init_part2_A_const_82 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_83 any

var A_arbace_classes_analyze__init_part2_A_const_84 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_85 any

var A_arbace_classes_analyze__init_part2_A_const_86 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_87 any

var A_arbace_classes_analyze__init_part2_A_const_88 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_89 any

var A_arbace_classes_analyze__init_part2_A_const_90 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_91 any

var A_arbace_classes_analyze__init_part2_A_const_92 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_93 any

var A_arbace_classes_analyze__init_part2_A_const_94 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_95 any

var A_arbace_classes_analyze__init_part2_A_const_96 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_97 any

var A_arbace_classes_analyze__init_part2_A_const_98 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_99 any

var A_arbace_classes_analyze__init_part2_A_const_100 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_101 any

var A_arbace_classes_analyze__init_part2_A_const_102 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_103 any

var A_arbace_classes_analyze__init_part2_A_const_104 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_105 any

var A_arbace_classes_analyze__init_part2_A_const_106 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_107 any

var A_arbace_classes_analyze__init_part2_A_const_108 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_109 any

var A_arbace_classes_analyze__init_part2_A_const_110 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_111 any

var A_arbace_classes_analyze__init_part2_A_const_112 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_113 any

var A_arbace_classes_analyze__init_part2_A_const_114 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_115 any

var A_arbace_classes_analyze__init_part2_A_const_116 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_117 any

var A_arbace_classes_analyze__init_part2_A_const_118 any

var A_arbace_classes_analyze__init_part2_A_const_119 any

var A_arbace_classes_analyze__init_part2_A_const_120 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_121 any

var A_arbace_classes_analyze__init_part2_A_const_122 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_123 any

var A_arbace_classes_analyze__init_part2_A_const_124 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_125 any

var A_arbace_classes_analyze__init_part2_A_const_126 any

var A_arbace_classes_analyze__init_part2_A_const_127 any

var A_arbace_classes_analyze__init_part2_A_const_128 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_129 any

var A_arbace_classes_analyze__init_part2_A_const_130 any

var A_arbace_classes_analyze__init_part2_A_const_131 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_132 any

var A_arbace_classes_analyze__init_part2_A_const_133 any

var A_arbace_classes_analyze__init_part2_A_const_134 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_135 any

var A_arbace_classes_analyze__init_part2_A_const_136 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_137 any

var A_arbace_classes_analyze__init_part2_A_const_138 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_139 any

var A_arbace_classes_analyze__init_part2_A_const_140 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_141 any

var A_arbace_classes_analyze__init_part2_A_const_142 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_143 any

var A_arbace_classes_analyze__init_part2_A_const_144 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_145 any

var A_arbace_classes_analyze__init_part2_A_const_146 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_147 any

var A_arbace_classes_analyze__init_part2_A_const_148 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_149 any

var A_arbace_classes_analyze__init_part2_A_const_150 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_151 any

var A_arbace_classes_analyze__init_part2_A_const_152 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_153 any

var A_arbace_classes_analyze__init_part2_A_const_154 any

var A_arbace_classes_analyze__init_part2_A_const_155 any

var A_arbace_classes_analyze__init_part2_A_const_156 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_157 any

var A_arbace_classes_analyze__init_part2_A_const_158 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_159 any

var A_arbace_classes_analyze__init_part2_A_const_160 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_161 any

var A_arbace_classes_analyze__init_part2_A_const_162 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_163 any

var A_arbace_classes_analyze__init_part2_A_const_164 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_165 any

var A_arbace_classes_analyze__init_part2_A_const_166 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_167 any

var A_arbace_classes_analyze__init_part2_A_const_168 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_169 any

var A_arbace_classes_analyze__init_part2_A_const_170 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_171 any

var A_arbace_classes_analyze__init_part2_A_const_172 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_173 any

var A_arbace_classes_analyze__init_part2_A_const_174 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_175 any

var A_arbace_classes_analyze__init_part2_A_const_176 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_177 any

var A_arbace_classes_analyze__init_part2_A_const_178 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_179 any

var A_arbace_classes_analyze__init_part2_A_const_180 any

var A_arbace_classes_analyze__init_part2_A_const_181 any

var A_arbace_classes_analyze__init_part2_A_const_182 *lang.Var

var A_arbace_classes_analyze__init_part2_A_const_183 any

var A_arbace_classes_analyze__init_part2_A_const_184 any

var A_arbace_classes_analyze__init_part2_A_init jrt.ClassInit

func A_arbace_classes_analyze__init_part2_A_Init() { if !A_arbace_classes_analyze__init_part2_A_init.Done() { A_arbace_classes_analyze__init_part2_A_init.Run(A_arbace_classes_analyze__init_part2_A_clinit) } }

func A_arbace_classes_analyze__init_part2_A_clinit() { A_arbace_classes_analyze__init_part2_A_clinit_p0(); A_arbace_classes_analyze__init_part2_A_clinit_p1(); A_arbace_classes_analyze__init_part2_A_clinit_p2(); A_arbace_classes_analyze__init_part2_A_clinit_p3() }

func A_arbace_classes_analyze__init_part2_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_analyze__init_part2_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_1014, 264); A_arbace_classes_analyze__init_part2_A_const_0 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[90]); A_arbace_classes_analyze__init_part2_A_const_1 = A_arbace_classes_analyze__init_part2_A_const_pool.A[91]; A_arbace_classes_analyze__init_part2_A_const_2 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[92]); A_arbace_classes_analyze__init_part2_A_const_3 = A_arbace_classes_analyze__init_part2_A_const_pool.A[93]; A_arbace_classes_analyze__init_part2_A_const_4 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[94]); A_arbace_classes_analyze__init_part2_A_const_5 = A_arbace_classes_analyze__init_part2_A_const_pool.A[95]; A_arbace_classes_analyze__init_part2_A_const_6 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[96]); A_arbace_classes_analyze__init_part2_A_const_7 = A_arbace_classes_analyze__init_part2_A_const_pool.A[97]; A_arbace_classes_analyze__init_part2_A_const_8 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[98]); A_arbace_classes_analyze__init_part2_A_const_9 = A_arbace_classes_analyze__init_part2_A_const_pool.A[99]; A_arbace_classes_analyze__init_part2_A_const_10 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[100]); A_arbace_classes_analyze__init_part2_A_const_11 = A_arbace_classes_analyze__init_part2_A_const_pool.A[101] }

func A_arbace_classes_analyze__init_part2_A_clinit_p1() { A_arbace_classes_analyze__init_part2_A_const_12 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[102]); A_arbace_classes_analyze__init_part2_A_const_13 = A_arbace_classes_analyze__init_part2_A_const_pool.A[103]; A_arbace_classes_analyze__init_part2_A_const_14 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[104]); A_arbace_classes_analyze__init_part2_A_const_15 = A_arbace_classes_analyze__init_part2_A_const_pool.A[105]; A_arbace_classes_analyze__init_part2_A_const_16 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[106]); A_arbace_classes_analyze__init_part2_A_const_17 = A_arbace_classes_analyze__init_part2_A_const_pool.A[107]; A_arbace_classes_analyze__init_part2_A_const_18 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[108]); A_arbace_classes_analyze__init_part2_A_const_19 = A_arbace_classes_analyze__init_part2_A_const_pool.A[109]; A_arbace_classes_analyze__init_part2_A_const_20 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[110]); A_arbace_classes_analyze__init_part2_A_const_21 = A_arbace_classes_analyze__init_part2_A_const_pool.A[111]; A_arbace_classes_analyze__init_part2_A_const_22 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[112]); A_arbace_classes_analyze__init_part2_A_const_23 = A_arbace_classes_analyze__init_part2_A_const_pool.A[113]; A_arbace_classes_analyze__init_part2_A_const_24 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[114]) }

func A_arbace_classes_analyze__init_part2_A_clinit_p2() { A_arbace_classes_analyze__init_part2_A_const_25 = A_arbace_classes_analyze__init_part2_A_const_pool.A[115]; A_arbace_classes_analyze__init_part2_A_const_26 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[116]); A_arbace_classes_analyze__init_part2_A_const_27 = A_arbace_classes_analyze__init_part2_A_const_pool.A[117]; A_arbace_classes_analyze__init_part2_A_const_28 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[118]); A_arbace_classes_analyze__init_part2_A_const_29 = A_arbace_classes_analyze__init_part2_A_const_pool.A[119]; A_arbace_classes_analyze__init_part2_A_const_30 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[120]); A_arbace_classes_analyze__init_part2_A_const_31 = A_arbace_classes_analyze__init_part2_A_const_pool.A[121] }

func A_arbace_classes_analyze__init_part2_A_clinit_p3() { var tmp1 *lang.Var; A_arbace_classes_analyze__init_part1_A_Init(); tmp1 = A_arbace_classes_analyze__init_part1_A_const_27; A_arbace_classes_analyze__init_part2_A_const_32 = tmp1; A_arbace_classes_analyze__init_part2_A_const_33 = A_arbace_classes_analyze__init_part2_A_const_pool.A[122]; A_arbace_classes_analyze__init_part2_A_const_34 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[123]); A_arbace_classes_analyze__init_part2_A_const_35 = A_arbace_classes_analyze__init_part2_A_const_pool.A[124]; var tmp2 *lang.Var; A_arbace_classes_analyze__init_part1_A_Init(); tmp2 = A_arbace_classes_analyze__init_part1_A_const_29; A_arbace_classes_analyze__init_part2_A_const_36 = tmp2; A_arbace_classes_analyze__init_part2_A_const_37 = A_arbace_classes_analyze__init_part2_A_const_pool.A[125]; A_arbace_classes_analyze__init_part2_A_const_38 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[126]); A_arbace_classes_analyze__init_part2_A_const_39 = A_arbace_classes_analyze__init_part2_A_const_pool.A[127]; A_arbace_classes_analyze__init_part2_A_const_40 = A_arbace_classes_analyze__init_part2_A_const_pool.A[128]; A_arbace_classes_analyze__init_part2_A_const_41 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[129]); A_arbace_classes_analyze__init_part2_A_const_42 = A_arbace_classes_analyze__init_part2_A_const_pool.A[130]; A_arbace_classes_analyze__init_part2_A_const_43 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[131]); A_arbace_classes_analyze__init_part2_A_const_44 = A_arbace_classes_analyze__init_part2_A_const_pool.A[132]; var tmp3 *lang.Var; A_arbace_classes_analyze__init_part1_A_Init(); tmp3 = A_arbace_classes_analyze__init_part1_A_const_159; A_arbace_classes_analyze__init_part2_A_const_45 = tmp3; A_arbace_classes_analyze__init_part2_A_const_46 = A_arbace_classes_analyze__init_part2_A_const_pool.A[133]; A_arbace_classes_analyze__init_part2_A_const_47 = A_arbace_classes_analyze__init_part2_A_const_pool.A[134]; var tmp4 *lang.Var; A_arbace_classes_analyze__init_part1_A_Init(); tmp4 = A_arbace_classes_analyze__init_part1_A_const_161; A_arbace_classes_analyze__init_part2_A_const_48 = tmp4; A_arbace_classes_analyze__init_part2_A_const_49 = A_arbace_classes_analyze__init_part2_A_const_pool.A[135]; var tmp5 *lang.Var; A_arbace_classes_analyze__init_part1_A_Init(); tmp5 = A_arbace_classes_analyze__init_part1_A_const_163; A_arbace_classes_analyze__init_part2_A_const_50 = tmp5; A_arbace_classes_analyze__init_part2_A_const_51 = A_arbace_classes_analyze__init_part2_A_const_pool.A[136]; A_arbace_classes_analyze__init_part2_A_const_52 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[137]); A_arbace_classes_analyze__init_part2_A_const_53 = A_arbace_classes_analyze__init_part2_A_const_pool.A[138]; A_arbace_classes_analyze__init_part2_A_const_54 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[139]); A_arbace_classes_analyze__init_part2_A_const_55 = A_arbace_classes_analyze__init_part2_A_const_pool.A[140]; A_arbace_classes_analyze__init_part2_A_const_56 = A_arbace_classes_analyze__init_part2_A_const_pool.A[141]; var tmp6 *lang.Var; A_arbace_classes_analyze__init_part1_A_Init(); tmp6 = A_arbace_classes_analyze__init_part1_A_const_45; A_arbace_classes_analyze__init_part2_A_const_57 = tmp6; A_arbace_classes_analyze__init_part2_A_const_58 = A_arbace_classes_analyze__init_part2_A_const_pool.A[142]; A_arbace_classes_analyze__init_part2_A_const_59 = A_arbace_classes_analyze__init_part2_A_const_pool.A[143]; A_arbace_classes_analyze__init_part2_A_const_60 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[144]); A_arbace_classes_analyze__init_part2_A_const_61 = A_arbace_classes_analyze__init_part2_A_const_pool.A[145]; A_arbace_classes_analyze__init_part2_A_const_62 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[146]); A_arbace_classes_analyze__init_part2_A_const_63 = A_arbace_classes_analyze__init_part2_A_const_pool.A[147]; var tmp7 *lang.Var; A_arbace_classes_analyze__init_part1_A_Init(); tmp7 = A_arbace_classes_analyze__init_part1_A_const_57; A_arbace_classes_analyze__init_part2_A_const_64 = tmp7; A_arbace_classes_analyze__init_part2_A_const_65 = A_arbace_classes_analyze__init_part2_A_const_pool.A[148]; A_arbace_classes_analyze__init_part2_A_const_66 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[149]); A_arbace_classes_analyze__init_part2_A_const_67 = A_arbace_classes_analyze__init_part2_A_const_pool.A[150]; var tmp8 *lang.Var; A_arbace_classes_analyze__init_part1_A_Init(); tmp8 = A_arbace_classes_analyze__init_part1_A_const_55; A_arbace_classes_analyze__init_part2_A_const_68 = tmp8; A_arbace_classes_analyze__init_part2_A_const_69 = A_arbace_classes_analyze__init_part2_A_const_pool.A[151]; A_arbace_classes_analyze__init_part2_A_const_70 = A_arbace_classes_analyze__init_part2_A_const_pool.A[152]; var tmp9 *lang.Var; A_arbace_classes_analyze__init_part1_A_Init(); tmp9 = A_arbace_classes_analyze__init_part1_A_const_43; A_arbace_classes_analyze__init_part2_A_const_71 = tmp9; A_arbace_classes_analyze__init_part2_A_const_72 = A_arbace_classes_analyze__init_part2_A_const_pool.A[153]; A_arbace_classes_analyze__init_part2_A_const_73 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[154]); A_arbace_classes_analyze__init_part2_A_const_74 = A_arbace_classes_analyze__init_part2_A_const_pool.A[155]; A_arbace_classes_analyze__init_part2_A_const_75 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[156]); A_arbace_classes_analyze__init_part2_A_const_76 = A_arbace_classes_analyze__init_part2_A_const_pool.A[157]; A_arbace_classes_analyze__init_part2_A_const_77 = A_arbace_classes_analyze__init_part2_A_const_pool.A[158]; A_arbace_classes_analyze__init_part2_A_const_78 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[159]); A_arbace_classes_analyze__init_part2_A_const_79 = A_arbace_classes_analyze__init_part2_A_const_pool.A[160]; A_arbace_classes_analyze__init_part2_A_const_80 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[161]); A_arbace_classes_analyze__init_part2_A_const_81 = A_arbace_classes_analyze__init_part2_A_const_pool.A[162]; A_arbace_classes_analyze__init_part2_A_const_82 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[163]); A_arbace_classes_analyze__init_part2_A_const_83 = A_arbace_classes_analyze__init_part2_A_const_pool.A[164]; A_arbace_classes_analyze__init_part2_A_const_84 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[165]); A_arbace_classes_analyze__init_part2_A_const_85 = A_arbace_classes_analyze__init_part2_A_const_pool.A[166]; A_arbace_classes_analyze__init_part2_A_const_86 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[167]); A_arbace_classes_analyze__init_part2_A_const_87 = A_arbace_classes_analyze__init_part2_A_const_pool.A[168]; A_arbace_classes_analyze__init_part2_A_const_88 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[169]); A_arbace_classes_analyze__init_part2_A_const_89 = A_arbace_classes_analyze__init_part2_A_const_pool.A[170]; A_arbace_classes_analyze__init_part2_A_const_90 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[171]); A_arbace_classes_analyze__init_part2_A_const_91 = A_arbace_classes_analyze__init_part2_A_const_pool.A[172]; A_arbace_classes_analyze__init_part2_A_const_92 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[173]); A_arbace_classes_analyze__init_part2_A_const_93 = A_arbace_classes_analyze__init_part2_A_const_pool.A[174]; A_arbace_classes_analyze__init_part2_A_const_94 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[175]); A_arbace_classes_analyze__init_part2_A_const_95 = A_arbace_classes_analyze__init_part2_A_const_pool.A[176]; A_arbace_classes_analyze__init_part2_A_const_96 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[177]); A_arbace_classes_analyze__init_part2_A_const_97 = A_arbace_classes_analyze__init_part2_A_const_pool.A[178]; A_arbace_classes_analyze__init_part2_A_const_98 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[179]); A_arbace_classes_analyze__init_part2_A_const_99 = A_arbace_classes_analyze__init_part2_A_const_pool.A[180]; A_arbace_classes_analyze__init_part2_A_const_100 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[181]); A_arbace_classes_analyze__init_part2_A_const_101 = A_arbace_classes_analyze__init_part2_A_const_pool.A[182]; A_arbace_classes_analyze__init_part2_A_const_102 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[183]); A_arbace_classes_analyze__init_part2_A_const_103 = A_arbace_classes_analyze__init_part2_A_const_pool.A[184]; A_arbace_classes_analyze__init_part2_A_const_104 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[185]); A_arbace_classes_analyze__init_part2_A_const_105 = A_arbace_classes_analyze__init_part2_A_const_pool.A[186]; A_arbace_classes_analyze__init_part2_A_const_106 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[187]); A_arbace_classes_analyze__init_part2_A_const_107 = A_arbace_classes_analyze__init_part2_A_const_pool.A[188]; A_arbace_classes_analyze__init_part2_A_const_108 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[189]); A_arbace_classes_analyze__init_part2_A_const_109 = A_arbace_classes_analyze__init_part2_A_const_pool.A[190]; A_arbace_classes_analyze__init_part2_A_const_110 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[191]); A_arbace_classes_analyze__init_part2_A_const_111 = A_arbace_classes_analyze__init_part2_A_const_pool.A[192]; A_arbace_classes_analyze__init_part2_A_const_112 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[193]); A_arbace_classes_analyze__init_part2_A_const_113 = A_arbace_classes_analyze__init_part2_A_const_pool.A[194]; A_arbace_classes_analyze__init_part2_A_const_114 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[195]); A_arbace_classes_analyze__init_part2_A_const_115 = A_arbace_classes_analyze__init_part2_A_const_pool.A[196]; A_arbace_classes_analyze__init_part2_A_const_116 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[197]); A_arbace_classes_analyze__init_part2_A_const_117 = A_arbace_classes_analyze__init_part2_A_const_pool.A[198]; A_arbace_classes_analyze__init_part2_A_const_118 = A_arbace_classes_analyze__init_part2_A_const_pool.A[199]; A_arbace_classes_analyze__init_part2_A_const_119 = A_arbace_classes_analyze__init_part2_A_const_pool.A[200]; A_arbace_classes_analyze__init_part2_A_const_120 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[201]); A_arbace_classes_analyze__init_part2_A_const_121 = A_arbace_classes_analyze__init_part2_A_const_pool.A[202]; A_arbace_classes_analyze__init_part2_A_const_122 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[203]); A_arbace_classes_analyze__init_part2_A_const_123 = A_arbace_classes_analyze__init_part2_A_const_pool.A[204]; var tmp10 *lang.Var; A_arbace_classes_analyze__init_part1_A_Init(); tmp10 = A_arbace_classes_analyze__init_part1_A_const_47; A_arbace_classes_analyze__init_part2_A_const_124 = tmp10; A_arbace_classes_analyze__init_part2_A_const_125 = A_arbace_classes_analyze__init_part2_A_const_pool.A[205]; A_arbace_classes_analyze__init_part2_A_const_126 = A_arbace_classes_analyze__init_part2_A_const_pool.A[206]; A_arbace_classes_analyze__init_part2_A_const_127 = A_arbace_classes_analyze__init_part2_A_const_pool.A[207]; A_arbace_classes_analyze__init_part2_A_const_128 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[208]); A_arbace_classes_analyze__init_part2_A_const_129 = A_arbace_classes_analyze__init_part2_A_const_pool.A[209]; A_arbace_classes_analyze__init_part2_A_const_130 = A_arbace_classes_analyze__init_part2_A_const_pool.A[210]; A_arbace_classes_analyze__init_part2_A_const_131 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[211]); A_arbace_classes_analyze__init_part2_A_const_132 = A_arbace_classes_analyze__init_part2_A_const_pool.A[212]; A_arbace_classes_analyze__init_part2_A_const_133 = A_arbace_classes_analyze__init_part2_A_const_pool.A[213]; A_arbace_classes_analyze__init_part2_A_const_134 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[214]); A_arbace_classes_analyze__init_part2_A_const_135 = A_arbace_classes_analyze__init_part2_A_const_pool.A[215]; var tmp11 *lang.Var; A_arbace_classes_analyze__init_part0_A_Init(); tmp11 = A_arbace_classes_analyze__init_part0_A_const_67; A_arbace_classes_analyze__init_part2_A_const_136 = tmp11; A_arbace_classes_analyze__init_part2_A_const_137 = A_arbace_classes_analyze__init_part2_A_const_pool.A[216]; A_arbace_classes_analyze__init_part2_A_const_138 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[217]); A_arbace_classes_analyze__init_part2_A_const_139 = A_arbace_classes_analyze__init_part2_A_const_pool.A[218]; A_arbace_classes_analyze__init_part2_A_const_140 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[219]); A_arbace_classes_analyze__init_part2_A_const_141 = A_arbace_classes_analyze__init_part2_A_const_pool.A[220]; A_arbace_classes_analyze__init_part2_A_const_142 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[221]); A_arbace_classes_analyze__init_part2_A_const_143 = A_arbace_classes_analyze__init_part2_A_const_pool.A[222]; A_arbace_classes_analyze__init_part2_A_const_144 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[223]); A_arbace_classes_analyze__init_part2_A_const_145 = A_arbace_classes_analyze__init_part2_A_const_pool.A[224]; A_arbace_classes_analyze__init_part2_A_const_146 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[225]); A_arbace_classes_analyze__init_part2_A_const_147 = A_arbace_classes_analyze__init_part2_A_const_pool.A[226]; A_arbace_classes_analyze__init_part2_A_const_148 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[227]); A_arbace_classes_analyze__init_part2_A_const_149 = A_arbace_classes_analyze__init_part2_A_const_pool.A[228]; A_arbace_classes_analyze__init_part2_A_const_150 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[229]); A_arbace_classes_analyze__init_part2_A_const_151 = A_arbace_classes_analyze__init_part2_A_const_pool.A[230]; A_arbace_classes_analyze__init_part2_A_const_152 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[231]); A_arbace_classes_analyze__init_part2_A_const_153 = A_arbace_classes_analyze__init_part2_A_const_pool.A[232]; A_arbace_classes_analyze__init_part2_A_const_154 = A_arbace_classes_analyze__init_part2_A_const_pool.A[233]; A_arbace_classes_analyze__init_part2_A_const_155 = A_arbace_classes_analyze__init_part2_A_const_pool.A[234]; A_arbace_classes_analyze__init_part2_A_const_156 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[235]); A_arbace_classes_analyze__init_part2_A_const_157 = A_arbace_classes_analyze__init_part2_A_const_pool.A[236]; A_arbace_classes_analyze__init_part2_A_const_158 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[237]); A_arbace_classes_analyze__init_part2_A_const_159 = A_arbace_classes_analyze__init_part2_A_const_pool.A[238]; A_arbace_classes_analyze__init_part2_A_const_160 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[239]); A_arbace_classes_analyze__init_part2_A_const_161 = A_arbace_classes_analyze__init_part2_A_const_pool.A[240]; A_arbace_classes_analyze__init_part2_A_const_162 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[241]); A_arbace_classes_analyze__init_part2_A_const_163 = A_arbace_classes_analyze__init_part2_A_const_pool.A[242]; A_arbace_classes_analyze__init_part2_A_const_164 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[243]); A_arbace_classes_analyze__init_part2_A_const_165 = A_arbace_classes_analyze__init_part2_A_const_pool.A[244]; A_arbace_classes_analyze__init_part2_A_const_166 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[245]); A_arbace_classes_analyze__init_part2_A_const_167 = A_arbace_classes_analyze__init_part2_A_const_pool.A[246]; A_arbace_classes_analyze__init_part2_A_const_168 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[247]); A_arbace_classes_analyze__init_part2_A_const_169 = A_arbace_classes_analyze__init_part2_A_const_pool.A[248]; A_arbace_classes_analyze__init_part2_A_const_170 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[249]); A_arbace_classes_analyze__init_part2_A_const_171 = A_arbace_classes_analyze__init_part2_A_const_pool.A[250]; A_arbace_classes_analyze__init_part2_A_const_172 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[251]); A_arbace_classes_analyze__init_part2_A_const_173 = A_arbace_classes_analyze__init_part2_A_const_pool.A[252]; A_arbace_classes_analyze__init_part2_A_const_174 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[253]); A_arbace_classes_analyze__init_part2_A_const_175 = A_arbace_classes_analyze__init_part2_A_const_pool.A[254]; A_arbace_classes_analyze__init_part2_A_const_176 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[255]); A_arbace_classes_analyze__init_part2_A_const_177 = A_arbace_classes_analyze__init_part2_A_const_pool.A[256]; A_arbace_classes_analyze__init_part2_A_const_178 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[257]); A_arbace_classes_analyze__init_part2_A_const_179 = A_arbace_classes_analyze__init_part2_A_const_pool.A[258]; A_arbace_classes_analyze__init_part2_A_const_180 = A_arbace_classes_analyze__init_part2_A_const_pool.A[259]; A_arbace_classes_analyze__init_part2_A_const_181 = A_arbace_classes_analyze__init_part2_A_const_pool.A[260]; A_arbace_classes_analyze__init_part2_A_const_182 = lang.Var_Cast(A_arbace_classes_analyze__init_part2_A_const_pool.A[261]); A_arbace_classes_analyze__init_part2_A_const_183 = A_arbace_classes_analyze__init_part2_A_const_pool.A[262]; A_arbace_classes_analyze__init_part2_A_const_184 = A_arbace_classes_analyze__init_part2_A_const_pool.A[263] }

func A_arbace_classes_analyze__init_part2_A_New() *A_arbace_classes_analyze__init_part2_A { A_arbace_classes_analyze__init_part2_A_Init(); t := &A_arbace_classes_analyze__init_part2_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_analyze__init_part2_A) Ctor() {}

func (t *A_arbace_classes_analyze__init_part2_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_analyze__init_part2_A) GetClass__Class() *jrt.Class { return A_arbace_classes_analyze__init_part2_A_class }

func (t *A_arbace_classes_analyze__init_part2_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_analyze__init_part2_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_analyze__init_part2_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_analyze__init_part2_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_analyze__init_part2_A); return ok }

func A_arbace_classes_analyze__init_part2_A_Cast(x any) *A_arbace_classes_analyze__init_part2_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_analyze__init_part2_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_analyze__init_part2_A_class)) }; return v }



type A_arbace_classes_analyze__init_part3_A struct{ jrt.Object }

var A_arbace_classes_analyze__init_part3_A_const_pool *jrt.RefArray

var A_arbace_classes_analyze__init_part3_A_const_0 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_1 any

var A_arbace_classes_analyze__init_part3_A_const_2 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_3 any

var A_arbace_classes_analyze__init_part3_A_const_4 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_5 any

var A_arbace_classes_analyze__init_part3_A_const_6 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_7 any

var A_arbace_classes_analyze__init_part3_A_const_8 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_9 any

var A_arbace_classes_analyze__init_part3_A_const_10 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_11 any

var A_arbace_classes_analyze__init_part3_A_const_12 any

var A_arbace_classes_analyze__init_part3_A_const_13 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_14 any

var A_arbace_classes_analyze__init_part3_A_const_15 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_16 any

var A_arbace_classes_analyze__init_part3_A_const_17 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_18 any

var A_arbace_classes_analyze__init_part3_A_const_19 any

var A_arbace_classes_analyze__init_part3_A_const_20 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_21 any

var A_arbace_classes_analyze__init_part3_A_const_22 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_23 any

var A_arbace_classes_analyze__init_part3_A_const_24 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_25 any

var A_arbace_classes_analyze__init_part3_A_const_26 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_27 any

var A_arbace_classes_analyze__init_part3_A_const_28 any

var A_arbace_classes_analyze__init_part3_A_const_29 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_30 any

var A_arbace_classes_analyze__init_part3_A_const_31 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_32 any

var A_arbace_classes_analyze__init_part3_A_const_33 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_34 any

var A_arbace_classes_analyze__init_part3_A_const_35 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_36 any

var A_arbace_classes_analyze__init_part3_A_const_37 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_38 any

var A_arbace_classes_analyze__init_part3_A_const_39 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_40 any

var A_arbace_classes_analyze__init_part3_A_const_41 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_42 any

var A_arbace_classes_analyze__init_part3_A_const_43 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_44 any

var A_arbace_classes_analyze__init_part3_A_const_45 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_46 any

var A_arbace_classes_analyze__init_part3_A_const_47 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_48 any

var A_arbace_classes_analyze__init_part3_A_const_49 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_50 any

var A_arbace_classes_analyze__init_part3_A_const_51 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_52 any

var A_arbace_classes_analyze__init_part3_A_const_53 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_54 any

var A_arbace_classes_analyze__init_part3_A_const_55 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_56 any

var A_arbace_classes_analyze__init_part3_A_const_57 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_58 any

var A_arbace_classes_analyze__init_part3_A_const_59 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_60 any

var A_arbace_classes_analyze__init_part3_A_const_61 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_62 any

var A_arbace_classes_analyze__init_part3_A_const_63 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_64 any

var A_arbace_classes_analyze__init_part3_A_const_65 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_66 any

var A_arbace_classes_analyze__init_part3_A_const_67 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_68 any

var A_arbace_classes_analyze__init_part3_A_const_69 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_70 any

var A_arbace_classes_analyze__init_part3_A_const_71 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_72 any

var A_arbace_classes_analyze__init_part3_A_const_73 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_74 any

var A_arbace_classes_analyze__init_part3_A_const_75 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_76 any

var A_arbace_classes_analyze__init_part3_A_const_77 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_78 any

var A_arbace_classes_analyze__init_part3_A_const_79 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_80 any

var A_arbace_classes_analyze__init_part3_A_const_81 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_82 any

var A_arbace_classes_analyze__init_part3_A_const_83 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_84 any

var A_arbace_classes_analyze__init_part3_A_const_85 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_86 any

var A_arbace_classes_analyze__init_part3_A_const_87 *lang.Var

var A_arbace_classes_analyze__init_part3_A_const_88 any

var A_arbace_classes_analyze__init_part3_A_init jrt.ClassInit

func A_arbace_classes_analyze__init_part3_A_Init() { if !A_arbace_classes_analyze__init_part3_A_init.Done() { A_arbace_classes_analyze__init_part3_A_init.Run(A_arbace_classes_analyze__init_part3_A_clinit) } }

func A_arbace_classes_analyze__init_part3_A_clinit() { A_arbace_classes_analyze__init_part3_A_clinit_p0(); A_arbace_classes_analyze__init_part3_A_clinit_p1() }

func A_arbace_classes_analyze__init_part3_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_analyze__init_part3_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_1090, 142); A_arbace_classes_analyze__init_part3_A_const_0 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[68]); A_arbace_classes_analyze__init_part3_A_const_1 = A_arbace_classes_analyze__init_part3_A_const_pool.A[69]; A_arbace_classes_analyze__init_part3_A_const_2 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[70]); A_arbace_classes_analyze__init_part3_A_const_3 = A_arbace_classes_analyze__init_part3_A_const_pool.A[71]; A_arbace_classes_analyze__init_part3_A_const_4 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[72]); A_arbace_classes_analyze__init_part3_A_const_5 = A_arbace_classes_analyze__init_part3_A_const_pool.A[73] }

func A_arbace_classes_analyze__init_part3_A_clinit_p1() { var tmp1 *lang.Var; A_arbace_classes_analyze__init_part2_A_Init(); tmp1 = A_arbace_classes_analyze__init_part2_A_const_90; A_arbace_classes_analyze__init_part3_A_const_6 = tmp1; A_arbace_classes_analyze__init_part3_A_const_7 = A_arbace_classes_analyze__init_part3_A_const_pool.A[74]; A_arbace_classes_analyze__init_part3_A_const_8 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[75]); A_arbace_classes_analyze__init_part3_A_const_9 = A_arbace_classes_analyze__init_part3_A_const_pool.A[76]; var tmp2 *lang.Var; A_arbace_classes_analyze__init_part2_A_Init(); tmp2 = A_arbace_classes_analyze__init_part2_A_const_92; A_arbace_classes_analyze__init_part3_A_const_10 = tmp2; A_arbace_classes_analyze__init_part3_A_const_11 = A_arbace_classes_analyze__init_part3_A_const_pool.A[77]; A_arbace_classes_analyze__init_part3_A_const_12 = A_arbace_classes_analyze__init_part3_A_const_pool.A[78]; var tmp3 *lang.Var; A_arbace_classes_analyze__init_part2_A_Init(); tmp3 = A_arbace_classes_analyze__init_part2_A_const_96; A_arbace_classes_analyze__init_part3_A_const_13 = tmp3; A_arbace_classes_analyze__init_part3_A_const_14 = A_arbace_classes_analyze__init_part3_A_const_pool.A[79]; var tmp4 *lang.Var; A_arbace_classes_analyze__init_part2_A_Init(); tmp4 = A_arbace_classes_analyze__init_part2_A_const_94; A_arbace_classes_analyze__init_part3_A_const_15 = tmp4; A_arbace_classes_analyze__init_part3_A_const_16 = A_arbace_classes_analyze__init_part3_A_const_pool.A[80]; A_arbace_classes_analyze__init_part3_A_const_17 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[81]); A_arbace_classes_analyze__init_part3_A_const_18 = A_arbace_classes_analyze__init_part3_A_const_pool.A[82]; A_arbace_classes_analyze__init_part3_A_const_19 = A_arbace_classes_analyze__init_part3_A_const_pool.A[83]; var tmp5 *lang.Var; A_arbace_classes_analyze__init_part1_A_Init(); tmp5 = A_arbace_classes_analyze__init_part1_A_const_178; A_arbace_classes_analyze__init_part3_A_const_20 = tmp5; A_arbace_classes_analyze__init_part3_A_const_21 = A_arbace_classes_analyze__init_part3_A_const_pool.A[84]; A_arbace_classes_analyze__init_part3_A_const_22 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[85]); A_arbace_classes_analyze__init_part3_A_const_23 = A_arbace_classes_analyze__init_part3_A_const_pool.A[86]; A_arbace_classes_analyze__init_part3_A_const_24 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[87]); A_arbace_classes_analyze__init_part3_A_const_25 = A_arbace_classes_analyze__init_part3_A_const_pool.A[88]; A_arbace_classes_analyze__init_part3_A_const_26 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[89]); A_arbace_classes_analyze__init_part3_A_const_27 = A_arbace_classes_analyze__init_part3_A_const_pool.A[90]; A_arbace_classes_analyze__init_part3_A_const_28 = A_arbace_classes_analyze__init_part3_A_const_pool.A[91]; A_arbace_classes_analyze__init_part3_A_const_29 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[92]); A_arbace_classes_analyze__init_part3_A_const_30 = A_arbace_classes_analyze__init_part3_A_const_pool.A[93]; A_arbace_classes_analyze__init_part3_A_const_31 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[94]); A_arbace_classes_analyze__init_part3_A_const_32 = A_arbace_classes_analyze__init_part3_A_const_pool.A[95]; var tmp6 *lang.Var; A_arbace_classes_analyze__init_part2_A_Init(); tmp6 = A_arbace_classes_analyze__init_part2_A_const_100; A_arbace_classes_analyze__init_part3_A_const_33 = tmp6; A_arbace_classes_analyze__init_part3_A_const_34 = A_arbace_classes_analyze__init_part3_A_const_pool.A[96]; A_arbace_classes_analyze__init_part3_A_const_35 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[97]); A_arbace_classes_analyze__init_part3_A_const_36 = A_arbace_classes_analyze__init_part3_A_const_pool.A[98]; A_arbace_classes_analyze__init_part3_A_const_37 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[99]); A_arbace_classes_analyze__init_part3_A_const_38 = A_arbace_classes_analyze__init_part3_A_const_pool.A[100]; A_arbace_classes_analyze__init_part3_A_const_39 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[101]); A_arbace_classes_analyze__init_part3_A_const_40 = A_arbace_classes_analyze__init_part3_A_const_pool.A[102]; A_arbace_classes_analyze__init_part3_A_const_41 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[103]); A_arbace_classes_analyze__init_part3_A_const_42 = A_arbace_classes_analyze__init_part3_A_const_pool.A[104]; A_arbace_classes_analyze__init_part3_A_const_43 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[105]); A_arbace_classes_analyze__init_part3_A_const_44 = A_arbace_classes_analyze__init_part3_A_const_pool.A[106]; A_arbace_classes_analyze__init_part3_A_const_45 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[107]); A_arbace_classes_analyze__init_part3_A_const_46 = A_arbace_classes_analyze__init_part3_A_const_pool.A[108]; var tmp7 *lang.Var; A_arbace_classes_analyze__init_part2_A_Init(); tmp7 = A_arbace_classes_analyze__init_part2_A_const_102; A_arbace_classes_analyze__init_part3_A_const_47 = tmp7; A_arbace_classes_analyze__init_part3_A_const_48 = A_arbace_classes_analyze__init_part3_A_const_pool.A[109]; A_arbace_classes_analyze__init_part3_A_const_49 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[110]); A_arbace_classes_analyze__init_part3_A_const_50 = A_arbace_classes_analyze__init_part3_A_const_pool.A[111]; A_arbace_classes_analyze__init_part3_A_const_51 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[112]); A_arbace_classes_analyze__init_part3_A_const_52 = A_arbace_classes_analyze__init_part3_A_const_pool.A[113]; var tmp8 *lang.Var; A_arbace_classes_analyze__init_part2_A_Init(); tmp8 = A_arbace_classes_analyze__init_part2_A_const_104; A_arbace_classes_analyze__init_part3_A_const_53 = tmp8; A_arbace_classes_analyze__init_part3_A_const_54 = A_arbace_classes_analyze__init_part3_A_const_pool.A[114]; A_arbace_classes_analyze__init_part3_A_const_55 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[115]); A_arbace_classes_analyze__init_part3_A_const_56 = A_arbace_classes_analyze__init_part3_A_const_pool.A[116]; A_arbace_classes_analyze__init_part3_A_const_57 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[117]); A_arbace_classes_analyze__init_part3_A_const_58 = A_arbace_classes_analyze__init_part3_A_const_pool.A[118]; var tmp9 *lang.Var; A_arbace_classes_analyze__init_part2_A_Init(); tmp9 = A_arbace_classes_analyze__init_part2_A_const_98; A_arbace_classes_analyze__init_part3_A_const_59 = tmp9; A_arbace_classes_analyze__init_part3_A_const_60 = A_arbace_classes_analyze__init_part3_A_const_pool.A[119]; A_arbace_classes_analyze__init_part3_A_const_61 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[120]); A_arbace_classes_analyze__init_part3_A_const_62 = A_arbace_classes_analyze__init_part3_A_const_pool.A[121]; A_arbace_classes_analyze__init_part3_A_const_63 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[122]); A_arbace_classes_analyze__init_part3_A_const_64 = A_arbace_classes_analyze__init_part3_A_const_pool.A[123]; A_arbace_classes_analyze__init_part3_A_const_65 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[124]); A_arbace_classes_analyze__init_part3_A_const_66 = A_arbace_classes_analyze__init_part3_A_const_pool.A[125]; A_arbace_classes_analyze__init_part3_A_const_67 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[126]); A_arbace_classes_analyze__init_part3_A_const_68 = A_arbace_classes_analyze__init_part3_A_const_pool.A[127]; var tmp10 *lang.Var; A_arbace_classes_analyze__init_part0_A_Init(); tmp10 = A_arbace_classes_analyze__init_part0_A_const_38; A_arbace_classes_analyze__init_part3_A_const_69 = tmp10; A_arbace_classes_analyze__init_part3_A_const_70 = A_arbace_classes_analyze__init_part3_A_const_pool.A[128]; A_arbace_classes_analyze__init_part3_A_const_71 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[129]); A_arbace_classes_analyze__init_part3_A_const_72 = A_arbace_classes_analyze__init_part3_A_const_pool.A[130]; A_arbace_classes_analyze__init_part3_A_const_73 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[131]); A_arbace_classes_analyze__init_part3_A_const_74 = A_arbace_classes_analyze__init_part3_A_const_pool.A[132]; var tmp11 *lang.Var; A_arbace_classes_analyze__init_part1_A_Init(); tmp11 = A_arbace_classes_analyze__init_part1_A_const_23; A_arbace_classes_analyze__init_part3_A_const_75 = tmp11; A_arbace_classes_analyze__init_part3_A_const_76 = A_arbace_classes_analyze__init_part3_A_const_pool.A[133]; A_arbace_classes_analyze__init_part3_A_const_77 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[134]); A_arbace_classes_analyze__init_part3_A_const_78 = A_arbace_classes_analyze__init_part3_A_const_pool.A[135]; var tmp12 *lang.Var; A_arbace_classes_analyze__init_part1_A_Init(); tmp12 = A_arbace_classes_analyze__init_part1_A_const_25; A_arbace_classes_analyze__init_part3_A_const_79 = tmp12; A_arbace_classes_analyze__init_part3_A_const_80 = A_arbace_classes_analyze__init_part3_A_const_pool.A[136]; A_arbace_classes_analyze__init_part3_A_const_81 = lang.Var_Cast(A_arbace_classes_analyze__init_part3_A_const_pool.A[137]); A_arbace_classes_analyze__init_part3_A_const_82 = A_arbace_classes_analyze__init_part3_A_const_pool.A[138]; var tmp13 *lang.Var; A_arbace_classes_analyze__init_part1_A_Init(); tmp13 = A_arbace_classes_analyze__init_part1_A_const_31; A_arbace_classes_analyze__init_part3_A_const_83 = tmp13; A_arbace_classes_analyze__init_part3_A_const_84 = A_arbace_classes_analyze__init_part3_A_const_pool.A[139]; var tmp14 *lang.Var; A_arbace_classes_analyze__init_part1_A_Init(); tmp14 = A_arbace_classes_analyze__init_part1_A_const_35; A_arbace_classes_analyze__init_part3_A_const_85 = tmp14; A_arbace_classes_analyze__init_part3_A_const_86 = A_arbace_classes_analyze__init_part3_A_const_pool.A[140]; var tmp15 *lang.Var; A_arbace_classes_analyze__init_part1_A_Init(); tmp15 = A_arbace_classes_analyze__init_part1_A_const_33; A_arbace_classes_analyze__init_part3_A_const_87 = tmp15; A_arbace_classes_analyze__init_part3_A_const_88 = A_arbace_classes_analyze__init_part3_A_const_pool.A[141] }

func A_arbace_classes_analyze__init_part3_A_New() *A_arbace_classes_analyze__init_part3_A { A_arbace_classes_analyze__init_part3_A_Init(); t := &A_arbace_classes_analyze__init_part3_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_analyze__init_part3_A) Ctor() {}

func (t *A_arbace_classes_analyze__init_part3_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_analyze__init_part3_A) GetClass__Class() *jrt.Class { return A_arbace_classes_analyze__init_part3_A_class }

func (t *A_arbace_classes_analyze__init_part3_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_analyze__init_part3_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_analyze__init_part3_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_analyze__init_part3_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_analyze__init_part3_A); return ok }

func A_arbace_classes_analyze__init_part3_A_Cast(x any) *A_arbace_classes_analyze__init_part3_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_analyze__init_part3_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_analyze__init_part3_A_class)) }; return v }
