//line j2g_up.ae:1
package aot_arbace_classes_analyze

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
func Up_ExceptionInfo_Throwable(p *lang.ExceptionInfo) jrt.Throwable_I { if p == nil { return nil }; return p }

func Up_Namespace_AReference(p *lang.Namespace) lang.AReference_I { if p == nil { return nil }; return p }

func Up_Double_Number(p *jrt.Double) jrt.Number_I { if p == nil { return nil }; return p }

func Up_Long_Number(p *jrt.Long) jrt.Number_I { if p == nil { return nil }; return p }
