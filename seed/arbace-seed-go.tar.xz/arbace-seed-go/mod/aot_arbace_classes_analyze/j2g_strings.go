//line j2g_strings.ae:1
package aot_arbace_classes_analyze

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn20,arbace.classes.typesyn1,tyn18,arbace.classes.envyn3,envyn20,arbace.classes.parseyn1,pyn20,arbace.classes.loweryn5,loweryn22,arbace.classes.opcodesyn7,Opcodesyn17,arbace.classes.goyn13,TypeReferenceyn11,arbace.corekn3,docks6,arbace13,compile-errorkn5,statekn5,flagskn15,outer-instance?kn5,outerkn4,desckn11,super-outerkn4,enumkn4,kindkn9,enum-bodykn4,anonkn5,localkn4,typekn8,captureskn7,nestingkn2,nskn4,elsekn13,local-classeskn5,classkn6,simplekn14,member-classeskn7,resolvekn5,tvarskn6,boundskn14,implicit-outerkn3,symkn7,tparamskn4,optskn11,type-paramskn1,tkn4,namekn4,argskn4,tvarkn4,metakn9,retentionkn7,methodskn5,arraykn10,annotationkn6,valueskn5,valuekn6,nestedkn5,constkn7,targetskn3,refkn4,pathkn4,annskn6,sourcekn7,visiblekn7,runtimekn7,packagekn8,counterskn3,topkn6,memberkn7,static?kn9,interfacekn14,static-contextkn15,creation-boundskn16,enclosing-methodkn9,nest-hostkn10,uses-this0kn7,lambdaskn5,extrakn8,anon-ctxkn5,orderkn6,parsedkn4,formkn14,parsed-memberskn7,memberskn10,own-boundskn7,extendskn10,implementskn10,anon-superkn6,recordkn12,headers-donekn5,superkn10,interfaceskn7,super-tkn12,interfaces-tkn9,signaturekn7,permitskn11,annotationskn16,type-annotationskn10,deprecatedkn3,tagyn16,java.lang.Objectkn2,tnkn5,finalkn5,ownerkn9,bridge-ofkn14,clojure-bridgekn7,derivedkn6,bridgekn6,throwskn3,retkn6,paramskn6,statickn5,vmetakn14,clojure-methodkn4,primkn7,privatekn8,has-bodykn7,defaultkn7,varargskn4,recvkn6,ret-tnkn3,sigkn17,param-annotationskn11,has-defaultkn5,scopekn6,methodkn11,inner-flagskn6,publickn9,protectedkn9,synthetickn7,compactkn4,ctorkn8,has-initkn4,initkn3,valkn7,lenientkn10,field-initkn12,members-donekn5,fieldkn13,enum-constantkn9,constantskn17,enum-values-fieldyn1,&kn10,componentskn9,componentkn15,record-accessorkn20,record-object-methodkn9,canonicalkn16,record-canonicalkn14,anon-ctor-desckn6,fieldskn11,in-progresskn11,enum-valueskn12,enum-valueOfkn7,mparamskn12,enum-$valueskn15,anon-super-ctorkn9,anon-ctorkn12,default-ctorkn2,opkn4,nullkn5,loosekn7,literalkn4,nonekn5,widenkn12,narrow-constkn3,boxkn5,unboxkn2,dokn2,ifkn4,thenkn6,switchkn4,bodykn5,caseskn3,trykn7,catcheskn3,letkn7,monitorkn2,idkn6,parentkn8,boundarykn13,ctor-prologuekn10,ctor-phasekn8,prologuekn5,framekn6,localskn6,lambdakn4,cvalkn8,receiverkn1,bkn8,capturedkn7,mutablekn11,outer-paramkn16,outer-param-pathkn4,basekn9,this-pathkn9,uses-thiskn14,creation-framekn5,macrokn4,linekn6,bigintkn11,array-clonekn7,cast-tokn4,castkn4,exprkn10,statementskn10,get-statickn9,get-fieldkn6,targetkn10,const-onlykn13,const-classeskn7,clojurekn9,class-litkn8,declarerkn11,clojure-tagkn9,var-derefkn3,varkn10,unresolvedkn7,convertkn4,fromkn2,tokn6,invokekn7,no-castkn11,if-instancekn4,whatkn4,loopkn5,labelkn6,breakskn3,itfkn3,remkn3,subkn3,deckn3,mulkn3,divkn3,negkn4,ushrkn3,addkn3,inckn3,notkn2,orkn3,andkn3,shrkn3,xorkn3,shlkn6,andnotkn5,exactkn8,longbitskn5,floatkn4,longkn5,arithkn6,familykn1,okn3,intkn7,comparekn3,cmpkn11,pending-varkn10,loop-localkn9,type-annskn8,bindingsks14,arbace.classes7,fn-bodykn10,label-loopkn12,break-targetkn6,labelskn4,testkn5,recuryn9,for-each*yn5,loop*kn2,kwkn5,breakkn6,returnkn5,throwyn5,catchyn7,finallykn7,classeskn7,finallykn4,lockkn9,set-localkn10,set-statickn9,set-fieldyn1,.yn3,setyn3,varyn5,superyn4,set!kn6,strictyn1,_kn9,fi-methodkn2,psks22,arbace.classes.analyze7,unknownks7,clojure10,no-reflectks7,clojure3,whykn12,clojure-argskn10,fi-adapterkn8,sam-namekn8,sam-desckn7,invokerkn12,invoker-desckn10,array-initkn5,elemskn7,specialkn7,virtualkn4,warnkn10,reflectionkn10,param-tagskn14,owner-overridekn7,ret-tagkn9,type-argskn13,type-arg-annskn9,arg-nodeskn8,instancekn10,clj-inlinekn7,alengthkn12,null-checkedkn7,in-ctorkn3,newkn9,ctor-callkn9,new-arraykn4,dimsyn5,arraykn4,agetkn5,indexkn4,asetkn9,instance?kn8,type-argyn3,newyn14,class-literal*ks22,arbace.classes.analyze18,qualified-instancekn6,inlinekn14,inline-aritieskn5,bool=ys11,arbace.core3,notys11,arbace.core1,=kn4,nil?kn10,identical?yn7,switch*yn15,with-resources*ys11,arbace.core7,import*yn2,doyn6,reify*yn9,java-str*yn5,case*yn3,tryyn6,super.yn6,label*yn6,break*yn5,this.kn4,thisyn13,monitor-enteryn7,lambda*yn5,throwyn6,letfn*yn6,class*yn9,continue*yn12,java-assert*yn2,ifyn5,quoteyn11,method-ref*yn12,monitor-exityn4,let*yn5,recuryn3,defyn3,fn*yn7,return*yn12,if-instance*yn8,deftype*kn10,var-invokeyn11,importClassys11,arbace.core4,castyn21,arbace.lang.Namespaceys14,arbace.lang.RT10,CURRENT_NSyn5,derefys14,arbace.lang.RT22,classForNameNonLoadingkn6,columnkn7,dynamickn10,class-initkn13,creation-actxkn10,clojure-fnkn11,method-infokn5,slot0kn5,paramyn6,.superkn9,enum-argskn9,anon-argskn4,callkn11,nested-callkn13,outer-bindingkn11,calls-superkn14,compact-localskn10,enum-constkn7,ordinalkn8,analyzedyn4,thiskn3,midkn6,clinitkn6,bodieskn10,field-nameyn6,this__kn6,superskn8,genericskn12,bridges-donekn12,clojure-typekn10,impl-ownerkn13,declared-onlyyn4,anonkn7,diamondkn20,super-outer-is-outerkn16,super-outer-pathkn8,java-strkn8,operandskn9,tag-constkn4,nodekn5,eagerkn5,partskn6,assertkn3,msgkn10,holder-topkn8,msg-desckn16,interface-assertkn11,uses-assertkn14,assert-holderskn12,holder-firstkn3,arrkn3,lenkn1,ikn2,itkn8,for-eachkn4,collkn6,hiddenkn4,elemkn8,iteratoryn5,closeys11,arbace.core5,some?yn19,java.lang.Throwableyn13,addSuppressedkn14,normal-finallykn5,interkn5,typeskn15,lambda-counterskn10,ref-lambdakn10,method-refkn2,fikn7,markerskn12,serializablekn12,intersectionkn3,samkn9,inst-desckn12,lambda-nodeskn12,serial-nodeskn14,qualifier-annskn9,qualifierkn5,boundkn10,null-checkkn7,unboundkn17,record-componentskn8,accessorkn7,patternkn5,compskn4,tempkn11,switch-mapskn6,stringkn4,whenkn5,guardkn5,ctypekn3,selkn8,sel-typekn11,enum-directkn11,sel-bindingkn7,restartks22,arbace.classes.analyze3,eofkn3,eofkn9,read-condkn5,allowyn8,defclasskn12,source-triedys11,arbace.core5,in-nsyn5,in-nsyn2,nsyn6,importys11,arbace.core6,importkn12,access-countkn9,accessorskn4,insnkn9,putstatickn9,getstatickn8,putfieldkn8,getfieldkn12,invokestatickn13,invokevirtualkn13,invokespecialkn15,clj-const-indexkn10,clj-constskn4,readkn4,textv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,V3,R7,R1,R8,V3,R9,R1,R10,V3,R11,R1,R12,V3,R13,R1,R14,v11,arbace.core5,referR15,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn22,arbace.classes.analyzem2,R16,s300,Entering class declarations (names, supertypes, members, what javac derives) and analyzing\n  code into typed nodes (SPEC §4 to §6), which the Go build's interpreter\n  (arbace.classes.interp) runs and j2g translates. (The bytecode back end, arbace.classes.emit,\n  is on the branch arbace-for-java-26.)v11,arbace.core5,swap!v22,arbace.classes.analyze3,idsv11,arbace.core3,incv11,arbace.core7,ex-infov11,arbace.core5,assocR17,v22,arbace.classes.analyze4,failv18,arbace.classes.env13,*compile-set*v22,arbace.classes.analyze4,declv11,arbace.core5,applyv11,arbace.core6,updateR18,v22,arbace.classes.analyze5,decl!v11,arbace.core3,notl0,v22,arbace.classes.analyze4,has?R19,i8,v18,arbace.classes.env9,nest-hostv18,arbace.classes.env4,infoR20,v22,arbace.classes.analyze11,outer-levelR21,v20,arbace.classes.types17,parse-method-descR22,v20,arbace.classes.types11,method-descv11,arbace.core4,consv20,arbace.classes.types14,internal->descv11,arbace.core6,concatR23,R24,R25,R26,V2,s18,Ljava/lang/String;s1,IS2,R27,R28,v11,arbace.core3,mapR29,R30,R31,v13,arbace.string7,replacev11,arbace.core5,mungev11,arbace.core4,namev11,arbace.core7,ns-namev18,arbace.classes.env6,known?v22,arbace.classes.analyze15,*source-lookup*v22,arbace.classes.analyze6,*unit*v22,arbace.classes.analyze18,enter-from-source!v11,arbace.core7,symbol?v11,arbace.core9,namespaceR32,v13,arbace.string9,includes?v13,arbace.string12,starts-with?v11,arbace.core6,ns-mapv11,arbace.core6,class?v11,arbace.core6,get-inv18,arbace.classes.env14,source-importsv22,arbace.classes.analyze13,class-exists?v13,arbace.string5,splitp2,\\$l2,v22,arbace.classes.analyze17,resolve-class-symv11,arbace.core6,symbolR33,R34,R35,R36,v11,arbace.core4,not=R27,R37,v22,arbace.classes.analyze15,default-import?v18,arbace.classes.env12,from-source?v20,arbace.classes.types10,package-ofv22,arbace.classes.analyze10,ns-packageR38,R39,v11,arbace.core3,setv11,arbace.core4,keysR40,R41,v22,arbace.classes.analyze14,implicit-outerv11,arbace.core4,mapvR42,R43,v11,arbace.core5,firstV2,R44,R45,v18,arbace.classes.env9,reflectedv18,arbace.classes.env10,load-classv17,arbace.classes.go9,go-build?v17,arbace.classes.go8,genericsv22,arbace.classes.analyze13,class-tparamsv11,arbace.core3,seqv11,arbace.core6,every?R46,R47,R48,R49,v20,arbace.classes.types10,parse-typev22,arbace.classes.analyze10,type-scopev20,arbace.classes.types5,erasev22,arbace.classes.analyze5,erasev22,arbace.classes.analyze10,parse-typev11,arbace.core4,somev22,arbace.classes.analyze11,class-scopeR50,v11,arbace.core7,keywordv13,arbace.string10,lower-caseR51,v11,arbace.core3,strv11,arbace.core4,subsR52,v18,arbace.classes.env5,info!v20,arbace.classes.types6,array?R53,v22,arbace.classes.analyze9,ann-valuev20,arbace.classes.types9,elem-typev11,arbace.core7,vector?v11,arbace.core4,seq?R54,v11,arbace.core6,secondR55,v11,arbace.core4,intov11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv22,arbace.classes.analyze12,element-typev11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,restv11,arbace.core4,map?R56,R57,v11,arbace.core10,re-matchesp5,[0-9]v18,arbace.classes.env10,interface?v22,arbace.classes.analyze9,type-descv20,arbace.classes.types11,class-desc?v20,arbace.classes.types11,string-descv20,arbace.classes.types14,desc->internali16384,v22,arbace.classes.analyze18,analyze-const-formR58,v22,arbace.classes.analyze15,annotations-nowR59,v11,arbace.core3,vecv11,arbace.core6,filterv22,arbace.classes.analyze18,annotation-targetsv11,arbace.core5,forceR60,R61,v20,arbace.classes.types12,element-pathv20,arbace.classes.types9,type-annsv11,arbace.core11,map-indexedv11,arbace.core4,nextv11,arbace.core8,to-arrayR62,v17,arbace.classes.go25,newTypeParameterReferencev17,arbace.classes.go20,CLASS_TYPE_PARAMETERv17,arbace.classes.go21,METHOD_TYPE_PARAMETERv11,arbace.core4,compv11,arbace.core3,keyv22,arbace.classes.analyze16,type-annotationsv17,arbace.classes.go30,newTypeParameterBoundReferencev17,arbace.classes.go26,CLASS_TYPE_PARAMETER_BOUNDv17,arbace.classes.go27,METHOD_TYPE_PARAMETER_BOUNDv22,arbace.classes.analyze9,retentionR63,R64,R65,v11,arbace.core5,true?V2,R44,R66,v11,arbace.core5,some?R67,v11,arbace.core4,fnilR68,v22,arbace.classes.analyze8,top-nameR69,R70,S2,R71,R54,R72,v11,arbace.core5,mergeR73,R74,R75,v11,arbace.core4,atomR76,R77,R78,R79,R80,v11,arbace.core5,doallR81,v20,arbace.classes.parse11,parse-classR82,v22,arbace.classes.analyze14,declare-class!R83,R84,v11,arbace.core6,repeatv22,arbace.classes.analyze12,update-decl!S2,R27,R28,R85,v22,arbace.classes.analyze15,bounds-of-scopeV2,R44,R45,v22,arbace.classes.analyze15,set-own-bounds!v11,arbace.core6,zipmapv20,arbace.classes.types17,parse-type-paramsV2,R44,R45,v20,arbace.classes.types10,bounds-mapV2,R44,R86,V2,R44,R87,R88,R89,v20,arbace.classes.types8,generic?v20,arbace.classes.types21,type-params-signaturev20,arbace.classes.types9,signatureR71,R90,R91,R92,R93,R94,R95,R96,V2,R44,R96,R97,v22,arbace.classes.analyze16,decl-annotationsR98,v22,arbace.classes.analyze23,tparam-type-annotationsS2,R71,R54,v17,arbace.classes.go21,newSuperTypeReferencel-1,i16,R99,S2,s20,java.lang.Deprecateds10,Deprecatedi131072,S2,R71,R54,R100,v22,arbace.classes.analyze6,tag-ofR101,R102,R103,v11,arbace.core8,distinctv18,arbace.classes.env14,all-supertypesS2,s6,<init>s8,<clinit>R104,S2,s6,<init>s8,<clinit>v11,arbace.core4,valsv11,arbace.core6,reducev20,arbace.classes.types4,ref?v18,arbace.classes.env11,assignable?v11,arbace.core9,array-mapv22,arbace.classes.analyze22,clojure-implementablesR105,R106,R107,R108,R109,R110,R111,v22,arbace.classes.analyze21,clojure-overrideablesv20,arbace.classes.types11,object-descv20,arbace.classes.types11,class->descv11,arbace.core7,string?v20,arbace.classes.types15,prim-desc->namev20,arbace.classes.types16,desc->class-namev22,arbace.classes.analyze16,clojure-tag-descv22,arbace.classes.analyze13,class-name-ofv11,arbace.core6,empty?v17,arbace.classes.go16,newTypeReferencev17,arbace.classes.go13,METHOD_RETURNv17,arbace.classes.go15,METHOD_RECEIVERv17,arbace.classes.go27,newFormalParameterReferencev17,arbace.classes.go21,newExceptionReferenceR112,v22,arbace.classes.analyze12,method-scopeV2,R44,R45,R113,v11,arbace.core8,not-any?v22,arbace.classes.analyze11,iface-kind?R114,v22,arbace.classes.analyze16,clojure-overridev22,arbace.classes.analyze15,infer-signaturev20,arbace.classes.types11,desc->tnodev22,arbace.classes.analyze10,param-infov20,arbace.classes.types5,prim?R115,R101,V2,R44,R109,v20,arbace.classes.parse8,flags-ofv22,arbace.classes.analyze11,method-modsR116,R117,R118,R119,v22,arbace.classes.analyze15,deprecated-flagR120,R121,R122,v22,arbace.classes.analyze16,method-signatureR123,v22,arbace.classes.analyze23,method-type-annotationsV2,R44,R118,R124,v11,arbace.core9,contains?R44,R125,R126,v11,arbace.core4,lastR127,V2,R44,R45,V2,R44,R109,S4,R116,R128,R129,R130,m4,R46,R115,R22,s1,Vm4,R46,R115,R22,s1,VR131,R132,R101,v22,arbace.classes.analyze10,field-modsR133,v17,arbace.classes.go5,FIELDR134,R135,R136,R137,R138,R139,v22,arbace.classes.analyze11,enter-fieldv22,arbace.classes.analyze12,enter-methodv22,arbace.classes.analyze10,enter-ctorv22,arbace.classes.analyze11,annotationsR140,R141,v20,arbace.classes.types8,array-ofR142,S1,R143,R144,R101,v11,arbace.core6,removeS1,R143,v22,arbace.classes.analyze10,for-targetR145,v22,arbace.classes.analyze14,derived-methodi1,R146,R147,V3,V2,s8,toStrings20,()Ljava/lang/String;V2,s8,hashCodes3,()IV2,s6,equalss21,(Ljava/lang/Object;)ZR148,v22,arbace.classes.analyze12,class-accessR149,R150,R151,R152,v22,arbace.classes.analyze16,resolve-members!R153,R154,R155,V1,V2,s4,namei32768,R156,i2,R157,R158,R159,v11,arbace.core5,char?v11,arbace.core8,integer?v11,arbace.core2,<=l65535,R160,R161,v22,arbace.classes.analyze8,wideningv20,arbace.classes.types6,box-ofR162,R163,v22,arbace.classes.analyze10,value-typeR164,v22,arbace.classes.analyze7,widens?R165,S4,s1,Ss1,Cs1,Bs1,IS4,s1,Ss1,Cs1,Bs1,Iv22,arbace.classes.analyze5,fits?R166,S4,s1,Ss1,Cs1,Bs1,Iv22,arbace.classes.analyze17,literal-tail-valsv22,arbace.classes.analyze10,boxed-descR167,v20,arbace.classes.types8,unbox-ofR168,v22,arbace.classes.analyze5,unifyv18,arbace.classes.env3,lubR169,v22,arbace.classes.analyze13,literal-tail?R170,R171,R172,m2,R160,R164,R173,R174,R175,R176,R177,R178,v11,arbace.core6,mapcatS4,s1,Ss1,Cs1,Bs1,Iv22,arbace.classes.analyze12,convert-nodeS4,s1,Ss1,Cs1,Bs1,IS3,s1,Ss1,Cs1,BR179,v22,arbace.classes.analyze7,next-idR180,R181,R182,R183,R184,R185,v11,arbace.core8,assoc-inR186,v22,arbace.classes.analyze8,scope-ofv22,arbace.classes.analyze5,stateR187,R188,R189,v22,arbace.classes.analyze15,outer-this-nodeR28,R190,R191,R192,v22,arbace.classes.analyze12,add-capture!v11,arbace.core10,take-whilev11,arbace.core7,iterateR193,v22,arbace.classes.analyze9,local-refR194,R195,v22,arbace.classes.analyze16,outer-this-node*R196,v11,arbace.core6,reset!R197,R198,v22,arbace.classes.analyze18,class-parent-framev11,arbace.core4,var?R15,v11,arbace.core10,ns-resolvev22,arbace.classes.analyze11,resolve-varv22,arbace.classes.analyze9,core-var?v22,arbace.classes.analyze16,clojure-specialsv22,arbace.classes.analyze15,arbace-specialsR199,R200,v11,arbace.core7,ex-datav11,arbace.core10,ex-messagev22,arbace.classes.analyze14,with-form-infov22,arbace.classes.analyze14,analyze-symbolv22,arbace.classes.analyze10,analyze-opv22,arbace.classes.analyze10,const-nodev11,arbace.core8,boolean?v11,arbace.core8,keyword?v22,arbace.classes.analyze12,clj-constantv22,arbace.classes.analyze14,clj-collectionv20,arbace.classes.types9,lang-descv11,arbace.core8,identityv11,arbace.core4,set?R201,v22,arbace.classes.analyze11,accessorizev22,arbace.classes.analyze11,coerce-hintv22,arbace.classes.analyze9,actx-descR202,R203,S2,R161,R164,v22,arbace.classes.analyze15,branching-tail?R204,R205,v22,arbace.classes.analyze7,analyzev11,arbace.core7,butlastR206,v22,arbace.classes.analyze12,static-flag?v18,arbace.classes.env11,const-valueR207,R208,R209,R210,R211,v22,arbace.classes.analyze13,field-indexesR212,v22,arbace.classes.analyze11,field-indexR213,v22,arbace.classes.analyze14,find-own-fieldv22,arbace.classes.analyze10,field-nodev18,arbace.classes.env9,subclass?R214,V3,R69,R50,R215,V3,R69,R50,R215,v22,arbace.classes.analyze13,resolve-classp5,[1-9]v22,arbace.classes.analyze9,class-litv18,arbace.classes.env10,find-fieldv20,arbace.classes.types10,prim-namesv11,arbace.core7,re-findp2,\\.R216,R217,v22,arbace.classes.analyze13,clj-var-fieldR218,v18,arbace.classes.env11,accessible?R219,R220,R221,v22,arbace.classes.analyze7,unboxedv22,arbace.classes.analyze9,prim-typev22,arbace.classes.analyze11,clone-tail?R222,v22,arbace.classes.analyze12,retype-cloneR223,R224,R225,v22,arbace.classes.analyze10,conversionS9,R177,R169,R170,R226,R224,R227,R178,R175,R172,v11,arbace.core6,pr-strv22,arbace.classes.analyze13,const-of-typeR226,v22,arbace.classes.analyze11,unify-nodesR228,R227,S4,s1,Js1,Fs1,Is1,Dv20,arbace.classes.types10,lang-classR229,v22,arbace.classes.analyze7,operandR230,v22,arbace.classes.analyze4,fmodR231,R232,R233,R234,R235,R236,R237,R238,R239,R240,R241,R242,R243,R244,R245,v22,arbace.classes.analyze9,arith-opsS4,R235,R239,R238,R232,R246,S2,R233,R237,l1,v20,arbace.classes.types8,numeric?S3,R236,R242,R244,S2,s1,Fs1,DR247,R248,R249,S2,s1,Fs1,Dv22,arbace.classes.analyze10,fold-arithR250,R251,R252,S5,s1,Js1,Ss1,Cs1,Bs1,IS5,s1,Js1,Ss1,Cs1,Bs1,IS1,s1,DR253,v20,arbace.classes.types9,int-like?S2,R230,R234,v11,arbace.core6,dissocm14,s1,Is3,ints1,Js4,longs1,Ss5,shorts1,Bs4,bytes1,Cs4,chars1,Fs5,floats1,Ds6,doublev22,arbace.classes.analyze12,compare-typeR254,R255,S4,s10,method-refs7,lambda*s11,method-ref*s6,lambdav22,arbace.classes.analyze12,lambda-form?R256,v22,arbace.classes.analyze12,binding-typev22,arbace.classes.analyze9,bind-initv22,arbace.classes.analyze12,make-bindingR257,R258,v22,arbace.classes.analyze15,local-type-annsv22,arbace.classes.analyze10,with-localv11,arbace.core9,partitionR259,R260,R261,R262,R263,v22,arbace.classes.analyze12,analyze-bodyv11,arbace.core5,even?S3,s4,anons8,letclasss6,class*v11,arbace.core8,tree-seqv11,arbace.core5,coll?v22,arbace.classes.analyze13,class-def-in?R264,v22,arbace.classes.analyze14,literal-branchR265,S2,R266,R267,v22,arbace.classes.analyze12,macroexpand1R268,v22,arbace.classes.analyze14,expand-to-loopR269,R270,R271,R272,R273,R274,v22,arbace.classes.analyze14,code-type-annsR275,R276,R277,R278,R279,v11,arbace.core4,listR280,R281,R282,R283,v22,arbace.classes.analyze10,super-nodev22,arbace.classes.analyze20,analyze-field-accessR280,p2,^-v22,arbace.classes.analyze12,analyze-set!R284,R285,S4,R167,R165,R168,R164,S2,R165,R164,S4,R167,R165,R168,R164,R286,v22,arbace.classes.analyze15,clj-fi-excludedR287,S3,s8,toStrings8,hashCodes6,equalsR288,v22,arbace.classes.analyze8,find-samS3,s8,toStrings8,hashCodes6,equalsR289,v22,arbace.classes.analyze13,clj-fi-methodv22,arbace.classes.analyze13,clj-prim-argsv11,arbace.core6,vectorv22,arbace.classes.analyze13,clj-arg-classm2,R290,Tv22,arbace.classes.analyze20,clj-param-arg-match?v22,arbace.classes.analyze13,clj-subsumes?v22,arbace.classes.analyze19,clj-ret-assignable?v13,arbace.string4,joinm2,R290,Tm2,R290,Tm2,R291,s14,no such methodv22,arbace.classes.analyze18,clj-matching-indexv22,arbace.classes.analyze15,clj-type-stringR291,R292,v22,arbace.classes.analyze17,param-tags-match?i128,v22,arbace.classes.analyze14,more-specific?v22,arbace.classes.analyze11,applicable?v22,arbace.classes.analyze14,expand-varargsv18,arbace.classes.env14,member-methodsv18,arbace.classes.env12,constructorsm12,s1,Js8,longCasts1,Ds10,doubleCasts1,Is7,intCasts1,Fs9,floatCasts1,Ss9,shortCasts1,Bs8,byteCastS2,R161,R164,S4,s1,Js1,Ss1,Bs1,IS2,s1,Fs1,Dm12,s1,Js1,Ls1,Ds1,Ds1,Is1,Is1,Ss1,Ss1,Bs1,Bs1,Fs1,FR293,R294,R295,R296,R297,S2,s1,Zs1,Cv22,arbace.classes.analyze15,clj-arg-convertv11,arbace.core4,takeR298,R299,v11,arbace.core4,dropi4096,v22,arbace.classes.analyze16,qualifying-ownerR300,R301,v22,arbace.classes.analyze12,convert-argsS2,s29,java/lang/invoke/MethodHandles26,java/lang/invoke/VarHandlei256,S2,R212,R302,R303,R302,v11,arbace.core20,*warn-on-reflection*v11,arbace.core7,printlnv11,arbace.core6,*file*v11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core5,*out*v11,arbace.core5,*err*v22,arbace.classes.analyze15,reflective-nodev22,arbace.classes.analyze7,objectsv22,arbace.classes.analyze18,reflection-warningR290,p114,^(No accessible|No matching|Ambiguous call|No field|No static field|Field not accessible|Method call|Field access)v22,arbace.classes.analyze8,reflect?v22,arbace.classes.analyze11,unresolved?R304,R305,R306,R307,v22,arbace.classes.analyze19,analyze-method-callR308,v22,arbace.classes.analyze13,type-arg-annsv22,arbace.classes.analyze10,or-reflectv22,arbace.classes.analyze20,analyze-method-call*R309,v22,arbace.classes.analyze15,reflective-callv22,arbace.classes.analyze19,instance-candidatesv22,arbace.classes.analyze22,signature-polymorphic?v22,arbace.classes.analyze10,clj-selectR310,v22,arbace.classes.analyze13,select-methodv22,arbace.classes.analyze11,invoke-nodev22,arbace.classes.analyze17,static-candidatesR311,v22,arbace.classes.analyze21,analyze-field-access*R312,R313,v22,arbace.classes.analyze9,this-nodev11,arbace.core12,keep-indexedv22,arbace.classes.analyze12,analyze-dot*R314,v22,arbace.classes.analyze21,needs-outer-instance?v22,arbace.classes.analyze14,ctor-call-nodeR315,R283,v22,arbace.classes.analyze16,outer-super-callv22,arbace.classes.analyze14,receiver-classv22,arbace.classes.analyze19,analyze-static-callv22,arbace.classes.analyze15,ctor-candidatesR316,v20,arbace.classes.types10,array-dimsR317,R318,v22,arbace.classes.analyze11,int-operandS2,R27,R28,R319,v11,arbace.core9,with-metap5,[1-9]R319,v22,arbace.classes.analyze18,outer-instance-forv22,arbace.classes.analyze9,array-newv11,arbace.core7,reverseR320,R321,R322,R323,R143,R324,v22,arbace.classes.analyze18,analyze-conversionv11,arbace.core5,list*R280,v13,arbace.string10,ends-with?S2,s6,super.s5,this.R325,R325,R280,R326,R327,S2,R161,R164,v22,arbace.classes.analyze16,with-node-localsm14,s1,Js8,longCasts1,Ds10,doubleCasts1,Is7,intCasts1,Fs9,floatCasts1,Ss9,shortCasts1,Bs8,byteCasts1,Cs8,charCastv11,arbace.core10,repeatedlyv11,arbace.core6,gensymS2,R161,R164,R328,R329,v22,arbace.classes.analyze15,var-invoke-nodev22,arbace.classes.analyze13,clj-call-nodev22,arbace.classes.analyze11,specializedv22,arbace.classes.analyze13,analyze-arithv22,arbace.classes.analyze11,conversionsv22,arbace.classes.analyze19,checked-conversionsv22,arbace.classes.analyze11,comparisonsv22,arbace.classes.analyze15,analyze-compareS3,s4,neg?s4,pos?s5,zero?m6,s5,zero?s2,==s4,pos?s1,>s4,neg?s1,<R330,R331,R332,S2,s5,some?s4,nil?R333,R334,v22,arbace.classes.analyze17,analyze-instance?v22,arbace.classes.analyze12,analyze-castS3,s4,agets7,alengths4,asetv22,arbace.classes.analyze12,analyze-asetv22,arbace.classes.analyze12,analyze-agetv22,arbace.classes.analyze15,analyze-lockingv22,arbace.classes.analyze15,analyze-fn-callR280,v22,arbace.classes.analyze11,analyze-dotR266,v22,arbace.classes.analyze16,analyze-for-eachR335,v22,arbace.classes.analyze14,analyze-switchR336,v22,arbace.classes.analyze22,analyze-with-resourcesR337,v22,arbace.classes.analyze19,analyze-clj-specialv22,arbace.classes.analyze7,core-opv22,arbace.classes.analyze12,core-op-nodev22,arbace.classes.analyze12,method-sugarR283,R283,R338,R339,R340,v22,arbace.classes.analyze16,analyze-java-strR341,R342,v22,arbace.classes.analyze11,analyze-tryR343,v22,arbace.classes.analyze17,analyze-ctor-callR344,v22,arbace.classes.analyze13,analyze-labelR284,R345,v22,arbace.classes.analyze13,analyze-breakR346,R347,R348,R349,v22,arbace.classes.analyze14,analyze-lambdaR350,v22,arbace.classes.analyze13,analyze-throwR351,R352,v22,arbace.classes.analyze16,analyze-letclassv22,arbace.classes.analyze12,analyze-anonR353,v22,arbace.classes.analyze13,analyze-recurR354,v22,arbace.classes.analyze19,analyze-java-assertR355,v22,arbace.classes.analyze10,analyze-ifR326,R356,v11,arbace.core7,number?R357,v22,arbace.classes.analyze18,analyze-method-refR358,R359,v22,arbace.classes.analyze11,analyze-letR360,R361,R325,v22,arbace.classes.analyze11,analyze-newR267,R282,R362,R363,v22,arbace.classes.analyze14,analyze-returnR364,v22,arbace.classes.analyze19,analyze-if-instanceR365,R366,R365,R282,R341,v20,arbace.classes.lower10,lower-caseS4,s1,Js1,Ss1,Bs1,IR339,v20,arbace.classes.lower11,lower-reifyv11,arbace.core4,*ns*R362,v20,arbace.classes.lower8,lower-fnR351,v20,arbace.classes.lower11,lower-letfnv22,arbace.classes.analyze12,expand-fullyR337,R280,R367,R368,R369,R280,R370,R371,R372,R361,v11,arbace.core6,internv20,arbace.classes.lower9,lower-defR361,v11,arbace.core5,nnextR373,R374,v22,arbace.classes.analyze18,non-constant-headsv22,arbace.classes.analyze16,may-be-constant?v22,arbace.classes.analyze9,new-frameR375,S2,R165,R166,R376,v22,arbace.classes.analyze13,creation-actxS2,R27,R28,R377,R378,R379,R380,v22,arbace.classes.analyze9,body-actxv22,arbace.classes.analyze11,bind-paramsV2,R69,R173,v22,arbace.classes.analyze11,clj-convertS3,R343,R381,R346,v22,arbace.classes.analyze15,ctor-call-form?S2,s3,lets4,let*v22,arbace.classes.analyze17,nested-ctor-call?R382,m6,R47,s6,<init>R22,s22,(Ljava/lang/String;I)VR104,s14,java/lang/EnumR383,S2,R27,R28,v22,arbace.classes.analyze18,analyze-ctor-call*V2,R185,R132,V2,R185,R193,V2,R50,R192,V2,R69,R173,R384,R385,R386,R387,R388,v22,arbace.classes.analyze19,implicit-super-callV2,R185,R193,v22,arbace.classes.analyze17,analyze-enum-bodyR389,R390,R391,R392,v11,arbace.core4,keepR393,R394,R395,v22,arbace.classes.analyze22,analyze-enum-constantsS3,R159,R149,R158,S3,R159,R149,R158,v22,arbace.classes.analyze19,analyze-method-bodyv22,arbace.classes.analyze14,analyze-class!R396,v22,arbace.classes.analyze17,analyze-ctor-bodyV2,R185,R132,R397,V2,R185,R132,R398,R399,v11,arbace.core4,nil?v20,arbace.classes.types14,reflect->tnodev20,arbace.classes.types5,substv22,arbace.classes.analyze14,class-genericsR400,R401,v22,arbace.classes.analyze15,clojure-bridgesv22,arbace.classes.analyze14,supertype-envsv18,arbace.classes.env16,superclass-chainv11,arbace.core7,memoizev22,arbace.classes.analyze13,erased-paramsR402,i1024,v11,arbace.core6,bit-orv11,arbace.core6,subvecR403,v22,arbace.classes.analyze16,supertypes-firstv22,arbace.classes.analyze15,resolve-header!v22,arbace.classes.analyze12,add-bridges!v22,arbace.classes.analyze19,mark-enum-abstract!v22,arbace.classes.analyze16,local-class-nameR404,v11,arbace.core11,select-keysV1,R377,v22,arbace.classes.analyze9,prologue?R405,v22,arbace.classes.analyze16,process-classes!R406,R407,R404,v20,arbace.classes.parse11,class-flagsv22,arbace.classes.analyze19,sharpest-accessiblev22,arbace.classes.analyze17,accessible-class?R408,R409,v22,arbace.classes.analyze12,const-stringR410,R411,R412,R413,v22,arbace.classes.analyze20,analyze-java-assert*R414,R415,R416,S2,R71,R54,v22,arbace.classes.analyze9,nest-hostR417,S2,R71,R54,R418,R419,R420,R421,R422,R423,R424,R425,R426,R427,R428,R429,R430,R336,R336,R280,R431,R338,R355,R432,R342,R280,R431,R272,R433,R280,R434,R342,R280,R431,R272,R433,R280,R434,R350,R435,V1,s19,java/lang/Throwablev22,arbace.classes.analyze14,object-methodsR436,R437,S1,s20,java/io/Serializablev22,arbace.classes.analyze20,lambda-method-prefixv11,arbace.core9,update-inR438,R439,v22,arbace.classes.analyze8,fi-typesR440,v22,arbace.classes.analyze12,lambda-name!v22,arbace.classes.analyze19,serial-lambda-name!R441,R442,R443,R444,R445,R446,R447,R448,R349,R449,R450,R283,R349,R280,v22,arbace.classes.analyze8,arg-stubv22,arbace.classes.analyze13,ref-as-lambdaR325,R280,R451,v22,arbace.classes.analyze9,ref-ownerR452,R280,R453,R280,R286,R454,v22,arbace.classes.analyze15,analyze-patternR455,R456,R457,R458,R459,v22,arbace.classes.analyze12,prim-type-ofv11,arbace.core4,odd?v22,arbace.classes.analyze11,enum-class?S4,s1,Ss1,Cs1,Bs1,IR460,R461,R462,m2,R161,Tm2,R118,TS4,s16,Ljava/lang/Byte;s21,Ljava/lang/Character;s17,Ljava/lang/Short;s19,Ljava/lang/Integer;v22,arbace.classes.analyze14,constant-labelR463,m2,R161,Tm2,R118,TS4,s16,Ljava/lang/Byte;s21,Ljava/lang/Character;s17,Ljava/lang/Short;s19,Ljava/lang/Integer;m2,R161,Tm2,R118,TS4,s16,Ljava/lang/Byte;s21,Ljava/lang/Character;s17,Ljava/lang/Short;s19,Ljava/lang/Integer;m2,R161,Tm2,R118,TS4,s16,Ljava/lang/Byte;s21,Ljava/lang/Character;s17,Ljava/lang/Short;s19,Ljava/lang/Integer;v22,arbace.classes.analyze11,switch-map!R464,R465,R466,R467,R468,R469,v11,arbace.core4,readm4,R470,R469,R471,R472,v11,arbace.core11,*read-eval*R356,v22,arbace.classes.analyze15,import-classes!R473,R15,v11,arbace.core4,evalv11,arbace.core9,create-nsp2,\\$R474,C21,java.lang.ClassLoaderv22,arbace.classes.analyze17,read-source-formsS3,R475,R476,R477,R338,v20,arbace.classes.parse13,split-optionsR66,S5,R478,R475,R476,R477,R479,S5,R478,R475,R476,R477,R479,v22,arbace.classes.analyze13,eval-ns-form!R338,m2,R31,R68,m2,R31,R68,R480,v11,arbace.core3,modl10,R481,i4,v22,arbace.classes.analyze14,accessor-ownerS2,R278,R279,v22,arbace.classes.analyze13,add-accessor!R482,R483,R484,R485,R486,R487,R488,S2,R278,R279,S2,R278,R279,S2,R278,R279,R489,R490,R491,v22,arbace.classes.analyze15,constant-field!R492,R493,v11,arbace.core12,*print-meta*")

var Lit_1 *jrt.String = jrt.Intern("access$")

var Lit_2 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001637")

var Lit_3 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$members__1549001640")

var Lit_4 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$present_QMARK___1549001642")

var Lit_5 *jrt.String = jrt.Intern("<init>")

var Lit_6 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001671")

var Lit_7 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001678")

var Lit_8 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001680")

var Lit_9 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001687")

var Lit_10 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001692")

var Lit_11 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001699")

var Lit_12 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001701")

var Lit_13 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001708")

var Lit_14 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001722")

var Lit_15 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001726")

var Lit_16 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001728")

var Lit_17 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001733")

var Lit_18 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001735")

var Lit_19 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001739")

var Lit_20 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001741")

var Lit_21 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001746")

var Lit_22 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001748")

var Lit_23 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001752")

var Lit_24 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001754")

var Lit_25 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001759")

var Lit_26 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001761")

var Lit_27 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001765")

var Lit_28 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001767")

var Lit_29 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001772")

var Lit_30 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001671$fn__1549001672")

var Lit_31 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001680$fn__1549001681")

var Lit_32 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001692$fn__1549001693")

var Lit_33 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001701$fn__1549001702")

var Lit_34 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001722$fn__1549001723")

var Lit_35 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001735$fn__1549001736")

var Lit_36 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001748$fn__1549001749")

var Lit_37 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001761$fn__1549001762")

var Lit_38 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$present_QMARK___1549001642$fn__1549001653")

var Lit_39 *jrt.String = jrt.Intern("arbace.classes.analyze$add_capture_BANG_$fn__1549000619")

var Lit_40 *jrt.String = jrt.Intern("arbace.classes.analyze$add_capture_BANG_$fn__1549000623")

var Lit_41 *jrt.String = jrt.Intern("arbace.classes.analyze$add_capture_BANG_$fn__1549000619$fn__1549000620")

var Lit_42 *jrt.String = jrt.Intern("arbace.classes.analyze$add_capture_BANG_$fn__1549000623$fn__1549000624")

var Lit_43 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze$fn__1549000646")

var Lit_44 *jrt.String = jrt.Intern("Empty list in class body")

var Lit_45 *jrt.String = jrt.Intern("Z")

var Lit_46 *jrt.String = jrt.Intern("C")

var Lit_47 *jrt.String = jrt.Intern("J")

var Lit_48 *jrt.String = jrt.Intern("I")

var Lit_49 *jrt.String = jrt.Intern("D")

var Lit_50 *jrt.String = jrt.Intern("F")

var Lit_51 *jrt.String = jrt.Intern("S")

var Lit_52 *jrt.String = jrt.Intern("B")

var Lit_53 *jrt.String = jrt.Intern("vector")

var Lit_54 *jrt.String = jrt.Intern("IPersistentVector")

var Lit_55 *jrt.String = jrt.Intern("map")

var Lit_56 *jrt.String = jrt.Intern("IPersistentMap")

var Lit_57 *jrt.String = jrt.Intern("set")

var Lit_58 *jrt.String = jrt.Intern("IPersistentSet")

var Lit_59 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_aget$fn__1549001215")

var Lit_60 *jrt.String = jrt.Intern("aget on a non-array of type ")

var Lit_61 *jrt.String = jrt.Intern("anon needs a vector of constructor arguments")

var Lit_62 *jrt.String = jrt.Intern("anon: :outer needs a value")

var Lit_63 *jrt.String = jrt.Intern("Bad anon supertype: ")

var Lit_64 *jrt.String = jrt.Intern("anon: :outer needs an instance of the superclass's outer class")

var Lit_65 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_anon$fn__1549001838")

var Lit_66 *jrt.String = jrt.Intern("An anonymous class of an interface takes no arguments")

var Lit_67 *jrt.String = jrt.Intern("anon: ")

var Lit_68 *jrt.String = jrt.Intern(" is not an inner class, :outer is not allowed")

var Lit_69 *jrt.String = jrt.Intern("/")

var Lit_70 *jrt.String = jrt.Intern(".")

var Lit_71 *jrt.String = jrt.Intern("constructor of ")

var Lit_72 *jrt.String = jrt.Intern("()V")

var Lit_73 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_anon$fn__1549001840")

var Lit_74 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_anon$fn__1549001846")

var Lit_75 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_anon$fn__1549001840$fn__1549001841")

var Lit_76 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_anon$fn__1549001840$fn__1549001841$fn__1549001842")

var Lit_77 *jrt.String = jrt.Intern(" takes ")

var Lit_78 *jrt.String = jrt.Intern(" operand(s) in class bodies")

var Lit_79 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_arith$fn__1549000723")

var Lit_80 *jrt.String = jrt.Intern(": operand of type ")

var Lit_81 *jrt.String = jrt.Intern(" is not integral")

var Lit_82 *jrt.String = jrt.Intern(": a double operand needs explicit narrowing")

var Lit_83 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_arith$fn__1549000735")

var Lit_84 *jrt.String = jrt.Intern(" needs explicit narrowing")

var Lit_85 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_arith$fn__1549000738")

var Lit_86 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_87 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_arith$fn__1549000740")

var Lit_88 *jrt.String = jrt.Intern(" on doubles is not Java arithmetic; use unchecked-divide/remainder")

var Lit_89 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_arith$fn__1549000742")

var Lit_90 *jrt.String = jrt.Intern("Operand of ")

var Lit_91 *jrt.String = jrt.Intern(" has non-primitive type ")

var Lit_92 *jrt.String = jrt.Intern(" (only primitives and their wrappers are arithmetic in class bodies)")

var Lit_93 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_aset$fn__1549001222")

var Lit_94 *jrt.String = jrt.Intern("aset on a non-array of type ")

var Lit_95 *jrt.String = jrt.Intern("array element")

var Lit_96 *jrt.String = jrt.Intern("aset on a non-array")

var Lit_97 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_body$fn__1549000654")

var Lit_98 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_body$fn__1549000656")

var Lit_99 *jrt.String = jrt.Intern("break: no label ")

var Lit_100 *jrt.String = jrt.Intern("break outside a loop")

var Lit_101 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_cast$fn__1549001255")

var Lit_102 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_class_BANG_$fn__1549001515")

var Lit_103 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_class_BANG_$fn__1549001517")

var Lit_104 *jrt.String = jrt.Intern("initializer of field ")

var Lit_105 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_class_BANG_$fn__1549001525")

var Lit_106 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_class_BANG_$fn__1549001529")

var Lit_107 *jrt.String = jrt.Intern("V")

var Lit_108 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_clj_special$fn__1549001401")

var Lit_109 *jrt.String = jrt.Intern("Unable to resolve var: ")

var Lit_110 *jrt.String = jrt.Intern(" in this context")

var Lit_111 *jrt.String = jrt.Intern("Var")

var Lit_112 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_clj_special$fn__1549001403")

var Lit_113 *jrt.String = jrt.Intern("First argument to def must be a Symbol")

var Lit_114 *jrt.String = jrt.Intern("Can't create defs outside of current ns")

var Lit_115 *jrt.String = jrt.Intern(" takes 2 operands in class bodies")

var Lit_116 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_compare$fn__1549000761")

var Lit_117 *jrt.String = jrt.Intern(" is not a number")

var Lit_118 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_compare$lit_int_QMARK___1549000767")

var Lit_119 *jrt.String = jrt.Intern("<")

var Lit_120 *jrt.String = jrt.Intern(">")

var Lit_121 *jrt.String = jrt.Intern("<=")

var Lit_122 *jrt.String = jrt.Intern("==")

var Lit_123 *jrt.String = jrt.Intern(">=")

var Lit_124 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_const_form$fn__1549001411")

var Lit_125 *jrt.String = jrt.Intern("Constant of type ")

var Lit_126 *jrt.String = jrt.Intern(" where ")

var Lit_127 *jrt.String = jrt.Intern(" is needed")

var Lit_128 *jrt.String = jrt.Intern("Literal out of range: ")

var Lit_129 *jrt.String = jrt.Intern("Cannot convert ")

var Lit_130 *jrt.String = jrt.Intern(" to ")

var Lit_131 *jrt.String = jrt.Intern("Narrowing ")

var Lit_132 *jrt.String = jrt.Intern(" needs unchecked-")

var Lit_133 *jrt.String = jrt.Intern("Cannot convert boolean to a number")

var Lit_134 *jrt.String = jrt.Intern("this$0")

var Lit_135 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_ctor_body$fn__1549001461")

var Lit_136 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_ctor_body$fn__1549001465")

var Lit_137 *jrt.String = jrt.Intern("Constructor call not reached")

var Lit_138 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_ctor_body$fn__1549001467")

var Lit_139 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_ctor_body$fn__1549001461$fn__1549001462")

var Lit_140 *jrt.String = jrt.Intern("A second constructor call")

var Lit_141 *jrt.String = jrt.Intern(" outside a constructor")

var Lit_142 *jrt.String = jrt.Intern("super.")

var Lit_143 *jrt.String = jrt.Intern("this.")

var Lit_144 *jrt.String = jrt.Intern("An enum constructor cannot call super.")

var Lit_145 *jrt.String = jrt.Intern("super")

var Lit_146 *jrt.String = jrt.Intern(".super outside a constructor")

var Lit_147 *jrt.String = jrt.Intern(" is not an inner class")

var Lit_148 *jrt.String = jrt.Intern("new")

var Lit_149 *jrt.String = jrt.Intern(".new needs an outer instance")

var Lit_150 *jrt.String = jrt.Intern("$")

var Lit_151 *jrt.String = jrt.Intern("Unknown class ")

var Lit_152 *jrt.String = jrt.Intern("-")

var Lit_153 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$fn__1549001475")

var Lit_154 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$iter__1549001477__1549001481")

var Lit_155 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$fn__1549001511")

var Lit_156 *jrt.String = jrt.Intern("$values")

var Lit_157 *jrt.String = jrt.Intern("()")

var Lit_158 *jrt.String = jrt.Intern("$VALUES")

var Lit_159 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$iter__1549001477__1549001481$fn__1549001482")

var Lit_160 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$iter__1549001477__1549001481$fn__1549001482$fn__1549001483")

var Lit_161 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$iter__1549001477__1549001481$fn__1549001482$fn__1549001503")

var Lit_162 *jrt.String = jrt.Intern("constructor of enum constant ")

var Lit_163 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$iter__1549001477__1549001481$fn__1549001482$fn__1549001505")

var Lit_164 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$iter__1549001477__1549001481$fn__1549001482$fn__1549001507")

var Lit_165 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$iter__1549001477__1549001481$fn__1549001482$fn__1549001483$fn__1549001490")

var Lit_166 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$iter__1549001477__1549001481$fn__1549001482$fn__1549001483$fn__1549001492")

var Lit_167 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$iter__1549001477__1549001481$fn__1549001482$fn__1549001483$fn__1549001494")

var Lit_168 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_field_access$fn__1549001145")

var Lit_169 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_field_access$fn__1549001147")

var Lit_170 *jrt.String = jrt.Intern("reference to field ")

var Lit_171 *jrt.String = jrt.Intern("getInstanceField")

var Lit_172 *jrt.String = jrt.Intern("(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;")

var Lit_173 *jrt.String = jrt.Intern("length")

var Lit_174 *jrt.String = jrt.Intern("Field access .")

var Lit_175 *jrt.String = jrt.Intern(" on a value of type ")

var Lit_176 *jrt.String = jrt.Intern("No field ")

var Lit_177 *jrt.String = jrt.Intern(" in ")

var Lit_178 *jrt.String = jrt.Intern("Field not accessible: ")

var Lit_179 *jrt.String = jrt.Intern("IFn")

var Lit_180 *jrt.String = jrt.Intern("Cannot call a value of type ")

var Lit_181 *jrt.String = jrt.Intern(" as a function")

var Lit_182 *jrt.String = jrt.Intern("Can't call nil")

var Lit_183 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_fn_call$fn__1549001395")

var Lit_184 *jrt.String = jrt.Intern("invoke")

var Lit_185 *jrt.String = jrt.Intern("IFn.invoke")

var Lit_186 *jrt.String = jrt.Intern("for-each needs a binding vector [x coll]")

var Lit_187 *jrt.String = jrt.Intern("Ljava/lang/Iterable;")

var Lit_188 *jrt.String = jrt.Intern("for-each over a value of type ")

var Lit_189 *jrt.String = jrt.Intern(", neither an array nor Iterable")

var Lit_190 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_for_each$aux__1549001912")

var Lit_191 *jrt.String = jrt.Intern("arr$")

var Lit_192 *jrt.String = jrt.Intern("len$")

var Lit_193 *jrt.String = jrt.Intern("i$")

var Lit_194 *jrt.String = jrt.Intern("Ljava/util/Iterator;")

var Lit_195 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_for_each$fn__1549001914")

var Lit_196 *jrt.String = jrt.Intern("iterator")

var Lit_197 *jrt.String = jrt.Intern("java/util/Iterator")

var Lit_198 *jrt.String = jrt.Intern("next")

var Lit_199 *jrt.String = jrt.Intern("()Ljava/lang/Object;")

var Lit_200 *jrt.String = jrt.Intern("for-each element")

var Lit_201 *jrt.String = jrt.Intern("Too many arguments to if")

var Lit_202 *jrt.String = jrt.Intern("if-instance needs [pattern expr]")

var Lit_203 *jrt.String = jrt.Intern("if-instance of a primitive")

var Lit_204 *jrt.String = jrt.Intern("inst$")

var Lit_205 *jrt.String = jrt.Intern("instance? needs a class")

var Lit_206 *jrt.String = jrt.Intern("instance? of a primitive")

var Lit_207 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_assert_STAR_$fn__1549001900")

var Lit_208 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_str$fn__1549001871")

var Lit_209 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_str$fn__1549001873")

var Lit_210 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_str$fn__1549001875")

var Lit_211 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_str$fn__1549001877")

var Lit_212 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_str$iter__1549001879__1549001883")

var Lit_213 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_str$iter__1549001879__1549001883$fn__1549001884")

var Lit_214 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_str$iter__1549001879__1549001883$fn__1549001884$fn__1549001885")

var Lit_215 *jrt.String = jrt.Intern("")

var Lit_216 *jrt.String = jrt.Intern("\x01")

var Lit_217 *jrt.String = jrt.Intern("\x02")

var Lit_218 *jrt.String = jrt.Intern("java-str of a void expression")

var Lit_219 *jrt.String = jrt.Intern("label needs a keyword")

var Lit_220 *jrt.String = jrt.Intern("lambda needs a parameter vector")

var Lit_221 *jrt.String = jrt.Intern("lambda for ")

var Lit_222 *jrt.String = jrt.Intern(" needs ")

var Lit_223 *jrt.String = jrt.Intern(" parameters")

var Lit_224 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_lambda$fn__1549001973")

var Lit_225 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_lambda$fn__1549001978")

var Lit_226 *jrt.String = jrt.Intern("lambda value")

var Lit_227 *jrt.String = jrt.Intern("let/loop needs a vector of bindings")

var Lit_228 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_let$fn__1549000819")

var Lit_229 *jrt.String = jrt.Intern("Bad binding: ")

var Lit_230 *jrt.String = jrt.Intern("^:const local needs a constant initializer: ")

var Lit_231 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_letclass$fn__1549001853")

var Lit_232 *jrt.String = jrt.Intern("locking needs a reference")

var Lit_233 *jrt.String = jrt.Intern("value of method ")

var Lit_234 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_call$fn__1549001102")

var Lit_235 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_call$fn__1549001104")

var Lit_236 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_call$fn__1549001106")

var Lit_237 *jrt.String = jrt.Intern("Method call .")

var Lit_238 *jrt.String = jrt.Intern(" on nil")

var Lit_239 *jrt.String = jrt.Intern("java/lang/Object")

var Lit_240 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_call_STAR_$fn__1549001117")

var Lit_241 *jrt.String = jrt.Intern("clone")

var Lit_242 *jrt.String = jrt.Intern("No accessible method ")

var Lit_243 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_call_STAR_$fn__1549001119")

var Lit_244 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_call_STAR_$fn__1549001121")

var Lit_245 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_call_STAR_$fn__1549001123")

var Lit_246 *jrt.String = jrt.Intern("method ")

var Lit_247 *jrt.String = jrt.Intern("method-ref takes FI, an optional signature, an optional receiver and a method")

var Lit_248 *jrt.String = jrt.Intern("Bad method in method-ref: ")

var Lit_249 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002015")

var Lit_250 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$register__1549002019")

var Lit_251 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002021")

var Lit_252 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002026")

var Lit_253 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002028")

var Lit_254 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002033")

var Lit_255 *jrt.String = jrt.Intern("rec$")

var Lit_256 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002035")

var Lit_257 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002040")

var Lit_258 *jrt.String = jrt.Intern("An unbound method reference needs the receiver as first parameter")

var Lit_259 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002043")

var Lit_260 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002051")

var Lit_261 *jrt.String = jrt.Intern("static method ")

var Lit_262 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002053")

var Lit_263 *jrt.String = jrt.Intern("a$")

var Lit_264 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_new$anns__1549001198")

var Lit_265 *jrt.String = jrt.Intern("Unable to resolve class: ")

var Lit_266 *jrt.String = jrt.Intern("Cannot instantiate abstract class ")

var Lit_267 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_new$fn__1549001204")

var Lit_268 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_new$fn__1549001206")

var Lit_269 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_new$fn__1549001208")

var Lit_270 *jrt.String = jrt.Intern("call to ")

var Lit_271 *jrt.String = jrt.Intern(" ctor")

var Lit_272 *jrt.String = jrt.Intern("invokeConstructor")

var Lit_273 *jrt.String = jrt.Intern("(Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;")

var Lit_274 *jrt.String = jrt.Intern(" is not supported in code compiled by the Java forms compiler")

var Lit_275 *jrt.String = jrt.Intern(" (class bodies, and fns using the Java forms; use locking)")

var Lit_276 *jrt.String = jrt.Intern("class* ")

var Lit_277 *jrt.String = jrt.Intern(" is not an expression")

var Lit_278 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_op$fn__1549001383")

var Lit_279 *jrt.String = jrt.Intern("A type pattern needs a type: ")

var Lit_280 *jrt.String = jrt.Intern("_")

var Lit_281 *jrt.String = jrt.Intern("Primitive pattern of type ")

var Lit_282 *jrt.String = jrt.Intern(" for a value of type ")

var Lit_283 *jrt.String = jrt.Intern(" is not supported")

var Lit_284 *jrt.String = jrt.Intern("Unknown record ")

var Lit_285 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_pattern$fn__1549002063")

var Lit_286 *jrt.String = jrt.Intern(" is not a record")

var Lit_287 *jrt.String = jrt.Intern("Record pattern ")

var Lit_288 *jrt.String = jrt.Intern(" component patterns")

var Lit_289 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_pattern$fn__1549002077")

var Lit_290 *jrt.String = jrt.Intern("Bad pattern: ")

var Lit_291 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_pattern$fn__1549002063$iter__1549002064__1549002068")

var Lit_292 *jrt.String = jrt.Intern("getRecordComponents")

var Lit_293 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_pattern$fn__1549002063$iter__1549002064__1549002068$fn__1549002069")

var Lit_294 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_pattern$fn__1549002063$iter__1549002064__1549002068$fn__1549002069$fn__1549002070")

var Lit_295 *jrt.String = jrt.Intern("java.lang.reflect.RecordComponent")

var Lit_296 *jrt.String = jrt.Intern("getName")

var Lit_297 *jrt.String = jrt.Intern("getType")

var Lit_298 *jrt.String = jrt.Intern("continue: no label ")

var Lit_299 *jrt.String = jrt.Intern("continue: label ")

var Lit_300 *jrt.String = jrt.Intern(" is not a loop")

var Lit_301 *jrt.String = jrt.Intern("recur/continue outside a loop")

var Lit_302 *jrt.String = jrt.Intern("Mismatched argument count to recur/continue, expected: ")

var Lit_303 *jrt.String = jrt.Intern(" args, got: ")

var Lit_304 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_recur$fn__1549000838")

var Lit_305 *jrt.String = jrt.Intern("recur argument")

var Lit_306 *jrt.String = jrt.Intern("return outside a method")

var Lit_307 *jrt.String = jrt.Intern("return value")

var Lit_308 *jrt.String = jrt.Intern("Cannot assign captured local ")

var Lit_309 *jrt.String = jrt.Intern("Cannot assign immutable local ")

var Lit_310 *jrt.String = jrt.Intern(" (use ^:mutable)")

var Lit_311 *jrt.String = jrt.Intern("value for ")

var Lit_312 *jrt.String = jrt.Intern("Unknown class in set!: ")

var Lit_313 *jrt.String = jrt.Intern("No static field ")

var Lit_314 *jrt.String = jrt.Intern(".-")

var Lit_315 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_set_BANG_$fn__1549000920")

var Lit_316 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_set_BANG_$fn__1549000925")

var Lit_317 *jrt.String = jrt.Intern("Bad set! target: ")

var Lit_318 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_static_call$fn__1549001133")

var Lit_319 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_static_call$fn__1549001135")

var Lit_320 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_static_call$fn__1549001142")

var Lit_321 *jrt.String = jrt.Intern("No accessible static method ")

var Lit_322 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_static_call$fn__1549001135$fn__1549001139")

var Lit_323 *jrt.String = jrt.Intern("call to static method ")

var Lit_324 *jrt.String = jrt.Intern(" on ")

var Lit_325 *jrt.String = jrt.Intern("invokeStaticMethod")

var Lit_326 *jrt.String = jrt.Intern("(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;")

var Lit_327 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$fn__1549002117")

var Lit_328 *jrt.String = jrt.Intern("RT")

var Lit_329 *jrt.String = jrt.Intern("intCast")

var Lit_330 *jrt.String = jrt.Intern("(J)I")

var Lit_331 *jrt.String = jrt.Intern("(Ljava/lang/Object;)I")

var Lit_332 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$null_label_QMARK___1549002119")

var Lit_333 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$fn__1549002122")

var Lit_334 *jrt.String = jrt.Intern("switch on a value of type ")

var Lit_335 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$enum_name__1549002127")

var Lit_336 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$iter__1549002129__1549002133")

var Lit_337 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$fn__1549002197")

var Lit_338 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$fn__1549002199")

var Lit_339 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$fn__1549002201")

var Lit_340 *jrt.String = jrt.Intern("sel$")

var Lit_341 *jrt.String = jrt.Intern("restart$")

var Lit_342 *jrt.String = jrt.Intern("Enum switch label must be a constant name: ")

var Lit_343 *jrt.String = jrt.Intern("No enum constant ")

var Lit_344 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$iter__1549002129__1549002133$fn__1549002134")

var Lit_345 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$iter__1549002129__1549002133$fn__1549002134$fn__1549002135")

var Lit_346 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$iter__1549002129__1549002133$fn__1549002134$iter__1549002171__1549002175")

var Lit_347 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$iter__1549002129__1549002133$fn__1549002134$fn__1549002135$iter__1549002147__1549002151")

var Lit_348 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$iter__1549002129__1549002133$fn__1549002134$fn__1549002135$iter__1549002147__1549002151$fn__1549002152")

var Lit_349 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$iter__1549002129__1549002133$fn__1549002134$fn__1549002135$iter__1549002147__1549002151$fn__1549002152$fn__1549002153")

var Lit_350 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$iter__1549002129__1549002133$fn__1549002134$iter__1549002171__1549002175$fn__1549002176")

var Lit_351 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$iter__1549002129__1549002133$fn__1549002134$iter__1549002171__1549002175$fn__1549002176$fn__1549002177")

var Lit_352 *jrt.String = jrt.Intern("this")

var Lit_353 *jrt.String = jrt.Intern("A primitive type is no value: ")

var Lit_354 *jrt.String = jrt.Intern(" (use Integer/TYPE)")

var Lit_355 *jrt.String = jrt.Intern("Unable to resolve symbol: ")

var Lit_356 *jrt.String = jrt.Intern("Ljava/lang/Throwable;")

var Lit_357 *jrt.String = jrt.Intern("throw of a non-Throwable: ")

var Lit_358 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$catch_QMARK___1549000875")

var Lit_359 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$fin_QMARK___1549000877")

var Lit_360 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$fn__1549000879")

var Lit_361 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$iter__1549000881__1549000885")

var Lit_362 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$fn__1549000905")

var Lit_363 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$iter__1549000881__1549000885$fn__1549000886")

var Lit_364 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$iter__1549000881__1549000885$fn__1549000886$fn__1549000887")

var Lit_365 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$iter__1549000881__1549000885$fn__1549000886$fn__1549000899")

var Lit_366 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$iter__1549000881__1549000885$fn__1549000886$fn__1549000901")

var Lit_367 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$iter__1549000881__1549000885$fn__1549000886$fn__1549000887$fn__1549000891")

var Lit_368 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$iter__1549000881__1549000885$fn__1549000886$fn__1549000887$fn__1549000893")

var Lit_369 *jrt.String = jrt.Intern("Unknown class: ")

var Lit_370 *jrt.String = jrt.Intern("with-resources needs a vector of resource bindings")

var Lit_371 *jrt.String = jrt.Intern("t$")

var Lit_372 *jrt.String = jrt.Intern("x$")

var Lit_373 *jrt.String = jrt.Intern("arbace.classes.analyze$ann_value$fn__1549000077")

var Lit_374 *jrt.String = jrt.Intern("Unknown annotation: ")

var Lit_375 *jrt.String = jrt.Intern("arbace.classes.analyze$ann_value$iter__1549000079__1549000083")

var Lit_376 *jrt.String = jrt.Intern("Ljava/lang/Class;")

var Lit_377 *jrt.String = jrt.Intern("arbace.classes.analyze$ann_value$iter__1549000079__1549000083$fn__1549000084")

var Lit_378 *jrt.String = jrt.Intern("arbace.classes.analyze$ann_value$iter__1549000079__1549000083$fn__1549000084$fn__1549000085")

var Lit_379 *jrt.String = jrt.Intern("arbace.classes.analyze$annotation_targets$fn__1549000100")

var Lit_380 *jrt.String = jrt.Intern("arbace.classes.analyze$annotation_targets$fn__1549000105")

var Lit_381 *jrt.String = jrt.Intern("java/lang/annotation/Target")

var Lit_382 *jrt.String = jrt.Intern("getAnnotation")

var Lit_383 *jrt.String = jrt.Intern("java.lang.annotation.Target")

var Lit_384 *jrt.String = jrt.Intern("value")

var Lit_385 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations$fn__1549000096")

var Lit_386 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations_now$iter__1549000172__1549000176")

var Lit_387 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations_now$iter__1549000172__1549000176$fn__1549000177")

var Lit_388 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations_now$iter__1549000172__1549000176$fn__1549000177$fn__1549000178")

var Lit_389 *jrt.String = jrt.Intern("Unknown annotation type: ")

var Lit_390 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations_now$iter__1549000172__1549000176$fn__1549000177$iter__1549000202__1549000206")

var Lit_391 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations_now$iter__1549000172__1549000176$fn__1549000177$fn__1549000178$iter__1549000182__1549000186")

var Lit_392 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations_now$iter__1549000172__1549000176$fn__1549000177$fn__1549000178$iter__1549000182__1549000186$fn__1549000187")

var Lit_393 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations_now$iter__1549000172__1549000176$fn__1549000177$fn__1549000178$iter__1549000182__1549000186$fn__1549000187$fn__1549000188")

var Lit_394 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations_now$iter__1549000172__1549000176$fn__1549000177$iter__1549000202__1549000206$fn__1549000207")

var Lit_395 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations_now$iter__1549000172__1549000176$fn__1549000177$iter__1549000202__1549000206$fn__1549000207$fn__1549000208")

var Lit_396 *jrt.String = jrt.Intern("arbace.classes.analyze$applicable_QMARK_$fn__1549000928")

var Lit_397 *jrt.String = jrt.Intern("arbace.classes.analyze$array_new$init__1549001184")

var Lit_398 *jrt.String = jrt.Intern("Bad dimensions for new ")

var Lit_399 *jrt.String = jrt.Intern("arbace.classes.analyze$array_new$fn__1549001188")

var Lit_400 *jrt.String = jrt.Intern("arbace.classes.analyze$array_new$init__1549001184$fn__1549001185")

var Lit_401 *jrt.String = jrt.Intern("arbace.classes.analyze$bind_init$fn__1549000807")

var Lit_402 *jrt.String = jrt.Intern("initializer of ")

var Lit_403 *jrt.String = jrt.Intern("arbace.classes.analyze$bind_params$fn__1549001432")

var Lit_404 *jrt.String = jrt.Intern("arbace.classes.analyze$body_actx$fn__1549001420")

var Lit_405 *jrt.String = jrt.Intern("arbace.classes.analyze$body_actx$fn__1549001422")

var Lit_406 *jrt.String = jrt.Intern("arbace.classes.analyze$body_actx$fn__1549001425")

var Lit_407 *jrt.String = jrt.Intern("arbace.classes.analyze$body_actx$fn__1549001427")

var Lit_408 *jrt.String = jrt.Intern("arbace.classes.analyze$class_def_in_QMARK_$fn__1549000830")

var Lit_409 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$iter__1549001545__1549001549")

var Lit_410 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001559")

var Lit_411 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001559$fn__1549001560")

var Lit_412 *jrt.String = jrt.Intern("getTypeParameters")

var Lit_413 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001559$iter__1549001563__1549001567")

var Lit_414 *jrt.String = jrt.Intern("java.lang.reflect.TypeVariable")

var Lit_415 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001559$iter__1549001563__1549001567$fn__1549001568")

var Lit_416 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001559$iter__1549001563__1549001567$fn__1549001568$fn__1549001569")

var Lit_417 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001559$iter__1549001563__1549001567$fn__1549001568$fn__1549001583")

var Lit_418 *jrt.String = jrt.Intern("getGenericParameterTypes")

var Lit_419 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001559$iter__1549001563__1549001567$fn__1549001568$iter__1549001585__1549001589")

var Lit_420 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001559$iter__1549001563__1549001567$fn__1549001568$fn__1549001569$fn__1549001570")

var Lit_421 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001559$iter__1549001563__1549001567$fn__1549001568$fn__1549001569$iter__1549001572__1549001576")

var Lit_422 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001559$iter__1549001563__1549001567$fn__1549001568$fn__1549001569$iter__1549001572__1549001576$fn__1549001577")

var Lit_423 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001559$iter__1549001563__1549001567$fn__1549001568$fn__1549001569$iter__1549001572__1549001576$fn__1549001577$fn__1549001578")

var Lit_424 *jrt.String = jrt.Intern("getBounds")

var Lit_425 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001559$iter__1549001563__1549001567$fn__1549001568$iter__1549001585__1549001589$fn__1549001590")

var Lit_426 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001559$iter__1549001563__1549001567$fn__1549001568$iter__1549001585__1549001589$fn__1549001590$fn__1549001591")

var Lit_427 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$iter__1549001545__1549001549$fn__1549001550")

var Lit_428 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$iter__1549001545__1549001549$fn__1549001550$fn__1549001551")

var Lit_429 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$iter__1549001545__1549001549$fn__1549001550$fn__1549001555")

var Lit_430 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$iter__1549001545__1549001549$fn__1549001550$fn__1549001551$fn__1549001552")

var Lit_431 *jrt.String = jrt.Intern("arbace.classes.analyze$class_tparams$fn__1549000049")

var Lit_432 *jrt.String = jrt.Intern("arbace.classes.analyze$class_tparams$fn__1549000051")

var Lit_433 *jrt.String = jrt.Intern("arbace.classes.analyze$class_tparams$fn__1549000051$fn__1549000052")

var Lit_434 *jrt.String = jrt.Intern("argument")

var Lit_435 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_arg_convert$ip__1549001057")

var Lit_436 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_arg_convert$code__1549001059")

var Lit_437 *jrt.String = jrt.Intern("(")

var Lit_438 *jrt.String = jrt.Intern(")")

var Lit_439 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_arg_convert$fn__1549001061")

var Lit_440 *jrt.String = jrt.Intern("FnInvokers")

var Lit_441 *jrt.String = jrt.Intern("No method ")

var Lit_442 *jrt.String = jrt.Intern(" in FnInvokers")

var Lit_443 *jrt.String = jrt.Intern("(Ljava/lang/Object;)")

var Lit_444 *jrt.String = jrt.Intern("O")

var Lit_445 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_call_node$fn__1549001291")

var Lit_446 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_collection$fn__1549002347")

var Lit_447 *jrt.String = jrt.Intern("([Ljava/lang/Object;)")

var Lit_448 *jrt.String = jrt.Intern("[Ljava/lang/Object;")

var Lit_449 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_collection$fn__1549002349")

var Lit_450 *jrt.String = jrt.Intern("Keyword")

var Lit_451 *jrt.String = jrt.Intern("Symbol")

var Lit_452 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_constant$fn__1549002341")

var Lit_453 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_convert$fn__1549001268")

var Lit_454 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_fi_method$fn__1549000943")

var Lit_455 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_fi_method$fn__1549000947")

var Lit_456 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_fi_method$fn__1549000949")

var Lit_457 *jrt.String = jrt.Intern("java.lang.FunctionalInterface")

var Lit_458 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_fi_method$fn__1549000943$fn__1549000944")

var Lit_459 *jrt.String = jrt.Intern("Ljava/lang/FunctionalInterface;")

var Lit_460 *jrt.String = jrt.Intern("More than one matching method found: ")

var Lit_461 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_matching_index$fn__1549000981")

var Lit_462 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_select$pdescs__1549000991")

var Lit_463 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_select$fn__1549000993")

var Lit_464 *jrt.String = jrt.Intern("interface ")

var Lit_465 *jrt.String = jrt.Intern("class ")

var Lit_466 *jrt.String = jrt.Intern("No matching ctor found for ")

var Lit_467 *jrt.String = jrt.Intern("No matching method ")

var Lit_468 *jrt.String = jrt.Intern(" found taking ")

var Lit_469 *jrt.String = jrt.Intern(" args for ")

var Lit_470 *jrt.String = jrt.Intern(" of ")

var Lit_471 *jrt.String = jrt.Intern(" args")

var Lit_472 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_select$fn__1549000997")

var Lit_473 *jrt.String = jrt.Intern("No matching ")

var Lit_474 *jrt.String = jrt.Intern(" for argument types ")

var Lit_475 *jrt.String = jrt.Intern("constructor")

var Lit_476 *jrt.String = jrt.Intern("argument types: ")

var Lit_477 *jrt.String = jrt.Intern(", ")

var Lit_478 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_type_string$fn__1549000985")

var Lit_479 *jrt.String = jrt.Intern("unknown")

var Lit_480 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000305__1549000311")

var Lit_481 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000305__1549000311$fn__1549000312")

var Lit_482 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000305__1549000311$fn__1549000312$iter__1549000307__1549000316")

var Lit_483 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000305__1549000311$fn__1549000312$iter__1549000326__1549000330")

var Lit_484 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000305__1549000311$fn__1549000312$iter__1549000307__1549000316$fn__1549000317")

var Lit_485 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000305__1549000311$fn__1549000312$iter__1549000307__1549000316$fn__1549000317$fn__1549000318")

var Lit_486 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000305__1549000311$fn__1549000312$iter__1549000307__1549000316$fn__1549000317$fn__1549000322")

var Lit_487 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000305__1549000311$fn__1549000312$iter__1549000307__1549000316$fn__1549000317$fn__1549000318$fn__1549000319")

var Lit_488 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000305__1549000311$fn__1549000312$iter__1549000326__1549000330$fn__1549000331")

var Lit_489 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000305__1549000311$fn__1549000312$iter__1549000326__1549000330$fn__1549000331$fn__1549000332")

var Lit_490 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_implementables$iter__1549000282__1549000288")

var Lit_491 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_implementables$iter__1549000282__1549000288$fn__1549000289")

var Lit_492 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_implementables$iter__1549000282__1549000288$fn__1549000289$iter__1549000284__1549000290")

var Lit_493 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_implementables$iter__1549000282__1549000288$fn__1549000289$iter__1549000284__1549000290$fn__1549000291")

var Lit_494 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_implementables$iter__1549000282__1549000288$fn__1549000289$iter__1549000284__1549000290$fn__1549000291$fn__1549000292")

var Lit_495 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_override$fn__1549000349")

var Lit_496 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_override$fn__1549000351")

var Lit_497 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_override$exact__1549000353")

var Lit_498 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_override$check_ret__1549000357")

var Lit_499 *jrt.String = jrt.Intern("Can't define method not in interfaces: ")

var Lit_500 *jrt.String = jrt.Intern("Must hint overloaded method: ")

var Lit_501 *jrt.String = jrt.Intern("Can't find matching overloaded method: ")

var Lit_502 *jrt.String = jrt.Intern("Can't find matching method: ")

var Lit_503 *jrt.String = jrt.Intern(", leave off hints for auto match.")

var Lit_504 *jrt.String = jrt.Intern("Mismatched return type: ")

var Lit_505 *jrt.String = jrt.Intern(", expected: ")

var Lit_506 *jrt.String = jrt.Intern(", had: ")

var Lit_507 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_override$exact__1549000353$fn__1549000354")

var Lit_508 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_overrideables$fn__1549000299")

var Lit_509 *jrt.String = jrt.Intern("[")

var Lit_510 *jrt.String = jrt.Intern("arbace.classes.analyze$code_type_anns$iter__1549001225__1549001231")

var Lit_511 *jrt.String = jrt.Intern("arbace.classes.analyze$code_type_anns$iter__1549001225__1549001231$fn__1549001232")

var Lit_512 *jrt.String = jrt.Intern("arbace.classes.analyze$code_type_anns$iter__1549001225__1549001231$fn__1549001232$iter__1549001227__1549001236")

var Lit_513 *jrt.String = jrt.Intern("arbace.classes.analyze$code_type_anns$iter__1549001225__1549001231$fn__1549001232$iter__1549001227__1549001236$fn__1549001237")

var Lit_514 *jrt.String = jrt.Intern("arbace.classes.analyze$code_type_anns$iter__1549001225__1549001231$fn__1549001232$iter__1549001227__1549001236$fn__1549001237$fn__1549001238")

var Lit_515 *jrt.String = jrt.Intern("arbace.classes.analyze$coerce_hint$fn__1549000649")

var Lit_516 *jrt.String = jrt.Intern("null")

var Lit_517 *jrt.String = jrt.Intern("const__")

var Lit_518 *jrt.String = jrt.Intern("arbace.classes.analyze$constant_field_BANG_$fn__1549002338")

var Lit_519 *jrt.String = jrt.Intern("switch label is not a constant: ")

var Lit_520 *jrt.String = jrt.Intern("arbace.classes.analyze$conversion$fn__1549000578")

var Lit_521 *jrt.String = jrt.Intern("arbace.classes.analyze$convert_args$fn__1549001072")

var Lit_522 *jrt.String = jrt.Intern("arbace.classes.analyze$convert_args$fn__1549001074")

var Lit_523 *jrt.String = jrt.Intern("arbace.classes.analyze$convert_args$fn__1549001076")

var Lit_524 *jrt.String = jrt.Intern("arbace.classes.analyze$convert_node$fn__1549000686")

var Lit_525 *jrt.String = jrt.Intern(" of type ")

var Lit_526 *jrt.String = jrt.Intern("arbace.classes.analyze$convert_node$fn__1549000692")

var Lit_527 *jrt.String = jrt.Intern("switch without default has no value of type ")

var Lit_528 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$call__1549001311")

var Lit_529 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001313")

var Lit_530 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001315")

var Lit_531 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001317")

var Lit_532 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001319")

var Lit_533 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001321")

var Lit_534 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001323")

var Lit_535 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001325")

var Lit_536 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001327")

var Lit_537 *jrt.String = jrt.Intern("=")

var Lit_538 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001332")

var Lit_539 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001334")

var Lit_540 *jrt.String = jrt.Intern("not=")

var Lit_541 *jrt.String = jrt.Intern("not")

var Lit_542 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001336")

var Lit_543 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001338")

var Lit_544 *jrt.String = jrt.Intern("nil?")

var Lit_545 *jrt.String = jrt.Intern("identical?")

var Lit_546 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001340")

var Lit_547 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001342")

var Lit_548 *jrt.String = jrt.Intern("instance?")

var Lit_549 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001347")

var Lit_550 *jrt.String = jrt.Intern("cast")

var Lit_551 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001352")

var Lit_552 *jrt.String = jrt.Intern("aset")

var Lit_553 *jrt.String = jrt.Intern("aget")

var Lit_554 *jrt.String = jrt.Intern("alength")

var Lit_555 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001355")

var Lit_556 *jrt.String = jrt.Intern("and")

var Lit_557 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001357")

var Lit_558 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001359")

var Lit_559 *jrt.String = jrt.Intern("or")

var Lit_560 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001361")

var Lit_561 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001363")

var Lit_562 *jrt.String = jrt.Intern("locking")

var Lit_563 *jrt.String = jrt.Intern("boolean")

var Lit_564 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001365")

var Lit_565 *jrt.String = jrt.Intern("arbace.classes.analyze$ctor_call_node$fn__1549001178")

var Lit_566 *jrt.String = jrt.Intern("No accessible constructor of ")

var Lit_567 *jrt.String = jrt.Intern("arbace.classes.analyze$ctor_candidates$fn__1549001053")

var Lit_568 *jrt.String = jrt.Intern("Not in the compilation: ")

var Lit_569 *jrt.String = jrt.Intern("arbace.classes.analyze$decl_annotations$fn__1549000115")

var Lit_570 *jrt.String = jrt.Intern("arbace.classes.analyze$decl_annotations$fn__1549000115$fn__1549000116")

var Lit_571 *jrt.String = jrt.Intern("ANNOTATION_TYPE")

var Lit_572 *jrt.String = jrt.Intern("TYPE")

var Lit_573 *jrt.String = jrt.Intern("Class defined twice in one form: ")

var Lit_574 *jrt.String = jrt.Intern("arbace.classes.analyze$declare_class_BANG_$fn__1549000227")

var Lit_575 *jrt.String = jrt.Intern("arbace.classes.analyze$declare_class_BANG_$fn__1549000229")

var Lit_576 *jrt.String = jrt.Intern("arbace.classes.analyze$deprecated_flag$fn__1549000253")

var Lit_577 *jrt.String = jrt.Intern("arbace.classes.analyze$derived_method$fn__1549000443")

var Lit_578 *jrt.String = jrt.Intern("arbace.classes.analyze$element_type$fn__1549000073")

var Lit_579 *jrt.String = jrt.Intern("A constructor needs a receiver parameter")

var Lit_580 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_ctor$fn__1549000426")

var Lit_581 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_ctor$fn__1549000428")

var Lit_582 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_ctor$fn__1549000431")

var Lit_583 *jrt.String = jrt.Intern("CONSTRUCTOR")

var Lit_584 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_ctor$fn__1549000433")

var Lit_585 *jrt.String = jrt.Intern("PARAMETER")

var Lit_586 *jrt.String = jrt.Intern("FIELD")

var Lit_587 *jrt.String = jrt.Intern("getValue")

var Lit_588 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_field$fn__1549000437")

var Lit_589 *jrt.String = jrt.Intern("getResource")

var Lit_590 *jrt.String = jrt.Intern("_class.ae")

var Lit_591 *jrt.String = jrt.Intern(".ae")

var Lit_592 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$fn__1549002238")

var Lit_593 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$iter__1549002240__1549002246")

var Lit_594 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$fn__1549002257")

var Lit_595 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$fn__1549002263")

var Lit_596 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$iter__1549002269__1549002275")

var Lit_597 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$iter__1549002285__1549002289")

var Lit_598 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$iter__1549002240__1549002246$fn__1549002247")

var Lit_599 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$iter__1549002240__1549002246$fn__1549002247$iter__1549002242__1549002248")

var Lit_600 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$iter__1549002240__1549002246$fn__1549002247$iter__1549002242__1549002248$fn__1549002249")

var Lit_601 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$iter__1549002240__1549002246$fn__1549002247$iter__1549002242__1549002248$fn__1549002249$fn__1549002250")

var Lit_602 *jrt.String = jrt.Intern("defclass")

var Lit_603 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$iter__1549002269__1549002275$fn__1549002276")

var Lit_604 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$iter__1549002269__1549002275$fn__1549002276$iter__1549002271__1549002277")

var Lit_605 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$iter__1549002269__1549002275$fn__1549002276$iter__1549002271__1549002277$fn__1549002278")

var Lit_606 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$iter__1549002269__1549002275$fn__1549002276$iter__1549002271__1549002277$fn__1549002278$fn__1549002279")

var Lit_607 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$iter__1549002285__1549002289$fn__1549002290")

var Lit_608 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$iter__1549002285__1549002289$fn__1549002290$fn__1549002291")

var Lit_609 *jrt.String = jrt.Intern("Instance method ")

var Lit_610 *jrt.String = jrt.Intern(" needs a receiver parameter")

var Lit_611 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_method$fn__1549000395")

var Lit_612 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_method$fn__1549000400")

var Lit_613 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_method$fn__1549000402")

var Lit_614 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_method$fn__1549000404")

var Lit_615 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_method$fn__1549000406")

var Lit_616 *jrt.String = jrt.Intern("Variable arity parameter must be an array: ")

var Lit_617 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_method$fn__1549000410")

var Lit_618 *jrt.String = jrt.Intern("METHOD")

var Lit_619 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_method$fn__1549000412")

var Lit_620 *jrt.String = jrt.Intern("arbace.classes.analyze$erased_params$fn__1549001629")

var Lit_621 *jrt.String = jrt.Intern("import")

var Lit_622 *jrt.String = jrt.Intern("in-ns")

var Lit_623 *jrt.String = jrt.Intern("arbace.classes.analyze$fi_types$fn__1549001944")

var Lit_624 *jrt.String = jrt.Intern("Ljava/io/Serializable;")

var Lit_625 *jrt.String = jrt.Intern(" is not an interface")

var Lit_626 *jrt.String = jrt.Intern("arbace.classes.analyze$find_sam$iter__1549001926__1549001932")

var Lit_627 *jrt.String = jrt.Intern(" is not a functional interface (abstract methods: ")

var Lit_628 *jrt.String = jrt.Intern("arbace.classes.analyze$find_sam$iter__1549001926__1549001932$fn__1549001933")

var Lit_629 *jrt.String = jrt.Intern("arbace.classes.analyze$find_sam$iter__1549001926__1549001932$fn__1549001933$iter__1549001928__1549001934")

var Lit_630 *jrt.String = jrt.Intern("arbace.classes.analyze$find_sam$iter__1549001926__1549001932$fn__1549001933$iter__1549001928__1549001934$fn__1549001935")

var Lit_631 *jrt.String = jrt.Intern("arbace.classes.analyze$find_sam$iter__1549001926__1549001932$fn__1549001933$iter__1549001928__1549001934$fn__1549001935$fn__1549001936")

var Lit_632 *jrt.String = jrt.Intern("arbace.classes.analyze$for_target$fn__1549000109")

var Lit_633 *jrt.String = jrt.Intern("arbace.classes.analyze$for_target$fn__1549000109$fn__1549000110")

var Lit_634 *jrt.String = jrt.Intern("arbace.classes.analyze$implicit_outer$fn__1549000056")

var Lit_635 *jrt.String = jrt.Intern("java/lang/Enum")

var Lit_636 *jrt.String = jrt.Intern("arbace.classes.analyze$import_classes_BANG_$iter__1549002212__1549002218")

var Lit_637 *jrt.String = jrt.Intern("arbace.classes.analyze$import_classes_BANG_$iter__1549002212__1549002218$fn__1549002219")

var Lit_638 *jrt.String = jrt.Intern("arbace.classes.analyze$import_classes_BANG_$iter__1549002212__1549002218$fn__1549002219$iter__1549002214__1549002220")

var Lit_639 *jrt.String = jrt.Intern("arbace.classes.analyze$import_classes_BANG_$iter__1549002212__1549002218$fn__1549002219$fn__1549002230")

var Lit_640 *jrt.String = jrt.Intern("arbace.classes.analyze$import_classes_BANG_$iter__1549002212__1549002218$fn__1549002219$iter__1549002214__1549002220$fn__1549002221")

var Lit_641 *jrt.String = jrt.Intern("arbace.classes.analyze$import_classes_BANG_$iter__1549002212__1549002218$fn__1549002219$iter__1549002214__1549002220$fn__1549002221$fn__1549002222")

var Lit_642 *jrt.String = jrt.Intern("arbace.classes.analyze$import_classes_BANG_$iter__1549002212__1549002218$fn__1549002219$iter__1549002214__1549002220$fn__1549002221$fn__1549002226")

var Lit_643 *jrt.String = jrt.Intern("arbace.classes.analyze$import_classes_BANG_$iter__1549002212__1549002218$fn__1549002219$iter__1549002214__1549002220$fn__1549002221$fn__1549002222$fn__1549002223")

var Lit_644 *jrt.String = jrt.Intern("arbace.classes.analyze$infer_signature$iter__1549000259__1549000265")

var Lit_645 *jrt.String = jrt.Intern("arbace.classes.analyze$infer_signature$iter__1549000259__1549000265$fn__1549000266")

var Lit_646 *jrt.String = jrt.Intern("arbace.classes.analyze$infer_signature$iter__1549000259__1549000265$fn__1549000266$iter__1549000261__1549000267")

var Lit_647 *jrt.String = jrt.Intern("arbace.classes.analyze$infer_signature$iter__1549000259__1549000265$fn__1549000266$iter__1549000261__1549000267$fn__1549000268")

var Lit_648 *jrt.String = jrt.Intern("arbace.classes.analyze$infer_signature$iter__1549000259__1549000265$fn__1549000266$iter__1549000261__1549000267$fn__1549000268$fn__1549000269")

var Lit_649 *jrt.String = jrt.Intern("arbace.classes.analyze$instance_candidates$fn__1549001045")

var Lit_650 *jrt.String = jrt.Intern("static")

var Lit_651 *jrt.String = jrt.Intern("<clinit>")

var Lit_652 *jrt.String = jrt.Intern("lambda$")

var Lit_653 *jrt.String = jrt.Intern("arbace.classes.analyze$literal_tail_QMARK_$fn__1549000585")

var Lit_654 *jrt.String = jrt.Intern("arbace.classes.analyze$literal_tail_QMARK_$fn__1549000587")

var Lit_655 *jrt.String = jrt.Intern("arbace.classes.analyze$literal_tail_vals$fn__1549000593")

var Lit_656 *jrt.String = jrt.Intern("arbace.classes.analyze$literal_tail_vals$fn__1549000595")

var Lit_657 *jrt.String = jrt.Intern("Cannot capture mutable local ")

var Lit_658 *jrt.String = jrt.Intern("Local out of scope: ")

var Lit_659 *jrt.String = jrt.Intern("arbace.classes.analyze$local_type_anns$iter__1549000776__1549000780")

var Lit_660 *jrt.String = jrt.Intern("arbace.classes.analyze$local_type_anns$iter__1549000786__1549000792")

var Lit_661 *jrt.String = jrt.Intern("arbace.classes.analyze$local_type_anns$iter__1549000776__1549000780$fn__1549000781")

var Lit_662 *jrt.String = jrt.Intern("arbace.classes.analyze$local_type_anns$iter__1549000776__1549000780$fn__1549000781$fn__1549000782")

var Lit_663 *jrt.String = jrt.Intern("TYPE_USE")

var Lit_664 *jrt.String = jrt.Intern("arbace.classes.analyze$local_type_anns$iter__1549000786__1549000792$fn__1549000793")

var Lit_665 *jrt.String = jrt.Intern("arbace.classes.analyze$local_type_anns$iter__1549000786__1549000792$fn__1549000793$iter__1549000788__1549000797")

var Lit_666 *jrt.String = jrt.Intern("arbace.classes.analyze$local_type_anns$iter__1549000786__1549000792$fn__1549000793$iter__1549000788__1549000797$fn__1549000798")

var Lit_667 *jrt.String = jrt.Intern("arbace.classes.analyze$local_type_anns$iter__1549000786__1549000792$fn__1549000793$iter__1549000788__1549000797$fn__1549000798$fn__1549000799")

var Lit_668 *jrt.String = jrt.Intern("arbace.classes.analyze$mark_enum_abstract_BANG_$pk__1549001789")

var Lit_669 *jrt.String = jrt.Intern("arbace.classes.analyze$mark_enum_abstract_BANG_$impl_QMARK___1549001791")

var Lit_670 *jrt.String = jrt.Intern("arbace.classes.analyze$mark_enum_abstract_BANG_$fn__1549001797")

var Lit_671 *jrt.String = jrt.Intern("arbace.classes.analyze$mark_enum_abstract_BANG_$fn__1549001801")

var Lit_672 *jrt.String = jrt.Intern("arbace.classes.analyze$mark_enum_abstract_BANG_$fn__1549001797$fn__1549001798")

var Lit_673 *jrt.String = jrt.Intern("arbace.classes.analyze$mark_enum_abstract_BANG_$impl_QMARK___1549001791$fn__1549001792")

var Lit_674 *jrt.String = jrt.Intern("arbace.classes.analyze$mark_enum_abstract_BANG_$impl_QMARK___1549001791$fn__1549001792$fn__1549001793")

var Lit_675 *jrt.String = jrt.Intern("arbace.classes.analyze$method_scope$fn__1549000361")

var Lit_676 *jrt.String = jrt.Intern("arbace.classes.analyze$method_signature$fn__1549000365")

var Lit_677 *jrt.String = jrt.Intern("^")

var Lit_678 *jrt.String = jrt.Intern("..")

var Lit_679 *jrt.String = jrt.Intern("arbace.classes.analyze$method_type_annotations$fn__1549000368")

var Lit_680 *jrt.String = jrt.Intern("arbace.classes.analyze$method_type_annotations$fn__1549000368$iter__1549000369__1549000373")

var Lit_681 *jrt.String = jrt.Intern("arbace.classes.analyze$method_type_annotations$fn__1549000368$fn__1549000379")

var Lit_682 *jrt.String = jrt.Intern("arbace.classes.analyze$method_type_annotations$fn__1549000368$fn__1549000381")

var Lit_683 *jrt.String = jrt.Intern("arbace.classes.analyze$method_type_annotations$fn__1549000368$iter__1549000369__1549000373$fn__1549000374")

var Lit_684 *jrt.String = jrt.Intern("arbace.classes.analyze$method_type_annotations$fn__1549000368$iter__1549000369__1549000373$fn__1549000374$fn__1549000375")

var Lit_685 *jrt.String = jrt.Intern("arbace.classes.analyze$more_specific_QMARK_$fn__1549000932")

var Lit_686 *jrt.String = jrt.Intern("do")

var Lit_687 *jrt.String = jrt.Intern("arbace.classes.analyze$not_yet$fn__1549001856")

var Lit_688 *jrt.String = jrt.Intern(" is not implemented yet")

var Lit_689 *jrt.String = jrt.Intern("arbace.classes.analyze$objects$fn__1549001089")

var Lit_690 *jrt.String = jrt.Intern("arbace.classes.analyze$operand$fn__1549000702")

var Lit_691 *jrt.String = jrt.Intern("Operand of type ")

var Lit_692 *jrt.String = jrt.Intern("No enclosing instance for ")

var Lit_693 *jrt.String = jrt.Intern("arbace.classes.analyze$outer_super_call$fn__1549002334")

var Lit_694 *jrt.String = jrt.Intern("arbace.classes.analyze$outer_this_node$fn__1549000630")

var Lit_695 *jrt.String = jrt.Intern("arbace.classes.analyze$outer_this_node$fn__1549000633")

var Lit_696 *jrt.String = jrt.Intern("No enclosing instance of type ")

var Lit_697 *jrt.String = jrt.Intern(" in scope")

var Lit_698 *jrt.String = jrt.Intern(" in a static context")

var Lit_699 *jrt.String = jrt.Intern("arbace.classes.analyze$param_tags_match_QMARK_$fn__1549000939")

var Lit_700 *jrt.String = jrt.Intern("UTF-8")

var Lit_701 *jrt.String = jrt.Intern("arbace.classes.analyze$read_source_forms$fn__1549002206")

var Lit_702 *jrt.String = jrt.Intern("arbace.classes.analyze$read_source_forms$fn__1549002208")

var Lit_703 *jrt.String = jrt.Intern("arbace.classes.analyze$ref_as_lambda$fn__1549001988")

var Lit_704 *jrt.String = jrt.Intern(" of a primitive")

var Lit_705 *jrt.String = jrt.Intern("NO_SOURCE_PATH")

var Lit_706 *jrt.String = jrt.Intern("call to method ")

var Lit_707 *jrt.String = jrt.Intern("invokeNoArgInstanceMember")

var Lit_708 *jrt.String = jrt.Intern("(Ljava/lang/Object;Ljava/lang/String;Z)Ljava/lang/Object;")

var Lit_709 *jrt.String = jrt.Intern("invokeInstanceMethod")

var Lit_710 *jrt.String = jrt.Intern("(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;")

var Lit_711 *jrt.String = jrt.Intern("Reflector")

var Lit_712 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_class_sym$fn__1549000037")

var Lit_713 *jrt.String = jrt.Intern("java/lang/")

var Lit_714 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_header_BANG_$fn__1549000240")

var Lit_715 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_header_BANG_$pt__1549000242")

var Lit_716 *jrt.String = jrt.Intern("java/lang/annotation/Annotation")

var Lit_717 *jrt.String = jrt.Intern("java/lang/Record")

var Lit_718 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_header_BANG_$fn__1549000245")

var Lit_719 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_header_BANG_$fn__1549000247")

var Lit_720 *jrt.String = jrt.Intern("Cannot extend final class ")

var Lit_721 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_header_BANG_$fn__1549000247$fn__1549000248")

var Lit_722 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000455__1549000459")

var Lit_723 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000465__1549000469")

var Lit_724 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000475__1549000479")

var Lit_725 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000485__1549000489")

var Lit_726 *jrt.String = jrt.Intern("values")

var Lit_727 *jrt.String = jrt.Intern("()[")

var Lit_728 *jrt.String = jrt.Intern("valueOf")

var Lit_729 *jrt.String = jrt.Intern("(Ljava/lang/String;)")

var Lit_730 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000495__1549000499")

var Lit_731 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000505__1549000509")

var Lit_732 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$declared_QMARK___1549000515")

var Lit_733 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000519__1549000523")

var Lit_734 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000531__1549000535")

var Lit_735 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$fn__1549000547")

var Lit_736 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$fn__1549000549")

var Lit_737 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$fn__1549000551")

var Lit_738 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$fn__1549000553")

var Lit_739 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$fn__1549000555")

var Lit_740 *jrt.String = jrt.Intern(")V")

var Lit_741 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$fn__1549000557")

var Lit_742 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$declared_QMARK___1549000515$fn__1549000516")

var Lit_743 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000455__1549000459$fn__1549000460")

var Lit_744 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000455__1549000459$fn__1549000460$fn__1549000461")

var Lit_745 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000465__1549000469$fn__1549000470")

var Lit_746 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000465__1549000469$fn__1549000470$fn__1549000471")

var Lit_747 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000475__1549000479$fn__1549000480")

var Lit_748 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000475__1549000479$fn__1549000480$fn__1549000481")

var Lit_749 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000485__1549000489$fn__1549000490")

var Lit_750 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000485__1549000489$fn__1549000490$fn__1549000491")

var Lit_751 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000495__1549000499$fn__1549000500")

var Lit_752 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000495__1549000499$fn__1549000500$fn__1549000501")

var Lit_753 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000505__1549000509$fn__1549000510")

var Lit_754 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000505__1549000509$fn__1549000510$fn__1549000511")

var Lit_755 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000519__1549000523$fn__1549000524")

var Lit_756 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000519__1549000523$fn__1549000524$fn__1549000525")

var Lit_757 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000531__1549000535$fn__1549000536")

var Lit_758 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000531__1549000535$fn__1549000536$fn__1549000537")

var Lit_759 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_var$fn__1549000640")

var Lit_760 *jrt.String = jrt.Intern("arbace.classes.analyze$retention$fn__1549000064")

var Lit_761 *jrt.String = jrt.Intern("arbace.classes.analyze$retention$fn__1549000069")

var Lit_762 *jrt.String = jrt.Intern("java/lang/annotation/Retention")

var Lit_763 *jrt.String = jrt.Intern("java.lang.annotation.Retention")

var Lit_764 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001011")

var Lit_765 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001015")

var Lit_766 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$pdescs__1549001017")

var Lit_767 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$varargs_QMARK___1549001019")

var Lit_768 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$pick__1549001021")

var Lit_769 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001027")

var Lit_770 *jrt.String = jrt.Intern("No method matches the param-tags of ")

var Lit_771 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001029")

var Lit_772 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001031")

var Lit_773 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001033")

var Lit_774 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001035")

var Lit_775 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001037")

var Lit_776 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001039")

var Lit_777 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001041")

var Lit_778 *jrt.String = jrt.Intern("; candidates: ")

var Lit_779 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001011$fn__1549001012")

var Lit_780 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$pick__1549001021$fn__1549001022")

var Lit_781 *jrt.String = jrt.Intern("Ambiguous call: ")

var Lit_782 *jrt.String = jrt.Intern(" ")

var Lit_783 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$pick__1549001021$fn__1549001022$fn__1549001023")

var Lit_784 *jrt.String = jrt.Intern(":")

var Lit_785 *jrt.String = jrt.Intern("arbace.classes.analyze$serial_lambda_name_BANG_$iter__1549001947__1549001951")

var Lit_786 *jrt.String = jrt.Intern("arbace.classes.analyze$serial_lambda_name_BANG_$iter__1549001947__1549001951$fn__1549001952")

var Lit_787 *jrt.String = jrt.Intern("arbace.classes.analyze$serial_lambda_name_BANG_$iter__1549001947__1549001951$fn__1549001952$fn__1549001953")

var Lit_788 *jrt.String = jrt.Intern(",")

var Lit_789 *jrt.String = jrt.Intern("arbace.classes.analyze$static_candidates$fn__1549001049")

var Lit_790 *jrt.String = jrt.Intern("super in a static context")

var Lit_791 *jrt.String = jrt.Intern("arbace.classes.analyze$supertype_envs$iter__1549001599__1549001603")

var Lit_792 *jrt.String = jrt.Intern("arbace.classes.analyze$supertype_envs$outer_env__1549001615")

var Lit_793 *jrt.String = jrt.Intern("arbace.classes.analyze$supertype_envs$iter__1549001617__1549001621")

var Lit_794 *jrt.String = jrt.Intern("arbace.classes.analyze$supertype_envs$iter__1549001599__1549001603$fn__1549001604")

var Lit_795 *jrt.String = jrt.Intern("arbace.classes.analyze$supertype_envs$iter__1549001599__1549001603$fn__1549001604$fn__1549001605")

var Lit_796 *jrt.String = jrt.Intern("arbace.classes.analyze$supertype_envs$iter__1549001617__1549001621$fn__1549001622")

var Lit_797 *jrt.String = jrt.Intern("arbace.classes.analyze$supertype_envs$iter__1549001617__1549001621$fn__1549001622$fn__1549001623")

var Lit_798 *jrt.String = jrt.Intern("arbace.classes.analyze$supertypes_first$visit__1549001775")

var Lit_799 *jrt.String = jrt.Intern("arbace.classes.analyze$switch_map_BANG_$fn__1549002101")

var Lit_800 *jrt.String = jrt.Intern("arbace.classes.analyze$switch_map_BANG_$fn__1549002103")

var Lit_801 *jrt.String = jrt.Intern("this$")

var Lit_802 *jrt.String = jrt.Intern("No this in a static context")

var Lit_803 *jrt.String = jrt.Intern("arbace.classes.analyze$tparam_type_annotations$fn__1549000152")

var Lit_804 *jrt.String = jrt.Intern("arbace.classes.analyze$tparam_type_annotations$fn__1549000152$fn__1549000154")

var Lit_805 *jrt.String = jrt.Intern("arbace.classes.analyze$tparam_type_annotations$fn__1549000152$fn__1549000154$iter__1549000157__1549000161")

var Lit_806 *jrt.String = jrt.Intern("arbace.classes.analyze$tparam_type_annotations$fn__1549000152$fn__1549000154$fn__1549000167")

var Lit_807 *jrt.String = jrt.Intern("arbace.classes.analyze$tparam_type_annotations$fn__1549000152$fn__1549000154$iter__1549000157__1549000161$fn__1549000162")

var Lit_808 *jrt.String = jrt.Intern("arbace.classes.analyze$tparam_type_annotations$fn__1549000152$fn__1549000154$iter__1549000157__1549000161$fn__1549000162$fn__1549000163")

var Lit_809 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations$fn__1549000120")

var Lit_810 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations$fn__1549000120$iter__1549000121__1549000125")

var Lit_811 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations$fn__1549000120$iter__1549000131__1549000137")

var Lit_812 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations$fn__1549000120$iter__1549000121__1549000125$fn__1549000126")

var Lit_813 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations$fn__1549000120$iter__1549000121__1549000125$fn__1549000126$fn__1549000127")

var Lit_814 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations$fn__1549000120$iter__1549000131__1549000137$fn__1549000138")

var Lit_815 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations$fn__1549000120$iter__1549000131__1549000137$fn__1549000138$iter__1549000133__1549000142")

var Lit_816 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations$fn__1549000120$iter__1549000131__1549000137$fn__1549000138$iter__1549000133__1549000142$fn__1549000143")

var Lit_817 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations$fn__1549000120$iter__1549000131__1549000137$fn__1549000138$iter__1549000133__1549000142$fn__1549000143$fn__1549000144")

var Lit_818 *jrt.String = jrt.Intern("arbace.classes.analyze$type_arg_anns$fn__1549001153")

var Lit_819 *jrt.String = jrt.Intern("arbace.classes.analyze$type_scope$fn__1549000042")

var Lit_820 *jrt.String = jrt.Intern("arbace.classes.analyze$type_scope$fn__1549000044")

var Lit_821 *jrt.String = jrt.Intern("arbace.classes.analyze$unify_nodes$fn__1549000600")

var Lit_822 *jrt.String = jrt.Intern("arbace.classes.analyze$unify_nodes$fn__1549000600$fn__1549000601")

var Lit_823 *jrt.String = jrt.Intern(" (line ")

var Lit_824 *jrt.String = jrt.Intern("arbace.classes.analyze$with_node_locals$fn__1549001277")

var Lit_825 *jrt.String = jrt.Intern("arbace.classes.analyze$with_node_locals$fn__1549001281")

var Lit_826 *jrt.String = jrt.Intern("arg__")

var Lit_827 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,dynamickn4,linekn6,columnkn4,filekn7,privatekn8,arglistsyn3,msgyn4,datayn1,nyn1,fyn1,&yn4,argsyn5,flagsyn1,myn1,oyn2,cnyn2,nskn8,declaredyn3,symyn1,cyn5,scopeyn4,formyn2,tnyn2,elyn4,descyn1,vyn4,annsyn6,targetyn7,contextyn3,refyn3,tpsyn6,class?yn6,parsedyn5,outeryn6,simpleyn3,ctxyn1,dyn3,ownyn3,kvskn6,publickn6,statickn5,finalkn9,transientkn9,protectedkn8,volatilekn9,synthetickn8,abstractkn12,synchronizedkn6,bridgekn6,nativeyn1,xyn4,nameyn5,arityyn3,tagyn5,mnameyn7,ret-tagyn6,paramsyn12,tparams-formyn6,ret-tnyn9,throws-tnyn5,mmetayn6,pinfosyn4,recvyn4,kindkn2,asyn4,moreyn1,tyn4,fromyn2,toyn1,pyn4,nodekn4,keysyn5,looseyn7,literalkn2,oryn1,ayn1,byn5,nodesyn3,clsyn6,parentyn8,boundaryyn4,actxyn4,typev11,arbace.core5,in-nsMyn22,arbace.classes.analyzem2,R0,s300,Entering class declarations (names, supertypes, members, what javac derives) and analyzing\n  code into typed nodes (SPEC §4 to §6), which the Go build's interpreter\n  (arbace.classes.interp) runs and j2g translates. (The bytecode back end, arbace.classes.emit,\n  is on the branch arbace-for-java-26.)m2,R0,s300,Entering class declarations (names, supertypes, members, what javac derives) and analyzing\n  code into typed nodes (SPEC §4 to §6), which the Go build's interpreter\n  (arbace.classes.interp) runs and j2g translates. (The bytecode back end, arbace.classes.emit,\n  is on the branch arbace-for-java-26.)R1,v22,arbace.classes.analyze6,*unit*m10,R2,TR3,i17,R4,i1,R5,s25,arbace/classes/analyze.aeR0,s89,The current compilation: {:order (atom [names in definition order]) :counters (atom {})}.v22,arbace.classes.analyze3,idsv11,arbace.core4,atoml0,m8,R6,TR3,i21,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze7,next-idm8,R7,L1,V0,R3,i22,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze4,failm8,R7,L2,V1,R8,V2,R8,R9,R3,i24,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze4,declm8,R7,L1,V1,R10,R3,i28,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze5,decl!m8,R7,L1,V1,R10,R3,i29,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,update-decl!m8,R7,L1,V4,R10,R11,R12,R13,R3,i30,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze5,statem8,R7,L1,V1,R10,R3,i31,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze4,has?m8,R7,L1,V2,R14,R11,R3,i33,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,static-flag?m8,R7,L1,V1,R15,R3,i34,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,nest-hostm8,R7,L1,V1,R10,R3,i36,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,outer-levelm12,R6,TR7,L1,V1,R16,R0,s83,How many enclosing instances class o has (javac's nesting level of the outer type).R3,i41,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,this0-namem10,R7,L1,V1,R10,R0,s90,javac's name of class n's outer instance field: this$N, N the outer class's nesting level.R3,i47,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,ctor-real-descm10,R7,L1,V2,R17,R15,R0,s73,The descriptor of a constructor of class cn with all implicit parameters.R3,i52,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,ns-packagem8,R7,L1,V1,R18,R3,i71,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze18,enter-from-source!m8,R19,TR3,i76,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,*source-lookup*v11,arbace.core3,notv17,arbace.classes.go9,go-build?m10,R2,TR3,i78,R4,i1,R5,s25,arbace/classes/analyze.aeR0,s138,Whether class names that resolve to nothing are looked up as p/C.ae sources (§9.2): not in\n  the Go build yet (doc/go/CLASSFORMS-REPL.md).v22,arbace.classes.analyze13,class-exists?m10,R6,TR7,L1,V1,R10,R3,i83,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,default-import?m12,R6,TR7,L1,V2,R20,R21,R0,s80,Is class c the one namespaces map symbol sym to by default (RT/DEFAULT_IMPORTS)?R3,i87,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze17,resolve-class-symm10,R7,L1,V2,R22,R20,R0,s311,Resolves a class name symbol from `scope` {:class internal-name :ns ns :local-classes {}}:\n  member classes of the class and its enclosing classes, then the namespace's explicit imports,\n  then the class's own package, then Clojure's default imports and java.lang (SPEC §5.2).\n  Returns an internal name or nil.R3,i92,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,implicit-outerm8,R19,TR3,i141,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,type-scopem10,R7,L1,V1,R22,R0,s72,A scope for types/parse-type: class name resolution plus type variables.R3,i143,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,class-tparamsm10,R6,TR7,L1,V1,R10,R3,i151,R4,i1,R5,s25,arbace/classes/analyze.aem10,R7,L1,V2,R22,R10,R0,s159,Inside a generic class, the simple name of one of its inner (non-static) member classes\n  denotes Outer<T...>.Inner (JLS 6.5.5.1): the outer type node, or nil.R3,i162,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,parse-typem8,R7,L1,V2,R22,R23,R3,i177,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze5,erasem8,R7,L1,V2,R22,R24,R3,i178,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,type-descm10,R7,L1,V2,R22,R23,R0,s46,The erased descriptor of a type form in scope.R3,i179,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,class-scopem10,R7,L1,V1,R10,R0,s33,The scope of the body of class n.R3,i184,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,retentionm10,R6,TR7,L1,V1,R10,R3,i193,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,element-typem12,R6,TR7,L1,V2,R10,R25,R0,s70,The return descriptor of annotation element `el` of annotation type n.R3,i207,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze18,analyze-const-formm8,R19,TR3,i213,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,ann-valuem10,R6,TR7,L1,V3,R22,R26,R27,R3,i215,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,annotations-nowm8,R19,TR3,i243,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,annotationsm10,R7,L1,V2,R22,R15,R0,s229,Annotations (delayed, as annotation types of the compilation may not be entered yet) in metadata m (symbol keys naming annotation types), in scope.\n  Returns [{:type desc :visible bool :values {name value}}], SOURCE ones dropped.R3,i245,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze18,annotation-targetsm10,R7,L1,V1,R10,R0,s78,The ElementType names of annotation type n's @Target, or nil when it has none.R3,i251,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,for-targetm10,R7,L1,V2,R28,R29,R0,s129,Annotations applicable to declaration context `target` (an ElementType name), as javac\n  propagates record component annotations.R3,i264,R4,i1,R5,s25,arbace/classes/analyze.aem8,R19,TR3,i272,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,decl-annotationsm10,R7,L1,V3,R22,R15,R30,R0,s148,Declaration annotations in metadata m for declaration context `context` (an ElementType\n  name): those without @Target or whose @Target includes it.R3,i274,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,type-annotationsm10,R7,L1,V4,R22,R31,R24,R15,R0,s172,Type annotations of a declared type tn at type reference `ref` (an int): those inside the\n  type, and those of the declaration's metadata m whose @Target includes TYPE_USE.R3,i284,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze23,tparam-type-annotationsm12,R6,TR7,L1,V3,R22,R32,R33,R0,s77,Type annotations of type parameters and their bounds (sort: class or method).R3,i300,R4,i1,R5,s25,arbace/classes/analyze.aem8,R7,L1,V2,R22,R15,R3,i328,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze8,top-namem8,R7,L1,V2,R18,R34,R3,i346,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,local-class-namem10,R7,L1,V2,R35,R36,R0,s81,javac's name for a local (simple name given) or anonymous class in class `outer`.R3,i354,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,declare-class!m10,R7,L1,V2,R37,R34,R0,s458,Enters a parsed Java form and its member classes into the compilation.\n  ctx: {:nesting :outer :name (for local and anonymous classes) :static-context bool\n        :local-classes {} :enclosing-method {:name :desc} :parsed-members (nil, or the member\n        classes parsed ahead, [{:parsed parsed-class :members [...]}...] in their order: j2g's\n        load parses them in parallel, arbace.j2g.world/parse-member-classes)}. Returns the\n        internal name.R3,i361,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,bounds-of-scopem12,R6,TR7,L1,V1,R38,R0,s160,Type variable bounds visible in class declaration d: its own, those of the method creating a\n  local or anonymous class, and, unless static, its outer classes'.R3,i403,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,set-own-bounds!m12,R6,TR7,L1,V4,R10,R39,R12,R40,R0,s215,Sets class n's own type variable bounds (and more keys and values kvs), and the bounds visible\n  in it, in one update (j2g's load resolves the headers in parallel: fewer updates of the\n  compilation, fewer retries).R3,i412,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,resolve-header!m10,R7,L1,V1,R10,R0,s78,Resolves type parameters, superclass, interfaces and the class Signature of n.R3,i420,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,field-modsS8,R6,R41,R42,R43,R44,R45,R46,R47,m8,R6,TR3,i476,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,method-modsS10,R6,R41,R42,R48,R43,R49,R50,R51,R45,R47,m8,R6,TR3,i477,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,deprecated-flagm10,R6,TR7,L1,V1,R15,R3,i480,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,iface-kind?m10,R6,TR7,L1,V1,R38,R3,i484,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze6,tag-ofm10,R6,TR7,L1,V1,R52,R3,i486,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,param-infom10,R6,TR7,L1,V2,R22,R20,R3,i488,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,infer-signaturem12,R6,TR7,L1,V3,R10,R53,R54,R0,s140,deftype's rule: an untyped instance method takes the erased signature of the unique method of\n  its supertypes with the same name and arity.R3,i493,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze22,clojure-implementablesm12,R6,TR7,L1,V1,R10,R0,s244,The methods of class n's supertypes that a reify or deftype class n can implement (public or\n  protected, neither static nor final), as arbace.lang.Compiler's NewInstanceExpr.considerMethod\n  takes them, each with its declaring class as :owner.R3,i508,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze21,clojure-overrideablesm12,R6,TR7,L1,V1,R10,R0,s270,arbace.lang.Compiler's NewInstanceExpr.gatherMethods for class n (a reify or deftype class):\n  the methods of its supertypes it can implement (public or protected, neither static nor\n  final), one per name and parameter types, the one with the most specific return type.R3,i520,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,clojure-bridgesm12,R6,TR7,L1,V1,R10,R0,s457,The covariant bridges arbace.lang.Compiler gives a reify or deftype class n\n  (NewInstanceExpr.emitMethods over gatherMethods' covariants): for every method of the\n  supertypes that another one with the same name and parameter types but a more specific return\n  type overrides, whether n implements it or not, a public bridge (ACC_BRIDGE only, no\n  exceptions) with the overridden return type calling the most specific one through its\n  declaring interface.R3,i538,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,clojure-tag-descm12,R6,TR7,L1,V2,R22,R55,R0,s80,The descriptor of arbace.lang.Compiler's tagClass of a hint: Object without one.R3,i560,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,class-name-ofm12,R6,TR7,L1,V1,R38,R0,s43,Class.getName of the class of descriptor d.R3,i568,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,clojure-overridem12,R6,TR7,L1,V5,R10,R22,R56,R57,R58,R0,s462,The method of class n's supertypes that a method of reify or deftype named mname (munged)\n  with parameters params and return hint ret-tag implements, chosen as arbace.lang.Compiler's\n  NewInstanceMethod.parse chooses it, with its errors: the only method with that name and arity\n  when nothing is hinted; otherwise the one whose parameter types are the hinted classes\n  (Object where unhinted), whose return type must be the hinted class (Object when unhinted).R3,i573,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,method-scopem10,R6,TR7,L1,V2,R22,R59,R3,i601,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,method-signaturem10,R6,TR7,L1,V4,R32,R58,R60,R61,R3,i607,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze23,method-type-annotationsm10,R6,TR7,L1,V7,R22,R32,R62,R60,R63,R61,R64,R3,i615,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,enter-methodm10,R6,TR7,L1,V3,R10,R22,R15,R3,i637,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,class-accessm10,R6,TR7,L1,V1,R38,R3,i691,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,enter-ctorm10,R6,TR7,L1,V3,R10,R22,R15,R3,i694,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,enter-fieldm10,R6,TR7,L1,V3,R10,R22,R15,R3,i718,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,derived-methodm10,R6,TR7,L1,V7,R10,R53,R26,R14,R65,R12,m2,R66,R67,R3,i735,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,resolve-members!m8,R19,TR3,i741,R4,i1,R5,s25,arbace/classes/analyze.aem10,R7,L1,V1,R10,R0,s153,Enters the fields and methods of n, declared and derived (§6). Supertypes in the\n  compilation are entered first (for deftype-style signature inference).R3,i743,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,const-of-typem10,R7,L1,V2,R68,R27,R0,s60,Converts constant value v to the Java value of descriptor t.R3,i852,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze5,fits?m8,R7,L1,V2,R68,R27,R3,i866,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,const-nodem8,R7,L1,V4,R68,R27,R12,m2,R66,R67,R3,i876,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,value-typem8,R7,L1,V1,R68,R3,i882,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze8,wideningS5,s1,Js1,Ss1,Fs1,Is1,DS4,s1,Js1,Fs1,Is1,DS4,s1,Js1,Fs1,Is1,DS3,s1,Js1,Fs1,DS2,s1,Fs1,DS1,s1,Dm6,R3,i884,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze7,widens?m8,R7,L1,V2,R69,R70,R3,i888,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,boxed-descm8,R7,L1,V1,R71,R3,i890,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze17,literal-tail-valsm8,R19,TR3,i892,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,conversionm10,R7,L1,V5,R72,R69,R70,R12,m4,R73,V2,R74,R75,R76,m4,R74,TR75,TR0,s166,How a value of type `from` converts to `to` in assignment and invocation contexts:\n  nil when it cannot, else a keyword: :none :widen :box :unbox :narrow-const :null.R3,i894,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze5,unifym10,R7,L1,V2,R77,R78,R0,s56,The type of a value that is one of two branches' values.R3,i922,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,literal-tail?m10,R7,L1,V1,R72,R0,s73,Is the value of node an integer literal that fits an int (in every tail)?R3,i939,R4,i1,R5,s25,arbace/classes/analyze.aem10,R7,L1,V1,R72,R0,s83,The values of the integer literal tails of node, or nil if some tail is no literal.R3,i954,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,convert-nodem8,R19,TR3,i971,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,literal-branchm10,R7,L1,V2,R72,R68,R0,s87,A branch of integer literals takes the int-like type of the whole (as Java types them).R3,i973,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,unify-nodesm10,R7,L1,V1,R79,R0,s53,The type of a value that is one of the nodes' values.R3,i980,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,new-framem8,R7,L1,V4,R65,R80,R81,R82,R3,i1009,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,prologue?m10,R7,L1,V1,R83,R0,s62,Is code of actx before the constructor call (no instance yet)?R3,i1012,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,make-bindingm8,R7,L1,V5,R83,R20,R84,R12,m2,R66,R67,R3,i1017,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,with-localm8,R7,L1,V2,R83,R78,R3,i1020,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze8,scope-ofm8,R7,L1,V1,R83,R3,i1022,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,actx-descm8,R7,L1,V2,R83,R23,R3,i1025,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,resolve-classm8,R7,L1,V2,R83,R20,R3,i1027,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,add-capture!m10,R6,TR7,L1,V2,R82,R78,R3,i1030,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,outer-this-nodem8,R19,TR3,i1038,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,local-refm10,R6,TR7,L1,V2,R83,R78,R3,i1040,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,outer-this-node*m8,R19,TR3,i1056,R4,i1,R5,s25,arbace/classes/analyze.ae")

var Lit_828 *jrt.String = jrt.Intern("arbace.classes.analyze$eval1549000004$loading__1927001464__auto____1549000005")

var Lit_829 *jrt.String = jrt.Intern("arbace.classes.analyze$eval1549000008$fn__1549000009")

var Lit_830 *jrt.String = jrt.Intern("arbace.classes.analyze$next_id")

var Lit_831 *jrt.String = jrt.Intern("arbace.classes.analyze$fail")

var Lit_832 *jrt.String = jrt.Intern("arbace.classes.analyze$decl")

var Lit_833 *jrt.String = jrt.Intern("arbace.classes.analyze$decl_BANG_")

var Lit_834 *jrt.String = jrt.Intern("arbace.classes.analyze$update_decl_BANG_")

var Lit_835 *jrt.String = jrt.Intern("arbace.classes.analyze$state")

var Lit_836 *jrt.String = jrt.Intern("arbace.classes.analyze$has_QMARK_")

var Lit_837 *jrt.String = jrt.Intern("arbace.classes.analyze$static_flag_QMARK_")

var Lit_838 *jrt.String = jrt.Intern("arbace.classes.analyze$nest_host")

var Lit_839 *jrt.String = jrt.Intern("arbace.classes.analyze$outer_level")

var Lit_840 *jrt.String = jrt.Intern("arbace.classes.analyze$this0_name")

var Lit_841 *jrt.String = jrt.Intern("arbace.classes.analyze$ctor_real_desc")

var Lit_842 *jrt.String = jrt.Intern("arbace.classes.analyze$ns_package")

var Lit_843 *jrt.String = jrt.Intern("arbace.classes.analyze$class_exists_QMARK_")

var Lit_844 *jrt.String = jrt.Intern("arbace.classes.analyze$default_import_QMARK_")

var Lit_845 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_class_sym")

var Lit_846 *jrt.String = jrt.Intern("arbace.classes.analyze$type_scope")

var Lit_847 *jrt.String = jrt.Intern("arbace.classes.analyze$class_tparams")

var Lit_848 *jrt.String = jrt.Intern("arbace.classes.analyze$implicit_outer")

var Lit_849 *jrt.String = jrt.Intern("arbace.classes.analyze$parse_type")

var Lit_850 *jrt.String = jrt.Intern("arbace.classes.analyze$erase")

var Lit_851 *jrt.String = jrt.Intern("arbace.classes.analyze$type_desc")

var Lit_852 *jrt.String = jrt.Intern("arbace.classes.analyze$class_scope")

var Lit_853 *jrt.String = jrt.Intern("arbace.classes.analyze$retention")

var Lit_854 *jrt.String = jrt.Intern("arbace.classes.analyze$element_type")

var Lit_855 *jrt.String = jrt.Intern("arbace.classes.analyze$ann_value")

var Lit_856 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations")

var Lit_857 *jrt.String = jrt.Intern("arbace.classes.analyze$annotation_targets")

var Lit_858 *jrt.String = jrt.Intern("arbace.classes.analyze$for_target")

var Lit_859 *jrt.String = jrt.Intern("arbace.classes.analyze$decl_annotations")

var Lit_860 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations")

var Lit_861 *jrt.String = jrt.Intern("arbace.classes.analyze$tparam_type_annotations")

var Lit_862 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations_now")

var Lit_863 *jrt.String = jrt.Intern("arbace.classes.analyze$top_name")

var Lit_864 *jrt.String = jrt.Intern("arbace.classes.analyze$local_class_name")

var Lit_865 *jrt.String = jrt.Intern("arbace.classes.analyze$declare_class_BANG_")

var Lit_866 *jrt.String = jrt.Intern("arbace.classes.analyze$bounds_of_scope")

var Lit_867 *jrt.String = jrt.Intern("arbace.classes.analyze$set_own_bounds_BANG_")

var Lit_868 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_header_BANG_")

var Lit_869 *jrt.String = jrt.Intern("arbace.classes.analyze$deprecated_flag")

var Lit_870 *jrt.String = jrt.Intern("arbace.classes.analyze$iface_kind_QMARK_")

var Lit_871 *jrt.String = jrt.Intern("arbace.classes.analyze$tag_of")

var Lit_872 *jrt.String = jrt.Intern("arbace.classes.analyze$param_info")

var Lit_873 *jrt.String = jrt.Intern("arbace.classes.analyze$infer_signature")

var Lit_874 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_implementables")

var Lit_875 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_overrideables")

var Lit_876 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges")

var Lit_877 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_tag_desc")

var Lit_878 *jrt.String = jrt.Intern("arbace.classes.analyze$class_name_of")

var Lit_879 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_override")

var Lit_880 *jrt.String = jrt.Intern("arbace.classes.analyze$method_scope")

var Lit_881 *jrt.String = jrt.Intern("arbace.classes.analyze$method_signature")

var Lit_882 *jrt.String = jrt.Intern("arbace.classes.analyze$method_type_annotations")

var Lit_883 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_method")

var Lit_884 *jrt.String = jrt.Intern("arbace.classes.analyze$class_access")

var Lit_885 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_ctor")

var Lit_886 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_field")

var Lit_887 *jrt.String = jrt.Intern("arbace.classes.analyze$derived_method")

var Lit_888 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_")

var Lit_889 *jrt.String = jrt.Intern("arbace.classes.analyze$const_of_type")

var Lit_890 *jrt.String = jrt.Intern("arbace.classes.analyze$fits_QMARK_")

var Lit_891 *jrt.String = jrt.Intern("arbace.classes.analyze$const_node")

var Lit_892 *jrt.String = jrt.Intern("arbace.classes.analyze$value_type")

var Lit_893 *jrt.String = jrt.Intern("arbace.classes.analyze$widens_QMARK_")

var Lit_894 *jrt.String = jrt.Intern("arbace.classes.analyze$boxed_desc")

var Lit_895 *jrt.String = jrt.Intern("arbace.classes.analyze$conversion")

var Lit_896 *jrt.String = jrt.Intern("arbace.classes.analyze$unify")

var Lit_897 *jrt.String = jrt.Intern("arbace.classes.analyze$literal_tail_QMARK_")

var Lit_898 *jrt.String = jrt.Intern("arbace.classes.analyze$literal_tail_vals")

var Lit_899 *jrt.String = jrt.Intern("arbace.classes.analyze$literal_branch")

var Lit_900 *jrt.String = jrt.Intern("arbace.classes.analyze$unify_nodes")

var Lit_901 *jrt.String = jrt.Intern("arbace.classes.analyze$new_frame")

var Lit_902 *jrt.String = jrt.Intern("arbace.classes.analyze$prologue_QMARK_")

var Lit_903 *jrt.String = jrt.Intern("arbace.classes.analyze$make_binding")

var Lit_904 *jrt.String = jrt.Intern("arbace.classes.analyze$with_local")

var Lit_905 *jrt.String = jrt.Intern("arbace.classes.analyze$scope_of")

var Lit_906 *jrt.String = jrt.Intern("arbace.classes.analyze$actx_desc")

var Lit_907 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_class")

var Lit_908 *jrt.String = jrt.Intern("arbace.classes.analyze$add_capture_BANG_")

var Lit_909 *jrt.String = jrt.Intern("arbace.classes.analyze$local_ref")

var Lit_910 *jrt.String = jrt.Intern("kn8,arglistsyn4,actxyn6,targetkn3,dockn4,linekn6,columnkn4,filekn7,privateyn1,nyn1,&yn12,monitor-exityn5,case*yn3,tryyn6,reify*yn7,finallyyn5,loop*yn2,doyn6,letfn*yn2,ifyn3,newyn8,deftype*yn4,let*yn3,fn*yn5,recuryn4,set!yn1,.yn3,varyn5,quoteyn5,catchys11,arbace.core7,import*yn5,throwyn13,monitor-enteryn3,defyn14,class-literal*yn6,break*yn9,for-each*yn11,method-ref*yn6,class*yn15,with-resources*yn12,if-instance*yn6,super.yn6,label*yn9,java-str*yn12,java-assert*yn7,lambda*yn7,switch*yn9,continue*yn5,this.yn7,return*yn1,vyn3,symyn4,formkn8,declaredyn1,fyn4,nodeyn3,tagyn5,formskn3,tagyn1,cyn6,fieldsyn17,java.util.HashMapyn1,dkn4,longkn3,negkn3,divkn5,floatkn3,subkn5,exactkn3,mulkn3,intkn3,shrkn8,longbitskn2,orkn3,addkn3,deckn3,shlkn3,xorkn3,remkn3,andkn6,andnotkn3,inckn3,notkn4,ushryn2,tokn4,keysyn4,whatyn1,tyn1,ayn1,byn2,opyn6,opnameyn9,arg-nodesyn3,argyn8,checked?yn4,argsyn5,nodesyn4,inityn5,loop?yn4,typeyn1,_yn8,bindingsyn4,bodykn2,asyn4,testyn4,thenyn4,elseyn5,labelyn2,kwyn1,eyn1,xyn5,phaseyn11,param-descsyn2,p1yn2,p2yn6,paramsyn4,tagsyn9,tag-descsyn1,myn4,descyn1,pyn2,c1yn2,c2yn2,r1yn2,r2yn6,plistsyn4,retsyn5,candsyn4,kindyn5,mnameyn2,cnyn10,param-tagsyn4,fromm10,R0,L1,V2,R1,R2,R3,s251,Java's T.this from actx: the path of this$0 hops from the current class to class T. In a\n  lambda in a constructor of an inner class, the constructor's outer instance parameter\n  captured by the lambda, as javac's Lower makes it before LambdaToMethod.R4,i1058,R5,i1,R6,s25,arbace/classes/analyze.aem10,R7,TR0,L1,V2,R1,R2,R4,i1080,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze18,class-parent-framem10,R0,L1,V1,R8,R3,s180,The frame enclosing the code of class n: where a local or anonymous class was declared, a\n  stand-in for the outer class's instance code for member classes, nil for top-level ones.R4,i1105,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,clojure-specialsS24,R9,R10,R11,R12,R13,R14,R15,R16,R17,R18,R19,R20,R21,R22,R23,R24,R25,R26,R27,R28,R29,R30,R31,R32,m6,R4,i1119,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,arbace-specialsS16,R33,R34,R35,R36,R37,R38,R39,R40,R41,R42,R43,R44,R45,R46,R47,R48,m6,R4,i1123,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,core-var?m10,R7,TR0,L1,V1,R49,R4,i1127,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,resolve-varm8,R0,L1,V2,R1,R50,R4,i1130,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze7,core-opm10,R0,L1,V2,R1,R50,R3,s59,The name of the core var a head symbol resolves to, or nil.R4,i1135,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,macroexpand1m8,R0,L1,V2,R1,R51,R4,i1141,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,accessorizem8,R52,TR4,i1154,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,outer-super-callm8,R52,TR4,i1156,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,code-type-annsm8,R52,TR4,i1156,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze20,analyze-method-call*m8,R52,TR4,i1156,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,clj-constantm8,R52,TR4,i1158,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,clj-collectionm8,R52,TR4,i1158,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,clj-var-fieldm8,R52,TR4,i1158,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze7,analyzem8,R52,TR4,i1160,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,analyze-bodym8,R52,TR4,i1160,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,analyze-invokem8,R52,TR4,i1160,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,analyze-newm8,R52,TR4,i1160,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,analyze-dotm8,R52,TR4,i1160,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,analyze-opm8,R52,TR4,i1160,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze18,analyze-class-formm8,R52,TR4,i1160,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,analyze-symbolm8,R52,TR4,i1160,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,coerce-hintm8,R52,TR4,i1160,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze21,needs-outer-instance?m8,R52,TR4,i1160,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,ctor-call-nodem8,R52,TR4,i1160,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,with-form-infom10,R7,TR0,L1,V2,R51,R53,R4,i1163,R5,i1,R6,s25,arbace/classes/analyze.aem10,R0,L1,V2,R1,R51,R3,s42,Analyzes a form of code into a typed node.R4,i1171,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,branching-tail?m8,R52,TR4,i1208,R5,i1,R6,s25,arbace/classes/analyze.aem8,R52,TR4,i1208,R5,i1,R6,s25,arbace/classes/analyze.aem10,R0,L1,V3,R1,R54,R55,R3,s136,A tag on an expression gives its static type, as in Clojure; a checkcast keeps the\n  verifier happy where the type is not already known.R4,i1210,R5,i1,R6,s25,arbace/classes/analyze.aem10,R0,L1,V2,R1,R56,R3,s25,Analyzes forms as a `do`.R4,i1231,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,field-nodem10,R7,TR0,L1,V3,R1,R53,R2,R4,i1245,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,field-indexesm10,R57,C38,java.util.concurrent.ConcurrentHashMapR7,TR4,i1261,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,field-indexm12,R7,TR0,L1,MV2,R58,R59,m2,R57,R60,R3,s108,{name [position field]} of the first field of each name in fields (a class's :fields) that is\n  not derived.R4,i1266,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,find-own-fieldm10,R0,L1,V2,R1,R50,R3,s102,A field of the current class or an enclosing class body, innermost first:\n  [field class-name] or nil.R4,i1283,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,this-nodem8,R0,L1,V1,R1,R4,i1305,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,class-litm10,R7,TR0,L1,V2,R1,R61,R4,i1309,R5,i1,R6,s25,arbace/classes/analyze.aem8,R0,L1,V2,R1,R50,R4,i1312,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,arith-opsm88,s16,unchecked-negateV2,R62,R63,s16,unchecked-divideV2,R62,R64,s24,unchecked-subtract-floatV2,R65,R66,s1,*V2,R67,R68,s19,bit-shift-right-intV2,R69,R70,s18,unchecked-subtractV2,R62,R66,s20,unchecked-divide-intV2,R69,R64,s6,bit-orV2,R71,R72,s20,unchecked-negate-intV2,R69,R63,s13,unchecked-addV2,R62,R73,s17,unchecked-dec-intV2,R69,R74,s1,-V2,R67,R66,s18,bit-shift-left-intV2,R69,R75,s7,bit-xorV2,R71,R76,s3,remV2,R67,R77,s7,bit-andV2,R71,R78,s17,unchecked-add-intV2,R69,R73,s13,unchecked-decV2,R62,R74,s11,bit-and-notV2,R71,R79,s22,unchecked-negate-floatV2,R65,R63,s13,unchecked-incV2,R62,R80,s3,incV2,R67,R80,s7,bit-notV2,R71,R81,s23,unchecked-remainder-intV2,R69,R77,s28,unsigned-bit-shift-right-intV2,R69,R82,s24,unsigned-bit-shift-rightV2,R71,R82,s11,bit-and-intV2,R69,R78,s11,bit-not-intV2,R69,R81,s24,unchecked-multiply-floatV2,R65,R68,s18,unchecked-multiplyV2,R62,R68,s22,unchecked-subtract-intV2,R69,R66,s15,bit-shift-rightV2,R71,R70,s22,unchecked-multiply-intV2,R69,R68,s25,unchecked-remainder-floatV2,R65,R77,s19,unchecked-add-floatV2,R65,R73,s17,unchecked-inc-intV2,R69,R80,s4,quotV2,R67,R64,s14,bit-shift-leftV2,R71,R75,s11,bit-xor-intV2,R69,R76,s19,unchecked-remainderV2,R62,R77,s10,bit-or-intV2,R69,R72,s22,unchecked-divide-floatV2,R65,R64,s3,decV2,R67,R74,s1,+V2,R67,R73,m8,R7,TR4,i1370,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,conversionsm14,s13,unchecked-ints1,Is14,unchecked-longs1,Js15,unchecked-shorts1,Ss14,unchecked-bytes1,Bs14,unchecked-chars1,Cs15,unchecked-floats1,Fs16,unchecked-doubles1,Dm8,R7,TR4,i1392,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze19,checked-conversionsm14,s3,ints1,Is4,longs1,Js5,shorts1,Ss4,bytes1,Bs4,chars1,Cs5,floats1,Fs6,doubles1,Dm8,R7,TR4,i1396,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,comparisonsS5,s2,<=s2,>=s1,<s2,==s1,>m8,R7,TR4,i1399,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze7,unboxedm10,R7,TR0,L1,V1,R54,R4,i1401,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,prim-typem10,R7,TR0,L1,V1,R54,R4,i1407,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,prim-type-ofm12,R7,TR0,L1,V1,R54,R3,s66,The primitive type of a node's value (unboxing a wrapper), or nil.R4,i1409,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,clone-tail?m12,R7,TR0,L1,V1,R54,R3,s61,Is the value of node (through do and let) an array's clone()?R4,i1414,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,retype-clonem10,R7,TR0,L1,V2,R54,R83,R4,i1423,R5,i1,R6,s25,arbace/classes/analyze.aem12,R7,TR0,L1,V1,R54,R3,s79,Is the value of node (through do and let) that of a conditional, switch or try?R4,i1431,R5,i1,R6,s25,arbace/classes/analyze.aem10,R0,L1,V4,R54,R83,R9,m4,R84,V1,R85,R72,m2,R85,s5,valueR3,s92,Converts node to type `to` (an assignment conversion; a const is converted at compile time).R4,i1441,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze7,operandm12,R7,TR0,L1,V2,R54,R86,R3,s82,Converts an operand to the operation type t: numeric promotion, literals narrowed.R4,i1486,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,int-operandm12,R7,TR0,L1,V2,R1,R54,R3,s138,An int operand (array dimension or index); in Clojure code (§5.13) also any other value,\n  converted by RT.intCast as Clojure converts it.R4,i1504,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze4,fmodm12,R7,TR0,L1,V2,R87,R88,R3,s88,Java's % on doubles (drem: the remainder of the truncated quotient, exact), for folding.R4,i1513,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,fold-arithm10,R7,TR0,L1,V4,R86,R89,R87,R88,R4,i1522,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,analyze-arithm10,R7,TR0,L1,V3,R1,R90,R91,R4,i1552,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze18,analyze-conversionm10,R7,TR0,L1,V6,R1,R83,R92,R93,R9,V1,R54,R4,i1597,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,compare-typem10,R7,TR0,L1,V2,R87,R88,R4,i1625,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,analyze-comparem10,R7,TR0,L1,V5,R1,R89,R94,R9,V1,R95,R4,i1633,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,bool-nodem10,R7,TR0,L1,V2,R1,R51,R4,i1656,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,lambda-form?m12,R7,TR0,L1,V1,R53,R3,s132,Is f a lambda or method reference, possibly under casts (javac's pending variable of\n  serializable lambda names sees through them)?R4,i1661,R5,i1,R6,s25,arbace/classes/analyze.aem8,R52,TR4,i1669,R5,i1,R6,s25,arbace/classes/analyze.aem8,R52,TR4,i1669,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,local-type-annsm12,R7,TR0,L1,V2,R1,R50,R3,s108,Type annotations of a local variable: TYPE_USE annotations on the binding symbol and those\n  inside its tag.R4,i1671,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,binding-typem12,R7,TR0,L1,V4,R1,R50,R96,R97,R3,s116,The type of a let/loop local: its tag, else its initializer's type (Clojure's loop widens\n  untagged int and float).R4,i1686,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,bind-initm10,R7,TR0,L1,V4,R1,R50,R96,R98,R4,i1700,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,analyze-letm10,R7,TR0,L1,V3,R1,V6,R99,R100,R9,R101,R102,R51,R97,R4,i1713,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,class-def-in?m12,R7,TR0,L1,V1,R51,R3,s43,Does form declare a class (anon, letclass)?R4,i1754,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,analyze-ifm10,R7,TR0,L1,V2,R1,V6,R99,R103,R104,R105,R102,R51,R4,i1760,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,analyze-recurm10,R7,TR0,L1,V3,R1,R94,R106,R4,i1776,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,expand-to-loopm12,R7,TR0,L1,V2,R1,R51,R3,s89,Macroexpands form until it is a loop* (or for-each*) form; nil if it does not become one.R4,i1796,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,analyze-labelm10,R7,TR0,L1,V2,R1,V4,R99,R107,R9,R101,R4,i1804,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,analyze-breakm10,R7,TR0,L1,V2,R1,V3,R99,R9,R94,R4,i1815,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,analyze-returnm10,R7,TR0,L1,V2,R1,V4,R99,R49,R102,R51,R4,i1824,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,analyze-throwm10,R7,TR0,L1,V2,R1,V2,R99,R108,R4,i1831,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,analyze-trym10,R7,TR0,L1,V2,R1,V3,R99,R9,R56,R4,i1844,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,analyze-lockingm10,R7,TR0,L1,V2,R1,V4,R99,R109,R9,R101,R4,i1863,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze20,analyze-field-accessm8,R52,TR4,i1871,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,super-nodem8,R52,TR4,i1871,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,analyze-set!m10,R7,TR0,L1,V2,R1,V3,R99,R2,R49,R4,i1873,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,applicable?m10,R7,TR0,L1,V3,R110,R91,R111,R4,i1926,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,more-specific?m10,R7,TR0,L1,V2,R112,R113,R4,i1936,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,expand-varargsm10,R7,TR0,L1,V2,R114,R8,R4,i1941,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze17,param-tags-match?m12,R7,TR0,L1,V3,R115,R116,R117,R3,s140,Do the param-tags match method m? tag-descs: each tag's descriptor as a delay (resolved once\n  for all the candidates, when first compared).R4,i1946,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,clj-fi-excludedS3,s20,java/util/Comparators18,java/lang/Runnables29,java/util/concurrent/Callablem8,R7,TR4,i1957,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze8,find-samm8,R52,TR4,i1959,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,clj-fi-methodm10,R0,L1,V1,R118,R3,s518,Compiler's FISupport.maybeFIMethod: for a parameter of type desc that is a\n  @FunctionalInterface other than Callable, Runnable and Comparator, its method (an abstract\n  one, of at most 10 parameters, other than equals, toString and hashCode) that an IFn argument\n  is adapted to, as {:name :ps [param desc ...] :ret desc}; else nil. A class compiled from\n  source (*from-source*: j2g's world, where the JDK's classes have Java forms) is asked\n  through its declaration: its annotations and its single abstract method.R4,i1961,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,clj-arg-classm12,R7,TR0,L1,V1,R54,R3,s174,The class arbace.lang.Compiler knows for an argument node (Expr.getJavaClass), as a\n  descriptor: nil for nil, ::unknown for Object (the type of what Clojure leaves untyped).R4,i1990,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,clj-prim-argsm16,s1,IS5,s1,Js1,Ss19,Ljava/lang/Integer;s1,Bs16,Ljava/lang/Long;s1,FS2,s17,Ljava/lang/Float;s1,Ds1,DS2,s18,Ljava/lang/Double;s1,Fs1,JS4,s1,Ss1,Bs16,Ljava/lang/Long;s1,Is1,CS1,s21,Ljava/lang/Character;s1,SS1,s17,Ljava/lang/Short;s1,BS1,s16,Ljava/lang/Byte;s1,ZS1,s19,Ljava/lang/Boolean;m10,R7,TR4,i1999,R5,i1,R6,s25,arbace/classes/analyze.aeR3,s66,Reflector.paramArgTypeMatch's conversions to primitive parameters.v22,arbace.classes.analyze20,clj-param-arg-match?m12,R7,TR0,L1,V2,R119,R87,R3,s86,Reflector.paramArgTypeMatch for parameter type p and argument class a (clj-arg-class).R4,i2010,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,clj-subsumes?m12,R7,TR0,L1,V2,R120,R121,R3,s62,Compiler.subsumes: is parameter list c1 more specific than c2?R4,i2021,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze19,clj-ret-assignable?m12,R7,TR0,L1,V2,R122,R123,R3,s51,Class.isAssignableFrom on return types: r1 from r2.R4,i2030,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze18,clj-matching-indexm12,R7,TR0,L1,V4,R85,R124,R94,R125,R3,s183,Compiler.getMatchingParams: the index of the parameter list (of plists, with return types\n  rets) chosen for the argument nodes, or -1; \"More than one matching method found\" on a tie.R4,i2035,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,clj-type-stringm12,R7,TR0,L1,V1,R94,R3,s30,Compiler.getTypeStringForArgs.R4,i2068,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,clj-selectm10,R0,L1,V5,R126,R94,R127,R128,R129,R3,s460,The method (or constructor) of cands that arbace.lang.Compiler calls for the argument nodes,\n  marked :clojure-args (its arguments converted as Clojure converts them): the only one of that\n  arity, else the one Compiler.getMatchingParams chooses (kind :instance, :static or :ctor of\n  class cn), with the compiler's errors. When it chooses none an instance method or constructor\n  is called by reflection, as in Clojure (an unresolved failure, see or-reflect).R4,i2073,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,select-methodm10,R0,L1,V5,R1,R126,R94,R85,R130,R3,s181,Chooses among candidate methods for argument nodes (JLS 15.12.2 on erased types: strict,\n  loose, then variable arity invocation; then literal narrowing). Returns [method varargs?].R4,i2098,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze19,instance-candidatesm10,R0,L1,V3,R131,R129,R128,R3,s110,The candidates of an instance method call (.mname x ...) from class `from` on a receiver of\n  class cn (§5.6).R4,i2134,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze17,static-candidatesm10,R0,L1,V3,R131,R129,R128,R3,s71,The candidates of a static method call (C/mname ...) from class `from`.R4,i2142,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,ctor-candidatesm10,R0,L1,V2,R131,R129,R3,s58,The constructors of class cn accessible from class `from`.R4,i2149,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,clj-arg-convertm12,R7,TR0,L1,V2,R54,R83,R3,s248,An argument node converted to parameter type `to` as arbace.lang.Compiler converts it\n  (HostExpr.emitUnboxArg): references by RT's longCast, intCast..., Boolean and Character\n  unboxed, references of other types checked, long to int by RT.intCast.R4,i2154,R5,i1,R6,s25,arbace/classes/analyze.ae")

var Lit_911 *jrt.String = jrt.Intern("arbace.classes.analyze$outer_this_node")

var Lit_912 *jrt.String = jrt.Intern("arbace.classes.analyze$outer_this_node_STAR_")

var Lit_913 *jrt.String = jrt.Intern("arbace.classes.analyze$class_parent_frame")

var Lit_914 *jrt.String = jrt.Intern("arbace.classes.analyze$core_var_QMARK_")

var Lit_915 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_var")

var Lit_916 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op")

var Lit_917 *jrt.String = jrt.Intern("arbace.classes.analyze$macroexpand1")

var Lit_918 *jrt.String = jrt.Intern("arbace.classes.analyze$with_form_info")

var Lit_919 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze")

var Lit_920 *jrt.String = jrt.Intern("arbace.classes.analyze$coerce_hint")

var Lit_921 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_body")

var Lit_922 *jrt.String = jrt.Intern("arbace.classes.analyze$field_node")

var Lit_923 *jrt.String = jrt.Intern("arbace.classes.analyze$field_index")

var Lit_924 *jrt.String = jrt.Intern("arbace.classes.analyze$find_own_field")

var Lit_925 *jrt.String = jrt.Intern("arbace.classes.analyze$this_node")

var Lit_926 *jrt.String = jrt.Intern("arbace.classes.analyze$class_lit")

var Lit_927 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_symbol")

var Lit_928 *jrt.String = jrt.Intern("arbace.classes.analyze$unboxed")

var Lit_929 *jrt.String = jrt.Intern("arbace.classes.analyze$prim_type")

var Lit_930 *jrt.String = jrt.Intern("arbace.classes.analyze$prim_type_of")

var Lit_931 *jrt.String = jrt.Intern("arbace.classes.analyze$clone_tail_QMARK_")

var Lit_932 *jrt.String = jrt.Intern("arbace.classes.analyze$retype_clone")

var Lit_933 *jrt.String = jrt.Intern("arbace.classes.analyze$branching_tail_QMARK_")

var Lit_934 *jrt.String = jrt.Intern("arbace.classes.analyze$convert_node")

var Lit_935 *jrt.String = jrt.Intern("arbace.classes.analyze$operand")

var Lit_936 *jrt.String = jrt.Intern("arbace.classes.analyze$int_operand")

var Lit_937 *jrt.String = jrt.Intern("arbace.classes.analyze$fmod")

var Lit_938 *jrt.String = jrt.Intern("arbace.classes.analyze$fold_arith")

var Lit_939 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_arith")

var Lit_940 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_conversion")

var Lit_941 *jrt.String = jrt.Intern("arbace.classes.analyze$compare_type")

var Lit_942 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_compare")

var Lit_943 *jrt.String = jrt.Intern("arbace.classes.analyze$bool_node")

var Lit_944 *jrt.String = jrt.Intern("arbace.classes.analyze$lambda_form_QMARK_")

var Lit_945 *jrt.String = jrt.Intern("arbace.classes.analyze$local_type_anns")

var Lit_946 *jrt.String = jrt.Intern("arbace.classes.analyze$binding_type")

var Lit_947 *jrt.String = jrt.Intern("arbace.classes.analyze$bind_init")

var Lit_948 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_let")

var Lit_949 *jrt.String = jrt.Intern("arbace.classes.analyze$class_def_in_QMARK_")

var Lit_950 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_if")

var Lit_951 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_recur")

var Lit_952 *jrt.String = jrt.Intern("arbace.classes.analyze$expand_to_loop")

var Lit_953 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_label")

var Lit_954 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_break")

var Lit_955 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_return")

var Lit_956 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_throw")

var Lit_957 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try")

var Lit_958 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_locking")

var Lit_959 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_set_BANG_")

var Lit_960 *jrt.String = jrt.Intern("arbace.classes.analyze$applicable_QMARK_")

var Lit_961 *jrt.String = jrt.Intern("arbace.classes.analyze$more_specific_QMARK_")

var Lit_962 *jrt.String = jrt.Intern("arbace.classes.analyze$expand_varargs")

var Lit_963 *jrt.String = jrt.Intern("arbace.classes.analyze$param_tags_match_QMARK_")

var Lit_964 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_fi_method")

var Lit_965 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_arg_class")

var Lit_966 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_param_arg_match_QMARK_")

var Lit_967 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_subsumes_QMARK_")

var Lit_968 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_ret_assignable_QMARK_")

var Lit_969 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_matching_index")

var Lit_970 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_type_string")

var Lit_971 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_select")

var Lit_972 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method")

var Lit_973 *jrt.String = jrt.Intern("arbace.classes.analyze$instance_candidates")

var Lit_974 *jrt.String = jrt.Intern("arbace.classes.analyze$static_candidates")

var Lit_975 *jrt.String = jrt.Intern("arbace.classes.analyze$ctor_candidates")

var Lit_976 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_arg_convert")

var Lit_977 *jrt.String = jrt.Intern("kn8,arglistsyn1,myn4,argsyn8,varargs?kn3,dockn4,linekn6,columnkn4,filekn7,privateyn11,static-typeyn4,actxyn4,kindyn10,owner-descyn6,targetyn4,whatyn3,whyyn5,nodesyn5,owneryn5,mnameyn4,descyn9,arg-nodesyn1,eyn1,fyn7,reflectkn8,declaredyn1,&kn4,keysyn7,specialyn10,param-tagsyn14,owner-overrideyn7,ret-tagyn9,type-argskn2,asyn4,optsyn2,cnyn2,tnyn5,fnameyn1,kyn4,formyn5,formsyn1,_yn6,memberyn5,outeryn5,tdescyn3,clsyn1,ayn4,idxsyn6,a-nodeyn4,moreyn1,xyn4,nodeyn2,toyn1,vyn3,copyn5,fnodeyn6,switchyn11,method-ref*yn7,deftypeyn8,letclassyn2,fnyn6,class*yn10,method-refyn6,lambdayn3,newyn8,deftype*yn3,fn*yn5,letfnyn4,anonyn9,defrecordyn7,lambda*yn7,switch*yn5,scopeyn7,lenientyn10,field-inityn1,nyn7,static?yn6,boundsyn11,method-infoyn3,retyn4,headyn5,sactxyn4,envsyn1,cyn5,namesyn4,fromyn10,super-formyn7,membersyn5,specsyn4,bodyyn5,ectoryn1,tyn1,dyn3,msgv22,arbace.classes.analyze12,convert-argsm10,R0,L1,V3,R1,R2,R3,R4,s191,Converts argument nodes to the parameter types of method m (packing variable arity\n  arguments into an array); as Clojure converts them when m was chosen for Clojure's code\n  (:clojure-args).R5,i2206,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,qualifying-ownerm12,R8,TR0,L1,V2,R9,R1,R4,s107,JLS 13.1: the class named in the instruction is the receiver's static type, except for\n  members of Object.R5,i2221,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,invoke-nodem8,R0,L1,V7,R10,R11,R12,R1,R13,R2,R3,R5,i2235,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze22,signature-polymorphic?m12,R8,TR0,L1,V1,R1,R4,s88,JVMS 2.9.3: a native variable arity method of MethodHandle or VarHandle taking Object[].R5,i2246,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze8,reflect?m12,R8,TR0,L1,V1,R10,R4,s241,Does a call the compiler cannot resolve go through arbace.lang.Reflector? With\n  ^{:reflection :warn} on the class (SPEC §12 question 7), and in the code of fns that\n  arbace.lang.Compiler hands over (^{:reflection :clojure}), as in Clojure.R5,i2254,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze18,reflection-warningm10,R8,TR0,L1,V3,R10,R14,R15,R5,i2261,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze7,objectsm10,R8,TR0,L1,V1,R16,R5,i2267,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,reflective-nodem10,R8,TR0,L1,V4,R17,R18,R19,R2,R5,i2270,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,reflective-callm12,R8,TR0,L1,V5,R10,R13,R18,R20,R15,R4,s64,A call through arbace.lang.Reflector at run time (see reflect?).R5,i2274,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,unresolved?m12,R8,TR0,L1,V1,R21,R4,s79,Is e the compiler's failure to resolve a member (so that reflection may apply)?R5,i2285,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,or-reflectm12,R8,TR0,L1,V3,R10,R22,R23,R4,s84,f's node, or when reflection applies and f fails to resolve a member, (reflect why).R5,i2292,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,type-arg-annsm8,R24,TR5,i2301,R6,i1,R7,s25,arbace/classes/analyze.aem8,R24,TR5,i2301,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze19,analyze-method-callm10,R0,L1,V6,R10,R13,R18,R2,R25,m4,R26,V5,R27,R28,R29,R30,R31,R32,R33,R4,s63,(.name target args) where target is a node of static type `tt`.R5,i2303,R6,i1,R7,s25,arbace/classes/analyze.aem8,R0,L1,V6,R10,R13,R18,R2,R25,m2,R26,V5,R27,R28,R29,R30,R20,R5,i2318,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,clj-convertm8,R24,TR5,i2346,R6,i1,R7,s25,arbace/classes/analyze.aem8,R24,TR5,i2346,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze19,analyze-static-callm8,R0,L1,V6,R10,R34,R18,R2,R25,m2,R26,V1,R28,R5,i2348,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze21,analyze-field-access*m8,R24,TR5,i2374,R6,i1,R7,s25,arbace/classes/analyze.aem10,R0,L2,V3,R10,R35,R36,V4,R10,R35,R36,R37,R4,s85,Field `fname` of target node; k is called with the field and owner (default: a read).R5,i2376,R6,i1,R7,s25,arbace/classes/analyze.aem10,R8,TR0,L1,V4,R10,R35,R36,R37,R5,i2388,R6,i1,R7,s25,arbace/classes/analyze.aem10,R8,TR0,L1,V1,R10,R5,i2416,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,receiver-classm12,R8,TR0,L1,V2,R10,R38,R4,s55,If form names a class (not a local), its internal name.R5,i2421,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,analyze-dot*m8,R24,TR5,i2428,R6,i1,R7,s25,arbace/classes/analyze.aem12,R8,TR0,L1,V2,R10,R39,R4,s139,Type annotations of explicit type arguments (^{:type-args [types]} on a method symbol, SPEC\n  §8.4): [[index [[path annotation] ...]] ...].R5,i2430,R6,i1,R7,s25,arbace/classes/analyze.aem10,R0,L1,V2,R10,V5,R40,R13,R41,R32,R38,R4,s53,(. target member args*) and (. target (member args*))R5,i2436,R6,i1,R7,s25,arbace/classes/analyze.aem10,R8,TR0,L1,V2,R10,V7,R40,R13,R41,R25,R2,R32,R38,R5,i2445,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze18,outer-instance-form8,R24,TR5,i2518,R6,i1,R7,s25,arbace/classes/analyze.aem10,R0,L1,V6,R10,R34,R2,R11,R25,m2,R26,V3,R42,R28,R20,R4,s72,A call of constructor of class cn with args; kind :new, :super or :this.R5,i2520,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,array-newm10,R8,TR0,L1,V3,R10,R43,R2,R5,i2534,R6,i1,R7,s25,arbace/classes/analyze.aem10,R8,TR0,L1,V1,R34,R5,i2546,R6,i1,R7,s25,arbace/classes/analyze.aem10,R0,L1,V2,R10,R34,R4,s65,The implicit outer instance node for creating class cn from actx.R5,i2550,R6,i1,R7,s25,arbace/classes/analyze.aem8,R0,L1,V2,R10,V4,R40,R44,R25,R2,R5,i2566,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,analyze-agetm10,R8,TR0,L1,V3,R10,V4,R40,R45,R25,R46,R47,R5,i2606,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,analyze-asetm10,R8,TR0,L1,V3,R10,V4,R40,R45,R25,R48,R47,R5,i2613,R6,i1,R7,s25,arbace/classes/analyze.aem10,R0,L1,V2,R10,R38,R4,s88,Type annotations of a type form in code, for the instruction it types: [[path ann] ...].R5,i2626,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze17,analyze-instance?m10,R8,TR0,L1,V2,R10,V3,R40,R44,R49,R5,i2633,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,analyze-castm10,R8,TR0,L1,V2,R10,V3,R40,R44,R49,R5,i2640,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze8,ref-nodem10,R8,TR0,L1,V3,R10,R49,R14,R5,i2655,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,analyze-anonm8,R24,TR5,i2662,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,analyze-letclassm8,R24,TR5,i2662,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze17,analyze-ctor-callm8,R24,TR5,i2662,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,analyze-java-strm8,R24,TR5,i2662,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze19,analyze-java-assertm8,R24,TR5,i2662,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze22,analyze-with-resourcesm8,R24,TR5,i2662,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,analyze-for-eachm8,R24,TR5,i2662,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,analyze-switchm8,R24,TR5,i2662,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,analyze-lambdam8,R24,TR5,i2662,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze18,analyze-method-refm8,R24,TR5,i2662,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze19,analyze-if-instancem8,R24,TR5,i2662,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,method-sugarm12,R8,TR0,L1,V2,R10,R38,R4,s46,Clojure's interop sugar as a `.` form, or nil.R5,i2666,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,analyze-fn-callm8,R24,TR5,i2698,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,var-invoke-nodem8,R24,TR5,i2698,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze19,analyze-clj-specialm8,R24,TR5,i2698,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,specializedm12,R8,TR0,L1,V1,R22,R4,s83,The node of f, or nil when f fails to compile (the Clojure operation then applies).R5,i2700,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,with-node-localsm8,R24,TR5,i2707,R6,i1,R7,s25,arbace/classes/analyze.aem10,R0,L1,V4,R10,R50,R51,R14,R4,s173,convert-node; in Clojure code (§5.13) a value that no assignment conversion gives the\n  primitive type `to` is converted by RT's longCast, intCast... as Clojure converts it.R5,i2709,R6,i1,R7,s25,arbace/classes/analyze.aem12,R8,TR0,L1,V3,R10,R16,R22,R4,s88,Analyzes (f syms) with the symbols bound to the already analyzed nodes, in order: a let.R5,i2727,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,clj-call-nodem12,R8,TR0,L1,V3,R10,R52,R16,R4,s165,A call of the function of var v on the analyzed argument nodes, as Clojure compiles it: its\n  :inline expansion if it has one for this arity, else a call of the var.R5,i2739,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,core-op-nodem12,R8,TR0,L1,V3,R10,R38,R53,R4,s165,A call of the core var named cop: an instruction where its operands allow (§5.4, §5.5),\n  else a call as Clojure compiles it (§5.13). Each argument is analyzed once.R5,i2750,R6,i1,R7,s25,arbace/classes/analyze.aem8,R0,L1,V2,R10,R38,R5,i2859,R6,i1,R7,s25,arbace/classes/analyze.aem10,R0,L1,V3,R10,R52,R16,R4,s56,A call of the function in var v with the argument nodes.R5,i2938,R6,i1,R7,s25,arbace/classes/analyze.aem10,R0,L1,V5,R10,R54,R2,R25,V1,R20,R4,s63,(f args*) where f is the node of any value: IFn.invoke (§5.13).R5,i2948,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,expand-fullym12,R8,TR0,L1,V2,R10,R38,R4,s45,Macroexpands form until its head is no macro.R5,i2961,R6,i1,R7,s25,arbace/classes/analyze.aem10,R0,L1,V2,R10,R38,R4,s214,Clojure's fn*, letfn*, case*, def, var, reify*, deftype* and import* in code compiled by the\n  Java forms compiler, rewritten by arbace.classes.lower (§5.13, §9.5), or (deftype*) compiled\n  by arbace.lang.Compiler.R5,i2968,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze18,non-constant-headsS16,R55,R56,R57,R58,R59,R60,R61,R62,R63,R64,R65,R66,R67,R68,R69,R70,m8,R8,TR5,i3015,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,may-be-constant?m12,R8,TR0,L1,V1,R38,R4,s162,Can form be a constant expression? Those declaring classes or lambdas cannot, and analyzing\n  them would declare those (an anonymous class number would be taken).R5,i3019,R6,i1,R7,s25,arbace/classes/analyze.aem10,R0,L3,V3,R71,R38,R19,V4,R71,R38,R19,R72,V5,R71,R38,R19,R72,R73,R4,s86,Analyzes a form expected to be a constant of type desc; returns the const node or nil.R5,i3028,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,creation-actxm10,R8,TR0,L1,V1,R74,R5,i3049,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,body-actxm12,R8,TR0,L1,V6,R74,R11,R75,R76,R77,R78,R4,s41,The analysis context for code of class n.R5,i3056,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,bind-paramsm12,R8,TR0,L1,V3,R10,R74,R1,R4,s72,Binds the receiver (unless static) and the parameters of method entry m.R5,i3071,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze19,analyze-method-bodym10,R8,TR0,L1,V2,R74,R1,R5,i3085,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,ctor-call-form?m10,R8,TR0,L1,V1,R22,R5,i3093,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze17,nested-ctor-call?m12,R8,TR0,L1,V1,R22,R4,s87,Is the constructor call in form f at the statement level of (nested) let and do bodies?R5,i3095,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze19,implicit-super-callm10,R8,TR0,L1,V2,R10,R74,R5,i3105,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze18,analyze-ctor-call*m8,R24,TR5,i3120,R6,i1,R7,s25,arbace/classes/analyze.aem10,R0,L1,V3,R10,R38,R11,R4,s206,(super. args) or (this. args); param-tags on the head pin the constructor (§4.7). In a\n  constructor whose call is nested in the prologue's let forms (:ctor-phase), the code after\n  it is past the prologue.R5,i3122,R6,i1,R7,s25,arbace/classes/analyze.aem10,R8,TR0,L1,V3,R10,V3,R79,R25,R2,R11,R5,i3133,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze17,analyze-ctor-bodym10,R8,TR0,L1,V2,R74,R1,R5,i3147,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze17,analyze-enum-bodym8,R24,TR5,i3191,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze22,analyze-enum-constantsm12,R8,TR0,L1,V2,R74,R80,R4,s64,The <clinit> nodes creating the constants of enum n and $VALUES.R5,i3193,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,analyze-class!m10,R0,L1,V1,R74,R4,s160,Analyzes all code of class n, in the textual order of its members (so anonymous classes are\n  numbered as javac numbers them). Results go to the class's :state.R5,i3217,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,class-genericsm12,R8,TR0,L1,V1,R74,R4,s112,Generic view of class n: {:tparams [sym] :supers [tnode] :methods [{:name :desc :params [tnode]\n  :bounds {}}]}.R5,i3285,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,supertype-envsm12,R8,TR0,L1,V1,R74,R4,s129,For every supertype S of class n: S -> substitution of S's type variables in n's terms (nil\n  for raw or non-generic supertypes).R5,i3316,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,erased-paramsm10,R8,TR0,L1,V4,R74,R81,R82,R1,R5,i3342,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,add-bridges!m10,R0,L1,V1,R74,R4,s372,Adds javac's bridge methods to class n (TransTypes.addBridgeIfNeeded): for each method meth\n  of a supertype whose implementation in n has another erasure, unless a bridge with meth's\n  erasure is already present at or below the implementation. Bridges of enclosing classes are\n  not yet present, as javac translates nested classes before adding the outer class's bridges.R5,i3354,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,supertypes-firstm12,R8,TR0,L1,V1,R83,R4,s72,Names ordered so that supertypes in the list come before their subtypes.R5,i3458,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze19,mark-enum-abstract!m12,R8,TR0,L1,V1,R74,R4,s120,An enum with constant bodies that leaves an interface method unimplemented is abstract\n  (javac's markAbstractIfNeeded).R5,i3471,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,process-classes!m10,R0,L1,V1,R84,R4,s123,Resolves headers and members of the classes declared since position `from` of the unit's\n  order, then analyzes their code.R5,i3492,R6,i1,R7,s25,arbace/classes/analyze.aem10,R0,L1,V2,R10,V6,R40,R40,R85,R2,R25,R86,R4,s144,(anon Super [args] member*) and (anon Inner [args] :outer o member*) (§4.8); param-tags on\n  the argument vector pin the superclass constructor.R5,i3505,R6,i1,R7,s25,arbace/classes/analyze.aem8,R0,L1,V2,R10,V5,R40,R40,R87,R25,R88,R5,i3592,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze7,not-yetm10,R8,TR0,L1,V1,R14,R5,i3611,R6,i1,R7,s25,arbace/classes/analyze.aem10,R0,L1,V4,R10,R74,R82,R89,R4,s159,The anonymous class E$n of an enum constant with a body; its constructor takes the enum\n  constructor's parameters (after name and ordinal) and passes them on.R5,i3613,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,const-stringm10,R0,L1,V2,R90,R52,R4,s39,Java's string conversion of a constant.R5,i3632,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze17,accessible-class?m10,R8,TR0,L1,V2,R10,R74,R5,i3642,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze19,sharpest-accessiblem10,R8,TR0,L1,V2,R10,R91,R5,i3647,R6,i1,R7,s25,arbace/classes/analyze.aem8,R0,L1,V2,R10,V3,R40,R25,R2,R5,i3656,R6,i1,R7,s25,arbace/classes/analyze.aev22,arbace.classes.analyze20,analyze-java-assert*m8,R24,TR5,i3682,R6,i1,R7,s25,arbace/classes/analyze.aem8,R0,L1,V2,R10,V5,R40,R82,R92,R32,R38,R5,i3684,R6,i1,R7,s25,arbace/classes/analyze.aem10,R8,TR0,L1,V3,R10,R34,V5,R40,R82,R92,R32,R38,R5,i3691,R6,i1,R7,s25,arbace/classes/analyze.ae")

var Lit_978 *jrt.String = jrt.Intern("arbace.classes.analyze$convert_args")

var Lit_979 *jrt.String = jrt.Intern("arbace.classes.analyze$qualifying_owner")

var Lit_980 *jrt.String = jrt.Intern("arbace.classes.analyze$invoke_node")

var Lit_981 *jrt.String = jrt.Intern("arbace.classes.analyze$signature_polymorphic_QMARK_")

var Lit_982 *jrt.String = jrt.Intern("arbace.classes.analyze$reflect_QMARK_")

var Lit_983 *jrt.String = jrt.Intern("arbace.classes.analyze$reflection_warning")

var Lit_984 *jrt.String = jrt.Intern("arbace.classes.analyze$objects")

var Lit_985 *jrt.String = jrt.Intern("arbace.classes.analyze$reflective_node")

var Lit_986 *jrt.String = jrt.Intern("arbace.classes.analyze$reflective_call")

var Lit_987 *jrt.String = jrt.Intern("arbace.classes.analyze$unresolved_QMARK_")

var Lit_988 *jrt.String = jrt.Intern("arbace.classes.analyze$or_reflect")

var Lit_989 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_call")

var Lit_990 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_call_STAR_")

var Lit_991 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_static_call")

var Lit_992 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_field_access")

var Lit_993 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_field_access_STAR_")

var Lit_994 *jrt.String = jrt.Intern("arbace.classes.analyze$super_node")

var Lit_995 *jrt.String = jrt.Intern("arbace.classes.analyze$receiver_class")

var Lit_996 *jrt.String = jrt.Intern("arbace.classes.analyze$type_arg_anns")

var Lit_997 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_dot")

var Lit_998 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_dot_STAR_")

var Lit_999 *jrt.String = jrt.Intern("arbace.classes.analyze$ctor_call_node")

var Lit_1000 *jrt.String = jrt.Intern("arbace.classes.analyze$array_new")

var Lit_1001 *jrt.String = jrt.Intern("arbace.classes.analyze$needs_outer_instance_QMARK_")

var Lit_1002 *jrt.String = jrt.Intern("arbace.classes.analyze$outer_instance_for")

var Lit_1003 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_new")

var Lit_1004 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_aget")

var Lit_1005 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_aset")

var Lit_1006 *jrt.String = jrt.Intern("arbace.classes.analyze$code_type_anns")

var Lit_1007 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_instance_QMARK_")

var Lit_1008 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_cast")

var Lit_1009 *jrt.String = jrt.Intern("arbace.classes.analyze$ref_node")

var Lit_1010 *jrt.String = jrt.Intern("arbace.classes.analyze$method_sugar")

var Lit_1011 *jrt.String = jrt.Intern("arbace.classes.analyze$specialized")

var Lit_1012 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_convert")

var Lit_1013 *jrt.String = jrt.Intern("arbace.classes.analyze$with_node_locals")

var Lit_1014 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_call_node")

var Lit_1015 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node")

var Lit_1016 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_op")

var Lit_1017 *jrt.String = jrt.Intern("arbace.classes.analyze$var_invoke_node")

var Lit_1018 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_fn_call")

var Lit_1019 *jrt.String = jrt.Intern("arbace.classes.analyze$expand_fully")

var Lit_1020 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_clj_special")

var Lit_1021 *jrt.String = jrt.Intern("arbace.classes.analyze$may_be_constant_QMARK_")

var Lit_1022 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_const_form")

var Lit_1023 *jrt.String = jrt.Intern("arbace.classes.analyze$creation_actx")

var Lit_1024 *jrt.String = jrt.Intern("arbace.classes.analyze$body_actx")

var Lit_1025 *jrt.String = jrt.Intern("arbace.classes.analyze$bind_params")

var Lit_1026 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_body")

var Lit_1027 *jrt.String = jrt.Intern("arbace.classes.analyze$ctor_call_form_QMARK_")

var Lit_1028 *jrt.String = jrt.Intern("arbace.classes.analyze$nested_ctor_call_QMARK_")

var Lit_1029 *jrt.String = jrt.Intern("arbace.classes.analyze$implicit_super_call")

var Lit_1030 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_ctor_call")

var Lit_1031 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_ctor_call_STAR_")

var Lit_1032 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_ctor_body")

var Lit_1033 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants")

var Lit_1034 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_class_BANG_")

var Lit_1035 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics")

var Lit_1036 *jrt.String = jrt.Intern("arbace.classes.analyze$supertype_envs")

var Lit_1037 *jrt.String = jrt.Intern("arbace.classes.analyze$erased_params")

var Lit_1038 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_")

var Lit_1039 *jrt.String = jrt.Intern("arbace.classes.analyze$supertypes_first")

var Lit_1040 *jrt.String = jrt.Intern("arbace.classes.analyze$mark_enum_abstract_BANG_")

var Lit_1041 *jrt.String = jrt.Intern("arbace.classes.analyze$process_classes_BANG_")

var Lit_1042 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_anon")

var Lit_1043 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_letclass")

var Lit_1044 *jrt.String = jrt.Intern("arbace.classes.analyze$not_yet")

var Lit_1045 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_body")

var Lit_1046 *jrt.String = jrt.Intern("arbace.classes.analyze$const_string")

var Lit_1047 *jrt.String = jrt.Intern("arbace.classes.analyze$accessible_class_QMARK_")

var Lit_1048 *jrt.String = jrt.Intern("arbace.classes.analyze$sharpest_accessible")

var Lit_1049 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_str")

var Lit_1050 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_assert")

var Lit_1051 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_assert_STAR_")

var Lit_1052 *jrt.String = jrt.Intern("kn8,arglistsyn4,actxyn1,_yn3,symyn4,collkn2,asyn2,bvyn1,&yn4,bodykn4,linekn6,columnkn4,fileyn8,bindingskn7,privateyn1,nkn3,dockn8,declaredyn4,formyn3,finyn3,samyn8,boundaryyn2,fiyn6,paramsyn1,dyn2,psyn3,retyn7,call-fnyn2,cnyn1,myn4,moreyn2,stkn4,keysyn9,componentyn3,patyn1,xyn4,thenyn4,elseyn1,eyn1,cyn4,descyn3,selyn7,clausesyn3,urlyn2,nsyn1,fyn1,oyn4,codeyn6,targetyn4,nodeyn5,mnameyn4,argsyn10,param-tagsyn1,kyn4,inityn1,vyn5,fnameyn5,elemsm8,R0,L1,V2,R1,V4,R2,V4,R3,R4,R5,R6,R7,R8,R9,i3710,R10,i1,R11,s25,arbace/classes/analyze.aem8,R0,L1,V2,R1,V4,R2,R12,R7,R8,R9,i3749,R10,i1,R11,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,object-methodsS3,s10,hashCode()s10,toString()s26,equals(Ljava/lang/Object;)m8,R13,TR9,i3788,R10,i1,R11,s25,arbace/classes/analyze.aem10,R0,L1,V1,R14,R15,s68,The single abstract method of functional interface n: {:name :desc}.R9,i3790,R10,i1,R11,s25,arbace/classes/analyze.aev22,arbace.classes.analyze20,lambda-method-prefixm8,R16,TR9,i3811,R10,i1,R11,s25,arbace/classes/analyze.aev22,arbace.classes.analyze8,fi-typesm12,R13,TR0,L1,V2,R1,R17,R15,s146,[main-interface markers serializable? intersection] of a lambda's target type form. Serializable\n  is no marker: it makes the lambda serializable.R9,i3813,R10,i1,R11,s25,arbace/classes/analyze.aev22,arbace.classes.analyze19,serial-lambda-name!m12,R13,TR0,L1,V4,R1,R18,R19,R20,R15,s175,javac's name for a serializable lambda: a hash of the enclosing method's signature, the\n  functional interface, the variable assigned and the captured locals (LambdaToMethod).R9,i3823,R10,i1,R11,s25,arbace/classes/analyze.aem10,R13,TR0,L1,V1,R1,R9,i3839,R10,i1,R11,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,lambda-name!m10,R13,TR0,L1,V1,R1,R9,i3849,R10,i1,R11,s25,arbace/classes/analyze.aem8,R0,L1,V2,R1,V5,R2,R21,R22,R7,R8,R9,i3856,R10,i1,R11,s25,arbace/classes/analyze.aev22,arbace.classes.analyze8,arg-stubm10,R13,TR0,L1,V1,R23,R9,i3888,R10,i1,R11,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,ref-as-lambdam12,R13,TR0,L1,V5,R1,R21,R24,R25,R26,R15,s138,javac makes a lambda method for references it cannot express as a method handle (variable\n  arity adaptation): the equivalent lambda form.R9,i3890,R10,i1,R11,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,ref-ownerm12,R13,TR0,L1,V2,R27,R28,R15,s182,The class a method reference's handle names: the declaring class, except that Object's\n  methods referenced through an interface are named by the interface (javac's binaryQualifier).R9,i3898,R10,i1,R11,s25,arbace/classes/analyze.aem8,R0,L1,V2,R1,V6,R2,R21,R7,R29,R5,R17,R9,i3904,R10,i1,R11,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,enum-class?m10,R13,TR0,L1,V1,R23,R9,i3999,R10,i1,R11,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,analyze-patternm10,R0,L1,V5,R1,R17,R30,R7,m2,R31,V1,R32,R15,s96,Analyzes a pattern form against a value of static type st. Returns [pattern actx-with-bindings].R9,i4002,R10,i1,R11,s25,arbace/classes/analyze.aem8,R0,L1,V2,R1,V6,R2,V4,R33,R34,R5,R6,R35,R36,R5,R17,R9,i4044,R10,i1,R11,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,switch-map!m12,R13,TR0,L1,V3,R1,R37,R38,R15,s112,Registers a use of enum constant `c` of enum e in the outermost class's $SwitchMap$; returns\n  its mapped value.R9,i4057,R10,i1,R11,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,constant-labelm10,R13,TR0,L1,V3,R1,R17,R39,R9,i4071,R10,i1,R11,s25,arbace/classes/analyze.aem8,R0,L1,V2,R1,V4,R2,R40,R7,R41,R9,i4079,R10,i1,R11,s25,arbace/classes/analyze.aev22,arbace.classes.analyze17,read-source-formsm10,R13,TR0,L1,V1,R42,R9,i4164,R10,i1,R11,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,import-classes!m10,R0,L1,V2,R43,R17,R15,s416,Imports the classes of an (import ...) form into namespace ns, without evaluating code (which\n  the frozen compiler would compile into ns's package, prohibited for java.*). Classes not on the\n  class path or compiled from source (env/*from-source*) go into env/source-imports, as their\n  sources are found by name (§9.2). Returns the class names that could not be imported (a name\n  already mapped to another class).R9,i4170,R10,i1,R11,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,eval-ns-form!m10,R0,L1,V1,R44,R15,s89,Evaluates a namespace form of a Java forms file: in-ns and import without compiling code.R9,i4192,R10,i1,R11,s25,arbace/classes/analyze.aem10,R0,L1,V1,R14,R15,s269,Looks up the top-level class of internal name n as a source p/C.ae on the class path. Its\n  namespace and import forms are evaluated and its Java forms entered as declarations only\n  (headers and members), so code being compiled can refer to them. Returns n when found.R9,i4202,R10,i1,R11,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,add-accessor!m12,R13,TR0,L1,V4,R45,R46,R39,R47,R15,s383,Registers an accessor of class o and, as data, the one member instruction it holds, target\n  {:insn :owner :name :desc :itf} (:insn :getfield, :putfield, :getstatic, :putstatic,\n  :invokevirtual, :invokestatic or :invokespecial: what j2g reads, arbace.j2g.access); returns\n  its name. (The JVM's back end also wrote the accessor's bytecode; it is on the branch\n  arbace-for-java-26.)R9,i4262,R10,i1,R11,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,accessor-ownerm12,R13,TR0,L1,V4,R1,R28,R7,V1,R47,R15,s250,The enclosing class of the current class through which protected member m is accessible,\n  when the current class itself cannot access it; else nil (javac's needsProtectedAccess and\n  accessClass). `target` is the receiver node of an instance member.R9,i4274,R10,i1,R11,s25,arbace/classes/analyze.aem10,R0,L1,V2,R1,R48,R15,s71,Rewrites a member access that needs a javac accessor into a call of it.R9,i4296,R10,i1,R11,s25,arbace/classes/analyze.aem10,R0,L1,V5,R1,R45,R49,R50,R51,R15,s90,(.m Outer/super args) from a nested class or lambda: javac's access$N01 accessor in Outer.R9,i4335,R10,i1,R11,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,constant-field!m12,R13,TR0,L1,V4,R1,R52,R39,R53,R15,s524,A static field of the current class holding a Clojure constant: returns {:owner :name :desc}.\n  The class's state keeps them in :clj-consts, a vector of [k field] in the order made (const__0,\n  const__1, ...: what <clinit> and the fields' declarations iterate), and :clj-const-index, k to\n  field. (A map from k iterated in its keys' hash order once past eight entries, and a var's\n  hash is its identity's: j2g's <clinit> of a deftype with many constants varied from run to run;\n  2026-10-17, doc/FUTAMURA-SURVEY.md, F2.2.)R9,i4357,R10,i1,R11,s25,arbace/classes/analyze.aem10,R0,L1,V2,R1,R54,R15,s76,A keyword or quoted datum as a constant node (read at class initialization).R9,i4374,R10,i1,R11,s25,arbace/classes/analyze.aem8,R0,L1,V2,R1,R54,R9,i4383,R10,i1,R11,s25,arbace/classes/analyze.aem10,R0,L1,V4,R1,R55,R39,R56,R15,s89,A collection literal: built by arbace.lang.RT/vector, map or set from its boxed elements.R9,i4387,R10,i1,R11,s25,arbace/classes/analyze.ae")

var Lit_1053 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_for_each")

var Lit_1054 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_with_resources")

var Lit_1055 *jrt.String = jrt.Intern("arbace.classes.analyze$find_sam")

var Lit_1056 *jrt.String = jrt.Intern("arbace.classes.analyze$fi_types")

var Lit_1057 *jrt.String = jrt.Intern("arbace.classes.analyze$serial_lambda_name_BANG_")

var Lit_1058 *jrt.String = jrt.Intern("arbace.classes.analyze$lambda_method_prefix")

var Lit_1059 *jrt.String = jrt.Intern("arbace.classes.analyze$lambda_name_BANG_")

var Lit_1060 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_lambda")

var Lit_1061 *jrt.String = jrt.Intern("arbace.classes.analyze$arg_stub")

var Lit_1062 *jrt.String = jrt.Intern("arbace.classes.analyze$ref_as_lambda")

var Lit_1063 *jrt.String = jrt.Intern("arbace.classes.analyze$ref_owner")

var Lit_1064 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref")

var Lit_1065 *jrt.String = jrt.Intern("arbace.classes.analyze$enum_class_QMARK_")

var Lit_1066 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_pattern")

var Lit_1067 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_if_instance")

var Lit_1068 *jrt.String = jrt.Intern("arbace.classes.analyze$switch_map_BANG_")

var Lit_1069 *jrt.String = jrt.Intern("arbace.classes.analyze$constant_label")

var Lit_1070 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch")

var Lit_1071 *jrt.String = jrt.Intern("arbace.classes.analyze$read_source_forms")

var Lit_1072 *jrt.String = jrt.Intern("arbace.classes.analyze$import_classes_BANG_")

var Lit_1073 *jrt.String = jrt.Intern("arbace.classes.analyze$eval_ns_form_BANG_")

var Lit_1074 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_")

var Lit_1075 *jrt.String = jrt.Intern("arbace.classes.analyze$add_accessor_BANG_")

var Lit_1076 *jrt.String = jrt.Intern("arbace.classes.analyze$accessor_owner")

var Lit_1077 *jrt.String = jrt.Intern("arbace.classes.analyze$accessorize")

var Lit_1078 *jrt.String = jrt.Intern("arbace.classes.analyze$outer_super_call")

var Lit_1079 *jrt.String = jrt.Intern("arbace.classes.analyze$constant_field_BANG_")

var Lit_1080 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_constant")

var Lit_1081 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_var_field")

var Lit_1082 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_collection")
