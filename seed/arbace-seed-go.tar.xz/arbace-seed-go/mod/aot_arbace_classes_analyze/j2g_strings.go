//line j2g_strings.ae:1
package aot_arbace_classes_analyze

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn20,arbace.classes.typesyn1,tyn18,arbace.classes.envyn3,envyn20,arbace.classes.parseyn1,pyn20,arbace.classes.loweryn5,loweryn22,arbace.classes.opcodesyn7,Opcodesyn17,arbace.classes.goyn13,TypeReferenceyn11,arbace.corekn3,docks6,arbace13,compile-errorkn5,statekn5,flagskn15,outer-instance?kn5,outerkn4,namekn6,fieldskn3,symkn4,desckn11,super-outerkn4,enumkn4,kindkn9,enum-bodykn4,anonkn5,localkn4,typekn8,captureskn7,nestingkn2,nskn4,elsekn13,local-classeskn5,classkn14,member-classeskn6,simplekn7,resolvekn5,tvarskn6,boundskn14,implicit-outerkn7,tparamskn4,optskn11,type-paramskn1,tkn4,argskn4,tvarkn4,metakn9,retentionkn7,methodskn5,arraykn10,annotationkn6,valueskn5,valuekn6,nestedkn5,constkn7,targetskn3,refkn4,pathkn4,annskn6,sourcekn7,visiblekn7,runtimekn11,has-defaultkn5,scopekn7,defaultkn7,packagekn8,counterskn3,topkn6,memberkn7,static?kn9,interfacekn14,static-contextkn15,creation-boundskn16,enclosing-methodkn9,nest-hostkn10,uses-this0kn7,lambdaskn5,extrakn8,anon-ctxkn5,orderkn6,parsedkn4,formkn14,parsed-memberskn7,memberskn10,own-boundskn7,extendskn10,implementskn10,anon-superkn6,recordkn12,headers-donekn5,superkn10,interfaceskn7,super-tkn12,interfaces-tkn9,signaturekn7,permitskn11,annotationskn16,type-annotationskn10,deprecatedkn3,tagyn16,java.lang.Objectkn2,tnkn5,finalkn5,ownerkn9,bridge-ofkn14,clojure-bridgekn7,derivedkn6,bridgekn6,throwskn3,retkn6,paramskn6,statickn5,vmetakn14,clojure-methodkn4,primkn7,privatekn8,has-bodykn7,varargskn4,recvkn6,ret-tnkn3,sigkn17,param-annotationskn6,methodkn11,inner-flagskn6,publickn9,protectedkn9,synthetickn7,compactkn4,ctorkn8,has-initkn4,initkn3,valkn7,lenientkn10,field-initkn12,members-donekn5,fieldkn13,enum-constantkn9,constantskn17,enum-values-fieldyn1,&kn10,componentskn9,componentkn15,record-accessorkn20,record-object-methodkn9,canonicalkn16,record-canonicalkn14,anon-ctor-desckn11,in-progresskn11,enum-valueskn12,enum-valueOfkn7,mparamskn12,enum-$valueskn15,anon-super-ctorkn9,anon-ctorkn12,default-ctorkn2,opkn4,nullkn5,loosekn7,literalkn4,nonekn5,widenkn12,narrow-constkn3,boxkn5,unboxkn2,dokn2,ifkn4,thenkn6,switchkn7,patternkn4,bodykn5,caseskn3,trykn7,catcheskn3,letkn7,monitorkn5,labelkn6,breakskn6,targetkn2,idkn6,parentkn8,boundarykn13,ctor-prologuekn10,ctor-phasekn8,prologuekn5,framekn6,localskn6,lambdakn4,cvalkn8,receiverkn1,bkn8,capturedkn7,mutablekn11,outer-paramkn14,creation-framekn16,outer-param-pathkn4,basekn9,this-pathkn9,uses-thiskn5,macrokn4,linekn6,bigintkn11,array-clonekn7,cast-tokn10,array-initkn9,new-arraykn4,castkn4,exprkn10,statementskn10,get-statickn9,get-fieldkn10,const-onlykn13,const-classeskn7,clojurekn9,class-litkn8,declarerkn11,clojure-tagkn9,var-derefkn3,varkn10,unresolvedkn7,convertkn4,fromkn2,tokn6,invokekn7,no-castkn11,if-instancekn4,whatkn4,loopkn3,itfkn3,remkn3,subkn3,deckn3,mulkn3,divkn3,negkn4,ushrkn3,addkn3,inckn3,notkn2,orkn3,andkn3,shrkn3,xorkn3,shlkn6,andnotkn5,exactkn8,longbitskn5,floatkn4,longkn5,arithkn6,familykn1,okn3,intkn7,comparekn3,cmpkn11,pending-varkn10,loop-localkn9,type-annskn8,bindingsks14,arbace.classes7,fn-bodykn10,label-loopkn12,break-targetkn6,labelskn4,testkn5,recuryn9,for-each*yn5,loop*kn2,kwkn5,breakkn6,returnkn5,throwyn5,catchyn7,finallykn7,classeskn7,finallykn4,lockkn9,set-localkn10,set-statickn9,set-fieldyn1,.yn3,setyn3,varyn4,set!kn6,strictyn1,_kn9,fi-methodkn2,psks22,arbace.classes.analyze7,unknownks7,clojure10,no-reflectks7,clojure3,whykn12,clojure-argskn10,fi-adapterkn8,sam-namekn8,sam-desckn7,invokerkn12,invoker-desckn5,elemskn7,specialkn7,virtualkn4,warnkn10,reflectionkn10,param-tagskn14,owner-overridekn7,ret-tagkn9,type-argskn13,type-arg-annskn9,arg-nodeskn8,instancekn10,clj-inlinekn7,alengthkn12,null-checkedyn5,superkn7,in-ctorkn3,newkn13,creation-actxkn4,speckn9,ctor-callkn4,dimsyn5,arraykn4,agetkn5,indexkn4,asetkn9,instance?kn8,type-argyn3,newyn14,class-literal*ks22,arbace.classes.analyze18,qualified-instancekn6,inlinekn14,inline-aritieskn5,bool=ys11,arbace.core3,notys11,arbace.core1,=kn4,nil?kn10,identical?yn7,switch*yn15,with-resources*ys11,arbace.core7,import*yn2,doyn6,reify*yn9,java-str*yn5,case*yn3,tryyn6,super.yn6,label*yn6,break*yn5,this.kn4,thisyn13,monitor-enteryn7,lambda*yn5,throwyn6,letfn*yn6,class*yn9,continue*yn12,java-assert*yn2,ifyn5,quoteyn11,method-ref*yn12,monitor-exityn4,let*yn5,recuryn3,defyn3,fn*yn7,return*yn12,if-instance*yn8,deftype*kn10,var-invokeyn11,importClassys11,arbace.core4,castyn21,arbace.lang.Namespaceys14,arbace.lang.RT10,CURRENT_NSyn5,derefys14,arbace.lang.RT22,classForNameNonLoadingkn6,columnkn7,dynamickn10,class-initkn10,clojure-fnkn11,method-infokn5,slot0kn5,paramyn6,.superkn9,enum-argskn9,anon-argskn4,callkn11,nested-callkn13,outer-bindingkn11,calls-superkn14,compact-localskn10,enum-constkn7,ordinalkn8,analyzedyn4,thiskn3,midkn6,clinitkn6,bodieskn10,field-nameyn6,this__kn6,superskn8,genericskn12,bridges-donekn12,clojure-typekn10,impl-ownerkn13,declared-onlyyn4,anonkn7,diamondkn20,super-outer-is-outerkn16,super-outer-pathkn8,java-strkn8,operandskn9,tag-constkn4,nodekn5,eagerkn5,partskn6,assertkn3,msgkn10,holder-topkn8,msg-desckn16,interface-assertkn11,uses-assertkn14,assert-holderskn12,holder-firstkn3,arrkn3,lenkn1,ikn2,itkn8,for-eachkn4,collkn6,hiddenkn4,elemkn8,iteratoryn5,closeys11,arbace.core5,some?yn19,java.lang.Throwableyn13,addSuppressedkn14,normal-finallykn7,bridgeskn5,interkn5,typeskn15,lambda-counterskn10,ref-lambdakn10,method-refkn2,fikn7,markerskn12,serializablekn12,intersectionkn3,samkn9,inst-desckn12,lambda-nodeskn12,serial-nodesyn4,castkn14,qualifier-annskn9,qualifierkn5,boundkn10,null-checkkn7,unboundkn13,unconditionalkn17,record-componentskn8,accessorkn5,compskn4,tempkn11,switch-mapskn4,whenyn2,oryn10,identical?kn6,stringkn5,guardkn5,ctypekn3,selkn8,sel-typekn11,enum-directkn11,sel-bindingkn7,restartks22,arbace.classes.analyze3,eofkn3,eofkn9,read-condkn5,allowyn8,defclassys11,arbace.core5,in-nsyn5,in-nsyn2,nsyn6,importys11,arbace.core6,importkn12,source-triedkn12,access-countkn9,accessorskn4,insnkn9,putstatickn9,getstatickn8,putfieldkn8,getfieldkn12,invokestatickn13,invokevirtualkn13,invokespecialkn15,clj-const-indexkn10,clj-constskn4,readkn4,textv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,V3,R7,R1,R8,V3,R9,R1,R10,V3,R11,R1,R12,V3,R13,R1,R14,v11,arbace.core5,referR15,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn22,arbace.classes.analyzem2,R16,s300,Entering class declarations (names, supertypes, members, what javac derives) and analyzing\n  code into typed nodes (SPEC §4 to §6), which the Go build's interpreter\n  (arbace.classes.interp) runs and j2g translates. (The bytecode back end, arbace.classes.emit,\n  is on the branch arbace-for-java-26.)v11,arbace.core5,swap!v22,arbace.classes.analyze3,idsv11,arbace.core3,incv11,arbace.core7,ex-infov11,arbace.core5,assocR17,v22,arbace.classes.analyze4,failv18,arbace.classes.env13,*compile-set*v22,arbace.classes.analyze4,declv11,arbace.core5,applyv11,arbace.core6,updateR18,v22,arbace.classes.analyze5,decl!v11,arbace.core3,notl0,v22,arbace.classes.analyze4,has?R19,i8,v18,arbace.classes.env9,nest-hostv18,arbace.classes.env4,infoR20,v22,arbace.classes.analyze11,outer-levelR21,v11,arbace.core3,setv11,arbace.core3,mapR22,R23,R24,v11,arbace.core9,contains?v20,arbace.classes.types17,parse-method-descR25,v20,arbace.classes.types11,method-descv11,arbace.core4,consv20,arbace.classes.types14,internal->descv11,arbace.core6,concatR26,R27,R28,R29,V2,s18,Ljava/lang/String;s1,IS2,R30,R31,R32,R33,R34,v13,arbace.string7,replacev11,arbace.core5,mungev11,arbace.core4,namev11,arbace.core7,ns-namev18,arbace.classes.env6,known?v22,arbace.classes.analyze15,*source-lookup*v22,arbace.classes.analyze6,*unit*v22,arbace.classes.analyze18,enter-from-source!v11,arbace.core7,symbol?v11,arbace.core9,namespaceR35,v13,arbace.string9,includes?v13,arbace.string12,starts-with?v11,arbace.core6,ns-mapv11,arbace.core6,class?v11,arbace.core6,get-inv18,arbace.classes.env14,source-importsv22,arbace.classes.analyze13,class-exists?v13,arbace.string5,splitp2,\\$l2,v22,arbace.classes.analyze17,resolve-class-symv11,arbace.core6,symbolR36,R37,R38,v11,arbace.core4,not=R39,R40,R30,v22,arbace.classes.analyze15,default-import?v18,arbace.classes.env12,from-source?v20,arbace.classes.types10,package-ofv22,arbace.classes.analyze10,ns-packageR41,R42,v11,arbace.core4,keysR43,R44,v22,arbace.classes.analyze14,implicit-outerv11,arbace.core4,mapvR45,v11,arbace.core5,firstV2,R46,R47,v18,arbace.classes.env9,reflectedv18,arbace.classes.env10,load-classv17,arbace.classes.go9,go-build?v17,arbace.classes.go8,genericsv22,arbace.classes.analyze13,class-tparamsv11,arbace.core3,seqv11,arbace.core6,every?R48,R49,R50,v20,arbace.classes.types10,parse-typev22,arbace.classes.analyze10,type-scopev20,arbace.classes.types5,erasev22,arbace.classes.analyze5,erasev22,arbace.classes.analyze10,parse-typev11,arbace.core4,somev22,arbace.classes.analyze11,class-scopeR51,v11,arbace.core7,keywordv13,arbace.string10,lower-caseR52,C30,java.lang.annotation.Retentionv11,arbace.core3,strv11,arbace.core4,subsR53,v18,arbace.classes.env5,info!v20,arbace.classes.types6,array?R54,v22,arbace.classes.analyze9,ann-valuev20,arbace.classes.types9,elem-typev11,arbace.core7,vector?v11,arbace.core4,seq?R55,v11,arbace.core6,secondR56,v11,arbace.core4,intov11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv22,arbace.classes.analyze12,element-typev11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,restv11,arbace.core4,map?R57,R58,v11,arbace.core10,re-matchesp5,[0-9]v18,arbace.classes.env10,interface?m18,s4,Bytes1,Bs6,Doubles1,Ds4,Voids1,Vs5,Shorts1,Ss9,Characters1,Cs7,Integers1,Is4,Longs1,Js5,Floats1,Fs7,Booleans1,Zv22,arbace.classes.analyze9,type-descv20,arbace.classes.types11,class-desc?v20,arbace.classes.types11,string-descv20,arbace.classes.types14,desc->internali16384,v22,arbace.classes.analyze18,analyze-const-formR59,p13,^java\\.lang\\.v22,arbace.classes.analyze15,annotations-nowR60,C27,java.lang.annotation.Targetv11,arbace.core3,vecv11,arbace.core6,filterv22,arbace.classes.analyze18,annotation-targetsv11,arbace.core5,forcev22,arbace.classes.analyze9,*lenient*R61,R62,v20,arbace.classes.types12,element-pathv20,arbace.classes.types9,type-annsv11,arbace.core11,map-indexedv11,arbace.core4,nextv11,arbace.core8,to-arrayR63,v17,arbace.classes.go25,newTypeParameterReferencev17,arbace.classes.go20,CLASS_TYPE_PARAMETERv17,arbace.classes.go21,METHOD_TYPE_PARAMETERv11,arbace.core4,compv11,arbace.core3,keyv22,arbace.classes.analyze16,type-annotationsv17,arbace.classes.go30,newTypeParameterBoundReferencev17,arbace.classes.go26,CLASS_TYPE_PARAMETER_BOUNDv17,arbace.classes.go27,METHOD_TYPE_PARAMETER_BOUNDv22,arbace.classes.analyze9,retentionR64,R65,R66,v11,arbace.core5,true?v22,arbace.classes.analyze14,annotation-nowR67,R68,R69,V2,R46,R70,v11,arbace.core5,some?R71,v11,arbace.core4,fnilR72,v22,arbace.classes.analyze8,top-nameR73,R74,S2,R75,R55,R76,v11,arbace.core5,mergeR77,R78,R79,v11,arbace.core4,atomR80,R81,R82,R83,R84,v11,arbace.core5,doallR85,v20,arbace.classes.parse11,parse-classR86,v22,arbace.classes.analyze14,declare-class!R87,R88,v11,arbace.core6,repeatv22,arbace.classes.analyze12,update-decl!S2,R30,R31,R89,v22,arbace.classes.analyze15,bounds-of-scopeV2,R46,R47,v22,arbace.classes.analyze15,set-own-bounds!v11,arbace.core6,zipmapv20,arbace.classes.types17,parse-type-paramsV2,R46,R47,v20,arbace.classes.types10,bounds-mapV2,R46,R90,V2,R46,R91,R92,R93,v20,arbace.classes.types8,generic?v20,arbace.classes.types21,type-params-signaturev20,arbace.classes.types9,signatureR75,R94,R95,R96,R97,R98,R99,R100,V2,R46,R100,R101,v22,arbace.classes.analyze16,decl-annotationsR102,v22,arbace.classes.analyze23,tparam-type-annotationsS2,R75,R55,v17,arbace.classes.go21,newSuperTypeReferencel-1,i16,R103,S2,s20,java.lang.Deprecateds10,Deprecatedi131072,S2,R75,R55,R104,v22,arbace.classes.analyze6,tag-ofR105,R106,R107,v11,arbace.core8,distinctv18,arbace.classes.env14,all-supertypesS2,s6,<init>s8,<clinit>R108,S2,s6,<init>s8,<clinit>v11,arbace.core4,valsv11,arbace.core6,reducev20,arbace.classes.types4,ref?v18,arbace.classes.env11,assignable?v11,arbace.core9,array-mapv22,arbace.classes.analyze22,clojure-implementablesR109,R110,R111,R112,R113,R114,R115,v22,arbace.classes.analyze21,clojure-overrideablesv20,arbace.classes.types11,object-descv20,arbace.classes.types11,class->descv11,arbace.core7,string?v20,arbace.classes.types15,prim-desc->namev20,arbace.classes.types16,desc->class-namev22,arbace.classes.analyze16,clojure-tag-descv22,arbace.classes.analyze13,class-name-ofv11,arbace.core6,empty?v17,arbace.classes.go16,newTypeReferencev17,arbace.classes.go13,METHOD_RETURNv17,arbace.classes.go15,METHOD_RECEIVERv17,arbace.classes.go27,newFormalParameterReferencev17,arbace.classes.go21,newExceptionReferenceR116,v22,arbace.classes.analyze12,method-scopeV2,R46,R47,R117,v11,arbace.core8,not-any?v22,arbace.classes.analyze11,iface-kind?R118,v22,arbace.classes.analyze16,clojure-overridev22,arbace.classes.analyze15,infer-signaturev20,arbace.classes.types11,desc->tnodev22,arbace.classes.analyze10,param-infov20,arbace.classes.types5,prim?R119,R105,V2,R46,R113,v20,arbace.classes.parse8,flags-ofv22,arbace.classes.analyze11,method-modsR120,R121,R122,v22,arbace.classes.analyze15,deprecated-flagR123,R124,R125,v22,arbace.classes.analyze16,method-signatureR126,v22,arbace.classes.analyze23,method-type-annotationsV2,R46,R69,R46,R127,v11,arbace.core4,lastR128,V2,R46,R47,V2,R46,R113,S4,R120,R129,R130,R131,m4,R48,R119,R25,s1,Vm4,R48,R119,R25,s1,VR132,R133,R105,v22,arbace.classes.analyze10,field-modsR134,v17,arbace.classes.go5,FIELDR135,R136,R137,R138,R139,R140,v22,arbace.classes.analyze11,enter-fieldv22,arbace.classes.analyze12,enter-methodv22,arbace.classes.analyze10,enter-ctorv22,arbace.classes.analyze11,annotationsR141,R142,v20,arbace.classes.types8,array-ofR143,S1,R144,R145,R105,v11,arbace.core6,removeS1,R144,v22,arbace.classes.analyze10,for-targetR146,v22,arbace.classes.analyze14,derived-methodi1,R147,R148,V3,V2,s8,toStrings20,()Ljava/lang/String;V2,s8,hashCodes3,()IV2,s6,equalss21,(Ljava/lang/Object;)ZR149,v22,arbace.classes.analyze12,class-accessR150,R151,R152,v22,arbace.classes.analyze16,resolve-members!R153,R154,R155,V1,V2,s4,namei32768,R156,i2,R157,R158,R159,v11,arbace.core5,char?v11,arbace.core8,integer?v11,arbace.core2,<=l65535,R160,R161,v22,arbace.classes.analyze8,wideningv20,arbace.classes.types6,box-ofR162,R163,v22,arbace.classes.analyze10,value-typeR164,v22,arbace.classes.analyze7,widens?R165,S4,s1,Ss1,Cs1,Bs1,IS4,s1,Ss1,Cs1,Bs1,Iv22,arbace.classes.analyze5,fits?R166,S4,s1,Ss1,Cs1,Bs1,Iv22,arbace.classes.analyze17,literal-tail-valsv22,arbace.classes.analyze10,boxed-descR167,v20,arbace.classes.types8,unbox-ofR168,v22,arbace.classes.analyze5,unifyv18,arbace.classes.env3,lubR169,v22,arbace.classes.analyze13,literal-tail?R170,R171,R172,R173,R174,R175,R176,R177,R178,R179,R180,R181,R182,v11,arbace.core6,mapcatS4,s1,Ss1,Cs1,Bs1,Iv22,arbace.classes.analyze12,convert-nodeS4,s1,Ss1,Cs1,Bs1,IS3,s1,Ss1,Cs1,BR183,v22,arbace.classes.analyze7,next-idR184,R185,R186,R187,R188,R189,v11,arbace.core8,assoc-inR190,v22,arbace.classes.analyze8,scope-ofv22,arbace.classes.analyze5,stateR191,R192,R193,v22,arbace.classes.analyze15,outer-this-nodeR31,R194,R195,R196,v22,arbace.classes.analyze12,add-capture!v11,arbace.core10,take-whilev11,arbace.core7,iteratev22,arbace.classes.analyze15,prologue-class?R197,R198,R199,R200,v22,arbace.classes.analyze9,local-refv22,arbace.classes.analyze16,outer-this-node*R201,v11,arbace.core6,reset!R202,v22,arbace.classes.analyze18,class-parent-framev11,arbace.core4,var?R15,v11,arbace.core10,ns-resolvev22,arbace.classes.analyze11,resolve-varv22,arbace.classes.analyze9,core-var?v22,arbace.classes.analyze16,clojure-specialsv22,arbace.classes.analyze15,arbace-specialsR203,v11,arbace.core4,*ns*v11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapR204,v11,arbace.core7,ex-datav11,arbace.core10,ex-messagev22,arbace.classes.analyze14,with-form-infov22,arbace.classes.analyze14,analyze-symbolv22,arbace.classes.analyze10,analyze-opv22,arbace.classes.analyze10,const-nodev11,arbace.core8,boolean?v11,arbace.core8,keyword?v22,arbace.classes.analyze12,clj-constantv22,arbace.classes.analyze14,clj-collectionv20,arbace.classes.types9,lang-descv11,arbace.core8,identityv11,arbace.core4,set?R205,v22,arbace.classes.analyze11,accessorizev22,arbace.classes.analyze11,coerce-hintv22,arbace.classes.analyze9,actx-descR206,R207,S2,R161,R164,S2,R208,R209,R210,R211,v22,arbace.classes.analyze15,branching-tail?v22,arbace.classes.analyze7,analyzev11,arbace.core7,butlastR212,v22,arbace.classes.analyze12,static-flag?v18,arbace.classes.env11,const-valueR213,R214,R215,R216,v22,arbace.classes.analyze13,field-indexesR217,v22,arbace.classes.analyze11,field-indexR218,v22,arbace.classes.analyze14,find-own-fieldv22,arbace.classes.analyze10,field-nodev18,arbace.classes.env9,subclass?R219,V3,R73,R51,R220,V3,R73,R51,R220,v22,arbace.classes.analyze13,resolve-classp5,[1-9]v22,arbace.classes.analyze9,class-litv18,arbace.classes.env10,find-fieldv20,arbace.classes.types10,prim-namesv11,arbace.core7,re-findp2,\\.R221,R222,v22,arbace.classes.analyze13,clj-var-fieldR223,v18,arbace.classes.env11,accessible?R224,R225,R226,v22,arbace.classes.analyze7,unboxedv22,arbace.classes.analyze9,prim-typev22,arbace.classes.analyze11,clone-tail?R227,v22,arbace.classes.analyze12,retype-cloneR228,R229,R230,v22,arbace.classes.analyze10,bound-nodev22,arbace.classes.analyze10,conversionS9,R178,R169,R170,R231,R229,R180,R179,R176,R172,v11,arbace.core6,pr-strv22,arbace.classes.analyze13,const-of-typeR231,v22,arbace.classes.analyze11,unify-nodesS4,s1,Js1,Fs1,Is1,Dv20,arbace.classes.types10,lang-classR232,v22,arbace.classes.analyze7,operandR233,v22,arbace.classes.analyze4,fmodR234,R235,R236,R237,R238,R239,R240,R241,R242,R243,R244,R245,R246,R247,R248,v22,arbace.classes.analyze9,arith-opsS4,R238,R242,R241,R235,R249,S2,R236,R240,l1,v20,arbace.classes.types8,numeric?S3,R239,R245,R247,S2,s1,Fs1,DR250,R251,R252,S2,s1,Fs1,Dv22,arbace.classes.analyze10,fold-arithR253,R254,R255,S5,s1,Js1,Ss1,Cs1,Bs1,IS5,s1,Js1,Ss1,Cs1,Bs1,IS1,s1,DR256,v20,arbace.classes.types9,int-like?S2,R233,R237,v11,arbace.core6,dissocm14,s1,Is3,ints1,Js4,longs1,Ss5,shorts1,Bs4,bytes1,Cs4,chars1,Fs5,floats1,Ds6,doublev22,arbace.classes.analyze12,compare-typeR257,R258,S4,s10,method-refs7,lambda*s11,method-ref*s6,lambdav22,arbace.classes.analyze12,lambda-form?R259,v22,arbace.classes.analyze12,binding-typev22,arbace.classes.analyze9,bind-initv22,arbace.classes.analyze12,make-bindingR260,R261,v22,arbace.classes.analyze15,local-type-annsv22,arbace.classes.analyze10,with-localv11,arbace.core9,partitionR262,R263,R264,R265,R266,v22,arbace.classes.analyze12,analyze-bodyv11,arbace.core5,even?S3,s4,anons8,letclasss6,class*v11,arbace.core8,tree-seqv11,arbace.core5,coll?v22,arbace.classes.analyze13,class-def-in?R267,v22,arbace.classes.analyze14,literal-branchR268,S2,R269,R270,v22,arbace.classes.analyze12,macroexpand1R271,v22,arbace.classes.analyze14,expand-to-loopR272,R273,R274,R275,R276,R277,v22,arbace.classes.analyze14,code-type-annsR278,R279,R280,R281,R282,v11,arbace.core4,listR283,R284,R285,v22,arbace.classes.analyze16,field-super-nodev22,arbace.classes.analyze20,analyze-field-accessR283,p2,^-v22,arbace.classes.analyze12,analyze-set!R286,R287,S4,R167,R165,R168,R164,S2,R165,R164,S4,R167,R165,R168,R164,R288,v22,arbace.classes.analyze15,clj-fi-excludedR289,C29,java.lang.FunctionalInterfaceS3,s8,toStrings8,hashCodes6,equalsR290,v22,arbace.classes.analyze8,find-samS3,s8,toStrings8,hashCodes6,equalsR291,v22,arbace.classes.analyze13,clj-fi-methodv22,arbace.classes.analyze13,clj-prim-argsv11,arbace.core6,vectorv22,arbace.classes.analyze13,clj-arg-classm2,R292,Tv22,arbace.classes.analyze20,clj-param-arg-match?v22,arbace.classes.analyze13,clj-subsumes?v22,arbace.classes.analyze19,clj-ret-assignable?v13,arbace.string4,joinm2,R292,Tm2,R292,Tm2,R293,s14,no such methodv22,arbace.classes.analyze18,clj-matching-indexv22,arbace.classes.analyze15,clj-type-stringR293,R294,v22,arbace.classes.analyze17,param-tags-match?i128,v22,arbace.classes.analyze14,more-specific?v22,arbace.classes.analyze11,applicable?v22,arbace.classes.analyze14,expand-varargsv18,arbace.classes.env14,member-methodsv18,arbace.classes.env12,constructorsm12,s1,Js8,longCasts1,Ds10,doubleCasts1,Is7,intCasts1,Fs9,floatCasts1,Ss9,shortCasts1,Bs8,byteCastS2,R161,R164,S4,s1,Js1,Ss1,Bs1,IS2,s1,Fs1,Dm12,s1,Js1,Ls1,Ds1,Ds1,Is1,Is1,Ss1,Ss1,Bs1,Bs1,Fs1,FR295,R296,R297,R298,R299,S2,s1,Zs1,Cv22,arbace.classes.analyze15,clj-arg-convertv11,arbace.core4,takeR208,R300,v11,arbace.core4,dropi4096,v22,arbace.classes.analyze16,qualifying-ownerR301,R302,v22,arbace.classes.analyze12,convert-argsS2,s29,java/lang/invoke/MethodHandles26,java/lang/invoke/VarHandlei256,S2,R217,R303,R304,R303,v11,arbace.core20,*warn-on-reflection*v11,arbace.core7,printlnv11,arbace.core6,*file*v11,arbace.core5,*out*v11,arbace.core5,*err*v22,arbace.classes.analyze15,reflective-nodev22,arbace.classes.analyze7,objectsv22,arbace.classes.analyze18,reflection-warningR292,p114,^(No accessible|No matching|Ambiguous call|No field|No static field|Field not accessible|Method call|Field access)v22,arbace.classes.analyze8,reflect?v22,arbace.classes.analyze11,unresolved?v22,arbace.classes.analyze8,invokersS2,s6,invokes11,invokeExactv22,arbace.classes.analyze9,invokers?v22,arbace.classes.analyze15,invokers-methodv22,arbace.classes.analyze11,invoke-nodeR305,R306,R307,R308,v22,arbace.classes.analyze19,analyze-method-callR309,v22,arbace.classes.analyze13,type-arg-annsv22,arbace.classes.analyze10,or-reflectv22,arbace.classes.analyze20,analyze-method-call*R310,v22,arbace.classes.analyze15,reflective-callv22,arbace.classes.analyze19,instance-candidatesv22,arbace.classes.analyze22,signature-polymorphic?v22,arbace.classes.analyze13,invokers-callv22,arbace.classes.analyze10,clj-selectR311,v22,arbace.classes.analyze13,select-methodv22,arbace.classes.analyze15,invokers-lookupv22,arbace.classes.analyze17,static-candidatesR312,v22,arbace.classes.analyze21,analyze-field-access*R313,R314,v22,arbace.classes.analyze9,this-nodeR315,v22,arbace.classes.analyze10,super-nodev11,arbace.core12,keep-indexedv22,arbace.classes.analyze12,analyze-dot*R316,v22,arbace.classes.analyze21,needs-outer-instance?v22,arbace.classes.analyze14,ctor-call-nodeR317,R315,v22,arbace.classes.analyze16,outer-super-callv22,arbace.classes.analyze14,receiver-classv22,arbace.classes.analyze19,analyze-static-callR318,v11,arbace.core7,reversev11,arbace.core4,keepv11,arbace.core7,flattenR319,v22,arbace.classes.analyze15,ctor-candidatesR320,v22,arbace.classes.analyze20,capture-local-super!v20,arbace.classes.types10,array-dimsR209,R321,v22,arbace.classes.analyze11,int-operandS2,R30,R31,R322,v11,arbace.core9,with-metap5,[1-9]R322,v22,arbace.classes.analyze18,outer-instance-forv22,arbace.classes.analyze9,array-newR323,R324,R325,R326,R144,R327,v22,arbace.classes.analyze18,analyze-conversionv11,arbace.core5,list*R283,v13,arbace.string10,ends-with?S2,s6,super.s5,this.R328,R328,R283,R329,R330,S2,R161,R164,v22,arbace.classes.analyze16,with-node-localsm14,s1,Js8,longCasts1,Ds10,doubleCasts1,Is7,intCasts1,Fs9,floatCasts1,Ss9,shortCasts1,Bs8,byteCasts1,Cs8,charCastv11,arbace.core10,repeatedlyv11,arbace.core6,gensymS2,R161,R164,R331,R332,v22,arbace.classes.analyze15,var-invoke-nodev22,arbace.classes.analyze13,clj-call-nodev22,arbace.classes.analyze11,specializedv22,arbace.classes.analyze13,analyze-arithv22,arbace.classes.analyze11,conversionsv22,arbace.classes.analyze19,checked-conversionsv22,arbace.classes.analyze11,comparisonsv22,arbace.classes.analyze15,analyze-compareS3,s4,neg?s4,pos?s5,zero?m6,s5,zero?s2,==s4,pos?s1,>s4,neg?s1,<R333,R334,R335,S2,s5,some?s4,nil?R336,R337,v22,arbace.classes.analyze17,analyze-instance?v22,arbace.classes.analyze12,analyze-castS3,s4,agets7,alengths4,asetv22,arbace.classes.analyze12,analyze-asetv22,arbace.classes.analyze12,analyze-agetv22,arbace.classes.analyze15,analyze-lockingv22,arbace.classes.analyze15,analyze-fn-callR283,v22,arbace.classes.analyze11,analyze-dotR269,v22,arbace.classes.analyze16,analyze-for-eachR338,v22,arbace.classes.analyze14,analyze-switchR339,v22,arbace.classes.analyze22,analyze-with-resourcesR340,v22,arbace.classes.analyze19,analyze-clj-specialv22,arbace.classes.analyze7,core-opv22,arbace.classes.analyze12,core-op-nodev22,arbace.classes.analyze12,method-sugarR315,R315,R341,R342,R343,v22,arbace.classes.analyze16,analyze-java-strR344,R345,v22,arbace.classes.analyze11,analyze-tryR346,v22,arbace.classes.analyze17,analyze-ctor-callR347,v22,arbace.classes.analyze13,analyze-labelR286,R348,v22,arbace.classes.analyze13,analyze-breakR349,R350,R351,R352,v22,arbace.classes.analyze14,analyze-lambdaR353,v22,arbace.classes.analyze13,analyze-throwR354,R355,v22,arbace.classes.analyze16,analyze-letclassv22,arbace.classes.analyze12,analyze-anonR356,v22,arbace.classes.analyze13,analyze-recurR357,v22,arbace.classes.analyze19,analyze-java-assertR358,v22,arbace.classes.analyze10,analyze-ifR329,R359,v11,arbace.core7,number?R360,v22,arbace.classes.analyze18,analyze-method-refR361,R362,v22,arbace.classes.analyze11,analyze-letR363,R364,R328,v22,arbace.classes.analyze11,analyze-newR270,R285,R365,R366,v22,arbace.classes.analyze14,analyze-returnR367,v22,arbace.classes.analyze19,analyze-if-instanceR368,R369,R368,R285,R344,v20,arbace.classes.lower10,lower-caseS4,s1,Js1,Ss1,Bs1,IR342,v20,arbace.classes.lower11,lower-reifyR365,v20,arbace.classes.lower8,lower-fnR354,v20,arbace.classes.lower11,lower-letfnv22,arbace.classes.analyze12,expand-fullyR340,R283,R370,R371,R372,R283,R373,R374,R375,R364,v11,arbace.core6,internv20,arbace.classes.lower9,lower-defR364,v11,arbace.core5,nnextR376,R377,v22,arbace.classes.analyze18,non-constant-headsv22,arbace.classes.analyze16,may-be-constant?v22,arbace.classes.analyze9,new-frameR378,S2,R165,R166,v22,arbace.classes.analyze13,creation-actxS2,R30,R31,R379,R380,R381,R382,v22,arbace.classes.analyze9,body-actxv22,arbace.classes.analyze11,bind-paramsV2,R73,R174,v22,arbace.classes.analyze11,clj-convertS3,R346,R383,R349,v22,arbace.classes.analyze15,ctor-call-form?S2,s3,lets4,let*v22,arbace.classes.analyze17,nested-ctor-call?R384,m6,R22,s6,<init>R25,s22,(Ljava/lang/String;I)VR108,s14,java/lang/EnumR385,S2,R30,R31,v22,arbace.classes.analyze18,analyze-ctor-call*V2,R189,R133,V2,R189,R197,V2,R51,R196,V2,R73,R174,R386,R387,R388,R389,R390,v22,arbace.classes.analyze19,implicit-super-callV2,R189,R197,v22,arbace.classes.analyze17,analyze-enum-bodyR391,R392,R393,R394,R395,R396,R397,v22,arbace.classes.analyze22,analyze-enum-constantsS3,R159,R150,R158,S3,R159,R150,R158,v22,arbace.classes.analyze19,analyze-method-bodyv22,arbace.classes.analyze14,analyze-class!R398,v22,arbace.classes.analyze17,analyze-ctor-bodyV2,R189,R133,R399,V2,R189,R133,v18,arbace.classes.env7,definedR400,R401,v11,arbace.core4,nil?v20,arbace.classes.types14,reflect->tnodev20,arbace.classes.types5,substv22,arbace.classes.analyze14,class-genericsR402,R403,v22,arbace.classes.analyze15,clojure-bridgesv22,arbace.classes.analyze14,supertype-envsv18,arbace.classes.env16,superclass-chainv11,arbace.core7,memoizev22,arbace.classes.analyze13,erased-paramsv22,arbace.classes.analyze10,param-keysR404,i1024,v11,arbace.core6,bit-orv11,arbace.core6,subvecR405,v22,arbace.classes.analyze16,supertypes-firstv22,arbace.classes.analyze15,resolve-header!v22,arbace.classes.analyze12,add-bridges!v22,arbace.classes.analyze19,mark-enum-abstract!v22,arbace.classes.analyze16,local-class-nameR406,v11,arbace.core11,select-keysV1,R379,v22,arbace.classes.analyze9,prologue?R407,v22,arbace.classes.analyze16,process-classes!R408,R409,R406,v20,arbace.classes.parse11,class-flagsv22,arbace.classes.analyze19,sharpest-accessiblev22,arbace.classes.analyze17,accessible-class?R410,R411,v22,arbace.classes.analyze12,const-stringR412,R413,R414,R415,v22,arbace.classes.analyze20,analyze-java-assert*R416,R417,R418,S2,R75,R55,v22,arbace.classes.analyze9,nest-hostR419,S2,R75,R55,R420,R421,R422,R423,R424,R425,R426,R427,R428,R429,R430,R431,R432,R339,R339,R283,R433,R341,R358,R434,R345,R283,R433,R275,R435,R283,R436,R345,R283,R433,R275,R435,R283,R436,R353,R437,V1,s19,java/lang/Throwablev22,arbace.classes.analyze14,object-methodsv11,arbace.core1,=v11,arbace.core5,countR438,R439,R440,S1,s20,java/io/Serializablev22,arbace.classes.analyze20,lambda-method-prefixv11,arbace.core9,update-inR441,R442,p6,\\$\\d+$v22,arbace.classes.analyze8,fi-typesv22,arbace.classes.analyze15,lambda-ret-descR443,v22,arbace.classes.analyze12,lambda-name!v22,arbace.classes.analyze19,serial-lambda-name!R444,R445,R446,R447,R448,R449,R450,R451,v22,arbace.classes.analyze8,desc-tagR352,p12,^No matchingR452,p10,(\\d+)/(.+)R453,R454,v22,arbace.classes.analyze13,ref-as-lambdaR283,R283,v11,arbace.core9,vary-metap1,/R315,R352,R283,v22,arbace.classes.analyze10,select-refv22,arbace.classes.analyze8,arg-stubR328,v22,arbace.classes.analyze9,cast-argsR283,R455,v22,arbace.classes.analyze9,ref-ownerR456,R283,R457,R283,R288,R458,R459,v22,arbace.classes.analyze15,analyze-patternR460,R461,R462,R463,v22,arbace.classes.analyze12,prim-type-ofv11,arbace.core4,odd?v22,arbace.classes.analyze11,enum-class?R464,R465,R466,R466,S4,s1,Ss1,Cs1,Bs1,IR467,R468,m2,R161,Tm2,R69,TS4,s16,Ljava/lang/Byte;s21,Ljava/lang/Character;s17,Ljava/lang/Short;s19,Ljava/lang/Integer;v22,arbace.classes.analyze14,constant-labelR469,m2,R161,Tm2,R69,TS4,s16,Ljava/lang/Byte;s21,Ljava/lang/Character;s17,Ljava/lang/Short;s19,Ljava/lang/Integer;m2,R161,Tm2,R69,TS4,s16,Ljava/lang/Byte;s21,Ljava/lang/Character;s17,Ljava/lang/Short;s19,Ljava/lang/Integer;m2,R161,Tm2,R69,TS4,s16,Ljava/lang/Byte;s21,Ljava/lang/Character;s17,Ljava/lang/Short;s19,Ljava/lang/Integer;v22,arbace.classes.analyze11,switch-map!R470,R471,R472,R473,R474,R475,v11,arbace.core4,readm4,R476,R475,R477,R478,v11,arbace.core11,*read-eval*R359,v22,arbace.classes.analyze15,import-classes!R479,R15,v11,arbace.core4,evalv11,arbace.core9,create-nsv22,arbace.classes.analyze17,read-source-formsS3,R480,R481,R482,R341,v20,arbace.classes.parse13,split-optionsR70,S5,R483,R480,R481,R482,R484,S5,R483,R480,R481,R482,R484,v22,arbace.classes.analyze13,eval-ns-form!R341,m2,R34,R72,m2,R34,R72,p2,\\$R485,v22,arbace.classes.analyze11,enter-file!R486,v11,arbace.core3,modl10,R487,i4,v22,arbace.classes.analyze14,accessor-ownerS2,R281,R282,v22,arbace.classes.analyze13,add-accessor!R488,R489,R490,R491,R492,R493,R494,S2,R281,R282,S2,R281,R282,S2,R281,R282,v22,arbace.classes.analyze11,*accessors*R495,R496,R497,v22,arbace.classes.analyze15,constant-field!R498,R499,v11,arbace.core12,*print-meta*")

var Lit_1 *jrt.String = jrt.Intern("access$")

var Lit_2 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001705")

var Lit_3 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$members__1549001708")

var Lit_4 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$present_QMARK___1549001710")

var Lit_5 *jrt.String = jrt.Intern("<init>")

var Lit_6 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001739")

var Lit_7 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001746")

var Lit_8 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001748")

var Lit_9 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001755")

var Lit_10 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001760")

var Lit_11 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001767")

var Lit_12 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001769")

var Lit_13 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001776")

var Lit_14 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001790")

var Lit_15 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001794")

var Lit_16 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001796")

var Lit_17 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001801")

var Lit_18 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001803")

var Lit_19 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001807")

var Lit_20 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001809")

var Lit_21 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001814")

var Lit_22 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001816")

var Lit_23 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001820")

var Lit_24 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001822")

var Lit_25 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001827")

var Lit_26 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001829")

var Lit_27 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001833")

var Lit_28 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001835")

var Lit_29 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001840")

var Lit_30 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001739$fn__1549001740")

var Lit_31 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001748$fn__1549001749")

var Lit_32 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001760$fn__1549001761")

var Lit_33 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001769$fn__1549001770")

var Lit_34 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001790$fn__1549001791")

var Lit_35 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001803$fn__1549001804")

var Lit_36 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001816$fn__1549001817")

var Lit_37 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$fn__1549001829$fn__1549001830")

var Lit_38 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_$present_QMARK___1549001710$fn__1549001721")

var Lit_39 *jrt.String = jrt.Intern("arbace.classes.analyze$add_capture_BANG_$fn__1549000624")

var Lit_40 *jrt.String = jrt.Intern("arbace.classes.analyze$add_capture_BANG_$fn__1549000628")

var Lit_41 *jrt.String = jrt.Intern("arbace.classes.analyze$add_capture_BANG_$fn__1549000624$fn__1549000625")

var Lit_42 *jrt.String = jrt.Intern("arbace.classes.analyze$add_capture_BANG_$fn__1549000628$fn__1549000629")

var Lit_43 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze$fn__1549000668")

var Lit_44 *jrt.String = jrt.Intern("Empty list in class body")

var Lit_45 *jrt.String = jrt.Intern("Z")

var Lit_46 *jrt.String = jrt.Intern("C")

var Lit_47 *jrt.String = jrt.Intern("J")

var Lit_48 *jrt.String = jrt.Intern("I")

var Lit_49 *jrt.String = jrt.Intern("D")

var Lit_50 *jrt.String = jrt.Intern("F")

var Lit_51 *jrt.String = jrt.Intern("S")

var Lit_52 *jrt.String = jrt.Intern("B")

var Lit_53 *jrt.String = jrt.Intern("vector")

var Lit_54 *jrt.String = jrt.Intern("IPersistentVector")

var Lit_55 *jrt.String = jrt.Intern("map")

var Lit_56 *jrt.String = jrt.Intern("IPersistentMap")

var Lit_57 *jrt.String = jrt.Intern("set")

var Lit_58 *jrt.String = jrt.Intern("IPersistentSet")

var Lit_59 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_aget$fn__1549001274")

var Lit_60 *jrt.String = jrt.Intern("aget on a non-array of type ")

var Lit_61 *jrt.String = jrt.Intern("anon needs a vector of constructor arguments")

var Lit_62 *jrt.String = jrt.Intern("anon: :outer needs a value")

var Lit_63 *jrt.String = jrt.Intern("Bad anon supertype: ")

var Lit_64 *jrt.String = jrt.Intern("anon: :outer needs an instance of the superclass's outer class")

var Lit_65 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_anon$fn__1549001906")

var Lit_66 *jrt.String = jrt.Intern("An anonymous class of an interface takes no arguments")

var Lit_67 *jrt.String = jrt.Intern("anon: ")

var Lit_68 *jrt.String = jrt.Intern(" is not an inner class, :outer is not allowed")

var Lit_69 *jrt.String = jrt.Intern("/")

var Lit_70 *jrt.String = jrt.Intern(".")

var Lit_71 *jrt.String = jrt.Intern("constructor of ")

var Lit_72 *jrt.String = jrt.Intern("()V")

var Lit_73 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_anon$fn__1549001908")

var Lit_74 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_anon$fn__1549001914")

var Lit_75 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_anon$fn__1549001908$fn__1549001909")

var Lit_76 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_anon$fn__1549001908$fn__1549001909$fn__1549001910")

var Lit_77 *jrt.String = jrt.Intern(" takes ")

var Lit_78 *jrt.String = jrt.Intern(" operand(s) in class bodies")

var Lit_79 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_arith$fn__1549000750")

var Lit_80 *jrt.String = jrt.Intern(": operand of type ")

var Lit_81 *jrt.String = jrt.Intern(" is not integral")

var Lit_82 *jrt.String = jrt.Intern(": a double operand needs explicit narrowing")

var Lit_83 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_arith$fn__1549000762")

var Lit_84 *jrt.String = jrt.Intern(" needs explicit narrowing")

var Lit_85 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_arith$fn__1549000765")

var Lit_86 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_87 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_arith$fn__1549000767")

var Lit_88 *jrt.String = jrt.Intern(" on doubles is not Java arithmetic; use unchecked-divide/remainder")

var Lit_89 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_arith$fn__1549000769")

var Lit_90 *jrt.String = jrt.Intern("Operand of ")

var Lit_91 *jrt.String = jrt.Intern(" has non-primitive type ")

var Lit_92 *jrt.String = jrt.Intern(" (only primitives and their wrappers are arithmetic in class bodies)")

var Lit_93 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_aset$fn__1549001281")

var Lit_94 *jrt.String = jrt.Intern("aset on a non-array of type ")

var Lit_95 *jrt.String = jrt.Intern("array element")

var Lit_96 *jrt.String = jrt.Intern("aset on a non-array")

var Lit_97 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_body$fn__1549000676")

var Lit_98 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_body$fn__1549000678")

var Lit_99 *jrt.String = jrt.Intern("break: no label ")

var Lit_100 *jrt.String = jrt.Intern("break outside a loop")

var Lit_101 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_cast$fn__1549001315")

var Lit_102 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_cast$fn__1549001320")

var Lit_103 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_class_BANG_$fn__1549001577")

var Lit_104 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_class_BANG_$fn__1549001579")

var Lit_105 *jrt.String = jrt.Intern("initializer of field ")

var Lit_106 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_class_BANG_$fn__1549001587")

var Lit_107 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_class_BANG_$fn__1549001591")

var Lit_108 *jrt.String = jrt.Intern("V")

var Lit_109 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_clj_special$fn__1549001463")

var Lit_110 *jrt.String = jrt.Intern("Unable to resolve var: ")

var Lit_111 *jrt.String = jrt.Intern(" in this context")

var Lit_112 *jrt.String = jrt.Intern("Var")

var Lit_113 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_clj_special$fn__1549001465")

var Lit_114 *jrt.String = jrt.Intern("First argument to def must be a Symbol")

var Lit_115 *jrt.String = jrt.Intern("Can't create defs outside of current ns")

var Lit_116 *jrt.String = jrt.Intern(" takes 2 operands in class bodies")

var Lit_117 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_compare$fn__1549000788")

var Lit_118 *jrt.String = jrt.Intern(" is not a number")

var Lit_119 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_compare$lit_int_QMARK___1549000794")

var Lit_120 *jrt.String = jrt.Intern("<")

var Lit_121 *jrt.String = jrt.Intern(">")

var Lit_122 *jrt.String = jrt.Intern("<=")

var Lit_123 *jrt.String = jrt.Intern("==")

var Lit_124 *jrt.String = jrt.Intern(">=")

var Lit_125 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_const_form$fn__1549001473")

var Lit_126 *jrt.String = jrt.Intern("Constant of type ")

var Lit_127 *jrt.String = jrt.Intern(" where ")

var Lit_128 *jrt.String = jrt.Intern(" is needed")

var Lit_129 *jrt.String = jrt.Intern("Literal out of range: ")

var Lit_130 *jrt.String = jrt.Intern("Cannot convert ")

var Lit_131 *jrt.String = jrt.Intern(" to ")

var Lit_132 *jrt.String = jrt.Intern("Narrowing ")

var Lit_133 *jrt.String = jrt.Intern(" needs unchecked-")

var Lit_134 *jrt.String = jrt.Intern("Cannot convert boolean to a number")

var Lit_135 *jrt.String = jrt.Intern("this$0")

var Lit_136 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_ctor_body$fn__1549001523")

var Lit_137 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_ctor_body$fn__1549001527")

var Lit_138 *jrt.String = jrt.Intern("Constructor call not reached")

var Lit_139 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_ctor_body$fn__1549001529")

var Lit_140 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_ctor_body$fn__1549001523$fn__1549001524")

var Lit_141 *jrt.String = jrt.Intern("A second constructor call")

var Lit_142 *jrt.String = jrt.Intern(" outside a constructor")

var Lit_143 *jrt.String = jrt.Intern("super.")

var Lit_144 *jrt.String = jrt.Intern("this.")

var Lit_145 *jrt.String = jrt.Intern("An enum constructor cannot call super.")

var Lit_146 *jrt.String = jrt.Intern("super")

var Lit_147 *jrt.String = jrt.Intern(".super outside a constructor")

var Lit_148 *jrt.String = jrt.Intern(" is not an inner class")

var Lit_149 *jrt.String = jrt.Intern("new")

var Lit_150 *jrt.String = jrt.Intern(".new needs an outer instance")

var Lit_151 *jrt.String = jrt.Intern("$")

var Lit_152 *jrt.String = jrt.Intern("Unknown class ")

var Lit_153 *jrt.String = jrt.Intern("-")

var Lit_154 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$fn__1549001537")

var Lit_155 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$iter__1549001539__1549001543")

var Lit_156 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$fn__1549001573")

var Lit_157 *jrt.String = jrt.Intern("$values")

var Lit_158 *jrt.String = jrt.Intern("()")

var Lit_159 *jrt.String = jrt.Intern("$VALUES")

var Lit_160 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$iter__1549001539__1549001543$fn__1549001544")

var Lit_161 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$iter__1549001539__1549001543$fn__1549001544$fn__1549001545")

var Lit_162 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$iter__1549001539__1549001543$fn__1549001544$fn__1549001565")

var Lit_163 *jrt.String = jrt.Intern("constructor of enum constant ")

var Lit_164 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$iter__1549001539__1549001543$fn__1549001544$fn__1549001567")

var Lit_165 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$iter__1549001539__1549001543$fn__1549001544$fn__1549001569")

var Lit_166 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$iter__1549001539__1549001543$fn__1549001544$fn__1549001545$fn__1549001552")

var Lit_167 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$iter__1549001539__1549001543$fn__1549001544$fn__1549001545$fn__1549001554")

var Lit_168 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants$iter__1549001539__1549001543$fn__1549001544$fn__1549001545$fn__1549001556")

var Lit_169 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_field_access$fn__1549001185")

var Lit_170 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_field_access$fn__1549001187")

var Lit_171 *jrt.String = jrt.Intern("reference to field ")

var Lit_172 *jrt.String = jrt.Intern("getInstanceField")

var Lit_173 *jrt.String = jrt.Intern("(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;")

var Lit_174 *jrt.String = jrt.Intern("length")

var Lit_175 *jrt.String = jrt.Intern("Field access .")

var Lit_176 *jrt.String = jrt.Intern(" on a value of type ")

var Lit_177 *jrt.String = jrt.Intern("No field ")

var Lit_178 *jrt.String = jrt.Intern(" in ")

var Lit_179 *jrt.String = jrt.Intern("Field not accessible: ")

var Lit_180 *jrt.String = jrt.Intern("IFn")

var Lit_181 *jrt.String = jrt.Intern("Cannot call a value of type ")

var Lit_182 *jrt.String = jrt.Intern(" as a function")

var Lit_183 *jrt.String = jrt.Intern("Can't call nil")

var Lit_184 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_fn_call$fn__1549001457")

var Lit_185 *jrt.String = jrt.Intern("invoke")

var Lit_186 *jrt.String = jrt.Intern("IFn.invoke")

var Lit_187 *jrt.String = jrt.Intern("for-each needs a binding vector [x coll]")

var Lit_188 *jrt.String = jrt.Intern("Ljava/lang/Iterable;")

var Lit_189 *jrt.String = jrt.Intern("for-each over a value of type ")

var Lit_190 *jrt.String = jrt.Intern(", neither an array nor Iterable")

var Lit_191 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_for_each$aux__1549001980")

var Lit_192 *jrt.String = jrt.Intern("arr$")

var Lit_193 *jrt.String = jrt.Intern("len$")

var Lit_194 *jrt.String = jrt.Intern("i$")

var Lit_195 *jrt.String = jrt.Intern("Ljava/util/Iterator;")

var Lit_196 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_for_each$fn__1549001982")

var Lit_197 *jrt.String = jrt.Intern("iterator")

var Lit_198 *jrt.String = jrt.Intern("java/util/Iterator")

var Lit_199 *jrt.String = jrt.Intern("next")

var Lit_200 *jrt.String = jrt.Intern("()Ljava/lang/Object;")

var Lit_201 *jrt.String = jrt.Intern("for-each element")

var Lit_202 *jrt.String = jrt.Intern("Too many arguments to if")

var Lit_203 *jrt.String = jrt.Intern("if-instance needs [pattern expr]")

var Lit_204 *jrt.String = jrt.Intern("if-instance of a primitive")

var Lit_205 *jrt.String = jrt.Intern("inst$")

var Lit_206 *jrt.String = jrt.Intern("instance? needs a class")

var Lit_207 *jrt.String = jrt.Intern("instance? of a primitive")

var Lit_208 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_assert_STAR_$fn__1549001968")

var Lit_209 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_str$fn__1549001939")

var Lit_210 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_str$fn__1549001941")

var Lit_211 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_str$fn__1549001943")

var Lit_212 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_str$fn__1549001945")

var Lit_213 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_str$iter__1549001947__1549001951")

var Lit_214 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_str$iter__1549001947__1549001951$fn__1549001952")

var Lit_215 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_str$iter__1549001947__1549001951$fn__1549001952$fn__1549001953")

var Lit_216 *jrt.String = jrt.Intern("")

var Lit_217 *jrt.String = jrt.Intern("\x01")

var Lit_218 *jrt.String = jrt.Intern("\x02")

var Lit_219 *jrt.String = jrt.Intern("java-str of a void expression")

var Lit_220 *jrt.String = jrt.Intern("label needs a keyword")

var Lit_221 *jrt.String = jrt.Intern("lambda needs a parameter vector")

var Lit_222 *jrt.String = jrt.Intern("lambda for ")

var Lit_223 *jrt.String = jrt.Intern(" needs ")

var Lit_224 *jrt.String = jrt.Intern(" parameters")

var Lit_225 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_lambda$fn__1549002051")

var Lit_226 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_lambda$fn__1549002056")

var Lit_227 *jrt.String = jrt.Intern("lambda value")

var Lit_228 *jrt.String = jrt.Intern("let/loop needs a vector of bindings")

var Lit_229 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_let$fn__1549000846")

var Lit_230 *jrt.String = jrt.Intern("Bad binding: ")

var Lit_231 *jrt.String = jrt.Intern("^:const local needs a constant initializer: ")

var Lit_232 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_letclass$fn__1549001921")

var Lit_233 *jrt.String = jrt.Intern("locking needs a reference")

var Lit_234 *jrt.String = jrt.Intern("value of method ")

var Lit_235 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_call$fn__1549001142")

var Lit_236 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_call$fn__1549001144")

var Lit_237 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_call$fn__1549001146")

var Lit_238 *jrt.String = jrt.Intern("Method call .")

var Lit_239 *jrt.String = jrt.Intern(" on nil")

var Lit_240 *jrt.String = jrt.Intern("java/lang/Object")

var Lit_241 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_call_STAR_$fn__1549001157")

var Lit_242 *jrt.String = jrt.Intern("clone")

var Lit_243 *jrt.String = jrt.Intern("No accessible method ")

var Lit_244 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_call_STAR_$fn__1549001159")

var Lit_245 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_call_STAR_$fn__1549001161")

var Lit_246 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_call_STAR_$fn__1549001163")

var Lit_247 *jrt.String = jrt.Intern("method ")

var Lit_248 *jrt.String = jrt.Intern("method-ref takes FI, an optional signature, an optional receiver and a method")

var Lit_249 *jrt.String = jrt.Intern("Bad method in method-ref: ")

var Lit_250 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002103")

var Lit_251 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$register__1549002110")

var Lit_252 *jrt.String = jrt.Intern("rec$")

var Lit_253 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002112")

var Lit_254 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002115")

var Lit_255 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002120")

var Lit_256 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002125")

var Lit_257 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002127")

var Lit_258 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002132")

var Lit_259 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002134")

var Lit_260 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002139")

var Lit_261 *jrt.String = jrt.Intern("An unbound method reference needs the receiver as first parameter")

var Lit_262 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002142")

var Lit_263 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002150")

var Lit_264 *jrt.String = jrt.Intern("static method ")

var Lit_265 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref$fn__1549002152")

var Lit_266 *jrt.String = jrt.Intern("a$")

var Lit_267 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_new$anns__1549001249")

var Lit_268 *jrt.String = jrt.Intern("[")

var Lit_269 *jrt.String = jrt.Intern("Unable to resolve class: ")

var Lit_270 *jrt.String = jrt.Intern("Cannot instantiate abstract class ")

var Lit_271 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_new$fn__1549001255")

var Lit_272 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_new$fn__1549001261")

var Lit_273 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_new$fn__1549001263")

var Lit_274 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_new$fn__1549001265")

var Lit_275 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_new$fn__1549001267")

var Lit_276 *jrt.String = jrt.Intern("call to ")

var Lit_277 *jrt.String = jrt.Intern(" ctor")

var Lit_278 *jrt.String = jrt.Intern("invokeConstructor")

var Lit_279 *jrt.String = jrt.Intern("(Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;")

var Lit_280 *jrt.String = jrt.Intern(" is not supported in code compiled by the Java forms compiler")

var Lit_281 *jrt.String = jrt.Intern(" (class bodies, and fns using the Java forms; use locking)")

var Lit_282 *jrt.String = jrt.Intern("class* ")

var Lit_283 *jrt.String = jrt.Intern(" is not an expression")

var Lit_284 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_op$fn__1549001445")

var Lit_285 *jrt.String = jrt.Intern("A type pattern needs a type: ")

var Lit_286 *jrt.String = jrt.Intern("_")

var Lit_287 *jrt.String = jrt.Intern("Primitive pattern of type ")

var Lit_288 *jrt.String = jrt.Intern(" for a value of type ")

var Lit_289 *jrt.String = jrt.Intern(" is not supported")

var Lit_290 *jrt.String = jrt.Intern("Unknown record ")

var Lit_291 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_pattern$fn__1549002163")

var Lit_292 *jrt.String = jrt.Intern(" is not a record")

var Lit_293 *jrt.String = jrt.Intern("Record pattern ")

var Lit_294 *jrt.String = jrt.Intern(" component patterns")

var Lit_295 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_pattern$fn__1549002177")

var Lit_296 *jrt.String = jrt.Intern("Bad pattern: ")

var Lit_297 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_pattern$fn__1549002163$iter__1549002164__1549002168")

var Lit_298 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_pattern$fn__1549002163$iter__1549002164__1549002168$fn__1549002169")

var Lit_299 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_pattern$fn__1549002163$iter__1549002164__1549002168$fn__1549002169$fn__1549002170")

var Lit_300 *jrt.String = jrt.Intern("continue: no label ")

var Lit_301 *jrt.String = jrt.Intern("continue: label ")

var Lit_302 *jrt.String = jrt.Intern(" is not a loop")

var Lit_303 *jrt.String = jrt.Intern("recur/continue outside a loop")

var Lit_304 *jrt.String = jrt.Intern("Mismatched argument count to recur/continue, expected: ")

var Lit_305 *jrt.String = jrt.Intern(" args, got: ")

var Lit_306 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_recur$fn__1549000865")

var Lit_307 *jrt.String = jrt.Intern("recur argument")

var Lit_308 *jrt.String = jrt.Intern("return outside a method")

var Lit_309 *jrt.String = jrt.Intern("return value")

var Lit_310 *jrt.String = jrt.Intern("Cannot assign captured local ")

var Lit_311 *jrt.String = jrt.Intern("Cannot assign immutable local ")

var Lit_312 *jrt.String = jrt.Intern(" (use ^:mutable)")

var Lit_313 *jrt.String = jrt.Intern("value for ")

var Lit_314 *jrt.String = jrt.Intern("Unknown class in set!: ")

var Lit_315 *jrt.String = jrt.Intern("No static field ")

var Lit_316 *jrt.String = jrt.Intern(".-")

var Lit_317 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_set_BANG_$fn__1549000947")

var Lit_318 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_set_BANG_$fn__1549000952")

var Lit_319 *jrt.String = jrt.Intern("Bad set! target: ")

var Lit_320 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_static_call$fn__1549001173")

var Lit_321 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_static_call$fn__1549001175")

var Lit_322 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_static_call$fn__1549001182")

var Lit_323 *jrt.String = jrt.Intern("No accessible static method ")

var Lit_324 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_static_call$fn__1549001175$fn__1549001179")

var Lit_325 *jrt.String = jrt.Intern("call to static method ")

var Lit_326 *jrt.String = jrt.Intern(" on ")

var Lit_327 *jrt.String = jrt.Intern("invokeStaticMethod")

var Lit_328 *jrt.String = jrt.Intern("(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;")

var Lit_329 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$fn__1549002222")

var Lit_330 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$fn__1549002225")

var Lit_331 *jrt.String = jrt.Intern("RT")

var Lit_332 *jrt.String = jrt.Intern("intCast")

var Lit_333 *jrt.String = jrt.Intern("(J)I")

var Lit_334 *jrt.String = jrt.Intern("(Ljava/lang/Object;)I")

var Lit_335 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$null_label_QMARK___1549002227")

var Lit_336 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$enum_const__1549002229")

var Lit_337 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$enum_pattern__1549002231")

var Lit_338 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$fn__1549002238")

var Lit_339 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$fn__1549002244")

var Lit_340 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$fn__1549002250")

var Lit_341 *jrt.String = jrt.Intern("switch on a value of type ")

var Lit_342 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$enum_name__1549002255")

var Lit_343 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$iter__1549002257__1549002261")

var Lit_344 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$fn__1549002325")

var Lit_345 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$fn__1549002327")

var Lit_346 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$fn__1549002329")

var Lit_347 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$fn__1549002331")

var Lit_348 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$fn__1549002333")

var Lit_349 *jrt.String = jrt.Intern("sel$")

var Lit_350 *jrt.String = jrt.Intern("restart$")

var Lit_351 *jrt.String = jrt.Intern("Enum switch label must be a constant name: ")

var Lit_352 *jrt.String = jrt.Intern("No enum constant ")

var Lit_353 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$enum_pattern__1549002231$fn__1549002232")

var Lit_354 *jrt.String = jrt.Intern("enum$")

var Lit_355 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$enum_pattern__1549002231$fn__1549002234")

var Lit_356 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$iter__1549002257__1549002261$fn__1549002262")

var Lit_357 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$iter__1549002257__1549002261$fn__1549002262$fn__1549002263")

var Lit_358 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$iter__1549002257__1549002261$fn__1549002262$iter__1549002299__1549002303")

var Lit_359 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$iter__1549002257__1549002261$fn__1549002262$fn__1549002263$iter__1549002275__1549002279")

var Lit_360 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$iter__1549002257__1549002261$fn__1549002262$fn__1549002263$iter__1549002275__1549002279$fn__1549002280")

var Lit_361 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$iter__1549002257__1549002261$fn__1549002262$fn__1549002263$iter__1549002275__1549002279$fn__1549002280$fn__1549002281")

var Lit_362 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$iter__1549002257__1549002261$fn__1549002262$iter__1549002299__1549002303$fn__1549002304")

var Lit_363 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch$iter__1549002257__1549002261$fn__1549002262$iter__1549002299__1549002303$fn__1549002304$fn__1549002305")

var Lit_364 *jrt.String = jrt.Intern("this")

var Lit_365 *jrt.String = jrt.Intern("A primitive type is no value: ")

var Lit_366 *jrt.String = jrt.Intern(" (use Integer/TYPE)")

var Lit_367 *jrt.String = jrt.Intern("Unable to resolve symbol: ")

var Lit_368 *jrt.String = jrt.Intern("Ljava/lang/Throwable;")

var Lit_369 *jrt.String = jrt.Intern("throw of a non-Throwable: ")

var Lit_370 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$catch_QMARK___1549000902")

var Lit_371 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$fin_QMARK___1549000904")

var Lit_372 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$fn__1549000906")

var Lit_373 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$iter__1549000908__1549000912")

var Lit_374 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$fn__1549000932")

var Lit_375 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$iter__1549000908__1549000912$fn__1549000913")

var Lit_376 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$iter__1549000908__1549000912$fn__1549000913$fn__1549000914")

var Lit_377 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$iter__1549000908__1549000912$fn__1549000913$fn__1549000926")

var Lit_378 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$iter__1549000908__1549000912$fn__1549000913$fn__1549000928")

var Lit_379 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$iter__1549000908__1549000912$fn__1549000913$fn__1549000914$fn__1549000918")

var Lit_380 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try$iter__1549000908__1549000912$fn__1549000913$fn__1549000914$fn__1549000920")

var Lit_381 *jrt.String = jrt.Intern("Unknown class: ")

var Lit_382 *jrt.String = jrt.Intern("with-resources needs a vector of resource bindings")

var Lit_383 *jrt.String = jrt.Intern("t$")

var Lit_384 *jrt.String = jrt.Intern("x$")

var Lit_385 *jrt.String = jrt.Intern("arbace.classes.analyze$ann_value$fn__1549000081")

var Lit_386 *jrt.String = jrt.Intern("Unknown annotation: ")

var Lit_387 *jrt.String = jrt.Intern("arbace.classes.analyze$ann_value$iter__1549000083__1549000087")

var Lit_388 *jrt.String = jrt.Intern("Ljava/lang/Class;")

var Lit_389 *jrt.String = jrt.Intern("TYPE")

var Lit_390 *jrt.String = jrt.Intern("arbace.classes.analyze$ann_value$iter__1549000083__1549000087$fn__1549000088")

var Lit_391 *jrt.String = jrt.Intern("arbace.classes.analyze$ann_value$iter__1549000083__1549000087$fn__1549000088$fn__1549000089")

var Lit_392 *jrt.String = jrt.Intern("Unknown annotation type: ")

var Lit_393 *jrt.String = jrt.Intern("arbace.classes.analyze$annotation_now$iter__1549000178__1549000182")

var Lit_394 *jrt.String = jrt.Intern("value")

var Lit_395 *jrt.String = jrt.Intern("arbace.classes.analyze$annotation_now$iter__1549000178__1549000182$fn__1549000183")

var Lit_396 *jrt.String = jrt.Intern("arbace.classes.analyze$annotation_now$iter__1549000178__1549000182$fn__1549000183$fn__1549000184")

var Lit_397 *jrt.String = jrt.Intern("arbace.classes.analyze$annotation_targets$fn__1549000104")

var Lit_398 *jrt.String = jrt.Intern("arbace.classes.analyze$annotation_targets$fn__1549000109")

var Lit_399 *jrt.String = jrt.Intern("java/lang/annotation/Target")

var Lit_400 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations$fn__1549000100")

var Lit_401 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations_now$iter__1549000195__1549000199")

var Lit_402 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations_now$iter__1549000195__1549000199$fn__1549000200")

var Lit_403 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations_now$iter__1549000195__1549000199$fn__1549000200$fn__1549000201")

var Lit_404 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations_now$iter__1549000195__1549000199$fn__1549000200$fn__1549000211")

var Lit_405 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations_now$iter__1549000195__1549000199$fn__1549000200$fn__1549000201$fn__1549000205")

var Lit_406 *jrt.String = jrt.Intern("arbace.classes.analyze$applicable_QMARK_$fn__1549000955")

var Lit_407 *jrt.String = jrt.Intern("arbace.classes.analyze$array_new$init__1549001233")

var Lit_408 *jrt.String = jrt.Intern("Bad dimensions for new ")

var Lit_409 *jrt.String = jrt.Intern("arbace.classes.analyze$array_new$fn__1549001237")

var Lit_410 *jrt.String = jrt.Intern("arbace.classes.analyze$array_new$init__1549001233$fn__1549001234")

var Lit_411 *jrt.String = jrt.Intern("arbace.classes.analyze$bind_init$fn__1549000834")

var Lit_412 *jrt.String = jrt.Intern("initializer of ")

var Lit_413 *jrt.String = jrt.Intern("arbace.classes.analyze$bind_params$fn__1549001494")

var Lit_414 *jrt.String = jrt.Intern("arbace.classes.analyze$body_actx$fn__1549001482")

var Lit_415 *jrt.String = jrt.Intern("arbace.classes.analyze$body_actx$fn__1549001484")

var Lit_416 *jrt.String = jrt.Intern("arbace.classes.analyze$body_actx$fn__1549001487")

var Lit_417 *jrt.String = jrt.Intern("arbace.classes.analyze$body_actx$fn__1549001489")

var Lit_418 *jrt.String = jrt.Intern("arbace.classes.analyze$bound_node$fn__1549000701")

var Lit_419 *jrt.String = jrt.Intern("val$")

var Lit_420 *jrt.String = jrt.Intern("arbace.classes.analyze$capture_local_super_BANG_$fn__1549001217")

var Lit_421 *jrt.String = jrt.Intern("arbace.classes.analyze$cast_args$fn__1549002077")

var Lit_422 *jrt.String = jrt.Intern("arbace.classes.analyze$class_def_in_QMARK_$fn__1549000857")

var Lit_423 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$iter__1549001607__1549001611")

var Lit_424 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001621")

var Lit_425 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001621$fn__1549001622")

var Lit_426 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001621$iter__1549001625__1549001629")

var Lit_427 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001621$iter__1549001625__1549001629$fn__1549001630")

var Lit_428 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001621$iter__1549001625__1549001629$fn__1549001630$fn__1549001631")

var Lit_429 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001621$iter__1549001625__1549001629$fn__1549001630$fn__1549001645")

var Lit_430 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001621$iter__1549001625__1549001629$fn__1549001630$iter__1549001647__1549001651")

var Lit_431 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001621$iter__1549001625__1549001629$fn__1549001630$fn__1549001631$fn__1549001632")

var Lit_432 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001621$iter__1549001625__1549001629$fn__1549001630$fn__1549001631$iter__1549001634__1549001638")

var Lit_433 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001621$iter__1549001625__1549001629$fn__1549001630$fn__1549001631$iter__1549001634__1549001638$fn__1549001639")

var Lit_434 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001621$iter__1549001625__1549001629$fn__1549001630$fn__1549001631$iter__1549001634__1549001638$fn__1549001639$fn__1549001640")

var Lit_435 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001621$iter__1549001625__1549001629$fn__1549001630$iter__1549001647__1549001651$fn__1549001652")

var Lit_436 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$fn__1549001621$iter__1549001625__1549001629$fn__1549001630$iter__1549001647__1549001651$fn__1549001652$fn__1549001653")

var Lit_437 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$iter__1549001607__1549001611$fn__1549001612")

var Lit_438 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$iter__1549001607__1549001611$fn__1549001612$fn__1549001613")

var Lit_439 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$iter__1549001607__1549001611$fn__1549001612$fn__1549001617")

var Lit_440 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics$iter__1549001607__1549001611$fn__1549001612$fn__1549001613$fn__1549001614")

var Lit_441 *jrt.String = jrt.Intern("arbace.classes.analyze$class_tparams$fn__1549000053")

var Lit_442 *jrt.String = jrt.Intern("arbace.classes.analyze$class_tparams$fn__1549000055")

var Lit_443 *jrt.String = jrt.Intern("arbace.classes.analyze$class_tparams$fn__1549000055$fn__1549000056")

var Lit_444 *jrt.String = jrt.Intern("argument")

var Lit_445 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_arg_convert$ip__1549001084")

var Lit_446 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_arg_convert$code__1549001086")

var Lit_447 *jrt.String = jrt.Intern("(")

var Lit_448 *jrt.String = jrt.Intern(")")

var Lit_449 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_arg_convert$fn__1549001088")

var Lit_450 *jrt.String = jrt.Intern("FnInvokers")

var Lit_451 *jrt.String = jrt.Intern("No method ")

var Lit_452 *jrt.String = jrt.Intern(" in FnInvokers")

var Lit_453 *jrt.String = jrt.Intern("(Ljava/lang/Object;)")

var Lit_454 *jrt.String = jrt.Intern("O")

var Lit_455 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_call_node$fn__1549001353")

var Lit_456 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_collection$fn__1549002490")

var Lit_457 *jrt.String = jrt.Intern("([Ljava/lang/Object;)")

var Lit_458 *jrt.String = jrt.Intern("[Ljava/lang/Object;")

var Lit_459 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_collection$fn__1549002492")

var Lit_460 *jrt.String = jrt.Intern("Keyword")

var Lit_461 *jrt.String = jrt.Intern("Symbol")

var Lit_462 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_constant$fn__1549002484")

var Lit_463 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_convert$fn__1549001330")

var Lit_464 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_fi_method$fn__1549000970")

var Lit_465 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_fi_method$fn__1549000974")

var Lit_466 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_fi_method$fn__1549000976")

var Lit_467 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_fi_method$fn__1549000970$fn__1549000971")

var Lit_468 *jrt.String = jrt.Intern("Ljava/lang/FunctionalInterface;")

var Lit_469 *jrt.String = jrt.Intern("More than one matching method found: ")

var Lit_470 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_matching_index$fn__1549001008")

var Lit_471 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_select$pdescs__1549001018")

var Lit_472 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_select$fn__1549001020")

var Lit_473 *jrt.String = jrt.Intern("interface ")

var Lit_474 *jrt.String = jrt.Intern("class ")

var Lit_475 *jrt.String = jrt.Intern("No matching ctor found for ")

var Lit_476 *jrt.String = jrt.Intern("No matching method ")

var Lit_477 *jrt.String = jrt.Intern(" found taking ")

var Lit_478 *jrt.String = jrt.Intern(" args for ")

var Lit_479 *jrt.String = jrt.Intern(" of ")

var Lit_480 *jrt.String = jrt.Intern(" args")

var Lit_481 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_select$fn__1549001024")

var Lit_482 *jrt.String = jrt.Intern("No matching ")

var Lit_483 *jrt.String = jrt.Intern(" for argument types ")

var Lit_484 *jrt.String = jrt.Intern("constructor")

var Lit_485 *jrt.String = jrt.Intern("argument types: ")

var Lit_486 *jrt.String = jrt.Intern(", ")

var Lit_487 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_type_string$fn__1549001012")

var Lit_488 *jrt.String = jrt.Intern("unknown")

var Lit_489 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000301__1549000307")

var Lit_490 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000301__1549000307$fn__1549000308")

var Lit_491 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000301__1549000307$fn__1549000308$iter__1549000303__1549000312")

var Lit_492 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000301__1549000307$fn__1549000308$iter__1549000322__1549000326")

var Lit_493 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000301__1549000307$fn__1549000308$iter__1549000303__1549000312$fn__1549000313")

var Lit_494 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000301__1549000307$fn__1549000308$iter__1549000303__1549000312$fn__1549000313$fn__1549000314")

var Lit_495 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000301__1549000307$fn__1549000308$iter__1549000303__1549000312$fn__1549000313$fn__1549000318")

var Lit_496 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000301__1549000307$fn__1549000308$iter__1549000303__1549000312$fn__1549000313$fn__1549000314$fn__1549000315")

var Lit_497 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000301__1549000307$fn__1549000308$iter__1549000322__1549000326$fn__1549000327")

var Lit_498 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges$iter__1549000301__1549000307$fn__1549000308$iter__1549000322__1549000326$fn__1549000327$fn__1549000328")

var Lit_499 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_implementables$iter__1549000278__1549000284")

var Lit_500 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_implementables$iter__1549000278__1549000284$fn__1549000285")

var Lit_501 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_implementables$iter__1549000278__1549000284$fn__1549000285$iter__1549000280__1549000286")

var Lit_502 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_implementables$iter__1549000278__1549000284$fn__1549000285$iter__1549000280__1549000286$fn__1549000287")

var Lit_503 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_implementables$iter__1549000278__1549000284$fn__1549000285$iter__1549000280__1549000286$fn__1549000287$fn__1549000288")

var Lit_504 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_override$fn__1549000345")

var Lit_505 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_override$fn__1549000347")

var Lit_506 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_override$exact__1549000349")

var Lit_507 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_override$check_ret__1549000353")

var Lit_508 *jrt.String = jrt.Intern("Can't define method not in interfaces: ")

var Lit_509 *jrt.String = jrt.Intern("Must hint overloaded method: ")

var Lit_510 *jrt.String = jrt.Intern("Can't find matching overloaded method: ")

var Lit_511 *jrt.String = jrt.Intern("Can't find matching method: ")

var Lit_512 *jrt.String = jrt.Intern(", leave off hints for auto match.")

var Lit_513 *jrt.String = jrt.Intern("Mismatched return type: ")

var Lit_514 *jrt.String = jrt.Intern(", expected: ")

var Lit_515 *jrt.String = jrt.Intern(", had: ")

var Lit_516 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_override$exact__1549000349$fn__1549000350")

var Lit_517 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_overrideables$fn__1549000295")

var Lit_518 *jrt.String = jrt.Intern("arbace.classes.analyze$code_type_anns$iter__1549001284__1549001290")

var Lit_519 *jrt.String = jrt.Intern("arbace.classes.analyze$code_type_anns$iter__1549001284__1549001290$fn__1549001291")

var Lit_520 *jrt.String = jrt.Intern("arbace.classes.analyze$code_type_anns$iter__1549001284__1549001290$fn__1549001291$iter__1549001286__1549001295")

var Lit_521 *jrt.String = jrt.Intern("arbace.classes.analyze$code_type_anns$iter__1549001284__1549001290$fn__1549001291$iter__1549001286__1549001295$fn__1549001296")

var Lit_522 *jrt.String = jrt.Intern("arbace.classes.analyze$code_type_anns$iter__1549001284__1549001290$fn__1549001291$iter__1549001286__1549001295$fn__1549001296$fn__1549001297")

var Lit_523 *jrt.String = jrt.Intern("arbace.classes.analyze$coerce_hint$fn__1549000671")

var Lit_524 *jrt.String = jrt.Intern("null")

var Lit_525 *jrt.String = jrt.Intern("const__")

var Lit_526 *jrt.String = jrt.Intern("arbace.classes.analyze$constant_field_BANG_$fn__1549002481")

var Lit_527 *jrt.String = jrt.Intern("switch label is not a constant: ")

var Lit_528 *jrt.String = jrt.Intern("arbace.classes.analyze$conversion$fn__1549000575")

var Lit_529 *jrt.String = jrt.Intern("arbace.classes.analyze$conversion$fn__1549000577")

var Lit_530 *jrt.String = jrt.Intern("arbace.classes.analyze$convert_args$fn__1549001099")

var Lit_531 *jrt.String = jrt.Intern("arbace.classes.analyze$convert_args$fn__1549001101")

var Lit_532 *jrt.String = jrt.Intern("arbace.classes.analyze$convert_args$fn__1549001103")

var Lit_533 *jrt.String = jrt.Intern("arbace.classes.analyze$convert_node$fn__1549000712")

var Lit_534 *jrt.String = jrt.Intern(" of type ")

var Lit_535 *jrt.String = jrt.Intern("arbace.classes.analyze$convert_node$fn__1549000718")

var Lit_536 *jrt.String = jrt.Intern("switch without default has no value of type ")

var Lit_537 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$call__1549001373")

var Lit_538 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001375")

var Lit_539 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001377")

var Lit_540 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001379")

var Lit_541 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001381")

var Lit_542 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001383")

var Lit_543 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001385")

var Lit_544 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001387")

var Lit_545 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001389")

var Lit_546 *jrt.String = jrt.Intern("=")

var Lit_547 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001394")

var Lit_548 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001396")

var Lit_549 *jrt.String = jrt.Intern("not=")

var Lit_550 *jrt.String = jrt.Intern("not")

var Lit_551 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001398")

var Lit_552 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001400")

var Lit_553 *jrt.String = jrt.Intern("nil?")

var Lit_554 *jrt.String = jrt.Intern("identical?")

var Lit_555 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001402")

var Lit_556 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001404")

var Lit_557 *jrt.String = jrt.Intern("instance?")

var Lit_558 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001409")

var Lit_559 *jrt.String = jrt.Intern("cast")

var Lit_560 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001414")

var Lit_561 *jrt.String = jrt.Intern("aset")

var Lit_562 *jrt.String = jrt.Intern("aget")

var Lit_563 *jrt.String = jrt.Intern("alength")

var Lit_564 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001417")

var Lit_565 *jrt.String = jrt.Intern("and")

var Lit_566 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001419")

var Lit_567 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001421")

var Lit_568 *jrt.String = jrt.Intern("or")

var Lit_569 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001423")

var Lit_570 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001425")

var Lit_571 *jrt.String = jrt.Intern("locking")

var Lit_572 *jrt.String = jrt.Intern("boolean")

var Lit_573 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node$fn__1549001427")

var Lit_574 *jrt.String = jrt.Intern("arbace.classes.analyze$ctor_call_node$fn__1549001227")

var Lit_575 *jrt.String = jrt.Intern("No accessible constructor of ")

var Lit_576 *jrt.String = jrt.Intern("arbace.classes.analyze$ctor_candidates$fn__1549001080")

var Lit_577 *jrt.String = jrt.Intern("Not in the compilation: ")

var Lit_578 *jrt.String = jrt.Intern("arbace.classes.analyze$decl_annotations$fn__1549000119")

var Lit_579 *jrt.String = jrt.Intern("arbace.classes.analyze$decl_annotations$fn__1549000119$fn__1549000120")

var Lit_580 *jrt.String = jrt.Intern("arbace.classes.analyze$decl_annotations$fn__1549000119$fn__1549000120$fn__1549000121")

var Lit_581 *jrt.String = jrt.Intern("ANNOTATION_TYPE")

var Lit_582 *jrt.String = jrt.Intern("Class defined twice in one form: ")

var Lit_583 *jrt.String = jrt.Intern("arbace.classes.analyze$declare_class_BANG_$fn__1549000223")

var Lit_584 *jrt.String = jrt.Intern("arbace.classes.analyze$declare_class_BANG_$fn__1549000225")

var Lit_585 *jrt.String = jrt.Intern("arbace.classes.analyze$deprecated_flag$fn__1549000249")

var Lit_586 *jrt.String = jrt.Intern("arbace.classes.analyze$derived_method$fn__1549000439")

var Lit_587 *jrt.String = jrt.Intern("arbace.classes.analyze$desc_tag$fn__1549002066")

var Lit_588 *jrt.String = jrt.Intern("arbace.classes.analyze$element_type$fn__1549000077")

var Lit_589 *jrt.String = jrt.Intern("A constructor needs a receiver parameter")

var Lit_590 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_ctor$fn__1549000422")

var Lit_591 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_ctor$fn__1549000424")

var Lit_592 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_ctor$fn__1549000427")

var Lit_593 *jrt.String = jrt.Intern("CONSTRUCTOR")

var Lit_594 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_ctor$fn__1549000429")

var Lit_595 *jrt.String = jrt.Intern("PARAMETER")

var Lit_596 *jrt.String = jrt.Intern("FIELD")

var Lit_597 *jrt.String = jrt.Intern("getValue")

var Lit_598 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_field$fn__1549000433")

var Lit_599 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_file_BANG_$fn__1549002370")

var Lit_600 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_file_BANG_$iter__1549002372__1549002380")

var Lit_601 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_file_BANG_$fn__1549002395")

var Lit_602 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_file_BANG_$fn__1549002401")

var Lit_603 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_file_BANG_$iter__1549002407__1549002413")

var Lit_604 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_file_BANG_$iter__1549002423__1549002427")

var Lit_605 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_file_BANG_$iter__1549002372__1549002380$fn__1549002381")

var Lit_606 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_file_BANG_$iter__1549002372__1549002380$fn__1549002381$iter__1549002374__1549002382")

var Lit_607 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_file_BANG_$iter__1549002372__1549002380$fn__1549002381$iter__1549002374__1549002382$fn__1549002383")

var Lit_608 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_file_BANG_$iter__1549002372__1549002380$fn__1549002381$iter__1549002374__1549002382$fn__1549002383$iter__1549002376__1549002384")

var Lit_609 *jrt.String = jrt.Intern("defclasses")

var Lit_610 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_file_BANG_$iter__1549002372__1549002380$fn__1549002381$iter__1549002374__1549002382$fn__1549002383$iter__1549002376__1549002384$fn__1549002385")

var Lit_611 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_file_BANG_$iter__1549002372__1549002380$fn__1549002381$iter__1549002374__1549002382$fn__1549002383$iter__1549002376__1549002384$fn__1549002385$fn__1549002386")

var Lit_612 *jrt.String = jrt.Intern("defclass")

var Lit_613 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_file_BANG_$iter__1549002407__1549002413$fn__1549002414")

var Lit_614 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_file_BANG_$iter__1549002407__1549002413$fn__1549002414$iter__1549002409__1549002415")

var Lit_615 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_file_BANG_$iter__1549002407__1549002413$fn__1549002414$iter__1549002409__1549002415$fn__1549002416")

var Lit_616 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_file_BANG_$iter__1549002407__1549002413$fn__1549002414$iter__1549002409__1549002415$fn__1549002416$fn__1549002417")

var Lit_617 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_file_BANG_$iter__1549002423__1549002427$fn__1549002428")

var Lit_618 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_file_BANG_$iter__1549002423__1549002427$fn__1549002428$fn__1549002429")

var Lit_619 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$fn__1549002450")

var Lit_620 *jrt.String = jrt.Intern("_class.ae")

var Lit_621 *jrt.String = jrt.Intern(".ae")

var Lit_622 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_$fn__1549002450$fn__1549002451")

var Lit_623 *jrt.String = jrt.Intern("Instance method ")

var Lit_624 *jrt.String = jrt.Intern(" needs a receiver parameter")

var Lit_625 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_method$fn__1549000391")

var Lit_626 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_method$fn__1549000396")

var Lit_627 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_method$fn__1549000398")

var Lit_628 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_method$fn__1549000400")

var Lit_629 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_method$fn__1549000402")

var Lit_630 *jrt.String = jrt.Intern("Variable arity parameter must be an array: ")

var Lit_631 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_method$fn__1549000406")

var Lit_632 *jrt.String = jrt.Intern("METHOD")

var Lit_633 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_method$fn__1549000408")

var Lit_634 *jrt.String = jrt.Intern("arbace.classes.analyze$erased_params$fn__1549001691")

var Lit_635 *jrt.String = jrt.Intern("import")

var Lit_636 *jrt.String = jrt.Intern("in-ns")

var Lit_637 *jrt.String = jrt.Intern("arbace.classes.analyze$fi_types$fn__1549002021")

var Lit_638 *jrt.String = jrt.Intern("Ljava/io/Serializable;")

var Lit_639 *jrt.String = jrt.Intern(" is not an interface")

var Lit_640 *jrt.String = jrt.Intern("arbace.classes.analyze$find_sam$iter__1549001995__1549002001")

var Lit_641 *jrt.String = jrt.Intern("arbace.classes.analyze$find_sam$params_of__1549002011")

var Lit_642 *jrt.String = jrt.Intern("arbace.classes.analyze$find_sam$fn__1549002013")

var Lit_643 *jrt.String = jrt.Intern(" is not a functional interface (abstract methods: ")

var Lit_644 *jrt.String = jrt.Intern("arbace.classes.analyze$find_sam$fn__1549002013$fn__1549002014")

var Lit_645 *jrt.String = jrt.Intern("arbace.classes.analyze$find_sam$fn__1549002013$fn__1549002014$fn__1549002015")

var Lit_646 *jrt.String = jrt.Intern("arbace.classes.analyze$find_sam$iter__1549001995__1549002001$fn__1549002002")

var Lit_647 *jrt.String = jrt.Intern("arbace.classes.analyze$find_sam$iter__1549001995__1549002001$fn__1549002002$iter__1549001997__1549002003")

var Lit_648 *jrt.String = jrt.Intern("arbace.classes.analyze$find_sam$iter__1549001995__1549002001$fn__1549002002$iter__1549001997__1549002003$fn__1549002004")

var Lit_649 *jrt.String = jrt.Intern("arbace.classes.analyze$find_sam$iter__1549001995__1549002001$fn__1549002002$iter__1549001997__1549002003$fn__1549002004$fn__1549002005")

var Lit_650 *jrt.String = jrt.Intern("arbace.classes.analyze$for_target$fn__1549000113")

var Lit_651 *jrt.String = jrt.Intern("arbace.classes.analyze$for_target$fn__1549000113$fn__1549000114")

var Lit_652 *jrt.String = jrt.Intern("arbace.classes.analyze$implicit_outer$fn__1549000060")

var Lit_653 *jrt.String = jrt.Intern("java/lang/Enum")

var Lit_654 *jrt.String = jrt.Intern("arbace.classes.analyze$import_classes_BANG_$iter__1549002344__1549002350")

var Lit_655 *jrt.String = jrt.Intern("arbace.classes.analyze$import_classes_BANG_$iter__1549002344__1549002350$fn__1549002351")

var Lit_656 *jrt.String = jrt.Intern("arbace.classes.analyze$import_classes_BANG_$iter__1549002344__1549002350$fn__1549002351$iter__1549002346__1549002352")

var Lit_657 *jrt.String = jrt.Intern("arbace.classes.analyze$import_classes_BANG_$iter__1549002344__1549002350$fn__1549002351$fn__1549002362")

var Lit_658 *jrt.String = jrt.Intern("arbace.classes.analyze$import_classes_BANG_$iter__1549002344__1549002350$fn__1549002351$iter__1549002346__1549002352$fn__1549002353")

var Lit_659 *jrt.String = jrt.Intern("arbace.classes.analyze$import_classes_BANG_$iter__1549002344__1549002350$fn__1549002351$iter__1549002346__1549002352$fn__1549002353$fn__1549002354")

var Lit_660 *jrt.String = jrt.Intern("arbace.classes.analyze$import_classes_BANG_$iter__1549002344__1549002350$fn__1549002351$iter__1549002346__1549002352$fn__1549002353$fn__1549002358")

var Lit_661 *jrt.String = jrt.Intern("arbace.classes.analyze$import_classes_BANG_$iter__1549002344__1549002350$fn__1549002351$iter__1549002346__1549002352$fn__1549002353$fn__1549002354$fn__1549002355")

var Lit_662 *jrt.String = jrt.Intern("arbace.classes.analyze$infer_signature$iter__1549000255__1549000261")

var Lit_663 *jrt.String = jrt.Intern("arbace.classes.analyze$infer_signature$iter__1549000255__1549000261$fn__1549000262")

var Lit_664 *jrt.String = jrt.Intern("arbace.classes.analyze$infer_signature$iter__1549000255__1549000261$fn__1549000262$iter__1549000257__1549000263")

var Lit_665 *jrt.String = jrt.Intern("arbace.classes.analyze$infer_signature$iter__1549000255__1549000261$fn__1549000262$iter__1549000257__1549000263$fn__1549000264")

var Lit_666 *jrt.String = jrt.Intern("arbace.classes.analyze$infer_signature$iter__1549000255__1549000261$fn__1549000262$iter__1549000257__1549000263$fn__1549000264$fn__1549000265")

var Lit_667 *jrt.String = jrt.Intern("arbace.classes.analyze$instance_candidates$fn__1549001072")

var Lit_668 *jrt.String = jrt.Intern("java/lang/invoke/MethodHandle")

var Lit_669 *jrt.String = jrt.Intern("L")

var Lit_670 *jrt.String = jrt.Intern("(Ljava/lang/invoke/MethodHandle;Ljava/lang/Class;[Ljava/lang/Class;[Ljava/lang/Object;)")

var Lit_671 *jrt.String = jrt.Intern("[Ljava/lang/Class;")

var Lit_672 *jrt.String = jrt.Intern("arbace.classes.analyze$invokers_call$fn__1549001130")

var Lit_673 *jrt.String = jrt.Intern("arbace.classes.analyze$invokers_call$fn__1549001132")

var Lit_674 *jrt.String = jrt.Intern("Ljava/lang/invoke/MethodHandle;")

var Lit_675 *jrt.String = jrt.Intern("java/lang/invoke/MethodHandles")

var Lit_676 *jrt.String = jrt.Intern("lookup")

var Lit_677 *jrt.String = jrt.Intern("(Ljava/lang/Class;)Ljava/lang/invoke/MethodHandles$Lookup;")

var Lit_678 *jrt.String = jrt.Intern("arbace.classes.analyze$invokers_method$fn__1549001125")

var Lit_679 *jrt.String = jrt.Intern(" in jdk.internal.jrt.Invokers")

var Lit_680 *jrt.String = jrt.Intern("static")

var Lit_681 *jrt.String = jrt.Intern("<clinit>")

var Lit_682 *jrt.String = jrt.Intern("lambda$")

var Lit_683 *jrt.String = jrt.Intern("arbace.classes.analyze$literal_tail_QMARK_$fn__1549000585")

var Lit_684 *jrt.String = jrt.Intern("arbace.classes.analyze$literal_tail_QMARK_$fn__1549000587")

var Lit_685 *jrt.String = jrt.Intern("arbace.classes.analyze$literal_tail_QMARK_$fn__1549000589")

var Lit_686 *jrt.String = jrt.Intern("arbace.classes.analyze$literal_tail_vals$fn__1549000596")

var Lit_687 *jrt.String = jrt.Intern("arbace.classes.analyze$literal_tail_vals$fn__1549000598")

var Lit_688 *jrt.String = jrt.Intern("arbace.classes.analyze$literal_tail_vals$fn__1549000600")

var Lit_689 *jrt.String = jrt.Intern("Cannot capture mutable local ")

var Lit_690 *jrt.String = jrt.Intern("Local out of scope: ")

var Lit_691 *jrt.String = jrt.Intern("arbace.classes.analyze$local_type_anns$iter__1549000803__1549000807")

var Lit_692 *jrt.String = jrt.Intern("arbace.classes.analyze$local_type_anns$iter__1549000813__1549000819")

var Lit_693 *jrt.String = jrt.Intern("arbace.classes.analyze$local_type_anns$iter__1549000803__1549000807$fn__1549000808")

var Lit_694 *jrt.String = jrt.Intern("arbace.classes.analyze$local_type_anns$iter__1549000803__1549000807$fn__1549000808$fn__1549000809")

var Lit_695 *jrt.String = jrt.Intern("TYPE_USE")

var Lit_696 *jrt.String = jrt.Intern("arbace.classes.analyze$local_type_anns$iter__1549000813__1549000819$fn__1549000820")

var Lit_697 *jrt.String = jrt.Intern("arbace.classes.analyze$local_type_anns$iter__1549000813__1549000819$fn__1549000820$iter__1549000815__1549000824")

var Lit_698 *jrt.String = jrt.Intern("arbace.classes.analyze$local_type_anns$iter__1549000813__1549000819$fn__1549000820$iter__1549000815__1549000824$fn__1549000825")

var Lit_699 *jrt.String = jrt.Intern("arbace.classes.analyze$local_type_anns$iter__1549000813__1549000819$fn__1549000820$iter__1549000815__1549000824$fn__1549000825$fn__1549000826")

var Lit_700 *jrt.String = jrt.Intern("arbace.classes.analyze$macroexpand1$expand__1549000664")

var Lit_701 *jrt.String = jrt.Intern("arbace.classes.analyze$mark_enum_abstract_BANG_$pk__1549001857")

var Lit_702 *jrt.String = jrt.Intern("arbace.classes.analyze$mark_enum_abstract_BANG_$impl_QMARK___1549001859")

var Lit_703 *jrt.String = jrt.Intern("arbace.classes.analyze$mark_enum_abstract_BANG_$fn__1549001865")

var Lit_704 *jrt.String = jrt.Intern("arbace.classes.analyze$mark_enum_abstract_BANG_$fn__1549001869")

var Lit_705 *jrt.String = jrt.Intern("arbace.classes.analyze$mark_enum_abstract_BANG_$fn__1549001865$fn__1549001866")

var Lit_706 *jrt.String = jrt.Intern("arbace.classes.analyze$mark_enum_abstract_BANG_$impl_QMARK___1549001859$fn__1549001860")

var Lit_707 *jrt.String = jrt.Intern("arbace.classes.analyze$mark_enum_abstract_BANG_$impl_QMARK___1549001859$fn__1549001860$fn__1549001861")

var Lit_708 *jrt.String = jrt.Intern("arbace.classes.analyze$method_scope$fn__1549000357")

var Lit_709 *jrt.String = jrt.Intern("arbace.classes.analyze$method_signature$fn__1549000361")

var Lit_710 *jrt.String = jrt.Intern("^")

var Lit_711 *jrt.String = jrt.Intern("..")

var Lit_712 *jrt.String = jrt.Intern("arbace.classes.analyze$method_type_annotations$fn__1549000364")

var Lit_713 *jrt.String = jrt.Intern("arbace.classes.analyze$method_type_annotations$fn__1549000364$iter__1549000365__1549000369")

var Lit_714 *jrt.String = jrt.Intern("arbace.classes.analyze$method_type_annotations$fn__1549000364$fn__1549000375")

var Lit_715 *jrt.String = jrt.Intern("arbace.classes.analyze$method_type_annotations$fn__1549000364$fn__1549000377")

var Lit_716 *jrt.String = jrt.Intern("arbace.classes.analyze$method_type_annotations$fn__1549000364$iter__1549000365__1549000369$fn__1549000370")

var Lit_717 *jrt.String = jrt.Intern("arbace.classes.analyze$method_type_annotations$fn__1549000364$iter__1549000365__1549000369$fn__1549000370$fn__1549000371")

var Lit_718 *jrt.String = jrt.Intern("arbace.classes.analyze$more_specific_QMARK_$fn__1549000959")

var Lit_719 *jrt.String = jrt.Intern("do")

var Lit_720 *jrt.String = jrt.Intern("arbace.classes.analyze$not_yet$fn__1549001924")

var Lit_721 *jrt.String = jrt.Intern(" is not implemented yet")

var Lit_722 *jrt.String = jrt.Intern("arbace.classes.analyze$objects$fn__1549001116")

var Lit_723 *jrt.String = jrt.Intern("arbace.classes.analyze$operand$fn__1549000729")

var Lit_724 *jrt.String = jrt.Intern("Operand of type ")

var Lit_725 *jrt.String = jrt.Intern("No enclosing instance for ")

var Lit_726 *jrt.String = jrt.Intern("arbace.classes.analyze$outer_super_call$fn__1549002477")

var Lit_727 *jrt.String = jrt.Intern("arbace.classes.analyze$outer_this_node$prologue_ctor__1549000640")

var Lit_728 *jrt.String = jrt.Intern("arbace.classes.analyze$outer_this_node$no__1549000648")

var Lit_729 *jrt.String = jrt.Intern("arbace.classes.analyze$outer_this_node$fn__1549000650")

var Lit_730 *jrt.String = jrt.Intern("No enclosing instance of type ")

var Lit_731 *jrt.String = jrt.Intern(" in scope")

var Lit_732 *jrt.String = jrt.Intern("arbace.classes.analyze$outer_this_node$prologue_ctor__1549000640$fn__1549000641")

var Lit_733 *jrt.String = jrt.Intern(" in a static context")

var Lit_734 *jrt.String = jrt.Intern("arbace.classes.analyze$param_keys$fn__1549001695")

var Lit_735 *jrt.String = jrt.Intern("arbace.classes.analyze$param_keys$fn__1549001695$fn__1549001696")

var Lit_736 *jrt.String = jrt.Intern("arbace.classes.analyze$param_tags_match_QMARK_$fn__1549000966")

var Lit_737 *jrt.String = jrt.Intern("UTF-8")

var Lit_738 *jrt.String = jrt.Intern("arbace.classes.analyze$read_source_forms$fn__1549002338")

var Lit_739 *jrt.String = jrt.Intern("arbace.classes.analyze$read_source_forms$fn__1549002340")

var Lit_740 *jrt.String = jrt.Intern("arbace.classes.analyze$ref_as_lambda$fn__1549002069")

var Lit_741 *jrt.String = jrt.Intern(" of a primitive")

var Lit_742 *jrt.String = jrt.Intern("NO_SOURCE_PATH")

var Lit_743 *jrt.String = jrt.Intern("call to method ")

var Lit_744 *jrt.String = jrt.Intern("invokeNoArgInstanceMember")

var Lit_745 *jrt.String = jrt.Intern("(Ljava/lang/Object;Ljava/lang/String;Z)Ljava/lang/Object;")

var Lit_746 *jrt.String = jrt.Intern("invokeInstanceMethod")

var Lit_747 *jrt.String = jrt.Intern("(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;")

var Lit_748 *jrt.String = jrt.Intern("Reflector")

var Lit_749 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_class_sym$fn__1549000039")

var Lit_750 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_class_sym$fn__1549000041")

var Lit_751 *jrt.String = jrt.Intern("java/lang/")

var Lit_752 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_header_BANG_$fn__1549000236")

var Lit_753 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_header_BANG_$pt__1549000238")

var Lit_754 *jrt.String = jrt.Intern("java/lang/annotation/Annotation")

var Lit_755 *jrt.String = jrt.Intern("java/lang/Record")

var Lit_756 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_header_BANG_$fn__1549000241")

var Lit_757 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_header_BANG_$fn__1549000243")

var Lit_758 *jrt.String = jrt.Intern("Cannot extend final class ")

var Lit_759 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_header_BANG_$fn__1549000243$fn__1549000244")

var Lit_760 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000451__1549000455")

var Lit_761 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000461__1549000465")

var Lit_762 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000471__1549000475")

var Lit_763 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000481__1549000485")

var Lit_764 *jrt.String = jrt.Intern("values")

var Lit_765 *jrt.String = jrt.Intern("()[")

var Lit_766 *jrt.String = jrt.Intern("valueOf")

var Lit_767 *jrt.String = jrt.Intern("(Ljava/lang/String;)")

var Lit_768 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000491__1549000495")

var Lit_769 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000501__1549000505")

var Lit_770 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$declared_QMARK___1549000511")

var Lit_771 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000515__1549000519")

var Lit_772 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000527__1549000531")

var Lit_773 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$fn__1549000543")

var Lit_774 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$fn__1549000545")

var Lit_775 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$fn__1549000547")

var Lit_776 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$fn__1549000549")

var Lit_777 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$fn__1549000551")

var Lit_778 *jrt.String = jrt.Intern(")V")

var Lit_779 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$fn__1549000553")

var Lit_780 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$declared_QMARK___1549000511$fn__1549000512")

var Lit_781 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000451__1549000455$fn__1549000456")

var Lit_782 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000451__1549000455$fn__1549000456$fn__1549000457")

var Lit_783 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000461__1549000465$fn__1549000466")

var Lit_784 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000461__1549000465$fn__1549000466$fn__1549000467")

var Lit_785 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000471__1549000475$fn__1549000476")

var Lit_786 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000471__1549000475$fn__1549000476$fn__1549000477")

var Lit_787 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000481__1549000485$fn__1549000486")

var Lit_788 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000481__1549000485$fn__1549000486$fn__1549000487")

var Lit_789 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000491__1549000495$fn__1549000496")

var Lit_790 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000491__1549000495$fn__1549000496$fn__1549000497")

var Lit_791 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000501__1549000505$fn__1549000506")

var Lit_792 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000501__1549000505$fn__1549000506$fn__1549000507")

var Lit_793 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000515__1549000519$fn__1549000520")

var Lit_794 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000515__1549000519$fn__1549000520$fn__1549000521")

var Lit_795 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000527__1549000531$fn__1549000532")

var Lit_796 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_$iter__1549000527__1549000531$fn__1549000532$fn__1549000533")

var Lit_797 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_var$fn__1549000660")

var Lit_798 *jrt.String = jrt.Intern("arbace.classes.analyze$retention$fn__1549000068")

var Lit_799 *jrt.String = jrt.Intern("arbace.classes.analyze$retention$fn__1549000073")

var Lit_800 *jrt.String = jrt.Intern("java/lang/annotation/Retention")

var Lit_801 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001038")

var Lit_802 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001042")

var Lit_803 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$pdescs__1549001044")

var Lit_804 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$varargs_QMARK___1549001046")

var Lit_805 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$pick__1549001048")

var Lit_806 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001054")

var Lit_807 *jrt.String = jrt.Intern("No method matches the param-tags of ")

var Lit_808 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001056")

var Lit_809 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001058")

var Lit_810 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001060")

var Lit_811 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001062")

var Lit_812 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001064")

var Lit_813 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001066")

var Lit_814 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001068")

var Lit_815 *jrt.String = jrt.Intern("; candidates: ")

var Lit_816 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$fn__1549001038$fn__1549001039")

var Lit_817 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$pick__1549001048$fn__1549001049")

var Lit_818 *jrt.String = jrt.Intern("Ambiguous call: ")

var Lit_819 *jrt.String = jrt.Intern(" ")

var Lit_820 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method$pick__1549001048$fn__1549001049$fn__1549001050")

var Lit_821 *jrt.String = jrt.Intern("arbace.classes.analyze$select_ref$fn__1549002074")

var Lit_822 *jrt.String = jrt.Intern(":")

var Lit_823 *jrt.String = jrt.Intern("arbace.classes.analyze$serial_lambda_name_BANG_$iter__1549002024__1549002028")

var Lit_824 *jrt.String = jrt.Intern("arbace.classes.analyze$serial_lambda_name_BANG_$iter__1549002024__1549002028$fn__1549002029")

var Lit_825 *jrt.String = jrt.Intern("arbace.classes.analyze$serial_lambda_name_BANG_$iter__1549002024__1549002028$fn__1549002029$fn__1549002030")

var Lit_826 *jrt.String = jrt.Intern(",")

var Lit_827 *jrt.String = jrt.Intern("arbace.classes.analyze$static_candidates$fn__1549001076")

var Lit_828 *jrt.String = jrt.Intern("super in a static context")

var Lit_829 *jrt.String = jrt.Intern("arbace.classes.analyze$supertype_envs$iter__1549001661__1549001665")

var Lit_830 *jrt.String = jrt.Intern("arbace.classes.analyze$supertype_envs$outer_env__1549001677")

var Lit_831 *jrt.String = jrt.Intern("arbace.classes.analyze$supertype_envs$iter__1549001679__1549001683")

var Lit_832 *jrt.String = jrt.Intern("arbace.classes.analyze$supertype_envs$iter__1549001661__1549001665$fn__1549001666")

var Lit_833 *jrt.String = jrt.Intern("arbace.classes.analyze$supertype_envs$iter__1549001661__1549001665$fn__1549001666$fn__1549001667")

var Lit_834 *jrt.String = jrt.Intern("arbace.classes.analyze$supertype_envs$iter__1549001679__1549001683$fn__1549001684")

var Lit_835 *jrt.String = jrt.Intern("arbace.classes.analyze$supertype_envs$iter__1549001679__1549001683$fn__1549001684$fn__1549001685")

var Lit_836 *jrt.String = jrt.Intern("arbace.classes.analyze$supertypes_first$visit__1549001843")

var Lit_837 *jrt.String = jrt.Intern("arbace.classes.analyze$switch_map_BANG_$fn__1549002201")

var Lit_838 *jrt.String = jrt.Intern("arbace.classes.analyze$switch_map_BANG_$fn__1549002203")

var Lit_839 *jrt.String = jrt.Intern("this$")

var Lit_840 *jrt.String = jrt.Intern("No this in a static context")

var Lit_841 *jrt.String = jrt.Intern("arbace.classes.analyze$tparam_type_annotations$fn__1549000158")

var Lit_842 *jrt.String = jrt.Intern("arbace.classes.analyze$tparam_type_annotations$fn__1549000158$fn__1549000160")

var Lit_843 *jrt.String = jrt.Intern("arbace.classes.analyze$tparam_type_annotations$fn__1549000158$fn__1549000160$iter__1549000163__1549000167")

var Lit_844 *jrt.String = jrt.Intern("arbace.classes.analyze$tparam_type_annotations$fn__1549000158$fn__1549000160$fn__1549000173")

var Lit_845 *jrt.String = jrt.Intern("arbace.classes.analyze$tparam_type_annotations$fn__1549000158$fn__1549000160$iter__1549000163__1549000167$fn__1549000168")

var Lit_846 *jrt.String = jrt.Intern("arbace.classes.analyze$tparam_type_annotations$fn__1549000158$fn__1549000160$iter__1549000163__1549000167$fn__1549000168$fn__1549000169")

var Lit_847 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations$fn__1549000126")

var Lit_848 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations$fn__1549000126$iter__1549000127__1549000131")

var Lit_849 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations$fn__1549000126$iter__1549000137__1549000143")

var Lit_850 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations$fn__1549000126$iter__1549000127__1549000131$fn__1549000132")

var Lit_851 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations$fn__1549000126$iter__1549000127__1549000131$fn__1549000132$fn__1549000133")

var Lit_852 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations$fn__1549000126$iter__1549000137__1549000143$fn__1549000144")

var Lit_853 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations$fn__1549000126$iter__1549000137__1549000143$fn__1549000144$iter__1549000139__1549000148")

var Lit_854 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations$fn__1549000126$iter__1549000137__1549000143$fn__1549000144$iter__1549000139__1549000148$fn__1549000149")

var Lit_855 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations$fn__1549000126$iter__1549000137__1549000143$fn__1549000144$iter__1549000139__1549000148$fn__1549000149$fn__1549000150")

var Lit_856 *jrt.String = jrt.Intern("arbace.classes.analyze$type_arg_anns$fn__1549001194")

var Lit_857 *jrt.String = jrt.Intern("arbace.classes.analyze$type_scope$fn__1549000046")

var Lit_858 *jrt.String = jrt.Intern("arbace.classes.analyze$type_scope$fn__1549000048")

var Lit_859 *jrt.String = jrt.Intern("arbace.classes.analyze$unify_nodes$fn__1549000605")

var Lit_860 *jrt.String = jrt.Intern("arbace.classes.analyze$unify_nodes$fn__1549000605$fn__1549000606")

var Lit_861 *jrt.String = jrt.Intern(" (line ")

var Lit_862 *jrt.String = jrt.Intern("arbace.classes.analyze$with_node_locals$fn__1549001339")

var Lit_863 *jrt.String = jrt.Intern("arbace.classes.analyze$with_node_locals$fn__1549001343")

var Lit_864 *jrt.String = jrt.Intern("arg__")

var Lit_865 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,dynamickn4,linekn6,columnkn4,filekn7,privatekn8,arglistsyn3,msgyn4,datayn1,nyn1,fyn1,&yn4,argsyn5,flagsyn1,myn1,oyn1,byn2,cnyn2,nskn8,declaredyn3,symyn1,cyn5,scopeyn4,formyn2,tnyn2,elyn4,descyn1,vyn4,annsyn6,targetyn7,contextyn3,refyn3,tpsyn6,class?yn1,kyn2,mmyn6,parsedyn5,outeryn6,simpleyn3,ctxyn1,dyn3,ownyn3,kvskn6,publickn6,statickn5,finalkn9,transientkn9,protectedkn8,volatilekn9,synthetickn8,abstractkn12,synchronizedkn6,bridgekn6,nativeyn1,xyn4,nameyn5,arityyn3,tagyn5,mnameyn7,ret-tagyn6,paramsyn12,tparams-formyn6,ret-tnyn9,throws-tnyn5,mmetayn6,pinfosyn4,recvyn4,kindkn2,asyn4,moreyn1,tyn4,fromyn2,toyn1,pyn4,nodekn4,keysyn5,looseyn7,literalkn2,oryn1,ayn5,nodesyn3,clsyn6,parentyn8,boundaryyn4,actxyn4,typev11,arbace.core5,in-nsMyn22,arbace.classes.analyzem2,R0,s300,Entering class declarations (names, supertypes, members, what javac derives) and analyzing\n  code into typed nodes (SPEC §4 to §6), which the Go build's interpreter\n  (arbace.classes.interp) runs and j2g translates. (The bytecode back end, arbace.classes.emit,\n  is on the branch arbace-for-java-26.)m2,R0,s300,Entering class declarations (names, supertypes, members, what javac derives) and analyzing\n  code into typed nodes (SPEC §4 to §6), which the Go build's interpreter\n  (arbace.classes.interp) runs and j2g translates. (The bytecode back end, arbace.classes.emit,\n  is on the branch arbace-for-java-26.)R1,v22,arbace.classes.analyze6,*unit*m10,R2,TR3,i17,R4,i1,R5,s25,arbace/classes/analyze.aeR0,s89,The current compilation: {:order (atom [names in definition order]) :counters (atom {})}.v22,arbace.classes.analyze3,idsv11,arbace.core4,atoml0,m8,R6,TR3,i21,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze7,next-idm8,R7,L1,V0,R3,i22,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze4,failm8,R7,L2,V1,R8,V2,R8,R9,R3,i24,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze4,declm8,R7,L1,V1,R10,R3,i28,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze5,decl!m8,R7,L1,V1,R10,R3,i29,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,update-decl!m8,R7,L1,V4,R10,R11,R12,R13,R3,i30,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze5,statem8,R7,L1,V1,R10,R3,i31,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze4,has?m8,R7,L1,V2,R14,R11,R3,i33,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,static-flag?m8,R7,L1,V1,R15,R3,i34,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,nest-hostm8,R7,L1,V1,R10,R3,i36,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,outer-levelm12,R6,TR7,L1,V1,R16,R0,s83,How many enclosing instances class o has (javac's nesting level of the outer type).R3,i41,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze18,capture-field-namem10,R7,L1,V2,R10,R17,R0,s215,The name of the field of local or anonymous class n holding captured local b: val$x, a $\n  appended while the class declares a field of that name (SynthName1's own val$prm1; javac's\n  Lower names its proxies apart).R3,i47,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,this0-namem10,R7,L1,V1,R10,R0,s90,javac's name of class n's outer instance field: this$N, N the outer class's nesting level.R3,i56,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,ctor-real-descm10,R7,L1,V2,R18,R15,R0,s73,The descriptor of a constructor of class cn with all implicit parameters.R3,i61,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,ns-packagem8,R7,L1,V1,R19,R3,i80,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze18,enter-from-source!m8,R20,TR3,i85,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,*source-lookup*m10,R2,TR3,i87,R4,i1,R5,s25,arbace/classes/analyze.aeR0,s269,Whether class names that resolve to nothing are looked up as p/C.ae sources (§9.2): on the\n  path the loader reads (the Go build's ARBACE_PATH and embedded sources, RT/resourceAsStream;\n  since JC4, doc/classes/JAVA-CONFORMANCE-SURVEY.md, JCS8 (b)); j2g binds it false.v22,arbace.classes.analyze13,class-exists?m10,R6,TR7,L1,V1,R10,R3,i93,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,default-import?m12,R6,TR7,L1,V2,R21,R22,R0,s80,Is class c the one namespaces map symbol sym to by default (RT/DEFAULT_IMPORTS)?R3,i97,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze17,resolve-class-symm10,R7,L1,V2,R23,R21,R0,s311,Resolves a class name symbol from `scope` {:class internal-name :ns ns :local-classes {}}:\n  member classes of the class and its enclosing classes, then the namespace's explicit imports,\n  then the class's own package, then Clojure's default imports and java.lang (SPEC §5.2).\n  Returns an internal name or nil.R3,i102,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,implicit-outerm8,R20,TR3,i160,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,type-scopem10,R7,L1,V1,R23,R0,s72,A scope for types/parse-type: class name resolution plus type variables.R3,i162,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,class-tparamsm10,R6,TR7,L1,V1,R10,R3,i170,R4,i1,R5,s25,arbace/classes/analyze.aem10,R7,L1,V2,R23,R10,R0,s159,Inside a generic class, the simple name of one of its inner (non-static) member classes\n  denotes Outer<T...>.Inner (JLS 6.5.5.1): the outer type node, or nil.R3,i181,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,parse-typem8,R7,L1,V2,R23,R24,R3,i196,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze5,erasem8,R7,L1,V2,R23,R25,R3,i197,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,type-descm10,R7,L1,V2,R23,R24,R0,s46,The erased descriptor of a type form in scope.R3,i198,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,class-scopem10,R7,L1,V1,R10,R0,s33,The scope of the body of class n.R3,i203,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,*lenient*m10,R2,TR3,i212,R4,i1,R5,s25,arbace/classes/analyze.aeR0,s263,When true, an annotation whose type or values cannot be resolved (a type outside the world, an\n  undeclared fact of the edge) is left out of annotations-now instead of failing: the run-time\n  annotations' encoder (arbace.classes.annot, F14) records what resolves.v22,arbace.classes.analyze9,retentionm10,R6,TR7,L1,V1,R10,R3,i219,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,element-typem12,R6,TR7,L1,V2,R10,R26,R0,s70,The return descriptor of annotation element `el` of annotation type n.R3,i233,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze18,analyze-const-formm8,R20,TR3,i239,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,ann-valuem10,R6,TR7,L1,V3,R23,R27,R28,R3,i241,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,annotations-nowm8,R20,TR3,i274,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,annotationsm10,R7,L1,V2,R23,R15,R0,s229,Annotations (delayed, as annotation types of the compilation may not be entered yet) in metadata m (symbol keys naming annotation types), in scope.\n  Returns [{:type desc :visible bool :values {name value}}], SOURCE ones dropped.R3,i276,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze18,annotation-targetsm10,R7,L1,V1,R10,R0,s78,The ElementType names of annotation type n's @Target, or nil when it has none.R3,i282,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,for-targetm10,R7,L1,V2,R29,R30,R0,s129,Annotations applicable to declaration context `target` (an ElementType name), as javac\n  propagates record component annotations.R3,i295,R4,i1,R5,s25,arbace/classes/analyze.aem8,R20,TR3,i303,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,decl-annotationsm10,R7,L1,V3,R23,R15,R31,R0,s148,Declaration annotations in metadata m for declaration context `context` (an ElementType\n  name): those without @Target or whose @Target includes it.R3,i305,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,type-annotationsm10,R7,L1,V4,R23,R32,R25,R15,R0,s172,Type annotations of a declared type tn at type reference `ref` (an int): those inside the\n  type, and those of the declaration's metadata m whose @Target includes TYPE_USE.R3,i317,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze23,tparam-type-annotationsm12,R6,TR7,L1,V3,R23,R33,R34,R0,s77,Type annotations of type parameters and their bounds (sort: class or method).R3,i333,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,annotation-nowm10,R6,TR7,L1,V3,R23,R35,R28,R3,i361,R4,i1,R5,s25,arbace/classes/analyze.aem8,R7,L1,V2,R23,R15,R3,i373,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,element-defaultm10,R7,L1,V1,R36,R0,s121,The analyzed default (ann-value's form) of annotation element method mm (its :default,\n  §4.12), or nil when it has none.R3,i383,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze8,top-namem8,R7,L1,V2,R19,R37,R3,i393,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,local-class-namem10,R7,L1,V2,R38,R39,R0,s81,javac's name for a local (simple name given) or anonymous class in class `outer`.R3,i401,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,declare-class!m10,R7,L1,V2,R40,R37,R0,s458,Enters a parsed Java form and its member classes into the compilation.\n  ctx: {:nesting :outer :name (for local and anonymous classes) :static-context bool\n        :local-classes {} :enclosing-method {:name :desc} :parsed-members (nil, or the member\n        classes parsed ahead, [{:parsed parsed-class :members [...]}...] in their order: j2g's\n        load parses them in parallel, arbace.j2g.world/parse-member-classes)}. Returns the\n        internal name.R3,i408,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,bounds-of-scopem12,R6,TR7,L1,V1,R41,R0,s160,Type variable bounds visible in class declaration d: its own, those of the method creating a\n  local or anonymous class, and, unless static, its outer classes'.R3,i450,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,set-own-bounds!m12,R6,TR7,L1,V4,R10,R42,R12,R43,R0,s215,Sets class n's own type variable bounds (and more keys and values kvs), and the bounds visible\n  in it, in one update (j2g's load resolves the headers in parallel: fewer updates of the\n  compilation, fewer retries).R3,i459,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,resolve-header!m10,R7,L1,V1,R10,R0,s78,Resolves type parameters, superclass, interfaces and the class Signature of n.R3,i467,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,field-modsS8,R6,R44,R45,R46,R47,R48,R49,R50,m8,R6,TR3,i523,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,method-modsS10,R6,R44,R45,R51,R46,R52,R53,R54,R48,R50,m8,R6,TR3,i524,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,deprecated-flagm10,R6,TR7,L1,V1,R15,R3,i527,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,iface-kind?m10,R6,TR7,L1,V1,R41,R3,i531,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze6,tag-ofm10,R6,TR7,L1,V1,R55,R3,i533,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,param-infom10,R6,TR7,L1,V2,R23,R21,R3,i535,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,infer-signaturem12,R6,TR7,L1,V3,R10,R56,R57,R0,s140,deftype's rule: an untyped instance method takes the erased signature of the unique method of\n  its supertypes with the same name and arity.R3,i540,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze22,clojure-implementablesm12,R6,TR7,L1,V1,R10,R0,s244,The methods of class n's supertypes that a reify or deftype class n can implement (public or\n  protected, neither static nor final), as arbace.lang.Compiler's NewInstanceExpr.considerMethod\n  takes them, each with its declaring class as :owner.R3,i555,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze21,clojure-overrideablesm12,R6,TR7,L1,V1,R10,R0,s270,arbace.lang.Compiler's NewInstanceExpr.gatherMethods for class n (a reify or deftype class):\n  the methods of its supertypes it can implement (public or protected, neither static nor\n  final), one per name and parameter types, the one with the most specific return type.R3,i567,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,clojure-bridgesm12,R6,TR7,L1,V1,R10,R0,s457,The covariant bridges arbace.lang.Compiler gives a reify or deftype class n\n  (NewInstanceExpr.emitMethods over gatherMethods' covariants): for every method of the\n  supertypes that another one with the same name and parameter types but a more specific return\n  type overrides, whether n implements it or not, a public bridge (ACC_BRIDGE only, no\n  exceptions) with the overridden return type calling the most specific one through its\n  declaring interface.R3,i585,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,clojure-tag-descm12,R6,TR7,L1,V2,R23,R58,R0,s80,The descriptor of arbace.lang.Compiler's tagClass of a hint: Object without one.R3,i607,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,class-name-ofm12,R6,TR7,L1,V1,R41,R0,s43,Class.getName of the class of descriptor d.R3,i615,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,clojure-overridem12,R6,TR7,L1,V5,R10,R23,R59,R60,R61,R0,s462,The method of class n's supertypes that a method of reify or deftype named mname (munged)\n  with parameters params and return hint ret-tag implements, chosen as arbace.lang.Compiler's\n  NewInstanceMethod.parse chooses it, with its errors: the only method with that name and arity\n  when nothing is hinted; otherwise the one whose parameter types are the hinted classes\n  (Object where unhinted), whose return type must be the hinted class (Object when unhinted).R3,i620,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,method-scopem10,R6,TR7,L1,V2,R23,R62,R3,i648,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,method-signaturem10,R6,TR7,L1,V4,R33,R61,R63,R64,R3,i654,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze23,method-type-annotationsm10,R6,TR7,L1,V7,R23,R33,R65,R63,R66,R64,R67,R3,i662,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,enter-methodm10,R6,TR7,L1,V3,R10,R23,R15,R3,i684,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,class-accessm10,R6,TR7,L1,V1,R41,R3,i738,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,enter-ctorm10,R6,TR7,L1,V3,R10,R23,R15,R3,i741,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,enter-fieldm10,R6,TR7,L1,V3,R10,R23,R15,R3,i765,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,derived-methodm10,R6,TR7,L1,V7,R10,R56,R27,R14,R68,R12,m2,R69,R70,R3,i782,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,resolve-members!m8,R20,TR3,i788,R4,i1,R5,s25,arbace/classes/analyze.aem10,R7,L1,V1,R10,R0,s153,Enters the fields and methods of n, declared and derived (§6). Supertypes in the\n  compilation are entered first (for deftype-style signature inference).R3,i790,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,const-of-typem10,R7,L1,V2,R71,R28,R0,s60,Converts constant value v to the Java value of descriptor t.R3,i899,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze5,fits?m8,R7,L1,V2,R71,R28,R3,i913,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,const-nodem8,R7,L1,V4,R71,R28,R12,m2,R69,R70,R3,i923,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,value-typem8,R7,L1,V1,R71,R3,i929,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze8,wideningS5,s1,Js1,Ss1,Fs1,Is1,DS4,s1,Js1,Fs1,Is1,DS4,s1,Js1,Fs1,Is1,DS3,s1,Js1,Fs1,DS2,s1,Fs1,DS1,s1,Dm6,R3,i931,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze7,widens?m8,R7,L1,V2,R72,R73,R3,i935,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,boxed-descm8,R7,L1,V1,R74,R3,i937,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze17,literal-tail-valsm8,R20,TR3,i939,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,conversionm10,R7,L1,V5,R75,R72,R73,R12,m4,R76,V2,R77,R78,R79,m4,R77,TR78,TR0,s166,How a value of type `from` converts to `to` in assignment and invocation contexts:\n  nil when it cannot, else a keyword: :none :widen :box :unbox :narrow-const :null.R3,i941,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze5,unifym10,R7,L1,V2,R80,R17,R0,s56,The type of a value that is one of two branches' values.R3,i972,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,literal-tail?m10,R7,L1,V1,R75,R0,s73,Is the value of node an integer literal that fits an int (in every tail)?R3,i989,R4,i1,R5,s25,arbace/classes/analyze.aem10,R7,L1,V1,R75,R0,s83,The values of the integer literal tails of node, or nil if some tail is no literal.R3,i1006,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,convert-nodem8,R20,TR3,i1025,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,literal-branchm10,R7,L1,V2,R75,R71,R0,s87,A branch of integer literals takes the int-like type of the whole (as Java types them).R3,i1027,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,unify-nodesm10,R7,L1,V1,R81,R0,s53,The type of a value that is one of the nodes' values.R3,i1034,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,new-framem8,R7,L1,V4,R68,R82,R83,R84,R3,i1063,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,prologue?m10,R7,L1,V1,R85,R0,s62,Is code of actx before the constructor call (no instance yet)?R3,i1066,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,make-bindingm8,R7,L1,V5,R85,R21,R86,R12,m2,R69,R70,R3,i1071,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,with-localm8,R7,L1,V2,R85,R17,R3,i1074,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze8,scope-ofm8,R7,L1,V1,R85,R3,i1076,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,actx-descm8,R7,L1,V2,R85,R24,R3,i1079,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,resolve-classm8,R7,L1,V2,R85,R21,R3,i1081,R4,i1,R5,s25,arbace/classes/analyze.ae")

var Lit_866 *jrt.String = jrt.Intern("arbace.classes.analyze$eval1549000004$loading__1927001464__auto____1549000005")

var Lit_867 *jrt.String = jrt.Intern("arbace.classes.analyze$eval1549000008$fn__1549000009")

var Lit_868 *jrt.String = jrt.Intern("arbace.classes.analyze$next_id")

var Lit_869 *jrt.String = jrt.Intern("arbace.classes.analyze$fail")

var Lit_870 *jrt.String = jrt.Intern("arbace.classes.analyze$decl")

var Lit_871 *jrt.String = jrt.Intern("arbace.classes.analyze$decl_BANG_")

var Lit_872 *jrt.String = jrt.Intern("arbace.classes.analyze$update_decl_BANG_")

var Lit_873 *jrt.String = jrt.Intern("arbace.classes.analyze$state")

var Lit_874 *jrt.String = jrt.Intern("arbace.classes.analyze$has_QMARK_")

var Lit_875 *jrt.String = jrt.Intern("arbace.classes.analyze$static_flag_QMARK_")

var Lit_876 *jrt.String = jrt.Intern("arbace.classes.analyze$nest_host")

var Lit_877 *jrt.String = jrt.Intern("arbace.classes.analyze$outer_level")

var Lit_878 *jrt.String = jrt.Intern("arbace.classes.analyze$capture_field_name")

var Lit_879 *jrt.String = jrt.Intern("arbace.classes.analyze$this0_name")

var Lit_880 *jrt.String = jrt.Intern("arbace.classes.analyze$ctor_real_desc")

var Lit_881 *jrt.String = jrt.Intern("arbace.classes.analyze$ns_package")

var Lit_882 *jrt.String = jrt.Intern("arbace.classes.analyze$class_exists_QMARK_")

var Lit_883 *jrt.String = jrt.Intern("arbace.classes.analyze$default_import_QMARK_")

var Lit_884 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_class_sym")

var Lit_885 *jrt.String = jrt.Intern("arbace.classes.analyze$type_scope")

var Lit_886 *jrt.String = jrt.Intern("arbace.classes.analyze$class_tparams")

var Lit_887 *jrt.String = jrt.Intern("arbace.classes.analyze$implicit_outer")

var Lit_888 *jrt.String = jrt.Intern("arbace.classes.analyze$parse_type")

var Lit_889 *jrt.String = jrt.Intern("arbace.classes.analyze$erase")

var Lit_890 *jrt.String = jrt.Intern("arbace.classes.analyze$type_desc")

var Lit_891 *jrt.String = jrt.Intern("arbace.classes.analyze$class_scope")

var Lit_892 *jrt.String = jrt.Intern("arbace.classes.analyze$retention")

var Lit_893 *jrt.String = jrt.Intern("arbace.classes.analyze$element_type")

var Lit_894 *jrt.String = jrt.Intern("arbace.classes.analyze$ann_value")

var Lit_895 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations")

var Lit_896 *jrt.String = jrt.Intern("arbace.classes.analyze$annotation_targets")

var Lit_897 *jrt.String = jrt.Intern("arbace.classes.analyze$for_target")

var Lit_898 *jrt.String = jrt.Intern("arbace.classes.analyze$decl_annotations")

var Lit_899 *jrt.String = jrt.Intern("arbace.classes.analyze$type_annotations")

var Lit_900 *jrt.String = jrt.Intern("arbace.classes.analyze$tparam_type_annotations")

var Lit_901 *jrt.String = jrt.Intern("arbace.classes.analyze$annotation_now")

var Lit_902 *jrt.String = jrt.Intern("arbace.classes.analyze$annotations_now")

var Lit_903 *jrt.String = jrt.Intern("arbace.classes.analyze$element_default")

var Lit_904 *jrt.String = jrt.Intern("arbace.classes.analyze$top_name")

var Lit_905 *jrt.String = jrt.Intern("arbace.classes.analyze$local_class_name")

var Lit_906 *jrt.String = jrt.Intern("arbace.classes.analyze$declare_class_BANG_")

var Lit_907 *jrt.String = jrt.Intern("arbace.classes.analyze$bounds_of_scope")

var Lit_908 *jrt.String = jrt.Intern("arbace.classes.analyze$set_own_bounds_BANG_")

var Lit_909 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_header_BANG_")

var Lit_910 *jrt.String = jrt.Intern("arbace.classes.analyze$deprecated_flag")

var Lit_911 *jrt.String = jrt.Intern("arbace.classes.analyze$iface_kind_QMARK_")

var Lit_912 *jrt.String = jrt.Intern("arbace.classes.analyze$tag_of")

var Lit_913 *jrt.String = jrt.Intern("arbace.classes.analyze$param_info")

var Lit_914 *jrt.String = jrt.Intern("arbace.classes.analyze$infer_signature")

var Lit_915 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_implementables")

var Lit_916 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_overrideables")

var Lit_917 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_bridges")

var Lit_918 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_tag_desc")

var Lit_919 *jrt.String = jrt.Intern("arbace.classes.analyze$class_name_of")

var Lit_920 *jrt.String = jrt.Intern("arbace.classes.analyze$clojure_override")

var Lit_921 *jrt.String = jrt.Intern("arbace.classes.analyze$method_scope")

var Lit_922 *jrt.String = jrt.Intern("arbace.classes.analyze$method_signature")

var Lit_923 *jrt.String = jrt.Intern("arbace.classes.analyze$method_type_annotations")

var Lit_924 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_method")

var Lit_925 *jrt.String = jrt.Intern("arbace.classes.analyze$class_access")

var Lit_926 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_ctor")

var Lit_927 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_field")

var Lit_928 *jrt.String = jrt.Intern("arbace.classes.analyze$derived_method")

var Lit_929 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_members_BANG_")

var Lit_930 *jrt.String = jrt.Intern("arbace.classes.analyze$const_of_type")

var Lit_931 *jrt.String = jrt.Intern("arbace.classes.analyze$fits_QMARK_")

var Lit_932 *jrt.String = jrt.Intern("arbace.classes.analyze$const_node")

var Lit_933 *jrt.String = jrt.Intern("arbace.classes.analyze$value_type")

var Lit_934 *jrt.String = jrt.Intern("arbace.classes.analyze$widens_QMARK_")

var Lit_935 *jrt.String = jrt.Intern("arbace.classes.analyze$boxed_desc")

var Lit_936 *jrt.String = jrt.Intern("arbace.classes.analyze$conversion")

var Lit_937 *jrt.String = jrt.Intern("arbace.classes.analyze$unify")

var Lit_938 *jrt.String = jrt.Intern("arbace.classes.analyze$literal_tail_QMARK_")

var Lit_939 *jrt.String = jrt.Intern("arbace.classes.analyze$literal_tail_vals")

var Lit_940 *jrt.String = jrt.Intern("arbace.classes.analyze$literal_branch")

var Lit_941 *jrt.String = jrt.Intern("arbace.classes.analyze$unify_nodes")

var Lit_942 *jrt.String = jrt.Intern("arbace.classes.analyze$new_frame")

var Lit_943 *jrt.String = jrt.Intern("arbace.classes.analyze$prologue_QMARK_")

var Lit_944 *jrt.String = jrt.Intern("arbace.classes.analyze$make_binding")

var Lit_945 *jrt.String = jrt.Intern("arbace.classes.analyze$with_local")

var Lit_946 *jrt.String = jrt.Intern("arbace.classes.analyze$scope_of")

var Lit_947 *jrt.String = jrt.Intern("arbace.classes.analyze$actx_desc")

var Lit_948 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_class")

var Lit_949 *jrt.String = jrt.Intern("kn7,privatekn8,arglistsyn8,boundaryyn1,bkn4,linekn6,columnkn4,filekn8,declaredyn4,actxyn1,nkn3,docyn6,targetyn1,&yn12,monitor-exityn5,case*yn3,tryyn6,reify*yn7,finallyyn5,loop*yn2,doyn6,letfn*yn2,ifyn3,newyn8,deftype*yn4,let*yn3,fn*yn5,recuryn4,set!yn1,.yn3,varyn5,quoteyn5,catchys11,arbace.core7,import*yn5,throwyn13,monitor-enteryn3,defyn14,class-literal*yn6,break*yn9,for-each*yn11,method-ref*yn6,class*yn15,with-resources*yn12,if-instance*yn6,super.yn6,label*yn9,java-str*yn12,java-assert*yn7,lambda*yn7,switch*yn9,continue*yn5,this.yn7,return*yn1,vyn3,symyn4,formyn1,fyn4,nodeyn3,tagyn5,formskn3,tagyn1,cyn6,fieldsyn17,java.util.HashMapyn1,dkn4,longkn3,negkn3,divkn5,floatkn3,subkn5,exactkn3,mulkn3,intkn3,shrkn8,longbitskn2,orkn3,addkn3,deckn3,shlkn3,xorkn3,remkn3,andkn6,andnotkn3,inckn3,notkn4,ushryn2,tokn4,keysyn4,whatyn1,tyn1,ayn2,opyn6,opnameyn9,arg-nodesyn3,argyn8,checked?yn4,argsyn5,nodesyn4,inityn5,loop?yn4,typeyn1,_yn8,bindingsyn4,bodykn2,asyn4,testyn4,thenyn4,elseyn5,labelyn2,kwyn1,eyn1,xyn5,phaseyn11,param-descsyn2,p1yn2,p2yn6,paramsyn4,tagsyn9,tag-descsyn1,myn4,descyn1,pyn2,c1yn2,c2yn2,r1yn2,r2yn6,plistsyn4,retsv22,arbace.classes.analyze12,add-capture!m10,R0,TR1,L1,V2,R2,R3,R4,i1084,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,outer-this-nodem8,R7,TR4,i1092,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,local-refm10,R0,TR1,L1,V2,R8,R3,R4,i1094,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,outer-this-node*m8,R7,TR4,i1110,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,prologue-class?m12,R0,TR1,L1,V1,R9,R10,s229,Is class n a local or anonymous class declared in a constructor's prologue, before the\n  constructor call (an early construction context: no instance of the constructor's class, so\n  no immediately enclosing instance, JLS 8.1.3)?R4,i1112,R5,i1,R6,s25,arbace/classes/analyze.aem10,R1,L1,V2,R8,R11,R10,s494,Java's T.this from actx: the path of this$0 hops from the current class to class T. In a\n  lambda in a constructor of an inner class, the constructor's outer instance parameter\n  captured by the lambda, as javac's Lower makes it before LambdaToMethod; likewise in a local or\n  anonymous class declared in the constructor's prologue (javac's Attr.RecoveryInfo: its check\n  context's anonymous class reads Attr.this's chk before super(...)), which captures the\n  parameter as it captures a local.R4,i1119,R5,i1,R6,s25,arbace/classes/analyze.aem10,R0,TR1,L1,V2,R8,R11,R4,i1164,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze18,class-parent-framem10,R1,L1,V1,R9,R10,s180,The frame enclosing the code of class n: where a local or anonymous class was declared, a\n  stand-in for the outer class's instance code for member classes, nil for top-level ones.R4,i1189,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,clojure-specialsS24,R12,R13,R14,R15,R16,R17,R18,R19,R20,R21,R22,R23,R24,R25,R26,R27,R28,R29,R30,R31,R32,R33,R34,R35,m6,R4,i1203,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,arbace-specialsS16,R36,R37,R38,R39,R40,R41,R42,R43,R44,R45,R46,R47,R48,R49,R50,R51,m6,R4,i1207,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,core-var?m10,R0,TR1,L1,V1,R52,R4,i1211,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,resolve-varm8,R1,L1,V2,R8,R53,R4,i1214,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze7,core-opm10,R1,L1,V2,R8,R53,R10,s59,The name of the core var a head symbol resolves to, or nil.R4,i1219,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,macroexpand1m8,R1,L1,V2,R8,R54,R4,i1225,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,accessorizem8,R7,TR4,i1244,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,outer-super-callm8,R7,TR4,i1246,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,code-type-annsm8,R7,TR4,i1246,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze20,analyze-method-call*m8,R7,TR4,i1246,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,clj-constantm8,R7,TR4,i1248,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,clj-collectionm8,R7,TR4,i1248,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,clj-var-fieldm8,R7,TR4,i1248,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze7,analyzem8,R7,TR4,i1250,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,analyze-bodym8,R7,TR4,i1250,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,analyze-invokem8,R7,TR4,i1250,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,analyze-newm8,R7,TR4,i1250,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,analyze-dotm8,R7,TR4,i1250,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,analyze-opm8,R7,TR4,i1250,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze18,analyze-class-formm8,R7,TR4,i1250,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,analyze-symbolm8,R7,TR4,i1250,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,coerce-hintm8,R7,TR4,i1250,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze21,needs-outer-instance?m8,R7,TR4,i1250,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,ctor-call-nodem8,R7,TR4,i1250,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,with-form-infom10,R0,TR1,L1,V2,R54,R55,R4,i1253,R5,i1,R6,s25,arbace/classes/analyze.aem10,R1,L1,V2,R8,R54,R10,s42,Analyzes a form of code into a typed node.R4,i1261,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,branching-tail?m8,R7,TR4,i1298,R5,i1,R6,s25,arbace/classes/analyze.aem8,R7,TR4,i1298,R5,i1,R6,s25,arbace/classes/analyze.aem10,R1,L1,V3,R8,R56,R57,R10,s136,A tag on an expression gives its static type, as in Clojure; a checkcast keeps the\n  verifier happy where the type is not already known.R4,i1300,R5,i1,R6,s25,arbace/classes/analyze.aem10,R1,L1,V2,R8,R58,R10,s25,Analyzes forms as a `do`.R4,i1325,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,field-nodem10,R0,TR1,L1,V3,R8,R55,R11,R4,i1339,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,field-indexesm10,R59,C38,java.util.concurrent.ConcurrentHashMapR0,TR4,i1355,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,field-indexm12,R0,TR1,L1,MV2,R60,R61,m2,R59,R62,R10,s108,{name [position field]} of the first field of each name in fields (a class's :fields) that is\n  not derived.R4,i1360,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,find-own-fieldm10,R1,L1,V2,R8,R53,R10,s102,A field of the current class or an enclosing class body, innermost first:\n  [field class-name] or nil.R4,i1377,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,this-nodem8,R1,L1,V1,R8,R4,i1399,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,class-litm10,R0,TR1,L1,V2,R8,R63,R4,i1403,R5,i1,R6,s25,arbace/classes/analyze.aem8,R1,L1,V2,R8,R53,R4,i1406,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,arith-opsm88,s16,unchecked-negateV2,R64,R65,s16,unchecked-divideV2,R64,R66,s24,unchecked-subtract-floatV2,R67,R68,s1,*V2,R69,R70,s19,bit-shift-right-intV2,R71,R72,s18,unchecked-subtractV2,R64,R68,s20,unchecked-divide-intV2,R71,R66,s6,bit-orV2,R73,R74,s20,unchecked-negate-intV2,R71,R65,s13,unchecked-addV2,R64,R75,s17,unchecked-dec-intV2,R71,R76,s1,-V2,R69,R68,s18,bit-shift-left-intV2,R71,R77,s7,bit-xorV2,R73,R78,s3,remV2,R69,R79,s7,bit-andV2,R73,R80,s17,unchecked-add-intV2,R71,R75,s13,unchecked-decV2,R64,R76,s11,bit-and-notV2,R73,R81,s22,unchecked-negate-floatV2,R67,R65,s13,unchecked-incV2,R64,R82,s3,incV2,R69,R82,s7,bit-notV2,R73,R83,s23,unchecked-remainder-intV2,R71,R79,s28,unsigned-bit-shift-right-intV2,R71,R84,s24,unsigned-bit-shift-rightV2,R73,R84,s11,bit-and-intV2,R71,R80,s11,bit-not-intV2,R71,R83,s24,unchecked-multiply-floatV2,R67,R70,s18,unchecked-multiplyV2,R64,R70,s22,unchecked-subtract-intV2,R71,R68,s15,bit-shift-rightV2,R73,R72,s22,unchecked-multiply-intV2,R71,R70,s25,unchecked-remainder-floatV2,R67,R79,s19,unchecked-add-floatV2,R67,R75,s17,unchecked-inc-intV2,R71,R82,s4,quotV2,R69,R66,s14,bit-shift-leftV2,R73,R77,s11,bit-xor-intV2,R71,R78,s19,unchecked-remainderV2,R64,R79,s10,bit-or-intV2,R71,R74,s22,unchecked-divide-floatV2,R67,R66,s3,decV2,R69,R76,s1,+V2,R69,R75,m8,R0,TR4,i1464,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,conversionsm14,s13,unchecked-ints1,Is14,unchecked-longs1,Js15,unchecked-shorts1,Ss14,unchecked-bytes1,Bs14,unchecked-chars1,Cs15,unchecked-floats1,Fs16,unchecked-doubles1,Dm8,R0,TR4,i1486,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze19,checked-conversionsm14,s3,ints1,Is4,longs1,Js5,shorts1,Ss4,bytes1,Bs4,chars1,Cs5,floats1,Fs6,doubles1,Dm8,R0,TR4,i1490,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,comparisonsS5,s2,<=s2,>=s1,<s2,==s1,>m8,R0,TR4,i1493,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze7,unboxedm10,R0,TR1,L1,V1,R56,R4,i1495,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,prim-typem10,R0,TR1,L1,V1,R56,R4,i1501,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,prim-type-ofm12,R0,TR1,L1,V1,R56,R10,s66,The primitive type of a node's value (unboxing a wrapper), or nil.R4,i1503,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,clone-tail?m12,R0,TR1,L1,V1,R56,R10,s61,Is the value of node (through do and let) an array's clone()?R4,i1508,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,retype-clonem10,R0,TR1,L1,V2,R56,R85,R4,i1517,R5,i1,R6,s25,arbace/classes/analyze.aem12,R0,TR1,L1,V1,R56,R10,s79,Is the value of node (through do and let) that of a conditional, switch or try?R4,i1525,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,bound-nodem10,R1,L1,V2,R56,R85,R10,s141,Node, a value of an intersection type (:bounds), as a value of its bound that converts to\n  `to` (a cast to it, javac's TransTypes), or node.R4,i1535,R5,i1,R6,s25,arbace/classes/analyze.aem10,R1,L1,V4,R56,R85,R12,m4,R86,V1,R87,R74,m2,R87,s5,valueR10,s92,Converts node to type `to` (an assignment conversion; a const is converted at compile time).R4,i1545,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze7,operandm12,R0,TR1,L1,V2,R56,R88,R10,s82,Converts an operand to the operation type t: numeric promotion, literals narrowed.R4,i1594,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,int-operandm12,R0,TR1,L1,V2,R8,R56,R10,s138,An int operand (array dimension or index); in Clojure code (§5.13) also any other value,\n  converted by RT.intCast as Clojure converts it.R4,i1612,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze4,fmodm12,R0,TR1,L1,V2,R89,R3,R10,s88,Java's % on doubles (drem: the remainder of the truncated quotient, exact), for folding.R4,i1621,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,fold-arithm10,R0,TR1,L1,V4,R88,R90,R89,R3,R4,i1630,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,analyze-arithm10,R0,TR1,L1,V3,R8,R91,R92,R4,i1660,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze18,analyze-conversionm10,R0,TR1,L1,V6,R8,R85,R93,R94,R12,V1,R56,R4,i1705,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,compare-typem10,R0,TR1,L1,V2,R89,R3,R4,i1733,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,analyze-comparem10,R0,TR1,L1,V5,R8,R90,R95,R12,V1,R96,R4,i1741,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,bool-nodem10,R0,TR1,L1,V2,R8,R54,R4,i1764,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,lambda-form?m12,R0,TR1,L1,V1,R55,R10,s132,Is f a lambda or method reference, possibly under casts (javac's pending variable of\n  serializable lambda names sees through them)?R4,i1769,R5,i1,R6,s25,arbace/classes/analyze.aem8,R7,TR4,i1777,R5,i1,R6,s25,arbace/classes/analyze.aem8,R7,TR4,i1777,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,local-type-annsm12,R0,TR1,L1,V2,R8,R53,R10,s108,Type annotations of a local variable: TYPE_USE annotations on the binding symbol and those\n  inside its tag.R4,i1779,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,binding-typem12,R0,TR1,L1,V4,R8,R53,R97,R98,R10,s116,The type of a let/loop local: its tag, else its initializer's type (Clojure's loop widens\n  untagged int and float).R4,i1794,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,bind-initm10,R0,TR1,L1,V4,R8,R53,R97,R99,R4,i1808,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,analyze-letm10,R0,TR1,L1,V3,R8,V6,R100,R101,R12,R102,R103,R54,R98,R4,i1821,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,class-def-in?m12,R0,TR1,L1,V1,R54,R10,s43,Does form declare a class (anon, letclass)?R4,i1869,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,analyze-ifm10,R0,TR1,L1,V2,R8,V6,R100,R104,R105,R106,R103,R54,R4,i1875,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,analyze-recurm10,R0,TR1,L1,V3,R8,R95,R107,R4,i1891,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,expand-to-loopm12,R0,TR1,L1,V2,R8,R54,R10,s89,Macroexpands form until it is a loop* (or for-each*) form; nil if it does not become one.R4,i1911,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,analyze-labelm10,R0,TR1,L1,V2,R8,V4,R100,R108,R12,R102,R4,i1919,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,analyze-breakm10,R0,TR1,L1,V2,R8,V3,R100,R12,R95,R4,i1935,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,analyze-returnm10,R0,TR1,L1,V2,R8,V4,R100,R52,R103,R54,R4,i1944,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,analyze-throwm10,R0,TR1,L1,V2,R8,V2,R100,R109,R4,i1951,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,analyze-trym10,R0,TR1,L1,V2,R8,V3,R100,R12,R58,R4,i1964,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,analyze-lockingm10,R0,TR1,L1,V2,R8,V4,R100,R110,R12,R102,R4,i1983,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze20,analyze-field-accessm8,R7,TR4,i1991,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,super-nodem8,R7,TR4,i1991,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,field-super-nodem8,R7,TR4,i1991,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,analyze-set!m10,R0,TR1,L1,V2,R8,V3,R100,R11,R52,R4,i1993,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,applicable?m10,R0,TR1,L1,V3,R111,R92,R112,R4,i2046,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,more-specific?m10,R0,TR1,L1,V2,R113,R114,R4,i2056,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,expand-varargsm10,R0,TR1,L1,V2,R115,R9,R4,i2061,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze17,param-tags-match?m12,R0,TR1,L1,V3,R116,R117,R118,R10,s140,Do the param-tags match method m? tag-descs: each tag's descriptor as a delay (resolved once\n  for all the candidates, when first compared).R4,i2066,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,clj-fi-excludedS3,s20,java/util/Comparators18,java/lang/Runnables29,java/util/concurrent/Callablem8,R0,TR4,i2077,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze8,find-samm8,R7,TR4,i2079,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,clj-fi-methodm10,R1,L1,V1,R119,R10,s518,Compiler's FISupport.maybeFIMethod: for a parameter of type desc that is a\n  @FunctionalInterface other than Callable, Runnable and Comparator, its method (an abstract\n  one, of at most 10 parameters, other than equals, toString and hashCode) that an IFn argument\n  is adapted to, as {:name :ps [param desc ...] :ret desc}; else nil. A class compiled from\n  source (*from-source*: j2g's world, where the JDK's classes have Java forms) is asked\n  through its declaration: its annotations and its single abstract method.R4,i2081,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,clj-arg-classm12,R0,TR1,L1,V1,R56,R10,s174,The class arbace.lang.Compiler knows for an argument node (Expr.getJavaClass), as a\n  descriptor: nil for nil, ::unknown for Object (the type of what Clojure leaves untyped).R4,i2110,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,clj-prim-argsm16,s1,IS5,s1,Js1,Ss19,Ljava/lang/Integer;s1,Bs16,Ljava/lang/Long;s1,FS2,s17,Ljava/lang/Float;s1,Ds1,DS2,s18,Ljava/lang/Double;s1,Fs1,JS4,s1,Ss1,Bs16,Ljava/lang/Long;s1,Is1,CS1,s21,Ljava/lang/Character;s1,SS1,s17,Ljava/lang/Short;s1,BS1,s16,Ljava/lang/Byte;s1,ZS1,s19,Ljava/lang/Boolean;m10,R0,TR4,i2119,R5,i1,R6,s25,arbace/classes/analyze.aeR10,s66,Reflector.paramArgTypeMatch's conversions to primitive parameters.v22,arbace.classes.analyze20,clj-param-arg-match?m12,R0,TR1,L1,V2,R120,R89,R10,s86,Reflector.paramArgTypeMatch for parameter type p and argument class a (clj-arg-class).R4,i2130,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,clj-subsumes?m12,R0,TR1,L1,V2,R121,R122,R10,s62,Compiler.subsumes: is parameter list c1 more specific than c2?R4,i2141,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze19,clj-ret-assignable?m12,R0,TR1,L1,V2,R123,R124,R10,s51,Class.isAssignableFrom on return types: r1 from r2.R4,i2150,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze18,clj-matching-indexm12,R0,TR1,L1,V4,R87,R125,R95,R126,R10,s183,Compiler.getMatchingParams: the index of the parameter list (of plists, with return types\n  rets) chosen for the argument nodes, or -1; \"More than one matching method found\" on a tie.R4,i2155,R5,i1,R6,s25,arbace/classes/analyze.ae")

var Lit_950 *jrt.String = jrt.Intern("arbace.classes.analyze$add_capture_BANG_")

var Lit_951 *jrt.String = jrt.Intern("arbace.classes.analyze$local_ref")

var Lit_952 *jrt.String = jrt.Intern("arbace.classes.analyze$prologue_class_QMARK_")

var Lit_953 *jrt.String = jrt.Intern("arbace.classes.analyze$outer_this_node")

var Lit_954 *jrt.String = jrt.Intern("arbace.classes.analyze$outer_this_node_STAR_")

var Lit_955 *jrt.String = jrt.Intern("arbace.classes.analyze$class_parent_frame")

var Lit_956 *jrt.String = jrt.Intern("arbace.classes.analyze$core_var_QMARK_")

var Lit_957 *jrt.String = jrt.Intern("arbace.classes.analyze$resolve_var")

var Lit_958 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op")

var Lit_959 *jrt.String = jrt.Intern("arbace.classes.analyze$macroexpand1")

var Lit_960 *jrt.String = jrt.Intern("arbace.classes.analyze$with_form_info")

var Lit_961 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze")

var Lit_962 *jrt.String = jrt.Intern("arbace.classes.analyze$coerce_hint")

var Lit_963 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_body")

var Lit_964 *jrt.String = jrt.Intern("arbace.classes.analyze$field_node")

var Lit_965 *jrt.String = jrt.Intern("arbace.classes.analyze$field_index")

var Lit_966 *jrt.String = jrt.Intern("arbace.classes.analyze$find_own_field")

var Lit_967 *jrt.String = jrt.Intern("arbace.classes.analyze$this_node")

var Lit_968 *jrt.String = jrt.Intern("arbace.classes.analyze$class_lit")

var Lit_969 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_symbol")

var Lit_970 *jrt.String = jrt.Intern("arbace.classes.analyze$unboxed")

var Lit_971 *jrt.String = jrt.Intern("arbace.classes.analyze$prim_type")

var Lit_972 *jrt.String = jrt.Intern("arbace.classes.analyze$prim_type_of")

var Lit_973 *jrt.String = jrt.Intern("arbace.classes.analyze$clone_tail_QMARK_")

var Lit_974 *jrt.String = jrt.Intern("arbace.classes.analyze$retype_clone")

var Lit_975 *jrt.String = jrt.Intern("arbace.classes.analyze$branching_tail_QMARK_")

var Lit_976 *jrt.String = jrt.Intern("arbace.classes.analyze$bound_node")

var Lit_977 *jrt.String = jrt.Intern("arbace.classes.analyze$convert_node")

var Lit_978 *jrt.String = jrt.Intern("arbace.classes.analyze$operand")

var Lit_979 *jrt.String = jrt.Intern("arbace.classes.analyze$int_operand")

var Lit_980 *jrt.String = jrt.Intern("arbace.classes.analyze$fmod")

var Lit_981 *jrt.String = jrt.Intern("arbace.classes.analyze$fold_arith")

var Lit_982 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_arith")

var Lit_983 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_conversion")

var Lit_984 *jrt.String = jrt.Intern("arbace.classes.analyze$compare_type")

var Lit_985 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_compare")

var Lit_986 *jrt.String = jrt.Intern("arbace.classes.analyze$bool_node")

var Lit_987 *jrt.String = jrt.Intern("arbace.classes.analyze$lambda_form_QMARK_")

var Lit_988 *jrt.String = jrt.Intern("arbace.classes.analyze$local_type_anns")

var Lit_989 *jrt.String = jrt.Intern("arbace.classes.analyze$binding_type")

var Lit_990 *jrt.String = jrt.Intern("arbace.classes.analyze$bind_init")

var Lit_991 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_let")

var Lit_992 *jrt.String = jrt.Intern("arbace.classes.analyze$class_def_in_QMARK_")

var Lit_993 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_if")

var Lit_994 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_recur")

var Lit_995 *jrt.String = jrt.Intern("arbace.classes.analyze$expand_to_loop")

var Lit_996 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_label")

var Lit_997 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_break")

var Lit_998 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_return")

var Lit_999 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_throw")

var Lit_1000 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_try")

var Lit_1001 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_locking")

var Lit_1002 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_set_BANG_")

var Lit_1003 *jrt.String = jrt.Intern("arbace.classes.analyze$applicable_QMARK_")

var Lit_1004 *jrt.String = jrt.Intern("arbace.classes.analyze$more_specific_QMARK_")

var Lit_1005 *jrt.String = jrt.Intern("arbace.classes.analyze$expand_varargs")

var Lit_1006 *jrt.String = jrt.Intern("arbace.classes.analyze$param_tags_match_QMARK_")

var Lit_1007 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_fi_method")

var Lit_1008 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_arg_class")

var Lit_1009 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_param_arg_match_QMARK_")

var Lit_1010 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_subsumes_QMARK_")

var Lit_1011 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_ret_assignable_QMARK_")

var Lit_1012 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_matching_index")

var Lit_1013 *jrt.String = jrt.Intern("kn7,privatekn8,arglistsyn4,argskn3,dockn4,linekn6,columnkn4,fileyn5,candsyn4,kindyn5,mnameyn2,cnyn4,actxyn4,whatyn10,param-tagsyn4,fromyn4,nodeyn2,toyn1,myn8,varargs?yn11,static-typeyn10,owner-descyn6,targetyn3,whyyn5,nodesyn5,owneryn4,descyn9,arg-nodesyn1,eyn1,fyn7,reflectkn8,declaredyn2,psyn3,retyn1,&kn4,keysyn7,specialyn14,owner-overrideyn7,ret-tagyn9,type-argskn2,asyn4,optsyn2,tnyn5,fnameyn1,kyn4,formyn5,formsyn1,_yn6,memberyn5,outeryn5,tdescyn3,clsyn1,ayn4,idxsyn6,a-nodeyn4,moreyn1,xyn1,vyn3,copyn5,fnodeyn6,switchyn11,method-ref*yn7,deftypeyn8,letclassyn2,fnyn6,class*yn10,method-refyn6,lambdayn3,newyn8,deftype*yn3,fn*yn5,letfnyn4,anonyn9,defrecordyn7,lambda*yn7,switch*yn5,scopeyn7,lenientyn10,field-inityn1,nyn7,static?yn6,boundsyn11,method-infoyn4,headyn5,sactxyn4,envsyn1,cv22,arbace.classes.analyze15,clj-type-stringm12,R0,TR1,L1,V1,R2,R3,s30,Compiler.getTypeStringForArgs.R4,i2188,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,clj-selectm10,R1,L1,V5,R7,R2,R8,R9,R10,R3,s460,The method (or constructor) of cands that arbace.lang.Compiler calls for the argument nodes,\n  marked :clojure-args (its arguments converted as Clojure converts them): the only one of that\n  arity, else the one Compiler.getMatchingParams chooses (kind :instance, :static or :ctor of\n  class cn), with the compiler's errors. When it chooses none an instance method or constructor\n  is called by reflection, as in Clojure (an unresolved failure, see or-reflect).R4,i2193,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,select-methodm10,R1,L1,V5,R11,R7,R2,R12,R13,R3,s181,Chooses among candidate methods for argument nodes (JLS 15.12.2 on erased types: strict,\n  loose, then variable arity invocation; then literal narrowing). Returns [method varargs?].R4,i2218,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze19,instance-candidatesm10,R1,L1,V3,R14,R10,R9,R3,s110,The candidates of an instance method call (.mname x ...) from class `from` on a receiver of\n  class cn (§5.6).R4,i2254,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze17,static-candidatesm10,R1,L1,V3,R14,R10,R9,R3,s71,The candidates of a static method call (C/mname ...) from class `from`.R4,i2262,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,ctor-candidatesm10,R1,L1,V2,R14,R10,R3,s58,The constructors of class cn accessible from class `from`.R4,i2269,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,clj-arg-convertm12,R0,TR1,L1,V2,R15,R16,R3,s248,An argument node converted to parameter type `to` as arbace.lang.Compiler converts it\n  (HostExpr.emitUnboxArg): references by RT's longCast, intCast..., Boolean and Character\n  unboxed, references of other types checked, long to int by RT.intCast.R4,i2274,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,convert-argsm10,R1,L1,V3,R17,R2,R18,R3,s191,Converts argument nodes to the parameter types of method m (packing variable arity\n  arguments into an array); as Clojure converts them when m was chosen for Clojure's code\n  (:clojure-args).R4,i2326,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,qualifying-ownerm12,R0,TR1,L1,V2,R19,R17,R3,s107,JLS 13.1: the class named in the instruction is the receiver's static type, except for\n  members of Object.R4,i2341,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,invoke-nodem8,R1,L1,V7,R11,R8,R20,R17,R21,R2,R18,R4,i2355,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze22,signature-polymorphic?m12,R0,TR1,L1,V1,R17,R3,s88,JVMS 2.9.3: a native variable arity method of MethodHandle or VarHandle taking Object[].R4,i2366,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze8,reflect?m12,R0,TR1,L1,V1,R11,R3,s241,Does a call the compiler cannot resolve go through arbace.lang.Reflector? With\n  ^{:reflection :warn} on the class (SPEC §12 question 7), and in the code of fns that\n  arbace.lang.Compiler hands over (^{:reflection :clojure}), as in Clojure.R4,i2374,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze18,reflection-warningm10,R0,TR1,L1,V3,R11,R12,R22,R4,i2381,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze7,objectsm10,R0,TR1,L1,V1,R23,R4,i2387,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,reflective-nodem10,R0,TR1,L1,V4,R24,R9,R25,R2,R4,i2390,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,reflective-callm12,R0,TR1,L1,V5,R11,R21,R9,R26,R22,R3,s64,A call through arbace.lang.Reflector at run time (see reflect?).R4,i2394,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,unresolved?m12,R0,TR1,L1,V1,R27,R3,s79,Is e the compiler's failure to resolve a member (so that reflection may apply)?R4,i2405,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,or-reflectm12,R0,TR1,L1,V3,R11,R28,R29,R3,s84,f's node, or when reflection applies and f fails to resolve a member, (reflect why).R4,i2412,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,type-arg-annsm8,R30,TR4,i2421,R5,i1,R6,s25,arbace/classes/analyze.aem8,R30,TR4,i2421,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze8,invokersm8,R0,TR4,i2428,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,invokers?m10,R0,TR1,L1,V0,R4,i2430,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,invokers-methodm10,R0,TR1,L1,V2,R9,R25,R4,i2432,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,invokers-callm12,R0,TR1,L1,V7,R11,R24,R9,R21,R31,R32,R2,R3,s244,(R) mh.invokeExact(a...) as Invokers.invokeExactR(mh, R.class, new Class[] {A...}, new Object[] {a...}), R\n  the return type's kind (L: Object, cast to R); invoke likewise; nil when the call is not MethodHandle's or the\n  world has no Invokers.R4,i2436,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,invokers-lookupm12,R0,TR1,L1,V4,R11,R10,R9,R2,R3,s91,MethodHandles.lookup() in class C as Invokers.lookup(C.class), when the world has Invokers.R4,i2455,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze19,analyze-method-callm10,R1,L1,V6,R11,R21,R9,R2,R33,m4,R34,V5,R35,R13,R36,R37,R38,R39,R40,R3,s63,(.name target args) where target is a node of static type `tt`.R4,i2463,R5,i1,R6,s25,arbace/classes/analyze.aem8,R1,L1,V6,R11,R21,R9,R2,R33,m2,R34,V5,R35,R13,R36,R37,R26,R4,i2478,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,clj-convertm8,R30,TR4,i2508,R5,i1,R6,s25,arbace/classes/analyze.aem8,R30,TR4,i2508,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze19,analyze-static-callm8,R1,L1,V6,R11,R10,R9,R2,R33,m2,R34,V1,R13,R4,i2510,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze21,analyze-field-access*m8,R30,TR4,i2538,R5,i1,R6,s25,arbace/classes/analyze.aem10,R1,L2,V3,R11,R41,R42,V4,R11,R41,R42,R43,R3,s85,Field `fname` of target node; k is called with the field and owner (default: a read).R4,i2540,R5,i1,R6,s25,arbace/classes/analyze.aem10,R0,TR1,L1,V4,R11,R41,R42,R43,R4,i2552,R5,i1,R6,s25,arbace/classes/analyze.aem10,R0,TR1,L1,V1,R11,R4,i2580,R5,i1,R6,s25,arbace/classes/analyze.aem12,R0,TR1,L1,V2,R11,R21,R3,s188,The receiver of a field read or written through super or Outer/super (Outer.super.f: the\n  field of Outer's superclass on the enclosing instance, JLS 15.11.2), or nil for another\n  target.R4,i2585,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,receiver-classm12,R0,TR1,L1,V2,R11,R44,R3,s55,If form names a class (not a local), its internal name.R4,i2599,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,analyze-dot*m8,R30,TR4,i2606,R5,i1,R6,s25,arbace/classes/analyze.aem12,R0,TR1,L1,V2,R11,R45,R3,s139,Type annotations of explicit type arguments (^{:type-args [types]} on a method symbol, SPEC\n  §8.4): [[index [[path annotation] ...]] ...].R4,i2608,R5,i1,R6,s25,arbace/classes/analyze.aem10,R1,L1,V2,R11,V5,R46,R21,R47,R39,R44,R3,s53,(. target member args*) and (. target (member args*))R4,i2614,R5,i1,R6,s25,arbace/classes/analyze.aem10,R0,TR1,L1,V2,R11,V7,R46,R21,R47,R33,R2,R39,R44,R4,i2623,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze18,outer-instance-form8,R30,TR4,i2699,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze20,capture-local-super!m12,R0,TR1,L1,V2,R11,R10,R3,s323,A constructor of a subclass of local class cn calls cn's constructor, which takes cn's\n  captured values: the subclass (or anonymous class) passes them on, so it captures them too\n  (javac's Lower.freevars of a local superclass); also the enclosing locals cn's form names, as\n  for a creation in its own body (analyze-new).R4,i2701,R5,i1,R6,s25,arbace/classes/analyze.aem10,R1,L1,V6,R11,R10,R2,R8,R33,m2,R34,V3,R48,R13,R26,R3,s72,A call of constructor of class cn with args; kind :new, :super or :this.R4,i2716,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,array-newm10,R0,TR1,L1,V3,R11,R49,R2,R4,i2735,R5,i1,R6,s25,arbace/classes/analyze.aem10,R0,TR1,L1,V1,R10,R4,i2747,R5,i1,R6,s25,arbace/classes/analyze.aem10,R1,L1,V2,R11,R10,R3,s65,The implicit outer instance node for creating class cn from actx.R4,i2751,R5,i1,R6,s25,arbace/classes/analyze.aem8,R1,L1,V2,R11,V4,R46,R50,R33,R2,R4,i2767,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,analyze-agetm10,R0,TR1,L1,V3,R11,V4,R46,R51,R33,R52,R53,R4,i2818,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,analyze-asetm10,R0,TR1,L1,V3,R11,V4,R46,R51,R33,R54,R53,R4,i2825,R5,i1,R6,s25,arbace/classes/analyze.aem10,R1,L1,V2,R11,R44,R3,s88,Type annotations of a type form in code, for the instruction it types: [[path ann] ...].R4,i2838,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze17,analyze-instance?m10,R0,TR1,L1,V2,R11,V3,R46,R50,R55,R4,i2845,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,analyze-castm10,R0,TR1,L1,V2,R11,V3,R46,R50,R55,R4,i2852,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze8,ref-nodem10,R0,TR1,L1,V3,R11,R55,R12,R4,i2872,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,analyze-anonm8,R30,TR4,i2879,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,analyze-letclassm8,R30,TR4,i2879,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze17,analyze-ctor-callm8,R30,TR4,i2879,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,analyze-java-strm8,R30,TR4,i2879,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze19,analyze-java-assertm8,R30,TR4,i2879,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze22,analyze-with-resourcesm8,R30,TR4,i2879,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,analyze-for-eachm8,R30,TR4,i2879,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,analyze-switchm8,R30,TR4,i2879,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,analyze-lambdam8,R30,TR4,i2879,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze18,analyze-method-refm8,R30,TR4,i2879,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze19,analyze-if-instancem8,R30,TR4,i2879,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,method-sugarm12,R0,TR1,L1,V2,R11,R44,R3,s46,Clojure's interop sugar as a `.` form, or nil.R4,i2883,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,analyze-fn-callm8,R30,TR4,i2915,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,var-invoke-nodem8,R30,TR4,i2915,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze19,analyze-clj-specialm8,R30,TR4,i2915,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,specializedm12,R0,TR1,L1,V1,R28,R3,s83,The node of f, or nil when f fails to compile (the Clojure operation then applies).R4,i2917,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,with-node-localsm8,R30,TR4,i2924,R5,i1,R6,s25,arbace/classes/analyze.aem10,R1,L1,V4,R11,R15,R16,R12,R3,s173,convert-node; in Clojure code (§5.13) a value that no assignment conversion gives the\n  primitive type `to` is converted by RT's longCast, intCast... as Clojure converts it.R4,i2926,R5,i1,R6,s25,arbace/classes/analyze.aem12,R0,TR1,L1,V3,R11,R23,R28,R3,s88,Analyzes (f syms) with the symbols bound to the already analyzed nodes, in order: a let.R4,i2944,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,clj-call-nodem12,R0,TR1,L1,V3,R11,R56,R23,R3,s165,A call of the function of var v on the analyzed argument nodes, as Clojure compiles it: its\n  :inline expansion if it has one for this arity, else a call of the var.R4,i2956,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,core-op-nodem12,R0,TR1,L1,V3,R11,R44,R57,R3,s165,A call of the core var named cop: an instruction where its operands allow (§5.4, §5.5),\n  else a call as Clojure compiles it (§5.13). Each argument is analyzed once.R4,i2967,R5,i1,R6,s25,arbace/classes/analyze.aem8,R1,L1,V2,R11,R44,R4,i3076,R5,i1,R6,s25,arbace/classes/analyze.aem10,R1,L1,V3,R11,R56,R23,R3,s56,A call of the function in var v with the argument nodes.R4,i3155,R5,i1,R6,s25,arbace/classes/analyze.aem10,R1,L1,V5,R11,R58,R2,R33,V1,R26,R3,s63,(f args*) where f is the node of any value: IFn.invoke (§5.13).R4,i3165,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,expand-fullym12,R0,TR1,L1,V2,R11,R44,R3,s45,Macroexpands form until its head is no macro.R4,i3178,R5,i1,R6,s25,arbace/classes/analyze.aem10,R1,L1,V2,R11,R44,R3,s214,Clojure's fn*, letfn*, case*, def, var, reify*, deftype* and import* in code compiled by the\n  Java forms compiler, rewritten by arbace.classes.lower (§5.13, §9.5), or (deftype*) compiled\n  by arbace.lang.Compiler.R4,i3185,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze18,non-constant-headsS16,R59,R60,R61,R62,R63,R64,R65,R66,R67,R68,R69,R70,R71,R72,R73,R74,m8,R0,TR4,i3236,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,may-be-constant?m12,R0,TR1,L1,V1,R44,R3,s162,Can form be a constant expression? Those declaring classes or lambdas cannot, and analyzing\n  them would declare those (an anonymous class number would be taken).R4,i3240,R5,i1,R6,s25,arbace/classes/analyze.aem10,R1,L3,V3,R75,R44,R25,V4,R75,R44,R25,R76,V5,R75,R44,R25,R76,R77,R3,s86,Analyzes a form expected to be a constant of type desc; returns the const node or nil.R4,i3249,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,creation-actxm10,R0,TR1,L1,V1,R78,R4,i3270,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,body-actxm12,R0,TR1,L1,V6,R78,R8,R79,R80,R81,R32,R3,s41,The analysis context for code of class n.R4,i3277,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,bind-paramsm12,R0,TR1,L1,V3,R11,R78,R17,R3,s72,Binds the receiver (unless static) and the parameters of method entry m.R4,i3292,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze19,analyze-method-bodym10,R0,TR1,L1,V2,R78,R17,R4,i3306,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,ctor-call-form?m10,R0,TR1,L1,V1,R28,R4,i3314,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze17,nested-ctor-call?m12,R0,TR1,L1,V1,R28,R3,s87,Is the constructor call in form f at the statement level of (nested) let and do bodies?R4,i3316,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze19,implicit-super-callm10,R0,TR1,L1,V2,R11,R78,R4,i3326,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze18,analyze-ctor-call*m8,R30,TR4,i3342,R5,i1,R6,s25,arbace/classes/analyze.aem10,R1,L1,V3,R11,R44,R8,R3,s206,(super. args) or (this. args); param-tags on the head pin the constructor (§4.7). In a\n  constructor whose call is nested in the prologue's let forms (:ctor-phase), the code after\n  it is past the prologue.R4,i3344,R5,i1,R6,s25,arbace/classes/analyze.aem10,R0,TR1,L1,V3,R11,V3,R82,R33,R2,R8,R4,i3355,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze17,analyze-ctor-bodym10,R0,TR1,L1,V2,R78,R17,R4,i3369,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze17,analyze-enum-bodym8,R30,TR4,i3413,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze22,analyze-enum-constantsm12,R0,TR1,L1,V2,R78,R83,R3,s64,The <clinit> nodes creating the constants of enum n and $VALUES.R4,i3415,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,analyze-class!m10,R1,L1,V1,R78,R3,s160,Analyzes all code of class n, in the textual order of its members (so anonymous classes are\n  numbered as javac numbers them). Results go to the class's :state.R4,i3439,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,class-genericsm12,R0,TR1,L1,V1,R78,R3,s112,Generic view of class n: {:tparams [sym] :supers [tnode] :methods [{:name :desc :params [tnode]\n  :bounds {}}]}.R4,i3507,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,supertype-envsm12,R0,TR1,L1,V1,R78,R3,s129,For every supertype S of class n: S -> substitution of S's type variables in n's terms (nil\n  for raw or non-generic supertypes).R4,i3543,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,erased-paramsm10,R0,TR1,L1,V4,R78,R84,R85,R17,R4,i3569,R5,i1,R6,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,param-keysm12,R0,TR1,L1,V4,R78,R84,R85,R17,R3,s365,The parameters of method m of class c, as a member of class n, for matching an override:\n  erased, but a parameter of one of m's own type variables with several bounds as the set of its\n  bounds' erasures (JLS 8.4.4: <T extends A & B> and <T extends B & A> are the same type\n  parameter; javac's bridge then calls the reordered override: ReorderedBoundsTest, JC4b).R4,i3581,R5,i1,R6,s25,arbace/classes/analyze.ae")

var Lit_1014 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_type_string")

var Lit_1015 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_select")

var Lit_1016 *jrt.String = jrt.Intern("arbace.classes.analyze$select_method")

var Lit_1017 *jrt.String = jrt.Intern("arbace.classes.analyze$instance_candidates")

var Lit_1018 *jrt.String = jrt.Intern("arbace.classes.analyze$static_candidates")

var Lit_1019 *jrt.String = jrt.Intern("arbace.classes.analyze$ctor_candidates")

var Lit_1020 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_arg_convert")

var Lit_1021 *jrt.String = jrt.Intern("arbace.classes.analyze$convert_args")

var Lit_1022 *jrt.String = jrt.Intern("arbace.classes.analyze$qualifying_owner")

var Lit_1023 *jrt.String = jrt.Intern("arbace.classes.analyze$invoke_node")

var Lit_1024 *jrt.String = jrt.Intern("arbace.classes.analyze$signature_polymorphic_QMARK_")

var Lit_1025 *jrt.String = jrt.Intern("arbace.classes.analyze$reflect_QMARK_")

var Lit_1026 *jrt.String = jrt.Intern("arbace.classes.analyze$reflection_warning")

var Lit_1027 *jrt.String = jrt.Intern("arbace.classes.analyze$objects")

var Lit_1028 *jrt.String = jrt.Intern("arbace.classes.analyze$reflective_node")

var Lit_1029 *jrt.String = jrt.Intern("arbace.classes.analyze$reflective_call")

var Lit_1030 *jrt.String = jrt.Intern("arbace.classes.analyze$unresolved_QMARK_")

var Lit_1031 *jrt.String = jrt.Intern("arbace.classes.analyze$or_reflect")

var Lit_1032 *jrt.String = jrt.Intern("jdk/internal/jrt/Invokers")

var Lit_1033 *jrt.String = jrt.Intern("arbace.classes.analyze$invokers_QMARK_")

var Lit_1034 *jrt.String = jrt.Intern("arbace.classes.analyze$invokers_method")

var Lit_1035 *jrt.String = jrt.Intern("arbace.classes.analyze$invokers_call")

var Lit_1036 *jrt.String = jrt.Intern("arbace.classes.analyze$invokers_lookup")

var Lit_1037 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_call")

var Lit_1038 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_call_STAR_")

var Lit_1039 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_static_call")

var Lit_1040 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_field_access")

var Lit_1041 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_field_access_STAR_")

var Lit_1042 *jrt.String = jrt.Intern("arbace.classes.analyze$super_node")

var Lit_1043 *jrt.String = jrt.Intern("arbace.classes.analyze$field_super_node")

var Lit_1044 *jrt.String = jrt.Intern("arbace.classes.analyze$receiver_class")

var Lit_1045 *jrt.String = jrt.Intern("arbace.classes.analyze$type_arg_anns")

var Lit_1046 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_dot")

var Lit_1047 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_dot_STAR_")

var Lit_1048 *jrt.String = jrt.Intern("arbace.classes.analyze$capture_local_super_BANG_")

var Lit_1049 *jrt.String = jrt.Intern("arbace.classes.analyze$ctor_call_node")

var Lit_1050 *jrt.String = jrt.Intern("arbace.classes.analyze$array_new")

var Lit_1051 *jrt.String = jrt.Intern("arbace.classes.analyze$needs_outer_instance_QMARK_")

var Lit_1052 *jrt.String = jrt.Intern("arbace.classes.analyze$outer_instance_for")

var Lit_1053 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_new")

var Lit_1054 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_aget")

var Lit_1055 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_aset")

var Lit_1056 *jrt.String = jrt.Intern("arbace.classes.analyze$code_type_anns")

var Lit_1057 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_instance_QMARK_")

var Lit_1058 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_cast")

var Lit_1059 *jrt.String = jrt.Intern("arbace.classes.analyze$ref_node")

var Lit_1060 *jrt.String = jrt.Intern("arbace.classes.analyze$method_sugar")

var Lit_1061 *jrt.String = jrt.Intern("arbace.classes.analyze$specialized")

var Lit_1062 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_convert")

var Lit_1063 *jrt.String = jrt.Intern("arbace.classes.analyze$with_node_locals")

var Lit_1064 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_call_node")

var Lit_1065 *jrt.String = jrt.Intern("arbace.classes.analyze$core_op_node")

var Lit_1066 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_op")

var Lit_1067 *jrt.String = jrt.Intern("arbace.classes.analyze$var_invoke_node")

var Lit_1068 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_fn_call")

var Lit_1069 *jrt.String = jrt.Intern("arbace.classes.analyze$expand_fully")

var Lit_1070 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_clj_special")

var Lit_1071 *jrt.String = jrt.Intern("arbace.classes.analyze$may_be_constant_QMARK_")

var Lit_1072 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_const_form")

var Lit_1073 *jrt.String = jrt.Intern("arbace.classes.analyze$creation_actx")

var Lit_1074 *jrt.String = jrt.Intern("arbace.classes.analyze$body_actx")

var Lit_1075 *jrt.String = jrt.Intern("arbace.classes.analyze$bind_params")

var Lit_1076 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_body")

var Lit_1077 *jrt.String = jrt.Intern("arbace.classes.analyze$ctor_call_form_QMARK_")

var Lit_1078 *jrt.String = jrt.Intern("arbace.classes.analyze$nested_ctor_call_QMARK_")

var Lit_1079 *jrt.String = jrt.Intern("arbace.classes.analyze$implicit_super_call")

var Lit_1080 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_ctor_call")

var Lit_1081 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_ctor_call_STAR_")

var Lit_1082 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_ctor_body")

var Lit_1083 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_constants")

var Lit_1084 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_class_BANG_")

var Lit_1085 *jrt.String = jrt.Intern("arbace.classes.analyze$class_generics")

var Lit_1086 *jrt.String = jrt.Intern("arbace.classes.analyze$supertype_envs")

var Lit_1087 *jrt.String = jrt.Intern("arbace.classes.analyze$erased_params")

var Lit_1088 *jrt.String = jrt.Intern("arbace.classes.analyze$param_keys")

var Lit_1089 *jrt.String = jrt.Intern("kn8,arglistsyn1,nkn3,dockn4,linekn6,columnkn4,filekn7,privateyn5,namesyn4,fromyn4,actxyn1,_yn10,super-formyn4,argsyn1,&yn7,membersyn5,specsyn4,bodyyn4,whatyn1,cyn5,ectoryn1,tyn1,vyn1,dkn8,declaredyn3,msgkn2,asyn4,formyn2,cnyn3,symyn4,collyn2,bvyn8,bindingsyn3,finyn3,samyn8,boundaryyn2,tgyn4,sretyn2,fiyn6,paramsyn2,psyn3,retyn7,call-fnyn1,myn5,candsyn5,stubsyn10,param-tagsyn4,moreyn2,stkn4,keysyn9,componentyn3,patyn1,xyn4,thenyn4,elseyn1,eyn4,descyn3,selyn7,clauseskn3,tagyn19,java.io.InputStreamyn2,nsyn1,fyn3,topyn2,inyn1,oyn4,codeyn6,targetyn4,nodekn7,dynamicyn5,mnameyn1,kyn4,inityn5,fnameyn5,elemsv22,arbace.classes.analyze12,add-bridges!m10,R0,L1,V1,R1,R2,s372,Adds javac's bridge methods to class n (TransTypes.addBridgeIfNeeded): for each method meth\n  of a supertype whose implementation in n has another erasure, unless a bridge with meth's\n  erasure is already present at or below the implementation. Bridges of enclosing classes are\n  not yet present, as javac translates nested classes before adding the outer class's bridges.R3,i3600,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,supertypes-firstm12,R6,TR0,L1,V1,R7,R2,s72,Names ordered so that supertypes in the list come before their subtypes.R3,i3705,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze19,mark-enum-abstract!m12,R6,TR0,L1,V1,R1,R2,s120,An enum with constant bodies that leaves an interface method unimplemented is abstract\n  (javac's markAbstractIfNeeded).R3,i3718,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze16,process-classes!m10,R0,L1,V1,R8,R2,s123,Resolves headers and members of the classes declared since position `from` of the unit's\n  order, then analyzes their code.R3,i3739,R4,i1,R5,s25,arbace/classes/analyze.aem10,R0,L1,V2,R9,V6,R10,R10,R11,R12,R13,R14,R2,s144,(anon Super [args] member*) and (anon Inner [args] :outer o member*) (§4.8); param-tags on\n  the argument vector pin the superclass constructor.R3,i3752,R4,i1,R5,s25,arbace/classes/analyze.aem8,R0,L1,V2,R9,V5,R10,R10,R15,R13,R16,R3,i3840,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze7,not-yetm10,R6,TR0,L1,V1,R17,R3,i3860,R4,i1,R5,s25,arbace/classes/analyze.aem10,R0,L1,V4,R9,R1,R18,R19,R2,s159,The anonymous class E$n of an enum constant with a body; its constructor takes the enum\n  constructor's parameters (after name and ordinal) and passes them on.R3,i3862,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,const-stringm10,R0,L1,V2,R20,R21,R2,s39,Java's string conversion of a constant.R3,i3881,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze17,accessible-class?m10,R6,TR0,L1,V2,R9,R1,R3,i3891,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze19,sharpest-accessiblem10,R6,TR0,L1,V2,R9,R22,R3,i3896,R4,i1,R5,s25,arbace/classes/analyze.aem8,R0,L1,V2,R9,V3,R10,R13,R12,R3,i3905,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze20,analyze-java-assert*m8,R23,TR3,i3931,R4,i1,R5,s25,arbace/classes/analyze.aem8,R0,L1,V2,R9,V5,R10,R18,R24,R25,R26,R3,i3933,R4,i1,R5,s25,arbace/classes/analyze.aem10,R6,TR0,L1,V3,R9,R27,V5,R10,R18,R24,R25,R26,R3,i3940,R4,i1,R5,s25,arbace/classes/analyze.aem8,R0,L1,V2,R9,V4,R10,V4,R28,R29,R25,R30,R13,R16,R3,i3959,R4,i1,R5,s25,arbace/classes/analyze.aem8,R0,L1,V2,R9,V4,R10,R31,R13,R16,R3,i4003,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,object-methodsS3,s10,hashCode()s10,toString()s26,equals(Ljava/lang/Object;)m8,R6,TR3,i4042,R4,i1,R5,s25,arbace/classes/analyze.aem10,R0,L1,V1,R1,R2,s68,The single abstract method of functional interface n: {:name :desc}.R3,i4044,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze20,lambda-method-prefixm8,R23,TR3,i4074,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze8,fi-typesm12,R6,TR0,L1,V2,R9,R26,R2,s146,[main-interface markers serializable? intersection] of a lambda's target type form. Serializable\n  is no marker: it makes the lambda serializable.R3,i4076,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze19,serial-lambda-name!m12,R6,TR0,L1,V4,R9,R32,R33,R34,R2,s175,javac's name for a serializable lambda: a hash of the enclosing method's signature, the\n  functional interface, the variable assigned and the captured locals (LambdaToMethod).R3,i4086,R4,i1,R5,s25,arbace/classes/analyze.aem10,R6,TR0,L1,V1,R9,R3,i4102,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze12,lambda-name!m10,R6,TR0,L1,V1,R9,R3,i4112,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,lambda-ret-descm12,R6,TR0,L1,V3,R9,R35,R36,R2,s468,The descriptor of a lambda's return tag. javac records the inferred return type, which may be\n  an anonymous class the lambda's body creates (Types.DescriptorCache.mergeDescriptors' map of a\n  FunctionDescriptor's anonymous subclass: ^Types$DescriptorCache$1), a class not declared until\n  the body is analyzed: then the functional interface method's own return type, which the\n  body's value converts to as well (doc/classes/JAVA-FRONTEND-SURVEY.md, \"As built: JN2\").R3,i4119,R4,i1,R5,s25,arbace/classes/analyze.aem8,R0,L1,V2,R9,V5,R10,R37,R38,R13,R16,R3,i4130,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze8,arg-stubm10,R6,TR0,L1,V1,R22,R3,i4171,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze8,desc-tagm12,R6,TR0,L1,V1,R22,R2,s78,A tag naming descriptor d: a primitive's name, an array's C/N, a class's name.R3,i4173,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,ref-as-lambdam12,R6,TR0,L1,V5,R9,R37,R39,R40,R41,R2,s138,javac makes a lambda method for references it cannot express as a method handle (variable\n  arity adaptation): the equivalent lambda form.R3,i4181,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,ref-ownerm12,R6,TR0,L1,V2,R27,R42,R2,s182,The class a method reference's handle names: the declaring class, except that Object's\n  methods referenced through an interface are named by the interface (javac's binaryQualifier).R3,i4189,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze10,select-refm12,R6,TR0,L1,V5,R9,R43,R44,R17,R45,R2,s314,select-method for a method reference's instantiated parameter types, [m varargs? cast?]:\n  when none applies, the only fixed-arity candidate of that arity, cast? true (a parameter of\n  an intersection type erased to another bound than the method's: javac makes a lambda that\n  casts the arguments, LambdaToMethod).R3,i4195,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze9,cast-argsm12,R6,TR0,L1,V2,R42,R12,R2,s66,The argument symbols cast to method m's reference parameter types.R3,i4211,R4,i1,R5,s25,arbace/classes/analyze.aem8,R0,L1,V2,R9,V6,R10,R37,R13,R46,R25,R26,R3,i4217,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,enum-class?m10,R6,TR0,L1,V1,R22,R3,i4336,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,analyze-patternm10,R0,L1,V5,R9,R26,R47,R13,m2,R48,V1,R49,R2,s96,Analyzes a pattern form against a value of static type st. Returns [pattern actx-with-bindings].R3,i4339,R4,i1,R5,s25,arbace/classes/analyze.aem8,R0,L1,V2,R9,V6,R10,V4,R50,R51,R25,R30,R52,R53,R25,R26,R3,i4392,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,switch-map!m12,R6,TR0,L1,V3,R9,R54,R18,R2,s112,Registers a use of enum constant `c` of enum e in the outermost class's $SwitchMap$; returns\n  its mapped value.R3,i4405,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,constant-labelm10,R6,TR0,L1,V3,R9,R26,R55,R3,i4419,R4,i1,R5,s25,arbace/classes/analyze.aem8,R0,L1,V2,R9,V4,R10,R56,R13,R57,R3,i4427,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze17,read-source-formsm10,R6,TR0,L1,V1,Myn2,inm2,R58,R59,R3,i4542,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,import-classes!m10,R0,L1,V2,R60,R26,R2,s416,Imports the classes of an (import ...) form into namespace ns, without evaluating code (which\n  the frozen compiler would compile into ns's package, prohibited for java.*). Classes not on the\n  class path or compiled from source (env/*from-source*) go into env/source-imports, as their\n  sources are found by name (§9.2). Returns the class names that could not be imported (a name\n  already mapped to another class).R3,i4548,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,eval-ns-form!m10,R0,L1,V1,R61,R2,s89,Evaluates a namespace form of a Java forms file: in-ns and import without compiling code.R3,i4570,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,enter-file!m12,R6,TR0,L1,V2,R62,R63,R2,s168,Enters the Java forms of the source file in (an InputStream) as declarations when the file\n  declares top-level class top (enter-from-source!); returns whether it does.R3,i4580,R4,i1,R5,s25,arbace/classes/analyze.aem10,R0,L1,V1,R1,R2,s381,Looks up the top-level class of internal name n as a source p/C.ae on the class path, else in\n  the file being loaded (*file*: a later form of it, as javac compiles a file's classes together;\n  JC4). Its namespace and import forms are evaluated and its Java forms entered as declarations\n  only (headers and members), so code being compiled can refer to them. Returns n when found.R3,i4628,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze13,add-accessor!m12,R6,TR0,L1,V4,R64,R65,R55,R66,R2,s383,Registers an accessor of class o and, as data, the one member instruction it holds, target\n  {:insn :owner :name :desc :itf} (:insn :getfield, :putfield, :getstatic, :putstatic,\n  :invokevirtual, :invokestatic or :invokespecial: what j2g reads, arbace.j2g.access); returns\n  its name. (The JVM's back end also wrote the accessor's bytecode; it is on the branch\n  arbace-for-java-26.)R3,i4655,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze14,accessor-ownerm12,R6,TR0,L1,V4,R9,R42,R13,V1,R66,R2,s250,The enclosing class of the current class through which protected member m is accessible,\n  when the current class itself cannot access it; else nil (javac's needsProtectedAccess and\n  accessClass). `target` is the receiver node of an instance member.R3,i4667,R4,i1,R5,s25,arbace/classes/analyze.aem10,R0,L1,V2,R9,R67,R2,s71,Rewrites a member access that needs a javac accessor into a call of it.R3,i4689,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze11,*accessors*m10,R68,TR3,i4728,R4,i1,R5,s25,arbace/classes/analyze.aeR2,s152,Are javac's accessors made (j2g's world, as javac compiles)? The interpreter, which calls\n  members directly (accessorize the identity), binds it false.m10,R0,L1,V5,R9,R64,R69,R12,R45,R2,s164,(.m Outer/super args) from a nested class or lambda: javac's access$N01 accessor in Outer;\n  without *accessors*, the special call itself on the enclosing instance.R3,i4733,R4,i1,R5,s25,arbace/classes/analyze.aev22,arbace.classes.analyze15,constant-field!m12,R6,TR0,L1,V4,R9,R70,R55,R71,R2,s524,A static field of the current class holding a Clojure constant: returns {:owner :name :desc}.\n  The class's state keeps them in :clj-consts, a vector of [k field] in the order made (const__0,\n  const__1, ...: what <clinit> and the fields' declarations iterate), and :clj-const-index, k to\n  field. (A map from k iterated in its keys' hash order once past eight entries, and a var's\n  hash is its identity's: j2g's <clinit> of a deftype with many constants varied from run to run;\n  2026-10-17, doc/FUTAMURA-SURVEY.md, F2.2.)R3,i4759,R4,i1,R5,s25,arbace/classes/analyze.aem10,R0,L1,V2,R9,R21,R2,s76,A keyword or quoted datum as a constant node (read at class initialization).R3,i4776,R4,i1,R5,s25,arbace/classes/analyze.aem8,R0,L1,V2,R9,R21,R3,i4785,R4,i1,R5,s25,arbace/classes/analyze.aem10,R0,L1,V4,R9,R72,R55,R73,R2,s89,A collection literal: built by arbace.lang.RT/vector, map or set from its boxed elements.R3,i4789,R4,i1,R5,s25,arbace/classes/analyze.ae")

var Lit_1090 *jrt.String = jrt.Intern("arbace.classes.analyze$add_bridges_BANG_")

var Lit_1091 *jrt.String = jrt.Intern("arbace.classes.analyze$supertypes_first")

var Lit_1092 *jrt.String = jrt.Intern("arbace.classes.analyze$mark_enum_abstract_BANG_")

var Lit_1093 *jrt.String = jrt.Intern("arbace.classes.analyze$process_classes_BANG_")

var Lit_1094 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_anon")

var Lit_1095 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_letclass")

var Lit_1096 *jrt.String = jrt.Intern("arbace.classes.analyze$not_yet")

var Lit_1097 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_enum_body")

var Lit_1098 *jrt.String = jrt.Intern("arbace.classes.analyze$const_string")

var Lit_1099 *jrt.String = jrt.Intern("arbace.classes.analyze$accessible_class_QMARK_")

var Lit_1100 *jrt.String = jrt.Intern("arbace.classes.analyze$sharpest_accessible")

var Lit_1101 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_str")

var Lit_1102 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_assert")

var Lit_1103 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_java_assert_STAR_")

var Lit_1104 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_for_each")

var Lit_1105 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_with_resources")

var Lit_1106 *jrt.String = jrt.Intern("arbace.classes.analyze$find_sam")

var Lit_1107 *jrt.String = jrt.Intern("arbace.classes.analyze$fi_types")

var Lit_1108 *jrt.String = jrt.Intern("arbace.classes.analyze$serial_lambda_name_BANG_")

var Lit_1109 *jrt.String = jrt.Intern("arbace.classes.analyze$lambda_method_prefix")

var Lit_1110 *jrt.String = jrt.Intern("arbace.classes.analyze$lambda_name_BANG_")

var Lit_1111 *jrt.String = jrt.Intern("arbace.classes.analyze$lambda_ret_desc")

var Lit_1112 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_lambda")

var Lit_1113 *jrt.String = jrt.Intern("arbace.classes.analyze$arg_stub")

var Lit_1114 *jrt.String = jrt.Intern("arbace.classes.analyze$desc_tag")

var Lit_1115 *jrt.String = jrt.Intern("arbace.classes.analyze$ref_as_lambda")

var Lit_1116 *jrt.String = jrt.Intern("arbace.classes.analyze$ref_owner")

var Lit_1117 *jrt.String = jrt.Intern("arbace.classes.analyze$select_ref")

var Lit_1118 *jrt.String = jrt.Intern("arbace.classes.analyze$cast_args")

var Lit_1119 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_method_ref")

var Lit_1120 *jrt.String = jrt.Intern("arbace.classes.analyze$enum_class_QMARK_")

var Lit_1121 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_pattern")

var Lit_1122 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_if_instance")

var Lit_1123 *jrt.String = jrt.Intern("arbace.classes.analyze$switch_map_BANG_")

var Lit_1124 *jrt.String = jrt.Intern("arbace.classes.analyze$constant_label")

var Lit_1125 *jrt.String = jrt.Intern("arbace.classes.analyze$analyze_switch")

var Lit_1126 *jrt.String = jrt.Intern("arbace.classes.analyze$read_source_forms")

var Lit_1127 *jrt.String = jrt.Intern("arbace.classes.analyze$import_classes_BANG_")

var Lit_1128 *jrt.String = jrt.Intern("arbace.classes.analyze$eval_ns_form_BANG_")

var Lit_1129 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_file_BANG_")

var Lit_1130 *jrt.String = jrt.Intern("arbace.classes.analyze$enter_from_source_BANG_")

var Lit_1131 *jrt.String = jrt.Intern("arbace.classes.analyze$add_accessor_BANG_")

var Lit_1132 *jrt.String = jrt.Intern("arbace.classes.analyze$accessor_owner")

var Lit_1133 *jrt.String = jrt.Intern("arbace.classes.analyze$accessorize")

var Lit_1134 *jrt.String = jrt.Intern("arbace.classes.analyze$outer_super_call")

var Lit_1135 *jrt.String = jrt.Intern("arbace.classes.analyze$constant_field_BANG_")

var Lit_1136 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_constant")

var Lit_1137 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_var_field")

var Lit_1138 *jrt.String = jrt.Intern("arbace.classes.analyze$clj_collection")
