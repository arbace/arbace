//line a2g_classes.ae:1
package aot_arbace_instant

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_instant_civil__GT_days_A_class, Name: "arbace.instant$civil__GT_days", Modifiers: 25, Simple: "civil__GT_days", Go: "arbace/aot_arbace_instant.A_arbace_instant_civil__GT_days_A", Source: "instant.ae", Declaring: &A_arbace_instant_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_instant_construct_calendar_A_class, Name: "arbace.instant$construct_calendar", Modifiers: 25, Simple: "construct_calendar", Go: "arbace/aot_arbace_instant.A_arbace_instant_construct_calendar_A", Source: "instant.ae", Declaring: &A_arbace_instant_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF10_class}}, jrt.CodeDecl{Out: &A_arbace_instant_construct_date_A_class, Name: "arbace.instant$construct_date", Modifiers: 25, Simple: "construct_date", Go: "arbace/aot_arbace_instant.A_arbace_instant_construct_date_A", Source: "instant.ae", Declaring: &A_arbace_instant_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF10_class}}, jrt.CodeDecl{Out: &A_arbace_instant_construct_timestamp_A_class, Name: "arbace.instant$construct_timestamp", Modifiers: 25, Simple: "construct_timestamp", Go: "arbace/aot_arbace_instant.A_arbace_instant_construct_timestamp_A", Source: "instant.ae", Declaring: &A_arbace_instant_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF10_class}}, jrt.CodeDecl{Out: &A_arbace_instant_days__GT_civil_A_class, Name: "arbace.instant$days__GT_civil", Modifiers: 25, Simple: "days__GT_civil", Go: "arbace/aot_arbace_instant.A_arbace_instant_days__GT_civil_A", Source: "instant.ae", Declaring: &A_arbace_instant_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_instant_divisible_QMARK__A_class, Name: "arbace.instant$divisible_QMARK_", Modifiers: 25, Simple: "divisible_QMARK_", Go: "arbace/aot_arbace_instant.A_arbace_instant_divisible_QMARK__A", Source: "instant.ae", Declaring: &A_arbace_instant_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_class, Name: "arbace.instant$eval783000002$loading__1927001464__auto____783000003", Modifiers: 25, Simple: "loading__1927001464__auto____783000003", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A", Source: "instant.ae", Declaring: &A_arbace_instant_eval783000002_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_instant_eval783000006_fn__783000007_A_class, Name: "arbace.instant$eval783000006$fn__783000007", Modifiers: 25, Simple: "fn__783000007", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000006_fn__783000007_A", Source: "instant.ae", Declaring: &A_arbace_instant_eval783000006_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_instant_eval783000044_fn__783000045_A_class, Name: "arbace.instant$eval783000044$fn__783000045", Modifiers: 25, Simple: "fn__783000045", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000044_fn__783000045_A", Source: "instant.ae", Declaring: &A_arbace_instant_eval783000044_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_instant_eval783000048_fn__783000049_A_class, Name: "arbace.instant$eval783000048$fn__783000049", Modifiers: 25, Simple: "fn__783000049", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000048_fn__783000049_A", Source: "instant.ae", Declaring: &A_arbace_instant_eval783000048_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_instant_eval783000053_fn__783000054_A_class, Name: "arbace.instant$eval783000053$fn__783000054", Modifiers: 25, Simple: "fn__783000054", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000053_fn__783000054_A", Source: "instant.ae", Declaring: &A_arbace_instant_eval783000053_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_instant_eval783000057_fn__783000058_A_class, Name: "arbace.instant$eval783000057$fn__783000058", Modifiers: 25, Simple: "fn__783000058", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000057_fn__783000058_A", Source: "instant.ae", Declaring: &A_arbace_instant_eval783000057_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_instant_eval783000065_fn__783000066_A_class, Name: "arbace.instant$eval783000065$fn__783000066", Modifiers: 25, Simple: "fn__783000066", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000065_fn__783000066_A", Source: "instant.ae", Declaring: &A_arbace_instant_eval783000065_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_instant_eval783000069_fn__783000070_A_class, Name: "arbace.instant$eval783000069$fn__783000070", Modifiers: 25, Simple: "fn__783000070", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000069_fn__783000070_A", Source: "instant.ae", Declaring: &A_arbace_instant_eval783000069_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_instant_fail_A_class, Name: "arbace.instant$fail", Modifiers: 25, Simple: "fail", Go: "arbace/aot_arbace_instant.A_arbace_instant_fail_A", Source: "instant.ae", Declaring: &A_arbace_instant_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_instant_fn__783000031_A_class, Name: "arbace.instant$fn__783000031", Modifiers: 25, Simple: "fn__783000031", Go: "arbace/aot_arbace_instant.A_arbace_instant_fn__783000031_A", Source: "instant.ae", Declaring: &A_arbace_instant_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_instant_fn__783000031_fn__783000032_A_class, Name: "arbace.instant$fn__783000031$fn__783000032", Modifiers: 25, Simple: "fn__783000032", Go: "arbace/aot_arbace_instant.A_arbace_instant_fn__783000031_fn__783000032_A", Source: "instant.ae", Declaring: &A_arbace_instant_fn__783000031_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_instant_indivisible_QMARK__A_class, Name: "arbace.instant$indivisible_QMARK_", Modifiers: 25, Simple: "indivisible_QMARK_", Go: "arbace/aot_arbace_instant.A_arbace_instant_indivisible_QMARK__A", Source: "instant.ae", Declaring: &A_arbace_instant_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_instant_leap_year_QMARK__A_class, Name: "arbace.instant$leap_year_QMARK_", Modifiers: 25, Simple: "leap_year_QMARK_", Go: "arbace/aot_arbace_instant.A_arbace_instant_leap_year_QMARK__A", Source: "instant.ae", Declaring: &A_arbace_instant_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_instant_parse_int_A_class, Name: "arbace.instant$parse_int", Modifiers: 25, Simple: "parse_int", Go: "arbace/aot_arbace_instant.A_arbace_instant_parse_int_A", Source: "instant.ae", Declaring: &A_arbace_instant_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_instant_parse_timestamp_A_class, Name: "arbace.instant$parse_timestamp", Modifiers: 25, Simple: "parse_timestamp", Go: "arbace/aot_arbace_instant.A_arbace_instant_parse_timestamp_A", Source: "instant.ae", Declaring: &A_arbace_instant_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_instant_print_calendar_A_class, Name: "arbace.instant$print_calendar", Modifiers: 25, Simple: "print_calendar", Go: "arbace/aot_arbace_instant.A_arbace_instant_print_calendar_A", Source: "instant.ae", Declaring: &A_arbace_instant_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_instant_print_date_A_class, Name: "arbace.instant$print_date", Modifiers: 25, Simple: "print_date", Go: "arbace/aot_arbace_instant.A_arbace_instant_print_date_A", Source: "instant.ae", Declaring: &A_arbace_instant_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_instant_print_timestamp_A_class, Name: "arbace.instant$print_timestamp", Modifiers: 25, Simple: "print_timestamp", Go: "arbace/aot_arbace_instant.A_arbace_instant_print_timestamp_A", Source: "instant.ae", Declaring: &A_arbace_instant_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_instant_read_instant_calendar_A_class, Name: "arbace.instant$read_instant_calendar", Modifiers: 25, Simple: "read_instant_calendar", Go: "arbace/aot_arbace_instant.A_arbace_instant_read_instant_calendar_A", Source: "instant.ae", Declaring: &A_arbace_instant_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_instant_read_instant_date_A_class, Name: "arbace.instant$read_instant_date", Modifiers: 25, Simple: "read_instant_date", Go: "arbace/aot_arbace_instant.A_arbace_instant_read_instant_date_A", Source: "instant.ae", Declaring: &A_arbace_instant_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_instant_read_instant_timestamp_A_class, Name: "arbace.instant$read_instant_timestamp", Modifiers: 25, Simple: "read_instant_timestamp", Go: "arbace/aot_arbace_instant.A_arbace_instant_read_instant_timestamp_A", Source: "instant.ae", Declaring: &A_arbace_instant_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_instant_validated_A_class, Name: "arbace.instant$validated", Modifiers: 25, Simple: "validated", Go: "arbace/aot_arbace_instant.A_arbace_instant_validated_A", Source: "instant.ae", Declaring: &A_arbace_instant_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_instant_validated_fn__783000035_A_class, Name: "arbace.instant$validated$fn__783000035", Modifiers: 25, Simple: "fn__783000035", Go: "arbace/aot_arbace_instant.A_arbace_instant_validated_fn__783000035_A", Source: "instant.ae", Declaring: &A_arbace_instant_validated_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF10_class}}, jrt.CodeDecl{Out: &A_arbace_instant_verify_A_class, Name: "arbace.instant$verify", Modifiers: 25, Simple: "verify", Go: "arbace/aot_arbace_instant.A_arbace_instant_verify_A", Source: "instant.ae", Declaring: &A_arbace_instant_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class, &lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_instant_zero_fill_right_A_class, Name: "arbace.instant$zero_fill_right", Modifiers: 25, Simple: "zero_fill_right", Go: "arbace/aot_arbace_instant.A_arbace_instant_zero_fill_right_A", Source: "instant.ae", Declaring: &A_arbace_instant_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_instant_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_A_New()}; return nil }

var A_arbace_instant_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_instant_A_new}

var A_arbace_instant_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_instant.A_arbace_instant_A"})

func init() { i := A_arbace_instant_A_class.Info(); i.IsInstance = A_arbace_instant_A_InstanceOf; i.Init = A_arbace_instant_A_Init; i.Table = A_arbace_instant_A_members }

var A_arbace_instant_civil__GT_days_A_class *jrt.Class

var A_arbace_instant_construct_calendar_A_class *jrt.Class

var A_arbace_instant_construct_date_A_class *jrt.Class

var A_arbace_instant_construct_timestamp_A_class *jrt.Class

var A_arbace_instant_days__GT_civil_A_class *jrt.Class

var A_arbace_instant_divisible_QMARK__A_class *jrt.Class

func A_arbace_instant_eval783000002_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_eval783000002_A_New()}; return nil }

var A_arbace_instant_eval783000002_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_instant_eval783000002_A_new}

var A_arbace_instant_eval783000002_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$eval783000002", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_instant_A_class, Simple: "eval783000002", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000002_A"})

func init() { i := A_arbace_instant_eval783000002_A_class.Info(); i.IsInstance = A_arbace_instant_eval783000002_A_InstanceOf; i.Table = A_arbace_instant_eval783000002_A_members }

var A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_class *jrt.Class

func A_arbace_instant_eval783000006_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_eval783000006_A_New()}; return nil }

var A_arbace_instant_eval783000006_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_instant_eval783000006_A_new}

var A_arbace_instant_eval783000006_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$eval783000006", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_instant_A_class, Simple: "eval783000006", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000006_A"})

func init() { i := A_arbace_instant_eval783000006_A_class.Info(); i.IsInstance = A_arbace_instant_eval783000006_A_InstanceOf; i.Table = A_arbace_instant_eval783000006_A_members }

var A_arbace_instant_eval783000006_fn__783000007_A_class *jrt.Class

func A_arbace_instant_eval783000044_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_eval783000044_A_New()}; return nil }

var A_arbace_instant_eval783000044_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_instant_eval783000044_A_new}

var A_arbace_instant_eval783000044_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$eval783000044", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_instant_A_class, Simple: "eval783000044", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000044_A"})

func init() { i := A_arbace_instant_eval783000044_A_class.Info(); i.IsInstance = A_arbace_instant_eval783000044_A_InstanceOf; i.Table = A_arbace_instant_eval783000044_A_members }

var A_arbace_instant_eval783000044_fn__783000045_A_class *jrt.Class

func A_arbace_instant_eval783000048_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_eval783000048_A_New()}; return nil }

var A_arbace_instant_eval783000048_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_instant_eval783000048_A_new}

var A_arbace_instant_eval783000048_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$eval783000048", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_instant_A_class, Simple: "eval783000048", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000048_A"})

func init() { i := A_arbace_instant_eval783000048_A_class.Info(); i.IsInstance = A_arbace_instant_eval783000048_A_InstanceOf; i.Table = A_arbace_instant_eval783000048_A_members }

var A_arbace_instant_eval783000048_fn__783000049_A_class *jrt.Class

func A_arbace_instant_eval783000053_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_eval783000053_A_New()}; return nil }

var A_arbace_instant_eval783000053_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_instant_eval783000053_A_new}

var A_arbace_instant_eval783000053_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$eval783000053", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_instant_A_class, Simple: "eval783000053", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000053_A"})

func init() { i := A_arbace_instant_eval783000053_A_class.Info(); i.IsInstance = A_arbace_instant_eval783000053_A_InstanceOf; i.Table = A_arbace_instant_eval783000053_A_members }

var A_arbace_instant_eval783000053_fn__783000054_A_class *jrt.Class

func A_arbace_instant_eval783000057_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_eval783000057_A_New()}; return nil }

var A_arbace_instant_eval783000057_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_instant_eval783000057_A_new}

var A_arbace_instant_eval783000057_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$eval783000057", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_instant_A_class, Simple: "eval783000057", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000057_A"})

func init() { i := A_arbace_instant_eval783000057_A_class.Info(); i.IsInstance = A_arbace_instant_eval783000057_A_InstanceOf; i.Table = A_arbace_instant_eval783000057_A_members }

var A_arbace_instant_eval783000057_fn__783000058_A_class *jrt.Class

func A_arbace_instant_eval783000065_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_eval783000065_A_New()}; return nil }

var A_arbace_instant_eval783000065_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_instant_eval783000065_A_new}

var A_arbace_instant_eval783000065_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$eval783000065", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_instant_A_class, Simple: "eval783000065", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000065_A"})

func init() { i := A_arbace_instant_eval783000065_A_class.Info(); i.IsInstance = A_arbace_instant_eval783000065_A_InstanceOf; i.Table = A_arbace_instant_eval783000065_A_members }

var A_arbace_instant_eval783000065_fn__783000066_A_class *jrt.Class

func A_arbace_instant_eval783000069_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_eval783000069_A_New()}; return nil }

var A_arbace_instant_eval783000069_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_instant_eval783000069_A_new}

var A_arbace_instant_eval783000069_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$eval783000069", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_instant_A_class, Simple: "eval783000069", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000069_A"})

func init() { i := A_arbace_instant_eval783000069_A_class.Info(); i.IsInstance = A_arbace_instant_eval783000069_A_InstanceOf; i.Table = A_arbace_instant_eval783000069_A_members }

var A_arbace_instant_eval783000069_fn__783000070_A_class *jrt.Class

var A_arbace_instant_fail_A_class *jrt.Class

var A_arbace_instant_fn__783000031_A_class *jrt.Class

var A_arbace_instant_fn__783000031_fn__783000032_A_class *jrt.Class

var A_arbace_instant_indivisible_QMARK__A_class *jrt.Class

var A_arbace_instant_leap_year_QMARK__A_class *jrt.Class

var A_arbace_instant_parse_int_A_class *jrt.Class

var A_arbace_instant_parse_timestamp_A_class *jrt.Class

var A_arbace_instant_print_calendar_A_class *jrt.Class

var A_arbace_instant_print_date_A_class *jrt.Class

var A_arbace_instant_print_timestamp_A_class *jrt.Class

var A_arbace_instant_read_instant_calendar_A_class *jrt.Class

var A_arbace_instant_read_instant_date_A_class *jrt.Class

var A_arbace_instant_read_instant_timestamp_A_class *jrt.Class

var A_arbace_instant_validated_A_class *jrt.Class

var A_arbace_instant_validated_fn__783000035_A_class *jrt.Class

var A_arbace_instant_verify_A_class *jrt.Class

var A_arbace_instant_zero_fill_right_A_class *jrt.Class

func A_arbace_instant__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_instant__init_A_Load__O()}; return nil }

func A_arbace_instant__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant__init_A_New()}; return nil }

var A_arbace_instant__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_instant__init_A_invoke, New: A_arbace_instant__init_A_new}

var A_arbace_instant__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_instant.A_arbace_instant__init_A", Source: "instant.ae"})

func init() { i := A_arbace_instant__init_A_class.Info(); i.IsInstance = A_arbace_instant__init_A_InstanceOf; i.Init = A_arbace_instant__init_A_Init; i.Table = A_arbace_instant__init_A_members }
