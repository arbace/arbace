//line a2g_classes.ae:1
package aot_arbace_instant

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_instant_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_A_New()}; return nil }

var A_arbace_instant_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_instant_A_new}

var A_arbace_instant_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_instant.A_arbace_instant_A"})

func init() { i := A_arbace_instant_A_class.Info(); i.IsInstance = A_arbace_instant_A_InstanceOf; i.Init = A_arbace_instant_A_Init; i.Table = A_arbace_instant_A_members; jrt.RegisterGoType(A_arbace_instant_A_class, reflect.TypeFor[A_arbace_instant_A]()) }

func A_arbace_instant_civil__GT_days_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_civil__GT_days_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_instant_civil__GT_days_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_civil__GT_days_A_New()}; return nil }

func A_arbace_instant_civil__GT_days_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_civil__GT_days_A_fn_class)}; return nil }

var A_arbace_instant_civil__GT_days_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_civil__GT_days_A_invoke, New: A_arbace_instant_civil__GT_days_A_new, Get: A_arbace_instant_civil__GT_days_A_get}

var A_arbace_instant_civil__GT_days_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$civil__GT_days", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_instant_A_class, Simple: "civil__GT_days", Go: "arbace/aot_arbace_instant.A_arbace_instant_civil__GT_days_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_civil__GT_days_A_class.Info(); i.IsInstance = A_arbace_instant_civil__GT_days_A_InstanceOf; i.Init = A_arbace_instant_civil__GT_days_A_Init; i.Table = A_arbace_instant_civil__GT_days_A_members; jrt.RegisterGoType(A_arbace_instant_civil__GT_days_A_class, reflect.TypeFor[A_arbace_instant_civil__GT_days_A]()) }

func A_arbace_instant_construct_calendar_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_construct_calendar_A).Invoke_O_O_O_O_O_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10])}; return nil }

func A_arbace_instant_construct_calendar_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_construct_calendar_A_New()}; return nil }

func A_arbace_instant_construct_calendar_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_construct_calendar_A_fn_class)}; return nil }

var A_arbace_instant_construct_calendar_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_construct_calendar_A_invoke, New: A_arbace_instant_construct_calendar_A_new, Get: A_arbace_instant_construct_calendar_A_get}

var A_arbace_instant_construct_calendar_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$construct_calendar", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF10_class}, Declaring: A_arbace_instant_A_class, Simple: "construct_calendar", Go: "arbace/aot_arbace_instant.A_arbace_instant_construct_calendar_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_construct_calendar_A_class.Info(); i.IsInstance = A_arbace_instant_construct_calendar_A_InstanceOf; i.Init = A_arbace_instant_construct_calendar_A_Init; i.Table = A_arbace_instant_construct_calendar_A_members; jrt.RegisterGoType(A_arbace_instant_construct_calendar_A_class, reflect.TypeFor[A_arbace_instant_construct_calendar_A]()) }

func A_arbace_instant_construct_date_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_construct_date_A).Invoke_O_O_O_O_O_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10])}; return nil }

func A_arbace_instant_construct_date_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_construct_date_A_New()}; return nil }

func A_arbace_instant_construct_date_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_construct_date_A_fn_class)}; return nil }

var A_arbace_instant_construct_date_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_construct_date_A_invoke, New: A_arbace_instant_construct_date_A_new, Get: A_arbace_instant_construct_date_A_get}

var A_arbace_instant_construct_date_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$construct_date", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF10_class}, Declaring: A_arbace_instant_A_class, Simple: "construct_date", Go: "arbace/aot_arbace_instant.A_arbace_instant_construct_date_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_construct_date_A_class.Info(); i.IsInstance = A_arbace_instant_construct_date_A_InstanceOf; i.Init = A_arbace_instant_construct_date_A_Init; i.Table = A_arbace_instant_construct_date_A_members; jrt.RegisterGoType(A_arbace_instant_construct_date_A_class, reflect.TypeFor[A_arbace_instant_construct_date_A]()) }

func A_arbace_instant_construct_timestamp_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_construct_timestamp_A).Invoke_O_O_O_O_O_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10])}; return nil }

func A_arbace_instant_construct_timestamp_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_construct_timestamp_A_New()}; return nil }

func A_arbace_instant_construct_timestamp_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_construct_timestamp_A_fn_class)}; return nil }

var A_arbace_instant_construct_timestamp_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_construct_timestamp_A_invoke, New: A_arbace_instant_construct_timestamp_A_new, Get: A_arbace_instant_construct_timestamp_A_get}

var A_arbace_instant_construct_timestamp_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$construct_timestamp", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF10_class}, Declaring: A_arbace_instant_A_class, Simple: "construct_timestamp", Go: "arbace/aot_arbace_instant.A_arbace_instant_construct_timestamp_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_construct_timestamp_A_class.Info(); i.IsInstance = A_arbace_instant_construct_timestamp_A_InstanceOf; i.Init = A_arbace_instant_construct_timestamp_A_Init; i.Table = A_arbace_instant_construct_timestamp_A_members; jrt.RegisterGoType(A_arbace_instant_construct_timestamp_A_class, reflect.TypeFor[A_arbace_instant_construct_timestamp_A]()) }

func A_arbace_instant_days__GT_civil_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_days__GT_civil_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_instant_days__GT_civil_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_days__GT_civil_A_New()}; return nil }

func A_arbace_instant_days__GT_civil_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_days__GT_civil_A_fn_class)}; return nil }

var A_arbace_instant_days__GT_civil_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_days__GT_civil_A_invoke, New: A_arbace_instant_days__GT_civil_A_new, Get: A_arbace_instant_days__GT_civil_A_get}

var A_arbace_instant_days__GT_civil_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$days__GT_civil", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_instant_A_class, Simple: "days__GT_civil", Go: "arbace/aot_arbace_instant.A_arbace_instant_days__GT_civil_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_days__GT_civil_A_class.Info(); i.IsInstance = A_arbace_instant_days__GT_civil_A_InstanceOf; i.Init = A_arbace_instant_days__GT_civil_A_Init; i.Table = A_arbace_instant_days__GT_civil_A_members; jrt.RegisterGoType(A_arbace_instant_days__GT_civil_A_class, reflect.TypeFor[A_arbace_instant_days__GT_civil_A]()) }

func A_arbace_instant_divisible_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_divisible_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_instant_divisible_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_divisible_QMARK__A_New()}; return nil }

func A_arbace_instant_divisible_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_divisible_QMARK__A_fn_class)}; return nil }

var A_arbace_instant_divisible_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_divisible_QMARK__A_invoke, New: A_arbace_instant_divisible_QMARK__A_new, Get: A_arbace_instant_divisible_QMARK__A_get}

var A_arbace_instant_divisible_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$divisible_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_instant_A_class, Simple: "divisible_QMARK_", Go: "arbace/aot_arbace_instant.A_arbace_instant_divisible_QMARK__A", Source: "instant.ae"})

func init() { i := A_arbace_instant_divisible_QMARK__A_class.Info(); i.IsInstance = A_arbace_instant_divisible_QMARK__A_InstanceOf; i.Init = A_arbace_instant_divisible_QMARK__A_Init; i.Table = A_arbace_instant_divisible_QMARK__A_members; jrt.RegisterGoType(A_arbace_instant_divisible_QMARK__A_class, reflect.TypeFor[A_arbace_instant_divisible_QMARK__A]()) }

func A_arbace_instant_eval783000002_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_eval783000002_A_New()}; return nil }

var A_arbace_instant_eval783000002_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_instant_eval783000002_A_new}

var A_arbace_instant_eval783000002_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$eval783000002", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_instant_A_class, Simple: "eval783000002", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000002_A"})

func init() { i := A_arbace_instant_eval783000002_A_class.Info(); i.IsInstance = A_arbace_instant_eval783000002_A_InstanceOf; i.Table = A_arbace_instant_eval783000002_A_members; jrt.RegisterGoType(A_arbace_instant_eval783000002_A_class, reflect.TypeFor[A_arbace_instant_eval783000002_A]()) }

func A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_New()}; return nil }

func A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_fn_class)}; return nil }

var A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_invoke, New: A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_new, Get: A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_get}

var A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$eval783000002$loading__1927001464__auto____783000003", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_instant_eval783000002_A_class, Simple: "loading__1927001464__auto____783000003", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_class.Info(); i.IsInstance = A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_InstanceOf; i.Init = A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_Init; i.Table = A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_members; jrt.RegisterGoType(A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_class, reflect.TypeFor[A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A]()) }

func A_arbace_instant_eval783000006_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_eval783000006_A_New()}; return nil }

var A_arbace_instant_eval783000006_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_instant_eval783000006_A_new}

var A_arbace_instant_eval783000006_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$eval783000006", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_instant_A_class, Simple: "eval783000006", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000006_A"})

func init() { i := A_arbace_instant_eval783000006_A_class.Info(); i.IsInstance = A_arbace_instant_eval783000006_A_InstanceOf; i.Table = A_arbace_instant_eval783000006_A_members; jrt.RegisterGoType(A_arbace_instant_eval783000006_A_class, reflect.TypeFor[A_arbace_instant_eval783000006_A]()) }

func A_arbace_instant_eval783000006_fn__783000007_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_eval783000006_fn__783000007_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_instant_eval783000006_fn__783000007_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_eval783000006_fn__783000007_A_New()}; return nil }

func A_arbace_instant_eval783000006_fn__783000007_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_eval783000006_fn__783000007_A_fn_class)}; return nil }

var A_arbace_instant_eval783000006_fn__783000007_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_eval783000006_fn__783000007_A_invoke, New: A_arbace_instant_eval783000006_fn__783000007_A_new, Get: A_arbace_instant_eval783000006_fn__783000007_A_get}

var A_arbace_instant_eval783000006_fn__783000007_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$eval783000006$fn__783000007", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_instant_eval783000006_A_class, Simple: "fn__783000007", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000006_fn__783000007_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_eval783000006_fn__783000007_A_class.Info(); i.IsInstance = A_arbace_instant_eval783000006_fn__783000007_A_InstanceOf; i.Init = A_arbace_instant_eval783000006_fn__783000007_A_Init; i.Table = A_arbace_instant_eval783000006_fn__783000007_A_members; jrt.RegisterGoType(A_arbace_instant_eval783000006_fn__783000007_A_class, reflect.TypeFor[A_arbace_instant_eval783000006_fn__783000007_A]()) }

func A_arbace_instant_eval783000044_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_eval783000044_A_New()}; return nil }

var A_arbace_instant_eval783000044_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_instant_eval783000044_A_new}

var A_arbace_instant_eval783000044_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$eval783000044", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_instant_A_class, Simple: "eval783000044", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000044_A"})

func init() { i := A_arbace_instant_eval783000044_A_class.Info(); i.IsInstance = A_arbace_instant_eval783000044_A_InstanceOf; i.Table = A_arbace_instant_eval783000044_A_members; jrt.RegisterGoType(A_arbace_instant_eval783000044_A_class, reflect.TypeFor[A_arbace_instant_eval783000044_A]()) }

func A_arbace_instant_eval783000044_fn__783000045_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_eval783000044_fn__783000045_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_instant_eval783000044_fn__783000045_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_eval783000044_fn__783000045_A_New()}; return nil }

func A_arbace_instant_eval783000044_fn__783000045_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_eval783000044_fn__783000045_A_fn_class)}; return nil }

var A_arbace_instant_eval783000044_fn__783000045_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_eval783000044_fn__783000045_A_invoke, New: A_arbace_instant_eval783000044_fn__783000045_A_new, Get: A_arbace_instant_eval783000044_fn__783000045_A_get}

var A_arbace_instant_eval783000044_fn__783000045_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$eval783000044$fn__783000045", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_instant_eval783000044_A_class, Simple: "fn__783000045", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000044_fn__783000045_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_eval783000044_fn__783000045_A_class.Info(); i.IsInstance = A_arbace_instant_eval783000044_fn__783000045_A_InstanceOf; i.Init = A_arbace_instant_eval783000044_fn__783000045_A_Init; i.Table = A_arbace_instant_eval783000044_fn__783000045_A_members; jrt.RegisterGoType(A_arbace_instant_eval783000044_fn__783000045_A_class, reflect.TypeFor[A_arbace_instant_eval783000044_fn__783000045_A]()) }

func A_arbace_instant_eval783000048_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_eval783000048_A_New()}; return nil }

var A_arbace_instant_eval783000048_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_instant_eval783000048_A_new}

var A_arbace_instant_eval783000048_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$eval783000048", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_instant_A_class, Simple: "eval783000048", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000048_A"})

func init() { i := A_arbace_instant_eval783000048_A_class.Info(); i.IsInstance = A_arbace_instant_eval783000048_A_InstanceOf; i.Table = A_arbace_instant_eval783000048_A_members; jrt.RegisterGoType(A_arbace_instant_eval783000048_A_class, reflect.TypeFor[A_arbace_instant_eval783000048_A]()) }

func A_arbace_instant_eval783000048_fn__783000049_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_eval783000048_fn__783000049_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_instant_eval783000048_fn__783000049_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_eval783000048_fn__783000049_A_New()}; return nil }

func A_arbace_instant_eval783000048_fn__783000049_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_eval783000048_fn__783000049_A_fn_class)}; return nil }

var A_arbace_instant_eval783000048_fn__783000049_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_eval783000048_fn__783000049_A_invoke, New: A_arbace_instant_eval783000048_fn__783000049_A_new, Get: A_arbace_instant_eval783000048_fn__783000049_A_get}

var A_arbace_instant_eval783000048_fn__783000049_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$eval783000048$fn__783000049", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_instant_eval783000048_A_class, Simple: "fn__783000049", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000048_fn__783000049_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_eval783000048_fn__783000049_A_class.Info(); i.IsInstance = A_arbace_instant_eval783000048_fn__783000049_A_InstanceOf; i.Init = A_arbace_instant_eval783000048_fn__783000049_A_Init; i.Table = A_arbace_instant_eval783000048_fn__783000049_A_members; jrt.RegisterGoType(A_arbace_instant_eval783000048_fn__783000049_A_class, reflect.TypeFor[A_arbace_instant_eval783000048_fn__783000049_A]()) }

func A_arbace_instant_eval783000053_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_eval783000053_A_New()}; return nil }

var A_arbace_instant_eval783000053_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_instant_eval783000053_A_new}

var A_arbace_instant_eval783000053_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$eval783000053", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_instant_A_class, Simple: "eval783000053", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000053_A"})

func init() { i := A_arbace_instant_eval783000053_A_class.Info(); i.IsInstance = A_arbace_instant_eval783000053_A_InstanceOf; i.Table = A_arbace_instant_eval783000053_A_members; jrt.RegisterGoType(A_arbace_instant_eval783000053_A_class, reflect.TypeFor[A_arbace_instant_eval783000053_A]()) }

func A_arbace_instant_eval783000053_fn__783000054_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_eval783000053_fn__783000054_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_instant_eval783000053_fn__783000054_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_eval783000053_fn__783000054_A_New()}; return nil }

func A_arbace_instant_eval783000053_fn__783000054_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_eval783000053_fn__783000054_A_fn_class)}; return nil }

var A_arbace_instant_eval783000053_fn__783000054_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_eval783000053_fn__783000054_A_invoke, New: A_arbace_instant_eval783000053_fn__783000054_A_new, Get: A_arbace_instant_eval783000053_fn__783000054_A_get}

var A_arbace_instant_eval783000053_fn__783000054_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$eval783000053$fn__783000054", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_instant_eval783000053_A_class, Simple: "fn__783000054", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000053_fn__783000054_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_eval783000053_fn__783000054_A_class.Info(); i.IsInstance = A_arbace_instant_eval783000053_fn__783000054_A_InstanceOf; i.Init = A_arbace_instant_eval783000053_fn__783000054_A_Init; i.Table = A_arbace_instant_eval783000053_fn__783000054_A_members; jrt.RegisterGoType(A_arbace_instant_eval783000053_fn__783000054_A_class, reflect.TypeFor[A_arbace_instant_eval783000053_fn__783000054_A]()) }

func A_arbace_instant_eval783000057_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_eval783000057_A_New()}; return nil }

var A_arbace_instant_eval783000057_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_instant_eval783000057_A_new}

var A_arbace_instant_eval783000057_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$eval783000057", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_instant_A_class, Simple: "eval783000057", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000057_A"})

func init() { i := A_arbace_instant_eval783000057_A_class.Info(); i.IsInstance = A_arbace_instant_eval783000057_A_InstanceOf; i.Table = A_arbace_instant_eval783000057_A_members; jrt.RegisterGoType(A_arbace_instant_eval783000057_A_class, reflect.TypeFor[A_arbace_instant_eval783000057_A]()) }

func A_arbace_instant_eval783000057_fn__783000058_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_eval783000057_fn__783000058_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_instant_eval783000057_fn__783000058_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_eval783000057_fn__783000058_A_New()}; return nil }

func A_arbace_instant_eval783000057_fn__783000058_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_eval783000057_fn__783000058_A_fn_class)}; return nil }

var A_arbace_instant_eval783000057_fn__783000058_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_eval783000057_fn__783000058_A_invoke, New: A_arbace_instant_eval783000057_fn__783000058_A_new, Get: A_arbace_instant_eval783000057_fn__783000058_A_get}

var A_arbace_instant_eval783000057_fn__783000058_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$eval783000057$fn__783000058", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_instant_eval783000057_A_class, Simple: "fn__783000058", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000057_fn__783000058_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_eval783000057_fn__783000058_A_class.Info(); i.IsInstance = A_arbace_instant_eval783000057_fn__783000058_A_InstanceOf; i.Init = A_arbace_instant_eval783000057_fn__783000058_A_Init; i.Table = A_arbace_instant_eval783000057_fn__783000058_A_members; jrt.RegisterGoType(A_arbace_instant_eval783000057_fn__783000058_A_class, reflect.TypeFor[A_arbace_instant_eval783000057_fn__783000058_A]()) }

func A_arbace_instant_eval783000065_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_eval783000065_A_New()}; return nil }

var A_arbace_instant_eval783000065_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_instant_eval783000065_A_new}

var A_arbace_instant_eval783000065_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$eval783000065", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_instant_A_class, Simple: "eval783000065", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000065_A"})

func init() { i := A_arbace_instant_eval783000065_A_class.Info(); i.IsInstance = A_arbace_instant_eval783000065_A_InstanceOf; i.Table = A_arbace_instant_eval783000065_A_members; jrt.RegisterGoType(A_arbace_instant_eval783000065_A_class, reflect.TypeFor[A_arbace_instant_eval783000065_A]()) }

func A_arbace_instant_eval783000065_fn__783000066_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_eval783000065_fn__783000066_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_instant_eval783000065_fn__783000066_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_eval783000065_fn__783000066_A_New()}; return nil }

func A_arbace_instant_eval783000065_fn__783000066_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_eval783000065_fn__783000066_A_fn_class)}; return nil }

var A_arbace_instant_eval783000065_fn__783000066_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_eval783000065_fn__783000066_A_invoke, New: A_arbace_instant_eval783000065_fn__783000066_A_new, Get: A_arbace_instant_eval783000065_fn__783000066_A_get}

var A_arbace_instant_eval783000065_fn__783000066_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$eval783000065$fn__783000066", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_instant_eval783000065_A_class, Simple: "fn__783000066", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000065_fn__783000066_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_eval783000065_fn__783000066_A_class.Info(); i.IsInstance = A_arbace_instant_eval783000065_fn__783000066_A_InstanceOf; i.Init = A_arbace_instant_eval783000065_fn__783000066_A_Init; i.Table = A_arbace_instant_eval783000065_fn__783000066_A_members; jrt.RegisterGoType(A_arbace_instant_eval783000065_fn__783000066_A_class, reflect.TypeFor[A_arbace_instant_eval783000065_fn__783000066_A]()) }

func A_arbace_instant_eval783000069_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_eval783000069_A_New()}; return nil }

var A_arbace_instant_eval783000069_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_instant_eval783000069_A_new}

var A_arbace_instant_eval783000069_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$eval783000069", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_instant_A_class, Simple: "eval783000069", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000069_A"})

func init() { i := A_arbace_instant_eval783000069_A_class.Info(); i.IsInstance = A_arbace_instant_eval783000069_A_InstanceOf; i.Table = A_arbace_instant_eval783000069_A_members; jrt.RegisterGoType(A_arbace_instant_eval783000069_A_class, reflect.TypeFor[A_arbace_instant_eval783000069_A]()) }

func A_arbace_instant_eval783000069_fn__783000070_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_eval783000069_fn__783000070_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_instant_eval783000069_fn__783000070_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_eval783000069_fn__783000070_A_New()}; return nil }

func A_arbace_instant_eval783000069_fn__783000070_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_eval783000069_fn__783000070_A_fn_class)}; return nil }

var A_arbace_instant_eval783000069_fn__783000070_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_eval783000069_fn__783000070_A_invoke, New: A_arbace_instant_eval783000069_fn__783000070_A_new, Get: A_arbace_instant_eval783000069_fn__783000070_A_get}

var A_arbace_instant_eval783000069_fn__783000070_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$eval783000069$fn__783000070", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_instant_eval783000069_A_class, Simple: "fn__783000070", Go: "arbace/aot_arbace_instant.A_arbace_instant_eval783000069_fn__783000070_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_eval783000069_fn__783000070_A_class.Info(); i.IsInstance = A_arbace_instant_eval783000069_fn__783000070_A_InstanceOf; i.Init = A_arbace_instant_eval783000069_fn__783000070_A_Init; i.Table = A_arbace_instant_eval783000069_fn__783000070_A_members; jrt.RegisterGoType(A_arbace_instant_eval783000069_fn__783000070_A_class, reflect.TypeFor[A_arbace_instant_eval783000069_fn__783000070_A]()) }

func A_arbace_instant_fail_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_fail_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_instant_fail_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_fail_A_New()}; return nil }

func A_arbace_instant_fail_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_fail_A_fn_class)}; return nil }

var A_arbace_instant_fail_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_fail_A_invoke, New: A_arbace_instant_fail_A_new, Get: A_arbace_instant_fail_A_get}

var A_arbace_instant_fail_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$fail", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_instant_A_class, Simple: "fail", Go: "arbace/aot_arbace_instant.A_arbace_instant_fail_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_fail_A_class.Info(); i.IsInstance = A_arbace_instant_fail_A_InstanceOf; i.Init = A_arbace_instant_fail_A_Init; i.Table = A_arbace_instant_fail_A_members; jrt.RegisterGoType(A_arbace_instant_fail_A_class, reflect.TypeFor[A_arbace_instant_fail_A]()) }

func A_arbace_instant_fn__783000031_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_fn__783000031_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_instant_fn__783000031_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_fn__783000031_A_New()}; return nil }

func A_arbace_instant_fn__783000031_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_fn__783000031_A_fn_class)}; return nil }

var A_arbace_instant_fn__783000031_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_fn__783000031_A_invoke, New: A_arbace_instant_fn__783000031_A_new, Get: A_arbace_instant_fn__783000031_A_get}

var A_arbace_instant_fn__783000031_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$fn__783000031", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_instant_A_class, Simple: "fn__783000031", Go: "arbace/aot_arbace_instant.A_arbace_instant_fn__783000031_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_fn__783000031_A_class.Info(); i.IsInstance = A_arbace_instant_fn__783000031_A_InstanceOf; i.Init = A_arbace_instant_fn__783000031_A_Init; i.Table = A_arbace_instant_fn__783000031_A_members; jrt.RegisterGoType(A_arbace_instant_fn__783000031_A_class, reflect.TypeFor[A_arbace_instant_fn__783000031_A]()) }

func A_arbace_instant_fn__783000031_fn__783000032_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_fn__783000031_fn__783000032_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_instant_fn__783000031_fn__783000032_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_fn__783000031_fn__783000032_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_instant_fn__783000031_fn__783000032_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_fn__783000031_fn__783000032_A_fn_class)}; return nil }

var A_arbace_instant_fn__783000031_fn__783000032_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_fn__783000031_fn__783000032_A_invoke, New: A_arbace_instant_fn__783000031_fn__783000032_A_new, Get: A_arbace_instant_fn__783000031_fn__783000032_A_get}

var A_arbace_instant_fn__783000031_fn__783000032_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$fn__783000031$fn__783000032", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_instant_fn__783000031_A_class, Simple: "fn__783000032", Go: "arbace/aot_arbace_instant.A_arbace_instant_fn__783000031_fn__783000032_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_fn__783000031_fn__783000032_A_class.Info(); i.IsInstance = A_arbace_instant_fn__783000031_fn__783000032_A_InstanceOf; i.Init = A_arbace_instant_fn__783000031_fn__783000032_A_Init; i.Table = A_arbace_instant_fn__783000031_fn__783000032_A_members; jrt.RegisterGoType(A_arbace_instant_fn__783000031_fn__783000032_A_class, reflect.TypeFor[A_arbace_instant_fn__783000031_fn__783000032_A]()) }

func A_arbace_instant_indivisible_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_indivisible_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_instant_indivisible_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_indivisible_QMARK__A_New()}; return nil }

func A_arbace_instant_indivisible_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_indivisible_QMARK__A_fn_class)}; return nil }

var A_arbace_instant_indivisible_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_indivisible_QMARK__A_invoke, New: A_arbace_instant_indivisible_QMARK__A_new, Get: A_arbace_instant_indivisible_QMARK__A_get}

var A_arbace_instant_indivisible_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$indivisible_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_instant_A_class, Simple: "indivisible_QMARK_", Go: "arbace/aot_arbace_instant.A_arbace_instant_indivisible_QMARK__A", Source: "instant.ae"})

func init() { i := A_arbace_instant_indivisible_QMARK__A_class.Info(); i.IsInstance = A_arbace_instant_indivisible_QMARK__A_InstanceOf; i.Init = A_arbace_instant_indivisible_QMARK__A_Init; i.Table = A_arbace_instant_indivisible_QMARK__A_members; jrt.RegisterGoType(A_arbace_instant_indivisible_QMARK__A_class, reflect.TypeFor[A_arbace_instant_indivisible_QMARK__A]()) }

func A_arbace_instant_leap_year_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_leap_year_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_instant_leap_year_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_leap_year_QMARK__A_New()}; return nil }

func A_arbace_instant_leap_year_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_leap_year_QMARK__A_fn_class)}; return nil }

var A_arbace_instant_leap_year_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_leap_year_QMARK__A_invoke, New: A_arbace_instant_leap_year_QMARK__A_new, Get: A_arbace_instant_leap_year_QMARK__A_get}

var A_arbace_instant_leap_year_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$leap_year_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_instant_A_class, Simple: "leap_year_QMARK_", Go: "arbace/aot_arbace_instant.A_arbace_instant_leap_year_QMARK__A", Source: "instant.ae"})

func init() { i := A_arbace_instant_leap_year_QMARK__A_class.Info(); i.IsInstance = A_arbace_instant_leap_year_QMARK__A_InstanceOf; i.Init = A_arbace_instant_leap_year_QMARK__A_Init; i.Table = A_arbace_instant_leap_year_QMARK__A_members; jrt.RegisterGoType(A_arbace_instant_leap_year_QMARK__A_class, reflect.TypeFor[A_arbace_instant_leap_year_QMARK__A]()) }

func A_arbace_instant_parse_int_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_parse_int_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_instant_parse_int_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_parse_int_A_New()}; return nil }

func A_arbace_instant_parse_int_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_parse_int_A_fn_class)}; return nil }

var A_arbace_instant_parse_int_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_parse_int_A_invoke, New: A_arbace_instant_parse_int_A_new, Get: A_arbace_instant_parse_int_A_get}

var A_arbace_instant_parse_int_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$parse_int", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_instant_A_class, Simple: "parse_int", Go: "arbace/aot_arbace_instant.A_arbace_instant_parse_int_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_parse_int_A_class.Info(); i.IsInstance = A_arbace_instant_parse_int_A_InstanceOf; i.Init = A_arbace_instant_parse_int_A_Init; i.Table = A_arbace_instant_parse_int_A_members; jrt.RegisterGoType(A_arbace_instant_parse_int_A_class, reflect.TypeFor[A_arbace_instant_parse_int_A]()) }

func A_arbace_instant_parse_timestamp_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_parse_timestamp_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_instant_parse_timestamp_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_parse_timestamp_A_New()}; return nil }

func A_arbace_instant_parse_timestamp_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_parse_timestamp_A_fn_class)}; return nil }

var A_arbace_instant_parse_timestamp_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_parse_timestamp_A_invoke, New: A_arbace_instant_parse_timestamp_A_new, Get: A_arbace_instant_parse_timestamp_A_get}

var A_arbace_instant_parse_timestamp_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$parse_timestamp", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_instant_A_class, Simple: "parse_timestamp", Go: "arbace/aot_arbace_instant.A_arbace_instant_parse_timestamp_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_parse_timestamp_A_class.Info(); i.IsInstance = A_arbace_instant_parse_timestamp_A_InstanceOf; i.Init = A_arbace_instant_parse_timestamp_A_Init; i.Table = A_arbace_instant_parse_timestamp_A_members; jrt.RegisterGoType(A_arbace_instant_parse_timestamp_A_class, reflect.TypeFor[A_arbace_instant_parse_timestamp_A]()) }

func A_arbace_instant_print_calendar_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_print_calendar_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_instant_print_calendar_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_print_calendar_A_New()}; return nil }

func A_arbace_instant_print_calendar_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_print_calendar_A_fn_class)}; return nil }

var A_arbace_instant_print_calendar_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_print_calendar_A_invoke, New: A_arbace_instant_print_calendar_A_new, Get: A_arbace_instant_print_calendar_A_get}

var A_arbace_instant_print_calendar_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$print_calendar", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_instant_A_class, Simple: "print_calendar", Go: "arbace/aot_arbace_instant.A_arbace_instant_print_calendar_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_print_calendar_A_class.Info(); i.IsInstance = A_arbace_instant_print_calendar_A_InstanceOf; i.Init = A_arbace_instant_print_calendar_A_Init; i.Table = A_arbace_instant_print_calendar_A_members; jrt.RegisterGoType(A_arbace_instant_print_calendar_A_class, reflect.TypeFor[A_arbace_instant_print_calendar_A]()) }

func A_arbace_instant_print_date_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_print_date_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_instant_print_date_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_print_date_A_New()}; return nil }

func A_arbace_instant_print_date_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_print_date_A_fn_class)}; return nil }

var A_arbace_instant_print_date_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_print_date_A_invoke, New: A_arbace_instant_print_date_A_new, Get: A_arbace_instant_print_date_A_get}

var A_arbace_instant_print_date_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$print_date", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_instant_A_class, Simple: "print_date", Go: "arbace/aot_arbace_instant.A_arbace_instant_print_date_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_print_date_A_class.Info(); i.IsInstance = A_arbace_instant_print_date_A_InstanceOf; i.Init = A_arbace_instant_print_date_A_Init; i.Table = A_arbace_instant_print_date_A_members; jrt.RegisterGoType(A_arbace_instant_print_date_A_class, reflect.TypeFor[A_arbace_instant_print_date_A]()) }

func A_arbace_instant_print_timestamp_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_print_timestamp_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_instant_print_timestamp_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_print_timestamp_A_New()}; return nil }

func A_arbace_instant_print_timestamp_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_print_timestamp_A_fn_class)}; return nil }

var A_arbace_instant_print_timestamp_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_print_timestamp_A_invoke, New: A_arbace_instant_print_timestamp_A_new, Get: A_arbace_instant_print_timestamp_A_get}

var A_arbace_instant_print_timestamp_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$print_timestamp", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_instant_A_class, Simple: "print_timestamp", Go: "arbace/aot_arbace_instant.A_arbace_instant_print_timestamp_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_print_timestamp_A_class.Info(); i.IsInstance = A_arbace_instant_print_timestamp_A_InstanceOf; i.Init = A_arbace_instant_print_timestamp_A_Init; i.Table = A_arbace_instant_print_timestamp_A_members; jrt.RegisterGoType(A_arbace_instant_print_timestamp_A_class, reflect.TypeFor[A_arbace_instant_print_timestamp_A]()) }

func A_arbace_instant_read_instant_calendar_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_read_instant_calendar_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_instant_read_instant_calendar_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_read_instant_calendar_A_New()}; return nil }

func A_arbace_instant_read_instant_calendar_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_read_instant_calendar_A_fn_class)}; return nil }

var A_arbace_instant_read_instant_calendar_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_read_instant_calendar_A_invoke, New: A_arbace_instant_read_instant_calendar_A_new, Get: A_arbace_instant_read_instant_calendar_A_get}

var A_arbace_instant_read_instant_calendar_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$read_instant_calendar", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_instant_A_class, Simple: "read_instant_calendar", Go: "arbace/aot_arbace_instant.A_arbace_instant_read_instant_calendar_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_read_instant_calendar_A_class.Info(); i.IsInstance = A_arbace_instant_read_instant_calendar_A_InstanceOf; i.Init = A_arbace_instant_read_instant_calendar_A_Init; i.Table = A_arbace_instant_read_instant_calendar_A_members; jrt.RegisterGoType(A_arbace_instant_read_instant_calendar_A_class, reflect.TypeFor[A_arbace_instant_read_instant_calendar_A]()) }

func A_arbace_instant_read_instant_date_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_read_instant_date_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_instant_read_instant_date_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_read_instant_date_A_New()}; return nil }

func A_arbace_instant_read_instant_date_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_read_instant_date_A_fn_class)}; return nil }

var A_arbace_instant_read_instant_date_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_read_instant_date_A_invoke, New: A_arbace_instant_read_instant_date_A_new, Get: A_arbace_instant_read_instant_date_A_get}

var A_arbace_instant_read_instant_date_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$read_instant_date", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_instant_A_class, Simple: "read_instant_date", Go: "arbace/aot_arbace_instant.A_arbace_instant_read_instant_date_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_read_instant_date_A_class.Info(); i.IsInstance = A_arbace_instant_read_instant_date_A_InstanceOf; i.Init = A_arbace_instant_read_instant_date_A_Init; i.Table = A_arbace_instant_read_instant_date_A_members; jrt.RegisterGoType(A_arbace_instant_read_instant_date_A_class, reflect.TypeFor[A_arbace_instant_read_instant_date_A]()) }

func A_arbace_instant_read_instant_timestamp_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_read_instant_timestamp_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_instant_read_instant_timestamp_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_read_instant_timestamp_A_New()}; return nil }

func A_arbace_instant_read_instant_timestamp_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_read_instant_timestamp_A_fn_class)}; return nil }

var A_arbace_instant_read_instant_timestamp_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_read_instant_timestamp_A_invoke, New: A_arbace_instant_read_instant_timestamp_A_new, Get: A_arbace_instant_read_instant_timestamp_A_get}

var A_arbace_instant_read_instant_timestamp_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$read_instant_timestamp", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_instant_A_class, Simple: "read_instant_timestamp", Go: "arbace/aot_arbace_instant.A_arbace_instant_read_instant_timestamp_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_read_instant_timestamp_A_class.Info(); i.IsInstance = A_arbace_instant_read_instant_timestamp_A_InstanceOf; i.Init = A_arbace_instant_read_instant_timestamp_A_Init; i.Table = A_arbace_instant_read_instant_timestamp_A_members; jrt.RegisterGoType(A_arbace_instant_read_instant_timestamp_A_class, reflect.TypeFor[A_arbace_instant_read_instant_timestamp_A]()) }

func A_arbace_instant_validated_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_validated_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_instant_validated_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_validated_A_New()}; return nil }

func A_arbace_instant_validated_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_validated_A_fn_class)}; return nil }

var A_arbace_instant_validated_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_validated_A_invoke, New: A_arbace_instant_validated_A_new, Get: A_arbace_instant_validated_A_get}

var A_arbace_instant_validated_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$validated", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_instant_A_class, Simple: "validated", Go: "arbace/aot_arbace_instant.A_arbace_instant_validated_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_validated_A_class.Info(); i.IsInstance = A_arbace_instant_validated_A_InstanceOf; i.Init = A_arbace_instant_validated_A_Init; i.Table = A_arbace_instant_validated_A_members; jrt.RegisterGoType(A_arbace_instant_validated_A_class, reflect.TypeFor[A_arbace_instant_validated_A]()) }

func A_arbace_instant_validated_fn__783000035_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_validated_fn__783000035_A).Invoke_O_O_O_O_O_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10])}; return nil }

func A_arbace_instant_validated_fn__783000035_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_validated_fn__783000035_A_New_O(args[0])}; return nil }

func A_arbace_instant_validated_fn__783000035_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_validated_fn__783000035_A_fn_class)}; return nil }

var A_arbace_instant_validated_fn__783000035_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_validated_fn__783000035_A_invoke, New: A_arbace_instant_validated_fn__783000035_A_new, Get: A_arbace_instant_validated_fn__783000035_A_get}

var A_arbace_instant_validated_fn__783000035_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$validated$fn__783000035", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF10_class}, Declaring: A_arbace_instant_validated_A_class, Simple: "fn__783000035", Go: "arbace/aot_arbace_instant.A_arbace_instant_validated_fn__783000035_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_validated_fn__783000035_A_class.Info(); i.IsInstance = A_arbace_instant_validated_fn__783000035_A_InstanceOf; i.Init = A_arbace_instant_validated_fn__783000035_A_Init; i.Table = A_arbace_instant_validated_fn__783000035_A_members; jrt.RegisterGoType(A_arbace_instant_validated_fn__783000035_A_class, reflect.TypeFor[A_arbace_instant_validated_fn__783000035_A]()) }

func A_arbace_instant_verify_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_verify_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3]); case 1: return this.(*A_arbace_instant_verify_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_instant_verify_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_verify_A_New()}; return nil }

func A_arbace_instant_verify_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_verify_A_fn_class)}; return nil }

var A_arbace_instant_verify_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_verify_A_invoke, New: A_arbace_instant_verify_A_new, Get: A_arbace_instant_verify_A_get}

var A_arbace_instant_verify_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$verify", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class, lang.Compiler_AOTF3_class}, Declaring: A_arbace_instant_A_class, Simple: "verify", Go: "arbace/aot_arbace_instant.A_arbace_instant_verify_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_verify_A_class.Info(); i.IsInstance = A_arbace_instant_verify_A_InstanceOf; i.Init = A_arbace_instant_verify_A_Init; i.Table = A_arbace_instant_verify_A_members; jrt.RegisterGoType(A_arbace_instant_verify_A_class, reflect.TypeFor[A_arbace_instant_verify_A]()) }

func A_arbace_instant_zero_fill_right_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_instant_zero_fill_right_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_instant_zero_fill_right_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant_zero_fill_right_A_New()}; return nil }

func A_arbace_instant_zero_fill_right_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_instant_zero_fill_right_A_fn_class)}; return nil }

var A_arbace_instant_zero_fill_right_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_instant_zero_fill_right_A_invoke, New: A_arbace_instant_zero_fill_right_A_new, Get: A_arbace_instant_zero_fill_right_A_get}

var A_arbace_instant_zero_fill_right_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant$zero_fill_right", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_instant_A_class, Simple: "zero_fill_right", Go: "arbace/aot_arbace_instant.A_arbace_instant_zero_fill_right_A", Source: "instant.ae"})

func init() { i := A_arbace_instant_zero_fill_right_A_class.Info(); i.IsInstance = A_arbace_instant_zero_fill_right_A_InstanceOf; i.Init = A_arbace_instant_zero_fill_right_A_Init; i.Table = A_arbace_instant_zero_fill_right_A_members; jrt.RegisterGoType(A_arbace_instant_zero_fill_right_A_class, reflect.TypeFor[A_arbace_instant_zero_fill_right_A]()) }

func A_arbace_instant__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_instant__init_A_Load__O(); case 1: return A_arbace_instant__init_A_Unit0__O(); case 2: return A_arbace_instant__init_A_Unit1__O(); case 3: return A_arbace_instant__init_A_Unit10__O(); case 4: return A_arbace_instant__init_A_Unit11__O(); case 5: return A_arbace_instant__init_A_Unit12__O(); case 6: return A_arbace_instant__init_A_Unit13__O(); case 7: return A_arbace_instant__init_A_Unit14__O(); case 8: return A_arbace_instant__init_A_Unit15__O(); case 9: return A_arbace_instant__init_A_Unit16__O(); case 10: return A_arbace_instant__init_A_Unit17__O(); case 11: return A_arbace_instant__init_A_Unit18__O(); case 12: return A_arbace_instant__init_A_Unit19__O(); case 13: return A_arbace_instant__init_A_Unit2__O(); case 14: return A_arbace_instant__init_A_Unit20__O(); case 15: return A_arbace_instant__init_A_Unit21__O(); case 16: return A_arbace_instant__init_A_Unit22__O(); case 17: return A_arbace_instant__init_A_Unit23__O(); case 18: return A_arbace_instant__init_A_Unit24__O(); case 19: return A_arbace_instant__init_A_Unit25__O(); case 20: return A_arbace_instant__init_A_Unit26__O(); case 21: return A_arbace_instant__init_A_Unit27__O(); case 22: return A_arbace_instant__init_A_Unit28__O(); case 23: return A_arbace_instant__init_A_Unit29__O(); case 24: return A_arbace_instant__init_A_Unit3__O(); case 25: return A_arbace_instant__init_A_Unit30__O(); case 26: return A_arbace_instant__init_A_Unit31__O(); case 27: return A_arbace_instant__init_A_Unit32__O(); case 28: return A_arbace_instant__init_A_Unit33__O(); case 29: return A_arbace_instant__init_A_Unit34__O(); case 30: return A_arbace_instant__init_A_Unit35__O(); case 31: return A_arbace_instant__init_A_Unit36__O(); case 32: return A_arbace_instant__init_A_Unit4__O(); case 33: return A_arbace_instant__init_A_Unit5__O(); case 34: return A_arbace_instant__init_A_Unit6__O(); case 35: return A_arbace_instant__init_A_Unit7__O(); case 36: return A_arbace_instant__init_A_Unit8__O(); case 37: return A_arbace_instant__init_A_Unit9__O()}; return nil }

func A_arbace_instant__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_instant__init_A_New()}; return nil }

var A_arbace_instant__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit34 ()Ljava.lang.Object;\nM9 unit35 ()Ljava.lang.Object;\nM9 unit36 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_instant__init_A_invoke, New: A_arbace_instant__init_A_new}

var A_arbace_instant__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.instant__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_instant.A_arbace_instant__init_A", Source: "instant.ae"})

func init() { i := A_arbace_instant__init_A_class.Info(); i.IsInstance = A_arbace_instant__init_A_InstanceOf; i.Init = A_arbace_instant__init_A_Init; i.Table = A_arbace_instant__init_A_members; jrt.RegisterGoType(A_arbace_instant__init_A_class, reflect.TypeFor[A_arbace_instant__init_A]()) }
