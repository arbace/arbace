//line a2g_strings.ae:1
package aot_arbace_instant

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("commute")

var Lit_3 *jrt.String = jrt.Intern("deref")

var Lit_4 *jrt.String = jrt.Intern("conj")

var Lit_5 *jrt.String = jrt.Intern("arbace.instant")

var Lit_6 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_7 *jrt.String = jrt.Intern("seq")

var Lit_8 *jrt.String = jrt.Intern("concat")

var Lit_9 *jrt.String = jrt.Intern("list")

var Lit_10 *jrt.String = jrt.Intern("throw")

var Lit_11 *jrt.String = jrt.Intern("java.lang.RuntimeException.")

var Lit_12 *jrt.String = jrt.Intern("when-not")

var Lit_13 *jrt.String = jrt.Intern("fail")

var Lit_14 *jrt.String = jrt.Intern("verify")

var Lit_15 *jrt.String = jrt.Intern("pr-str")

var Lit_16 *jrt.String = jrt.Intern("mod")

var Lit_17 *jrt.String = jrt.Intern("not")

var Lit_18 *jrt.String = jrt.Intern("divisible?")

var Lit_19 *jrt.String = jrt.Intern("else")

var Lit_20 *jrt.String = jrt.Intern("re-matches")

var Lit_21 *jrt.String = jrt.Intern("timestamp")

var Lit_22 *jrt.String = jrt.Intern("parse-int")

var Lit_23 *jrt.String = jrt.Intern("zero-fill-right")

var Lit_24 *jrt.String = jrt.Intern("indivisible?")

var Lit_25 *jrt.String = jrt.Intern("<=")

var Lit_26 *jrt.String = jrt.Intern("days-in-month")

var Lit_27 *jrt.String = jrt.Intern("leap-year?")

var Lit_28 *jrt.String = jrt.Intern("gregorian-cutover-day")

var Lit_29 *jrt.String = jrt.Intern("days->civil")

var Lit_30 *jrt.String = jrt.Intern("format")

var Lit_31 *jrt.String = jrt.Intern("print-date")

var Lit_32 *jrt.String = jrt.Intern("print-calendar")

var Lit_33 *jrt.String = jrt.Intern("print-timestamp")

var Lit_34 *jrt.String = jrt.Intern("civil->days")

var Lit_35 *jrt.String = jrt.Intern("parse-timestamp")

var Lit_36 *jrt.String = jrt.Intern("validated")

var Lit_37 *jrt.String = jrt.Intern("construct-date")

var Lit_38 *jrt.String = jrt.Intern("construct-calendar")

var Lit_39 *jrt.String = jrt.Intern("construct-timestamp")

var Lit_40 *jrt.String = jrt.Intern("arbace.instant$civil__GT_days")

var Lit_41 *jrt.String = jrt.Intern("arbace.instant$construct_calendar")

var Lit_42 *jrt.String = jrt.Intern("GMT%s%02d:%02d")

var Lit_43 *jrt.String = jrt.Intern("-")

var Lit_44 *jrt.String = jrt.Intern("+")

var Lit_45 *jrt.String = jrt.Intern("arbace.instant$construct_date")

var Lit_46 *jrt.String = jrt.Intern("arbace.instant$construct_timestamp")

var Lit_47 *jrt.String = jrt.Intern("arbace.instant$days__GT_civil")

var Lit_48 *jrt.String = jrt.Intern("arbace.instant$divisible_QMARK_")

var Lit_49 *jrt.String = jrt.Intern("arbace.instant$eval783000002$loading__1927001464__auto____783000003")

var Lit_50 *jrt.String = jrt.Intern("java.util.Calendar")

var Lit_51 *jrt.String = jrt.Intern("java.util.Date")

var Lit_52 *jrt.String = jrt.Intern("java.util.GregorianCalendar")

var Lit_53 *jrt.String = jrt.Intern("java.util.TimeZone")

var Lit_54 *jrt.String = jrt.Intern("java.sql.Timestamp")

var Lit_55 *jrt.String = jrt.Intern("arbace.instant$eval783000006$fn__783000007")

var Lit_56 *jrt.String = jrt.Intern("arbace.instant$eval783000044$fn__783000045")

var Lit_57 *jrt.String = jrt.Intern("arbace.instant$eval783000048$fn__783000049")

var Lit_58 *jrt.String = jrt.Intern("arbace.instant$eval783000053$fn__783000054")

var Lit_59 *jrt.String = jrt.Intern("arbace.instant$eval783000057$fn__783000058")

var Lit_60 *jrt.String = jrt.Intern("arbace.instant$eval783000065$fn__783000066")

var Lit_61 *jrt.String = jrt.Intern("arbace.instant$eval783000069$fn__783000070")

var Lit_62 *jrt.String = jrt.Intern("arbace.instant$fail")

var Lit_63 *jrt.String = jrt.Intern("arbace.instant$fn__783000031")

var Lit_64 *jrt.String = jrt.Intern("arbace.instant$fn__783000031$fn__783000032")

var Lit_65 *jrt.String = jrt.Intern("arbace.instant$indivisible_QMARK_")

var Lit_66 *jrt.String = jrt.Intern("arbace.instant$leap_year_QMARK_")

var Lit_67 *jrt.String = jrt.Intern("arbace.instant$parse_int")

var Lit_68 *jrt.String = jrt.Intern("arbace.instant$parse_timestamp")

var Lit_69 *jrt.String = jrt.Intern("Unrecognized date/time syntax: ")

var Lit_70 *jrt.String = jrt.Intern("arbace.instant$print_calendar")

var Lit_71 *jrt.String = jrt.Intern("%1$tFT%1$tT.%1$tL%1$tz")

var Lit_72 *jrt.String = jrt.Intern("#inst \"")

var Lit_73 *jrt.String = jrt.Intern(":")

var Lit_74 *jrt.String = jrt.Intern("\"")

var Lit_75 *jrt.String = jrt.Intern("arbace.instant$print_date")

var Lit_76 *jrt.String = jrt.Intern("%04d-%02d-%02dT%02d:%02d:%02d.%03d-00:00")

var Lit_77 *jrt.String = jrt.Intern("arbace.instant$print_timestamp")

var Lit_78 *jrt.String = jrt.Intern("%04d-%02d-%02dT%02d:%02d:%02d")

var Lit_79 *jrt.String = jrt.Intern(".%09d-00:00")

var Lit_80 *jrt.String = jrt.Intern("arbace.instant$read_instant_calendar")

var Lit_81 *jrt.String = jrt.Intern("arbace.instant$read_instant_date")

var Lit_82 *jrt.String = jrt.Intern("arbace.instant$read_instant_timestamp")

var Lit_83 *jrt.String = jrt.Intern("arbace.instant$validated")

var Lit_84 *jrt.String = jrt.Intern("arbace.instant$validated$fn__783000035")

var Lit_85 *jrt.String = jrt.Intern("failed: (<= 1 months 12)")

var Lit_86 *jrt.String = jrt.Intern("failed: (<= 1 days (days-in-month months (leap-year? years)))")

var Lit_87 *jrt.String = jrt.Intern("failed: (<= 0 hours 23)")

var Lit_88 *jrt.String = jrt.Intern("failed: (<= 0 minutes 59)")

var Lit_89 *jrt.String = jrt.Intern("failed: (<= 0 seconds (if (= minutes 59) 60 59))")

var Lit_90 *jrt.String = jrt.Intern("failed: (<= 0 nanoseconds 999999999)")

var Lit_91 *jrt.String = jrt.Intern("failed: (<= -1 offset-sign 1)")

var Lit_92 *jrt.String = jrt.Intern("failed: (<= 0 offset-hours 23)")

var Lit_93 *jrt.String = jrt.Intern("failed: (<= 0 offset-minutes 59)")

var Lit_94 *jrt.String = jrt.Intern("arbace.instant$verify")

var Lit_95 *jrt.String = jrt.Intern("failed: ")

var Lit_96 *jrt.String = jrt.Intern("arbace.instant$zero_fill_right")

var Lit_97 *jrt.String = jrt.Intern("in-ns")

var Lit_98 *jrt.String = jrt.Intern("*warn-on-reflection*")

var Lit_99 *jrt.String = jrt.Intern("private")

var Lit_100 *jrt.String = jrt.Intern("arglists")

var Lit_101 *jrt.String = jrt.Intern("msg")

var Lit_102 *jrt.String = jrt.Intern("line")

var Lit_103 *jrt.String = jrt.Intern("column")

var Lit_104 *jrt.String = jrt.Intern("file")

var Lit_105 *jrt.String = jrt.Intern("arbace/instant.ae")

var Lit_106 *jrt.String = jrt.Intern("test")

var Lit_107 *jrt.String = jrt.Intern("num")

var Lit_108 *jrt.String = jrt.Intern("div")

var Lit_109 *jrt.String = jrt.Intern("s")

var Lit_110 *jrt.String = jrt.Intern("tag")

var Lit_111 *jrt.String = jrt.Intern("String")

var Lit_112 *jrt.String = jrt.Intern("width")

var Lit_113 *jrt.String = jrt.Intern("(\\d\\d\\d\\d)(?:-(\\d\\d)(?:-(\\d\\d)(?:[T](\\d\\d)(?::(\\d\\d)(?::(\\d\\d)(?:[.](\\d+))?)?)?)?)?)?(?:[Z]|([-+])(\\d\\d):(\\d\\d))?")

var Lit_114 *jrt.String = jrt.Intern("new-instant")

var Lit_115 *jrt.String = jrt.Intern("cs")

var Lit_116 *jrt.String = jrt.Intern("CharSequence")

var Lit_117 *jrt.String = jrt.Intern("doc")

var Lit_118 *jrt.String = jrt.Intern("Parse a string containing an RFC3339-like like timestamp.\n\nThe function new-instant is called with the following arguments.\n\n                min  max           default\n                ---  ------------  -------\n  years          0           9999      N/A (s must provide years)\n  months         1             12        1\n  days           1             31        1 (actual max days depends\n  hours          0             23        0  on month and year)\n  minutes        0             59        0\n  seconds        0             60        0 (though 60 is only valid\n  nanoseconds    0      999999999        0  when minutes is 59)\n  offset-sign   -1              1        0\n  offset-hours   0             23        0\n  offset-minutes 0             59        0\n\nThese are all integers and will be non-nil. (The listed defaults\nwill be passed if the corresponding field is not present in s.)\n\nGrammar (of s):\n\n  date-fullyear   = 4DIGIT\n  date-month      = 2DIGIT  ; 01-12\n  date-mday       = 2DIGIT  ; 01-28, 01-29, 01-30, 01-31 based on\n                            ; month/year\n  time-hour       = 2DIGIT  ; 00-23\n  time-minute     = 2DIGIT  ; 00-59\n  time-second     = 2DIGIT  ; 00-58, 00-59, 00-60 based on leap second\n                            ; rules\n  time-secfrac    = '.' 1*DIGIT\n  time-numoffset  = ('+' / '-') time-hour ':' time-minute\n  time-offset     = 'Z' / time-numoffset\n\n  time-part       = time-hour [ ':' time-minute [ ':' time-second\n                    [time-secfrac] [time-offset] ] ]\n\n  timestamp       = date-year [ '-' date-month [ '-' date-mday\n                    [ 'T' time-part ] ] ]\n\nUnlike RFC3339:\n\n  - we only parse the timestamp format\n  - timestamp can elide trailing components\n  - time-offset is optional (defaults to +00:00)\n\nThough time-offset is syntactically optional, a missing time-offset\nwill be treated as if the time-offset zero (+00:00) had been\nspecified.\n")

var Lit_119 *jrt.String = jrt.Intern("year")

var Lit_120 *jrt.String = jrt.Intern("new-instance")

var Lit_121 *jrt.String = jrt.Intern("Return a function which constructs an instant by calling constructor\nafter first validating that those arguments are in range and otherwise\nplausible. The resulting function will throw an exception if called\nwith invalid arguments.")

var Lit_122 *jrt.String = jrt.Intern("The first day of the Gregorian calendar, 1582-10-15, in days since 1970-01-01, as\n  java.util.GregorianCalendar's default cutover (the Julian calendar before it).")

var Lit_123 *jrt.String = jrt.Intern("z")

var Lit_124 *jrt.String = jrt.Intern("[year month day] of a count of days since 1970-01-01: the Gregorian calendar from its\n  cutover, the Julian before (GregorianCalendar's); the year astronomical (0 is 1 BC).")

var Lit_125 *jrt.String = jrt.Intern("y")

var Lit_126 *jrt.String = jrt.Intern("m")

var Lit_127 *jrt.String = jrt.Intern("d")

var Lit_128 *jrt.String = jrt.Intern("The count of days since 1970-01-01 of a (astronomical) year, month, day, as\n  GregorianCalendar counts it: Gregorian from the cutover, Julian before.")

var Lit_129 *jrt.String = jrt.Intern("w")

var Lit_130 *jrt.String = jrt.Intern("java.io.Writer")

var Lit_131 *jrt.String = jrt.Intern("Print a java.util.Date as RFC3339 timestamp, always in UTC.")

var Lit_132 *jrt.String = jrt.Intern("print-method")

var Lit_133 *jrt.String = jrt.Intern("print-dup")

var Lit_134 *jrt.String = jrt.Intern("c")

var Lit_135 *jrt.String = jrt.Intern("Print a java.util.Calendar as RFC3339 timestamp, preserving timezone.")

var Lit_136 *jrt.String = jrt.Intern("ts")

var Lit_137 *jrt.String = jrt.Intern("Print a java.sql.Timestamp as RFC3339 timestamp, always in UTC.")

var Lit_138 *jrt.String = jrt.Intern("years")

var Lit_139 *jrt.String = jrt.Intern("months")

var Lit_140 *jrt.String = jrt.Intern("days")

var Lit_141 *jrt.String = jrt.Intern("hours")

var Lit_142 *jrt.String = jrt.Intern("minutes")

var Lit_143 *jrt.String = jrt.Intern("seconds")

var Lit_144 *jrt.String = jrt.Intern("nanoseconds")

var Lit_145 *jrt.String = jrt.Intern("offset-sign")

var Lit_146 *jrt.String = jrt.Intern("offset-hours")

var Lit_147 *jrt.String = jrt.Intern("offset-minutes")

var Lit_148 *jrt.String = jrt.Intern("Construct a java.util.Date, which expresses the original instant as\nmilliseconds since the epoch, UTC.")

var Lit_149 *jrt.String = jrt.Intern("read-instant-date")

var Lit_150 *jrt.String = jrt.Intern("To read an instant as a java.util.Date, bind *data-readers* to a map with\nthis var as the value for the 'inst key. The timezone offset will be used\nto convert into UTC.")

var Lit_151 *jrt.String = jrt.Intern("Construct a java.util.Calendar, preserving the timezone\noffset, but truncating the subsecond fraction to milliseconds.")

var Lit_152 *jrt.String = jrt.Intern("Construct a java.sql.Timestamp, which has nanosecond precision.")

var Lit_153 *jrt.String = jrt.Intern("read-instant-calendar")

var Lit_154 *jrt.String = jrt.Intern("To read an instant as a java.util.Calendar, bind *data-readers* to a map with\nthis var as the value for the 'inst key.  Calendar preserves the timezone\noffset.")

var Lit_155 *jrt.String = jrt.Intern("read-instant-timestamp")

var Lit_156 *jrt.String = jrt.Intern("To read an instant as a java.sql.Timestamp, bind *data-readers* to a\nmap with this var as the value for the 'inst key. Timestamp preserves\nfractional seconds with nanosecond precision. The timezone offset will\nbe used to convert into UTC.")
