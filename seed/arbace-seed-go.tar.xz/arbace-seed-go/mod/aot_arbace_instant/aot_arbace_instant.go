//line aot_arbace_instant.ae:1
package aot_arbace_instant

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)













func A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_New() *A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A) Ctor() {}
//line :21:1
func (t *A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_instant_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_1); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_4)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_5)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_6)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_7)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_8)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :21:1
func A_arbace_instant_eval783000006_fn__783000007_A_New() *A_arbace_instant_eval783000006_fn__783000007_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000006_fn__783000007_A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_instant_eval783000006_fn__783000007_A) Ctor() {}
//line :21:1
func (t *A_arbace_instant_eval783000006_fn__783000007_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_2.GetRawRoot__O()); var tmp2 any; var root_11 any = A_arbace_instant_A_const_3.GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_11, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = A_arbace_instant_A_const_4; if linked_12 == nil { tmp2 = ifn_13.Invoke_O__O(arg_14) } else { tmp2 = linked_12.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_11, arg_14) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_instant_A_const_5.GetRawRoot__O(), A_arbace_instant_A_const_6) }








func A_arbace_instant_fail_A_New() *A_arbace_instant_fail_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_fail_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_instant_fail_A) Ctor() {}
//line :30:1
func (t *A_arbace_instant_fail_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, msg__2 any) any { var root_15 any = A_arbace_instant_A_const_7.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any; var root_19 any = A_arbace_instant_A_const_8.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_10); var arg_23 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()); var tmp2 any; var root_24 any = A_arbace_instant_A_const_7.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any; var root_28 any = A_arbace_instant_A_const_8.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_30 lang.IFn; if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_11); var arg_32 any = lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(msg__2); if linked_29 == nil { arg_27 = ifn_30.Invoke_O_O__O(arg_31, arg_32) } else { arg_27 = linked_29.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_28, arg_31, arg_32) }; if linked_25 == nil { tmp2 = ifn_26.Invoke_O__O(arg_27) } else { tmp2 = linked_25.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_24, arg_27) }; arg_23 = tmp1.Invoke_O__O(tmp2); if linked_20 == nil { arg_18 = ifn_21.Invoke_O_O__O(arg_22, arg_23) } else { arg_18 = linked_20.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_19, arg_22, arg_23) }; if linked_16 == nil { return ifn_17.Invoke_O__O(arg_18) } else { return linked_16.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_15, arg_18) } }



func A_arbace_instant_verify_A_New() *A_arbace_instant_verify_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_verify_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_instant_verify_A) Ctor() {}
//line :34:1
func (t *A_arbace_instant_verify_A) Invoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, test__2, msg__3 any) any { var root_33 any = A_arbace_instant_A_const_7.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_33, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_35 lang.IFn; if linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_8.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_12); var tmp3 any = lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(test__2); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()); var tmp5 any; var root_43 any = A_arbace_instant_A_const_7.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any; var root_47 any = A_arbace_instant_A_const_8.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_13); var arg_51 any = lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(msg__3); if linked_48 == nil { arg_46 = ifn_49.Invoke_O_O__O(arg_50, arg_51) } else { arg_46 = linked_48.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_47, arg_50, arg_51) }; if linked_44 == nil { tmp5 = ifn_45.Invoke_O__O(arg_46) } else { tmp5 = linked_44.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_43, arg_46) }; arg_36 = tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O__O(tmp5)); if linked_34 == nil { return ifn_35.Invoke_O__O(arg_36) } else { return linked_34.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_33, arg_36) } }
//line :34:1
func (t *A_arbace_instant_verify_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, test__2 any) any { var root_52 any = A_arbace_instant_A_const_7.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = lang.IFn_Cast(A_arbace_instant_A_const_8.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_14), lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(test__2), lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_28, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_instant_A_const_15.GetRawRoot__O()).Invoke_O__O(test__2))).Ref())); if linked_53 == nil { return ifn_54.Invoke_O__O(arg_55) } else { return linked_53.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_52, arg_55) } }



func A_arbace_instant_divisible_QMARK__A_New() *A_arbace_instant_divisible_QMARK__A { A_arbace_instant_A_Init(); t := &A_arbace_instant_divisible_QMARK__A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_instant_divisible_QMARK__A) Ctor() {}
//line :38:1
func (t *A_arbace_instant_divisible_QMARK__A) Invoke_O_O_O__O(self, num__0, div__1 any) any {

	var tmp1 bool; var na_66 any; var root_67 any = A_arbace_instant_A_const_16.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_mod_A_fn_class); var ifn_69 lang.IFn; if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = num__0; var arg_71 any = div__1; if linked_68 == nil { na_66 = ifn_69.Invoke_O_O__O(arg_70, arg_71) } else { na_66 = linked_68.(*aot_arbace_core.A_arbace_core_mod_A).Invoke_O_O_O__O(root_67, arg_70, arg_71) }; if jrt.Long_InstanceOf(na_66) { var n0_72 int64 = jrt.NN(jrt.Long_Cast(na_66)).LongValue__J(); tmp1 = n0_72 == 0 } else { if jrt.Double_InstanceOf(na_66) { var n0_72_2 float64 = jrt.NN(jrt.Double_Cast(na_66)).DoubleValue__D(); tmp1 = n0_72_2 == 0.0 } else { tmp1 = lang.Numbers_IsZero_O__Z_NoInit(na_66) } }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp1).Ref()
}
func A_arbace_instant_indivisible_QMARK__A_New() *A_arbace_instant_indivisible_QMARK__A { A_arbace_instant_A_Init(); t := &A_arbace_instant_indivisible_QMARK__A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_instant_indivisible_QMARK__A) Ctor() {}
//line :42:1
func (t *A_arbace_instant_indivisible_QMARK__A) Invoke_O_O_O__O(self, num__0, div__1 any) any {

	var root_73 any = A_arbace_instant_A_const_17.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any; var root_77 any = A_arbace_instant_A_const_18.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, A_arbace_instant_divisible_QMARK__A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = num__0; var arg_81 any = div__1; if linked_78 == nil { arg_76 = ifn_79.Invoke_O_O__O(arg_80, arg_81) } else { arg_76 = linked_78.(*A_arbace_instant_divisible_QMARK__A).Invoke_O_O_O__O(root_77, arg_80, arg_81) }; if linked_74 == nil { return ifn_75.Invoke_O__O(arg_76) } else { return linked_74.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_73, arg_76)
	}
}


func A_arbace_instant_parse_int_A_New() *A_arbace_instant_parse_int_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_parse_int_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_instant_parse_int_A) Ctor() {}
//line :49:1
func (t *A_arbace_instant_parse_int_A) Invoke_O_O__O(self, s__0 any) any {
	return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(s__0))).Ref()
}
func A_arbace_instant_zero_fill_right_A_New() *A_arbace_instant_zero_fill_right_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_zero_fill_right_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_instant_zero_fill_right_A) Ctor() {}
//line :52:1
func (t *A_arbace_instant_zero_fill_right_A) Invoke_O_O_O__O(self, s__0, width__1 any) any {
	if lang.Util_Equiv_O_J__Z_NoInit(width__1, int64(lang.RT_Count_O__I_NoInit(s__0))) { return s__0 } else { var tmp1 bool; var na_82 any = width__1; var na_83 int64 = int64(lang.RT_Count_O__I_NoInit(s__0))
		if jrt.Long_InstanceOf(na_82) { var n0_84 int64 = jrt.NN(jrt.Long_Cast(na_82)).LongValue__J(); var n1_85 int64 = na_83; tmp1 = n0_84 < n1_85 } else { tmp1 = lang.Numbers_Lt_O_J__Z_NoInit(na_82, na_83) }
//line :53:1
		if tmp1 {
			return jrt.NN(jrt.String_Cast(s__0)).Substring_I_I__String(lang.RT_IntCast_J__I_NoInit(0), lang.RT_IntCast_O__I_NoInit(width__1)).Ref() } else {
//line :53:1
				if A_arbace_instant_A_const_19 != nil { var b__3 any = jrt.StringBuilder_New_String(jrt.String_Cast(s__0)); L1: for {


					var tmp2 bool; var na_87 int64 = int64(jrt.NN(jrt.StringBuilder_Cast(b__3)).Length__I()); var na_88 any = width__1; if jrt.Long_InstanceOf(na_88) { var n0_89 int64 = na_87; var n1_90 int64 = jrt.NN(jrt.Long_Cast(na_88)).LongValue__J(); tmp2 = n0_89 < n1_90 } else { tmp2 = lang.Numbers_Lt_J_O__Z_NoInit(na_87, na_88) }; if tmp2 {
						b__3 = jrt.NN(jrt.StringBuilder_Cast(b__3)).Append_O__StringBuilder(A_arbace_instant_A_const_20).Ref(); continue L1 } else {
							return jrt.NN(jrt.StringBuilder_Cast(b__3)).ToString__String().Ref() } } } else {
//line :53:1
								return nil } } }
//line :52:1
	panic("j2g: unreachable")
}









func A_arbace_instant_parse_timestamp_A_New() *A_arbace_instant_parse_timestamp_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_parse_timestamp_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_instant_parse_timestamp_A) Ctor() {}
//line :63:1
func (t *A_arbace_instant_parse_timestamp_A) Invoke_O_O_O__O(self, new_instant__0, cs__1 any) any { var temp__1927000408__auto____3 any; var root_92 any = A_arbace_instant_A_const_21.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_94 lang.IFn; if





















































	linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = A_arbace_instant_A_const_22.GetRawRoot__O(); var arg_96 any = cs__1; if linked_93 == nil { temp__1927000408__auto____3 = ifn_94.Invoke_O_O__O(arg_95, arg_96) } else { temp__1927000408__auto____3 = linked_93.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_92, arg_95, arg_96) }; if /*line :115:1*/ jrt.J2g_Truth(temp__1927000408__auto____3) { var vec__783000026__4 any = temp__1927000408__auto____3; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(0), nil); var years__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(1), nil); var months__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(2), nil); var days__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(3), nil); var hours__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(4), nil); var minutes__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(5), nil); var seconds__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(6), nil); var fraction__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(7), nil); var offset_sign__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(8), nil); var offset_hours__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(9), nil); var offset_minutes__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(10), nil); var tmp1 lang.IFn = lang.IFn_Cast(new_instant__0); var tmp2 any; var root_97 any = A_arbace_instant_A_const_23.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, A_arbace_instant_parse_int_A_fn_class); var ifn_99 lang.IFn; _ = ___5



		if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = years__6; if linked_98 == nil { tmp2 = ifn_99.Invoke_O__O(arg_100) } else { tmp2 = linked_98.(*A_arbace_instant_parse_int_A).Invoke_O_O__O(root_97, arg_100) }
//line :118:1
		var tmp3 any = tmp2; var tmp4 any; var tmp5 any; var root_101 any = A_arbace_instant_A_const_17.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_103 lang.IFn

		if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = months__7; if linked_102 == nil { tmp5 = ifn_103.Invoke_O__O(arg_104) } else { tmp5 = linked_102.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_101, arg_104) }; if jrt.J2g_Truth(tmp5) { tmp4 = A_arbace_instant_A_const_24 } else { var root_105 any = A_arbace_instant_A_const_23.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, A_arbace_instant_parse_int_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = months__7; if linked_106 == nil { tmp4 = ifn_107.Invoke_O__O(arg_108) } else { tmp4 = linked_106.(*A_arbace_instant_parse_int_A).Invoke_O_O__O(root_105, arg_108) } }
//line :118:1
		var tmp6 any = tmp4; var tmp7 any; var tmp8 any; var root_109 any = A_arbace_instant_A_const_17.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_111 lang.IFn


		if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = days__8; if linked_110 == nil { tmp8 = ifn_111.Invoke_O__O(arg_112) } else { tmp8 = linked_110.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_109, arg_112) }; if jrt.J2g_Truth(tmp8) { tmp7 = A_arbace_instant_A_const_24 } else { var root_113 any = A_arbace_instant_A_const_23.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, A_arbace_instant_parse_int_A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = days__8; if linked_114 == nil { tmp7 = ifn_115.Invoke_O__O(arg_116) } else { tmp7 = linked_114.(*A_arbace_instant_parse_int_A).Invoke_O_O__O(root_113, arg_116) } }
//line :118:1
		var tmp9 any = tmp7; var tmp10 any; var tmp11 any; var root_117 any = A_arbace_instant_A_const_17.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_119 lang.IFn



		if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = hours__9; if linked_118 == nil { tmp11 = ifn_119.Invoke_O__O(arg_120) } else { tmp11 = linked_118.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_117, arg_120) }; if jrt.J2g_Truth(tmp11) { tmp10 = A_arbace_instant_A_const_25 } else { var root_121 any = A_arbace_instant_A_const_23.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, A_arbace_instant_parse_int_A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = hours__9; if linked_122 == nil { tmp10 = ifn_123.Invoke_O__O(arg_124) } else { tmp10 = linked_122.(*A_arbace_instant_parse_int_A).Invoke_O_O__O(root_121, arg_124) } }
//line :118:1
		var tmp12 any = tmp10; var tmp13 any; var tmp14 any; var root_125 any = A_arbace_instant_A_const_17.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_127 lang.IFn




		if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = minutes__10; if linked_126 == nil { tmp14 = ifn_127.Invoke_O__O(arg_128) } else { tmp14 = linked_126.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_125, arg_128) }; if jrt.J2g_Truth(tmp14) { tmp13 = A_arbace_instant_A_const_25 } else { var root_129 any = A_arbace_instant_A_const_23.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, A_arbace_instant_parse_int_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = minutes__10; if linked_130 == nil { tmp13 = ifn_131.Invoke_O__O(arg_132) } else { tmp13 = linked_130.(*A_arbace_instant_parse_int_A).Invoke_O_O__O(root_129, arg_132) } }
//line :118:1
		var tmp15 any = tmp13; var tmp16 any; var tmp17 any; var root_133 any = A_arbace_instant_A_const_17.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_135 lang.IFn





		if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = seconds__11; if linked_134 == nil { tmp17 = ifn_135.Invoke_O__O(arg_136) } else { tmp17 = linked_134.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_133, arg_136) }; if jrt.J2g_Truth(tmp17) { tmp16 = A_arbace_instant_A_const_25 } else { var root_137 any = A_arbace_instant_A_const_23.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, A_arbace_instant_parse_int_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = seconds__11; if linked_138 == nil { tmp16 = ifn_139.Invoke_O__O(arg_140) } else { tmp16 = linked_138.(*A_arbace_instant_parse_int_A).Invoke_O_O__O(root_137, arg_140) } }
//line :118:1
		var tmp18 any = tmp16; var tmp19 any; var tmp20 any; var root_141 any = A_arbace_instant_A_const_17.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_143 lang.IFn






		if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = fraction__12; if linked_142 == nil { tmp20 = ifn_143.Invoke_O__O(arg_144) } else { tmp20 = linked_142.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_141, arg_144) }; if jrt.J2g_Truth(tmp20) { tmp19 = A_arbace_instant_A_const_25 } else { var root_145 any = A_arbace_instant_A_const_23.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, A_arbace_instant_parse_int_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any; var root_149 any = A_arbace_instant_A_const_26.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, A_arbace_instant_zero_fill_right_A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = fraction__12; var arg_153 any = A_arbace_instant_A_const_27; if linked_150 == nil { arg_148 = ifn_151.Invoke_O_O__O(arg_152, arg_153) } else { arg_148 = linked_150.(*A_arbace_instant_zero_fill_right_A).Invoke_O_O_O__O(root_149, arg_152, arg_153) }; if linked_146 == nil { tmp19 = ifn_147.Invoke_O__O(arg_148) } else { tmp19 = linked_146.(*A_arbace_instant_parse_int_A).Invoke_O_O__O(root_145, arg_148) } }
//line :118:1
		var tmp21 any = tmp19; var tmp22 any







		if lang.Util_Equiv_O_O__Z_NoInit(Lit_2, offset_sign__13) { tmp22 = A_arbace_instant_A_const_28 } else { if lang.Util_Equiv_O_O__Z_NoInit(Lit_3, offset_sign__13) { tmp22 = A_arbace_instant_A_const_24 } else { if A_arbace_instant_A_const_19 != nil { tmp22 = A_arbace_instant_A_const_25 } else { tmp22 = nil } } }
//line :118:1
		var tmp23 any = tmp22; var tmp24 any; var tmp25 any; var root_154 any = A_arbace_instant_A_const_17.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_156 lang.IFn










		if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = offset_hours__14; if linked_155 == nil { tmp25 = ifn_156.Invoke_O__O(arg_157) } else { tmp25 = linked_155.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_154, arg_157) }; if jrt.J2g_Truth(tmp25) { tmp24 = A_arbace_instant_A_const_25 } else { var root_158 any = A_arbace_instant_A_const_23.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, A_arbace_instant_parse_int_A_fn_class); var ifn_160 lang.IFn; if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any = offset_hours__14; if linked_159 == nil { tmp24 = ifn_160.Invoke_O__O(arg_161) } else { tmp24 = linked_159.(*A_arbace_instant_parse_int_A).Invoke_O_O__O(root_158, arg_161) } }
//line :118:1
		var tmp26 any = tmp24; var tmp27 any; var tmp28 any; var root_162 any = A_arbace_instant_A_const_17.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_164 lang.IFn











		if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = offset_minutes__15; if linked_163 == nil { tmp28 = ifn_164.Invoke_O__O(arg_165) } else { tmp28 = linked_163.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_162, arg_165) }; if jrt.J2g_Truth(tmp28) { tmp27 = A_arbace_instant_A_const_25 } else { var root_166 any = A_arbace_instant_A_const_23.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, A_arbace_instant_parse_int_A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = offset_minutes__15; if linked_167 == nil { tmp27 = ifn_168.Invoke_O__O(arg_169) } else { tmp27 = linked_167.(*A_arbace_instant_parse_int_A).Invoke_O_O__O(root_166, arg_169) } }
//line :118:1
		return tmp1.Invoke_O_O_O_O_O_O_O_O_O_O__O(tmp3, tmp6, tmp9, tmp12, tmp15, tmp18, tmp21, tmp23, tmp26, tmp27) } else {
//line :115:1
			panic(jrt.Thrown(jrt.RuntimeException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, cs__1))))) } }




















func A_arbace_instant_leap_year_QMARK__A_New() *A_arbace_instant_leap_year_QMARK__A { A_arbace_instant_A_Init(); t := &A_arbace_instant_leap_year_QMARK__A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_instant_leap_year_QMARK__A) Ctor() {}
//line :136:1
func (t *A_arbace_instant_leap_year_QMARK__A) Invoke_O_O__O(self, year__0 any) any { var and__1927000168__auto____2 any; var root_170 any = A_arbace_instant_A_const_18.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, A_arbace_instant_divisible_QMARK__A_fn_class); var ifn_172 lang.IFn; if

	linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = year__0; var arg_174 any = A_arbace_instant_A_const_29; if linked_171 == nil { and__1927000168__auto____2 = ifn_172.Invoke_O_O__O(arg_173, arg_174) } else { and__1927000168__auto____2 = linked_171.(*A_arbace_instant_divisible_QMARK__A).Invoke_O_O_O__O(root_170, arg_173, arg_174) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var or__1927000174__auto____3 any; var root_175 any = A_arbace_instant_A_const_30.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, A_arbace_instant_indivisible_QMARK__A_fn_class); var ifn_177 lang.IFn
		if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = year__0; var arg_179 any = A_arbace_instant_A_const_31; if linked_176 == nil { or__1927000174__auto____3 = ifn_177.Invoke_O_O__O(arg_178, arg_179) } else { or__1927000174__auto____3 = linked_176.(*A_arbace_instant_indivisible_QMARK__A).Invoke_O_O_O__O(root_175, arg_178, arg_179) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else {
			var root_180 any = A_arbace_instant_A_const_18.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, A_arbace_instant_divisible_QMARK__A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = year__0; var arg_184 any = A_arbace_instant_A_const_32; if linked_181 == nil { return ifn_182.Invoke_O_O__O(arg_183, arg_184) } else { return linked_181.(*A_arbace_instant_divisible_QMARK__A).Invoke_O_O_O__O(root_180, arg_183, arg_184) } } } else {
//line :138:1
				return and__1927000168__auto____2 } }




func A_arbace_instant_fn__783000031_A_New() *A_arbace_instant_fn__783000031_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_fn__783000031_A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_instant_fn__783000031_A) Ctor() {}
//line :143:1
func (t *A_arbace_instant_fn__783000031_A) Invoke_O__O(self any) any { var dim_norm__1 any = A_arbace_instant_A_const_33; var dim_leap__2 any = A_arbace_instant_A_const_34; var fnbody__186 any = A_arbace_instant_fn__783000031_fn__783000032_A_New_O_O(dim_norm__1, dim_leap__2); var tmp1 *jrt.Class; var fncls__185 *jrt.Class = A_arbace_instant_fn__783000031_fn__783000032_A_fn_class; if

	fncls__185 == nil { var fncls__185d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, fnbody__186); A_arbace_instant_fn__783000031_fn__783000032_A_fn_class = fncls__185d; tmp1 = fncls__185d } else { tmp1 = fncls__185 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__186, tmp1, nil) }
//line :145:1
func A_arbace_instant_fn__783000031_fn__783000032_A_New_O_O(p0, p1 any) *A_arbace_instant_fn__783000031_fn__783000032_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_fn__783000031_fn__783000032_A{}; t.Ctor_O_O(p0, p1); return t }
//line :145:1
func (t *A_arbace_instant_fn__783000031_fn__783000032_A) Ctor_O_O(c__dim_norm, c__dim_leap any) { t.F_dim_norm = c__dim_norm; t.F_dim_leap = c__dim_leap }
//line :145:1
func (t *A_arbace_instant_fn__783000031_fn__783000032_A) Invoke_O_O_O__O(self, month__1, leap_year_QMARK___2 any) any {
	var tmp1 any; if jrt.J2g_Truth(leap_year_QMARK___2) { tmp1 = t.F_dim_leap } else { tmp1 = t.F_dim_norm }; return lang.IFn_Cast(tmp1).Invoke_O__O(month__1)
}
func A_arbace_instant_validated_A_New() *A_arbace_instant_validated_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_validated_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_instant_validated_A) Ctor() {}
//line :148:1
func (t *A_arbace_instant_validated_A) Invoke_O_O__O(self, new_instance__0 any) any {





	var fnbody__251 any = A_arbace_instant_validated_fn__783000035_A_New_O(new_instance__0); var tmp1 *jrt.Class; var fncls__250 *jrt.Class = A_arbace_instant_validated_fn__783000035_A_fn_class; if fncls__250 == nil { var fncls__250d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, fnbody__251); A_arbace_instant_validated_fn__783000035_A_fn_class = fncls__250d; tmp1 = fncls__250d } else { tmp1 = fncls__250 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__251, tmp1, nil) }
//line :154:1
func A_arbace_instant_validated_fn__783000035_A_New_O(p0 any) *A_arbace_instant_validated_fn__783000035_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_validated_fn__783000035_A{}; t.Ctor_O(p0); return t }
//line :154:1
func (t *A_arbace_instant_validated_fn__783000035_A) Ctor_O(c__new_instance any) { t.F_new_instance = c__new_instance }
//line :154:1
func (t *A_arbace_instant_validated_fn__783000035_A) Invoke_O_O_O_O_O_O_O_O_O_O_O__O(self, years__1, months__2, days__3, hours__4, minutes__5, seconds__6, nanoseconds__7, offset_sign__8, offset_hours__9, offset_minutes__10 any) any {

	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_24, months__2, A_arbace_instant_A_const_36)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_19))) }
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()); var tmp2 any = A_arbace_instant_A_const_24; var tmp3 any; var root_199 any = A_arbace_instant_A_const_37.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, A_arbace_instant_fn__783000031_fn__783000032_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = months__2; var arg_203 any; var root_204 any = A_arbace_instant_A_const_38.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, A_arbace_instant_leap_year_QMARK__A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = years__1; if linked_205 == nil { arg_203 = ifn_206.Invoke_O__O(arg_207) } else { arg_203 = linked_205.(*A_arbace_instant_leap_year_QMARK__A).Invoke_O_O__O(root_204, arg_207) }; if linked_200 == nil { tmp3 = ifn_201.Invoke_O_O__O(arg_202, arg_203) } else { tmp3 = linked_200.(*A_arbace_instant_fn__783000031_fn__783000032_A).Invoke_O_O_O__O(root_199, arg_202, arg_203) }; if jrt.J2g_Truth(tmp1.Invoke_O_O_O__O(tmp2, days__3, tmp3)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_20))) }
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_25, hours__4, A_arbace_instant_A_const_39)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_21))) }
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_25, minutes__5, A_arbace_instant_A_const_40)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_22))) }
	var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()); var tmp5 any = A_arbace_instant_A_const_25; var tmp6 any; if lang.Util_Equiv_O_J__Z_NoInit(minutes__5, 59) { tmp6 = A_arbace_instant_A_const_41 } else { tmp6 = A_arbace_instant_A_const_40 }; if jrt.J2g_Truth(tmp4.Invoke_O_O_O__O(tmp5, seconds__6, tmp6)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_23))) }
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_25, nanoseconds__7, A_arbace_instant_A_const_42)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_24))) }
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_28, offset_sign__8, A_arbace_instant_A_const_24)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_25))) }
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_25, offset_hours__9, A_arbace_instant_A_const_39)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_26))) }
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_25, offset_minutes__10, A_arbace_instant_A_const_40)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_27))) }
	return lang.IFn_Cast(t.F_new_instance).Invoke_O_O_O_O_O_O_O_O_O_O__O(years__1, months__2, days__3, hours__4, minutes__5, seconds__6, nanoseconds__7, offset_sign__8, offset_hours__9, offset_minutes__10)
}











func A_arbace_instant_days__GT_civil_A_New() *A_arbace_instant_days__GT_civil_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_days__GT_civil_A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_instant_days__GT_civil_A) Ctor() {}
//line :178:1
func (t *A_arbace_instant_days__GT_civil_A) Invoke_O_O__O(self, z__0 any) any {



	var tmp1 bool; var na_252 any = z__0; var na_253 any = A_arbace_instant_A_const_43.GetRawRoot__O(); var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_252); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_253) }; tmp2 = tmp3; if tmp2 { var n0_254 int64 = jrt.NN(jrt.Long_Cast(na_252)).LongValue__J(); var n1_255 int64 = jrt.NN(jrt.Long_Cast(na_253)).LongValue__J(); tmp1 = n0_254 >= n1_255 } else { var tmp4 bool; var tmp5 bool; tmp5 = jrt.Double_InstanceOf(na_252); if tmp5 { tmp5 = jrt.Double_InstanceOf(na_253) }; tmp4 = tmp5; if tmp4 { var n0_254_2 float64 = jrt.NN(jrt.Double_Cast(na_252)).DoubleValue__D(); var n1_255_2 float64 = jrt.NN(jrt.Double_Cast(na_253)).DoubleValue__D(); tmp1 = n0_254_2 >= n1_255_2 } else { tmp1 = lang.Numbers_Gte_O_O__Z_NoInit(na_252, na_253) } }; if tmp1 { var z__2 any; var na_257 any = z__0; var na_258 int64 = 719468
		if jrt.Long_InstanceOf(na_257) { var n0_259 int64 = jrt.NN(jrt.Long_Cast(na_257)).LongValue__J(); var n1_260 int64 = na_258; var nr_261 int64 = n0_259 + n1_260; if (n0_259^nr_261)&(n1_260^nr_261) >= 0 { z__2 = jrt.Long_ValueOf_J__Long_NoInit(nr_261).Ref() } else { z__2 = lang.Numbers_Add_O_J__Number_NoInit(na_257, na_258) } } else { z__2 = lang.Numbers_Add_O_J__Number_NoInit(na_257, na_258) }
//line :182:1
		var era__3 any; var na_262 any; var tmp6 bool
		var na_264 any = z__2; var na_265 int64 = 0
		if jrt.Long_InstanceOf(na_264) { var n0_266 int64 = jrt.NN(jrt.Long_Cast(na_264)).LongValue__J(); var n1_267 int64 = na_265; tmp6 = n0_266 >= n1_267 } else { tmp6 = lang.Numbers_Gte_O_J__Z_NoInit(na_264, na_265) }; if tmp6 { na_262 = z__2 } else { var na_269 any = z__2; var na_270 int64 = 146096; if jrt.Long_InstanceOf(na_269) { var n0_271 int64 = jrt.NN(jrt.Long_Cast(na_269)).LongValue__J(); var n1_272 int64 = na_270; var nr_273 int64 = n0_271 - n1_272; var tmp7 bool; var tmp8 bool; tmp8 = !(n1_272 == -9223372036854775808); if tmp8 { tmp8 = (n0_271^n1_272)&(n0_271^nr_273) >= 0 }; tmp7 = tmp8; if tmp7 { na_262 = jrt.Long_ValueOf_J__Long_NoInit(nr_273).Ref() } else { na_262 = lang.Numbers_Minus_O_J__Number_NoInit(na_269, na_270) } } else { na_262 = lang.Numbers_Minus_O_J__Number_NoInit(na_269, na_270) } }; var na_263 int64 = 146097; if jrt.Long_InstanceOf(na_262) { var n0_274 int64 = jrt.NN(jrt.Long_Cast(na_262)).LongValue__J(); var n1_275 int64 = na_263; if n1_275 == 0 { era__3 = lang.Numbers_Quotient_O_J__Number_NoInit(na_262, na_263) } else { era__3 = jrt.Long_ValueOf_J__Long_NoInit(n0_274 / n1_275).Ref() } } else { era__3 = lang.Numbers_Quotient_O_J__Number_NoInit(na_262, na_263) }
//line :182:1
		var doe__4 any; var na_277 any = z__2; var na_278 any
		var na_279 any = era__3
		var na_280 int64 = 146097
		if jrt.Long_InstanceOf(na_279) { var n0_281 int64 = jrt.NN(jrt.Long_Cast(na_279)).LongValue__J(); var n1_282 int64 = na_280; var nr_283 int64 = n0_281 * n1_282; var tmp9 bool; var tmp10 bool; var tmp11 bool; var tmp12 bool; tmp12 = n0_281 == -9223372036854775808; if tmp12 { tmp12 = n1_282 < 0 }; tmp11 = tmp12; tmp10 = !tmp11; if tmp10 { var tmp13 bool; tmp13 = n1_282 == 0; if !tmp13 { tmp13 = nr_283/n1_282 == n0_281 }; tmp10 = tmp13 }; tmp9 = tmp10; if tmp9 { na_278 = jrt.Long_ValueOf_J__Long_NoInit(nr_283).Ref() } else { na_278 = lang.Numbers_Multiply_O_J__Number_NoInit(na_279, na_280) } } else { na_278 = lang.Numbers_Multiply_O_J__Number_NoInit(na_279, na_280) }; var tmp14 bool; var tmp15 bool; tmp15 = jrt.Long_InstanceOf(na_277); if tmp15 { tmp15 = jrt.Long_InstanceOf(na_278) }; tmp14 = tmp15; if tmp14 { var n0_284 int64 = jrt.NN(jrt.Long_Cast(na_277)).LongValue__J(); var n1_285 int64 = jrt.NN(jrt.Long_Cast(na_278)).LongValue__J(); var nr_286 int64 = n0_284 - n1_285; var tmp16 bool; var tmp17 bool; tmp17 = !(n1_285 == -9223372036854775808); if tmp17 { tmp17 = (n0_284^n1_285)&(n0_284^nr_286) >= 0 }; tmp16 = tmp17; if tmp16 { doe__4 = jrt.Long_ValueOf_J__Long_NoInit(nr_286).Ref() } else { doe__4 = lang.Numbers_Minus_O_O__Number_NoInit(na_277, na_278) } } else { var tmp18 bool; var tmp19 bool; tmp19 = jrt.Double_InstanceOf(na_277); if tmp19 { tmp19 = jrt.Double_InstanceOf(na_278) }; tmp18 = tmp19; if tmp18 { var n0_284_2 float64 = jrt.NN(jrt.Double_Cast(na_277)).DoubleValue__D(); var n1_285_2 float64 = jrt.NN(jrt.Double_Cast(na_278)).DoubleValue__D(); doe__4 = jrt.Double_ValueOf_D__Double_NoInit(n0_284_2 + -n1_285_2).Ref() } else { doe__4 = lang.Numbers_Minus_O_O__Number_NoInit(na_277, na_278) } }
//line :182:1
		var yoe__5 any; var na_287 any; var na_289 any; var na_291 any; var na_293 any = doe__4; var na_294 any
		var na_295 any = doe__4
		var na_296 int64 = 1460

		if jrt.Long_InstanceOf(na_295) { var n0_297 int64 = jrt.NN(jrt.Long_Cast(na_295)).LongValue__J(); var n1_298 int64 = na_296; if n1_298 == 0 { na_294 = lang.Numbers_Quotient_O_J__Number_NoInit(na_295, na_296) } else { na_294 = jrt.Long_ValueOf_J__Long_NoInit(n0_297 / n1_298).Ref() } } else { na_294 = lang.Numbers_Quotient_O_J__Number_NoInit(na_295, na_296) }; var tmp20 bool; var tmp21 bool; tmp21 = jrt.Long_InstanceOf(na_293); if tmp21 { tmp21 = jrt.Long_InstanceOf(na_294) }; tmp20 = tmp21; if tmp20 { var n0_300 int64 = jrt.NN(jrt.Long_Cast(na_293)).LongValue__J(); var n1_301 int64 = jrt.NN(jrt.Long_Cast(na_294)).LongValue__J(); var nr_302 int64 = n0_300 - n1_301; var tmp22 bool; var tmp23 bool; tmp23 = !(n1_301 == -9223372036854775808); if tmp23 { tmp23 = (n0_300^n1_301)&(n0_300^nr_302) >= 0 }; tmp22 = tmp23; if tmp22 { na_291 = jrt.Long_ValueOf_J__Long_NoInit(nr_302).Ref() } else { na_291 = lang.Numbers_Minus_O_O__Number_NoInit(na_293, na_294) } } else { var tmp24 bool; var tmp25 bool; tmp25 = jrt.Double_InstanceOf(na_293); if tmp25 { tmp25 = jrt.Double_InstanceOf(na_294) }; tmp24 = tmp25; if tmp24 { var n0_300_2 float64 = jrt.NN(jrt.Double_Cast(na_293)).DoubleValue__D(); var n1_301_2 float64 = jrt.NN(jrt.Double_Cast(na_294)).DoubleValue__D(); na_291 = jrt.Double_ValueOf_D__Double_NoInit(n0_300_2 + -n1_301_2).Ref() } else { na_291 = lang.Numbers_Minus_O_O__Number_NoInit(na_293, na_294) } }; var na_292 any; var na_303 any; var na_304 any = doe__4; var na_305 int64 = 36524; if jrt.Long_InstanceOf(na_304) { var n0_306 int64 = jrt.NN(jrt.Long_Cast(na_304)).LongValue__J(); var n1_307 int64 = na_305; if n1_307 == 0 { na_303 = lang.Numbers_Quotient_O_J__Number_NoInit(na_304, na_305) } else { na_303 = jrt.Long_ValueOf_J__Long_NoInit(n0_306 / n1_307).Ref() } } else { na_303 = lang.Numbers_Quotient_O_J__Number_NoInit(na_304, na_305) }; if jrt.Long_InstanceOf(na_303) { var n0_309 int64 = jrt.NN(jrt.Long_Cast(na_303)).LongValue__J(); if n0_309 == -9223372036854775808 { na_292 = lang.Numbers_Minus_O__Number_NoInit(na_303) } else { na_292 = jrt.Long_ValueOf_J__Long_NoInit(-n0_309).Ref() } } else { if jrt.Double_InstanceOf(na_303) { var n0_309_2 float64 = jrt.NN(jrt.Double_Cast(na_303)).DoubleValue__D(); na_292 = jrt.Double_ValueOf_D__Double_NoInit(-n0_309_2).Ref() } else { na_292 = lang.Numbers_Minus_O__Number_NoInit(na_303) } }; var tmp26 bool; var tmp27 bool; tmp27 = jrt.Long_InstanceOf(na_291); if tmp27 { tmp27 = jrt.Long_InstanceOf(na_292) }; tmp26 = tmp27; if tmp26 { var n0_310 int64 = jrt.NN(jrt.Long_Cast(na_291)).LongValue__J(); var n1_311 int64 = jrt.NN(jrt.Long_Cast(na_292)).LongValue__J(); var nr_312 int64 = n0_310 - n1_311; var tmp28 bool; var tmp29 bool; tmp29 = !(n1_311 == -9223372036854775808); if tmp29 { tmp29 = (n0_310^n1_311)&(n0_310^nr_312) >= 0 }; tmp28 = tmp29; if tmp28 { na_289 = jrt.Long_ValueOf_J__Long_NoInit(nr_312).Ref() } else { na_289 = lang.Numbers_Minus_O_O__Number_NoInit(na_291, na_292) } } else { var tmp30 bool; var tmp31 bool; tmp31 = jrt.Double_InstanceOf(na_291); if tmp31 { tmp31 = jrt.Double_InstanceOf(na_292) }; tmp30 = tmp31; if tmp30 { var n0_310_2 float64 = jrt.NN(jrt.Double_Cast(na_291)).DoubleValue__D(); var n1_311_2 float64 = jrt.NN(jrt.Double_Cast(na_292)).DoubleValue__D(); na_289 = jrt.Double_ValueOf_D__Double_NoInit(n0_310_2 + -n1_311_2).Ref() } else { na_289 = lang.Numbers_Minus_O_O__Number_NoInit(na_291, na_292) } }; var na_290 any; var na_313 any = doe__4; var na_314 int64 = 146096; if jrt.Long_InstanceOf(na_313) { var n0_315 int64 = jrt.NN(jrt.Long_Cast(na_313)).LongValue__J(); var n1_316 int64 = na_314; if n1_316 == 0 { na_290 = lang.Numbers_Quotient_O_J__Number_NoInit(na_313, na_314) } else { na_290 = jrt.Long_ValueOf_J__Long_NoInit(n0_315 / n1_316).Ref() } } else { na_290 = lang.Numbers_Quotient_O_J__Number_NoInit(na_313, na_314) }; var tmp32 bool; var tmp33 bool; tmp33 = jrt.Long_InstanceOf(na_289); if tmp33 { tmp33 = jrt.Long_InstanceOf(na_290) }; tmp32 = tmp33; if tmp32 { var n0_318 int64 = jrt.NN(jrt.Long_Cast(na_289)).LongValue__J(); var n1_319 int64 = jrt.NN(jrt.Long_Cast(na_290)).LongValue__J(); var nr_320 int64 = n0_318 - n1_319; var tmp34 bool; var tmp35 bool; tmp35 = !(n1_319 == -9223372036854775808); if tmp35 { tmp35 = (n0_318^n1_319)&(n0_318^nr_320) >= 0 }; tmp34 = tmp35; if tmp34 { na_287 = jrt.Long_ValueOf_J__Long_NoInit(nr_320).Ref() } else { na_287 = lang.Numbers_Minus_O_O__Number_NoInit(na_289, na_290) } } else { var tmp36 bool; var tmp37 bool; tmp37 = jrt.Double_InstanceOf(na_289); if tmp37 { tmp37 = jrt.Double_InstanceOf(na_290) }; tmp36 = tmp37; if tmp36 { var n0_318_2 float64 = jrt.NN(jrt.Double_Cast(na_289)).DoubleValue__D(); var n1_319_2 float64 = jrt.NN(jrt.Double_Cast(na_290)).DoubleValue__D(); na_287 = jrt.Double_ValueOf_D__Double_NoInit(n0_318_2 + -n1_319_2).Ref() } else { na_287 = lang.Numbers_Minus_O_O__Number_NoInit(na_289, na_290) } }; var na_288 int64 = 365; if jrt.Long_InstanceOf(na_287) { var n0_321 int64 = jrt.NN(jrt.Long_Cast(na_287)).LongValue__J(); var n1_322 int64 = na_288; if n1_322 == 0 { yoe__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_287, na_288) } else { yoe__5 = jrt.Long_ValueOf_J__Long_NoInit(n0_321 / n1_322).Ref() } } else { yoe__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_287, na_288) }
//line :182:1
		var y__6 any; var na_324 any = yoe__5; var na_325 any
		var na_326 any = era__3
		var na_327 int64 = 400


		if jrt.Long_InstanceOf(na_326) { var n0_328 int64 = jrt.NN(jrt.Long_Cast(na_326)).LongValue__J(); var n1_329 int64 = na_327; var nr_330 int64 = n0_328 * n1_329; var tmp38 bool; var tmp39 bool; var tmp40 bool; var tmp41 bool; tmp41 = n0_328 == -9223372036854775808; if tmp41 { tmp41 = n1_329 < 0 }; tmp40 = tmp41; tmp39 = !tmp40; if tmp39 { var tmp42 bool; tmp42 = n1_329 == 0; if !tmp42 { tmp42 = nr_330/n1_329 == n0_328 }; tmp39 = tmp42 }; tmp38 = tmp39; if tmp38 { na_325 = jrt.Long_ValueOf_J__Long_NoInit(nr_330).Ref() } else { na_325 = lang.Numbers_Multiply_O_J__Number_NoInit(na_326, na_327) } } else { na_325 = lang.Numbers_Multiply_O_J__Number_NoInit(na_326, na_327) }; var tmp43 bool; var tmp44 bool; tmp44 = jrt.Long_InstanceOf(na_324); if tmp44 { tmp44 = jrt.Long_InstanceOf(na_325) }; tmp43 = tmp44; if tmp43 { var n0_331 int64 = jrt.NN(jrt.Long_Cast(na_324)).LongValue__J(); var n1_332 int64 = jrt.NN(jrt.Long_Cast(na_325)).LongValue__J(); var nr_333 int64 = n0_331 + n1_332; if (n0_331^nr_333)&(n1_332^nr_333) >= 0 { y__6 = jrt.Long_ValueOf_J__Long_NoInit(nr_333).Ref() } else { y__6 = lang.Numbers_Add_O_O__Number_NoInit(na_324, na_325) } } else { var tmp45 bool; var tmp46 bool; tmp46 = jrt.Double_InstanceOf(na_324); if tmp46 { tmp46 = jrt.Double_InstanceOf(na_325) }; tmp45 = tmp46; if tmp45 { var n0_331_2 float64 = jrt.NN(jrt.Double_Cast(na_324)).DoubleValue__D(); var n1_332_2 float64 = jrt.NN(jrt.Double_Cast(na_325)).DoubleValue__D(); y__6 = jrt.Double_ValueOf_D__Double_NoInit(n0_331_2 + n1_332_2).Ref() } else { y__6 = lang.Numbers_Add_O_O__Number_NoInit(na_324, na_325) } }
//line :182:1
		var doy__7 any; var na_334 any = doe__4; var na_335 any; var na_336 any; var na_338 any
		var na_340 int64 = 365
		var na_341 any = yoe__5



		if jrt.Long_InstanceOf(na_341) { var n0_342 int64 = na_340; var n1_343 int64 = jrt.NN(jrt.Long_Cast(na_341)).LongValue__J(); var nr_344 int64 = n0_342 * n1_343; var tmp47 bool; var tmp48 bool; var tmp49 bool; var tmp50 bool; tmp50 = n0_342 == -9223372036854775808; if tmp50 { tmp50 = n1_343 < 0 }; tmp49 = tmp50; tmp48 = !tmp49; if tmp48 { var tmp51 bool; tmp51 = n1_343 == 0; if !tmp51 { tmp51 = nr_344/n1_343 == n0_342 }; tmp48 = tmp51 }; tmp47 = tmp48; if tmp47 { na_338 = jrt.Long_ValueOf_J__Long_NoInit(nr_344).Ref() } else { na_338 = lang.Numbers_Multiply_J_O__Number_NoInit(na_340, na_341) } } else { na_338 = lang.Numbers_Multiply_J_O__Number_NoInit(na_340, na_341) }; var na_339 any; var na_345 any = yoe__5; var na_346 int64 = 4; if jrt.Long_InstanceOf(na_345) { var n0_347 int64 = jrt.NN(jrt.Long_Cast(na_345)).LongValue__J(); var n1_348 int64 = na_346; if n1_348 == 0 { na_339 = lang.Numbers_Quotient_O_J__Number_NoInit(na_345, na_346) } else { na_339 = jrt.Long_ValueOf_J__Long_NoInit(n0_347 / n1_348).Ref() } } else { na_339 = lang.Numbers_Quotient_O_J__Number_NoInit(na_345, na_346) }; var tmp52 bool; var tmp53 bool; tmp53 = jrt.Long_InstanceOf(na_338); if tmp53 { tmp53 = jrt.Long_InstanceOf(na_339) }; tmp52 = tmp53; if tmp52 { var n0_350 int64 = jrt.NN(jrt.Long_Cast(na_338)).LongValue__J(); var n1_351 int64 = jrt.NN(jrt.Long_Cast(na_339)).LongValue__J(); var nr_352 int64 = n0_350 + n1_351; if (n0_350^nr_352)&(n1_351^nr_352) >= 0 { na_336 = jrt.Long_ValueOf_J__Long_NoInit(nr_352).Ref() } else { na_336 = lang.Numbers_Add_O_O__Number_NoInit(na_338, na_339) } } else { var tmp54 bool; var tmp55 bool; tmp55 = jrt.Double_InstanceOf(na_338); if tmp55 { tmp55 = jrt.Double_InstanceOf(na_339) }; tmp54 = tmp55; if tmp54 { var n0_350_2 float64 = jrt.NN(jrt.Double_Cast(na_338)).DoubleValue__D(); var n1_351_2 float64 = jrt.NN(jrt.Double_Cast(na_339)).DoubleValue__D(); na_336 = jrt.Double_ValueOf_D__Double_NoInit(n0_350_2 + n1_351_2).Ref() } else { na_336 = lang.Numbers_Add_O_O__Number_NoInit(na_338, na_339) } }; var na_337 any; var na_353 any = yoe__5; var na_354 int64 = 100; if jrt.Long_InstanceOf(na_353) { var n0_355 int64 = jrt.NN(jrt.Long_Cast(na_353)).LongValue__J(); var n1_356 int64 = na_354; if n1_356 == 0 { na_337 = lang.Numbers_Quotient_O_J__Number_NoInit(na_353, na_354) } else { na_337 = jrt.Long_ValueOf_J__Long_NoInit(n0_355 / n1_356).Ref() } } else { na_337 = lang.Numbers_Quotient_O_J__Number_NoInit(na_353, na_354) }; var tmp56 bool; var tmp57 bool; tmp57 = jrt.Long_InstanceOf(na_336); if tmp57 { tmp57 = jrt.Long_InstanceOf(na_337) }; tmp56 = tmp57; if tmp56 { var n0_358 int64 = jrt.NN(jrt.Long_Cast(na_336)).LongValue__J(); var n1_359 int64 = jrt.NN(jrt.Long_Cast(na_337)).LongValue__J(); var nr_360 int64 = n0_358 - n1_359; var tmp58 bool; var tmp59 bool; tmp59 = !(n1_359 == -9223372036854775808); if tmp59 { tmp59 = (n0_358^n1_359)&(n0_358^nr_360) >= 0 }; tmp58 = tmp59; if tmp58 { na_335 = jrt.Long_ValueOf_J__Long_NoInit(nr_360).Ref() } else { na_335 = lang.Numbers_Minus_O_O__Number_NoInit(na_336, na_337) } } else { var tmp60 bool; var tmp61 bool; tmp61 = jrt.Double_InstanceOf(na_336); if tmp61 { tmp61 = jrt.Double_InstanceOf(na_337) }; tmp60 = tmp61; if tmp60 { var n0_358_2 float64 = jrt.NN(jrt.Double_Cast(na_336)).DoubleValue__D(); var n1_359_2 float64 = jrt.NN(jrt.Double_Cast(na_337)).DoubleValue__D(); na_335 = jrt.Double_ValueOf_D__Double_NoInit(n0_358_2 + -n1_359_2).Ref() } else { na_335 = lang.Numbers_Minus_O_O__Number_NoInit(na_336, na_337) } }; var tmp62 bool; var tmp63 bool; tmp63 = jrt.Long_InstanceOf(na_334); if tmp63 { tmp63 = jrt.Long_InstanceOf(na_335) }; tmp62 = tmp63; if tmp62 { var n0_361 int64 = jrt.NN(jrt.Long_Cast(na_334)).LongValue__J(); var n1_362 int64 = jrt.NN(jrt.Long_Cast(na_335)).LongValue__J(); var nr_363 int64 = n0_361 - n1_362; var tmp64 bool; var tmp65 bool; tmp65 = !(n1_362 == -9223372036854775808); if tmp65 { tmp65 = (n0_361^n1_362)&(n0_361^nr_363) >= 0 }; tmp64 = tmp65; if tmp64 { doy__7 = jrt.Long_ValueOf_J__Long_NoInit(nr_363).Ref() } else { doy__7 = lang.Numbers_Minus_O_O__Number_NoInit(na_334, na_335) } } else { var tmp66 bool; var tmp67 bool; tmp67 = jrt.Double_InstanceOf(na_334); if tmp67 { tmp67 = jrt.Double_InstanceOf(na_335) }; tmp66 = tmp67; if tmp66 { var n0_361_2 float64 = jrt.NN(jrt.Double_Cast(na_334)).DoubleValue__D(); var n1_362_2 float64 = jrt.NN(jrt.Double_Cast(na_335)).DoubleValue__D(); doy__7 = jrt.Double_ValueOf_D__Double_NoInit(n0_361_2 + -n1_362_2).Ref() } else { doy__7 = lang.Numbers_Minus_O_O__Number_NoInit(na_334, na_335) } }
//line :182:1
		var mp__8 any; var na_364 any; var na_366 any
		var na_368 int64 = 5
		var na_369 any = doy__7




		if jrt.Long_InstanceOf(na_369) { var n0_370 int64 = na_368; var n1_371 int64 = jrt.NN(jrt.Long_Cast(na_369)).LongValue__J(); var nr_372 int64 = n0_370 * n1_371; var tmp68 bool; var tmp69 bool; var tmp70 bool; var tmp71 bool; tmp71 = n0_370 == -9223372036854775808; if tmp71 { tmp71 = n1_371 < 0 }; tmp70 = tmp71; tmp69 = !tmp70; if tmp69 { var tmp72 bool; tmp72 = n1_371 == 0; if !tmp72 { tmp72 = nr_372/n1_371 == n0_370 }; tmp69 = tmp72 }; tmp68 = tmp69; if tmp68 { na_366 = jrt.Long_ValueOf_J__Long_NoInit(nr_372).Ref() } else { na_366 = lang.Numbers_Multiply_J_O__Number_NoInit(na_368, na_369) } } else { na_366 = lang.Numbers_Multiply_J_O__Number_NoInit(na_368, na_369) }; var na_367 int64 = 2; if jrt.Long_InstanceOf(na_366) { var n0_373 int64 = jrt.NN(jrt.Long_Cast(na_366)).LongValue__J(); var n1_374 int64 = na_367; var nr_375 int64 = n0_373 + n1_374; if (n0_373^nr_375)&(n1_374^nr_375) >= 0 { na_364 = jrt.Long_ValueOf_J__Long_NoInit(nr_375).Ref() } else { na_364 = lang.Numbers_Add_O_J__Number_NoInit(na_366, na_367) } } else { na_364 = lang.Numbers_Add_O_J__Number_NoInit(na_366, na_367) }; var na_365 int64 = 153; if jrt.Long_InstanceOf(na_364) { var n0_376 int64 = jrt.NN(jrt.Long_Cast(na_364)).LongValue__J(); var n1_377 int64 = na_365; if n1_377 == 0 { mp__8 = lang.Numbers_Quotient_O_J__Number_NoInit(na_364, na_365) } else { mp__8 = jrt.Long_ValueOf_J__Long_NoInit(n0_376 / n1_377).Ref() } } else { mp__8 = lang.Numbers_Quotient_O_J__Number_NoInit(na_364, na_365) }
//line :182:1
		var d__9 any; var na_379 any; var na_380 any = doy__7; var na_381 any; var na_382 any; var na_384 any
		var na_386 int64 = 153
		var na_387 any = mp__8





		if jrt.Long_InstanceOf(na_387) { var n0_388 int64 = na_386; var n1_389 int64 = jrt.NN(jrt.Long_Cast(na_387)).LongValue__J(); var nr_390 int64 = n0_388 * n1_389; var tmp73 bool; var tmp74 bool; var tmp75 bool; var tmp76 bool; tmp76 = n0_388 == -9223372036854775808; if tmp76 { tmp76 = n1_389 < 0 }; tmp75 = tmp76; tmp74 = !tmp75; if tmp74 { var tmp77 bool; tmp77 = n1_389 == 0; if !tmp77 { tmp77 = nr_390/n1_389 == n0_388 }; tmp74 = tmp77 }; tmp73 = tmp74; if tmp73 { na_384 = jrt.Long_ValueOf_J__Long_NoInit(nr_390).Ref() } else { na_384 = lang.Numbers_Multiply_J_O__Number_NoInit(na_386, na_387) } } else { na_384 = lang.Numbers_Multiply_J_O__Number_NoInit(na_386, na_387) }; var na_385 int64 = 2; if jrt.Long_InstanceOf(na_384) { var n0_391 int64 = jrt.NN(jrt.Long_Cast(na_384)).LongValue__J(); var n1_392 int64 = na_385; var nr_393 int64 = n0_391 + n1_392; if (n0_391^nr_393)&(n1_392^nr_393) >= 0 { na_382 = jrt.Long_ValueOf_J__Long_NoInit(nr_393).Ref() } else { na_382 = lang.Numbers_Add_O_J__Number_NoInit(na_384, na_385) } } else { na_382 = lang.Numbers_Add_O_J__Number_NoInit(na_384, na_385) }; var na_383 int64 = 5; if jrt.Long_InstanceOf(na_382) { var n0_394 int64 = jrt.NN(jrt.Long_Cast(na_382)).LongValue__J(); var n1_395 int64 = na_383; if n1_395 == 0 { na_381 = lang.Numbers_Quotient_O_J__Number_NoInit(na_382, na_383) } else { na_381 = jrt.Long_ValueOf_J__Long_NoInit(n0_394 / n1_395).Ref() } } else { na_381 = lang.Numbers_Quotient_O_J__Number_NoInit(na_382, na_383) }; var tmp78 bool; var tmp79 bool; tmp79 = jrt.Long_InstanceOf(na_380); if tmp79 { tmp79 = jrt.Long_InstanceOf(na_381) }; tmp78 = tmp79; if tmp78 { var n0_397 int64 = jrt.NN(jrt.Long_Cast(na_380)).LongValue__J(); var n1_398 int64 = jrt.NN(jrt.Long_Cast(na_381)).LongValue__J(); var nr_399 int64 = n0_397 - n1_398; var tmp80 bool; var tmp81 bool; tmp81 = !(n1_398 == -9223372036854775808); if tmp81 { tmp81 = (n0_397^n1_398)&(n0_397^nr_399) >= 0 }; tmp80 = tmp81; if tmp80 { na_379 = jrt.Long_ValueOf_J__Long_NoInit(nr_399).Ref() } else { na_379 = lang.Numbers_Minus_O_O__Number_NoInit(na_380, na_381) } } else { var tmp82 bool; var tmp83 bool; tmp83 = jrt.Double_InstanceOf(na_380); if tmp83 { tmp83 = jrt.Double_InstanceOf(na_381) }; tmp82 = tmp83; if tmp82 { var n0_397_2 float64 = jrt.NN(jrt.Double_Cast(na_380)).DoubleValue__D(); var n1_398_2 float64 = jrt.NN(jrt.Double_Cast(na_381)).DoubleValue__D(); na_379 = jrt.Double_ValueOf_D__Double_NoInit(n0_397_2 + -n1_398_2).Ref() } else { na_379 = lang.Numbers_Minus_O_O__Number_NoInit(na_380, na_381) } }; if jrt.Long_InstanceOf(na_379) { var n0_400 int64 = jrt.NN(jrt.Long_Cast(na_379)).LongValue__J(); if n0_400 == 9223372036854775807 { d__9 = lang.Numbers_Inc_O__Number_NoInit(na_379) } else { d__9 = jrt.Long_ValueOf_J__Long_NoInit(n0_400 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_379) { var n0_400_2 float64 = jrt.NN(jrt.Double_Cast(na_379)).DoubleValue__D(); d__9 = jrt.Double_ValueOf_D__Double_NoInit(n0_400_2 + 1.0).Ref() } else { d__9 = lang.Numbers_Inc_O__Number_NoInit(na_379) } }
//line :182:1
		var m__10 any; var tmp84 bool
		var na_401 any = mp__8
		var na_402 int64 = 10






		if jrt.Long_InstanceOf(na_401) { var n0_403 int64 = jrt.NN(jrt.Long_Cast(na_401)).LongValue__J(); var n1_404 int64 = na_402; tmp84 = n0_403 < n1_404 } else { tmp84 = lang.Numbers_Lt_O_J__Z_NoInit(na_401, na_402) }; if tmp84 { var na_406 any = mp__8; var na_407 int64 = 3; if jrt.Long_InstanceOf(na_406) { var n0_408 int64 = jrt.NN(jrt.Long_Cast(na_406)).LongValue__J(); var n1_409 int64 = na_407; var nr_410 int64 = n0_408 + n1_409; if (n0_408^nr_410)&(n1_409^nr_410) >= 0 { m__10 = jrt.Long_ValueOf_J__Long_NoInit(nr_410).Ref() } else { m__10 = lang.Numbers_Add_O_J__Number_NoInit(na_406, na_407) } } else { m__10 = lang.Numbers_Add_O_J__Number_NoInit(na_406, na_407) } } else { var na_411 any = mp__8; var na_412 int64 = 9; if jrt.Long_InstanceOf(na_411) { var n0_413 int64 = jrt.NN(jrt.Long_Cast(na_411)).LongValue__J(); var n1_414 int64 = na_412; var nr_415 int64 = n0_413 - n1_414; var tmp85 bool; var tmp86 bool; tmp86 = !(n1_414 == -9223372036854775808); if tmp86 { tmp86 = (n0_413^n1_414)&(n0_413^nr_415) >= 0 }; tmp85 = tmp86; if tmp85 { m__10 = jrt.Long_ValueOf_J__Long_NoInit(nr_415).Ref() } else { m__10 = lang.Numbers_Minus_O_J__Number_NoInit(na_411, na_412) } } else { m__10 = lang.Numbers_Minus_O_J__Number_NoInit(na_411, na_412) } }
//line :182:1
		var tmp87 any; var tmp88 bool
		var na_456 any = m__10
		var na_457 int64 = 2







		if jrt.Long_InstanceOf(na_456) { var n0_458 int64 = jrt.NN(jrt.Long_Cast(na_456)).LongValue__J(); var n1_459 int64 = na_457; tmp88 = n0_458 <= n1_459 } else { tmp88 = lang.Numbers_Lte_O_J__Z_NoInit(na_456, na_457) }; if tmp88 { var na_461 any = y__6; if jrt.Long_InstanceOf(na_461) { var n0_462 int64 = jrt.NN(jrt.Long_Cast(na_461)).LongValue__J(); if n0_462 == 9223372036854775807 { tmp87 = lang.Numbers_Inc_O__Number_NoInit(na_461) } else { tmp87 = jrt.Long_ValueOf_J__Long_NoInit(n0_462 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_461) { var n0_462_2 float64 = jrt.NN(jrt.Double_Cast(na_461)).DoubleValue__D(); tmp87 = jrt.Double_ValueOf_D__Double_NoInit(n0_462_2 + 1.0).Ref() } else { tmp87 = lang.Numbers_Inc_O__Number_NoInit(na_461) } } } else { tmp87 = y__6 }
//line :182:1
		return lang.Tuple_Create_O_O_O__IPersistentVector(tmp87, m__10, d__9) } else { var c__2 any; var na_416 any
			var na_418 any = z__0
			var na_419 int64 = 2440588








			if jrt.Long_InstanceOf(na_418) { var n0_420 int64 = jrt.NN(jrt.Long_Cast(na_418)).LongValue__J(); var n1_421 int64 = na_419; var nr_422 int64 = n0_420 + n1_421; if (n0_420^nr_422)&(n1_421^nr_422) >= 0 { na_416 = jrt.Long_ValueOf_J__Long_NoInit(nr_422).Ref() } else { na_416 = lang.Numbers_Add_O_J__Number_NoInit(na_418, na_419) } } else { na_416 = lang.Numbers_Add_O_J__Number_NoInit(na_418, na_419) }; var na_417 int64 = 32082; if jrt.Long_InstanceOf(na_416) { var n0_423 int64 = jrt.NN(jrt.Long_Cast(na_416)).LongValue__J(); var n1_424 int64 = na_417; var nr_425 int64 = n0_423 + n1_424; if (n0_423^nr_425)&(n1_424^nr_425) >= 0 { c__2 = jrt.Long_ValueOf_J__Long_NoInit(nr_425).Ref() } else { c__2 = lang.Numbers_Add_O_J__Number_NoInit(na_416, na_417) } } else { c__2 = lang.Numbers_Add_O_J__Number_NoInit(na_416, na_417) }
//line :182:1
			var d__3 int64; var tmp89 jrt.Number_I; var na_426 any
			var na_428 int64 = 4
			var na_429 any = c__2









			if jrt.Long_InstanceOf(na_429) { var n0_430 int64 = na_428; var n1_431 int64 = jrt.NN(jrt.Long_Cast(na_429)).LongValue__J(); var nr_432 int64 = n0_430 * n1_431; var tmp90 bool; var tmp91 bool; var tmp92 bool; var tmp93 bool; tmp93 = n0_430 == -9223372036854775808; if tmp93 { tmp93 = n1_431 < 0 }; tmp92 = tmp93; tmp91 = !tmp92; if tmp91 { var tmp94 bool; tmp94 = n1_431 == 0; if !tmp94 { tmp94 = nr_432/n1_431 == n0_430 }; tmp91 = tmp94 }; tmp90 = tmp91; if tmp90 { na_426 = jrt.Long_ValueOf_J__Long_NoInit(nr_432).Ref() } else { na_426 = lang.Numbers_Multiply_J_O__Number_NoInit(na_428, na_429) } } else { na_426 = lang.Numbers_Multiply_J_O__Number_NoInit(na_428, na_429) }; var na_427 int64 = 3; if jrt.Long_InstanceOf(na_426) { var n0_433 int64 = jrt.NN(jrt.Long_Cast(na_426)).LongValue__J(); var n1_434 int64 = na_427; var nr_435 int64 = n0_433 + n1_434; if (n0_433^nr_435)&(n1_434^nr_435) >= 0 { tmp89 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_435)) } else { tmp89 = lang.Numbers_Add_O_J__Number_NoInit(na_426, na_427) } } else { tmp89 = lang.Numbers_Add_O_J__Number_NoInit(na_426, na_427) }; d__3 = jrt.Math_FloorDiv_J_J__J(lang.RT_LongCast_O__J_NoInit(tmp89), 1461)
//line :182:1
			var e__4 any; var na_436 any = c__2; var na_437 int64 = jrt.Math_FloorDiv_J_J__J(lang.RT_LongCast_J__J_NoInit(lang.Numbers_Multiply_J_J__J_NoInit(1461, d__3)), 4)












			if jrt.Long_InstanceOf(na_436) { var n0_438 int64 = jrt.NN(jrt.Long_Cast(na_436)).LongValue__J(); var n1_439 int64 = na_437; var nr_440 int64 = n0_438 - n1_439; var tmp95 bool; var tmp96 bool; tmp96 = !(n1_439 == -9223372036854775808); if tmp96 { tmp96 = (n0_438^n1_439)&(n0_438^nr_440) >= 0 }; tmp95 = tmp96; if tmp95 { e__4 = jrt.Long_ValueOf_J__Long_NoInit(nr_440).Ref() } else { e__4 = lang.Numbers_Minus_O_J__Number_NoInit(na_436, na_437) } } else { e__4 = lang.Numbers_Minus_O_J__Number_NoInit(na_436, na_437) }
//line :182:1
			var m__5 any; var na_441 any; var na_443 any
			var na_445 int64 = 5
			var na_446 any = e__4











			if jrt.Long_InstanceOf(na_446) { var n0_447 int64 = na_445; var n1_448 int64 = jrt.NN(jrt.Long_Cast(na_446)).LongValue__J(); var nr_449 int64 = n0_447 * n1_448; var tmp97 bool; var tmp98 bool; var tmp99 bool; var tmp100 bool; tmp100 = n0_447 == -9223372036854775808; if tmp100 { tmp100 = n1_448 < 0 }; tmp99 = tmp100; tmp98 = !tmp99; if tmp98 { var tmp101 bool; tmp101 = n1_448 == 0; if !tmp101 { tmp101 = nr_449/n1_448 == n0_447 }; tmp98 = tmp101 }; tmp97 = tmp98; if tmp97 { na_443 = jrt.Long_ValueOf_J__Long_NoInit(nr_449).Ref() } else { na_443 = lang.Numbers_Multiply_J_O__Number_NoInit(na_445, na_446) } } else { na_443 = lang.Numbers_Multiply_J_O__Number_NoInit(na_445, na_446) }; var na_444 int64 = 2; if jrt.Long_InstanceOf(na_443) { var n0_450 int64 = jrt.NN(jrt.Long_Cast(na_443)).LongValue__J(); var n1_451 int64 = na_444; var nr_452 int64 = n0_450 + n1_451; if (n0_450^nr_452)&(n1_451^nr_452) >= 0 { na_441 = jrt.Long_ValueOf_J__Long_NoInit(nr_452).Ref() } else { na_441 = lang.Numbers_Add_O_J__Number_NoInit(na_443, na_444) } } else { na_441 = lang.Numbers_Add_O_J__Number_NoInit(na_443, na_444) }; var na_442 int64 = 153; if jrt.Long_InstanceOf(na_441) { var n0_453 int64 = jrt.NN(jrt.Long_Cast(na_441)).LongValue__J(); var n1_454 int64 = na_442; if n1_454 == 0 { m__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_441, na_442) } else { m__5 = jrt.Long_ValueOf_J__Long_NoInit(n0_453 / n1_454).Ref() } } else { m__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_441, na_442) }
//line :182:1
			var tmp102 jrt.Number_I; var na_463 int64 = lang.Numbers_Minus_J_J__J_NoInit(d__3, 4800); var na_464 any
			var na_465 any = m__5
			var na_466 int64 = 10












			if jrt.Long_InstanceOf(na_465) { var n0_467 int64 = jrt.NN(jrt.Long_Cast(na_465)).LongValue__J(); var n1_468 int64 = na_466; if n1_468 == 0 { na_464 = lang.Numbers_Quotient_O_J__Number_NoInit(na_465, na_466) } else { na_464 = jrt.Long_ValueOf_J__Long_NoInit(n0_467 / n1_468).Ref() } } else { na_464 = lang.Numbers_Quotient_O_J__Number_NoInit(na_465, na_466) }; if jrt.Long_InstanceOf(na_464) { var n0_470 int64 = na_463; var n1_471 int64 = jrt.NN(jrt.Long_Cast(na_464)).LongValue__J(); var nr_472 int64 = n0_470 + n1_471; if (n0_470^nr_472)&(n1_471^nr_472) >= 0 { tmp102 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_472)) } else { tmp102 = lang.Numbers_Add_J_O__Number_NoInit(na_463, na_464) } } else { tmp102 = lang.Numbers_Add_J_O__Number_NoInit(na_463, na_464) }
//line :182:1
			var tmp103 any = tmp102; var tmp104 jrt.Number_I; var na_473 any
			var na_475 any = m__5
			var na_476 int64 = 3













			if jrt.Long_InstanceOf(na_475) { var n0_477 int64 = jrt.NN(jrt.Long_Cast(na_475)).LongValue__J(); var n1_478 int64 = na_476; var nr_479 int64 = n0_477 + n1_478; if (n0_477^nr_479)&(n1_478^nr_479) >= 0 { na_473 = jrt.Long_ValueOf_J__Long_NoInit(nr_479).Ref() } else { na_473 = lang.Numbers_Add_O_J__Number_NoInit(na_475, na_476) } } else { na_473 = lang.Numbers_Add_O_J__Number_NoInit(na_475, na_476) }; var na_474 any; var na_480 int64 = 12; var na_481 any; var na_482 any = m__5; var na_483 int64 = 10; if jrt.Long_InstanceOf(na_482) { var n0_484 int64 = jrt.NN(jrt.Long_Cast(na_482)).LongValue__J(); var n1_485 int64 = na_483; if n1_485 == 0 { na_481 = lang.Numbers_Quotient_O_J__Number_NoInit(na_482, na_483) } else { na_481 = jrt.Long_ValueOf_J__Long_NoInit(n0_484 / n1_485).Ref() } } else { na_481 = lang.Numbers_Quotient_O_J__Number_NoInit(na_482, na_483) }; if jrt.Long_InstanceOf(na_481) { var n0_487 int64 = na_480; var n1_488 int64 = jrt.NN(jrt.Long_Cast(na_481)).LongValue__J(); var nr_489 int64 = n0_487 * n1_488; var tmp105 bool; var tmp106 bool; var tmp107 bool; var tmp108 bool; tmp108 = n0_487 == -9223372036854775808; if tmp108 { tmp108 = n1_488 < 0 }; tmp107 = tmp108; tmp106 = !tmp107; if tmp106 { var tmp109 bool; tmp109 = n1_488 == 0; if !tmp109 { tmp109 = nr_489/n1_488 == n0_487 }; tmp106 = tmp109 }; tmp105 = tmp106; if tmp105 { na_474 = jrt.Long_ValueOf_J__Long_NoInit(nr_489).Ref() } else { na_474 = lang.Numbers_Multiply_J_O__Number_NoInit(na_480, na_481) } } else { na_474 = lang.Numbers_Multiply_J_O__Number_NoInit(na_480, na_481) }; var tmp110 bool; var tmp111 bool; tmp111 = jrt.Long_InstanceOf(na_473); if tmp111 { tmp111 = jrt.Long_InstanceOf(na_474) }; tmp110 = tmp111; if tmp110 { var n0_490 int64 = jrt.NN(jrt.Long_Cast(na_473)).LongValue__J(); var n1_491 int64 = jrt.NN(jrt.Long_Cast(na_474)).LongValue__J(); var nr_492 int64 = n0_490 - n1_491; var tmp112 bool; var tmp113 bool; tmp113 = !(n1_491 == -9223372036854775808); if tmp113 { tmp113 = (n0_490^n1_491)&(n0_490^nr_492) >= 0 }; tmp112 = tmp113; if tmp112 { tmp104 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_492)) } else { tmp104 = lang.Numbers_Minus_O_O__Number_NoInit(na_473, na_474) } } else { var tmp114 bool; var tmp115 bool; tmp115 = jrt.Double_InstanceOf(na_473); if tmp115 { tmp115 = jrt.Double_InstanceOf(na_474) }; tmp114 = tmp115; if tmp114 { var n0_490_2 float64 = jrt.NN(jrt.Double_Cast(na_473)).DoubleValue__D(); var n1_491_2 float64 = jrt.NN(jrt.Double_Cast(na_474)).DoubleValue__D(); tmp104 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_490_2 + -n1_491_2)) } else { tmp104 = lang.Numbers_Minus_O_O__Number_NoInit(na_473, na_474) } }
//line :182:1
			var tmp116 any = tmp104; var tmp117 jrt.Number_I; var na_493 any; var na_494 any = e__4; var na_495 any; var na_496 any; var na_498 any
			var na_500 int64 = 153
			var na_501 any = m__5














			if jrt.Long_InstanceOf(na_501) { var n0_502 int64 = na_500; var n1_503 int64 = jrt.NN(jrt.Long_Cast(na_501)).LongValue__J(); var nr_504 int64 = n0_502 * n1_503; var tmp118 bool; var tmp119 bool; var tmp120 bool; var tmp121 bool; tmp121 = n0_502 == -9223372036854775808; if tmp121 { tmp121 = n1_503 < 0 }; tmp120 = tmp121; tmp119 = !tmp120; if tmp119 { var tmp122 bool; tmp122 = n1_503 == 0; if !tmp122 { tmp122 = nr_504/n1_503 == n0_502 }; tmp119 = tmp122 }; tmp118 = tmp119; if tmp118 { na_498 = jrt.Long_ValueOf_J__Long_NoInit(nr_504).Ref() } else { na_498 = lang.Numbers_Multiply_J_O__Number_NoInit(na_500, na_501) } } else { na_498 = lang.Numbers_Multiply_J_O__Number_NoInit(na_500, na_501) }; var na_499 int64 = 2; if jrt.Long_InstanceOf(na_498) { var n0_505 int64 = jrt.NN(jrt.Long_Cast(na_498)).LongValue__J(); var n1_506 int64 = na_499; var nr_507 int64 = n0_505 + n1_506; if (n0_505^nr_507)&(n1_506^nr_507) >= 0 { na_496 = jrt.Long_ValueOf_J__Long_NoInit(nr_507).Ref() } else { na_496 = lang.Numbers_Add_O_J__Number_NoInit(na_498, na_499) } } else { na_496 = lang.Numbers_Add_O_J__Number_NoInit(na_498, na_499) }; var na_497 int64 = 5; if jrt.Long_InstanceOf(na_496) { var n0_508 int64 = jrt.NN(jrt.Long_Cast(na_496)).LongValue__J(); var n1_509 int64 = na_497; if n1_509 == 0 { na_495 = lang.Numbers_Quotient_O_J__Number_NoInit(na_496, na_497) } else { na_495 = jrt.Long_ValueOf_J__Long_NoInit(n0_508 / n1_509).Ref() } } else { na_495 = lang.Numbers_Quotient_O_J__Number_NoInit(na_496, na_497) }; var tmp123 bool; var tmp124 bool; tmp124 = jrt.Long_InstanceOf(na_494); if tmp124 { tmp124 = jrt.Long_InstanceOf(na_495) }; tmp123 = tmp124; if tmp123 { var n0_511 int64 = jrt.NN(jrt.Long_Cast(na_494)).LongValue__J(); var n1_512 int64 = jrt.NN(jrt.Long_Cast(na_495)).LongValue__J(); var nr_513 int64 = n0_511 - n1_512; var tmp125 bool; var tmp126 bool; tmp126 = !(n1_512 == -9223372036854775808); if tmp126 { tmp126 = (n0_511^n1_512)&(n0_511^nr_513) >= 0 }; tmp125 = tmp126; if tmp125 { na_493 = jrt.Long_ValueOf_J__Long_NoInit(nr_513).Ref() } else { na_493 = lang.Numbers_Minus_O_O__Number_NoInit(na_494, na_495) } } else { var tmp127 bool; var tmp128 bool; tmp128 = jrt.Double_InstanceOf(na_494); if tmp128 { tmp128 = jrt.Double_InstanceOf(na_495) }; tmp127 = tmp128; if tmp127 { var n0_511_2 float64 = jrt.NN(jrt.Double_Cast(na_494)).DoubleValue__D(); var n1_512_2 float64 = jrt.NN(jrt.Double_Cast(na_495)).DoubleValue__D(); na_493 = jrt.Double_ValueOf_D__Double_NoInit(n0_511_2 + -n1_512_2).Ref() } else { na_493 = lang.Numbers_Minus_O_O__Number_NoInit(na_494, na_495) } }; if jrt.Long_InstanceOf(na_493) { var n0_514 int64 = jrt.NN(jrt.Long_Cast(na_493)).LongValue__J(); if n0_514 == 9223372036854775807 { tmp117 = lang.Numbers_Inc_O__Number_NoInit(na_493) } else { tmp117 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_514 + 1)) } } else { if jrt.Double_InstanceOf(na_493) { var n0_514_2 float64 = jrt.NN(jrt.Double_Cast(na_493)).DoubleValue__D(); tmp117 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_514_2 + 1.0)) } else { tmp117 = lang.Numbers_Inc_O__Number_NoInit(na_493) } }
//line :182:1
			return lang.Tuple_Create_O_O_O__IPersistentVector(tmp103, tmp116, tmp117)
		}
}
















func A_arbace_instant_civil__GT_days_A_New() *A_arbace_instant_civil__GT_days_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_civil__GT_days_A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_instant_civil__GT_days_A) Ctor() {}
//line :201:1
func (t *A_arbace_instant_civil__GT_days_A) Invoke_O_O_O_O__O(self, y__0, m__1, d__2 any) any { var g__4 any; var y__4 any; var tmp1 bool; var na_515 any = m__1; var na_516 int64 = 2; if



	jrt.Long_InstanceOf(na_515) { var n0_517 int64 = jrt.NN(jrt.Long_Cast(na_515)).LongValue__J(); var n1_518 int64 = na_516; tmp1 = n0_517 <= n1_518 } else { tmp1 = lang.Numbers_Lte_O_J__Z_NoInit(na_515, na_516) }; if tmp1 { var na_520 any = y__0; if jrt.Long_InstanceOf(na_520) { var n0_521 int64 = jrt.NN(jrt.Long_Cast(na_520)).LongValue__J(); if n0_521 == -9223372036854775808 { y__4 = lang.Numbers_Dec_O__Number_NoInit(na_520) } else { y__4 = jrt.Long_ValueOf_J__Long_NoInit(n0_521 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_520) { var n0_521_2 float64 = jrt.NN(jrt.Double_Cast(na_520)).DoubleValue__D(); y__4 = jrt.Double_ValueOf_D__Double_NoInit(n0_521_2 - 1.0).Ref() } else { y__4 = lang.Numbers_Dec_O__Number_NoInit(na_520) } } } else { y__4 = y__0 }; var era__5 any; var na_522 any; var tmp2 bool; var na_524 any = y__4; var na_525 int64 = 0; if
	jrt.Long_InstanceOf(na_524) { var n0_526 int64 = jrt.NN(jrt.Long_Cast(na_524)).LongValue__J(); var n1_527 int64 = na_525; tmp2 = n0_526 >= n1_527 } else { tmp2 = lang.Numbers_Gte_O_J__Z_NoInit(na_524, na_525) }; if tmp2 { na_522 = y__4 } else { var na_529 any = y__4; var na_530 int64 = 399; if jrt.Long_InstanceOf(na_529) { var n0_531 int64 = jrt.NN(jrt.Long_Cast(na_529)).LongValue__J(); var n1_532 int64 = na_530; var nr_533 int64 = n0_531 - n1_532; var tmp3 bool; var tmp4 bool; tmp4 = !(n1_532 == -9223372036854775808); if tmp4 { tmp4 = (n0_531^n1_532)&(n0_531^nr_533) >= 0 }; tmp3 = tmp4; if tmp3 { na_522 = jrt.Long_ValueOf_J__Long_NoInit(nr_533).Ref() } else { na_522 = lang.Numbers_Minus_O_J__Number_NoInit(na_529, na_530) } } else { na_522 = lang.Numbers_Minus_O_J__Number_NoInit(na_529, na_530) } }; var na_523 int64 = 400; if jrt.Long_InstanceOf(na_522) { var n0_534 int64 = jrt.NN(jrt.Long_Cast(na_522)).LongValue__J(); var n1_535 int64 = na_523; if n1_535 == 0 { era__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_522, na_523) } else { era__5 = jrt.Long_ValueOf_J__Long_NoInit(n0_534 / n1_535).Ref() } } else { era__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_522, na_523) }; var yoe__6 any; var na_537 any = y__4; var na_538 any; var na_539 any = era__5; var na_540 int64 = 400; if
	jrt.Long_InstanceOf(na_539) { var n0_541 int64 = jrt.NN(jrt.Long_Cast(na_539)).LongValue__J(); var n1_542 int64 = na_540; var nr_543 int64 = n0_541 * n1_542; var tmp5 bool; var tmp6 bool; var tmp7 bool; var tmp8 bool; tmp8 = n0_541 == -9223372036854775808; if tmp8 { tmp8 = n1_542 < 0 }; tmp7 = tmp8; tmp6 = !tmp7; if tmp6 { var tmp9 bool; tmp9 = n1_542 == 0; if !tmp9 { tmp9 = nr_543/n1_542 == n0_541 }; tmp6 = tmp9 }; tmp5 = tmp6; if tmp5 { na_538 = jrt.Long_ValueOf_J__Long_NoInit(nr_543).Ref() } else { na_538 = lang.Numbers_Multiply_O_J__Number_NoInit(na_539, na_540) } } else { na_538 = lang.Numbers_Multiply_O_J__Number_NoInit(na_539, na_540) }; var tmp10 bool; var tmp11 bool; tmp11 = jrt.Long_InstanceOf(na_537); if tmp11 { tmp11 = jrt.Long_InstanceOf(na_538) }; tmp10 = tmp11; if tmp10 { var n0_544 int64 = jrt.NN(jrt.Long_Cast(na_537)).LongValue__J(); var n1_545 int64 = jrt.NN(jrt.Long_Cast(na_538)).LongValue__J(); var nr_546 int64 = n0_544 - n1_545; var tmp12 bool; var tmp13 bool; tmp13 = !(n1_545 == -9223372036854775808); if tmp13 { tmp13 = (n0_544^n1_545)&(n0_544^nr_546) >= 0 }; tmp12 = tmp13; if tmp12 { yoe__6 = jrt.Long_ValueOf_J__Long_NoInit(nr_546).Ref() } else { yoe__6 = lang.Numbers_Minus_O_O__Number_NoInit(na_537, na_538) } } else { var tmp14 bool; var tmp15 bool; tmp15 = jrt.Double_InstanceOf(na_537); if tmp15 { tmp15 = jrt.Double_InstanceOf(na_538) }; tmp14 = tmp15; if tmp14 { var n0_544_2 float64 = jrt.NN(jrt.Double_Cast(na_537)).DoubleValue__D(); var n1_545_2 float64 = jrt.NN(jrt.Double_Cast(na_538)).DoubleValue__D(); yoe__6 = jrt.Double_ValueOf_D__Double_NoInit(n0_544_2 + -n1_545_2).Ref() } else { yoe__6 = lang.Numbers_Minus_O_O__Number_NoInit(na_537, na_538) } }; var doy__7 any; var na_547 any; var na_549 any; var na_551 any; var na_553 int64 = 153; var na_554 any; var tmp16 bool; var na_555 any = m__1; var na_556 int64 = 2; if
	jrt.Long_InstanceOf(na_555) { var n0_557 int64 = jrt.NN(jrt.Long_Cast(na_555)).LongValue__J(); var n1_558 int64 = na_556; tmp16 = n0_557 > n1_558 } else { tmp16 = lang.Numbers_Gt_O_J__Z_NoInit(na_555, na_556) }; if tmp16 { var na_560 any = m__1; var na_561 int64 = 3; if jrt.Long_InstanceOf(na_560) { var n0_562 int64 = jrt.NN(jrt.Long_Cast(na_560)).LongValue__J(); var n1_563 int64 = na_561; var nr_564 int64 = n0_562 - n1_563; var tmp17 bool; var tmp18 bool; tmp18 = !(n1_563 == -9223372036854775808); if tmp18 { tmp18 = (n0_562^n1_563)&(n0_562^nr_564) >= 0 }; tmp17 = tmp18; if tmp17 { na_554 = jrt.Long_ValueOf_J__Long_NoInit(nr_564).Ref() } else { na_554 = lang.Numbers_Minus_O_J__Number_NoInit(na_560, na_561) } } else { na_554 = lang.Numbers_Minus_O_J__Number_NoInit(na_560, na_561) } } else { var na_565 any = m__1; var na_566 int64 = 9; if jrt.Long_InstanceOf(na_565) { var n0_567 int64 = jrt.NN(jrt.Long_Cast(na_565)).LongValue__J(); var n1_568 int64 = na_566; var nr_569 int64 = n0_567 + n1_568; if (n0_567^nr_569)&(n1_568^nr_569) >= 0 { na_554 = jrt.Long_ValueOf_J__Long_NoInit(nr_569).Ref() } else { na_554 = lang.Numbers_Add_O_J__Number_NoInit(na_565, na_566) } } else { na_554 = lang.Numbers_Add_O_J__Number_NoInit(na_565, na_566) } }; if jrt.Long_InstanceOf(na_554) { var n0_570 int64 = na_553; var n1_571 int64 = jrt.NN(jrt.Long_Cast(na_554)).LongValue__J(); var nr_572 int64 = n0_570 * n1_571; var tmp19 bool; var tmp20 bool; var tmp21 bool; var tmp22 bool; tmp22 = n0_570 == -9223372036854775808; if tmp22 { tmp22 = n1_571 < 0 }; tmp21 = tmp22; tmp20 = !tmp21; if tmp20 { var tmp23 bool; tmp23 = n1_571 == 0; if !tmp23 { tmp23 = nr_572/n1_571 == n0_570 }; tmp20 = tmp23 }; tmp19 = tmp20; if tmp19 { na_551 = jrt.Long_ValueOf_J__Long_NoInit(nr_572).Ref() } else { na_551 = lang.Numbers_Multiply_J_O__Number_NoInit(na_553, na_554) } } else { na_551 = lang.Numbers_Multiply_J_O__Number_NoInit(na_553, na_554) }; var na_552 int64 = 2; if jrt.Long_InstanceOf(na_551) { var n0_573 int64 = jrt.NN(jrt.Long_Cast(na_551)).LongValue__J(); var n1_574 int64 = na_552; var nr_575 int64 = n0_573 + n1_574; if (n0_573^nr_575)&(n1_574^nr_575) >= 0 { na_549 = jrt.Long_ValueOf_J__Long_NoInit(nr_575).Ref() } else { na_549 = lang.Numbers_Add_O_J__Number_NoInit(na_551, na_552) } } else { na_549 = lang.Numbers_Add_O_J__Number_NoInit(na_551, na_552) }; var na_550 int64 = 5; if jrt.Long_InstanceOf(na_549) { var n0_576 int64 = jrt.NN(jrt.Long_Cast(na_549)).LongValue__J(); var n1_577 int64 = na_550; if n1_577 == 0 { na_547 = lang.Numbers_Quotient_O_J__Number_NoInit(na_549, na_550) } else { na_547 = jrt.Long_ValueOf_J__Long_NoInit(n0_576 / n1_577).Ref() } } else { na_547 = lang.Numbers_Quotient_O_J__Number_NoInit(na_549, na_550) }; var na_548 any; var na_579 any = d__2; if jrt.Long_InstanceOf(na_579) { var n0_580 int64 = jrt.NN(jrt.Long_Cast(na_579)).LongValue__J(); if n0_580 == -9223372036854775808 { na_548 = lang.Numbers_Dec_O__Number_NoInit(na_579) } else { na_548 = jrt.Long_ValueOf_J__Long_NoInit(n0_580 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_579) { var n0_580_2 float64 = jrt.NN(jrt.Double_Cast(na_579)).DoubleValue__D(); na_548 = jrt.Double_ValueOf_D__Double_NoInit(n0_580_2 - 1.0).Ref() } else { na_548 = lang.Numbers_Dec_O__Number_NoInit(na_579) } }; var tmp24 bool; var tmp25 bool; tmp25 = jrt.Long_InstanceOf(na_547); if tmp25 { tmp25 = jrt.Long_InstanceOf(na_548) }; tmp24 = tmp25; if tmp24 { var n0_581 int64 = jrt.NN(jrt.Long_Cast(na_547)).LongValue__J(); var n1_582 int64 = jrt.NN(jrt.Long_Cast(na_548)).LongValue__J(); var nr_583 int64 = n0_581 + n1_582; if (n0_581^nr_583)&(n1_582^nr_583) >= 0 { doy__7 = jrt.Long_ValueOf_J__Long_NoInit(nr_583).Ref() } else { doy__7 = lang.Numbers_Add_O_O__Number_NoInit(na_547, na_548) } } else { var tmp26 bool; var tmp27 bool; tmp27 = jrt.Double_InstanceOf(na_547); if tmp27 { tmp27 = jrt.Double_InstanceOf(na_548) }; tmp26 = tmp27; if tmp26 { var n0_581_2 float64 = jrt.NN(jrt.Double_Cast(na_547)).DoubleValue__D(); var n1_582_2 float64 = jrt.NN(jrt.Double_Cast(na_548)).DoubleValue__D(); doy__7 = jrt.Double_ValueOf_D__Double_NoInit(n0_581_2 + n1_582_2).Ref() } else { doy__7 = lang.Numbers_Add_O_O__Number_NoInit(na_547, na_548) } }; var doe__8 any; var na_584 any; var na_586 any; var na_588 any; var na_590 any = yoe__6; var na_591 int64 = 365; if
	jrt.Long_InstanceOf(na_590) { var n0_592 int64 = jrt.NN(jrt.Long_Cast(na_590)).LongValue__J(); var n1_593 int64 = na_591; var nr_594 int64 = n0_592 * n1_593; var tmp28 bool; var tmp29 bool; var tmp30 bool; var tmp31 bool; tmp31 = n0_592 == -9223372036854775808; if tmp31 { tmp31 = n1_593 < 0 }; tmp30 = tmp31; tmp29 = !tmp30; if tmp29 { var tmp32 bool; tmp32 = n1_593 == 0; if !tmp32 { tmp32 = nr_594/n1_593 == n0_592 }; tmp29 = tmp32 }; tmp28 = tmp29; if tmp28 { na_588 = jrt.Long_ValueOf_J__Long_NoInit(nr_594).Ref() } else { na_588 = lang.Numbers_Multiply_O_J__Number_NoInit(na_590, na_591) } } else { na_588 = lang.Numbers_Multiply_O_J__Number_NoInit(na_590, na_591) }; var na_589 any; var na_595 any = yoe__6; var na_596 int64 = 4; if jrt.Long_InstanceOf(na_595) { var n0_597 int64 = jrt.NN(jrt.Long_Cast(na_595)).LongValue__J(); var n1_598 int64 = na_596; if n1_598 == 0 { na_589 = lang.Numbers_Quotient_O_J__Number_NoInit(na_595, na_596) } else { na_589 = jrt.Long_ValueOf_J__Long_NoInit(n0_597 / n1_598).Ref() } } else { na_589 = lang.Numbers_Quotient_O_J__Number_NoInit(na_595, na_596) }; var tmp33 bool; var tmp34 bool; tmp34 = jrt.Long_InstanceOf(na_588); if tmp34 { tmp34 = jrt.Long_InstanceOf(na_589) }; tmp33 = tmp34; if tmp33 { var n0_600 int64 = jrt.NN(jrt.Long_Cast(na_588)).LongValue__J(); var n1_601 int64 = jrt.NN(jrt.Long_Cast(na_589)).LongValue__J(); var nr_602 int64 = n0_600 + n1_601; if (n0_600^nr_602)&(n1_601^nr_602) >= 0 { na_586 = jrt.Long_ValueOf_J__Long_NoInit(nr_602).Ref() } else { na_586 = lang.Numbers_Add_O_O__Number_NoInit(na_588, na_589) } } else { var tmp35 bool; var tmp36 bool; tmp36 = jrt.Double_InstanceOf(na_588); if tmp36 { tmp36 = jrt.Double_InstanceOf(na_589) }; tmp35 = tmp36; if tmp35 { var n0_600_2 float64 = jrt.NN(jrt.Double_Cast(na_588)).DoubleValue__D(); var n1_601_2 float64 = jrt.NN(jrt.Double_Cast(na_589)).DoubleValue__D(); na_586 = jrt.Double_ValueOf_D__Double_NoInit(n0_600_2 + n1_601_2).Ref() } else { na_586 = lang.Numbers_Add_O_O__Number_NoInit(na_588, na_589) } }; var na_587 any = doy__7; var tmp37 bool; var tmp38 bool; tmp38 = jrt.Long_InstanceOf(na_586); if tmp38 { tmp38 = jrt.Long_InstanceOf(na_587) }; tmp37 = tmp38; if tmp37 { var n0_603 int64 = jrt.NN(jrt.Long_Cast(na_586)).LongValue__J(); var n1_604 int64 = jrt.NN(jrt.Long_Cast(na_587)).LongValue__J(); var nr_605 int64 = n0_603 + n1_604; if (n0_603^nr_605)&(n1_604^nr_605) >= 0 { na_584 = jrt.Long_ValueOf_J__Long_NoInit(nr_605).Ref() } else { na_584 = lang.Numbers_Add_O_O__Number_NoInit(na_586, na_587) } } else { var tmp39 bool; var tmp40 bool; tmp40 = jrt.Double_InstanceOf(na_586); if tmp40 { tmp40 = jrt.Double_InstanceOf(na_587) }; tmp39 = tmp40; if tmp39 { var n0_603_2 float64 = jrt.NN(jrt.Double_Cast(na_586)).DoubleValue__D(); var n1_604_2 float64 = jrt.NN(jrt.Double_Cast(na_587)).DoubleValue__D(); na_584 = jrt.Double_ValueOf_D__Double_NoInit(n0_603_2 + n1_604_2).Ref() } else { na_584 = lang.Numbers_Add_O_O__Number_NoInit(na_586, na_587) } }; var na_585 any; var na_606 any = yoe__6; var na_607 int64 = 100; if jrt.Long_InstanceOf(na_606) { var n0_608 int64 = jrt.NN(jrt.Long_Cast(na_606)).LongValue__J(); var n1_609 int64 = na_607; if n1_609 == 0 { na_585 = lang.Numbers_Quotient_O_J__Number_NoInit(na_606, na_607) } else { na_585 = jrt.Long_ValueOf_J__Long_NoInit(n0_608 / n1_609).Ref() } } else { na_585 = lang.Numbers_Quotient_O_J__Number_NoInit(na_606, na_607) }; var tmp41 bool; var tmp42 bool; tmp42 = jrt.Long_InstanceOf(na_584); if tmp42 { tmp42 = jrt.Long_InstanceOf(na_585) }; tmp41 = tmp42; if tmp41 { var n0_611 int64 = jrt.NN(jrt.Long_Cast(na_584)).LongValue__J(); var n1_612 int64 = jrt.NN(jrt.Long_Cast(na_585)).LongValue__J(); var nr_613 int64 = n0_611 - n1_612; var tmp43 bool; var tmp44 bool; tmp44 = !(n1_612 == -9223372036854775808); if tmp44 { tmp44 = (n0_611^n1_612)&(n0_611^nr_613) >= 0 }; tmp43 = tmp44; if tmp43 { doe__8 = jrt.Long_ValueOf_J__Long_NoInit(nr_613).Ref() } else { doe__8 = lang.Numbers_Minus_O_O__Number_NoInit(na_584, na_585) } } else { var tmp45 bool; var tmp46 bool; tmp46 = jrt.Double_InstanceOf(na_584); if tmp46 { tmp46 = jrt.Double_InstanceOf(na_585) }; tmp45 = tmp46; if tmp45 { var n0_611_2 float64 = jrt.NN(jrt.Double_Cast(na_584)).DoubleValue__D(); var n1_612_2 float64 = jrt.NN(jrt.Double_Cast(na_585)).DoubleValue__D(); doe__8 = jrt.Double_ValueOf_D__Double_NoInit(n0_611_2 + -n1_612_2).Ref() } else { doe__8 = lang.Numbers_Minus_O_O__Number_NoInit(na_584, na_585) } }; var na_614 any; var na_616 any; var na_618 any = era__5; var na_619 int64 = 146097; if
	jrt.Long_InstanceOf(na_618) { var n0_620 int64 = jrt.NN(jrt.Long_Cast(na_618)).LongValue__J(); var n1_621 int64 = na_619; var nr_622 int64 = n0_620 * n1_621; var tmp47 bool; var tmp48 bool; var tmp49 bool; var tmp50 bool; tmp50 = n0_620 == -9223372036854775808; if tmp50 { tmp50 = n1_621 < 0 }; tmp49 = tmp50; tmp48 = !tmp49; if tmp48 { var tmp51 bool; tmp51 = n1_621 == 0; if !tmp51 { tmp51 = nr_622/n1_621 == n0_620 }; tmp48 = tmp51 }; tmp47 = tmp48; if tmp47 { na_616 = jrt.Long_ValueOf_J__Long_NoInit(nr_622).Ref() } else { na_616 = lang.Numbers_Multiply_O_J__Number_NoInit(na_618, na_619) } } else { na_616 = lang.Numbers_Multiply_O_J__Number_NoInit(na_618, na_619) }; var na_617 any = doe__8; var tmp52 bool; var tmp53 bool; tmp53 = jrt.Long_InstanceOf(na_616); if tmp53 { tmp53 = jrt.Long_InstanceOf(na_617) }; tmp52 = tmp53; if tmp52 { var n0_623 int64 = jrt.NN(jrt.Long_Cast(na_616)).LongValue__J(); var n1_624 int64 = jrt.NN(jrt.Long_Cast(na_617)).LongValue__J(); var nr_625 int64 = n0_623 + n1_624; if (n0_623^nr_625)&(n1_624^nr_625) >= 0 { na_614 = jrt.Long_ValueOf_J__Long_NoInit(nr_625).Ref() } else { na_614 = lang.Numbers_Add_O_O__Number_NoInit(na_616, na_617) } } else { var tmp54 bool; var tmp55 bool; tmp55 = jrt.Double_InstanceOf(na_616); if tmp55 { tmp55 = jrt.Double_InstanceOf(na_617) }; tmp54 = tmp55; if tmp54 { var n0_623_2 float64 = jrt.NN(jrt.Double_Cast(na_616)).DoubleValue__D(); var n1_624_2 float64 = jrt.NN(jrt.Double_Cast(na_617)).DoubleValue__D(); na_614 = jrt.Double_ValueOf_D__Double_NoInit(n0_623_2 + n1_624_2).Ref() } else { na_614 = lang.Numbers_Add_O_O__Number_NoInit(na_616, na_617) } }; var na_615 int64 = -719468; if jrt.Long_InstanceOf(na_614) { var n0_626 int64 = jrt.NN(jrt.Long_Cast(na_614)).LongValue__J(); var n1_627 int64 = na_615; var nr_628 int64 = n0_626 + n1_627; if (n0_626^nr_628)&(n1_627^nr_628) >= 0 { g__4 = jrt.Long_ValueOf_J__Long_NoInit(nr_628).Ref() } else { g__4 = lang.Numbers_Add_O_J__Number_NoInit(na_614, na_615) } } else { g__4 = lang.Numbers_Add_O_J__Number_NoInit(na_614, na_615) }; var tmp56 bool; var na_629 any = g__4; var na_630 any =
	A_arbace_instant_A_const_43.GetRawRoot__O(); var tmp57 bool; var tmp58 bool; tmp58 = jrt.Long_InstanceOf(na_629); if tmp58 { tmp58 = jrt.Long_InstanceOf(na_630) }; tmp57 = tmp58; if tmp57 { var n0_631 int64 = jrt.NN(jrt.Long_Cast(na_629)).LongValue__J(); var n1_632 int64 = jrt.NN(jrt.Long_Cast(na_630)).LongValue__J(); tmp56 = n0_631 >= n1_632 } else { var tmp59 bool; var tmp60 bool; tmp60 = jrt.Double_InstanceOf(na_629); if tmp60 { tmp60 = jrt.Double_InstanceOf(na_630) }; tmp59 = tmp60; if tmp59 { var n0_631_2 float64 = jrt.NN(jrt.Double_Cast(na_629)).DoubleValue__D(); var n1_632_2 float64 = jrt.NN(jrt.Double_Cast(na_630)).DoubleValue__D(); tmp56 = n0_631_2 >= n1_632_2 } else { tmp56 = lang.Numbers_Gte_O_O__Z_NoInit(na_629, na_630) } }; if tmp56 { return g__4 } else { var a__5 any; var na_634 any
		var na_636 int64 = 14; var na_637 any = m__1
		if jrt.Long_InstanceOf(na_637) { var n0_638 int64 = na_636; var n1_639 int64 = jrt.NN(jrt.Long_Cast(na_637)).LongValue__J(); var nr_640 int64 = n0_638 - n1_639; var tmp61 bool; var tmp62 bool; tmp62 = !(n1_639 == -9223372036854775808); if tmp62 { tmp62 = (n0_638^n1_639)&(n0_638^nr_640) >= 0 }; tmp61 = tmp62; if tmp61 { na_634 = jrt.Long_ValueOf_J__Long_NoInit(nr_640).Ref() } else { na_634 = lang.Numbers_Minus_J_O__Number_NoInit(na_636, na_637) } } else { na_634 = lang.Numbers_Minus_J_O__Number_NoInit(na_636, na_637) }; var na_635 int64 = 12; if jrt.Long_InstanceOf(na_634) { var n0_641 int64 = jrt.NN(jrt.Long_Cast(na_634)).LongValue__J(); var n1_642 int64 = na_635; if n1_642 == 0 { a__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_634, na_635) } else { a__5 = jrt.Long_ValueOf_J__Long_NoInit(n0_641 / n1_642).Ref() } } else { a__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_634, na_635) }
//line :211:1
		var yy__6 any; var na_644 any
		var na_646 any = y__0
		var na_647 int64 = 4800
		if jrt.Long_InstanceOf(na_646) { var n0_648 int64 = jrt.NN(jrt.Long_Cast(na_646)).LongValue__J(); var n1_649 int64 = na_647; var nr_650 int64 = n0_648 + n1_649; if (n0_648^nr_650)&(n1_649^nr_650) >= 0 { na_644 = jrt.Long_ValueOf_J__Long_NoInit(nr_650).Ref() } else { na_644 = lang.Numbers_Add_O_J__Number_NoInit(na_646, na_647) } } else { na_644 = lang.Numbers_Add_O_J__Number_NoInit(na_646, na_647) }; var na_645 any = a__5; var tmp63 bool; var tmp64 bool; tmp64 = jrt.Long_InstanceOf(na_644); if tmp64 { tmp64 = jrt.Long_InstanceOf(na_645) }; tmp63 = tmp64; if tmp63 { var n0_651 int64 = jrt.NN(jrt.Long_Cast(na_644)).LongValue__J(); var n1_652 int64 = jrt.NN(jrt.Long_Cast(na_645)).LongValue__J(); var nr_653 int64 = n0_651 - n1_652; var tmp65 bool; var tmp66 bool; tmp66 = !(n1_652 == -9223372036854775808); if tmp66 { tmp66 = (n0_651^n1_652)&(n0_651^nr_653) >= 0 }; tmp65 = tmp66; if tmp65 { yy__6 = jrt.Long_ValueOf_J__Long_NoInit(nr_653).Ref() } else { yy__6 = lang.Numbers_Minus_O_O__Number_NoInit(na_644, na_645) } } else { var tmp67 bool; var tmp68 bool; tmp68 = jrt.Double_InstanceOf(na_644); if tmp68 { tmp68 = jrt.Double_InstanceOf(na_645) }; tmp67 = tmp68; if tmp67 { var n0_651_2 float64 = jrt.NN(jrt.Double_Cast(na_644)).DoubleValue__D(); var n1_652_2 float64 = jrt.NN(jrt.Double_Cast(na_645)).DoubleValue__D(); yy__6 = jrt.Double_ValueOf_D__Double_NoInit(n0_651_2 + -n1_652_2).Ref() } else { yy__6 = lang.Numbers_Minus_O_O__Number_NoInit(na_644, na_645) } }
//line :211:1
		var mm__7 any; var na_654 any; var na_656 any = m__1; var na_657 any
		var na_658 int64 = 12
		var na_659 any = a__5

		if jrt.Long_InstanceOf(na_659) { var n0_660 int64 = na_658; var n1_661 int64 = jrt.NN(jrt.Long_Cast(na_659)).LongValue__J(); var nr_662 int64 = n0_660 * n1_661; var tmp69 bool; var tmp70 bool; var tmp71 bool; var tmp72 bool; tmp72 = n0_660 == -9223372036854775808; if tmp72 { tmp72 = n1_661 < 0 }; tmp71 = tmp72; tmp70 = !tmp71; if tmp70 { var tmp73 bool; tmp73 = n1_661 == 0; if !tmp73 { tmp73 = nr_662/n1_661 == n0_660 }; tmp70 = tmp73 }; tmp69 = tmp70; if tmp69 { na_657 = jrt.Long_ValueOf_J__Long_NoInit(nr_662).Ref() } else { na_657 = lang.Numbers_Multiply_J_O__Number_NoInit(na_658, na_659) } } else { na_657 = lang.Numbers_Multiply_J_O__Number_NoInit(na_658, na_659) }; var tmp74 bool; var tmp75 bool; tmp75 = jrt.Long_InstanceOf(na_656); if tmp75 { tmp75 = jrt.Long_InstanceOf(na_657) }; tmp74 = tmp75; if tmp74 { var n0_663 int64 = jrt.NN(jrt.Long_Cast(na_656)).LongValue__J(); var n1_664 int64 = jrt.NN(jrt.Long_Cast(na_657)).LongValue__J(); var nr_665 int64 = n0_663 + n1_664; if (n0_663^nr_665)&(n1_664^nr_665) >= 0 { na_654 = jrt.Long_ValueOf_J__Long_NoInit(nr_665).Ref() } else { na_654 = lang.Numbers_Add_O_O__Number_NoInit(na_656, na_657) } } else { var tmp76 bool; var tmp77 bool; tmp77 = jrt.Double_InstanceOf(na_656); if tmp77 { tmp77 = jrt.Double_InstanceOf(na_657) }; tmp76 = tmp77; if tmp76 { var n0_663_2 float64 = jrt.NN(jrt.Double_Cast(na_656)).DoubleValue__D(); var n1_664_2 float64 = jrt.NN(jrt.Double_Cast(na_657)).DoubleValue__D(); na_654 = jrt.Double_ValueOf_D__Double_NoInit(n0_663_2 + n1_664_2).Ref() } else { na_654 = lang.Numbers_Add_O_O__Number_NoInit(na_656, na_657) } }; var na_655 int64 = 3; if jrt.Long_InstanceOf(na_654) { var n0_666 int64 = jrt.NN(jrt.Long_Cast(na_654)).LongValue__J(); var n1_667 int64 = na_655; var nr_668 int64 = n0_666 - n1_667; var tmp78 bool; var tmp79 bool; tmp79 = !(n1_667 == -9223372036854775808); if tmp79 { tmp79 = (n0_666^n1_667)&(n0_666^nr_668) >= 0 }; tmp78 = tmp79; if tmp78 { mm__7 = jrt.Long_ValueOf_J__Long_NoInit(nr_668).Ref() } else { mm__7 = lang.Numbers_Minus_O_J__Number_NoInit(na_654, na_655) } } else { mm__7 = lang.Numbers_Minus_O_J__Number_NoInit(na_654, na_655) }
		var na_669 any; var na_671 any; var na_673 any; var na_675 any; var na_677 any = d__2; var na_678 any; var na_679 any; var na_681 any; var na_683 int64 = 153; var na_684 any = mm__7; if jrt.Long_InstanceOf(na_684) { var n0_685 int64 = na_683; var n1_686 int64 = jrt.NN(jrt.Long_Cast(na_684)).LongValue__J(); var nr_687 int64 = n0_685 * n1_686; var tmp80 bool; var tmp81 bool; var tmp82 bool; var tmp83 bool; tmp83 = n0_685 == -9223372036854775808; if tmp83 { tmp83 = n1_686 < 0 }; tmp82 = tmp83; tmp81 = !tmp82; if tmp81 { var tmp84 bool; tmp84 = n1_686 == 0; if !tmp84 { tmp84 = nr_687/n1_686 == n0_685 }; tmp81 = tmp84 }; tmp80 = tmp81; if tmp80 { na_681 = jrt.Long_ValueOf_J__Long_NoInit(nr_687).Ref() } else { na_681 = lang.Numbers_Multiply_J_O__Number_NoInit(na_683, na_684) } } else { na_681 = lang.Numbers_Multiply_J_O__Number_NoInit(na_683, na_684) }; var na_682 int64 = 2; if jrt.Long_InstanceOf(na_681) { var n0_688 int64 = jrt.NN(jrt.Long_Cast(na_681)).LongValue__J(); var n1_689 int64 = na_682; var nr_690 int64 = n0_688 + n1_689; if (n0_688^nr_690)&(n1_689^nr_690) >= 0 { na_679 = jrt.Long_ValueOf_J__Long_NoInit(nr_690).Ref() } else { na_679 = lang.Numbers_Add_O_J__Number_NoInit(na_681, na_682) } } else { na_679 = lang.Numbers_Add_O_J__Number_NoInit(na_681, na_682) }; var na_680 int64 = 5; if jrt.Long_InstanceOf(na_679) { var n0_691 int64 = jrt.NN(jrt.Long_Cast(na_679)).LongValue__J(); var n1_692 int64 = na_680; if n1_692 == 0 { na_678 = lang.Numbers_Quotient_O_J__Number_NoInit(na_679, na_680) } else { na_678 = jrt.Long_ValueOf_J__Long_NoInit(n0_691 / n1_692).Ref() } } else { na_678 = lang.Numbers_Quotient_O_J__Number_NoInit(na_679, na_680) }; var tmp85 bool; var tmp86 bool; tmp86 = jrt.Long_InstanceOf(na_677); if tmp86 { tmp86 = jrt.Long_InstanceOf(na_678) }; tmp85 = tmp86; if tmp85 { var n0_694 int64 = jrt.NN(jrt.Long_Cast(na_677)).LongValue__J(); var n1_695 int64 = jrt.NN(jrt.Long_Cast(na_678)).LongValue__J(); var nr_696 int64 = n0_694 + n1_695; if (n0_694^nr_696)&(n1_695^nr_696) >= 0 { na_675 = jrt.Long_ValueOf_J__Long_NoInit(nr_696).Ref() } else { na_675 = lang.Numbers_Add_O_O__Number_NoInit(na_677, na_678) } } else { var tmp87 bool; var tmp88 bool; tmp88 = jrt.Double_InstanceOf(na_677); if tmp88 { tmp88 = jrt.Double_InstanceOf(na_678) }; tmp87 = tmp88; if tmp87 { var n0_694_2 float64 = jrt.NN(jrt.Double_Cast(na_677)).DoubleValue__D(); var n1_695_2 float64 = jrt.NN(jrt.Double_Cast(na_678)).DoubleValue__D(); na_675 = jrt.Double_ValueOf_D__Double_NoInit(n0_694_2 + n1_695_2).Ref() } else { na_675 = lang.Numbers_Add_O_O__Number_NoInit(na_677, na_678) } }; var na_676 any; var na_697 int64 = 365; var na_698 any = yy__6; if jrt.Long_InstanceOf(na_698) { var n0_699 int64 = na_697; var n1_700 int64 = jrt.NN(jrt.Long_Cast(na_698)).LongValue__J(); var nr_701 int64 = n0_699 * n1_700; var tmp89 bool; var tmp90 bool; var tmp91 bool; var tmp92 bool; tmp92 = n0_699 == -9223372036854775808; if tmp92 { tmp92 = n1_700 < 0 }; tmp91 = tmp92; tmp90 = !tmp91; if tmp90 { var tmp93 bool; tmp93 = n1_700 == 0; if !tmp93 { tmp93 = nr_701/n1_700 == n0_699 }; tmp90 = tmp93 }; tmp89 = tmp90; if tmp89 { na_676 = jrt.Long_ValueOf_J__Long_NoInit(nr_701).Ref() } else { na_676 = lang.Numbers_Multiply_J_O__Number_NoInit(na_697, na_698) } } else { na_676 = lang.Numbers_Multiply_J_O__Number_NoInit(na_697, na_698) }; var tmp94 bool; var tmp95 bool; tmp95 = jrt.Long_InstanceOf(na_675); if tmp95 { tmp95 = jrt.Long_InstanceOf(na_676) }; tmp94 = tmp95; if tmp94 { var n0_702 int64 = jrt.NN(jrt.Long_Cast(na_675)).LongValue__J(); var n1_703 int64 = jrt.NN(jrt.Long_Cast(na_676)).LongValue__J(); var nr_704 int64 = n0_702 + n1_703; if (n0_702^nr_704)&(n1_703^nr_704) >= 0 { na_673 = jrt.Long_ValueOf_J__Long_NoInit(nr_704).Ref() } else { na_673 = lang.Numbers_Add_O_O__Number_NoInit(na_675, na_676) } } else { var tmp96 bool; var tmp97 bool; tmp97 = jrt.Double_InstanceOf(na_675); if tmp97 { tmp97 = jrt.Double_InstanceOf(na_676) }; tmp96 = tmp97; if tmp96 { var n0_702_2 float64 = jrt.NN(jrt.Double_Cast(na_675)).DoubleValue__D(); var n1_703_2 float64 = jrt.NN(jrt.Double_Cast(na_676)).DoubleValue__D(); na_673 = jrt.Double_ValueOf_D__Double_NoInit(n0_702_2 + n1_703_2).Ref() } else { na_673 = lang.Numbers_Add_O_O__Number_NoInit(na_675, na_676) } }; var na_674 int64 = jrt.Math_FloorDiv_J_J__J(lang.RT_LongCast_O__J_NoInit(yy__6), 4); if jrt.Long_InstanceOf(na_673) { var n0_705 int64 = jrt.NN(jrt.Long_Cast(na_673)).LongValue__J(); var n1_706 int64 = na_674; var nr_707 int64 = n0_705 + n1_706; if (n0_705^nr_707)&(n1_706^nr_707) >= 0 { na_671 = jrt.Long_ValueOf_J__Long_NoInit(nr_707).Ref() } else { na_671 = lang.Numbers_Add_O_J__Number_NoInit(na_673, na_674) } } else { na_671 = lang.Numbers_Add_O_J__Number_NoInit(na_673, na_674) }; var na_672 int64 = -32083; if jrt.Long_InstanceOf(na_671) { var n0_708 int64 = jrt.NN(jrt.Long_Cast(na_671)).LongValue__J(); var n1_709 int64 = na_672; var nr_710 int64 = n0_708 + n1_709; if (n0_708^nr_710)&(n1_709^nr_710) >= 0 { na_669 = jrt.Long_ValueOf_J__Long_NoInit(nr_710).Ref() } else { na_669 = lang.Numbers_Add_O_J__Number_NoInit(na_671, na_672) } } else { na_669 = lang.Numbers_Add_O_J__Number_NoInit(na_671, na_672) }; var na_670 int64 = 2440588; if jrt.Long_InstanceOf(na_669) { var n0_711 int64 = jrt.NN(jrt.Long_Cast(na_669)).LongValue__J(); var n1_712 int64 = na_670; var nr_713 int64 = n0_711 - n1_712; var tmp98 bool; var tmp99 bool; tmp99 = !(n1_712 == -9223372036854775808); if tmp99 { tmp99 = (n0_711^n1_712)&(n0_711^nr_713) >= 0 }; tmp98 = tmp99; if tmp98 { return jrt.Long_ValueOf_J__Long_NoInit(nr_713).Ref() } else { return lang.Numbers_Minus_O_J__Number_NoInit(na_669, na_670) } } else { return lang.Numbers_Minus_O_J__Number_NoInit(na_669, na_670) } } }

func A_arbace_instant_print_date_A_New() *A_arbace_instant_print_date_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_print_date_A{}; t.Ctor(); return t }
//line :218:1
func (t *A_arbace_instant_print_date_A) Ctor() {}
//line :218:1
func (t *A_arbace_instant_print_date_A) Invoke_O_O_O__O(self, d__0, w__1 any) any { var ms__3 int64 = jrt.Date_Cast(d__0).GetTime__J(); var days__4 int64 = jrt.Math_FloorDiv_J_J__J(ms__3, 86400000); var msd__5 int64 = jrt.Math_FloorMod_J_J__J(ms__3, 86400000); var vec__783000040__6 any; var root_714 any = A_arbace_instant_A_const_44.GetRawRoot__O(); var linked_715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_714, A_arbace_instant_days__GT_civil_A_fn_class); var ifn_716 lang.IFn; if





	linked_715 == nil { ifn_716 = lang.IFn_Cast(root_714) } else { ifn_716 = nil }; var arg_717 any = jrt.Long_ValueOf_J__Long_NoInit(days__4).Ref(); if linked_715 == nil { vec__783000040__6 = ifn_716.Invoke_O__O(arg_717) } else { vec__783000040__6 = linked_715.(*A_arbace_instant_days__GT_civil_A).Invoke_O_O__O(root_714, arg_717) }; var y__7 any = /*line :218:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__783000040__6, lang.RT_IntCast_J__I_NoInit(0), nil); var m__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000040__6, lang.RT_IntCast_J__I_NoInit(1), nil); var dd__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000040__6, lang.RT_IntCast_J__I_NoInit(2), nil);






	jrt.Writer_Cast(w__1).Write_String__V(Lit_12); var tmp1 jrt.Writer_I =
	jrt.Writer_Cast(w__1); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_45.GetRawRoot__O()); var tmp3 any; var tmp4 bool; var na_729 any = y__7; var na_730 int64 = 0; if
	jrt.Long_InstanceOf(na_729) { var n0_731 int64 = jrt.NN(jrt.Long_Cast(na_729)).LongValue__J(); var n1_732 int64 = na_730; tmp4 = n0_731 <= n1_732 } else { tmp4 = lang.Numbers_Lte_O_J__Z_NoInit(na_729, na_730) }; if tmp4 { var na_734 int64 = 1; var na_735 any = y__7; if jrt.Long_InstanceOf(na_735) { var n0_736 int64 = na_734; var n1_737 int64 = jrt.NN(jrt.Long_Cast(na_735)).LongValue__J(); var nr_738 int64 = n0_736 - n1_737; var tmp5 bool; var tmp6 bool; tmp6 = !(n1_737 == -9223372036854775808); if tmp6 { tmp6 = (n0_736^n1_737)&(n0_736^nr_738) >= 0 }; tmp5 = tmp6; if tmp5 { tmp3 = jrt.Long_ValueOf_J__Long_NoInit(nr_738).Ref() } else { tmp3 = lang.Numbers_Minus_J_O__Number_NoInit(na_734, na_735) } } else { tmp3 = lang.Numbers_Minus_J_O__Number_NoInit(na_734, na_735) } } else { tmp3 = y__7 }; /*line :226:1*/tmp1.Write_String__V(jrt.String_Cast(tmp2.Invoke_O_O_O_O_O_O_O_O__O(Lit_15, tmp3, m__8, dd__9, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(msd__5, 3600000)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Remainder_J_J__J_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(msd__5, 60000), 60)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Remainder_J_J__J_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(msd__5, 1000), 60)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Remainder_J_J__J_NoInit(msd__5, 1000)).Ref())));


	jrt.Writer_Cast(w__1).Write_String__V(Lit_14); return nil }

func A_arbace_instant_eval783000044_fn__783000045_A_New() *A_arbace_instant_eval783000044_fn__783000045_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000044_fn__783000045_A{}; t.Ctor(); return t }
//line :231:1
func (t *A_arbace_instant_eval783000044_fn__783000045_A) Ctor() {}
//line :231:1
func (t *A_arbace_instant_eval783000044_fn__783000045_A) Invoke_O_O_O__O(self, d__1, w__2 any) any {

	var root_739 any = A_arbace_instant_A_const_46.GetRawRoot__O(); var linked_740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_739, A_arbace_instant_print_date_A_fn_class); var ifn_741 lang.IFn; if linked_740 == nil { ifn_741 = lang.IFn_Cast(root_739) } else { ifn_741 = nil }; var arg_742 any = d__1; var arg_743 any = w__2; if linked_740 == nil { return ifn_741.Invoke_O_O__O(arg_742, arg_743) } else { return linked_740.(*A_arbace_instant_print_date_A).Invoke_O_O_O__O(root_739, arg_742, arg_743)
	} }
func A_arbace_instant_eval783000048_fn__783000049_A_New() *A_arbace_instant_eval783000048_fn__783000049_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000048_fn__783000049_A{}; t.Ctor(); return t }
//line :235:1
func (t *A_arbace_instant_eval783000048_fn__783000049_A) Ctor() {}
//line :235:1
func (t *A_arbace_instant_eval783000048_fn__783000049_A) Invoke_O_O_O__O(self, d__1, w__2 any) any {

	var root_744 any = A_arbace_instant_A_const_46.GetRawRoot__O(); var linked_745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_744, A_arbace_instant_print_date_A_fn_class); var ifn_746 lang.IFn; if linked_745 == nil { ifn_746 = lang.IFn_Cast(root_744) } else { ifn_746 = nil }; var arg_747 any = d__1; var arg_748 any = w__2; if linked_745 == nil { return ifn_746.Invoke_O_O__O(arg_747, arg_748) } else { return linked_745.(*A_arbace_instant_print_date_A).Invoke_O_O_O__O(root_744, arg_747, arg_748)
	} }
func A_arbace_instant_print_calendar_A_New() *A_arbace_instant_print_calendar_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_print_calendar_A{}; t.Ctor(); return t }
//line :239:1
func (t *A_arbace_instant_print_calendar_A) Ctor() {}
//line :239:1
func (t *A_arbace_instant_print_calendar_A) Invoke_O_O_O__O(self, c__0, w__1 any) any { var calstr__3 any = lang.IFn_Cast(A_arbace_instant_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_11, c__0); var offset_minutes__4 int64 = lang.Numbers_Minus_J_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(calstr__3)).Length__I()), 2);





	jrt.Writer_Cast(w__1).Write_String__V(Lit_12);
	jrt.Writer_Cast(w__1).Write_String_I_I__V(jrt.String_Cast(calstr__3), lang.RT_IntCast_J__I_NoInit(0), lang.RT_IntCast_J__I_NoInit(offset_minutes__4));
	jrt.Writer_Cast(w__1).Write_String__V(Lit_13);
	jrt.Writer_Cast(w__1).Write_String_I_I__V(jrt.String_Cast(calstr__3), lang.RT_IntCast_J__I_NoInit(offset_minutes__4), lang.RT_IntCast_J__I_NoInit(2));
	jrt.Writer_Cast(w__1).Write_String__V(Lit_14); return nil }

func A_arbace_instant_eval783000053_fn__783000054_A_New() *A_arbace_instant_eval783000053_fn__783000054_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000053_fn__783000054_A{}; t.Ctor(); return t }
//line :251:1
func (t *A_arbace_instant_eval783000053_fn__783000054_A) Ctor() {}
//line :251:1
func (t *A_arbace_instant_eval783000053_fn__783000054_A) Invoke_O_O_O__O(self, c__1, w__2 any) any {

	var root_754 any = A_arbace_instant_A_const_47.GetRawRoot__O(); var linked_755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_754, A_arbace_instant_print_calendar_A_fn_class); var ifn_756 lang.IFn; if linked_755 == nil { ifn_756 = lang.IFn_Cast(root_754) } else { ifn_756 = nil }; var arg_757 any = c__1; var arg_758 any = w__2; if linked_755 == nil { return ifn_756.Invoke_O_O__O(arg_757, arg_758) } else { return linked_755.(*A_arbace_instant_print_calendar_A).Invoke_O_O_O__O(root_754, arg_757, arg_758)
	} }
func A_arbace_instant_eval783000057_fn__783000058_A_New() *A_arbace_instant_eval783000057_fn__783000058_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000057_fn__783000058_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_instant_eval783000057_fn__783000058_A) Ctor() {}
//line :255:1
func (t *A_arbace_instant_eval783000057_fn__783000058_A) Invoke_O_O_O__O(self, c__1, w__2 any) any {

	var root_759 any = A_arbace_instant_A_const_47.GetRawRoot__O(); var linked_760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_759, A_arbace_instant_print_calendar_A_fn_class); var ifn_761 lang.IFn; if linked_760 == nil { ifn_761 = lang.IFn_Cast(root_759) } else { ifn_761 = nil }; var arg_762 any = c__1; var arg_763 any = w__2; if linked_760 == nil { return ifn_761.Invoke_O_O__O(arg_762, arg_763) } else { return linked_760.(*A_arbace_instant_print_calendar_A).Invoke_O_O_O__O(root_759, arg_762, arg_763)
	} }
func A_arbace_instant_print_timestamp_A_New() *A_arbace_instant_print_timestamp_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_print_timestamp_A{}; t.Ctor(); return t }
//line :259:1
func (t *A_arbace_instant_print_timestamp_A) Ctor() {}
//line :259:1
func (t *A_arbace_instant_print_timestamp_A) Invoke_O_O_O__O(self, ts__0, w__1 any) any { var ms__3 int64 = jrt.NN(jrt.Timestamp_Cast(ts__0)).GetTime__J(); var days__4 int64 = jrt.Math_FloorDiv_J_J__J(ms__3, 86400000); var msd__5 int64 = jrt.Math_FloorMod_J_J__J(ms__3, 86400000); var vec__783000061__6 any; var root_764 any = A_arbace_instant_A_const_44.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_764, A_arbace_instant_days__GT_civil_A_fn_class); var ifn_766 lang.IFn; if





	linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any = jrt.Long_ValueOf_J__Long_NoInit(days__4).Ref(); if linked_765 == nil { vec__783000061__6 = ifn_766.Invoke_O__O(arg_767) } else { vec__783000061__6 = linked_765.(*A_arbace_instant_days__GT_civil_A).Invoke_O_O__O(root_764, arg_767) }; var y__7 any = /*line :259:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__783000061__6, lang.RT_IntCast_J__I_NoInit(0), nil); var m__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000061__6, lang.RT_IntCast_J__I_NoInit(1), nil); var dd__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000061__6, lang.RT_IntCast_J__I_NoInit(2), nil);






	jrt.Writer_Cast(w__1).Write_String__V(Lit_12); var tmp1 jrt.Writer_I =
	jrt.Writer_Cast(w__1); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_45.GetRawRoot__O()); var tmp3 any; var tmp4 bool; var na_778 any = y__7; var na_779 int64 = 0; if
	jrt.Long_InstanceOf(na_778) { var n0_780 int64 = jrt.NN(jrt.Long_Cast(na_778)).LongValue__J(); var n1_781 int64 = na_779; tmp4 = n0_780 <= n1_781 } else { tmp4 = lang.Numbers_Lte_O_J__Z_NoInit(na_778, na_779) }; if tmp4 { var na_783 int64 = 1; var na_784 any = y__7; if jrt.Long_InstanceOf(na_784) { var n0_785 int64 = na_783; var n1_786 int64 = jrt.NN(jrt.Long_Cast(na_784)).LongValue__J(); var nr_787 int64 = n0_785 - n1_786; var tmp5 bool; var tmp6 bool; tmp6 = !(n1_786 == -9223372036854775808); if tmp6 { tmp6 = (n0_785^n1_786)&(n0_785^nr_787) >= 0 }; tmp5 = tmp6; if tmp5 { tmp3 = jrt.Long_ValueOf_J__Long_NoInit(nr_787).Ref() } else { tmp3 = lang.Numbers_Minus_J_O__Number_NoInit(na_783, na_784) } } else { tmp3 = lang.Numbers_Minus_J_O__Number_NoInit(na_783, na_784) } } else { tmp3 = y__7 }; /*line :267:1*/tmp1.Write_String__V(jrt.String_Cast(tmp2.Invoke_O_O_O_O_O_O_O__O(Lit_16, tmp3, m__8, dd__9, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(msd__5, 3600000)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Remainder_J_J__J_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(msd__5, 60000), 60)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Remainder_J_J__J_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(msd__5, 1000), 60)).Ref())));




	jrt.Writer_Cast(w__1).Write_String__V(jrt.String_Cast(lang.IFn_Cast(A_arbace_instant_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_17, jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Timestamp_Cast(ts__0)).GetNanos__I()).Ref())));
	jrt.Writer_Cast(w__1).Write_String__V(Lit_14); return nil }

func A_arbace_instant_eval783000065_fn__783000066_A_New() *A_arbace_instant_eval783000065_fn__783000066_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000065_fn__783000066_A{}; t.Ctor(); return t }
//line :275:1
func (t *A_arbace_instant_eval783000065_fn__783000066_A) Ctor() {}
//line :275:1
func (t *A_arbace_instant_eval783000065_fn__783000066_A) Invoke_O_O_O__O(self, ts__1, w__2 any) any {

	var root_793 any = A_arbace_instant_A_const_48.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_793, A_arbace_instant_print_timestamp_A_fn_class); var ifn_795 lang.IFn; if linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = ts__1; var arg_797 any = w__2; if linked_794 == nil { return ifn_795.Invoke_O_O__O(arg_796, arg_797) } else { return linked_794.(*A_arbace_instant_print_timestamp_A).Invoke_O_O_O__O(root_793, arg_796, arg_797)
	} }
func A_arbace_instant_eval783000069_fn__783000070_A_New() *A_arbace_instant_eval783000069_fn__783000070_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000069_fn__783000070_A{}; t.Ctor(); return t }
//line :279:1
func (t *A_arbace_instant_eval783000069_fn__783000070_A) Ctor() {}
//line :279:1
func (t *A_arbace_instant_eval783000069_fn__783000070_A) Invoke_O_O_O__O(self, ts__1, w__2 any) any {

	var root_798 any = A_arbace_instant_A_const_48.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, A_arbace_instant_print_timestamp_A_fn_class); var ifn_800 lang.IFn; if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any = ts__1; var arg_802 any = w__2; if linked_799 == nil { return ifn_800.Invoke_O_O__O(arg_801, arg_802) } else { return linked_799.(*A_arbace_instant_print_timestamp_A).Invoke_O_O_O__O(root_798, arg_801, arg_802)
	}
}


func A_arbace_instant_construct_date_A_New() *A_arbace_instant_construct_date_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_construct_date_A{}; t.Ctor(); return t }
//line :286:1
func (t *A_arbace_instant_construct_date_A) Ctor() {}
//line :286:1
func (t *A_arbace_instant_construct_date_A) Invoke_O_O_O_O_O_O_O_O_O_O_O__O(self, years__0, months__1, days__2, hours__3, minutes__4, seconds__5, nanoseconds__6, offset_sign__7, offset_hours__8, offset_minutes__9 any) any { var tmp1 jrt.Number_I; var na_803 any; var na_805 any; var na_807 any; var na_809 any; var na_811 any; var na_813 any; var root_815 any = A_arbace_instant_A_const_49.GetRawRoot__O(); var linked_816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_815, A_arbace_instant_civil__GT_days_A_fn_class); var ifn_817 lang.IFn; if




	linked_816 == nil { ifn_817 = lang.IFn_Cast(root_815) } else { ifn_817 = nil }; var arg_818 any = years__0; var arg_819 any = months__1; var arg_820 any = days__2; if linked_816 == nil { na_813 = ifn_817.Invoke_O_O_O__O(arg_818, arg_819, arg_820) } else { na_813 = linked_816.(*A_arbace_instant_civil__GT_days_A).Invoke_O_O_O_O__O(root_815, arg_818, arg_819, arg_820) }; var na_814 int64 = 86400000; if jrt.Long_InstanceOf(na_813) { var n0_821 int64 = jrt.NN(jrt.Long_Cast(na_813)).LongValue__J(); var n1_822 int64 = na_814; var nr_823 int64 = n0_821 * n1_822; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 bool; tmp5 = n0_821 == -9223372036854775808; if tmp5 { tmp5 = n1_822 < 0 }; tmp4 = tmp5; tmp3 = !tmp4; if tmp3 { var tmp6 bool; tmp6 = n1_822 == 0; if !tmp6 { tmp6 = nr_823/n1_822 == n0_821 }; tmp3 = tmp6 }; tmp2 = tmp3; if tmp2 { na_811 = jrt.Long_ValueOf_J__Long_NoInit(nr_823).Ref() } else { na_811 = lang.Numbers_Multiply_O_J__Number_NoInit(na_813, na_814) } } else { na_811 = lang.Numbers_Multiply_O_J__Number_NoInit(na_813, na_814) }; var na_812 any; var na_824 any = hours__3; var na_825 int64 = 3600000; if
	jrt.Long_InstanceOf(na_824) { var n0_826 int64 = jrt.NN(jrt.Long_Cast(na_824)).LongValue__J(); var n1_827 int64 = na_825; var nr_828 int64 = n0_826 * n1_827; var tmp7 bool; var tmp8 bool; var tmp9 bool; var tmp10 bool; tmp10 = n0_826 == -9223372036854775808; if tmp10 { tmp10 = n1_827 < 0 }; tmp9 = tmp10; tmp8 = !tmp9; if tmp8 { var tmp11 bool; tmp11 = n1_827 == 0; if !tmp11 { tmp11 = nr_828/n1_827 == n0_826 }; tmp8 = tmp11 }; tmp7 = tmp8; if tmp7 { na_812 = jrt.Long_ValueOf_J__Long_NoInit(nr_828).Ref() } else { na_812 = lang.Numbers_Multiply_O_J__Number_NoInit(na_824, na_825) } } else { na_812 = lang.Numbers_Multiply_O_J__Number_NoInit(na_824, na_825) }; var tmp12 bool; var tmp13 bool; tmp13 = /*line :291:1*/jrt.Long_InstanceOf(na_811); if tmp13 { tmp13 = jrt.Long_InstanceOf(na_812) }; tmp12 = tmp13; if tmp12 { var n0_829 int64 = jrt.NN(jrt.Long_Cast(na_811)).LongValue__J(); var n1_830 int64 = jrt.NN(jrt.Long_Cast(na_812)).LongValue__J(); var nr_831 int64 = n0_829 + n1_830; if (n0_829^nr_831)&(n1_830^nr_831) >= 0 { na_809 = jrt.Long_ValueOf_J__Long_NoInit(nr_831).Ref() } else { na_809 = lang.Numbers_Add_O_O__Number_NoInit(na_811, na_812) } } else { var tmp14 bool; var tmp15 bool; tmp15 = jrt.Double_InstanceOf(na_811); if tmp15 { tmp15 = jrt.Double_InstanceOf(na_812) }; tmp14 = tmp15; if tmp14 { var n0_829_2 float64 = jrt.NN(jrt.Double_Cast(na_811)).DoubleValue__D(); var n1_830_2 float64 = jrt.NN(jrt.Double_Cast(na_812)).DoubleValue__D(); na_809 = jrt.Double_ValueOf_D__Double_NoInit(n0_829_2 + n1_830_2).Ref() } else { na_809 = lang.Numbers_Add_O_O__Number_NoInit(na_811, na_812) } }; var na_810 any; var na_832 any = minutes__4; var na_833 int64 = 60000; if
	jrt.Long_InstanceOf(na_832) { var n0_834 int64 = jrt.NN(jrt.Long_Cast(na_832)).LongValue__J(); var n1_835 int64 = na_833; var nr_836 int64 = n0_834 * n1_835; var tmp16 bool; var tmp17 bool; var tmp18 bool; var tmp19 bool; tmp19 = n0_834 == -9223372036854775808; if tmp19 { tmp19 = n1_835 < 0 }; tmp18 = tmp19; tmp17 = !tmp18; if tmp17 { var tmp20 bool; tmp20 = n1_835 == 0; if !tmp20 { tmp20 = nr_836/n1_835 == n0_834 }; tmp17 = tmp20 }; tmp16 = tmp17; if tmp16 { na_810 = jrt.Long_ValueOf_J__Long_NoInit(nr_836).Ref() } else { na_810 = lang.Numbers_Multiply_O_J__Number_NoInit(na_832, na_833) } } else { na_810 = lang.Numbers_Multiply_O_J__Number_NoInit(na_832, na_833) }; var tmp21 bool; var tmp22 bool; tmp22 = /*line :291:1*/jrt.Long_InstanceOf(na_809); if tmp22 { tmp22 = jrt.Long_InstanceOf(na_810) }; tmp21 = tmp22; if tmp21 { var n0_837 int64 = jrt.NN(jrt.Long_Cast(na_809)).LongValue__J(); var n1_838 int64 = jrt.NN(jrt.Long_Cast(na_810)).LongValue__J(); var nr_839 int64 = n0_837 + n1_838; if (n0_837^nr_839)&(n1_838^nr_839) >= 0 { na_807 = jrt.Long_ValueOf_J__Long_NoInit(nr_839).Ref() } else { na_807 = lang.Numbers_Add_O_O__Number_NoInit(na_809, na_810) } } else { var tmp23 bool; var tmp24 bool; tmp24 = jrt.Double_InstanceOf(na_809); if tmp24 { tmp24 = jrt.Double_InstanceOf(na_810) }; tmp23 = tmp24; if tmp23 { var n0_837_2 float64 = jrt.NN(jrt.Double_Cast(na_809)).DoubleValue__D(); var n1_838_2 float64 = jrt.NN(jrt.Double_Cast(na_810)).DoubleValue__D(); na_807 = jrt.Double_ValueOf_D__Double_NoInit(n0_837_2 + n1_838_2).Ref() } else { na_807 = lang.Numbers_Add_O_O__Number_NoInit(na_809, na_810) } }; var na_808 any; var na_840 any = seconds__5; var na_841 int64 = 1000; if
	jrt.Long_InstanceOf(na_840) { var n0_842 int64 = jrt.NN(jrt.Long_Cast(na_840)).LongValue__J(); var n1_843 int64 = na_841; var nr_844 int64 = n0_842 * n1_843; var tmp25 bool; var tmp26 bool; var tmp27 bool; var tmp28 bool; tmp28 = n0_842 == -9223372036854775808; if tmp28 { tmp28 = n1_843 < 0 }; tmp27 = tmp28; tmp26 = !tmp27; if tmp26 { var tmp29 bool; tmp29 = n1_843 == 0; if !tmp29 { tmp29 = nr_844/n1_843 == n0_842 }; tmp26 = tmp29 }; tmp25 = tmp26; if tmp25 { na_808 = jrt.Long_ValueOf_J__Long_NoInit(nr_844).Ref() } else { na_808 = lang.Numbers_Multiply_O_J__Number_NoInit(na_840, na_841) } } else { na_808 = lang.Numbers_Multiply_O_J__Number_NoInit(na_840, na_841) }; var tmp30 bool; var tmp31 bool; tmp31 = /*line :291:1*/jrt.Long_InstanceOf(na_807); if tmp31 { tmp31 = jrt.Long_InstanceOf(na_808) }; tmp30 = tmp31; if tmp30 { var n0_845 int64 = jrt.NN(jrt.Long_Cast(na_807)).LongValue__J(); var n1_846 int64 = jrt.NN(jrt.Long_Cast(na_808)).LongValue__J(); var nr_847 int64 = n0_845 + n1_846; if (n0_845^nr_847)&(n1_846^nr_847) >= 0 { na_805 = jrt.Long_ValueOf_J__Long_NoInit(nr_847).Ref() } else { na_805 = lang.Numbers_Add_O_O__Number_NoInit(na_807, na_808) } } else { var tmp32 bool; var tmp33 bool; tmp33 = jrt.Double_InstanceOf(na_807); if tmp33 { tmp33 = jrt.Double_InstanceOf(na_808) }; tmp32 = tmp33; if tmp32 { var n0_845_2 float64 = jrt.NN(jrt.Double_Cast(na_807)).DoubleValue__D(); var n1_846_2 float64 = jrt.NN(jrt.Double_Cast(na_808)).DoubleValue__D(); na_805 = jrt.Double_ValueOf_D__Double_NoInit(n0_845_2 + n1_846_2).Ref() } else { na_805 = lang.Numbers_Add_O_O__Number_NoInit(na_807, na_808) } }; var na_806 any; var na_848 any = nanoseconds__6; var na_849 int64 = 1000000; if

	jrt.Long_InstanceOf(na_848) { var n0_850 int64 = jrt.NN(jrt.Long_Cast(na_848)).LongValue__J(); var n1_851 int64 = na_849; if n1_851 == 0 { na_806 = lang.Numbers_Quotient_O_J__Number_NoInit(na_848, na_849) } else { na_806 = jrt.Long_ValueOf_J__Long_NoInit(n0_850 / n1_851).Ref() } } else { na_806 = lang.Numbers_Quotient_O_J__Number_NoInit(na_848, na_849) }; var tmp34 bool; var tmp35 bool; tmp35 = /*line :291:1*/jrt.Long_InstanceOf(na_805); if tmp35 { tmp35 = jrt.Long_InstanceOf(na_806) }; tmp34 = tmp35; if tmp34 { var n0_853 int64 = jrt.NN(jrt.Long_Cast(na_805)).LongValue__J(); var n1_854 int64 = jrt.NN(jrt.Long_Cast(na_806)).LongValue__J(); var nr_855 int64 = n0_853 + n1_854; if (n0_853^nr_855)&(n1_854^nr_855) >= 0 { na_803 = jrt.Long_ValueOf_J__Long_NoInit(nr_855).Ref() } else { na_803 = lang.Numbers_Add_O_O__Number_NoInit(na_805, na_806) } } else { var tmp36 bool; var tmp37 bool; tmp37 = jrt.Double_InstanceOf(na_805); if tmp37 { tmp37 = jrt.Double_InstanceOf(na_806) }; tmp36 = tmp37; if tmp36 { var n0_853_2 float64 = jrt.NN(jrt.Double_Cast(na_805)).DoubleValue__D(); var n1_854_2 float64 = jrt.NN(jrt.Double_Cast(na_806)).DoubleValue__D(); na_803 = jrt.Double_ValueOf_D__Double_NoInit(n0_853_2 + n1_854_2).Ref() } else { na_803 = lang.Numbers_Add_O_O__Number_NoInit(na_805, na_806) } }; var na_804 any; var na_856 any; var na_858 any = offset_sign__7; var na_859 any; var na_860 any; var na_862 any = offset_hours__8; var na_863 int64 = 60; if


	jrt.Long_InstanceOf(na_862) { var n0_864 int64 = jrt.NN(jrt.Long_Cast(na_862)).LongValue__J(); var n1_865 int64 = na_863; var nr_866 int64 = n0_864 * n1_865; var tmp38 bool; var tmp39 bool; var tmp40 bool; var tmp41 bool; tmp41 = n0_864 == -9223372036854775808; if tmp41 { tmp41 = n1_865 < 0 }; tmp40 = tmp41; tmp39 = !tmp40; if tmp39 { var tmp42 bool; tmp42 = n1_865 == 0; if !tmp42 { tmp42 = nr_866/n1_865 == n0_864 }; tmp39 = tmp42 }; tmp38 = tmp39; if tmp38 { na_860 = jrt.Long_ValueOf_J__Long_NoInit(nr_866).Ref() } else { na_860 = lang.Numbers_Multiply_O_J__Number_NoInit(na_862, na_863) } } else { na_860 = lang.Numbers_Multiply_O_J__Number_NoInit(na_862, na_863) }; var na_861 any = offset_minutes__9; var tmp43 bool; var tmp44 bool; tmp44 = jrt.Long_InstanceOf(na_860); if tmp44 { tmp44 = jrt.Long_InstanceOf(na_861) }; tmp43 = tmp44; if tmp43 { var n0_867 int64 = jrt.NN(jrt.Long_Cast(na_860)).LongValue__J(); var n1_868 int64 = jrt.NN(jrt.Long_Cast(na_861)).LongValue__J(); var nr_869 int64 = n0_867 + n1_868; if (n0_867^nr_869)&(n1_868^nr_869) >= 0 { na_859 = jrt.Long_ValueOf_J__Long_NoInit(nr_869).Ref() } else { na_859 = lang.Numbers_Add_O_O__Number_NoInit(na_860, na_861) } } else { var tmp45 bool; var tmp46 bool; tmp46 = jrt.Double_InstanceOf(na_860); if tmp46 { tmp46 = jrt.Double_InstanceOf(na_861) }; tmp45 = tmp46; if tmp45 { var n0_867_2 float64 = jrt.NN(jrt.Double_Cast(na_860)).DoubleValue__D(); var n1_868_2 float64 = jrt.NN(jrt.Double_Cast(na_861)).DoubleValue__D(); na_859 = jrt.Double_ValueOf_D__Double_NoInit(n0_867_2 + n1_868_2).Ref() } else { na_859 = lang.Numbers_Add_O_O__Number_NoInit(na_860, na_861) } }; var tmp47 bool; var tmp48 bool; tmp48 = jrt.Long_InstanceOf(na_858); if tmp48 { tmp48 = jrt.Long_InstanceOf(na_859) }; tmp47 = tmp48; if tmp47 { var n0_870 int64 = jrt.NN(jrt.Long_Cast(na_858)).LongValue__J(); var n1_871 int64 = jrt.NN(jrt.Long_Cast(na_859)).LongValue__J(); var nr_872 int64 = n0_870 * n1_871; var tmp49 bool; var tmp50 bool; var tmp51 bool; var tmp52 bool; tmp52 = n0_870 == -9223372036854775808; if tmp52 { tmp52 = n1_871 < 0 }; tmp51 = tmp52; tmp50 = !tmp51; if tmp50 { var tmp53 bool; tmp53 = n1_871 == 0; if !tmp53 { tmp53 = nr_872/n1_871 == n0_870 }; tmp50 = tmp53 }; tmp49 = tmp50; if tmp49 { na_856 = jrt.Long_ValueOf_J__Long_NoInit(nr_872).Ref() } else { na_856 = lang.Numbers_Multiply_O_O__Number_NoInit(na_858, na_859) } } else { var tmp54 bool; var tmp55 bool; tmp55 = jrt.Double_InstanceOf(na_858); if tmp55 { tmp55 = jrt.Double_InstanceOf(na_859) }; tmp54 = tmp55; if tmp54 { var n0_870_2 float64 = jrt.NN(jrt.Double_Cast(na_858)).DoubleValue__D(); var n1_871_2 float64 = jrt.NN(jrt.Double_Cast(na_859)).DoubleValue__D(); na_856 = jrt.Double_ValueOf_D__Double_NoInit(float64(n0_870_2 * n1_871_2)).Ref() } else { na_856 = lang.Numbers_Multiply_O_O__Number_NoInit(na_858, na_859) } }; var na_857 int64 = 60000; if jrt.Long_InstanceOf(na_856) { var n0_873 int64 = jrt.NN(jrt.Long_Cast(na_856)).LongValue__J(); var n1_874 int64 = na_857; var nr_875 int64 = n0_873 * n1_874; var tmp56 bool; var tmp57 bool; var tmp58 bool; var tmp59 bool; tmp59 = n0_873 == -9223372036854775808; if tmp59 { tmp59 = n1_874 < 0 }; tmp58 = tmp59; tmp57 = !tmp58; if tmp57 { var tmp60 bool; tmp60 = n1_874 == 0; if !tmp60 { tmp60 = nr_875/n1_874 == n0_873 }; tmp57 = tmp60 }; tmp56 = tmp57; if tmp56 { na_804 = jrt.Long_ValueOf_J__Long_NoInit(nr_875).Ref() } else { na_804 = lang.Numbers_Multiply_O_J__Number_NoInit(na_856, na_857) } } else { na_804 = lang.Numbers_Multiply_O_J__Number_NoInit(na_856, na_857) }; var tmp61 bool; var tmp62 bool; tmp62 = /*line :291:1*/jrt.Long_InstanceOf(na_803); if tmp62 { tmp62 = jrt.Long_InstanceOf(na_804) }; tmp61 = tmp62; if tmp61 { var n0_876 int64 = jrt.NN(jrt.Long_Cast(na_803)).LongValue__J(); var n1_877 int64 = jrt.NN(jrt.Long_Cast(na_804)).LongValue__J(); var nr_878 int64 = n0_876 - n1_877; var tmp63 bool; var tmp64 bool; tmp64 = !(n1_877 == -9223372036854775808); if tmp64 { tmp64 = (n0_876^n1_877)&(n0_876^nr_878) >= 0 }; tmp63 = tmp64; if tmp63 { tmp1 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_878)) } else { tmp1 = lang.Numbers_Minus_O_O__Number_NoInit(na_803, na_804) } } else { var tmp65 bool; var tmp66 bool; tmp66 = jrt.Double_InstanceOf(na_803); if tmp66 { tmp66 = jrt.Double_InstanceOf(na_804) }; tmp65 = tmp66; if tmp65 { var n0_876_2 float64 = jrt.NN(jrt.Double_Cast(na_803)).DoubleValue__D(); var n1_877_2 float64 = jrt.NN(jrt.Double_Cast(na_804)).DoubleValue__D(); tmp1 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_876_2 + -n1_877_2)) } else { tmp1 = lang.Numbers_Minus_O_O__Number_NoInit(na_803, na_804) } }; return /*line :286:1*/ jrt.Date_New_J(lang.RT_LongCast_O__J_NoInit(tmp1)) }









func A_arbace_instant_read_instant_date_A_New() *A_arbace_instant_read_instant_date_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_read_instant_date_A{}; t.Ctor(); return t }
//line :296:1
func (t *A_arbace_instant_read_instant_date_A) Ctor() {}
//line :296:1
func (t *A_arbace_instant_read_instant_date_A) Invoke_O_O__O(self, cs__0 any) any {




	var root_879 any = A_arbace_instant_A_const_50.GetRawRoot__O(); var linked_880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_879, A_arbace_instant_parse_timestamp_A_fn_class); var ifn_881 lang.IFn; if linked_880 == nil { ifn_881 = lang.IFn_Cast(root_879) } else { ifn_881 = nil }; var arg_882 any; var root_884 any = A_arbace_instant_A_const_51.GetRawRoot__O(); var linked_885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_884, A_arbace_instant_validated_A_fn_class); var ifn_886 lang.IFn; if linked_885 == nil { ifn_886 = lang.IFn_Cast(root_884) } else { ifn_886 = nil }; var arg_887 any = A_arbace_instant_A_const_52.GetRawRoot__O(); if linked_885 == nil { arg_882 = ifn_886.Invoke_O__O(arg_887) } else { arg_882 = linked_885.(*A_arbace_instant_validated_A).Invoke_O_O__O(root_884, arg_887) }; var arg_883 any = cs__0; if linked_880 == nil { return ifn_881.Invoke_O_O__O(arg_882, arg_883) } else { return linked_880.(*A_arbace_instant_parse_timestamp_A).Invoke_O_O_O__O(root_879, arg_882, arg_883)
	} }
func A_arbace_instant_construct_calendar_A_New() *A_arbace_instant_construct_calendar_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_construct_calendar_A{}; t.Ctor(); return t }
//line :303:1
func (t *A_arbace_instant_construct_calendar_A) Ctor() {}
//line :303:1
func (t *A_arbace_instant_construct_calendar_A) Invoke_O_O_O_O_O_O_O_O_O_O_O__O(self, years__0, months__1, days__2, hours__3, minutes__4, seconds__5, nanoseconds__6, offset_sign__7, offset_hours__8, offset_minutes__9 any) any { var G__783000075__11_ any; var tmp1 int32 = lang.RT_IntCast_O__I_NoInit(years__0); var tmp2 jrt.Number_I; var na_888 any = months__1; if





	jrt.Long_InstanceOf(na_888) { var n0_889 int64 = jrt.NN(jrt.Long_Cast(na_888)).LongValue__J(); if n0_889 == -9223372036854775808 { tmp2 = lang.Numbers_Dec_O__Number_NoInit(na_888) } else { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_889 - 1)) } } else { if jrt.Double_InstanceOf(na_888) { var n0_889_2 float64 = jrt.NN(jrt.Double_Cast(na_888)).DoubleValue__D(); tmp2 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_889_2 - 1.0)) } else { tmp2 = lang.Numbers_Dec_O__Number_NoInit(na_888) } }; G__783000075__11_ = /*line :303:1*/jrt.GregorianCalendar_New_I_I_I_I_I_I(tmp1, lang.RT_IntCast_O__I_NoInit(tmp2), lang.RT_IntCast_O__I_NoInit(days__2), lang.RT_IntCast_O__I_NoInit(hours__3), lang.RT_IntCast_O__I_NoInit(minutes__4), lang.RT_IntCast_O__I_NoInit(seconds__5)); var tmp3 jrt.Calendar_I =






	jrt.Calendar_Cast(G__783000075__11_); var tmp4 jrt.Number_I; var na_890 any = nanoseconds__6; var na_891 int64 = 1000000; if jrt.Long_InstanceOf(na_890) { var n0_892 int64 = jrt.NN(jrt.Long_Cast(na_890)).LongValue__J(); var n1_893 int64 = na_891; if n1_893 == 0 { tmp4 = lang.Numbers_Quotient_O_J__Number_NoInit(na_890, na_891) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_892 / n1_893)) } } else { tmp4 = lang.Numbers_Quotient_O_J__Number_NoInit(na_890, na_891) }; tmp3.Set_I_I__V(14, lang.RT_IntCast_O__I_NoInit(tmp4)); var tmp5 jrt.GregorianCalendar_I =
	jrt.GregorianCalendar_Cast(G__783000075__11_); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_45.GetRawRoot__O()); var tmp7 *jrt.String; var tmp8 bool; var na_902 any = offset_sign__7; if

	jrt.Long_InstanceOf(na_902) { var n0_903 int64 = jrt.NN(jrt.Long_Cast(na_902)).LongValue__J(); tmp8 = n0_903 < 0 } else { if jrt.Double_InstanceOf(na_902) { var n0_903_2 float64 = jrt.NN(jrt.Double_Cast(na_902)).DoubleValue__D(); tmp8 = n0_903_2 < 0.0 } else { tmp8 = lang.Numbers_IsNeg_O__Z_NoInit(na_902) } }; if tmp8 { tmp7 = Lit_2 } else { tmp7 = Lit_3 }; /*line :311:1*/tmp5.SetTimeZone_TimeZone__V(jrt.TimeZone_GetTimeZone_String__TimeZone(jrt.String_Cast(tmp6.Invoke_O_O_O_O__O(Lit_1, tmp7.Ref(), offset_hours__8, offset_minutes__9)))); return G__783000075__11_ }




func A_arbace_instant_construct_timestamp_A_New() *A_arbace_instant_construct_timestamp_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_construct_timestamp_A{}; t.Ctor(); return t }
//line :316:1
func (t *A_arbace_instant_construct_timestamp_A) Ctor() {}
//line :316:1
func (t *A_arbace_instant_construct_timestamp_A) Invoke_O_O_O_O_O_O_O_O_O_O_O__O(self, years__0, months__1, days__2, hours__3, minutes__4, seconds__5, nanoseconds__6, offset_sign__7, offset_hours__8, offset_minutes__9 any) any { var G__783000077__11_ any; var tmp1 any; var root_904 any = A_arbace_instant_A_const_53.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_904, A_arbace_instant_construct_calendar_A_fn_class); var ifn_906 lang.IFn; if





	linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any = years__0; var arg_908 any = months__1; var arg_909 any = days__2; var arg_910 any = hours__3; var arg_911 any = minutes__4; var arg_912 any = seconds__5; var arg_913 any = A_arbace_instant_A_const_25; var arg_914 any = offset_sign__7; var arg_915 any = offset_hours__8; var arg_916 any = offset_minutes__9; if linked_905 == nil { tmp1 = ifn_906.Invoke_O_O_O_O_O_O_O_O_O_O__O(arg_907, arg_908, arg_909, arg_910, arg_911, arg_912, arg_913, arg_914, arg_915, arg_916) } else { tmp1 = linked_905.(*A_arbace_instant_construct_calendar_A).Invoke_O_O_O_O_O_O_O_O_O_O_O__O(root_904, arg_907, arg_908, arg_909, arg_910, arg_911, arg_912, arg_913, arg_914, arg_915, arg_916) }; G__783000077__11_ = /*line :316:1*/jrt.Timestamp_New_J(jrt.Calendar_Cast(tmp1).GetTimeInMillis__J());









	jrt.NN(jrt.Timestamp_Cast(G__783000077__11_)).SetNanos_I__V(lang.RT_IntCast_O__I_NoInit(nanoseconds__6)); return G__783000077__11_ }

func A_arbace_instant_read_instant_calendar_A_New() *A_arbace_instant_read_instant_calendar_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_read_instant_calendar_A{}; t.Ctor(); return t }
//line :328:1
func (t *A_arbace_instant_read_instant_calendar_A) Ctor() {}
//line :328:1
func (t *A_arbace_instant_read_instant_calendar_A) Invoke_O_O__O(self, cs__0 any) any {




	var root_917 any = A_arbace_instant_A_const_50.GetRawRoot__O(); var linked_918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_917, A_arbace_instant_parse_timestamp_A_fn_class); var ifn_919 lang.IFn; if linked_918 == nil { ifn_919 = lang.IFn_Cast(root_917) } else { ifn_919 = nil }; var arg_920 any; var root_922 any = A_arbace_instant_A_const_51.GetRawRoot__O(); var linked_923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_922, A_arbace_instant_validated_A_fn_class); var ifn_924 lang.IFn; if linked_923 == nil { ifn_924 = lang.IFn_Cast(root_922) } else { ifn_924 = nil }; var arg_925 any = A_arbace_instant_A_const_53.GetRawRoot__O(); if linked_923 == nil { arg_920 = ifn_924.Invoke_O__O(arg_925) } else { arg_920 = linked_923.(*A_arbace_instant_validated_A).Invoke_O_O__O(root_922, arg_925) }; var arg_921 any = cs__0; if linked_918 == nil { return ifn_919.Invoke_O_O__O(arg_920, arg_921) } else { return linked_918.(*A_arbace_instant_parse_timestamp_A).Invoke_O_O_O__O(root_917, arg_920, arg_921)
	} }
func A_arbace_instant_read_instant_timestamp_A_New() *A_arbace_instant_read_instant_timestamp_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_read_instant_timestamp_A{}; t.Ctor(); return t }
//line :335:1
func (t *A_arbace_instant_read_instant_timestamp_A) Ctor() {}
//line :335:1
func (t *A_arbace_instant_read_instant_timestamp_A) Invoke_O_O__O(self, cs__0 any) any {





	var root_926 any = A_arbace_instant_A_const_50.GetRawRoot__O(); var linked_927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_926, A_arbace_instant_parse_timestamp_A_fn_class); var ifn_928 lang.IFn; if linked_927 == nil { ifn_928 = lang.IFn_Cast(root_926) } else { ifn_928 = nil }; var arg_929 any; var root_931 any = A_arbace_instant_A_const_51.GetRawRoot__O(); var linked_932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_931, A_arbace_instant_validated_A_fn_class); var ifn_933 lang.IFn; if linked_932 == nil { ifn_933 = lang.IFn_Cast(root_931) } else { ifn_933 = nil }; var arg_934 any = A_arbace_instant_A_const_54.GetRawRoot__O(); if linked_932 == nil { arg_929 = ifn_933.Invoke_O__O(arg_934) } else { arg_929 = linked_932.(*A_arbace_instant_validated_A).Invoke_O_O__O(root_931, arg_934) }; var arg_930 any = cs__0; if linked_927 == nil { return ifn_928.Invoke_O_O__O(arg_929, arg_930) } else { return linked_927.(*A_arbace_instant_parse_timestamp_A).Invoke_O_O_O__O(root_926, arg_929, arg_930)
	} }
type A_arbace_instant_A struct{ jrt.Object }

var A_arbace_instant_A_const_pool *jrt.RefArray

var A_arbace_instant_A_const_0 *lang.Var

var A_arbace_instant_A_const_1 any

var A_arbace_instant_A_const_2 *lang.Var

var A_arbace_instant_A_const_3 *lang.Var

var A_arbace_instant_A_const_4 *lang.Var

var A_arbace_instant_A_const_5 *lang.Var

var A_arbace_instant_A_const_6 any

var A_arbace_instant_A_const_7 *lang.Var

var A_arbace_instant_A_const_8 *lang.Var

var A_arbace_instant_A_const_9 *lang.Var

var A_arbace_instant_A_const_10 any

var A_arbace_instant_A_const_11 any

var A_arbace_instant_A_const_12 any

var A_arbace_instant_A_const_13 any

var A_arbace_instant_A_const_14 any

var A_arbace_instant_A_const_15 *lang.Var

var A_arbace_instant_A_const_16 *lang.Var

var A_arbace_instant_A_const_17 *lang.Var

var A_arbace_instant_A_const_18 *lang.Var

var A_arbace_instant_A_const_19 *lang.Keyword

var A_arbace_instant_A_const_20 any

var A_arbace_instant_A_const_21 *lang.Var

var A_arbace_instant_A_const_22 *lang.Var

var A_arbace_instant_A_const_23 *lang.Var

var A_arbace_instant_A_const_24 any

var A_arbace_instant_A_const_25 any

var A_arbace_instant_A_const_26 *lang.Var

var A_arbace_instant_A_const_27 any

var A_arbace_instant_A_const_28 any

var A_arbace_instant_A_const_29 any

var A_arbace_instant_A_const_30 *lang.Var

var A_arbace_instant_A_const_31 any

var A_arbace_instant_A_const_32 any

var A_arbace_instant_A_const_33 any

var A_arbace_instant_A_const_34 any

var A_arbace_instant_A_const_35 *lang.Var

var A_arbace_instant_A_const_36 any

var A_arbace_instant_A_const_37 *lang.Var

var A_arbace_instant_A_const_38 *lang.Var

var A_arbace_instant_A_const_39 any

var A_arbace_instant_A_const_40 any

var A_arbace_instant_A_const_41 any

var A_arbace_instant_A_const_42 any

var A_arbace_instant_A_const_43 *lang.Var

var A_arbace_instant_A_const_44 *lang.Var

var A_arbace_instant_A_const_45 *lang.Var

var A_arbace_instant_A_const_46 *lang.Var

var A_arbace_instant_A_const_47 *lang.Var

var A_arbace_instant_A_const_48 *lang.Var

var A_arbace_instant_A_const_49 *lang.Var

var A_arbace_instant_A_const_50 *lang.Var

var A_arbace_instant_A_const_51 *lang.Var

var A_arbace_instant_A_const_52 *lang.Var

var A_arbace_instant_A_const_53 *lang.Var

var A_arbace_instant_A_const_54 *lang.Var

var A_arbace_instant_A_init jrt.ClassInit

func A_arbace_instant_A_Init() { if !A_arbace_instant_A_init.Done() { A_arbace_instant_A_init.Run(A_arbace_instant_A_clinit) } }

func A_arbace_instant_A_clinit() { A_arbace_instant_A_clinit_p0(); A_arbace_instant_A_clinit_p1(); A_arbace_instant_A_clinit_p2(); A_arbace_instant_A_clinit_p3(); A_arbace_instant_A_clinit_p4() }

func A_arbace_instant_A_clinit_p0() { jrt.StartCheck(); A_arbace_instant_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 63); A_arbace_instant_A_const_0 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[8]); A_arbace_instant_A_const_1 = A_arbace_instant_A_const_pool.A[9]; A_arbace_instant_A_const_2 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[10]); A_arbace_instant_A_const_3 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[11]); A_arbace_instant_A_const_4 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[12]); A_arbace_instant_A_const_5 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[13]); A_arbace_instant_A_const_6 = A_arbace_instant_A_const_pool.A[14]; A_arbace_instant_A_const_7 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[15]); A_arbace_instant_A_const_8 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[16]); A_arbace_instant_A_const_9 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[17]); A_arbace_instant_A_const_10 = A_arbace_instant_A_const_pool.A[18]; A_arbace_instant_A_const_11 = A_arbace_instant_A_const_pool.A[19] }

func A_arbace_instant_A_clinit_p1() { A_arbace_instant_A_const_12 = A_arbace_instant_A_const_pool.A[20]; A_arbace_instant_A_const_13 = A_arbace_instant_A_const_pool.A[21]; A_arbace_instant_A_const_14 = A_arbace_instant_A_const_pool.A[22]; A_arbace_instant_A_const_15 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[23]); A_arbace_instant_A_const_16 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[24]); A_arbace_instant_A_const_17 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[25]); A_arbace_instant_A_const_18 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[26]); A_arbace_instant_A_const_19 = lang.Keyword_Cast(A_arbace_instant_A_const_pool.A[27]); A_arbace_instant_A_const_20 = A_arbace_instant_A_const_pool.A[28]; A_arbace_instant_A_const_21 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[29]); A_arbace_instant_A_const_22 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[30]); A_arbace_instant_A_const_23 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[31]); A_arbace_instant_A_const_24 = A_arbace_instant_A_const_pool.A[32] }

func A_arbace_instant_A_clinit_p2() { A_arbace_instant_A_const_25 = A_arbace_instant_A_const_pool.A[33]; A_arbace_instant_A_const_26 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[34]); A_arbace_instant_A_const_27 = A_arbace_instant_A_const_pool.A[35]; A_arbace_instant_A_const_28 = A_arbace_instant_A_const_pool.A[36]; A_arbace_instant_A_const_29 = A_arbace_instant_A_const_pool.A[37]; A_arbace_instant_A_const_30 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[38]); A_arbace_instant_A_const_31 = A_arbace_instant_A_const_pool.A[39]; A_arbace_instant_A_const_32 = A_arbace_instant_A_const_pool.A[40]; A_arbace_instant_A_const_33 = A_arbace_instant_A_const_pool.A[41]; A_arbace_instant_A_const_34 = A_arbace_instant_A_const_pool.A[42]; A_arbace_instant_A_const_35 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[43]); A_arbace_instant_A_const_36 = A_arbace_instant_A_const_pool.A[44]; A_arbace_instant_A_const_37 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[45]); A_arbace_instant_A_const_38 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[46]) }

func A_arbace_instant_A_clinit_p3() { A_arbace_instant_A_const_39 = A_arbace_instant_A_const_pool.A[47]; A_arbace_instant_A_const_40 = A_arbace_instant_A_const_pool.A[48]; A_arbace_instant_A_const_41 = A_arbace_instant_A_const_pool.A[49]; A_arbace_instant_A_const_42 = A_arbace_instant_A_const_pool.A[50]; A_arbace_instant_A_const_43 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[51]); A_arbace_instant_A_const_44 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[52]); A_arbace_instant_A_const_45 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[53]); A_arbace_instant_A_const_46 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[54]); A_arbace_instant_A_const_47 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[55]); A_arbace_instant_A_const_48 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[56]); A_arbace_instant_A_const_49 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[57]); A_arbace_instant_A_const_50 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[58]); A_arbace_instant_A_const_51 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[59]) }

func A_arbace_instant_A_clinit_p4() { A_arbace_instant_A_const_52 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[60]); A_arbace_instant_A_const_53 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[61]); A_arbace_instant_A_const_54 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[62]) }

func A_arbace_instant_A_New() *A_arbace_instant_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_A) Ctor() {}

func (t *A_arbace_instant_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_A) GetClass__Class() *jrt.Class { return A_arbace_instant_A_class }

func (t *A_arbace_instant_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_A); return ok }

func A_arbace_instant_A_Cast(x any) *A_arbace_instant_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_A_class)) }; return v }



type A_arbace_instant_civil__GT_days_A struct{ j2g_header uint64 }

var A_arbace_instant_civil__GT_days_A_fn_class *jrt.Class



type A_arbace_instant_construct_calendar_A struct{ j2g_header uint64 }

var A_arbace_instant_construct_calendar_A_fn_class *jrt.Class



type A_arbace_instant_construct_date_A struct{ j2g_header uint64 }

var A_arbace_instant_construct_date_A_fn_class *jrt.Class



type A_arbace_instant_construct_timestamp_A struct{ j2g_header uint64 }

var A_arbace_instant_construct_timestamp_A_fn_class *jrt.Class



type A_arbace_instant_days__GT_civil_A struct{ j2g_header uint64 }

var A_arbace_instant_days__GT_civil_A_fn_class *jrt.Class



type A_arbace_instant_divisible_QMARK__A struct{ j2g_header uint64 }

var A_arbace_instant_divisible_QMARK__A_fn_class *jrt.Class



type A_arbace_instant_eval783000002_A struct{ jrt.Object }

func A_arbace_instant_eval783000002_A_New() *A_arbace_instant_eval783000002_A { t := &A_arbace_instant_eval783000002_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000002_A) Ctor() {}

func (t *A_arbace_instant_eval783000002_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000002_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000002_A_class }

func (t *A_arbace_instant_eval783000002_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000002_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000002_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000002_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000002_A); return ok }

func A_arbace_instant_eval783000002_A_Cast(x any) *A_arbace_instant_eval783000002_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000002_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000002_A_class)) }; return v }



type A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_fn_class *jrt.Class



type A_arbace_instant_eval783000006_A struct{ jrt.Object }

func A_arbace_instant_eval783000006_A_New() *A_arbace_instant_eval783000006_A { t := &A_arbace_instant_eval783000006_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000006_A) Ctor() {}

func (t *A_arbace_instant_eval783000006_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000006_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000006_A_class }

func (t *A_arbace_instant_eval783000006_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000006_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000006_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000006_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000006_A); return ok }

func A_arbace_instant_eval783000006_A_Cast(x any) *A_arbace_instant_eval783000006_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000006_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000006_A_class)) }; return v }



type A_arbace_instant_eval783000006_fn__783000007_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000006_fn__783000007_A_fn_class *jrt.Class



type A_arbace_instant_eval783000044_A struct{ jrt.Object }

func A_arbace_instant_eval783000044_A_New() *A_arbace_instant_eval783000044_A { t := &A_arbace_instant_eval783000044_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000044_A) Ctor() {}

func (t *A_arbace_instant_eval783000044_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000044_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000044_A_class }

func (t *A_arbace_instant_eval783000044_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000044_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000044_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000044_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000044_A); return ok }

func A_arbace_instant_eval783000044_A_Cast(x any) *A_arbace_instant_eval783000044_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000044_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000044_A_class)) }; return v }



type A_arbace_instant_eval783000044_fn__783000045_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000044_fn__783000045_A_fn_class *jrt.Class



type A_arbace_instant_eval783000048_A struct{ jrt.Object }

func A_arbace_instant_eval783000048_A_New() *A_arbace_instant_eval783000048_A { t := &A_arbace_instant_eval783000048_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000048_A) Ctor() {}

func (t *A_arbace_instant_eval783000048_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000048_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000048_A_class }

func (t *A_arbace_instant_eval783000048_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000048_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000048_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000048_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000048_A); return ok }

func A_arbace_instant_eval783000048_A_Cast(x any) *A_arbace_instant_eval783000048_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000048_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000048_A_class)) }; return v }



type A_arbace_instant_eval783000048_fn__783000049_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000048_fn__783000049_A_fn_class *jrt.Class



type A_arbace_instant_eval783000053_A struct{ jrt.Object }

func A_arbace_instant_eval783000053_A_New() *A_arbace_instant_eval783000053_A { t := &A_arbace_instant_eval783000053_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000053_A) Ctor() {}

func (t *A_arbace_instant_eval783000053_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000053_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000053_A_class }

func (t *A_arbace_instant_eval783000053_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000053_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000053_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000053_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000053_A); return ok }

func A_arbace_instant_eval783000053_A_Cast(x any) *A_arbace_instant_eval783000053_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000053_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000053_A_class)) }; return v }



type A_arbace_instant_eval783000053_fn__783000054_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000053_fn__783000054_A_fn_class *jrt.Class



type A_arbace_instant_eval783000057_A struct{ jrt.Object }

func A_arbace_instant_eval783000057_A_New() *A_arbace_instant_eval783000057_A { t := &A_arbace_instant_eval783000057_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000057_A) Ctor() {}

func (t *A_arbace_instant_eval783000057_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000057_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000057_A_class }

func (t *A_arbace_instant_eval783000057_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000057_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000057_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000057_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000057_A); return ok }

func A_arbace_instant_eval783000057_A_Cast(x any) *A_arbace_instant_eval783000057_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000057_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000057_A_class)) }; return v }



type A_arbace_instant_eval783000057_fn__783000058_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000057_fn__783000058_A_fn_class *jrt.Class



type A_arbace_instant_eval783000065_A struct{ jrt.Object }

func A_arbace_instant_eval783000065_A_New() *A_arbace_instant_eval783000065_A { t := &A_arbace_instant_eval783000065_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000065_A) Ctor() {}

func (t *A_arbace_instant_eval783000065_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000065_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000065_A_class }

func (t *A_arbace_instant_eval783000065_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000065_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000065_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000065_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000065_A); return ok }

func A_arbace_instant_eval783000065_A_Cast(x any) *A_arbace_instant_eval783000065_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000065_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000065_A_class)) }; return v }



type A_arbace_instant_eval783000065_fn__783000066_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000065_fn__783000066_A_fn_class *jrt.Class



type A_arbace_instant_eval783000069_A struct{ jrt.Object }

func A_arbace_instant_eval783000069_A_New() *A_arbace_instant_eval783000069_A { t := &A_arbace_instant_eval783000069_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000069_A) Ctor() {}

func (t *A_arbace_instant_eval783000069_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000069_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000069_A_class }

func (t *A_arbace_instant_eval783000069_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000069_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000069_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000069_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000069_A); return ok }

func A_arbace_instant_eval783000069_A_Cast(x any) *A_arbace_instant_eval783000069_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000069_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000069_A_class)) }; return v }



type A_arbace_instant_eval783000069_fn__783000070_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000069_fn__783000070_A_fn_class *jrt.Class



type A_arbace_instant_fail_A struct{ j2g_header uint64 }

var A_arbace_instant_fail_A_fn_class *jrt.Class



type A_arbace_instant_fn__783000031_A struct{ j2g_header uint64 }

var A_arbace_instant_fn__783000031_A_fn_class *jrt.Class



type A_arbace_instant_fn__783000031_fn__783000032_A struct{ j2g_header uint64; F_dim_norm, F_dim_leap any }

var A_arbace_instant_fn__783000031_fn__783000032_A_fn_class *jrt.Class



type A_arbace_instant_indivisible_QMARK__A struct{ j2g_header uint64 }

var A_arbace_instant_indivisible_QMARK__A_fn_class *jrt.Class



type A_arbace_instant_leap_year_QMARK__A struct{ j2g_header uint64 }

var A_arbace_instant_leap_year_QMARK__A_fn_class *jrt.Class



type A_arbace_instant_parse_int_A struct{ j2g_header uint64 }

var A_arbace_instant_parse_int_A_fn_class *jrt.Class



type A_arbace_instant_parse_timestamp_A struct{ j2g_header uint64 }

var A_arbace_instant_parse_timestamp_A_fn_class *jrt.Class



type A_arbace_instant_print_calendar_A struct{ j2g_header uint64 }

var A_arbace_instant_print_calendar_A_fn_class *jrt.Class



type A_arbace_instant_print_date_A struct{ j2g_header uint64 }

var A_arbace_instant_print_date_A_fn_class *jrt.Class



type A_arbace_instant_print_timestamp_A struct{ j2g_header uint64 }

var A_arbace_instant_print_timestamp_A_fn_class *jrt.Class



type A_arbace_instant_read_instant_calendar_A struct{ j2g_header uint64 }

var A_arbace_instant_read_instant_calendar_A_fn_class *jrt.Class



type A_arbace_instant_read_instant_date_A struct{ j2g_header uint64 }

var A_arbace_instant_read_instant_date_A_fn_class *jrt.Class



type A_arbace_instant_read_instant_timestamp_A struct{ j2g_header uint64 }

var A_arbace_instant_read_instant_timestamp_A_fn_class *jrt.Class



type A_arbace_instant_validated_A struct{ j2g_header uint64 }

var A_arbace_instant_validated_A_fn_class *jrt.Class



type A_arbace_instant_validated_fn__783000035_A struct{ j2g_header uint64; F_new_instance any }

var A_arbace_instant_validated_fn__783000035_A_fn_class *jrt.Class



type A_arbace_instant_verify_A struct{ j2g_header uint64 }

var A_arbace_instant_verify_A_fn_class *jrt.Class



type A_arbace_instant_zero_fill_right_A struct{ j2g_header uint64 }

var A_arbace_instant_zero_fill_right_A_fn_class *jrt.Class
