//line aot_arbace_instant.ae:1
package aot_arbace_instant

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)













func A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_New() *A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A) Ctor() {}
//line :21:1
func (t *A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_instant_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_1); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_4)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_5)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_6)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_7)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_8)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :21:1
func A_arbace_instant_eval783000006_fn__783000007_A_New() *A_arbace_instant_eval783000006_fn__783000007_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000006_fn__783000007_A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_instant_eval783000006_fn__783000007_A) Ctor() {}
//line :21:1
func (t *A_arbace_instant_eval783000006_fn__783000007_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_2.GetRawRoot__O()); var tmp2 any; var root_11 any = A_arbace_instant_A_const_3.GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_11, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = A_arbace_instant_A_const_4; if linked_12 == nil { tmp2 = ifn_13.Invoke_O__O(arg_14) } else { tmp2 = linked_12.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_11, arg_14) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_instant_A_const_5.GetRawRoot__O(), A_arbace_instant_A_const_6) }








func A_arbace_instant_fail_A_New() *A_arbace_instant_fail_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_fail_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_instant_fail_A) Ctor() {}
//line :30:1
func (t *A_arbace_instant_fail_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, msg__2 any) any { var root_15 any = A_arbace_instant_A_const_7.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any; var root_19 any = A_arbace_instant_A_const_8.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_10); var arg_23 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()); var tmp2 any; var root_24 any = A_arbace_instant_A_const_7.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any; var root_28 any = A_arbace_instant_A_const_8.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_30 lang.IFn; if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_11); var arg_32 any = lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(msg__2); if linked_29 == nil { arg_27 = ifn_30.Invoke_O_O__O(arg_31, arg_32) } else { arg_27 = linked_29.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_28, arg_31, arg_32) }; if linked_25 == nil { tmp2 = ifn_26.Invoke_O__O(arg_27) } else { tmp2 = linked_25.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_24, arg_27) }; arg_23 = tmp1.Invoke_O__O(tmp2); if linked_20 == nil { arg_18 = ifn_21.Invoke_O_O__O(arg_22, arg_23) } else { arg_18 = linked_20.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_19, arg_22, arg_23) }; if linked_16 == nil { return ifn_17.Invoke_O__O(arg_18) } else { return linked_16.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_15, arg_18) } }



func A_arbace_instant_verify_A_New() *A_arbace_instant_verify_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_verify_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_instant_verify_A) Ctor() {}
//line :34:1
func (t *A_arbace_instant_verify_A) Invoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, test__2, msg__3 any) any { var root_33 any = A_arbace_instant_A_const_7.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_33, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_35 lang.IFn; if linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_8.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_12); var tmp3 any = lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(test__2); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()); var tmp5 any; var root_43 any = A_arbace_instant_A_const_7.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any; var root_47 any = A_arbace_instant_A_const_8.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_13); var arg_51 any = lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(msg__3); if linked_48 == nil { arg_46 = ifn_49.Invoke_O_O__O(arg_50, arg_51) } else { arg_46 = linked_48.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_47, arg_50, arg_51) }; if linked_44 == nil { tmp5 = ifn_45.Invoke_O__O(arg_46) } else { tmp5 = linked_44.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_43, arg_46) }; arg_36 = tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O__O(tmp5)); if linked_34 == nil { return ifn_35.Invoke_O__O(arg_36) } else { return linked_34.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_33, arg_36) } }
//line :34:1
func (t *A_arbace_instant_verify_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, test__2 any) any { var root_52 any = A_arbace_instant_A_const_7.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = lang.IFn_Cast(A_arbace_instant_A_const_8.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_14), lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(test__2), lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_28, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_instant_A_const_15.GetRawRoot__O()).Invoke_O__O(test__2))).Ref())); if linked_53 == nil { return ifn_54.Invoke_O__O(arg_55) } else { return linked_53.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_52, arg_55) } }



func A_arbace_instant_divisible_QMARK__A_New() *A_arbace_instant_divisible_QMARK__A { A_arbace_instant_A_Init(); t := &A_arbace_instant_divisible_QMARK__A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_instant_divisible_QMARK__A) Ctor() {}
//line :38:1
func (t *A_arbace_instant_divisible_QMARK__A) Invoke_O_O_O__O(self, num__0, div__1 any) any {

	var tmp1 bool; var na_66 any; var root_67 any = A_arbace_instant_A_const_16.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_mod_A_fn_class); var ifn_69 lang.IFn; if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = num__0; var arg_71 any = div__1; if linked_68 == nil { na_66 = ifn_69.Invoke_O_O__O(arg_70, arg_71) } else { na_66 = linked_68.(*aot_arbace_core.A_arbace_core_mod_A).Invoke_O_O_O__O(root_67, arg_70, arg_71) }; if jrt.Long_InstanceOf(na_66) { var n0_72 int64 = jrt.NN(jrt.Long_Cast(na_66)).LongValue__J(); tmp1 = n0_72 == 0 } else { if jrt.Double_InstanceOf(na_66) { var n0_72_2 float64 = jrt.NN(jrt.Double_Cast(na_66)).DoubleValue__D(); tmp1 = n0_72_2 == 0.0 } else { tmp1 = lang.Numbers_IsZero_O__Z_NoInit(na_66) } }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp1).Ref()
}
func A_arbace_instant_indivisible_QMARK__A_New() *A_arbace_instant_indivisible_QMARK__A { A_arbace_instant_A_Init(); t := &A_arbace_instant_indivisible_QMARK__A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_instant_indivisible_QMARK__A) Ctor() {}
//line :42:1
func (t *A_arbace_instant_indivisible_QMARK__A) Invoke_O_O_O__O(self, num__0, div__1 any) any {

	var root_73 any = A_arbace_instant_A_const_17.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any; var root_77 any = A_arbace_instant_A_const_18.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, A_arbace_instant_divisible_QMARK__A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = num__0; var arg_81 any = div__1; if linked_78 == nil { arg_76 = ifn_79.Invoke_O_O__O(arg_80, arg_81) } else { arg_76 = linked_78.(*A_arbace_instant_divisible_QMARK__A).Invoke_O_O_O__O(root_77, arg_80, arg_81) }; if linked_74 == nil { return ifn_75.Invoke_O__O(arg_76) } else { return linked_74.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_73, arg_76)
	}
}


func A_arbace_instant_parse_int_A_New() *A_arbace_instant_parse_int_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_parse_int_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_instant_parse_int_A) Ctor() {}
//line :49:1
func (t *A_arbace_instant_parse_int_A) Invoke_O_O__O(self, s__0 any) any {
	return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(s__0))).Ref()
}
func A_arbace_instant_zero_fill_right_A_New() *A_arbace_instant_zero_fill_right_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_zero_fill_right_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_instant_zero_fill_right_A) Ctor() {}
//line :52:1
func (t *A_arbace_instant_zero_fill_right_A) Invoke_O_O_O__O(self, s__0, width__1 any) any {
	if lang.Util_Equiv_O_J__Z_NoInit(width__1, int64(lang.RT_Count_O__I_NoInit(s__0))) { return s__0 } else { var tmp1 bool; var na_82 any = width__1; var na_83 int64 = int64(lang.RT_Count_O__I_NoInit(s__0))
		if jrt.Long_InstanceOf(na_82) { var n0_84 int64 = jrt.NN(jrt.Long_Cast(na_82)).LongValue__J(); var n1_85 int64 = na_83; tmp1 = n0_84 < n1_85 } else { tmp1 = lang.Numbers_Lt_O_J__Z_NoInit(na_82, na_83) }
//line :53:1
		if tmp1 {
			return jrt.NN(jrt.String_Cast(s__0)).Substring_I_I__String(lang.RT_IntCast_J__I_NoInit(0), lang.RT_IntCast_O__I_NoInit(width__1)).Ref() } else {
//line :53:1
				if A_arbace_instant_A_const_19 != nil { var b__3 any = jrt.StringBuilder_New_String(jrt.String_Cast(s__0)); L1: for {


					var tmp2 bool; var na_87 int64 = int64(jrt.NN(jrt.StringBuilder_Cast(b__3)).Length__I()); var na_88 any = width__1; if jrt.Long_InstanceOf(na_88) { var n0_89 int64 = na_87; var n1_90 int64 = jrt.NN(jrt.Long_Cast(na_88)).LongValue__J(); tmp2 = n0_89 < n1_90 } else { tmp2 = lang.Numbers_Lt_J_O__Z_NoInit(na_87, na_88) }; if tmp2 {
						b__3 = jrt.NN(jrt.StringBuilder_Cast(b__3)).Append_O__StringBuilder(A_arbace_instant_A_const_20).Ref(); continue L1 } else {
							return jrt.NN(jrt.StringBuilder_Cast(b__3)).ToString__String().Ref() } } } else {
//line :53:1
								return nil } } }
//line :52:1
	panic("j2g: unreachable")
}









func A_arbace_instant_parse_timestamp_A_New() *A_arbace_instant_parse_timestamp_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_parse_timestamp_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_instant_parse_timestamp_A) Ctor() {}
//line :63:1
func (t *A_arbace_instant_parse_timestamp_A) Invoke_O_O_O__O(self, new_instant__0, cs__1 any) any { var temp__1927000408__auto____3 any; var root_92 any = A_arbace_instant_A_const_21.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_94 lang.IFn; if





















































	linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = A_arbace_instant_A_const_22.GetRawRoot__O(); var arg_96 any = cs__1; if linked_93 == nil { temp__1927000408__auto____3 = ifn_94.Invoke_O_O__O(arg_95, arg_96) } else { temp__1927000408__auto____3 = linked_93.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_92, arg_95, arg_96) }; if /*line :115:1*/ jrt.J2g_Truth(temp__1927000408__auto____3) { var vec__783000026__4 any = temp__1927000408__auto____3; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(0), nil); var years__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(1), nil); var months__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(2), nil); var days__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(3), nil); var hours__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(4), nil); var minutes__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(5), nil); var seconds__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(6), nil); var fraction__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(7), nil); var offset_sign__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(8), nil); var offset_hours__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(9), nil); var offset_minutes__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(10), nil); var tmp1 lang.IFn = lang.IFn_Cast(new_instant__0); var tmp2 any; var root_97 any = A_arbace_instant_A_const_23.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, A_arbace_instant_parse_int_A_fn_class); var ifn_99 lang.IFn; _ = ___5



		if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = years__6; if linked_98 == nil { tmp2 = ifn_99.Invoke_O__O(arg_100) } else { tmp2 = linked_98.(*A_arbace_instant_parse_int_A).Invoke_O_O__O(root_97, arg_100) }
//line :118:1
		var tmp3 any = tmp2; var tmp4 any; var tmp5 any; var root_101 any = A_arbace_instant_A_const_17.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_103 lang.IFn

		if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = months__7; if linked_102 == nil { tmp5 = ifn_103.Invoke_O__O(arg_104) } else { tmp5 = linked_102.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_101, arg_104) }; if jrt.J2g_Truth(tmp5) { tmp4 = A_arbace_instant_A_const_24 } else { var root_105 any = A_arbace_instant_A_const_23.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, A_arbace_instant_parse_int_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = months__7; if linked_106 == nil { tmp4 = ifn_107.Invoke_O__O(arg_108) } else { tmp4 = linked_106.(*A_arbace_instant_parse_int_A).Invoke_O_O__O(root_105, arg_108) } }
//line :118:1
		var tmp6 any = tmp4; var tmp7 any; var tmp8 any; var root_109 any = A_arbace_instant_A_const_17.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_111 lang.IFn


		if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = days__8; if linked_110 == nil { tmp8 = ifn_111.Invoke_O__O(arg_112) } else { tmp8 = linked_110.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_109, arg_112) }; if jrt.J2g_Truth(tmp8) { tmp7 = A_arbace_instant_A_const_24 } else { var root_113 any = A_arbace_instant_A_const_23.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, A_arbace_instant_parse_int_A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = days__8; if linked_114 == nil { tmp7 = ifn_115.Invoke_O__O(arg_116) } else { tmp7 = linked_114.(*A_arbace_instant_parse_int_A).Invoke_O_O__O(root_113, arg_116) } }
//line :118:1
		var tmp9 any = tmp7; var tmp10 any; var tmp11 any; var root_117 any = A_arbace_instant_A_const_17.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_119 lang.IFn



		if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = hours__9; if linked_118 == nil { tmp11 = ifn_119.Invoke_O__O(arg_120) } else { tmp11 = linked_118.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_117, arg_120) }; if jrt.J2g_Truth(tmp11) { tmp10 = A_arbace_instant_A_const_25 } else { var root_121 any = A_arbace_instant_A_const_23.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, A_arbace_instant_parse_int_A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = hours__9; if linked_122 == nil { tmp10 = ifn_123.Invoke_O__O(arg_124) } else { tmp10 = linked_122.(*A_arbace_instant_parse_int_A).Invoke_O_O__O(root_121, arg_124) } }
//line :118:1
		var tmp12 any = tmp10; var tmp13 any; var tmp14 any; var root_125 any = A_arbace_instant_A_const_17.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_127 lang.IFn




		if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = minutes__10; if linked_126 == nil { tmp14 = ifn_127.Invoke_O__O(arg_128) } else { tmp14 = linked_126.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_125, arg_128) }; if jrt.J2g_Truth(tmp14) { tmp13 = A_arbace_instant_A_const_25 } else { var root_129 any = A_arbace_instant_A_const_23.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, A_arbace_instant_parse_int_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = minutes__10; if linked_130 == nil { tmp13 = ifn_131.Invoke_O__O(arg_132) } else { tmp13 = linked_130.(*A_arbace_instant_parse_int_A).Invoke_O_O__O(root_129, arg_132) } }
//line :118:1
		var tmp15 any = tmp13; var tmp16 any; var tmp17 any; var root_133 any = A_arbace_instant_A_const_17.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_135 lang.IFn





		if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = seconds__11; if linked_134 == nil { tmp17 = ifn_135.Invoke_O__O(arg_136) } else { tmp17 = linked_134.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_133, arg_136) }; if jrt.J2g_Truth(tmp17) { tmp16 = A_arbace_instant_A_const_25 } else { var root_137 any = A_arbace_instant_A_const_23.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, A_arbace_instant_parse_int_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = seconds__11; if linked_138 == nil { tmp16 = ifn_139.Invoke_O__O(arg_140) } else { tmp16 = linked_138.(*A_arbace_instant_parse_int_A).Invoke_O_O__O(root_137, arg_140) } }
//line :118:1
		var tmp18 any = tmp16; var tmp19 any; var tmp20 any; var root_141 any = A_arbace_instant_A_const_17.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_143 lang.IFn






		if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = fraction__12; if linked_142 == nil { tmp20 = ifn_143.Invoke_O__O(arg_144) } else { tmp20 = linked_142.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_141, arg_144) }; if jrt.J2g_Truth(tmp20) { tmp19 = A_arbace_instant_A_const_25 } else { var root_145 any = A_arbace_instant_A_const_23.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, A_arbace_instant_parse_int_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any; var root_149 any = A_arbace_instant_A_const_26.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, A_arbace_instant_zero_fill_right_A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = fraction__12; var arg_153 any = A_arbace_instant_A_const_27; if linked_150 == nil { arg_148 = ifn_151.Invoke_O_O__O(arg_152, arg_153) } else { arg_148 = linked_150.(*A_arbace_instant_zero_fill_right_A).Invoke_O_O_O__O(root_149, arg_152, arg_153) }; if linked_146 == nil { tmp19 = ifn_147.Invoke_O__O(arg_148) } else { tmp19 = linked_146.(*A_arbace_instant_parse_int_A).Invoke_O_O__O(root_145, arg_148) } }
//line :118:1
		var tmp21 any = tmp19; var tmp22 any







		if lang.Util_Equiv_O_O__Z_NoInit(Lit_2, offset_sign__13) { tmp22 = A_arbace_instant_A_const_28 } else { if lang.Util_Equiv_O_O__Z_NoInit(Lit_3, offset_sign__13) { tmp22 = A_arbace_instant_A_const_24 } else { if A_arbace_instant_A_const_19 != nil { tmp22 = A_arbace_instant_A_const_25 } else { tmp22 = nil } } }
//line :118:1
		var tmp23 any = tmp22; var tmp24 any; var tmp25 any; var root_154 any = A_arbace_instant_A_const_17.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_156 lang.IFn










		if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = offset_hours__14; if linked_155 == nil { tmp25 = ifn_156.Invoke_O__O(arg_157) } else { tmp25 = linked_155.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_154, arg_157) }; if jrt.J2g_Truth(tmp25) { tmp24 = A_arbace_instant_A_const_25 } else { var root_158 any = A_arbace_instant_A_const_23.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, A_arbace_instant_parse_int_A_fn_class); var ifn_160 lang.IFn; if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any = offset_hours__14; if linked_159 == nil { tmp24 = ifn_160.Invoke_O__O(arg_161) } else { tmp24 = linked_159.(*A_arbace_instant_parse_int_A).Invoke_O_O__O(root_158, arg_161) } }
//line :118:1
		var tmp26 any = tmp24; var tmp27 any; var tmp28 any; var root_162 any = A_arbace_instant_A_const_17.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_164 lang.IFn











		if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = offset_minutes__15; if linked_163 == nil { tmp28 = ifn_164.Invoke_O__O(arg_165) } else { tmp28 = linked_163.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_162, arg_165) }; if jrt.J2g_Truth(tmp28) { tmp27 = A_arbace_instant_A_const_25 } else { var root_166 any = A_arbace_instant_A_const_23.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, A_arbace_instant_parse_int_A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = offset_minutes__15; if linked_167 == nil { tmp27 = ifn_168.Invoke_O__O(arg_169) } else { tmp27 = linked_167.(*A_arbace_instant_parse_int_A).Invoke_O_O__O(root_166, arg_169) } }
//line :118:1
		return tmp1.Invoke_O_O_O_O_O_O_O_O_O_O__O(tmp3, tmp6, tmp9, tmp12, tmp15, tmp18, tmp21, tmp23, tmp26, tmp27) } else {
//line :115:1
			panic(jrt.Thrown(jrt.RuntimeException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, cs__1))))) } }




















func A_arbace_instant_leap_year_QMARK__A_New() *A_arbace_instant_leap_year_QMARK__A { A_arbace_instant_A_Init(); t := &A_arbace_instant_leap_year_QMARK__A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_instant_leap_year_QMARK__A) Ctor() {}
//line :136:1
func (t *A_arbace_instant_leap_year_QMARK__A) Invoke_O_O__O(self, year__0 any) any { var and__1927000168__auto____2 any; var root_170 any = A_arbace_instant_A_const_18.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, A_arbace_instant_divisible_QMARK__A_fn_class); var ifn_172 lang.IFn; if

	linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = year__0; var arg_174 any = A_arbace_instant_A_const_29; if linked_171 == nil { and__1927000168__auto____2 = ifn_172.Invoke_O_O__O(arg_173, arg_174) } else { and__1927000168__auto____2 = linked_171.(*A_arbace_instant_divisible_QMARK__A).Invoke_O_O_O__O(root_170, arg_173, arg_174) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var or__1927000174__auto____3 any; var root_175 any = A_arbace_instant_A_const_30.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, A_arbace_instant_indivisible_QMARK__A_fn_class); var ifn_177 lang.IFn
		if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = year__0; var arg_179 any = A_arbace_instant_A_const_31; if linked_176 == nil { or__1927000174__auto____3 = ifn_177.Invoke_O_O__O(arg_178, arg_179) } else { or__1927000174__auto____3 = linked_176.(*A_arbace_instant_indivisible_QMARK__A).Invoke_O_O_O__O(root_175, arg_178, arg_179) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else {
			var root_180 any = A_arbace_instant_A_const_18.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, A_arbace_instant_divisible_QMARK__A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = year__0; var arg_184 any = A_arbace_instant_A_const_32; if linked_181 == nil { return ifn_182.Invoke_O_O__O(arg_183, arg_184) } else { return linked_181.(*A_arbace_instant_divisible_QMARK__A).Invoke_O_O_O__O(root_180, arg_183, arg_184) } } } else {
//line :138:1
				return and__1927000168__auto____2 } }




func A_arbace_instant_fn__783000031_A_New() *A_arbace_instant_fn__783000031_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_fn__783000031_A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_instant_fn__783000031_A) Ctor() {}
//line :143:1
func (t *A_arbace_instant_fn__783000031_A) Invoke_O__O(self any) any { var dim_norm__1 any = A_arbace_instant_A_const_33; var dim_leap__2 any = A_arbace_instant_A_const_34; var tmp1 any = A_arbace_instant_fn__783000031_fn__783000032_A_New_O_O(dim_norm__1, dim_leap__2); var tmp2 *jrt.Class; var fncls__185 *jrt.Class = A_arbace_instant_fn__783000031_fn__783000032_A_fn_class; if

	fncls__185 == nil { var fncls__185d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_instant_fn__783000031_fn__783000032_A_fn_class = fncls__185d; tmp2 = fncls__185d } else { tmp2 = fncls__185 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :145:1
func A_arbace_instant_fn__783000031_fn__783000032_A_New_O_O(p0, p1 any) *A_arbace_instant_fn__783000031_fn__783000032_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_fn__783000031_fn__783000032_A{}; t.Ctor_O_O(p0, p1); return t }
//line :145:1
func (t *A_arbace_instant_fn__783000031_fn__783000032_A) Ctor_O_O(c__dim_norm, c__dim_leap any) { t.F_dim_norm = c__dim_norm; t.F_dim_leap = c__dim_leap }
//line :145:1
func (t *A_arbace_instant_fn__783000031_fn__783000032_A) Invoke_O_O_O__O(self, month__1, leap_year_QMARK___2 any) any {
	var tmp1 any; if jrt.J2g_Truth(leap_year_QMARK___2) { tmp1 = t.F_dim_leap } else { tmp1 = t.F_dim_norm }; return lang.IFn_Cast(tmp1).Invoke_O__O(month__1)
}
func A_arbace_instant_validated_A_New() *A_arbace_instant_validated_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_validated_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_instant_validated_A) Ctor() {}
//line :148:1
func (t *A_arbace_instant_validated_A) Invoke_O_O__O(self, new_instance__0 any) any {





	var tmp1 any = A_arbace_instant_validated_fn__783000035_A_New_O(new_instance__0); var tmp2 *jrt.Class; var fncls__249 *jrt.Class = A_arbace_instant_validated_fn__783000035_A_fn_class; if fncls__249 == nil { var fncls__249d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_instant_validated_fn__783000035_A_fn_class = fncls__249d; tmp2 = fncls__249d } else { tmp2 = fncls__249 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :154:1
func A_arbace_instant_validated_fn__783000035_A_New_O(p0 any) *A_arbace_instant_validated_fn__783000035_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_validated_fn__783000035_A{}; t.Ctor_O(p0); return t }
//line :154:1
func (t *A_arbace_instant_validated_fn__783000035_A) Ctor_O(c__new_instance any) { t.F_new_instance = c__new_instance }
//line :154:1
func (t *A_arbace_instant_validated_fn__783000035_A) Invoke_O_O_O_O_O_O_O_O_O_O_O__O(self, years__1, months__2, days__3, hours__4, minutes__5, seconds__6, nanoseconds__7, offset_sign__8, offset_hours__9, offset_minutes__10 any) any {

	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_24, months__2, A_arbace_instant_A_const_36)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_19))) }
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()); var tmp2 any = A_arbace_instant_A_const_24; var tmp3 any; var root_198 any = A_arbace_instant_A_const_37.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, A_arbace_instant_fn__783000031_fn__783000032_A_fn_class); var ifn_200 lang.IFn; if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = months__2; var arg_202 any; var root_203 any = A_arbace_instant_A_const_38.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, A_arbace_instant_leap_year_QMARK__A_fn_class); var ifn_205 lang.IFn; if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any = years__1; if linked_204 == nil { arg_202 = ifn_205.Invoke_O__O(arg_206) } else { arg_202 = linked_204.(*A_arbace_instant_leap_year_QMARK__A).Invoke_O_O__O(root_203, arg_206) }; if linked_199 == nil { tmp3 = ifn_200.Invoke_O_O__O(arg_201, arg_202) } else { tmp3 = linked_199.(*A_arbace_instant_fn__783000031_fn__783000032_A).Invoke_O_O_O__O(root_198, arg_201, arg_202) }; if jrt.J2g_Truth(tmp1.Invoke_O_O_O__O(tmp2, days__3, tmp3)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_20))) }
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_25, hours__4, A_arbace_instant_A_const_39)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_21))) }
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_25, minutes__5, A_arbace_instant_A_const_40)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_22))) }
	var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()); var tmp5 any = A_arbace_instant_A_const_25; var tmp6 any; if lang.Util_Equiv_O_J__Z_NoInit(minutes__5, 59) { tmp6 = A_arbace_instant_A_const_41 } else { tmp6 = A_arbace_instant_A_const_40 }; if jrt.J2g_Truth(tmp4.Invoke_O_O_O__O(tmp5, seconds__6, tmp6)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_23))) }
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_25, nanoseconds__7, A_arbace_instant_A_const_42)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_24))) }
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_28, offset_sign__8, A_arbace_instant_A_const_24)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_25))) }
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_25, offset_hours__9, A_arbace_instant_A_const_39)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_26))) }
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_25, offset_minutes__10, A_arbace_instant_A_const_40)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_27))) }
	return lang.IFn_Cast(t.F_new_instance).Invoke_O_O_O_O_O_O_O_O_O_O__O(years__1, months__2, days__3, hours__4, minutes__5, seconds__6, nanoseconds__7, offset_sign__8, offset_hours__9, offset_minutes__10)
}











func A_arbace_instant_days__GT_civil_A_New() *A_arbace_instant_days__GT_civil_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_days__GT_civil_A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_instant_days__GT_civil_A) Ctor() {}
//line :178:1
func (t *A_arbace_instant_days__GT_civil_A) Invoke_O_O__O(self, z__0 any) any {



	var tmp1 bool; var na_250 any = z__0; var na_251 any = A_arbace_instant_A_const_43.GetRawRoot__O(); var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_250); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_251) }; tmp2 = tmp3; if tmp2 { var n0_252 int64 = jrt.NN(jrt.Long_Cast(na_250)).LongValue__J(); var n1_253 int64 = jrt.NN(jrt.Long_Cast(na_251)).LongValue__J(); tmp1 = n0_252 >= n1_253 } else { var tmp4 bool; var tmp5 bool; tmp5 = jrt.Double_InstanceOf(na_250); if tmp5 { tmp5 = jrt.Double_InstanceOf(na_251) }; tmp4 = tmp5; if tmp4 { var n0_252_2 float64 = jrt.NN(jrt.Double_Cast(na_250)).DoubleValue__D(); var n1_253_2 float64 = jrt.NN(jrt.Double_Cast(na_251)).DoubleValue__D(); tmp1 = n0_252_2 >= n1_253_2 } else { tmp1 = lang.Numbers_Gte_O_O__Z_NoInit(na_250, na_251) } }; if tmp1 { var z__2 any; var na_255 any = z__0; var na_256 int64 = 719468
		if jrt.Long_InstanceOf(na_255) { var n0_257 int64 = jrt.NN(jrt.Long_Cast(na_255)).LongValue__J(); var n1_258 int64 = na_256; var nr_259 int64 = n0_257 + n1_258; if (n0_257^nr_259)&(n1_258^nr_259) >= 0 { z__2 = jrt.Long_ValueOf_J__Long_NoInit(nr_259).Ref() } else { z__2 = lang.Numbers_Add_O_J__Number_NoInit(na_255, na_256) } } else { z__2 = lang.Numbers_Add_O_J__Number_NoInit(na_255, na_256) }
//line :182:1
		var era__3 any; var na_260 any; var tmp6 bool
		var na_262 any = z__2; var na_263 int64 = 0
		if jrt.Long_InstanceOf(na_262) { var n0_264 int64 = jrt.NN(jrt.Long_Cast(na_262)).LongValue__J(); var n1_265 int64 = na_263; tmp6 = n0_264 >= n1_265 } else { tmp6 = lang.Numbers_Gte_O_J__Z_NoInit(na_262, na_263) }; if tmp6 { na_260 = z__2 } else { var na_267 any = z__2; var na_268 int64 = 146096; if jrt.Long_InstanceOf(na_267) { var n0_269 int64 = jrt.NN(jrt.Long_Cast(na_267)).LongValue__J(); var n1_270 int64 = na_268; var nr_271 int64 = n0_269 - n1_270; var tmp7 bool; var tmp8 bool; tmp8 = !(n1_270 == -9223372036854775808); if tmp8 { tmp8 = (n0_269^n1_270)&(n0_269^nr_271) >= 0 }; tmp7 = tmp8; if tmp7 { na_260 = jrt.Long_ValueOf_J__Long_NoInit(nr_271).Ref() } else { na_260 = lang.Numbers_Minus_O_J__Number_NoInit(na_267, na_268) } } else { na_260 = lang.Numbers_Minus_O_J__Number_NoInit(na_267, na_268) } }; var na_261 int64 = 146097; if jrt.Long_InstanceOf(na_260) { var n0_272 int64 = jrt.NN(jrt.Long_Cast(na_260)).LongValue__J(); var n1_273 int64 = na_261; if n1_273 == 0 { era__3 = lang.Numbers_Quotient_O_J__Number_NoInit(na_260, na_261) } else { era__3 = jrt.Long_ValueOf_J__Long_NoInit(n0_272 / n1_273).Ref() } } else { era__3 = lang.Numbers_Quotient_O_J__Number_NoInit(na_260, na_261) }
//line :182:1
		var doe__4 any; var na_275 any = z__2; var na_276 any
		var na_277 any = era__3
		var na_278 int64 = 146097
		if jrt.Long_InstanceOf(na_277) { var n0_279 int64 = jrt.NN(jrt.Long_Cast(na_277)).LongValue__J(); var n1_280 int64 = na_278; var nr_281 int64 = n0_279 * n1_280; var tmp9 bool; var tmp10 bool; var tmp11 bool; var tmp12 bool; tmp12 = n0_279 == -9223372036854775808; if tmp12 { tmp12 = n1_280 < 0 }; tmp11 = tmp12; tmp10 = !tmp11; if tmp10 { var tmp13 bool; tmp13 = n1_280 == 0; if !tmp13 { tmp13 = nr_281/n1_280 == n0_279 }; tmp10 = tmp13 }; tmp9 = tmp10; if tmp9 { na_276 = jrt.Long_ValueOf_J__Long_NoInit(nr_281).Ref() } else { na_276 = lang.Numbers_Multiply_O_J__Number_NoInit(na_277, na_278) } } else { na_276 = lang.Numbers_Multiply_O_J__Number_NoInit(na_277, na_278) }; var tmp14 bool; var tmp15 bool; tmp15 = jrt.Long_InstanceOf(na_275); if tmp15 { tmp15 = jrt.Long_InstanceOf(na_276) }; tmp14 = tmp15; if tmp14 { var n0_282 int64 = jrt.NN(jrt.Long_Cast(na_275)).LongValue__J(); var n1_283 int64 = jrt.NN(jrt.Long_Cast(na_276)).LongValue__J(); var nr_284 int64 = n0_282 - n1_283; var tmp16 bool; var tmp17 bool; tmp17 = !(n1_283 == -9223372036854775808); if tmp17 { tmp17 = (n0_282^n1_283)&(n0_282^nr_284) >= 0 }; tmp16 = tmp17; if tmp16 { doe__4 = jrt.Long_ValueOf_J__Long_NoInit(nr_284).Ref() } else { doe__4 = lang.Numbers_Minus_O_O__Number_NoInit(na_275, na_276) } } else { var tmp18 bool; var tmp19 bool; tmp19 = jrt.Double_InstanceOf(na_275); if tmp19 { tmp19 = jrt.Double_InstanceOf(na_276) }; tmp18 = tmp19; if tmp18 { var n0_282_2 float64 = jrt.NN(jrt.Double_Cast(na_275)).DoubleValue__D(); var n1_283_2 float64 = jrt.NN(jrt.Double_Cast(na_276)).DoubleValue__D(); doe__4 = jrt.Double_ValueOf_D__Double_NoInit(n0_282_2 + -n1_283_2).Ref() } else { doe__4 = lang.Numbers_Minus_O_O__Number_NoInit(na_275, na_276) } }
//line :182:1
		var yoe__5 any; var na_285 any; var na_287 any; var na_289 any; var na_291 any = doe__4; var na_292 any
		var na_293 any = doe__4
		var na_294 int64 = 1460

		if jrt.Long_InstanceOf(na_293) { var n0_295 int64 = jrt.NN(jrt.Long_Cast(na_293)).LongValue__J(); var n1_296 int64 = na_294; if n1_296 == 0 { na_292 = lang.Numbers_Quotient_O_J__Number_NoInit(na_293, na_294) } else { na_292 = jrt.Long_ValueOf_J__Long_NoInit(n0_295 / n1_296).Ref() } } else { na_292 = lang.Numbers_Quotient_O_J__Number_NoInit(na_293, na_294) }; var tmp20 bool; var tmp21 bool; tmp21 = jrt.Long_InstanceOf(na_291); if tmp21 { tmp21 = jrt.Long_InstanceOf(na_292) }; tmp20 = tmp21; if tmp20 { var n0_298 int64 = jrt.NN(jrt.Long_Cast(na_291)).LongValue__J(); var n1_299 int64 = jrt.NN(jrt.Long_Cast(na_292)).LongValue__J(); var nr_300 int64 = n0_298 - n1_299; var tmp22 bool; var tmp23 bool; tmp23 = !(n1_299 == -9223372036854775808); if tmp23 { tmp23 = (n0_298^n1_299)&(n0_298^nr_300) >= 0 }; tmp22 = tmp23; if tmp22 { na_289 = jrt.Long_ValueOf_J__Long_NoInit(nr_300).Ref() } else { na_289 = lang.Numbers_Minus_O_O__Number_NoInit(na_291, na_292) } } else { var tmp24 bool; var tmp25 bool; tmp25 = jrt.Double_InstanceOf(na_291); if tmp25 { tmp25 = jrt.Double_InstanceOf(na_292) }; tmp24 = tmp25; if tmp24 { var n0_298_2 float64 = jrt.NN(jrt.Double_Cast(na_291)).DoubleValue__D(); var n1_299_2 float64 = jrt.NN(jrt.Double_Cast(na_292)).DoubleValue__D(); na_289 = jrt.Double_ValueOf_D__Double_NoInit(n0_298_2 + -n1_299_2).Ref() } else { na_289 = lang.Numbers_Minus_O_O__Number_NoInit(na_291, na_292) } }; var na_290 any; var na_301 any; var na_302 any = doe__4; var na_303 int64 = 36524; if jrt.Long_InstanceOf(na_302) { var n0_304 int64 = jrt.NN(jrt.Long_Cast(na_302)).LongValue__J(); var n1_305 int64 = na_303; if n1_305 == 0 { na_301 = lang.Numbers_Quotient_O_J__Number_NoInit(na_302, na_303) } else { na_301 = jrt.Long_ValueOf_J__Long_NoInit(n0_304 / n1_305).Ref() } } else { na_301 = lang.Numbers_Quotient_O_J__Number_NoInit(na_302, na_303) }; if jrt.Long_InstanceOf(na_301) { var n0_307 int64 = jrt.NN(jrt.Long_Cast(na_301)).LongValue__J(); if n0_307 == -9223372036854775808 { na_290 = lang.Numbers_Minus_O__Number_NoInit(na_301) } else { na_290 = jrt.Long_ValueOf_J__Long_NoInit(-n0_307).Ref() } } else { if jrt.Double_InstanceOf(na_301) { var n0_307_2 float64 = jrt.NN(jrt.Double_Cast(na_301)).DoubleValue__D(); na_290 = jrt.Double_ValueOf_D__Double_NoInit(-n0_307_2).Ref() } else { na_290 = lang.Numbers_Minus_O__Number_NoInit(na_301) } }; var tmp26 bool; var tmp27 bool; tmp27 = jrt.Long_InstanceOf(na_289); if tmp27 { tmp27 = jrt.Long_InstanceOf(na_290) }; tmp26 = tmp27; if tmp26 { var n0_308 int64 = jrt.NN(jrt.Long_Cast(na_289)).LongValue__J(); var n1_309 int64 = jrt.NN(jrt.Long_Cast(na_290)).LongValue__J(); var nr_310 int64 = n0_308 - n1_309; var tmp28 bool; var tmp29 bool; tmp29 = !(n1_309 == -9223372036854775808); if tmp29 { tmp29 = (n0_308^n1_309)&(n0_308^nr_310) >= 0 }; tmp28 = tmp29; if tmp28 { na_287 = jrt.Long_ValueOf_J__Long_NoInit(nr_310).Ref() } else { na_287 = lang.Numbers_Minus_O_O__Number_NoInit(na_289, na_290) } } else { var tmp30 bool; var tmp31 bool; tmp31 = jrt.Double_InstanceOf(na_289); if tmp31 { tmp31 = jrt.Double_InstanceOf(na_290) }; tmp30 = tmp31; if tmp30 { var n0_308_2 float64 = jrt.NN(jrt.Double_Cast(na_289)).DoubleValue__D(); var n1_309_2 float64 = jrt.NN(jrt.Double_Cast(na_290)).DoubleValue__D(); na_287 = jrt.Double_ValueOf_D__Double_NoInit(n0_308_2 + -n1_309_2).Ref() } else { na_287 = lang.Numbers_Minus_O_O__Number_NoInit(na_289, na_290) } }; var na_288 any; var na_311 any = doe__4; var na_312 int64 = 146096; if jrt.Long_InstanceOf(na_311) { var n0_313 int64 = jrt.NN(jrt.Long_Cast(na_311)).LongValue__J(); var n1_314 int64 = na_312; if n1_314 == 0 { na_288 = lang.Numbers_Quotient_O_J__Number_NoInit(na_311, na_312) } else { na_288 = jrt.Long_ValueOf_J__Long_NoInit(n0_313 / n1_314).Ref() } } else { na_288 = lang.Numbers_Quotient_O_J__Number_NoInit(na_311, na_312) }; var tmp32 bool; var tmp33 bool; tmp33 = jrt.Long_InstanceOf(na_287); if tmp33 { tmp33 = jrt.Long_InstanceOf(na_288) }; tmp32 = tmp33; if tmp32 { var n0_316 int64 = jrt.NN(jrt.Long_Cast(na_287)).LongValue__J(); var n1_317 int64 = jrt.NN(jrt.Long_Cast(na_288)).LongValue__J(); var nr_318 int64 = n0_316 - n1_317; var tmp34 bool; var tmp35 bool; tmp35 = !(n1_317 == -9223372036854775808); if tmp35 { tmp35 = (n0_316^n1_317)&(n0_316^nr_318) >= 0 }; tmp34 = tmp35; if tmp34 { na_285 = jrt.Long_ValueOf_J__Long_NoInit(nr_318).Ref() } else { na_285 = lang.Numbers_Minus_O_O__Number_NoInit(na_287, na_288) } } else { var tmp36 bool; var tmp37 bool; tmp37 = jrt.Double_InstanceOf(na_287); if tmp37 { tmp37 = jrt.Double_InstanceOf(na_288) }; tmp36 = tmp37; if tmp36 { var n0_316_2 float64 = jrt.NN(jrt.Double_Cast(na_287)).DoubleValue__D(); var n1_317_2 float64 = jrt.NN(jrt.Double_Cast(na_288)).DoubleValue__D(); na_285 = jrt.Double_ValueOf_D__Double_NoInit(n0_316_2 + -n1_317_2).Ref() } else { na_285 = lang.Numbers_Minus_O_O__Number_NoInit(na_287, na_288) } }; var na_286 int64 = 365; if jrt.Long_InstanceOf(na_285) { var n0_319 int64 = jrt.NN(jrt.Long_Cast(na_285)).LongValue__J(); var n1_320 int64 = na_286; if n1_320 == 0 { yoe__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_285, na_286) } else { yoe__5 = jrt.Long_ValueOf_J__Long_NoInit(n0_319 / n1_320).Ref() } } else { yoe__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_285, na_286) }
//line :182:1
		var y__6 any; var na_322 any = yoe__5; var na_323 any
		var na_324 any = era__3
		var na_325 int64 = 400


		if jrt.Long_InstanceOf(na_324) { var n0_326 int64 = jrt.NN(jrt.Long_Cast(na_324)).LongValue__J(); var n1_327 int64 = na_325; var nr_328 int64 = n0_326 * n1_327; var tmp38 bool; var tmp39 bool; var tmp40 bool; var tmp41 bool; tmp41 = n0_326 == -9223372036854775808; if tmp41 { tmp41 = n1_327 < 0 }; tmp40 = tmp41; tmp39 = !tmp40; if tmp39 { var tmp42 bool; tmp42 = n1_327 == 0; if !tmp42 { tmp42 = nr_328/n1_327 == n0_326 }; tmp39 = tmp42 }; tmp38 = tmp39; if tmp38 { na_323 = jrt.Long_ValueOf_J__Long_NoInit(nr_328).Ref() } else { na_323 = lang.Numbers_Multiply_O_J__Number_NoInit(na_324, na_325) } } else { na_323 = lang.Numbers_Multiply_O_J__Number_NoInit(na_324, na_325) }; var tmp43 bool; var tmp44 bool; tmp44 = jrt.Long_InstanceOf(na_322); if tmp44 { tmp44 = jrt.Long_InstanceOf(na_323) }; tmp43 = tmp44; if tmp43 { var n0_329 int64 = jrt.NN(jrt.Long_Cast(na_322)).LongValue__J(); var n1_330 int64 = jrt.NN(jrt.Long_Cast(na_323)).LongValue__J(); var nr_331 int64 = n0_329 + n1_330; if (n0_329^nr_331)&(n1_330^nr_331) >= 0 { y__6 = jrt.Long_ValueOf_J__Long_NoInit(nr_331).Ref() } else { y__6 = lang.Numbers_Add_O_O__Number_NoInit(na_322, na_323) } } else { var tmp45 bool; var tmp46 bool; tmp46 = jrt.Double_InstanceOf(na_322); if tmp46 { tmp46 = jrt.Double_InstanceOf(na_323) }; tmp45 = tmp46; if tmp45 { var n0_329_2 float64 = jrt.NN(jrt.Double_Cast(na_322)).DoubleValue__D(); var n1_330_2 float64 = jrt.NN(jrt.Double_Cast(na_323)).DoubleValue__D(); y__6 = jrt.Double_ValueOf_D__Double_NoInit(n0_329_2 + n1_330_2).Ref() } else { y__6 = lang.Numbers_Add_O_O__Number_NoInit(na_322, na_323) } }
//line :182:1
		var doy__7 any; var na_332 any = doe__4; var na_333 any; var na_334 any; var na_336 any
		var na_338 int64 = 365
		var na_339 any = yoe__5



		if jrt.Long_InstanceOf(na_339) { var n0_340 int64 = na_338; var n1_341 int64 = jrt.NN(jrt.Long_Cast(na_339)).LongValue__J(); var nr_342 int64 = n0_340 * n1_341; var tmp47 bool; var tmp48 bool; var tmp49 bool; var tmp50 bool; tmp50 = n0_340 == -9223372036854775808; if tmp50 { tmp50 = n1_341 < 0 }; tmp49 = tmp50; tmp48 = !tmp49; if tmp48 { var tmp51 bool; tmp51 = n1_341 == 0; if !tmp51 { tmp51 = nr_342/n1_341 == n0_340 }; tmp48 = tmp51 }; tmp47 = tmp48; if tmp47 { na_336 = jrt.Long_ValueOf_J__Long_NoInit(nr_342).Ref() } else { na_336 = lang.Numbers_Multiply_J_O__Number_NoInit(na_338, na_339) } } else { na_336 = lang.Numbers_Multiply_J_O__Number_NoInit(na_338, na_339) }; var na_337 any; var na_343 any = yoe__5; var na_344 int64 = 4; if jrt.Long_InstanceOf(na_343) { var n0_345 int64 = jrt.NN(jrt.Long_Cast(na_343)).LongValue__J(); var n1_346 int64 = na_344; if n1_346 == 0 { na_337 = lang.Numbers_Quotient_O_J__Number_NoInit(na_343, na_344) } else { na_337 = jrt.Long_ValueOf_J__Long_NoInit(n0_345 / n1_346).Ref() } } else { na_337 = lang.Numbers_Quotient_O_J__Number_NoInit(na_343, na_344) }; var tmp52 bool; var tmp53 bool; tmp53 = jrt.Long_InstanceOf(na_336); if tmp53 { tmp53 = jrt.Long_InstanceOf(na_337) }; tmp52 = tmp53; if tmp52 { var n0_348 int64 = jrt.NN(jrt.Long_Cast(na_336)).LongValue__J(); var n1_349 int64 = jrt.NN(jrt.Long_Cast(na_337)).LongValue__J(); var nr_350 int64 = n0_348 + n1_349; if (n0_348^nr_350)&(n1_349^nr_350) >= 0 { na_334 = jrt.Long_ValueOf_J__Long_NoInit(nr_350).Ref() } else { na_334 = lang.Numbers_Add_O_O__Number_NoInit(na_336, na_337) } } else { var tmp54 bool; var tmp55 bool; tmp55 = jrt.Double_InstanceOf(na_336); if tmp55 { tmp55 = jrt.Double_InstanceOf(na_337) }; tmp54 = tmp55; if tmp54 { var n0_348_2 float64 = jrt.NN(jrt.Double_Cast(na_336)).DoubleValue__D(); var n1_349_2 float64 = jrt.NN(jrt.Double_Cast(na_337)).DoubleValue__D(); na_334 = jrt.Double_ValueOf_D__Double_NoInit(n0_348_2 + n1_349_2).Ref() } else { na_334 = lang.Numbers_Add_O_O__Number_NoInit(na_336, na_337) } }; var na_335 any; var na_351 any = yoe__5; var na_352 int64 = 100; if jrt.Long_InstanceOf(na_351) { var n0_353 int64 = jrt.NN(jrt.Long_Cast(na_351)).LongValue__J(); var n1_354 int64 = na_352; if n1_354 == 0 { na_335 = lang.Numbers_Quotient_O_J__Number_NoInit(na_351, na_352) } else { na_335 = jrt.Long_ValueOf_J__Long_NoInit(n0_353 / n1_354).Ref() } } else { na_335 = lang.Numbers_Quotient_O_J__Number_NoInit(na_351, na_352) }; var tmp56 bool; var tmp57 bool; tmp57 = jrt.Long_InstanceOf(na_334); if tmp57 { tmp57 = jrt.Long_InstanceOf(na_335) }; tmp56 = tmp57; if tmp56 { var n0_356 int64 = jrt.NN(jrt.Long_Cast(na_334)).LongValue__J(); var n1_357 int64 = jrt.NN(jrt.Long_Cast(na_335)).LongValue__J(); var nr_358 int64 = n0_356 - n1_357; var tmp58 bool; var tmp59 bool; tmp59 = !(n1_357 == -9223372036854775808); if tmp59 { tmp59 = (n0_356^n1_357)&(n0_356^nr_358) >= 0 }; tmp58 = tmp59; if tmp58 { na_333 = jrt.Long_ValueOf_J__Long_NoInit(nr_358).Ref() } else { na_333 = lang.Numbers_Minus_O_O__Number_NoInit(na_334, na_335) } } else { var tmp60 bool; var tmp61 bool; tmp61 = jrt.Double_InstanceOf(na_334); if tmp61 { tmp61 = jrt.Double_InstanceOf(na_335) }; tmp60 = tmp61; if tmp60 { var n0_356_2 float64 = jrt.NN(jrt.Double_Cast(na_334)).DoubleValue__D(); var n1_357_2 float64 = jrt.NN(jrt.Double_Cast(na_335)).DoubleValue__D(); na_333 = jrt.Double_ValueOf_D__Double_NoInit(n0_356_2 + -n1_357_2).Ref() } else { na_333 = lang.Numbers_Minus_O_O__Number_NoInit(na_334, na_335) } }; var tmp62 bool; var tmp63 bool; tmp63 = jrt.Long_InstanceOf(na_332); if tmp63 { tmp63 = jrt.Long_InstanceOf(na_333) }; tmp62 = tmp63; if tmp62 { var n0_359 int64 = jrt.NN(jrt.Long_Cast(na_332)).LongValue__J(); var n1_360 int64 = jrt.NN(jrt.Long_Cast(na_333)).LongValue__J(); var nr_361 int64 = n0_359 - n1_360; var tmp64 bool; var tmp65 bool; tmp65 = !(n1_360 == -9223372036854775808); if tmp65 { tmp65 = (n0_359^n1_360)&(n0_359^nr_361) >= 0 }; tmp64 = tmp65; if tmp64 { doy__7 = jrt.Long_ValueOf_J__Long_NoInit(nr_361).Ref() } else { doy__7 = lang.Numbers_Minus_O_O__Number_NoInit(na_332, na_333) } } else { var tmp66 bool; var tmp67 bool; tmp67 = jrt.Double_InstanceOf(na_332); if tmp67 { tmp67 = jrt.Double_InstanceOf(na_333) }; tmp66 = tmp67; if tmp66 { var n0_359_2 float64 = jrt.NN(jrt.Double_Cast(na_332)).DoubleValue__D(); var n1_360_2 float64 = jrt.NN(jrt.Double_Cast(na_333)).DoubleValue__D(); doy__7 = jrt.Double_ValueOf_D__Double_NoInit(n0_359_2 + -n1_360_2).Ref() } else { doy__7 = lang.Numbers_Minus_O_O__Number_NoInit(na_332, na_333) } }
//line :182:1
		var mp__8 any; var na_362 any; var na_364 any
		var na_366 int64 = 5
		var na_367 any = doy__7




		if jrt.Long_InstanceOf(na_367) { var n0_368 int64 = na_366; var n1_369 int64 = jrt.NN(jrt.Long_Cast(na_367)).LongValue__J(); var nr_370 int64 = n0_368 * n1_369; var tmp68 bool; var tmp69 bool; var tmp70 bool; var tmp71 bool; tmp71 = n0_368 == -9223372036854775808; if tmp71 { tmp71 = n1_369 < 0 }; tmp70 = tmp71; tmp69 = !tmp70; if tmp69 { var tmp72 bool; tmp72 = n1_369 == 0; if !tmp72 { tmp72 = nr_370/n1_369 == n0_368 }; tmp69 = tmp72 }; tmp68 = tmp69; if tmp68 { na_364 = jrt.Long_ValueOf_J__Long_NoInit(nr_370).Ref() } else { na_364 = lang.Numbers_Multiply_J_O__Number_NoInit(na_366, na_367) } } else { na_364 = lang.Numbers_Multiply_J_O__Number_NoInit(na_366, na_367) }; var na_365 int64 = 2; if jrt.Long_InstanceOf(na_364) { var n0_371 int64 = jrt.NN(jrt.Long_Cast(na_364)).LongValue__J(); var n1_372 int64 = na_365; var nr_373 int64 = n0_371 + n1_372; if (n0_371^nr_373)&(n1_372^nr_373) >= 0 { na_362 = jrt.Long_ValueOf_J__Long_NoInit(nr_373).Ref() } else { na_362 = lang.Numbers_Add_O_J__Number_NoInit(na_364, na_365) } } else { na_362 = lang.Numbers_Add_O_J__Number_NoInit(na_364, na_365) }; var na_363 int64 = 153; if jrt.Long_InstanceOf(na_362) { var n0_374 int64 = jrt.NN(jrt.Long_Cast(na_362)).LongValue__J(); var n1_375 int64 = na_363; if n1_375 == 0 { mp__8 = lang.Numbers_Quotient_O_J__Number_NoInit(na_362, na_363) } else { mp__8 = jrt.Long_ValueOf_J__Long_NoInit(n0_374 / n1_375).Ref() } } else { mp__8 = lang.Numbers_Quotient_O_J__Number_NoInit(na_362, na_363) }
//line :182:1
		var d__9 any; var na_377 any; var na_378 any = doy__7; var na_379 any; var na_380 any; var na_382 any
		var na_384 int64 = 153
		var na_385 any = mp__8





		if jrt.Long_InstanceOf(na_385) { var n0_386 int64 = na_384; var n1_387 int64 = jrt.NN(jrt.Long_Cast(na_385)).LongValue__J(); var nr_388 int64 = n0_386 * n1_387; var tmp73 bool; var tmp74 bool; var tmp75 bool; var tmp76 bool; tmp76 = n0_386 == -9223372036854775808; if tmp76 { tmp76 = n1_387 < 0 }; tmp75 = tmp76; tmp74 = !tmp75; if tmp74 { var tmp77 bool; tmp77 = n1_387 == 0; if !tmp77 { tmp77 = nr_388/n1_387 == n0_386 }; tmp74 = tmp77 }; tmp73 = tmp74; if tmp73 { na_382 = jrt.Long_ValueOf_J__Long_NoInit(nr_388).Ref() } else { na_382 = lang.Numbers_Multiply_J_O__Number_NoInit(na_384, na_385) } } else { na_382 = lang.Numbers_Multiply_J_O__Number_NoInit(na_384, na_385) }; var na_383 int64 = 2; if jrt.Long_InstanceOf(na_382) { var n0_389 int64 = jrt.NN(jrt.Long_Cast(na_382)).LongValue__J(); var n1_390 int64 = na_383; var nr_391 int64 = n0_389 + n1_390; if (n0_389^nr_391)&(n1_390^nr_391) >= 0 { na_380 = jrt.Long_ValueOf_J__Long_NoInit(nr_391).Ref() } else { na_380 = lang.Numbers_Add_O_J__Number_NoInit(na_382, na_383) } } else { na_380 = lang.Numbers_Add_O_J__Number_NoInit(na_382, na_383) }; var na_381 int64 = 5; if jrt.Long_InstanceOf(na_380) { var n0_392 int64 = jrt.NN(jrt.Long_Cast(na_380)).LongValue__J(); var n1_393 int64 = na_381; if n1_393 == 0 { na_379 = lang.Numbers_Quotient_O_J__Number_NoInit(na_380, na_381) } else { na_379 = jrt.Long_ValueOf_J__Long_NoInit(n0_392 / n1_393).Ref() } } else { na_379 = lang.Numbers_Quotient_O_J__Number_NoInit(na_380, na_381) }; var tmp78 bool; var tmp79 bool; tmp79 = jrt.Long_InstanceOf(na_378); if tmp79 { tmp79 = jrt.Long_InstanceOf(na_379) }; tmp78 = tmp79; if tmp78 { var n0_395 int64 = jrt.NN(jrt.Long_Cast(na_378)).LongValue__J(); var n1_396 int64 = jrt.NN(jrt.Long_Cast(na_379)).LongValue__J(); var nr_397 int64 = n0_395 - n1_396; var tmp80 bool; var tmp81 bool; tmp81 = !(n1_396 == -9223372036854775808); if tmp81 { tmp81 = (n0_395^n1_396)&(n0_395^nr_397) >= 0 }; tmp80 = tmp81; if tmp80 { na_377 = jrt.Long_ValueOf_J__Long_NoInit(nr_397).Ref() } else { na_377 = lang.Numbers_Minus_O_O__Number_NoInit(na_378, na_379) } } else { var tmp82 bool; var tmp83 bool; tmp83 = jrt.Double_InstanceOf(na_378); if tmp83 { tmp83 = jrt.Double_InstanceOf(na_379) }; tmp82 = tmp83; if tmp82 { var n0_395_2 float64 = jrt.NN(jrt.Double_Cast(na_378)).DoubleValue__D(); var n1_396_2 float64 = jrt.NN(jrt.Double_Cast(na_379)).DoubleValue__D(); na_377 = jrt.Double_ValueOf_D__Double_NoInit(n0_395_2 + -n1_396_2).Ref() } else { na_377 = lang.Numbers_Minus_O_O__Number_NoInit(na_378, na_379) } }; if jrt.Long_InstanceOf(na_377) { var n0_398 int64 = jrt.NN(jrt.Long_Cast(na_377)).LongValue__J(); if n0_398 == 9223372036854775807 { d__9 = lang.Numbers_Inc_O__Number_NoInit(na_377) } else { d__9 = jrt.Long_ValueOf_J__Long_NoInit(n0_398 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_377) { var n0_398_2 float64 = jrt.NN(jrt.Double_Cast(na_377)).DoubleValue__D(); d__9 = jrt.Double_ValueOf_D__Double_NoInit(n0_398_2 + 1.0).Ref() } else { d__9 = lang.Numbers_Inc_O__Number_NoInit(na_377) } }
//line :182:1
		var m__10 any; var tmp84 bool
		var na_399 any = mp__8
		var na_400 int64 = 10






		if jrt.Long_InstanceOf(na_399) { var n0_401 int64 = jrt.NN(jrt.Long_Cast(na_399)).LongValue__J(); var n1_402 int64 = na_400; tmp84 = n0_401 < n1_402 } else { tmp84 = lang.Numbers_Lt_O_J__Z_NoInit(na_399, na_400) }; if tmp84 { var na_404 any = mp__8; var na_405 int64 = 3; if jrt.Long_InstanceOf(na_404) { var n0_406 int64 = jrt.NN(jrt.Long_Cast(na_404)).LongValue__J(); var n1_407 int64 = na_405; var nr_408 int64 = n0_406 + n1_407; if (n0_406^nr_408)&(n1_407^nr_408) >= 0 { m__10 = jrt.Long_ValueOf_J__Long_NoInit(nr_408).Ref() } else { m__10 = lang.Numbers_Add_O_J__Number_NoInit(na_404, na_405) } } else { m__10 = lang.Numbers_Add_O_J__Number_NoInit(na_404, na_405) } } else { var na_409 any = mp__8; var na_410 int64 = 9; if jrt.Long_InstanceOf(na_409) { var n0_411 int64 = jrt.NN(jrt.Long_Cast(na_409)).LongValue__J(); var n1_412 int64 = na_410; var nr_413 int64 = n0_411 - n1_412; var tmp85 bool; var tmp86 bool; tmp86 = !(n1_412 == -9223372036854775808); if tmp86 { tmp86 = (n0_411^n1_412)&(n0_411^nr_413) >= 0 }; tmp85 = tmp86; if tmp85 { m__10 = jrt.Long_ValueOf_J__Long_NoInit(nr_413).Ref() } else { m__10 = lang.Numbers_Minus_O_J__Number_NoInit(na_409, na_410) } } else { m__10 = lang.Numbers_Minus_O_J__Number_NoInit(na_409, na_410) } }
//line :182:1
		var tmp87 any; var tmp88 bool
		var na_454 any = m__10
		var na_455 int64 = 2







		if jrt.Long_InstanceOf(na_454) { var n0_456 int64 = jrt.NN(jrt.Long_Cast(na_454)).LongValue__J(); var n1_457 int64 = na_455; tmp88 = n0_456 <= n1_457 } else { tmp88 = lang.Numbers_Lte_O_J__Z_NoInit(na_454, na_455) }; if tmp88 { var na_459 any = y__6; if jrt.Long_InstanceOf(na_459) { var n0_460 int64 = jrt.NN(jrt.Long_Cast(na_459)).LongValue__J(); if n0_460 == 9223372036854775807 { tmp87 = lang.Numbers_Inc_O__Number_NoInit(na_459) } else { tmp87 = jrt.Long_ValueOf_J__Long_NoInit(n0_460 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_459) { var n0_460_2 float64 = jrt.NN(jrt.Double_Cast(na_459)).DoubleValue__D(); tmp87 = jrt.Double_ValueOf_D__Double_NoInit(n0_460_2 + 1.0).Ref() } else { tmp87 = lang.Numbers_Inc_O__Number_NoInit(na_459) } } } else { tmp87 = y__6 }
//line :182:1
		return lang.Tuple_Create_O_O_O__IPersistentVector(tmp87, m__10, d__9) } else { var c__2 any; var na_414 any
			var na_416 any = z__0
			var na_417 int64 = 2440588








			if jrt.Long_InstanceOf(na_416) { var n0_418 int64 = jrt.NN(jrt.Long_Cast(na_416)).LongValue__J(); var n1_419 int64 = na_417; var nr_420 int64 = n0_418 + n1_419; if (n0_418^nr_420)&(n1_419^nr_420) >= 0 { na_414 = jrt.Long_ValueOf_J__Long_NoInit(nr_420).Ref() } else { na_414 = lang.Numbers_Add_O_J__Number_NoInit(na_416, na_417) } } else { na_414 = lang.Numbers_Add_O_J__Number_NoInit(na_416, na_417) }; var na_415 int64 = 32082; if jrt.Long_InstanceOf(na_414) { var n0_421 int64 = jrt.NN(jrt.Long_Cast(na_414)).LongValue__J(); var n1_422 int64 = na_415; var nr_423 int64 = n0_421 + n1_422; if (n0_421^nr_423)&(n1_422^nr_423) >= 0 { c__2 = jrt.Long_ValueOf_J__Long_NoInit(nr_423).Ref() } else { c__2 = lang.Numbers_Add_O_J__Number_NoInit(na_414, na_415) } } else { c__2 = lang.Numbers_Add_O_J__Number_NoInit(na_414, na_415) }
//line :182:1
			var d__3 int64; var tmp89 jrt.Number_I; var na_424 any
			var na_426 int64 = 4
			var na_427 any = c__2









			if jrt.Long_InstanceOf(na_427) { var n0_428 int64 = na_426; var n1_429 int64 = jrt.NN(jrt.Long_Cast(na_427)).LongValue__J(); var nr_430 int64 = n0_428 * n1_429; var tmp90 bool; var tmp91 bool; var tmp92 bool; var tmp93 bool; tmp93 = n0_428 == -9223372036854775808; if tmp93 { tmp93 = n1_429 < 0 }; tmp92 = tmp93; tmp91 = !tmp92; if tmp91 { var tmp94 bool; tmp94 = n1_429 == 0; if !tmp94 { tmp94 = nr_430/n1_429 == n0_428 }; tmp91 = tmp94 }; tmp90 = tmp91; if tmp90 { na_424 = jrt.Long_ValueOf_J__Long_NoInit(nr_430).Ref() } else { na_424 = lang.Numbers_Multiply_J_O__Number_NoInit(na_426, na_427) } } else { na_424 = lang.Numbers_Multiply_J_O__Number_NoInit(na_426, na_427) }; var na_425 int64 = 3; if jrt.Long_InstanceOf(na_424) { var n0_431 int64 = jrt.NN(jrt.Long_Cast(na_424)).LongValue__J(); var n1_432 int64 = na_425; var nr_433 int64 = n0_431 + n1_432; if (n0_431^nr_433)&(n1_432^nr_433) >= 0 { tmp89 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_433)) } else { tmp89 = lang.Numbers_Add_O_J__Number_NoInit(na_424, na_425) } } else { tmp89 = lang.Numbers_Add_O_J__Number_NoInit(na_424, na_425) }; d__3 = jrt.Math_FloorDiv_J_J__J(lang.RT_LongCast_O__J_NoInit(tmp89), 1461)
//line :182:1
			var e__4 any; var na_434 any = c__2; var na_435 int64 = jrt.Math_FloorDiv_J_J__J(lang.RT_LongCast_J__J_NoInit(lang.Numbers_Multiply_J_J__J_NoInit(1461, d__3)), 4)












			if jrt.Long_InstanceOf(na_434) { var n0_436 int64 = jrt.NN(jrt.Long_Cast(na_434)).LongValue__J(); var n1_437 int64 = na_435; var nr_438 int64 = n0_436 - n1_437; var tmp95 bool; var tmp96 bool; tmp96 = !(n1_437 == -9223372036854775808); if tmp96 { tmp96 = (n0_436^n1_437)&(n0_436^nr_438) >= 0 }; tmp95 = tmp96; if tmp95 { e__4 = jrt.Long_ValueOf_J__Long_NoInit(nr_438).Ref() } else { e__4 = lang.Numbers_Minus_O_J__Number_NoInit(na_434, na_435) } } else { e__4 = lang.Numbers_Minus_O_J__Number_NoInit(na_434, na_435) }
//line :182:1
			var m__5 any; var na_439 any; var na_441 any
			var na_443 int64 = 5
			var na_444 any = e__4











			if jrt.Long_InstanceOf(na_444) { var n0_445 int64 = na_443; var n1_446 int64 = jrt.NN(jrt.Long_Cast(na_444)).LongValue__J(); var nr_447 int64 = n0_445 * n1_446; var tmp97 bool; var tmp98 bool; var tmp99 bool; var tmp100 bool; tmp100 = n0_445 == -9223372036854775808; if tmp100 { tmp100 = n1_446 < 0 }; tmp99 = tmp100; tmp98 = !tmp99; if tmp98 { var tmp101 bool; tmp101 = n1_446 == 0; if !tmp101 { tmp101 = nr_447/n1_446 == n0_445 }; tmp98 = tmp101 }; tmp97 = tmp98; if tmp97 { na_441 = jrt.Long_ValueOf_J__Long_NoInit(nr_447).Ref() } else { na_441 = lang.Numbers_Multiply_J_O__Number_NoInit(na_443, na_444) } } else { na_441 = lang.Numbers_Multiply_J_O__Number_NoInit(na_443, na_444) }; var na_442 int64 = 2; if jrt.Long_InstanceOf(na_441) { var n0_448 int64 = jrt.NN(jrt.Long_Cast(na_441)).LongValue__J(); var n1_449 int64 = na_442; var nr_450 int64 = n0_448 + n1_449; if (n0_448^nr_450)&(n1_449^nr_450) >= 0 { na_439 = jrt.Long_ValueOf_J__Long_NoInit(nr_450).Ref() } else { na_439 = lang.Numbers_Add_O_J__Number_NoInit(na_441, na_442) } } else { na_439 = lang.Numbers_Add_O_J__Number_NoInit(na_441, na_442) }; var na_440 int64 = 153; if jrt.Long_InstanceOf(na_439) { var n0_451 int64 = jrt.NN(jrt.Long_Cast(na_439)).LongValue__J(); var n1_452 int64 = na_440; if n1_452 == 0 { m__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_439, na_440) } else { m__5 = jrt.Long_ValueOf_J__Long_NoInit(n0_451 / n1_452).Ref() } } else { m__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_439, na_440) }
//line :182:1
			var tmp102 jrt.Number_I; var na_461 int64 = lang.Numbers_Minus_J_J__J_NoInit(d__3, 4800); var na_462 any
			var na_463 any = m__5
			var na_464 int64 = 10












			if jrt.Long_InstanceOf(na_463) { var n0_465 int64 = jrt.NN(jrt.Long_Cast(na_463)).LongValue__J(); var n1_466 int64 = na_464; if n1_466 == 0 { na_462 = lang.Numbers_Quotient_O_J__Number_NoInit(na_463, na_464) } else { na_462 = jrt.Long_ValueOf_J__Long_NoInit(n0_465 / n1_466).Ref() } } else { na_462 = lang.Numbers_Quotient_O_J__Number_NoInit(na_463, na_464) }; if jrt.Long_InstanceOf(na_462) { var n0_468 int64 = na_461; var n1_469 int64 = jrt.NN(jrt.Long_Cast(na_462)).LongValue__J(); var nr_470 int64 = n0_468 + n1_469; if (n0_468^nr_470)&(n1_469^nr_470) >= 0 { tmp102 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_470)) } else { tmp102 = lang.Numbers_Add_J_O__Number_NoInit(na_461, na_462) } } else { tmp102 = lang.Numbers_Add_J_O__Number_NoInit(na_461, na_462) }
//line :182:1
			var tmp103 any = tmp102; var tmp104 jrt.Number_I; var na_471 any
			var na_473 any = m__5
			var na_474 int64 = 3













			if jrt.Long_InstanceOf(na_473) { var n0_475 int64 = jrt.NN(jrt.Long_Cast(na_473)).LongValue__J(); var n1_476 int64 = na_474; var nr_477 int64 = n0_475 + n1_476; if (n0_475^nr_477)&(n1_476^nr_477) >= 0 { na_471 = jrt.Long_ValueOf_J__Long_NoInit(nr_477).Ref() } else { na_471 = lang.Numbers_Add_O_J__Number_NoInit(na_473, na_474) } } else { na_471 = lang.Numbers_Add_O_J__Number_NoInit(na_473, na_474) }; var na_472 any; var na_478 int64 = 12; var na_479 any; var na_480 any = m__5; var na_481 int64 = 10; if jrt.Long_InstanceOf(na_480) { var n0_482 int64 = jrt.NN(jrt.Long_Cast(na_480)).LongValue__J(); var n1_483 int64 = na_481; if n1_483 == 0 { na_479 = lang.Numbers_Quotient_O_J__Number_NoInit(na_480, na_481) } else { na_479 = jrt.Long_ValueOf_J__Long_NoInit(n0_482 / n1_483).Ref() } } else { na_479 = lang.Numbers_Quotient_O_J__Number_NoInit(na_480, na_481) }; if jrt.Long_InstanceOf(na_479) { var n0_485 int64 = na_478; var n1_486 int64 = jrt.NN(jrt.Long_Cast(na_479)).LongValue__J(); var nr_487 int64 = n0_485 * n1_486; var tmp105 bool; var tmp106 bool; var tmp107 bool; var tmp108 bool; tmp108 = n0_485 == -9223372036854775808; if tmp108 { tmp108 = n1_486 < 0 }; tmp107 = tmp108; tmp106 = !tmp107; if tmp106 { var tmp109 bool; tmp109 = n1_486 == 0; if !tmp109 { tmp109 = nr_487/n1_486 == n0_485 }; tmp106 = tmp109 }; tmp105 = tmp106; if tmp105 { na_472 = jrt.Long_ValueOf_J__Long_NoInit(nr_487).Ref() } else { na_472 = lang.Numbers_Multiply_J_O__Number_NoInit(na_478, na_479) } } else { na_472 = lang.Numbers_Multiply_J_O__Number_NoInit(na_478, na_479) }; var tmp110 bool; var tmp111 bool; tmp111 = jrt.Long_InstanceOf(na_471); if tmp111 { tmp111 = jrt.Long_InstanceOf(na_472) }; tmp110 = tmp111; if tmp110 { var n0_488 int64 = jrt.NN(jrt.Long_Cast(na_471)).LongValue__J(); var n1_489 int64 = jrt.NN(jrt.Long_Cast(na_472)).LongValue__J(); var nr_490 int64 = n0_488 - n1_489; var tmp112 bool; var tmp113 bool; tmp113 = !(n1_489 == -9223372036854775808); if tmp113 { tmp113 = (n0_488^n1_489)&(n0_488^nr_490) >= 0 }; tmp112 = tmp113; if tmp112 { tmp104 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_490)) } else { tmp104 = lang.Numbers_Minus_O_O__Number_NoInit(na_471, na_472) } } else { var tmp114 bool; var tmp115 bool; tmp115 = jrt.Double_InstanceOf(na_471); if tmp115 { tmp115 = jrt.Double_InstanceOf(na_472) }; tmp114 = tmp115; if tmp114 { var n0_488_2 float64 = jrt.NN(jrt.Double_Cast(na_471)).DoubleValue__D(); var n1_489_2 float64 = jrt.NN(jrt.Double_Cast(na_472)).DoubleValue__D(); tmp104 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_488_2 + -n1_489_2)) } else { tmp104 = lang.Numbers_Minus_O_O__Number_NoInit(na_471, na_472) } }
//line :182:1
			var tmp116 any = tmp104; var tmp117 jrt.Number_I; var na_491 any; var na_492 any = e__4; var na_493 any; var na_494 any; var na_496 any
			var na_498 int64 = 153
			var na_499 any = m__5














			if jrt.Long_InstanceOf(na_499) { var n0_500 int64 = na_498; var n1_501 int64 = jrt.NN(jrt.Long_Cast(na_499)).LongValue__J(); var nr_502 int64 = n0_500 * n1_501; var tmp118 bool; var tmp119 bool; var tmp120 bool; var tmp121 bool; tmp121 = n0_500 == -9223372036854775808; if tmp121 { tmp121 = n1_501 < 0 }; tmp120 = tmp121; tmp119 = !tmp120; if tmp119 { var tmp122 bool; tmp122 = n1_501 == 0; if !tmp122 { tmp122 = nr_502/n1_501 == n0_500 }; tmp119 = tmp122 }; tmp118 = tmp119; if tmp118 { na_496 = jrt.Long_ValueOf_J__Long_NoInit(nr_502).Ref() } else { na_496 = lang.Numbers_Multiply_J_O__Number_NoInit(na_498, na_499) } } else { na_496 = lang.Numbers_Multiply_J_O__Number_NoInit(na_498, na_499) }; var na_497 int64 = 2; if jrt.Long_InstanceOf(na_496) { var n0_503 int64 = jrt.NN(jrt.Long_Cast(na_496)).LongValue__J(); var n1_504 int64 = na_497; var nr_505 int64 = n0_503 + n1_504; if (n0_503^nr_505)&(n1_504^nr_505) >= 0 { na_494 = jrt.Long_ValueOf_J__Long_NoInit(nr_505).Ref() } else { na_494 = lang.Numbers_Add_O_J__Number_NoInit(na_496, na_497) } } else { na_494 = lang.Numbers_Add_O_J__Number_NoInit(na_496, na_497) }; var na_495 int64 = 5; if jrt.Long_InstanceOf(na_494) { var n0_506 int64 = jrt.NN(jrt.Long_Cast(na_494)).LongValue__J(); var n1_507 int64 = na_495; if n1_507 == 0 { na_493 = lang.Numbers_Quotient_O_J__Number_NoInit(na_494, na_495) } else { na_493 = jrt.Long_ValueOf_J__Long_NoInit(n0_506 / n1_507).Ref() } } else { na_493 = lang.Numbers_Quotient_O_J__Number_NoInit(na_494, na_495) }; var tmp123 bool; var tmp124 bool; tmp124 = jrt.Long_InstanceOf(na_492); if tmp124 { tmp124 = jrt.Long_InstanceOf(na_493) }; tmp123 = tmp124; if tmp123 { var n0_509 int64 = jrt.NN(jrt.Long_Cast(na_492)).LongValue__J(); var n1_510 int64 = jrt.NN(jrt.Long_Cast(na_493)).LongValue__J(); var nr_511 int64 = n0_509 - n1_510; var tmp125 bool; var tmp126 bool; tmp126 = !(n1_510 == -9223372036854775808); if tmp126 { tmp126 = (n0_509^n1_510)&(n0_509^nr_511) >= 0 }; tmp125 = tmp126; if tmp125 { na_491 = jrt.Long_ValueOf_J__Long_NoInit(nr_511).Ref() } else { na_491 = lang.Numbers_Minus_O_O__Number_NoInit(na_492, na_493) } } else { var tmp127 bool; var tmp128 bool; tmp128 = jrt.Double_InstanceOf(na_492); if tmp128 { tmp128 = jrt.Double_InstanceOf(na_493) }; tmp127 = tmp128; if tmp127 { var n0_509_2 float64 = jrt.NN(jrt.Double_Cast(na_492)).DoubleValue__D(); var n1_510_2 float64 = jrt.NN(jrt.Double_Cast(na_493)).DoubleValue__D(); na_491 = jrt.Double_ValueOf_D__Double_NoInit(n0_509_2 + -n1_510_2).Ref() } else { na_491 = lang.Numbers_Minus_O_O__Number_NoInit(na_492, na_493) } }; if jrt.Long_InstanceOf(na_491) { var n0_512 int64 = jrt.NN(jrt.Long_Cast(na_491)).LongValue__J(); if n0_512 == 9223372036854775807 { tmp117 = lang.Numbers_Inc_O__Number_NoInit(na_491) } else { tmp117 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_512 + 1)) } } else { if jrt.Double_InstanceOf(na_491) { var n0_512_2 float64 = jrt.NN(jrt.Double_Cast(na_491)).DoubleValue__D(); tmp117 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_512_2 + 1.0)) } else { tmp117 = lang.Numbers_Inc_O__Number_NoInit(na_491) } }
//line :182:1
			return lang.Tuple_Create_O_O_O__IPersistentVector(tmp103, tmp116, tmp117)
		}
}
















func A_arbace_instant_civil__GT_days_A_New() *A_arbace_instant_civil__GT_days_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_civil__GT_days_A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_instant_civil__GT_days_A) Ctor() {}
//line :201:1
func (t *A_arbace_instant_civil__GT_days_A) Invoke_O_O_O_O__O(self, y__0, m__1, d__2 any) any { var g__4 any; var y__4 any; var tmp1 bool; var na_513 any = m__1; var na_514 int64 = 2; if



	jrt.Long_InstanceOf(na_513) { var n0_515 int64 = jrt.NN(jrt.Long_Cast(na_513)).LongValue__J(); var n1_516 int64 = na_514; tmp1 = n0_515 <= n1_516 } else { tmp1 = lang.Numbers_Lte_O_J__Z_NoInit(na_513, na_514) }; if tmp1 { var na_518 any = y__0; if jrt.Long_InstanceOf(na_518) { var n0_519 int64 = jrt.NN(jrt.Long_Cast(na_518)).LongValue__J(); if n0_519 == -9223372036854775808 { y__4 = lang.Numbers_Dec_O__Number_NoInit(na_518) } else { y__4 = jrt.Long_ValueOf_J__Long_NoInit(n0_519 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_518) { var n0_519_2 float64 = jrt.NN(jrt.Double_Cast(na_518)).DoubleValue__D(); y__4 = jrt.Double_ValueOf_D__Double_NoInit(n0_519_2 - 1.0).Ref() } else { y__4 = lang.Numbers_Dec_O__Number_NoInit(na_518) } } } else { y__4 = y__0 }; var era__5 any; var na_520 any; var tmp2 bool; var na_522 any = y__4; var na_523 int64 = 0; if
	jrt.Long_InstanceOf(na_522) { var n0_524 int64 = jrt.NN(jrt.Long_Cast(na_522)).LongValue__J(); var n1_525 int64 = na_523; tmp2 = n0_524 >= n1_525 } else { tmp2 = lang.Numbers_Gte_O_J__Z_NoInit(na_522, na_523) }; if tmp2 { na_520 = y__4 } else { var na_527 any = y__4; var na_528 int64 = 399; if jrt.Long_InstanceOf(na_527) { var n0_529 int64 = jrt.NN(jrt.Long_Cast(na_527)).LongValue__J(); var n1_530 int64 = na_528; var nr_531 int64 = n0_529 - n1_530; var tmp3 bool; var tmp4 bool; tmp4 = !(n1_530 == -9223372036854775808); if tmp4 { tmp4 = (n0_529^n1_530)&(n0_529^nr_531) >= 0 }; tmp3 = tmp4; if tmp3 { na_520 = jrt.Long_ValueOf_J__Long_NoInit(nr_531).Ref() } else { na_520 = lang.Numbers_Minus_O_J__Number_NoInit(na_527, na_528) } } else { na_520 = lang.Numbers_Minus_O_J__Number_NoInit(na_527, na_528) } }; var na_521 int64 = 400; if jrt.Long_InstanceOf(na_520) { var n0_532 int64 = jrt.NN(jrt.Long_Cast(na_520)).LongValue__J(); var n1_533 int64 = na_521; if n1_533 == 0 { era__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_520, na_521) } else { era__5 = jrt.Long_ValueOf_J__Long_NoInit(n0_532 / n1_533).Ref() } } else { era__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_520, na_521) }; var yoe__6 any; var na_535 any = y__4; var na_536 any; var na_537 any = era__5; var na_538 int64 = 400; if
	jrt.Long_InstanceOf(na_537) { var n0_539 int64 = jrt.NN(jrt.Long_Cast(na_537)).LongValue__J(); var n1_540 int64 = na_538; var nr_541 int64 = n0_539 * n1_540; var tmp5 bool; var tmp6 bool; var tmp7 bool; var tmp8 bool; tmp8 = n0_539 == -9223372036854775808; if tmp8 { tmp8 = n1_540 < 0 }; tmp7 = tmp8; tmp6 = !tmp7; if tmp6 { var tmp9 bool; tmp9 = n1_540 == 0; if !tmp9 { tmp9 = nr_541/n1_540 == n0_539 }; tmp6 = tmp9 }; tmp5 = tmp6; if tmp5 { na_536 = jrt.Long_ValueOf_J__Long_NoInit(nr_541).Ref() } else { na_536 = lang.Numbers_Multiply_O_J__Number_NoInit(na_537, na_538) } } else { na_536 = lang.Numbers_Multiply_O_J__Number_NoInit(na_537, na_538) }; var tmp10 bool; var tmp11 bool; tmp11 = jrt.Long_InstanceOf(na_535); if tmp11 { tmp11 = jrt.Long_InstanceOf(na_536) }; tmp10 = tmp11; if tmp10 { var n0_542 int64 = jrt.NN(jrt.Long_Cast(na_535)).LongValue__J(); var n1_543 int64 = jrt.NN(jrt.Long_Cast(na_536)).LongValue__J(); var nr_544 int64 = n0_542 - n1_543; var tmp12 bool; var tmp13 bool; tmp13 = !(n1_543 == -9223372036854775808); if tmp13 { tmp13 = (n0_542^n1_543)&(n0_542^nr_544) >= 0 }; tmp12 = tmp13; if tmp12 { yoe__6 = jrt.Long_ValueOf_J__Long_NoInit(nr_544).Ref() } else { yoe__6 = lang.Numbers_Minus_O_O__Number_NoInit(na_535, na_536) } } else { var tmp14 bool; var tmp15 bool; tmp15 = jrt.Double_InstanceOf(na_535); if tmp15 { tmp15 = jrt.Double_InstanceOf(na_536) }; tmp14 = tmp15; if tmp14 { var n0_542_2 float64 = jrt.NN(jrt.Double_Cast(na_535)).DoubleValue__D(); var n1_543_2 float64 = jrt.NN(jrt.Double_Cast(na_536)).DoubleValue__D(); yoe__6 = jrt.Double_ValueOf_D__Double_NoInit(n0_542_2 + -n1_543_2).Ref() } else { yoe__6 = lang.Numbers_Minus_O_O__Number_NoInit(na_535, na_536) } }; var doy__7 any; var na_545 any; var na_547 any; var na_549 any; var na_551 int64 = 153; var na_552 any; var tmp16 bool; var na_553 any = m__1; var na_554 int64 = 2; if
	jrt.Long_InstanceOf(na_553) { var n0_555 int64 = jrt.NN(jrt.Long_Cast(na_553)).LongValue__J(); var n1_556 int64 = na_554; tmp16 = n0_555 > n1_556 } else { tmp16 = lang.Numbers_Gt_O_J__Z_NoInit(na_553, na_554) }; if tmp16 { var na_558 any = m__1; var na_559 int64 = 3; if jrt.Long_InstanceOf(na_558) { var n0_560 int64 = jrt.NN(jrt.Long_Cast(na_558)).LongValue__J(); var n1_561 int64 = na_559; var nr_562 int64 = n0_560 - n1_561; var tmp17 bool; var tmp18 bool; tmp18 = !(n1_561 == -9223372036854775808); if tmp18 { tmp18 = (n0_560^n1_561)&(n0_560^nr_562) >= 0 }; tmp17 = tmp18; if tmp17 { na_552 = jrt.Long_ValueOf_J__Long_NoInit(nr_562).Ref() } else { na_552 = lang.Numbers_Minus_O_J__Number_NoInit(na_558, na_559) } } else { na_552 = lang.Numbers_Minus_O_J__Number_NoInit(na_558, na_559) } } else { var na_563 any = m__1; var na_564 int64 = 9; if jrt.Long_InstanceOf(na_563) { var n0_565 int64 = jrt.NN(jrt.Long_Cast(na_563)).LongValue__J(); var n1_566 int64 = na_564; var nr_567 int64 = n0_565 + n1_566; if (n0_565^nr_567)&(n1_566^nr_567) >= 0 { na_552 = jrt.Long_ValueOf_J__Long_NoInit(nr_567).Ref() } else { na_552 = lang.Numbers_Add_O_J__Number_NoInit(na_563, na_564) } } else { na_552 = lang.Numbers_Add_O_J__Number_NoInit(na_563, na_564) } }; if jrt.Long_InstanceOf(na_552) { var n0_568 int64 = na_551; var n1_569 int64 = jrt.NN(jrt.Long_Cast(na_552)).LongValue__J(); var nr_570 int64 = n0_568 * n1_569; var tmp19 bool; var tmp20 bool; var tmp21 bool; var tmp22 bool; tmp22 = n0_568 == -9223372036854775808; if tmp22 { tmp22 = n1_569 < 0 }; tmp21 = tmp22; tmp20 = !tmp21; if tmp20 { var tmp23 bool; tmp23 = n1_569 == 0; if !tmp23 { tmp23 = nr_570/n1_569 == n0_568 }; tmp20 = tmp23 }; tmp19 = tmp20; if tmp19 { na_549 = jrt.Long_ValueOf_J__Long_NoInit(nr_570).Ref() } else { na_549 = lang.Numbers_Multiply_J_O__Number_NoInit(na_551, na_552) } } else { na_549 = lang.Numbers_Multiply_J_O__Number_NoInit(na_551, na_552) }; var na_550 int64 = 2; if jrt.Long_InstanceOf(na_549) { var n0_571 int64 = jrt.NN(jrt.Long_Cast(na_549)).LongValue__J(); var n1_572 int64 = na_550; var nr_573 int64 = n0_571 + n1_572; if (n0_571^nr_573)&(n1_572^nr_573) >= 0 { na_547 = jrt.Long_ValueOf_J__Long_NoInit(nr_573).Ref() } else { na_547 = lang.Numbers_Add_O_J__Number_NoInit(na_549, na_550) } } else { na_547 = lang.Numbers_Add_O_J__Number_NoInit(na_549, na_550) }; var na_548 int64 = 5; if jrt.Long_InstanceOf(na_547) { var n0_574 int64 = jrt.NN(jrt.Long_Cast(na_547)).LongValue__J(); var n1_575 int64 = na_548; if n1_575 == 0 { na_545 = lang.Numbers_Quotient_O_J__Number_NoInit(na_547, na_548) } else { na_545 = jrt.Long_ValueOf_J__Long_NoInit(n0_574 / n1_575).Ref() } } else { na_545 = lang.Numbers_Quotient_O_J__Number_NoInit(na_547, na_548) }; var na_546 any; var na_577 any = d__2; if jrt.Long_InstanceOf(na_577) { var n0_578 int64 = jrt.NN(jrt.Long_Cast(na_577)).LongValue__J(); if n0_578 == -9223372036854775808 { na_546 = lang.Numbers_Dec_O__Number_NoInit(na_577) } else { na_546 = jrt.Long_ValueOf_J__Long_NoInit(n0_578 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_577) { var n0_578_2 float64 = jrt.NN(jrt.Double_Cast(na_577)).DoubleValue__D(); na_546 = jrt.Double_ValueOf_D__Double_NoInit(n0_578_2 - 1.0).Ref() } else { na_546 = lang.Numbers_Dec_O__Number_NoInit(na_577) } }; var tmp24 bool; var tmp25 bool; tmp25 = jrt.Long_InstanceOf(na_545); if tmp25 { tmp25 = jrt.Long_InstanceOf(na_546) }; tmp24 = tmp25; if tmp24 { var n0_579 int64 = jrt.NN(jrt.Long_Cast(na_545)).LongValue__J(); var n1_580 int64 = jrt.NN(jrt.Long_Cast(na_546)).LongValue__J(); var nr_581 int64 = n0_579 + n1_580; if (n0_579^nr_581)&(n1_580^nr_581) >= 0 { doy__7 = jrt.Long_ValueOf_J__Long_NoInit(nr_581).Ref() } else { doy__7 = lang.Numbers_Add_O_O__Number_NoInit(na_545, na_546) } } else { var tmp26 bool; var tmp27 bool; tmp27 = jrt.Double_InstanceOf(na_545); if tmp27 { tmp27 = jrt.Double_InstanceOf(na_546) }; tmp26 = tmp27; if tmp26 { var n0_579_2 float64 = jrt.NN(jrt.Double_Cast(na_545)).DoubleValue__D(); var n1_580_2 float64 = jrt.NN(jrt.Double_Cast(na_546)).DoubleValue__D(); doy__7 = jrt.Double_ValueOf_D__Double_NoInit(n0_579_2 + n1_580_2).Ref() } else { doy__7 = lang.Numbers_Add_O_O__Number_NoInit(na_545, na_546) } }; var doe__8 any; var na_582 any; var na_584 any; var na_586 any; var na_588 any = yoe__6; var na_589 int64 = 365; if
	jrt.Long_InstanceOf(na_588) { var n0_590 int64 = jrt.NN(jrt.Long_Cast(na_588)).LongValue__J(); var n1_591 int64 = na_589; var nr_592 int64 = n0_590 * n1_591; var tmp28 bool; var tmp29 bool; var tmp30 bool; var tmp31 bool; tmp31 = n0_590 == -9223372036854775808; if tmp31 { tmp31 = n1_591 < 0 }; tmp30 = tmp31; tmp29 = !tmp30; if tmp29 { var tmp32 bool; tmp32 = n1_591 == 0; if !tmp32 { tmp32 = nr_592/n1_591 == n0_590 }; tmp29 = tmp32 }; tmp28 = tmp29; if tmp28 { na_586 = jrt.Long_ValueOf_J__Long_NoInit(nr_592).Ref() } else { na_586 = lang.Numbers_Multiply_O_J__Number_NoInit(na_588, na_589) } } else { na_586 = lang.Numbers_Multiply_O_J__Number_NoInit(na_588, na_589) }; var na_587 any; var na_593 any = yoe__6; var na_594 int64 = 4; if jrt.Long_InstanceOf(na_593) { var n0_595 int64 = jrt.NN(jrt.Long_Cast(na_593)).LongValue__J(); var n1_596 int64 = na_594; if n1_596 == 0 { na_587 = lang.Numbers_Quotient_O_J__Number_NoInit(na_593, na_594) } else { na_587 = jrt.Long_ValueOf_J__Long_NoInit(n0_595 / n1_596).Ref() } } else { na_587 = lang.Numbers_Quotient_O_J__Number_NoInit(na_593, na_594) }; var tmp33 bool; var tmp34 bool; tmp34 = jrt.Long_InstanceOf(na_586); if tmp34 { tmp34 = jrt.Long_InstanceOf(na_587) }; tmp33 = tmp34; if tmp33 { var n0_598 int64 = jrt.NN(jrt.Long_Cast(na_586)).LongValue__J(); var n1_599 int64 = jrt.NN(jrt.Long_Cast(na_587)).LongValue__J(); var nr_600 int64 = n0_598 + n1_599; if (n0_598^nr_600)&(n1_599^nr_600) >= 0 { na_584 = jrt.Long_ValueOf_J__Long_NoInit(nr_600).Ref() } else { na_584 = lang.Numbers_Add_O_O__Number_NoInit(na_586, na_587) } } else { var tmp35 bool; var tmp36 bool; tmp36 = jrt.Double_InstanceOf(na_586); if tmp36 { tmp36 = jrt.Double_InstanceOf(na_587) }; tmp35 = tmp36; if tmp35 { var n0_598_2 float64 = jrt.NN(jrt.Double_Cast(na_586)).DoubleValue__D(); var n1_599_2 float64 = jrt.NN(jrt.Double_Cast(na_587)).DoubleValue__D(); na_584 = jrt.Double_ValueOf_D__Double_NoInit(n0_598_2 + n1_599_2).Ref() } else { na_584 = lang.Numbers_Add_O_O__Number_NoInit(na_586, na_587) } }; var na_585 any = doy__7; var tmp37 bool; var tmp38 bool; tmp38 = jrt.Long_InstanceOf(na_584); if tmp38 { tmp38 = jrt.Long_InstanceOf(na_585) }; tmp37 = tmp38; if tmp37 { var n0_601 int64 = jrt.NN(jrt.Long_Cast(na_584)).LongValue__J(); var n1_602 int64 = jrt.NN(jrt.Long_Cast(na_585)).LongValue__J(); var nr_603 int64 = n0_601 + n1_602; if (n0_601^nr_603)&(n1_602^nr_603) >= 0 { na_582 = jrt.Long_ValueOf_J__Long_NoInit(nr_603).Ref() } else { na_582 = lang.Numbers_Add_O_O__Number_NoInit(na_584, na_585) } } else { var tmp39 bool; var tmp40 bool; tmp40 = jrt.Double_InstanceOf(na_584); if tmp40 { tmp40 = jrt.Double_InstanceOf(na_585) }; tmp39 = tmp40; if tmp39 { var n0_601_2 float64 = jrt.NN(jrt.Double_Cast(na_584)).DoubleValue__D(); var n1_602_2 float64 = jrt.NN(jrt.Double_Cast(na_585)).DoubleValue__D(); na_582 = jrt.Double_ValueOf_D__Double_NoInit(n0_601_2 + n1_602_2).Ref() } else { na_582 = lang.Numbers_Add_O_O__Number_NoInit(na_584, na_585) } }; var na_583 any; var na_604 any = yoe__6; var na_605 int64 = 100; if jrt.Long_InstanceOf(na_604) { var n0_606 int64 = jrt.NN(jrt.Long_Cast(na_604)).LongValue__J(); var n1_607 int64 = na_605; if n1_607 == 0 { na_583 = lang.Numbers_Quotient_O_J__Number_NoInit(na_604, na_605) } else { na_583 = jrt.Long_ValueOf_J__Long_NoInit(n0_606 / n1_607).Ref() } } else { na_583 = lang.Numbers_Quotient_O_J__Number_NoInit(na_604, na_605) }; var tmp41 bool; var tmp42 bool; tmp42 = jrt.Long_InstanceOf(na_582); if tmp42 { tmp42 = jrt.Long_InstanceOf(na_583) }; tmp41 = tmp42; if tmp41 { var n0_609 int64 = jrt.NN(jrt.Long_Cast(na_582)).LongValue__J(); var n1_610 int64 = jrt.NN(jrt.Long_Cast(na_583)).LongValue__J(); var nr_611 int64 = n0_609 - n1_610; var tmp43 bool; var tmp44 bool; tmp44 = !(n1_610 == -9223372036854775808); if tmp44 { tmp44 = (n0_609^n1_610)&(n0_609^nr_611) >= 0 }; tmp43 = tmp44; if tmp43 { doe__8 = jrt.Long_ValueOf_J__Long_NoInit(nr_611).Ref() } else { doe__8 = lang.Numbers_Minus_O_O__Number_NoInit(na_582, na_583) } } else { var tmp45 bool; var tmp46 bool; tmp46 = jrt.Double_InstanceOf(na_582); if tmp46 { tmp46 = jrt.Double_InstanceOf(na_583) }; tmp45 = tmp46; if tmp45 { var n0_609_2 float64 = jrt.NN(jrt.Double_Cast(na_582)).DoubleValue__D(); var n1_610_2 float64 = jrt.NN(jrt.Double_Cast(na_583)).DoubleValue__D(); doe__8 = jrt.Double_ValueOf_D__Double_NoInit(n0_609_2 + -n1_610_2).Ref() } else { doe__8 = lang.Numbers_Minus_O_O__Number_NoInit(na_582, na_583) } }; var na_612 any; var na_614 any; var na_616 any = era__5; var na_617 int64 = 146097; if
	jrt.Long_InstanceOf(na_616) { var n0_618 int64 = jrt.NN(jrt.Long_Cast(na_616)).LongValue__J(); var n1_619 int64 = na_617; var nr_620 int64 = n0_618 * n1_619; var tmp47 bool; var tmp48 bool; var tmp49 bool; var tmp50 bool; tmp50 = n0_618 == -9223372036854775808; if tmp50 { tmp50 = n1_619 < 0 }; tmp49 = tmp50; tmp48 = !tmp49; if tmp48 { var tmp51 bool; tmp51 = n1_619 == 0; if !tmp51 { tmp51 = nr_620/n1_619 == n0_618 }; tmp48 = tmp51 }; tmp47 = tmp48; if tmp47 { na_614 = jrt.Long_ValueOf_J__Long_NoInit(nr_620).Ref() } else { na_614 = lang.Numbers_Multiply_O_J__Number_NoInit(na_616, na_617) } } else { na_614 = lang.Numbers_Multiply_O_J__Number_NoInit(na_616, na_617) }; var na_615 any = doe__8; var tmp52 bool; var tmp53 bool; tmp53 = jrt.Long_InstanceOf(na_614); if tmp53 { tmp53 = jrt.Long_InstanceOf(na_615) }; tmp52 = tmp53; if tmp52 { var n0_621 int64 = jrt.NN(jrt.Long_Cast(na_614)).LongValue__J(); var n1_622 int64 = jrt.NN(jrt.Long_Cast(na_615)).LongValue__J(); var nr_623 int64 = n0_621 + n1_622; if (n0_621^nr_623)&(n1_622^nr_623) >= 0 { na_612 = jrt.Long_ValueOf_J__Long_NoInit(nr_623).Ref() } else { na_612 = lang.Numbers_Add_O_O__Number_NoInit(na_614, na_615) } } else { var tmp54 bool; var tmp55 bool; tmp55 = jrt.Double_InstanceOf(na_614); if tmp55 { tmp55 = jrt.Double_InstanceOf(na_615) }; tmp54 = tmp55; if tmp54 { var n0_621_2 float64 = jrt.NN(jrt.Double_Cast(na_614)).DoubleValue__D(); var n1_622_2 float64 = jrt.NN(jrt.Double_Cast(na_615)).DoubleValue__D(); na_612 = jrt.Double_ValueOf_D__Double_NoInit(n0_621_2 + n1_622_2).Ref() } else { na_612 = lang.Numbers_Add_O_O__Number_NoInit(na_614, na_615) } }; var na_613 int64 = -719468; if jrt.Long_InstanceOf(na_612) { var n0_624 int64 = jrt.NN(jrt.Long_Cast(na_612)).LongValue__J(); var n1_625 int64 = na_613; var nr_626 int64 = n0_624 + n1_625; if (n0_624^nr_626)&(n1_625^nr_626) >= 0 { g__4 = jrt.Long_ValueOf_J__Long_NoInit(nr_626).Ref() } else { g__4 = lang.Numbers_Add_O_J__Number_NoInit(na_612, na_613) } } else { g__4 = lang.Numbers_Add_O_J__Number_NoInit(na_612, na_613) }; var tmp56 bool; var na_627 any = g__4; var na_628 any =
	A_arbace_instant_A_const_43.GetRawRoot__O(); var tmp57 bool; var tmp58 bool; tmp58 = jrt.Long_InstanceOf(na_627); if tmp58 { tmp58 = jrt.Long_InstanceOf(na_628) }; tmp57 = tmp58; if tmp57 { var n0_629 int64 = jrt.NN(jrt.Long_Cast(na_627)).LongValue__J(); var n1_630 int64 = jrt.NN(jrt.Long_Cast(na_628)).LongValue__J(); tmp56 = n0_629 >= n1_630 } else { var tmp59 bool; var tmp60 bool; tmp60 = jrt.Double_InstanceOf(na_627); if tmp60 { tmp60 = jrt.Double_InstanceOf(na_628) }; tmp59 = tmp60; if tmp59 { var n0_629_2 float64 = jrt.NN(jrt.Double_Cast(na_627)).DoubleValue__D(); var n1_630_2 float64 = jrt.NN(jrt.Double_Cast(na_628)).DoubleValue__D(); tmp56 = n0_629_2 >= n1_630_2 } else { tmp56 = lang.Numbers_Gte_O_O__Z_NoInit(na_627, na_628) } }; if tmp56 { return g__4 } else { var a__5 any; var na_632 any
		var na_634 int64 = 14; var na_635 any = m__1
		if jrt.Long_InstanceOf(na_635) { var n0_636 int64 = na_634; var n1_637 int64 = jrt.NN(jrt.Long_Cast(na_635)).LongValue__J(); var nr_638 int64 = n0_636 - n1_637; var tmp61 bool; var tmp62 bool; tmp62 = !(n1_637 == -9223372036854775808); if tmp62 { tmp62 = (n0_636^n1_637)&(n0_636^nr_638) >= 0 }; tmp61 = tmp62; if tmp61 { na_632 = jrt.Long_ValueOf_J__Long_NoInit(nr_638).Ref() } else { na_632 = lang.Numbers_Minus_J_O__Number_NoInit(na_634, na_635) } } else { na_632 = lang.Numbers_Minus_J_O__Number_NoInit(na_634, na_635) }; var na_633 int64 = 12; if jrt.Long_InstanceOf(na_632) { var n0_639 int64 = jrt.NN(jrt.Long_Cast(na_632)).LongValue__J(); var n1_640 int64 = na_633; if n1_640 == 0 { a__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_632, na_633) } else { a__5 = jrt.Long_ValueOf_J__Long_NoInit(n0_639 / n1_640).Ref() } } else { a__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_632, na_633) }
//line :211:1
		var yy__6 any; var na_642 any
		var na_644 any = y__0
		var na_645 int64 = 4800
		if jrt.Long_InstanceOf(na_644) { var n0_646 int64 = jrt.NN(jrt.Long_Cast(na_644)).LongValue__J(); var n1_647 int64 = na_645; var nr_648 int64 = n0_646 + n1_647; if (n0_646^nr_648)&(n1_647^nr_648) >= 0 { na_642 = jrt.Long_ValueOf_J__Long_NoInit(nr_648).Ref() } else { na_642 = lang.Numbers_Add_O_J__Number_NoInit(na_644, na_645) } } else { na_642 = lang.Numbers_Add_O_J__Number_NoInit(na_644, na_645) }; var na_643 any = a__5; var tmp63 bool; var tmp64 bool; tmp64 = jrt.Long_InstanceOf(na_642); if tmp64 { tmp64 = jrt.Long_InstanceOf(na_643) }; tmp63 = tmp64; if tmp63 { var n0_649 int64 = jrt.NN(jrt.Long_Cast(na_642)).LongValue__J(); var n1_650 int64 = jrt.NN(jrt.Long_Cast(na_643)).LongValue__J(); var nr_651 int64 = n0_649 - n1_650; var tmp65 bool; var tmp66 bool; tmp66 = !(n1_650 == -9223372036854775808); if tmp66 { tmp66 = (n0_649^n1_650)&(n0_649^nr_651) >= 0 }; tmp65 = tmp66; if tmp65 { yy__6 = jrt.Long_ValueOf_J__Long_NoInit(nr_651).Ref() } else { yy__6 = lang.Numbers_Minus_O_O__Number_NoInit(na_642, na_643) } } else { var tmp67 bool; var tmp68 bool; tmp68 = jrt.Double_InstanceOf(na_642); if tmp68 { tmp68 = jrt.Double_InstanceOf(na_643) }; tmp67 = tmp68; if tmp67 { var n0_649_2 float64 = jrt.NN(jrt.Double_Cast(na_642)).DoubleValue__D(); var n1_650_2 float64 = jrt.NN(jrt.Double_Cast(na_643)).DoubleValue__D(); yy__6 = jrt.Double_ValueOf_D__Double_NoInit(n0_649_2 + -n1_650_2).Ref() } else { yy__6 = lang.Numbers_Minus_O_O__Number_NoInit(na_642, na_643) } }
//line :211:1
		var mm__7 any; var na_652 any; var na_654 any = m__1; var na_655 any
		var na_656 int64 = 12
		var na_657 any = a__5

		if jrt.Long_InstanceOf(na_657) { var n0_658 int64 = na_656; var n1_659 int64 = jrt.NN(jrt.Long_Cast(na_657)).LongValue__J(); var nr_660 int64 = n0_658 * n1_659; var tmp69 bool; var tmp70 bool; var tmp71 bool; var tmp72 bool; tmp72 = n0_658 == -9223372036854775808; if tmp72 { tmp72 = n1_659 < 0 }; tmp71 = tmp72; tmp70 = !tmp71; if tmp70 { var tmp73 bool; tmp73 = n1_659 == 0; if !tmp73 { tmp73 = nr_660/n1_659 == n0_658 }; tmp70 = tmp73 }; tmp69 = tmp70; if tmp69 { na_655 = jrt.Long_ValueOf_J__Long_NoInit(nr_660).Ref() } else { na_655 = lang.Numbers_Multiply_J_O__Number_NoInit(na_656, na_657) } } else { na_655 = lang.Numbers_Multiply_J_O__Number_NoInit(na_656, na_657) }; var tmp74 bool; var tmp75 bool; tmp75 = jrt.Long_InstanceOf(na_654); if tmp75 { tmp75 = jrt.Long_InstanceOf(na_655) }; tmp74 = tmp75; if tmp74 { var n0_661 int64 = jrt.NN(jrt.Long_Cast(na_654)).LongValue__J(); var n1_662 int64 = jrt.NN(jrt.Long_Cast(na_655)).LongValue__J(); var nr_663 int64 = n0_661 + n1_662; if (n0_661^nr_663)&(n1_662^nr_663) >= 0 { na_652 = jrt.Long_ValueOf_J__Long_NoInit(nr_663).Ref() } else { na_652 = lang.Numbers_Add_O_O__Number_NoInit(na_654, na_655) } } else { var tmp76 bool; var tmp77 bool; tmp77 = jrt.Double_InstanceOf(na_654); if tmp77 { tmp77 = jrt.Double_InstanceOf(na_655) }; tmp76 = tmp77; if tmp76 { var n0_661_2 float64 = jrt.NN(jrt.Double_Cast(na_654)).DoubleValue__D(); var n1_662_2 float64 = jrt.NN(jrt.Double_Cast(na_655)).DoubleValue__D(); na_652 = jrt.Double_ValueOf_D__Double_NoInit(n0_661_2 + n1_662_2).Ref() } else { na_652 = lang.Numbers_Add_O_O__Number_NoInit(na_654, na_655) } }; var na_653 int64 = 3; if jrt.Long_InstanceOf(na_652) { var n0_664 int64 = jrt.NN(jrt.Long_Cast(na_652)).LongValue__J(); var n1_665 int64 = na_653; var nr_666 int64 = n0_664 - n1_665; var tmp78 bool; var tmp79 bool; tmp79 = !(n1_665 == -9223372036854775808); if tmp79 { tmp79 = (n0_664^n1_665)&(n0_664^nr_666) >= 0 }; tmp78 = tmp79; if tmp78 { mm__7 = jrt.Long_ValueOf_J__Long_NoInit(nr_666).Ref() } else { mm__7 = lang.Numbers_Minus_O_J__Number_NoInit(na_652, na_653) } } else { mm__7 = lang.Numbers_Minus_O_J__Number_NoInit(na_652, na_653) }
		var na_667 any; var na_669 any; var na_671 any; var na_673 any; var na_675 any = d__2; var na_676 any; var na_677 any; var na_679 any; var na_681 int64 = 153; var na_682 any = mm__7; if jrt.Long_InstanceOf(na_682) { var n0_683 int64 = na_681; var n1_684 int64 = jrt.NN(jrt.Long_Cast(na_682)).LongValue__J(); var nr_685 int64 = n0_683 * n1_684; var tmp80 bool; var tmp81 bool; var tmp82 bool; var tmp83 bool; tmp83 = n0_683 == -9223372036854775808; if tmp83 { tmp83 = n1_684 < 0 }; tmp82 = tmp83; tmp81 = !tmp82; if tmp81 { var tmp84 bool; tmp84 = n1_684 == 0; if !tmp84 { tmp84 = nr_685/n1_684 == n0_683 }; tmp81 = tmp84 }; tmp80 = tmp81; if tmp80 { na_679 = jrt.Long_ValueOf_J__Long_NoInit(nr_685).Ref() } else { na_679 = lang.Numbers_Multiply_J_O__Number_NoInit(na_681, na_682) } } else { na_679 = lang.Numbers_Multiply_J_O__Number_NoInit(na_681, na_682) }; var na_680 int64 = 2; if jrt.Long_InstanceOf(na_679) { var n0_686 int64 = jrt.NN(jrt.Long_Cast(na_679)).LongValue__J(); var n1_687 int64 = na_680; var nr_688 int64 = n0_686 + n1_687; if (n0_686^nr_688)&(n1_687^nr_688) >= 0 { na_677 = jrt.Long_ValueOf_J__Long_NoInit(nr_688).Ref() } else { na_677 = lang.Numbers_Add_O_J__Number_NoInit(na_679, na_680) } } else { na_677 = lang.Numbers_Add_O_J__Number_NoInit(na_679, na_680) }; var na_678 int64 = 5; if jrt.Long_InstanceOf(na_677) { var n0_689 int64 = jrt.NN(jrt.Long_Cast(na_677)).LongValue__J(); var n1_690 int64 = na_678; if n1_690 == 0 { na_676 = lang.Numbers_Quotient_O_J__Number_NoInit(na_677, na_678) } else { na_676 = jrt.Long_ValueOf_J__Long_NoInit(n0_689 / n1_690).Ref() } } else { na_676 = lang.Numbers_Quotient_O_J__Number_NoInit(na_677, na_678) }; var tmp85 bool; var tmp86 bool; tmp86 = jrt.Long_InstanceOf(na_675); if tmp86 { tmp86 = jrt.Long_InstanceOf(na_676) }; tmp85 = tmp86; if tmp85 { var n0_692 int64 = jrt.NN(jrt.Long_Cast(na_675)).LongValue__J(); var n1_693 int64 = jrt.NN(jrt.Long_Cast(na_676)).LongValue__J(); var nr_694 int64 = n0_692 + n1_693; if (n0_692^nr_694)&(n1_693^nr_694) >= 0 { na_673 = jrt.Long_ValueOf_J__Long_NoInit(nr_694).Ref() } else { na_673 = lang.Numbers_Add_O_O__Number_NoInit(na_675, na_676) } } else { var tmp87 bool; var tmp88 bool; tmp88 = jrt.Double_InstanceOf(na_675); if tmp88 { tmp88 = jrt.Double_InstanceOf(na_676) }; tmp87 = tmp88; if tmp87 { var n0_692_2 float64 = jrt.NN(jrt.Double_Cast(na_675)).DoubleValue__D(); var n1_693_2 float64 = jrt.NN(jrt.Double_Cast(na_676)).DoubleValue__D(); na_673 = jrt.Double_ValueOf_D__Double_NoInit(n0_692_2 + n1_693_2).Ref() } else { na_673 = lang.Numbers_Add_O_O__Number_NoInit(na_675, na_676) } }; var na_674 any; var na_695 int64 = 365; var na_696 any = yy__6; if jrt.Long_InstanceOf(na_696) { var n0_697 int64 = na_695; var n1_698 int64 = jrt.NN(jrt.Long_Cast(na_696)).LongValue__J(); var nr_699 int64 = n0_697 * n1_698; var tmp89 bool; var tmp90 bool; var tmp91 bool; var tmp92 bool; tmp92 = n0_697 == -9223372036854775808; if tmp92 { tmp92 = n1_698 < 0 }; tmp91 = tmp92; tmp90 = !tmp91; if tmp90 { var tmp93 bool; tmp93 = n1_698 == 0; if !tmp93 { tmp93 = nr_699/n1_698 == n0_697 }; tmp90 = tmp93 }; tmp89 = tmp90; if tmp89 { na_674 = jrt.Long_ValueOf_J__Long_NoInit(nr_699).Ref() } else { na_674 = lang.Numbers_Multiply_J_O__Number_NoInit(na_695, na_696) } } else { na_674 = lang.Numbers_Multiply_J_O__Number_NoInit(na_695, na_696) }; var tmp94 bool; var tmp95 bool; tmp95 = jrt.Long_InstanceOf(na_673); if tmp95 { tmp95 = jrt.Long_InstanceOf(na_674) }; tmp94 = tmp95; if tmp94 { var n0_700 int64 = jrt.NN(jrt.Long_Cast(na_673)).LongValue__J(); var n1_701 int64 = jrt.NN(jrt.Long_Cast(na_674)).LongValue__J(); var nr_702 int64 = n0_700 + n1_701; if (n0_700^nr_702)&(n1_701^nr_702) >= 0 { na_671 = jrt.Long_ValueOf_J__Long_NoInit(nr_702).Ref() } else { na_671 = lang.Numbers_Add_O_O__Number_NoInit(na_673, na_674) } } else { var tmp96 bool; var tmp97 bool; tmp97 = jrt.Double_InstanceOf(na_673); if tmp97 { tmp97 = jrt.Double_InstanceOf(na_674) }; tmp96 = tmp97; if tmp96 { var n0_700_2 float64 = jrt.NN(jrt.Double_Cast(na_673)).DoubleValue__D(); var n1_701_2 float64 = jrt.NN(jrt.Double_Cast(na_674)).DoubleValue__D(); na_671 = jrt.Double_ValueOf_D__Double_NoInit(n0_700_2 + n1_701_2).Ref() } else { na_671 = lang.Numbers_Add_O_O__Number_NoInit(na_673, na_674) } }; var na_672 int64 = jrt.Math_FloorDiv_J_J__J(lang.RT_LongCast_O__J_NoInit(yy__6), 4); if jrt.Long_InstanceOf(na_671) { var n0_703 int64 = jrt.NN(jrt.Long_Cast(na_671)).LongValue__J(); var n1_704 int64 = na_672; var nr_705 int64 = n0_703 + n1_704; if (n0_703^nr_705)&(n1_704^nr_705) >= 0 { na_669 = jrt.Long_ValueOf_J__Long_NoInit(nr_705).Ref() } else { na_669 = lang.Numbers_Add_O_J__Number_NoInit(na_671, na_672) } } else { na_669 = lang.Numbers_Add_O_J__Number_NoInit(na_671, na_672) }; var na_670 int64 = -32083; if jrt.Long_InstanceOf(na_669) { var n0_706 int64 = jrt.NN(jrt.Long_Cast(na_669)).LongValue__J(); var n1_707 int64 = na_670; var nr_708 int64 = n0_706 + n1_707; if (n0_706^nr_708)&(n1_707^nr_708) >= 0 { na_667 = jrt.Long_ValueOf_J__Long_NoInit(nr_708).Ref() } else { na_667 = lang.Numbers_Add_O_J__Number_NoInit(na_669, na_670) } } else { na_667 = lang.Numbers_Add_O_J__Number_NoInit(na_669, na_670) }; var na_668 int64 = 2440588; if jrt.Long_InstanceOf(na_667) { var n0_709 int64 = jrt.NN(jrt.Long_Cast(na_667)).LongValue__J(); var n1_710 int64 = na_668; var nr_711 int64 = n0_709 - n1_710; var tmp98 bool; var tmp99 bool; tmp99 = !(n1_710 == -9223372036854775808); if tmp99 { tmp99 = (n0_709^n1_710)&(n0_709^nr_711) >= 0 }; tmp98 = tmp99; if tmp98 { return jrt.Long_ValueOf_J__Long_NoInit(nr_711).Ref() } else { return lang.Numbers_Minus_O_J__Number_NoInit(na_667, na_668) } } else { return lang.Numbers_Minus_O_J__Number_NoInit(na_667, na_668) } } }

func A_arbace_instant_print_date_A_New() *A_arbace_instant_print_date_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_print_date_A{}; t.Ctor(); return t }
//line :218:1
func (t *A_arbace_instant_print_date_A) Ctor() {}
//line :218:1
func (t *A_arbace_instant_print_date_A) Invoke_O_O_O__O(self, d__0, w__1 any) any { var ms__3 int64 = jrt.Date_Cast(d__0).GetTime__J(); var days__4 int64 = jrt.Math_FloorDiv_J_J__J(ms__3, 86400000); var msd__5 int64 = jrt.Math_FloorMod_J_J__J(ms__3, 86400000); var vec__783000040__6 any; var root_712 any = A_arbace_instant_A_const_44.GetRawRoot__O(); var linked_713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_712, A_arbace_instant_days__GT_civil_A_fn_class); var ifn_714 lang.IFn; if





	linked_713 == nil { ifn_714 = lang.IFn_Cast(root_712) } else { ifn_714 = nil }; var arg_715 any = jrt.Long_ValueOf_J__Long_NoInit(days__4).Ref(); if linked_713 == nil { vec__783000040__6 = ifn_714.Invoke_O__O(arg_715) } else { vec__783000040__6 = linked_713.(*A_arbace_instant_days__GT_civil_A).Invoke_O_O__O(root_712, arg_715) }; var y__7 any = /*line :218:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__783000040__6, lang.RT_IntCast_J__I_NoInit(0), nil); var m__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000040__6, lang.RT_IntCast_J__I_NoInit(1), nil); var dd__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000040__6, lang.RT_IntCast_J__I_NoInit(2), nil);






	jrt.Writer_Cast(w__1).Write_String__V(Lit_12); var tmp1 jrt.Writer_I =
	jrt.Writer_Cast(w__1); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_45.GetRawRoot__O()); var tmp3 any; var tmp4 bool; var na_727 any = y__7; var na_728 int64 = 0; if
	jrt.Long_InstanceOf(na_727) { var n0_729 int64 = jrt.NN(jrt.Long_Cast(na_727)).LongValue__J(); var n1_730 int64 = na_728; tmp4 = n0_729 <= n1_730 } else { tmp4 = lang.Numbers_Lte_O_J__Z_NoInit(na_727, na_728) }; if tmp4 { var na_732 int64 = 1; var na_733 any = y__7; if jrt.Long_InstanceOf(na_733) { var n0_734 int64 = na_732; var n1_735 int64 = jrt.NN(jrt.Long_Cast(na_733)).LongValue__J(); var nr_736 int64 = n0_734 - n1_735; var tmp5 bool; var tmp6 bool; tmp6 = !(n1_735 == -9223372036854775808); if tmp6 { tmp6 = (n0_734^n1_735)&(n0_734^nr_736) >= 0 }; tmp5 = tmp6; if tmp5 { tmp3 = jrt.Long_ValueOf_J__Long_NoInit(nr_736).Ref() } else { tmp3 = lang.Numbers_Minus_J_O__Number_NoInit(na_732, na_733) } } else { tmp3 = lang.Numbers_Minus_J_O__Number_NoInit(na_732, na_733) } } else { tmp3 = y__7 }; /*line :226:1*/tmp1.Write_String__V(jrt.String_Cast(tmp2.Invoke_O_O_O_O_O_O_O_O__O(Lit_15, tmp3, m__8, dd__9, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(msd__5, 3600000)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Remainder_J_J__J_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(msd__5, 60000), 60)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Remainder_J_J__J_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(msd__5, 1000), 60)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Remainder_J_J__J_NoInit(msd__5, 1000)).Ref())));


	jrt.Writer_Cast(w__1).Write_String__V(Lit_14); return nil }

func A_arbace_instant_eval783000044_fn__783000045_A_New() *A_arbace_instant_eval783000044_fn__783000045_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000044_fn__783000045_A{}; t.Ctor(); return t }
//line :231:1
func (t *A_arbace_instant_eval783000044_fn__783000045_A) Ctor() {}
//line :231:1
func (t *A_arbace_instant_eval783000044_fn__783000045_A) Invoke_O_O_O__O(self, d__1, w__2 any) any {

	var root_737 any = A_arbace_instant_A_const_46.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_737, A_arbace_instant_print_date_A_fn_class); var ifn_739 lang.IFn; if linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var arg_740 any = d__1; var arg_741 any = w__2; if linked_738 == nil { return ifn_739.Invoke_O_O__O(arg_740, arg_741) } else { return linked_738.(*A_arbace_instant_print_date_A).Invoke_O_O_O__O(root_737, arg_740, arg_741)
	} }
func A_arbace_instant_eval783000048_fn__783000049_A_New() *A_arbace_instant_eval783000048_fn__783000049_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000048_fn__783000049_A{}; t.Ctor(); return t }
//line :235:1
func (t *A_arbace_instant_eval783000048_fn__783000049_A) Ctor() {}
//line :235:1
func (t *A_arbace_instant_eval783000048_fn__783000049_A) Invoke_O_O_O__O(self, d__1, w__2 any) any {

	var root_742 any = A_arbace_instant_A_const_46.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_742, A_arbace_instant_print_date_A_fn_class); var ifn_744 lang.IFn; if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any = d__1; var arg_746 any = w__2; if linked_743 == nil { return ifn_744.Invoke_O_O__O(arg_745, arg_746) } else { return linked_743.(*A_arbace_instant_print_date_A).Invoke_O_O_O__O(root_742, arg_745, arg_746)
	} }
func A_arbace_instant_print_calendar_A_New() *A_arbace_instant_print_calendar_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_print_calendar_A{}; t.Ctor(); return t }
//line :239:1
func (t *A_arbace_instant_print_calendar_A) Ctor() {}
//line :239:1
func (t *A_arbace_instant_print_calendar_A) Invoke_O_O_O__O(self, c__0, w__1 any) any { var calstr__3 any = lang.IFn_Cast(A_arbace_instant_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_11, c__0); var offset_minutes__4 int64 = lang.Numbers_Minus_J_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(calstr__3)).Length__I()), 2);





	jrt.Writer_Cast(w__1).Write_String__V(Lit_12);
	jrt.Writer_Cast(w__1).Write_String_I_I__V(jrt.String_Cast(calstr__3), lang.RT_IntCast_J__I_NoInit(0), lang.RT_IntCast_J__I_NoInit(offset_minutes__4));
	jrt.Writer_Cast(w__1).Write_String__V(Lit_13);
	jrt.Writer_Cast(w__1).Write_String_I_I__V(jrt.String_Cast(calstr__3), lang.RT_IntCast_J__I_NoInit(offset_minutes__4), lang.RT_IntCast_J__I_NoInit(2));
	jrt.Writer_Cast(w__1).Write_String__V(Lit_14); return nil }

func A_arbace_instant_eval783000053_fn__783000054_A_New() *A_arbace_instant_eval783000053_fn__783000054_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000053_fn__783000054_A{}; t.Ctor(); return t }
//line :251:1
func (t *A_arbace_instant_eval783000053_fn__783000054_A) Ctor() {}
//line :251:1
func (t *A_arbace_instant_eval783000053_fn__783000054_A) Invoke_O_O_O__O(self, c__1, w__2 any) any {

	var root_752 any = A_arbace_instant_A_const_47.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, A_arbace_instant_print_calendar_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any = c__1; var arg_756 any = w__2; if linked_753 == nil { return ifn_754.Invoke_O_O__O(arg_755, arg_756) } else { return linked_753.(*A_arbace_instant_print_calendar_A).Invoke_O_O_O__O(root_752, arg_755, arg_756)
	} }
func A_arbace_instant_eval783000057_fn__783000058_A_New() *A_arbace_instant_eval783000057_fn__783000058_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000057_fn__783000058_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_instant_eval783000057_fn__783000058_A) Ctor() {}
//line :255:1
func (t *A_arbace_instant_eval783000057_fn__783000058_A) Invoke_O_O_O__O(self, c__1, w__2 any) any {

	var root_757 any = A_arbace_instant_A_const_47.GetRawRoot__O(); var linked_758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_757, A_arbace_instant_print_calendar_A_fn_class); var ifn_759 lang.IFn; if linked_758 == nil { ifn_759 = lang.IFn_Cast(root_757) } else { ifn_759 = nil }; var arg_760 any = c__1; var arg_761 any = w__2; if linked_758 == nil { return ifn_759.Invoke_O_O__O(arg_760, arg_761) } else { return linked_758.(*A_arbace_instant_print_calendar_A).Invoke_O_O_O__O(root_757, arg_760, arg_761)
	} }
func A_arbace_instant_print_timestamp_A_New() *A_arbace_instant_print_timestamp_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_print_timestamp_A{}; t.Ctor(); return t }
//line :259:1
func (t *A_arbace_instant_print_timestamp_A) Ctor() {}
//line :259:1
func (t *A_arbace_instant_print_timestamp_A) Invoke_O_O_O__O(self, ts__0, w__1 any) any { var ms__3 int64 = jrt.NN(jrt.Timestamp_Cast(ts__0)).GetTime__J(); var days__4 int64 = jrt.Math_FloorDiv_J_J__J(ms__3, 86400000); var msd__5 int64 = jrt.Math_FloorMod_J_J__J(ms__3, 86400000); var vec__783000061__6 any; var root_762 any = A_arbace_instant_A_const_44.GetRawRoot__O(); var linked_763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_762, A_arbace_instant_days__GT_civil_A_fn_class); var ifn_764 lang.IFn; if





	linked_763 == nil { ifn_764 = lang.IFn_Cast(root_762) } else { ifn_764 = nil }; var arg_765 any = jrt.Long_ValueOf_J__Long_NoInit(days__4).Ref(); if linked_763 == nil { vec__783000061__6 = ifn_764.Invoke_O__O(arg_765) } else { vec__783000061__6 = linked_763.(*A_arbace_instant_days__GT_civil_A).Invoke_O_O__O(root_762, arg_765) }; var y__7 any = /*line :259:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__783000061__6, lang.RT_IntCast_J__I_NoInit(0), nil); var m__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000061__6, lang.RT_IntCast_J__I_NoInit(1), nil); var dd__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000061__6, lang.RT_IntCast_J__I_NoInit(2), nil);






	jrt.Writer_Cast(w__1).Write_String__V(Lit_12); var tmp1 jrt.Writer_I =
	jrt.Writer_Cast(w__1); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_45.GetRawRoot__O()); var tmp3 any; var tmp4 bool; var na_776 any = y__7; var na_777 int64 = 0; if
	jrt.Long_InstanceOf(na_776) { var n0_778 int64 = jrt.NN(jrt.Long_Cast(na_776)).LongValue__J(); var n1_779 int64 = na_777; tmp4 = n0_778 <= n1_779 } else { tmp4 = lang.Numbers_Lte_O_J__Z_NoInit(na_776, na_777) }; if tmp4 { var na_781 int64 = 1; var na_782 any = y__7; if jrt.Long_InstanceOf(na_782) { var n0_783 int64 = na_781; var n1_784 int64 = jrt.NN(jrt.Long_Cast(na_782)).LongValue__J(); var nr_785 int64 = n0_783 - n1_784; var tmp5 bool; var tmp6 bool; tmp6 = !(n1_784 == -9223372036854775808); if tmp6 { tmp6 = (n0_783^n1_784)&(n0_783^nr_785) >= 0 }; tmp5 = tmp6; if tmp5 { tmp3 = jrt.Long_ValueOf_J__Long_NoInit(nr_785).Ref() } else { tmp3 = lang.Numbers_Minus_J_O__Number_NoInit(na_781, na_782) } } else { tmp3 = lang.Numbers_Minus_J_O__Number_NoInit(na_781, na_782) } } else { tmp3 = y__7 }; /*line :267:1*/tmp1.Write_String__V(jrt.String_Cast(tmp2.Invoke_O_O_O_O_O_O_O__O(Lit_16, tmp3, m__8, dd__9, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(msd__5, 3600000)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Remainder_J_J__J_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(msd__5, 60000), 60)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Remainder_J_J__J_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(msd__5, 1000), 60)).Ref())));




	jrt.Writer_Cast(w__1).Write_String__V(jrt.String_Cast(lang.IFn_Cast(A_arbace_instant_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_17, jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Timestamp_Cast(ts__0)).GetNanos__I()).Ref())));
	jrt.Writer_Cast(w__1).Write_String__V(Lit_14); return nil }

func A_arbace_instant_eval783000065_fn__783000066_A_New() *A_arbace_instant_eval783000065_fn__783000066_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000065_fn__783000066_A{}; t.Ctor(); return t }
//line :275:1
func (t *A_arbace_instant_eval783000065_fn__783000066_A) Ctor() {}
//line :275:1
func (t *A_arbace_instant_eval783000065_fn__783000066_A) Invoke_O_O_O__O(self, ts__1, w__2 any) any {

	var root_791 any = A_arbace_instant_A_const_48.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, A_arbace_instant_print_timestamp_A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any = ts__1; var arg_795 any = w__2; if linked_792 == nil { return ifn_793.Invoke_O_O__O(arg_794, arg_795) } else { return linked_792.(*A_arbace_instant_print_timestamp_A).Invoke_O_O_O__O(root_791, arg_794, arg_795)
	} }
func A_arbace_instant_eval783000069_fn__783000070_A_New() *A_arbace_instant_eval783000069_fn__783000070_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000069_fn__783000070_A{}; t.Ctor(); return t }
//line :279:1
func (t *A_arbace_instant_eval783000069_fn__783000070_A) Ctor() {}
//line :279:1
func (t *A_arbace_instant_eval783000069_fn__783000070_A) Invoke_O_O_O__O(self, ts__1, w__2 any) any {

	var root_796 any = A_arbace_instant_A_const_48.GetRawRoot__O(); var linked_797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_796, A_arbace_instant_print_timestamp_A_fn_class); var ifn_798 lang.IFn; if linked_797 == nil { ifn_798 = lang.IFn_Cast(root_796) } else { ifn_798 = nil }; var arg_799 any = ts__1; var arg_800 any = w__2; if linked_797 == nil { return ifn_798.Invoke_O_O__O(arg_799, arg_800) } else { return linked_797.(*A_arbace_instant_print_timestamp_A).Invoke_O_O_O__O(root_796, arg_799, arg_800)
	}
}


func A_arbace_instant_construct_date_A_New() *A_arbace_instant_construct_date_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_construct_date_A{}; t.Ctor(); return t }
//line :286:1
func (t *A_arbace_instant_construct_date_A) Ctor() {}
//line :286:1
func (t *A_arbace_instant_construct_date_A) Invoke_O_O_O_O_O_O_O_O_O_O_O__O(self, years__0, months__1, days__2, hours__3, minutes__4, seconds__5, nanoseconds__6, offset_sign__7, offset_hours__8, offset_minutes__9 any) any { var tmp1 jrt.Number_I; var na_801 any; var na_803 any; var na_805 any; var na_807 any; var na_809 any; var na_811 any; var root_813 any = A_arbace_instant_A_const_49.GetRawRoot__O(); var linked_814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_813, A_arbace_instant_civil__GT_days_A_fn_class); var ifn_815 lang.IFn; if




	linked_814 == nil { ifn_815 = lang.IFn_Cast(root_813) } else { ifn_815 = nil }; var arg_816 any = years__0; var arg_817 any = months__1; var arg_818 any = days__2; if linked_814 == nil { na_811 = ifn_815.Invoke_O_O_O__O(arg_816, arg_817, arg_818) } else { na_811 = linked_814.(*A_arbace_instant_civil__GT_days_A).Invoke_O_O_O_O__O(root_813, arg_816, arg_817, arg_818) }; var na_812 int64 = 86400000; if jrt.Long_InstanceOf(na_811) { var n0_819 int64 = jrt.NN(jrt.Long_Cast(na_811)).LongValue__J(); var n1_820 int64 = na_812; var nr_821 int64 = n0_819 * n1_820; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 bool; tmp5 = n0_819 == -9223372036854775808; if tmp5 { tmp5 = n1_820 < 0 }; tmp4 = tmp5; tmp3 = !tmp4; if tmp3 { var tmp6 bool; tmp6 = n1_820 == 0; if !tmp6 { tmp6 = nr_821/n1_820 == n0_819 }; tmp3 = tmp6 }; tmp2 = tmp3; if tmp2 { na_809 = jrt.Long_ValueOf_J__Long_NoInit(nr_821).Ref() } else { na_809 = lang.Numbers_Multiply_O_J__Number_NoInit(na_811, na_812) } } else { na_809 = lang.Numbers_Multiply_O_J__Number_NoInit(na_811, na_812) }; var na_810 any; var na_822 any = hours__3; var na_823 int64 = 3600000; if
	jrt.Long_InstanceOf(na_822) { var n0_824 int64 = jrt.NN(jrt.Long_Cast(na_822)).LongValue__J(); var n1_825 int64 = na_823; var nr_826 int64 = n0_824 * n1_825; var tmp7 bool; var tmp8 bool; var tmp9 bool; var tmp10 bool; tmp10 = n0_824 == -9223372036854775808; if tmp10 { tmp10 = n1_825 < 0 }; tmp9 = tmp10; tmp8 = !tmp9; if tmp8 { var tmp11 bool; tmp11 = n1_825 == 0; if !tmp11 { tmp11 = nr_826/n1_825 == n0_824 }; tmp8 = tmp11 }; tmp7 = tmp8; if tmp7 { na_810 = jrt.Long_ValueOf_J__Long_NoInit(nr_826).Ref() } else { na_810 = lang.Numbers_Multiply_O_J__Number_NoInit(na_822, na_823) } } else { na_810 = lang.Numbers_Multiply_O_J__Number_NoInit(na_822, na_823) }; var tmp12 bool; var tmp13 bool; tmp13 = /*line :291:1*/jrt.Long_InstanceOf(na_809); if tmp13 { tmp13 = jrt.Long_InstanceOf(na_810) }; tmp12 = tmp13; if tmp12 { var n0_827 int64 = jrt.NN(jrt.Long_Cast(na_809)).LongValue__J(); var n1_828 int64 = jrt.NN(jrt.Long_Cast(na_810)).LongValue__J(); var nr_829 int64 = n0_827 + n1_828; if (n0_827^nr_829)&(n1_828^nr_829) >= 0 { na_807 = jrt.Long_ValueOf_J__Long_NoInit(nr_829).Ref() } else { na_807 = lang.Numbers_Add_O_O__Number_NoInit(na_809, na_810) } } else { var tmp14 bool; var tmp15 bool; tmp15 = jrt.Double_InstanceOf(na_809); if tmp15 { tmp15 = jrt.Double_InstanceOf(na_810) }; tmp14 = tmp15; if tmp14 { var n0_827_2 float64 = jrt.NN(jrt.Double_Cast(na_809)).DoubleValue__D(); var n1_828_2 float64 = jrt.NN(jrt.Double_Cast(na_810)).DoubleValue__D(); na_807 = jrt.Double_ValueOf_D__Double_NoInit(n0_827_2 + n1_828_2).Ref() } else { na_807 = lang.Numbers_Add_O_O__Number_NoInit(na_809, na_810) } }; var na_808 any; var na_830 any = minutes__4; var na_831 int64 = 60000; if
	jrt.Long_InstanceOf(na_830) { var n0_832 int64 = jrt.NN(jrt.Long_Cast(na_830)).LongValue__J(); var n1_833 int64 = na_831; var nr_834 int64 = n0_832 * n1_833; var tmp16 bool; var tmp17 bool; var tmp18 bool; var tmp19 bool; tmp19 = n0_832 == -9223372036854775808; if tmp19 { tmp19 = n1_833 < 0 }; tmp18 = tmp19; tmp17 = !tmp18; if tmp17 { var tmp20 bool; tmp20 = n1_833 == 0; if !tmp20 { tmp20 = nr_834/n1_833 == n0_832 }; tmp17 = tmp20 }; tmp16 = tmp17; if tmp16 { na_808 = jrt.Long_ValueOf_J__Long_NoInit(nr_834).Ref() } else { na_808 = lang.Numbers_Multiply_O_J__Number_NoInit(na_830, na_831) } } else { na_808 = lang.Numbers_Multiply_O_J__Number_NoInit(na_830, na_831) }; var tmp21 bool; var tmp22 bool; tmp22 = /*line :291:1*/jrt.Long_InstanceOf(na_807); if tmp22 { tmp22 = jrt.Long_InstanceOf(na_808) }; tmp21 = tmp22; if tmp21 { var n0_835 int64 = jrt.NN(jrt.Long_Cast(na_807)).LongValue__J(); var n1_836 int64 = jrt.NN(jrt.Long_Cast(na_808)).LongValue__J(); var nr_837 int64 = n0_835 + n1_836; if (n0_835^nr_837)&(n1_836^nr_837) >= 0 { na_805 = jrt.Long_ValueOf_J__Long_NoInit(nr_837).Ref() } else { na_805 = lang.Numbers_Add_O_O__Number_NoInit(na_807, na_808) } } else { var tmp23 bool; var tmp24 bool; tmp24 = jrt.Double_InstanceOf(na_807); if tmp24 { tmp24 = jrt.Double_InstanceOf(na_808) }; tmp23 = tmp24; if tmp23 { var n0_835_2 float64 = jrt.NN(jrt.Double_Cast(na_807)).DoubleValue__D(); var n1_836_2 float64 = jrt.NN(jrt.Double_Cast(na_808)).DoubleValue__D(); na_805 = jrt.Double_ValueOf_D__Double_NoInit(n0_835_2 + n1_836_2).Ref() } else { na_805 = lang.Numbers_Add_O_O__Number_NoInit(na_807, na_808) } }; var na_806 any; var na_838 any = seconds__5; var na_839 int64 = 1000; if
	jrt.Long_InstanceOf(na_838) { var n0_840 int64 = jrt.NN(jrt.Long_Cast(na_838)).LongValue__J(); var n1_841 int64 = na_839; var nr_842 int64 = n0_840 * n1_841; var tmp25 bool; var tmp26 bool; var tmp27 bool; var tmp28 bool; tmp28 = n0_840 == -9223372036854775808; if tmp28 { tmp28 = n1_841 < 0 }; tmp27 = tmp28; tmp26 = !tmp27; if tmp26 { var tmp29 bool; tmp29 = n1_841 == 0; if !tmp29 { tmp29 = nr_842/n1_841 == n0_840 }; tmp26 = tmp29 }; tmp25 = tmp26; if tmp25 { na_806 = jrt.Long_ValueOf_J__Long_NoInit(nr_842).Ref() } else { na_806 = lang.Numbers_Multiply_O_J__Number_NoInit(na_838, na_839) } } else { na_806 = lang.Numbers_Multiply_O_J__Number_NoInit(na_838, na_839) }; var tmp30 bool; var tmp31 bool; tmp31 = /*line :291:1*/jrt.Long_InstanceOf(na_805); if tmp31 { tmp31 = jrt.Long_InstanceOf(na_806) }; tmp30 = tmp31; if tmp30 { var n0_843 int64 = jrt.NN(jrt.Long_Cast(na_805)).LongValue__J(); var n1_844 int64 = jrt.NN(jrt.Long_Cast(na_806)).LongValue__J(); var nr_845 int64 = n0_843 + n1_844; if (n0_843^nr_845)&(n1_844^nr_845) >= 0 { na_803 = jrt.Long_ValueOf_J__Long_NoInit(nr_845).Ref() } else { na_803 = lang.Numbers_Add_O_O__Number_NoInit(na_805, na_806) } } else { var tmp32 bool; var tmp33 bool; tmp33 = jrt.Double_InstanceOf(na_805); if tmp33 { tmp33 = jrt.Double_InstanceOf(na_806) }; tmp32 = tmp33; if tmp32 { var n0_843_2 float64 = jrt.NN(jrt.Double_Cast(na_805)).DoubleValue__D(); var n1_844_2 float64 = jrt.NN(jrt.Double_Cast(na_806)).DoubleValue__D(); na_803 = jrt.Double_ValueOf_D__Double_NoInit(n0_843_2 + n1_844_2).Ref() } else { na_803 = lang.Numbers_Add_O_O__Number_NoInit(na_805, na_806) } }; var na_804 any; var na_846 any = nanoseconds__6; var na_847 int64 = 1000000; if

	jrt.Long_InstanceOf(na_846) { var n0_848 int64 = jrt.NN(jrt.Long_Cast(na_846)).LongValue__J(); var n1_849 int64 = na_847; if n1_849 == 0 { na_804 = lang.Numbers_Quotient_O_J__Number_NoInit(na_846, na_847) } else { na_804 = jrt.Long_ValueOf_J__Long_NoInit(n0_848 / n1_849).Ref() } } else { na_804 = lang.Numbers_Quotient_O_J__Number_NoInit(na_846, na_847) }; var tmp34 bool; var tmp35 bool; tmp35 = /*line :291:1*/jrt.Long_InstanceOf(na_803); if tmp35 { tmp35 = jrt.Long_InstanceOf(na_804) }; tmp34 = tmp35; if tmp34 { var n0_851 int64 = jrt.NN(jrt.Long_Cast(na_803)).LongValue__J(); var n1_852 int64 = jrt.NN(jrt.Long_Cast(na_804)).LongValue__J(); var nr_853 int64 = n0_851 + n1_852; if (n0_851^nr_853)&(n1_852^nr_853) >= 0 { na_801 = jrt.Long_ValueOf_J__Long_NoInit(nr_853).Ref() } else { na_801 = lang.Numbers_Add_O_O__Number_NoInit(na_803, na_804) } } else { var tmp36 bool; var tmp37 bool; tmp37 = jrt.Double_InstanceOf(na_803); if tmp37 { tmp37 = jrt.Double_InstanceOf(na_804) }; tmp36 = tmp37; if tmp36 { var n0_851_2 float64 = jrt.NN(jrt.Double_Cast(na_803)).DoubleValue__D(); var n1_852_2 float64 = jrt.NN(jrt.Double_Cast(na_804)).DoubleValue__D(); na_801 = jrt.Double_ValueOf_D__Double_NoInit(n0_851_2 + n1_852_2).Ref() } else { na_801 = lang.Numbers_Add_O_O__Number_NoInit(na_803, na_804) } }; var na_802 any; var na_854 any; var na_856 any = offset_sign__7; var na_857 any; var na_858 any; var na_860 any = offset_hours__8; var na_861 int64 = 60; if


	jrt.Long_InstanceOf(na_860) { var n0_862 int64 = jrt.NN(jrt.Long_Cast(na_860)).LongValue__J(); var n1_863 int64 = na_861; var nr_864 int64 = n0_862 * n1_863; var tmp38 bool; var tmp39 bool; var tmp40 bool; var tmp41 bool; tmp41 = n0_862 == -9223372036854775808; if tmp41 { tmp41 = n1_863 < 0 }; tmp40 = tmp41; tmp39 = !tmp40; if tmp39 { var tmp42 bool; tmp42 = n1_863 == 0; if !tmp42 { tmp42 = nr_864/n1_863 == n0_862 }; tmp39 = tmp42 }; tmp38 = tmp39; if tmp38 { na_858 = jrt.Long_ValueOf_J__Long_NoInit(nr_864).Ref() } else { na_858 = lang.Numbers_Multiply_O_J__Number_NoInit(na_860, na_861) } } else { na_858 = lang.Numbers_Multiply_O_J__Number_NoInit(na_860, na_861) }; var na_859 any = offset_minutes__9; var tmp43 bool; var tmp44 bool; tmp44 = jrt.Long_InstanceOf(na_858); if tmp44 { tmp44 = jrt.Long_InstanceOf(na_859) }; tmp43 = tmp44; if tmp43 { var n0_865 int64 = jrt.NN(jrt.Long_Cast(na_858)).LongValue__J(); var n1_866 int64 = jrt.NN(jrt.Long_Cast(na_859)).LongValue__J(); var nr_867 int64 = n0_865 + n1_866; if (n0_865^nr_867)&(n1_866^nr_867) >= 0 { na_857 = jrt.Long_ValueOf_J__Long_NoInit(nr_867).Ref() } else { na_857 = lang.Numbers_Add_O_O__Number_NoInit(na_858, na_859) } } else { var tmp45 bool; var tmp46 bool; tmp46 = jrt.Double_InstanceOf(na_858); if tmp46 { tmp46 = jrt.Double_InstanceOf(na_859) }; tmp45 = tmp46; if tmp45 { var n0_865_2 float64 = jrt.NN(jrt.Double_Cast(na_858)).DoubleValue__D(); var n1_866_2 float64 = jrt.NN(jrt.Double_Cast(na_859)).DoubleValue__D(); na_857 = jrt.Double_ValueOf_D__Double_NoInit(n0_865_2 + n1_866_2).Ref() } else { na_857 = lang.Numbers_Add_O_O__Number_NoInit(na_858, na_859) } }; var tmp47 bool; var tmp48 bool; tmp48 = jrt.Long_InstanceOf(na_856); if tmp48 { tmp48 = jrt.Long_InstanceOf(na_857) }; tmp47 = tmp48; if tmp47 { var n0_868 int64 = jrt.NN(jrt.Long_Cast(na_856)).LongValue__J(); var n1_869 int64 = jrt.NN(jrt.Long_Cast(na_857)).LongValue__J(); var nr_870 int64 = n0_868 * n1_869; var tmp49 bool; var tmp50 bool; var tmp51 bool; var tmp52 bool; tmp52 = n0_868 == -9223372036854775808; if tmp52 { tmp52 = n1_869 < 0 }; tmp51 = tmp52; tmp50 = !tmp51; if tmp50 { var tmp53 bool; tmp53 = n1_869 == 0; if !tmp53 { tmp53 = nr_870/n1_869 == n0_868 }; tmp50 = tmp53 }; tmp49 = tmp50; if tmp49 { na_854 = jrt.Long_ValueOf_J__Long_NoInit(nr_870).Ref() } else { na_854 = lang.Numbers_Multiply_O_O__Number_NoInit(na_856, na_857) } } else { var tmp54 bool; var tmp55 bool; tmp55 = jrt.Double_InstanceOf(na_856); if tmp55 { tmp55 = jrt.Double_InstanceOf(na_857) }; tmp54 = tmp55; if tmp54 { var n0_868_2 float64 = jrt.NN(jrt.Double_Cast(na_856)).DoubleValue__D(); var n1_869_2 float64 = jrt.NN(jrt.Double_Cast(na_857)).DoubleValue__D(); na_854 = jrt.Double_ValueOf_D__Double_NoInit(float64(n0_868_2 * n1_869_2)).Ref() } else { na_854 = lang.Numbers_Multiply_O_O__Number_NoInit(na_856, na_857) } }; var na_855 int64 = 60000; if jrt.Long_InstanceOf(na_854) { var n0_871 int64 = jrt.NN(jrt.Long_Cast(na_854)).LongValue__J(); var n1_872 int64 = na_855; var nr_873 int64 = n0_871 * n1_872; var tmp56 bool; var tmp57 bool; var tmp58 bool; var tmp59 bool; tmp59 = n0_871 == -9223372036854775808; if tmp59 { tmp59 = n1_872 < 0 }; tmp58 = tmp59; tmp57 = !tmp58; if tmp57 { var tmp60 bool; tmp60 = n1_872 == 0; if !tmp60 { tmp60 = nr_873/n1_872 == n0_871 }; tmp57 = tmp60 }; tmp56 = tmp57; if tmp56 { na_802 = jrt.Long_ValueOf_J__Long_NoInit(nr_873).Ref() } else { na_802 = lang.Numbers_Multiply_O_J__Number_NoInit(na_854, na_855) } } else { na_802 = lang.Numbers_Multiply_O_J__Number_NoInit(na_854, na_855) }; var tmp61 bool; var tmp62 bool; tmp62 = /*line :291:1*/jrt.Long_InstanceOf(na_801); if tmp62 { tmp62 = jrt.Long_InstanceOf(na_802) }; tmp61 = tmp62; if tmp61 { var n0_874 int64 = jrt.NN(jrt.Long_Cast(na_801)).LongValue__J(); var n1_875 int64 = jrt.NN(jrt.Long_Cast(na_802)).LongValue__J(); var nr_876 int64 = n0_874 - n1_875; var tmp63 bool; var tmp64 bool; tmp64 = !(n1_875 == -9223372036854775808); if tmp64 { tmp64 = (n0_874^n1_875)&(n0_874^nr_876) >= 0 }; tmp63 = tmp64; if tmp63 { tmp1 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_876)) } else { tmp1 = lang.Numbers_Minus_O_O__Number_NoInit(na_801, na_802) } } else { var tmp65 bool; var tmp66 bool; tmp66 = jrt.Double_InstanceOf(na_801); if tmp66 { tmp66 = jrt.Double_InstanceOf(na_802) }; tmp65 = tmp66; if tmp65 { var n0_874_2 float64 = jrt.NN(jrt.Double_Cast(na_801)).DoubleValue__D(); var n1_875_2 float64 = jrt.NN(jrt.Double_Cast(na_802)).DoubleValue__D(); tmp1 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_874_2 + -n1_875_2)) } else { tmp1 = lang.Numbers_Minus_O_O__Number_NoInit(na_801, na_802) } }; return /*line :286:1*/ jrt.Date_New_J(lang.RT_LongCast_O__J_NoInit(tmp1)) }









func A_arbace_instant_read_instant_date_A_New() *A_arbace_instant_read_instant_date_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_read_instant_date_A{}; t.Ctor(); return t }
//line :296:1
func (t *A_arbace_instant_read_instant_date_A) Ctor() {}
//line :296:1
func (t *A_arbace_instant_read_instant_date_A) Invoke_O_O__O(self, cs__0 any) any {




	var root_877 any = A_arbace_instant_A_const_50.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, A_arbace_instant_parse_timestamp_A_fn_class); var ifn_879 lang.IFn; if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any; var root_882 any = A_arbace_instant_A_const_51.GetRawRoot__O(); var linked_883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_882, A_arbace_instant_validated_A_fn_class); var ifn_884 lang.IFn; if linked_883 == nil { ifn_884 = lang.IFn_Cast(root_882) } else { ifn_884 = nil }; var arg_885 any = A_arbace_instant_A_const_52.GetRawRoot__O(); if linked_883 == nil { arg_880 = ifn_884.Invoke_O__O(arg_885) } else { arg_880 = linked_883.(*A_arbace_instant_validated_A).Invoke_O_O__O(root_882, arg_885) }; var arg_881 any = cs__0; if linked_878 == nil { return ifn_879.Invoke_O_O__O(arg_880, arg_881) } else { return linked_878.(*A_arbace_instant_parse_timestamp_A).Invoke_O_O_O__O(root_877, arg_880, arg_881)
	} }
func A_arbace_instant_construct_calendar_A_New() *A_arbace_instant_construct_calendar_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_construct_calendar_A{}; t.Ctor(); return t }
//line :303:1
func (t *A_arbace_instant_construct_calendar_A) Ctor() {}
//line :303:1
func (t *A_arbace_instant_construct_calendar_A) Invoke_O_O_O_O_O_O_O_O_O_O_O__O(self, years__0, months__1, days__2, hours__3, minutes__4, seconds__5, nanoseconds__6, offset_sign__7, offset_hours__8, offset_minutes__9 any) any { var G__783000075__11_ any; var tmp1 int32 = lang.RT_IntCast_O__I_NoInit(years__0); var tmp2 jrt.Number_I; var na_886 any = months__1; if





	jrt.Long_InstanceOf(na_886) { var n0_887 int64 = jrt.NN(jrt.Long_Cast(na_886)).LongValue__J(); if n0_887 == -9223372036854775808 { tmp2 = lang.Numbers_Dec_O__Number_NoInit(na_886) } else { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_887 - 1)) } } else { if jrt.Double_InstanceOf(na_886) { var n0_887_2 float64 = jrt.NN(jrt.Double_Cast(na_886)).DoubleValue__D(); tmp2 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_887_2 - 1.0)) } else { tmp2 = lang.Numbers_Dec_O__Number_NoInit(na_886) } }; G__783000075__11_ = /*line :303:1*/jrt.GregorianCalendar_New_I_I_I_I_I_I(tmp1, lang.RT_IntCast_O__I_NoInit(tmp2), lang.RT_IntCast_O__I_NoInit(days__2), lang.RT_IntCast_O__I_NoInit(hours__3), lang.RT_IntCast_O__I_NoInit(minutes__4), lang.RT_IntCast_O__I_NoInit(seconds__5)); var tmp3 jrt.Calendar_I =






	jrt.Calendar_Cast(G__783000075__11_); var tmp4 jrt.Number_I; var na_888 any = nanoseconds__6; var na_889 int64 = 1000000; if jrt.Long_InstanceOf(na_888) { var n0_890 int64 = jrt.NN(jrt.Long_Cast(na_888)).LongValue__J(); var n1_891 int64 = na_889; if n1_891 == 0 { tmp4 = lang.Numbers_Quotient_O_J__Number_NoInit(na_888, na_889) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_890 / n1_891)) } } else { tmp4 = lang.Numbers_Quotient_O_J__Number_NoInit(na_888, na_889) }; tmp3.Set_I_I__V(14, lang.RT_IntCast_O__I_NoInit(tmp4)); var tmp5 /*line :311:1*/*jrt.GregorianCalendar = jrt.GregorianCalendar_Cast(G__783000075__11_); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_45.GetRawRoot__O()); var tmp7 *jrt.String; var tmp8 bool; var na_900 any = offset_sign__7; if

	jrt.Long_InstanceOf(na_900) { var n0_901 int64 = jrt.NN(jrt.Long_Cast(na_900)).LongValue__J(); tmp8 = n0_901 < 0 } else { if jrt.Double_InstanceOf(na_900) { var n0_901_2 float64 = jrt.NN(jrt.Double_Cast(na_900)).DoubleValue__D(); tmp8 = n0_901_2 < 0.0 } else { tmp8 = lang.Numbers_IsNeg_O__Z_NoInit(na_900) } }; if tmp8 { tmp7 = Lit_2 } else { tmp7 = Lit_3 }; /*line :311:1*/jrt.NN(tmp5).SetTimeZone_TimeZone__V(jrt.TimeZone_GetTimeZone_String__TimeZone(jrt.String_Cast(tmp6.Invoke_O_O_O_O__O(Lit_1, tmp7.Ref(), offset_hours__8, offset_minutes__9)))); return G__783000075__11_ }




func A_arbace_instant_construct_timestamp_A_New() *A_arbace_instant_construct_timestamp_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_construct_timestamp_A{}; t.Ctor(); return t }
//line :316:1
func (t *A_arbace_instant_construct_timestamp_A) Ctor() {}
//line :316:1
func (t *A_arbace_instant_construct_timestamp_A) Invoke_O_O_O_O_O_O_O_O_O_O_O__O(self, years__0, months__1, days__2, hours__3, minutes__4, seconds__5, nanoseconds__6, offset_sign__7, offset_hours__8, offset_minutes__9 any) any { var G__783000077__11_ any; var tmp1 any; var root_902 any = A_arbace_instant_A_const_53.GetRawRoot__O(); var linked_903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_902, A_arbace_instant_construct_calendar_A_fn_class); var ifn_904 lang.IFn; if





	linked_903 == nil { ifn_904 = lang.IFn_Cast(root_902) } else { ifn_904 = nil }; var arg_905 any = years__0; var arg_906 any = months__1; var arg_907 any = days__2; var arg_908 any = hours__3; var arg_909 any = minutes__4; var arg_910 any = seconds__5; var arg_911 any = A_arbace_instant_A_const_25; var arg_912 any = offset_sign__7; var arg_913 any = offset_hours__8; var arg_914 any = offset_minutes__9; if linked_903 == nil { tmp1 = ifn_904.Invoke_O_O_O_O_O_O_O_O_O_O__O(arg_905, arg_906, arg_907, arg_908, arg_909, arg_910, arg_911, arg_912, arg_913, arg_914) } else { tmp1 = linked_903.(*A_arbace_instant_construct_calendar_A).Invoke_O_O_O_O_O_O_O_O_O_O_O__O(root_902, arg_905, arg_906, arg_907, arg_908, arg_909, arg_910, arg_911, arg_912, arg_913, arg_914) }; G__783000077__11_ = /*line :316:1*/jrt.Timestamp_New_J(jrt.Calendar_Cast(tmp1).GetTimeInMillis__J());









	jrt.NN(jrt.Timestamp_Cast(G__783000077__11_)).SetNanos_I__V(lang.RT_IntCast_O__I_NoInit(nanoseconds__6)); return G__783000077__11_ }

func A_arbace_instant_read_instant_calendar_A_New() *A_arbace_instant_read_instant_calendar_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_read_instant_calendar_A{}; t.Ctor(); return t }
//line :328:1
func (t *A_arbace_instant_read_instant_calendar_A) Ctor() {}
//line :328:1
func (t *A_arbace_instant_read_instant_calendar_A) Invoke_O_O__O(self, cs__0 any) any {




	var root_915 any = A_arbace_instant_A_const_50.GetRawRoot__O(); var linked_916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_915, A_arbace_instant_parse_timestamp_A_fn_class); var ifn_917 lang.IFn; if linked_916 == nil { ifn_917 = lang.IFn_Cast(root_915) } else { ifn_917 = nil }; var arg_918 any; var root_920 any = A_arbace_instant_A_const_51.GetRawRoot__O(); var linked_921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_920, A_arbace_instant_validated_A_fn_class); var ifn_922 lang.IFn; if linked_921 == nil { ifn_922 = lang.IFn_Cast(root_920) } else { ifn_922 = nil }; var arg_923 any = A_arbace_instant_A_const_53.GetRawRoot__O(); if linked_921 == nil { arg_918 = ifn_922.Invoke_O__O(arg_923) } else { arg_918 = linked_921.(*A_arbace_instant_validated_A).Invoke_O_O__O(root_920, arg_923) }; var arg_919 any = cs__0; if linked_916 == nil { return ifn_917.Invoke_O_O__O(arg_918, arg_919) } else { return linked_916.(*A_arbace_instant_parse_timestamp_A).Invoke_O_O_O__O(root_915, arg_918, arg_919)
	} }
func A_arbace_instant_read_instant_timestamp_A_New() *A_arbace_instant_read_instant_timestamp_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_read_instant_timestamp_A{}; t.Ctor(); return t }
//line :335:1
func (t *A_arbace_instant_read_instant_timestamp_A) Ctor() {}
//line :335:1
func (t *A_arbace_instant_read_instant_timestamp_A) Invoke_O_O__O(self, cs__0 any) any {





	var root_924 any = A_arbace_instant_A_const_50.GetRawRoot__O(); var linked_925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_924, A_arbace_instant_parse_timestamp_A_fn_class); var ifn_926 lang.IFn; if linked_925 == nil { ifn_926 = lang.IFn_Cast(root_924) } else { ifn_926 = nil }; var arg_927 any; var root_929 any = A_arbace_instant_A_const_51.GetRawRoot__O(); var linked_930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_929, A_arbace_instant_validated_A_fn_class); var ifn_931 lang.IFn; if linked_930 == nil { ifn_931 = lang.IFn_Cast(root_929) } else { ifn_931 = nil }; var arg_932 any = A_arbace_instant_A_const_54.GetRawRoot__O(); if linked_930 == nil { arg_927 = ifn_931.Invoke_O__O(arg_932) } else { arg_927 = linked_930.(*A_arbace_instant_validated_A).Invoke_O_O__O(root_929, arg_932) }; var arg_928 any = cs__0; if linked_925 == nil { return ifn_926.Invoke_O_O__O(arg_927, arg_928) } else { return linked_925.(*A_arbace_instant_parse_timestamp_A).Invoke_O_O_O__O(root_924, arg_927, arg_928)
	} }
type A_arbace_instant_A struct{ jrt.Object }

var A_arbace_instant_A_const_pool *jrt.RefArray

var A_arbace_instant_A_const_0 *lang.Var

var A_arbace_instant_A_const_1 any

var A_arbace_instant_A_const_2 *lang.Var

var A_arbace_instant_A_const_3 *lang.Var

var A_arbace_instant_A_const_4 *lang.Var

var A_arbace_instant_A_const_5 *lang.Var

var A_arbace_instant_A_const_6 any

var A_arbace_instant_A_const_7 *lang.Var

var A_arbace_instant_A_const_8 *lang.Var

var A_arbace_instant_A_const_9 *lang.Var

var A_arbace_instant_A_const_10 any

var A_arbace_instant_A_const_11 any

var A_arbace_instant_A_const_12 any

var A_arbace_instant_A_const_13 any

var A_arbace_instant_A_const_14 any

var A_arbace_instant_A_const_15 *lang.Var

var A_arbace_instant_A_const_16 *lang.Var

var A_arbace_instant_A_const_17 *lang.Var

var A_arbace_instant_A_const_18 *lang.Var

var A_arbace_instant_A_const_19 *lang.Keyword

var A_arbace_instant_A_const_20 any

var A_arbace_instant_A_const_21 *lang.Var

var A_arbace_instant_A_const_22 *lang.Var

var A_arbace_instant_A_const_23 *lang.Var

var A_arbace_instant_A_const_24 any

var A_arbace_instant_A_const_25 any

var A_arbace_instant_A_const_26 *lang.Var

var A_arbace_instant_A_const_27 any

var A_arbace_instant_A_const_28 any

var A_arbace_instant_A_const_29 any

var A_arbace_instant_A_const_30 *lang.Var

var A_arbace_instant_A_const_31 any

var A_arbace_instant_A_const_32 any

var A_arbace_instant_A_const_33 any

var A_arbace_instant_A_const_34 any

var A_arbace_instant_A_const_35 *lang.Var

var A_arbace_instant_A_const_36 any

var A_arbace_instant_A_const_37 *lang.Var

var A_arbace_instant_A_const_38 *lang.Var

var A_arbace_instant_A_const_39 any

var A_arbace_instant_A_const_40 any

var A_arbace_instant_A_const_41 any

var A_arbace_instant_A_const_42 any

var A_arbace_instant_A_const_43 *lang.Var

var A_arbace_instant_A_const_44 *lang.Var

var A_arbace_instant_A_const_45 *lang.Var

var A_arbace_instant_A_const_46 *lang.Var

var A_arbace_instant_A_const_47 *lang.Var

var A_arbace_instant_A_const_48 *lang.Var

var A_arbace_instant_A_const_49 *lang.Var

var A_arbace_instant_A_const_50 *lang.Var

var A_arbace_instant_A_const_51 *lang.Var

var A_arbace_instant_A_const_52 *lang.Var

var A_arbace_instant_A_const_53 *lang.Var

var A_arbace_instant_A_const_54 *lang.Var

var A_arbace_instant_A_init jrt.ClassInit

func A_arbace_instant_A_Init() { if !A_arbace_instant_A_init.Done() { A_arbace_instant_A_init.Run(A_arbace_instant_A_clinit) } }

func A_arbace_instant_A_clinit() { A_arbace_instant_A_clinit_p0(); A_arbace_instant_A_clinit_p1(); A_arbace_instant_A_clinit_p2(); A_arbace_instant_A_clinit_p3(); A_arbace_instant_A_clinit_p4() }

func A_arbace_instant_A_clinit_p0() { jrt.StartCheck(); A_arbace_instant_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 63); A_arbace_instant_A_const_0 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[8]); A_arbace_instant_A_const_1 = A_arbace_instant_A_const_pool.A[9]; A_arbace_instant_A_const_2 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[10]); A_arbace_instant_A_const_3 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[11]); A_arbace_instant_A_const_4 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[12]); A_arbace_instant_A_const_5 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[13]); A_arbace_instant_A_const_6 = A_arbace_instant_A_const_pool.A[14]; A_arbace_instant_A_const_7 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[15]); A_arbace_instant_A_const_8 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[16]); A_arbace_instant_A_const_9 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[17]); A_arbace_instant_A_const_10 = A_arbace_instant_A_const_pool.A[18]; A_arbace_instant_A_const_11 = A_arbace_instant_A_const_pool.A[19] }

func A_arbace_instant_A_clinit_p1() { A_arbace_instant_A_const_12 = A_arbace_instant_A_const_pool.A[20]; A_arbace_instant_A_const_13 = A_arbace_instant_A_const_pool.A[21]; A_arbace_instant_A_const_14 = A_arbace_instant_A_const_pool.A[22]; A_arbace_instant_A_const_15 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[23]); A_arbace_instant_A_const_16 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[24]); A_arbace_instant_A_const_17 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[25]); A_arbace_instant_A_const_18 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[26]); A_arbace_instant_A_const_19 = lang.Keyword_Cast(A_arbace_instant_A_const_pool.A[27]); A_arbace_instant_A_const_20 = A_arbace_instant_A_const_pool.A[28]; A_arbace_instant_A_const_21 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[29]); A_arbace_instant_A_const_22 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[30]); A_arbace_instant_A_const_23 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[31]); A_arbace_instant_A_const_24 = A_arbace_instant_A_const_pool.A[32] }

func A_arbace_instant_A_clinit_p2() { A_arbace_instant_A_const_25 = A_arbace_instant_A_const_pool.A[33]; A_arbace_instant_A_const_26 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[34]); A_arbace_instant_A_const_27 = A_arbace_instant_A_const_pool.A[35]; A_arbace_instant_A_const_28 = A_arbace_instant_A_const_pool.A[36]; A_arbace_instant_A_const_29 = A_arbace_instant_A_const_pool.A[37]; A_arbace_instant_A_const_30 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[38]); A_arbace_instant_A_const_31 = A_arbace_instant_A_const_pool.A[39]; A_arbace_instant_A_const_32 = A_arbace_instant_A_const_pool.A[40]; A_arbace_instant_A_const_33 = A_arbace_instant_A_const_pool.A[41]; A_arbace_instant_A_const_34 = A_arbace_instant_A_const_pool.A[42]; A_arbace_instant_A_const_35 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[43]); A_arbace_instant_A_const_36 = A_arbace_instant_A_const_pool.A[44]; A_arbace_instant_A_const_37 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[45]); A_arbace_instant_A_const_38 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[46]) }

func A_arbace_instant_A_clinit_p3() { A_arbace_instant_A_const_39 = A_arbace_instant_A_const_pool.A[47]; A_arbace_instant_A_const_40 = A_arbace_instant_A_const_pool.A[48]; A_arbace_instant_A_const_41 = A_arbace_instant_A_const_pool.A[49]; A_arbace_instant_A_const_42 = A_arbace_instant_A_const_pool.A[50]; A_arbace_instant_A_const_43 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[51]); A_arbace_instant_A_const_44 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[52]); A_arbace_instant_A_const_45 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[53]); A_arbace_instant_A_const_46 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[54]); A_arbace_instant_A_const_47 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[55]); A_arbace_instant_A_const_48 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[56]); A_arbace_instant_A_const_49 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[57]); A_arbace_instant_A_const_50 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[58]); A_arbace_instant_A_const_51 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[59]) }

func A_arbace_instant_A_clinit_p4() { A_arbace_instant_A_const_52 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[60]); A_arbace_instant_A_const_53 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[61]); A_arbace_instant_A_const_54 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[62]) }

func A_arbace_instant_A_New() *A_arbace_instant_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_A) Ctor() {}

func (t *A_arbace_instant_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_A) GetClass__Class() *jrt.Class { return A_arbace_instant_A_class }

func (t *A_arbace_instant_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_A); return ok }

func A_arbace_instant_A_Cast(x any) *A_arbace_instant_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_A_class)) }; return v }



type A_arbace_instant_civil__GT_days_A struct{ j2g_header uint64 }

var A_arbace_instant_civil__GT_days_A_fn_class *jrt.Class



type A_arbace_instant_construct_calendar_A struct{ j2g_header uint64 }

var A_arbace_instant_construct_calendar_A_fn_class *jrt.Class



type A_arbace_instant_construct_date_A struct{ j2g_header uint64 }

var A_arbace_instant_construct_date_A_fn_class *jrt.Class



type A_arbace_instant_construct_timestamp_A struct{ j2g_header uint64 }

var A_arbace_instant_construct_timestamp_A_fn_class *jrt.Class



type A_arbace_instant_days__GT_civil_A struct{ j2g_header uint64 }

var A_arbace_instant_days__GT_civil_A_fn_class *jrt.Class



type A_arbace_instant_divisible_QMARK__A struct{ j2g_header uint64 }

var A_arbace_instant_divisible_QMARK__A_fn_class *jrt.Class



type A_arbace_instant_eval783000002_A struct{ jrt.Object }

func A_arbace_instant_eval783000002_A_New() *A_arbace_instant_eval783000002_A { t := &A_arbace_instant_eval783000002_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000002_A) Ctor() {}

func (t *A_arbace_instant_eval783000002_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000002_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000002_A_class }

func (t *A_arbace_instant_eval783000002_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000002_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000002_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000002_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000002_A); return ok }

func A_arbace_instant_eval783000002_A_Cast(x any) *A_arbace_instant_eval783000002_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000002_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000002_A_class)) }; return v }



type A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_fn_class *jrt.Class



type A_arbace_instant_eval783000006_A struct{ jrt.Object }

func A_arbace_instant_eval783000006_A_New() *A_arbace_instant_eval783000006_A { t := &A_arbace_instant_eval783000006_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000006_A) Ctor() {}

func (t *A_arbace_instant_eval783000006_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000006_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000006_A_class }

func (t *A_arbace_instant_eval783000006_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000006_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000006_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000006_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000006_A); return ok }

func A_arbace_instant_eval783000006_A_Cast(x any) *A_arbace_instant_eval783000006_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000006_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000006_A_class)) }; return v }



type A_arbace_instant_eval783000006_fn__783000007_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000006_fn__783000007_A_fn_class *jrt.Class



type A_arbace_instant_eval783000044_A struct{ jrt.Object }

func A_arbace_instant_eval783000044_A_New() *A_arbace_instant_eval783000044_A { t := &A_arbace_instant_eval783000044_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000044_A) Ctor() {}

func (t *A_arbace_instant_eval783000044_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000044_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000044_A_class }

func (t *A_arbace_instant_eval783000044_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000044_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000044_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000044_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000044_A); return ok }

func A_arbace_instant_eval783000044_A_Cast(x any) *A_arbace_instant_eval783000044_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000044_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000044_A_class)) }; return v }



type A_arbace_instant_eval783000044_fn__783000045_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000044_fn__783000045_A_fn_class *jrt.Class



type A_arbace_instant_eval783000048_A struct{ jrt.Object }

func A_arbace_instant_eval783000048_A_New() *A_arbace_instant_eval783000048_A { t := &A_arbace_instant_eval783000048_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000048_A) Ctor() {}

func (t *A_arbace_instant_eval783000048_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000048_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000048_A_class }

func (t *A_arbace_instant_eval783000048_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000048_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000048_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000048_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000048_A); return ok }

func A_arbace_instant_eval783000048_A_Cast(x any) *A_arbace_instant_eval783000048_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000048_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000048_A_class)) }; return v }



type A_arbace_instant_eval783000048_fn__783000049_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000048_fn__783000049_A_fn_class *jrt.Class



type A_arbace_instant_eval783000053_A struct{ jrt.Object }

func A_arbace_instant_eval783000053_A_New() *A_arbace_instant_eval783000053_A { t := &A_arbace_instant_eval783000053_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000053_A) Ctor() {}

func (t *A_arbace_instant_eval783000053_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000053_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000053_A_class }

func (t *A_arbace_instant_eval783000053_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000053_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000053_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000053_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000053_A); return ok }

func A_arbace_instant_eval783000053_A_Cast(x any) *A_arbace_instant_eval783000053_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000053_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000053_A_class)) }; return v }



type A_arbace_instant_eval783000053_fn__783000054_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000053_fn__783000054_A_fn_class *jrt.Class



type A_arbace_instant_eval783000057_A struct{ jrt.Object }

func A_arbace_instant_eval783000057_A_New() *A_arbace_instant_eval783000057_A { t := &A_arbace_instant_eval783000057_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000057_A) Ctor() {}

func (t *A_arbace_instant_eval783000057_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000057_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000057_A_class }

func (t *A_arbace_instant_eval783000057_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000057_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000057_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000057_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000057_A); return ok }

func A_arbace_instant_eval783000057_A_Cast(x any) *A_arbace_instant_eval783000057_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000057_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000057_A_class)) }; return v }



type A_arbace_instant_eval783000057_fn__783000058_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000057_fn__783000058_A_fn_class *jrt.Class



type A_arbace_instant_eval783000065_A struct{ jrt.Object }

func A_arbace_instant_eval783000065_A_New() *A_arbace_instant_eval783000065_A { t := &A_arbace_instant_eval783000065_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000065_A) Ctor() {}

func (t *A_arbace_instant_eval783000065_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000065_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000065_A_class }

func (t *A_arbace_instant_eval783000065_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000065_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000065_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000065_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000065_A); return ok }

func A_arbace_instant_eval783000065_A_Cast(x any) *A_arbace_instant_eval783000065_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000065_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000065_A_class)) }; return v }



type A_arbace_instant_eval783000065_fn__783000066_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000065_fn__783000066_A_fn_class *jrt.Class



type A_arbace_instant_eval783000069_A struct{ jrt.Object }

func A_arbace_instant_eval783000069_A_New() *A_arbace_instant_eval783000069_A { t := &A_arbace_instant_eval783000069_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000069_A) Ctor() {}

func (t *A_arbace_instant_eval783000069_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000069_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000069_A_class }

func (t *A_arbace_instant_eval783000069_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000069_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000069_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000069_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000069_A); return ok }

func A_arbace_instant_eval783000069_A_Cast(x any) *A_arbace_instant_eval783000069_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000069_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000069_A_class)) }; return v }



type A_arbace_instant_eval783000069_fn__783000070_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000069_fn__783000070_A_fn_class *jrt.Class



type A_arbace_instant_fail_A struct{ j2g_header uint64 }

var A_arbace_instant_fail_A_fn_class *jrt.Class



type A_arbace_instant_fn__783000031_A struct{ j2g_header uint64 }

var A_arbace_instant_fn__783000031_A_fn_class *jrt.Class



type A_arbace_instant_fn__783000031_fn__783000032_A struct{ j2g_header uint64; F_dim_norm, F_dim_leap any }

var A_arbace_instant_fn__783000031_fn__783000032_A_fn_class *jrt.Class



type A_arbace_instant_indivisible_QMARK__A struct{ j2g_header uint64 }

var A_arbace_instant_indivisible_QMARK__A_fn_class *jrt.Class



type A_arbace_instant_leap_year_QMARK__A struct{ j2g_header uint64 }

var A_arbace_instant_leap_year_QMARK__A_fn_class *jrt.Class



type A_arbace_instant_parse_int_A struct{ j2g_header uint64 }

var A_arbace_instant_parse_int_A_fn_class *jrt.Class



type A_arbace_instant_parse_timestamp_A struct{ j2g_header uint64 }

var A_arbace_instant_parse_timestamp_A_fn_class *jrt.Class



type A_arbace_instant_print_calendar_A struct{ j2g_header uint64 }

var A_arbace_instant_print_calendar_A_fn_class *jrt.Class



type A_arbace_instant_print_date_A struct{ j2g_header uint64 }

var A_arbace_instant_print_date_A_fn_class *jrt.Class



type A_arbace_instant_print_timestamp_A struct{ j2g_header uint64 }

var A_arbace_instant_print_timestamp_A_fn_class *jrt.Class



type A_arbace_instant_read_instant_calendar_A struct{ j2g_header uint64 }

var A_arbace_instant_read_instant_calendar_A_fn_class *jrt.Class



type A_arbace_instant_read_instant_date_A struct{ j2g_header uint64 }

var A_arbace_instant_read_instant_date_A_fn_class *jrt.Class



type A_arbace_instant_read_instant_timestamp_A struct{ j2g_header uint64 }

var A_arbace_instant_read_instant_timestamp_A_fn_class *jrt.Class



type A_arbace_instant_validated_A struct{ j2g_header uint64 }

var A_arbace_instant_validated_A_fn_class *jrt.Class



type A_arbace_instant_validated_fn__783000035_A struct{ j2g_header uint64; F_new_instance any }

var A_arbace_instant_validated_fn__783000035_A_fn_class *jrt.Class



type A_arbace_instant_verify_A struct{ j2g_header uint64 }

var A_arbace_instant_verify_A_fn_class *jrt.Class



type A_arbace_instant_zero_fill_right_A struct{ j2g_header uint64 }

var A_arbace_instant_zero_fill_right_A_fn_class *jrt.Class
