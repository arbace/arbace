//line aot_arbace_instant.ae:1
package aot_arbace_instant

import (
	"arbace/jrt"
	"arbace/lang"
)














func A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_New() *A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A) Ctor() {}
//line :21:1
func (t *A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_instant_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_1); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_4)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_5)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_6)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_7)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_8)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :21:1
func A_arbace_instant_eval783000006_fn__783000007_A_New() *A_arbace_instant_eval783000006_fn__783000007_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000006_fn__783000007_A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_instant_eval783000006_fn__783000007_A) Ctor() {}
//line :21:1
func (t *A_arbace_instant_eval783000006_fn__783000007_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_instant_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_instant_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_6), A_arbace_instant_A_const_4.GetRawRoot__O(), A_arbace_instant_A_const_5) }








func A_arbace_instant_fail_A_New() *A_arbace_instant_fail_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_fail_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_instant_fail_A) Ctor() {}
//line :30:1
func (t *A_arbace_instant_fail_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, msg__2 any) any { return lang.IFn_Cast(A_arbace_instant_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_instant_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_10), lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_instant_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_instant_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_11), lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(msg__2)))))) }



func A_arbace_instant_verify_A_New() *A_arbace_instant_verify_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_verify_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_instant_verify_A) Ctor() {}
//line :34:1
func (t *A_arbace_instant_verify_A) Invoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, test__2, msg__3 any) any { return lang.IFn_Cast(A_arbace_instant_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_instant_A_const_8.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_12), lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(test__2), lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_instant_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_instant_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_13), lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(msg__3)))))) }
//line :34:1
func (t *A_arbace_instant_verify_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, test__2 any) any { return lang.IFn_Cast(A_arbace_instant_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_instant_A_const_8.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_14), lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(test__2), lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_28, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_instant_A_const_15.GetRawRoot__O()).Invoke_O__O(test__2))).Ref()))) }



func A_arbace_instant_divisible_QMARK__A_New() *A_arbace_instant_divisible_QMARK__A { A_arbace_instant_A_Init(); t := &A_arbace_instant_divisible_QMARK__A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_instant_divisible_QMARK__A) Ctor() {}
//line :38:1
func (t *A_arbace_instant_divisible_QMARK__A) Invoke_O_O_O__O(self, num__0, div__1 any) any {

	var tmp1 bool; var na_1 any = lang.IFn_Cast(A_arbace_instant_A_const_16.GetRawRoot__O()).Invoke_O_O__O(num__0, div__1); if jrt.Long_InstanceOf(na_1) { var n0_2 int64 = jrt.NN(jrt.Long_Cast(na_1)).LongValue__J(); tmp1 = n0_2 == 0 } else { if jrt.Double_InstanceOf(na_1) { var n0_2_2 float64 = jrt.NN(jrt.Double_Cast(na_1)).DoubleValue__D(); tmp1 = n0_2_2 == 0.0 } else { tmp1 = lang.Numbers_IsZero_O__Z_NoInit(na_1) } }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp1).Ref()
}
func A_arbace_instant_indivisible_QMARK__A_New() *A_arbace_instant_indivisible_QMARK__A { A_arbace_instant_A_Init(); t := &A_arbace_instant_indivisible_QMARK__A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_instant_indivisible_QMARK__A) Ctor() {}
//line :42:1
func (t *A_arbace_instant_indivisible_QMARK__A) Invoke_O_O_O__O(self, num__0, div__1 any) any {

	return lang.IFn_Cast(A_arbace_instant_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_instant_A_const_18.GetRawRoot__O()).Invoke_O_O__O(num__0, div__1))
}



func A_arbace_instant_parse_int_A_New() *A_arbace_instant_parse_int_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_parse_int_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_instant_parse_int_A) Ctor() {}
//line :49:1
func (t *A_arbace_instant_parse_int_A) Invoke_O_O__O(self, s__0 any) any {
	return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(s__0))).Ref()
}
func A_arbace_instant_zero_fill_right_A_New() *A_arbace_instant_zero_fill_right_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_zero_fill_right_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_instant_zero_fill_right_A) Ctor() {}
//line :52:1
func (t *A_arbace_instant_zero_fill_right_A) Invoke_O_O_O__O(self, s__0, width__1 any) any {
	if lang.Util_Equiv_O_J__Z_NoInit(width__1, int64(lang.RT_Count_O__I_NoInit(s__0))) { return s__0 } else { var tmp1 bool; var na_3 any = width__1; var na_4 int64 = int64(lang.RT_Count_O__I_NoInit(s__0))
		if jrt.Long_InstanceOf(na_3) { var n0_5 int64 = jrt.NN(jrt.Long_Cast(na_3)).LongValue__J(); var n1_6 int64 = na_4; tmp1 = n0_5 < n1_6 } else { tmp1 = lang.Numbers_Lt_O_J__Z_NoInit(na_3, na_4) }
//line :53:1
		if tmp1 {
			return jrt.NN(jrt.String_Cast(s__0)).Substring_I_I__String(lang.RT_IntCast_J__I_NoInit(0), lang.RT_IntCast_O__I_NoInit(width__1)).Ref() } else {
//line :53:1
				if A_arbace_instant_A_const_19 != nil { var b__3 any = jrt.StringBuilder_New_String(jrt.String_Cast(s__0)); L1: for {


					var tmp2 bool; var na_8 int64 = int64(jrt.NN(jrt.StringBuilder_Cast(b__3)).Length__I()); var na_9 any = width__1; if jrt.Long_InstanceOf(na_9) { var n0_10 int64 = na_8; var n1_11 int64 = jrt.NN(jrt.Long_Cast(na_9)).LongValue__J(); tmp2 = n0_10 < n1_11 } else { tmp2 = lang.Numbers_Lt_J_O__Z_NoInit(na_8, na_9) }; if tmp2 {
						b__3 = jrt.NN(jrt.StringBuilder_Cast(b__3)).Append_O__StringBuilder(A_arbace_instant_A_const_20).Ref(); continue L1 } else {
							return jrt.NN(jrt.StringBuilder_Cast(b__3)).ToString__String().Ref() } } } else {
//line :53:1
								return nil } } }
//line :52:1
	panic("j2g: unreachable")
}









func A_arbace_instant_parse_timestamp_A_New() *A_arbace_instant_parse_timestamp_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_parse_timestamp_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_instant_parse_timestamp_A) Ctor() {}
//line :63:1
func (t *A_arbace_instant_parse_timestamp_A) Invoke_O_O_O__O(self, new_instant__0, cs__1 any) any { var temp__1927000408__auto____3 any = lang.IFn_Cast(A_arbace_instant_A_const_21.GetRawRoot__O()).Invoke_O_O__O(A_arbace_instant_A_const_22.GetRawRoot__O(), cs__1); if



















































	jrt.J2g_Truth(temp__1927000408__auto____3) { var vec__783000026__4 any = temp__1927000408__auto____3; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(0), nil); var years__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(1), nil); var months__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(2), nil); var days__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(3), nil); var hours__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(4), nil); var minutes__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(5), nil); var seconds__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(6), nil); var fraction__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(7), nil); var offset_sign__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(8), nil); var offset_hours__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(9), nil); var offset_minutes__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000026__4, lang.RT_IntCast_J__I_NoInit(10), nil); var tmp1 lang.IFn = lang.IFn_Cast(new_instant__0); var tmp2 any = lang.IFn_Cast(A_arbace_instant_A_const_23.GetRawRoot__O()).Invoke_O__O(years__6); var tmp3 any; _ = ___5




		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_17.GetRawRoot__O()).Invoke_O__O(months__7)) { tmp3 = A_arbace_instant_A_const_24 } else { tmp3 = lang.IFn_Cast(A_arbace_instant_A_const_23.GetRawRoot__O()).Invoke_O__O(months__7) }
//line :118:1
		var tmp4 any = tmp3; var tmp5 any


		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_17.GetRawRoot__O()).Invoke_O__O(days__8)) { tmp5 = A_arbace_instant_A_const_24 } else { tmp5 = lang.IFn_Cast(A_arbace_instant_A_const_23.GetRawRoot__O()).Invoke_O__O(days__8) }
//line :118:1
		var tmp6 any = tmp5; var tmp7 any



		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_17.GetRawRoot__O()).Invoke_O__O(hours__9)) { tmp7 = A_arbace_instant_A_const_25 } else { tmp7 = lang.IFn_Cast(A_arbace_instant_A_const_23.GetRawRoot__O()).Invoke_O__O(hours__9) }
//line :118:1
		var tmp8 any = tmp7; var tmp9 any




		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_17.GetRawRoot__O()).Invoke_O__O(minutes__10)) { tmp9 = A_arbace_instant_A_const_25 } else { tmp9 = lang.IFn_Cast(A_arbace_instant_A_const_23.GetRawRoot__O()).Invoke_O__O(minutes__10) }
//line :118:1
		var tmp10 any = tmp9; var tmp11 any





		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_17.GetRawRoot__O()).Invoke_O__O(seconds__11)) { tmp11 = A_arbace_instant_A_const_25 } else { tmp11 = lang.IFn_Cast(A_arbace_instant_A_const_23.GetRawRoot__O()).Invoke_O__O(seconds__11) }
//line :118:1
		var tmp12 any = tmp11; var tmp13 any






		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_17.GetRawRoot__O()).Invoke_O__O(fraction__12)) { tmp13 = A_arbace_instant_A_const_25 } else { tmp13 = lang.IFn_Cast(A_arbace_instant_A_const_23.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_instant_A_const_27.GetRawRoot__O()).Invoke_O_O__O(fraction__12, A_arbace_instant_A_const_28)) }
//line :118:1
		var tmp14 any = tmp13; var tmp15 any







		if lang.Util_Equiv_O_O__Z_NoInit(Lit_2, offset_sign__13) { tmp15 = A_arbace_instant_A_const_26 } else { if lang.Util_Equiv_O_O__Z_NoInit(Lit_3, offset_sign__13) { tmp15 = A_arbace_instant_A_const_24 } else { if A_arbace_instant_A_const_19 != nil { tmp15 = A_arbace_instant_A_const_25 } else { tmp15 = nil } } }
//line :118:1
		var tmp16 any = tmp15; var tmp17 any










		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_17.GetRawRoot__O()).Invoke_O__O(offset_hours__14)) { tmp17 = A_arbace_instant_A_const_25 } else { tmp17 = lang.IFn_Cast(A_arbace_instant_A_const_23.GetRawRoot__O()).Invoke_O__O(offset_hours__14) }
//line :118:1
		var tmp18 any = tmp17; var tmp19 any











		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_17.GetRawRoot__O()).Invoke_O__O(offset_minutes__15)) { tmp19 = A_arbace_instant_A_const_25 } else { tmp19 = lang.IFn_Cast(A_arbace_instant_A_const_23.GetRawRoot__O()).Invoke_O__O(offset_minutes__15) }
//line :118:1
		return tmp1.Invoke_O_O_O_O_O_O_O_O_O_O__O(tmp2, tmp4, tmp6, tmp8, tmp10, tmp12, tmp14, tmp16, tmp18, tmp19) } else {
//line :115:1
			panic(jrt.Thrown(jrt.RuntimeException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, cs__1))))) } }




















func A_arbace_instant_leap_year_QMARK__A_New() *A_arbace_instant_leap_year_QMARK__A { A_arbace_instant_A_Init(); t := &A_arbace_instant_leap_year_QMARK__A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_instant_leap_year_QMARK__A) Ctor() {}
//line :136:1
func (t *A_arbace_instant_leap_year_QMARK__A) Invoke_O_O__O(self, year__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_instant_A_const_18.GetRawRoot__O()).Invoke_O_O__O(year__0, A_arbace_instant_A_const_30); if

	jrt.J2g_Truth(and__1927000168__auto____2) { var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_instant_A_const_29.GetRawRoot__O()).Invoke_O_O__O(year__0, A_arbace_instant_A_const_31)
		if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else {
			return lang.IFn_Cast(A_arbace_instant_A_const_18.GetRawRoot__O()).Invoke_O_O__O(year__0, A_arbace_instant_A_const_32) } } else {
//line :138:1
				return and__1927000168__auto____2 } }




func A_arbace_instant_fn__783000031_A_New() *A_arbace_instant_fn__783000031_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_fn__783000031_A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_instant_fn__783000031_A) Ctor() {}
//line :143:1
func (t *A_arbace_instant_fn__783000031_A) Invoke_O__O(self any) any { var dim_norm__1 any = A_arbace_instant_A_const_33; var dim_leap__2 any = A_arbace_instant_A_const_34; var tmp1 any = A_arbace_instant_fn__783000031_fn__783000032_A_New_O_O(dim_norm__1, dim_leap__2); var tmp2 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_instant_fn__783000031_fn__783000032_A_fn_class; if

	fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_instant_fn__783000031_fn__783000032_A_fn_class = fncls__13d; tmp2 = fncls__13d } else { tmp2 = fncls__13 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :145:1
func A_arbace_instant_fn__783000031_fn__783000032_A_New_O_O(p0, p1 any) *A_arbace_instant_fn__783000031_fn__783000032_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_fn__783000031_fn__783000032_A{}; t.Ctor_O_O(p0, p1); return t }
//line :145:1
func (t *A_arbace_instant_fn__783000031_fn__783000032_A) Ctor_O_O(c__dim_norm, c__dim_leap any) { t.F_dim_norm = c__dim_norm; t.F_dim_leap = c__dim_leap }
//line :145:1
func (t *A_arbace_instant_fn__783000031_fn__783000032_A) Invoke_O_O_O__O(self, month__1, leap_year_QMARK___2 any) any {
	var tmp1 any; if jrt.J2g_Truth(leap_year_QMARK___2) { tmp1 = t.F_dim_leap } else { tmp1 = t.F_dim_norm }; return lang.IFn_Cast(tmp1).Invoke_O__O(month__1)
}
func A_arbace_instant_validated_A_New() *A_arbace_instant_validated_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_validated_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_instant_validated_A) Ctor() {}
//line :148:1
func (t *A_arbace_instant_validated_A) Invoke_O_O__O(self, new_instance__0 any) any {





	var tmp1 any = A_arbace_instant_validated_fn__783000035_A_New_O(new_instance__0); var tmp2 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_instant_validated_fn__783000035_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_instant_validated_fn__783000035_A_fn_class = fncls__14d; tmp2 = fncls__14d } else { tmp2 = fncls__14 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :154:1
func A_arbace_instant_validated_fn__783000035_A_New_O(p0 any) *A_arbace_instant_validated_fn__783000035_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_validated_fn__783000035_A{}; t.Ctor_O(p0); return t }
//line :154:1
func (t *A_arbace_instant_validated_fn__783000035_A) Ctor_O(c__new_instance any) { t.F_new_instance = c__new_instance }
//line :154:1
func (t *A_arbace_instant_validated_fn__783000035_A) Invoke_O_O_O_O_O_O_O_O_O_O_O__O(self, years__1, months__2, days__3, hours__4, minutes__5, seconds__6, nanoseconds__7, offset_sign__8, offset_hours__9, offset_minutes__10 any) any {

	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_24, months__2, A_arbace_instant_A_const_36)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_19))) }
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()); var tmp2 any = A_arbace_instant_A_const_24; if jrt.J2g_Truth(tmp1.Invoke_O_O_O__O(tmp2, days__3, lang.IFn_Cast(A_arbace_instant_A_const_37.GetRawRoot__O()).Invoke_O_O__O(months__2, lang.IFn_Cast(A_arbace_instant_A_const_38.GetRawRoot__O()).Invoke_O__O(years__1)))) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_20))) }
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_25, hours__4, A_arbace_instant_A_const_39)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_21))) }
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_25, minutes__5, A_arbace_instant_A_const_40)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_22))) }
	var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()); var tmp4 any = A_arbace_instant_A_const_25; var tmp5 any; if lang.Util_Equiv_O_J__Z_NoInit(minutes__5, 59) { tmp5 = A_arbace_instant_A_const_41 } else { tmp5 = A_arbace_instant_A_const_40 }; if jrt.J2g_Truth(tmp3.Invoke_O_O_O__O(tmp4, seconds__6, tmp5)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_23))) }
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_25, nanoseconds__7, A_arbace_instant_A_const_42)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_24))) }
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_26, offset_sign__8, A_arbace_instant_A_const_24)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_25))) }
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_25, offset_hours__9, A_arbace_instant_A_const_39)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_26))) }
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_25, offset_minutes__10, A_arbace_instant_A_const_40)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_27))) }
	return lang.IFn_Cast(t.F_new_instance).Invoke_O_O_O_O_O_O_O_O_O_O__O(years__1, months__2, days__3, hours__4, minutes__5, seconds__6, nanoseconds__7, offset_sign__8, offset_hours__9, offset_minutes__10)
}











func A_arbace_instant_days__GT_civil_A_New() *A_arbace_instant_days__GT_civil_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_days__GT_civil_A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_instant_days__GT_civil_A) Ctor() {}
//line :178:1
func (t *A_arbace_instant_days__GT_civil_A) Invoke_O_O__O(self, z__0 any) any {



	var tmp1 bool; var na_15 any = z__0; var na_16 any = A_arbace_instant_A_const_43.GetRawRoot__O(); var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_15); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_16) }; tmp2 = tmp3; if tmp2 { var n0_17 int64 = jrt.NN(jrt.Long_Cast(na_15)).LongValue__J(); var n1_18 int64 = jrt.NN(jrt.Long_Cast(na_16)).LongValue__J(); tmp1 = n0_17 >= n1_18 } else { var tmp4 bool; var tmp5 bool; tmp5 = jrt.Double_InstanceOf(na_15); if tmp5 { tmp5 = jrt.Double_InstanceOf(na_16) }; tmp4 = tmp5; if tmp4 { var n0_17_2 float64 = jrt.NN(jrt.Double_Cast(na_15)).DoubleValue__D(); var n1_18_2 float64 = jrt.NN(jrt.Double_Cast(na_16)).DoubleValue__D(); tmp1 = n0_17_2 >= n1_18_2 } else { tmp1 = lang.Numbers_Gte_O_O__Z_NoInit(na_15, na_16) } }; if tmp1 { var z__2 any; var na_20 any = z__0; var na_21 int64 = 719468
		if jrt.Long_InstanceOf(na_20) { var n0_22 int64 = jrt.NN(jrt.Long_Cast(na_20)).LongValue__J(); var n1_23 int64 = na_21; var nr_24 int64 = n0_22 + n1_23; if (n0_22^nr_24)&(n1_23^nr_24) >= 0 { z__2 = jrt.Long_ValueOf_J__Long_NoInit(nr_24).Ref() } else { z__2 = lang.Numbers_Add_O_J__Number_NoInit(na_20, na_21) } } else { z__2 = lang.Numbers_Add_O_J__Number_NoInit(na_20, na_21) }
//line :182:1
		var era__3 any; var na_25 any; var tmp6 bool
		var na_27 any = z__2; var na_28 int64 = 0
		if jrt.Long_InstanceOf(na_27) { var n0_29 int64 = jrt.NN(jrt.Long_Cast(na_27)).LongValue__J(); var n1_30 int64 = na_28; tmp6 = n0_29 >= n1_30 } else { tmp6 = lang.Numbers_Gte_O_J__Z_NoInit(na_27, na_28) }; if tmp6 { na_25 = z__2 } else { var na_32 any = z__2; var na_33 int64 = 146096; if jrt.Long_InstanceOf(na_32) { var n0_34 int64 = jrt.NN(jrt.Long_Cast(na_32)).LongValue__J(); var n1_35 int64 = na_33; var nr_36 int64 = n0_34 - n1_35; var tmp7 bool; var tmp8 bool; tmp8 = !(n1_35 == -9223372036854775808); if tmp8 { tmp8 = (n0_34^n1_35)&(n0_34^nr_36) >= 0 }; tmp7 = tmp8; if tmp7 { na_25 = jrt.Long_ValueOf_J__Long_NoInit(nr_36).Ref() } else { na_25 = lang.Numbers_Minus_O_J__Number_NoInit(na_32, na_33) } } else { na_25 = lang.Numbers_Minus_O_J__Number_NoInit(na_32, na_33) } }; var na_26 int64 = 146097; if jrt.Long_InstanceOf(na_25) { var n0_37 int64 = jrt.NN(jrt.Long_Cast(na_25)).LongValue__J(); var n1_38 int64 = na_26; if n1_38 == 0 { era__3 = lang.Numbers_Quotient_O_J__Number_NoInit(na_25, na_26) } else { era__3 = jrt.Long_ValueOf_J__Long_NoInit(n0_37 / n1_38).Ref() } } else { era__3 = lang.Numbers_Quotient_O_J__Number_NoInit(na_25, na_26) }
//line :182:1
		var doe__4 any; var na_40 any = z__2; var na_41 any
		var na_42 any = era__3
		var na_43 int64 = 146097
		if jrt.Long_InstanceOf(na_42) { var n0_44 int64 = jrt.NN(jrt.Long_Cast(na_42)).LongValue__J(); var n1_45 int64 = na_43; var nr_46 int64 = n0_44 * n1_45; var tmp9 bool; var tmp10 bool; var tmp11 bool; var tmp12 bool; tmp12 = n0_44 == -9223372036854775808; if tmp12 { tmp12 = n1_45 < 0 }; tmp11 = tmp12; tmp10 = !tmp11; if tmp10 { var tmp13 bool; tmp13 = n1_45 == 0; if !tmp13 { tmp13 = nr_46/n1_45 == n0_44 }; tmp10 = tmp13 }; tmp9 = tmp10; if tmp9 { na_41 = jrt.Long_ValueOf_J__Long_NoInit(nr_46).Ref() } else { na_41 = lang.Numbers_Multiply_O_J__Number_NoInit(na_42, na_43) } } else { na_41 = lang.Numbers_Multiply_O_J__Number_NoInit(na_42, na_43) }; var tmp14 bool; var tmp15 bool; tmp15 = jrt.Long_InstanceOf(na_40); if tmp15 { tmp15 = jrt.Long_InstanceOf(na_41) }; tmp14 = tmp15; if tmp14 { var n0_47 int64 = jrt.NN(jrt.Long_Cast(na_40)).LongValue__J(); var n1_48 int64 = jrt.NN(jrt.Long_Cast(na_41)).LongValue__J(); var nr_49 int64 = n0_47 - n1_48; var tmp16 bool; var tmp17 bool; tmp17 = !(n1_48 == -9223372036854775808); if tmp17 { tmp17 = (n0_47^n1_48)&(n0_47^nr_49) >= 0 }; tmp16 = tmp17; if tmp16 { doe__4 = jrt.Long_ValueOf_J__Long_NoInit(nr_49).Ref() } else { doe__4 = lang.Numbers_Minus_O_O__Number_NoInit(na_40, na_41) } } else { var tmp18 bool; var tmp19 bool; tmp19 = jrt.Double_InstanceOf(na_40); if tmp19 { tmp19 = jrt.Double_InstanceOf(na_41) }; tmp18 = tmp19; if tmp18 { var n0_47_2 float64 = jrt.NN(jrt.Double_Cast(na_40)).DoubleValue__D(); var n1_48_2 float64 = jrt.NN(jrt.Double_Cast(na_41)).DoubleValue__D(); doe__4 = jrt.Double_ValueOf_D__Double_NoInit(n0_47_2 + -n1_48_2).Ref() } else { doe__4 = lang.Numbers_Minus_O_O__Number_NoInit(na_40, na_41) } }
//line :182:1
		var yoe__5 any; var na_50 any; var na_52 any; var na_54 any; var na_56 any = doe__4; var na_57 any
		var na_58 any = doe__4
		var na_59 int64 = 1460

		if jrt.Long_InstanceOf(na_58) { var n0_60 int64 = jrt.NN(jrt.Long_Cast(na_58)).LongValue__J(); var n1_61 int64 = na_59; if n1_61 == 0 { na_57 = lang.Numbers_Quotient_O_J__Number_NoInit(na_58, na_59) } else { na_57 = jrt.Long_ValueOf_J__Long_NoInit(n0_60 / n1_61).Ref() } } else { na_57 = lang.Numbers_Quotient_O_J__Number_NoInit(na_58, na_59) }; var tmp20 bool; var tmp21 bool; tmp21 = jrt.Long_InstanceOf(na_56); if tmp21 { tmp21 = jrt.Long_InstanceOf(na_57) }; tmp20 = tmp21; if tmp20 { var n0_63 int64 = jrt.NN(jrt.Long_Cast(na_56)).LongValue__J(); var n1_64 int64 = jrt.NN(jrt.Long_Cast(na_57)).LongValue__J(); var nr_65 int64 = n0_63 - n1_64; var tmp22 bool; var tmp23 bool; tmp23 = !(n1_64 == -9223372036854775808); if tmp23 { tmp23 = (n0_63^n1_64)&(n0_63^nr_65) >= 0 }; tmp22 = tmp23; if tmp22 { na_54 = jrt.Long_ValueOf_J__Long_NoInit(nr_65).Ref() } else { na_54 = lang.Numbers_Minus_O_O__Number_NoInit(na_56, na_57) } } else { var tmp24 bool; var tmp25 bool; tmp25 = jrt.Double_InstanceOf(na_56); if tmp25 { tmp25 = jrt.Double_InstanceOf(na_57) }; tmp24 = tmp25; if tmp24 { var n0_63_2 float64 = jrt.NN(jrt.Double_Cast(na_56)).DoubleValue__D(); var n1_64_2 float64 = jrt.NN(jrt.Double_Cast(na_57)).DoubleValue__D(); na_54 = jrt.Double_ValueOf_D__Double_NoInit(n0_63_2 + -n1_64_2).Ref() } else { na_54 = lang.Numbers_Minus_O_O__Number_NoInit(na_56, na_57) } }; var na_55 any; var na_66 any; var na_67 any = doe__4; var na_68 int64 = 36524; if jrt.Long_InstanceOf(na_67) { var n0_69 int64 = jrt.NN(jrt.Long_Cast(na_67)).LongValue__J(); var n1_70 int64 = na_68; if n1_70 == 0 { na_66 = lang.Numbers_Quotient_O_J__Number_NoInit(na_67, na_68) } else { na_66 = jrt.Long_ValueOf_J__Long_NoInit(n0_69 / n1_70).Ref() } } else { na_66 = lang.Numbers_Quotient_O_J__Number_NoInit(na_67, na_68) }; if jrt.Long_InstanceOf(na_66) { var n0_72 int64 = jrt.NN(jrt.Long_Cast(na_66)).LongValue__J(); if n0_72 == -9223372036854775808 { na_55 = lang.Numbers_Minus_O__Number_NoInit(na_66) } else { na_55 = jrt.Long_ValueOf_J__Long_NoInit(-n0_72).Ref() } } else { if jrt.Double_InstanceOf(na_66) { var n0_72_2 float64 = jrt.NN(jrt.Double_Cast(na_66)).DoubleValue__D(); na_55 = jrt.Double_ValueOf_D__Double_NoInit(-n0_72_2).Ref() } else { na_55 = lang.Numbers_Minus_O__Number_NoInit(na_66) } }; var tmp26 bool; var tmp27 bool; tmp27 = jrt.Long_InstanceOf(na_54); if tmp27 { tmp27 = jrt.Long_InstanceOf(na_55) }; tmp26 = tmp27; if tmp26 { var n0_73 int64 = jrt.NN(jrt.Long_Cast(na_54)).LongValue__J(); var n1_74 int64 = jrt.NN(jrt.Long_Cast(na_55)).LongValue__J(); var nr_75 int64 = n0_73 - n1_74; var tmp28 bool; var tmp29 bool; tmp29 = !(n1_74 == -9223372036854775808); if tmp29 { tmp29 = (n0_73^n1_74)&(n0_73^nr_75) >= 0 }; tmp28 = tmp29; if tmp28 { na_52 = jrt.Long_ValueOf_J__Long_NoInit(nr_75).Ref() } else { na_52 = lang.Numbers_Minus_O_O__Number_NoInit(na_54, na_55) } } else { var tmp30 bool; var tmp31 bool; tmp31 = jrt.Double_InstanceOf(na_54); if tmp31 { tmp31 = jrt.Double_InstanceOf(na_55) }; tmp30 = tmp31; if tmp30 { var n0_73_2 float64 = jrt.NN(jrt.Double_Cast(na_54)).DoubleValue__D(); var n1_74_2 float64 = jrt.NN(jrt.Double_Cast(na_55)).DoubleValue__D(); na_52 = jrt.Double_ValueOf_D__Double_NoInit(n0_73_2 + -n1_74_2).Ref() } else { na_52 = lang.Numbers_Minus_O_O__Number_NoInit(na_54, na_55) } }; var na_53 any; var na_76 any = doe__4; var na_77 int64 = 146096; if jrt.Long_InstanceOf(na_76) { var n0_78 int64 = jrt.NN(jrt.Long_Cast(na_76)).LongValue__J(); var n1_79 int64 = na_77; if n1_79 == 0 { na_53 = lang.Numbers_Quotient_O_J__Number_NoInit(na_76, na_77) } else { na_53 = jrt.Long_ValueOf_J__Long_NoInit(n0_78 / n1_79).Ref() } } else { na_53 = lang.Numbers_Quotient_O_J__Number_NoInit(na_76, na_77) }; var tmp32 bool; var tmp33 bool; tmp33 = jrt.Long_InstanceOf(na_52); if tmp33 { tmp33 = jrt.Long_InstanceOf(na_53) }; tmp32 = tmp33; if tmp32 { var n0_81 int64 = jrt.NN(jrt.Long_Cast(na_52)).LongValue__J(); var n1_82 int64 = jrt.NN(jrt.Long_Cast(na_53)).LongValue__J(); var nr_83 int64 = n0_81 - n1_82; var tmp34 bool; var tmp35 bool; tmp35 = !(n1_82 == -9223372036854775808); if tmp35 { tmp35 = (n0_81^n1_82)&(n0_81^nr_83) >= 0 }; tmp34 = tmp35; if tmp34 { na_50 = jrt.Long_ValueOf_J__Long_NoInit(nr_83).Ref() } else { na_50 = lang.Numbers_Minus_O_O__Number_NoInit(na_52, na_53) } } else { var tmp36 bool; var tmp37 bool; tmp37 = jrt.Double_InstanceOf(na_52); if tmp37 { tmp37 = jrt.Double_InstanceOf(na_53) }; tmp36 = tmp37; if tmp36 { var n0_81_2 float64 = jrt.NN(jrt.Double_Cast(na_52)).DoubleValue__D(); var n1_82_2 float64 = jrt.NN(jrt.Double_Cast(na_53)).DoubleValue__D(); na_50 = jrt.Double_ValueOf_D__Double_NoInit(n0_81_2 + -n1_82_2).Ref() } else { na_50 = lang.Numbers_Minus_O_O__Number_NoInit(na_52, na_53) } }; var na_51 int64 = 365; if jrt.Long_InstanceOf(na_50) { var n0_84 int64 = jrt.NN(jrt.Long_Cast(na_50)).LongValue__J(); var n1_85 int64 = na_51; if n1_85 == 0 { yoe__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_50, na_51) } else { yoe__5 = jrt.Long_ValueOf_J__Long_NoInit(n0_84 / n1_85).Ref() } } else { yoe__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_50, na_51) }
//line :182:1
		var y__6 any; var na_87 any = yoe__5; var na_88 any
		var na_89 any = era__3
		var na_90 int64 = 400


		if jrt.Long_InstanceOf(na_89) { var n0_91 int64 = jrt.NN(jrt.Long_Cast(na_89)).LongValue__J(); var n1_92 int64 = na_90; var nr_93 int64 = n0_91 * n1_92; var tmp38 bool; var tmp39 bool; var tmp40 bool; var tmp41 bool; tmp41 = n0_91 == -9223372036854775808; if tmp41 { tmp41 = n1_92 < 0 }; tmp40 = tmp41; tmp39 = !tmp40; if tmp39 { var tmp42 bool; tmp42 = n1_92 == 0; if !tmp42 { tmp42 = nr_93/n1_92 == n0_91 }; tmp39 = tmp42 }; tmp38 = tmp39; if tmp38 { na_88 = jrt.Long_ValueOf_J__Long_NoInit(nr_93).Ref() } else { na_88 = lang.Numbers_Multiply_O_J__Number_NoInit(na_89, na_90) } } else { na_88 = lang.Numbers_Multiply_O_J__Number_NoInit(na_89, na_90) }; var tmp43 bool; var tmp44 bool; tmp44 = jrt.Long_InstanceOf(na_87); if tmp44 { tmp44 = jrt.Long_InstanceOf(na_88) }; tmp43 = tmp44; if tmp43 { var n0_94 int64 = jrt.NN(jrt.Long_Cast(na_87)).LongValue__J(); var n1_95 int64 = jrt.NN(jrt.Long_Cast(na_88)).LongValue__J(); var nr_96 int64 = n0_94 + n1_95; if (n0_94^nr_96)&(n1_95^nr_96) >= 0 { y__6 = jrt.Long_ValueOf_J__Long_NoInit(nr_96).Ref() } else { y__6 = lang.Numbers_Add_O_O__Number_NoInit(na_87, na_88) } } else { var tmp45 bool; var tmp46 bool; tmp46 = jrt.Double_InstanceOf(na_87); if tmp46 { tmp46 = jrt.Double_InstanceOf(na_88) }; tmp45 = tmp46; if tmp45 { var n0_94_2 float64 = jrt.NN(jrt.Double_Cast(na_87)).DoubleValue__D(); var n1_95_2 float64 = jrt.NN(jrt.Double_Cast(na_88)).DoubleValue__D(); y__6 = jrt.Double_ValueOf_D__Double_NoInit(n0_94_2 + n1_95_2).Ref() } else { y__6 = lang.Numbers_Add_O_O__Number_NoInit(na_87, na_88) } }
//line :182:1
		var doy__7 any; var na_97 any = doe__4; var na_98 any; var na_99 any; var na_101 any
		var na_103 int64 = 365
		var na_104 any = yoe__5



		if jrt.Long_InstanceOf(na_104) { var n0_105 int64 = na_103; var n1_106 int64 = jrt.NN(jrt.Long_Cast(na_104)).LongValue__J(); var nr_107 int64 = n0_105 * n1_106; var tmp47 bool; var tmp48 bool; var tmp49 bool; var tmp50 bool; tmp50 = n0_105 == -9223372036854775808; if tmp50 { tmp50 = n1_106 < 0 }; tmp49 = tmp50; tmp48 = !tmp49; if tmp48 { var tmp51 bool; tmp51 = n1_106 == 0; if !tmp51 { tmp51 = nr_107/n1_106 == n0_105 }; tmp48 = tmp51 }; tmp47 = tmp48; if tmp47 { na_101 = jrt.Long_ValueOf_J__Long_NoInit(nr_107).Ref() } else { na_101 = lang.Numbers_Multiply_J_O__Number_NoInit(na_103, na_104) } } else { na_101 = lang.Numbers_Multiply_J_O__Number_NoInit(na_103, na_104) }; var na_102 any; var na_108 any = yoe__5; var na_109 int64 = 4; if jrt.Long_InstanceOf(na_108) { var n0_110 int64 = jrt.NN(jrt.Long_Cast(na_108)).LongValue__J(); var n1_111 int64 = na_109; if n1_111 == 0 { na_102 = lang.Numbers_Quotient_O_J__Number_NoInit(na_108, na_109) } else { na_102 = jrt.Long_ValueOf_J__Long_NoInit(n0_110 / n1_111).Ref() } } else { na_102 = lang.Numbers_Quotient_O_J__Number_NoInit(na_108, na_109) }; var tmp52 bool; var tmp53 bool; tmp53 = jrt.Long_InstanceOf(na_101); if tmp53 { tmp53 = jrt.Long_InstanceOf(na_102) }; tmp52 = tmp53; if tmp52 { var n0_113 int64 = jrt.NN(jrt.Long_Cast(na_101)).LongValue__J(); var n1_114 int64 = jrt.NN(jrt.Long_Cast(na_102)).LongValue__J(); var nr_115 int64 = n0_113 + n1_114; if (n0_113^nr_115)&(n1_114^nr_115) >= 0 { na_99 = jrt.Long_ValueOf_J__Long_NoInit(nr_115).Ref() } else { na_99 = lang.Numbers_Add_O_O__Number_NoInit(na_101, na_102) } } else { var tmp54 bool; var tmp55 bool; tmp55 = jrt.Double_InstanceOf(na_101); if tmp55 { tmp55 = jrt.Double_InstanceOf(na_102) }; tmp54 = tmp55; if tmp54 { var n0_113_2 float64 = jrt.NN(jrt.Double_Cast(na_101)).DoubleValue__D(); var n1_114_2 float64 = jrt.NN(jrt.Double_Cast(na_102)).DoubleValue__D(); na_99 = jrt.Double_ValueOf_D__Double_NoInit(n0_113_2 + n1_114_2).Ref() } else { na_99 = lang.Numbers_Add_O_O__Number_NoInit(na_101, na_102) } }; var na_100 any; var na_116 any = yoe__5; var na_117 int64 = 100; if jrt.Long_InstanceOf(na_116) { var n0_118 int64 = jrt.NN(jrt.Long_Cast(na_116)).LongValue__J(); var n1_119 int64 = na_117; if n1_119 == 0 { na_100 = lang.Numbers_Quotient_O_J__Number_NoInit(na_116, na_117) } else { na_100 = jrt.Long_ValueOf_J__Long_NoInit(n0_118 / n1_119).Ref() } } else { na_100 = lang.Numbers_Quotient_O_J__Number_NoInit(na_116, na_117) }; var tmp56 bool; var tmp57 bool; tmp57 = jrt.Long_InstanceOf(na_99); if tmp57 { tmp57 = jrt.Long_InstanceOf(na_100) }; tmp56 = tmp57; if tmp56 { var n0_121 int64 = jrt.NN(jrt.Long_Cast(na_99)).LongValue__J(); var n1_122 int64 = jrt.NN(jrt.Long_Cast(na_100)).LongValue__J(); var nr_123 int64 = n0_121 - n1_122; var tmp58 bool; var tmp59 bool; tmp59 = !(n1_122 == -9223372036854775808); if tmp59 { tmp59 = (n0_121^n1_122)&(n0_121^nr_123) >= 0 }; tmp58 = tmp59; if tmp58 { na_98 = jrt.Long_ValueOf_J__Long_NoInit(nr_123).Ref() } else { na_98 = lang.Numbers_Minus_O_O__Number_NoInit(na_99, na_100) } } else { var tmp60 bool; var tmp61 bool; tmp61 = jrt.Double_InstanceOf(na_99); if tmp61 { tmp61 = jrt.Double_InstanceOf(na_100) }; tmp60 = tmp61; if tmp60 { var n0_121_2 float64 = jrt.NN(jrt.Double_Cast(na_99)).DoubleValue__D(); var n1_122_2 float64 = jrt.NN(jrt.Double_Cast(na_100)).DoubleValue__D(); na_98 = jrt.Double_ValueOf_D__Double_NoInit(n0_121_2 + -n1_122_2).Ref() } else { na_98 = lang.Numbers_Minus_O_O__Number_NoInit(na_99, na_100) } }; var tmp62 bool; var tmp63 bool; tmp63 = jrt.Long_InstanceOf(na_97); if tmp63 { tmp63 = jrt.Long_InstanceOf(na_98) }; tmp62 = tmp63; if tmp62 { var n0_124 int64 = jrt.NN(jrt.Long_Cast(na_97)).LongValue__J(); var n1_125 int64 = jrt.NN(jrt.Long_Cast(na_98)).LongValue__J(); var nr_126 int64 = n0_124 - n1_125; var tmp64 bool; var tmp65 bool; tmp65 = !(n1_125 == -9223372036854775808); if tmp65 { tmp65 = (n0_124^n1_125)&(n0_124^nr_126) >= 0 }; tmp64 = tmp65; if tmp64 { doy__7 = jrt.Long_ValueOf_J__Long_NoInit(nr_126).Ref() } else { doy__7 = lang.Numbers_Minus_O_O__Number_NoInit(na_97, na_98) } } else { var tmp66 bool; var tmp67 bool; tmp67 = jrt.Double_InstanceOf(na_97); if tmp67 { tmp67 = jrt.Double_InstanceOf(na_98) }; tmp66 = tmp67; if tmp66 { var n0_124_2 float64 = jrt.NN(jrt.Double_Cast(na_97)).DoubleValue__D(); var n1_125_2 float64 = jrt.NN(jrt.Double_Cast(na_98)).DoubleValue__D(); doy__7 = jrt.Double_ValueOf_D__Double_NoInit(n0_124_2 + -n1_125_2).Ref() } else { doy__7 = lang.Numbers_Minus_O_O__Number_NoInit(na_97, na_98) } }
//line :182:1
		var mp__8 any; var na_127 any; var na_129 any
		var na_131 int64 = 5
		var na_132 any = doy__7




		if jrt.Long_InstanceOf(na_132) { var n0_133 int64 = na_131; var n1_134 int64 = jrt.NN(jrt.Long_Cast(na_132)).LongValue__J(); var nr_135 int64 = n0_133 * n1_134; var tmp68 bool; var tmp69 bool; var tmp70 bool; var tmp71 bool; tmp71 = n0_133 == -9223372036854775808; if tmp71 { tmp71 = n1_134 < 0 }; tmp70 = tmp71; tmp69 = !tmp70; if tmp69 { var tmp72 bool; tmp72 = n1_134 == 0; if !tmp72 { tmp72 = nr_135/n1_134 == n0_133 }; tmp69 = tmp72 }; tmp68 = tmp69; if tmp68 { na_129 = jrt.Long_ValueOf_J__Long_NoInit(nr_135).Ref() } else { na_129 = lang.Numbers_Multiply_J_O__Number_NoInit(na_131, na_132) } } else { na_129 = lang.Numbers_Multiply_J_O__Number_NoInit(na_131, na_132) }; var na_130 int64 = 2; if jrt.Long_InstanceOf(na_129) { var n0_136 int64 = jrt.NN(jrt.Long_Cast(na_129)).LongValue__J(); var n1_137 int64 = na_130; var nr_138 int64 = n0_136 + n1_137; if (n0_136^nr_138)&(n1_137^nr_138) >= 0 { na_127 = jrt.Long_ValueOf_J__Long_NoInit(nr_138).Ref() } else { na_127 = lang.Numbers_Add_O_J__Number_NoInit(na_129, na_130) } } else { na_127 = lang.Numbers_Add_O_J__Number_NoInit(na_129, na_130) }; var na_128 int64 = 153; if jrt.Long_InstanceOf(na_127) { var n0_139 int64 = jrt.NN(jrt.Long_Cast(na_127)).LongValue__J(); var n1_140 int64 = na_128; if n1_140 == 0 { mp__8 = lang.Numbers_Quotient_O_J__Number_NoInit(na_127, na_128) } else { mp__8 = jrt.Long_ValueOf_J__Long_NoInit(n0_139 / n1_140).Ref() } } else { mp__8 = lang.Numbers_Quotient_O_J__Number_NoInit(na_127, na_128) }
//line :182:1
		var d__9 any; var na_142 any; var na_143 any = doy__7; var na_144 any; var na_145 any; var na_147 any
		var na_149 int64 = 153
		var na_150 any = mp__8





		if jrt.Long_InstanceOf(na_150) { var n0_151 int64 = na_149; var n1_152 int64 = jrt.NN(jrt.Long_Cast(na_150)).LongValue__J(); var nr_153 int64 = n0_151 * n1_152; var tmp73 bool; var tmp74 bool; var tmp75 bool; var tmp76 bool; tmp76 = n0_151 == -9223372036854775808; if tmp76 { tmp76 = n1_152 < 0 }; tmp75 = tmp76; tmp74 = !tmp75; if tmp74 { var tmp77 bool; tmp77 = n1_152 == 0; if !tmp77 { tmp77 = nr_153/n1_152 == n0_151 }; tmp74 = tmp77 }; tmp73 = tmp74; if tmp73 { na_147 = jrt.Long_ValueOf_J__Long_NoInit(nr_153).Ref() } else { na_147 = lang.Numbers_Multiply_J_O__Number_NoInit(na_149, na_150) } } else { na_147 = lang.Numbers_Multiply_J_O__Number_NoInit(na_149, na_150) }; var na_148 int64 = 2; if jrt.Long_InstanceOf(na_147) { var n0_154 int64 = jrt.NN(jrt.Long_Cast(na_147)).LongValue__J(); var n1_155 int64 = na_148; var nr_156 int64 = n0_154 + n1_155; if (n0_154^nr_156)&(n1_155^nr_156) >= 0 { na_145 = jrt.Long_ValueOf_J__Long_NoInit(nr_156).Ref() } else { na_145 = lang.Numbers_Add_O_J__Number_NoInit(na_147, na_148) } } else { na_145 = lang.Numbers_Add_O_J__Number_NoInit(na_147, na_148) }; var na_146 int64 = 5; if jrt.Long_InstanceOf(na_145) { var n0_157 int64 = jrt.NN(jrt.Long_Cast(na_145)).LongValue__J(); var n1_158 int64 = na_146; if n1_158 == 0 { na_144 = lang.Numbers_Quotient_O_J__Number_NoInit(na_145, na_146) } else { na_144 = jrt.Long_ValueOf_J__Long_NoInit(n0_157 / n1_158).Ref() } } else { na_144 = lang.Numbers_Quotient_O_J__Number_NoInit(na_145, na_146) }; var tmp78 bool; var tmp79 bool; tmp79 = jrt.Long_InstanceOf(na_143); if tmp79 { tmp79 = jrt.Long_InstanceOf(na_144) }; tmp78 = tmp79; if tmp78 { var n0_160 int64 = jrt.NN(jrt.Long_Cast(na_143)).LongValue__J(); var n1_161 int64 = jrt.NN(jrt.Long_Cast(na_144)).LongValue__J(); var nr_162 int64 = n0_160 - n1_161; var tmp80 bool; var tmp81 bool; tmp81 = !(n1_161 == -9223372036854775808); if tmp81 { tmp81 = (n0_160^n1_161)&(n0_160^nr_162) >= 0 }; tmp80 = tmp81; if tmp80 { na_142 = jrt.Long_ValueOf_J__Long_NoInit(nr_162).Ref() } else { na_142 = lang.Numbers_Minus_O_O__Number_NoInit(na_143, na_144) } } else { var tmp82 bool; var tmp83 bool; tmp83 = jrt.Double_InstanceOf(na_143); if tmp83 { tmp83 = jrt.Double_InstanceOf(na_144) }; tmp82 = tmp83; if tmp82 { var n0_160_2 float64 = jrt.NN(jrt.Double_Cast(na_143)).DoubleValue__D(); var n1_161_2 float64 = jrt.NN(jrt.Double_Cast(na_144)).DoubleValue__D(); na_142 = jrt.Double_ValueOf_D__Double_NoInit(n0_160_2 + -n1_161_2).Ref() } else { na_142 = lang.Numbers_Minus_O_O__Number_NoInit(na_143, na_144) } }; if jrt.Long_InstanceOf(na_142) { var n0_163 int64 = jrt.NN(jrt.Long_Cast(na_142)).LongValue__J(); if n0_163 == 9223372036854775807 { d__9 = lang.Numbers_Inc_O__Number_NoInit(na_142) } else { d__9 = jrt.Long_ValueOf_J__Long_NoInit(n0_163 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_142) { var n0_163_2 float64 = jrt.NN(jrt.Double_Cast(na_142)).DoubleValue__D(); d__9 = jrt.Double_ValueOf_D__Double_NoInit(n0_163_2 + 1.0).Ref() } else { d__9 = lang.Numbers_Inc_O__Number_NoInit(na_142) } }
//line :182:1
		var m__10 any; var tmp84 bool
		var na_164 any = mp__8
		var na_165 int64 = 10






		if jrt.Long_InstanceOf(na_164) { var n0_166 int64 = jrt.NN(jrt.Long_Cast(na_164)).LongValue__J(); var n1_167 int64 = na_165; tmp84 = n0_166 < n1_167 } else { tmp84 = lang.Numbers_Lt_O_J__Z_NoInit(na_164, na_165) }; if tmp84 { var na_169 any = mp__8; var na_170 int64 = 3; if jrt.Long_InstanceOf(na_169) { var n0_171 int64 = jrt.NN(jrt.Long_Cast(na_169)).LongValue__J(); var n1_172 int64 = na_170; var nr_173 int64 = n0_171 + n1_172; if (n0_171^nr_173)&(n1_172^nr_173) >= 0 { m__10 = jrt.Long_ValueOf_J__Long_NoInit(nr_173).Ref() } else { m__10 = lang.Numbers_Add_O_J__Number_NoInit(na_169, na_170) } } else { m__10 = lang.Numbers_Add_O_J__Number_NoInit(na_169, na_170) } } else { var na_174 any = mp__8; var na_175 int64 = 9; if jrt.Long_InstanceOf(na_174) { var n0_176 int64 = jrt.NN(jrt.Long_Cast(na_174)).LongValue__J(); var n1_177 int64 = na_175; var nr_178 int64 = n0_176 - n1_177; var tmp85 bool; var tmp86 bool; tmp86 = !(n1_177 == -9223372036854775808); if tmp86 { tmp86 = (n0_176^n1_177)&(n0_176^nr_178) >= 0 }; tmp85 = tmp86; if tmp85 { m__10 = jrt.Long_ValueOf_J__Long_NoInit(nr_178).Ref() } else { m__10 = lang.Numbers_Minus_O_J__Number_NoInit(na_174, na_175) } } else { m__10 = lang.Numbers_Minus_O_J__Number_NoInit(na_174, na_175) } }
//line :182:1
		var tmp87 any; var tmp88 bool
		var na_219 any = m__10
		var na_220 int64 = 2







		if jrt.Long_InstanceOf(na_219) { var n0_221 int64 = jrt.NN(jrt.Long_Cast(na_219)).LongValue__J(); var n1_222 int64 = na_220; tmp88 = n0_221 <= n1_222 } else { tmp88 = lang.Numbers_Lte_O_J__Z_NoInit(na_219, na_220) }; if tmp88 { var na_224 any = y__6; if jrt.Long_InstanceOf(na_224) { var n0_225 int64 = jrt.NN(jrt.Long_Cast(na_224)).LongValue__J(); if n0_225 == 9223372036854775807 { tmp87 = lang.Numbers_Inc_O__Number_NoInit(na_224) } else { tmp87 = jrt.Long_ValueOf_J__Long_NoInit(n0_225 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_224) { var n0_225_2 float64 = jrt.NN(jrt.Double_Cast(na_224)).DoubleValue__D(); tmp87 = jrt.Double_ValueOf_D__Double_NoInit(n0_225_2 + 1.0).Ref() } else { tmp87 = lang.Numbers_Inc_O__Number_NoInit(na_224) } } } else { tmp87 = y__6 }
//line :182:1
		return lang.Tuple_Create_O_O_O__IPersistentVector(tmp87, m__10, d__9) } else { var c__2 any; var na_179 any
			var na_181 any = z__0
			var na_182 int64 = 2440588








			if jrt.Long_InstanceOf(na_181) { var n0_183 int64 = jrt.NN(jrt.Long_Cast(na_181)).LongValue__J(); var n1_184 int64 = na_182; var nr_185 int64 = n0_183 + n1_184; if (n0_183^nr_185)&(n1_184^nr_185) >= 0 { na_179 = jrt.Long_ValueOf_J__Long_NoInit(nr_185).Ref() } else { na_179 = lang.Numbers_Add_O_J__Number_NoInit(na_181, na_182) } } else { na_179 = lang.Numbers_Add_O_J__Number_NoInit(na_181, na_182) }; var na_180 int64 = 32082; if jrt.Long_InstanceOf(na_179) { var n0_186 int64 = jrt.NN(jrt.Long_Cast(na_179)).LongValue__J(); var n1_187 int64 = na_180; var nr_188 int64 = n0_186 + n1_187; if (n0_186^nr_188)&(n1_187^nr_188) >= 0 { c__2 = jrt.Long_ValueOf_J__Long_NoInit(nr_188).Ref() } else { c__2 = lang.Numbers_Add_O_J__Number_NoInit(na_179, na_180) } } else { c__2 = lang.Numbers_Add_O_J__Number_NoInit(na_179, na_180) }
//line :182:1
			var d__3 int64; var tmp89 jrt.Number_I; var na_189 any
			var na_191 int64 = 4
			var na_192 any = c__2









			if jrt.Long_InstanceOf(na_192) { var n0_193 int64 = na_191; var n1_194 int64 = jrt.NN(jrt.Long_Cast(na_192)).LongValue__J(); var nr_195 int64 = n0_193 * n1_194; var tmp90 bool; var tmp91 bool; var tmp92 bool; var tmp93 bool; tmp93 = n0_193 == -9223372036854775808; if tmp93 { tmp93 = n1_194 < 0 }; tmp92 = tmp93; tmp91 = !tmp92; if tmp91 { var tmp94 bool; tmp94 = n1_194 == 0; if !tmp94 { tmp94 = nr_195/n1_194 == n0_193 }; tmp91 = tmp94 }; tmp90 = tmp91; if tmp90 { na_189 = jrt.Long_ValueOf_J__Long_NoInit(nr_195).Ref() } else { na_189 = lang.Numbers_Multiply_J_O__Number_NoInit(na_191, na_192) } } else { na_189 = lang.Numbers_Multiply_J_O__Number_NoInit(na_191, na_192) }; var na_190 int64 = 3; if jrt.Long_InstanceOf(na_189) { var n0_196 int64 = jrt.NN(jrt.Long_Cast(na_189)).LongValue__J(); var n1_197 int64 = na_190; var nr_198 int64 = n0_196 + n1_197; if (n0_196^nr_198)&(n1_197^nr_198) >= 0 { tmp89 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_198)) } else { tmp89 = lang.Numbers_Add_O_J__Number_NoInit(na_189, na_190) } } else { tmp89 = lang.Numbers_Add_O_J__Number_NoInit(na_189, na_190) }; d__3 = jrt.Math_FloorDiv_J_J__J(lang.RT_LongCast_O__J_NoInit(tmp89), 1461)
//line :182:1
			var e__4 any; var na_199 any = c__2; var na_200 int64 = jrt.Math_FloorDiv_J_J__J(lang.RT_LongCast_J__J_NoInit(lang.Numbers_Multiply_J_J__J_NoInit(1461, d__3)), 4)












			if jrt.Long_InstanceOf(na_199) { var n0_201 int64 = jrt.NN(jrt.Long_Cast(na_199)).LongValue__J(); var n1_202 int64 = na_200; var nr_203 int64 = n0_201 - n1_202; var tmp95 bool; var tmp96 bool; tmp96 = !(n1_202 == -9223372036854775808); if tmp96 { tmp96 = (n0_201^n1_202)&(n0_201^nr_203) >= 0 }; tmp95 = tmp96; if tmp95 { e__4 = jrt.Long_ValueOf_J__Long_NoInit(nr_203).Ref() } else { e__4 = lang.Numbers_Minus_O_J__Number_NoInit(na_199, na_200) } } else { e__4 = lang.Numbers_Minus_O_J__Number_NoInit(na_199, na_200) }
//line :182:1
			var m__5 any; var na_204 any; var na_206 any
			var na_208 int64 = 5
			var na_209 any = e__4











			if jrt.Long_InstanceOf(na_209) { var n0_210 int64 = na_208; var n1_211 int64 = jrt.NN(jrt.Long_Cast(na_209)).LongValue__J(); var nr_212 int64 = n0_210 * n1_211; var tmp97 bool; var tmp98 bool; var tmp99 bool; var tmp100 bool; tmp100 = n0_210 == -9223372036854775808; if tmp100 { tmp100 = n1_211 < 0 }; tmp99 = tmp100; tmp98 = !tmp99; if tmp98 { var tmp101 bool; tmp101 = n1_211 == 0; if !tmp101 { tmp101 = nr_212/n1_211 == n0_210 }; tmp98 = tmp101 }; tmp97 = tmp98; if tmp97 { na_206 = jrt.Long_ValueOf_J__Long_NoInit(nr_212).Ref() } else { na_206 = lang.Numbers_Multiply_J_O__Number_NoInit(na_208, na_209) } } else { na_206 = lang.Numbers_Multiply_J_O__Number_NoInit(na_208, na_209) }; var na_207 int64 = 2; if jrt.Long_InstanceOf(na_206) { var n0_213 int64 = jrt.NN(jrt.Long_Cast(na_206)).LongValue__J(); var n1_214 int64 = na_207; var nr_215 int64 = n0_213 + n1_214; if (n0_213^nr_215)&(n1_214^nr_215) >= 0 { na_204 = jrt.Long_ValueOf_J__Long_NoInit(nr_215).Ref() } else { na_204 = lang.Numbers_Add_O_J__Number_NoInit(na_206, na_207) } } else { na_204 = lang.Numbers_Add_O_J__Number_NoInit(na_206, na_207) }; var na_205 int64 = 153; if jrt.Long_InstanceOf(na_204) { var n0_216 int64 = jrt.NN(jrt.Long_Cast(na_204)).LongValue__J(); var n1_217 int64 = na_205; if n1_217 == 0 { m__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_204, na_205) } else { m__5 = jrt.Long_ValueOf_J__Long_NoInit(n0_216 / n1_217).Ref() } } else { m__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_204, na_205) }
//line :182:1
			var tmp102 jrt.Number_I; var na_226 int64 = lang.Numbers_Minus_J_J__J_NoInit(d__3, 4800); var na_227 any
			var na_228 any = m__5
			var na_229 int64 = 10












			if jrt.Long_InstanceOf(na_228) { var n0_230 int64 = jrt.NN(jrt.Long_Cast(na_228)).LongValue__J(); var n1_231 int64 = na_229; if n1_231 == 0 { na_227 = lang.Numbers_Quotient_O_J__Number_NoInit(na_228, na_229) } else { na_227 = jrt.Long_ValueOf_J__Long_NoInit(n0_230 / n1_231).Ref() } } else { na_227 = lang.Numbers_Quotient_O_J__Number_NoInit(na_228, na_229) }; if jrt.Long_InstanceOf(na_227) { var n0_233 int64 = na_226; var n1_234 int64 = jrt.NN(jrt.Long_Cast(na_227)).LongValue__J(); var nr_235 int64 = n0_233 + n1_234; if (n0_233^nr_235)&(n1_234^nr_235) >= 0 { tmp102 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_235)) } else { tmp102 = lang.Numbers_Add_J_O__Number_NoInit(na_226, na_227) } } else { tmp102 = lang.Numbers_Add_J_O__Number_NoInit(na_226, na_227) }
//line :182:1
			var tmp103 any = tmp102; var tmp104 jrt.Number_I; var na_236 any
			var na_238 any = m__5
			var na_239 int64 = 3













			if jrt.Long_InstanceOf(na_238) { var n0_240 int64 = jrt.NN(jrt.Long_Cast(na_238)).LongValue__J(); var n1_241 int64 = na_239; var nr_242 int64 = n0_240 + n1_241; if (n0_240^nr_242)&(n1_241^nr_242) >= 0 { na_236 = jrt.Long_ValueOf_J__Long_NoInit(nr_242).Ref() } else { na_236 = lang.Numbers_Add_O_J__Number_NoInit(na_238, na_239) } } else { na_236 = lang.Numbers_Add_O_J__Number_NoInit(na_238, na_239) }; var na_237 any; var na_243 int64 = 12; var na_244 any; var na_245 any = m__5; var na_246 int64 = 10; if jrt.Long_InstanceOf(na_245) { var n0_247 int64 = jrt.NN(jrt.Long_Cast(na_245)).LongValue__J(); var n1_248 int64 = na_246; if n1_248 == 0 { na_244 = lang.Numbers_Quotient_O_J__Number_NoInit(na_245, na_246) } else { na_244 = jrt.Long_ValueOf_J__Long_NoInit(n0_247 / n1_248).Ref() } } else { na_244 = lang.Numbers_Quotient_O_J__Number_NoInit(na_245, na_246) }; if jrt.Long_InstanceOf(na_244) { var n0_250 int64 = na_243; var n1_251 int64 = jrt.NN(jrt.Long_Cast(na_244)).LongValue__J(); var nr_252 int64 = n0_250 * n1_251; var tmp105 bool; var tmp106 bool; var tmp107 bool; var tmp108 bool; tmp108 = n0_250 == -9223372036854775808; if tmp108 { tmp108 = n1_251 < 0 }; tmp107 = tmp108; tmp106 = !tmp107; if tmp106 { var tmp109 bool; tmp109 = n1_251 == 0; if !tmp109 { tmp109 = nr_252/n1_251 == n0_250 }; tmp106 = tmp109 }; tmp105 = tmp106; if tmp105 { na_237 = jrt.Long_ValueOf_J__Long_NoInit(nr_252).Ref() } else { na_237 = lang.Numbers_Multiply_J_O__Number_NoInit(na_243, na_244) } } else { na_237 = lang.Numbers_Multiply_J_O__Number_NoInit(na_243, na_244) }; var tmp110 bool; var tmp111 bool; tmp111 = jrt.Long_InstanceOf(na_236); if tmp111 { tmp111 = jrt.Long_InstanceOf(na_237) }; tmp110 = tmp111; if tmp110 { var n0_253 int64 = jrt.NN(jrt.Long_Cast(na_236)).LongValue__J(); var n1_254 int64 = jrt.NN(jrt.Long_Cast(na_237)).LongValue__J(); var nr_255 int64 = n0_253 - n1_254; var tmp112 bool; var tmp113 bool; tmp113 = !(n1_254 == -9223372036854775808); if tmp113 { tmp113 = (n0_253^n1_254)&(n0_253^nr_255) >= 0 }; tmp112 = tmp113; if tmp112 { tmp104 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_255)) } else { tmp104 = lang.Numbers_Minus_O_O__Number_NoInit(na_236, na_237) } } else { var tmp114 bool; var tmp115 bool; tmp115 = jrt.Double_InstanceOf(na_236); if tmp115 { tmp115 = jrt.Double_InstanceOf(na_237) }; tmp114 = tmp115; if tmp114 { var n0_253_2 float64 = jrt.NN(jrt.Double_Cast(na_236)).DoubleValue__D(); var n1_254_2 float64 = jrt.NN(jrt.Double_Cast(na_237)).DoubleValue__D(); tmp104 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_253_2 + -n1_254_2)) } else { tmp104 = lang.Numbers_Minus_O_O__Number_NoInit(na_236, na_237) } }
//line :182:1
			var tmp116 any = tmp104; var tmp117 jrt.Number_I; var na_256 any; var na_257 any = e__4; var na_258 any; var na_259 any; var na_261 any
			var na_263 int64 = 153
			var na_264 any = m__5














			if jrt.Long_InstanceOf(na_264) { var n0_265 int64 = na_263; var n1_266 int64 = jrt.NN(jrt.Long_Cast(na_264)).LongValue__J(); var nr_267 int64 = n0_265 * n1_266; var tmp118 bool; var tmp119 bool; var tmp120 bool; var tmp121 bool; tmp121 = n0_265 == -9223372036854775808; if tmp121 { tmp121 = n1_266 < 0 }; tmp120 = tmp121; tmp119 = !tmp120; if tmp119 { var tmp122 bool; tmp122 = n1_266 == 0; if !tmp122 { tmp122 = nr_267/n1_266 == n0_265 }; tmp119 = tmp122 }; tmp118 = tmp119; if tmp118 { na_261 = jrt.Long_ValueOf_J__Long_NoInit(nr_267).Ref() } else { na_261 = lang.Numbers_Multiply_J_O__Number_NoInit(na_263, na_264) } } else { na_261 = lang.Numbers_Multiply_J_O__Number_NoInit(na_263, na_264) }; var na_262 int64 = 2; if jrt.Long_InstanceOf(na_261) { var n0_268 int64 = jrt.NN(jrt.Long_Cast(na_261)).LongValue__J(); var n1_269 int64 = na_262; var nr_270 int64 = n0_268 + n1_269; if (n0_268^nr_270)&(n1_269^nr_270) >= 0 { na_259 = jrt.Long_ValueOf_J__Long_NoInit(nr_270).Ref() } else { na_259 = lang.Numbers_Add_O_J__Number_NoInit(na_261, na_262) } } else { na_259 = lang.Numbers_Add_O_J__Number_NoInit(na_261, na_262) }; var na_260 int64 = 5; if jrt.Long_InstanceOf(na_259) { var n0_271 int64 = jrt.NN(jrt.Long_Cast(na_259)).LongValue__J(); var n1_272 int64 = na_260; if n1_272 == 0 { na_258 = lang.Numbers_Quotient_O_J__Number_NoInit(na_259, na_260) } else { na_258 = jrt.Long_ValueOf_J__Long_NoInit(n0_271 / n1_272).Ref() } } else { na_258 = lang.Numbers_Quotient_O_J__Number_NoInit(na_259, na_260) }; var tmp123 bool; var tmp124 bool; tmp124 = jrt.Long_InstanceOf(na_257); if tmp124 { tmp124 = jrt.Long_InstanceOf(na_258) }; tmp123 = tmp124; if tmp123 { var n0_274 int64 = jrt.NN(jrt.Long_Cast(na_257)).LongValue__J(); var n1_275 int64 = jrt.NN(jrt.Long_Cast(na_258)).LongValue__J(); var nr_276 int64 = n0_274 - n1_275; var tmp125 bool; var tmp126 bool; tmp126 = !(n1_275 == -9223372036854775808); if tmp126 { tmp126 = (n0_274^n1_275)&(n0_274^nr_276) >= 0 }; tmp125 = tmp126; if tmp125 { na_256 = jrt.Long_ValueOf_J__Long_NoInit(nr_276).Ref() } else { na_256 = lang.Numbers_Minus_O_O__Number_NoInit(na_257, na_258) } } else { var tmp127 bool; var tmp128 bool; tmp128 = jrt.Double_InstanceOf(na_257); if tmp128 { tmp128 = jrt.Double_InstanceOf(na_258) }; tmp127 = tmp128; if tmp127 { var n0_274_2 float64 = jrt.NN(jrt.Double_Cast(na_257)).DoubleValue__D(); var n1_275_2 float64 = jrt.NN(jrt.Double_Cast(na_258)).DoubleValue__D(); na_256 = jrt.Double_ValueOf_D__Double_NoInit(n0_274_2 + -n1_275_2).Ref() } else { na_256 = lang.Numbers_Minus_O_O__Number_NoInit(na_257, na_258) } }; if jrt.Long_InstanceOf(na_256) { var n0_277 int64 = jrt.NN(jrt.Long_Cast(na_256)).LongValue__J(); if n0_277 == 9223372036854775807 { tmp117 = lang.Numbers_Inc_O__Number_NoInit(na_256) } else { tmp117 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_277 + 1)) } } else { if jrt.Double_InstanceOf(na_256) { var n0_277_2 float64 = jrt.NN(jrt.Double_Cast(na_256)).DoubleValue__D(); tmp117 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_277_2 + 1.0)) } else { tmp117 = lang.Numbers_Inc_O__Number_NoInit(na_256) } }
//line :182:1
			return lang.Tuple_Create_O_O_O__IPersistentVector(tmp103, tmp116, tmp117)
		}
}
















func A_arbace_instant_civil__GT_days_A_New() *A_arbace_instant_civil__GT_days_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_civil__GT_days_A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_instant_civil__GT_days_A) Ctor() {}
//line :201:1
func (t *A_arbace_instant_civil__GT_days_A) Invoke_O_O_O_O__O(self, y__0, m__1, d__2 any) any { var g__4 any; var y__4 any; var tmp1 bool; var na_278 any = m__1; var na_279 int64 = 2; if



	jrt.Long_InstanceOf(na_278) { var n0_280 int64 = jrt.NN(jrt.Long_Cast(na_278)).LongValue__J(); var n1_281 int64 = na_279; tmp1 = n0_280 <= n1_281 } else { tmp1 = lang.Numbers_Lte_O_J__Z_NoInit(na_278, na_279) }; if tmp1 { var na_283 any = y__0; if jrt.Long_InstanceOf(na_283) { var n0_284 int64 = jrt.NN(jrt.Long_Cast(na_283)).LongValue__J(); if n0_284 == -9223372036854775808 { y__4 = lang.Numbers_Dec_O__Number_NoInit(na_283) } else { y__4 = jrt.Long_ValueOf_J__Long_NoInit(n0_284 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_283) { var n0_284_2 float64 = jrt.NN(jrt.Double_Cast(na_283)).DoubleValue__D(); y__4 = jrt.Double_ValueOf_D__Double_NoInit(n0_284_2 - 1.0).Ref() } else { y__4 = lang.Numbers_Dec_O__Number_NoInit(na_283) } } } else { y__4 = y__0 }; var era__5 any; var na_285 any; var tmp2 bool; var na_287 any = y__4; var na_288 int64 = 0; if
	jrt.Long_InstanceOf(na_287) { var n0_289 int64 = jrt.NN(jrt.Long_Cast(na_287)).LongValue__J(); var n1_290 int64 = na_288; tmp2 = n0_289 >= n1_290 } else { tmp2 = lang.Numbers_Gte_O_J__Z_NoInit(na_287, na_288) }; if tmp2 { na_285 = y__4 } else { var na_292 any = y__4; var na_293 int64 = 399; if jrt.Long_InstanceOf(na_292) { var n0_294 int64 = jrt.NN(jrt.Long_Cast(na_292)).LongValue__J(); var n1_295 int64 = na_293; var nr_296 int64 = n0_294 - n1_295; var tmp3 bool; var tmp4 bool; tmp4 = !(n1_295 == -9223372036854775808); if tmp4 { tmp4 = (n0_294^n1_295)&(n0_294^nr_296) >= 0 }; tmp3 = tmp4; if tmp3 { na_285 = jrt.Long_ValueOf_J__Long_NoInit(nr_296).Ref() } else { na_285 = lang.Numbers_Minus_O_J__Number_NoInit(na_292, na_293) } } else { na_285 = lang.Numbers_Minus_O_J__Number_NoInit(na_292, na_293) } }; var na_286 int64 = 400; if jrt.Long_InstanceOf(na_285) { var n0_297 int64 = jrt.NN(jrt.Long_Cast(na_285)).LongValue__J(); var n1_298 int64 = na_286; if n1_298 == 0 { era__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_285, na_286) } else { era__5 = jrt.Long_ValueOf_J__Long_NoInit(n0_297 / n1_298).Ref() } } else { era__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_285, na_286) }; var yoe__6 any; var na_300 any = y__4; var na_301 any; var na_302 any = era__5; var na_303 int64 = 400; if
	jrt.Long_InstanceOf(na_302) { var n0_304 int64 = jrt.NN(jrt.Long_Cast(na_302)).LongValue__J(); var n1_305 int64 = na_303; var nr_306 int64 = n0_304 * n1_305; var tmp5 bool; var tmp6 bool; var tmp7 bool; var tmp8 bool; tmp8 = n0_304 == -9223372036854775808; if tmp8 { tmp8 = n1_305 < 0 }; tmp7 = tmp8; tmp6 = !tmp7; if tmp6 { var tmp9 bool; tmp9 = n1_305 == 0; if !tmp9 { tmp9 = nr_306/n1_305 == n0_304 }; tmp6 = tmp9 }; tmp5 = tmp6; if tmp5 { na_301 = jrt.Long_ValueOf_J__Long_NoInit(nr_306).Ref() } else { na_301 = lang.Numbers_Multiply_O_J__Number_NoInit(na_302, na_303) } } else { na_301 = lang.Numbers_Multiply_O_J__Number_NoInit(na_302, na_303) }; var tmp10 bool; var tmp11 bool; tmp11 = jrt.Long_InstanceOf(na_300); if tmp11 { tmp11 = jrt.Long_InstanceOf(na_301) }; tmp10 = tmp11; if tmp10 { var n0_307 int64 = jrt.NN(jrt.Long_Cast(na_300)).LongValue__J(); var n1_308 int64 = jrt.NN(jrt.Long_Cast(na_301)).LongValue__J(); var nr_309 int64 = n0_307 - n1_308; var tmp12 bool; var tmp13 bool; tmp13 = !(n1_308 == -9223372036854775808); if tmp13 { tmp13 = (n0_307^n1_308)&(n0_307^nr_309) >= 0 }; tmp12 = tmp13; if tmp12 { yoe__6 = jrt.Long_ValueOf_J__Long_NoInit(nr_309).Ref() } else { yoe__6 = lang.Numbers_Minus_O_O__Number_NoInit(na_300, na_301) } } else { var tmp14 bool; var tmp15 bool; tmp15 = jrt.Double_InstanceOf(na_300); if tmp15 { tmp15 = jrt.Double_InstanceOf(na_301) }; tmp14 = tmp15; if tmp14 { var n0_307_2 float64 = jrt.NN(jrt.Double_Cast(na_300)).DoubleValue__D(); var n1_308_2 float64 = jrt.NN(jrt.Double_Cast(na_301)).DoubleValue__D(); yoe__6 = jrt.Double_ValueOf_D__Double_NoInit(n0_307_2 + -n1_308_2).Ref() } else { yoe__6 = lang.Numbers_Minus_O_O__Number_NoInit(na_300, na_301) } }; var doy__7 any; var na_310 any; var na_312 any; var na_314 any; var na_316 int64 = 153; var na_317 any; var tmp16 bool; var na_318 any = m__1; var na_319 int64 = 2; if
	jrt.Long_InstanceOf(na_318) { var n0_320 int64 = jrt.NN(jrt.Long_Cast(na_318)).LongValue__J(); var n1_321 int64 = na_319; tmp16 = n0_320 > n1_321 } else { tmp16 = lang.Numbers_Gt_O_J__Z_NoInit(na_318, na_319) }; if tmp16 { var na_323 any = m__1; var na_324 int64 = 3; if jrt.Long_InstanceOf(na_323) { var n0_325 int64 = jrt.NN(jrt.Long_Cast(na_323)).LongValue__J(); var n1_326 int64 = na_324; var nr_327 int64 = n0_325 - n1_326; var tmp17 bool; var tmp18 bool; tmp18 = !(n1_326 == -9223372036854775808); if tmp18 { tmp18 = (n0_325^n1_326)&(n0_325^nr_327) >= 0 }; tmp17 = tmp18; if tmp17 { na_317 = jrt.Long_ValueOf_J__Long_NoInit(nr_327).Ref() } else { na_317 = lang.Numbers_Minus_O_J__Number_NoInit(na_323, na_324) } } else { na_317 = lang.Numbers_Minus_O_J__Number_NoInit(na_323, na_324) } } else { var na_328 any = m__1; var na_329 int64 = 9; if jrt.Long_InstanceOf(na_328) { var n0_330 int64 = jrt.NN(jrt.Long_Cast(na_328)).LongValue__J(); var n1_331 int64 = na_329; var nr_332 int64 = n0_330 + n1_331; if (n0_330^nr_332)&(n1_331^nr_332) >= 0 { na_317 = jrt.Long_ValueOf_J__Long_NoInit(nr_332).Ref() } else { na_317 = lang.Numbers_Add_O_J__Number_NoInit(na_328, na_329) } } else { na_317 = lang.Numbers_Add_O_J__Number_NoInit(na_328, na_329) } }; if jrt.Long_InstanceOf(na_317) { var n0_333 int64 = na_316; var n1_334 int64 = jrt.NN(jrt.Long_Cast(na_317)).LongValue__J(); var nr_335 int64 = n0_333 * n1_334; var tmp19 bool; var tmp20 bool; var tmp21 bool; var tmp22 bool; tmp22 = n0_333 == -9223372036854775808; if tmp22 { tmp22 = n1_334 < 0 }; tmp21 = tmp22; tmp20 = !tmp21; if tmp20 { var tmp23 bool; tmp23 = n1_334 == 0; if !tmp23 { tmp23 = nr_335/n1_334 == n0_333 }; tmp20 = tmp23 }; tmp19 = tmp20; if tmp19 { na_314 = jrt.Long_ValueOf_J__Long_NoInit(nr_335).Ref() } else { na_314 = lang.Numbers_Multiply_J_O__Number_NoInit(na_316, na_317) } } else { na_314 = lang.Numbers_Multiply_J_O__Number_NoInit(na_316, na_317) }; var na_315 int64 = 2; if jrt.Long_InstanceOf(na_314) { var n0_336 int64 = jrt.NN(jrt.Long_Cast(na_314)).LongValue__J(); var n1_337 int64 = na_315; var nr_338 int64 = n0_336 + n1_337; if (n0_336^nr_338)&(n1_337^nr_338) >= 0 { na_312 = jrt.Long_ValueOf_J__Long_NoInit(nr_338).Ref() } else { na_312 = lang.Numbers_Add_O_J__Number_NoInit(na_314, na_315) } } else { na_312 = lang.Numbers_Add_O_J__Number_NoInit(na_314, na_315) }; var na_313 int64 = 5; if jrt.Long_InstanceOf(na_312) { var n0_339 int64 = jrt.NN(jrt.Long_Cast(na_312)).LongValue__J(); var n1_340 int64 = na_313; if n1_340 == 0 { na_310 = lang.Numbers_Quotient_O_J__Number_NoInit(na_312, na_313) } else { na_310 = jrt.Long_ValueOf_J__Long_NoInit(n0_339 / n1_340).Ref() } } else { na_310 = lang.Numbers_Quotient_O_J__Number_NoInit(na_312, na_313) }; var na_311 any; var na_342 any = d__2; if jrt.Long_InstanceOf(na_342) { var n0_343 int64 = jrt.NN(jrt.Long_Cast(na_342)).LongValue__J(); if n0_343 == -9223372036854775808 { na_311 = lang.Numbers_Dec_O__Number_NoInit(na_342) } else { na_311 = jrt.Long_ValueOf_J__Long_NoInit(n0_343 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_342) { var n0_343_2 float64 = jrt.NN(jrt.Double_Cast(na_342)).DoubleValue__D(); na_311 = jrt.Double_ValueOf_D__Double_NoInit(n0_343_2 - 1.0).Ref() } else { na_311 = lang.Numbers_Dec_O__Number_NoInit(na_342) } }; var tmp24 bool; var tmp25 bool; tmp25 = jrt.Long_InstanceOf(na_310); if tmp25 { tmp25 = jrt.Long_InstanceOf(na_311) }; tmp24 = tmp25; if tmp24 { var n0_344 int64 = jrt.NN(jrt.Long_Cast(na_310)).LongValue__J(); var n1_345 int64 = jrt.NN(jrt.Long_Cast(na_311)).LongValue__J(); var nr_346 int64 = n0_344 + n1_345; if (n0_344^nr_346)&(n1_345^nr_346) >= 0 { doy__7 = jrt.Long_ValueOf_J__Long_NoInit(nr_346).Ref() } else { doy__7 = lang.Numbers_Add_O_O__Number_NoInit(na_310, na_311) } } else { var tmp26 bool; var tmp27 bool; tmp27 = jrt.Double_InstanceOf(na_310); if tmp27 { tmp27 = jrt.Double_InstanceOf(na_311) }; tmp26 = tmp27; if tmp26 { var n0_344_2 float64 = jrt.NN(jrt.Double_Cast(na_310)).DoubleValue__D(); var n1_345_2 float64 = jrt.NN(jrt.Double_Cast(na_311)).DoubleValue__D(); doy__7 = jrt.Double_ValueOf_D__Double_NoInit(n0_344_2 + n1_345_2).Ref() } else { doy__7 = lang.Numbers_Add_O_O__Number_NoInit(na_310, na_311) } }; var doe__8 any; var na_347 any; var na_349 any; var na_351 any; var na_353 any = yoe__6; var na_354 int64 = 365; if
	jrt.Long_InstanceOf(na_353) { var n0_355 int64 = jrt.NN(jrt.Long_Cast(na_353)).LongValue__J(); var n1_356 int64 = na_354; var nr_357 int64 = n0_355 * n1_356; var tmp28 bool; var tmp29 bool; var tmp30 bool; var tmp31 bool; tmp31 = n0_355 == -9223372036854775808; if tmp31 { tmp31 = n1_356 < 0 }; tmp30 = tmp31; tmp29 = !tmp30; if tmp29 { var tmp32 bool; tmp32 = n1_356 == 0; if !tmp32 { tmp32 = nr_357/n1_356 == n0_355 }; tmp29 = tmp32 }; tmp28 = tmp29; if tmp28 { na_351 = jrt.Long_ValueOf_J__Long_NoInit(nr_357).Ref() } else { na_351 = lang.Numbers_Multiply_O_J__Number_NoInit(na_353, na_354) } } else { na_351 = lang.Numbers_Multiply_O_J__Number_NoInit(na_353, na_354) }; var na_352 any; var na_358 any = yoe__6; var na_359 int64 = 4; if jrt.Long_InstanceOf(na_358) { var n0_360 int64 = jrt.NN(jrt.Long_Cast(na_358)).LongValue__J(); var n1_361 int64 = na_359; if n1_361 == 0 { na_352 = lang.Numbers_Quotient_O_J__Number_NoInit(na_358, na_359) } else { na_352 = jrt.Long_ValueOf_J__Long_NoInit(n0_360 / n1_361).Ref() } } else { na_352 = lang.Numbers_Quotient_O_J__Number_NoInit(na_358, na_359) }; var tmp33 bool; var tmp34 bool; tmp34 = jrt.Long_InstanceOf(na_351); if tmp34 { tmp34 = jrt.Long_InstanceOf(na_352) }; tmp33 = tmp34; if tmp33 { var n0_363 int64 = jrt.NN(jrt.Long_Cast(na_351)).LongValue__J(); var n1_364 int64 = jrt.NN(jrt.Long_Cast(na_352)).LongValue__J(); var nr_365 int64 = n0_363 + n1_364; if (n0_363^nr_365)&(n1_364^nr_365) >= 0 { na_349 = jrt.Long_ValueOf_J__Long_NoInit(nr_365).Ref() } else { na_349 = lang.Numbers_Add_O_O__Number_NoInit(na_351, na_352) } } else { var tmp35 bool; var tmp36 bool; tmp36 = jrt.Double_InstanceOf(na_351); if tmp36 { tmp36 = jrt.Double_InstanceOf(na_352) }; tmp35 = tmp36; if tmp35 { var n0_363_2 float64 = jrt.NN(jrt.Double_Cast(na_351)).DoubleValue__D(); var n1_364_2 float64 = jrt.NN(jrt.Double_Cast(na_352)).DoubleValue__D(); na_349 = jrt.Double_ValueOf_D__Double_NoInit(n0_363_2 + n1_364_2).Ref() } else { na_349 = lang.Numbers_Add_O_O__Number_NoInit(na_351, na_352) } }; var na_350 any = doy__7; var tmp37 bool; var tmp38 bool; tmp38 = jrt.Long_InstanceOf(na_349); if tmp38 { tmp38 = jrt.Long_InstanceOf(na_350) }; tmp37 = tmp38; if tmp37 { var n0_366 int64 = jrt.NN(jrt.Long_Cast(na_349)).LongValue__J(); var n1_367 int64 = jrt.NN(jrt.Long_Cast(na_350)).LongValue__J(); var nr_368 int64 = n0_366 + n1_367; if (n0_366^nr_368)&(n1_367^nr_368) >= 0 { na_347 = jrt.Long_ValueOf_J__Long_NoInit(nr_368).Ref() } else { na_347 = lang.Numbers_Add_O_O__Number_NoInit(na_349, na_350) } } else { var tmp39 bool; var tmp40 bool; tmp40 = jrt.Double_InstanceOf(na_349); if tmp40 { tmp40 = jrt.Double_InstanceOf(na_350) }; tmp39 = tmp40; if tmp39 { var n0_366_2 float64 = jrt.NN(jrt.Double_Cast(na_349)).DoubleValue__D(); var n1_367_2 float64 = jrt.NN(jrt.Double_Cast(na_350)).DoubleValue__D(); na_347 = jrt.Double_ValueOf_D__Double_NoInit(n0_366_2 + n1_367_2).Ref() } else { na_347 = lang.Numbers_Add_O_O__Number_NoInit(na_349, na_350) } }; var na_348 any; var na_369 any = yoe__6; var na_370 int64 = 100; if jrt.Long_InstanceOf(na_369) { var n0_371 int64 = jrt.NN(jrt.Long_Cast(na_369)).LongValue__J(); var n1_372 int64 = na_370; if n1_372 == 0 { na_348 = lang.Numbers_Quotient_O_J__Number_NoInit(na_369, na_370) } else { na_348 = jrt.Long_ValueOf_J__Long_NoInit(n0_371 / n1_372).Ref() } } else { na_348 = lang.Numbers_Quotient_O_J__Number_NoInit(na_369, na_370) }; var tmp41 bool; var tmp42 bool; tmp42 = jrt.Long_InstanceOf(na_347); if tmp42 { tmp42 = jrt.Long_InstanceOf(na_348) }; tmp41 = tmp42; if tmp41 { var n0_374 int64 = jrt.NN(jrt.Long_Cast(na_347)).LongValue__J(); var n1_375 int64 = jrt.NN(jrt.Long_Cast(na_348)).LongValue__J(); var nr_376 int64 = n0_374 - n1_375; var tmp43 bool; var tmp44 bool; tmp44 = !(n1_375 == -9223372036854775808); if tmp44 { tmp44 = (n0_374^n1_375)&(n0_374^nr_376) >= 0 }; tmp43 = tmp44; if tmp43 { doe__8 = jrt.Long_ValueOf_J__Long_NoInit(nr_376).Ref() } else { doe__8 = lang.Numbers_Minus_O_O__Number_NoInit(na_347, na_348) } } else { var tmp45 bool; var tmp46 bool; tmp46 = jrt.Double_InstanceOf(na_347); if tmp46 { tmp46 = jrt.Double_InstanceOf(na_348) }; tmp45 = tmp46; if tmp45 { var n0_374_2 float64 = jrt.NN(jrt.Double_Cast(na_347)).DoubleValue__D(); var n1_375_2 float64 = jrt.NN(jrt.Double_Cast(na_348)).DoubleValue__D(); doe__8 = jrt.Double_ValueOf_D__Double_NoInit(n0_374_2 + -n1_375_2).Ref() } else { doe__8 = lang.Numbers_Minus_O_O__Number_NoInit(na_347, na_348) } }; var na_377 any; var na_379 any; var na_381 any = era__5; var na_382 int64 = 146097; if
	jrt.Long_InstanceOf(na_381) { var n0_383 int64 = jrt.NN(jrt.Long_Cast(na_381)).LongValue__J(); var n1_384 int64 = na_382; var nr_385 int64 = n0_383 * n1_384; var tmp47 bool; var tmp48 bool; var tmp49 bool; var tmp50 bool; tmp50 = n0_383 == -9223372036854775808; if tmp50 { tmp50 = n1_384 < 0 }; tmp49 = tmp50; tmp48 = !tmp49; if tmp48 { var tmp51 bool; tmp51 = n1_384 == 0; if !tmp51 { tmp51 = nr_385/n1_384 == n0_383 }; tmp48 = tmp51 }; tmp47 = tmp48; if tmp47 { na_379 = jrt.Long_ValueOf_J__Long_NoInit(nr_385).Ref() } else { na_379 = lang.Numbers_Multiply_O_J__Number_NoInit(na_381, na_382) } } else { na_379 = lang.Numbers_Multiply_O_J__Number_NoInit(na_381, na_382) }; var na_380 any = doe__8; var tmp52 bool; var tmp53 bool; tmp53 = jrt.Long_InstanceOf(na_379); if tmp53 { tmp53 = jrt.Long_InstanceOf(na_380) }; tmp52 = tmp53; if tmp52 { var n0_386 int64 = jrt.NN(jrt.Long_Cast(na_379)).LongValue__J(); var n1_387 int64 = jrt.NN(jrt.Long_Cast(na_380)).LongValue__J(); var nr_388 int64 = n0_386 + n1_387; if (n0_386^nr_388)&(n1_387^nr_388) >= 0 { na_377 = jrt.Long_ValueOf_J__Long_NoInit(nr_388).Ref() } else { na_377 = lang.Numbers_Add_O_O__Number_NoInit(na_379, na_380) } } else { var tmp54 bool; var tmp55 bool; tmp55 = jrt.Double_InstanceOf(na_379); if tmp55 { tmp55 = jrt.Double_InstanceOf(na_380) }; tmp54 = tmp55; if tmp54 { var n0_386_2 float64 = jrt.NN(jrt.Double_Cast(na_379)).DoubleValue__D(); var n1_387_2 float64 = jrt.NN(jrt.Double_Cast(na_380)).DoubleValue__D(); na_377 = jrt.Double_ValueOf_D__Double_NoInit(n0_386_2 + n1_387_2).Ref() } else { na_377 = lang.Numbers_Add_O_O__Number_NoInit(na_379, na_380) } }; var na_378 int64 = -719468; if jrt.Long_InstanceOf(na_377) { var n0_389 int64 = jrt.NN(jrt.Long_Cast(na_377)).LongValue__J(); var n1_390 int64 = na_378; var nr_391 int64 = n0_389 + n1_390; if (n0_389^nr_391)&(n1_390^nr_391) >= 0 { g__4 = jrt.Long_ValueOf_J__Long_NoInit(nr_391).Ref() } else { g__4 = lang.Numbers_Add_O_J__Number_NoInit(na_377, na_378) } } else { g__4 = lang.Numbers_Add_O_J__Number_NoInit(na_377, na_378) }; var tmp56 bool; var na_392 any = g__4; var na_393 any =
	A_arbace_instant_A_const_43.GetRawRoot__O(); var tmp57 bool; var tmp58 bool; tmp58 = jrt.Long_InstanceOf(na_392); if tmp58 { tmp58 = jrt.Long_InstanceOf(na_393) }; tmp57 = tmp58; if tmp57 { var n0_394 int64 = jrt.NN(jrt.Long_Cast(na_392)).LongValue__J(); var n1_395 int64 = jrt.NN(jrt.Long_Cast(na_393)).LongValue__J(); tmp56 = n0_394 >= n1_395 } else { var tmp59 bool; var tmp60 bool; tmp60 = jrt.Double_InstanceOf(na_392); if tmp60 { tmp60 = jrt.Double_InstanceOf(na_393) }; tmp59 = tmp60; if tmp59 { var n0_394_2 float64 = jrt.NN(jrt.Double_Cast(na_392)).DoubleValue__D(); var n1_395_2 float64 = jrt.NN(jrt.Double_Cast(na_393)).DoubleValue__D(); tmp56 = n0_394_2 >= n1_395_2 } else { tmp56 = lang.Numbers_Gte_O_O__Z_NoInit(na_392, na_393) } }; if tmp56 { return g__4 } else { var a__5 any; var na_397 any
		var na_399 int64 = 14; var na_400 any = m__1
		if jrt.Long_InstanceOf(na_400) { var n0_401 int64 = na_399; var n1_402 int64 = jrt.NN(jrt.Long_Cast(na_400)).LongValue__J(); var nr_403 int64 = n0_401 - n1_402; var tmp61 bool; var tmp62 bool; tmp62 = !(n1_402 == -9223372036854775808); if tmp62 { tmp62 = (n0_401^n1_402)&(n0_401^nr_403) >= 0 }; tmp61 = tmp62; if tmp61 { na_397 = jrt.Long_ValueOf_J__Long_NoInit(nr_403).Ref() } else { na_397 = lang.Numbers_Minus_J_O__Number_NoInit(na_399, na_400) } } else { na_397 = lang.Numbers_Minus_J_O__Number_NoInit(na_399, na_400) }; var na_398 int64 = 12; if jrt.Long_InstanceOf(na_397) { var n0_404 int64 = jrt.NN(jrt.Long_Cast(na_397)).LongValue__J(); var n1_405 int64 = na_398; if n1_405 == 0 { a__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_397, na_398) } else { a__5 = jrt.Long_ValueOf_J__Long_NoInit(n0_404 / n1_405).Ref() } } else { a__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_397, na_398) }
//line :211:1
		var yy__6 any; var na_407 any
		var na_409 any = y__0
		var na_410 int64 = 4800
		if jrt.Long_InstanceOf(na_409) { var n0_411 int64 = jrt.NN(jrt.Long_Cast(na_409)).LongValue__J(); var n1_412 int64 = na_410; var nr_413 int64 = n0_411 + n1_412; if (n0_411^nr_413)&(n1_412^nr_413) >= 0 { na_407 = jrt.Long_ValueOf_J__Long_NoInit(nr_413).Ref() } else { na_407 = lang.Numbers_Add_O_J__Number_NoInit(na_409, na_410) } } else { na_407 = lang.Numbers_Add_O_J__Number_NoInit(na_409, na_410) }; var na_408 any = a__5; var tmp63 bool; var tmp64 bool; tmp64 = jrt.Long_InstanceOf(na_407); if tmp64 { tmp64 = jrt.Long_InstanceOf(na_408) }; tmp63 = tmp64; if tmp63 { var n0_414 int64 = jrt.NN(jrt.Long_Cast(na_407)).LongValue__J(); var n1_415 int64 = jrt.NN(jrt.Long_Cast(na_408)).LongValue__J(); var nr_416 int64 = n0_414 - n1_415; var tmp65 bool; var tmp66 bool; tmp66 = !(n1_415 == -9223372036854775808); if tmp66 { tmp66 = (n0_414^n1_415)&(n0_414^nr_416) >= 0 }; tmp65 = tmp66; if tmp65 { yy__6 = jrt.Long_ValueOf_J__Long_NoInit(nr_416).Ref() } else { yy__6 = lang.Numbers_Minus_O_O__Number_NoInit(na_407, na_408) } } else { var tmp67 bool; var tmp68 bool; tmp68 = jrt.Double_InstanceOf(na_407); if tmp68 { tmp68 = jrt.Double_InstanceOf(na_408) }; tmp67 = tmp68; if tmp67 { var n0_414_2 float64 = jrt.NN(jrt.Double_Cast(na_407)).DoubleValue__D(); var n1_415_2 float64 = jrt.NN(jrt.Double_Cast(na_408)).DoubleValue__D(); yy__6 = jrt.Double_ValueOf_D__Double_NoInit(n0_414_2 + -n1_415_2).Ref() } else { yy__6 = lang.Numbers_Minus_O_O__Number_NoInit(na_407, na_408) } }
//line :211:1
		var mm__7 any; var na_417 any; var na_419 any = m__1; var na_420 any
		var na_421 int64 = 12
		var na_422 any = a__5

		if jrt.Long_InstanceOf(na_422) { var n0_423 int64 = na_421; var n1_424 int64 = jrt.NN(jrt.Long_Cast(na_422)).LongValue__J(); var nr_425 int64 = n0_423 * n1_424; var tmp69 bool; var tmp70 bool; var tmp71 bool; var tmp72 bool; tmp72 = n0_423 == -9223372036854775808; if tmp72 { tmp72 = n1_424 < 0 }; tmp71 = tmp72; tmp70 = !tmp71; if tmp70 { var tmp73 bool; tmp73 = n1_424 == 0; if !tmp73 { tmp73 = nr_425/n1_424 == n0_423 }; tmp70 = tmp73 }; tmp69 = tmp70; if tmp69 { na_420 = jrt.Long_ValueOf_J__Long_NoInit(nr_425).Ref() } else { na_420 = lang.Numbers_Multiply_J_O__Number_NoInit(na_421, na_422) } } else { na_420 = lang.Numbers_Multiply_J_O__Number_NoInit(na_421, na_422) }; var tmp74 bool; var tmp75 bool; tmp75 = jrt.Long_InstanceOf(na_419); if tmp75 { tmp75 = jrt.Long_InstanceOf(na_420) }; tmp74 = tmp75; if tmp74 { var n0_426 int64 = jrt.NN(jrt.Long_Cast(na_419)).LongValue__J(); var n1_427 int64 = jrt.NN(jrt.Long_Cast(na_420)).LongValue__J(); var nr_428 int64 = n0_426 + n1_427; if (n0_426^nr_428)&(n1_427^nr_428) >= 0 { na_417 = jrt.Long_ValueOf_J__Long_NoInit(nr_428).Ref() } else { na_417 = lang.Numbers_Add_O_O__Number_NoInit(na_419, na_420) } } else { var tmp76 bool; var tmp77 bool; tmp77 = jrt.Double_InstanceOf(na_419); if tmp77 { tmp77 = jrt.Double_InstanceOf(na_420) }; tmp76 = tmp77; if tmp76 { var n0_426_2 float64 = jrt.NN(jrt.Double_Cast(na_419)).DoubleValue__D(); var n1_427_2 float64 = jrt.NN(jrt.Double_Cast(na_420)).DoubleValue__D(); na_417 = jrt.Double_ValueOf_D__Double_NoInit(n0_426_2 + n1_427_2).Ref() } else { na_417 = lang.Numbers_Add_O_O__Number_NoInit(na_419, na_420) } }; var na_418 int64 = 3; if jrt.Long_InstanceOf(na_417) { var n0_429 int64 = jrt.NN(jrt.Long_Cast(na_417)).LongValue__J(); var n1_430 int64 = na_418; var nr_431 int64 = n0_429 - n1_430; var tmp78 bool; var tmp79 bool; tmp79 = !(n1_430 == -9223372036854775808); if tmp79 { tmp79 = (n0_429^n1_430)&(n0_429^nr_431) >= 0 }; tmp78 = tmp79; if tmp78 { mm__7 = jrt.Long_ValueOf_J__Long_NoInit(nr_431).Ref() } else { mm__7 = lang.Numbers_Minus_O_J__Number_NoInit(na_417, na_418) } } else { mm__7 = lang.Numbers_Minus_O_J__Number_NoInit(na_417, na_418) }
		var na_432 any; var na_434 any; var na_436 any; var na_438 any; var na_440 any = d__2; var na_441 any; var na_442 any; var na_444 any; var na_446 int64 = 153; var na_447 any = mm__7; if jrt.Long_InstanceOf(na_447) { var n0_448 int64 = na_446; var n1_449 int64 = jrt.NN(jrt.Long_Cast(na_447)).LongValue__J(); var nr_450 int64 = n0_448 * n1_449; var tmp80 bool; var tmp81 bool; var tmp82 bool; var tmp83 bool; tmp83 = n0_448 == -9223372036854775808; if tmp83 { tmp83 = n1_449 < 0 }; tmp82 = tmp83; tmp81 = !tmp82; if tmp81 { var tmp84 bool; tmp84 = n1_449 == 0; if !tmp84 { tmp84 = nr_450/n1_449 == n0_448 }; tmp81 = tmp84 }; tmp80 = tmp81; if tmp80 { na_444 = jrt.Long_ValueOf_J__Long_NoInit(nr_450).Ref() } else { na_444 = lang.Numbers_Multiply_J_O__Number_NoInit(na_446, na_447) } } else { na_444 = lang.Numbers_Multiply_J_O__Number_NoInit(na_446, na_447) }; var na_445 int64 = 2; if jrt.Long_InstanceOf(na_444) { var n0_451 int64 = jrt.NN(jrt.Long_Cast(na_444)).LongValue__J(); var n1_452 int64 = na_445; var nr_453 int64 = n0_451 + n1_452; if (n0_451^nr_453)&(n1_452^nr_453) >= 0 { na_442 = jrt.Long_ValueOf_J__Long_NoInit(nr_453).Ref() } else { na_442 = lang.Numbers_Add_O_J__Number_NoInit(na_444, na_445) } } else { na_442 = lang.Numbers_Add_O_J__Number_NoInit(na_444, na_445) }; var na_443 int64 = 5; if jrt.Long_InstanceOf(na_442) { var n0_454 int64 = jrt.NN(jrt.Long_Cast(na_442)).LongValue__J(); var n1_455 int64 = na_443; if n1_455 == 0 { na_441 = lang.Numbers_Quotient_O_J__Number_NoInit(na_442, na_443) } else { na_441 = jrt.Long_ValueOf_J__Long_NoInit(n0_454 / n1_455).Ref() } } else { na_441 = lang.Numbers_Quotient_O_J__Number_NoInit(na_442, na_443) }; var tmp85 bool; var tmp86 bool; tmp86 = jrt.Long_InstanceOf(na_440); if tmp86 { tmp86 = jrt.Long_InstanceOf(na_441) }; tmp85 = tmp86; if tmp85 { var n0_457 int64 = jrt.NN(jrt.Long_Cast(na_440)).LongValue__J(); var n1_458 int64 = jrt.NN(jrt.Long_Cast(na_441)).LongValue__J(); var nr_459 int64 = n0_457 + n1_458; if (n0_457^nr_459)&(n1_458^nr_459) >= 0 { na_438 = jrt.Long_ValueOf_J__Long_NoInit(nr_459).Ref() } else { na_438 = lang.Numbers_Add_O_O__Number_NoInit(na_440, na_441) } } else { var tmp87 bool; var tmp88 bool; tmp88 = jrt.Double_InstanceOf(na_440); if tmp88 { tmp88 = jrt.Double_InstanceOf(na_441) }; tmp87 = tmp88; if tmp87 { var n0_457_2 float64 = jrt.NN(jrt.Double_Cast(na_440)).DoubleValue__D(); var n1_458_2 float64 = jrt.NN(jrt.Double_Cast(na_441)).DoubleValue__D(); na_438 = jrt.Double_ValueOf_D__Double_NoInit(n0_457_2 + n1_458_2).Ref() } else { na_438 = lang.Numbers_Add_O_O__Number_NoInit(na_440, na_441) } }; var na_439 any; var na_460 int64 = 365; var na_461 any = yy__6; if jrt.Long_InstanceOf(na_461) { var n0_462 int64 = na_460; var n1_463 int64 = jrt.NN(jrt.Long_Cast(na_461)).LongValue__J(); var nr_464 int64 = n0_462 * n1_463; var tmp89 bool; var tmp90 bool; var tmp91 bool; var tmp92 bool; tmp92 = n0_462 == -9223372036854775808; if tmp92 { tmp92 = n1_463 < 0 }; tmp91 = tmp92; tmp90 = !tmp91; if tmp90 { var tmp93 bool; tmp93 = n1_463 == 0; if !tmp93 { tmp93 = nr_464/n1_463 == n0_462 }; tmp90 = tmp93 }; tmp89 = tmp90; if tmp89 { na_439 = jrt.Long_ValueOf_J__Long_NoInit(nr_464).Ref() } else { na_439 = lang.Numbers_Multiply_J_O__Number_NoInit(na_460, na_461) } } else { na_439 = lang.Numbers_Multiply_J_O__Number_NoInit(na_460, na_461) }; var tmp94 bool; var tmp95 bool; tmp95 = jrt.Long_InstanceOf(na_438); if tmp95 { tmp95 = jrt.Long_InstanceOf(na_439) }; tmp94 = tmp95; if tmp94 { var n0_465 int64 = jrt.NN(jrt.Long_Cast(na_438)).LongValue__J(); var n1_466 int64 = jrt.NN(jrt.Long_Cast(na_439)).LongValue__J(); var nr_467 int64 = n0_465 + n1_466; if (n0_465^nr_467)&(n1_466^nr_467) >= 0 { na_436 = jrt.Long_ValueOf_J__Long_NoInit(nr_467).Ref() } else { na_436 = lang.Numbers_Add_O_O__Number_NoInit(na_438, na_439) } } else { var tmp96 bool; var tmp97 bool; tmp97 = jrt.Double_InstanceOf(na_438); if tmp97 { tmp97 = jrt.Double_InstanceOf(na_439) }; tmp96 = tmp97; if tmp96 { var n0_465_2 float64 = jrt.NN(jrt.Double_Cast(na_438)).DoubleValue__D(); var n1_466_2 float64 = jrt.NN(jrt.Double_Cast(na_439)).DoubleValue__D(); na_436 = jrt.Double_ValueOf_D__Double_NoInit(n0_465_2 + n1_466_2).Ref() } else { na_436 = lang.Numbers_Add_O_O__Number_NoInit(na_438, na_439) } }; var na_437 int64 = jrt.Math_FloorDiv_J_J__J(lang.RT_LongCast_O__J_NoInit(yy__6), 4); if jrt.Long_InstanceOf(na_436) { var n0_468 int64 = jrt.NN(jrt.Long_Cast(na_436)).LongValue__J(); var n1_469 int64 = na_437; var nr_470 int64 = n0_468 + n1_469; if (n0_468^nr_470)&(n1_469^nr_470) >= 0 { na_434 = jrt.Long_ValueOf_J__Long_NoInit(nr_470).Ref() } else { na_434 = lang.Numbers_Add_O_J__Number_NoInit(na_436, na_437) } } else { na_434 = lang.Numbers_Add_O_J__Number_NoInit(na_436, na_437) }; var na_435 int64 = -32083; if jrt.Long_InstanceOf(na_434) { var n0_471 int64 = jrt.NN(jrt.Long_Cast(na_434)).LongValue__J(); var n1_472 int64 = na_435; var nr_473 int64 = n0_471 + n1_472; if (n0_471^nr_473)&(n1_472^nr_473) >= 0 { na_432 = jrt.Long_ValueOf_J__Long_NoInit(nr_473).Ref() } else { na_432 = lang.Numbers_Add_O_J__Number_NoInit(na_434, na_435) } } else { na_432 = lang.Numbers_Add_O_J__Number_NoInit(na_434, na_435) }; var na_433 int64 = 2440588; if jrt.Long_InstanceOf(na_432) { var n0_474 int64 = jrt.NN(jrt.Long_Cast(na_432)).LongValue__J(); var n1_475 int64 = na_433; var nr_476 int64 = n0_474 - n1_475; var tmp98 bool; var tmp99 bool; tmp99 = !(n1_475 == -9223372036854775808); if tmp99 { tmp99 = (n0_474^n1_475)&(n0_474^nr_476) >= 0 }; tmp98 = tmp99; if tmp98 { return jrt.Long_ValueOf_J__Long_NoInit(nr_476).Ref() } else { return lang.Numbers_Minus_O_J__Number_NoInit(na_432, na_433) } } else { return lang.Numbers_Minus_O_J__Number_NoInit(na_432, na_433) } } }

func A_arbace_instant_print_date_A_New() *A_arbace_instant_print_date_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_print_date_A{}; t.Ctor(); return t }
//line :218:1
func (t *A_arbace_instant_print_date_A) Ctor() {}
//line :218:1
func (t *A_arbace_instant_print_date_A) Invoke_O_O_O__O(self, d__0, w__1 any) any { var ms__3 int64 = jrt.Date_Cast(d__0).GetTime__J(); var days__4 int64 = jrt.Math_FloorDiv_J_J__J(ms__3, 86400000); var msd__5 int64 = jrt.Math_FloorMod_J_J__J(ms__3, 86400000); var vec__783000040__6 any = lang.IFn_Cast(A_arbace_instant_A_const_44.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(days__4).Ref()); var y__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000040__6, lang.RT_IntCast_J__I_NoInit(0), nil); var m__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000040__6, lang.RT_IntCast_J__I_NoInit(1), nil); var dd__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000040__6, lang.RT_IntCast_J__I_NoInit(2), nil);






	jrt.Writer_Cast(w__1).Write_String__V(Lit_12); var tmp1 jrt.Writer_I =
	jrt.Writer_Cast(w__1); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_45.GetRawRoot__O()); var tmp3 any; var tmp4 bool; var na_477 any = y__7; var na_478 int64 = 0; if
	jrt.Long_InstanceOf(na_477) { var n0_479 int64 = jrt.NN(jrt.Long_Cast(na_477)).LongValue__J(); var n1_480 int64 = na_478; tmp4 = n0_479 <= n1_480 } else { tmp4 = lang.Numbers_Lte_O_J__Z_NoInit(na_477, na_478) }; if tmp4 { var na_482 int64 = 1; var na_483 any = y__7; if jrt.Long_InstanceOf(na_483) { var n0_484 int64 = na_482; var n1_485 int64 = jrt.NN(jrt.Long_Cast(na_483)).LongValue__J(); var nr_486 int64 = n0_484 - n1_485; var tmp5 bool; var tmp6 bool; tmp6 = !(n1_485 == -9223372036854775808); if tmp6 { tmp6 = (n0_484^n1_485)&(n0_484^nr_486) >= 0 }; tmp5 = tmp6; if tmp5 { tmp3 = jrt.Long_ValueOf_J__Long_NoInit(nr_486).Ref() } else { tmp3 = lang.Numbers_Minus_J_O__Number_NoInit(na_482, na_483) } } else { tmp3 = lang.Numbers_Minus_J_O__Number_NoInit(na_482, na_483) } } else { tmp3 = y__7 }; /*line :226:1*/tmp1.Write_String__V(jrt.String_Cast(tmp2.Invoke_O_O_O_O_O_O_O_O__O(Lit_15, tmp3, m__8, dd__9, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(msd__5, 3600000)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Remainder_J_J__J_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(msd__5, 60000), 60)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Remainder_J_J__J_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(msd__5, 1000), 60)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Remainder_J_J__J_NoInit(msd__5, 1000)).Ref())));


	jrt.Writer_Cast(w__1).Write_String__V(Lit_14); return nil }

func A_arbace_instant_eval783000044_fn__783000045_A_New() *A_arbace_instant_eval783000044_fn__783000045_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000044_fn__783000045_A{}; t.Ctor(); return t }
//line :231:1
func (t *A_arbace_instant_eval783000044_fn__783000045_A) Ctor() {}
//line :231:1
func (t *A_arbace_instant_eval783000044_fn__783000045_A) Invoke_O_O_O__O(self, d__1, w__2 any) any {

	return lang.IFn_Cast(A_arbace_instant_A_const_46.GetRawRoot__O()).Invoke_O_O__O(d__1, w__2)
}
func A_arbace_instant_eval783000048_fn__783000049_A_New() *A_arbace_instant_eval783000048_fn__783000049_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000048_fn__783000049_A{}; t.Ctor(); return t }
//line :235:1
func (t *A_arbace_instant_eval783000048_fn__783000049_A) Ctor() {}
//line :235:1
func (t *A_arbace_instant_eval783000048_fn__783000049_A) Invoke_O_O_O__O(self, d__1, w__2 any) any {

	return lang.IFn_Cast(A_arbace_instant_A_const_46.GetRawRoot__O()).Invoke_O_O__O(d__1, w__2)
}
func A_arbace_instant_print_calendar_A_New() *A_arbace_instant_print_calendar_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_print_calendar_A{}; t.Ctor(); return t }
//line :239:1
func (t *A_arbace_instant_print_calendar_A) Ctor() {}
//line :239:1
func (t *A_arbace_instant_print_calendar_A) Invoke_O_O_O__O(self, c__0, w__1 any) any { var calstr__3 any = lang.IFn_Cast(A_arbace_instant_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_11, c__0); var offset_minutes__4 int64 = lang.Numbers_Minus_J_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(calstr__3)).Length__I()), 2);





	jrt.Writer_Cast(w__1).Write_String__V(Lit_12);
	jrt.Writer_Cast(w__1).Write_String_I_I__V(jrt.String_Cast(calstr__3), lang.RT_IntCast_J__I_NoInit(0), lang.RT_IntCast_J__I_NoInit(offset_minutes__4));
	jrt.Writer_Cast(w__1).Write_String__V(Lit_13);
	jrt.Writer_Cast(w__1).Write_String_I_I__V(jrt.String_Cast(calstr__3), lang.RT_IntCast_J__I_NoInit(offset_minutes__4), lang.RT_IntCast_J__I_NoInit(2));
	jrt.Writer_Cast(w__1).Write_String__V(Lit_14); return nil }

func A_arbace_instant_eval783000053_fn__783000054_A_New() *A_arbace_instant_eval783000053_fn__783000054_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000053_fn__783000054_A{}; t.Ctor(); return t }
//line :251:1
func (t *A_arbace_instant_eval783000053_fn__783000054_A) Ctor() {}
//line :251:1
func (t *A_arbace_instant_eval783000053_fn__783000054_A) Invoke_O_O_O__O(self, c__1, w__2 any) any {

	return lang.IFn_Cast(A_arbace_instant_A_const_47.GetRawRoot__O()).Invoke_O_O__O(c__1, w__2)
}
func A_arbace_instant_eval783000057_fn__783000058_A_New() *A_arbace_instant_eval783000057_fn__783000058_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000057_fn__783000058_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_instant_eval783000057_fn__783000058_A) Ctor() {}
//line :255:1
func (t *A_arbace_instant_eval783000057_fn__783000058_A) Invoke_O_O_O__O(self, c__1, w__2 any) any {

	return lang.IFn_Cast(A_arbace_instant_A_const_47.GetRawRoot__O()).Invoke_O_O__O(c__1, w__2)
}
func A_arbace_instant_print_timestamp_A_New() *A_arbace_instant_print_timestamp_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_print_timestamp_A{}; t.Ctor(); return t }
//line :259:1
func (t *A_arbace_instant_print_timestamp_A) Ctor() {}
//line :259:1
func (t *A_arbace_instant_print_timestamp_A) Invoke_O_O_O__O(self, ts__0, w__1 any) any { var ms__3 int64 = jrt.NN(jrt.Timestamp_Cast(ts__0)).GetTime__J(); var days__4 int64 = jrt.Math_FloorDiv_J_J__J(ms__3, 86400000); var msd__5 int64 = jrt.Math_FloorMod_J_J__J(ms__3, 86400000); var vec__783000061__6 any = lang.IFn_Cast(A_arbace_instant_A_const_44.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(days__4).Ref()); var y__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000061__6, lang.RT_IntCast_J__I_NoInit(0), nil); var m__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000061__6, lang.RT_IntCast_J__I_NoInit(1), nil); var dd__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__783000061__6, lang.RT_IntCast_J__I_NoInit(2), nil);






	jrt.Writer_Cast(w__1).Write_String__V(Lit_12); var tmp1 jrt.Writer_I =
	jrt.Writer_Cast(w__1); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_45.GetRawRoot__O()); var tmp3 any; var tmp4 bool; var na_487 any = y__7; var na_488 int64 = 0; if
	jrt.Long_InstanceOf(na_487) { var n0_489 int64 = jrt.NN(jrt.Long_Cast(na_487)).LongValue__J(); var n1_490 int64 = na_488; tmp4 = n0_489 <= n1_490 } else { tmp4 = lang.Numbers_Lte_O_J__Z_NoInit(na_487, na_488) }; if tmp4 { var na_492 int64 = 1; var na_493 any = y__7; if jrt.Long_InstanceOf(na_493) { var n0_494 int64 = na_492; var n1_495 int64 = jrt.NN(jrt.Long_Cast(na_493)).LongValue__J(); var nr_496 int64 = n0_494 - n1_495; var tmp5 bool; var tmp6 bool; tmp6 = !(n1_495 == -9223372036854775808); if tmp6 { tmp6 = (n0_494^n1_495)&(n0_494^nr_496) >= 0 }; tmp5 = tmp6; if tmp5 { tmp3 = jrt.Long_ValueOf_J__Long_NoInit(nr_496).Ref() } else { tmp3 = lang.Numbers_Minus_J_O__Number_NoInit(na_492, na_493) } } else { tmp3 = lang.Numbers_Minus_J_O__Number_NoInit(na_492, na_493) } } else { tmp3 = y__7 }; /*line :267:1*/tmp1.Write_String__V(jrt.String_Cast(tmp2.Invoke_O_O_O_O_O_O_O__O(Lit_16, tmp3, m__8, dd__9, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(msd__5, 3600000)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Remainder_J_J__J_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(msd__5, 60000), 60)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Remainder_J_J__J_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(msd__5, 1000), 60)).Ref())));




	jrt.Writer_Cast(w__1).Write_String__V(jrt.String_Cast(lang.IFn_Cast(A_arbace_instant_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_17, jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Timestamp_Cast(ts__0)).GetNanos__I()).Ref())));
	jrt.Writer_Cast(w__1).Write_String__V(Lit_14); return nil }

func A_arbace_instant_eval783000065_fn__783000066_A_New() *A_arbace_instant_eval783000065_fn__783000066_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000065_fn__783000066_A{}; t.Ctor(); return t }
//line :275:1
func (t *A_arbace_instant_eval783000065_fn__783000066_A) Ctor() {}
//line :275:1
func (t *A_arbace_instant_eval783000065_fn__783000066_A) Invoke_O_O_O__O(self, ts__1, w__2 any) any {

	return lang.IFn_Cast(A_arbace_instant_A_const_48.GetRawRoot__O()).Invoke_O_O__O(ts__1, w__2)
}
func A_arbace_instant_eval783000069_fn__783000070_A_New() *A_arbace_instant_eval783000069_fn__783000070_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000069_fn__783000070_A{}; t.Ctor(); return t }
//line :279:1
func (t *A_arbace_instant_eval783000069_fn__783000070_A) Ctor() {}
//line :279:1
func (t *A_arbace_instant_eval783000069_fn__783000070_A) Invoke_O_O_O__O(self, ts__1, w__2 any) any {

	return lang.IFn_Cast(A_arbace_instant_A_const_48.GetRawRoot__O()).Invoke_O_O__O(ts__1, w__2)
}



func A_arbace_instant_construct_date_A_New() *A_arbace_instant_construct_date_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_construct_date_A{}; t.Ctor(); return t }
//line :286:1
func (t *A_arbace_instant_construct_date_A) Ctor() {}
//line :286:1
func (t *A_arbace_instant_construct_date_A) Invoke_O_O_O_O_O_O_O_O_O_O_O__O(self, years__0, months__1, days__2, hours__3, minutes__4, seconds__5, nanoseconds__6, offset_sign__7, offset_hours__8, offset_minutes__9 any) any { var tmp1 jrt.Number_I; var na_497 any; var na_499 any; var na_501 any; var na_503 any; var na_505 any; var na_507 any = lang.IFn_Cast(A_arbace_instant_A_const_49.GetRawRoot__O()).Invoke_O_O_O__O(years__0, months__1, days__2); var na_508 int64 = 86400000; if




	jrt.Long_InstanceOf(na_507) { var n0_509 int64 = jrt.NN(jrt.Long_Cast(na_507)).LongValue__J(); var n1_510 int64 = na_508; var nr_511 int64 = n0_509 * n1_510; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 bool; tmp5 = n0_509 == -9223372036854775808; if tmp5 { tmp5 = n1_510 < 0 }; tmp4 = tmp5; tmp3 = !tmp4; if tmp3 { var tmp6 bool; tmp6 = n1_510 == 0; if !tmp6 { tmp6 = nr_511/n1_510 == n0_509 }; tmp3 = tmp6 }; tmp2 = tmp3; if tmp2 { na_505 = jrt.Long_ValueOf_J__Long_NoInit(nr_511).Ref() } else { na_505 = lang.Numbers_Multiply_O_J__Number_NoInit(na_507, na_508) } } else { na_505 = lang.Numbers_Multiply_O_J__Number_NoInit(na_507, na_508) }; var na_506 any; var na_512 any = hours__3; var na_513 int64 = 3600000; if
	jrt.Long_InstanceOf(na_512) { var n0_514 int64 = jrt.NN(jrt.Long_Cast(na_512)).LongValue__J(); var n1_515 int64 = na_513; var nr_516 int64 = n0_514 * n1_515; var tmp7 bool; var tmp8 bool; var tmp9 bool; var tmp10 bool; tmp10 = n0_514 == -9223372036854775808; if tmp10 { tmp10 = n1_515 < 0 }; tmp9 = tmp10; tmp8 = !tmp9; if tmp8 { var tmp11 bool; tmp11 = n1_515 == 0; if !tmp11 { tmp11 = nr_516/n1_515 == n0_514 }; tmp8 = tmp11 }; tmp7 = tmp8; if tmp7 { na_506 = jrt.Long_ValueOf_J__Long_NoInit(nr_516).Ref() } else { na_506 = lang.Numbers_Multiply_O_J__Number_NoInit(na_512, na_513) } } else { na_506 = lang.Numbers_Multiply_O_J__Number_NoInit(na_512, na_513) }; var tmp12 bool; var tmp13 bool; tmp13 = /*line :291:1*/jrt.Long_InstanceOf(na_505); if tmp13 { tmp13 = jrt.Long_InstanceOf(na_506) }; tmp12 = tmp13; if tmp12 { var n0_517 int64 = jrt.NN(jrt.Long_Cast(na_505)).LongValue__J(); var n1_518 int64 = jrt.NN(jrt.Long_Cast(na_506)).LongValue__J(); var nr_519 int64 = n0_517 + n1_518; if (n0_517^nr_519)&(n1_518^nr_519) >= 0 { na_503 = jrt.Long_ValueOf_J__Long_NoInit(nr_519).Ref() } else { na_503 = lang.Numbers_Add_O_O__Number_NoInit(na_505, na_506) } } else { var tmp14 bool; var tmp15 bool; tmp15 = jrt.Double_InstanceOf(na_505); if tmp15 { tmp15 = jrt.Double_InstanceOf(na_506) }; tmp14 = tmp15; if tmp14 { var n0_517_2 float64 = jrt.NN(jrt.Double_Cast(na_505)).DoubleValue__D(); var n1_518_2 float64 = jrt.NN(jrt.Double_Cast(na_506)).DoubleValue__D(); na_503 = jrt.Double_ValueOf_D__Double_NoInit(n0_517_2 + n1_518_2).Ref() } else { na_503 = lang.Numbers_Add_O_O__Number_NoInit(na_505, na_506) } }; var na_504 any; var na_520 any = minutes__4; var na_521 int64 = 60000; if
	jrt.Long_InstanceOf(na_520) { var n0_522 int64 = jrt.NN(jrt.Long_Cast(na_520)).LongValue__J(); var n1_523 int64 = na_521; var nr_524 int64 = n0_522 * n1_523; var tmp16 bool; var tmp17 bool; var tmp18 bool; var tmp19 bool; tmp19 = n0_522 == -9223372036854775808; if tmp19 { tmp19 = n1_523 < 0 }; tmp18 = tmp19; tmp17 = !tmp18; if tmp17 { var tmp20 bool; tmp20 = n1_523 == 0; if !tmp20 { tmp20 = nr_524/n1_523 == n0_522 }; tmp17 = tmp20 }; tmp16 = tmp17; if tmp16 { na_504 = jrt.Long_ValueOf_J__Long_NoInit(nr_524).Ref() } else { na_504 = lang.Numbers_Multiply_O_J__Number_NoInit(na_520, na_521) } } else { na_504 = lang.Numbers_Multiply_O_J__Number_NoInit(na_520, na_521) }; var tmp21 bool; var tmp22 bool; tmp22 = /*line :291:1*/jrt.Long_InstanceOf(na_503); if tmp22 { tmp22 = jrt.Long_InstanceOf(na_504) }; tmp21 = tmp22; if tmp21 { var n0_525 int64 = jrt.NN(jrt.Long_Cast(na_503)).LongValue__J(); var n1_526 int64 = jrt.NN(jrt.Long_Cast(na_504)).LongValue__J(); var nr_527 int64 = n0_525 + n1_526; if (n0_525^nr_527)&(n1_526^nr_527) >= 0 { na_501 = jrt.Long_ValueOf_J__Long_NoInit(nr_527).Ref() } else { na_501 = lang.Numbers_Add_O_O__Number_NoInit(na_503, na_504) } } else { var tmp23 bool; var tmp24 bool; tmp24 = jrt.Double_InstanceOf(na_503); if tmp24 { tmp24 = jrt.Double_InstanceOf(na_504) }; tmp23 = tmp24; if tmp23 { var n0_525_2 float64 = jrt.NN(jrt.Double_Cast(na_503)).DoubleValue__D(); var n1_526_2 float64 = jrt.NN(jrt.Double_Cast(na_504)).DoubleValue__D(); na_501 = jrt.Double_ValueOf_D__Double_NoInit(n0_525_2 + n1_526_2).Ref() } else { na_501 = lang.Numbers_Add_O_O__Number_NoInit(na_503, na_504) } }; var na_502 any; var na_528 any = seconds__5; var na_529 int64 = 1000; if
	jrt.Long_InstanceOf(na_528) { var n0_530 int64 = jrt.NN(jrt.Long_Cast(na_528)).LongValue__J(); var n1_531 int64 = na_529; var nr_532 int64 = n0_530 * n1_531; var tmp25 bool; var tmp26 bool; var tmp27 bool; var tmp28 bool; tmp28 = n0_530 == -9223372036854775808; if tmp28 { tmp28 = n1_531 < 0 }; tmp27 = tmp28; tmp26 = !tmp27; if tmp26 { var tmp29 bool; tmp29 = n1_531 == 0; if !tmp29 { tmp29 = nr_532/n1_531 == n0_530 }; tmp26 = tmp29 }; tmp25 = tmp26; if tmp25 { na_502 = jrt.Long_ValueOf_J__Long_NoInit(nr_532).Ref() } else { na_502 = lang.Numbers_Multiply_O_J__Number_NoInit(na_528, na_529) } } else { na_502 = lang.Numbers_Multiply_O_J__Number_NoInit(na_528, na_529) }; var tmp30 bool; var tmp31 bool; tmp31 = /*line :291:1*/jrt.Long_InstanceOf(na_501); if tmp31 { tmp31 = jrt.Long_InstanceOf(na_502) }; tmp30 = tmp31; if tmp30 { var n0_533 int64 = jrt.NN(jrt.Long_Cast(na_501)).LongValue__J(); var n1_534 int64 = jrt.NN(jrt.Long_Cast(na_502)).LongValue__J(); var nr_535 int64 = n0_533 + n1_534; if (n0_533^nr_535)&(n1_534^nr_535) >= 0 { na_499 = jrt.Long_ValueOf_J__Long_NoInit(nr_535).Ref() } else { na_499 = lang.Numbers_Add_O_O__Number_NoInit(na_501, na_502) } } else { var tmp32 bool; var tmp33 bool; tmp33 = jrt.Double_InstanceOf(na_501); if tmp33 { tmp33 = jrt.Double_InstanceOf(na_502) }; tmp32 = tmp33; if tmp32 { var n0_533_2 float64 = jrt.NN(jrt.Double_Cast(na_501)).DoubleValue__D(); var n1_534_2 float64 = jrt.NN(jrt.Double_Cast(na_502)).DoubleValue__D(); na_499 = jrt.Double_ValueOf_D__Double_NoInit(n0_533_2 + n1_534_2).Ref() } else { na_499 = lang.Numbers_Add_O_O__Number_NoInit(na_501, na_502) } }; var na_500 any; var na_536 any = nanoseconds__6; var na_537 int64 = 1000000; if

	jrt.Long_InstanceOf(na_536) { var n0_538 int64 = jrt.NN(jrt.Long_Cast(na_536)).LongValue__J(); var n1_539 int64 = na_537; if n1_539 == 0 { na_500 = lang.Numbers_Quotient_O_J__Number_NoInit(na_536, na_537) } else { na_500 = jrt.Long_ValueOf_J__Long_NoInit(n0_538 / n1_539).Ref() } } else { na_500 = lang.Numbers_Quotient_O_J__Number_NoInit(na_536, na_537) }; var tmp34 bool; var tmp35 bool; tmp35 = /*line :291:1*/jrt.Long_InstanceOf(na_499); if tmp35 { tmp35 = jrt.Long_InstanceOf(na_500) }; tmp34 = tmp35; if tmp34 { var n0_541 int64 = jrt.NN(jrt.Long_Cast(na_499)).LongValue__J(); var n1_542 int64 = jrt.NN(jrt.Long_Cast(na_500)).LongValue__J(); var nr_543 int64 = n0_541 + n1_542; if (n0_541^nr_543)&(n1_542^nr_543) >= 0 { na_497 = jrt.Long_ValueOf_J__Long_NoInit(nr_543).Ref() } else { na_497 = lang.Numbers_Add_O_O__Number_NoInit(na_499, na_500) } } else { var tmp36 bool; var tmp37 bool; tmp37 = jrt.Double_InstanceOf(na_499); if tmp37 { tmp37 = jrt.Double_InstanceOf(na_500) }; tmp36 = tmp37; if tmp36 { var n0_541_2 float64 = jrt.NN(jrt.Double_Cast(na_499)).DoubleValue__D(); var n1_542_2 float64 = jrt.NN(jrt.Double_Cast(na_500)).DoubleValue__D(); na_497 = jrt.Double_ValueOf_D__Double_NoInit(n0_541_2 + n1_542_2).Ref() } else { na_497 = lang.Numbers_Add_O_O__Number_NoInit(na_499, na_500) } }; var na_498 any; var na_544 any; var na_546 any = offset_sign__7; var na_547 any; var na_548 any; var na_550 any = offset_hours__8; var na_551 int64 = 60; if


	jrt.Long_InstanceOf(na_550) { var n0_552 int64 = jrt.NN(jrt.Long_Cast(na_550)).LongValue__J(); var n1_553 int64 = na_551; var nr_554 int64 = n0_552 * n1_553; var tmp38 bool; var tmp39 bool; var tmp40 bool; var tmp41 bool; tmp41 = n0_552 == -9223372036854775808; if tmp41 { tmp41 = n1_553 < 0 }; tmp40 = tmp41; tmp39 = !tmp40; if tmp39 { var tmp42 bool; tmp42 = n1_553 == 0; if !tmp42 { tmp42 = nr_554/n1_553 == n0_552 }; tmp39 = tmp42 }; tmp38 = tmp39; if tmp38 { na_548 = jrt.Long_ValueOf_J__Long_NoInit(nr_554).Ref() } else { na_548 = lang.Numbers_Multiply_O_J__Number_NoInit(na_550, na_551) } } else { na_548 = lang.Numbers_Multiply_O_J__Number_NoInit(na_550, na_551) }; var na_549 any = offset_minutes__9; var tmp43 bool; var tmp44 bool; tmp44 = jrt.Long_InstanceOf(na_548); if tmp44 { tmp44 = jrt.Long_InstanceOf(na_549) }; tmp43 = tmp44; if tmp43 { var n0_555 int64 = jrt.NN(jrt.Long_Cast(na_548)).LongValue__J(); var n1_556 int64 = jrt.NN(jrt.Long_Cast(na_549)).LongValue__J(); var nr_557 int64 = n0_555 + n1_556; if (n0_555^nr_557)&(n1_556^nr_557) >= 0 { na_547 = jrt.Long_ValueOf_J__Long_NoInit(nr_557).Ref() } else { na_547 = lang.Numbers_Add_O_O__Number_NoInit(na_548, na_549) } } else { var tmp45 bool; var tmp46 bool; tmp46 = jrt.Double_InstanceOf(na_548); if tmp46 { tmp46 = jrt.Double_InstanceOf(na_549) }; tmp45 = tmp46; if tmp45 { var n0_555_2 float64 = jrt.NN(jrt.Double_Cast(na_548)).DoubleValue__D(); var n1_556_2 float64 = jrt.NN(jrt.Double_Cast(na_549)).DoubleValue__D(); na_547 = jrt.Double_ValueOf_D__Double_NoInit(n0_555_2 + n1_556_2).Ref() } else { na_547 = lang.Numbers_Add_O_O__Number_NoInit(na_548, na_549) } }; var tmp47 bool; var tmp48 bool; tmp48 = jrt.Long_InstanceOf(na_546); if tmp48 { tmp48 = jrt.Long_InstanceOf(na_547) }; tmp47 = tmp48; if tmp47 { var n0_558 int64 = jrt.NN(jrt.Long_Cast(na_546)).LongValue__J(); var n1_559 int64 = jrt.NN(jrt.Long_Cast(na_547)).LongValue__J(); var nr_560 int64 = n0_558 * n1_559; var tmp49 bool; var tmp50 bool; var tmp51 bool; var tmp52 bool; tmp52 = n0_558 == -9223372036854775808; if tmp52 { tmp52 = n1_559 < 0 }; tmp51 = tmp52; tmp50 = !tmp51; if tmp50 { var tmp53 bool; tmp53 = n1_559 == 0; if !tmp53 { tmp53 = nr_560/n1_559 == n0_558 }; tmp50 = tmp53 }; tmp49 = tmp50; if tmp49 { na_544 = jrt.Long_ValueOf_J__Long_NoInit(nr_560).Ref() } else { na_544 = lang.Numbers_Multiply_O_O__Number_NoInit(na_546, na_547) } } else { var tmp54 bool; var tmp55 bool; tmp55 = jrt.Double_InstanceOf(na_546); if tmp55 { tmp55 = jrt.Double_InstanceOf(na_547) }; tmp54 = tmp55; if tmp54 { var n0_558_2 float64 = jrt.NN(jrt.Double_Cast(na_546)).DoubleValue__D(); var n1_559_2 float64 = jrt.NN(jrt.Double_Cast(na_547)).DoubleValue__D(); na_544 = jrt.Double_ValueOf_D__Double_NoInit(float64(n0_558_2 * n1_559_2)).Ref() } else { na_544 = lang.Numbers_Multiply_O_O__Number_NoInit(na_546, na_547) } }; var na_545 int64 = 60000; if jrt.Long_InstanceOf(na_544) { var n0_561 int64 = jrt.NN(jrt.Long_Cast(na_544)).LongValue__J(); var n1_562 int64 = na_545; var nr_563 int64 = n0_561 * n1_562; var tmp56 bool; var tmp57 bool; var tmp58 bool; var tmp59 bool; tmp59 = n0_561 == -9223372036854775808; if tmp59 { tmp59 = n1_562 < 0 }; tmp58 = tmp59; tmp57 = !tmp58; if tmp57 { var tmp60 bool; tmp60 = n1_562 == 0; if !tmp60 { tmp60 = nr_563/n1_562 == n0_561 }; tmp57 = tmp60 }; tmp56 = tmp57; if tmp56 { na_498 = jrt.Long_ValueOf_J__Long_NoInit(nr_563).Ref() } else { na_498 = lang.Numbers_Multiply_O_J__Number_NoInit(na_544, na_545) } } else { na_498 = lang.Numbers_Multiply_O_J__Number_NoInit(na_544, na_545) }; var tmp61 bool; var tmp62 bool; tmp62 = /*line :291:1*/jrt.Long_InstanceOf(na_497); if tmp62 { tmp62 = jrt.Long_InstanceOf(na_498) }; tmp61 = tmp62; if tmp61 { var n0_564 int64 = jrt.NN(jrt.Long_Cast(na_497)).LongValue__J(); var n1_565 int64 = jrt.NN(jrt.Long_Cast(na_498)).LongValue__J(); var nr_566 int64 = n0_564 - n1_565; var tmp63 bool; var tmp64 bool; tmp64 = !(n1_565 == -9223372036854775808); if tmp64 { tmp64 = (n0_564^n1_565)&(n0_564^nr_566) >= 0 }; tmp63 = tmp64; if tmp63 { tmp1 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_566)) } else { tmp1 = lang.Numbers_Minus_O_O__Number_NoInit(na_497, na_498) } } else { var tmp65 bool; var tmp66 bool; tmp66 = jrt.Double_InstanceOf(na_497); if tmp66 { tmp66 = jrt.Double_InstanceOf(na_498) }; tmp65 = tmp66; if tmp65 { var n0_564_2 float64 = jrt.NN(jrt.Double_Cast(na_497)).DoubleValue__D(); var n1_565_2 float64 = jrt.NN(jrt.Double_Cast(na_498)).DoubleValue__D(); tmp1 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_564_2 + -n1_565_2)) } else { tmp1 = lang.Numbers_Minus_O_O__Number_NoInit(na_497, na_498) } }; return /*line :286:1*/ jrt.Date_New_J(lang.RT_LongCast_O__J_NoInit(tmp1)) }









func A_arbace_instant_read_instant_date_A_New() *A_arbace_instant_read_instant_date_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_read_instant_date_A{}; t.Ctor(); return t }
//line :296:1
func (t *A_arbace_instant_read_instant_date_A) Ctor() {}
//line :296:1
func (t *A_arbace_instant_read_instant_date_A) Invoke_O_O__O(self, cs__0 any) any {




	return lang.IFn_Cast(A_arbace_instant_A_const_50.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_instant_A_const_51.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_52.GetRawRoot__O()), cs__0)
}
func A_arbace_instant_construct_calendar_A_New() *A_arbace_instant_construct_calendar_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_construct_calendar_A{}; t.Ctor(); return t }
//line :303:1
func (t *A_arbace_instant_construct_calendar_A) Ctor() {}
//line :303:1
func (t *A_arbace_instant_construct_calendar_A) Invoke_O_O_O_O_O_O_O_O_O_O_O__O(self, years__0, months__1, days__2, hours__3, minutes__4, seconds__5, nanoseconds__6, offset_sign__7, offset_hours__8, offset_minutes__9 any) any { var G__783000075__11_ any; var tmp1 int32 = lang.RT_IntCast_O__I_NoInit(years__0); var tmp2 jrt.Number_I; var na_567 any = months__1; if





	jrt.Long_InstanceOf(na_567) { var n0_568 int64 = jrt.NN(jrt.Long_Cast(na_567)).LongValue__J(); if n0_568 == -9223372036854775808 { tmp2 = lang.Numbers_Dec_O__Number_NoInit(na_567) } else { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_568 - 1)) } } else { if jrt.Double_InstanceOf(na_567) { var n0_568_2 float64 = jrt.NN(jrt.Double_Cast(na_567)).DoubleValue__D(); tmp2 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_568_2 - 1.0)) } else { tmp2 = lang.Numbers_Dec_O__Number_NoInit(na_567) } }; G__783000075__11_ = /*line :303:1*/jrt.GregorianCalendar_New_I_I_I_I_I_I(tmp1, lang.RT_IntCast_O__I_NoInit(tmp2), lang.RT_IntCast_O__I_NoInit(days__2), lang.RT_IntCast_O__I_NoInit(hours__3), lang.RT_IntCast_O__I_NoInit(minutes__4), lang.RT_IntCast_O__I_NoInit(seconds__5)); var tmp3 jrt.Calendar_I =






	jrt.Calendar_Cast(G__783000075__11_); var tmp4 jrt.Number_I; var na_569 any = nanoseconds__6; var na_570 int64 = 1000000; if jrt.Long_InstanceOf(na_569) { var n0_571 int64 = jrt.NN(jrt.Long_Cast(na_569)).LongValue__J(); var n1_572 int64 = na_570; if n1_572 == 0 { tmp4 = lang.Numbers_Quotient_O_J__Number_NoInit(na_569, na_570) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_571 / n1_572)) } } else { tmp4 = lang.Numbers_Quotient_O_J__Number_NoInit(na_569, na_570) }; tmp3.Set_I_I__V(14, lang.RT_IntCast_O__I_NoInit(tmp4)); var tmp5 /*line :311:1*/*jrt.GregorianCalendar = jrt.GregorianCalendar_Cast(G__783000075__11_); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_45.GetRawRoot__O()); var tmp7 *jrt.String; var tmp8 bool; var na_574 any = offset_sign__7; if

	jrt.Long_InstanceOf(na_574) { var n0_575 int64 = jrt.NN(jrt.Long_Cast(na_574)).LongValue__J(); tmp8 = n0_575 < 0 } else { if jrt.Double_InstanceOf(na_574) { var n0_575_2 float64 = jrt.NN(jrt.Double_Cast(na_574)).DoubleValue__D(); tmp8 = n0_575_2 < 0.0 } else { tmp8 = lang.Numbers_IsNeg_O__Z_NoInit(na_574) } }; if tmp8 { tmp7 = Lit_2 } else { tmp7 = Lit_3 }; /*line :311:1*/jrt.NN(tmp5).SetTimeZone_TimeZone__V(jrt.TimeZone_GetTimeZone_String__TimeZone(jrt.String_Cast(tmp6.Invoke_O_O_O_O__O(Lit_1, tmp7.Ref(), offset_hours__8, offset_minutes__9)))); return G__783000075__11_ }




func A_arbace_instant_construct_timestamp_A_New() *A_arbace_instant_construct_timestamp_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_construct_timestamp_A{}; t.Ctor(); return t }
//line :316:1
func (t *A_arbace_instant_construct_timestamp_A) Ctor() {}
//line :316:1
func (t *A_arbace_instant_construct_timestamp_A) Invoke_O_O_O_O_O_O_O_O_O_O_O__O(self, years__0, months__1, days__2, hours__3, minutes__4, seconds__5, nanoseconds__6, offset_sign__7, offset_hours__8, offset_minutes__9 any) any { var G__783000077__11_ any = jrt.Timestamp_New_J(jrt.Calendar_Cast(lang.IFn_Cast(A_arbace_instant_A_const_53.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O__O(years__0, months__1, days__2, hours__3, minutes__4, seconds__5, A_arbace_instant_A_const_25, offset_sign__7, offset_hours__8, offset_minutes__9)).GetTimeInMillis__J());









	jrt.NN(jrt.Timestamp_Cast(G__783000077__11_)).SetNanos_I__V(lang.RT_IntCast_O__I_NoInit(nanoseconds__6)); return G__783000077__11_ }

func A_arbace_instant_read_instant_calendar_A_New() *A_arbace_instant_read_instant_calendar_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_read_instant_calendar_A{}; t.Ctor(); return t }
//line :328:1
func (t *A_arbace_instant_read_instant_calendar_A) Ctor() {}
//line :328:1
func (t *A_arbace_instant_read_instant_calendar_A) Invoke_O_O__O(self, cs__0 any) any {




	return lang.IFn_Cast(A_arbace_instant_A_const_50.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_instant_A_const_51.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_53.GetRawRoot__O()), cs__0)
}
func A_arbace_instant_read_instant_timestamp_A_New() *A_arbace_instant_read_instant_timestamp_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_read_instant_timestamp_A{}; t.Ctor(); return t }
//line :335:1
func (t *A_arbace_instant_read_instant_timestamp_A) Ctor() {}
//line :335:1
func (t *A_arbace_instant_read_instant_timestamp_A) Invoke_O_O__O(self, cs__0 any) any {





	return lang.IFn_Cast(A_arbace_instant_A_const_50.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_instant_A_const_51.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_54.GetRawRoot__O()), cs__0)
}
type A_arbace_instant_A struct{ jrt.Object }

var A_arbace_instant_A_const_pool *jrt.RefArray

var A_arbace_instant_A_const_0 *lang.Var

var A_arbace_instant_A_const_1 any

var A_arbace_instant_A_const_2 *lang.Var

var A_arbace_instant_A_const_3 *lang.Var

var A_arbace_instant_A_const_4 *lang.Var

var A_arbace_instant_A_const_5 any

var A_arbace_instant_A_const_6 *lang.Var

var A_arbace_instant_A_const_7 *lang.Var

var A_arbace_instant_A_const_8 *lang.Var

var A_arbace_instant_A_const_9 *lang.Var

var A_arbace_instant_A_const_10 any

var A_arbace_instant_A_const_11 any

var A_arbace_instant_A_const_12 any

var A_arbace_instant_A_const_13 any

var A_arbace_instant_A_const_14 any

var A_arbace_instant_A_const_15 *lang.Var

var A_arbace_instant_A_const_16 *lang.Var

var A_arbace_instant_A_const_17 *lang.Var

var A_arbace_instant_A_const_18 *lang.Var

var A_arbace_instant_A_const_19 *lang.Keyword

var A_arbace_instant_A_const_20 any

var A_arbace_instant_A_const_21 *lang.Var

var A_arbace_instant_A_const_22 *lang.Var

var A_arbace_instant_A_const_23 *lang.Var

var A_arbace_instant_A_const_24 any

var A_arbace_instant_A_const_25 any

var A_arbace_instant_A_const_26 any

var A_arbace_instant_A_const_27 *lang.Var

var A_arbace_instant_A_const_28 any

var A_arbace_instant_A_const_29 *lang.Var

var A_arbace_instant_A_const_30 any

var A_arbace_instant_A_const_31 any

var A_arbace_instant_A_const_32 any

var A_arbace_instant_A_const_33 any

var A_arbace_instant_A_const_34 any

var A_arbace_instant_A_const_35 *lang.Var

var A_arbace_instant_A_const_36 any

var A_arbace_instant_A_const_37 *lang.Var

var A_arbace_instant_A_const_38 *lang.Var

var A_arbace_instant_A_const_39 any

var A_arbace_instant_A_const_40 any

var A_arbace_instant_A_const_41 any

var A_arbace_instant_A_const_42 any

var A_arbace_instant_A_const_43 *lang.Var

var A_arbace_instant_A_const_44 *lang.Var

var A_arbace_instant_A_const_45 *lang.Var

var A_arbace_instant_A_const_46 *lang.Var

var A_arbace_instant_A_const_47 *lang.Var

var A_arbace_instant_A_const_48 *lang.Var

var A_arbace_instant_A_const_49 *lang.Var

var A_arbace_instant_A_const_50 *lang.Var

var A_arbace_instant_A_const_51 *lang.Var

var A_arbace_instant_A_const_52 *lang.Var

var A_arbace_instant_A_const_53 *lang.Var

var A_arbace_instant_A_const_54 *lang.Var

var A_arbace_instant_A_init jrt.ClassInit

func A_arbace_instant_A_Init() { if !A_arbace_instant_A_init.Done() { A_arbace_instant_A_init.Run(A_arbace_instant_A_clinit) } }

func A_arbace_instant_A_clinit() { A_arbace_instant_A_clinit_p0(); A_arbace_instant_A_clinit_p1(); A_arbace_instant_A_clinit_p2(); A_arbace_instant_A_clinit_p3(); A_arbace_instant_A_clinit_p4() }

func A_arbace_instant_A_clinit_p0() { jrt.StartCheck(); A_arbace_instant_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 63); A_arbace_instant_A_const_0 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[8]); A_arbace_instant_A_const_1 = A_arbace_instant_A_const_pool.A[9]; A_arbace_instant_A_const_2 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[10]); A_arbace_instant_A_const_3 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[11]); A_arbace_instant_A_const_4 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[12]); A_arbace_instant_A_const_5 = A_arbace_instant_A_const_pool.A[13]; A_arbace_instant_A_const_6 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[14]); A_arbace_instant_A_const_7 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[15]); A_arbace_instant_A_const_8 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[16]); A_arbace_instant_A_const_9 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[17]); A_arbace_instant_A_const_10 = A_arbace_instant_A_const_pool.A[18]; A_arbace_instant_A_const_11 = A_arbace_instant_A_const_pool.A[19] }

func A_arbace_instant_A_clinit_p1() { A_arbace_instant_A_const_12 = A_arbace_instant_A_const_pool.A[20]; A_arbace_instant_A_const_13 = A_arbace_instant_A_const_pool.A[21]; A_arbace_instant_A_const_14 = A_arbace_instant_A_const_pool.A[22]; A_arbace_instant_A_const_15 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[23]); A_arbace_instant_A_const_16 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[24]); A_arbace_instant_A_const_17 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[25]); A_arbace_instant_A_const_18 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[26]); A_arbace_instant_A_const_19 = lang.Keyword_Cast(A_arbace_instant_A_const_pool.A[27]); A_arbace_instant_A_const_20 = A_arbace_instant_A_const_pool.A[28]; A_arbace_instant_A_const_21 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[29]); A_arbace_instant_A_const_22 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[30]); A_arbace_instant_A_const_23 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[31]); A_arbace_instant_A_const_24 = A_arbace_instant_A_const_pool.A[32] }

func A_arbace_instant_A_clinit_p2() { A_arbace_instant_A_const_25 = A_arbace_instant_A_const_pool.A[33]; A_arbace_instant_A_const_26 = A_arbace_instant_A_const_pool.A[34]; A_arbace_instant_A_const_27 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[35]); A_arbace_instant_A_const_28 = A_arbace_instant_A_const_pool.A[36]; A_arbace_instant_A_const_29 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[37]); A_arbace_instant_A_const_30 = A_arbace_instant_A_const_pool.A[38]; A_arbace_instant_A_const_31 = A_arbace_instant_A_const_pool.A[39]; A_arbace_instant_A_const_32 = A_arbace_instant_A_const_pool.A[40]; A_arbace_instant_A_const_33 = A_arbace_instant_A_const_pool.A[41]; A_arbace_instant_A_const_34 = A_arbace_instant_A_const_pool.A[42]; A_arbace_instant_A_const_35 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[43]); A_arbace_instant_A_const_36 = A_arbace_instant_A_const_pool.A[44]; A_arbace_instant_A_const_37 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[45]); A_arbace_instant_A_const_38 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[46]) }

func A_arbace_instant_A_clinit_p3() { A_arbace_instant_A_const_39 = A_arbace_instant_A_const_pool.A[47]; A_arbace_instant_A_const_40 = A_arbace_instant_A_const_pool.A[48]; A_arbace_instant_A_const_41 = A_arbace_instant_A_const_pool.A[49]; A_arbace_instant_A_const_42 = A_arbace_instant_A_const_pool.A[50]; A_arbace_instant_A_const_43 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[51]); A_arbace_instant_A_const_44 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[52]); A_arbace_instant_A_const_45 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[53]); A_arbace_instant_A_const_46 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[54]); A_arbace_instant_A_const_47 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[55]); A_arbace_instant_A_const_48 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[56]); A_arbace_instant_A_const_49 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[57]); A_arbace_instant_A_const_50 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[58]); A_arbace_instant_A_const_51 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[59]) }

func A_arbace_instant_A_clinit_p4() { A_arbace_instant_A_const_52 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[60]); A_arbace_instant_A_const_53 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[61]); A_arbace_instant_A_const_54 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[62]) }

func A_arbace_instant_A_New() *A_arbace_instant_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_A) Ctor() {}

func (t *A_arbace_instant_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_A) GetClass__Class() *jrt.Class { return A_arbace_instant_A_class }

func (t *A_arbace_instant_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_A); return ok }

func A_arbace_instant_A_Cast(x any) *A_arbace_instant_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_A_class)) }; return v }



type A_arbace_instant_civil__GT_days_A struct{ j2g_header uint64 }

var A_arbace_instant_civil__GT_days_A_fn_class *jrt.Class



type A_arbace_instant_construct_calendar_A struct{ j2g_header uint64 }

var A_arbace_instant_construct_calendar_A_fn_class *jrt.Class



type A_arbace_instant_construct_date_A struct{ j2g_header uint64 }

var A_arbace_instant_construct_date_A_fn_class *jrt.Class



type A_arbace_instant_construct_timestamp_A struct{ j2g_header uint64 }

var A_arbace_instant_construct_timestamp_A_fn_class *jrt.Class



type A_arbace_instant_days__GT_civil_A struct{ j2g_header uint64 }

var A_arbace_instant_days__GT_civil_A_fn_class *jrt.Class



type A_arbace_instant_divisible_QMARK__A struct{ j2g_header uint64 }

var A_arbace_instant_divisible_QMARK__A_fn_class *jrt.Class



type A_arbace_instant_eval783000002_A struct{ jrt.Object }

func A_arbace_instant_eval783000002_A_New() *A_arbace_instant_eval783000002_A { t := &A_arbace_instant_eval783000002_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000002_A) Ctor() {}

func (t *A_arbace_instant_eval783000002_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000002_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000002_A_class }

func (t *A_arbace_instant_eval783000002_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000002_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000002_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000002_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000002_A); return ok }

func A_arbace_instant_eval783000002_A_Cast(x any) *A_arbace_instant_eval783000002_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000002_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000002_A_class)) }; return v }



type A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_fn_class *jrt.Class



type A_arbace_instant_eval783000006_A struct{ jrt.Object }

func A_arbace_instant_eval783000006_A_New() *A_arbace_instant_eval783000006_A { t := &A_arbace_instant_eval783000006_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000006_A) Ctor() {}

func (t *A_arbace_instant_eval783000006_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000006_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000006_A_class }

func (t *A_arbace_instant_eval783000006_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000006_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000006_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000006_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000006_A); return ok }

func A_arbace_instant_eval783000006_A_Cast(x any) *A_arbace_instant_eval783000006_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000006_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000006_A_class)) }; return v }



type A_arbace_instant_eval783000006_fn__783000007_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000006_fn__783000007_A_fn_class *jrt.Class



type A_arbace_instant_eval783000044_A struct{ jrt.Object }

func A_arbace_instant_eval783000044_A_New() *A_arbace_instant_eval783000044_A { t := &A_arbace_instant_eval783000044_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000044_A) Ctor() {}

func (t *A_arbace_instant_eval783000044_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000044_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000044_A_class }

func (t *A_arbace_instant_eval783000044_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000044_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000044_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000044_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000044_A); return ok }

func A_arbace_instant_eval783000044_A_Cast(x any) *A_arbace_instant_eval783000044_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000044_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000044_A_class)) }; return v }



type A_arbace_instant_eval783000044_fn__783000045_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000044_fn__783000045_A_fn_class *jrt.Class



type A_arbace_instant_eval783000048_A struct{ jrt.Object }

func A_arbace_instant_eval783000048_A_New() *A_arbace_instant_eval783000048_A { t := &A_arbace_instant_eval783000048_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000048_A) Ctor() {}

func (t *A_arbace_instant_eval783000048_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000048_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000048_A_class }

func (t *A_arbace_instant_eval783000048_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000048_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000048_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000048_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000048_A); return ok }

func A_arbace_instant_eval783000048_A_Cast(x any) *A_arbace_instant_eval783000048_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000048_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000048_A_class)) }; return v }



type A_arbace_instant_eval783000048_fn__783000049_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000048_fn__783000049_A_fn_class *jrt.Class



type A_arbace_instant_eval783000053_A struct{ jrt.Object }

func A_arbace_instant_eval783000053_A_New() *A_arbace_instant_eval783000053_A { t := &A_arbace_instant_eval783000053_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000053_A) Ctor() {}

func (t *A_arbace_instant_eval783000053_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000053_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000053_A_class }

func (t *A_arbace_instant_eval783000053_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000053_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000053_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000053_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000053_A); return ok }

func A_arbace_instant_eval783000053_A_Cast(x any) *A_arbace_instant_eval783000053_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000053_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000053_A_class)) }; return v }



type A_arbace_instant_eval783000053_fn__783000054_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000053_fn__783000054_A_fn_class *jrt.Class



type A_arbace_instant_eval783000057_A struct{ jrt.Object }

func A_arbace_instant_eval783000057_A_New() *A_arbace_instant_eval783000057_A { t := &A_arbace_instant_eval783000057_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000057_A) Ctor() {}

func (t *A_arbace_instant_eval783000057_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000057_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000057_A_class }

func (t *A_arbace_instant_eval783000057_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000057_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000057_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000057_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000057_A); return ok }

func A_arbace_instant_eval783000057_A_Cast(x any) *A_arbace_instant_eval783000057_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000057_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000057_A_class)) }; return v }



type A_arbace_instant_eval783000057_fn__783000058_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000057_fn__783000058_A_fn_class *jrt.Class



type A_arbace_instant_eval783000065_A struct{ jrt.Object }

func A_arbace_instant_eval783000065_A_New() *A_arbace_instant_eval783000065_A { t := &A_arbace_instant_eval783000065_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000065_A) Ctor() {}

func (t *A_arbace_instant_eval783000065_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000065_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000065_A_class }

func (t *A_arbace_instant_eval783000065_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000065_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000065_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000065_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000065_A); return ok }

func A_arbace_instant_eval783000065_A_Cast(x any) *A_arbace_instant_eval783000065_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000065_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000065_A_class)) }; return v }



type A_arbace_instant_eval783000065_fn__783000066_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000065_fn__783000066_A_fn_class *jrt.Class



type A_arbace_instant_eval783000069_A struct{ jrt.Object }

func A_arbace_instant_eval783000069_A_New() *A_arbace_instant_eval783000069_A { t := &A_arbace_instant_eval783000069_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000069_A) Ctor() {}

func (t *A_arbace_instant_eval783000069_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000069_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000069_A_class }

func (t *A_arbace_instant_eval783000069_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000069_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000069_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000069_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000069_A); return ok }

func A_arbace_instant_eval783000069_A_Cast(x any) *A_arbace_instant_eval783000069_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000069_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000069_A_class)) }; return v }



type A_arbace_instant_eval783000069_fn__783000070_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000069_fn__783000070_A_fn_class *jrt.Class



type A_arbace_instant_fail_A struct{ j2g_header uint64 }

var A_arbace_instant_fail_A_fn_class *jrt.Class



type A_arbace_instant_fn__783000031_A struct{ j2g_header uint64 }

var A_arbace_instant_fn__783000031_A_fn_class *jrt.Class



type A_arbace_instant_fn__783000031_fn__783000032_A struct{ j2g_header uint64; F_dim_norm, F_dim_leap any }

var A_arbace_instant_fn__783000031_fn__783000032_A_fn_class *jrt.Class



type A_arbace_instant_indivisible_QMARK__A struct{ j2g_header uint64 }

var A_arbace_instant_indivisible_QMARK__A_fn_class *jrt.Class



type A_arbace_instant_leap_year_QMARK__A struct{ j2g_header uint64 }

var A_arbace_instant_leap_year_QMARK__A_fn_class *jrt.Class



type A_arbace_instant_parse_int_A struct{ j2g_header uint64 }

var A_arbace_instant_parse_int_A_fn_class *jrt.Class



type A_arbace_instant_parse_timestamp_A struct{ j2g_header uint64 }

var A_arbace_instant_parse_timestamp_A_fn_class *jrt.Class



type A_arbace_instant_print_calendar_A struct{ j2g_header uint64 }

var A_arbace_instant_print_calendar_A_fn_class *jrt.Class



type A_arbace_instant_print_date_A struct{ j2g_header uint64 }

var A_arbace_instant_print_date_A_fn_class *jrt.Class



type A_arbace_instant_print_timestamp_A struct{ j2g_header uint64 }

var A_arbace_instant_print_timestamp_A_fn_class *jrt.Class



type A_arbace_instant_read_instant_calendar_A struct{ j2g_header uint64 }

var A_arbace_instant_read_instant_calendar_A_fn_class *jrt.Class



type A_arbace_instant_read_instant_date_A struct{ j2g_header uint64 }

var A_arbace_instant_read_instant_date_A_fn_class *jrt.Class



type A_arbace_instant_read_instant_timestamp_A struct{ j2g_header uint64 }

var A_arbace_instant_read_instant_timestamp_A_fn_class *jrt.Class



type A_arbace_instant_validated_A struct{ j2g_header uint64 }

var A_arbace_instant_validated_A_fn_class *jrt.Class



type A_arbace_instant_validated_fn__783000035_A struct{ j2g_header uint64; F_new_instance any }

var A_arbace_instant_validated_fn__783000035_A_fn_class *jrt.Class



type A_arbace_instant_verify_A struct{ j2g_header uint64 }

var A_arbace_instant_verify_A_fn_class *jrt.Class



type A_arbace_instant_zero_fill_right_A struct{ j2g_header uint64 }

var A_arbace_instant_zero_fill_right_A_fn_class *jrt.Class
