//line aot_arbace_instant.ae:1
package aot_arbace_instant

import (
	"arbace/jrt"
	"arbace/lang"
)














func A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_New() *A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A) Ctor() {}
//line :21:1
func (t *A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_instant_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_1); { var tmp4 *lang.Var; lang.RT_Init(); tmp4 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp4).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_4)); var tmp5 *lang.Var; lang.RT_Init(); tmp5 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp5).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_5)); var tmp6 *lang.Var; lang.RT_Init(); tmp6 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp6).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_6)); var tmp7 *lang.Var; lang.RT_Init(); tmp7 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp7).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_7)); var tmp8 *lang.Var; lang.RT_Init(); tmp8 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp8).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_8)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp9 != nil { panic(tmp9) }; return tmp3 }
//line :21:1
func A_arbace_instant_eval783000006_fn__783000007_A_New() *A_arbace_instant_eval783000006_fn__783000007_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000006_fn__783000007_A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_instant_eval783000006_fn__783000007_A) Ctor() {}
//line :21:1
func (t *A_arbace_instant_eval783000006_fn__783000007_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_instant_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_instant_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_6), A_arbace_instant_A_const_4.GetRawRoot__O(), A_arbace_instant_A_const_5) }








func A_arbace_instant_fail_A_New() *A_arbace_instant_fail_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_fail_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_instant_fail_A) Ctor() {}
//line :30:1
func (t *A_arbace_instant_fail_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, msg__2 any) any { return lang.IFn_Cast(A_arbace_instant_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_instant_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_10), lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_instant_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_instant_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_11), lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(msg__2)))))) }



func A_arbace_instant_verify_A_New() *A_arbace_instant_verify_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_verify_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_instant_verify_A) Ctor() {}
//line :34:1
func (t *A_arbace_instant_verify_A) Invoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, test__2, msg__3 any) any { return lang.IFn_Cast(A_arbace_instant_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_instant_A_const_8.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_12), lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(test__2), lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_instant_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_instant_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_13), lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(msg__3)))))) }
//line :34:1
func (t *A_arbace_instant_verify_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, test__2 any) any { return lang.IFn_Cast(A_arbace_instant_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_instant_A_const_8.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_14), lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(test__2), lang.IFn_Cast(A_arbace_instant_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_28, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_instant_A_const_15.GetRawRoot__O()).Invoke_O__O(test__2))).Ref()))) }



func A_arbace_instant_divisible_QMARK__A_New() *A_arbace_instant_divisible_QMARK__A { A_arbace_instant_A_Init(); t := &A_arbace_instant_divisible_QMARK__A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_instant_divisible_QMARK__A) Ctor() {}
//line :38:1
func (t *A_arbace_instant_divisible_QMARK__A) Invoke_O_O_O__O(self, num__0, div__1 any) any {

	return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_O__Z(lang.IFn_Cast(A_arbace_instant_A_const_16.GetRawRoot__O()).Invoke_O_O__O(num__0, div__1))).Ref()
}
func A_arbace_instant_indivisible_QMARK__A_New() *A_arbace_instant_indivisible_QMARK__A { A_arbace_instant_A_Init(); t := &A_arbace_instant_indivisible_QMARK__A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_instant_indivisible_QMARK__A) Ctor() {}
//line :42:1
func (t *A_arbace_instant_indivisible_QMARK__A) Invoke_O_O_O__O(self, num__0, div__1 any) any {

	return lang.IFn_Cast(A_arbace_instant_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_instant_A_const_18.GetRawRoot__O()).Invoke_O_O__O(num__0, div__1))
}



func A_arbace_instant_parse_int_A_New() *A_arbace_instant_parse_int_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_parse_int_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_instant_parse_int_A) Ctor() {}
//line :49:1
func (t *A_arbace_instant_parse_int_A) Invoke_O_O__O(self, s__0 any) any {
	return jrt.Long_ValueOf_J__Long(jrt.Long_ParseLong_String__J(jrt.String_Cast(s__0))).Ref()
}
func A_arbace_instant_zero_fill_right_A_New() *A_arbace_instant_zero_fill_right_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_zero_fill_right_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_instant_zero_fill_right_A) Ctor() {}
//line :52:1
func (t *A_arbace_instant_zero_fill_right_A) Invoke_O_O_O__O(self, s__0, width__1 any) any {
	if lang.Util_Equiv_O_J__Z(width__1, int64(lang.RT_Count_O__I(s__0))) { return s__0 } else { if lang.Numbers_Lt_O_J__Z(width__1, int64(lang.RT_Count_O__I(s__0))) {
		return jrt.NN(jrt.String_Cast(s__0)).Substring_I_I__String(lang.RT_IntCast_J__I(0), lang.RT_IntCast_O__I(width__1)).Ref() } else {
//line :53:1
			if A_arbace_instant_A_const_19 != nil { var b__3 any = jrt.StringBuilder_New_String(jrt.String_Cast(s__0)); L1: for {


				if lang.Numbers_Lt_J_O__Z(int64(jrt.NN(jrt.StringBuilder_Cast(b__3)).Length__I()), width__1) {
					b__3 = jrt.NN(jrt.StringBuilder_Cast(b__3)).Append_O__StringBuilder(A_arbace_instant_A_const_20).Ref(); continue L1 } else {
						return jrt.NN(jrt.StringBuilder_Cast(b__3)).ToString__String().Ref() } } } else {
//line :53:1
							return nil } } }
//line :52:1
	panic("j2g: unreachable")
}









func A_arbace_instant_parse_timestamp_A_New() *A_arbace_instant_parse_timestamp_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_parse_timestamp_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_instant_parse_timestamp_A) Ctor() {}
//line :63:1
func (t *A_arbace_instant_parse_timestamp_A) Invoke_O_O_O__O(self, new_instant__0, cs__1 any) any { var temp__1927000408__auto____3 any = lang.IFn_Cast(A_arbace_instant_A_const_21.GetRawRoot__O()).Invoke_O_O__O(A_arbace_instant_A_const_22.GetRawRoot__O(), cs__1); if



















































	jrt.J2g_Truth(temp__1927000408__auto____3) { var vec__783000026__4 any = temp__1927000408__auto____3; var ___5 any = lang.RT_Nth_O_I_O__O(vec__783000026__4, lang.RT_IntCast_J__I(0), nil); var years__6 any = lang.RT_Nth_O_I_O__O(vec__783000026__4, lang.RT_IntCast_J__I(1), nil); var months__7 any = lang.RT_Nth_O_I_O__O(vec__783000026__4, lang.RT_IntCast_J__I(2), nil); var days__8 any = lang.RT_Nth_O_I_O__O(vec__783000026__4, lang.RT_IntCast_J__I(3), nil); var hours__9 any = lang.RT_Nth_O_I_O__O(vec__783000026__4, lang.RT_IntCast_J__I(4), nil); var minutes__10 any = lang.RT_Nth_O_I_O__O(vec__783000026__4, lang.RT_IntCast_J__I(5), nil); var seconds__11 any = lang.RT_Nth_O_I_O__O(vec__783000026__4, lang.RT_IntCast_J__I(6), nil); var fraction__12 any = lang.RT_Nth_O_I_O__O(vec__783000026__4, lang.RT_IntCast_J__I(7), nil); var offset_sign__13 any = lang.RT_Nth_O_I_O__O(vec__783000026__4, lang.RT_IntCast_J__I(8), nil); var offset_hours__14 any = lang.RT_Nth_O_I_O__O(vec__783000026__4, lang.RT_IntCast_J__I(9), nil); var offset_minutes__15 any = lang.RT_Nth_O_I_O__O(vec__783000026__4, lang.RT_IntCast_J__I(10), nil); var tmp1 lang.IFn = lang.IFn_Cast(new_instant__0); var tmp2 any = lang.IFn_Cast(A_arbace_instant_A_const_23.GetRawRoot__O()).Invoke_O__O(years__6); var tmp3 any; _ = ___5




		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_17.GetRawRoot__O()).Invoke_O__O(months__7)) { tmp3 = A_arbace_instant_A_const_24 } else { tmp3 = lang.IFn_Cast(A_arbace_instant_A_const_23.GetRawRoot__O()).Invoke_O__O(months__7) }
//line :118:1
		var tmp4 any = tmp3; var tmp5 any


		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_17.GetRawRoot__O()).Invoke_O__O(days__8)) { tmp5 = A_arbace_instant_A_const_24 } else { tmp5 = lang.IFn_Cast(A_arbace_instant_A_const_23.GetRawRoot__O()).Invoke_O__O(days__8) }
//line :118:1
		var tmp6 any = tmp5; var tmp7 any



		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_17.GetRawRoot__O()).Invoke_O__O(hours__9)) { tmp7 = A_arbace_instant_A_const_25 } else { tmp7 = lang.IFn_Cast(A_arbace_instant_A_const_23.GetRawRoot__O()).Invoke_O__O(hours__9) }
//line :118:1
		var tmp8 any = tmp7; var tmp9 any




		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_17.GetRawRoot__O()).Invoke_O__O(minutes__10)) { tmp9 = A_arbace_instant_A_const_25 } else { tmp9 = lang.IFn_Cast(A_arbace_instant_A_const_23.GetRawRoot__O()).Invoke_O__O(minutes__10) }
//line :118:1
		var tmp10 any = tmp9; var tmp11 any





		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_17.GetRawRoot__O()).Invoke_O__O(seconds__11)) { tmp11 = A_arbace_instant_A_const_25 } else { tmp11 = lang.IFn_Cast(A_arbace_instant_A_const_23.GetRawRoot__O()).Invoke_O__O(seconds__11) }
//line :118:1
		var tmp12 any = tmp11; var tmp13 any






		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_17.GetRawRoot__O()).Invoke_O__O(fraction__12)) { tmp13 = A_arbace_instant_A_const_25 } else { tmp13 = lang.IFn_Cast(A_arbace_instant_A_const_23.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_instant_A_const_27.GetRawRoot__O()).Invoke_O_O__O(fraction__12, A_arbace_instant_A_const_28)) }
//line :118:1
		var tmp14 any = tmp13; var tmp15 any







		if lang.Util_Equiv_O_O__Z(Lit_2, offset_sign__13) { tmp15 = A_arbace_instant_A_const_26 } else { if lang.Util_Equiv_O_O__Z(Lit_3, offset_sign__13) { tmp15 = A_arbace_instant_A_const_24 } else { if A_arbace_instant_A_const_19 != nil { tmp15 = A_arbace_instant_A_const_25 } else { tmp15 = nil } } }
//line :118:1
		var tmp16 any = tmp15; var tmp17 any










		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_17.GetRawRoot__O()).Invoke_O__O(offset_hours__14)) { tmp17 = A_arbace_instant_A_const_25 } else { tmp17 = lang.IFn_Cast(A_arbace_instant_A_const_23.GetRawRoot__O()).Invoke_O__O(offset_hours__14) }
//line :118:1
		var tmp18 any = tmp17; var tmp19 any











		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_17.GetRawRoot__O()).Invoke_O__O(offset_minutes__15)) { tmp19 = A_arbace_instant_A_const_25 } else { tmp19 = lang.IFn_Cast(A_arbace_instant_A_const_23.GetRawRoot__O()).Invoke_O__O(offset_minutes__15) }
//line :118:1
		return tmp1.Invoke_O_O_O_O_O_O_O_O_O_O__O(tmp2, tmp4, tmp6, tmp8, tmp10, tmp12, tmp14, tmp16, tmp18, tmp19) } else {
//line :115:1
			panic(jrt.Thrown(jrt.RuntimeException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, cs__1))))) } }




















func A_arbace_instant_leap_year_QMARK__A_New() *A_arbace_instant_leap_year_QMARK__A { A_arbace_instant_A_Init(); t := &A_arbace_instant_leap_year_QMARK__A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_instant_leap_year_QMARK__A) Ctor() {}
//line :136:1
func (t *A_arbace_instant_leap_year_QMARK__A) Invoke_O_O__O(self, year__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_instant_A_const_18.GetRawRoot__O()).Invoke_O_O__O(year__0, A_arbace_instant_A_const_30); if

	jrt.J2g_Truth(and__1927000168__auto____2) { var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_instant_A_const_29.GetRawRoot__O()).Invoke_O_O__O(year__0, A_arbace_instant_A_const_31)
		if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else {
			return lang.IFn_Cast(A_arbace_instant_A_const_18.GetRawRoot__O()).Invoke_O_O__O(year__0, A_arbace_instant_A_const_32) } } else {
//line :138:1
				return and__1927000168__auto____2 } }




func A_arbace_instant_fn__783000031_A_New() *A_arbace_instant_fn__783000031_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_fn__783000031_A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_instant_fn__783000031_A) Ctor() {}
//line :143:1
func (t *A_arbace_instant_fn__783000031_A) Invoke_O__O(self any) any { var dim_norm__1 any = A_arbace_instant_A_const_33; var dim_leap__2 any = A_arbace_instant_A_const_34; var tmp1 any = A_arbace_instant_fn__783000031_fn__783000032_A_New_O_O(dim_norm__1, dim_leap__2); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_instant_fn__783000031_fn__783000032_A_fn_class; if

	fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_9, false); A_arbace_instant_fn__783000031_fn__783000032_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :145:1
func A_arbace_instant_fn__783000031_fn__783000032_A_New_O_O(p0, p1 any) *A_arbace_instant_fn__783000031_fn__783000032_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_fn__783000031_fn__783000032_A{}; t.Ctor_O_O(p0, p1); return t }
//line :145:1
func (t *A_arbace_instant_fn__783000031_fn__783000032_A) Ctor_O_O(c__dim_norm, c__dim_leap any) { t.F_dim_norm = c__dim_norm; t.F_dim_leap = c__dim_leap }
//line :145:1
func (t *A_arbace_instant_fn__783000031_fn__783000032_A) Invoke_O_O_O__O(self, month__1, leap_year_QMARK___2 any) any {
	var tmp1 any; if jrt.J2g_Truth(leap_year_QMARK___2) { tmp1 = t.F_dim_leap } else { tmp1 = t.F_dim_norm }; return lang.IFn_Cast(tmp1).Invoke_O__O(month__1)
}
func A_arbace_instant_validated_A_New() *A_arbace_instant_validated_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_validated_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_instant_validated_A) Ctor() {}
//line :148:1
func (t *A_arbace_instant_validated_A) Invoke_O_O__O(self, new_instance__0 any) any {





	var tmp1 any = A_arbace_instant_validated_fn__783000035_A_New_O(new_instance__0); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_instant_validated_fn__783000035_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); A_arbace_instant_validated_fn__783000035_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :154:1
func A_arbace_instant_validated_fn__783000035_A_New_O(p0 any) *A_arbace_instant_validated_fn__783000035_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_validated_fn__783000035_A{}; t.Ctor_O(p0); return t }
//line :154:1
func (t *A_arbace_instant_validated_fn__783000035_A) Ctor_O(c__new_instance any) { t.F_new_instance = c__new_instance }
//line :154:1
func (t *A_arbace_instant_validated_fn__783000035_A) Invoke_O_O_O_O_O_O_O_O_O_O_O__O(self, years__1, months__2, days__3, hours__4, minutes__5, seconds__6, nanoseconds__7, offset_sign__8, offset_hours__9, offset_minutes__10 any) any {

	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_24, months__2, A_arbace_instant_A_const_36)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_19))) }
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()); var tmp2 any = A_arbace_instant_A_const_24; if jrt.J2g_Truth(tmp1.Invoke_O_O_O__O(tmp2, days__3, lang.IFn_Cast(A_arbace_instant_A_const_37.GetRawRoot__O()).Invoke_O_O__O(months__2, lang.IFn_Cast(A_arbace_instant_A_const_38.GetRawRoot__O()).Invoke_O__O(years__1)))) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_20))) }
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_25, hours__4, A_arbace_instant_A_const_39)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_21))) }
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_25, minutes__5, A_arbace_instant_A_const_40)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_22))) }
	var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()); var tmp4 any = A_arbace_instant_A_const_25; var tmp5 any; if lang.Util_Equiv_O_J__Z(minutes__5, 59) { tmp5 = A_arbace_instant_A_const_41 } else { tmp5 = A_arbace_instant_A_const_40 }; if jrt.J2g_Truth(tmp3.Invoke_O_O_O__O(tmp4, seconds__6, tmp5)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_23))) }
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_25, nanoseconds__7, A_arbace_instant_A_const_42)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_24))) }
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_26, offset_sign__8, A_arbace_instant_A_const_24)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_25))) }
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_25, offset_hours__9, A_arbace_instant_A_const_39)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_26))) }
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_instant_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_instant_A_const_25, offset_minutes__10, A_arbace_instant_A_const_40)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_27))) }
	return lang.IFn_Cast(t.F_new_instance).Invoke_O_O_O_O_O_O_O_O_O_O__O(years__1, months__2, days__3, hours__4, minutes__5, seconds__6, nanoseconds__7, offset_sign__8, offset_hours__9, offset_minutes__10)
}











func A_arbace_instant_days__GT_civil_A_New() *A_arbace_instant_days__GT_civil_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_days__GT_civil_A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_instant_days__GT_civil_A) Ctor() {}
//line :178:1
func (t *A_arbace_instant_days__GT_civil_A) Invoke_O_O__O(self, z__0 any) any {



	if lang.Numbers_Gte_O_O__Z(z__0, A_arbace_instant_A_const_43.GetRawRoot__O()) { var z__2 any = lang.Numbers_Add_O_J__Number(z__0, 719468); var era__3 any; var tmp1 any

		if lang.Numbers_Gte_O_J__Z(z__2, 0) { tmp1 = z__2 } else { tmp1 = lang.Numbers_Minus_O_J__Number(z__2, 146096) }; era__3 = lang.Numbers_Quotient_O_J__Number(tmp1, 146097)
//line :182:1
		var doe__4 any = lang.Numbers_Minus_O_O__Number(z__2, lang.Numbers_Multiply_O_J__Number(era__3, 146097)); var yoe__5 any = lang.Numbers_Quotient_O_J__Number(lang.Numbers_Minus_O_O__Number(lang.Numbers_Minus_O_O__Number(lang.Numbers_Minus_O_O__Number(doe__4, lang.Numbers_Quotient_O_J__Number(doe__4, 1460)), lang.Numbers_Minus_O__Number(lang.Numbers_Quotient_O_J__Number(doe__4, 36524))), lang.Numbers_Quotient_O_J__Number(doe__4, 146096)), 365); var y__6 any = lang.Numbers_Add_O_O__Number(yoe__5, lang.Numbers_Multiply_O_J__Number(era__3, 400)); var doy__7 any = lang.Numbers_Minus_O_O__Number(doe__4, lang.Numbers_Minus_O_O__Number(lang.Numbers_Add_O_O__Number(lang.Numbers_Multiply_J_O__Number(365, yoe__5), lang.Numbers_Quotient_O_J__Number(yoe__5, 4)), lang.Numbers_Quotient_O_J__Number(yoe__5, 100))); var mp__8 any = lang.Numbers_Quotient_O_J__Number(lang.Numbers_Add_O_J__Number(lang.Numbers_Multiply_J_O__Number(5, doy__7), 2), 153); var d__9 any = lang.Numbers_Inc_O__Number(lang.Numbers_Minus_O_O__Number(doy__7, lang.Numbers_Quotient_O_J__Number(lang.Numbers_Add_O_J__Number(lang.Numbers_Multiply_J_O__Number(153, mp__8), 2), 5))); var m__10 any








		if lang.Numbers_Lt_O_J__Z(mp__8, 10) { m__10 = lang.Numbers_Add_O_J__Number(mp__8, 3) } else { m__10 = lang.Numbers_Minus_O_J__Number(mp__8, 9) }
//line :182:1
		var tmp2 any









		if lang.Numbers_Lte_O_J__Z(m__10, 2) { tmp2 = lang.Numbers_Inc_O__Number(y__6) } else { tmp2 = y__6 }
//line :182:1
		return lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, m__10, d__9) } else { var c__2 any = lang.Numbers_Add_O_J__Number(lang.Numbers_Add_O_J__Number(z__0, 2440588), 32082); var d__3 int64 = jrt.Math_FloorDiv_J_J__J(lang.RT_LongCast_O__J(lang.Numbers_Add_O_J__Number(lang.Numbers_Multiply_J_O__Number(4, c__2), 3)), 1461); var e__4 any = lang.Numbers_Minus_O_J__Number(c__2, jrt.Math_FloorDiv_J_J__J(lang.RT_LongCast_J__J(lang.Numbers_Multiply_J_J__J(1461, d__3)), 4)); var m__5 any = lang.Numbers_Quotient_O_J__Number(lang.Numbers_Add_O_J__Number(lang.Numbers_Multiply_J_O__Number(5, e__4), 2), 153); return lang.Tuple_Create_O_O_O__IPersistentVector(lang.Numbers_Add_J_O__Number(lang.Numbers_Minus_J_J__J(d__3, 4800), lang.Numbers_Quotient_O_J__Number(m__5, 10)), lang.Numbers_Minus_O_O__Number(lang.Numbers_Add_O_J__Number(m__5, 3), lang.Numbers_Multiply_J_O__Number(12, lang.Numbers_Quotient_O_J__Number(m__5, 10))), lang.Numbers_Inc_O__Number(lang.Numbers_Minus_O_O__Number(e__4, lang.Numbers_Quotient_O_J__Number(lang.Numbers_Add_O_J__Number(lang.Numbers_Multiply_J_O__Number(153, m__5), 2), 5))))
		}
}
















func A_arbace_instant_civil__GT_days_A_New() *A_arbace_instant_civil__GT_days_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_civil__GT_days_A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_instant_civil__GT_days_A) Ctor() {}
//line :201:1
func (t *A_arbace_instant_civil__GT_days_A) Invoke_O_O_O_O__O(self, y__0, m__1, d__2 any) any { var g__4 any; var y__4 any; if



	lang.Numbers_Lte_O_J__Z(m__1, 2) { y__4 = lang.Numbers_Dec_O__Number(y__0) } else { y__4 = y__0 }; var era__5 any; var tmp1 any; if
	lang.Numbers_Gte_O_J__Z(y__4, 0) { tmp1 = y__4 } else { tmp1 = lang.Numbers_Minus_O_J__Number(y__4, 399) }; era__5 = lang.Numbers_Quotient_O_J__Number(tmp1, 400); var yoe__6 any = /*line :201:1*/lang.Numbers_Minus_O_O__Number(y__4, lang.Numbers_Multiply_O_J__Number(era__5, 400)); var doy__7 any; var tmp2 jrt.Number_I; if






	lang.Numbers_Gt_O_J__Z(m__1, 2) { tmp2 = lang.Numbers_Minus_O_J__Number(m__1, 3) } else { tmp2 = lang.Numbers_Add_O_J__Number(m__1, 9) }; doy__7 = lang.Numbers_Add_O_O__Number(lang.Numbers_Quotient_O_J__Number(lang.Numbers_Add_O_J__Number(lang.Numbers_Multiply_J_O__Number(153, tmp2), 2), 5), lang.Numbers_Dec_O__Number(d__2)); var doe__8 any = /*line :201:1*/lang.Numbers_Minus_O_O__Number(lang.Numbers_Add_O_O__Number(lang.Numbers_Add_O_O__Number(lang.Numbers_Multiply_O_J__Number(yoe__6, 365), lang.Numbers_Quotient_O_J__Number(yoe__6, 4)), doy__7), lang.Numbers_Quotient_O_J__Number(yoe__6, 100)); g__4 =








	lang.Numbers_Add_O_J__Number(lang.Numbers_Add_O_O__Number(lang.Numbers_Multiply_O_J__Number(era__5, 146097), doe__8), -719468); if
	lang.Numbers_Gte_O_O__Z(g__4, A_arbace_instant_A_const_43.GetRawRoot__O()) { return g__4 } else { var a__5 any = lang.Numbers_Quotient_O_J__Number(lang.Numbers_Minus_J_O__Number(14, m__1), 12); var yy__6 any = lang.Numbers_Minus_O_O__Number(lang.Numbers_Add_O_J__Number(y__0, 4800), a__5); var mm__7 any = lang.Numbers_Minus_O_J__Number(lang.Numbers_Add_O_O__Number(m__1, lang.Numbers_Multiply_J_O__Number(12, a__5)), 3)




		return lang.Numbers_Minus_O_J__Number(lang.Numbers_Add_O_J__Number(lang.Numbers_Add_O_J__Number(lang.Numbers_Add_O_O__Number(lang.Numbers_Add_O_O__Number(d__2, lang.Numbers_Quotient_O_J__Number(lang.Numbers_Add_O_J__Number(lang.Numbers_Multiply_J_O__Number(153, mm__7), 2), 5)), lang.Numbers_Multiply_J_O__Number(365, yy__6)), jrt.Math_FloorDiv_J_J__J(lang.RT_LongCast_O__J(yy__6), 4)), -32083), 2440588) } }

func A_arbace_instant_print_date_A_New() *A_arbace_instant_print_date_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_print_date_A{}; t.Ctor(); return t }
//line :218:1
func (t *A_arbace_instant_print_date_A) Ctor() {}
//line :218:1
func (t *A_arbace_instant_print_date_A) Invoke_O_O_O__O(self, d__0, w__1 any) any { var ms__3 int64 = jrt.Date_Cast(d__0).GetTime__J(); var days__4 int64 = jrt.Math_FloorDiv_J_J__J(ms__3, 86400000); var msd__5 int64 = jrt.Math_FloorMod_J_J__J(ms__3, 86400000); var vec__783000040__6 any = lang.IFn_Cast(A_arbace_instant_A_const_44.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(days__4).Ref()); var y__7 any = lang.RT_Nth_O_I_O__O(vec__783000040__6, lang.RT_IntCast_J__I(0), nil); var m__8 any = lang.RT_Nth_O_I_O__O(vec__783000040__6, lang.RT_IntCast_J__I(1), nil); var dd__9 any = lang.RT_Nth_O_I_O__O(vec__783000040__6, lang.RT_IntCast_J__I(2), nil);






	jrt.Writer_Cast(w__1).Write_String__V(Lit_12); var tmp1 jrt.Writer_I =
	jrt.Writer_Cast(w__1); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_45.GetRawRoot__O()); var tmp3 any; if
	lang.Numbers_Lte_O_J__Z(y__7, 0) { tmp3 = lang.Numbers_Minus_J_O__Number(1, y__7) } else { tmp3 = y__7 }; /*line :226:1*/tmp1.Write_String__V(jrt.String_Cast(tmp2.Invoke_O_O_O_O_O_O_O_O__O(Lit_15, tmp3, m__8, dd__9, jrt.Long_ValueOf_J__Long(lang.Numbers_Quotient_J_J__J(msd__5, 3600000)).Ref(), jrt.Long_ValueOf_J__Long(lang.Numbers_Remainder_J_J__J(lang.Numbers_Quotient_J_J__J(msd__5, 60000), 60)).Ref(), jrt.Long_ValueOf_J__Long(lang.Numbers_Remainder_J_J__J(lang.Numbers_Quotient_J_J__J(msd__5, 1000), 60)).Ref(), jrt.Long_ValueOf_J__Long(lang.Numbers_Remainder_J_J__J(msd__5, 1000)).Ref())));


	jrt.Writer_Cast(w__1).Write_String__V(Lit_14); return nil }

func A_arbace_instant_eval783000044_fn__783000045_A_New() *A_arbace_instant_eval783000044_fn__783000045_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000044_fn__783000045_A{}; t.Ctor(); return t }
//line :231:1
func (t *A_arbace_instant_eval783000044_fn__783000045_A) Ctor() {}
//line :231:1
func (t *A_arbace_instant_eval783000044_fn__783000045_A) Invoke_O_O_O__O(self, d__1, w__2 any) any {

	return lang.IFn_Cast(A_arbace_instant_A_const_46.GetRawRoot__O()).Invoke_O_O__O(d__1, w__2)
}
func A_arbace_instant_eval783000048_fn__783000049_A_New() *A_arbace_instant_eval783000048_fn__783000049_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000048_fn__783000049_A{}; t.Ctor(); return t }
//line :235:1
func (t *A_arbace_instant_eval783000048_fn__783000049_A) Ctor() {}
//line :235:1
func (t *A_arbace_instant_eval783000048_fn__783000049_A) Invoke_O_O_O__O(self, d__1, w__2 any) any {

	return lang.IFn_Cast(A_arbace_instant_A_const_46.GetRawRoot__O()).Invoke_O_O__O(d__1, w__2)
}
func A_arbace_instant_print_calendar_A_New() *A_arbace_instant_print_calendar_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_print_calendar_A{}; t.Ctor(); return t }
//line :239:1
func (t *A_arbace_instant_print_calendar_A) Ctor() {}
//line :239:1
func (t *A_arbace_instant_print_calendar_A) Invoke_O_O_O__O(self, c__0, w__1 any) any { var calstr__3 any = lang.IFn_Cast(A_arbace_instant_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_11, c__0); var offset_minutes__4 int64 = lang.Numbers_Minus_J_J__J(int64(jrt.NN(jrt.String_Cast(calstr__3)).Length__I()), 2);





	jrt.Writer_Cast(w__1).Write_String__V(Lit_12);
	jrt.Writer_Cast(w__1).Write_String_I_I__V(jrt.String_Cast(calstr__3), lang.RT_IntCast_J__I(0), lang.RT_IntCast_J__I(offset_minutes__4));
	jrt.Writer_Cast(w__1).Write_String__V(Lit_13);
	jrt.Writer_Cast(w__1).Write_String_I_I__V(jrt.String_Cast(calstr__3), lang.RT_IntCast_J__I(offset_minutes__4), lang.RT_IntCast_J__I(2));
	jrt.Writer_Cast(w__1).Write_String__V(Lit_14); return nil }

func A_arbace_instant_eval783000053_fn__783000054_A_New() *A_arbace_instant_eval783000053_fn__783000054_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000053_fn__783000054_A{}; t.Ctor(); return t }
//line :251:1
func (t *A_arbace_instant_eval783000053_fn__783000054_A) Ctor() {}
//line :251:1
func (t *A_arbace_instant_eval783000053_fn__783000054_A) Invoke_O_O_O__O(self, c__1, w__2 any) any {

	return lang.IFn_Cast(A_arbace_instant_A_const_47.GetRawRoot__O()).Invoke_O_O__O(c__1, w__2)
}
func A_arbace_instant_eval783000057_fn__783000058_A_New() *A_arbace_instant_eval783000057_fn__783000058_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000057_fn__783000058_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_instant_eval783000057_fn__783000058_A) Ctor() {}
//line :255:1
func (t *A_arbace_instant_eval783000057_fn__783000058_A) Invoke_O_O_O__O(self, c__1, w__2 any) any {

	return lang.IFn_Cast(A_arbace_instant_A_const_47.GetRawRoot__O()).Invoke_O_O__O(c__1, w__2)
}
func A_arbace_instant_print_timestamp_A_New() *A_arbace_instant_print_timestamp_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_print_timestamp_A{}; t.Ctor(); return t }
//line :259:1
func (t *A_arbace_instant_print_timestamp_A) Ctor() {}
//line :259:1
func (t *A_arbace_instant_print_timestamp_A) Invoke_O_O_O__O(self, ts__0, w__1 any) any { var ms__3 int64 = jrt.NN(jrt.Timestamp_Cast(ts__0)).GetTime__J(); var days__4 int64 = jrt.Math_FloorDiv_J_J__J(ms__3, 86400000); var msd__5 int64 = jrt.Math_FloorMod_J_J__J(ms__3, 86400000); var vec__783000061__6 any = lang.IFn_Cast(A_arbace_instant_A_const_44.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(days__4).Ref()); var y__7 any = lang.RT_Nth_O_I_O__O(vec__783000061__6, lang.RT_IntCast_J__I(0), nil); var m__8 any = lang.RT_Nth_O_I_O__O(vec__783000061__6, lang.RT_IntCast_J__I(1), nil); var dd__9 any = lang.RT_Nth_O_I_O__O(vec__783000061__6, lang.RT_IntCast_J__I(2), nil);






	jrt.Writer_Cast(w__1).Write_String__V(Lit_12); var tmp1 jrt.Writer_I =
	jrt.Writer_Cast(w__1); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_45.GetRawRoot__O()); var tmp3 any; if
	lang.Numbers_Lte_O_J__Z(y__7, 0) { tmp3 = lang.Numbers_Minus_J_O__Number(1, y__7) } else { tmp3 = y__7 }; /*line :267:1*/tmp1.Write_String__V(jrt.String_Cast(tmp2.Invoke_O_O_O_O_O_O_O__O(Lit_16, tmp3, m__8, dd__9, jrt.Long_ValueOf_J__Long(lang.Numbers_Quotient_J_J__J(msd__5, 3600000)).Ref(), jrt.Long_ValueOf_J__Long(lang.Numbers_Remainder_J_J__J(lang.Numbers_Quotient_J_J__J(msd__5, 60000), 60)).Ref(), jrt.Long_ValueOf_J__Long(lang.Numbers_Remainder_J_J__J(lang.Numbers_Quotient_J_J__J(msd__5, 1000), 60)).Ref())));




	jrt.Writer_Cast(w__1).Write_String__V(jrt.String_Cast(lang.IFn_Cast(A_arbace_instant_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_17, jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.Timestamp_Cast(ts__0)).GetNanos__I()).Ref())));
	jrt.Writer_Cast(w__1).Write_String__V(Lit_14); return nil }

func A_arbace_instant_eval783000065_fn__783000066_A_New() *A_arbace_instant_eval783000065_fn__783000066_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000065_fn__783000066_A{}; t.Ctor(); return t }
//line :275:1
func (t *A_arbace_instant_eval783000065_fn__783000066_A) Ctor() {}
//line :275:1
func (t *A_arbace_instant_eval783000065_fn__783000066_A) Invoke_O_O_O__O(self, ts__1, w__2 any) any {

	return lang.IFn_Cast(A_arbace_instant_A_const_48.GetRawRoot__O()).Invoke_O_O__O(ts__1, w__2)
}
func A_arbace_instant_eval783000069_fn__783000070_A_New() *A_arbace_instant_eval783000069_fn__783000070_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_eval783000069_fn__783000070_A{}; t.Ctor(); return t }
//line :279:1
func (t *A_arbace_instant_eval783000069_fn__783000070_A) Ctor() {}
//line :279:1
func (t *A_arbace_instant_eval783000069_fn__783000070_A) Invoke_O_O_O__O(self, ts__1, w__2 any) any {

	return lang.IFn_Cast(A_arbace_instant_A_const_48.GetRawRoot__O()).Invoke_O_O__O(ts__1, w__2)
}



func A_arbace_instant_construct_date_A_New() *A_arbace_instant_construct_date_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_construct_date_A{}; t.Ctor(); return t }
//line :286:1
func (t *A_arbace_instant_construct_date_A) Ctor() {}
//line :286:1
func (t *A_arbace_instant_construct_date_A) Invoke_O_O_O_O_O_O_O_O_O_O_O__O(self, years__0, months__1, days__2, hours__3, minutes__4, seconds__5, nanoseconds__6, offset_sign__7, offset_hours__8, offset_minutes__9 any) any { return jrt.Date_New_J(lang.RT_LongCast_O__J(lang.Numbers_Minus_O_O__Number(lang.Numbers_Add_O_O__Number(lang.Numbers_Add_O_O__Number(lang.Numbers_Add_O_O__Number(lang.Numbers_Add_O_O__Number(lang.Numbers_Multiply_O_J__Number(lang.IFn_Cast(A_arbace_instant_A_const_49.GetRawRoot__O()).Invoke_O_O_O__O(years__0, months__1, days__2), 86400000), lang.Numbers_Multiply_O_J__Number(hours__3, 3600000)), lang.Numbers_Multiply_O_J__Number(minutes__4, 60000)), lang.Numbers_Multiply_O_J__Number(seconds__5, 1000)), lang.Numbers_Quotient_O_J__Number(nanoseconds__6, 1000000)), lang.Numbers_Multiply_O_J__Number(lang.Numbers_Multiply_O_O__Number(offset_sign__7, lang.Numbers_Add_O_O__Number(lang.Numbers_Multiply_O_J__Number(offset_hours__8, 60), offset_minutes__9)), 60000)))) }









func A_arbace_instant_read_instant_date_A_New() *A_arbace_instant_read_instant_date_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_read_instant_date_A{}; t.Ctor(); return t }
//line :296:1
func (t *A_arbace_instant_read_instant_date_A) Ctor() {}
//line :296:1
func (t *A_arbace_instant_read_instant_date_A) Invoke_O_O__O(self, cs__0 any) any {




	return lang.IFn_Cast(A_arbace_instant_A_const_50.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_instant_A_const_51.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_52.GetRawRoot__O()), cs__0)
}
func A_arbace_instant_construct_calendar_A_New() *A_arbace_instant_construct_calendar_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_construct_calendar_A{}; t.Ctor(); return t }
//line :303:1
func (t *A_arbace_instant_construct_calendar_A) Ctor() {}
//line :303:1
func (t *A_arbace_instant_construct_calendar_A) Invoke_O_O_O_O_O_O_O_O_O_O_O__O(self, years__0, months__1, days__2, hours__3, minutes__4, seconds__5, nanoseconds__6, offset_sign__7, offset_hours__8, offset_minutes__9 any) any { var G__783000075__11_ any = jrt.GregorianCalendar_New_I_I_I_I_I_I(lang.RT_IntCast_O__I(years__0), lang.RT_IntCast_O__I(lang.Numbers_Dec_O__Number(months__1)), lang.RT_IntCast_O__I(days__2), lang.RT_IntCast_O__I(hours__3), lang.RT_IntCast_O__I(minutes__4), lang.RT_IntCast_O__I(seconds__5));






	jrt.Calendar_Cast(G__783000075__11_).Set_I_I__V(14, lang.RT_IntCast_O__I(lang.Numbers_Quotient_O_J__Number(nanoseconds__6, 1000000))); var tmp1 /*line :311:1*/*jrt.GregorianCalendar = jrt.GregorianCalendar_Cast(G__783000075__11_); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_instant_A_const_45.GetRawRoot__O()); var tmp3 *jrt.String; if

	lang.Numbers_IsNeg_O__Z(offset_sign__7) { tmp3 = Lit_2 } else { tmp3 = Lit_3 }; /*line :311:1*/jrt.NN(tmp1).SetTimeZone_TimeZone__V(jrt.TimeZone_GetTimeZone_String__TimeZone(jrt.String_Cast(tmp2.Invoke_O_O_O_O__O(Lit_1, tmp3.Ref(), offset_hours__8, offset_minutes__9)))); return G__783000075__11_ }




func A_arbace_instant_construct_timestamp_A_New() *A_arbace_instant_construct_timestamp_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_construct_timestamp_A{}; t.Ctor(); return t }
//line :316:1
func (t *A_arbace_instant_construct_timestamp_A) Ctor() {}
//line :316:1
func (t *A_arbace_instant_construct_timestamp_A) Invoke_O_O_O_O_O_O_O_O_O_O_O__O(self, years__0, months__1, days__2, hours__3, minutes__4, seconds__5, nanoseconds__6, offset_sign__7, offset_hours__8, offset_minutes__9 any) any { var G__783000077__11_ any = jrt.Timestamp_New_J(jrt.Calendar_Cast(lang.IFn_Cast(A_arbace_instant_A_const_53.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O__O(years__0, months__1, days__2, hours__3, minutes__4, seconds__5, A_arbace_instant_A_const_25, offset_sign__7, offset_hours__8, offset_minutes__9)).GetTimeInMillis__J());









	jrt.NN(jrt.Timestamp_Cast(G__783000077__11_)).SetNanos_I__V(lang.RT_IntCast_O__I(nanoseconds__6)); return G__783000077__11_ }

func A_arbace_instant_read_instant_calendar_A_New() *A_arbace_instant_read_instant_calendar_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_read_instant_calendar_A{}; t.Ctor(); return t }
//line :328:1
func (t *A_arbace_instant_read_instant_calendar_A) Ctor() {}
//line :328:1
func (t *A_arbace_instant_read_instant_calendar_A) Invoke_O_O__O(self, cs__0 any) any {




	return lang.IFn_Cast(A_arbace_instant_A_const_50.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_instant_A_const_51.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_53.GetRawRoot__O()), cs__0)
}
func A_arbace_instant_read_instant_timestamp_A_New() *A_arbace_instant_read_instant_timestamp_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_read_instant_timestamp_A{}; t.Ctor(); return t }
//line :335:1
func (t *A_arbace_instant_read_instant_timestamp_A) Ctor() {}
//line :335:1
func (t *A_arbace_instant_read_instant_timestamp_A) Invoke_O_O__O(self, cs__0 any) any {





	return lang.IFn_Cast(A_arbace_instant_A_const_50.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_instant_A_const_51.GetRawRoot__O()).Invoke_O__O(A_arbace_instant_A_const_54.GetRawRoot__O()), cs__0)
}
type A_arbace_instant_A struct{ jrt.Object }

var A_arbace_instant_A_const_pool *jrt.RefArray

var A_arbace_instant_A_const_0 *lang.Var

var A_arbace_instant_A_const_1 any

var A_arbace_instant_A_const_2 *lang.Var

var A_arbace_instant_A_const_3 *lang.Var

var A_arbace_instant_A_const_4 *lang.Var

var A_arbace_instant_A_const_5 any

var A_arbace_instant_A_const_6 *lang.Var

var A_arbace_instant_A_const_7 *lang.Var

var A_arbace_instant_A_const_8 *lang.Var

var A_arbace_instant_A_const_9 *lang.Var

var A_arbace_instant_A_const_10 any

var A_arbace_instant_A_const_11 any

var A_arbace_instant_A_const_12 any

var A_arbace_instant_A_const_13 any

var A_arbace_instant_A_const_14 any

var A_arbace_instant_A_const_15 *lang.Var

var A_arbace_instant_A_const_16 *lang.Var

var A_arbace_instant_A_const_17 *lang.Var

var A_arbace_instant_A_const_18 *lang.Var

var A_arbace_instant_A_const_19 *lang.Keyword

var A_arbace_instant_A_const_20 any

var A_arbace_instant_A_const_21 *lang.Var

var A_arbace_instant_A_const_22 *lang.Var

var A_arbace_instant_A_const_23 *lang.Var

var A_arbace_instant_A_const_24 any

var A_arbace_instant_A_const_25 any

var A_arbace_instant_A_const_26 any

var A_arbace_instant_A_const_27 *lang.Var

var A_arbace_instant_A_const_28 any

var A_arbace_instant_A_const_29 *lang.Var

var A_arbace_instant_A_const_30 any

var A_arbace_instant_A_const_31 any

var A_arbace_instant_A_const_32 any

var A_arbace_instant_A_const_33 any

var A_arbace_instant_A_const_34 any

var A_arbace_instant_A_const_35 *lang.Var

var A_arbace_instant_A_const_36 any

var A_arbace_instant_A_const_37 *lang.Var

var A_arbace_instant_A_const_38 *lang.Var

var A_arbace_instant_A_const_39 any

var A_arbace_instant_A_const_40 any

var A_arbace_instant_A_const_41 any

var A_arbace_instant_A_const_42 any

var A_arbace_instant_A_const_43 *lang.Var

var A_arbace_instant_A_const_44 *lang.Var

var A_arbace_instant_A_const_45 *lang.Var

var A_arbace_instant_A_const_46 *lang.Var

var A_arbace_instant_A_const_47 *lang.Var

var A_arbace_instant_A_const_48 *lang.Var

var A_arbace_instant_A_const_49 *lang.Var

var A_arbace_instant_A_const_50 *lang.Var

var A_arbace_instant_A_const_51 *lang.Var

var A_arbace_instant_A_const_52 *lang.Var

var A_arbace_instant_A_const_53 *lang.Var

var A_arbace_instant_A_const_54 *lang.Var

var A_arbace_instant_A_init jrt.ClassInit

func A_arbace_instant_A_Init() { if !A_arbace_instant_A_init.Done() { A_arbace_instant_A_init.Run(A_arbace_instant_A_clinit) } }

func A_arbace_instant_A_clinit() { A_arbace_instant_A_clinit_p0(); A_arbace_instant_A_clinit_p1(); A_arbace_instant_A_clinit_p2(); A_arbace_instant_A_clinit_p3(); A_arbace_instant_A_clinit_p4() }

func A_arbace_instant_A_clinit_p0() { A_arbace_instant_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 63); A_arbace_instant_A_const_0 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[8]); A_arbace_instant_A_const_1 = A_arbace_instant_A_const_pool.A[9]; A_arbace_instant_A_const_2 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[10]); A_arbace_instant_A_const_3 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[11]); A_arbace_instant_A_const_4 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[12]); A_arbace_instant_A_const_5 = A_arbace_instant_A_const_pool.A[13]; A_arbace_instant_A_const_6 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[14]); A_arbace_instant_A_const_7 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[15]); A_arbace_instant_A_const_8 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[16]); A_arbace_instant_A_const_9 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[17]); A_arbace_instant_A_const_10 = A_arbace_instant_A_const_pool.A[18]; A_arbace_instant_A_const_11 = A_arbace_instant_A_const_pool.A[19] }

func A_arbace_instant_A_clinit_p1() { A_arbace_instant_A_const_12 = A_arbace_instant_A_const_pool.A[20]; A_arbace_instant_A_const_13 = A_arbace_instant_A_const_pool.A[21]; A_arbace_instant_A_const_14 = A_arbace_instant_A_const_pool.A[22]; A_arbace_instant_A_const_15 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[23]); A_arbace_instant_A_const_16 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[24]); A_arbace_instant_A_const_17 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[25]); A_arbace_instant_A_const_18 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[26]); A_arbace_instant_A_const_19 = lang.Keyword_Cast(A_arbace_instant_A_const_pool.A[27]); A_arbace_instant_A_const_20 = A_arbace_instant_A_const_pool.A[28]; A_arbace_instant_A_const_21 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[29]); A_arbace_instant_A_const_22 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[30]); A_arbace_instant_A_const_23 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[31]); A_arbace_instant_A_const_24 = A_arbace_instant_A_const_pool.A[32] }

func A_arbace_instant_A_clinit_p2() { A_arbace_instant_A_const_25 = A_arbace_instant_A_const_pool.A[33]; A_arbace_instant_A_const_26 = A_arbace_instant_A_const_pool.A[34]; A_arbace_instant_A_const_27 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[35]); A_arbace_instant_A_const_28 = A_arbace_instant_A_const_pool.A[36]; A_arbace_instant_A_const_29 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[37]); A_arbace_instant_A_const_30 = A_arbace_instant_A_const_pool.A[38]; A_arbace_instant_A_const_31 = A_arbace_instant_A_const_pool.A[39]; A_arbace_instant_A_const_32 = A_arbace_instant_A_const_pool.A[40]; A_arbace_instant_A_const_33 = A_arbace_instant_A_const_pool.A[41]; A_arbace_instant_A_const_34 = A_arbace_instant_A_const_pool.A[42]; A_arbace_instant_A_const_35 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[43]); A_arbace_instant_A_const_36 = A_arbace_instant_A_const_pool.A[44]; A_arbace_instant_A_const_37 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[45]); A_arbace_instant_A_const_38 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[46]) }

func A_arbace_instant_A_clinit_p3() { A_arbace_instant_A_const_39 = A_arbace_instant_A_const_pool.A[47]; A_arbace_instant_A_const_40 = A_arbace_instant_A_const_pool.A[48]; A_arbace_instant_A_const_41 = A_arbace_instant_A_const_pool.A[49]; A_arbace_instant_A_const_42 = A_arbace_instant_A_const_pool.A[50]; A_arbace_instant_A_const_43 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[51]); A_arbace_instant_A_const_44 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[52]); A_arbace_instant_A_const_45 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[53]); A_arbace_instant_A_const_46 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[54]); A_arbace_instant_A_const_47 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[55]); A_arbace_instant_A_const_48 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[56]); A_arbace_instant_A_const_49 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[57]); A_arbace_instant_A_const_50 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[58]); A_arbace_instant_A_const_51 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[59]) }

func A_arbace_instant_A_clinit_p4() { A_arbace_instant_A_const_52 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[60]); A_arbace_instant_A_const_53 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[61]); A_arbace_instant_A_const_54 = lang.Var_Cast(A_arbace_instant_A_const_pool.A[62]) }

func A_arbace_instant_A_New() *A_arbace_instant_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_A) Ctor() {}

func (t *A_arbace_instant_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_A) GetClass__Class() *jrt.Class { return A_arbace_instant_A_class }

func (t *A_arbace_instant_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_A); return ok }

func A_arbace_instant_A_Cast(x any) *A_arbace_instant_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_A_class)) }; return v }



type A_arbace_instant_civil__GT_days_A struct{ j2g_header uint64 }

var A_arbace_instant_civil__GT_days_A_fn_class *jrt.Class



type A_arbace_instant_construct_calendar_A struct{ j2g_header uint64 }

var A_arbace_instant_construct_calendar_A_fn_class *jrt.Class



type A_arbace_instant_construct_date_A struct{ j2g_header uint64 }

var A_arbace_instant_construct_date_A_fn_class *jrt.Class



type A_arbace_instant_construct_timestamp_A struct{ j2g_header uint64 }

var A_arbace_instant_construct_timestamp_A_fn_class *jrt.Class



type A_arbace_instant_days__GT_civil_A struct{ j2g_header uint64 }

var A_arbace_instant_days__GT_civil_A_fn_class *jrt.Class



type A_arbace_instant_divisible_QMARK__A struct{ j2g_header uint64 }

var A_arbace_instant_divisible_QMARK__A_fn_class *jrt.Class



type A_arbace_instant_eval783000002_A struct{ jrt.Object }

func A_arbace_instant_eval783000002_A_New() *A_arbace_instant_eval783000002_A { t := &A_arbace_instant_eval783000002_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000002_A) Ctor() {}

func (t *A_arbace_instant_eval783000002_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000002_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000002_A_class }

func (t *A_arbace_instant_eval783000002_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000002_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000002_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000002_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000002_A); return ok }

func A_arbace_instant_eval783000002_A_Cast(x any) *A_arbace_instant_eval783000002_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000002_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000002_A_class)) }; return v }



type A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_fn_class *jrt.Class



type A_arbace_instant_eval783000006_A struct{ jrt.Object }

func A_arbace_instant_eval783000006_A_New() *A_arbace_instant_eval783000006_A { t := &A_arbace_instant_eval783000006_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000006_A) Ctor() {}

func (t *A_arbace_instant_eval783000006_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000006_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000006_A_class }

func (t *A_arbace_instant_eval783000006_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000006_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000006_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000006_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000006_A); return ok }

func A_arbace_instant_eval783000006_A_Cast(x any) *A_arbace_instant_eval783000006_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000006_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000006_A_class)) }; return v }



type A_arbace_instant_eval783000006_fn__783000007_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000006_fn__783000007_A_fn_class *jrt.Class



type A_arbace_instant_eval783000044_A struct{ jrt.Object }

func A_arbace_instant_eval783000044_A_New() *A_arbace_instant_eval783000044_A { t := &A_arbace_instant_eval783000044_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000044_A) Ctor() {}

func (t *A_arbace_instant_eval783000044_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000044_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000044_A_class }

func (t *A_arbace_instant_eval783000044_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000044_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000044_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000044_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000044_A); return ok }

func A_arbace_instant_eval783000044_A_Cast(x any) *A_arbace_instant_eval783000044_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000044_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000044_A_class)) }; return v }



type A_arbace_instant_eval783000044_fn__783000045_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000044_fn__783000045_A_fn_class *jrt.Class



type A_arbace_instant_eval783000048_A struct{ jrt.Object }

func A_arbace_instant_eval783000048_A_New() *A_arbace_instant_eval783000048_A { t := &A_arbace_instant_eval783000048_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000048_A) Ctor() {}

func (t *A_arbace_instant_eval783000048_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000048_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000048_A_class }

func (t *A_arbace_instant_eval783000048_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000048_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000048_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000048_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000048_A); return ok }

func A_arbace_instant_eval783000048_A_Cast(x any) *A_arbace_instant_eval783000048_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000048_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000048_A_class)) }; return v }



type A_arbace_instant_eval783000048_fn__783000049_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000048_fn__783000049_A_fn_class *jrt.Class



type A_arbace_instant_eval783000053_A struct{ jrt.Object }

func A_arbace_instant_eval783000053_A_New() *A_arbace_instant_eval783000053_A { t := &A_arbace_instant_eval783000053_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000053_A) Ctor() {}

func (t *A_arbace_instant_eval783000053_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000053_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000053_A_class }

func (t *A_arbace_instant_eval783000053_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000053_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000053_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000053_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000053_A); return ok }

func A_arbace_instant_eval783000053_A_Cast(x any) *A_arbace_instant_eval783000053_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000053_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000053_A_class)) }; return v }



type A_arbace_instant_eval783000053_fn__783000054_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000053_fn__783000054_A_fn_class *jrt.Class



type A_arbace_instant_eval783000057_A struct{ jrt.Object }

func A_arbace_instant_eval783000057_A_New() *A_arbace_instant_eval783000057_A { t := &A_arbace_instant_eval783000057_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000057_A) Ctor() {}

func (t *A_arbace_instant_eval783000057_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000057_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000057_A_class }

func (t *A_arbace_instant_eval783000057_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000057_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000057_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000057_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000057_A); return ok }

func A_arbace_instant_eval783000057_A_Cast(x any) *A_arbace_instant_eval783000057_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000057_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000057_A_class)) }; return v }



type A_arbace_instant_eval783000057_fn__783000058_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000057_fn__783000058_A_fn_class *jrt.Class



type A_arbace_instant_eval783000065_A struct{ jrt.Object }

func A_arbace_instant_eval783000065_A_New() *A_arbace_instant_eval783000065_A { t := &A_arbace_instant_eval783000065_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000065_A) Ctor() {}

func (t *A_arbace_instant_eval783000065_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000065_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000065_A_class }

func (t *A_arbace_instant_eval783000065_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000065_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000065_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000065_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000065_A); return ok }

func A_arbace_instant_eval783000065_A_Cast(x any) *A_arbace_instant_eval783000065_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000065_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000065_A_class)) }; return v }



type A_arbace_instant_eval783000065_fn__783000066_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000065_fn__783000066_A_fn_class *jrt.Class



type A_arbace_instant_eval783000069_A struct{ jrt.Object }

func A_arbace_instant_eval783000069_A_New() *A_arbace_instant_eval783000069_A { t := &A_arbace_instant_eval783000069_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000069_A) Ctor() {}

func (t *A_arbace_instant_eval783000069_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000069_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000069_A_class }

func (t *A_arbace_instant_eval783000069_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000069_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000069_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000069_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000069_A); return ok }

func A_arbace_instant_eval783000069_A_Cast(x any) *A_arbace_instant_eval783000069_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000069_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000069_A_class)) }; return v }



type A_arbace_instant_eval783000069_fn__783000070_A struct{ j2g_header uint64 }

var A_arbace_instant_eval783000069_fn__783000070_A_fn_class *jrt.Class



type A_arbace_instant_fail_A struct{ j2g_header uint64 }

var A_arbace_instant_fail_A_fn_class *jrt.Class



type A_arbace_instant_fn__783000031_A struct{ j2g_header uint64 }

var A_arbace_instant_fn__783000031_A_fn_class *jrt.Class



type A_arbace_instant_fn__783000031_fn__783000032_A struct{ j2g_header uint64; F_dim_norm, F_dim_leap any }

var A_arbace_instant_fn__783000031_fn__783000032_A_fn_class *jrt.Class



type A_arbace_instant_indivisible_QMARK__A struct{ j2g_header uint64 }

var A_arbace_instant_indivisible_QMARK__A_fn_class *jrt.Class



type A_arbace_instant_leap_year_QMARK__A struct{ j2g_header uint64 }

var A_arbace_instant_leap_year_QMARK__A_fn_class *jrt.Class



type A_arbace_instant_parse_int_A struct{ j2g_header uint64 }

var A_arbace_instant_parse_int_A_fn_class *jrt.Class



type A_arbace_instant_parse_timestamp_A struct{ j2g_header uint64 }

var A_arbace_instant_parse_timestamp_A_fn_class *jrt.Class



type A_arbace_instant_print_calendar_A struct{ j2g_header uint64 }

var A_arbace_instant_print_calendar_A_fn_class *jrt.Class



type A_arbace_instant_print_date_A struct{ j2g_header uint64 }

var A_arbace_instant_print_date_A_fn_class *jrt.Class



type A_arbace_instant_print_timestamp_A struct{ j2g_header uint64 }

var A_arbace_instant_print_timestamp_A_fn_class *jrt.Class



type A_arbace_instant_read_instant_calendar_A struct{ j2g_header uint64 }

var A_arbace_instant_read_instant_calendar_A_fn_class *jrt.Class



type A_arbace_instant_read_instant_date_A struct{ j2g_header uint64 }

var A_arbace_instant_read_instant_date_A_fn_class *jrt.Class



type A_arbace_instant_read_instant_timestamp_A struct{ j2g_header uint64 }

var A_arbace_instant_read_instant_timestamp_A_fn_class *jrt.Class



type A_arbace_instant_validated_A struct{ j2g_header uint64 }

var A_arbace_instant_validated_A_fn_class *jrt.Class



type A_arbace_instant_validated_fn__783000035_A struct{ j2g_header uint64; F_new_instance any }

var A_arbace_instant_validated_fn__783000035_A_fn_class *jrt.Class



type A_arbace_instant_verify_A struct{ j2g_header uint64 }

var A_arbace_instant_verify_A_fn_class *jrt.Class



type A_arbace_instant_zero_fill_right_A struct{ j2g_header uint64 }

var A_arbace_instant_zero_fill_right_A_fn_class *jrt.Class
