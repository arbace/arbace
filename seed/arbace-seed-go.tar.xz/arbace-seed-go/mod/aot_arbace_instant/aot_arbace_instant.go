//line aot_arbace_instant.ae:1
package aot_arbace_instant

import (
	"arbace/jrt"
	"arbace/lang"
)














func A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_New() *A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A { A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_Init(); t := &A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A) Ctor() {}
//line :21:1
func (t *A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_instant_A_Init(); tmp4 = A_arbace_instant_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_instant_A_Init(); tmp6 = A_arbace_instant_A_const_1; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; lang.RT_Init(); tmp7 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp7).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_50)); var tmp8 *lang.Var; lang.RT_Init(); tmp8 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp8).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_51)); var tmp9 *lang.Var; lang.RT_Init(); tmp9 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp9).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_52)); var tmp10 *lang.Var; lang.RT_Init(); tmp10 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp10).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_53)); var tmp11 *lang.Var; lang.RT_Init(); tmp11 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp11).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_54)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp12 != nil { panic(tmp12) }; return tmp3 }
//line :21:1
func A_arbace_instant_eval783000006_fn__783000007_A_New() *A_arbace_instant_eval783000006_fn__783000007_A { A_arbace_instant_eval783000006_fn__783000007_A_Init(); t := &A_arbace_instant_eval783000006_fn__783000007_A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_instant_eval783000006_fn__783000007_A) Ctor() {}
//line :21:1
func (t *A_arbace_instant_eval783000006_fn__783000007_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_instant_A_Init(); tmp1 = A_arbace_instant_A_const_2; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_instant_A_Init(); tmp3 = A_arbace_instant_A_const_3; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_instant_A_Init(); tmp5 = A_arbace_instant_A_const_6; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_instant_A_Init(); tmp7 = A_arbace_instant_A_const_4; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_instant_A_Init(); tmp9 = A_arbace_instant_A_const_5; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }








func A_arbace_instant_fail_A_New() *A_arbace_instant_fail_A { A_arbace_instant_fail_A_Init(); t := &A_arbace_instant_fail_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_instant_fail_A) Ctor() {}
//line :30:1
func (t *A_arbace_instant_fail_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, msg__2 any) any { var tmp1 *lang.Var; A_arbace_instant_A_Init(); tmp1 = A_arbace_instant_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_instant_A_Init(); tmp3 = A_arbace_instant_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_instant_A_Init(); tmp5 = A_arbace_instant_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_instant_A_Init(); tmp7 = A_arbace_instant_A_const_10; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_instant_A_Init(); tmp9 = A_arbace_instant_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_instant_A_Init(); tmp11 = A_arbace_instant_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_instant_A_Init(); tmp13 = A_arbace_instant_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_instant_A_Init(); tmp15 = A_arbace_instant_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_instant_A_Init(); tmp17 = A_arbace_instant_A_const_11; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_instant_A_Init(); tmp19 = A_arbace_instant_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(msg__2)))))) }



func A_arbace_instant_verify_A_New() *A_arbace_instant_verify_A { A_arbace_instant_verify_A_Init(); t := &A_arbace_instant_verify_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_instant_verify_A) Ctor() {}
//line :34:1
func (t *A_arbace_instant_verify_A) Invoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, test__2, msg__3 any) any { var tmp1 *lang.Var; A_arbace_instant_A_Init(); tmp1 = A_arbace_instant_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_instant_A_Init(); tmp3 = A_arbace_instant_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_instant_A_Init(); tmp5 = A_arbace_instant_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_instant_A_Init(); tmp7 = A_arbace_instant_A_const_12; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_instant_A_Init(); tmp9 = A_arbace_instant_A_const_9; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(test__2); var tmp11 *lang.Var; A_arbace_instant_A_Init(); tmp11 = A_arbace_instant_A_const_9; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_instant_A_Init(); tmp13 = A_arbace_instant_A_const_7; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_instant_A_Init(); tmp15 = A_arbace_instant_A_const_8; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_instant_A_Init(); tmp17 = A_arbace_instant_A_const_9; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any; A_arbace_instant_A_Init(); tmp19 = A_arbace_instant_A_const_13; var tmp20 any = tmp18.Invoke_O__O(tmp19); var tmp21 *lang.Var; A_arbace_instant_A_Init(); tmp21 = A_arbace_instant_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp10, tmp12.Invoke_O__O(tmp14.Invoke_O__O(tmp16.Invoke_O_O__O(tmp20, lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(msg__3)))))) }
//line :34:1
func (t *A_arbace_instant_verify_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, test__2 any) any { var tmp1 *lang.Var; A_arbace_instant_A_Init(); tmp1 = A_arbace_instant_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_instant_A_Init(); tmp3 = A_arbace_instant_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_instant_A_Init(); tmp5 = A_arbace_instant_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_instant_A_Init(); tmp7 = A_arbace_instant_A_const_14; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_instant_A_Init(); tmp9 = A_arbace_instant_A_const_9; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(test__2); var tmp11 *lang.Var; A_arbace_instant_A_Init(); tmp11 = A_arbace_instant_A_const_9; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_95, nil); var tmp14 *lang.Var; A_arbace_instant_A_Init(); tmp14 = A_arbace_instant_A_const_15; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp10, tmp12.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(test__2))).Ref()))) }



func A_arbace_instant_divisible_QMARK__A_New() *A_arbace_instant_divisible_QMARK__A { A_arbace_instant_divisible_QMARK__A_Init(); t := &A_arbace_instant_divisible_QMARK__A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_instant_divisible_QMARK__A) Ctor() {}
//line :38:1
func (t *A_arbace_instant_divisible_QMARK__A) Invoke_O_O_O__O(self, num__0, div__1 any) any {

	var tmp1 *lang.Var; A_arbace_instant_A_Init(); tmp1 = A_arbace_instant_A_const_16; return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_O__Z(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(num__0, div__1))).Ref()
}
func A_arbace_instant_indivisible_QMARK__A_New() *A_arbace_instant_indivisible_QMARK__A { A_arbace_instant_indivisible_QMARK__A_Init(); t := &A_arbace_instant_indivisible_QMARK__A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_instant_indivisible_QMARK__A) Ctor() {}
//line :42:1
func (t *A_arbace_instant_indivisible_QMARK__A) Invoke_O_O_O__O(self, num__0, div__1 any) any {

	var tmp1 *lang.Var; A_arbace_instant_A_Init(); tmp1 = A_arbace_instant_A_const_17; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_instant_A_Init(); tmp3 = A_arbace_instant_A_const_18; return tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(num__0, div__1))
}



func A_arbace_instant_parse_int_A_New() *A_arbace_instant_parse_int_A { A_arbace_instant_parse_int_A_Init(); t := &A_arbace_instant_parse_int_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_instant_parse_int_A) Ctor() {}
//line :49:1
func (t *A_arbace_instant_parse_int_A) Invoke_O_O__O(self, s__0 any) any {
	return jrt.Long_ValueOf_J__Long(jrt.Long_ParseLong_String__J(jrt.String_Cast(s__0))).Ref()
}
func A_arbace_instant_zero_fill_right_A_New() *A_arbace_instant_zero_fill_right_A { A_arbace_instant_zero_fill_right_A_Init(); t := &A_arbace_instant_zero_fill_right_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_instant_zero_fill_right_A) Ctor() {}
//line :52:1
func (t *A_arbace_instant_zero_fill_right_A) Invoke_O_O_O__O(self, s__0, width__1 any) any {
	if lang.Util_Equiv_O_J__Z(width__1, int64(lang.RT_Count_O__I(s__0))) { return s__0 } else { if lang.Numbers_Lt_O_J__Z(width__1, int64(lang.RT_Count_O__I(s__0))) {
		return jrt.NN(jrt.String_Cast(s__0)).Substring_I_I__String(lang.RT_IntCast_J__I(0), lang.RT_IntCast_O__I(width__1)).Ref() } else {
//line :53:1
			var tmp1 *lang.Keyword; A_arbace_instant_A_Init(); tmp1 = A_arbace_instant_A_const_19; if tmp1 != nil { var b__3 any = jrt.StringBuilder_New_String(jrt.String_Cast(s__0)); L1: for {


				if lang.Numbers_Lt_J_O__Z(int64(jrt.NN(jrt.StringBuilder_Cast(b__3)).Length__I()), width__1) {
					var tmp2 *jrt.StringBuilder = jrt.StringBuilder_Cast(b__3); var tmp3 any; A_arbace_instant_A_Init(); tmp3 = A_arbace_instant_A_const_20; b__3 = jrt.NN(tmp2).Append_O__StringBuilder(tmp3).Ref(); continue L1 } else {
						return jrt.NN(jrt.StringBuilder_Cast(b__3)).ToString__String().Ref() } } } else {
//line :53:1
							return nil } } }
//line :52:1
	panic("a2g: unreachable")
}









func A_arbace_instant_parse_timestamp_A_New() *A_arbace_instant_parse_timestamp_A { A_arbace_instant_parse_timestamp_A_Init(); t := &A_arbace_instant_parse_timestamp_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_instant_parse_timestamp_A) Ctor() {}
//line :63:1
func (t *A_arbace_instant_parse_timestamp_A) Invoke_O_O_O__O(self, new_instant__0, cs__1 any) any { var temp__1927000408__auto____3 any; var tmp1 *lang.Var;





















































	A_arbace_instant_A_Init(); tmp1 = A_arbace_instant_A_const_21; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_instant_A_Init(); tmp3 = A_arbace_instant_A_const_22; temp__1927000408__auto____3 = tmp2.Invoke_O_O__O(jrt.NN(tmp3).GetRawRoot__O(), cs__1); if /*line :115:1*/ jrt.A2g_Truth(temp__1927000408__auto____3) { var vec__783000026__4 any = temp__1927000408__auto____3; var ___5 any = lang.RT_Nth_O_I_O__O(vec__783000026__4, lang.RT_IntCast_J__I(0), nil); var years__6 any = lang.RT_Nth_O_I_O__O(vec__783000026__4, lang.RT_IntCast_J__I(1), nil); var months__7 any = lang.RT_Nth_O_I_O__O(vec__783000026__4, lang.RT_IntCast_J__I(2), nil); var days__8 any = lang.RT_Nth_O_I_O__O(vec__783000026__4, lang.RT_IntCast_J__I(3), nil); var hours__9 any = lang.RT_Nth_O_I_O__O(vec__783000026__4, lang.RT_IntCast_J__I(4), nil); var minutes__10 any = lang.RT_Nth_O_I_O__O(vec__783000026__4, lang.RT_IntCast_J__I(5), nil); var seconds__11 any = lang.RT_Nth_O_I_O__O(vec__783000026__4, lang.RT_IntCast_J__I(6), nil); var fraction__12 any = lang.RT_Nth_O_I_O__O(vec__783000026__4, lang.RT_IntCast_J__I(7), nil); var offset_sign__13 any = lang.RT_Nth_O_I_O__O(vec__783000026__4, lang.RT_IntCast_J__I(8), nil); var offset_hours__14 any = lang.RT_Nth_O_I_O__O(vec__783000026__4, lang.RT_IntCast_J__I(9), nil); var offset_minutes__15 any = lang.RT_Nth_O_I_O__O(vec__783000026__4, lang.RT_IntCast_J__I(10), nil); var tmp4 lang.IFn = lang.IFn_Cast(new_instant__0); var tmp5 *lang.Var; _ = ___5


		A_arbace_instant_A_Init(); tmp5 = A_arbace_instant_A_const_23; var tmp6 any = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(years__6); var tmp7 any; var tmp8 *lang.Var

		A_arbace_instant_A_Init(); tmp8 = A_arbace_instant_A_const_17; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(months__7)) { A_arbace_instant_A_Init(); tmp7 = A_arbace_instant_A_const_24 } else { var tmp9 *lang.Var; A_arbace_instant_A_Init(); tmp9 = A_arbace_instant_A_const_23; tmp7 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(months__7) }
//line :118:1
		var tmp10 any = tmp7; var tmp11 any; var tmp12 *lang.Var


		A_arbace_instant_A_Init(); tmp12 = A_arbace_instant_A_const_17; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(days__8)) { A_arbace_instant_A_Init(); tmp11 = A_arbace_instant_A_const_24 } else { var tmp13 *lang.Var; A_arbace_instant_A_Init(); tmp13 = A_arbace_instant_A_const_23; tmp11 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(days__8) }
//line :118:1
		var tmp14 any = tmp11; var tmp15 any; var tmp16 *lang.Var



		A_arbace_instant_A_Init(); tmp16 = A_arbace_instant_A_const_17; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(hours__9)) { A_arbace_instant_A_Init(); tmp15 = A_arbace_instant_A_const_25 } else { var tmp17 *lang.Var; A_arbace_instant_A_Init(); tmp17 = A_arbace_instant_A_const_23; tmp15 = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(hours__9) }
//line :118:1
		var tmp18 any = tmp15; var tmp19 any; var tmp20 *lang.Var




		A_arbace_instant_A_Init(); tmp20 = A_arbace_instant_A_const_17; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(minutes__10)) { A_arbace_instant_A_Init(); tmp19 = A_arbace_instant_A_const_25 } else { var tmp21 *lang.Var; A_arbace_instant_A_Init(); tmp21 = A_arbace_instant_A_const_23; tmp19 = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(minutes__10) }
//line :118:1
		var tmp22 any = tmp19; var tmp23 any; var tmp24 *lang.Var





		A_arbace_instant_A_Init(); tmp24 = A_arbace_instant_A_const_17; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(seconds__11)) { A_arbace_instant_A_Init(); tmp23 = A_arbace_instant_A_const_25 } else { var tmp25 *lang.Var; A_arbace_instant_A_Init(); tmp25 = A_arbace_instant_A_const_23; tmp23 = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(seconds__11) }
//line :118:1
		var tmp26 any = tmp23; var tmp27 any; var tmp28 *lang.Var






		A_arbace_instant_A_Init(); tmp28 = A_arbace_instant_A_const_17; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(fraction__12)) { A_arbace_instant_A_Init(); tmp27 = A_arbace_instant_A_const_25 } else { var tmp29 *lang.Var; A_arbace_instant_A_Init(); tmp29 = A_arbace_instant_A_const_23; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Var; A_arbace_instant_A_Init(); tmp31 = A_arbace_instant_A_const_27; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 any; A_arbace_instant_A_Init(); tmp33 = A_arbace_instant_A_const_28; tmp27 = tmp30.Invoke_O__O(tmp32.Invoke_O_O__O(fraction__12, tmp33)) }
//line :118:1
		var tmp34 any = tmp27; var tmp35 any







		if lang.Util_Equiv_O_O__Z(Lit_43, offset_sign__13) { A_arbace_instant_A_Init(); tmp35 = A_arbace_instant_A_const_26 } else { if lang.Util_Equiv_O_O__Z(Lit_44, offset_sign__13) { A_arbace_instant_A_Init(); tmp35 = A_arbace_instant_A_const_24 } else { var tmp36 *lang.Keyword; A_arbace_instant_A_Init(); tmp36 = A_arbace_instant_A_const_19; if tmp36 != nil { A_arbace_instant_A_Init(); tmp35 = A_arbace_instant_A_const_25 } else { tmp35 = nil } } }
//line :118:1
		var tmp37 any = tmp35; var tmp38 any; var tmp39 *lang.Var










		A_arbace_instant_A_Init(); tmp39 = A_arbace_instant_A_const_17; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()).Invoke_O__O(offset_hours__14)) { A_arbace_instant_A_Init(); tmp38 = A_arbace_instant_A_const_25 } else { var tmp40 *lang.Var; A_arbace_instant_A_Init(); tmp40 = A_arbace_instant_A_const_23; tmp38 = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()).Invoke_O__O(offset_hours__14) }
//line :118:1
		var tmp41 any = tmp38; var tmp42 any; var tmp43 *lang.Var











		A_arbace_instant_A_Init(); tmp43 = A_arbace_instant_A_const_17; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()).Invoke_O__O(offset_minutes__15)) { A_arbace_instant_A_Init(); tmp42 = A_arbace_instant_A_const_25 } else { var tmp44 *lang.Var; A_arbace_instant_A_Init(); tmp44 = A_arbace_instant_A_const_23; tmp42 = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()).Invoke_O__O(offset_minutes__15) }
//line :118:1
		return tmp4.Invoke_O_O_O_O_O_O_O_O_O_O__O(tmp6, tmp10, tmp14, tmp18, tmp22, tmp26, tmp34, tmp37, tmp41, tmp42) } else {
//line :115:1
			panic(jrt.Thrown(jrt.RuntimeException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_69, nil), jrt.RefArrayOf(jrt.Object_class, nil, cs__1))))) } }




















func A_arbace_instant_leap_year_QMARK__A_New() *A_arbace_instant_leap_year_QMARK__A { A_arbace_instant_leap_year_QMARK__A_Init(); t := &A_arbace_instant_leap_year_QMARK__A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_instant_leap_year_QMARK__A) Ctor() {}
//line :136:1
func (t *A_arbace_instant_leap_year_QMARK__A) Invoke_O_O__O(self, year__0 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var;

	A_arbace_instant_A_Init(); tmp1 = A_arbace_instant_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_instant_A_Init(); tmp3 = A_arbace_instant_A_const_30; and__1927000168__auto____2 = tmp2.Invoke_O_O__O(year__0, tmp3); if jrt.A2g_Truth(and__1927000168__auto____2) { var or__1927000174__auto____3 any; var tmp4 *lang.Var
		A_arbace_instant_A_Init(); tmp4 = A_arbace_instant_A_const_29; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_instant_A_Init(); tmp6 = A_arbace_instant_A_const_31; or__1927000174__auto____3 = tmp5.Invoke_O_O__O(year__0, tmp6); if jrt.A2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else {
			var tmp7 *lang.Var; A_arbace_instant_A_Init(); tmp7 = A_arbace_instant_A_const_18; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_instant_A_Init(); tmp9 = A_arbace_instant_A_const_32; return tmp8.Invoke_O_O__O(year__0, tmp9) } } else {
//line :138:1
				return and__1927000168__auto____2 } }




func A_arbace_instant_fn__783000031_A_New() *A_arbace_instant_fn__783000031_A { A_arbace_instant_fn__783000031_A_Init(); t := &A_arbace_instant_fn__783000031_A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_instant_fn__783000031_A) Ctor() {}
//line :143:1
func (t *A_arbace_instant_fn__783000031_A) Invoke_O__O(self any) any { var dim_norm__1 any; A_arbace_instant_A_Init(); dim_norm__1 = A_arbace_instant_A_const_33; var dim_leap__2 any; A_arbace_instant_A_Init(); dim_leap__2 = A_arbace_instant_A_const_34; var tmp1 any =

	A_arbace_instant_fn__783000031_fn__783000032_A_New_O_O(dim_norm__1, dim_leap__2); var tmp2 *jrt.Class; A_arbace_instant_fn__783000031_fn__783000032_A_Init(); tmp2 = A_arbace_instant_fn__783000031_fn__783000032_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :145:1
func A_arbace_instant_fn__783000031_fn__783000032_A_New_O_O(p0, p1 any) *A_arbace_instant_fn__783000031_fn__783000032_A { A_arbace_instant_fn__783000031_fn__783000032_A_Init(); t := &A_arbace_instant_fn__783000031_fn__783000032_A{}; t.Ctor_O_O(p0, p1); return t }
//line :145:1
func (t *A_arbace_instant_fn__783000031_fn__783000032_A) Ctor_O_O(c__dim_norm, c__dim_leap any) { t.F_dim_norm = c__dim_norm; t.F_dim_leap = c__dim_leap }
//line :145:1
func (t *A_arbace_instant_fn__783000031_fn__783000032_A) Invoke_O_O_O__O(self, month__1, leap_year_QMARK___2 any) any {
	var tmp1 any; if jrt.A2g_Truth(leap_year_QMARK___2) { tmp1 = t.F_dim_leap } else { tmp1 = t.F_dim_norm }; return lang.IFn_Cast(tmp1).Invoke_O__O(month__1)
}
func A_arbace_instant_validated_A_New() *A_arbace_instant_validated_A { A_arbace_instant_validated_A_Init(); t := &A_arbace_instant_validated_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_instant_validated_A) Ctor() {}
//line :148:1
func (t *A_arbace_instant_validated_A) Invoke_O_O__O(self, new_instance__0 any) any {





	var tmp1 any = A_arbace_instant_validated_fn__783000035_A_New_O(new_instance__0); var tmp2 *jrt.Class; A_arbace_instant_validated_fn__783000035_A_Init(); tmp2 = A_arbace_instant_validated_fn__783000035_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :154:1
func A_arbace_instant_validated_fn__783000035_A_New_O(p0 any) *A_arbace_instant_validated_fn__783000035_A { A_arbace_instant_validated_fn__783000035_A_Init(); t := &A_arbace_instant_validated_fn__783000035_A{}; t.Ctor_O(p0); return t }
//line :154:1
func (t *A_arbace_instant_validated_fn__783000035_A) Ctor_O(c__new_instance any) { t.F_new_instance = c__new_instance }
//line :154:1
func (t *A_arbace_instant_validated_fn__783000035_A) Invoke_O_O_O_O_O_O_O_O_O_O_O__O(self, years__1, months__2, days__3, hours__4, minutes__5, seconds__6, nanoseconds__7, offset_sign__8, offset_hours__9, offset_minutes__10 any) any {

	var tmp1 *lang.Var; A_arbace_instant_A_Init(); tmp1 = A_arbace_instant_A_const_35; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_instant_A_Init(); tmp3 = A_arbace_instant_A_const_24; var tmp4 any = tmp3; var tmp5 any; A_arbace_instant_A_Init(); tmp5 = A_arbace_instant_A_const_36; if jrt.A2g_Truth(tmp2.Invoke_O_O_O__O(tmp4, months__2, tmp5)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_85))) }
	var tmp6 *lang.Var; A_arbace_instant_A_Init(); tmp6 = A_arbace_instant_A_const_35; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any; A_arbace_instant_A_Init(); tmp8 = A_arbace_instant_A_const_24; var tmp9 any = tmp8; var tmp10 *lang.Var; A_arbace_instant_A_Init(); tmp10 = A_arbace_instant_A_const_37; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_instant_A_Init(); tmp12 = A_arbace_instant_A_const_38; if jrt.A2g_Truth(tmp7.Invoke_O_O_O__O(tmp9, days__3, tmp11.Invoke_O_O__O(months__2, lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(years__1)))) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_86))) }
	var tmp13 *lang.Var; A_arbace_instant_A_Init(); tmp13 = A_arbace_instant_A_const_35; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 any; A_arbace_instant_A_Init(); tmp15 = A_arbace_instant_A_const_25; var tmp16 any = tmp15; var tmp17 any; A_arbace_instant_A_Init(); tmp17 = A_arbace_instant_A_const_39; if jrt.A2g_Truth(tmp14.Invoke_O_O_O__O(tmp16, hours__4, tmp17)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_87))) }
	var tmp18 *lang.Var; A_arbace_instant_A_Init(); tmp18 = A_arbace_instant_A_const_35; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 any; A_arbace_instant_A_Init(); tmp20 = A_arbace_instant_A_const_25; var tmp21 any = tmp20; var tmp22 any; A_arbace_instant_A_Init(); tmp22 = A_arbace_instant_A_const_40; if jrt.A2g_Truth(tmp19.Invoke_O_O_O__O(tmp21, minutes__5, tmp22)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_88))) }
	var tmp23 *lang.Var; A_arbace_instant_A_Init(); tmp23 = A_arbace_instant_A_const_35; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 any; A_arbace_instant_A_Init(); tmp25 = A_arbace_instant_A_const_25; var tmp26 any = tmp25; var tmp27 any; if lang.Util_Equiv_O_J__Z(minutes__5, 59) { A_arbace_instant_A_Init(); tmp27 = A_arbace_instant_A_const_41 } else { A_arbace_instant_A_Init(); tmp27 = A_arbace_instant_A_const_40 }; if jrt.A2g_Truth(tmp24.Invoke_O_O_O__O(tmp26, seconds__6, tmp27)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_89))) }
	var tmp28 *lang.Var; A_arbace_instant_A_Init(); tmp28 = A_arbace_instant_A_const_35; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 any; A_arbace_instant_A_Init(); tmp30 = A_arbace_instant_A_const_25; var tmp31 any = tmp30; var tmp32 any; A_arbace_instant_A_Init(); tmp32 = A_arbace_instant_A_const_42; if jrt.A2g_Truth(tmp29.Invoke_O_O_O__O(tmp31, nanoseconds__7, tmp32)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_90))) }
	var tmp33 *lang.Var; A_arbace_instant_A_Init(); tmp33 = A_arbace_instant_A_const_35; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 any; A_arbace_instant_A_Init(); tmp35 = A_arbace_instant_A_const_26; var tmp36 any = tmp35; var tmp37 any; A_arbace_instant_A_Init(); tmp37 = A_arbace_instant_A_const_24; if jrt.A2g_Truth(tmp34.Invoke_O_O_O__O(tmp36, offset_sign__8, tmp37)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_91))) }
	var tmp38 *lang.Var; A_arbace_instant_A_Init(); tmp38 = A_arbace_instant_A_const_35; var tmp39 lang.IFn = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()); var tmp40 any; A_arbace_instant_A_Init(); tmp40 = A_arbace_instant_A_const_25; var tmp41 any = tmp40; var tmp42 any; A_arbace_instant_A_Init(); tmp42 = A_arbace_instant_A_const_39; if jrt.A2g_Truth(tmp39.Invoke_O_O_O__O(tmp41, offset_hours__9, tmp42)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_92))) }
	var tmp43 *lang.Var; A_arbace_instant_A_Init(); tmp43 = A_arbace_instant_A_const_35; var tmp44 lang.IFn = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()); var tmp45 any; A_arbace_instant_A_Init(); tmp45 = A_arbace_instant_A_const_25; var tmp46 any = tmp45; var tmp47 any; A_arbace_instant_A_Init(); tmp47 = A_arbace_instant_A_const_40; if jrt.A2g_Truth(tmp44.Invoke_O_O_O__O(tmp46, offset_minutes__10, tmp47)) { } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(Lit_93))) }
	return lang.IFn_Cast(t.F_new_instance).Invoke_O_O_O_O_O_O_O_O_O_O__O(years__1, months__2, days__3, hours__4, minutes__5, seconds__6, nanoseconds__7, offset_sign__8, offset_hours__9, offset_minutes__10)
}











func A_arbace_instant_days__GT_civil_A_New() *A_arbace_instant_days__GT_civil_A { A_arbace_instant_days__GT_civil_A_Init(); t := &A_arbace_instant_days__GT_civil_A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_instant_days__GT_civil_A) Ctor() {}
//line :178:1
func (t *A_arbace_instant_days__GT_civil_A) Invoke_O_O__O(self, z__0 any) any {



	var tmp1 *lang.Var; A_arbace_instant_A_Init(); tmp1 = A_arbace_instant_A_const_43; if lang.Numbers_Gte_O_O__Z(z__0, jrt.NN(tmp1).GetRawRoot__O()) { var z__2 any = lang.Numbers_Add_O_J__Number(z__0, 719468); var era__3 any; var tmp2 any

		if lang.Numbers_Gte_O_J__Z(z__2, 0) { tmp2 = z__2 } else { tmp2 = lang.Numbers_Minus_O_J__Number(z__2, 146096) }; era__3 = lang.Numbers_Quotient_O_J__Number(tmp2, 146097)
//line :182:1
		var doe__4 any = lang.Numbers_Minus_O_O__Number(z__2, lang.Numbers_Multiply_O_J__Number(era__3, 146097)); var yoe__5 any = lang.Numbers_Quotient_O_J__Number(lang.Numbers_Minus_O_O__Number(lang.Numbers_Minus_O_O__Number(lang.Numbers_Minus_O_O__Number(doe__4, lang.Numbers_Quotient_O_J__Number(doe__4, 1460)), lang.Numbers_Minus_O__Number(lang.Numbers_Quotient_O_J__Number(doe__4, 36524))), lang.Numbers_Quotient_O_J__Number(doe__4, 146096)), 365); var y__6 any = lang.Numbers_Add_O_O__Number(yoe__5, lang.Numbers_Multiply_O_J__Number(era__3, 400)); var doy__7 any = lang.Numbers_Minus_O_O__Number(doe__4, lang.Numbers_Minus_O_O__Number(lang.Numbers_Add_O_O__Number(lang.Numbers_Multiply_J_O__Number(365, yoe__5), lang.Numbers_Quotient_O_J__Number(yoe__5, 4)), lang.Numbers_Quotient_O_J__Number(yoe__5, 100))); var mp__8 any = lang.Numbers_Quotient_O_J__Number(lang.Numbers_Add_O_J__Number(lang.Numbers_Multiply_J_O__Number(5, doy__7), 2), 153); var d__9 any = lang.Numbers_Inc_O__Number(lang.Numbers_Minus_O_O__Number(doy__7, lang.Numbers_Quotient_O_J__Number(lang.Numbers_Add_O_J__Number(lang.Numbers_Multiply_J_O__Number(153, mp__8), 2), 5))); var m__10 any








		if lang.Numbers_Lt_O_J__Z(mp__8, 10) { m__10 = lang.Numbers_Add_O_J__Number(mp__8, 3) } else { m__10 = lang.Numbers_Minus_O_J__Number(mp__8, 9) }
//line :182:1
		var tmp3 any









		if lang.Numbers_Lte_O_J__Z(m__10, 2) { tmp3 = lang.Numbers_Inc_O__Number(y__6) } else { tmp3 = y__6 }
//line :182:1
		return lang.Tuple_Create_O_O_O__IPersistentVector(tmp3, m__10, d__9) } else { var c__2 any = lang.Numbers_Add_O_J__Number(lang.Numbers_Add_O_J__Number(z__0, 2440588), 32082); var d__3 int64 = jrt.Math_FloorDiv_J_J__J(lang.RT_LongCast_O__J(lang.Numbers_Add_O_J__Number(lang.Numbers_Multiply_J_O__Number(4, c__2), 3)), 1461); var e__4 any = lang.Numbers_Minus_O_J__Number(c__2, jrt.Math_FloorDiv_J_J__J(lang.RT_LongCast_J__J(lang.Numbers_Multiply_J_J__J(1461, d__3)), 4)); var m__5 any = lang.Numbers_Quotient_O_J__Number(lang.Numbers_Add_O_J__Number(lang.Numbers_Multiply_J_O__Number(5, e__4), 2), 153); return lang.Tuple_Create_O_O_O__IPersistentVector(lang.Numbers_Add_J_O__Number(lang.Numbers_Minus_J_J__J(d__3, 4800), lang.Numbers_Quotient_O_J__Number(m__5, 10)), lang.Numbers_Minus_O_O__Number(lang.Numbers_Add_O_J__Number(m__5, 3), lang.Numbers_Multiply_J_O__Number(12, lang.Numbers_Quotient_O_J__Number(m__5, 10))), lang.Numbers_Inc_O__Number(lang.Numbers_Minus_O_O__Number(e__4, lang.Numbers_Quotient_O_J__Number(lang.Numbers_Add_O_J__Number(lang.Numbers_Multiply_J_O__Number(153, m__5), 2), 5))))
		}
}
















func A_arbace_instant_civil__GT_days_A_New() *A_arbace_instant_civil__GT_days_A { A_arbace_instant_civil__GT_days_A_Init(); t := &A_arbace_instant_civil__GT_days_A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_instant_civil__GT_days_A) Ctor() {}
//line :201:1
func (t *A_arbace_instant_civil__GT_days_A) Invoke_O_O_O_O__O(self, y__0, m__1, d__2 any) any { var g__4 any; var y__4 any; if



	lang.Numbers_Lte_O_J__Z(m__1, 2) { y__4 = lang.Numbers_Dec_O__Number(y__0) } else { y__4 = y__0 }; var era__5 any; var tmp1 any; if
	lang.Numbers_Gte_O_J__Z(y__4, 0) { tmp1 = y__4 } else { tmp1 = lang.Numbers_Minus_O_J__Number(y__4, 399) }; era__5 = lang.Numbers_Quotient_O_J__Number(tmp1, 400); var yoe__6 any = /*line :201:1*/lang.Numbers_Minus_O_O__Number(y__4, lang.Numbers_Multiply_O_J__Number(era__5, 400)); var doy__7 any; var tmp2 jrt.Number_I; if






	lang.Numbers_Gt_O_J__Z(m__1, 2) { tmp2 = lang.Numbers_Minus_O_J__Number(m__1, 3) } else { tmp2 = lang.Numbers_Add_O_J__Number(m__1, 9) }; doy__7 = lang.Numbers_Add_O_O__Number(lang.Numbers_Quotient_O_J__Number(lang.Numbers_Add_O_J__Number(lang.Numbers_Multiply_J_O__Number(153, tmp2), 2), 5), lang.Numbers_Dec_O__Number(d__2)); var doe__8 any = /*line :201:1*/lang.Numbers_Minus_O_O__Number(lang.Numbers_Add_O_O__Number(lang.Numbers_Add_O_O__Number(lang.Numbers_Multiply_O_J__Number(yoe__6, 365), lang.Numbers_Quotient_O_J__Number(yoe__6, 4)), doy__7), lang.Numbers_Quotient_O_J__Number(yoe__6, 100)); g__4 =








	lang.Numbers_Add_O_J__Number(lang.Numbers_Add_O_O__Number(lang.Numbers_Multiply_O_J__Number(era__5, 146097), doe__8), -719468); var tmp3 /*line :211:1*/*lang.Var; A_arbace_instant_A_Init(); tmp3 = A_arbace_instant_A_const_43; if lang.Numbers_Gte_O_O__Z(g__4, jrt.NN(tmp3).GetRawRoot__O()) { return g__4 } else { var a__5 any = lang.Numbers_Quotient_O_J__Number(lang.Numbers_Minus_J_O__Number(14, m__1), 12); var yy__6 any = lang.Numbers_Minus_O_O__Number(lang.Numbers_Add_O_J__Number(y__0, 4800), a__5); var mm__7 any = lang.Numbers_Minus_O_J__Number(lang.Numbers_Add_O_O__Number(m__1, lang.Numbers_Multiply_J_O__Number(12, a__5)), 3)




		return lang.Numbers_Minus_O_J__Number(lang.Numbers_Add_O_J__Number(lang.Numbers_Add_O_J__Number(lang.Numbers_Add_O_O__Number(lang.Numbers_Add_O_O__Number(d__2, lang.Numbers_Quotient_O_J__Number(lang.Numbers_Add_O_J__Number(lang.Numbers_Multiply_J_O__Number(153, mm__7), 2), 5)), lang.Numbers_Multiply_J_O__Number(365, yy__6)), jrt.Math_FloorDiv_J_J__J(lang.RT_LongCast_O__J(yy__6), 4)), -32083), 2440588) } }

func A_arbace_instant_print_date_A_New() *A_arbace_instant_print_date_A { A_arbace_instant_print_date_A_Init(); t := &A_arbace_instant_print_date_A{}; t.Ctor(); return t }
//line :218:1
func (t *A_arbace_instant_print_date_A) Ctor() {}
//line :218:1
func (t *A_arbace_instant_print_date_A) Invoke_O_O_O__O(self, d__0, w__1 any) any { var ms__3 int64 = jrt.Date_Cast(d__0).GetTime__J(); var days__4 int64 = jrt.Math_FloorDiv_J_J__J(ms__3, 86400000); var msd__5 int64 = jrt.Math_FloorMod_J_J__J(ms__3, 86400000); var vec__783000040__6 any; var tmp1 *lang.Var;





	A_arbace_instant_A_Init(); tmp1 = A_arbace_instant_A_const_44; vec__783000040__6 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(days__4).Ref()); var y__7 any = /*line :218:1*/lang.RT_Nth_O_I_O__O(vec__783000040__6, lang.RT_IntCast_J__I(0), nil); var m__8 any = lang.RT_Nth_O_I_O__O(vec__783000040__6, lang.RT_IntCast_J__I(1), nil); var dd__9 any = lang.RT_Nth_O_I_O__O(vec__783000040__6, lang.RT_IntCast_J__I(2), nil);






	jrt.Writer_Cast(w__1).Write_String__V(Lit_72); var tmp2 jrt.Writer_I =
	jrt.Writer_Cast(w__1); var tmp3 *lang.Var; A_arbace_instant_A_Init(); tmp3 = A_arbace_instant_A_const_45; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any; if
	lang.Numbers_Lte_O_J__Z(y__7, 0) { tmp5 = lang.Numbers_Minus_J_O__Number(1, y__7) } else { tmp5 = y__7 }; /*line :226:1*/tmp2.Write_String__V(jrt.String_Cast(tmp4.Invoke_O_O_O_O_O_O_O_O__O(Lit_76, tmp5, m__8, dd__9, jrt.Long_ValueOf_J__Long(lang.Numbers_Quotient_J_J__J(msd__5, 3600000)).Ref(), jrt.Long_ValueOf_J__Long(lang.Numbers_Remainder_J_J__J(lang.Numbers_Quotient_J_J__J(msd__5, 60000), 60)).Ref(), jrt.Long_ValueOf_J__Long(lang.Numbers_Remainder_J_J__J(lang.Numbers_Quotient_J_J__J(msd__5, 1000), 60)).Ref(), jrt.Long_ValueOf_J__Long(lang.Numbers_Remainder_J_J__J(msd__5, 1000)).Ref())));


	jrt.Writer_Cast(w__1).Write_String__V(Lit_74); return nil }

func A_arbace_instant_eval783000044_fn__783000045_A_New() *A_arbace_instant_eval783000044_fn__783000045_A { A_arbace_instant_eval783000044_fn__783000045_A_Init(); t := &A_arbace_instant_eval783000044_fn__783000045_A{}; t.Ctor(); return t }
//line :231:1
func (t *A_arbace_instant_eval783000044_fn__783000045_A) Ctor() {}
//line :231:1
func (t *A_arbace_instant_eval783000044_fn__783000045_A) Invoke_O_O_O__O(self, d__1, w__2 any) any {

	var tmp1 *lang.Var; A_arbace_instant_A_Init(); tmp1 = A_arbace_instant_A_const_46; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(d__1, w__2)
}
func A_arbace_instant_eval783000048_fn__783000049_A_New() *A_arbace_instant_eval783000048_fn__783000049_A { A_arbace_instant_eval783000048_fn__783000049_A_Init(); t := &A_arbace_instant_eval783000048_fn__783000049_A{}; t.Ctor(); return t }
//line :235:1
func (t *A_arbace_instant_eval783000048_fn__783000049_A) Ctor() {}
//line :235:1
func (t *A_arbace_instant_eval783000048_fn__783000049_A) Invoke_O_O_O__O(self, d__1, w__2 any) any {

	var tmp1 *lang.Var; A_arbace_instant_A_Init(); tmp1 = A_arbace_instant_A_const_46; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(d__1, w__2)
}
func A_arbace_instant_print_calendar_A_New() *A_arbace_instant_print_calendar_A { A_arbace_instant_print_calendar_A_Init(); t := &A_arbace_instant_print_calendar_A{}; t.Ctor(); return t }
//line :239:1
func (t *A_arbace_instant_print_calendar_A) Ctor() {}
//line :239:1
func (t *A_arbace_instant_print_calendar_A) Invoke_O_O_O__O(self, c__0, w__1 any) any { var calstr__3 any; var tmp1 *lang.Var;


	A_arbace_instant_A_Init(); tmp1 = A_arbace_instant_A_const_45; calstr__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(Lit_71, c__0); var offset_minutes__4 int64 = /*line :239:1*/lang.Numbers_Minus_J_J__J(int64(jrt.NN(jrt.String_Cast(calstr__3)).Length__I()), 2);





	jrt.Writer_Cast(w__1).Write_String__V(Lit_72);
	jrt.Writer_Cast(w__1).Write_String_I_I__V(jrt.String_Cast(calstr__3), lang.RT_IntCast_J__I(0), lang.RT_IntCast_J__I(offset_minutes__4));
	jrt.Writer_Cast(w__1).Write_String__V(Lit_73);
	jrt.Writer_Cast(w__1).Write_String_I_I__V(jrt.String_Cast(calstr__3), lang.RT_IntCast_J__I(offset_minutes__4), lang.RT_IntCast_J__I(2));
	jrt.Writer_Cast(w__1).Write_String__V(Lit_74); return nil }

func A_arbace_instant_eval783000053_fn__783000054_A_New() *A_arbace_instant_eval783000053_fn__783000054_A { A_arbace_instant_eval783000053_fn__783000054_A_Init(); t := &A_arbace_instant_eval783000053_fn__783000054_A{}; t.Ctor(); return t }
//line :251:1
func (t *A_arbace_instant_eval783000053_fn__783000054_A) Ctor() {}
//line :251:1
func (t *A_arbace_instant_eval783000053_fn__783000054_A) Invoke_O_O_O__O(self, c__1, w__2 any) any {

	var tmp1 *lang.Var; A_arbace_instant_A_Init(); tmp1 = A_arbace_instant_A_const_47; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(c__1, w__2)
}
func A_arbace_instant_eval783000057_fn__783000058_A_New() *A_arbace_instant_eval783000057_fn__783000058_A { A_arbace_instant_eval783000057_fn__783000058_A_Init(); t := &A_arbace_instant_eval783000057_fn__783000058_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_instant_eval783000057_fn__783000058_A) Ctor() {}
//line :255:1
func (t *A_arbace_instant_eval783000057_fn__783000058_A) Invoke_O_O_O__O(self, c__1, w__2 any) any {

	var tmp1 *lang.Var; A_arbace_instant_A_Init(); tmp1 = A_arbace_instant_A_const_47; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(c__1, w__2)
}
func A_arbace_instant_print_timestamp_A_New() *A_arbace_instant_print_timestamp_A { A_arbace_instant_print_timestamp_A_Init(); t := &A_arbace_instant_print_timestamp_A{}; t.Ctor(); return t }
//line :259:1
func (t *A_arbace_instant_print_timestamp_A) Ctor() {}
//line :259:1
func (t *A_arbace_instant_print_timestamp_A) Invoke_O_O_O__O(self, ts__0, w__1 any) any { var ms__3 int64 = jrt.NN(jrt.Timestamp_Cast(ts__0)).GetTime__J(); var days__4 int64 = jrt.Math_FloorDiv_J_J__J(ms__3, 86400000); var msd__5 int64 = jrt.Math_FloorMod_J_J__J(ms__3, 86400000); var vec__783000061__6 any; var tmp1 *lang.Var;





	A_arbace_instant_A_Init(); tmp1 = A_arbace_instant_A_const_44; vec__783000061__6 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(days__4).Ref()); var y__7 any = /*line :259:1*/lang.RT_Nth_O_I_O__O(vec__783000061__6, lang.RT_IntCast_J__I(0), nil); var m__8 any = lang.RT_Nth_O_I_O__O(vec__783000061__6, lang.RT_IntCast_J__I(1), nil); var dd__9 any = lang.RT_Nth_O_I_O__O(vec__783000061__6, lang.RT_IntCast_J__I(2), nil);






	jrt.Writer_Cast(w__1).Write_String__V(Lit_72); var tmp2 jrt.Writer_I =
	jrt.Writer_Cast(w__1); var tmp3 *lang.Var; A_arbace_instant_A_Init(); tmp3 = A_arbace_instant_A_const_45; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any; if
	lang.Numbers_Lte_O_J__Z(y__7, 0) { tmp5 = lang.Numbers_Minus_J_O__Number(1, y__7) } else { tmp5 = y__7 }; /*line :267:1*/tmp2.Write_String__V(jrt.String_Cast(tmp4.Invoke_O_O_O_O_O_O_O__O(Lit_78, tmp5, m__8, dd__9, jrt.Long_ValueOf_J__Long(lang.Numbers_Quotient_J_J__J(msd__5, 3600000)).Ref(), jrt.Long_ValueOf_J__Long(lang.Numbers_Remainder_J_J__J(lang.Numbers_Quotient_J_J__J(msd__5, 60000), 60)).Ref(), jrt.Long_ValueOf_J__Long(lang.Numbers_Remainder_J_J__J(lang.Numbers_Quotient_J_J__J(msd__5, 1000), 60)).Ref()))); var tmp6 jrt.Writer_I =




	jrt.Writer_Cast(w__1); var tmp7 *lang.Var; A_arbace_instant_A_Init(); tmp7 = A_arbace_instant_A_const_45; tmp6.Write_String__V(jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O_O__O(Lit_79, jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.Timestamp_Cast(ts__0)).GetNanos__I()).Ref())));
	jrt.Writer_Cast(w__1).Write_String__V(Lit_74); return nil }

func A_arbace_instant_eval783000065_fn__783000066_A_New() *A_arbace_instant_eval783000065_fn__783000066_A { A_arbace_instant_eval783000065_fn__783000066_A_Init(); t := &A_arbace_instant_eval783000065_fn__783000066_A{}; t.Ctor(); return t }
//line :275:1
func (t *A_arbace_instant_eval783000065_fn__783000066_A) Ctor() {}
//line :275:1
func (t *A_arbace_instant_eval783000065_fn__783000066_A) Invoke_O_O_O__O(self, ts__1, w__2 any) any {

	var tmp1 *lang.Var; A_arbace_instant_A_Init(); tmp1 = A_arbace_instant_A_const_48; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(ts__1, w__2)
}
func A_arbace_instant_eval783000069_fn__783000070_A_New() *A_arbace_instant_eval783000069_fn__783000070_A { A_arbace_instant_eval783000069_fn__783000070_A_Init(); t := &A_arbace_instant_eval783000069_fn__783000070_A{}; t.Ctor(); return t }
//line :279:1
func (t *A_arbace_instant_eval783000069_fn__783000070_A) Ctor() {}
//line :279:1
func (t *A_arbace_instant_eval783000069_fn__783000070_A) Invoke_O_O_O__O(self, ts__1, w__2 any) any {

	var tmp1 *lang.Var; A_arbace_instant_A_Init(); tmp1 = A_arbace_instant_A_const_48; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(ts__1, w__2)
}



func A_arbace_instant_construct_date_A_New() *A_arbace_instant_construct_date_A { A_arbace_instant_construct_date_A_Init(); t := &A_arbace_instant_construct_date_A{}; t.Ctor(); return t }
//line :286:1
func (t *A_arbace_instant_construct_date_A) Ctor() {}
//line :286:1
func (t *A_arbace_instant_construct_date_A) Invoke_O_O_O_O_O_O_O_O_O_O_O__O(self, years__0, months__1, days__2, hours__3, minutes__4, seconds__5, nanoseconds__6, offset_sign__7, offset_hours__8, offset_minutes__9 any) any { var tmp1 *lang.Var; A_arbace_instant_A_Init(); tmp1 = A_arbace_instant_A_const_49; return jrt.Date_New_J(lang.RT_LongCast_O__J(lang.Numbers_Minus_O_O__Number(lang.Numbers_Add_O_O__Number(lang.Numbers_Add_O_O__Number(lang.Numbers_Add_O_O__Number(lang.Numbers_Add_O_O__Number(lang.Numbers_Multiply_O_J__Number(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(years__0, months__1, days__2), 86400000), lang.Numbers_Multiply_O_J__Number(hours__3, 3600000)), lang.Numbers_Multiply_O_J__Number(minutes__4, 60000)), lang.Numbers_Multiply_O_J__Number(seconds__5, 1000)), lang.Numbers_Quotient_O_J__Number(nanoseconds__6, 1000000)), lang.Numbers_Multiply_O_J__Number(lang.Numbers_Multiply_O_O__Number(offset_sign__7, lang.Numbers_Add_O_O__Number(lang.Numbers_Multiply_O_J__Number(offset_hours__8, 60), offset_minutes__9)), 60000)))) }









func A_arbace_instant_read_instant_date_A_New() *A_arbace_instant_read_instant_date_A { A_arbace_instant_read_instant_date_A_Init(); t := &A_arbace_instant_read_instant_date_A{}; t.Ctor(); return t }
//line :296:1
func (t *A_arbace_instant_read_instant_date_A) Ctor() {}
//line :296:1
func (t *A_arbace_instant_read_instant_date_A) Invoke_O_O__O(self, cs__0 any) any {




	var tmp1 *lang.Var; A_arbace_instant_A_Init(); tmp1 = A_arbace_instant_A_const_50; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_instant_A_Init(); tmp3 = A_arbace_instant_A_const_51; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_instant_A_Init(); tmp5 = A_arbace_instant_A_const_52; return tmp2.Invoke_O_O__O(tmp4.Invoke_O__O(jrt.NN(tmp5).GetRawRoot__O()), cs__0)
}
func A_arbace_instant_construct_calendar_A_New() *A_arbace_instant_construct_calendar_A { A_arbace_instant_construct_calendar_A_Init(); t := &A_arbace_instant_construct_calendar_A{}; t.Ctor(); return t }
//line :303:1
func (t *A_arbace_instant_construct_calendar_A) Ctor() {}
//line :303:1
func (t *A_arbace_instant_construct_calendar_A) Invoke_O_O_O_O_O_O_O_O_O_O_O__O(self, years__0, months__1, days__2, hours__3, minutes__4, seconds__5, nanoseconds__6, offset_sign__7, offset_hours__8, offset_minutes__9 any) any { var G__783000075__11_ any = jrt.GregorianCalendar_New_I_I_I_I_I_I(lang.RT_IntCast_O__I(years__0), lang.RT_IntCast_O__I(lang.Numbers_Dec_O__Number(months__1)), lang.RT_IntCast_O__I(days__2), lang.RT_IntCast_O__I(hours__3), lang.RT_IntCast_O__I(minutes__4), lang.RT_IntCast_O__I(seconds__5));






	jrt.Calendar_Cast(G__783000075__11_).Set_I_I__V(14, lang.RT_IntCast_O__I(lang.Numbers_Quotient_O_J__Number(nanoseconds__6, 1000000))); var tmp1 /*line :311:1*/*jrt.GregorianCalendar = jrt.GregorianCalendar_Cast(G__783000075__11_); var tmp2 *lang.Var; A_arbace_instant_A_Init(); tmp2 = A_arbace_instant_A_const_45; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *jrt.String; if

	lang.Numbers_IsNeg_O__Z(offset_sign__7) { tmp4 = Lit_43 } else { tmp4 = Lit_44 }; /*line :311:1*/jrt.NN(tmp1).SetTimeZone_TimeZone__V(jrt.TimeZone_GetTimeZone_String__TimeZone(jrt.String_Cast(tmp3.Invoke_O_O_O_O__O(Lit_42, tmp4.Ref(), offset_hours__8, offset_minutes__9)))); return G__783000075__11_ }




func A_arbace_instant_construct_timestamp_A_New() *A_arbace_instant_construct_timestamp_A { A_arbace_instant_construct_timestamp_A_Init(); t := &A_arbace_instant_construct_timestamp_A{}; t.Ctor(); return t }
//line :316:1
func (t *A_arbace_instant_construct_timestamp_A) Ctor() {}
//line :316:1
func (t *A_arbace_instant_construct_timestamp_A) Invoke_O_O_O_O_O_O_O_O_O_O_O__O(self, years__0, months__1, days__2, hours__3, minutes__4, seconds__5, nanoseconds__6, offset_sign__7, offset_hours__8, offset_minutes__9 any) any { var G__783000077__11_ any; var tmp1 *lang.Var; A_arbace_instant_A_Init(); tmp1 = A_arbace_instant_A_const_53; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_instant_A_Init(); tmp3 = A_arbace_instant_A_const_25; G__783000077__11_ = jrt.Timestamp_New_J(jrt.Calendar_Cast(tmp2.Invoke_O_O_O_O_O_O_O_O_O_O__O(years__0, months__1, days__2, hours__3, minutes__4, seconds__5, tmp3, offset_sign__7, offset_hours__8, offset_minutes__9)).GetTimeInMillis__J());









	jrt.NN(jrt.Timestamp_Cast(G__783000077__11_)).SetNanos_I__V(lang.RT_IntCast_O__I(nanoseconds__6)); return G__783000077__11_ }

func A_arbace_instant_read_instant_calendar_A_New() *A_arbace_instant_read_instant_calendar_A { A_arbace_instant_read_instant_calendar_A_Init(); t := &A_arbace_instant_read_instant_calendar_A{}; t.Ctor(); return t }
//line :328:1
func (t *A_arbace_instant_read_instant_calendar_A) Ctor() {}
//line :328:1
func (t *A_arbace_instant_read_instant_calendar_A) Invoke_O_O__O(self, cs__0 any) any {




	var tmp1 *lang.Var; A_arbace_instant_A_Init(); tmp1 = A_arbace_instant_A_const_50; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_instant_A_Init(); tmp3 = A_arbace_instant_A_const_51; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_instant_A_Init(); tmp5 = A_arbace_instant_A_const_53; return tmp2.Invoke_O_O__O(tmp4.Invoke_O__O(jrt.NN(tmp5).GetRawRoot__O()), cs__0)
}
func A_arbace_instant_read_instant_timestamp_A_New() *A_arbace_instant_read_instant_timestamp_A { A_arbace_instant_read_instant_timestamp_A_Init(); t := &A_arbace_instant_read_instant_timestamp_A{}; t.Ctor(); return t }
//line :335:1
func (t *A_arbace_instant_read_instant_timestamp_A) Ctor() {}
//line :335:1
func (t *A_arbace_instant_read_instant_timestamp_A) Invoke_O_O__O(self, cs__0 any) any {





	var tmp1 *lang.Var; A_arbace_instant_A_Init(); tmp1 = A_arbace_instant_A_const_50; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_instant_A_Init(); tmp3 = A_arbace_instant_A_const_51; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_instant_A_Init(); tmp5 = A_arbace_instant_A_const_54; return tmp2.Invoke_O_O__O(tmp4.Invoke_O__O(jrt.NN(tmp5).GetRawRoot__O()), cs__0)
}
type A_arbace_instant_A struct{ jrt.Object }

var A_arbace_instant_A_const_0 *lang.Var

var A_arbace_instant_A_const_1 any

var A_arbace_instant_A_const_2 *lang.Var

var A_arbace_instant_A_const_3 *lang.Var

var A_arbace_instant_A_const_4 *lang.Var

var A_arbace_instant_A_const_5 any

var A_arbace_instant_A_const_6 *lang.Var

var A_arbace_instant_A_const_7 *lang.Var

var A_arbace_instant_A_const_8 *lang.Var

var A_arbace_instant_A_const_9 *lang.Var

var A_arbace_instant_A_const_10 any

var A_arbace_instant_A_const_11 any

var A_arbace_instant_A_const_12 any

var A_arbace_instant_A_const_13 any

var A_arbace_instant_A_const_14 any

var A_arbace_instant_A_const_15 *lang.Var

var A_arbace_instant_A_const_16 *lang.Var

var A_arbace_instant_A_const_17 *lang.Var

var A_arbace_instant_A_const_18 *lang.Var

var A_arbace_instant_A_const_19 *lang.Keyword

var A_arbace_instant_A_const_20 any

var A_arbace_instant_A_const_21 *lang.Var

var A_arbace_instant_A_const_22 *lang.Var

var A_arbace_instant_A_const_23 *lang.Var

var A_arbace_instant_A_const_24 any

var A_arbace_instant_A_const_25 any

var A_arbace_instant_A_const_26 any

var A_arbace_instant_A_const_27 *lang.Var

var A_arbace_instant_A_const_28 any

var A_arbace_instant_A_const_29 *lang.Var

var A_arbace_instant_A_const_30 any

var A_arbace_instant_A_const_31 any

var A_arbace_instant_A_const_32 any

var A_arbace_instant_A_const_33 any

var A_arbace_instant_A_const_34 any

var A_arbace_instant_A_const_35 *lang.Var

var A_arbace_instant_A_const_36 any

var A_arbace_instant_A_const_37 *lang.Var

var A_arbace_instant_A_const_38 *lang.Var

var A_arbace_instant_A_const_39 any

var A_arbace_instant_A_const_40 any

var A_arbace_instant_A_const_41 any

var A_arbace_instant_A_const_42 any

var A_arbace_instant_A_const_43 *lang.Var

var A_arbace_instant_A_const_44 *lang.Var

var A_arbace_instant_A_const_45 *lang.Var

var A_arbace_instant_A_const_46 *lang.Var

var A_arbace_instant_A_const_47 *lang.Var

var A_arbace_instant_A_const_48 *lang.Var

var A_arbace_instant_A_const_49 *lang.Var

var A_arbace_instant_A_const_50 *lang.Var

var A_arbace_instant_A_const_51 *lang.Var

var A_arbace_instant_A_const_52 *lang.Var

var A_arbace_instant_A_const_53 *lang.Var

var A_arbace_instant_A_const_54 *lang.Var

var A_arbace_instant_A_init jrt.ClassInit

func A_arbace_instant_A_Init() { if !A_arbace_instant_A_init.Done() { A_arbace_instant_A_init.Run(A_arbace_instant_A_clinit) } }

func A_arbace_instant_A_clinit() { A_arbace_instant_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_instant_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_instant_A_const_2 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_instant_A_const_3 = lang.RT_Var_String_String__Var(Lit_0, Lit_3); A_arbace_instant_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_4); A_arbace_instant_A_const_5 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref(); A_arbace_instant_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_6); A_arbace_instant_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_7); A_arbace_instant_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_instant_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_9); A_arbace_instant_A_const_10 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_10).Ref(); A_arbace_instant_A_const_11 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_11).Ref(); A_arbace_instant_A_const_12 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_12).Ref(); A_arbace_instant_A_const_13 = lang.Symbol_Intern_String_String__Symbol(Lit_5, Lit_13).Ref(); A_arbace_instant_A_const_14 = lang.Symbol_Intern_String_String__Symbol(Lit_5, Lit_14).Ref(); A_arbace_instant_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_15); A_arbace_instant_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); A_arbace_instant_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_instant_A_const_18 = lang.RT_Var_String_String__Var(Lit_5, Lit_18); A_arbace_instant_A_const_19 = lang.RT_Keyword_String_String__Keyword(nil, Lit_19); A_arbace_instant_A_const_20 = jrt.Character_ValueOf_C__Character(48).Ref(); A_arbace_instant_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_instant_A_const_22 = lang.RT_Var_String_String__Var(Lit_5, Lit_21); A_arbace_instant_A_const_23 = lang.RT_Var_String_String__Var(Lit_5, Lit_22); A_arbace_instant_A_const_24 = jrt.Long_ValueOf_J__Long(1).Ref(); A_arbace_instant_A_const_25 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_instant_A_const_26 = jrt.Long_ValueOf_J__Long(-1).Ref(); A_arbace_instant_A_const_27 = lang.RT_Var_String_String__Var(Lit_5, Lit_23); A_arbace_instant_A_const_28 = jrt.Long_ValueOf_J__Long(9).Ref(); A_arbace_instant_A_const_29 = lang.RT_Var_String_String__Var(Lit_5, Lit_24); A_arbace_instant_A_const_30 = jrt.Long_ValueOf_J__Long(4).Ref(); A_arbace_instant_A_const_31 = jrt.Long_ValueOf_J__Long(100).Ref(); A_arbace_instant_A_const_32 = jrt.Long_ValueOf_J__Long(400).Ref(); A_arbace_instant_A_const_33 = lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long(31).Ref(), jrt.Long_ValueOf_J__Long(28).Ref(), jrt.Long_ValueOf_J__Long(31).Ref(), jrt.Long_ValueOf_J__Long(30).Ref(), jrt.Long_ValueOf_J__Long(31).Ref(), jrt.Long_ValueOf_J__Long(30).Ref(), jrt.Long_ValueOf_J__Long(31).Ref(), jrt.Long_ValueOf_J__Long(31).Ref(), jrt.Long_ValueOf_J__Long(30).Ref(), jrt.Long_ValueOf_J__Long(31).Ref(), jrt.Long_ValueOf_J__Long(30).Ref(), jrt.Long_ValueOf_J__Long(31).Ref())); A_arbace_instant_A_const_34 = lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long(31).Ref(), jrt.Long_ValueOf_J__Long(29).Ref(), jrt.Long_ValueOf_J__Long(31).Ref(), jrt.Long_ValueOf_J__Long(30).Ref(), jrt.Long_ValueOf_J__Long(31).Ref(), jrt.Long_ValueOf_J__Long(30).Ref(), jrt.Long_ValueOf_J__Long(31).Ref(), jrt.Long_ValueOf_J__Long(31).Ref(), jrt.Long_ValueOf_J__Long(30).Ref(), jrt.Long_ValueOf_J__Long(31).Ref(), jrt.Long_ValueOf_J__Long(30).Ref(), jrt.Long_ValueOf_J__Long(31).Ref())); A_arbace_instant_A_const_35 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); A_arbace_instant_A_const_36 = jrt.Long_ValueOf_J__Long(12).Ref(); A_arbace_instant_A_const_37 = lang.RT_Var_String_String__Var(Lit_5, Lit_26); A_arbace_instant_A_const_38 = lang.RT_Var_String_String__Var(Lit_5, Lit_27); A_arbace_instant_A_const_39 = jrt.Long_ValueOf_J__Long(23).Ref(); A_arbace_instant_A_const_40 = jrt.Long_ValueOf_J__Long(59).Ref(); A_arbace_instant_A_const_41 = jrt.Long_ValueOf_J__Long(60).Ref(); A_arbace_instant_A_const_42 = jrt.Long_ValueOf_J__Long(999999999).Ref(); A_arbace_instant_A_const_43 = lang.RT_Var_String_String__Var(Lit_5, Lit_28); A_arbace_instant_A_const_44 = lang.RT_Var_String_String__Var(Lit_5, Lit_29); A_arbace_instant_A_const_45 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_instant_A_const_46 = lang.RT_Var_String_String__Var(Lit_5, Lit_31); A_arbace_instant_A_const_47 = lang.RT_Var_String_String__Var(Lit_5, Lit_32); A_arbace_instant_A_const_48 = lang.RT_Var_String_String__Var(Lit_5, Lit_33); A_arbace_instant_A_const_49 = lang.RT_Var_String_String__Var(Lit_5, Lit_34); A_arbace_instant_A_const_50 = lang.RT_Var_String_String__Var(Lit_5, Lit_35); A_arbace_instant_A_const_51 = lang.RT_Var_String_String__Var(Lit_5, Lit_36); A_arbace_instant_A_const_52 = lang.RT_Var_String_String__Var(Lit_5, Lit_37); A_arbace_instant_A_const_53 = lang.RT_Var_String_String__Var(Lit_5, Lit_38); A_arbace_instant_A_const_54 = lang.RT_Var_String_String__Var(Lit_5, Lit_39) }

func A_arbace_instant_A_New() *A_arbace_instant_A { A_arbace_instant_A_Init(); t := &A_arbace_instant_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_A) Ctor() {}

func (t *A_arbace_instant_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_A) GetClass__Class() *jrt.Class { return A_arbace_instant_A_class }

func (t *A_arbace_instant_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_A); return ok }

func A_arbace_instant_A_Cast(x any) *A_arbace_instant_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_A_class)) }; return v }



type A_arbace_instant_civil__GT_days_A struct{ jrt.Object }

func (t *A_arbace_instant_civil__GT_days_A) Is_Compiler_AOTF3() {}

var A_arbace_instant_civil__GT_days_A_fn_class *jrt.Class

var A_arbace_instant_civil__GT_days_A_init jrt.ClassInit

func A_arbace_instant_civil__GT_days_A_Init() { if !A_arbace_instant_civil__GT_days_A_init.Done() { A_arbace_instant_civil__GT_days_A_init.Run(A_arbace_instant_civil__GT_days_A_clinit) } }

func A_arbace_instant_civil__GT_days_A_clinit() { A_arbace_instant_civil__GT_days_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_40, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_civil__GT_days_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_civil__GT_days_A) GetClass__Class() *jrt.Class { return A_arbace_instant_civil__GT_days_A_class }

func (t *A_arbace_instant_civil__GT_days_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_civil__GT_days_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_civil__GT_days_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_civil__GT_days_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_civil__GT_days_A); return ok }

func A_arbace_instant_civil__GT_days_A_Cast(x any) *A_arbace_instant_civil__GT_days_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_civil__GT_days_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_civil__GT_days_A_class)) }; return v }



type A_arbace_instant_construct_calendar_A struct{ jrt.Object }

func (t *A_arbace_instant_construct_calendar_A) Is_Compiler_AOTF10() {}

var A_arbace_instant_construct_calendar_A_fn_class *jrt.Class

var A_arbace_instant_construct_calendar_A_init jrt.ClassInit

func A_arbace_instant_construct_calendar_A_Init() { if !A_arbace_instant_construct_calendar_A_init.Done() { A_arbace_instant_construct_calendar_A_init.Run(A_arbace_instant_construct_calendar_A_clinit) } }

func A_arbace_instant_construct_calendar_A_clinit() { A_arbace_instant_construct_calendar_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_41, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_construct_calendar_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_construct_calendar_A) GetClass__Class() *jrt.Class { return A_arbace_instant_construct_calendar_A_class }

func (t *A_arbace_instant_construct_calendar_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_construct_calendar_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_construct_calendar_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_construct_calendar_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_construct_calendar_A); return ok }

func A_arbace_instant_construct_calendar_A_Cast(x any) *A_arbace_instant_construct_calendar_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_construct_calendar_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_construct_calendar_A_class)) }; return v }



type A_arbace_instant_construct_date_A struct{ jrt.Object }

func (t *A_arbace_instant_construct_date_A) Is_Compiler_AOTF10() {}

var A_arbace_instant_construct_date_A_fn_class *jrt.Class

var A_arbace_instant_construct_date_A_init jrt.ClassInit

func A_arbace_instant_construct_date_A_Init() { if !A_arbace_instant_construct_date_A_init.Done() { A_arbace_instant_construct_date_A_init.Run(A_arbace_instant_construct_date_A_clinit) } }

func A_arbace_instant_construct_date_A_clinit() { A_arbace_instant_construct_date_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_45, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_construct_date_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_construct_date_A) GetClass__Class() *jrt.Class { return A_arbace_instant_construct_date_A_class }

func (t *A_arbace_instant_construct_date_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_construct_date_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_construct_date_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_construct_date_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_construct_date_A); return ok }

func A_arbace_instant_construct_date_A_Cast(x any) *A_arbace_instant_construct_date_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_construct_date_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_construct_date_A_class)) }; return v }



type A_arbace_instant_construct_timestamp_A struct{ jrt.Object }

func (t *A_arbace_instant_construct_timestamp_A) Is_Compiler_AOTF10() {}

var A_arbace_instant_construct_timestamp_A_fn_class *jrt.Class

var A_arbace_instant_construct_timestamp_A_init jrt.ClassInit

func A_arbace_instant_construct_timestamp_A_Init() { if !A_arbace_instant_construct_timestamp_A_init.Done() { A_arbace_instant_construct_timestamp_A_init.Run(A_arbace_instant_construct_timestamp_A_clinit) } }

func A_arbace_instant_construct_timestamp_A_clinit() { A_arbace_instant_construct_timestamp_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_46, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_construct_timestamp_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_construct_timestamp_A) GetClass__Class() *jrt.Class { return A_arbace_instant_construct_timestamp_A_class }

func (t *A_arbace_instant_construct_timestamp_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_construct_timestamp_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_construct_timestamp_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_construct_timestamp_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_construct_timestamp_A); return ok }

func A_arbace_instant_construct_timestamp_A_Cast(x any) *A_arbace_instant_construct_timestamp_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_construct_timestamp_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_construct_timestamp_A_class)) }; return v }



type A_arbace_instant_days__GT_civil_A struct{ jrt.Object }

func (t *A_arbace_instant_days__GT_civil_A) Is_Compiler_AOTF1() {}

var A_arbace_instant_days__GT_civil_A_fn_class *jrt.Class

var A_arbace_instant_days__GT_civil_A_init jrt.ClassInit

func A_arbace_instant_days__GT_civil_A_Init() { if !A_arbace_instant_days__GT_civil_A_init.Done() { A_arbace_instant_days__GT_civil_A_init.Run(A_arbace_instant_days__GT_civil_A_clinit) } }

func A_arbace_instant_days__GT_civil_A_clinit() { A_arbace_instant_days__GT_civil_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_47, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_days__GT_civil_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_days__GT_civil_A) GetClass__Class() *jrt.Class { return A_arbace_instant_days__GT_civil_A_class }

func (t *A_arbace_instant_days__GT_civil_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_days__GT_civil_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_days__GT_civil_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_days__GT_civil_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_days__GT_civil_A); return ok }

func A_arbace_instant_days__GT_civil_A_Cast(x any) *A_arbace_instant_days__GT_civil_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_days__GT_civil_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_days__GT_civil_A_class)) }; return v }



type A_arbace_instant_divisible_QMARK__A struct{ jrt.Object }

func (t *A_arbace_instant_divisible_QMARK__A) Is_Compiler_AOTF2() {}

var A_arbace_instant_divisible_QMARK__A_fn_class *jrt.Class

var A_arbace_instant_divisible_QMARK__A_init jrt.ClassInit

func A_arbace_instant_divisible_QMARK__A_Init() { if !A_arbace_instant_divisible_QMARK__A_init.Done() { A_arbace_instant_divisible_QMARK__A_init.Run(A_arbace_instant_divisible_QMARK__A_clinit) } }

func A_arbace_instant_divisible_QMARK__A_clinit() { A_arbace_instant_divisible_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_48, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_divisible_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_divisible_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_instant_divisible_QMARK__A_class }

func (t *A_arbace_instant_divisible_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_divisible_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_divisible_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_divisible_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_divisible_QMARK__A); return ok }

func A_arbace_instant_divisible_QMARK__A_Cast(x any) *A_arbace_instant_divisible_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_divisible_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_divisible_QMARK__A_class)) }; return v }



type A_arbace_instant_eval783000002_A struct{ jrt.Object }

func A_arbace_instant_eval783000002_A_New() *A_arbace_instant_eval783000002_A { t := &A_arbace_instant_eval783000002_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000002_A) Ctor() {}

func (t *A_arbace_instant_eval783000002_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000002_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000002_A_class }

func (t *A_arbace_instant_eval783000002_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000002_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000002_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000002_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000002_A); return ok }

func A_arbace_instant_eval783000002_A_Cast(x any) *A_arbace_instant_eval783000002_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000002_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000002_A_class)) }; return v }



type A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A struct{ jrt.Object }

func (t *A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A) Is_Compiler_AOTF0() {}

var A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_fn_class *jrt.Class

var A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_init jrt.ClassInit

func A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_Init() { if !A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_init.Done() { A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_init.Run(A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_clinit) } }

func A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_clinit() { A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_49, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_class }

func (t *A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A); return ok }

func A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_Cast(x any) *A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_class)) }; return v }



type A_arbace_instant_eval783000006_A struct{ jrt.Object }

func A_arbace_instant_eval783000006_A_New() *A_arbace_instant_eval783000006_A { t := &A_arbace_instant_eval783000006_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000006_A) Ctor() {}

func (t *A_arbace_instant_eval783000006_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000006_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000006_A_class }

func (t *A_arbace_instant_eval783000006_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000006_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000006_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000006_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000006_A); return ok }

func A_arbace_instant_eval783000006_A_Cast(x any) *A_arbace_instant_eval783000006_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000006_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000006_A_class)) }; return v }



type A_arbace_instant_eval783000006_fn__783000007_A struct{ jrt.Object }

func (t *A_arbace_instant_eval783000006_fn__783000007_A) Is_Compiler_AOTF0() {}

var A_arbace_instant_eval783000006_fn__783000007_A_fn_class *jrt.Class

var A_arbace_instant_eval783000006_fn__783000007_A_init jrt.ClassInit

func A_arbace_instant_eval783000006_fn__783000007_A_Init() { if !A_arbace_instant_eval783000006_fn__783000007_A_init.Done() { A_arbace_instant_eval783000006_fn__783000007_A_init.Run(A_arbace_instant_eval783000006_fn__783000007_A_clinit) } }

func A_arbace_instant_eval783000006_fn__783000007_A_clinit() { A_arbace_instant_eval783000006_fn__783000007_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_55, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_eval783000006_fn__783000007_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000006_fn__783000007_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000006_fn__783000007_A_class }

func (t *A_arbace_instant_eval783000006_fn__783000007_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000006_fn__783000007_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000006_fn__783000007_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000006_fn__783000007_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000006_fn__783000007_A); return ok }

func A_arbace_instant_eval783000006_fn__783000007_A_Cast(x any) *A_arbace_instant_eval783000006_fn__783000007_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000006_fn__783000007_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000006_fn__783000007_A_class)) }; return v }



type A_arbace_instant_eval783000044_A struct{ jrt.Object }

func A_arbace_instant_eval783000044_A_New() *A_arbace_instant_eval783000044_A { t := &A_arbace_instant_eval783000044_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000044_A) Ctor() {}

func (t *A_arbace_instant_eval783000044_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000044_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000044_A_class }

func (t *A_arbace_instant_eval783000044_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000044_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000044_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000044_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000044_A); return ok }

func A_arbace_instant_eval783000044_A_Cast(x any) *A_arbace_instant_eval783000044_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000044_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000044_A_class)) }; return v }



type A_arbace_instant_eval783000044_fn__783000045_A struct{ jrt.Object }

func (t *A_arbace_instant_eval783000044_fn__783000045_A) Is_Compiler_AOTF2() {}

var A_arbace_instant_eval783000044_fn__783000045_A_fn_class *jrt.Class

var A_arbace_instant_eval783000044_fn__783000045_A_init jrt.ClassInit

func A_arbace_instant_eval783000044_fn__783000045_A_Init() { if !A_arbace_instant_eval783000044_fn__783000045_A_init.Done() { A_arbace_instant_eval783000044_fn__783000045_A_init.Run(A_arbace_instant_eval783000044_fn__783000045_A_clinit) } }

func A_arbace_instant_eval783000044_fn__783000045_A_clinit() { A_arbace_instant_eval783000044_fn__783000045_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_56, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_eval783000044_fn__783000045_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000044_fn__783000045_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000044_fn__783000045_A_class }

func (t *A_arbace_instant_eval783000044_fn__783000045_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000044_fn__783000045_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000044_fn__783000045_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000044_fn__783000045_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000044_fn__783000045_A); return ok }

func A_arbace_instant_eval783000044_fn__783000045_A_Cast(x any) *A_arbace_instant_eval783000044_fn__783000045_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000044_fn__783000045_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000044_fn__783000045_A_class)) }; return v }



type A_arbace_instant_eval783000048_A struct{ jrt.Object }

func A_arbace_instant_eval783000048_A_New() *A_arbace_instant_eval783000048_A { t := &A_arbace_instant_eval783000048_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000048_A) Ctor() {}

func (t *A_arbace_instant_eval783000048_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000048_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000048_A_class }

func (t *A_arbace_instant_eval783000048_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000048_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000048_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000048_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000048_A); return ok }

func A_arbace_instant_eval783000048_A_Cast(x any) *A_arbace_instant_eval783000048_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000048_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000048_A_class)) }; return v }



type A_arbace_instant_eval783000048_fn__783000049_A struct{ jrt.Object }

func (t *A_arbace_instant_eval783000048_fn__783000049_A) Is_Compiler_AOTF2() {}

var A_arbace_instant_eval783000048_fn__783000049_A_fn_class *jrt.Class

var A_arbace_instant_eval783000048_fn__783000049_A_init jrt.ClassInit

func A_arbace_instant_eval783000048_fn__783000049_A_Init() { if !A_arbace_instant_eval783000048_fn__783000049_A_init.Done() { A_arbace_instant_eval783000048_fn__783000049_A_init.Run(A_arbace_instant_eval783000048_fn__783000049_A_clinit) } }

func A_arbace_instant_eval783000048_fn__783000049_A_clinit() { A_arbace_instant_eval783000048_fn__783000049_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_57, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_eval783000048_fn__783000049_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000048_fn__783000049_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000048_fn__783000049_A_class }

func (t *A_arbace_instant_eval783000048_fn__783000049_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000048_fn__783000049_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000048_fn__783000049_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000048_fn__783000049_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000048_fn__783000049_A); return ok }

func A_arbace_instant_eval783000048_fn__783000049_A_Cast(x any) *A_arbace_instant_eval783000048_fn__783000049_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000048_fn__783000049_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000048_fn__783000049_A_class)) }; return v }



type A_arbace_instant_eval783000053_A struct{ jrt.Object }

func A_arbace_instant_eval783000053_A_New() *A_arbace_instant_eval783000053_A { t := &A_arbace_instant_eval783000053_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000053_A) Ctor() {}

func (t *A_arbace_instant_eval783000053_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000053_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000053_A_class }

func (t *A_arbace_instant_eval783000053_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000053_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000053_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000053_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000053_A); return ok }

func A_arbace_instant_eval783000053_A_Cast(x any) *A_arbace_instant_eval783000053_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000053_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000053_A_class)) }; return v }



type A_arbace_instant_eval783000053_fn__783000054_A struct{ jrt.Object }

func (t *A_arbace_instant_eval783000053_fn__783000054_A) Is_Compiler_AOTF2() {}

var A_arbace_instant_eval783000053_fn__783000054_A_fn_class *jrt.Class

var A_arbace_instant_eval783000053_fn__783000054_A_init jrt.ClassInit

func A_arbace_instant_eval783000053_fn__783000054_A_Init() { if !A_arbace_instant_eval783000053_fn__783000054_A_init.Done() { A_arbace_instant_eval783000053_fn__783000054_A_init.Run(A_arbace_instant_eval783000053_fn__783000054_A_clinit) } }

func A_arbace_instant_eval783000053_fn__783000054_A_clinit() { A_arbace_instant_eval783000053_fn__783000054_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_58, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_eval783000053_fn__783000054_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000053_fn__783000054_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000053_fn__783000054_A_class }

func (t *A_arbace_instant_eval783000053_fn__783000054_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000053_fn__783000054_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000053_fn__783000054_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000053_fn__783000054_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000053_fn__783000054_A); return ok }

func A_arbace_instant_eval783000053_fn__783000054_A_Cast(x any) *A_arbace_instant_eval783000053_fn__783000054_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000053_fn__783000054_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000053_fn__783000054_A_class)) }; return v }



type A_arbace_instant_eval783000057_A struct{ jrt.Object }

func A_arbace_instant_eval783000057_A_New() *A_arbace_instant_eval783000057_A { t := &A_arbace_instant_eval783000057_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000057_A) Ctor() {}

func (t *A_arbace_instant_eval783000057_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000057_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000057_A_class }

func (t *A_arbace_instant_eval783000057_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000057_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000057_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000057_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000057_A); return ok }

func A_arbace_instant_eval783000057_A_Cast(x any) *A_arbace_instant_eval783000057_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000057_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000057_A_class)) }; return v }



type A_arbace_instant_eval783000057_fn__783000058_A struct{ jrt.Object }

func (t *A_arbace_instant_eval783000057_fn__783000058_A) Is_Compiler_AOTF2() {}

var A_arbace_instant_eval783000057_fn__783000058_A_fn_class *jrt.Class

var A_arbace_instant_eval783000057_fn__783000058_A_init jrt.ClassInit

func A_arbace_instant_eval783000057_fn__783000058_A_Init() { if !A_arbace_instant_eval783000057_fn__783000058_A_init.Done() { A_arbace_instant_eval783000057_fn__783000058_A_init.Run(A_arbace_instant_eval783000057_fn__783000058_A_clinit) } }

func A_arbace_instant_eval783000057_fn__783000058_A_clinit() { A_arbace_instant_eval783000057_fn__783000058_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_59, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_eval783000057_fn__783000058_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000057_fn__783000058_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000057_fn__783000058_A_class }

func (t *A_arbace_instant_eval783000057_fn__783000058_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000057_fn__783000058_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000057_fn__783000058_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000057_fn__783000058_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000057_fn__783000058_A); return ok }

func A_arbace_instant_eval783000057_fn__783000058_A_Cast(x any) *A_arbace_instant_eval783000057_fn__783000058_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000057_fn__783000058_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000057_fn__783000058_A_class)) }; return v }



type A_arbace_instant_eval783000065_A struct{ jrt.Object }

func A_arbace_instant_eval783000065_A_New() *A_arbace_instant_eval783000065_A { t := &A_arbace_instant_eval783000065_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000065_A) Ctor() {}

func (t *A_arbace_instant_eval783000065_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000065_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000065_A_class }

func (t *A_arbace_instant_eval783000065_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000065_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000065_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000065_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000065_A); return ok }

func A_arbace_instant_eval783000065_A_Cast(x any) *A_arbace_instant_eval783000065_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000065_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000065_A_class)) }; return v }



type A_arbace_instant_eval783000065_fn__783000066_A struct{ jrt.Object }

func (t *A_arbace_instant_eval783000065_fn__783000066_A) Is_Compiler_AOTF2() {}

var A_arbace_instant_eval783000065_fn__783000066_A_fn_class *jrt.Class

var A_arbace_instant_eval783000065_fn__783000066_A_init jrt.ClassInit

func A_arbace_instant_eval783000065_fn__783000066_A_Init() { if !A_arbace_instant_eval783000065_fn__783000066_A_init.Done() { A_arbace_instant_eval783000065_fn__783000066_A_init.Run(A_arbace_instant_eval783000065_fn__783000066_A_clinit) } }

func A_arbace_instant_eval783000065_fn__783000066_A_clinit() { A_arbace_instant_eval783000065_fn__783000066_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_60, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_eval783000065_fn__783000066_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000065_fn__783000066_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000065_fn__783000066_A_class }

func (t *A_arbace_instant_eval783000065_fn__783000066_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000065_fn__783000066_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000065_fn__783000066_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000065_fn__783000066_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000065_fn__783000066_A); return ok }

func A_arbace_instant_eval783000065_fn__783000066_A_Cast(x any) *A_arbace_instant_eval783000065_fn__783000066_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000065_fn__783000066_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000065_fn__783000066_A_class)) }; return v }



type A_arbace_instant_eval783000069_A struct{ jrt.Object }

func A_arbace_instant_eval783000069_A_New() *A_arbace_instant_eval783000069_A { t := &A_arbace_instant_eval783000069_A{}; t.Ctor(); return t }

func (t *A_arbace_instant_eval783000069_A) Ctor() {}

func (t *A_arbace_instant_eval783000069_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000069_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000069_A_class }

func (t *A_arbace_instant_eval783000069_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000069_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000069_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000069_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000069_A); return ok }

func A_arbace_instant_eval783000069_A_Cast(x any) *A_arbace_instant_eval783000069_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000069_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000069_A_class)) }; return v }



type A_arbace_instant_eval783000069_fn__783000070_A struct{ jrt.Object }

func (t *A_arbace_instant_eval783000069_fn__783000070_A) Is_Compiler_AOTF2() {}

var A_arbace_instant_eval783000069_fn__783000070_A_fn_class *jrt.Class

var A_arbace_instant_eval783000069_fn__783000070_A_init jrt.ClassInit

func A_arbace_instant_eval783000069_fn__783000070_A_Init() { if !A_arbace_instant_eval783000069_fn__783000070_A_init.Done() { A_arbace_instant_eval783000069_fn__783000070_A_init.Run(A_arbace_instant_eval783000069_fn__783000070_A_clinit) } }

func A_arbace_instant_eval783000069_fn__783000070_A_clinit() { A_arbace_instant_eval783000069_fn__783000070_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_61, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_eval783000069_fn__783000070_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_eval783000069_fn__783000070_A) GetClass__Class() *jrt.Class { return A_arbace_instant_eval783000069_fn__783000070_A_class }

func (t *A_arbace_instant_eval783000069_fn__783000070_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_eval783000069_fn__783000070_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_eval783000069_fn__783000070_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_eval783000069_fn__783000070_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_eval783000069_fn__783000070_A); return ok }

func A_arbace_instant_eval783000069_fn__783000070_A_Cast(x any) *A_arbace_instant_eval783000069_fn__783000070_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_eval783000069_fn__783000070_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_eval783000069_fn__783000070_A_class)) }; return v }



type A_arbace_instant_fail_A struct{ jrt.Object }

func (t *A_arbace_instant_fail_A) Is_Compiler_AOTF3() {}

var A_arbace_instant_fail_A_fn_class *jrt.Class

var A_arbace_instant_fail_A_init jrt.ClassInit

func A_arbace_instant_fail_A_Init() { if !A_arbace_instant_fail_A_init.Done() { A_arbace_instant_fail_A_init.Run(A_arbace_instant_fail_A_clinit) } }

func A_arbace_instant_fail_A_clinit() { A_arbace_instant_fail_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_62, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_fail_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_fail_A) GetClass__Class() *jrt.Class { return A_arbace_instant_fail_A_class }

func (t *A_arbace_instant_fail_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_fail_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_fail_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_fail_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_fail_A); return ok }

func A_arbace_instant_fail_A_Cast(x any) *A_arbace_instant_fail_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_fail_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_fail_A_class)) }; return v }



type A_arbace_instant_fn__783000031_A struct{ jrt.Object }

func (t *A_arbace_instant_fn__783000031_A) Is_Compiler_AOTF0() {}

var A_arbace_instant_fn__783000031_A_fn_class *jrt.Class

var A_arbace_instant_fn__783000031_A_init jrt.ClassInit

func A_arbace_instant_fn__783000031_A_Init() { if !A_arbace_instant_fn__783000031_A_init.Done() { A_arbace_instant_fn__783000031_A_init.Run(A_arbace_instant_fn__783000031_A_clinit) } }

func A_arbace_instant_fn__783000031_A_clinit() { A_arbace_instant_fn__783000031_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_63, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_fn__783000031_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_fn__783000031_A) GetClass__Class() *jrt.Class { return A_arbace_instant_fn__783000031_A_class }

func (t *A_arbace_instant_fn__783000031_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_fn__783000031_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_fn__783000031_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_fn__783000031_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_fn__783000031_A); return ok }

func A_arbace_instant_fn__783000031_A_Cast(x any) *A_arbace_instant_fn__783000031_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_fn__783000031_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_fn__783000031_A_class)) }; return v }



type A_arbace_instant_fn__783000031_fn__783000032_A struct{ jrt.Object; F_dim_norm, F_dim_leap any }

func (t *A_arbace_instant_fn__783000031_fn__783000032_A) Is_Compiler_AOTF2() {}

var A_arbace_instant_fn__783000031_fn__783000032_A_fn_class *jrt.Class

var A_arbace_instant_fn__783000031_fn__783000032_A_init jrt.ClassInit

func A_arbace_instant_fn__783000031_fn__783000032_A_Init() { if !A_arbace_instant_fn__783000031_fn__783000032_A_init.Done() { A_arbace_instant_fn__783000031_fn__783000032_A_init.Run(A_arbace_instant_fn__783000031_fn__783000032_A_clinit) } }

func A_arbace_instant_fn__783000031_fn__783000032_A_clinit() { A_arbace_instant_fn__783000031_fn__783000032_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_64, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_fn__783000031_fn__783000032_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_fn__783000031_fn__783000032_A) GetClass__Class() *jrt.Class { return A_arbace_instant_fn__783000031_fn__783000032_A_class }

func (t *A_arbace_instant_fn__783000031_fn__783000032_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_fn__783000031_fn__783000032_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_fn__783000031_fn__783000032_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_fn__783000031_fn__783000032_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_fn__783000031_fn__783000032_A); return ok }

func A_arbace_instant_fn__783000031_fn__783000032_A_Cast(x any) *A_arbace_instant_fn__783000031_fn__783000032_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_fn__783000031_fn__783000032_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_fn__783000031_fn__783000032_A_class)) }; return v }



type A_arbace_instant_indivisible_QMARK__A struct{ jrt.Object }

func (t *A_arbace_instant_indivisible_QMARK__A) Is_Compiler_AOTF2() {}

var A_arbace_instant_indivisible_QMARK__A_fn_class *jrt.Class

var A_arbace_instant_indivisible_QMARK__A_init jrt.ClassInit

func A_arbace_instant_indivisible_QMARK__A_Init() { if !A_arbace_instant_indivisible_QMARK__A_init.Done() { A_arbace_instant_indivisible_QMARK__A_init.Run(A_arbace_instant_indivisible_QMARK__A_clinit) } }

func A_arbace_instant_indivisible_QMARK__A_clinit() { A_arbace_instant_indivisible_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_65, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_indivisible_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_indivisible_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_instant_indivisible_QMARK__A_class }

func (t *A_arbace_instant_indivisible_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_indivisible_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_indivisible_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_indivisible_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_indivisible_QMARK__A); return ok }

func A_arbace_instant_indivisible_QMARK__A_Cast(x any) *A_arbace_instant_indivisible_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_indivisible_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_indivisible_QMARK__A_class)) }; return v }



type A_arbace_instant_leap_year_QMARK__A struct{ jrt.Object }

func (t *A_arbace_instant_leap_year_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_instant_leap_year_QMARK__A_fn_class *jrt.Class

var A_arbace_instant_leap_year_QMARK__A_init jrt.ClassInit

func A_arbace_instant_leap_year_QMARK__A_Init() { if !A_arbace_instant_leap_year_QMARK__A_init.Done() { A_arbace_instant_leap_year_QMARK__A_init.Run(A_arbace_instant_leap_year_QMARK__A_clinit) } }

func A_arbace_instant_leap_year_QMARK__A_clinit() { A_arbace_instant_leap_year_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_66, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_leap_year_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_leap_year_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_instant_leap_year_QMARK__A_class }

func (t *A_arbace_instant_leap_year_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_leap_year_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_leap_year_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_leap_year_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_leap_year_QMARK__A); return ok }

func A_arbace_instant_leap_year_QMARK__A_Cast(x any) *A_arbace_instant_leap_year_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_leap_year_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_leap_year_QMARK__A_class)) }; return v }



type A_arbace_instant_parse_int_A struct{ jrt.Object }

func (t *A_arbace_instant_parse_int_A) Is_Compiler_AOTF1() {}

var A_arbace_instant_parse_int_A_fn_class *jrt.Class

var A_arbace_instant_parse_int_A_init jrt.ClassInit

func A_arbace_instant_parse_int_A_Init() { if !A_arbace_instant_parse_int_A_init.Done() { A_arbace_instant_parse_int_A_init.Run(A_arbace_instant_parse_int_A_clinit) } }

func A_arbace_instant_parse_int_A_clinit() { A_arbace_instant_parse_int_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_67, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_parse_int_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_parse_int_A) GetClass__Class() *jrt.Class { return A_arbace_instant_parse_int_A_class }

func (t *A_arbace_instant_parse_int_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_parse_int_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_parse_int_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_parse_int_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_parse_int_A); return ok }

func A_arbace_instant_parse_int_A_Cast(x any) *A_arbace_instant_parse_int_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_parse_int_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_parse_int_A_class)) }; return v }



type A_arbace_instant_parse_timestamp_A struct{ jrt.Object }

func (t *A_arbace_instant_parse_timestamp_A) Is_Compiler_AOTF2() {}

var A_arbace_instant_parse_timestamp_A_fn_class *jrt.Class

var A_arbace_instant_parse_timestamp_A_init jrt.ClassInit

func A_arbace_instant_parse_timestamp_A_Init() { if !A_arbace_instant_parse_timestamp_A_init.Done() { A_arbace_instant_parse_timestamp_A_init.Run(A_arbace_instant_parse_timestamp_A_clinit) } }

func A_arbace_instant_parse_timestamp_A_clinit() { A_arbace_instant_parse_timestamp_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_68, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_parse_timestamp_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_parse_timestamp_A) GetClass__Class() *jrt.Class { return A_arbace_instant_parse_timestamp_A_class }

func (t *A_arbace_instant_parse_timestamp_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_parse_timestamp_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_parse_timestamp_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_parse_timestamp_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_parse_timestamp_A); return ok }

func A_arbace_instant_parse_timestamp_A_Cast(x any) *A_arbace_instant_parse_timestamp_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_parse_timestamp_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_parse_timestamp_A_class)) }; return v }



type A_arbace_instant_print_calendar_A struct{ jrt.Object }

func (t *A_arbace_instant_print_calendar_A) Is_Compiler_AOTF2() {}

var A_arbace_instant_print_calendar_A_fn_class *jrt.Class

var A_arbace_instant_print_calendar_A_init jrt.ClassInit

func A_arbace_instant_print_calendar_A_Init() { if !A_arbace_instant_print_calendar_A_init.Done() { A_arbace_instant_print_calendar_A_init.Run(A_arbace_instant_print_calendar_A_clinit) } }

func A_arbace_instant_print_calendar_A_clinit() { A_arbace_instant_print_calendar_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_70, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_print_calendar_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_print_calendar_A) GetClass__Class() *jrt.Class { return A_arbace_instant_print_calendar_A_class }

func (t *A_arbace_instant_print_calendar_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_print_calendar_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_print_calendar_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_print_calendar_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_print_calendar_A); return ok }

func A_arbace_instant_print_calendar_A_Cast(x any) *A_arbace_instant_print_calendar_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_print_calendar_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_print_calendar_A_class)) }; return v }



type A_arbace_instant_print_date_A struct{ jrt.Object }

func (t *A_arbace_instant_print_date_A) Is_Compiler_AOTF2() {}

var A_arbace_instant_print_date_A_fn_class *jrt.Class

var A_arbace_instant_print_date_A_init jrt.ClassInit

func A_arbace_instant_print_date_A_Init() { if !A_arbace_instant_print_date_A_init.Done() { A_arbace_instant_print_date_A_init.Run(A_arbace_instant_print_date_A_clinit) } }

func A_arbace_instant_print_date_A_clinit() { A_arbace_instant_print_date_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_75, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_print_date_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_print_date_A) GetClass__Class() *jrt.Class { return A_arbace_instant_print_date_A_class }

func (t *A_arbace_instant_print_date_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_print_date_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_print_date_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_print_date_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_print_date_A); return ok }

func A_arbace_instant_print_date_A_Cast(x any) *A_arbace_instant_print_date_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_print_date_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_print_date_A_class)) }; return v }



type A_arbace_instant_print_timestamp_A struct{ jrt.Object }

func (t *A_arbace_instant_print_timestamp_A) Is_Compiler_AOTF2() {}

var A_arbace_instant_print_timestamp_A_fn_class *jrt.Class

var A_arbace_instant_print_timestamp_A_init jrt.ClassInit

func A_arbace_instant_print_timestamp_A_Init() { if !A_arbace_instant_print_timestamp_A_init.Done() { A_arbace_instant_print_timestamp_A_init.Run(A_arbace_instant_print_timestamp_A_clinit) } }

func A_arbace_instant_print_timestamp_A_clinit() { A_arbace_instant_print_timestamp_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_77, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_print_timestamp_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_print_timestamp_A) GetClass__Class() *jrt.Class { return A_arbace_instant_print_timestamp_A_class }

func (t *A_arbace_instant_print_timestamp_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_print_timestamp_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_print_timestamp_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_print_timestamp_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_print_timestamp_A); return ok }

func A_arbace_instant_print_timestamp_A_Cast(x any) *A_arbace_instant_print_timestamp_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_print_timestamp_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_print_timestamp_A_class)) }; return v }



type A_arbace_instant_read_instant_calendar_A struct{ jrt.Object }

func (t *A_arbace_instant_read_instant_calendar_A) Is_Compiler_AOTF1() {}

var A_arbace_instant_read_instant_calendar_A_fn_class *jrt.Class

var A_arbace_instant_read_instant_calendar_A_init jrt.ClassInit

func A_arbace_instant_read_instant_calendar_A_Init() { if !A_arbace_instant_read_instant_calendar_A_init.Done() { A_arbace_instant_read_instant_calendar_A_init.Run(A_arbace_instant_read_instant_calendar_A_clinit) } }

func A_arbace_instant_read_instant_calendar_A_clinit() { A_arbace_instant_read_instant_calendar_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_80, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_read_instant_calendar_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_read_instant_calendar_A) GetClass__Class() *jrt.Class { return A_arbace_instant_read_instant_calendar_A_class }

func (t *A_arbace_instant_read_instant_calendar_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_read_instant_calendar_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_read_instant_calendar_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_read_instant_calendar_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_read_instant_calendar_A); return ok }

func A_arbace_instant_read_instant_calendar_A_Cast(x any) *A_arbace_instant_read_instant_calendar_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_read_instant_calendar_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_read_instant_calendar_A_class)) }; return v }



type A_arbace_instant_read_instant_date_A struct{ jrt.Object }

func (t *A_arbace_instant_read_instant_date_A) Is_Compiler_AOTF1() {}

var A_arbace_instant_read_instant_date_A_fn_class *jrt.Class

var A_arbace_instant_read_instant_date_A_init jrt.ClassInit

func A_arbace_instant_read_instant_date_A_Init() { if !A_arbace_instant_read_instant_date_A_init.Done() { A_arbace_instant_read_instant_date_A_init.Run(A_arbace_instant_read_instant_date_A_clinit) } }

func A_arbace_instant_read_instant_date_A_clinit() { A_arbace_instant_read_instant_date_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_81, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_read_instant_date_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_read_instant_date_A) GetClass__Class() *jrt.Class { return A_arbace_instant_read_instant_date_A_class }

func (t *A_arbace_instant_read_instant_date_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_read_instant_date_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_read_instant_date_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_read_instant_date_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_read_instant_date_A); return ok }

func A_arbace_instant_read_instant_date_A_Cast(x any) *A_arbace_instant_read_instant_date_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_read_instant_date_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_read_instant_date_A_class)) }; return v }



type A_arbace_instant_read_instant_timestamp_A struct{ jrt.Object }

func (t *A_arbace_instant_read_instant_timestamp_A) Is_Compiler_AOTF1() {}

var A_arbace_instant_read_instant_timestamp_A_fn_class *jrt.Class

var A_arbace_instant_read_instant_timestamp_A_init jrt.ClassInit

func A_arbace_instant_read_instant_timestamp_A_Init() { if !A_arbace_instant_read_instant_timestamp_A_init.Done() { A_arbace_instant_read_instant_timestamp_A_init.Run(A_arbace_instant_read_instant_timestamp_A_clinit) } }

func A_arbace_instant_read_instant_timestamp_A_clinit() { A_arbace_instant_read_instant_timestamp_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_82, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_read_instant_timestamp_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_read_instant_timestamp_A) GetClass__Class() *jrt.Class { return A_arbace_instant_read_instant_timestamp_A_class }

func (t *A_arbace_instant_read_instant_timestamp_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_read_instant_timestamp_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_read_instant_timestamp_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_read_instant_timestamp_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_read_instant_timestamp_A); return ok }

func A_arbace_instant_read_instant_timestamp_A_Cast(x any) *A_arbace_instant_read_instant_timestamp_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_read_instant_timestamp_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_read_instant_timestamp_A_class)) }; return v }



type A_arbace_instant_validated_A struct{ jrt.Object }

func (t *A_arbace_instant_validated_A) Is_Compiler_AOTF1() {}

var A_arbace_instant_validated_A_fn_class *jrt.Class

var A_arbace_instant_validated_A_init jrt.ClassInit

func A_arbace_instant_validated_A_Init() { if !A_arbace_instant_validated_A_init.Done() { A_arbace_instant_validated_A_init.Run(A_arbace_instant_validated_A_clinit) } }

func A_arbace_instant_validated_A_clinit() { A_arbace_instant_validated_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_83, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_validated_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_validated_A) GetClass__Class() *jrt.Class { return A_arbace_instant_validated_A_class }

func (t *A_arbace_instant_validated_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_validated_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_validated_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_validated_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_validated_A); return ok }

func A_arbace_instant_validated_A_Cast(x any) *A_arbace_instant_validated_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_validated_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_validated_A_class)) }; return v }



type A_arbace_instant_validated_fn__783000035_A struct{ jrt.Object; F_new_instance any }

func (t *A_arbace_instant_validated_fn__783000035_A) Is_Compiler_AOTF10() {}

var A_arbace_instant_validated_fn__783000035_A_fn_class *jrt.Class

var A_arbace_instant_validated_fn__783000035_A_init jrt.ClassInit

func A_arbace_instant_validated_fn__783000035_A_Init() { if !A_arbace_instant_validated_fn__783000035_A_init.Done() { A_arbace_instant_validated_fn__783000035_A_init.Run(A_arbace_instant_validated_fn__783000035_A_clinit) } }

func A_arbace_instant_validated_fn__783000035_A_clinit() { A_arbace_instant_validated_fn__783000035_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_84, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_validated_fn__783000035_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_validated_fn__783000035_A) GetClass__Class() *jrt.Class { return A_arbace_instant_validated_fn__783000035_A_class }

func (t *A_arbace_instant_validated_fn__783000035_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_validated_fn__783000035_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_validated_fn__783000035_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_validated_fn__783000035_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_validated_fn__783000035_A); return ok }

func A_arbace_instant_validated_fn__783000035_A_Cast(x any) *A_arbace_instant_validated_fn__783000035_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_validated_fn__783000035_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_validated_fn__783000035_A_class)) }; return v }



type A_arbace_instant_verify_A struct{ jrt.Object }

func (t *A_arbace_instant_verify_A) Is_Compiler_AOTF4() {}

func (t *A_arbace_instant_verify_A) Is_Compiler_AOTF3() {}

var A_arbace_instant_verify_A_fn_class *jrt.Class

var A_arbace_instant_verify_A_init jrt.ClassInit

func A_arbace_instant_verify_A_Init() { if !A_arbace_instant_verify_A_init.Done() { A_arbace_instant_verify_A_init.Run(A_arbace_instant_verify_A_clinit) } }

func A_arbace_instant_verify_A_clinit() { A_arbace_instant_verify_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_94, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_verify_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_verify_A) GetClass__Class() *jrt.Class { return A_arbace_instant_verify_A_class }

func (t *A_arbace_instant_verify_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_verify_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_verify_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_verify_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_verify_A); return ok }

func A_arbace_instant_verify_A_Cast(x any) *A_arbace_instant_verify_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_verify_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_verify_A_class)) }; return v }



type A_arbace_instant_zero_fill_right_A struct{ jrt.Object }

func (t *A_arbace_instant_zero_fill_right_A) Is_Compiler_AOTF2() {}

var A_arbace_instant_zero_fill_right_A_fn_class *jrt.Class

var A_arbace_instant_zero_fill_right_A_init jrt.ClassInit

func A_arbace_instant_zero_fill_right_A_Init() { if !A_arbace_instant_zero_fill_right_A_init.Done() { A_arbace_instant_zero_fill_right_A_init.Run(A_arbace_instant_zero_fill_right_A_clinit) } }

func A_arbace_instant_zero_fill_right_A_clinit() { A_arbace_instant_zero_fill_right_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_96, lang.Compiler_AOTFn_class) }

func (t *A_arbace_instant_zero_fill_right_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant_zero_fill_right_A) GetClass__Class() *jrt.Class { return A_arbace_instant_zero_fill_right_A_class }

func (t *A_arbace_instant_zero_fill_right_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant_zero_fill_right_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant_zero_fill_right_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant_zero_fill_right_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant_zero_fill_right_A); return ok }

func A_arbace_instant_zero_fill_right_A_Cast(x any) *A_arbace_instant_zero_fill_right_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant_zero_fill_right_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant_zero_fill_right_A_class)) }; return v }
