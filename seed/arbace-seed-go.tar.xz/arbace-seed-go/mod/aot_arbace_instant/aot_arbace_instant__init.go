//line aot_arbace_instant__init.ae:1
package aot_arbace_instant

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_instant__init_A_Load__O() any { A_arbace_instant__init_A_Init(); A_arbace_instant__init_A_Unit0__O(); A_arbace_instant__init_A_Unit1__O(); A_arbace_instant__init_A_Unit2__O(); A_arbace_instant__init_A_Unit3__O(); A_arbace_instant__init_A_Unit4__O(); A_arbace_instant__init_A_Unit5__O(); A_arbace_instant__init_A_Unit6__O(); A_arbace_instant__init_A_Unit7__O(); A_arbace_instant__init_A_Unit8__O(); A_arbace_instant__init_A_Unit9__O(); A_arbace_instant__init_A_Unit10__O(); A_arbace_instant__init_A_Unit11__O(); A_arbace_instant__init_A_Unit12__O(); A_arbace_instant__init_A_Unit13__O(); A_arbace_instant__init_A_Unit14__O(); A_arbace_instant__init_A_Unit15__O(); A_arbace_instant__init_A_Unit16__O(); A_arbace_instant__init_A_Unit17__O(); A_arbace_instant__init_A_Unit18__O(); A_arbace_instant__init_A_Unit19__O(); A_arbace_instant__init_A_Unit20__O(); A_arbace_instant__init_A_Unit21__O(); A_arbace_instant__init_A_Unit22__O(); A_arbace_instant__init_A_Unit23__O(); A_arbace_instant__init_A_Unit24__O(); A_arbace_instant__init_A_Unit25__O(); A_arbace_instant__init_A_Unit26__O(); A_arbace_instant__init_A_Unit27__O(); A_arbace_instant__init_A_Unit28__O(); A_arbace_instant__init_A_Unit29__O(); A_arbace_instant__init_A_Unit30__O(); A_arbace_instant__init_A_Unit31__O(); A_arbace_instant__init_A_Unit32__O(); A_arbace_instant__init_A_Unit33__O(); A_arbace_instant__init_A_Unit34__O(); A_arbace_instant__init_A_Unit35__O(); A_arbace_instant__init_A_Unit36__O(); return nil }















func A_arbace_instant__init_A_Unit0__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(21, 1); return lang.IFn_Cast(jrt.NN(A_arbace_instant__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_instant__init_A_const_1) }
//line :21:1
func A_arbace_instant__init_A_Unit1__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(21, 1); var tmp1 any = A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_New(); var tmp2 *jrt.Class; A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_Init(); tmp2 = A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :21:1
func A_arbace_instant__init_A_Unit2__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(21, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_instant__init_A_const_1)).Equals_O__Z(A_arbace_instant__init_A_const_2) { return nil } else { var tmp1 any = A_arbace_instant_eval783000006_fn__783000007_A_New(); var tmp2 *jrt.Class; A_arbace_instant_eval783000006_fn__783000007_A_Init(); tmp2 = A_arbace_instant_eval783000006_fn__783000007_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_instant__init_A_Unit3__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(25, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_3; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; return jrt.NN(tmp1).Set_O__O(tmp2.Ref()) }




func A_arbace_instant__init_A_Unit4__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(30, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_4; var tmp2 any = A_arbace_instant_fail_A_New(); var tmp3 *jrt.Class; A_arbace_instant_fail_A_Init(); tmp3 = A_arbace_instant_fail_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_5)); return A_arbace_instant__init_A_const_4.Ref() }
//line :30:1
func A_arbace_instant__init_A_Unit5__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(30, 1); jrt.NN(A_arbace_instant__init_A_const_4).SetMacro__V(); return nil }
//line :30:1
func A_arbace_instant__init_A_Unit6__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(30, 1); return A_arbace_instant__init_A_const_4.Ref() }



func A_arbace_instant__init_A_Unit7__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(34, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_6; var tmp2 any = A_arbace_instant_verify_A_New(); var tmp3 *jrt.Class; A_arbace_instant_verify_A_Init(); tmp3 = A_arbace_instant_verify_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_7)); return A_arbace_instant__init_A_const_6.Ref() }
//line :34:1
func A_arbace_instant__init_A_Unit8__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(34, 1); jrt.NN(A_arbace_instant__init_A_const_6).SetMacro__V(); return nil }
//line :34:1
func A_arbace_instant__init_A_Unit9__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(34, 1); return A_arbace_instant__init_A_const_6.Ref() }



func A_arbace_instant__init_A_Unit10__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(38, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_8; var tmp2 any = A_arbace_instant_divisible_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_instant_divisible_QMARK__A_Init(); tmp3 = A_arbace_instant_divisible_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_9)); return A_arbace_instant__init_A_const_8.Ref() }



func A_arbace_instant__init_A_Unit11__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(42, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_10; var tmp2 any = A_arbace_instant_indivisible_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_instant_indivisible_QMARK__A_Init(); tmp3 = A_arbace_instant_indivisible_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_11)); return A_arbace_instant__init_A_const_10.Ref() }






func A_arbace_instant__init_A_Unit12__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(49, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_12; var tmp2 any = A_arbace_instant_parse_int_A_New(); var tmp3 *jrt.Class; A_arbace_instant_parse_int_A_Init(); tmp3 = A_arbace_instant_parse_int_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_13)); return A_arbace_instant__init_A_const_12.Ref() }


func A_arbace_instant__init_A_Unit13__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(52, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_14; var tmp2 any = A_arbace_instant_zero_fill_right_A_New(); var tmp3 *jrt.Class; A_arbace_instant_zero_fill_right_A_Init(); tmp3 = A_arbace_instant_zero_fill_right_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_15)); return A_arbace_instant__init_A_const_14.Ref() }







func A_arbace_instant__init_A_Unit14__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(60, 1); jrt.NN(A_arbace_instant__init_A_const_16).BindRoot_O__V(A_arbace_instant__init_A_const_17); var tmp1 *lang.Var = A_arbace_instant__init_A_const_16; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_18)); return A_arbace_instant__init_A_const_16.Ref() }


func A_arbace_instant__init_A_Unit15__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(63, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_19; var tmp2 any = A_arbace_instant_parse_timestamp_A_New(); var tmp3 *jrt.Class; A_arbace_instant_parse_timestamp_A_Init(); tmp3 = A_arbace_instant_parse_timestamp_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_19; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_20)); return A_arbace_instant__init_A_const_19.Ref() }








































































func A_arbace_instant__init_A_Unit16__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(136, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_21; var tmp2 any = A_arbace_instant_leap_year_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_instant_leap_year_QMARK__A_Init(); tmp3 = A_arbace_instant_leap_year_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_21; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_22)); return A_arbace_instant__init_A_const_21.Ref() }





func A_arbace_instant__init_A_Unit17__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(142, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_23; var tmp2 any = A_arbace_instant_fn__783000031_A_New(); var tmp3 *jrt.Class; A_arbace_instant_fn__783000031_A_Init(); tmp3 = A_arbace_instant_fn__783000031_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_instant__init_A_const_23; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_24)); return A_arbace_instant__init_A_const_23.Ref() }





func A_arbace_instant__init_A_Unit18__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(148, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_25; var tmp2 any = A_arbace_instant_validated_A_New(); var tmp3 *jrt.Class; A_arbace_instant_validated_A_Init(); tmp3 = A_arbace_instant_validated_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_25; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_26)); return A_arbace_instant__init_A_const_25.Ref() }
























func A_arbace_instant__init_A_Unit19__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(173, 1); jrt.NN(A_arbace_instant__init_A_const_27).BindRoot_O__V(A_arbace_instant__init_A_const_28); var tmp1 *lang.Var = A_arbace_instant__init_A_const_27; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_29)); return A_arbace_instant__init_A_const_27.Ref() }




func A_arbace_instant__init_A_Unit20__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(178, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_30; var tmp2 any = A_arbace_instant_days__GT_civil_A_New(); var tmp3 *jrt.Class; A_arbace_instant_days__GT_civil_A_Init(); tmp3 = A_arbace_instant_days__GT_civil_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_30; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_31)); return A_arbace_instant__init_A_const_30.Ref() }






















func A_arbace_instant__init_A_Unit21__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(201, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_32; var tmp2 any = A_arbace_instant_civil__GT_days_A_New(); var tmp3 *jrt.Class; A_arbace_instant_civil__GT_days_A_Init(); tmp3 = A_arbace_instant_civil__GT_days_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_32; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_33)); return A_arbace_instant__init_A_const_32.Ref() }
















func A_arbace_instant__init_A_Unit22__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(218, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_34; var tmp2 any = A_arbace_instant_print_date_A_New(); var tmp3 *jrt.Class; A_arbace_instant_print_date_A_Init(); tmp3 = A_arbace_instant_print_date_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_34; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_35)); return A_arbace_instant__init_A_const_34.Ref() }












func A_arbace_instant__init_A_Unit23__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(231, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_instant__init_A_const_36).GetRawRoot__O()); var tmp2 any = A_arbace_instant__init_A_const_37.Ref(); var tmp3 any = A_arbace_instant_eval783000044_fn__783000045_A_New(); var tmp4 *jrt.Class; A_arbace_instant_eval783000044_fn__783000045_A_Init(); tmp4 = A_arbace_instant_eval783000044_fn__783000045_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_instant__init_A_Unit24__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(235, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_instant__init_A_const_38).GetRawRoot__O()); var tmp2 any = A_arbace_instant__init_A_const_37.Ref(); var tmp3 any = A_arbace_instant_eval783000048_fn__783000049_A_New(); var tmp4 *jrt.Class; A_arbace_instant_eval783000048_fn__783000049_A_Init(); tmp4 = A_arbace_instant_eval783000048_fn__783000049_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_instant__init_A_Unit25__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(239, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_39; var tmp2 any = A_arbace_instant_print_calendar_A_New(); var tmp3 *jrt.Class; A_arbace_instant_print_calendar_A_Init(); tmp3 = A_arbace_instant_print_calendar_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_39; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_40)); return A_arbace_instant__init_A_const_39.Ref() }











func A_arbace_instant__init_A_Unit26__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(251, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_instant__init_A_const_36).GetRawRoot__O()); var tmp2 any = A_arbace_instant__init_A_const_41.Ref(); var tmp3 any = A_arbace_instant_eval783000053_fn__783000054_A_New(); var tmp4 *jrt.Class; A_arbace_instant_eval783000053_fn__783000054_A_Init(); tmp4 = A_arbace_instant_eval783000053_fn__783000054_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_instant__init_A_Unit27__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(255, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_instant__init_A_const_38).GetRawRoot__O()); var tmp2 any = A_arbace_instant__init_A_const_41.Ref(); var tmp3 any = A_arbace_instant_eval783000057_fn__783000058_A_New(); var tmp4 *jrt.Class; A_arbace_instant_eval783000057_fn__783000058_A_Init(); tmp4 = A_arbace_instant_eval783000057_fn__783000058_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_instant__init_A_Unit28__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(259, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_42; var tmp2 any = A_arbace_instant_print_timestamp_A_New(); var tmp3 *jrt.Class; A_arbace_instant_print_timestamp_A_Init(); tmp3 = A_arbace_instant_print_timestamp_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_42; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_43)); return A_arbace_instant__init_A_const_42.Ref() }















func A_arbace_instant__init_A_Unit29__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(275, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_instant__init_A_const_36).GetRawRoot__O()); var tmp2 any = A_arbace_instant__init_A_const_44.Ref(); var tmp3 any = A_arbace_instant_eval783000065_fn__783000066_A_New(); var tmp4 *jrt.Class; A_arbace_instant_eval783000065_fn__783000066_A_Init(); tmp4 = A_arbace_instant_eval783000065_fn__783000066_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_instant__init_A_Unit30__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(279, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_instant__init_A_const_38).GetRawRoot__O()); var tmp2 any = A_arbace_instant__init_A_const_44.Ref(); var tmp3 any = A_arbace_instant_eval783000069_fn__783000070_A_New(); var tmp4 *jrt.Class; A_arbace_instant_eval783000069_fn__783000070_A_Init(); tmp4 = A_arbace_instant_eval783000069_fn__783000070_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_instant__init_A_Unit31__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(286, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_45; var tmp2 any = A_arbace_instant_construct_date_A_New(); var tmp3 *jrt.Class; A_arbace_instant_construct_date_A_Init(); tmp3 = A_arbace_instant_construct_date_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_45; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_46)); return A_arbace_instant__init_A_const_45.Ref() }









func A_arbace_instant__init_A_Unit32__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(296, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_47; var tmp2 any = A_arbace_instant_read_instant_date_A_New(); var tmp3 *jrt.Class; A_arbace_instant_read_instant_date_A_Init(); tmp3 = A_arbace_instant_read_instant_date_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_47; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_48)); return A_arbace_instant__init_A_const_47.Ref() }






func A_arbace_instant__init_A_Unit33__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(303, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_49; var tmp2 any = A_arbace_instant_construct_calendar_A_New(); var tmp3 *jrt.Class; A_arbace_instant_construct_calendar_A_Init(); tmp3 = A_arbace_instant_construct_calendar_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_49; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_50)); return A_arbace_instant__init_A_const_49.Ref() }












func A_arbace_instant__init_A_Unit34__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(316, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_51; var tmp2 any = A_arbace_instant_construct_timestamp_A_New(); var tmp3 *jrt.Class; A_arbace_instant_construct_timestamp_A_Init(); tmp3 = A_arbace_instant_construct_timestamp_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_51; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_52)); return A_arbace_instant__init_A_const_51.Ref() }











func A_arbace_instant__init_A_Unit35__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(328, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_53; var tmp2 any = A_arbace_instant_read_instant_calendar_A_New(); var tmp3 *jrt.Class; A_arbace_instant_read_instant_calendar_A_Init(); tmp3 = A_arbace_instant_read_instant_calendar_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_53; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_54)); return A_arbace_instant__init_A_const_53.Ref() }






func A_arbace_instant__init_A_Unit36__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(335, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_55; var tmp2 any = A_arbace_instant_read_instant_timestamp_A_New(); var tmp3 *jrt.Class; A_arbace_instant_read_instant_timestamp_A_Init(); tmp3 = A_arbace_instant_read_instant_timestamp_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_55; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_56)); return A_arbace_instant__init_A_const_55.Ref() }



type A_arbace_instant__init_A struct{ jrt.Object }

var A_arbace_instant__init_A_const_0 *lang.Var

var A_arbace_instant__init_A_const_1 any

var A_arbace_instant__init_A_const_2 any

var A_arbace_instant__init_A_const_3 *lang.Var

var A_arbace_instant__init_A_const_4 *lang.Var

var A_arbace_instant__init_A_const_5 any

var A_arbace_instant__init_A_const_6 *lang.Var

var A_arbace_instant__init_A_const_7 any

var A_arbace_instant__init_A_const_8 *lang.Var

var A_arbace_instant__init_A_const_9 any

var A_arbace_instant__init_A_const_10 *lang.Var

var A_arbace_instant__init_A_const_11 any

var A_arbace_instant__init_A_const_12 *lang.Var

var A_arbace_instant__init_A_const_13 any

var A_arbace_instant__init_A_const_14 *lang.Var

var A_arbace_instant__init_A_const_15 any

var A_arbace_instant__init_A_const_16 *lang.Var

var A_arbace_instant__init_A_const_17 any

var A_arbace_instant__init_A_const_18 any

var A_arbace_instant__init_A_const_19 *lang.Var

var A_arbace_instant__init_A_const_20 any

var A_arbace_instant__init_A_const_21 *lang.Var

var A_arbace_instant__init_A_const_22 any

var A_arbace_instant__init_A_const_23 *lang.Var

var A_arbace_instant__init_A_const_24 any

var A_arbace_instant__init_A_const_25 *lang.Var

var A_arbace_instant__init_A_const_26 any

var A_arbace_instant__init_A_const_27 *lang.Var

var A_arbace_instant__init_A_const_28 any

var A_arbace_instant__init_A_const_29 any

var A_arbace_instant__init_A_const_30 *lang.Var

var A_arbace_instant__init_A_const_31 any

var A_arbace_instant__init_A_const_32 *lang.Var

var A_arbace_instant__init_A_const_33 any

var A_arbace_instant__init_A_const_34 *lang.Var

var A_arbace_instant__init_A_const_35 any

var A_arbace_instant__init_A_const_36 *lang.Var

var A_arbace_instant__init_A_const_37 *jrt.Class

var A_arbace_instant__init_A_const_38 *lang.Var

var A_arbace_instant__init_A_const_39 *lang.Var

var A_arbace_instant__init_A_const_40 any

var A_arbace_instant__init_A_const_41 *jrt.Class

var A_arbace_instant__init_A_const_42 *lang.Var

var A_arbace_instant__init_A_const_43 any

var A_arbace_instant__init_A_const_44 *jrt.Class

var A_arbace_instant__init_A_const_45 *lang.Var

var A_arbace_instant__init_A_const_46 any

var A_arbace_instant__init_A_const_47 *lang.Var

var A_arbace_instant__init_A_const_48 any

var A_arbace_instant__init_A_const_49 *lang.Var

var A_arbace_instant__init_A_const_50 any

var A_arbace_instant__init_A_const_51 *lang.Var

var A_arbace_instant__init_A_const_52 any

var A_arbace_instant__init_A_const_53 *lang.Var

var A_arbace_instant__init_A_const_54 any

var A_arbace_instant__init_A_const_55 *lang.Var

var A_arbace_instant__init_A_const_56 any

var A_arbace_instant__init_A_init jrt.ClassInit

func A_arbace_instant__init_A_Init() { if !A_arbace_instant__init_A_init.Done() { A_arbace_instant__init_A_init.Run(A_arbace_instant__init_A_clinit) } }

func A_arbace_instant__init_A_clinit() { A_arbace_instant__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_97); A_arbace_instant__init_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref(); A_arbace_instant__init_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_instant__init_A_const_3 = lang.RT_Var_String_String__Var(Lit_0, Lit_98); A_arbace_instant__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_5, Lit_13); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_99).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_instant__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_100).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_101).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(30).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), Lit_105)); A_arbace_instant__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_5, Lit_14); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_99).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_instant__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_100).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_101).Ref()), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(34).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), Lit_105)); A_arbace_instant__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_5, Lit_18); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_99).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_instant__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_100).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_107).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_108).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(38).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), Lit_105)); A_arbace_instant__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_5, Lit_24); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_99).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_instant__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_100).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_107).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_108).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(42).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), Lit_105)); A_arbace_instant__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_5, Lit_22); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_99).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_instant__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_100).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_109)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_110).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_111).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(49).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), Lit_105)); A_arbace_instant__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_5, Lit_23); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_99).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_instant__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_100).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_109)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_110).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_111).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_112).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(52).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), Lit_105)); A_arbace_instant__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_5, Lit_21); A_arbace_instant__init_A_const_17 = jrt.Pattern_Compile_String__Pattern(Lit_113).Ref(); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_99).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_instant__init_A_const_18 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(60).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), Lit_105)); A_arbace_instant__init_A_const_19 = lang.RT_Var_String_String__Var(Lit_5, Lit_35); A_arbace_instant__init_A_const_20 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_100).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_114).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_115)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_110).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_116).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_117).Ref(), Lit_118, lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(63).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), Lit_105)); A_arbace_instant__init_A_const_21 = lang.RT_Var_String_String__Var(Lit_5, Lit_27); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_99).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_instant__init_A_const_22 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_100).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_119).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(136).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), Lit_105)); A_arbace_instant__init_A_const_23 = lang.RT_Var_String_String__Var(Lit_5, Lit_26); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_99).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_instant__init_A_const_24 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(142).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), Lit_105)); A_arbace_instant__init_A_const_25 = lang.RT_Var_String_String__Var(Lit_5, Lit_36); A_arbace_instant__init_A_const_26 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_100).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_120).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_117).Ref(), Lit_121, lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(148).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), Lit_105)); A_arbace_instant__init_A_const_27 = lang.RT_Var_String_String__Var(Lit_5, Lit_28); A_arbace_instant__init_A_const_28 = jrt.Long_ValueOf_J__Long(-141427).Ref(); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_99).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_instant__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(173).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), Lit_105, lang.RT_Keyword_String_String__Keyword(nil, Lit_117).Ref(), Lit_122)); A_arbace_instant__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_5, Lit_29); var tmp31 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_99).Ref(); var tmp32 *jrt.Boolean; jrt.Boolean_Init(); tmp32 = jrt.Boolean_TRUE; var tmp33 any = tmp32.Ref(); A_arbace_instant__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp33, lang.RT_Keyword_String_String__Keyword(nil, Lit_100).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_123).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_117).Ref(), Lit_124, lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(178).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), Lit_105)); A_arbace_instant__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_5, Lit_34); var tmp34 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_99).Ref(); var tmp35 *jrt.Boolean; jrt.Boolean_Init(); tmp35 = jrt.Boolean_TRUE; var tmp36 any = tmp35.Ref(); A_arbace_instant__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, tmp36, lang.RT_Keyword_String_String__Keyword(nil, Lit_100).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_125).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_126).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_127).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_117).Ref(), Lit_128, lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(201).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), Lit_105)); A_arbace_instant__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_5, Lit_31); var tmp37 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_99).Ref(); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; var tmp39 any = tmp38.Ref(); A_arbace_instant__init_A_const_35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, lang.RT_Keyword_String_String__Keyword(nil, Lit_100).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_127)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_110).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_51).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_129)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_110).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_130).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_117).Ref(), Lit_131, lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(218).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), Lit_105)); A_arbace_instant__init_A_const_36 = lang.RT_Var_String_String__Var(Lit_0, Lit_132); A_arbace_instant__init_A_const_37 = lang.RT_ClassForNameNonLoading_String__Class(Lit_51); A_arbace_instant__init_A_const_38 = lang.RT_Var_String_String__Var(Lit_0, Lit_133); A_arbace_instant__init_A_const_39 = lang.RT_Var_String_String__Var(Lit_5, Lit_32); var tmp40 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_99).Ref(); var tmp41 *jrt.Boolean; jrt.Boolean_Init(); tmp41 = jrt.Boolean_TRUE; var tmp42 any = tmp41.Ref(); A_arbace_instant__init_A_const_40 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp42, lang.RT_Keyword_String_String__Keyword(nil, Lit_100).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_134)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_110).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_50).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_129)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_110).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_130).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_117).Ref(), Lit_135, lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(239).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), Lit_105)); A_arbace_instant__init_A_const_41 = lang.RT_ClassForNameNonLoading_String__Class(Lit_50); A_arbace_instant__init_A_const_42 = lang.RT_Var_String_String__Var(Lit_5, Lit_33); var tmp43 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_99).Ref(); var tmp44 *jrt.Boolean; jrt.Boolean_Init(); tmp44 = jrt.Boolean_TRUE; var tmp45 any = tmp44.Ref(); A_arbace_instant__init_A_const_43 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp43, tmp45, lang.RT_Keyword_String_String__Keyword(nil, Lit_100).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_136)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_110).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_54).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_129)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_110).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_130).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_117).Ref(), Lit_137, lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(259).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), Lit_105)); A_arbace_instant__init_A_const_44 = lang.RT_ClassForNameNonLoading_String__Class(Lit_54); A_arbace_instant__init_A_const_45 = lang.RT_Var_String_String__Var(Lit_5, Lit_37); var tmp46 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_99).Ref(); var tmp47 *jrt.Boolean; jrt.Boolean_Init(); tmp47 = jrt.Boolean_TRUE; var tmp48 any = tmp47.Ref(); A_arbace_instant__init_A_const_46 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp46, tmp48, lang.RT_Keyword_String_String__Keyword(nil, Lit_100).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_138).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_139).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_140).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_141).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_142).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_143).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_144).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_145).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_146).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_147).Ref()))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_117).Ref(), Lit_148, lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(286).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), Lit_105)); A_arbace_instant__init_A_const_47 = lang.RT_Var_String_String__Var(Lit_5, Lit_149); A_arbace_instant__init_A_const_48 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_100).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_115)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_110).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_116).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_117).Ref(), Lit_150, lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(296).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), Lit_105)); A_arbace_instant__init_A_const_49 = lang.RT_Var_String_String__Var(Lit_5, Lit_38); var tmp49 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_99).Ref(); var tmp50 *jrt.Boolean; jrt.Boolean_Init(); tmp50 = jrt.Boolean_TRUE; var tmp51 any = tmp50.Ref(); A_arbace_instant__init_A_const_50 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp49, tmp51, lang.RT_Keyword_String_String__Keyword(nil, Lit_100).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_138).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_139).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_140).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_141).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_142).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_143).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_144).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_145).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_146).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_147).Ref()))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_110).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_52).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_117).Ref(), Lit_151, lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(303).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), Lit_105)); A_arbace_instant__init_A_const_51 = lang.RT_Var_String_String__Var(Lit_5, Lit_39); var tmp52 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_99).Ref(); var tmp53 *jrt.Boolean; jrt.Boolean_Init(); tmp53 = jrt.Boolean_TRUE; var tmp54 any = tmp53.Ref(); A_arbace_instant__init_A_const_52 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp52, tmp54, lang.RT_Keyword_String_String__Keyword(nil, Lit_100).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_138).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_139).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_140).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_141).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_142).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_143).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_144).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_145).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_146).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_147).Ref()))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_117).Ref(), Lit_152, lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(316).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), Lit_105)); A_arbace_instant__init_A_const_53 = lang.RT_Var_String_String__Var(Lit_5, Lit_153); A_arbace_instant__init_A_const_54 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_100).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_115)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_110).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_116).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_117).Ref(), Lit_154, lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(328).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), Lit_105)); A_arbace_instant__init_A_const_55 = lang.RT_Var_String_String__Var(Lit_5, Lit_155); A_arbace_instant__init_A_const_56 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_100).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_115)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_110).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_116).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_117).Ref(), Lit_156, lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(335).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), Lit_105)) }

func A_arbace_instant__init_A_New() *A_arbace_instant__init_A { A_arbace_instant__init_A_Init(); t := &A_arbace_instant__init_A{}; t.Ctor(); return t }

func (t *A_arbace_instant__init_A) Ctor() {}

func (t *A_arbace_instant__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant__init_A) GetClass__Class() *jrt.Class { return A_arbace_instant__init_A_class }

func (t *A_arbace_instant__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_instant__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant__init_A); return ok }

func A_arbace_instant__init_A_Cast(x any) *A_arbace_instant__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant__init_A_class)) }; return v }
