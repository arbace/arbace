//line aot_arbace_instant__init.ae:1
package aot_arbace_instant

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_instant__init_A_Load__O() any { A_arbace_instant__init_A_Init(); A_arbace_instant__init_A_Unit0__O(); A_arbace_instant__init_A_Unit1__O(); A_arbace_instant__init_A_Unit2__O(); A_arbace_instant__init_A_Unit3__O(); A_arbace_instant__init_A_Unit4__O(); A_arbace_instant__init_A_Unit5__O(); A_arbace_instant__init_A_Unit6__O(); A_arbace_instant__init_A_Unit7__O(); A_arbace_instant__init_A_Unit8__O(); A_arbace_instant__init_A_Unit9__O(); A_arbace_instant__init_A_Unit10__O(); A_arbace_instant__init_A_Unit11__O(); A_arbace_instant__init_A_Unit12__O(); A_arbace_instant__init_A_Unit13__O(); A_arbace_instant__init_A_Unit14__O(); A_arbace_instant__init_A_Unit15__O(); A_arbace_instant__init_A_Unit16__O(); A_arbace_instant__init_A_Unit17__O(); A_arbace_instant__init_A_Unit18__O(); A_arbace_instant__init_A_Unit19__O(); A_arbace_instant__init_A_Unit20__O(); A_arbace_instant__init_A_Unit21__O(); A_arbace_instant__init_A_Unit22__O(); A_arbace_instant__init_A_Unit23__O(); A_arbace_instant__init_A_Unit24__O(); A_arbace_instant__init_A_Unit25__O(); A_arbace_instant__init_A_Unit26__O(); A_arbace_instant__init_A_Unit27__O(); A_arbace_instant__init_A_Unit28__O(); A_arbace_instant__init_A_Unit29__O(); A_arbace_instant__init_A_Unit30__O(); A_arbace_instant__init_A_Unit31__O(); A_arbace_instant__init_A_Unit32__O(); A_arbace_instant__init_A_Unit33__O(); A_arbace_instant__init_A_Unit34__O(); A_arbace_instant__init_A_Unit35__O(); A_arbace_instant__init_A_Unit36__O(); return nil }















func A_arbace_instant__init_A_Unit0__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(21, 1); return lang.IFn_Cast(A_arbace_instant__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_instant__init_A_const_1) }
//line :21:1
func A_arbace_instant__init_A_Unit1__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(21, 1); var tmp1 any = A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_30, false); A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :21:1
func A_arbace_instant__init_A_Unit2__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(21, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_instant__init_A_const_1)).Equals_O__Z(A_arbace_instant__init_A_const_2) { return nil } else { var tmp1 any = A_arbace_instant_eval783000006_fn__783000007_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_instant_eval783000006_fn__783000007_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_31, false); A_arbace_instant_eval783000006_fn__783000007_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_instant__init_A_Unit3__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(25, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_3; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; return tmp1.Set_O__O(tmp2.Ref()) }




func A_arbace_instant__init_A_Unit4__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(30, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_4; var tmp2 any = A_arbace_instant_fail_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_instant_fail_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_32, false); A_arbace_instant_fail_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_5)); return A_arbace_instant__init_A_const_4 }
//line :30:1
func A_arbace_instant__init_A_Unit5__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(30, 1); A_arbace_instant__init_A_const_4.SetMacro__V(); return nil }
//line :30:1
func A_arbace_instant__init_A_Unit6__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(30, 1); return A_arbace_instant__init_A_const_4 }



func A_arbace_instant__init_A_Unit7__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(34, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_6; var tmp2 any = A_arbace_instant_verify_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_instant_verify_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_33, false); A_arbace_instant_verify_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_7)); return A_arbace_instant__init_A_const_6 }
//line :34:1
func A_arbace_instant__init_A_Unit8__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(34, 1); A_arbace_instant__init_A_const_6.SetMacro__V(); return nil }
//line :34:1
func A_arbace_instant__init_A_Unit9__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(34, 1); return A_arbace_instant__init_A_const_6 }



func A_arbace_instant__init_A_Unit10__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(38, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_8; var tmp2 any = A_arbace_instant_divisible_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_instant_divisible_QMARK__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_34, false); A_arbace_instant_divisible_QMARK__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_9)); return A_arbace_instant__init_A_const_8 }



func A_arbace_instant__init_A_Unit11__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(42, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_10; var tmp2 any = A_arbace_instant_indivisible_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_instant_indivisible_QMARK__A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_35, false); A_arbace_instant_indivisible_QMARK__A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_11)); return A_arbace_instant__init_A_const_10 }






func A_arbace_instant__init_A_Unit12__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(49, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_12; var tmp2 any = A_arbace_instant_parse_int_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_instant_parse_int_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_36, false); A_arbace_instant_parse_int_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_13)); return A_arbace_instant__init_A_const_12 }


func A_arbace_instant__init_A_Unit13__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(52, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_14; var tmp2 any = A_arbace_instant_zero_fill_right_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_instant_zero_fill_right_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_37, false); A_arbace_instant_zero_fill_right_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_15)); return A_arbace_instant__init_A_const_14 }







func A_arbace_instant__init_A_Unit14__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(60, 1); A_arbace_instant__init_A_const_16.BindRoot_O__V(A_arbace_instant__init_A_const_17); var tmp1 *lang.Var = A_arbace_instant__init_A_const_16; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_18)); return A_arbace_instant__init_A_const_16 }


func A_arbace_instant__init_A_Unit15__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(63, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_19; var tmp2 any = A_arbace_instant_parse_timestamp_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_instant_parse_timestamp_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_38, false); A_arbace_instant_parse_timestamp_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_20)); return A_arbace_instant__init_A_const_19 }








































































func A_arbace_instant__init_A_Unit16__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(136, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_21; var tmp2 any = A_arbace_instant_leap_year_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_instant_leap_year_QMARK__A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_39, false); A_arbace_instant_leap_year_QMARK__A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_22)); return A_arbace_instant__init_A_const_21 }





func A_arbace_instant__init_A_Unit17__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(142, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_23; var tmp2 any = A_arbace_instant_fn__783000031_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_instant_fn__783000031_A_fn_class; if
						fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_40, false); A_arbace_instant_fn__783000031_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; /*line :142:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_instant__init_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_24)); return A_arbace_instant__init_A_const_23 }





func A_arbace_instant__init_A_Unit18__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(148, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_25; var tmp2 any = A_arbace_instant_validated_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_instant_validated_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_41, false); A_arbace_instant_validated_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_26)); return A_arbace_instant__init_A_const_25 }
























func A_arbace_instant__init_A_Unit19__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(173, 1); A_arbace_instant__init_A_const_27.BindRoot_O__V(A_arbace_instant__init_A_const_28); var tmp1 *lang.Var = A_arbace_instant__init_A_const_27; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_29)); return A_arbace_instant__init_A_const_27 }




func A_arbace_instant__init_A_Unit20__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(178, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_30; var tmp2 any = A_arbace_instant_days__GT_civil_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_instant_days__GT_civil_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_42, false); A_arbace_instant_days__GT_civil_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_31)); return A_arbace_instant__init_A_const_30 }






















func A_arbace_instant__init_A_Unit21__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(201, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_32; var tmp2 any = A_arbace_instant_civil__GT_days_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_instant_civil__GT_days_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_43, false); A_arbace_instant_civil__GT_days_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_33)); return A_arbace_instant__init_A_const_32 }
















func A_arbace_instant__init_A_Unit22__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(218, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_34; var tmp2 any = A_arbace_instant_print_date_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_instant_print_date_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_44, false); A_arbace_instant_print_date_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_35)); return A_arbace_instant__init_A_const_34 }












func A_arbace_instant__init_A_Unit23__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(231, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_instant__init_A_const_36.GetRawRoot__O()); var tmp2 any = A_arbace_instant__init_A_const_37; var tmp3 any = A_arbace_instant_eval783000044_fn__783000045_A_New(); var tmp4 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_instant_eval783000044_fn__783000045_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_45, false); A_arbace_instant_eval783000044_fn__783000045_A_fn_class = fncls__16d; tmp4 = fncls__16d } else { tmp4 = fncls__16 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_instant__init_A_Unit24__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(235, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_instant__init_A_const_38.GetRawRoot__O()); var tmp2 any = A_arbace_instant__init_A_const_37; var tmp3 any = A_arbace_instant_eval783000048_fn__783000049_A_New(); var tmp4 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_instant_eval783000048_fn__783000049_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_46, false); A_arbace_instant_eval783000048_fn__783000049_A_fn_class = fncls__17d; tmp4 = fncls__17d } else { tmp4 = fncls__17 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_instant__init_A_Unit25__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(239, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_39; var tmp2 any = A_arbace_instant_print_calendar_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_instant_print_calendar_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_47, false); A_arbace_instant_print_calendar_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_40)); return A_arbace_instant__init_A_const_39 }











func A_arbace_instant__init_A_Unit26__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(251, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_instant__init_A_const_36.GetRawRoot__O()); var tmp2 any = A_arbace_instant__init_A_const_41; var tmp3 any = A_arbace_instant_eval783000053_fn__783000054_A_New(); var tmp4 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_instant_eval783000053_fn__783000054_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_48, false); A_arbace_instant_eval783000053_fn__783000054_A_fn_class = fncls__19d; tmp4 = fncls__19d } else { tmp4 = fncls__19 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_instant__init_A_Unit27__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(255, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_instant__init_A_const_38.GetRawRoot__O()); var tmp2 any = A_arbace_instant__init_A_const_41; var tmp3 any = A_arbace_instant_eval783000057_fn__783000058_A_New(); var tmp4 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_instant_eval783000057_fn__783000058_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_49, false); A_arbace_instant_eval783000057_fn__783000058_A_fn_class = fncls__20d; tmp4 = fncls__20d } else { tmp4 = fncls__20 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_instant__init_A_Unit28__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(259, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_42; var tmp2 any = A_arbace_instant_print_timestamp_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_instant_print_timestamp_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_50, false); A_arbace_instant_print_timestamp_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_43)); return A_arbace_instant__init_A_const_42 }















func A_arbace_instant__init_A_Unit29__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(275, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_instant__init_A_const_36.GetRawRoot__O()); var tmp2 any = A_arbace_instant__init_A_const_44; var tmp3 any = A_arbace_instant_eval783000065_fn__783000066_A_New(); var tmp4 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_instant_eval783000065_fn__783000066_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_51, false); A_arbace_instant_eval783000065_fn__783000066_A_fn_class = fncls__22d; tmp4 = fncls__22d } else { tmp4 = fncls__22 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_instant__init_A_Unit30__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(279, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_instant__init_A_const_38.GetRawRoot__O()); var tmp2 any = A_arbace_instant__init_A_const_44; var tmp3 any = A_arbace_instant_eval783000069_fn__783000070_A_New(); var tmp4 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_instant_eval783000069_fn__783000070_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_52, false); A_arbace_instant_eval783000069_fn__783000070_A_fn_class = fncls__23d; tmp4 = fncls__23d } else { tmp4 = fncls__23 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_instant__init_A_Unit31__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(286, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_45; var tmp2 any = A_arbace_instant_construct_date_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_instant_construct_date_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_53, false); A_arbace_instant_construct_date_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_46)); return A_arbace_instant__init_A_const_45 }









func A_arbace_instant__init_A_Unit32__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(296, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_47; var tmp2 any = A_arbace_instant_read_instant_date_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_instant_read_instant_date_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_54, false); A_arbace_instant_read_instant_date_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_48)); return A_arbace_instant__init_A_const_47 }






func A_arbace_instant__init_A_Unit33__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(303, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_49; var tmp2 any = A_arbace_instant_construct_calendar_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_instant_construct_calendar_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_55, false); A_arbace_instant_construct_calendar_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_50)); return A_arbace_instant__init_A_const_49 }












func A_arbace_instant__init_A_Unit34__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(316, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_51; var tmp2 any = A_arbace_instant_construct_timestamp_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_instant_construct_timestamp_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_56, false); A_arbace_instant_construct_timestamp_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_52)); return A_arbace_instant__init_A_const_51 }











func A_arbace_instant__init_A_Unit35__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(328, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_53; var tmp2 any = A_arbace_instant_read_instant_calendar_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_instant_read_instant_calendar_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_57, false); A_arbace_instant_read_instant_calendar_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_54)); return A_arbace_instant__init_A_const_53 }






func A_arbace_instant__init_A_Unit36__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V(335, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_55; var tmp2 any = A_arbace_instant_read_instant_timestamp_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_instant_read_instant_timestamp_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_58, false); A_arbace_instant_read_instant_timestamp_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_instant__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_56)); return A_arbace_instant__init_A_const_55 }



type A_arbace_instant__init_A struct{ jrt.Object }

var A_arbace_instant__init_A_const_pool *jrt.RefArray

var A_arbace_instant__init_A_const_0 *lang.Var

var A_arbace_instant__init_A_const_1 any

var A_arbace_instant__init_A_const_2 any

var A_arbace_instant__init_A_const_3 *lang.Var

var A_arbace_instant__init_A_const_4 *lang.Var

var A_arbace_instant__init_A_const_5 any

var A_arbace_instant__init_A_const_6 *lang.Var

var A_arbace_instant__init_A_const_7 any

var A_arbace_instant__init_A_const_8 *lang.Var

var A_arbace_instant__init_A_const_9 any

var A_arbace_instant__init_A_const_10 *lang.Var

var A_arbace_instant__init_A_const_11 any

var A_arbace_instant__init_A_const_12 *lang.Var

var A_arbace_instant__init_A_const_13 any

var A_arbace_instant__init_A_const_14 *lang.Var

var A_arbace_instant__init_A_const_15 any

var A_arbace_instant__init_A_const_16 *lang.Var

var A_arbace_instant__init_A_const_17 any

var A_arbace_instant__init_A_const_18 any

var A_arbace_instant__init_A_const_19 *lang.Var

var A_arbace_instant__init_A_const_20 any

var A_arbace_instant__init_A_const_21 *lang.Var

var A_arbace_instant__init_A_const_22 any

var A_arbace_instant__init_A_const_23 *lang.Var

var A_arbace_instant__init_A_const_24 any

var A_arbace_instant__init_A_const_25 *lang.Var

var A_arbace_instant__init_A_const_26 any

var A_arbace_instant__init_A_const_27 *lang.Var

var A_arbace_instant__init_A_const_28 any

var A_arbace_instant__init_A_const_29 any

var A_arbace_instant__init_A_const_30 *lang.Var

var A_arbace_instant__init_A_const_31 any

var A_arbace_instant__init_A_const_32 *lang.Var

var A_arbace_instant__init_A_const_33 any

var A_arbace_instant__init_A_const_34 *lang.Var

var A_arbace_instant__init_A_const_35 any

var A_arbace_instant__init_A_const_36 *lang.Var

var A_arbace_instant__init_A_const_37 *jrt.Class

var A_arbace_instant__init_A_const_38 *lang.Var

var A_arbace_instant__init_A_const_39 *lang.Var

var A_arbace_instant__init_A_const_40 any

var A_arbace_instant__init_A_const_41 *jrt.Class

var A_arbace_instant__init_A_const_42 *lang.Var

var A_arbace_instant__init_A_const_43 any

var A_arbace_instant__init_A_const_44 *jrt.Class

var A_arbace_instant__init_A_const_45 *lang.Var

var A_arbace_instant__init_A_const_46 any

var A_arbace_instant__init_A_const_47 *lang.Var

var A_arbace_instant__init_A_const_48 any

var A_arbace_instant__init_A_const_49 *lang.Var

var A_arbace_instant__init_A_const_50 any

var A_arbace_instant__init_A_const_51 *lang.Var

var A_arbace_instant__init_A_const_52 any

var A_arbace_instant__init_A_const_53 *lang.Var

var A_arbace_instant__init_A_const_54 any

var A_arbace_instant__init_A_const_55 *lang.Var

var A_arbace_instant__init_A_const_56 any

var A_arbace_instant__init_A_init jrt.ClassInit

func A_arbace_instant__init_A_Init() { if !A_arbace_instant__init_A_init.Done() { A_arbace_instant__init_A_init.Run(A_arbace_instant__init_A_clinit) } }

func A_arbace_instant__init_A_clinit() { A_arbace_instant__init_A_clinit_p0(); A_arbace_instant__init_A_clinit_p1(); A_arbace_instant__init_A_clinit_p2(); A_arbace_instant__init_A_clinit_p3(); A_arbace_instant__init_A_clinit_p4() }

func A_arbace_instant__init_A_clinit_p0() { A_arbace_instant__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_29, 95); A_arbace_instant__init_A_const_0 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[38]); A_arbace_instant__init_A_const_1 = A_arbace_instant__init_A_const_pool.A[39]; A_arbace_instant__init_A_const_2 = A_arbace_instant__init_A_const_pool.A[40]; A_arbace_instant__init_A_const_3 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[41]); A_arbace_instant__init_A_const_4 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[42]); A_arbace_instant__init_A_const_5 = A_arbace_instant__init_A_const_pool.A[43]; A_arbace_instant__init_A_const_6 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[44]); A_arbace_instant__init_A_const_7 = A_arbace_instant__init_A_const_pool.A[45]; A_arbace_instant__init_A_const_8 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[46]); A_arbace_instant__init_A_const_9 = A_arbace_instant__init_A_const_pool.A[47]; A_arbace_instant__init_A_const_10 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[48]); A_arbace_instant__init_A_const_11 = A_arbace_instant__init_A_const_pool.A[49]; A_arbace_instant__init_A_const_12 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[50]) }

func A_arbace_instant__init_A_clinit_p1() { A_arbace_instant__init_A_const_13 = A_arbace_instant__init_A_const_pool.A[51]; A_arbace_instant__init_A_const_14 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[52]); A_arbace_instant__init_A_const_15 = A_arbace_instant__init_A_const_pool.A[53]; A_arbace_instant__init_A_const_16 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[54]); A_arbace_instant__init_A_const_17 = A_arbace_instant__init_A_const_pool.A[55]; A_arbace_instant__init_A_const_18 = A_arbace_instant__init_A_const_pool.A[56]; A_arbace_instant__init_A_const_19 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[57]); A_arbace_instant__init_A_const_20 = A_arbace_instant__init_A_const_pool.A[58]; A_arbace_instant__init_A_const_21 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[59]); A_arbace_instant__init_A_const_22 = A_arbace_instant__init_A_const_pool.A[60]; A_arbace_instant__init_A_const_23 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[61]); A_arbace_instant__init_A_const_24 = A_arbace_instant__init_A_const_pool.A[62]; A_arbace_instant__init_A_const_25 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[63]); A_arbace_instant__init_A_const_26 = A_arbace_instant__init_A_const_pool.A[64] }

func A_arbace_instant__init_A_clinit_p2() { A_arbace_instant__init_A_const_27 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[65]); A_arbace_instant__init_A_const_28 = A_arbace_instant__init_A_const_pool.A[66]; A_arbace_instant__init_A_const_29 = A_arbace_instant__init_A_const_pool.A[67]; A_arbace_instant__init_A_const_30 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[68]); A_arbace_instant__init_A_const_31 = A_arbace_instant__init_A_const_pool.A[69]; A_arbace_instant__init_A_const_32 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[70]); A_arbace_instant__init_A_const_33 = A_arbace_instant__init_A_const_pool.A[71]; A_arbace_instant__init_A_const_34 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[72]); A_arbace_instant__init_A_const_35 = A_arbace_instant__init_A_const_pool.A[73]; A_arbace_instant__init_A_const_36 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[74]); A_arbace_instant__init_A_const_37 = jrt.Class_Cast(A_arbace_instant__init_A_const_pool.A[75]); A_arbace_instant__init_A_const_38 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[76]); A_arbace_instant__init_A_const_39 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[77]) }

func A_arbace_instant__init_A_clinit_p3() { A_arbace_instant__init_A_const_40 = A_arbace_instant__init_A_const_pool.A[78]; A_arbace_instant__init_A_const_41 = jrt.Class_Cast(A_arbace_instant__init_A_const_pool.A[79]); A_arbace_instant__init_A_const_42 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[80]); A_arbace_instant__init_A_const_43 = A_arbace_instant__init_A_const_pool.A[81]; A_arbace_instant__init_A_const_44 = jrt.Class_Cast(A_arbace_instant__init_A_const_pool.A[82]); A_arbace_instant__init_A_const_45 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[83]); A_arbace_instant__init_A_const_46 = A_arbace_instant__init_A_const_pool.A[84]; A_arbace_instant__init_A_const_47 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[85]); A_arbace_instant__init_A_const_48 = A_arbace_instant__init_A_const_pool.A[86]; A_arbace_instant__init_A_const_49 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[87]); A_arbace_instant__init_A_const_50 = A_arbace_instant__init_A_const_pool.A[88]; A_arbace_instant__init_A_const_51 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[89]); A_arbace_instant__init_A_const_52 = A_arbace_instant__init_A_const_pool.A[90] }

func A_arbace_instant__init_A_clinit_p4() { A_arbace_instant__init_A_const_53 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[91]); A_arbace_instant__init_A_const_54 = A_arbace_instant__init_A_const_pool.A[92]; A_arbace_instant__init_A_const_55 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[93]); A_arbace_instant__init_A_const_56 = A_arbace_instant__init_A_const_pool.A[94] }

func A_arbace_instant__init_A_New() *A_arbace_instant__init_A { A_arbace_instant__init_A_Init(); t := &A_arbace_instant__init_A{}; t.Ctor(); return t }

func (t *A_arbace_instant__init_A) Ctor() {}

func (t *A_arbace_instant__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant__init_A) GetClass__Class() *jrt.Class { return A_arbace_instant__init_A_class }

func (t *A_arbace_instant__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant__init_A); return ok }

func A_arbace_instant__init_A_Cast(x any) *A_arbace_instant__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant__init_A_class)) }; return v }
