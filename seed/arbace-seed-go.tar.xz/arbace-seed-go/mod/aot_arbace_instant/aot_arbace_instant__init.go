//line aot_arbace_instant__init.ae:1
package aot_arbace_instant

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_instant__init_A_Load__O() any { A_arbace_instant__init_A_Init(); jrt.StartCheck(); A_arbace_instant__init_A_Unit0__O(); A_arbace_instant__init_A_Unit1__O(); A_arbace_instant__init_A_Unit2__O(); A_arbace_instant__init_A_Unit3__O(); A_arbace_instant__init_A_Unit4__O(); A_arbace_instant__init_A_Unit5__O(); A_arbace_instant__init_A_Unit6__O(); A_arbace_instant__init_A_Unit7__O(); A_arbace_instant__init_A_Unit8__O(); A_arbace_instant__init_A_Unit9__O(); A_arbace_instant__init_A_Unit10__O(); A_arbace_instant__init_A_Unit11__O(); A_arbace_instant__init_A_Unit12__O(); A_arbace_instant__init_A_Unit13__O(); A_arbace_instant__init_A_Unit14__O(); A_arbace_instant__init_A_Unit15__O(); A_arbace_instant__init_A_Unit16__O(); A_arbace_instant__init_A_Unit17__O(); A_arbace_instant__init_A_Unit18__O(); A_arbace_instant__init_A_Unit19__O(); A_arbace_instant__init_A_Unit20__O(); A_arbace_instant__init_A_Unit21__O(); A_arbace_instant__init_A_Unit22__O(); A_arbace_instant__init_A_Unit23__O(); A_arbace_instant__init_A_Unit24__O(); A_arbace_instant__init_A_Unit25__O(); A_arbace_instant__init_A_Unit26__O(); A_arbace_instant__init_A_Unit27__O(); A_arbace_instant__init_A_Unit28__O(); A_arbace_instant__init_A_Unit29__O(); A_arbace_instant__init_A_Unit30__O(); A_arbace_instant__init_A_Unit31__O(); A_arbace_instant__init_A_Unit32__O(); A_arbace_instant__init_A_Unit33__O(); A_arbace_instant__init_A_Unit34__O(); A_arbace_instant__init_A_Unit35__O(); A_arbace_instant__init_A_Unit36__O(); return nil }















func A_arbace_instant__init_A_Unit0__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(21, 1); return lang.IFn_Cast(A_arbace_instant__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_instant__init_A_const_1) }
//line :21:1
func A_arbace_instant__init_A_Unit1__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(21, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, nil); A_arbace_instant_eval783000002_loading__1927001464__auto____783000003_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :21:1
func A_arbace_instant__init_A_Unit2__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(21, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_instant__init_A_const_1)).Equals_O__Z(A_arbace_instant__init_A_const_2) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_instant_eval783000006_fn__783000007_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_instant_eval783000006_fn__783000007_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, nil); A_arbace_instant_eval783000006_fn__783000007_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_instant__init_A_Unit3__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(25, 1); return A_arbace_instant__init_A_const_3.Set_O__O(jrt.Boolean_TRUE.Ref()) }




func A_arbace_instant__init_A_Unit4__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(30, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_instant_fail_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_instant_fail_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, nil); A_arbace_instant_fail_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_instant__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_5)); return A_arbace_instant__init_A_const_4 }
//line :30:1
func A_arbace_instant__init_A_Unit5__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(30, 1); A_arbace_instant__init_A_const_4.SetMacro__V(); return nil }
//line :30:1
func A_arbace_instant__init_A_Unit6__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(30, 1); return A_arbace_instant__init_A_const_4 }



func A_arbace_instant__init_A_Unit7__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(34, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_instant_verify_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_instant_verify_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, nil); A_arbace_instant_verify_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_instant__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_7)); return A_arbace_instant__init_A_const_6 }
//line :34:1
func A_arbace_instant__init_A_Unit8__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(34, 1); A_arbace_instant__init_A_const_6.SetMacro__V(); return nil }
//line :34:1
func A_arbace_instant__init_A_Unit9__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(34, 1); return A_arbace_instant__init_A_const_6 }



func A_arbace_instant__init_A_Unit10__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_instant_divisible_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_instant_divisible_QMARK__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, nil); A_arbace_instant_divisible_QMARK__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_instant__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_9)); return A_arbace_instant__init_A_const_8 }



func A_arbace_instant__init_A_Unit11__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_instant_indivisible_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_instant_indivisible_QMARK__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, nil); A_arbace_instant_indivisible_QMARK__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_instant__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_11)); return A_arbace_instant__init_A_const_10 }






func A_arbace_instant__init_A_Unit12__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(49, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_instant_parse_int_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_instant_parse_int_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, nil); A_arbace_instant_parse_int_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_instant__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_13)); return A_arbace_instant__init_A_const_12 }


func A_arbace_instant__init_A_Unit13__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(52, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_instant_zero_fill_right_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_instant_zero_fill_right_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, nil); A_arbace_instant_zero_fill_right_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_instant__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_15)); return A_arbace_instant__init_A_const_14 }







func A_arbace_instant__init_A_Unit14__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(60, 1); A_arbace_instant__init_A_const_16.BindRoot_O__V(A_arbace_instant__init_A_const_17); var tmp1 *lang.Var = A_arbace_instant__init_A_const_16; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_18)); return A_arbace_instant__init_A_const_16 }


func A_arbace_instant__init_A_Unit15__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(63, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_19; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_instant_parse_timestamp_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_instant_parse_timestamp_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, nil); A_arbace_instant_parse_timestamp_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_instant__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_20)); return A_arbace_instant__init_A_const_19 }








































































func A_arbace_instant__init_A_Unit16__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(136, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_21; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_instant_leap_year_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_instant_leap_year_QMARK__A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, nil); A_arbace_instant_leap_year_QMARK__A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_instant__init_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_22)); return A_arbace_instant__init_A_const_21 }





func A_arbace_instant__init_A_Unit17__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(142, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_23; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_instant_fn__783000031_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_instant_fn__783000031_A_fn_class; if
						fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, nil); A_arbace_instant_fn__783000031_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); /*line :142:1*/tmp1.BindRoot_O__V(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()); var tmp4 *lang.Var = A_arbace_instant__init_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_24)); return A_arbace_instant__init_A_const_23 }





func A_arbace_instant__init_A_Unit18__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(148, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_25; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_instant_validated_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_instant_validated_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, nil); A_arbace_instant_validated_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_instant__init_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_26)); return A_arbace_instant__init_A_const_25 }
























func A_arbace_instant__init_A_Unit19__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(173, 1); A_arbace_instant__init_A_const_27.BindRoot_O__V(A_arbace_instant__init_A_const_28); var tmp1 *lang.Var = A_arbace_instant__init_A_const_27; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_29)); return A_arbace_instant__init_A_const_27 }




func A_arbace_instant__init_A_Unit20__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_instant_days__GT_civil_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_instant_days__GT_civil_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, nil); A_arbace_instant_days__GT_civil_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_instant__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_31)); return A_arbace_instant__init_A_const_30 }






















func A_arbace_instant__init_A_Unit21__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(201, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_instant_civil__GT_days_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_instant_civil__GT_days_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, nil); A_arbace_instant_civil__GT_days_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_instant__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_33)); return A_arbace_instant__init_A_const_32 }
















func A_arbace_instant__init_A_Unit22__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(218, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_instant_print_date_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_instant_print_date_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, nil); A_arbace_instant_print_date_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_instant__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_35)); return A_arbace_instant__init_A_const_34 }












func A_arbace_instant__init_A_Unit23__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(231, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_instant__init_A_const_36.GetRawRoot__O()); var tmp2 any = A_arbace_instant__init_A_const_37; var tmp3 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_instant_eval783000044_fn__783000045_A_New(); var tmp4 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_instant_eval783000044_fn__783000045_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, nil); A_arbace_instant_eval783000044_fn__783000045_A_fn_class = fncls__31d; tmp4 = fncls__31d } else { tmp4 = fncls__31 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }



func A_arbace_instant__init_A_Unit24__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(235, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_instant__init_A_const_38.GetRawRoot__O()); var tmp2 any = A_arbace_instant__init_A_const_37; var tmp3 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_instant_eval783000048_fn__783000049_A_New(); var tmp4 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_instant_eval783000048_fn__783000049_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, nil); A_arbace_instant_eval783000048_fn__783000049_A_fn_class = fncls__33d; tmp4 = fncls__33d } else { tmp4 = fncls__33 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }



func A_arbace_instant__init_A_Unit25__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(239, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_39; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_instant_print_calendar_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_instant_print_calendar_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, nil); A_arbace_instant_print_calendar_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_instant__init_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_40)); return A_arbace_instant__init_A_const_39 }











func A_arbace_instant__init_A_Unit26__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(251, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_instant__init_A_const_36.GetRawRoot__O()); var tmp2 any = A_arbace_instant__init_A_const_41; var tmp3 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_instant_eval783000053_fn__783000054_A_New(); var tmp4 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_instant_eval783000053_fn__783000054_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, nil); A_arbace_instant_eval783000053_fn__783000054_A_fn_class = fncls__37d; tmp4 = fncls__37d } else { tmp4 = fncls__37 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }



func A_arbace_instant__init_A_Unit27__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(255, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_instant__init_A_const_38.GetRawRoot__O()); var tmp2 any = A_arbace_instant__init_A_const_41; var tmp3 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_instant_eval783000057_fn__783000058_A_New(); var tmp4 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_instant_eval783000057_fn__783000058_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, nil); A_arbace_instant_eval783000057_fn__783000058_A_fn_class = fncls__39d; tmp4 = fncls__39d } else { tmp4 = fncls__39 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }



func A_arbace_instant__init_A_Unit28__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(259, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_instant_print_timestamp_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_instant_print_timestamp_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, nil); A_arbace_instant_print_timestamp_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_instant__init_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_43)); return A_arbace_instant__init_A_const_42 }















func A_arbace_instant__init_A_Unit29__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(275, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_instant__init_A_const_36.GetRawRoot__O()); var tmp2 any = A_arbace_instant__init_A_const_44; var tmp3 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_instant_eval783000065_fn__783000066_A_New(); var tmp4 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_instant_eval783000065_fn__783000066_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_51, false, nil); A_arbace_instant_eval783000065_fn__783000066_A_fn_class = fncls__43d; tmp4 = fncls__43d } else { tmp4 = fncls__43 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }



func A_arbace_instant__init_A_Unit30__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(279, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_instant__init_A_const_38.GetRawRoot__O()); var tmp2 any = A_arbace_instant__init_A_const_44; var tmp3 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_instant_eval783000069_fn__783000070_A_New(); var tmp4 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_instant_eval783000069_fn__783000070_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_52, false, nil); A_arbace_instant_eval783000069_fn__783000070_A_fn_class = fncls__45d; tmp4 = fncls__45d } else { tmp4 = fncls__45 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }






func A_arbace_instant__init_A_Unit31__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(286, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_45; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_instant_construct_date_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_instant_construct_date_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, false, nil); A_arbace_instant_construct_date_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_instant__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_46)); return A_arbace_instant__init_A_const_45 }









func A_arbace_instant__init_A_Unit32__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(296, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_47; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_instant_read_instant_date_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_instant_read_instant_date_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, nil); A_arbace_instant_read_instant_date_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_instant__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_48)); return A_arbace_instant__init_A_const_47 }






func A_arbace_instant__init_A_Unit33__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(303, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_49; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_instant_construct_calendar_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_instant_construct_calendar_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, nil); A_arbace_instant_construct_calendar_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_instant__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_50)); return A_arbace_instant__init_A_const_49 }












func A_arbace_instant__init_A_Unit34__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(316, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_instant_construct_timestamp_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_instant_construct_timestamp_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, nil); A_arbace_instant_construct_timestamp_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_instant__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_52)); return A_arbace_instant__init_A_const_51 }











func A_arbace_instant__init_A_Unit35__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(328, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_53; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_instant_read_instant_calendar_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_instant_read_instant_calendar_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, nil); A_arbace_instant_read_instant_calendar_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_instant__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_54)); return A_arbace_instant__init_A_const_53 }






func A_arbace_instant__init_A_Unit36__O() any { A_arbace_instant__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(335, 1); var tmp1 *lang.Var = A_arbace_instant__init_A_const_55; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_instant_read_instant_timestamp_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_instant_read_instant_timestamp_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, nil); A_arbace_instant_read_instant_timestamp_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_instant__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_instant__init_A_const_56)); return A_arbace_instant__init_A_const_55 }



type A_arbace_instant__init_A struct{ jrt.Object }

var A_arbace_instant__init_A_const_pool *jrt.RefArray

var A_arbace_instant__init_A_const_0 *lang.Var

var A_arbace_instant__init_A_const_1 any

var A_arbace_instant__init_A_const_2 any

var A_arbace_instant__init_A_const_3 *lang.Var

var A_arbace_instant__init_A_const_4 *lang.Var

var A_arbace_instant__init_A_const_5 any

var A_arbace_instant__init_A_const_6 *lang.Var

var A_arbace_instant__init_A_const_7 any

var A_arbace_instant__init_A_const_8 *lang.Var

var A_arbace_instant__init_A_const_9 any

var A_arbace_instant__init_A_const_10 *lang.Var

var A_arbace_instant__init_A_const_11 any

var A_arbace_instant__init_A_const_12 *lang.Var

var A_arbace_instant__init_A_const_13 any

var A_arbace_instant__init_A_const_14 *lang.Var

var A_arbace_instant__init_A_const_15 any

var A_arbace_instant__init_A_const_16 *lang.Var

var A_arbace_instant__init_A_const_17 any

var A_arbace_instant__init_A_const_18 any

var A_arbace_instant__init_A_const_19 *lang.Var

var A_arbace_instant__init_A_const_20 any

var A_arbace_instant__init_A_const_21 *lang.Var

var A_arbace_instant__init_A_const_22 any

var A_arbace_instant__init_A_const_23 *lang.Var

var A_arbace_instant__init_A_const_24 any

var A_arbace_instant__init_A_const_25 *lang.Var

var A_arbace_instant__init_A_const_26 any

var A_arbace_instant__init_A_const_27 *lang.Var

var A_arbace_instant__init_A_const_28 any

var A_arbace_instant__init_A_const_29 any

var A_arbace_instant__init_A_const_30 *lang.Var

var A_arbace_instant__init_A_const_31 any

var A_arbace_instant__init_A_const_32 *lang.Var

var A_arbace_instant__init_A_const_33 any

var A_arbace_instant__init_A_const_34 *lang.Var

var A_arbace_instant__init_A_const_35 any

var A_arbace_instant__init_A_const_36 *lang.Var

var A_arbace_instant__init_A_const_37 *jrt.Class

var A_arbace_instant__init_A_const_38 *lang.Var

var A_arbace_instant__init_A_const_39 *lang.Var

var A_arbace_instant__init_A_const_40 any

var A_arbace_instant__init_A_const_41 *jrt.Class

var A_arbace_instant__init_A_const_42 *lang.Var

var A_arbace_instant__init_A_const_43 any

var A_arbace_instant__init_A_const_44 *jrt.Class

var A_arbace_instant__init_A_const_45 *lang.Var

var A_arbace_instant__init_A_const_46 any

var A_arbace_instant__init_A_const_47 *lang.Var

var A_arbace_instant__init_A_const_48 any

var A_arbace_instant__init_A_const_49 *lang.Var

var A_arbace_instant__init_A_const_50 any

var A_arbace_instant__init_A_const_51 *lang.Var

var A_arbace_instant__init_A_const_52 any

var A_arbace_instant__init_A_const_53 *lang.Var

var A_arbace_instant__init_A_const_54 any

var A_arbace_instant__init_A_const_55 *lang.Var

var A_arbace_instant__init_A_const_56 any

var A_arbace_instant__init_A_init jrt.ClassInit

func A_arbace_instant__init_A_Init() { if !A_arbace_instant__init_A_init.Done() { A_arbace_instant__init_A_init.Run(A_arbace_instant__init_A_clinit) } }

func A_arbace_instant__init_A_clinit() { A_arbace_instant__init_A_clinit_p0(); A_arbace_instant__init_A_clinit_p1(); A_arbace_instant__init_A_clinit_p2(); A_arbace_instant__init_A_clinit_p3(); A_arbace_instant__init_A_clinit_p4() }

func A_arbace_instant__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_instant__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_29, 95); A_arbace_instant__init_A_const_0 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[38]); A_arbace_instant__init_A_const_1 = A_arbace_instant__init_A_const_pool.A[39]; A_arbace_instant__init_A_const_2 = A_arbace_instant__init_A_const_pool.A[40]; A_arbace_instant__init_A_const_3 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[41]); A_arbace_instant__init_A_const_4 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[42]); A_arbace_instant__init_A_const_5 = A_arbace_instant__init_A_const_pool.A[43]; A_arbace_instant__init_A_const_6 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[44]); A_arbace_instant__init_A_const_7 = A_arbace_instant__init_A_const_pool.A[45]; A_arbace_instant__init_A_const_8 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[46]); A_arbace_instant__init_A_const_9 = A_arbace_instant__init_A_const_pool.A[47]; A_arbace_instant__init_A_const_10 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[48]); A_arbace_instant__init_A_const_11 = A_arbace_instant__init_A_const_pool.A[49] }

func A_arbace_instant__init_A_clinit_p1() { A_arbace_instant__init_A_const_12 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[50]); A_arbace_instant__init_A_const_13 = A_arbace_instant__init_A_const_pool.A[51]; A_arbace_instant__init_A_const_14 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[52]); A_arbace_instant__init_A_const_15 = A_arbace_instant__init_A_const_pool.A[53]; A_arbace_instant__init_A_const_16 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[54]); A_arbace_instant__init_A_const_17 = A_arbace_instant__init_A_const_pool.A[55]; A_arbace_instant__init_A_const_18 = A_arbace_instant__init_A_const_pool.A[56]; A_arbace_instant__init_A_const_19 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[57]); A_arbace_instant__init_A_const_20 = A_arbace_instant__init_A_const_pool.A[58]; A_arbace_instant__init_A_const_21 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[59]); A_arbace_instant__init_A_const_22 = A_arbace_instant__init_A_const_pool.A[60]; A_arbace_instant__init_A_const_23 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[61]); A_arbace_instant__init_A_const_24 = A_arbace_instant__init_A_const_pool.A[62] }

func A_arbace_instant__init_A_clinit_p2() { A_arbace_instant__init_A_const_25 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[63]); A_arbace_instant__init_A_const_26 = A_arbace_instant__init_A_const_pool.A[64]; A_arbace_instant__init_A_const_27 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[65]); A_arbace_instant__init_A_const_28 = A_arbace_instant__init_A_const_pool.A[66]; A_arbace_instant__init_A_const_29 = A_arbace_instant__init_A_const_pool.A[67]; A_arbace_instant__init_A_const_30 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[68]); A_arbace_instant__init_A_const_31 = A_arbace_instant__init_A_const_pool.A[69]; A_arbace_instant__init_A_const_32 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[70]); A_arbace_instant__init_A_const_33 = A_arbace_instant__init_A_const_pool.A[71]; A_arbace_instant__init_A_const_34 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[72]); A_arbace_instant__init_A_const_35 = A_arbace_instant__init_A_const_pool.A[73]; A_arbace_instant__init_A_const_36 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[74]); A_arbace_instant__init_A_const_37 = jrt.Class_Cast(A_arbace_instant__init_A_const_pool.A[75]) }

func A_arbace_instant__init_A_clinit_p3() { A_arbace_instant__init_A_const_38 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[76]); A_arbace_instant__init_A_const_39 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[77]); A_arbace_instant__init_A_const_40 = A_arbace_instant__init_A_const_pool.A[78]; A_arbace_instant__init_A_const_41 = jrt.Class_Cast(A_arbace_instant__init_A_const_pool.A[79]); A_arbace_instant__init_A_const_42 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[80]); A_arbace_instant__init_A_const_43 = A_arbace_instant__init_A_const_pool.A[81]; A_arbace_instant__init_A_const_44 = jrt.Class_Cast(A_arbace_instant__init_A_const_pool.A[82]); A_arbace_instant__init_A_const_45 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[83]); A_arbace_instant__init_A_const_46 = A_arbace_instant__init_A_const_pool.A[84]; A_arbace_instant__init_A_const_47 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[85]); A_arbace_instant__init_A_const_48 = A_arbace_instant__init_A_const_pool.A[86]; A_arbace_instant__init_A_const_49 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[87]); A_arbace_instant__init_A_const_50 = A_arbace_instant__init_A_const_pool.A[88] }

func A_arbace_instant__init_A_clinit_p4() { A_arbace_instant__init_A_const_51 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[89]); A_arbace_instant__init_A_const_52 = A_arbace_instant__init_A_const_pool.A[90]; A_arbace_instant__init_A_const_53 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[91]); A_arbace_instant__init_A_const_54 = A_arbace_instant__init_A_const_pool.A[92]; A_arbace_instant__init_A_const_55 = lang.Var_Cast(A_arbace_instant__init_A_const_pool.A[93]); A_arbace_instant__init_A_const_56 = A_arbace_instant__init_A_const_pool.A[94] }

func A_arbace_instant__init_A_New() *A_arbace_instant__init_A { A_arbace_instant__init_A_Init(); t := &A_arbace_instant__init_A{}; t.Ctor(); return t }

func (t *A_arbace_instant__init_A) Ctor() {}

func (t *A_arbace_instant__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_instant__init_A) GetClass__Class() *jrt.Class { return A_arbace_instant__init_A_class }

func (t *A_arbace_instant__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_instant__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_instant__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_instant__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_instant__init_A); return ok }

func A_arbace_instant__init_A_Cast(x any) *A_arbace_instant__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_instant__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_instant__init_A_class)) }; return v }
