//line j2g_strings.ae:1
package aot_arbace_instant

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn14,arbace.instantyn5,throwyn27,java.lang.RuntimeException.ys11,arbace.core8,when-notys14,arbace.instant4,failys14,arbace.instant6,verifykn4,elsev11,arbace.core5,referR0,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjR1,v11,arbace.core3,seqv11,arbace.core6,concatv11,arbace.core4,listR2,R3,R4,R5,R6,v11,arbace.core6,pr-strv11,arbace.core3,modv11,arbace.core3,notv14,arbace.instant10,divisible?R7,c48,v11,arbace.core10,re-matchesv14,arbace.instant9,timestampv14,arbace.instant9,parse-intl1,l0,v14,arbace.instant15,zero-fill-rightl9,l-1,l4,v14,arbace.instant12,indivisible?l100,l400,V13,nl31,l28,l31,l30,l31,l30,l31,l31,l30,l31,l30,l31,V13,nl31,l29,l31,l30,l31,l30,l31,l31,l30,l31,l30,l31,v11,arbace.core2,<=l12,v14,arbace.instant13,days-in-monthv14,arbace.instant10,leap-year?l23,l59,l60,l999999999,v14,arbace.instant21,gregorian-cutover-dayv14,arbace.instant11,days->civilv11,arbace.core6,formatv14,arbace.instant10,print-datev14,arbace.instant14,print-calendarv14,arbace.instant15,print-timestampv14,arbace.instant11,civil->daysv14,arbace.instant15,parse-timestampv14,arbace.instant9,validatedv14,arbace.instant14,construct-datev14,arbace.instant18,construct-calendarv14,arbace.instant19,construct-timestamp")

var Lit_1 *jrt.String = jrt.Intern("GMT%s%02d:%02d")

var Lit_2 *jrt.String = jrt.Intern("-")

var Lit_3 *jrt.String = jrt.Intern("+")

var Lit_4 *jrt.String = jrt.Intern("java.util.Calendar")

var Lit_5 *jrt.String = jrt.Intern("java.util.Date")

var Lit_6 *jrt.String = jrt.Intern("java.util.GregorianCalendar")

var Lit_7 *jrt.String = jrt.Intern("java.util.TimeZone")

var Lit_8 *jrt.String = jrt.Intern("java.sql.Timestamp")

var Lit_9 *jrt.String = jrt.Intern("arbace.instant$fn__783000031$fn__783000032")

var Lit_10 *jrt.String = jrt.Intern("Unrecognized date/time syntax: ")

var Lit_11 *jrt.String = jrt.Intern("%1$tFT%1$tT.%1$tL%1$tz")

var Lit_12 *jrt.String = jrt.Intern("#inst \"")

var Lit_13 *jrt.String = jrt.Intern(":")

var Lit_14 *jrt.String = jrt.Intern("\"")

var Lit_15 *jrt.String = jrt.Intern("%04d-%02d-%02dT%02d:%02d:%02d.%03d-00:00")

var Lit_16 *jrt.String = jrt.Intern("%04d-%02d-%02dT%02d:%02d:%02d")

var Lit_17 *jrt.String = jrt.Intern(".%09d-00:00")

var Lit_18 *jrt.String = jrt.Intern("arbace.instant$validated$fn__783000035")

var Lit_19 *jrt.String = jrt.Intern("failed: (<= 1 months 12)")

var Lit_20 *jrt.String = jrt.Intern("failed: (<= 1 days (days-in-month months (leap-year? years)))")

var Lit_21 *jrt.String = jrt.Intern("failed: (<= 0 hours 23)")

var Lit_22 *jrt.String = jrt.Intern("failed: (<= 0 minutes 59)")

var Lit_23 *jrt.String = jrt.Intern("failed: (<= 0 seconds (if (= minutes 59) 60 59))")

var Lit_24 *jrt.String = jrt.Intern("failed: (<= 0 nanoseconds 999999999)")

var Lit_25 *jrt.String = jrt.Intern("failed: (<= -1 offset-sign 1)")

var Lit_26 *jrt.String = jrt.Intern("failed: (<= 0 offset-hours 23)")

var Lit_27 *jrt.String = jrt.Intern("failed: (<= 0 offset-minutes 59)")

var Lit_28 *jrt.String = jrt.Intern("failed: ")

var Lit_29 *jrt.String = jrt.Intern("yn14,arbace.instantyn11,arbace.corekn7,privatekn8,arglistsyn3,msgkn4,linekn6,columnkn4,fileyn4,testyn3,numyn3,divkn3,tagyn6,Stringyn5,widthyn11,new-instantyn12,CharSequencekn3,docyn4,yearyn12,new-instanceyn1,zyn1,yyn1,myn1,dyn14,java.util.Dateyn14,java.io.Writeryn18,java.util.Calendaryn18,java.sql.Timestampyn5,yearsyn6,monthsyn4,daysyn5,hoursyn7,minutesyn7,secondsyn11,nanosecondsyn11,offset-signyn12,offset-hoursyn14,offset-minutesyn27,java.util.GregorianCalendarv11,arbace.core5,in-nsR0,R1,v11,arbace.core20,*warn-on-reflection*v14,arbace.instant4,failm10,R2,TR3,L1,V1,R4,R5,i30,R6,i1,R7,s17,arbace/instant.aev14,arbace.instant6,verifym10,R2,TR3,L2,V2,R8,R4,V1,R8,R5,i34,R6,i1,R7,s17,arbace/instant.aev14,arbace.instant10,divisible?m10,R2,TR3,L1,V2,R9,R10,R5,i38,R6,i1,R7,s17,arbace/instant.aev14,arbace.instant12,indivisible?m10,R2,TR3,L1,V2,R9,R10,R5,i42,R6,i1,R7,s17,arbace/instant.aev14,arbace.instant9,parse-intm10,R2,TR3,L1,V1,Myn1,sm2,R11,R12,R5,i49,R6,i1,R7,s17,arbace/instant.aev14,arbace.instant15,zero-fill-rightm10,R2,TR3,L1,V2,Myn1,sm2,R11,R12,R13,R5,i52,R6,i1,R7,s17,arbace/instant.aev14,arbace.instant9,timestampp113,(\\d\\d\\d\\d)(?:-(\\d\\d)(?:-(\\d\\d)(?:[T](\\d\\d)(?::(\\d\\d)(?::(\\d\\d)(?:[.](\\d+))?)?)?)?)?)?(?:[Z]|([-+])(\\d\\d):(\\d\\d))?m8,R2,TR5,i60,R6,i1,R7,s17,arbace/instant.aev14,arbace.instant15,parse-timestampm10,R3,L1,V2,R14,Myn2,csm2,R11,R15,R16,s1900,Parse a string containing an RFC3339-like like timestamp.\n\nThe function new-instant is called with the following arguments.\n\n                min  max           default\n                ---  ------------  -------\n  years          0           9999      N/A (s must provide years)\n  months         1             12        1\n  days           1             31        1 (actual max days depends\n  hours          0             23        0  on month and year)\n  minutes        0             59        0\n  seconds        0             60        0 (though 60 is only valid\n  nanoseconds    0      999999999        0  when minutes is 59)\n  offset-sign   -1              1        0\n  offset-hours   0             23        0\n  offset-minutes 0             59        0\n\nThese are all integers and will be non-nil. (The listed defaults\nwill be passed if the corresponding field is not present in s.)\n\nGrammar (of s):\n\n  date-fullyear   = 4DIGIT\n  date-month      = 2DIGIT  ; 01-12\n  date-mday       = 2DIGIT  ; 01-28, 01-29, 01-30, 01-31 based on\n                            ; month/year\n  time-hour       = 2DIGIT  ; 00-23\n  time-minute     = 2DIGIT  ; 00-59\n  time-second     = 2DIGIT  ; 00-58, 00-59, 00-60 based on leap second\n                            ; rules\n  time-secfrac    = '.' 1*DIGIT\n  time-numoffset  = ('+' / '-') time-hour ':' time-minute\n  time-offset     = 'Z' / time-numoffset\n\n  time-part       = time-hour [ ':' time-minute [ ':' time-second\n                    [time-secfrac] [time-offset] ] ]\n\n  timestamp       = date-year [ '-' date-month [ '-' date-mday\n                    [ 'T' time-part ] ] ]\n\nUnlike RFC3339:\n\n  - we only parse the timestamp format\n  - timestamp can elide trailing components\n  - time-offset is optional (defaults to +00:00)\n\nThough time-offset is syntactically optional, a missing time-offset\nwill be treated as if the time-offset zero (+00:00) had been\nspecified.\nR5,i63,R6,i1,R7,s17,arbace/instant.aev14,arbace.instant10,leap-year?m10,R2,TR3,L1,V1,R17,R5,i136,R6,i1,R7,s17,arbace/instant.aev14,arbace.instant13,days-in-monthm8,R2,TR5,i142,R6,i1,R7,s17,arbace/instant.aev14,arbace.instant9,validatedm10,R3,L1,V1,R18,R16,s231,Return a function which constructs an instant by calling constructor\nafter first validating that those arguments are in range and otherwise\nplausible. The resulting function will throw an exception if called\nwith invalid arguments.R5,i148,R6,i1,R7,s17,arbace/instant.aev14,arbace.instant21,gregorian-cutover-dayl-141427,m10,R2,TR5,i173,R6,i1,R7,s17,arbace/instant.aeR16,s162,The first day of the Gregorian calendar, 1582-10-15, in days since 1970-01-01, as\n  java.util.GregorianCalendar's default cutover (the Julian calendar before it).v14,arbace.instant11,days->civilm12,R2,TR3,L1,V1,R19,R16,s172,[year month day] of a count of days since 1970-01-01: the Gregorian calendar from its\n  cutover, the Julian before (GregorianCalendar's); the year astronomical (0 is 1 BC).R5,i178,R6,i1,R7,s17,arbace/instant.aev14,arbace.instant11,civil->daysm12,R2,TR3,L1,V3,R20,R21,R22,R16,s149,The count of days since 1970-01-01 of a (astronomical) year, month, day, as\n  GregorianCalendar counts it: Gregorian from the cutover, Julian before.R5,i201,R6,i1,R7,s17,arbace/instant.aev14,arbace.instant10,print-datem12,R2,TR3,L1,V2,Myn1,dm2,R11,R23,Myn1,wm2,R11,R24,R16,s59,Print a java.util.Date as RFC3339 timestamp, always in UTC.R5,i218,R6,i1,R7,s17,arbace/instant.aev11,arbace.core12,print-methodC14,java.util.Datev11,arbace.core9,print-dupv14,arbace.instant14,print-calendarm12,R2,TR3,L1,V2,Myn1,cm2,R11,R25,Myn1,wm2,R11,R24,R16,s69,Print a java.util.Calendar as RFC3339 timestamp, preserving timezone.R5,i239,R6,i1,R7,s17,arbace/instant.aeC18,java.util.Calendarv14,arbace.instant15,print-timestampm12,R2,TR3,L1,V2,Myn2,tsm2,R11,R26,Myn1,wm2,R11,R24,R16,s63,Print a java.sql.Timestamp as RFC3339 timestamp, always in UTC.R5,i259,R6,i1,R7,s17,arbace/instant.aeC18,java.sql.Timestampv14,arbace.instant14,construct-datem12,R2,TR3,L1,V10,R27,R28,R29,R30,R31,R32,R33,R34,R35,R36,R16,s102,Construct a java.util.Date, which expresses the original instant as\nmilliseconds since the epoch, UTC.R5,i286,R6,i1,R7,s17,arbace/instant.aev14,arbace.instant17,read-instant-datem10,R3,L1,V1,Myn2,csm2,R11,R15,R16,s168,To read an instant as a java.util.Date, bind *data-readers* to a map with\nthis var as the value for the 'inst key. The timezone offset will be used\nto convert into UTC.R5,i296,R6,i1,R7,s17,arbace/instant.aev14,arbace.instant18,construct-calendarm12,R2,TR3,L1,MV10,R27,R28,R29,R30,R31,R32,R33,R34,R35,R36,m2,R11,R37,R16,s118,Construct a java.util.Calendar, preserving the timezone\noffset, but truncating the subsecond fraction to milliseconds.R5,i303,R6,i1,R7,s17,arbace/instant.aev14,arbace.instant19,construct-timestampm12,R2,TR3,L1,V10,R27,R28,R29,R30,R31,R32,R33,R34,R35,R36,R16,s63,Construct a java.sql.Timestamp, which has nanosecond precision.R5,i316,R6,i1,R7,s17,arbace/instant.aev14,arbace.instant21,read-instant-calendarm10,R3,L1,V1,Myn2,csm2,R11,R15,R16,s159,To read an instant as a java.util.Calendar, bind *data-readers* to a map with\nthis var as the value for the 'inst key.  Calendar preserves the timezone\noffset.R5,i328,R6,i1,R7,s17,arbace/instant.aev14,arbace.instant22,read-instant-timestampm10,R3,L1,V1,Myn2,csm2,R11,R15,R16,s238,To read an instant as a java.sql.Timestamp, bind *data-readers* to a\nmap with this var as the value for the 'inst key. Timestamp preserves\nfractional seconds with nanosecond precision. The timezone offset will\nbe used to convert into UTC.R5,i335,R6,i1,R7,s17,arbace/instant.ae")

var Lit_30 *jrt.String = jrt.Intern("arbace.instant$eval783000002$loading__1927001464__auto____783000003")

var Lit_31 *jrt.String = jrt.Intern("arbace.instant$eval783000006$fn__783000007")

var Lit_32 *jrt.String = jrt.Intern("arbace.instant$fail")

var Lit_33 *jrt.String = jrt.Intern("arbace.instant$verify")

var Lit_34 *jrt.String = jrt.Intern("arbace.instant$divisible_QMARK_")

var Lit_35 *jrt.String = jrt.Intern("arbace.instant$indivisible_QMARK_")

var Lit_36 *jrt.String = jrt.Intern("arbace.instant$parse_int")

var Lit_37 *jrt.String = jrt.Intern("arbace.instant$zero_fill_right")

var Lit_38 *jrt.String = jrt.Intern("arbace.instant$parse_timestamp")

var Lit_39 *jrt.String = jrt.Intern("arbace.instant$leap_year_QMARK_")

var Lit_40 *jrt.String = jrt.Intern("arbace.instant$fn__783000031")

var Lit_41 *jrt.String = jrt.Intern("arbace.instant$validated")

var Lit_42 *jrt.String = jrt.Intern("arbace.instant$days__GT_civil")

var Lit_43 *jrt.String = jrt.Intern("arbace.instant$civil__GT_days")

var Lit_44 *jrt.String = jrt.Intern("arbace.instant$print_date")

var Lit_45 *jrt.String = jrt.Intern("arbace.instant$eval783000044$fn__783000045")

var Lit_46 *jrt.String = jrt.Intern("arbace.instant$eval783000048$fn__783000049")

var Lit_47 *jrt.String = jrt.Intern("arbace.instant$print_calendar")

var Lit_48 *jrt.String = jrt.Intern("arbace.instant$eval783000053$fn__783000054")

var Lit_49 *jrt.String = jrt.Intern("arbace.instant$eval783000057$fn__783000058")

var Lit_50 *jrt.String = jrt.Intern("arbace.instant$print_timestamp")

var Lit_51 *jrt.String = jrt.Intern("arbace.instant$eval783000065$fn__783000066")

var Lit_52 *jrt.String = jrt.Intern("arbace.instant$eval783000069$fn__783000070")

var Lit_53 *jrt.String = jrt.Intern("arbace.instant$construct_date")

var Lit_54 *jrt.String = jrt.Intern("arbace.instant$read_instant_date")

var Lit_55 *jrt.String = jrt.Intern("arbace.instant$construct_calendar")

var Lit_56 *jrt.String = jrt.Intern("arbace.instant$construct_timestamp")

var Lit_57 *jrt.String = jrt.Intern("arbace.instant$read_instant_calendar")

var Lit_58 *jrt.String = jrt.Intern("arbace.instant$read_instant_timestamp")
