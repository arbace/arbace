//line a2g_strings.ae:1
package aot_arbace_pprint_dispatch

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.pprintkn7,privatekn8,arglistskn3,tagyn19,arbace.lang.MultiFnyn12,dispatch-valyn4,funckn3,dockn4,linekn6,columnkn4,fileyn5,quoteys11,arbace.core5,derefyn3,varys11,arbace.core7,unquoteyn4,aliskn8,declaredyn3,objyn4,avecyn4,amapyn4,asetyn1,okn5,addedyn6,objectkn7,defaultyn4,formyn9,referenceyn12,has-doc-str?yn11,binding-veckn7,dynamicyn1,.yn3,fn*yn10,when-firstyn2,ifyn5,condpyn2,..yn8,defmacroyn4,defnyn4,loopyn6,structyn5,doseqyn6,if-notyn8,when-notyn3,defyn4,whenyn9,with-openyn15,with-local-varsyn7,defonceyn8,when-letyn2,nsyn7,dotimesyn4,condyn3,letyn2,fnyn5,defn-yn7,lockingyn2,->yn6,if-letyn7,bindingyn10,struct-mapyn3,symv11,arbace.core5,in-nsR0,v13,arbace.pprint10,use-methodm12,R1,TR2,L1,V3,Myn7,multifnm2,R3,R4,R5,R6,R7,s83,Installs a function as a new method of multimethod associated with dispatch-value. R8,i19,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint13,reader-macrosm8,R11,s1,'R12,s1,@R13,s2,#'R14,s1,~m8,R1,TR8,i44,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint19,pprint-reader-macrom10,R1,TR2,L1,V1,R15,R8,i48,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint10,pprint-mapm8,R16,TR8,i64,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint11,pprint-metam10,R1,TR2,L1,V1,R17,R8,i66,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint18,pprint-simple-listm10,R1,TR2,L1,V1,R15,R8,i75,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint11,pprint-listm10,R1,TR2,L1,V1,R15,R8,i86,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint13,pprint-vectorm10,R1,TR2,L1,V1,R18,R8,i91,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint12,pprint-arraym8,R1,TR8,i102,R9,i1,R10,s25,arbace/pprint/dispatch.aem10,R1,TR2,L1,V1,R19,R8,i105,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint10,pprint-setm10,R1,TR2,L1,V1,R20,R8,i126,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint13,pprint-iderefm10,R1,TR2,L1,V1,R21,R8,i137,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint13,pprint-pqueuem8,R1,TR8,i142,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint21,pprint-simple-defaultm10,R1,TR2,L1,V1,R17,R8,i144,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint15,simple-dispatchm12,R22,s3,1.2R2,V1,V1,R23,R7,s68,The pretty print dispatch function for simple data structure format.R8,i150,R9,i1,R10,s25,arbace/pprint/dispatch.aev11,arbace.core5,derefv11,arbace.core5,classR24,v11,arbace.core16,global-hierarchym12,R22,s3,1.2R2,V1,V1,R23,R7,s68,The pretty print dispatch function for simple data structure format.R8,i150,R9,i1,R10,s25,arbace/pprint/dispatch.aeC16,arbace.lang.ISeqC29,arbace.lang.IPersistentVectorC26,arbace.lang.IPersistentMapC26,arbace.lang.IPersistentSetC27,arbace.lang.PersistentQueueC15,arbace.lang.VarC18,arbace.lang.IDerefv11,arbace.core2,prv13,arbace.pprint23,pprint-simple-code-listm8,R16,TR8,i170,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint8,bracketsm12,R1,TR2,L1,V1,R25,R7,s40,Figure out which kind of brackets to useR8,i178,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint19,pprint-ns-referencem12,R1,TR2,L1,V1,R26,R7,s73,Pretty print a single reference (import, use, etc.) from a namespace declR8,i185,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint9,pprint-nsm12,R1,TR2,L1,V1,R15,R7,s48,The pretty print dispatch chunk for the ns macroR8,i219,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint17,pprint-hold-firstm8,R1,TR8,i250,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint11,single-defnm10,R1,TR2,L1,V2,R15,R27,R8,i257,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint10,multi-defnm10,R1,TR2,L1,V2,R15,R27,R8,i266,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint11,pprint-defnm10,R1,TR2,L1,V1,R15,R8,i272,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint19,pprint-binding-formm10,R1,TR2,L1,V1,R28,R8,i297,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint10,pprint-letm10,R1,TR2,L1,V1,R15,R8,i312,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint9,pprint-ifm8,R1,TR8,i326,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint11,pprint-condm10,R1,TR2,L1,V1,R15,R8,i328,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint12,pprint-condpm10,R1,TR2,L1,V1,R15,R8,i348,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint12,*symbol-map*m10,R1,TR29,TR8,i368,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint16,pprint-anon-funcm10,R1,TR2,L1,V1,R15,R8,i370,R9,i1,R10,s25,arbace/pprint/dispatch.aem10,R1,TR2,L1,V1,R15,R8,i392,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint9,two-formsm10,R1,TR2,L1,V1,R19,R8,i405,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint11,add-core-nsm10,R1,TR2,L1,V1,R19,R8,i412,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint12,*code-table*m10,R1,TR29,TR8,i421,R9,i1,R10,s25,arbace/pprint/dispatch.aeR30,R31,R32,R33,R34,R35,R36,R37,R38,R39,R40,R41,R42,R43,R44,R45,R46,R47,R48,R49,R50,R51,R52,R53,R54,R55,R56,R57,R58,R59,v13,arbace.pprint16,pprint-code-listm10,R1,TR2,L1,V1,R15,R8,i438,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint18,pprint-code-symbolm10,R1,TR2,L1,V1,R60,R8,i444,R9,i1,R10,s25,arbace/pprint/dispatch.aev13,arbace.pprint13,code-dispatchm12,R22,s3,1.2R2,V1,V1,R23,R7,s68,The pretty print dispatch function for pretty printing Clojure code.R8,i451,R9,i1,R10,s25,arbace/pprint/dispatch.aem12,R22,s3,1.2R2,V1,V1,R23,R7,s68,The pretty print dispatch function for pretty printing Clojure code.R8,i451,R9,i1,R10,s25,arbace/pprint/dispatch.aeC18,arbace.lang.Symbolv13,arbace.pprint19,set-pprint-dispatch")

var Lit_1 *jrt.String = jrt.Intern("arbace.pprint$use_method")

var Lit_2 *jrt.String = jrt.Intern("arbace.pprint$pprint_reader_macro")

var Lit_3 *jrt.String = jrt.Intern("arbace.pprint$pprint_meta")

var Lit_4 *jrt.String = jrt.Intern("arbace.pprint$pprint_simple_list")

var Lit_5 *jrt.String = jrt.Intern("arbace.pprint$pprint_list")

var Lit_6 *jrt.String = jrt.Intern("arbace.pprint$pprint_vector")

var Lit_7 *jrt.String = jrt.Intern("arbace.pprint$fn__740000014")

var Lit_8 *jrt.String = jrt.Intern("arbace.pprint$pprint_map")

var Lit_9 *jrt.String = jrt.Intern("arbace.pprint$pprint_set")

var Lit_10 *jrt.String = jrt.Intern("arbace.pprint$pprint_ideref")

var Lit_11 *jrt.String = jrt.Intern("arbace.pprint$fn__740000032")

var Lit_12 *jrt.String = jrt.Intern("arbace.pprint$pprint_simple_default")

var Lit_13 *jrt.String = jrt.Intern("simple-dispatch")

var Lit_14 *jrt.String = jrt.Intern("arbace.pprint$brackets")

var Lit_15 *jrt.String = jrt.Intern("arbace.pprint$pprint_ns_reference")

var Lit_16 *jrt.String = jrt.Intern("arbace.pprint$pprint_ns")

var Lit_17 *jrt.String = jrt.Intern("arbace.pprint$fn__740000107")

var Lit_18 *jrt.String = jrt.Intern("arbace.pprint$single_defn")

var Lit_19 *jrt.String = jrt.Intern("arbace.pprint$multi_defn")

var Lit_20 *jrt.String = jrt.Intern("arbace.pprint$pprint_defn")

var Lit_21 *jrt.String = jrt.Intern("arbace.pprint$pprint_binding_form")

var Lit_22 *jrt.String = jrt.Intern("arbace.pprint$pprint_let")

var Lit_23 *jrt.String = jrt.Intern("arbace.pprint$fn__740000152")

var Lit_24 *jrt.String = jrt.Intern("arbace.pprint$pprint_cond")

var Lit_25 *jrt.String = jrt.Intern("arbace.pprint$pprint_condp")

var Lit_26 *jrt.String = jrt.Intern("arbace.pprint$pprint_anon_func")

var Lit_27 *jrt.String = jrt.Intern("arbace.pprint$pprint_simple_code_list")

var Lit_28 *jrt.String = jrt.Intern("arbace.pprint$two_forms")

var Lit_29 *jrt.String = jrt.Intern("arbace.pprint$add_core_ns")

var Lit_30 *jrt.String = jrt.Intern("arbace.pprint$pprint_code_list")

var Lit_31 *jrt.String = jrt.Intern("arbace.pprint$pprint_code_symbol")

var Lit_32 *jrt.String = jrt.Intern("code-dispatch")
