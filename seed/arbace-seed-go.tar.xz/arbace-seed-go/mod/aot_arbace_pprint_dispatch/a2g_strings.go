//line a2g_strings.ae:1
package aot_arbace_pprint_dispatch

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("in-ns")

var Lit_2 *jrt.String = jrt.Intern("arbace.pprint")

var Lit_3 *jrt.String = jrt.Intern("use-method")

var Lit_4 *jrt.String = jrt.Intern("private")

var Lit_5 *jrt.String = jrt.Intern("arglists")

var Lit_6 *jrt.String = jrt.Intern("multifn")

var Lit_7 *jrt.String = jrt.Intern("tag")

var Lit_8 *jrt.String = jrt.Intern("arbace.lang.MultiFn")

var Lit_9 *jrt.String = jrt.Intern("dispatch-val")

var Lit_10 *jrt.String = jrt.Intern("func")

var Lit_11 *jrt.String = jrt.Intern("doc")

var Lit_12 *jrt.String = jrt.Intern("Installs a function as a new method of multimethod associated with dispatch-value. ")

var Lit_13 *jrt.String = jrt.Intern("line")

var Lit_14 *jrt.String = jrt.Intern("column")

var Lit_15 *jrt.String = jrt.Intern("file")

var Lit_16 *jrt.String = jrt.Intern("arbace/pprint/dispatch.ae")

var Lit_17 *jrt.String = jrt.Intern("reader-macros")

var Lit_18 *jrt.String = jrt.Intern("quote")

var Lit_19 *jrt.String = jrt.Intern("'")

var Lit_20 *jrt.String = jrt.Intern("deref")

var Lit_21 *jrt.String = jrt.Intern("@")

var Lit_22 *jrt.String = jrt.Intern("var")

var Lit_23 *jrt.String = jrt.Intern("#'")

var Lit_24 *jrt.String = jrt.Intern("unquote")

var Lit_25 *jrt.String = jrt.Intern("~")

var Lit_26 *jrt.String = jrt.Intern("pprint-reader-macro")

var Lit_27 *jrt.String = jrt.Intern("alis")

var Lit_28 *jrt.String = jrt.Intern("pprint-map")

var Lit_29 *jrt.String = jrt.Intern("declared")

var Lit_30 *jrt.String = jrt.Intern("pprint-meta")

var Lit_31 *jrt.String = jrt.Intern("obj")

var Lit_32 *jrt.String = jrt.Intern("pprint-simple-list")

var Lit_33 *jrt.String = jrt.Intern("pprint-list")

var Lit_34 *jrt.String = jrt.Intern("pprint-vector")

var Lit_35 *jrt.String = jrt.Intern("avec")

var Lit_36 *jrt.String = jrt.Intern("pprint-array")

var Lit_37 *jrt.String = jrt.Intern("amap")

var Lit_38 *jrt.String = jrt.Intern("pprint-set")

var Lit_39 *jrt.String = jrt.Intern("aset")

var Lit_40 *jrt.String = jrt.Intern("pprint-ideref")

var Lit_41 *jrt.String = jrt.Intern("o")

var Lit_42 *jrt.String = jrt.Intern("pprint-pqueue")

var Lit_43 *jrt.String = jrt.Intern("pprint-simple-default")

var Lit_44 *jrt.String = jrt.Intern("simple-dispatch")

var Lit_45 *jrt.String = jrt.Intern("added")

var Lit_46 *jrt.String = jrt.Intern("1.2")

var Lit_47 *jrt.String = jrt.Intern("object")

var Lit_48 *jrt.String = jrt.Intern("The pretty print dispatch function for simple data structure format.")

var Lit_49 *jrt.String = jrt.Intern("class")

var Lit_50 *jrt.String = jrt.Intern("default")

var Lit_51 *jrt.String = jrt.Intern("global-hierarchy")

var Lit_52 *jrt.String = jrt.Intern("arbace.lang.ISeq")

var Lit_53 *jrt.String = jrt.Intern("arbace.lang.IPersistentVector")

var Lit_54 *jrt.String = jrt.Intern("arbace.lang.IPersistentMap")

var Lit_55 *jrt.String = jrt.Intern("arbace.lang.IPersistentSet")

var Lit_56 *jrt.String = jrt.Intern("arbace.lang.PersistentQueue")

var Lit_57 *jrt.String = jrt.Intern("arbace.lang.Var")

var Lit_58 *jrt.String = jrt.Intern("arbace.lang.IDeref")

var Lit_59 *jrt.String = jrt.Intern("pr")

var Lit_60 *jrt.String = jrt.Intern("pprint-simple-code-list")

var Lit_61 *jrt.String = jrt.Intern("brackets")

var Lit_62 *jrt.String = jrt.Intern("form")

var Lit_63 *jrt.String = jrt.Intern("Figure out which kind of brackets to use")

var Lit_64 *jrt.String = jrt.Intern("pprint-ns-reference")

var Lit_65 *jrt.String = jrt.Intern("reference")

var Lit_66 *jrt.String = jrt.Intern("Pretty print a single reference (import, use, etc.) from a namespace decl")

var Lit_67 *jrt.String = jrt.Intern("pprint-ns")

var Lit_68 *jrt.String = jrt.Intern("The pretty print dispatch chunk for the ns macro")

var Lit_69 *jrt.String = jrt.Intern("pprint-hold-first")

var Lit_70 *jrt.String = jrt.Intern("single-defn")

var Lit_71 *jrt.String = jrt.Intern("has-doc-str?")

var Lit_72 *jrt.String = jrt.Intern("multi-defn")

var Lit_73 *jrt.String = jrt.Intern("pprint-defn")

var Lit_74 *jrt.String = jrt.Intern("pprint-binding-form")

var Lit_75 *jrt.String = jrt.Intern("binding-vec")

var Lit_76 *jrt.String = jrt.Intern("pprint-let")

var Lit_77 *jrt.String = jrt.Intern("pprint-if")

var Lit_78 *jrt.String = jrt.Intern("pprint-cond")

var Lit_79 *jrt.String = jrt.Intern("pprint-condp")

var Lit_80 *jrt.String = jrt.Intern("*symbol-map*")

var Lit_81 *jrt.String = jrt.Intern("dynamic")

var Lit_82 *jrt.String = jrt.Intern("pprint-anon-func")

var Lit_83 *jrt.String = jrt.Intern("two-forms")

var Lit_84 *jrt.String = jrt.Intern("add-core-ns")

var Lit_85 *jrt.String = jrt.Intern("*code-table*")

var Lit_86 *jrt.String = jrt.Intern(".")

var Lit_87 *jrt.String = jrt.Intern("fn*")

var Lit_88 *jrt.String = jrt.Intern("when-first")

var Lit_89 *jrt.String = jrt.Intern("if")

var Lit_90 *jrt.String = jrt.Intern("condp")

var Lit_91 *jrt.String = jrt.Intern("..")

var Lit_92 *jrt.String = jrt.Intern("defmacro")

var Lit_93 *jrt.String = jrt.Intern("defn")

var Lit_94 *jrt.String = jrt.Intern("loop")

var Lit_95 *jrt.String = jrt.Intern("struct")

var Lit_96 *jrt.String = jrt.Intern("doseq")

var Lit_97 *jrt.String = jrt.Intern("if-not")

var Lit_98 *jrt.String = jrt.Intern("when-not")

var Lit_99 *jrt.String = jrt.Intern("def")

var Lit_100 *jrt.String = jrt.Intern("when")

var Lit_101 *jrt.String = jrt.Intern("with-open")

var Lit_102 *jrt.String = jrt.Intern("with-local-vars")

var Lit_103 *jrt.String = jrt.Intern("defonce")

var Lit_104 *jrt.String = jrt.Intern("when-let")

var Lit_105 *jrt.String = jrt.Intern("ns")

var Lit_106 *jrt.String = jrt.Intern("dotimes")

var Lit_107 *jrt.String = jrt.Intern("cond")

var Lit_108 *jrt.String = jrt.Intern("let")

var Lit_109 *jrt.String = jrt.Intern("fn")

var Lit_110 *jrt.String = jrt.Intern("defn-")

var Lit_111 *jrt.String = jrt.Intern("locking")

var Lit_112 *jrt.String = jrt.Intern("->")

var Lit_113 *jrt.String = jrt.Intern("if-let")

var Lit_114 *jrt.String = jrt.Intern("binding")

var Lit_115 *jrt.String = jrt.Intern("struct-map")

var Lit_116 *jrt.String = jrt.Intern("pprint-code-list")

var Lit_117 *jrt.String = jrt.Intern("pprint-code-symbol")

var Lit_118 *jrt.String = jrt.Intern("sym")

var Lit_119 *jrt.String = jrt.Intern("code-dispatch")

var Lit_120 *jrt.String = jrt.Intern("The pretty print dispatch function for pretty printing Clojure code.")

var Lit_121 *jrt.String = jrt.Intern("arbace.lang.Symbol")

var Lit_122 *jrt.String = jrt.Intern("set-pprint-dispatch")
