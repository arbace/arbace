//line a2g_up.ae:1
package aot_arbace_pprint_dispatch

import "arbace/lang"


func Up_Symbol_IObj(p *lang.Symbol) lang.IObj { if p == nil { return nil }; return p }

func Up_Var_IRef(p *lang.Var) lang.IRef { if p == nil { return nil }; return p }
