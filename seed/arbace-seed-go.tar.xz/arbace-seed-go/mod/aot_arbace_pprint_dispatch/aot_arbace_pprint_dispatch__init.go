//line aot_arbace_pprint_dispatch__init.ae:1
package aot_arbace_pprint_dispatch

import (
	"arbace/aot_arbace_pprint"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_pprint_dispatch__init_A_Load__O() any { A_arbace_pprint_dispatch__init_A_Init(); A_arbace_pprint_dispatch__init_A_Unit0__O(); A_arbace_pprint_dispatch__init_A_Unit1__O(); A_arbace_pprint_dispatch__init_A_Unit2__O(); A_arbace_pprint_dispatch__init_A_Unit3__O(); A_arbace_pprint_dispatch__init_A_Unit4__O(); A_arbace_pprint_dispatch__init_A_Unit5__O(); A_arbace_pprint_dispatch__init_A_Unit6__O(); A_arbace_pprint_dispatch__init_A_Unit7__O(); A_arbace_pprint_dispatch__init_A_Unit8__O(); A_arbace_pprint_dispatch__init_A_Unit9__O(); A_arbace_pprint_dispatch__init_A_Unit10__O(); A_arbace_pprint_dispatch__init_A_Unit11__O(); A_arbace_pprint_dispatch__init_A_Unit12__O(); A_arbace_pprint_dispatch__init_A_Unit13__O(); A_arbace_pprint_dispatch__init_A_Unit14__O(); A_arbace_pprint_dispatch__init_A_Unit15__O(); A_arbace_pprint_dispatch__init_A_Unit16__O(); A_arbace_pprint_dispatch__init_A_Unit17__O(); A_arbace_pprint_dispatch__init_A_Unit18__O(); A_arbace_pprint_dispatch__init_A_Unit19__O(); A_arbace_pprint_dispatch__init_A_Unit20__O(); A_arbace_pprint_dispatch__init_A_Unit21__O(); A_arbace_pprint_dispatch__init_A_Unit22__O(); A_arbace_pprint_dispatch__init_A_Unit23__O(); A_arbace_pprint_dispatch__init_A_Unit24__O(); A_arbace_pprint_dispatch__init_A_Unit25__O(); A_arbace_pprint_dispatch__init_A_Unit26__O(); A_arbace_pprint_dispatch__init_A_Unit27__O(); A_arbace_pprint_dispatch__init_A_Unit28__O(); A_arbace_pprint_dispatch__init_A_Unit29__O(); A_arbace_pprint_dispatch__init_A_Unit30__O(); A_arbace_pprint_dispatch__init_A_Unit31__O(); A_arbace_pprint_dispatch__init_A_Unit32__O(); A_arbace_pprint_dispatch__init_A_Unit33__O(); A_arbace_pprint_dispatch__init_A_Unit34__O(); A_arbace_pprint_dispatch__init_A_Unit35__O(); A_arbace_pprint_dispatch__init_A_Unit36__O(); A_arbace_pprint_dispatch__init_A_Unit37__O(); A_arbace_pprint_dispatch__init_A_Unit38__O(); A_arbace_pprint_dispatch__init_A_Unit39__O(); A_arbace_pprint_dispatch__init_A_Unit40__O(); A_arbace_pprint_dispatch__init_A_Unit41__O(); A_arbace_pprint_dispatch__init_A_Unit42__O(); A_arbace_pprint_dispatch__init_A_Unit43__O(); A_arbace_pprint_dispatch__init_A_Unit44__O(); A_arbace_pprint_dispatch__init_A_Unit45__O(); A_arbace_pprint_dispatch__init_A_Unit46__O(); A_arbace_pprint_dispatch__init_A_Unit47__O(); A_arbace_pprint_dispatch__init_A_Unit48__O(); A_arbace_pprint_dispatch__init_A_Unit49__O(); A_arbace_pprint_dispatch__init_A_Unit50__O(); A_arbace_pprint_dispatch__init_A_Unit51__O(); A_arbace_pprint_dispatch__init_A_Unit52__O(); A_arbace_pprint_dispatch__init_A_Unit53__O(); A_arbace_pprint_dispatch__init_A_Unit54__O(); A_arbace_pprint_dispatch__init_A_Unit55__O(); A_arbace_pprint_dispatch__init_A_Unit56__O(); A_arbace_pprint_dispatch__init_A_Unit57__O(); A_arbace_pprint_dispatch__init_A_Unit58__O(); return nil }











func A_arbace_pprint_dispatch__init_A_Unit0__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(17, 1); return lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_dispatch__init_A_const_1) }

func A_arbace_pprint_dispatch__init_A_Unit1__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_2; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_use_method_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_use_method_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1, false); aot_arbace_pprint.A_arbace_pprint_use_method_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_3)); return A_arbace_pprint_dispatch__init_A_const_2 }
























func A_arbace_pprint_dispatch__init_A_Unit2__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); A_arbace_pprint_dispatch__init_A_const_4.BindRoot_O__V(A_arbace_pprint_dispatch__init_A_const_5); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_6)); return A_arbace_pprint_dispatch__init_A_const_4 }



func A_arbace_pprint_dispatch__init_A_Unit3__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_7; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_reader_macro_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_reader_macro_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_2, false); aot_arbace_pprint.A_arbace_pprint_pprint_reader_macro_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_7; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_8)); return A_arbace_pprint_dispatch__init_A_const_7 }
//line :48:1
func A_arbace_pprint_dispatch__init_A_Unit58__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); return nil }















func A_arbace_pprint_dispatch__init_A_Unit4__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(64, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_9; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_10)); return A_arbace_pprint_dispatch__init_A_const_9 }

func A_arbace_pprint_dispatch__init_A_Unit5__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(66, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_11; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_meta_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_meta_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, false); aot_arbace_pprint.A_arbace_pprint_pprint_meta_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_12)); return A_arbace_pprint_dispatch__init_A_const_11 }








func A_arbace_pprint_dispatch__init_A_Unit6__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(75, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_13; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_simple_list_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_simple_list_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_4, false); aot_arbace_pprint.A_arbace_pprint_pprint_simple_list_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_14)); return A_arbace_pprint_dispatch__init_A_const_13 }










func A_arbace_pprint_dispatch__init_A_Unit7__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(86, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_15; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_list_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_list_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_5, false); aot_arbace_pprint.A_arbace_pprint_pprint_list_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_16)); return A_arbace_pprint_dispatch__init_A_const_15 }




func A_arbace_pprint_dispatch__init_A_Unit8__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(91, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_17; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_vector_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_vector_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_6, false); aot_arbace_pprint.A_arbace_pprint_pprint_vector_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_18)); return A_arbace_pprint_dispatch__init_A_const_17 }










func A_arbace_pprint_dispatch__init_A_Unit9__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(102, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_19; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_fn__740000014_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__740000014_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_7, false); aot_arbace_pprint.A_arbace_pprint_fn__740000014_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_20)); return A_arbace_pprint_dispatch__init_A_const_19 }


func A_arbace_pprint_dispatch__init_A_Unit10__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(105, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_9; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_map_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_map_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_8, false); aot_arbace_pprint.A_arbace_pprint_pprint_map_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_21)); return A_arbace_pprint_dispatch__init_A_const_9 }




















func A_arbace_pprint_dispatch__init_A_Unit11__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(126, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_22; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_set_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_set_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_9, false); aot_arbace_pprint.A_arbace_pprint_pprint_set_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_23)); return A_arbace_pprint_dispatch__init_A_const_22 }










func A_arbace_pprint_dispatch__init_A_Unit12__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(137, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_24; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_ideref_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_ideref_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_10, false); aot_arbace_pprint.A_arbace_pprint_pprint_ideref_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_25)); return A_arbace_pprint_dispatch__init_A_const_24 }




func A_arbace_pprint_dispatch__init_A_Unit13__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(142, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_26; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_fn__740000032_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__740000032_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_11, false); aot_arbace_pprint.A_arbace_pprint_fn__740000032_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_27)); return A_arbace_pprint_dispatch__init_A_const_26 }

func A_arbace_pprint_dispatch__init_A_Unit14__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(144, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_28; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_simple_default_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_simple_default_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_12, false); aot_arbace_pprint.A_arbace_pprint_pprint_simple_default_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_29)); return A_arbace_pprint_dispatch__init_A_const_28 }





func A_arbace_pprint_dispatch__init_A_Unit15__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(150, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_30; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_31)); v__1927000386__auto____1 = A_arbace_pprint_dispatch__init_A_const_30; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { tmp2 = lang.MultiFn_InstanceOf(lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_32.GetRawRoot__O()).Invoke_O__O(v__1927000386__auto____1)) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp3 *lang.Var = A_arbace_pprint_dispatch__init_A_const_30; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_36)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_30; var tmp5 *jrt.String = Lit_13; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_33.GetRawRoot__O()); var tmp7 any = A_arbace_pprint_dispatch__init_A_const_34; tmp4.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp5, tmp6, tmp7, A_arbace_pprint_dispatch__init_A_const_35)); return A_arbace_pprint_dispatch__init_A_const_30 } }





func A_arbace_pprint_dispatch__init_A_Unit16__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(156, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_dispatch__init_A_const_30.GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_37; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_pprint_dispatch__init_A_const_15.GetRawRoot__O()) }
func A_arbace_pprint_dispatch__init_A_Unit17__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(157, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_dispatch__init_A_const_30.GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_38; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_pprint_dispatch__init_A_const_17.GetRawRoot__O()) }
func A_arbace_pprint_dispatch__init_A_Unit18__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(158, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_dispatch__init_A_const_30.GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_39; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_pprint_dispatch__init_A_const_9.GetRawRoot__O()) }
func A_arbace_pprint_dispatch__init_A_Unit19__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(159, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_dispatch__init_A_const_30.GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_40; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_pprint_dispatch__init_A_const_22.GetRawRoot__O()) }
func A_arbace_pprint_dispatch__init_A_Unit20__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(160, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_dispatch__init_A_const_30.GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_41; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_pprint_dispatch__init_A_const_26.GetRawRoot__O()) }
func A_arbace_pprint_dispatch__init_A_Unit21__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(161, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_dispatch__init_A_const_30.GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_42; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_pprint_dispatch__init_A_const_28.GetRawRoot__O()) }
func A_arbace_pprint_dispatch__init_A_Unit22__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(162, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_dispatch__init_A_const_30.GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_43; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_pprint_dispatch__init_A_const_24.GetRawRoot__O()) }
func A_arbace_pprint_dispatch__init_A_Unit23__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(163, 1); return lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_pprint_dispatch__init_A_const_30.GetRawRoot__O(), nil, A_arbace_pprint_dispatch__init_A_const_44.Get__O()) }
func A_arbace_pprint_dispatch__init_A_Unit24__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(164, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_dispatch__init_A_const_30.GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_34; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_pprint_dispatch__init_A_const_28.GetRawRoot__O()) }





func A_arbace_pprint_dispatch__init_A_Unit25__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(170, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_45; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_46)); return A_arbace_pprint_dispatch__init_A_const_45 }







func A_arbace_pprint_dispatch__init_A_Unit26__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(178, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_47; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_brackets_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_brackets_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_14, false); aot_arbace_pprint.A_arbace_pprint_brackets_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_48)); return A_arbace_pprint_dispatch__init_A_const_47 }






func A_arbace_pprint_dispatch__init_A_Unit27__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(185, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_49; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_ns_reference_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_ns_reference_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_15, false); aot_arbace_pprint.A_arbace_pprint_pprint_ns_reference_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_50)); return A_arbace_pprint_dispatch__init_A_const_49 }

































func A_arbace_pprint_dispatch__init_A_Unit28__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(219, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_51; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_ns_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_ns_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_16, false); aot_arbace_pprint.A_arbace_pprint_pprint_ns_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_52)); return A_arbace_pprint_dispatch__init_A_const_51 }






























func A_arbace_pprint_dispatch__init_A_Unit29__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(250, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_53; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_fn__740000107_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__740000107_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_17, false); aot_arbace_pprint.A_arbace_pprint_fn__740000107_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_54)); return A_arbace_pprint_dispatch__init_A_const_53 }






func A_arbace_pprint_dispatch__init_A_Unit30__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(257, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_55; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_single_defn_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_single_defn_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); aot_arbace_pprint.A_arbace_pprint_single_defn_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_56)); return A_arbace_pprint_dispatch__init_A_const_55 }








func A_arbace_pprint_dispatch__init_A_Unit31__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(266, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_57; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_multi_defn_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_multi_defn_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_19, false); aot_arbace_pprint.A_arbace_pprint_multi_defn_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_58)); return A_arbace_pprint_dispatch__init_A_const_57 }





func A_arbace_pprint_dispatch__init_A_Unit32__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(272, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_59; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_defn_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_defn_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_20, false); aot_arbace_pprint.A_arbace_pprint_pprint_defn_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_60)); return A_arbace_pprint_dispatch__init_A_const_59 }
























func A_arbace_pprint_dispatch__init_A_Unit33__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(297, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_61; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_binding_form_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_binding_form_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_21, false); aot_arbace_pprint.A_arbace_pprint_pprint_binding_form_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_62)); return A_arbace_pprint_dispatch__init_A_const_61 }














func A_arbace_pprint_dispatch__init_A_Unit34__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(312, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_63; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_let_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_let_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_22, false); aot_arbace_pprint.A_arbace_pprint_pprint_let_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_64)); return A_arbace_pprint_dispatch__init_A_const_63 }













func A_arbace_pprint_dispatch__init_A_Unit35__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(326, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_65; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_fn__740000152_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__740000152_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_23, false); aot_arbace_pprint.A_arbace_pprint_fn__740000152_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_66)); return A_arbace_pprint_dispatch__init_A_const_65 }

func A_arbace_pprint_dispatch__init_A_Unit36__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(328, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_67; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_cond_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_cond_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_24, false); aot_arbace_pprint.A_arbace_pprint_pprint_cond_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_68)); return A_arbace_pprint_dispatch__init_A_const_67 }



















func A_arbace_pprint_dispatch__init_A_Unit37__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(348, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_69; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_condp_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_condp_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_25, false); aot_arbace_pprint.A_arbace_pprint_pprint_condp_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_70)); return A_arbace_pprint_dispatch__init_A_const_69 }



















func A_arbace_pprint_dispatch__init_A_Unit38__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(368, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_71; var tmp2 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; tmp1.BindRoot_O__V(tmp2.Ref()); var tmp3 *lang.Var = A_arbace_pprint_dispatch__init_A_const_71; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_72)); return A_arbace_pprint_dispatch__init_A_const_71.SetDynamic_Z__Var(true).Ref() }

func A_arbace_pprint_dispatch__init_A_Unit39__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(370, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_73; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_anon_func_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_anon_func_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_26, false); aot_arbace_pprint.A_arbace_pprint_pprint_anon_func_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_74)); return A_arbace_pprint_dispatch__init_A_const_73 }





















func A_arbace_pprint_dispatch__init_A_Unit40__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(392, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_45; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_simple_code_list_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_simple_code_list_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_27, false); aot_arbace_pprint.A_arbace_pprint_pprint_simple_code_list_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_75)); return A_arbace_pprint_dispatch__init_A_const_45 }












func A_arbace_pprint_dispatch__init_A_Unit41__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(405, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_76; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_two_forms_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_two_forms_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_28, false); aot_arbace_pprint.A_arbace_pprint_two_forms_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_77)); return A_arbace_pprint_dispatch__init_A_const_76 }






func A_arbace_pprint_dispatch__init_A_Unit42__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(412, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_78; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_add_core_ns_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_add_core_ns_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_29, false); aot_arbace_pprint.A_arbace_pprint_add_core_ns_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_79)); return A_arbace_pprint_dispatch__init_A_const_78 }








func A_arbace_pprint_dispatch__init_A_Unit43__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(421, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_80; var tmp2 any = A_arbace_pprint_dispatch__init_A_const_82; var tmp3 any = A_arbace_pprint_dispatch__init_A_const_53.GetRawRoot__O(); var tmp4 any = A_arbace_pprint_dispatch__init_A_const_83; var tmp5 any = A_arbace_pprint_dispatch__init_A_const_73.GetRawRoot__O(); var tmp6 any = A_arbace_pprint_dispatch__init_A_const_84; var tmp7 any = A_arbace_pprint_dispatch__init_A_const_63.GetRawRoot__O(); var tmp8 any = A_arbace_pprint_dispatch__init_A_const_85; var tmp9 any = A_arbace_pprint_dispatch__init_A_const_65.GetRawRoot__O(); var tmp10 any = A_arbace_pprint_dispatch__init_A_const_86; var tmp11 any = A_arbace_pprint_dispatch__init_A_const_69.GetRawRoot__O(); var tmp12 any = A_arbace_pprint_dispatch__init_A_const_87; var tmp13 any = A_arbace_pprint_dispatch__init_A_const_53.GetRawRoot__O(); var tmp14 any = A_arbace_pprint_dispatch__init_A_const_88; var tmp15 any = A_arbace_pprint_dispatch__init_A_const_59.GetRawRoot__O(); var tmp16 any = A_arbace_pprint_dispatch__init_A_const_89; var tmp17 any = A_arbace_pprint_dispatch__init_A_const_59.GetRawRoot__O(); var tmp18 any = A_arbace_pprint_dispatch__init_A_const_90; var tmp19 any = A_arbace_pprint_dispatch__init_A_const_63.GetRawRoot__O(); var tmp20 any = A_arbace_pprint_dispatch__init_A_const_91; var tmp21 any = A_arbace_pprint_dispatch__init_A_const_53.GetRawRoot__O(); var tmp22 any = A_arbace_pprint_dispatch__init_A_const_92; var tmp23 any = A_arbace_pprint_dispatch__init_A_const_63.GetRawRoot__O(); var tmp24 any = A_arbace_pprint_dispatch__init_A_const_93; var tmp25 any = A_arbace_pprint_dispatch__init_A_const_65.GetRawRoot__O(); var tmp26 any = A_arbace_pprint_dispatch__init_A_const_94; var tmp27 any = A_arbace_pprint_dispatch__init_A_const_65.GetRawRoot__O(); var tmp28 any = A_arbace_pprint_dispatch__init_A_const_95; var tmp29 any = A_arbace_pprint_dispatch__init_A_const_53.GetRawRoot__O(); var tmp30 any = A_arbace_pprint_dispatch__init_A_const_96; var tmp31 any = A_arbace_pprint_dispatch__init_A_const_65.GetRawRoot__O(); var tmp32 any = A_arbace_pprint_dispatch__init_A_const_97; var tmp33 any = A_arbace_pprint_dispatch__init_A_const_63.GetRawRoot__O(); var tmp34 any = A_arbace_pprint_dispatch__init_A_const_98; var tmp35 any = A_arbace_pprint_dispatch__init_A_const_63.GetRawRoot__O(); var tmp36 any = A_arbace_pprint_dispatch__init_A_const_99; var tmp37 any = A_arbace_pprint_dispatch__init_A_const_53.GetRawRoot__O(); var tmp38 any = A_arbace_pprint_dispatch__init_A_const_100; var tmp39 any = A_arbace_pprint_dispatch__init_A_const_63.GetRawRoot__O(); var tmp40 any = A_arbace_pprint_dispatch__init_A_const_101; var tmp41 any = A_arbace_pprint_dispatch__init_A_const_51.GetRawRoot__O(); var tmp42 any = A_arbace_pprint_dispatch__init_A_const_102; var tmp43 any = A_arbace_pprint_dispatch__init_A_const_63.GetRawRoot__O(); var tmp44 any = A_arbace_pprint_dispatch__init_A_const_103; var tmp45 any = A_arbace_pprint_dispatch__init_A_const_67.GetRawRoot__O(); var tmp46 any = A_arbace_pprint_dispatch__init_A_const_104; var tmp47 any = A_arbace_pprint_dispatch__init_A_const_63.GetRawRoot__O(); var tmp48 any = A_arbace_pprint_dispatch__init_A_const_105; var tmp49 any = A_arbace_pprint_dispatch__init_A_const_59.GetRawRoot__O(); var tmp50 any = A_arbace_pprint_dispatch__init_A_const_106; var tmp51 any = A_arbace_pprint_dispatch__init_A_const_59.GetRawRoot__O(); var tmp52 any = A_arbace_pprint_dispatch__init_A_const_107; var tmp53 any = A_arbace_pprint_dispatch__init_A_const_53.GetRawRoot__O(); var tmp54 any = A_arbace_pprint_dispatch__init_A_const_108; var tmp55 any = A_arbace_pprint_dispatch__init_A_const_53.GetRawRoot__O(); var tmp56 any = A_arbace_pprint_dispatch__init_A_const_109; var tmp57 any = A_arbace_pprint_dispatch__init_A_const_63.GetRawRoot__O(); var tmp58 any = A_arbace_pprint_dispatch__init_A_const_110; var tmp59 any = A_arbace_pprint_dispatch__init_A_const_63.GetRawRoot__O(); var tmp60 any = A_arbace_pprint_dispatch__init_A_const_111; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_76.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_78.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, tmp22, tmp23, tmp24, tmp25, tmp26, tmp27, tmp28, tmp29, tmp30, tmp31, tmp32, tmp33, tmp34, tmp35, tmp36, tmp37, tmp38, tmp39, tmp40, tmp41, tmp42, tmp43, tmp44, tmp45, tmp46, tmp47, tmp48, tmp49, tmp50, tmp51, tmp52, tmp53, tmp54, tmp55, tmp56, tmp57, tmp58, tmp59, tmp60, A_arbace_pprint_dispatch__init_A_const_53.GetRawRoot__O()))))); var tmp61 *lang.Var = A_arbace_pprint_dispatch__init_A_const_80; tmp61.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_81)); return A_arbace_pprint_dispatch__init_A_const_80.SetDynamic_Z__Var(true).Ref() }
















func A_arbace_pprint_dispatch__init_A_Unit44__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(438, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_112; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_code_list_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_code_list_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_30, false); aot_arbace_pprint.A_arbace_pprint_pprint_code_list_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_112; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_113)); return A_arbace_pprint_dispatch__init_A_const_112 }





func A_arbace_pprint_dispatch__init_A_Unit45__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(444, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_114; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_code_symbol_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_code_symbol_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_31, false); aot_arbace_pprint.A_arbace_pprint_pprint_code_symbol_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_115)); return A_arbace_pprint_dispatch__init_A_const_114 }






func A_arbace_pprint_dispatch__init_A_Unit46__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(451, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_116; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_117)); v__1927000386__auto____1 = A_arbace_pprint_dispatch__init_A_const_116; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { tmp2 = lang.MultiFn_InstanceOf(lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_32.GetRawRoot__O()).Invoke_O__O(v__1927000386__auto____1)) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp3 *lang.Var = A_arbace_pprint_dispatch__init_A_const_116; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_118)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_116; var tmp5 *jrt.String = Lit_32; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_33.GetRawRoot__O()); var tmp7 any = A_arbace_pprint_dispatch__init_A_const_34; tmp4.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp5, tmp6, tmp7, A_arbace_pprint_dispatch__init_A_const_35)); return A_arbace_pprint_dispatch__init_A_const_116 } }





func A_arbace_pprint_dispatch__init_A_Unit47__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(457, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_dispatch__init_A_const_116.GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_37; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_pprint_dispatch__init_A_const_112.GetRawRoot__O()) }
func A_arbace_pprint_dispatch__init_A_Unit48__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(458, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_dispatch__init_A_const_116.GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_119; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_pprint_dispatch__init_A_const_114.GetRawRoot__O()) }


func A_arbace_pprint_dispatch__init_A_Unit49__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(461, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_dispatch__init_A_const_116.GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_38; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_pprint_dispatch__init_A_const_17.GetRawRoot__O()) }
func A_arbace_pprint_dispatch__init_A_Unit50__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(462, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_dispatch__init_A_const_116.GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_39; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_pprint_dispatch__init_A_const_9.GetRawRoot__O()) }
func A_arbace_pprint_dispatch__init_A_Unit51__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(463, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_dispatch__init_A_const_116.GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_40; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_pprint_dispatch__init_A_const_22.GetRawRoot__O()) }
func A_arbace_pprint_dispatch__init_A_Unit52__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(464, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_dispatch__init_A_const_116.GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_41; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_pprint_dispatch__init_A_const_26.GetRawRoot__O()) }
func A_arbace_pprint_dispatch__init_A_Unit53__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(465, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_dispatch__init_A_const_116.GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_43; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_pprint_dispatch__init_A_const_24.GetRawRoot__O()) }
func A_arbace_pprint_dispatch__init_A_Unit54__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(466, 1); return lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_pprint_dispatch__init_A_const_116.GetRawRoot__O(), nil, A_arbace_pprint_dispatch__init_A_const_44.Get__O()) }
func A_arbace_pprint_dispatch__init_A_Unit55__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(467, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O()); var tmp2 any = A_arbace_pprint_dispatch__init_A_const_116.GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_34; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_pprint_dispatch__init_A_const_28.GetRawRoot__O()) }

func A_arbace_pprint_dispatch__init_A_Unit56__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(469, 1); return lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_120.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_dispatch__init_A_const_30.GetRawRoot__O()) }


func A_arbace_pprint_dispatch__init_A_Unit57__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(472, 1); return nil }



type A_arbace_pprint_dispatch__init_A struct{ jrt.Object }

var A_arbace_pprint_dispatch__init_A_const_pool *jrt.RefArray

var A_arbace_pprint_dispatch__init_A_const_0 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_1 any

var A_arbace_pprint_dispatch__init_A_const_2 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_3 any

var A_arbace_pprint_dispatch__init_A_const_4 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_5 any

var A_arbace_pprint_dispatch__init_A_const_6 any

var A_arbace_pprint_dispatch__init_A_const_7 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_8 any

var A_arbace_pprint_dispatch__init_A_const_9 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_10 any

var A_arbace_pprint_dispatch__init_A_const_11 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_12 any

var A_arbace_pprint_dispatch__init_A_const_13 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_14 any

var A_arbace_pprint_dispatch__init_A_const_15 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_16 any

var A_arbace_pprint_dispatch__init_A_const_17 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_18 any

var A_arbace_pprint_dispatch__init_A_const_19 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_20 any

var A_arbace_pprint_dispatch__init_A_const_21 any

var A_arbace_pprint_dispatch__init_A_const_22 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_23 any

var A_arbace_pprint_dispatch__init_A_const_24 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_25 any

var A_arbace_pprint_dispatch__init_A_const_26 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_27 any

var A_arbace_pprint_dispatch__init_A_const_28 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_29 any

var A_arbace_pprint_dispatch__init_A_const_30 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_31 any

var A_arbace_pprint_dispatch__init_A_const_32 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_33 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_34 *lang.Keyword

var A_arbace_pprint_dispatch__init_A_const_35 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_36 any

var A_arbace_pprint_dispatch__init_A_const_37 *jrt.Class

var A_arbace_pprint_dispatch__init_A_const_38 *jrt.Class

var A_arbace_pprint_dispatch__init_A_const_39 *jrt.Class

var A_arbace_pprint_dispatch__init_A_const_40 *jrt.Class

var A_arbace_pprint_dispatch__init_A_const_41 *jrt.Class

var A_arbace_pprint_dispatch__init_A_const_42 *jrt.Class

var A_arbace_pprint_dispatch__init_A_const_43 *jrt.Class

var A_arbace_pprint_dispatch__init_A_const_44 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_45 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_46 any

var A_arbace_pprint_dispatch__init_A_const_47 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_48 any

var A_arbace_pprint_dispatch__init_A_const_49 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_50 any

var A_arbace_pprint_dispatch__init_A_const_51 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_52 any

var A_arbace_pprint_dispatch__init_A_const_53 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_54 any

var A_arbace_pprint_dispatch__init_A_const_55 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_56 any

var A_arbace_pprint_dispatch__init_A_const_57 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_58 any

var A_arbace_pprint_dispatch__init_A_const_59 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_60 any

var A_arbace_pprint_dispatch__init_A_const_61 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_62 any

var A_arbace_pprint_dispatch__init_A_const_63 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_64 any

var A_arbace_pprint_dispatch__init_A_const_65 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_66 any

var A_arbace_pprint_dispatch__init_A_const_67 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_68 any

var A_arbace_pprint_dispatch__init_A_const_69 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_70 any

var A_arbace_pprint_dispatch__init_A_const_71 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_72 any

var A_arbace_pprint_dispatch__init_A_const_73 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_74 any

var A_arbace_pprint_dispatch__init_A_const_75 any

var A_arbace_pprint_dispatch__init_A_const_76 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_77 any

var A_arbace_pprint_dispatch__init_A_const_78 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_79 any

var A_arbace_pprint_dispatch__init_A_const_80 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_81 any

var A_arbace_pprint_dispatch__init_A_const_82 any

var A_arbace_pprint_dispatch__init_A_const_83 any

var A_arbace_pprint_dispatch__init_A_const_84 any

var A_arbace_pprint_dispatch__init_A_const_85 any

var A_arbace_pprint_dispatch__init_A_const_86 any

var A_arbace_pprint_dispatch__init_A_const_87 any

var A_arbace_pprint_dispatch__init_A_const_88 any

var A_arbace_pprint_dispatch__init_A_const_89 any

var A_arbace_pprint_dispatch__init_A_const_90 any

var A_arbace_pprint_dispatch__init_A_const_91 any

var A_arbace_pprint_dispatch__init_A_const_92 any

var A_arbace_pprint_dispatch__init_A_const_93 any

var A_arbace_pprint_dispatch__init_A_const_94 any

var A_arbace_pprint_dispatch__init_A_const_95 any

var A_arbace_pprint_dispatch__init_A_const_96 any

var A_arbace_pprint_dispatch__init_A_const_97 any

var A_arbace_pprint_dispatch__init_A_const_98 any

var A_arbace_pprint_dispatch__init_A_const_99 any

var A_arbace_pprint_dispatch__init_A_const_100 any

var A_arbace_pprint_dispatch__init_A_const_101 any

var A_arbace_pprint_dispatch__init_A_const_102 any

var A_arbace_pprint_dispatch__init_A_const_103 any

var A_arbace_pprint_dispatch__init_A_const_104 any

var A_arbace_pprint_dispatch__init_A_const_105 any

var A_arbace_pprint_dispatch__init_A_const_106 any

var A_arbace_pprint_dispatch__init_A_const_107 any

var A_arbace_pprint_dispatch__init_A_const_108 any

var A_arbace_pprint_dispatch__init_A_const_109 any

var A_arbace_pprint_dispatch__init_A_const_110 any

var A_arbace_pprint_dispatch__init_A_const_111 any

var A_arbace_pprint_dispatch__init_A_const_112 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_113 any

var A_arbace_pprint_dispatch__init_A_const_114 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_115 any

var A_arbace_pprint_dispatch__init_A_const_116 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_117 any

var A_arbace_pprint_dispatch__init_A_const_118 any

var A_arbace_pprint_dispatch__init_A_const_119 *jrt.Class

var A_arbace_pprint_dispatch__init_A_const_120 *lang.Var

var A_arbace_pprint_dispatch__init_A_init jrt.ClassInit

func A_arbace_pprint_dispatch__init_A_Init() { if !A_arbace_pprint_dispatch__init_A_init.Done() { A_arbace_pprint_dispatch__init_A_init.Run(A_arbace_pprint_dispatch__init_A_clinit) } }

func A_arbace_pprint_dispatch__init_A_clinit() { A_arbace_pprint_dispatch__init_A_clinit_p0(); A_arbace_pprint_dispatch__init_A_clinit_p1(); A_arbace_pprint_dispatch__init_A_clinit_p2(); A_arbace_pprint_dispatch__init_A_clinit_p3(); A_arbace_pprint_dispatch__init_A_clinit_p4(); A_arbace_pprint_dispatch__init_A_clinit_p5(); A_arbace_pprint_dispatch__init_A_clinit_p6(); A_arbace_pprint_dispatch__init_A_clinit_p7(); A_arbace_pprint_dispatch__init_A_clinit_p8() }

func A_arbace_pprint_dispatch__init_A_clinit_p0() { A_arbace_pprint_dispatch__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 182); A_arbace_pprint_dispatch__init_A_const_0 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[61]); A_arbace_pprint_dispatch__init_A_const_1 = A_arbace_pprint_dispatch__init_A_const_pool.A[62]; A_arbace_pprint_dispatch__init_A_const_2 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[63]); A_arbace_pprint_dispatch__init_A_const_3 = A_arbace_pprint_dispatch__init_A_const_pool.A[64]; A_arbace_pprint_dispatch__init_A_const_4 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[65]); A_arbace_pprint_dispatch__init_A_const_5 = A_arbace_pprint_dispatch__init_A_const_pool.A[66]; A_arbace_pprint_dispatch__init_A_const_6 = A_arbace_pprint_dispatch__init_A_const_pool.A[67]; A_arbace_pprint_dispatch__init_A_const_7 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[68]); A_arbace_pprint_dispatch__init_A_const_8 = A_arbace_pprint_dispatch__init_A_const_pool.A[69]; A_arbace_pprint_dispatch__init_A_const_9 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[70]); A_arbace_pprint_dispatch__init_A_const_10 = A_arbace_pprint_dispatch__init_A_const_pool.A[71]; A_arbace_pprint_dispatch__init_A_const_11 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[72]); A_arbace_pprint_dispatch__init_A_const_12 = A_arbace_pprint_dispatch__init_A_const_pool.A[73] }

func A_arbace_pprint_dispatch__init_A_clinit_p1() { A_arbace_pprint_dispatch__init_A_const_13 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[74]); A_arbace_pprint_dispatch__init_A_const_14 = A_arbace_pprint_dispatch__init_A_const_pool.A[75]; A_arbace_pprint_dispatch__init_A_const_15 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[76]); A_arbace_pprint_dispatch__init_A_const_16 = A_arbace_pprint_dispatch__init_A_const_pool.A[77]; A_arbace_pprint_dispatch__init_A_const_17 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[78]); A_arbace_pprint_dispatch__init_A_const_18 = A_arbace_pprint_dispatch__init_A_const_pool.A[79]; A_arbace_pprint_dispatch__init_A_const_19 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[80]); A_arbace_pprint_dispatch__init_A_const_20 = A_arbace_pprint_dispatch__init_A_const_pool.A[81]; A_arbace_pprint_dispatch__init_A_const_21 = A_arbace_pprint_dispatch__init_A_const_pool.A[82]; A_arbace_pprint_dispatch__init_A_const_22 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[83]); A_arbace_pprint_dispatch__init_A_const_23 = A_arbace_pprint_dispatch__init_A_const_pool.A[84]; A_arbace_pprint_dispatch__init_A_const_24 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[85]); A_arbace_pprint_dispatch__init_A_const_25 = A_arbace_pprint_dispatch__init_A_const_pool.A[86] }

func A_arbace_pprint_dispatch__init_A_clinit_p2() { A_arbace_pprint_dispatch__init_A_const_26 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[87]); A_arbace_pprint_dispatch__init_A_const_27 = A_arbace_pprint_dispatch__init_A_const_pool.A[88]; A_arbace_pprint_dispatch__init_A_const_28 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[89]); A_arbace_pprint_dispatch__init_A_const_29 = A_arbace_pprint_dispatch__init_A_const_pool.A[90]; A_arbace_pprint_dispatch__init_A_const_30 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[91]); A_arbace_pprint_dispatch__init_A_const_31 = A_arbace_pprint_dispatch__init_A_const_pool.A[92]; A_arbace_pprint_dispatch__init_A_const_32 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[93]); A_arbace_pprint_dispatch__init_A_const_33 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[94]); A_arbace_pprint_dispatch__init_A_const_34 = lang.Keyword_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[95]); A_arbace_pprint_dispatch__init_A_const_35 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[96]); A_arbace_pprint_dispatch__init_A_const_36 = A_arbace_pprint_dispatch__init_A_const_pool.A[97]; A_arbace_pprint_dispatch__init_A_const_37 = jrt.Class_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[98]); A_arbace_pprint_dispatch__init_A_const_38 = jrt.Class_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[99]) }

func A_arbace_pprint_dispatch__init_A_clinit_p3() { A_arbace_pprint_dispatch__init_A_const_39 = jrt.Class_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[100]); A_arbace_pprint_dispatch__init_A_const_40 = jrt.Class_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[101]); A_arbace_pprint_dispatch__init_A_const_41 = jrt.Class_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[102]); A_arbace_pprint_dispatch__init_A_const_42 = jrt.Class_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[103]); A_arbace_pprint_dispatch__init_A_const_43 = jrt.Class_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[104]); A_arbace_pprint_dispatch__init_A_const_44 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[105]); A_arbace_pprint_dispatch__init_A_const_45 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[106]); A_arbace_pprint_dispatch__init_A_const_46 = A_arbace_pprint_dispatch__init_A_const_pool.A[107]; A_arbace_pprint_dispatch__init_A_const_47 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[108]); A_arbace_pprint_dispatch__init_A_const_48 = A_arbace_pprint_dispatch__init_A_const_pool.A[109]; A_arbace_pprint_dispatch__init_A_const_49 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[110]); A_arbace_pprint_dispatch__init_A_const_50 = A_arbace_pprint_dispatch__init_A_const_pool.A[111] }

func A_arbace_pprint_dispatch__init_A_clinit_p4() { A_arbace_pprint_dispatch__init_A_const_51 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[112]); A_arbace_pprint_dispatch__init_A_const_52 = A_arbace_pprint_dispatch__init_A_const_pool.A[113]; A_arbace_pprint_dispatch__init_A_const_53 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[114]); A_arbace_pprint_dispatch__init_A_const_54 = A_arbace_pprint_dispatch__init_A_const_pool.A[115]; A_arbace_pprint_dispatch__init_A_const_55 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[116]); A_arbace_pprint_dispatch__init_A_const_56 = A_arbace_pprint_dispatch__init_A_const_pool.A[117]; A_arbace_pprint_dispatch__init_A_const_57 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[118]); A_arbace_pprint_dispatch__init_A_const_58 = A_arbace_pprint_dispatch__init_A_const_pool.A[119]; A_arbace_pprint_dispatch__init_A_const_59 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[120]); A_arbace_pprint_dispatch__init_A_const_60 = A_arbace_pprint_dispatch__init_A_const_pool.A[121]; A_arbace_pprint_dispatch__init_A_const_61 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[122]); A_arbace_pprint_dispatch__init_A_const_62 = A_arbace_pprint_dispatch__init_A_const_pool.A[123]; A_arbace_pprint_dispatch__init_A_const_63 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[124]) }

func A_arbace_pprint_dispatch__init_A_clinit_p5() { A_arbace_pprint_dispatch__init_A_const_64 = A_arbace_pprint_dispatch__init_A_const_pool.A[125]; A_arbace_pprint_dispatch__init_A_const_65 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[126]); A_arbace_pprint_dispatch__init_A_const_66 = A_arbace_pprint_dispatch__init_A_const_pool.A[127]; A_arbace_pprint_dispatch__init_A_const_67 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[128]); A_arbace_pprint_dispatch__init_A_const_68 = A_arbace_pprint_dispatch__init_A_const_pool.A[129]; A_arbace_pprint_dispatch__init_A_const_69 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[130]); A_arbace_pprint_dispatch__init_A_const_70 = A_arbace_pprint_dispatch__init_A_const_pool.A[131]; A_arbace_pprint_dispatch__init_A_const_71 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[132]); A_arbace_pprint_dispatch__init_A_const_72 = A_arbace_pprint_dispatch__init_A_const_pool.A[133]; A_arbace_pprint_dispatch__init_A_const_73 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[134]); A_arbace_pprint_dispatch__init_A_const_74 = A_arbace_pprint_dispatch__init_A_const_pool.A[135]; A_arbace_pprint_dispatch__init_A_const_75 = A_arbace_pprint_dispatch__init_A_const_pool.A[136]; A_arbace_pprint_dispatch__init_A_const_76 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[137]); A_arbace_pprint_dispatch__init_A_const_77 = A_arbace_pprint_dispatch__init_A_const_pool.A[138] }

func A_arbace_pprint_dispatch__init_A_clinit_p6() { A_arbace_pprint_dispatch__init_A_const_78 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[139]); A_arbace_pprint_dispatch__init_A_const_79 = A_arbace_pprint_dispatch__init_A_const_pool.A[140]; A_arbace_pprint_dispatch__init_A_const_80 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[141]); A_arbace_pprint_dispatch__init_A_const_81 = A_arbace_pprint_dispatch__init_A_const_pool.A[142]; A_arbace_pprint_dispatch__init_A_const_82 = A_arbace_pprint_dispatch__init_A_const_pool.A[143]; A_arbace_pprint_dispatch__init_A_const_83 = A_arbace_pprint_dispatch__init_A_const_pool.A[144]; A_arbace_pprint_dispatch__init_A_const_84 = A_arbace_pprint_dispatch__init_A_const_pool.A[145]; A_arbace_pprint_dispatch__init_A_const_85 = A_arbace_pprint_dispatch__init_A_const_pool.A[146]; A_arbace_pprint_dispatch__init_A_const_86 = A_arbace_pprint_dispatch__init_A_const_pool.A[147]; A_arbace_pprint_dispatch__init_A_const_87 = A_arbace_pprint_dispatch__init_A_const_pool.A[148]; A_arbace_pprint_dispatch__init_A_const_88 = A_arbace_pprint_dispatch__init_A_const_pool.A[149]; A_arbace_pprint_dispatch__init_A_const_89 = A_arbace_pprint_dispatch__init_A_const_pool.A[150]; A_arbace_pprint_dispatch__init_A_const_90 = A_arbace_pprint_dispatch__init_A_const_pool.A[151]; A_arbace_pprint_dispatch__init_A_const_91 = A_arbace_pprint_dispatch__init_A_const_pool.A[152]; A_arbace_pprint_dispatch__init_A_const_92 = A_arbace_pprint_dispatch__init_A_const_pool.A[153] }

func A_arbace_pprint_dispatch__init_A_clinit_p7() { A_arbace_pprint_dispatch__init_A_const_93 = A_arbace_pprint_dispatch__init_A_const_pool.A[154]; A_arbace_pprint_dispatch__init_A_const_94 = A_arbace_pprint_dispatch__init_A_const_pool.A[155]; A_arbace_pprint_dispatch__init_A_const_95 = A_arbace_pprint_dispatch__init_A_const_pool.A[156]; A_arbace_pprint_dispatch__init_A_const_96 = A_arbace_pprint_dispatch__init_A_const_pool.A[157]; A_arbace_pprint_dispatch__init_A_const_97 = A_arbace_pprint_dispatch__init_A_const_pool.A[158]; A_arbace_pprint_dispatch__init_A_const_98 = A_arbace_pprint_dispatch__init_A_const_pool.A[159]; A_arbace_pprint_dispatch__init_A_const_99 = A_arbace_pprint_dispatch__init_A_const_pool.A[160]; A_arbace_pprint_dispatch__init_A_const_100 = A_arbace_pprint_dispatch__init_A_const_pool.A[161]; A_arbace_pprint_dispatch__init_A_const_101 = A_arbace_pprint_dispatch__init_A_const_pool.A[162]; A_arbace_pprint_dispatch__init_A_const_102 = A_arbace_pprint_dispatch__init_A_const_pool.A[163]; A_arbace_pprint_dispatch__init_A_const_103 = A_arbace_pprint_dispatch__init_A_const_pool.A[164]; A_arbace_pprint_dispatch__init_A_const_104 = A_arbace_pprint_dispatch__init_A_const_pool.A[165]; A_arbace_pprint_dispatch__init_A_const_105 = A_arbace_pprint_dispatch__init_A_const_pool.A[166]; A_arbace_pprint_dispatch__init_A_const_106 = A_arbace_pprint_dispatch__init_A_const_pool.A[167]; A_arbace_pprint_dispatch__init_A_const_107 = A_arbace_pprint_dispatch__init_A_const_pool.A[168]; A_arbace_pprint_dispatch__init_A_const_108 = A_arbace_pprint_dispatch__init_A_const_pool.A[169] }

func A_arbace_pprint_dispatch__init_A_clinit_p8() { A_arbace_pprint_dispatch__init_A_const_109 = A_arbace_pprint_dispatch__init_A_const_pool.A[170]; A_arbace_pprint_dispatch__init_A_const_110 = A_arbace_pprint_dispatch__init_A_const_pool.A[171]; A_arbace_pprint_dispatch__init_A_const_111 = A_arbace_pprint_dispatch__init_A_const_pool.A[172]; A_arbace_pprint_dispatch__init_A_const_112 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[173]); A_arbace_pprint_dispatch__init_A_const_113 = A_arbace_pprint_dispatch__init_A_const_pool.A[174]; A_arbace_pprint_dispatch__init_A_const_114 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[175]); A_arbace_pprint_dispatch__init_A_const_115 = A_arbace_pprint_dispatch__init_A_const_pool.A[176]; A_arbace_pprint_dispatch__init_A_const_116 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[177]); A_arbace_pprint_dispatch__init_A_const_117 = A_arbace_pprint_dispatch__init_A_const_pool.A[178]; A_arbace_pprint_dispatch__init_A_const_118 = A_arbace_pprint_dispatch__init_A_const_pool.A[179]; A_arbace_pprint_dispatch__init_A_const_119 = jrt.Class_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[180]); A_arbace_pprint_dispatch__init_A_const_120 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[181]) }

func A_arbace_pprint_dispatch__init_A_New() *A_arbace_pprint_dispatch__init_A { A_arbace_pprint_dispatch__init_A_Init(); t := &A_arbace_pprint_dispatch__init_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_dispatch__init_A) Ctor() {}

func (t *A_arbace_pprint_dispatch__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_dispatch__init_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_dispatch__init_A_class }

func (t *A_arbace_pprint_dispatch__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_dispatch__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_pprint_dispatch__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_dispatch__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_dispatch__init_A); return ok }

func A_arbace_pprint_dispatch__init_A_Cast(x any) *A_arbace_pprint_dispatch__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_dispatch__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_dispatch__init_A_class)) }; return v }
