//line aot_arbace_pprint_dispatch__init.ae:1
package aot_arbace_pprint_dispatch

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_pprint"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_pprint_dispatch__init_A_Load__O() any { A_arbace_pprint_dispatch__init_A_Init(); jrt.StartCheck(); A_arbace_pprint_dispatch__init_A_Unit0__O(); A_arbace_pprint_dispatch__init_A_Unit1__O(); A_arbace_pprint_dispatch__init_A_Unit2__O(); A_arbace_pprint_dispatch__init_A_Unit3__O(); A_arbace_pprint_dispatch__init_A_Unit4__O(); A_arbace_pprint_dispatch__init_A_Unit5__O(); A_arbace_pprint_dispatch__init_A_Unit6__O(); A_arbace_pprint_dispatch__init_A_Unit7__O(); A_arbace_pprint_dispatch__init_A_Unit8__O(); A_arbace_pprint_dispatch__init_A_Unit9__O(); A_arbace_pprint_dispatch__init_A_Unit10__O(); A_arbace_pprint_dispatch__init_A_Unit11__O(); A_arbace_pprint_dispatch__init_A_Unit12__O(); A_arbace_pprint_dispatch__init_A_Unit13__O(); A_arbace_pprint_dispatch__init_A_Unit14__O(); A_arbace_pprint_dispatch__init_A_Unit15__O(); A_arbace_pprint_dispatch__init_A_Unit16__O(); A_arbace_pprint_dispatch__init_A_Unit17__O(); A_arbace_pprint_dispatch__init_A_Unit18__O(); A_arbace_pprint_dispatch__init_A_Unit19__O(); A_arbace_pprint_dispatch__init_A_Unit20__O(); A_arbace_pprint_dispatch__init_A_Unit21__O(); A_arbace_pprint_dispatch__init_A_Unit22__O(); A_arbace_pprint_dispatch__init_A_Unit23__O(); A_arbace_pprint_dispatch__init_A_Unit24__O(); A_arbace_pprint_dispatch__init_A_Unit25__O(); A_arbace_pprint_dispatch__init_A_Unit26__O(); A_arbace_pprint_dispatch__init_A_Unit27__O(); A_arbace_pprint_dispatch__init_A_Unit28__O(); A_arbace_pprint_dispatch__init_A_Unit29__O(); A_arbace_pprint_dispatch__init_A_Unit30__O(); A_arbace_pprint_dispatch__init_A_Unit31__O(); A_arbace_pprint_dispatch__init_A_Unit32__O(); A_arbace_pprint_dispatch__init_A_Unit33__O(); A_arbace_pprint_dispatch__init_A_Unit34__O(); A_arbace_pprint_dispatch__init_A_Unit35__O(); A_arbace_pprint_dispatch__init_A_Unit36__O(); A_arbace_pprint_dispatch__init_A_Unit37__O(); A_arbace_pprint_dispatch__init_A_Unit38__O(); A_arbace_pprint_dispatch__init_A_Unit39__O(); A_arbace_pprint_dispatch__init_A_Unit40__O(); A_arbace_pprint_dispatch__init_A_Unit41__O(); A_arbace_pprint_dispatch__init_A_Unit42__O(); A_arbace_pprint_dispatch__init_A_Unit43__O(); A_arbace_pprint_dispatch__init_A_Unit44__O(); A_arbace_pprint_dispatch__init_A_Unit45__O(); A_arbace_pprint_dispatch__init_A_Unit46__O(); A_arbace_pprint_dispatch__init_A_Unit47__O(); A_arbace_pprint_dispatch__init_A_Unit48__O(); A_arbace_pprint_dispatch__init_A_Unit49__O(); A_arbace_pprint_dispatch__init_A_Unit50__O(); A_arbace_pprint_dispatch__init_A_Unit51__O(); A_arbace_pprint_dispatch__init_A_Unit52__O(); A_arbace_pprint_dispatch__init_A_Unit53__O(); A_arbace_pprint_dispatch__init_A_Unit54__O(); A_arbace_pprint_dispatch__init_A_Unit55__O(); A_arbace_pprint_dispatch__init_A_Unit56__O(); A_arbace_pprint_dispatch__init_A_Unit57__O(); A_arbace_pprint_dispatch__init_A_Unit58__O(); return nil }











func A_arbace_pprint_dispatch__init_A_Unit0__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); return lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_dispatch__init_A_const_1) }

func A_arbace_pprint_dispatch__init_A_Unit1__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(19, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_2; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_use_method_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_use_method_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); aot_arbace_pprint.A_arbace_pprint_use_method_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_3)); return A_arbace_pprint_dispatch__init_A_const_2 }
























func A_arbace_pprint_dispatch__init_A_Unit2__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); A_arbace_pprint_dispatch__init_A_const_4.BindRoot_O__V(A_arbace_pprint_dispatch__init_A_const_5); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_6)); return A_arbace_pprint_dispatch__init_A_const_4 }



func A_arbace_pprint_dispatch__init_A_Unit3__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_7; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_reader_macro_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_reader_macro_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); aot_arbace_pprint.A_arbace_pprint_pprint_reader_macro_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_7; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_8)); return A_arbace_pprint_dispatch__init_A_const_7 }
//line :48:1
func A_arbace_pprint_dispatch__init_A_Unit58__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); return nil }















func A_arbace_pprint_dispatch__init_A_Unit4__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(64, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_9; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_10)); return A_arbace_pprint_dispatch__init_A_const_9 }

func A_arbace_pprint_dispatch__init_A_Unit5__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(66, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_11; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_meta_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_meta_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); aot_arbace_pprint.A_arbace_pprint_pprint_meta_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_12)); return A_arbace_pprint_dispatch__init_A_const_11 }








func A_arbace_pprint_dispatch__init_A_Unit6__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(75, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_13; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_simple_list_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_simple_list_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); aot_arbace_pprint.A_arbace_pprint_pprint_simple_list_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_14)); return A_arbace_pprint_dispatch__init_A_const_13 }










func A_arbace_pprint_dispatch__init_A_Unit7__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(86, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_15; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_list_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_list_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); aot_arbace_pprint.A_arbace_pprint_pprint_list_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_16)); return A_arbace_pprint_dispatch__init_A_const_15 }




func A_arbace_pprint_dispatch__init_A_Unit8__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(91, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_17; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_vector_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_vector_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); aot_arbace_pprint.A_arbace_pprint_pprint_vector_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_18)); return A_arbace_pprint_dispatch__init_A_const_17 }










func A_arbace_pprint_dispatch__init_A_Unit9__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(102, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_19; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_fn__740000014_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__740000014_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); aot_arbace_pprint.A_arbace_pprint_fn__740000014_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_20)); return A_arbace_pprint_dispatch__init_A_const_19 }


func A_arbace_pprint_dispatch__init_A_Unit10__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(105, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_9; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_map_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_map_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); aot_arbace_pprint.A_arbace_pprint_pprint_map_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_21)); return A_arbace_pprint_dispatch__init_A_const_9 }




















func A_arbace_pprint_dispatch__init_A_Unit11__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_22; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_set_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_set_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); aot_arbace_pprint.A_arbace_pprint_pprint_set_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_23)); return A_arbace_pprint_dispatch__init_A_const_22 }










func A_arbace_pprint_dispatch__init_A_Unit12__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(137, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_24; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_ideref_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_ideref_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); aot_arbace_pprint.A_arbace_pprint_pprint_ideref_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_25)); return A_arbace_pprint_dispatch__init_A_const_24 }




func A_arbace_pprint_dispatch__init_A_Unit13__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(142, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_26; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_fn__740000032_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__740000032_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); aot_arbace_pprint.A_arbace_pprint_fn__740000032_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_27)); return A_arbace_pprint_dispatch__init_A_const_26 }

func A_arbace_pprint_dispatch__init_A_Unit14__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(144, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_28; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_simple_default_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_simple_default_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); aot_arbace_pprint.A_arbace_pprint_pprint_simple_default_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_29)); return A_arbace_pprint_dispatch__init_A_const_28 }





func A_arbace_pprint_dispatch__init_A_Unit15__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(150, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_30; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_31)); v__1927000386__auto____1 = A_arbace_pprint_dispatch__init_A_const_30; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { var tmp3 any; var root_13 any = A_arbace_pprint_dispatch__init_A_const_32.GetRawRoot__O(); var linked_14 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_13, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_15 lang.IFn; if linked_14 == nil { ifn_15 = lang.IFn_Cast(root_13) } else { ifn_15 = nil }; var arg_16 any = v__1927000386__auto____1; if linked_14 == nil { tmp3 = ifn_15.Invoke_O__O(arg_16) } else { tmp3 = linked_14.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_13, arg_16) }; tmp2 = lang.MultiFn_InstanceOf(tmp3) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_36)); var tmp5 *lang.Var = A_arbace_pprint_dispatch__init_A_const_30; var tmp6 *jrt.String = Lit_13; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_33.GetRawRoot__O()); var tmp8 any = A_arbace_pprint_dispatch__init_A_const_34; tmp5.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp6, tmp7, tmp8, A_arbace_pprint_dispatch__init_A_const_35)); return A_arbace_pprint_dispatch__init_A_const_30 } }





func A_arbace_pprint_dispatch__init_A_Unit16__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(156, 1); var root_17 any = A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_pprint.A_arbace_pprint_use_method_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = A_arbace_pprint_dispatch__init_A_const_30.GetRawRoot__O(); var arg_21 any = A_arbace_pprint_dispatch__init_A_const_37; var arg_22 any = A_arbace_pprint_dispatch__init_A_const_15.GetRawRoot__O(); if linked_18 == nil { return ifn_19.Invoke_O_O_O__O(arg_20, arg_21, arg_22) } else { return linked_18.(*aot_arbace_pprint.A_arbace_pprint_use_method_A).Invoke_O_O_O_O__O(root_17, arg_20, arg_21, arg_22) } }
func A_arbace_pprint_dispatch__init_A_Unit17__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(157, 1); var root_23 any = A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, aot_arbace_pprint.A_arbace_pprint_use_method_A_fn_class); var ifn_25 lang.IFn; if linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = A_arbace_pprint_dispatch__init_A_const_30.GetRawRoot__O(); var arg_27 any = A_arbace_pprint_dispatch__init_A_const_38; var arg_28 any = A_arbace_pprint_dispatch__init_A_const_17.GetRawRoot__O(); if linked_24 == nil { return ifn_25.Invoke_O_O_O__O(arg_26, arg_27, arg_28) } else { return linked_24.(*aot_arbace_pprint.A_arbace_pprint_use_method_A).Invoke_O_O_O_O__O(root_23, arg_26, arg_27, arg_28) } }
func A_arbace_pprint_dispatch__init_A_Unit18__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(158, 1); var root_29 any = A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_29, aot_arbace_pprint.A_arbace_pprint_use_method_A_fn_class); var ifn_31 lang.IFn; if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any = A_arbace_pprint_dispatch__init_A_const_30.GetRawRoot__O(); var arg_33 any = A_arbace_pprint_dispatch__init_A_const_39; var arg_34 any = A_arbace_pprint_dispatch__init_A_const_9.GetRawRoot__O(); if linked_30 == nil { return ifn_31.Invoke_O_O_O__O(arg_32, arg_33, arg_34) } else { return linked_30.(*aot_arbace_pprint.A_arbace_pprint_use_method_A).Invoke_O_O_O_O__O(root_29, arg_32, arg_33, arg_34) } }
func A_arbace_pprint_dispatch__init_A_Unit19__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(159, 1); var root_35 any = A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_pprint.A_arbace_pprint_use_method_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = A_arbace_pprint_dispatch__init_A_const_30.GetRawRoot__O(); var arg_39 any = A_arbace_pprint_dispatch__init_A_const_40; var arg_40 any = A_arbace_pprint_dispatch__init_A_const_22.GetRawRoot__O(); if linked_36 == nil { return ifn_37.Invoke_O_O_O__O(arg_38, arg_39, arg_40) } else { return linked_36.(*aot_arbace_pprint.A_arbace_pprint_use_method_A).Invoke_O_O_O_O__O(root_35, arg_38, arg_39, arg_40) } }
func A_arbace_pprint_dispatch__init_A_Unit20__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(160, 1); var root_41 any = A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_pprint.A_arbace_pprint_use_method_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = A_arbace_pprint_dispatch__init_A_const_30.GetRawRoot__O(); var arg_45 any = A_arbace_pprint_dispatch__init_A_const_41; var arg_46 any = A_arbace_pprint_dispatch__init_A_const_26.GetRawRoot__O(); if linked_42 == nil { return ifn_43.Invoke_O_O_O__O(arg_44, arg_45, arg_46) } else { return linked_42.(*aot_arbace_pprint.A_arbace_pprint_use_method_A).Invoke_O_O_O_O__O(root_41, arg_44, arg_45, arg_46) } }
func A_arbace_pprint_dispatch__init_A_Unit21__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(161, 1); var root_47 any = A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_pprint.A_arbace_pprint_use_method_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = A_arbace_pprint_dispatch__init_A_const_30.GetRawRoot__O(); var arg_51 any = A_arbace_pprint_dispatch__init_A_const_42; var arg_52 any = A_arbace_pprint_dispatch__init_A_const_28.GetRawRoot__O(); if linked_48 == nil { return ifn_49.Invoke_O_O_O__O(arg_50, arg_51, arg_52) } else { return linked_48.(*aot_arbace_pprint.A_arbace_pprint_use_method_A).Invoke_O_O_O_O__O(root_47, arg_50, arg_51, arg_52) } }
func A_arbace_pprint_dispatch__init_A_Unit22__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(162, 1); var root_53 any = A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_pprint.A_arbace_pprint_use_method_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = A_arbace_pprint_dispatch__init_A_const_30.GetRawRoot__O(); var arg_57 any = A_arbace_pprint_dispatch__init_A_const_43; var arg_58 any = A_arbace_pprint_dispatch__init_A_const_24.GetRawRoot__O(); if linked_54 == nil { return ifn_55.Invoke_O_O_O__O(arg_56, arg_57, arg_58) } else { return linked_54.(*aot_arbace_pprint.A_arbace_pprint_use_method_A).Invoke_O_O_O_O__O(root_53, arg_56, arg_57, arg_58) } }
func A_arbace_pprint_dispatch__init_A_Unit23__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(163, 1); var root_59 any = A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_pprint.A_arbace_pprint_use_method_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = A_arbace_pprint_dispatch__init_A_const_30.GetRawRoot__O(); var arg_63 any; var arg_64 any = A_arbace_pprint_dispatch__init_A_const_44.Get__O(); if linked_60 == nil { return ifn_61.Invoke_O_O_O__O(arg_62, arg_63, arg_64) } else { return linked_60.(*aot_arbace_pprint.A_arbace_pprint_use_method_A).Invoke_O_O_O_O__O(root_59, arg_62, arg_63, arg_64) } }
func A_arbace_pprint_dispatch__init_A_Unit24__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(164, 1); var root_65 any = A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_pprint.A_arbace_pprint_use_method_A_fn_class); var ifn_67 lang.IFn; if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = A_arbace_pprint_dispatch__init_A_const_30.GetRawRoot__O(); var arg_69 any = A_arbace_pprint_dispatch__init_A_const_34; var arg_70 any = A_arbace_pprint_dispatch__init_A_const_28.GetRawRoot__O(); if linked_66 == nil { return ifn_67.Invoke_O_O_O__O(arg_68, arg_69, arg_70) } else { return linked_66.(*aot_arbace_pprint.A_arbace_pprint_use_method_A).Invoke_O_O_O_O__O(root_65, arg_68, arg_69, arg_70) } }





func A_arbace_pprint_dispatch__init_A_Unit25__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(170, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_45; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_46)); return A_arbace_pprint_dispatch__init_A_const_45 }







func A_arbace_pprint_dispatch__init_A_Unit26__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_47; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_brackets_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_brackets_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); aot_arbace_pprint.A_arbace_pprint_brackets_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_48)); return A_arbace_pprint_dispatch__init_A_const_47 }






func A_arbace_pprint_dispatch__init_A_Unit27__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(185, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_49; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_ns_reference_A_New(); var tmp3 *jrt.Class; var fncls__72 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_ns_reference_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); aot_arbace_pprint.A_arbace_pprint_pprint_ns_reference_A_fn_class = fncls__72d; tmp3 = fncls__72d } else { tmp3 = fncls__72 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_50)); return A_arbace_pprint_dispatch__init_A_const_49 }

































func A_arbace_pprint_dispatch__init_A_Unit28__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(219, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_51; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_ns_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_ns_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); aot_arbace_pprint.A_arbace_pprint_pprint_ns_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_52)); return A_arbace_pprint_dispatch__init_A_const_51 }






























func A_arbace_pprint_dispatch__init_A_Unit29__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(250, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_53; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_fn__740000107_A_New(); var tmp3 *jrt.Class; var fncls__74 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__740000107_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); aot_arbace_pprint.A_arbace_pprint_fn__740000107_A_fn_class = fncls__74d; tmp3 = fncls__74d } else { tmp3 = fncls__74 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_54)); return A_arbace_pprint_dispatch__init_A_const_53 }






func A_arbace_pprint_dispatch__init_A_Unit30__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(257, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_55; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_single_defn_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_single_defn_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); aot_arbace_pprint.A_arbace_pprint_single_defn_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_56)); return A_arbace_pprint_dispatch__init_A_const_55 }








func A_arbace_pprint_dispatch__init_A_Unit31__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(266, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_57; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_multi_defn_A_New(); var tmp3 *jrt.Class; var fncls__76 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_multi_defn_A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); aot_arbace_pprint.A_arbace_pprint_multi_defn_A_fn_class = fncls__76d; tmp3 = fncls__76d } else { tmp3 = fncls__76 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_58)); return A_arbace_pprint_dispatch__init_A_const_57 }





func A_arbace_pprint_dispatch__init_A_Unit32__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(272, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_59; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_defn_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_defn_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); aot_arbace_pprint.A_arbace_pprint_pprint_defn_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_60)); return A_arbace_pprint_dispatch__init_A_const_59 }
























func A_arbace_pprint_dispatch__init_A_Unit33__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(297, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_61; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_binding_form_A_New(); var tmp3 *jrt.Class; var fncls__78 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_binding_form_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); aot_arbace_pprint.A_arbace_pprint_pprint_binding_form_A_fn_class = fncls__78d; tmp3 = fncls__78d } else { tmp3 = fncls__78 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_62)); return A_arbace_pprint_dispatch__init_A_const_61 }














func A_arbace_pprint_dispatch__init_A_Unit34__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(312, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_63; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_let_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_let_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); aot_arbace_pprint.A_arbace_pprint_pprint_let_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_64)); return A_arbace_pprint_dispatch__init_A_const_63 }













func A_arbace_pprint_dispatch__init_A_Unit35__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(326, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_65; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_fn__740000152_A_New(); var tmp3 *jrt.Class; var fncls__80 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__740000152_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); aot_arbace_pprint.A_arbace_pprint_fn__740000152_A_fn_class = fncls__80d; tmp3 = fncls__80d } else { tmp3 = fncls__80 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_66)); return A_arbace_pprint_dispatch__init_A_const_65 }

func A_arbace_pprint_dispatch__init_A_Unit36__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(328, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_67; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_cond_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_cond_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); aot_arbace_pprint.A_arbace_pprint_pprint_cond_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_68)); return A_arbace_pprint_dispatch__init_A_const_67 }



















func A_arbace_pprint_dispatch__init_A_Unit37__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(348, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_69; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_condp_A_New(); var tmp3 *jrt.Class; var fncls__82 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_condp_A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); aot_arbace_pprint.A_arbace_pprint_pprint_condp_A_fn_class = fncls__82d; tmp3 = fncls__82d } else { tmp3 = fncls__82 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_70)); return A_arbace_pprint_dispatch__init_A_const_69 }



















func A_arbace_pprint_dispatch__init_A_Unit38__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(368, 1); A_arbace_pprint_dispatch__init_A_const_71.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_71; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_72)); return A_arbace_pprint_dispatch__init_A_const_71.SetDynamic_Z__Var(true).Ref() }

func A_arbace_pprint_dispatch__init_A_Unit39__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(370, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_73; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_anon_func_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_anon_func_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); aot_arbace_pprint.A_arbace_pprint_pprint_anon_func_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_74)); return A_arbace_pprint_dispatch__init_A_const_73 }





















func A_arbace_pprint_dispatch__init_A_Unit40__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(392, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_45; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_simple_code_list_A_New(); var tmp3 *jrt.Class; var fncls__84 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_simple_code_list_A_fn_class; if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); aot_arbace_pprint.A_arbace_pprint_pprint_simple_code_list_A_fn_class = fncls__84d; tmp3 = fncls__84d } else { tmp3 = fncls__84 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_75)); return A_arbace_pprint_dispatch__init_A_const_45 }












func A_arbace_pprint_dispatch__init_A_Unit41__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(405, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_76; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_two_forms_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_two_forms_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); aot_arbace_pprint.A_arbace_pprint_two_forms_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_77)); return A_arbace_pprint_dispatch__init_A_const_76 }






func A_arbace_pprint_dispatch__init_A_Unit42__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(412, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_78; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_add_core_ns_A_New(); var tmp3 *jrt.Class; var fncls__86 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_add_core_ns_A_fn_class; if fncls__86 == nil { var fncls__86d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); aot_arbace_pprint.A_arbace_pprint_add_core_ns_A_fn_class = fncls__86d; tmp3 = fncls__86d } else { tmp3 = fncls__86 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_79)); return A_arbace_pprint_dispatch__init_A_const_78 }








func A_arbace_pprint_dispatch__init_A_Unit43__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(421, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_80; var tmp2 any; var root_91 any = A_arbace_pprint_dispatch__init_A_const_76.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_pprint.A_arbace_pprint_two_forms_A_fn_class); var ifn_93 lang.IFn; if
							linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any; var root_87 any = A_arbace_pprint_dispatch__init_A_const_78.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_pprint.A_arbace_pprint_add_core_ns_A_fn_class); var ifn_89 lang.IFn; if
							linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var tmp3 any = A_arbace_pprint_dispatch__init_A_const_81; var tmp4 any = A_arbace_pprint_dispatch__init_A_const_53.GetRawRoot__O(); var tmp5 any = A_arbace_pprint_dispatch__init_A_const_82; var tmp6 any = A_arbace_pprint_dispatch__init_A_const_73.GetRawRoot__O(); var tmp7 any = A_arbace_pprint_dispatch__init_A_const_83; var tmp8 any = A_arbace_pprint_dispatch__init_A_const_63.GetRawRoot__O(); var tmp9 any = A_arbace_pprint_dispatch__init_A_const_84; var tmp10 any = A_arbace_pprint_dispatch__init_A_const_65.GetRawRoot__O(); var tmp11 any = A_arbace_pprint_dispatch__init_A_const_85; var tmp12 any = A_arbace_pprint_dispatch__init_A_const_69.GetRawRoot__O(); var tmp13 any = A_arbace_pprint_dispatch__init_A_const_86; var tmp14 any = A_arbace_pprint_dispatch__init_A_const_53.GetRawRoot__O(); var tmp15 any = A_arbace_pprint_dispatch__init_A_const_87; var tmp16 any = A_arbace_pprint_dispatch__init_A_const_59.GetRawRoot__O(); var tmp17 any = A_arbace_pprint_dispatch__init_A_const_88; var tmp18 any = A_arbace_pprint_dispatch__init_A_const_59.GetRawRoot__O(); var tmp19 any = A_arbace_pprint_dispatch__init_A_const_89; var tmp20 any = A_arbace_pprint_dispatch__init_A_const_63.GetRawRoot__O(); var tmp21 any = A_arbace_pprint_dispatch__init_A_const_90; var tmp22 any = A_arbace_pprint_dispatch__init_A_const_53.GetRawRoot__O(); var tmp23 any = A_arbace_pprint_dispatch__init_A_const_91; var tmp24 any = A_arbace_pprint_dispatch__init_A_const_63.GetRawRoot__O(); var tmp25 any = A_arbace_pprint_dispatch__init_A_const_92; var tmp26 any = A_arbace_pprint_dispatch__init_A_const_65.GetRawRoot__O(); var tmp27 any = A_arbace_pprint_dispatch__init_A_const_93; var tmp28 any = A_arbace_pprint_dispatch__init_A_const_65.GetRawRoot__O(); var tmp29 any = A_arbace_pprint_dispatch__init_A_const_94; var tmp30 any = A_arbace_pprint_dispatch__init_A_const_53.GetRawRoot__O(); var tmp31 any = A_arbace_pprint_dispatch__init_A_const_95; var tmp32 any = A_arbace_pprint_dispatch__init_A_const_65.GetRawRoot__O(); var tmp33 any = A_arbace_pprint_dispatch__init_A_const_96; var tmp34 any = A_arbace_pprint_dispatch__init_A_const_63.GetRawRoot__O(); var tmp35 any = A_arbace_pprint_dispatch__init_A_const_97; var tmp36 any = A_arbace_pprint_dispatch__init_A_const_63.GetRawRoot__O(); var tmp37 any = A_arbace_pprint_dispatch__init_A_const_98; var tmp38 any = A_arbace_pprint_dispatch__init_A_const_53.GetRawRoot__O(); var tmp39 any = A_arbace_pprint_dispatch__init_A_const_99; var tmp40 any = A_arbace_pprint_dispatch__init_A_const_63.GetRawRoot__O(); var tmp41 any = A_arbace_pprint_dispatch__init_A_const_100; var tmp42 any = A_arbace_pprint_dispatch__init_A_const_51.GetRawRoot__O(); var tmp43 any = A_arbace_pprint_dispatch__init_A_const_101; var tmp44 any = A_arbace_pprint_dispatch__init_A_const_63.GetRawRoot__O(); var tmp45 any = A_arbace_pprint_dispatch__init_A_const_102; var tmp46 any = A_arbace_pprint_dispatch__init_A_const_67.GetRawRoot__O(); var tmp47 any = A_arbace_pprint_dispatch__init_A_const_103; var tmp48 any = A_arbace_pprint_dispatch__init_A_const_63.GetRawRoot__O(); var tmp49 any = A_arbace_pprint_dispatch__init_A_const_104; var tmp50 any = A_arbace_pprint_dispatch__init_A_const_59.GetRawRoot__O(); var tmp51 any = A_arbace_pprint_dispatch__init_A_const_105; var tmp52 any = A_arbace_pprint_dispatch__init_A_const_59.GetRawRoot__O(); var tmp53 any = A_arbace_pprint_dispatch__init_A_const_106; var tmp54 any = A_arbace_pprint_dispatch__init_A_const_53.GetRawRoot__O(); var tmp55 any = A_arbace_pprint_dispatch__init_A_const_107; var tmp56 any = A_arbace_pprint_dispatch__init_A_const_53.GetRawRoot__O(); var tmp57 any = A_arbace_pprint_dispatch__init_A_const_108; var tmp58 any = A_arbace_pprint_dispatch__init_A_const_63.GetRawRoot__O(); var tmp59 any = A_arbace_pprint_dispatch__init_A_const_109; var tmp60 any = A_arbace_pprint_dispatch__init_A_const_63.GetRawRoot__O(); var tmp61 any = A_arbace_pprint_dispatch__init_A_const_110; var arg_90 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, tmp22, tmp23, tmp24, tmp25, tmp26, tmp27, tmp28, tmp29, tmp30, tmp31, tmp32, tmp33, tmp34, tmp35, tmp36, tmp37, tmp38, tmp39, tmp40, tmp41, tmp42, tmp43, tmp44, tmp45, tmp46, tmp47, tmp48, tmp49, tmp50, tmp51, tmp52, tmp53, tmp54, tmp55, tmp56, tmp57, tmp58, tmp59, tmp60, tmp61, A_arbace_pprint_dispatch__init_A_const_53.GetRawRoot__O())); if linked_88 == nil { arg_94 = ifn_89.Invoke_O__O(arg_90) } else { arg_94 = linked_88.(*aot_arbace_pprint.A_arbace_pprint_add_core_ns_A).Invoke_O_O__O(root_87, arg_90) }; if /*line :422:1*/ linked_92 == nil { tmp2 = ifn_93.Invoke_O__O(arg_94) } else { tmp2 = linked_92.(*aot_arbace_pprint.A_arbace_pprint_two_forms_A).Invoke_O_O__O(root_91, arg_94) }; /*line :421:1*/tmp1.BindRoot_O__V(tmp2); var tmp62 *lang.Var = A_arbace_pprint_dispatch__init_A_const_80; tmp62.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_111)); return A_arbace_pprint_dispatch__init_A_const_80.SetDynamic_Z__Var(true).Ref() }
















func A_arbace_pprint_dispatch__init_A_Unit44__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(438, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_112; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_code_list_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_code_list_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); aot_arbace_pprint.A_arbace_pprint_pprint_code_list_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_112; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_113)); return A_arbace_pprint_dispatch__init_A_const_112 }





func A_arbace_pprint_dispatch__init_A_Unit45__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(444, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_114; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_code_symbol_A_New(); var tmp3 *jrt.Class; var fncls__96 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pprint_code_symbol_A_fn_class; if fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); aot_arbace_pprint.A_arbace_pprint_pprint_code_symbol_A_fn_class = fncls__96d; tmp3 = fncls__96d } else { tmp3 = fncls__96 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_115)); return A_arbace_pprint_dispatch__init_A_const_114 }






func A_arbace_pprint_dispatch__init_A_Unit46__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(451, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_116; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_117)); v__1927000386__auto____1 = A_arbace_pprint_dispatch__init_A_const_116; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { var tmp3 any; var root_97 any = A_arbace_pprint_dispatch__init_A_const_32.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = v__1927000386__auto____1; if linked_98 == nil { tmp3 = ifn_99.Invoke_O__O(arg_100) } else { tmp3 = linked_98.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_97, arg_100) }; tmp2 = lang.MultiFn_InstanceOf(tmp3) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_116; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_118)); var tmp5 *lang.Var = A_arbace_pprint_dispatch__init_A_const_116; var tmp6 *jrt.String = Lit_32; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_pprint_dispatch__init_A_const_33.GetRawRoot__O()); var tmp8 any = A_arbace_pprint_dispatch__init_A_const_34; tmp5.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp6, tmp7, tmp8, A_arbace_pprint_dispatch__init_A_const_35)); return A_arbace_pprint_dispatch__init_A_const_116 } }





func A_arbace_pprint_dispatch__init_A_Unit47__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(457, 1); var root_101 any = A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, aot_arbace_pprint.A_arbace_pprint_use_method_A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = A_arbace_pprint_dispatch__init_A_const_116.GetRawRoot__O(); var arg_105 any = A_arbace_pprint_dispatch__init_A_const_37; var arg_106 any = A_arbace_pprint_dispatch__init_A_const_112.GetRawRoot__O(); if linked_102 == nil { return ifn_103.Invoke_O_O_O__O(arg_104, arg_105, arg_106) } else { return linked_102.(*aot_arbace_pprint.A_arbace_pprint_use_method_A).Invoke_O_O_O_O__O(root_101, arg_104, arg_105, arg_106) } }
func A_arbace_pprint_dispatch__init_A_Unit48__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(458, 1); var root_107 any = A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_pprint.A_arbace_pprint_use_method_A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = A_arbace_pprint_dispatch__init_A_const_116.GetRawRoot__O(); var arg_111 any = A_arbace_pprint_dispatch__init_A_const_119; var arg_112 any = A_arbace_pprint_dispatch__init_A_const_114.GetRawRoot__O(); if linked_108 == nil { return ifn_109.Invoke_O_O_O__O(arg_110, arg_111, arg_112) } else { return linked_108.(*aot_arbace_pprint.A_arbace_pprint_use_method_A).Invoke_O_O_O_O__O(root_107, arg_110, arg_111, arg_112) } }


func A_arbace_pprint_dispatch__init_A_Unit49__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(461, 1); var root_113 any = A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, aot_arbace_pprint.A_arbace_pprint_use_method_A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = A_arbace_pprint_dispatch__init_A_const_116.GetRawRoot__O(); var arg_117 any = A_arbace_pprint_dispatch__init_A_const_38; var arg_118 any = A_arbace_pprint_dispatch__init_A_const_17.GetRawRoot__O(); if linked_114 == nil { return ifn_115.Invoke_O_O_O__O(arg_116, arg_117, arg_118) } else { return linked_114.(*aot_arbace_pprint.A_arbace_pprint_use_method_A).Invoke_O_O_O_O__O(root_113, arg_116, arg_117, arg_118) } }
func A_arbace_pprint_dispatch__init_A_Unit50__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(462, 1); var root_119 any = A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_pprint.A_arbace_pprint_use_method_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = A_arbace_pprint_dispatch__init_A_const_116.GetRawRoot__O(); var arg_123 any = A_arbace_pprint_dispatch__init_A_const_39; var arg_124 any = A_arbace_pprint_dispatch__init_A_const_9.GetRawRoot__O(); if linked_120 == nil { return ifn_121.Invoke_O_O_O__O(arg_122, arg_123, arg_124) } else { return linked_120.(*aot_arbace_pprint.A_arbace_pprint_use_method_A).Invoke_O_O_O_O__O(root_119, arg_122, arg_123, arg_124) } }
func A_arbace_pprint_dispatch__init_A_Unit51__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(463, 1); var root_125 any = A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, aot_arbace_pprint.A_arbace_pprint_use_method_A_fn_class); var ifn_127 lang.IFn; if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = A_arbace_pprint_dispatch__init_A_const_116.GetRawRoot__O(); var arg_129 any = A_arbace_pprint_dispatch__init_A_const_40; var arg_130 any = A_arbace_pprint_dispatch__init_A_const_22.GetRawRoot__O(); if linked_126 == nil { return ifn_127.Invoke_O_O_O__O(arg_128, arg_129, arg_130) } else { return linked_126.(*aot_arbace_pprint.A_arbace_pprint_use_method_A).Invoke_O_O_O_O__O(root_125, arg_128, arg_129, arg_130) } }
func A_arbace_pprint_dispatch__init_A_Unit52__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(464, 1); var root_131 any = A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, aot_arbace_pprint.A_arbace_pprint_use_method_A_fn_class); var ifn_133 lang.IFn; if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any = A_arbace_pprint_dispatch__init_A_const_116.GetRawRoot__O(); var arg_135 any = A_arbace_pprint_dispatch__init_A_const_41; var arg_136 any = A_arbace_pprint_dispatch__init_A_const_26.GetRawRoot__O(); if linked_132 == nil { return ifn_133.Invoke_O_O_O__O(arg_134, arg_135, arg_136) } else { return linked_132.(*aot_arbace_pprint.A_arbace_pprint_use_method_A).Invoke_O_O_O_O__O(root_131, arg_134, arg_135, arg_136) } }
func A_arbace_pprint_dispatch__init_A_Unit53__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(465, 1); var root_137 any = A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_pprint.A_arbace_pprint_use_method_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = A_arbace_pprint_dispatch__init_A_const_116.GetRawRoot__O(); var arg_141 any = A_arbace_pprint_dispatch__init_A_const_43; var arg_142 any = A_arbace_pprint_dispatch__init_A_const_24.GetRawRoot__O(); if linked_138 == nil { return ifn_139.Invoke_O_O_O__O(arg_140, arg_141, arg_142) } else { return linked_138.(*aot_arbace_pprint.A_arbace_pprint_use_method_A).Invoke_O_O_O_O__O(root_137, arg_140, arg_141, arg_142) } }
func A_arbace_pprint_dispatch__init_A_Unit54__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(466, 1); var root_143 any = A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, aot_arbace_pprint.A_arbace_pprint_use_method_A_fn_class); var ifn_145 lang.IFn; if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = A_arbace_pprint_dispatch__init_A_const_116.GetRawRoot__O(); var arg_147 any; var arg_148 any = A_arbace_pprint_dispatch__init_A_const_44.Get__O(); if linked_144 == nil { return ifn_145.Invoke_O_O_O__O(arg_146, arg_147, arg_148) } else { return linked_144.(*aot_arbace_pprint.A_arbace_pprint_use_method_A).Invoke_O_O_O_O__O(root_143, arg_146, arg_147, arg_148) } }
func A_arbace_pprint_dispatch__init_A_Unit55__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(467, 1); var root_149 any = A_arbace_pprint_dispatch__init_A_const_2.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, aot_arbace_pprint.A_arbace_pprint_use_method_A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = A_arbace_pprint_dispatch__init_A_const_116.GetRawRoot__O(); var arg_153 any = A_arbace_pprint_dispatch__init_A_const_34; var arg_154 any = A_arbace_pprint_dispatch__init_A_const_28.GetRawRoot__O(); if linked_150 == nil { return ifn_151.Invoke_O_O_O__O(arg_152, arg_153, arg_154) } else { return linked_150.(*aot_arbace_pprint.A_arbace_pprint_use_method_A).Invoke_O_O_O_O__O(root_149, arg_152, arg_153, arg_154) } }

func A_arbace_pprint_dispatch__init_A_Unit56__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(469, 1); var root_155 any = A_arbace_pprint_dispatch__init_A_const_120.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_pprint.A_arbace_pprint_set_pprint_dispatch_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = A_arbace_pprint_dispatch__init_A_const_30.GetRawRoot__O(); if linked_156 == nil { return ifn_157.Invoke_O__O(arg_158) } else { return linked_156.(*aot_arbace_pprint.A_arbace_pprint_set_pprint_dispatch_A).Invoke_O_O__O(root_155, arg_158) } }


func A_arbace_pprint_dispatch__init_A_Unit57__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(472, 1); return nil }



type A_arbace_pprint_dispatch__init_A struct{ jrt.Object }

var A_arbace_pprint_dispatch__init_A_const_pool *jrt.RefArray

var A_arbace_pprint_dispatch__init_A_const_0 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_1 any

var A_arbace_pprint_dispatch__init_A_const_2 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_3 any

var A_arbace_pprint_dispatch__init_A_const_4 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_5 any

var A_arbace_pprint_dispatch__init_A_const_6 any

var A_arbace_pprint_dispatch__init_A_const_7 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_8 any

var A_arbace_pprint_dispatch__init_A_const_9 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_10 any

var A_arbace_pprint_dispatch__init_A_const_11 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_12 any

var A_arbace_pprint_dispatch__init_A_const_13 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_14 any

var A_arbace_pprint_dispatch__init_A_const_15 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_16 any

var A_arbace_pprint_dispatch__init_A_const_17 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_18 any

var A_arbace_pprint_dispatch__init_A_const_19 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_20 any

var A_arbace_pprint_dispatch__init_A_const_21 any

var A_arbace_pprint_dispatch__init_A_const_22 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_23 any

var A_arbace_pprint_dispatch__init_A_const_24 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_25 any

var A_arbace_pprint_dispatch__init_A_const_26 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_27 any

var A_arbace_pprint_dispatch__init_A_const_28 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_29 any

var A_arbace_pprint_dispatch__init_A_const_30 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_31 any

var A_arbace_pprint_dispatch__init_A_const_32 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_33 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_34 *lang.Keyword

var A_arbace_pprint_dispatch__init_A_const_35 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_36 any

var A_arbace_pprint_dispatch__init_A_const_37 *jrt.Class

var A_arbace_pprint_dispatch__init_A_const_38 *jrt.Class

var A_arbace_pprint_dispatch__init_A_const_39 *jrt.Class

var A_arbace_pprint_dispatch__init_A_const_40 *jrt.Class

var A_arbace_pprint_dispatch__init_A_const_41 *jrt.Class

var A_arbace_pprint_dispatch__init_A_const_42 *jrt.Class

var A_arbace_pprint_dispatch__init_A_const_43 *jrt.Class

var A_arbace_pprint_dispatch__init_A_const_44 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_45 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_46 any

var A_arbace_pprint_dispatch__init_A_const_47 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_48 any

var A_arbace_pprint_dispatch__init_A_const_49 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_50 any

var A_arbace_pprint_dispatch__init_A_const_51 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_52 any

var A_arbace_pprint_dispatch__init_A_const_53 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_54 any

var A_arbace_pprint_dispatch__init_A_const_55 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_56 any

var A_arbace_pprint_dispatch__init_A_const_57 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_58 any

var A_arbace_pprint_dispatch__init_A_const_59 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_60 any

var A_arbace_pprint_dispatch__init_A_const_61 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_62 any

var A_arbace_pprint_dispatch__init_A_const_63 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_64 any

var A_arbace_pprint_dispatch__init_A_const_65 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_66 any

var A_arbace_pprint_dispatch__init_A_const_67 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_68 any

var A_arbace_pprint_dispatch__init_A_const_69 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_70 any

var A_arbace_pprint_dispatch__init_A_const_71 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_72 any

var A_arbace_pprint_dispatch__init_A_const_73 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_74 any

var A_arbace_pprint_dispatch__init_A_const_75 any

var A_arbace_pprint_dispatch__init_A_const_76 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_77 any

var A_arbace_pprint_dispatch__init_A_const_78 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_79 any

var A_arbace_pprint_dispatch__init_A_const_80 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_81 any

var A_arbace_pprint_dispatch__init_A_const_82 any

var A_arbace_pprint_dispatch__init_A_const_83 any

var A_arbace_pprint_dispatch__init_A_const_84 any

var A_arbace_pprint_dispatch__init_A_const_85 any

var A_arbace_pprint_dispatch__init_A_const_86 any

var A_arbace_pprint_dispatch__init_A_const_87 any

var A_arbace_pprint_dispatch__init_A_const_88 any

var A_arbace_pprint_dispatch__init_A_const_89 any

var A_arbace_pprint_dispatch__init_A_const_90 any

var A_arbace_pprint_dispatch__init_A_const_91 any

var A_arbace_pprint_dispatch__init_A_const_92 any

var A_arbace_pprint_dispatch__init_A_const_93 any

var A_arbace_pprint_dispatch__init_A_const_94 any

var A_arbace_pprint_dispatch__init_A_const_95 any

var A_arbace_pprint_dispatch__init_A_const_96 any

var A_arbace_pprint_dispatch__init_A_const_97 any

var A_arbace_pprint_dispatch__init_A_const_98 any

var A_arbace_pprint_dispatch__init_A_const_99 any

var A_arbace_pprint_dispatch__init_A_const_100 any

var A_arbace_pprint_dispatch__init_A_const_101 any

var A_arbace_pprint_dispatch__init_A_const_102 any

var A_arbace_pprint_dispatch__init_A_const_103 any

var A_arbace_pprint_dispatch__init_A_const_104 any

var A_arbace_pprint_dispatch__init_A_const_105 any

var A_arbace_pprint_dispatch__init_A_const_106 any

var A_arbace_pprint_dispatch__init_A_const_107 any

var A_arbace_pprint_dispatch__init_A_const_108 any

var A_arbace_pprint_dispatch__init_A_const_109 any

var A_arbace_pprint_dispatch__init_A_const_110 any

var A_arbace_pprint_dispatch__init_A_const_111 any

var A_arbace_pprint_dispatch__init_A_const_112 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_113 any

var A_arbace_pprint_dispatch__init_A_const_114 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_115 any

var A_arbace_pprint_dispatch__init_A_const_116 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_117 any

var A_arbace_pprint_dispatch__init_A_const_118 any

var A_arbace_pprint_dispatch__init_A_const_119 *jrt.Class

var A_arbace_pprint_dispatch__init_A_const_120 *lang.Var

var A_arbace_pprint_dispatch__init_A_init jrt.ClassInit

func A_arbace_pprint_dispatch__init_A_Init() { if !A_arbace_pprint_dispatch__init_A_init.Done() { A_arbace_pprint_dispatch__init_A_init.Run(A_arbace_pprint_dispatch__init_A_clinit) } }

func A_arbace_pprint_dispatch__init_A_clinit() { A_arbace_pprint_dispatch__init_A_clinit_p0(); A_arbace_pprint_dispatch__init_A_clinit_p1(); A_arbace_pprint_dispatch__init_A_clinit_p2(); A_arbace_pprint_dispatch__init_A_clinit_p3(); A_arbace_pprint_dispatch__init_A_clinit_p4(); A_arbace_pprint_dispatch__init_A_clinit_p5(); A_arbace_pprint_dispatch__init_A_clinit_p6(); A_arbace_pprint_dispatch__init_A_clinit_p7(); A_arbace_pprint_dispatch__init_A_clinit_p8() }

func A_arbace_pprint_dispatch__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_pprint_dispatch__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 182); A_arbace_pprint_dispatch__init_A_const_0 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[61]); A_arbace_pprint_dispatch__init_A_const_1 = A_arbace_pprint_dispatch__init_A_const_pool.A[62]; A_arbace_pprint_dispatch__init_A_const_2 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[63]); A_arbace_pprint_dispatch__init_A_const_3 = A_arbace_pprint_dispatch__init_A_const_pool.A[64]; A_arbace_pprint_dispatch__init_A_const_4 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[65]); A_arbace_pprint_dispatch__init_A_const_5 = A_arbace_pprint_dispatch__init_A_const_pool.A[66]; A_arbace_pprint_dispatch__init_A_const_6 = A_arbace_pprint_dispatch__init_A_const_pool.A[67]; A_arbace_pprint_dispatch__init_A_const_7 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[68]); A_arbace_pprint_dispatch__init_A_const_8 = A_arbace_pprint_dispatch__init_A_const_pool.A[69]; A_arbace_pprint_dispatch__init_A_const_9 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[70]); A_arbace_pprint_dispatch__init_A_const_10 = A_arbace_pprint_dispatch__init_A_const_pool.A[71]; A_arbace_pprint_dispatch__init_A_const_11 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[72]); A_arbace_pprint_dispatch__init_A_const_12 = A_arbace_pprint_dispatch__init_A_const_pool.A[73] }

func A_arbace_pprint_dispatch__init_A_clinit_p1() { A_arbace_pprint_dispatch__init_A_const_13 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[74]); A_arbace_pprint_dispatch__init_A_const_14 = A_arbace_pprint_dispatch__init_A_const_pool.A[75]; A_arbace_pprint_dispatch__init_A_const_15 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[76]); A_arbace_pprint_dispatch__init_A_const_16 = A_arbace_pprint_dispatch__init_A_const_pool.A[77]; A_arbace_pprint_dispatch__init_A_const_17 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[78]); A_arbace_pprint_dispatch__init_A_const_18 = A_arbace_pprint_dispatch__init_A_const_pool.A[79]; A_arbace_pprint_dispatch__init_A_const_19 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[80]); A_arbace_pprint_dispatch__init_A_const_20 = A_arbace_pprint_dispatch__init_A_const_pool.A[81]; A_arbace_pprint_dispatch__init_A_const_21 = A_arbace_pprint_dispatch__init_A_const_pool.A[82]; A_arbace_pprint_dispatch__init_A_const_22 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[83]); A_arbace_pprint_dispatch__init_A_const_23 = A_arbace_pprint_dispatch__init_A_const_pool.A[84]; A_arbace_pprint_dispatch__init_A_const_24 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[85]); A_arbace_pprint_dispatch__init_A_const_25 = A_arbace_pprint_dispatch__init_A_const_pool.A[86] }

func A_arbace_pprint_dispatch__init_A_clinit_p2() { A_arbace_pprint_dispatch__init_A_const_26 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[87]); A_arbace_pprint_dispatch__init_A_const_27 = A_arbace_pprint_dispatch__init_A_const_pool.A[88]; A_arbace_pprint_dispatch__init_A_const_28 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[89]); A_arbace_pprint_dispatch__init_A_const_29 = A_arbace_pprint_dispatch__init_A_const_pool.A[90]; A_arbace_pprint_dispatch__init_A_const_30 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[91]); A_arbace_pprint_dispatch__init_A_const_31 = A_arbace_pprint_dispatch__init_A_const_pool.A[92]; A_arbace_pprint_dispatch__init_A_const_32 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[93]); A_arbace_pprint_dispatch__init_A_const_33 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[94]); A_arbace_pprint_dispatch__init_A_const_34 = lang.Keyword_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[95]); A_arbace_pprint_dispatch__init_A_const_35 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[96]); A_arbace_pprint_dispatch__init_A_const_36 = A_arbace_pprint_dispatch__init_A_const_pool.A[97]; A_arbace_pprint_dispatch__init_A_const_37 = jrt.Class_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[98]); A_arbace_pprint_dispatch__init_A_const_38 = jrt.Class_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[99]) }

func A_arbace_pprint_dispatch__init_A_clinit_p3() { A_arbace_pprint_dispatch__init_A_const_39 = jrt.Class_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[100]); A_arbace_pprint_dispatch__init_A_const_40 = jrt.Class_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[101]); A_arbace_pprint_dispatch__init_A_const_41 = jrt.Class_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[102]); A_arbace_pprint_dispatch__init_A_const_42 = jrt.Class_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[103]); A_arbace_pprint_dispatch__init_A_const_43 = jrt.Class_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[104]); A_arbace_pprint_dispatch__init_A_const_44 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[105]); A_arbace_pprint_dispatch__init_A_const_45 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[106]); A_arbace_pprint_dispatch__init_A_const_46 = A_arbace_pprint_dispatch__init_A_const_pool.A[107]; A_arbace_pprint_dispatch__init_A_const_47 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[108]); A_arbace_pprint_dispatch__init_A_const_48 = A_arbace_pprint_dispatch__init_A_const_pool.A[109]; A_arbace_pprint_dispatch__init_A_const_49 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[110]); A_arbace_pprint_dispatch__init_A_const_50 = A_arbace_pprint_dispatch__init_A_const_pool.A[111] }

func A_arbace_pprint_dispatch__init_A_clinit_p4() { A_arbace_pprint_dispatch__init_A_const_51 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[112]); A_arbace_pprint_dispatch__init_A_const_52 = A_arbace_pprint_dispatch__init_A_const_pool.A[113]; A_arbace_pprint_dispatch__init_A_const_53 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[114]); A_arbace_pprint_dispatch__init_A_const_54 = A_arbace_pprint_dispatch__init_A_const_pool.A[115]; A_arbace_pprint_dispatch__init_A_const_55 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[116]); A_arbace_pprint_dispatch__init_A_const_56 = A_arbace_pprint_dispatch__init_A_const_pool.A[117]; A_arbace_pprint_dispatch__init_A_const_57 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[118]); A_arbace_pprint_dispatch__init_A_const_58 = A_arbace_pprint_dispatch__init_A_const_pool.A[119]; A_arbace_pprint_dispatch__init_A_const_59 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[120]); A_arbace_pprint_dispatch__init_A_const_60 = A_arbace_pprint_dispatch__init_A_const_pool.A[121]; A_arbace_pprint_dispatch__init_A_const_61 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[122]); A_arbace_pprint_dispatch__init_A_const_62 = A_arbace_pprint_dispatch__init_A_const_pool.A[123]; A_arbace_pprint_dispatch__init_A_const_63 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[124]) }

func A_arbace_pprint_dispatch__init_A_clinit_p5() { A_arbace_pprint_dispatch__init_A_const_64 = A_arbace_pprint_dispatch__init_A_const_pool.A[125]; A_arbace_pprint_dispatch__init_A_const_65 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[126]); A_arbace_pprint_dispatch__init_A_const_66 = A_arbace_pprint_dispatch__init_A_const_pool.A[127]; A_arbace_pprint_dispatch__init_A_const_67 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[128]); A_arbace_pprint_dispatch__init_A_const_68 = A_arbace_pprint_dispatch__init_A_const_pool.A[129]; A_arbace_pprint_dispatch__init_A_const_69 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[130]); A_arbace_pprint_dispatch__init_A_const_70 = A_arbace_pprint_dispatch__init_A_const_pool.A[131]; A_arbace_pprint_dispatch__init_A_const_71 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[132]); A_arbace_pprint_dispatch__init_A_const_72 = A_arbace_pprint_dispatch__init_A_const_pool.A[133]; A_arbace_pprint_dispatch__init_A_const_73 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[134]); A_arbace_pprint_dispatch__init_A_const_74 = A_arbace_pprint_dispatch__init_A_const_pool.A[135]; A_arbace_pprint_dispatch__init_A_const_75 = A_arbace_pprint_dispatch__init_A_const_pool.A[136]; A_arbace_pprint_dispatch__init_A_const_76 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[137]); A_arbace_pprint_dispatch__init_A_const_77 = A_arbace_pprint_dispatch__init_A_const_pool.A[138] }

func A_arbace_pprint_dispatch__init_A_clinit_p6() { A_arbace_pprint_dispatch__init_A_const_78 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[139]); A_arbace_pprint_dispatch__init_A_const_79 = A_arbace_pprint_dispatch__init_A_const_pool.A[140]; A_arbace_pprint_dispatch__init_A_const_80 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[141]); A_arbace_pprint_dispatch__init_A_const_81 = A_arbace_pprint_dispatch__init_A_const_pool.A[142]; A_arbace_pprint_dispatch__init_A_const_82 = A_arbace_pprint_dispatch__init_A_const_pool.A[143]; A_arbace_pprint_dispatch__init_A_const_83 = A_arbace_pprint_dispatch__init_A_const_pool.A[144]; A_arbace_pprint_dispatch__init_A_const_84 = A_arbace_pprint_dispatch__init_A_const_pool.A[145]; A_arbace_pprint_dispatch__init_A_const_85 = A_arbace_pprint_dispatch__init_A_const_pool.A[146]; A_arbace_pprint_dispatch__init_A_const_86 = A_arbace_pprint_dispatch__init_A_const_pool.A[147]; A_arbace_pprint_dispatch__init_A_const_87 = A_arbace_pprint_dispatch__init_A_const_pool.A[148]; A_arbace_pprint_dispatch__init_A_const_88 = A_arbace_pprint_dispatch__init_A_const_pool.A[149]; A_arbace_pprint_dispatch__init_A_const_89 = A_arbace_pprint_dispatch__init_A_const_pool.A[150]; A_arbace_pprint_dispatch__init_A_const_90 = A_arbace_pprint_dispatch__init_A_const_pool.A[151]; A_arbace_pprint_dispatch__init_A_const_91 = A_arbace_pprint_dispatch__init_A_const_pool.A[152]; A_arbace_pprint_dispatch__init_A_const_92 = A_arbace_pprint_dispatch__init_A_const_pool.A[153] }

func A_arbace_pprint_dispatch__init_A_clinit_p7() { A_arbace_pprint_dispatch__init_A_const_93 = A_arbace_pprint_dispatch__init_A_const_pool.A[154]; A_arbace_pprint_dispatch__init_A_const_94 = A_arbace_pprint_dispatch__init_A_const_pool.A[155]; A_arbace_pprint_dispatch__init_A_const_95 = A_arbace_pprint_dispatch__init_A_const_pool.A[156]; A_arbace_pprint_dispatch__init_A_const_96 = A_arbace_pprint_dispatch__init_A_const_pool.A[157]; A_arbace_pprint_dispatch__init_A_const_97 = A_arbace_pprint_dispatch__init_A_const_pool.A[158]; A_arbace_pprint_dispatch__init_A_const_98 = A_arbace_pprint_dispatch__init_A_const_pool.A[159]; A_arbace_pprint_dispatch__init_A_const_99 = A_arbace_pprint_dispatch__init_A_const_pool.A[160]; A_arbace_pprint_dispatch__init_A_const_100 = A_arbace_pprint_dispatch__init_A_const_pool.A[161]; A_arbace_pprint_dispatch__init_A_const_101 = A_arbace_pprint_dispatch__init_A_const_pool.A[162]; A_arbace_pprint_dispatch__init_A_const_102 = A_arbace_pprint_dispatch__init_A_const_pool.A[163]; A_arbace_pprint_dispatch__init_A_const_103 = A_arbace_pprint_dispatch__init_A_const_pool.A[164]; A_arbace_pprint_dispatch__init_A_const_104 = A_arbace_pprint_dispatch__init_A_const_pool.A[165]; A_arbace_pprint_dispatch__init_A_const_105 = A_arbace_pprint_dispatch__init_A_const_pool.A[166]; A_arbace_pprint_dispatch__init_A_const_106 = A_arbace_pprint_dispatch__init_A_const_pool.A[167]; A_arbace_pprint_dispatch__init_A_const_107 = A_arbace_pprint_dispatch__init_A_const_pool.A[168]; A_arbace_pprint_dispatch__init_A_const_108 = A_arbace_pprint_dispatch__init_A_const_pool.A[169] }

func A_arbace_pprint_dispatch__init_A_clinit_p8() { A_arbace_pprint_dispatch__init_A_const_109 = A_arbace_pprint_dispatch__init_A_const_pool.A[170]; A_arbace_pprint_dispatch__init_A_const_110 = A_arbace_pprint_dispatch__init_A_const_pool.A[171]; A_arbace_pprint_dispatch__init_A_const_111 = A_arbace_pprint_dispatch__init_A_const_pool.A[172]; A_arbace_pprint_dispatch__init_A_const_112 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[173]); A_arbace_pprint_dispatch__init_A_const_113 = A_arbace_pprint_dispatch__init_A_const_pool.A[174]; A_arbace_pprint_dispatch__init_A_const_114 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[175]); A_arbace_pprint_dispatch__init_A_const_115 = A_arbace_pprint_dispatch__init_A_const_pool.A[176]; A_arbace_pprint_dispatch__init_A_const_116 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[177]); A_arbace_pprint_dispatch__init_A_const_117 = A_arbace_pprint_dispatch__init_A_const_pool.A[178]; A_arbace_pprint_dispatch__init_A_const_118 = A_arbace_pprint_dispatch__init_A_const_pool.A[179]; A_arbace_pprint_dispatch__init_A_const_119 = jrt.Class_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[180]); A_arbace_pprint_dispatch__init_A_const_120 = lang.Var_Cast(A_arbace_pprint_dispatch__init_A_const_pool.A[181]) }

func A_arbace_pprint_dispatch__init_A_New() *A_arbace_pprint_dispatch__init_A { A_arbace_pprint_dispatch__init_A_Init(); t := &A_arbace_pprint_dispatch__init_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_dispatch__init_A) Ctor() {}

func (t *A_arbace_pprint_dispatch__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_dispatch__init_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_dispatch__init_A_class }

func (t *A_arbace_pprint_dispatch__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_dispatch__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_pprint_dispatch__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_dispatch__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_dispatch__init_A); return ok }

func A_arbace_pprint_dispatch__init_A_Cast(x any) *A_arbace_pprint_dispatch__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_dispatch__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_dispatch__init_A_class)) }; return v }
