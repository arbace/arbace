//line aot_arbace_pprint_dispatch__init.ae:1
package aot_arbace_pprint_dispatch

import (
	"arbace/aot_arbace_pprint"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_pprint_dispatch__init_A_Load__O() any { A_arbace_pprint_dispatch__init_A_Init(); A_arbace_pprint_dispatch__init_A_Unit0__O(); A_arbace_pprint_dispatch__init_A_Unit1__O(); A_arbace_pprint_dispatch__init_A_Unit2__O(); A_arbace_pprint_dispatch__init_A_Unit3__O(); A_arbace_pprint_dispatch__init_A_Unit4__O(); A_arbace_pprint_dispatch__init_A_Unit5__O(); A_arbace_pprint_dispatch__init_A_Unit6__O(); A_arbace_pprint_dispatch__init_A_Unit7__O(); A_arbace_pprint_dispatch__init_A_Unit8__O(); A_arbace_pprint_dispatch__init_A_Unit9__O(); A_arbace_pprint_dispatch__init_A_Unit10__O(); A_arbace_pprint_dispatch__init_A_Unit11__O(); A_arbace_pprint_dispatch__init_A_Unit12__O(); A_arbace_pprint_dispatch__init_A_Unit13__O(); A_arbace_pprint_dispatch__init_A_Unit14__O(); A_arbace_pprint_dispatch__init_A_Unit15__O(); A_arbace_pprint_dispatch__init_A_Unit16__O(); A_arbace_pprint_dispatch__init_A_Unit17__O(); A_arbace_pprint_dispatch__init_A_Unit18__O(); A_arbace_pprint_dispatch__init_A_Unit19__O(); A_arbace_pprint_dispatch__init_A_Unit20__O(); A_arbace_pprint_dispatch__init_A_Unit21__O(); A_arbace_pprint_dispatch__init_A_Unit22__O(); A_arbace_pprint_dispatch__init_A_Unit23__O(); A_arbace_pprint_dispatch__init_A_Unit24__O(); A_arbace_pprint_dispatch__init_A_Unit25__O(); A_arbace_pprint_dispatch__init_A_Unit26__O(); A_arbace_pprint_dispatch__init_A_Unit27__O(); A_arbace_pprint_dispatch__init_A_Unit28__O(); A_arbace_pprint_dispatch__init_A_Unit29__O(); A_arbace_pprint_dispatch__init_A_Unit30__O(); A_arbace_pprint_dispatch__init_A_Unit31__O(); A_arbace_pprint_dispatch__init_A_Unit32__O(); A_arbace_pprint_dispatch__init_A_Unit33__O(); A_arbace_pprint_dispatch__init_A_Unit34__O(); A_arbace_pprint_dispatch__init_A_Unit35__O(); A_arbace_pprint_dispatch__init_A_Unit36__O(); A_arbace_pprint_dispatch__init_A_Unit37__O(); A_arbace_pprint_dispatch__init_A_Unit38__O(); A_arbace_pprint_dispatch__init_A_Unit39__O(); A_arbace_pprint_dispatch__init_A_Unit40__O(); A_arbace_pprint_dispatch__init_A_Unit41__O(); A_arbace_pprint_dispatch__init_A_Unit42__O(); A_arbace_pprint_dispatch__init_A_Unit43__O(); A_arbace_pprint_dispatch__init_A_Unit44__O(); A_arbace_pprint_dispatch__init_A_Unit45__O(); A_arbace_pprint_dispatch__init_A_Unit46__O(); A_arbace_pprint_dispatch__init_A_Unit47__O(); A_arbace_pprint_dispatch__init_A_Unit48__O(); A_arbace_pprint_dispatch__init_A_Unit49__O(); A_arbace_pprint_dispatch__init_A_Unit50__O(); A_arbace_pprint_dispatch__init_A_Unit51__O(); A_arbace_pprint_dispatch__init_A_Unit52__O(); A_arbace_pprint_dispatch__init_A_Unit53__O(); A_arbace_pprint_dispatch__init_A_Unit54__O(); A_arbace_pprint_dispatch__init_A_Unit55__O(); A_arbace_pprint_dispatch__init_A_Unit56__O(); A_arbace_pprint_dispatch__init_A_Unit57__O(); A_arbace_pprint_dispatch__init_A_Unit58__O(); return nil }











func A_arbace_pprint_dispatch__init_A_Unit0__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(17, 1); return lang.IFn_Cast(jrt.NN(A_arbace_pprint_dispatch__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_dispatch__init_A_const_1) }

func A_arbace_pprint_dispatch__init_A_Unit1__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_2; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_use_method_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_use_method_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_use_method_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_2; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_3)); return A_arbace_pprint_dispatch__init_A_const_2.Ref() }
























func A_arbace_pprint_dispatch__init_A_Unit2__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); jrt.NN(A_arbace_pprint_dispatch__init_A_const_4).BindRoot_O__V(A_arbace_pprint_dispatch__init_A_const_5); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_4; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_6)); return A_arbace_pprint_dispatch__init_A_const_4.Ref() }



func A_arbace_pprint_dispatch__init_A_Unit3__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_7; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_reader_macro_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pprint_reader_macro_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pprint_reader_macro_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_7; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_8)); return A_arbace_pprint_dispatch__init_A_const_7.Ref() }
//line :48:1
func A_arbace_pprint_dispatch__init_A_Unit58__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); return nil }















func A_arbace_pprint_dispatch__init_A_Unit4__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(64, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_9; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_10)); return A_arbace_pprint_dispatch__init_A_const_9.Ref() }

func A_arbace_pprint_dispatch__init_A_Unit5__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(66, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_11; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_meta_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pprint_meta_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pprint_meta_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_11; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_12)); return A_arbace_pprint_dispatch__init_A_const_11.Ref() }








func A_arbace_pprint_dispatch__init_A_Unit6__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(75, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_13; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_simple_list_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pprint_simple_list_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pprint_simple_list_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_13; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_14)); return A_arbace_pprint_dispatch__init_A_const_13.Ref() }










func A_arbace_pprint_dispatch__init_A_Unit7__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(86, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_15; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_list_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pprint_list_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pprint_list_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_15; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_16)); return A_arbace_pprint_dispatch__init_A_const_15.Ref() }




func A_arbace_pprint_dispatch__init_A_Unit8__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(91, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_17; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_vector_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pprint_vector_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pprint_vector_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_17; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_18)); return A_arbace_pprint_dispatch__init_A_const_17.Ref() }










func A_arbace_pprint_dispatch__init_A_Unit9__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(102, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_19; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_fn__740000014_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_fn__740000014_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_fn__740000014_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_19; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_20)); return A_arbace_pprint_dispatch__init_A_const_19.Ref() }


func A_arbace_pprint_dispatch__init_A_Unit10__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(105, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_9; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_map_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pprint_map_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pprint_map_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_9; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_21)); return A_arbace_pprint_dispatch__init_A_const_9.Ref() }




















func A_arbace_pprint_dispatch__init_A_Unit11__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(126, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_22; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_set_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pprint_set_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pprint_set_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_23)); return A_arbace_pprint_dispatch__init_A_const_22.Ref() }










func A_arbace_pprint_dispatch__init_A_Unit12__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(137, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_24; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_ideref_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pprint_ideref_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pprint_ideref_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_25)); return A_arbace_pprint_dispatch__init_A_const_24.Ref() }




func A_arbace_pprint_dispatch__init_A_Unit13__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(142, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_26; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_fn__740000032_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_fn__740000032_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_fn__740000032_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_26; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_27)); return A_arbace_pprint_dispatch__init_A_const_26.Ref() }

func A_arbace_pprint_dispatch__init_A_Unit14__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(144, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_28; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_simple_default_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pprint_simple_default_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pprint_simple_default_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_28; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_29)); return A_arbace_pprint_dispatch__init_A_const_28.Ref() }





func A_arbace_pprint_dispatch__init_A_Unit15__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(150, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_30; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_31)); v__1927000386__auto____1 = A_arbace_pprint_dispatch__init_A_const_30.Ref(); var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { tmp2 = lang.MultiFn_InstanceOf(lang.IFn_Cast(jrt.NN(A_arbace_pprint_dispatch__init_A_const_32).GetRawRoot__O()).Invoke_O__O(v__1927000386__auto____1)) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp3 *lang.Var = A_arbace_pprint_dispatch__init_A_const_30; jrt.NN(tmp3).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_36)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_30; var tmp5 *jrt.String = Lit_44; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_pprint_dispatch__init_A_const_33).GetRawRoot__O()); var tmp7 any = A_arbace_pprint_dispatch__init_A_const_34.Ref(); jrt.NN(tmp4).BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp5, tmp6, tmp7, Up_Var_IRef(A_arbace_pprint_dispatch__init_A_const_35))); return A_arbace_pprint_dispatch__init_A_const_30.Ref() } }





func A_arbace_pprint_dispatch__init_A_Unit16__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(156, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_pprint_dispatch__init_A_const_2).GetRawRoot__O()); var tmp2 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_30).GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_37.Ref(); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, jrt.NN(A_arbace_pprint_dispatch__init_A_const_15).GetRawRoot__O()) }
func A_arbace_pprint_dispatch__init_A_Unit17__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(157, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_pprint_dispatch__init_A_const_2).GetRawRoot__O()); var tmp2 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_30).GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_38.Ref(); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, jrt.NN(A_arbace_pprint_dispatch__init_A_const_17).GetRawRoot__O()) }
func A_arbace_pprint_dispatch__init_A_Unit18__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(158, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_pprint_dispatch__init_A_const_2).GetRawRoot__O()); var tmp2 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_30).GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_39.Ref(); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, jrt.NN(A_arbace_pprint_dispatch__init_A_const_9).GetRawRoot__O()) }
func A_arbace_pprint_dispatch__init_A_Unit19__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(159, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_pprint_dispatch__init_A_const_2).GetRawRoot__O()); var tmp2 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_30).GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_40.Ref(); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, jrt.NN(A_arbace_pprint_dispatch__init_A_const_22).GetRawRoot__O()) }
func A_arbace_pprint_dispatch__init_A_Unit20__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(160, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_pprint_dispatch__init_A_const_2).GetRawRoot__O()); var tmp2 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_30).GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_41.Ref(); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, jrt.NN(A_arbace_pprint_dispatch__init_A_const_26).GetRawRoot__O()) }
func A_arbace_pprint_dispatch__init_A_Unit21__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(161, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_pprint_dispatch__init_A_const_2).GetRawRoot__O()); var tmp2 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_30).GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_42.Ref(); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, jrt.NN(A_arbace_pprint_dispatch__init_A_const_28).GetRawRoot__O()) }
func A_arbace_pprint_dispatch__init_A_Unit22__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(162, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_pprint_dispatch__init_A_const_2).GetRawRoot__O()); var tmp2 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_30).GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_43.Ref(); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, jrt.NN(A_arbace_pprint_dispatch__init_A_const_24).GetRawRoot__O()) }
func A_arbace_pprint_dispatch__init_A_Unit23__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(163, 1); return lang.IFn_Cast(jrt.NN(A_arbace_pprint_dispatch__init_A_const_2).GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(A_arbace_pprint_dispatch__init_A_const_30).GetRawRoot__O(), nil, jrt.NN(A_arbace_pprint_dispatch__init_A_const_44).Get__O()) }
func A_arbace_pprint_dispatch__init_A_Unit24__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(164, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_pprint_dispatch__init_A_const_2).GetRawRoot__O()); var tmp2 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_30).GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_34.Ref(); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, jrt.NN(A_arbace_pprint_dispatch__init_A_const_28).GetRawRoot__O()) }





func A_arbace_pprint_dispatch__init_A_Unit25__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(170, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_45; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_46)); return A_arbace_pprint_dispatch__init_A_const_45.Ref() }







func A_arbace_pprint_dispatch__init_A_Unit26__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(178, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_47; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_brackets_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_brackets_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_brackets_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_47; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_48)); return A_arbace_pprint_dispatch__init_A_const_47.Ref() }






func A_arbace_pprint_dispatch__init_A_Unit27__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(185, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_49; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_ns_reference_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pprint_ns_reference_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pprint_ns_reference_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_49; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_50)); return A_arbace_pprint_dispatch__init_A_const_49.Ref() }

































func A_arbace_pprint_dispatch__init_A_Unit28__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(219, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_51; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_ns_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pprint_ns_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pprint_ns_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_51; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_52)); return A_arbace_pprint_dispatch__init_A_const_51.Ref() }






























func A_arbace_pprint_dispatch__init_A_Unit29__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(250, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_53; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_fn__740000107_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_fn__740000107_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_fn__740000107_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_53; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_54)); return A_arbace_pprint_dispatch__init_A_const_53.Ref() }






func A_arbace_pprint_dispatch__init_A_Unit30__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(257, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_55; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_single_defn_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_single_defn_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_single_defn_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_55; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_56)); return A_arbace_pprint_dispatch__init_A_const_55.Ref() }








func A_arbace_pprint_dispatch__init_A_Unit31__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(266, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_57; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_multi_defn_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_multi_defn_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_multi_defn_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_57; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_58)); return A_arbace_pprint_dispatch__init_A_const_57.Ref() }





func A_arbace_pprint_dispatch__init_A_Unit32__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(272, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_59; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_defn_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pprint_defn_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pprint_defn_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_59; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_60)); return A_arbace_pprint_dispatch__init_A_const_59.Ref() }
























func A_arbace_pprint_dispatch__init_A_Unit33__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(297, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_61; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_binding_form_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pprint_binding_form_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pprint_binding_form_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_61; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_62)); return A_arbace_pprint_dispatch__init_A_const_61.Ref() }














func A_arbace_pprint_dispatch__init_A_Unit34__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(312, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_63; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_let_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pprint_let_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pprint_let_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_63; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_64)); return A_arbace_pprint_dispatch__init_A_const_63.Ref() }













func A_arbace_pprint_dispatch__init_A_Unit35__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(326, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_65; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_fn__740000152_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_fn__740000152_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_fn__740000152_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_65; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_66)); return A_arbace_pprint_dispatch__init_A_const_65.Ref() }

func A_arbace_pprint_dispatch__init_A_Unit36__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(328, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_67; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_cond_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pprint_cond_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pprint_cond_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_67; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_68)); return A_arbace_pprint_dispatch__init_A_const_67.Ref() }



















func A_arbace_pprint_dispatch__init_A_Unit37__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(348, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_69; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_condp_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pprint_condp_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pprint_condp_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_69; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_70)); return A_arbace_pprint_dispatch__init_A_const_69.Ref() }



















func A_arbace_pprint_dispatch__init_A_Unit38__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(368, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_71; var tmp2 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; jrt.NN(tmp1).BindRoot_O__V(tmp2.Ref()); var tmp3 *lang.Var = A_arbace_pprint_dispatch__init_A_const_71; jrt.NN(tmp3).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_72)); return jrt.NN(A_arbace_pprint_dispatch__init_A_const_71).SetDynamic_Z__Var(true).Ref() }

func A_arbace_pprint_dispatch__init_A_Unit39__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(370, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_73; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_anon_func_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pprint_anon_func_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pprint_anon_func_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_73; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_74)); return A_arbace_pprint_dispatch__init_A_const_73.Ref() }





















func A_arbace_pprint_dispatch__init_A_Unit40__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(392, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_45; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_simple_code_list_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pprint_simple_code_list_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pprint_simple_code_list_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_45; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_75)); return A_arbace_pprint_dispatch__init_A_const_45.Ref() }












func A_arbace_pprint_dispatch__init_A_Unit41__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(405, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_76; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_two_forms_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_two_forms_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_two_forms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_76; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_77)); return A_arbace_pprint_dispatch__init_A_const_76.Ref() }






func A_arbace_pprint_dispatch__init_A_Unit42__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(412, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_78; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_add_core_ns_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_add_core_ns_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_add_core_ns_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_78; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_79)); return A_arbace_pprint_dispatch__init_A_const_78.Ref() }








func A_arbace_pprint_dispatch__init_A_Unit43__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(421, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_80; var tmp2 any = A_arbace_pprint_dispatch__init_A_const_82; var tmp3 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_53).GetRawRoot__O(); var tmp4 any = A_arbace_pprint_dispatch__init_A_const_83; var tmp5 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_73).GetRawRoot__O(); var tmp6 any = A_arbace_pprint_dispatch__init_A_const_84; var tmp7 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_63).GetRawRoot__O(); var tmp8 any = A_arbace_pprint_dispatch__init_A_const_85; var tmp9 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_65).GetRawRoot__O(); var tmp10 any = A_arbace_pprint_dispatch__init_A_const_86; var tmp11 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_69).GetRawRoot__O(); var tmp12 any = A_arbace_pprint_dispatch__init_A_const_87; var tmp13 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_53).GetRawRoot__O(); var tmp14 any = A_arbace_pprint_dispatch__init_A_const_88; var tmp15 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_59).GetRawRoot__O(); var tmp16 any = A_arbace_pprint_dispatch__init_A_const_89; var tmp17 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_59).GetRawRoot__O(); var tmp18 any = A_arbace_pprint_dispatch__init_A_const_90; var tmp19 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_63).GetRawRoot__O(); var tmp20 any = A_arbace_pprint_dispatch__init_A_const_91; var tmp21 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_53).GetRawRoot__O(); var tmp22 any = A_arbace_pprint_dispatch__init_A_const_92; var tmp23 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_63).GetRawRoot__O(); var tmp24 any = A_arbace_pprint_dispatch__init_A_const_93; var tmp25 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_65).GetRawRoot__O(); var tmp26 any = A_arbace_pprint_dispatch__init_A_const_94; var tmp27 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_65).GetRawRoot__O(); var tmp28 any = A_arbace_pprint_dispatch__init_A_const_95; var tmp29 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_53).GetRawRoot__O(); var tmp30 any = A_arbace_pprint_dispatch__init_A_const_96; var tmp31 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_65).GetRawRoot__O(); var tmp32 any = A_arbace_pprint_dispatch__init_A_const_97; var tmp33 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_63).GetRawRoot__O(); var tmp34 any = A_arbace_pprint_dispatch__init_A_const_98; var tmp35 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_63).GetRawRoot__O(); var tmp36 any = A_arbace_pprint_dispatch__init_A_const_99; var tmp37 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_53).GetRawRoot__O(); var tmp38 any = A_arbace_pprint_dispatch__init_A_const_100; var tmp39 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_63).GetRawRoot__O(); var tmp40 any = A_arbace_pprint_dispatch__init_A_const_101; var tmp41 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_51).GetRawRoot__O(); var tmp42 any = A_arbace_pprint_dispatch__init_A_const_102; var tmp43 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_63).GetRawRoot__O(); var tmp44 any = A_arbace_pprint_dispatch__init_A_const_103; var tmp45 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_67).GetRawRoot__O(); var tmp46 any = A_arbace_pprint_dispatch__init_A_const_104; var tmp47 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_63).GetRawRoot__O(); var tmp48 any = A_arbace_pprint_dispatch__init_A_const_105; var tmp49 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_59).GetRawRoot__O(); var tmp50 any = A_arbace_pprint_dispatch__init_A_const_106; var tmp51 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_59).GetRawRoot__O(); var tmp52 any = A_arbace_pprint_dispatch__init_A_const_107; var tmp53 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_53).GetRawRoot__O(); var tmp54 any = A_arbace_pprint_dispatch__init_A_const_108; var tmp55 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_53).GetRawRoot__O(); var tmp56 any = A_arbace_pprint_dispatch__init_A_const_109; var tmp57 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_63).GetRawRoot__O(); var tmp58 any = A_arbace_pprint_dispatch__init_A_const_110; var tmp59 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_63).GetRawRoot__O(); var tmp60 any = A_arbace_pprint_dispatch__init_A_const_111; jrt.NN(tmp1).BindRoot_O__V(lang.IFn_Cast(jrt.NN(A_arbace_pprint_dispatch__init_A_const_76).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(jrt.NN(A_arbace_pprint_dispatch__init_A_const_78).GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, tmp22, tmp23, tmp24, tmp25, tmp26, tmp27, tmp28, tmp29, tmp30, tmp31, tmp32, tmp33, tmp34, tmp35, tmp36, tmp37, tmp38, tmp39, tmp40, tmp41, tmp42, tmp43, tmp44, tmp45, tmp46, tmp47, tmp48, tmp49, tmp50, tmp51, tmp52, tmp53, tmp54, tmp55, tmp56, tmp57, tmp58, tmp59, tmp60, jrt.NN(A_arbace_pprint_dispatch__init_A_const_53).GetRawRoot__O()))))); var tmp61 *lang.Var = A_arbace_pprint_dispatch__init_A_const_80; jrt.NN(tmp61).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_81)); return jrt.NN(A_arbace_pprint_dispatch__init_A_const_80).SetDynamic_Z__Var(true).Ref() }
















func A_arbace_pprint_dispatch__init_A_Unit44__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(438, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_112; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_code_list_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pprint_code_list_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pprint_code_list_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_112; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_113)); return A_arbace_pprint_dispatch__init_A_const_112.Ref() }





func A_arbace_pprint_dispatch__init_A_Unit45__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(444, 1); var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_114; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pprint_code_symbol_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_pprint_code_symbol_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_pprint_code_symbol_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_114; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_115)); return A_arbace_pprint_dispatch__init_A_const_114.Ref() }






func A_arbace_pprint_dispatch__init_A_Unit46__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(451, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_pprint_dispatch__init_A_const_116; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_117)); v__1927000386__auto____1 = A_arbace_pprint_dispatch__init_A_const_116.Ref(); var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { tmp2 = lang.MultiFn_InstanceOf(lang.IFn_Cast(jrt.NN(A_arbace_pprint_dispatch__init_A_const_32).GetRawRoot__O()).Invoke_O__O(v__1927000386__auto____1)) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp3 *lang.Var = A_arbace_pprint_dispatch__init_A_const_116; jrt.NN(tmp3).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_dispatch__init_A_const_118)); var tmp4 *lang.Var = A_arbace_pprint_dispatch__init_A_const_116; var tmp5 *jrt.String = Lit_119; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_pprint_dispatch__init_A_const_33).GetRawRoot__O()); var tmp7 any = A_arbace_pprint_dispatch__init_A_const_34.Ref(); jrt.NN(tmp4).BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp5, tmp6, tmp7, Up_Var_IRef(A_arbace_pprint_dispatch__init_A_const_35))); return A_arbace_pprint_dispatch__init_A_const_116.Ref() } }





func A_arbace_pprint_dispatch__init_A_Unit47__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(457, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_pprint_dispatch__init_A_const_2).GetRawRoot__O()); var tmp2 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_116).GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_37.Ref(); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, jrt.NN(A_arbace_pprint_dispatch__init_A_const_112).GetRawRoot__O()) }
func A_arbace_pprint_dispatch__init_A_Unit48__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(458, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_pprint_dispatch__init_A_const_2).GetRawRoot__O()); var tmp2 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_116).GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_119.Ref(); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, jrt.NN(A_arbace_pprint_dispatch__init_A_const_114).GetRawRoot__O()) }


func A_arbace_pprint_dispatch__init_A_Unit49__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(461, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_pprint_dispatch__init_A_const_2).GetRawRoot__O()); var tmp2 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_116).GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_38.Ref(); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, jrt.NN(A_arbace_pprint_dispatch__init_A_const_17).GetRawRoot__O()) }
func A_arbace_pprint_dispatch__init_A_Unit50__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(462, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_pprint_dispatch__init_A_const_2).GetRawRoot__O()); var tmp2 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_116).GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_39.Ref(); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, jrt.NN(A_arbace_pprint_dispatch__init_A_const_9).GetRawRoot__O()) }
func A_arbace_pprint_dispatch__init_A_Unit51__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(463, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_pprint_dispatch__init_A_const_2).GetRawRoot__O()); var tmp2 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_116).GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_40.Ref(); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, jrt.NN(A_arbace_pprint_dispatch__init_A_const_22).GetRawRoot__O()) }
func A_arbace_pprint_dispatch__init_A_Unit52__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(464, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_pprint_dispatch__init_A_const_2).GetRawRoot__O()); var tmp2 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_116).GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_41.Ref(); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, jrt.NN(A_arbace_pprint_dispatch__init_A_const_26).GetRawRoot__O()) }
func A_arbace_pprint_dispatch__init_A_Unit53__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(465, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_pprint_dispatch__init_A_const_2).GetRawRoot__O()); var tmp2 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_116).GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_43.Ref(); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, jrt.NN(A_arbace_pprint_dispatch__init_A_const_24).GetRawRoot__O()) }
func A_arbace_pprint_dispatch__init_A_Unit54__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(466, 1); return lang.IFn_Cast(jrt.NN(A_arbace_pprint_dispatch__init_A_const_2).GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(A_arbace_pprint_dispatch__init_A_const_116).GetRawRoot__O(), nil, jrt.NN(A_arbace_pprint_dispatch__init_A_const_44).Get__O()) }
func A_arbace_pprint_dispatch__init_A_Unit55__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(467, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_pprint_dispatch__init_A_const_2).GetRawRoot__O()); var tmp2 any = jrt.NN(A_arbace_pprint_dispatch__init_A_const_116).GetRawRoot__O(); var tmp3 any = A_arbace_pprint_dispatch__init_A_const_34.Ref(); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, jrt.NN(A_arbace_pprint_dispatch__init_A_const_28).GetRawRoot__O()) }

func A_arbace_pprint_dispatch__init_A_Unit56__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(469, 1); return lang.IFn_Cast(jrt.NN(A_arbace_pprint_dispatch__init_A_const_120).GetRawRoot__O()).Invoke_O__O(jrt.NN(A_arbace_pprint_dispatch__init_A_const_30).GetRawRoot__O()) }


func A_arbace_pprint_dispatch__init_A_Unit57__O() any { A_arbace_pprint_dispatch__init_A_Init(); lang.Compiler_AOT_At_I_I__V(472, 1); return nil }



type A_arbace_pprint_dispatch__init_A struct{ jrt.Object }

var A_arbace_pprint_dispatch__init_A_const_0 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_1 any

var A_arbace_pprint_dispatch__init_A_const_2 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_3 any

var A_arbace_pprint_dispatch__init_A_const_4 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_5 any

var A_arbace_pprint_dispatch__init_A_const_6 any

var A_arbace_pprint_dispatch__init_A_const_7 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_8 any

var A_arbace_pprint_dispatch__init_A_const_9 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_10 any

var A_arbace_pprint_dispatch__init_A_const_11 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_12 any

var A_arbace_pprint_dispatch__init_A_const_13 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_14 any

var A_arbace_pprint_dispatch__init_A_const_15 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_16 any

var A_arbace_pprint_dispatch__init_A_const_17 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_18 any

var A_arbace_pprint_dispatch__init_A_const_19 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_20 any

var A_arbace_pprint_dispatch__init_A_const_21 any

var A_arbace_pprint_dispatch__init_A_const_22 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_23 any

var A_arbace_pprint_dispatch__init_A_const_24 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_25 any

var A_arbace_pprint_dispatch__init_A_const_26 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_27 any

var A_arbace_pprint_dispatch__init_A_const_28 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_29 any

var A_arbace_pprint_dispatch__init_A_const_30 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_31 any

var A_arbace_pprint_dispatch__init_A_const_32 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_33 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_34 *lang.Keyword

var A_arbace_pprint_dispatch__init_A_const_35 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_36 any

var A_arbace_pprint_dispatch__init_A_const_37 *jrt.Class

var A_arbace_pprint_dispatch__init_A_const_38 *jrt.Class

var A_arbace_pprint_dispatch__init_A_const_39 *jrt.Class

var A_arbace_pprint_dispatch__init_A_const_40 *jrt.Class

var A_arbace_pprint_dispatch__init_A_const_41 *jrt.Class

var A_arbace_pprint_dispatch__init_A_const_42 *jrt.Class

var A_arbace_pprint_dispatch__init_A_const_43 *jrt.Class

var A_arbace_pprint_dispatch__init_A_const_44 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_45 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_46 any

var A_arbace_pprint_dispatch__init_A_const_47 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_48 any

var A_arbace_pprint_dispatch__init_A_const_49 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_50 any

var A_arbace_pprint_dispatch__init_A_const_51 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_52 any

var A_arbace_pprint_dispatch__init_A_const_53 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_54 any

var A_arbace_pprint_dispatch__init_A_const_55 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_56 any

var A_arbace_pprint_dispatch__init_A_const_57 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_58 any

var A_arbace_pprint_dispatch__init_A_const_59 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_60 any

var A_arbace_pprint_dispatch__init_A_const_61 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_62 any

var A_arbace_pprint_dispatch__init_A_const_63 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_64 any

var A_arbace_pprint_dispatch__init_A_const_65 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_66 any

var A_arbace_pprint_dispatch__init_A_const_67 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_68 any

var A_arbace_pprint_dispatch__init_A_const_69 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_70 any

var A_arbace_pprint_dispatch__init_A_const_71 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_72 any

var A_arbace_pprint_dispatch__init_A_const_73 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_74 any

var A_arbace_pprint_dispatch__init_A_const_75 any

var A_arbace_pprint_dispatch__init_A_const_76 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_77 any

var A_arbace_pprint_dispatch__init_A_const_78 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_79 any

var A_arbace_pprint_dispatch__init_A_const_80 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_81 any

var A_arbace_pprint_dispatch__init_A_const_82 any

var A_arbace_pprint_dispatch__init_A_const_83 any

var A_arbace_pprint_dispatch__init_A_const_84 any

var A_arbace_pprint_dispatch__init_A_const_85 any

var A_arbace_pprint_dispatch__init_A_const_86 any

var A_arbace_pprint_dispatch__init_A_const_87 any

var A_arbace_pprint_dispatch__init_A_const_88 any

var A_arbace_pprint_dispatch__init_A_const_89 any

var A_arbace_pprint_dispatch__init_A_const_90 any

var A_arbace_pprint_dispatch__init_A_const_91 any

var A_arbace_pprint_dispatch__init_A_const_92 any

var A_arbace_pprint_dispatch__init_A_const_93 any

var A_arbace_pprint_dispatch__init_A_const_94 any

var A_arbace_pprint_dispatch__init_A_const_95 any

var A_arbace_pprint_dispatch__init_A_const_96 any

var A_arbace_pprint_dispatch__init_A_const_97 any

var A_arbace_pprint_dispatch__init_A_const_98 any

var A_arbace_pprint_dispatch__init_A_const_99 any

var A_arbace_pprint_dispatch__init_A_const_100 any

var A_arbace_pprint_dispatch__init_A_const_101 any

var A_arbace_pprint_dispatch__init_A_const_102 any

var A_arbace_pprint_dispatch__init_A_const_103 any

var A_arbace_pprint_dispatch__init_A_const_104 any

var A_arbace_pprint_dispatch__init_A_const_105 any

var A_arbace_pprint_dispatch__init_A_const_106 any

var A_arbace_pprint_dispatch__init_A_const_107 any

var A_arbace_pprint_dispatch__init_A_const_108 any

var A_arbace_pprint_dispatch__init_A_const_109 any

var A_arbace_pprint_dispatch__init_A_const_110 any

var A_arbace_pprint_dispatch__init_A_const_111 any

var A_arbace_pprint_dispatch__init_A_const_112 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_113 any

var A_arbace_pprint_dispatch__init_A_const_114 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_115 any

var A_arbace_pprint_dispatch__init_A_const_116 *lang.Var

var A_arbace_pprint_dispatch__init_A_const_117 any

var A_arbace_pprint_dispatch__init_A_const_118 any

var A_arbace_pprint_dispatch__init_A_const_119 *jrt.Class

var A_arbace_pprint_dispatch__init_A_const_120 *lang.Var

var A_arbace_pprint_dispatch__init_A_init jrt.ClassInit

func A_arbace_pprint_dispatch__init_A_Init() { if !A_arbace_pprint_dispatch__init_A_init.Done() { A_arbace_pprint_dispatch__init_A_init.Run(A_arbace_pprint_dispatch__init_A_clinit) } }

func A_arbace_pprint_dispatch__init_A_clinit() { A_arbace_pprint_dispatch__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_pprint_dispatch__init_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_2).Ref(); A_arbace_pprint_dispatch__init_A_const_2 = lang.RT_Var_String_String__Var(Lit_2, Lit_3); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_pprint_dispatch__init_A_const_3 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_8).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_10).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12, lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(19).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_2, Lit_17); A_arbace_pprint_dispatch__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_18).Ref(), Lit_19, lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_20).Ref(), Lit_21, lang.Symbol_Intern_String_String__Symbol(nil, Lit_22).Ref(), Lit_23, lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_24).Ref(), Lit_25)); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_pprint_dispatch__init_A_const_6 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(44).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_7 = lang.RT_Var_String_String__Var(Lit_2, Lit_26); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_pprint_dispatch__init_A_const_8 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_27).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(48).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_9 = lang.RT_Var_String_String__Var(Lit_2, Lit_28); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_29).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_pprint_dispatch__init_A_const_10 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(64).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_11 = lang.RT_Var_String_String__Var(Lit_2, Lit_30); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_pprint_dispatch__init_A_const_12 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_31).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(66).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_13 = lang.RT_Var_String_String__Var(Lit_2, Lit_32); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_pprint_dispatch__init_A_const_14 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_27).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(75).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_15 = lang.RT_Var_String_String__Var(Lit_2, Lit_33); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_pprint_dispatch__init_A_const_16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_27).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(86).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_17 = lang.RT_Var_String_String__Var(Lit_2, Lit_34); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_pprint_dispatch__init_A_const_18 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_35).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(91).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_19 = lang.RT_Var_String_String__Var(Lit_2, Lit_36); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_pprint_dispatch__init_A_const_20 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(102).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_pprint_dispatch__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_37).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(105).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_2, Lit_38); var tmp31 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp32 *jrt.Boolean; jrt.Boolean_Init(); tmp32 = jrt.Boolean_TRUE; var tmp33 any = tmp32.Ref(); A_arbace_pprint_dispatch__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp33, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_39).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(126).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_2, Lit_40); var tmp34 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp35 *jrt.Boolean; jrt.Boolean_Init(); tmp35 = jrt.Boolean_TRUE; var tmp36 any = tmp35.Ref(); A_arbace_pprint_dispatch__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, tmp36, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_41).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(137).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_2, Lit_42); var tmp37 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; var tmp39 any = tmp38.Ref(); A_arbace_pprint_dispatch__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(142).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_2, Lit_43); var tmp40 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp41 *jrt.Boolean; jrt.Boolean_Init(); tmp41 = jrt.Boolean_TRUE; var tmp42 any = tmp41.Ref(); A_arbace_pprint_dispatch__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp42, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_31).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(144).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_2, Lit_44); A_arbace_pprint_dispatch__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_45).Ref(), Lit_46, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_47).Ref())), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_48, lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(150).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_pprint_dispatch__init_A_const_33 = lang.RT_Var_String_String__Var(Lit_0, Lit_49); A_arbace_pprint_dispatch__init_A_const_34 = lang.RT_Keyword_String_String__Keyword(nil, Lit_50); A_arbace_pprint_dispatch__init_A_const_35 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_pprint_dispatch__init_A_const_36 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_45).Ref(), Lit_46, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_47).Ref())), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_48, lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(150).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_37 = lang.RT_ClassForNameNonLoading_String__Class(Lit_52); A_arbace_pprint_dispatch__init_A_const_38 = lang.RT_ClassForNameNonLoading_String__Class(Lit_53); A_arbace_pprint_dispatch__init_A_const_39 = lang.RT_ClassForNameNonLoading_String__Class(Lit_54); A_arbace_pprint_dispatch__init_A_const_40 = lang.RT_ClassForNameNonLoading_String__Class(Lit_55); A_arbace_pprint_dispatch__init_A_const_41 = lang.RT_ClassForNameNonLoading_String__Class(Lit_56); A_arbace_pprint_dispatch__init_A_const_42 = lang.RT_ClassForNameNonLoading_String__Class(Lit_57); A_arbace_pprint_dispatch__init_A_const_43 = lang.RT_ClassForNameNonLoading_String__Class(Lit_58); A_arbace_pprint_dispatch__init_A_const_44 = lang.RT_Var_String_String__Var(Lit_0, Lit_59); A_arbace_pprint_dispatch__init_A_const_45 = lang.RT_Var_String_String__Var(Lit_2, Lit_60); var tmp43 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_29).Ref(); var tmp44 *jrt.Boolean; jrt.Boolean_Init(); tmp44 = jrt.Boolean_TRUE; var tmp45 any = tmp44.Ref(); A_arbace_pprint_dispatch__init_A_const_46 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp43, tmp45, lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(170).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_47 = lang.RT_Var_String_String__Var(Lit_2, Lit_61); var tmp46 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp47 *jrt.Boolean; jrt.Boolean_Init(); tmp47 = jrt.Boolean_TRUE; var tmp48 any = tmp47.Ref(); A_arbace_pprint_dispatch__init_A_const_48 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp46, tmp48, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_62).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_63, lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(178).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_49 = lang.RT_Var_String_String__Var(Lit_2, Lit_64); var tmp49 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp50 *jrt.Boolean; jrt.Boolean_Init(); tmp50 = jrt.Boolean_TRUE; var tmp51 any = tmp50.Ref(); A_arbace_pprint_dispatch__init_A_const_50 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp49, tmp51, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_65).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_66, lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(185).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_51 = lang.RT_Var_String_String__Var(Lit_2, Lit_67); var tmp52 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp53 *jrt.Boolean; jrt.Boolean_Init(); tmp53 = jrt.Boolean_TRUE; var tmp54 any = tmp53.Ref(); A_arbace_pprint_dispatch__init_A_const_52 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp52, tmp54, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_27).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_68, lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(219).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_53 = lang.RT_Var_String_String__Var(Lit_2, Lit_69); var tmp55 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp56 *jrt.Boolean; jrt.Boolean_Init(); tmp56 = jrt.Boolean_TRUE; var tmp57 any = tmp56.Ref(); A_arbace_pprint_dispatch__init_A_const_54 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp55, tmp57, lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(250).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_55 = lang.RT_Var_String_String__Var(Lit_2, Lit_70); var tmp58 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp59 *jrt.Boolean; jrt.Boolean_Init(); tmp59 = jrt.Boolean_TRUE; var tmp60 any = tmp59.Ref(); A_arbace_pprint_dispatch__init_A_const_56 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp58, tmp60, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_27).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_71).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(257).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_57 = lang.RT_Var_String_String__Var(Lit_2, Lit_72); var tmp61 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp62 *jrt.Boolean; jrt.Boolean_Init(); tmp62 = jrt.Boolean_TRUE; var tmp63 any = tmp62.Ref(); A_arbace_pprint_dispatch__init_A_const_58 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp61, tmp63, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_27).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_71).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(266).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_59 = lang.RT_Var_String_String__Var(Lit_2, Lit_73); var tmp64 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp65 *jrt.Boolean; jrt.Boolean_Init(); tmp65 = jrt.Boolean_TRUE; var tmp66 any = tmp65.Ref(); A_arbace_pprint_dispatch__init_A_const_60 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp64, tmp66, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_27).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(272).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_61 = lang.RT_Var_String_String__Var(Lit_2, Lit_74); var tmp67 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp68 *jrt.Boolean; jrt.Boolean_Init(); tmp68 = jrt.Boolean_TRUE; var tmp69 any = tmp68.Ref(); A_arbace_pprint_dispatch__init_A_const_62 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp67, tmp69, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_75).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(297).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_63 = lang.RT_Var_String_String__Var(Lit_2, Lit_76); var tmp70 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp71 *jrt.Boolean; jrt.Boolean_Init(); tmp71 = jrt.Boolean_TRUE; var tmp72 any = tmp71.Ref(); A_arbace_pprint_dispatch__init_A_const_64 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp70, tmp72, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_27).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(312).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_65 = lang.RT_Var_String_String__Var(Lit_2, Lit_77); var tmp73 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp74 *jrt.Boolean; jrt.Boolean_Init(); tmp74 = jrt.Boolean_TRUE; var tmp75 any = tmp74.Ref(); A_arbace_pprint_dispatch__init_A_const_66 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp73, tmp75, lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(326).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_67 = lang.RT_Var_String_String__Var(Lit_2, Lit_78); var tmp76 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp77 *jrt.Boolean; jrt.Boolean_Init(); tmp77 = jrt.Boolean_TRUE; var tmp78 any = tmp77.Ref(); A_arbace_pprint_dispatch__init_A_const_68 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp76, tmp78, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_27).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(328).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_69 = lang.RT_Var_String_String__Var(Lit_2, Lit_79); var tmp79 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp80 *jrt.Boolean; jrt.Boolean_Init(); tmp80 = jrt.Boolean_TRUE; var tmp81 any = tmp80.Ref(); A_arbace_pprint_dispatch__init_A_const_70 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp79, tmp81, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_27).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(348).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_71 = lang.RT_Var_String_String__Var(Lit_2, Lit_80); var tmp82 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp83 *jrt.Boolean; jrt.Boolean_Init(); tmp83 = jrt.Boolean_TRUE; var tmp84 any = tmp83.Ref(); var tmp85 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(); var tmp86 *jrt.Boolean; jrt.Boolean_Init(); tmp86 = jrt.Boolean_TRUE; var tmp87 any = tmp86.Ref(); A_arbace_pprint_dispatch__init_A_const_72 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp82, tmp84, tmp85, tmp87, lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(368).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_73 = lang.RT_Var_String_String__Var(Lit_2, Lit_82); var tmp88 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp89 *jrt.Boolean; jrt.Boolean_Init(); tmp89 = jrt.Boolean_TRUE; var tmp90 any = tmp89.Ref(); A_arbace_pprint_dispatch__init_A_const_74 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp88, tmp90, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_27).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(370).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); var tmp91 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp92 *jrt.Boolean; jrt.Boolean_Init(); tmp92 = jrt.Boolean_TRUE; var tmp93 any = tmp92.Ref(); A_arbace_pprint_dispatch__init_A_const_75 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp91, tmp93, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_27).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(392).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_76 = lang.RT_Var_String_String__Var(Lit_2, Lit_83); var tmp94 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp95 *jrt.Boolean; jrt.Boolean_Init(); tmp95 = jrt.Boolean_TRUE; var tmp96 any = tmp95.Ref(); A_arbace_pprint_dispatch__init_A_const_77 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp94, tmp96, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_37).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(405).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_78 = lang.RT_Var_String_String__Var(Lit_2, Lit_84); var tmp97 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp98 *jrt.Boolean; jrt.Boolean_Init(); tmp98 = jrt.Boolean_TRUE; var tmp99 any = tmp98.Ref(); A_arbace_pprint_dispatch__init_A_const_79 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp97, tmp99, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_37).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(412).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_80 = lang.RT_Var_String_String__Var(Lit_2, Lit_85); var tmp100 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp101 *jrt.Boolean; jrt.Boolean_Init(); tmp101 = jrt.Boolean_TRUE; var tmp102 any = tmp101.Ref(); var tmp103 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(); var tmp104 *jrt.Boolean; jrt.Boolean_Init(); tmp104 = jrt.Boolean_TRUE; var tmp105 any = tmp104.Ref(); A_arbace_pprint_dispatch__init_A_const_81 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp100, tmp102, tmp103, tmp105, lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(421).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_82 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_86).Ref(); A_arbace_pprint_dispatch__init_A_const_83 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_87).Ref(); A_arbace_pprint_dispatch__init_A_const_84 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref(); A_arbace_pprint_dispatch__init_A_const_85 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_89).Ref(); A_arbace_pprint_dispatch__init_A_const_86 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_90).Ref(); A_arbace_pprint_dispatch__init_A_const_87 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_91).Ref(); A_arbace_pprint_dispatch__init_A_const_88 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_92).Ref(); A_arbace_pprint_dispatch__init_A_const_89 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_93).Ref(); A_arbace_pprint_dispatch__init_A_const_90 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_94).Ref(); A_arbace_pprint_dispatch__init_A_const_91 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref(); A_arbace_pprint_dispatch__init_A_const_92 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_96).Ref(); A_arbace_pprint_dispatch__init_A_const_93 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_97).Ref(); A_arbace_pprint_dispatch__init_A_const_94 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_98).Ref(); A_arbace_pprint_dispatch__init_A_const_95 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_99).Ref(); A_arbace_pprint_dispatch__init_A_const_96 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_100).Ref(); A_arbace_pprint_dispatch__init_A_const_97 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_101).Ref(); A_arbace_pprint_dispatch__init_A_const_98 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_102).Ref(); A_arbace_pprint_dispatch__init_A_const_99 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_103).Ref(); A_arbace_pprint_dispatch__init_A_const_100 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_104).Ref(); A_arbace_pprint_dispatch__init_A_const_101 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_105).Ref(); A_arbace_pprint_dispatch__init_A_const_102 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref(); A_arbace_pprint_dispatch__init_A_const_103 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_107).Ref(); A_arbace_pprint_dispatch__init_A_const_104 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_108).Ref(); A_arbace_pprint_dispatch__init_A_const_105 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_109).Ref(); A_arbace_pprint_dispatch__init_A_const_106 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_110).Ref(); A_arbace_pprint_dispatch__init_A_const_107 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_111).Ref(); A_arbace_pprint_dispatch__init_A_const_108 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_112).Ref(); A_arbace_pprint_dispatch__init_A_const_109 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_113).Ref(); A_arbace_pprint_dispatch__init_A_const_110 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_114).Ref(); A_arbace_pprint_dispatch__init_A_const_111 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_115).Ref(); A_arbace_pprint_dispatch__init_A_const_112 = lang.RT_Var_String_String__Var(Lit_2, Lit_116); var tmp106 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp107 *jrt.Boolean; jrt.Boolean_Init(); tmp107 = jrt.Boolean_TRUE; var tmp108 any = tmp107.Ref(); A_arbace_pprint_dispatch__init_A_const_113 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp106, tmp108, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_27).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(438).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_114 = lang.RT_Var_String_String__Var(Lit_2, Lit_117); var tmp109 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp110 *jrt.Boolean; jrt.Boolean_Init(); tmp110 = jrt.Boolean_TRUE; var tmp111 any = tmp110.Ref(); A_arbace_pprint_dispatch__init_A_const_115 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp109, tmp111, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_118).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(444).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_116 = lang.RT_Var_String_String__Var(Lit_2, Lit_119); A_arbace_pprint_dispatch__init_A_const_117 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_45).Ref(), Lit_46, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_47).Ref())), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_120, lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(451).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_118 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_45).Ref(), Lit_46, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_47).Ref())), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_120, lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), jrt.Integer_ValueOf_I__Integer(451).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_pprint_dispatch__init_A_const_119 = lang.RT_ClassForNameNonLoading_String__Class(Lit_121); A_arbace_pprint_dispatch__init_A_const_120 = lang.RT_Var_String_String__Var(Lit_2, Lit_122) }

func A_arbace_pprint_dispatch__init_A_New() *A_arbace_pprint_dispatch__init_A { A_arbace_pprint_dispatch__init_A_Init(); t := &A_arbace_pprint_dispatch__init_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_dispatch__init_A) Ctor() {}

func (t *A_arbace_pprint_dispatch__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_dispatch__init_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_dispatch__init_A_class }

func (t *A_arbace_pprint_dispatch__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_dispatch__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_pprint_dispatch__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_dispatch__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_dispatch__init_A); return ok }

func A_arbace_pprint_dispatch__init_A_Cast(x any) *A_arbace_pprint_dispatch__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_dispatch__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_dispatch__init_A_class)) }; return v }
