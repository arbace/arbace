//line j2g_strings.ae:1
package aot_arbace_go_check_infer

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn20,arbace.go.check.codekn8,declaredkn4,linekn6,columnkn4,filekn7,privatekn8,arglistsyn7,tparamsyn5,targsyn5,ifacekn3,docyn1,uyn1,xyn2,tyyn1,hyn1,yyn1,myn4,modeyn1,pyn2,xiyn2,yiyn5,exactyn3,tpsyn2,tpyn8,inferredyn6,paramsyn4,argsyn7,reverseyn3,errv11,arbace.core5,in-nsR0,v20,arbace.go.check.code5,unifym8,R1,TR2,i7,R3,i1,R4,s24,arbace/go/check/infer.aev20,arbace.go.check.code14,nify-structurem8,R1,TR2,i7,R3,i1,R4,s24,arbace/go/check/infer.aev20,arbace.go.check.code11,depth-limitl50,m8,R5,TR2,i9,R3,i1,R4,s24,arbace/go/check/infer.aev20,arbace.go.check.code11,new-unifierm12,R5,TR6,L1,V3,R7,R8,R9,R10,s135,go/types' newUnifier: tparams' handles, the known targs (nil: unknown); iface: whether\n  interfaces' methods inform inference (go1.21).R2,i11,R3,i1,R4,s24,arbace/go/check/infer.aev20,arbace.go.check.code4,u-atm10,R5,TR6,L1,V2,R11,R12,R2,i19,R3,i1,R4,s24,arbace/go/check/infer.aev20,arbace.go.check.code6,u-set!m10,R5,TR6,L1,V3,R11,R12,R13,R2,i20,R3,i1,R4,s24,arbace/go/check/infer.aev20,arbace.go.check.code7,u-boundm12,R5,TR6,L1,V2,R11,R12,R10,s65,x when it is one of the type parameters being inferred, else nil.R2,i22,R3,i1,R4,s24,arbace/go/check/infer.aev20,arbace.go.check.code11,set-handle!m10,R5,TR6,L1,V3,R11,R12,R14,R2,i27,R3,i1,R4,s24,arbace/go/check/infer.aev20,arbace.go.check.code7,u-join!m10,R5,TR6,L1,V3,R11,R12,R15,R2,i31,R3,i1,R4,s24,arbace/go/check/infer.aev20,arbace.go.check.code10,u-unknownsm10,R5,TR6,L1,V1,R11,R2,i39,R3,i1,R4,s24,arbace/go/check/infer.aev20,arbace.go.check.code10,u-inferredm10,R5,TR6,L1,V2,R11,R7,R2,i41,R3,i1,R4,s24,arbace/go/check/infer.aev20,arbace.go.check.code8,as-ifacem12,R5,TR6,L1,V1,R12,R10,s79,go/types' asInterface: x's underlying interface when x is not a type parameter.R2,i43,R3,i1,R4,s24,arbace/go/check/infer.aev20,arbace.go.check.code9,type-lit?m10,R5,TR6,L1,V1,R12,R2,i49,R3,i1,R4,s24,arbace/go/check/infer.aev20,arbace.go.check.code14,method-type-ofm12,R5,TR6,L1,V2,R15,R16,R10,s135,The signature of y's method m (an interface method's data) as LookupFieldOrMethod finds it,\n  or nil (none, a field, a generic method).R2,i51,R3,i1,R4,s24,arbace/go/check/infer.aev20,arbace.go.check.code4,nifym12,R5,TR6,L1,V5,R11,R12,R15,R17,R18,R10,s72,go/types' unifier.nify: whether x and y unify (mode: #{:assign :exact}).R2,i63,R3,i1,R4,s24,arbace/go/check/infer.aev20,arbace.go.check.code13,ifaces-unify?m12,R5,TR6,L1,V5,R11,R19,R20,R18,R21,R10,s175,Whether interfaces xi and yi unify: equal type sets, and the methods of the one with fewer\n  shared and unified exactly (go1.21's interface inference), or all of them (exact).R2,i108,R3,i1,R4,s24,arbace/go/check/infer.aem10,R5,TR6,L1,V5,R11,R12,R15,R17,R18,R2,i130,R3,i1,R4,s24,arbace/go/check/infer.aem10,R6,L1,V4,R11,R12,R15,R17,R10,s24,go/types' unifier.unify.R2,i181,R3,i1,R4,s24,arbace/go/check/infer.aev20,arbace.go.check.code14,parameterized?m10,R6,L1,V2,R22,R13,R10,s70,go/types' isParameterized: whether ty mentions one of tparams (a set).R2,i188,R3,i1,R4,s24,arbace/go/check/infer.aev20,arbace.go.check.code14,rename-tparamsm10,R6,L1,V2,R7,R13,R10,s147,go/types' renameTParams: [new type parameters, ty with them] (the bounds renamed too), so\n  that recursive instantiations do not confuse inference.R2,i214,R3,i1,R4,s24,arbace/go/check/infer.aev20,arbace.go.check.code9,core-termm12,R5,TR6,L1,V1,R23,R10,s69,go/types' coreTerm: [term single?] of type parameter tp's constraint.R2,i226,R3,i1,R4,s24,arbace/go/check/infer.aev20,arbace.go.check.code12,kill-cycles!m12,R5,TR6,L1,V2,R7,R24,R10,s107,go/types' killCycles: the inferred types (a volatile vector) whose substitution would not end\n  set to nil.R2,i236,R3,i1,R4,s24,arbace/go/check/infer.aev20,arbace.go.check.code12,tparam-namesm10,R5,TR6,L1,V1,R22,R2,i270,R3,i1,R4,s24,arbace/go/check/infer.aev20,arbace.go.check.code5,inferm10,R6,L1,V6,R7,R8,R25,R26,R27,R28,R10,s305,go/types' infer: the type arguments of tparams (targs: those known, nil the unknown), from\n  the function parameters' types params and the arguments' nodes args (each {:type :mode\n  :form}), or nil after reporting through err (a function of a form and a message); reverse: a\n  reverse inference's wording.R2,i278,R3,i1,R4,s24,arbace/go/check/infer.ae")

var Lit_1 *jrt.String = jrt.Intern("arbace.go.check.code$new_unifier")

var Lit_2 *jrt.String = jrt.Intern("arbace.go.check.code$u_at")

var Lit_3 *jrt.String = jrt.Intern("arbace.go.check.code$u_set_BANG_")

var Lit_4 *jrt.String = jrt.Intern("arbace.go.check.code$u_bound")

var Lit_5 *jrt.String = jrt.Intern("arbace.go.check.code$set_handle_BANG_")

var Lit_6 *jrt.String = jrt.Intern("arbace.go.check.code$u_join_BANG_")

var Lit_7 *jrt.String = jrt.Intern("arbace.go.check.code$u_unknowns")

var Lit_8 *jrt.String = jrt.Intern("arbace.go.check.code$u_inferred")

var Lit_9 *jrt.String = jrt.Intern("arbace.go.check.code$as_iface")

var Lit_10 *jrt.String = jrt.Intern("arbace.go.check.code$type_lit_QMARK_")

var Lit_11 *jrt.String = jrt.Intern("arbace.go.check.code$method_type_of")

var Lit_12 *jrt.String = jrt.Intern("arbace.go.check.code$nify")

var Lit_13 *jrt.String = jrt.Intern("arbace.go.check.code$ifaces_unify_QMARK_")

var Lit_14 *jrt.String = jrt.Intern("arbace.go.check.code$nify_structure")

var Lit_15 *jrt.String = jrt.Intern("arbace.go.check.code$unify")

var Lit_16 *jrt.String = jrt.Intern("arbace.go.check.code$parameterized_QMARK_")

var Lit_17 *jrt.String = jrt.Intern("arbace.go.check.code$rename_tparams")

var Lit_18 *jrt.String = jrt.Intern("arbace.go.check.code$core_term")

var Lit_19 *jrt.String = jrt.Intern("arbace.go.check.code$kill_cycles_BANG_")

var Lit_20 *jrt.String = jrt.Intern("arbace.go.check.code$tparam_names")

var Lit_21 *jrt.String = jrt.Intern("arbace.go.check.code$infer")
