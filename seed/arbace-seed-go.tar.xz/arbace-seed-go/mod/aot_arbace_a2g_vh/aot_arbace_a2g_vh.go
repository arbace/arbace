//line aot_arbace_a2g_vh.ae:1
package aot_arbace_a2g_vh

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_New() *A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_a2g_vh_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_vh_A_const_2); tmp3 = lang.IFn_Cast(A_arbace_a2g_vh_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_a2g_vh_A_const_3, A_arbace_a2g_vh_A_const_4, A_arbace_a2g_vh_A_const_5, A_arbace_a2g_vh_A_const_6, A_arbace_a2g_vh_A_const_7); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :1:1
func A_arbace_a2g_vh_eval331000008_fn__331000009_A_New() *A_arbace_a2g_vh_eval331000008_fn__331000009_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_eval331000008_fn__331000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_vh_eval331000008_fn__331000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_vh_eval331000008_fn__331000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_a2g_vh_A_const_8.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_vh_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_vh_A_const_12), A_arbace_a2g_vh_A_const_10.GetRawRoot__O(), A_arbace_a2g_vh_A_const_11) }
























func A_arbace_a2g_vh_class_arg_A_New() *A_arbace_a2g_vh_class_arg_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_class_arg_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_a2g_vh_class_arg_A) Ctor() {}
//line :26:1
func (t *A_arbace_a2g_vh_class_arg_A) Invoke_O_O_O__O(self, node__0, env__1 any) any { var node__3 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_13.GetRawRoot__O()).Invoke_O__O(node__0); var G__331000012__4_ any = A_arbace_a2g_vh_A_const_14.Invoke_O__O(node__3); switch




	lang.Util_Hash_O__I(G__331000012__4_) >> 6 & 3 { case 0: if any(G__331000012__4_) == any(A_arbace_a2g_vh_A_const_15) {




		return lang.IFn_Cast(A_arbace_a2g_vh_A_const_16.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_vh_A_const_26.Invoke_O__O(node__3), env__1) }
//line :31:1
	case 1: if any(G__331000012__4_) == any(A_arbace_a2g_vh_A_const_17) {
		return A_arbace_a2g_vh_A_const_18.Invoke_O__O(node__3) }
//line :31:1
	case 2: if any(G__331000012__4_) == any(A_arbace_a2g_vh_A_const_19) { var f__5 any = A_arbace_a2g_vh_A_const_20.Invoke_O__O(node__3)


		if lang.Util_Equiv_O_O__Z(Lit_2, A_arbace_a2g_vh_A_const_21.Invoke_O__O(f__5)) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_vh_A_const_22.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____6 any = A_arbace_a2g_vh_A_const_27.Invoke_O__O(f__5); if jrt.A2g_Truth(or__1927000174__auto____6) { tmp2 = or__1927000174__auto____6 } else { tmp2 = A_arbace_a2g_vh_A_const_28.Invoke_O__O(f__5) }; return tmp1.Invoke_O__O(tmp2) } else { return nil } }
//line :31:1
	case 3: if any(G__331000012__4_) == any(A_arbace_a2g_vh_A_const_23) { var tmp3 *lang.Keyword = A_arbace_a2g_vh_A_const_24; var temp__1927000414__auto____5 any = lang.RT_Get_O_O__O(env__1, tmp3.Invoke_O__O(A_arbace_a2g_vh_A_const_25.Invoke_O__O(node__3)))



		if jrt.A2g_Truth(temp__1927000414__auto____5) { var init__6 any = temp__1927000414__auto____5; return lang.IFn_Cast(A_arbace_a2g_vh_A_const_16.GetRawRoot__O()).Invoke_O_O__O(init__6, env__1) } else { return nil } }
//line :31:1
	default:}; return nil }







func A_arbace_a2g_vh_string_arg_A_New() *A_arbace_a2g_vh_string_arg_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_string_arg_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_a2g_vh_string_arg_A) Ctor() {}
//line :39:1
func (t *A_arbace_a2g_vh_string_arg_A) Invoke_O_O__O(self, node__0 any) any { var node__2 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_13.GetRawRoot__O()).Invoke_O__O(node__0); var tmp1 any; var tmp2 any = A_arbace_a2g_vh_A_const_29; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z(tmp2, A_arbace_a2g_vh_A_const_14.Invoke_O__O(node__2)); if and__1927000168__auto____3 {

	tmp1 = lang.IFn_Cast(A_arbace_a2g_vh_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_vh_A_const_31.Invoke_O__O(node__2)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }; if jrt.A2g_Truth(tmp1) { return A_arbace_a2g_vh_A_const_31.Invoke_O__O(node__2) } else { return nil } }

func A_arbace_a2g_vh_byte_order_arg_A_New() *A_arbace_a2g_vh_byte_order_arg_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_byte_order_arg_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_a2g_vh_byte_order_arg_A) Ctor() {}
//line :43:1
func (t *A_arbace_a2g_vh_byte_order_arg_A) Invoke_O_O_O__O(self, node__0, env__1 any) any { var node__3 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_13.GetRawRoot__O()).Invoke_O__O(node__0); var G__331000015__4_ any = A_arbace_a2g_vh_A_const_14.Invoke_O__O(node__3); switch




	lang.Util_Hash_O__I(G__331000015__4_) >> 0 & 1 { case 0: if any(G__331000015__4_) == any(A_arbace_a2g_vh_A_const_19) { var f__5 any = A_arbace_a2g_vh_A_const_20.Invoke_O__O(node__3); var tmp1 any; var or__1927000174__auto____6 any = A_arbace_a2g_vh_A_const_27.Invoke_O__O(f__5)

		if jrt.A2g_Truth(or__1927000174__auto____6) { tmp1 = or__1927000174__auto____6 } else { tmp1 = A_arbace_a2g_vh_A_const_28.Invoke_O__O(f__5) }; if lang.Util_Equiv_O_O__Z(Lit_1, tmp1) {
			var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_vh_A_const_32); return tmp2.Invoke_O__O(A_arbace_a2g_vh_A_const_21.Invoke_O__O(f__5)) } else {
//line :50:1
				return nil } }
//line :48:1
	case 1: if any(G__331000015__4_) == any(A_arbace_a2g_vh_A_const_23) { var tmp3 *lang.Keyword = A_arbace_a2g_vh_A_const_24; var temp__1927000414__auto____5 any = lang.RT_Get_O_O__O(env__1, tmp3.Invoke_O__O(A_arbace_a2g_vh_A_const_25.Invoke_O__O(node__3)))



		if jrt.A2g_Truth(temp__1927000414__auto____5) { var init__6 any = temp__1927000414__auto____5; return lang.IFn_Cast(A_arbace_a2g_vh_A_const_33.GetRawRoot__O()).Invoke_O_O__O(init__6, env__1) } else { return nil } }
//line :48:1
	default:}; return nil }






func A_arbace_a2g_vh_find_field_A_New() *A_arbace_a2g_vh_find_field_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_find_field_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_a2g_vh_find_field_A) Ctor() {}
//line :55:1
func (t *A_arbace_a2g_vh_find_field_A) Invoke_O_O_O__O(self, n__0, fname__1 any) any { { var c__3 any = n__0; L1: for { var temp__1927000414__auto____4 any
											var and__1927000168__auto____4 any = c__3


	if jrt.A2g_Truth(and__1927000168__auto____4) { temp__1927000414__auto____4 = lang.IFn_Cast(A_arbace_a2g_vh_A_const_34.GetRawRoot__O()).Invoke_O__O(c__3) } else { temp__1927000414__auto____4 = and__1927000168__auto____4 }; if jrt.A2g_Truth(temp__1927000414__auto____4) { var d__5 any = temp__1927000414__auto____4; var or__1927000174__auto____6 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_vh_A_const_35.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_vh_find_field_fn__331000018_A_New_O(fname__1); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_a2g_vh_find_field_fn__331000018_A_fn_class
		if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_7, false); A_arbace_a2g_vh_find_field_fn__331000018_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; or__1927000174__auto____6 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), A_arbace_a2g_vh_A_const_36.Invoke_O__O(d__5)); if jrt.A2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else {
			c__3 = A_arbace_a2g_vh_A_const_37.Invoke_O__O(d__5); continue L1 } } else {
//line :59:1
				return nil } } }; /*line :55:1*/panic("a2g: unreachable") }




func A_arbace_a2g_vh_find_field_fn__331000018_A_New_O(p0 any) *A_arbace_a2g_vh_find_field_fn__331000018_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_find_field_fn__331000018_A{}; t.Ctor_O(p0); return t }
//line :60:1
func (t *A_arbace_a2g_vh_find_field_fn__331000018_A) Ctor_O(c__fname any) { t.F_fname = c__fname }
//line :60:1
func (t *A_arbace_a2g_vh_find_field_fn__331000018_A) Invoke_O_O__O(self, p1__331000017_SHARP___1 any) any { var tmp1 any = t.F_fname; if lang.Util_Equiv_O_O__Z(tmp1, A_arbace_a2g_vh_A_const_21.Invoke_O__O(p1__331000017_SHARP___1)) { return p1__331000017_SHARP___1 } else { return nil } }


func A_arbace_a2g_vh_static_flag_QMARK__A_New() *A_arbace_a2g_vh_static_flag_QMARK__A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_static_flag_QMARK__A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_a2g_vh_static_flag_QMARK__A) Ctor() {}
//line :63:1
func (t *A_arbace_a2g_vh_static_flag_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_vh_A_const_38.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____2 any = A_arbace_a2g_vh_A_const_39.Invoke_O__O(f__0); if jrt.A2g_Truth(or__1927000174__auto____2) { tmp2 = or__1927000174__auto____2 } else { tmp2 = A_arbace_a2g_vh_A_const_40 }; return tmp1.Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_J__Z(lang.Numbers_And_O_J__J(tmp2, 8))).Ref()) }

func A_arbace_a2g_vh_handle_spec_A_New() *A_arbace_a2g_vh_handle_spec_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_handle_spec_A{}; t.Ctor(); return t }
//line :65:1
func (t *A_arbace_a2g_vh_handle_spec_A) Ctor() {}
//line :65:1
func (t *A_arbace_a2g_vh_handle_spec_A) Invoke_O_O_O_O__O(self, n__0, init__1, env__2 any) any { var init__4 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_13.GetRawRoot__O()).Invoke_O__O(init__1); var field_spec__5 any; var tmp1 any = A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_New(); var tmp2 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_fn_class; if





	fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_8, false); A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_fn_class = fncls__4d; tmp2 = fncls__4d } else { tmp2 = fncls__4 }; field_spec__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 any = A_arbace_a2g_vh_A_const_47; if





	lang.Util_Equiv_O_O__Z(tmp3, A_arbace_a2g_vh_A_const_14.Invoke_O__O(init__4)) { var map__331000024__6 any = init__4; var map__331000024__7 any
		if lang.ISeq_InstanceOf(map__331000024__6) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_vh_A_const_48.GetRawRoot__O()).Invoke_O__O(map__331000024__6)) { map__331000024__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_a2g_vh_A_const_49.GetRawRoot__O()).Invoke_O__O(map__331000024__6), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_vh_A_const_50.GetRawRoot__O()).Invoke_O__O(map__331000024__6)) { map__331000024__7 = lang.IFn_Cast(A_arbace_a2g_vh_A_const_51.GetRawRoot__O()).Invoke_O__O(map__331000024__6) } else { lang.PersistentArrayMap_Init(); map__331000024__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__331000024__7 = map__331000024__6 }
//line :77:1
		var owner__8 any = lang.RT_Get_O_O__O(map__331000024__7, A_arbace_a2g_vh_A_const_28); var name__9 any = lang.RT_Get_O_O__O(map__331000024__7, A_arbace_a2g_vh_A_const_21); var args__10 any = lang.RT_Get_O_O__O(map__331000024__7, A_arbace_a2g_vh_A_const_52); var kind__11 any = lang.RT_Get_O_O__O(map__331000024__7, A_arbace_a2g_vh_A_const_45); var tmp4 bool; var and__1927000168__auto____12 bool = lang.Util_Equiv_O_O__Z(owner__8, Lit_9)


		if and__1927000168__auto____12 { var and__1927000168__auto____13 bool = lang.Util_Equiv_O_O__Z(name__9, Lit_10); if and__1927000168__auto____13 { tmp4 = lang.Util_Equiv_J_J__Z(3, int64(lang.RT_Count_O__I(args__10))) } else { tmp4 = and__1927000168__auto____13 } } else { tmp4 = and__1927000168__auto____12 }
//line :79:1
		if tmp4 {

			return lang.IFn_Cast(field_spec__5).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_vh_A_const_16.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O(args__10, lang.RT_IntCast_J__I(0)), env__2), lang.IFn_Cast(A_arbace_a2g_vh_A_const_65.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(args__10, lang.RT_IntCast_J__I(1))), lang.IFn_Cast(A_arbace_a2g_vh_A_const_16.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O(args__10, lang.RT_IntCast_J__I(2)), env__2)) } else {
//line :79:1
				var tmp5 bool; var and__1927000168__auto____12_2 bool = lang.Util_Equiv_O_O__Z(owner__8, Lit_11)



				if and__1927000168__auto____12_2 { var and__1927000168__auto____13_2 bool = lang.Util_Equiv_O_O__Z(name__9, Lit_10); if and__1927000168__auto____13_2 { tmp5 = lang.Util_Equiv_O_O__Z(kind__11, A_arbace_a2g_vh_A_const_53) } else { tmp5 = and__1927000168__auto____13_2 } } else { tmp5 = and__1927000168__auto____12_2 }
//line :79:1
				if tmp5 { var G__331000026__12_ int32 = lang.RT_Count_O__I(args__10)




					switch G__331000026__12_ { case 3:

						return lang.IFn_Cast(field_spec__5).Invoke_O_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_12, nil, Lit_13), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil)).Ref(), lang.IFn_Cast(A_arbace_a2g_vh_A_const_65.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(args__10, lang.RT_IntCast_J__I(1))), lang.IFn_Cast(A_arbace_a2g_vh_A_const_16.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O(args__10, lang.RT_IntCast_J__I(2)), env__2))
//line :84:1
					case 4:


						return lang.IFn_Cast(field_spec__5).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_vh_A_const_16.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O(args__10, lang.RT_IntCast_J__I(1)), env__2), lang.IFn_Cast(A_arbace_a2g_vh_A_const_65.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(args__10, lang.RT_IntCast_J__I(2))), lang.IFn_Cast(A_arbace_a2g_vh_A_const_16.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O(args__10, lang.RT_IntCast_J__I(3)), env__2))
//line :84:1
					default:}; return nil } else {
//line :79:1
						var tmp6 bool; var and__1927000168__auto____12_3 bool = lang.Util_Equiv_O_O__Z(owner__8, Lit_14)










						if and__1927000168__auto____12_3 { var and__1927000168__auto____13_3 bool = lang.Util_Equiv_O_O__Z(name__9, Lit_15); if and__1927000168__auto____13_3 { var and__1927000168__auto____14 bool = lang.Util_Equiv_O_O__Z(kind__11, A_arbace_a2g_vh_A_const_53); if and__1927000168__auto____14 {
							tmp6 = lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(args__10))) } else {
//line :90:1
								tmp6 = and__1927000168__auto____14 } } else { tmp6 = and__1927000168__auto____13_3 } } else { tmp6 = and__1927000168__auto____12_3 }
//line :79:1
						if tmp6 { var d__12 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_16.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_vh_A_const_51.GetRawRoot__O()).Invoke_O__O(args__10), env__2); var tmp7 any
							var and__1927000168__auto____13_4 any = d__12












							if jrt.A2g_Truth(and__1927000168__auto____13_4) { tmp7 = lang.IFn_Cast(A_arbace_a2g_vh_A_const_54.GetRawRoot__O()).Invoke_O__O(d__12) } else { tmp7 = and__1927000168__auto____13_4 }; if jrt.A2g_Truth(tmp7) { return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_a2g_vh_A_const_45, A_arbace_a2g_vh_A_const_55, A_arbace_a2g_vh_A_const_44, d__12)) } else { return nil } } else {
//line :79:1
								var tmp8 bool; var and__1927000168__auto____12_4 bool = lang.Util_Equiv_O_O__Z(owner__8, Lit_14)



















								if and__1927000168__auto____12_4 { var and__1927000168__auto____13_5 bool = lang.Util_Equiv_O_O__Z(name__9, Lit_16); if and__1927000168__auto____13_5 { var and__1927000168__auto____14_2 bool = lang.Util_Equiv_O_O__Z(kind__11, A_arbace_a2g_vh_A_const_53); if and__1927000168__auto____14_2 {
									tmp8 = lang.Util_Equiv_J_J__Z(2, int64(lang.RT_Count_O__I(args__10))) } else {
//line :99:1
										tmp8 = and__1927000168__auto____14_2 } } else { tmp8 = and__1927000168__auto____13_5 } } else { tmp8 = and__1927000168__auto____12_4 }
//line :79:1
								if tmp8 { var d__12_2 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_16.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_vh_A_const_51.GetRawRoot__O()).Invoke_O__O(args__10), env__2); var o__13 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_vh_A_const_66.GetRawRoot__O()).Invoke_O__O(args__10), env__2); var tmp9 any; var and__1927000168__auto____14_3 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_56).Invoke_O__O(d__12_2)























									if jrt.A2g_Truth(and__1927000168__auto____14_3) { tmp9 = o__13 } else { tmp9 = and__1927000168__auto____14_3 }; if jrt.A2g_Truth(tmp9) { return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_a2g_vh_A_const_45, A_arbace_a2g_vh_A_const_57, A_arbace_a2g_vh_A_const_44, d__12_2, A_arbace_a2g_vh_A_const_58, o__13)) } else { return nil } } else {
//line :79:1
										var tmp10 any; var and__1927000168__auto____12_5 bool = lang.Util_Equiv_O_O__Z(owner__8, A_arbace_a2g_vh_A_const_59.GetRawRoot__O())

























										if and__1927000168__auto____12_5 { var and__1927000168__auto____13_6 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_60).Invoke_O__O(name__9); if jrt.A2g_Truth(and__1927000168__auto____13_6) { var and__1927000168__auto____14_4 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_61.GetRawRoot__O()).Invoke_O__O(args__10); if jrt.A2g_Truth(and__1927000168__auto____14_4) {
											tmp10 = lang.IFn_Cast(A_arbace_a2g_vh_A_const_62.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_vh_A_const_67.Invoke_O__O(init__4)) } else {
//line :105:1
												tmp10 = and__1927000168__auto____14_4 } } else { tmp10 = and__1927000168__auto____13_6 } } else { tmp10 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____12_5).Ref() }
//line :79:1
										if jrt.A2g_Truth(tmp10) {



























											return lang.IFn_Cast(A_arbace_a2g_vh_A_const_63.GetRawRoot__O()).Invoke_O_O_O__O(n__0, A_arbace_a2g_vh_A_const_67.Invoke_O__O(init__4), env__2) } else {
//line :79:1
												if A_arbace_a2g_vh_A_const_64 != nil { return nil } else { return nil } } } } } } } else {
//line :77:1
													return nil } }
//line :71:1
func A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_New() *A_arbace_a2g_vh_handle_spec_field_spec__331000022_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_handle_spec_field_spec__331000022_A{}; t.Ctor(); return t }
//line :71:1
func (t *A_arbace_a2g_vh_handle_spec_field_spec__331000022_A) Ctor() {}
//line :71:1
func (t *A_arbace_a2g_vh_handle_spec_field_spec__331000022_A) Invoke_O_O_O_O__O(self, c__1, fname__2, tdesc__3 any) any {
	var tmp1 any; var and__1927000168__auto____4 any = c__1; if jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = fname__2; if jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = tdesc__3; if jrt.A2g_Truth(and__1927000168__auto____6) { tmp1 = lang.IFn_Cast(A_arbace_a2g_vh_A_const_41.GetRawRoot__O()).Invoke_O__O(c__1) } else { tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.A2g_Truth(tmp1) { var cn__4 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_42.GetRawRoot__O()).Invoke_O__O(c__1); var f__5 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_43.GetRawRoot__O()).Invoke_O_O__O(cn__4, fname__2); var tmp2 any
		var and__1927000168__auto____6_2 any = f__5

		if jrt.A2g_Truth(and__1927000168__auto____6_2) { var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z(tdesc__3, A_arbace_a2g_vh_A_const_44.Invoke_O__O(f__5)); if and__1927000168__auto____7 { tmp2 = lang.IFn_Cast(A_arbace_a2g_vh_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_vh_A_const_46.GetRawRoot__O()).Invoke_O__O(f__5)) } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____7).Ref() } } else { tmp2 = and__1927000168__auto____6_2 }; if jrt.A2g_Truth(tmp2) { var tmp3 any = A_arbace_a2g_vh_A_const_45; var tmp4 any = A_arbace_a2g_vh_A_const_20; var tmp5 any = A_arbace_a2g_vh_A_const_18; var tmp6 any; var or__1927000174__auto____6 any = A_arbace_a2g_vh_A_const_28.Invoke_O__O(f__5)
			if jrt.A2g_Truth(or__1927000174__auto____6) { tmp6 = or__1927000174__auto____6 } else { tmp6 = cn__4 }
//line :75:1
			return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, tmp6, A_arbace_a2g_vh_A_const_21, fname__2, A_arbace_a2g_vh_A_const_44, tdesc__3, A_arbace_a2g_vh_A_const_20, f__5)) } else { return nil } } else {
//line :72:1
				return nil
			}
}




































func A_arbace_a2g_vh_class_handles_A_New() *A_arbace_a2g_vh_class_handles_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_class_handles_A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_a2g_vh_class_handles_A) Ctor() {}
//line :111:1
func (t *A_arbace_a2g_vh_class_handles_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_a2g_vh_A_const_70; var st__2 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_9.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_vh_A_const_34.GetRawRoot__O()).Invoke_O__O(n__0))); var code__3 any = A_arbace_a2g_vh_A_const_68.Invoke_O__O(st__2); var env__4 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_vh_A_const_69.GetRawRoot__O()); var tmp3 *lang.PersistentArrayMap;




	lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; env__4 = tmp2.Invoke_O__O(tmp3.Ref()); var out__5 any; var tmp4 lang.IFn = /*line :111:1*/lang.IFn_Cast(A_arbace_a2g_vh_A_const_69.GetRawRoot__O()); var tmp5 *lang.PersistentArrayMap;





	lang.PersistentArrayMap_Init(); tmp5 = lang.PersistentArrayMap_EMPTY; out__5 = tmp4.Invoke_O__O(tmp5.Ref()); var seq_331000028__6 any = /*line :111:1*/lang.IFn_Cast(A_arbace_a2g_vh_A_const_50.GetRawRoot__O()).Invoke_O__O(code__3); var chunk_331000029__7 any; var count_331000030__8 int64 = 0; var i_331000031__9 int64 = 0; L1: for {






		if lang.Numbers_Lt_J_J__Z(i_331000031__9, count_331000030__8) { var nd__10 any = lang.Indexed_Cast(chunk_331000029__7).Nth_I__O(lang.RT_IntCast_J__I(i_331000031__9)); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_a2g_vh_A_const_73.GetRawRoot__O()); var tmp7 any = A_arbace_a2g_vh_class_handles_fn__331000032_A_New_O(env__4); var tmp8 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_a2g_vh_class_handles_fn__331000032_A_fn_class
			if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, false); A_arbace_a2g_vh_class_handles_fn__331000032_A_fn_class = fncls__6d; tmp8 = fncls__6d } else { tmp8 = fncls__6 }; tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), nd__10)
//line :118:1
			seq_331000028__6, chunk_331000029__7, count_331000030__8, i_331000031__9 = seq_331000028__6, chunk_331000029__7, count_331000030__8, lang.Numbers_Unchecked_inc_J__J(i_331000031__9); continue L1 } else { var temp__1927000414__auto____10 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_50.GetRawRoot__O()).Invoke_O__O(seq_331000028__6); if jrt.A2g_Truth(temp__1927000414__auto____10) { var seq_331000028__11 any = temp__1927000414__auto____10; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_vh_A_const_71.GetRawRoot__O()).Invoke_O__O(seq_331000028__11)) { var c__1927000678__auto____12 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_72.GetRawRoot__O()).Invoke_O__O(seq_331000028__11); seq_331000028__6, chunk_331000029__7, count_331000030__8, i_331000031__9 = lang.IFn_Cast(A_arbace_a2g_vh_A_const_79.GetRawRoot__O()).Invoke_O__O(seq_331000028__11), c__1927000678__auto____12, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var nd__12 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_331000028__11); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_a2g_vh_A_const_73.GetRawRoot__O()); var tmp10 any = A_arbace_a2g_vh_class_handles_fn__331000044_A_New_O(env__4); var tmp11 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_a2g_vh_class_handles_fn__331000044_A_fn_class
				if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_4, false); A_arbace_a2g_vh_class_handles_fn__331000044_A_fn_class = fncls__7d; tmp11 = fncls__7d } else { tmp11 = fncls__7 }; tmp9.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), nd__12)
//line :118:1
				seq_331000028__6, chunk_331000029__7, count_331000030__8, i_331000031__9 = lang.IFn_Cast(A_arbace_a2g_vh_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_331000028__11), nil, 0, 0; continue L1 } } }
//line :111:1
		break L1 }; var seq_331000056__6 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_50.GetRawRoot__O()).Invoke_O__O(code__3); var chunk_331000057__7 any; var count_331000058__8 int64 = 0; var i_331000059__9 int64 = 0; L2: for {












			if lang.Numbers_Lt_J_J__Z(i_331000059__9, count_331000058__8) { var nd__10_2 any = lang.Indexed_Cast(chunk_331000057__7).Nth_I__O(lang.RT_IntCast_J__I(i_331000059__9)); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_a2g_vh_A_const_73.GetRawRoot__O()); var tmp13 any = A_arbace_a2g_vh_class_handles_fn__331000060_A_New_O_O_O(env__4, out__5, n__0); var tmp14 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_a2g_vh_class_handles_fn__331000060_A_fn_class
				if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_5, false); A_arbace_a2g_vh_class_handles_fn__331000060_A_fn_class = fncls__8d; tmp14 = fncls__8d } else { tmp14 = fncls__8 }; tmp12.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil), nd__10_2)
//line :124:1
				seq_331000056__6, chunk_331000057__7, count_331000058__8, i_331000059__9 = seq_331000056__6, chunk_331000057__7, count_331000058__8, lang.Numbers_Unchecked_inc_J__J(i_331000059__9); continue L2 } else { var temp__1927000414__auto____10_2 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_50.GetRawRoot__O()).Invoke_O__O(seq_331000056__6); if jrt.A2g_Truth(temp__1927000414__auto____10_2) { var seq_331000056__11 any = temp__1927000414__auto____10_2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_vh_A_const_71.GetRawRoot__O()).Invoke_O__O(seq_331000056__11)) { var c__1927000678__auto____12_2 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_72.GetRawRoot__O()).Invoke_O__O(seq_331000056__11); seq_331000056__6, chunk_331000057__7, count_331000058__8, i_331000059__9 = lang.IFn_Cast(A_arbace_a2g_vh_A_const_79.GetRawRoot__O()).Invoke_O__O(seq_331000056__11), c__1927000678__auto____12_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____12_2))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var nd__12_2 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_331000056__11); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_a2g_vh_A_const_73.GetRawRoot__O()); var tmp16 any = A_arbace_a2g_vh_class_handles_fn__331000062_A_New_O_O_O(env__4, out__5, n__0); var tmp17 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_a2g_vh_class_handles_fn__331000062_A_fn_class
					if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_6, false); A_arbace_a2g_vh_class_handles_fn__331000062_A_fn_class = fncls__9d; tmp17 = fncls__9d } else { tmp17 = fncls__9 }; tmp15.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil), nd__12_2)
//line :124:1
					seq_331000056__6, chunk_331000057__7, count_331000058__8, i_331000059__9 = lang.IFn_Cast(A_arbace_a2g_vh_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_331000056__11), nil, 0, 0; continue L2 } } }
//line :111:1
			break L2 }; return /*line :114:1*/ lang.IFn_Cast(A_arbace_a2g_vh_A_const_9.GetRawRoot__O()).Invoke_O__O(out__5) }




func A_arbace_a2g_vh_class_handles_fn__331000032_A_New_O(p0 any) *A_arbace_a2g_vh_class_handles_fn__331000032_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_class_handles_fn__331000032_A{}; t.Ctor_O(p0); return t }
//line :119:1
func (t *A_arbace_a2g_vh_class_handles_fn__331000032_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :119:1
func (t *A_arbace_a2g_vh_class_handles_fn__331000032_A) Invoke_O_O__O(self, x__1 any) any {
	{ var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_vh_A_const_74); if jrt.A2g_Truth(tmp1.Invoke_O__O(A_arbace_a2g_vh_A_const_14.Invoke_O__O(x__1))) { var seq_331000033__2 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_50.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_vh_A_const_75.Invoke_O__O(x__1)); var chunk_331000034__3 any; var count_331000035__4 int64 = 0; var i_331000036__5 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z(i_331000036__5, count_331000035__4) { var vec__331000037__6 any = lang.Indexed_Cast(chunk_331000034__3).Nth_I__O(lang.RT_IntCast_J__I(i_331000036__5)); var b__7 any = lang.RT_Nth_O_I_O__O(vec__331000037__6, lang.RT_IntCast_J__I(0), nil); var init__8 any = lang.RT_Nth_O_I_O__O(vec__331000037__6, lang.RT_IntCast_J__I(1), nil); var tmp2 any; var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_62.GetRawRoot__O()).Invoke_O__O(b__7); if jrt.A2g_Truth(and__1927000168__auto____9) { tmp2 = lang.IFn_Cast(A_arbace_a2g_vh_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_vh_A_const_76.Invoke_O__O(b__7)) } else { tmp2 = and__1927000168__auto____9 }; if jrt.A2g_Truth(tmp2) {
			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_vh_A_const_77.GetRawRoot__O()); var tmp4 any = t.F_env; tmp3.Invoke_O_O_O_O__O(tmp4, A_arbace_a2g_vh_A_const_78.GetRawRoot__O(), A_arbace_a2g_vh_A_const_24.Invoke_O__O(b__7), init__8)
//line :121:1
			seq_331000033__2, chunk_331000034__3, count_331000035__4, i_331000036__5 = seq_331000033__2, chunk_331000034__3, count_331000035__4, lang.Numbers_Unchecked_inc_J__J(i_331000036__5); continue L1 } else { seq_331000033__2, chunk_331000034__3, count_331000035__4, i_331000036__5 = seq_331000033__2, chunk_331000034__3, count_331000035__4, lang.Numbers_Unchecked_inc_J__J(i_331000036__5); continue L1 } } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_50.GetRawRoot__O()).Invoke_O__O(seq_331000033__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_331000033__7 any = temp__1927000414__auto____6; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_vh_A_const_71.GetRawRoot__O()).Invoke_O__O(seq_331000033__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_72.GetRawRoot__O()).Invoke_O__O(seq_331000033__7); seq_331000033__2, chunk_331000034__3, count_331000035__4, i_331000036__5 = lang.IFn_Cast(A_arbace_a2g_vh_A_const_79.GetRawRoot__O()).Invoke_O__O(seq_331000033__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__331000040__8 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_331000033__7); var b__9 any = lang.RT_Nth_O_I_O__O(vec__331000040__8, lang.RT_IntCast_J__I(0), nil); var init__10 any = lang.RT_Nth_O_I_O__O(vec__331000040__8, lang.RT_IntCast_J__I(1), nil); var tmp5 any; var and__1927000168__auto____11 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_62.GetRawRoot__O()).Invoke_O__O(b__9); if jrt.A2g_Truth(and__1927000168__auto____11) { tmp5 = lang.IFn_Cast(A_arbace_a2g_vh_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_vh_A_const_76.Invoke_O__O(b__9)) } else { tmp5 = and__1927000168__auto____11 }; if jrt.A2g_Truth(tmp5) {
				var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_a2g_vh_A_const_77.GetRawRoot__O()); var tmp7 any = t.F_env; tmp6.Invoke_O_O_O_O__O(tmp7, A_arbace_a2g_vh_A_const_78.GetRawRoot__O(), A_arbace_a2g_vh_A_const_24.Invoke_O__O(b__9), init__10)
//line :121:1
				seq_331000033__2, chunk_331000034__3, count_331000035__4, i_331000036__5 = lang.IFn_Cast(A_arbace_a2g_vh_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_331000033__7), nil, 0, 0; continue L1 } else { seq_331000033__2, chunk_331000034__3, count_331000035__4, i_331000036__5 = lang.IFn_Cast(A_arbace_a2g_vh_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_331000033__7), nil, 0, 0; continue L1 } } } else { return nil } } } } else {
//line :120:1
					return nil } }
//line :119:1
	panic("a2g: unreachable") }
//line :119:1
func A_arbace_a2g_vh_class_handles_fn__331000044_A_New_O(p0 any) *A_arbace_a2g_vh_class_handles_fn__331000044_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_class_handles_fn__331000044_A{}; t.Ctor_O(p0); return t }
//line :119:1
func (t *A_arbace_a2g_vh_class_handles_fn__331000044_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :119:1
func (t *A_arbace_a2g_vh_class_handles_fn__331000044_A) Invoke_O_O__O(self, x__1 any) any {
	{ var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_vh_A_const_80); if jrt.A2g_Truth(tmp1.Invoke_O__O(A_arbace_a2g_vh_A_const_14.Invoke_O__O(x__1))) { var seq_331000045__2 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_50.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_vh_A_const_75.Invoke_O__O(x__1)); var chunk_331000046__3 any; var count_331000047__4 int64 = 0; var i_331000048__5 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z(i_331000048__5, count_331000047__4) { var vec__331000049__6 any = lang.Indexed_Cast(chunk_331000046__3).Nth_I__O(lang.RT_IntCast_J__I(i_331000048__5)); var b__7 any = lang.RT_Nth_O_I_O__O(vec__331000049__6, lang.RT_IntCast_J__I(0), nil); var init__8 any = lang.RT_Nth_O_I_O__O(vec__331000049__6, lang.RT_IntCast_J__I(1), nil); var tmp2 any; var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_62.GetRawRoot__O()).Invoke_O__O(b__7); if jrt.A2g_Truth(and__1927000168__auto____9) { tmp2 = lang.IFn_Cast(A_arbace_a2g_vh_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_vh_A_const_76.Invoke_O__O(b__7)) } else { tmp2 = and__1927000168__auto____9 }; if jrt.A2g_Truth(tmp2) {
			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_vh_A_const_77.GetRawRoot__O()); var tmp4 any = t.F_env; tmp3.Invoke_O_O_O_O__O(tmp4, A_arbace_a2g_vh_A_const_78.GetRawRoot__O(), A_arbace_a2g_vh_A_const_24.Invoke_O__O(b__7), init__8)
//line :121:1
			seq_331000045__2, chunk_331000046__3, count_331000047__4, i_331000048__5 = seq_331000045__2, chunk_331000046__3, count_331000047__4, lang.Numbers_Unchecked_inc_J__J(i_331000048__5); continue L1 } else { seq_331000045__2, chunk_331000046__3, count_331000047__4, i_331000048__5 = seq_331000045__2, chunk_331000046__3, count_331000047__4, lang.Numbers_Unchecked_inc_J__J(i_331000048__5); continue L1 } } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_50.GetRawRoot__O()).Invoke_O__O(seq_331000045__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_331000045__7 any = temp__1927000414__auto____6; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_vh_A_const_71.GetRawRoot__O()).Invoke_O__O(seq_331000045__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_72.GetRawRoot__O()).Invoke_O__O(seq_331000045__7); seq_331000045__2, chunk_331000046__3, count_331000047__4, i_331000048__5 = lang.IFn_Cast(A_arbace_a2g_vh_A_const_79.GetRawRoot__O()).Invoke_O__O(seq_331000045__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__331000052__8 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_331000045__7); var b__9 any = lang.RT_Nth_O_I_O__O(vec__331000052__8, lang.RT_IntCast_J__I(0), nil); var init__10 any = lang.RT_Nth_O_I_O__O(vec__331000052__8, lang.RT_IntCast_J__I(1), nil); var tmp5 any; var and__1927000168__auto____11 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_62.GetRawRoot__O()).Invoke_O__O(b__9); if jrt.A2g_Truth(and__1927000168__auto____11) { tmp5 = lang.IFn_Cast(A_arbace_a2g_vh_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_vh_A_const_76.Invoke_O__O(b__9)) } else { tmp5 = and__1927000168__auto____11 }; if jrt.A2g_Truth(tmp5) {
				var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_a2g_vh_A_const_77.GetRawRoot__O()); var tmp7 any = t.F_env; tmp6.Invoke_O_O_O_O__O(tmp7, A_arbace_a2g_vh_A_const_78.GetRawRoot__O(), A_arbace_a2g_vh_A_const_24.Invoke_O__O(b__9), init__10)
//line :121:1
				seq_331000045__2, chunk_331000046__3, count_331000047__4, i_331000048__5 = lang.IFn_Cast(A_arbace_a2g_vh_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_331000045__7), nil, 0, 0; continue L1 } else { seq_331000045__2, chunk_331000046__3, count_331000047__4, i_331000048__5 = lang.IFn_Cast(A_arbace_a2g_vh_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_331000045__7), nil, 0, 0; continue L1 } } } else { return nil } } } } else {
//line :120:1
					return nil } }
//line :119:1
	panic("a2g: unreachable")
}




func A_arbace_a2g_vh_class_handles_fn__331000060_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_vh_class_handles_fn__331000060_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_class_handles_fn__331000060_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :125:1
func (t *A_arbace_a2g_vh_class_handles_fn__331000060_A) Ctor_O_O_O(c__env, c__out, c__n any) { t.F_env = c__env; t.F_out = c__out; t.F_n = c__n }
//line :125:1
func (t *A_arbace_a2g_vh_class_handles_fn__331000060_A) Invoke_O_O__O(self, x__1 any) any {
	var tmp1 bool; var tmp2 any = A_arbace_a2g_vh_A_const_81; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z(tmp2, A_arbace_a2g_vh_A_const_14.Invoke_O__O(x__1)); if and__1927000168__auto____2 { var tmp3 *lang.Keyword = A_arbace_a2g_vh_A_const_44; tmp1 = lang.Util_Equiv_O_O__Z(A_arbace_a2g_vh_A_const_82.GetRawRoot__O(), tmp3.Invoke_O__O(A_arbace_a2g_vh_A_const_20.Invoke_O__O(x__1))) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { var f__2 any = A_arbace_a2g_vh_A_const_20.Invoke_O__O(x__1); var o__3 any; var or__1927000174__auto____3 any = A_arbace_a2g_vh_A_const_27.Invoke_O__O(f__2)

		if jrt.A2g_Truth(or__1927000174__auto____3) { o__3 = or__1927000174__auto____3 } else { o__3 = A_arbace_a2g_vh_A_const_28.Invoke_O__O(f__2) }
//line :126:1
		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_vh_A_const_63.GetRawRoot__O()); var tmp5 any = t.F_n; var temp__1927000414__auto____4 any = tmp4.Invoke_O_O_O__O(tmp5, A_arbace_a2g_vh_A_const_31.Invoke_O__O(x__1), lang.IFn_Cast(A_arbace_a2g_vh_A_const_9.GetRawRoot__O()).Invoke_O__O(t.F_env))


		if jrt.A2g_Truth(temp__1927000414__auto____4) { var spec__5 any = temp__1927000414__auto____4; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_a2g_vh_A_const_77.GetRawRoot__O()); var tmp7 any = t.F_out
			return tmp6.Invoke_O_O_O_O__O(tmp7, A_arbace_a2g_vh_A_const_78.GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(o__3, A_arbace_a2g_vh_A_const_21.Invoke_O__O(f__2)), spec__5) } else {
//line :129:1
				return nil } } else {
//line :126:1
					return nil } }
//line :125:1
func A_arbace_a2g_vh_class_handles_fn__331000062_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_vh_class_handles_fn__331000062_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_class_handles_fn__331000062_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :125:1
func (t *A_arbace_a2g_vh_class_handles_fn__331000062_A) Ctor_O_O_O(c__env, c__out, c__n any) { t.F_env = c__env; t.F_out = c__out; t.F_n = c__n }
//line :125:1
func (t *A_arbace_a2g_vh_class_handles_fn__331000062_A) Invoke_O_O__O(self, x__1 any) any {
	var tmp1 bool; var tmp2 any = A_arbace_a2g_vh_A_const_81; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z(tmp2, A_arbace_a2g_vh_A_const_14.Invoke_O__O(x__1)); if and__1927000168__auto____2 { var tmp3 *lang.Keyword = A_arbace_a2g_vh_A_const_44; tmp1 = lang.Util_Equiv_O_O__Z(A_arbace_a2g_vh_A_const_82.GetRawRoot__O(), tmp3.Invoke_O__O(A_arbace_a2g_vh_A_const_20.Invoke_O__O(x__1))) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { var f__2 any = A_arbace_a2g_vh_A_const_20.Invoke_O__O(x__1); var o__3 any; var or__1927000174__auto____3 any = A_arbace_a2g_vh_A_const_27.Invoke_O__O(f__2)

		if jrt.A2g_Truth(or__1927000174__auto____3) { o__3 = or__1927000174__auto____3 } else { o__3 = A_arbace_a2g_vh_A_const_28.Invoke_O__O(f__2) }
//line :126:1
		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_vh_A_const_63.GetRawRoot__O()); var tmp5 any = t.F_n; var temp__1927000414__auto____4 any = tmp4.Invoke_O_O_O__O(tmp5, A_arbace_a2g_vh_A_const_31.Invoke_O__O(x__1), lang.IFn_Cast(A_arbace_a2g_vh_A_const_9.GetRawRoot__O()).Invoke_O__O(t.F_env))


		if jrt.A2g_Truth(temp__1927000414__auto____4) { var spec__5 any = temp__1927000414__auto____4; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_a2g_vh_A_const_77.GetRawRoot__O()); var tmp7 any = t.F_out
			return tmp6.Invoke_O_O_O_O__O(tmp7, A_arbace_a2g_vh_A_const_78.GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(o__3, A_arbace_a2g_vh_A_const_21.Invoke_O__O(f__2)), spec__5) } else {
//line :129:1
				return nil } } else {
//line :126:1
					return nil
				}
}





func A_arbace_a2g_vh_handles_A_New() *A_arbace_a2g_vh_handles_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_handles_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_a2g_vh_handles_A) Ctor() {}
//line :134:1
func (t *A_arbace_a2g_vh_handles_A) Invoke_O_O__O(self, class_names__0 any) any { var hs__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_vh_A_const_83.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap;



	lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; var tmp3 any = tmp2.Ref(); var tmp4 any; var iter__1927001039__auto____2 any; var tmp5 any = A_arbace_a2g_vh_handles_iter__331000066__331000072_A_New(); var tmp6 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_a2g_vh_handles_iter__331000066__331000072_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_17, false); A_arbace_a2g_vh_handles_iter__331000066__331000072_A_fn_class = fncls__16d; tmp6 = fncls__16d } else { tmp6 = fncls__16 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); tmp4 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(class_names__0); hs__2 = tmp1.Invoke_O_O__O(tmp3, tmp4); var tmp7 any = A_arbace_a2g_vh_A_const_84; var tmp8 any = A_arbace_a2g_vh_A_const_36; var tmp9 lang.IFn = /*line :134:1*/lang.IFn_Cast(A_arbace_a2g_vh_A_const_85.GetRawRoot__O()); var tmp10 any; var iter__1927001039__auto____3 any; var tmp11 any = A_arbace_a2g_vh_handles_iter__331000086__331000090_A_New(); var tmp12 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_a2g_vh_handles_iter__331000086__331000090_A_fn_class; if









	fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); A_arbace_a2g_vh_handles_iter__331000086__331000090_A_fn_class = fncls__19d; tmp12 = fncls__19d } else { tmp12 = fncls__19 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); tmp10 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(hs__2); return /*line :134:1*/ lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, hs__2, tmp8, tmp9.Invoke_O__O(tmp10))) }



func A_arbace_a2g_vh_handles_iter__331000066__331000072_A_New() *A_arbace_a2g_vh_handles_iter__331000066__331000072_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_handles_iter__331000066__331000072_A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_A) Ctor() {}
//line :138:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_A) Invoke_O_O__O(self, s__331000067__1 any) any { var tmp1 any = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_New_O_O(self, s__331000067__1); var tmp2 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_19, false); A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_fn_class = fncls__15d; tmp2 = fncls__15d } else { tmp2 = fncls__15 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :138:1
func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_New_O_O(p0, p1 any) *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A{}; t.Ctor_O_O(p0, p1); return t }
//line :138:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A) Ctor_O_O(c__iter__331000066, c__s__331000067 any) { t.F_iter__331000066 = c__iter__331000066; t.F_s__331000067 = c__s__331000067 }
//line :138:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A) Invoke_O__O(self any) any { { var s__331000067__1 any; var t_ any = t.F_s__331000067; t.F_s__331000067 = nil; s__331000067__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_50.GetRawRoot__O()).Invoke_O__O(s__331000067__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var n__4 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_51.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var d__5 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_34.GetRawRoot__O()).Invoke_O__O(n__4); var tmp1 any
													var and__1927000168__auto____6 any = d__5
													if jrt.A2g_Truth(and__1927000168__auto____6) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_vh_A_const_35.GetRawRoot__O()); var tmp3 any = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_New(); var tmp4 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_20, false); A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_fn_class = fncls__13d; tmp4 = fncls__13d } else { tmp4 = fncls__13 }; tmp1 = tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), A_arbace_a2g_vh_A_const_36.Invoke_O__O(d__5)) } else { tmp1 = and__1927000168__auto____6 }
//line :138:1
	if jrt.A2g_Truth(tmp1) { var iterys__1927001035__auto____6 any; var tmp5 any = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_New(); var tmp6 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_21, false); A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_fn_class = fncls__12d; tmp6 = fncls__12d } else { tmp6 = fncls__12 }; iterys__1927001035__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var fs__1927001036__auto____7 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_vh_A_const_50.GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____6); var tmp9 any = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_New_O(n__4); var tmp10 *jrt.Class
		var fncls__14 /*line :138:1*/*jrt.Class = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_fn_class


		if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_22, false); A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_fn_class = fncls__14d; tmp10 = fncls__14d } else { tmp10 = fncls__14 }
//line :138:1
		fs__1927001036__auto____7 = tmp7.Invoke_O__O(tmp8.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil).Invoke__O())); if jrt.A2g_Truth(fs__1927001036__auto____7) { var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__331000066); return lang.IFn_Cast(A_arbace_a2g_vh_A_const_92.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____7, tmp11.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_vh_A_const_91.GetRawRoot__O()).Invoke_O__O(s__331000067__1))) } else { s__331000067__1 = lang.IFn_Cast(A_arbace_a2g_vh_A_const_91.GetRawRoot__O()).Invoke_O__O(s__331000067__1); continue L1 } } else { s__331000067__1 = lang.IFn_Cast(A_arbace_a2g_vh_A_const_91.GetRawRoot__O()).Invoke_O__O(s__331000067__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :138:1
func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_New() *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A) Ctor() {}
//line :138:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A) Invoke_O_O__O(self, s__331000069__1 any) any { var tmp1 any = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_New_O_O(s__331000069__1, self); var tmp2 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_23, false); A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_fn_class = fncls__11d; tmp2 = fncls__11d } else { tmp2 = fncls__11 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :138:1
func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_New_O_O(p0, p1 any) *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A{}; t.Ctor_O_O(p0, p1); return t }
//line :138:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A) Ctor_O_O(c__s__331000069, c__iter__331000068 any) { t.F_s__331000069 = c__s__331000069; t.F_iter__331000068 = c__iter__331000068 }
//line :138:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A) Invoke_O__O(self any) any { { var s__331000069__1 any; var t_ any = t.F_s__331000069; t.F_s__331000069 = nil; s__331000069__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_50.GetRawRoot__O()).Invoke_O__O(s__331000069__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__331000069__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_vh_A_const_71.GetRawRoot__O()).Invoke_O__O(s__331000069__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_72.GetRawRoot__O()).Invoke_O__O(s__331000069__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__331000071__6 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_86.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_New_O_I_O(b__331000071__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_24, false); A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_fn_class = fncls__10d; tmp2 = fncls__10d } else { tmp2 = fncls__10 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__331000068); return lang.IFn_Cast(A_arbace_a2g_vh_A_const_88.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_vh_A_const_90.GetRawRoot__O()).Invoke_O__O(b__331000071__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_vh_A_const_79.GetRawRoot__O()).Invoke_O__O(s__331000069__3))) } else { return lang.IFn_Cast(A_arbace_a2g_vh_A_const_88.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_vh_A_const_90.GetRawRoot__O()).Invoke_O__O(b__331000071__6), nil) } } else { var e__4 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_51.GetRawRoot__O()).Invoke_O__O(s__331000069__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__331000068); return lang.IFn_Cast(A_arbace_a2g_vh_A_const_89.GetRawRoot__O()).Invoke_O_O__O(e__4, tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_vh_A_const_91.GetRawRoot__O()).Invoke_O__O(s__331000069__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :138:1
func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :138:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A) Ctor_O_I_O(c__b__331000071 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__331000071 = c__b__331000071; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :138:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A) Invoke_O__O(self any) any { { var i__331000070__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__331000070__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__331000070__1)); lang.IFn_Cast(A_arbace_a2g_vh_A_const_87.GetRawRoot__O()).Invoke_O_O__O(t.F_b__331000071, e__2); i__331000070__1 = lang.Numbers_Unchecked_inc_J__J(i__331000070__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_New() *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A{}; t.Ctor(); return t }
//line :140:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A) Ctor() {}
//line :140:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A) Invoke_O_O__O(self, p1__331000065_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(A_arbace_a2g_vh_A_const_82.GetRawRoot__O(), A_arbace_a2g_vh_A_const_44.Invoke_O__O(p1__331000065_SHARP___1))).Ref() }
func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_New_O(p0 any) *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A{}; t.Ctor_O(p0); return t }
//line :141:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :141:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_vh_A_const_93.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); if tmp4 != nil { if true { var ___3 jrt.Throwable_I = tmp4; _ = ___3; tmp1 = nil } }; return tmp1 }


func A_arbace_a2g_vh_handles_iter__331000086__331000090_A_New() *A_arbace_a2g_vh_handles_iter__331000086__331000090_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_handles_iter__331000086__331000090_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_A) Ctor() {}
//line :144:1
func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_A) Invoke_O_O__O(self, s__331000087__1 any) any { var tmp1 any = A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_New_O_O(self, s__331000087__1); var tmp2 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_25, false); A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_fn_class = fncls__18d; tmp2 = fncls__18d } else { tmp2 = fncls__18 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :144:1
func A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_New_O_O(p0, p1 any) *A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A{}; t.Ctor_O_O(p0, p1); return t }
//line :144:1
func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A) Ctor_O_O(c__iter__331000086, c__s__331000087 any) { t.F_iter__331000086 = c__iter__331000086; t.F_s__331000087 = c__s__331000087 }
//line :144:1
func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A) Invoke_O__O(self any) any { { var s__331000087__1 any; var t_ any = t.F_s__331000087; t.F_s__331000087 = nil; s__331000087__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_50.GetRawRoot__O()).Invoke_O__O(s__331000087__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__331000087__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_vh_A_const_71.GetRawRoot__O()).Invoke_O__O(s__331000087__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_72.GetRawRoot__O()).Invoke_O__O(s__331000087__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__331000089__6 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_86.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_New_O_I_O(b__331000089__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_26, false); A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_fn_class = fncls__17d; tmp2 = fncls__17d } else { tmp2 = fncls__17 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__331000086); return lang.IFn_Cast(A_arbace_a2g_vh_A_const_88.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_vh_A_const_90.GetRawRoot__O()).Invoke_O__O(b__331000089__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_vh_A_const_79.GetRawRoot__O()).Invoke_O__O(s__331000087__3))) } else { return lang.IFn_Cast(A_arbace_a2g_vh_A_const_88.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_vh_A_const_90.GetRawRoot__O()).Invoke_O__O(b__331000089__6), nil) } } else { var vec__331000097__4 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_51.GetRawRoot__O()).Invoke_O__O(s__331000087__3); var ___5 any = lang.RT_Nth_O_I_O__O(vec__331000097__4, lang.RT_IntCast_J__I(0), nil); var s__6 any = lang.RT_Nth_O_I_O__O(vec__331000097__4, lang.RT_IntCast_J__I(1), nil); var tmp4 any = A_arbace_a2g_vh_A_const_20; _ = ___5; if lang.Util_Equiv_O_O__Z(tmp4, A_arbace_a2g_vh_A_const_45.Invoke_O__O(s__6)) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__331000086); return lang.IFn_Cast(A_arbace_a2g_vh_A_const_89.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_a2g_vh_A_const_18.Invoke_O__O(s__6), A_arbace_a2g_vh_A_const_21.Invoke_O__O(s__6)), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_vh_A_const_91.GetRawRoot__O()).Invoke_O__O(s__331000087__3))) } else { s__331000087__1 = lang.IFn_Cast(A_arbace_a2g_vh_A_const_91.GetRawRoot__O()).Invoke_O__O(s__331000087__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :144:1
func A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :144:1
func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A) Ctor_O_I_O(c__b__331000089 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__331000089 = c__b__331000089; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :144:1
func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A) Invoke_O__O(self any) any { { var i__331000088__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__331000088__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__331000093__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__331000088__1)); var ___3 any = lang.RT_Nth_O_I_O__O(vec__331000093__2, lang.RT_IntCast_J__I(0), nil); var s__4 any = lang.RT_Nth_O_I_O__O(vec__331000093__2, lang.RT_IntCast_J__I(1), nil); var tmp2 any = A_arbace_a2g_vh_A_const_20; _ = ___3; if lang.Util_Equiv_O_O__Z(tmp2, A_arbace_a2g_vh_A_const_45.Invoke_O__O(s__4)) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_vh_A_const_87.GetRawRoot__O()); var tmp4 any = t.F_b__331000089; tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(A_arbace_a2g_vh_A_const_18.Invoke_O__O(s__4), A_arbace_a2g_vh_A_const_21.Invoke_O__O(s__4))); i__331000088__1 = lang.Numbers_Unchecked_inc_J__J(i__331000088__1); continue L1 } else { i__331000088__1 = lang.Numbers_Unchecked_inc_J__J(i__331000088__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }






func A_arbace_a2g_vh_mode_A_New() *A_arbace_a2g_vh_mode_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_mode_A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_a2g_vh_mode_A) Ctor() {}
//line :151:1
func (t *A_arbace_a2g_vh_mode_A) Invoke_O_O__O(self, name__0 any) any {


	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_vh_A_const_94).Invoke_O__O(name__0)) { return A_arbace_a2g_vh_A_const_95 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_vh_A_const_96).Invoke_O__O(name__0)) { return A_arbace_a2g_vh_A_const_97 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_vh_A_const_98).Invoke_O__O(name__0)) { return A_arbace_a2g_vh_A_const_99 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_vh_A_const_100).Invoke_O__O(name__0)) { return A_arbace_a2g_vh_A_const_101 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_vh_A_const_102).Invoke_O__O(name__0)) { return A_arbace_a2g_vh_A_const_103 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_vh_A_const_104).Invoke_O__O(name__0)) { return A_arbace_a2g_vh_A_const_105 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_vh_A_const_106).Invoke_O__O(name__0)) { return A_arbace_a2g_vh_A_const_107 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_vh_A_const_108).Invoke_O__O(name__0)) { return A_arbace_a2g_vh_A_const_109 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_vh_A_const_110).Invoke_O__O(name__0)) { return A_arbace_a2g_vh_A_const_111 } else { if A_arbace_a2g_vh_A_const_64 != nil { return nil } else { return nil
	}
	}
	}
	}
	}
	}
	}
	}
	}
	}
}

func A_arbace_a2g_vh_fence_QMARK__A_New() *A_arbace_a2g_vh_fence_QMARK__A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_fence_QMARK__A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_a2g_vh_fence_QMARK__A) Ctor() {}
//line :167:1
func (t *A_arbace_a2g_vh_fence_QMARK__A) Invoke_O_O__O(self, node__0 any) any { var tmp1 any = A_arbace_a2g_vh_A_const_47; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z(tmp1, A_arbace_a2g_vh_A_const_14.Invoke_O__O(node__0)); if and__1927000168__auto____2 {
										var tmp2 any = A_arbace_a2g_vh_A_const_53; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z(tmp2, A_arbace_a2g_vh_A_const_45.Invoke_O__O(node__0)); if and__1927000168__auto____3 { var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z(A_arbace_a2g_vh_A_const_59.GetRawRoot__O(), A_arbace_a2g_vh_A_const_28.Invoke_O__O(node__0)); if and__1927000168__auto____4 { return lang.IFn_Cast(A_arbace_a2g_vh_A_const_112.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_vh_A_const_21.Invoke_O__O(node__0)) } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() } }

func A_arbace_a2g_vh_op_handle_A_New() *A_arbace_a2g_vh_op_handle_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_op_handle_A{}; t.Ctor(); return t }
//line :170:1
func (t *A_arbace_a2g_vh_op_handle_A) Ctor() {}
//line :170:1
func (t *A_arbace_a2g_vh_op_handle_A) Invoke_O_O_O__O(self, hs__0, node__1 any) any {



	var tmp1 any; var tmp2 any = A_arbace_a2g_vh_A_const_47; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z(tmp2, A_arbace_a2g_vh_A_const_14.Invoke_O__O(node__1)); if and__1927000168__auto____3 { var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z(A_arbace_a2g_vh_A_const_59.GetRawRoot__O(), A_arbace_a2g_vh_A_const_28.Invoke_O__O(node__1)); if and__1927000168__auto____4 { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_vh_A_const_113.GetRawRoot__O()); var tmp4 any = A_arbace_a2g_vh_A_const_53; tmp1 = tmp3.Invoke_O_O__O(tmp4, A_arbace_a2g_vh_A_const_45.Invoke_O__O(node__1)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }; if jrt.A2g_Truth(tmp1) { var tg__3 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_vh_A_const_67.Invoke_O__O(node__1))
		var tmp5 any = A_arbace_a2g_vh_A_const_19
		if lang.Util_Equiv_O_O__Z(tmp5, A_arbace_a2g_vh_A_const_14.Invoke_O__O(tg__3)) { var f__4 any = A_arbace_a2g_vh_A_const_20.Invoke_O__O(tg__3); var spec__5 any; var tmp6 any; var or__1927000174__auto____5 any = A_arbace_a2g_vh_A_const_27.Invoke_O__O(f__4)

			if jrt.A2g_Truth(or__1927000174__auto____5) { tmp6 = or__1927000174__auto____5 } else { tmp6 = A_arbace_a2g_vh_A_const_28.Invoke_O__O(f__4) }; spec__5 = lang.RT_Get_O_O__O(hs__0, lang.Tuple_Create_O_O__IPersistentVector(tmp6, A_arbace_a2g_vh_A_const_21.Invoke_O__O(f__4)))
//line :176:1
			var m__6 any = lang.IFn_Cast(A_arbace_a2g_vh_A_const_114.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_vh_A_const_21.Invoke_O__O(node__1)); var tmp7 any
			var and__1927000168__auto____7 any = spec__5


			if jrt.A2g_Truth(and__1927000168__auto____7) { tmp7 = m__6 } else { tmp7 = and__1927000168__auto____7 }; if jrt.A2g_Truth(tmp7) { return lang.IFn_Cast(A_arbace_a2g_vh_A_const_78.GetRawRoot__O()).Invoke_O_O_O__O(spec__5, A_arbace_a2g_vh_A_const_115, m__6) } else { return nil } } else {
//line :176:1
				return nil } } else {
//line :174:1
					return nil
				}
}




















































type A_arbace_a2g_vh_A struct{ jrt.Object }

var A_arbace_a2g_vh_A_const_pool *jrt.RefArray

var A_arbace_a2g_vh_A_const_0 *lang.Var

var A_arbace_a2g_vh_A_const_1 *lang.Var

var A_arbace_a2g_vh_A_const_2 any

var A_arbace_a2g_vh_A_const_3 any

var A_arbace_a2g_vh_A_const_4 any

var A_arbace_a2g_vh_A_const_5 any

var A_arbace_a2g_vh_A_const_6 any

var A_arbace_a2g_vh_A_const_7 any

var A_arbace_a2g_vh_A_const_8 *lang.Var

var A_arbace_a2g_vh_A_const_9 *lang.Var

var A_arbace_a2g_vh_A_const_10 *lang.Var

var A_arbace_a2g_vh_A_const_11 any

var A_arbace_a2g_vh_A_const_12 *lang.Var

var A_arbace_a2g_vh_A_const_13 *lang.Var

var A_arbace_a2g_vh_A_const_14 *lang.Keyword

var A_arbace_a2g_vh_A_const_15 *lang.Keyword

var A_arbace_a2g_vh_A_const_16 *lang.Var

var A_arbace_a2g_vh_A_const_17 *lang.Keyword

var A_arbace_a2g_vh_A_const_18 *lang.Keyword

var A_arbace_a2g_vh_A_const_19 *lang.Keyword

var A_arbace_a2g_vh_A_const_20 *lang.Keyword

var A_arbace_a2g_vh_A_const_21 *lang.Keyword

var A_arbace_a2g_vh_A_const_22 *lang.Var

var A_arbace_a2g_vh_A_const_23 *lang.Keyword

var A_arbace_a2g_vh_A_const_24 *lang.Keyword

var A_arbace_a2g_vh_A_const_25 *lang.Keyword

var A_arbace_a2g_vh_A_const_26 *lang.Keyword

var A_arbace_a2g_vh_A_const_27 *lang.Keyword

var A_arbace_a2g_vh_A_const_28 *lang.Keyword

var A_arbace_a2g_vh_A_const_29 *lang.Keyword

var A_arbace_a2g_vh_A_const_30 *lang.Var

var A_arbace_a2g_vh_A_const_31 *lang.Keyword

var A_arbace_a2g_vh_A_const_32 any

var A_arbace_a2g_vh_A_const_33 *lang.Var

var A_arbace_a2g_vh_A_const_34 *lang.Var

var A_arbace_a2g_vh_A_const_35 *lang.Var

var A_arbace_a2g_vh_A_const_36 *lang.Keyword

var A_arbace_a2g_vh_A_const_37 *lang.Keyword

var A_arbace_a2g_vh_A_const_38 *lang.Var

var A_arbace_a2g_vh_A_const_39 *lang.Keyword

var A_arbace_a2g_vh_A_const_40 any

var A_arbace_a2g_vh_A_const_41 *lang.Var

var A_arbace_a2g_vh_A_const_42 *lang.Var

var A_arbace_a2g_vh_A_const_43 *lang.Var

var A_arbace_a2g_vh_A_const_44 *lang.Keyword

var A_arbace_a2g_vh_A_const_45 *lang.Keyword

var A_arbace_a2g_vh_A_const_46 *lang.Var

var A_arbace_a2g_vh_A_const_47 *lang.Keyword

var A_arbace_a2g_vh_A_const_48 *lang.Var

var A_arbace_a2g_vh_A_const_49 *lang.Var

var A_arbace_a2g_vh_A_const_50 *lang.Var

var A_arbace_a2g_vh_A_const_51 *lang.Var

var A_arbace_a2g_vh_A_const_52 *lang.Keyword

var A_arbace_a2g_vh_A_const_53 *lang.Keyword

var A_arbace_a2g_vh_A_const_54 *lang.Var

var A_arbace_a2g_vh_A_const_55 *lang.Keyword

var A_arbace_a2g_vh_A_const_56 any

var A_arbace_a2g_vh_A_const_57 *lang.Keyword

var A_arbace_a2g_vh_A_const_58 *lang.Keyword

var A_arbace_a2g_vh_A_const_59 *lang.Var

var A_arbace_a2g_vh_A_const_60 any

var A_arbace_a2g_vh_A_const_61 *lang.Var

var A_arbace_a2g_vh_A_const_62 *lang.Var

var A_arbace_a2g_vh_A_const_63 *lang.Var

var A_arbace_a2g_vh_A_const_64 *lang.Keyword

var A_arbace_a2g_vh_A_const_65 *lang.Var

var A_arbace_a2g_vh_A_const_66 *lang.Var

var A_arbace_a2g_vh_A_const_67 *lang.Keyword

var A_arbace_a2g_vh_A_const_68 *lang.Keyword

var A_arbace_a2g_vh_A_const_69 *lang.Var

var A_arbace_a2g_vh_A_const_70 *lang.Keyword

var A_arbace_a2g_vh_A_const_71 *lang.Var

var A_arbace_a2g_vh_A_const_72 *lang.Var

var A_arbace_a2g_vh_A_const_73 *lang.Var

var A_arbace_a2g_vh_A_const_74 any

var A_arbace_a2g_vh_A_const_75 *lang.Keyword

var A_arbace_a2g_vh_A_const_76 *lang.Keyword

var A_arbace_a2g_vh_A_const_77 *lang.Var

var A_arbace_a2g_vh_A_const_78 *lang.Var

var A_arbace_a2g_vh_A_const_79 *lang.Var

var A_arbace_a2g_vh_A_const_80 any

var A_arbace_a2g_vh_A_const_81 *lang.Keyword

var A_arbace_a2g_vh_A_const_82 *lang.Var

var A_arbace_a2g_vh_A_const_83 *lang.Var

var A_arbace_a2g_vh_A_const_84 *lang.Keyword

var A_arbace_a2g_vh_A_const_85 *lang.Var

var A_arbace_a2g_vh_A_const_86 *lang.Var

var A_arbace_a2g_vh_A_const_87 *lang.Var

var A_arbace_a2g_vh_A_const_88 *lang.Var

var A_arbace_a2g_vh_A_const_89 *lang.Var

var A_arbace_a2g_vh_A_const_90 *lang.Var

var A_arbace_a2g_vh_A_const_91 *lang.Var

var A_arbace_a2g_vh_A_const_92 *lang.Var

var A_arbace_a2g_vh_A_const_93 *lang.Var

var A_arbace_a2g_vh_A_const_94 any

var A_arbace_a2g_vh_A_const_95 *lang.Keyword

var A_arbace_a2g_vh_A_const_96 any

var A_arbace_a2g_vh_A_const_97 *lang.Keyword

var A_arbace_a2g_vh_A_const_98 any

var A_arbace_a2g_vh_A_const_99 *lang.Keyword

var A_arbace_a2g_vh_A_const_100 any

var A_arbace_a2g_vh_A_const_101 *lang.Keyword

var A_arbace_a2g_vh_A_const_102 any

var A_arbace_a2g_vh_A_const_103 *lang.Keyword

var A_arbace_a2g_vh_A_const_104 any

var A_arbace_a2g_vh_A_const_105 *lang.Keyword

var A_arbace_a2g_vh_A_const_106 any

var A_arbace_a2g_vh_A_const_107 *lang.Keyword

var A_arbace_a2g_vh_A_const_108 any

var A_arbace_a2g_vh_A_const_109 *lang.Keyword

var A_arbace_a2g_vh_A_const_110 any

var A_arbace_a2g_vh_A_const_111 *lang.Keyword

var A_arbace_a2g_vh_A_const_112 *lang.Var

var A_arbace_a2g_vh_A_const_113 *lang.Var

var A_arbace_a2g_vh_A_const_114 *lang.Var

var A_arbace_a2g_vh_A_const_115 *lang.Keyword

var A_arbace_a2g_vh_A_init jrt.ClassInit

func A_arbace_a2g_vh_A_Init() { if !A_arbace_a2g_vh_A_init.Done() { A_arbace_a2g_vh_A_init.Run(A_arbace_a2g_vh_A_clinit) } }

func A_arbace_a2g_vh_A_clinit() { A_arbace_a2g_vh_A_clinit_p0(); A_arbace_a2g_vh_A_clinit_p1(); A_arbace_a2g_vh_A_clinit_p2(); A_arbace_a2g_vh_A_clinit_p3(); A_arbace_a2g_vh_A_clinit_p4(); A_arbace_a2g_vh_A_clinit_p5(); A_arbace_a2g_vh_A_clinit_p6(); A_arbace_a2g_vh_A_clinit_p7(); A_arbace_a2g_vh_A_clinit_p8(); A_arbace_a2g_vh_A_clinit_p9() }

func A_arbace_a2g_vh_A_clinit_p0() { A_arbace_a2g_vh_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 175); A_arbace_a2g_vh_A_const_0 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[59]); A_arbace_a2g_vh_A_const_1 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[60]); A_arbace_a2g_vh_A_const_2 = A_arbace_a2g_vh_A_const_pool.A[61]; A_arbace_a2g_vh_A_const_3 = A_arbace_a2g_vh_A_const_pool.A[62]; A_arbace_a2g_vh_A_const_4 = A_arbace_a2g_vh_A_const_pool.A[63]; A_arbace_a2g_vh_A_const_5 = A_arbace_a2g_vh_A_const_pool.A[64]; A_arbace_a2g_vh_A_const_6 = A_arbace_a2g_vh_A_const_pool.A[65]; A_arbace_a2g_vh_A_const_7 = A_arbace_a2g_vh_A_const_pool.A[66]; A_arbace_a2g_vh_A_const_8 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[67]); A_arbace_a2g_vh_A_const_9 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[68]); A_arbace_a2g_vh_A_const_10 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[69]); A_arbace_a2g_vh_A_const_11 = A_arbace_a2g_vh_A_const_pool.A[70]; A_arbace_a2g_vh_A_const_12 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[71]) }

func A_arbace_a2g_vh_A_clinit_p1() { A_arbace_a2g_vh_A_const_13 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[72]); A_arbace_a2g_vh_A_const_14 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[73]); A_arbace_a2g_vh_A_const_15 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[74]); A_arbace_a2g_vh_A_const_16 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[75]); A_arbace_a2g_vh_A_const_17 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[76]); A_arbace_a2g_vh_A_const_18 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[77]); A_arbace_a2g_vh_A_const_19 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[78]); A_arbace_a2g_vh_A_const_20 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[79]); A_arbace_a2g_vh_A_const_21 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[80]); A_arbace_a2g_vh_A_const_22 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[81]); A_arbace_a2g_vh_A_const_23 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[82]); A_arbace_a2g_vh_A_const_24 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[83]) }

func A_arbace_a2g_vh_A_clinit_p2() { A_arbace_a2g_vh_A_const_25 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[84]); A_arbace_a2g_vh_A_const_26 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[85]); A_arbace_a2g_vh_A_const_27 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[86]); A_arbace_a2g_vh_A_const_28 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[87]); A_arbace_a2g_vh_A_const_29 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[88]); A_arbace_a2g_vh_A_const_30 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[89]); A_arbace_a2g_vh_A_const_31 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[90]); A_arbace_a2g_vh_A_const_32 = A_arbace_a2g_vh_A_const_pool.A[91]; A_arbace_a2g_vh_A_const_33 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[92]); A_arbace_a2g_vh_A_const_34 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[93]); A_arbace_a2g_vh_A_const_35 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[94]); A_arbace_a2g_vh_A_const_36 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[95]) }

func A_arbace_a2g_vh_A_clinit_p3() { A_arbace_a2g_vh_A_const_37 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[96]); A_arbace_a2g_vh_A_const_38 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[97]); A_arbace_a2g_vh_A_const_39 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[98]); A_arbace_a2g_vh_A_const_40 = A_arbace_a2g_vh_A_const_pool.A[99]; A_arbace_a2g_vh_A_const_41 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[100]); A_arbace_a2g_vh_A_const_42 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[101]); A_arbace_a2g_vh_A_const_43 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[102]); A_arbace_a2g_vh_A_const_44 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[103]); A_arbace_a2g_vh_A_const_45 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[104]); A_arbace_a2g_vh_A_const_46 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[105]); A_arbace_a2g_vh_A_const_47 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[106]); A_arbace_a2g_vh_A_const_48 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[107]) }

func A_arbace_a2g_vh_A_clinit_p4() { A_arbace_a2g_vh_A_const_49 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[108]); A_arbace_a2g_vh_A_const_50 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[109]); A_arbace_a2g_vh_A_const_51 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[110]); A_arbace_a2g_vh_A_const_52 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[111]); A_arbace_a2g_vh_A_const_53 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[112]); A_arbace_a2g_vh_A_const_54 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[113]); A_arbace_a2g_vh_A_const_55 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[114]); A_arbace_a2g_vh_A_const_56 = A_arbace_a2g_vh_A_const_pool.A[115]; A_arbace_a2g_vh_A_const_57 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[116]); A_arbace_a2g_vh_A_const_58 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[117]); A_arbace_a2g_vh_A_const_59 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[118]); A_arbace_a2g_vh_A_const_60 = A_arbace_a2g_vh_A_const_pool.A[119] }

func A_arbace_a2g_vh_A_clinit_p5() { A_arbace_a2g_vh_A_const_61 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[120]); A_arbace_a2g_vh_A_const_62 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[121]); A_arbace_a2g_vh_A_const_63 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[122]); A_arbace_a2g_vh_A_const_64 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[123]); A_arbace_a2g_vh_A_const_65 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[124]); A_arbace_a2g_vh_A_const_66 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[125]); A_arbace_a2g_vh_A_const_67 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[126]); A_arbace_a2g_vh_A_const_68 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[127]); A_arbace_a2g_vh_A_const_69 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[128]); A_arbace_a2g_vh_A_const_70 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[129]); A_arbace_a2g_vh_A_const_71 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[130]); A_arbace_a2g_vh_A_const_72 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[131]) }

func A_arbace_a2g_vh_A_clinit_p6() { A_arbace_a2g_vh_A_const_73 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[132]); A_arbace_a2g_vh_A_const_74 = A_arbace_a2g_vh_A_const_pool.A[133]; A_arbace_a2g_vh_A_const_75 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[134]); A_arbace_a2g_vh_A_const_76 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[135]); A_arbace_a2g_vh_A_const_77 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[136]); A_arbace_a2g_vh_A_const_78 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[137]); A_arbace_a2g_vh_A_const_79 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[138]); A_arbace_a2g_vh_A_const_80 = A_arbace_a2g_vh_A_const_pool.A[139]; A_arbace_a2g_vh_A_const_81 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[140]); A_arbace_a2g_vh_A_const_82 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[141]); A_arbace_a2g_vh_A_const_83 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[142]); A_arbace_a2g_vh_A_const_84 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[143]) }

func A_arbace_a2g_vh_A_clinit_p7() { A_arbace_a2g_vh_A_const_85 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[144]); A_arbace_a2g_vh_A_const_86 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[145]); A_arbace_a2g_vh_A_const_87 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[146]); A_arbace_a2g_vh_A_const_88 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[147]); A_arbace_a2g_vh_A_const_89 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[148]); A_arbace_a2g_vh_A_const_90 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[149]); A_arbace_a2g_vh_A_const_91 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[150]); A_arbace_a2g_vh_A_const_92 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[151]); A_arbace_a2g_vh_A_const_93 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[152]); A_arbace_a2g_vh_A_const_94 = A_arbace_a2g_vh_A_const_pool.A[153]; A_arbace_a2g_vh_A_const_95 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[154]); A_arbace_a2g_vh_A_const_96 = A_arbace_a2g_vh_A_const_pool.A[155] }

func A_arbace_a2g_vh_A_clinit_p8() { A_arbace_a2g_vh_A_const_97 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[156]); A_arbace_a2g_vh_A_const_98 = A_arbace_a2g_vh_A_const_pool.A[157]; A_arbace_a2g_vh_A_const_99 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[158]); A_arbace_a2g_vh_A_const_100 = A_arbace_a2g_vh_A_const_pool.A[159]; A_arbace_a2g_vh_A_const_101 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[160]); A_arbace_a2g_vh_A_const_102 = A_arbace_a2g_vh_A_const_pool.A[161]; A_arbace_a2g_vh_A_const_103 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[162]); A_arbace_a2g_vh_A_const_104 = A_arbace_a2g_vh_A_const_pool.A[163]; A_arbace_a2g_vh_A_const_105 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[164]); A_arbace_a2g_vh_A_const_106 = A_arbace_a2g_vh_A_const_pool.A[165]; A_arbace_a2g_vh_A_const_107 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[166]); A_arbace_a2g_vh_A_const_108 = A_arbace_a2g_vh_A_const_pool.A[167]; A_arbace_a2g_vh_A_const_109 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[168]) }

func A_arbace_a2g_vh_A_clinit_p9() { A_arbace_a2g_vh_A_const_110 = A_arbace_a2g_vh_A_const_pool.A[169]; A_arbace_a2g_vh_A_const_111 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[170]); A_arbace_a2g_vh_A_const_112 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[171]); A_arbace_a2g_vh_A_const_113 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[172]); A_arbace_a2g_vh_A_const_114 = lang.Var_Cast(A_arbace_a2g_vh_A_const_pool.A[173]); A_arbace_a2g_vh_A_const_115 = lang.Keyword_Cast(A_arbace_a2g_vh_A_const_pool.A[174]) }

func A_arbace_a2g_vh_A_New() *A_arbace_a2g_vh_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_vh_A) Ctor() {}

func (t *A_arbace_a2g_vh_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_A_class }

func (t *A_arbace_a2g_vh_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_A); return ok }

func A_arbace_a2g_vh_A_Cast(x any) *A_arbace_a2g_vh_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_A_class)) }; return v }



type A_arbace_a2g_vh_byte_order_arg_A struct{ a2g_header uint64 }

var A_arbace_a2g_vh_byte_order_arg_A_fn_class *jrt.Class



type A_arbace_a2g_vh_class_arg_A struct{ a2g_header uint64 }

var A_arbace_a2g_vh_class_arg_A_fn_class *jrt.Class



type A_arbace_a2g_vh_class_handles_A struct{ a2g_header uint64 }

var A_arbace_a2g_vh_class_handles_A_fn_class *jrt.Class



type A_arbace_a2g_vh_class_handles_fn__331000032_A struct{ a2g_header uint64; F_env any }

var A_arbace_a2g_vh_class_handles_fn__331000032_A_fn_class *jrt.Class



type A_arbace_a2g_vh_class_handles_fn__331000044_A struct{ a2g_header uint64; F_env any }

var A_arbace_a2g_vh_class_handles_fn__331000044_A_fn_class *jrt.Class



type A_arbace_a2g_vh_class_handles_fn__331000060_A struct{ a2g_header uint64; F_env, F_out, F_n any }

var A_arbace_a2g_vh_class_handles_fn__331000060_A_fn_class *jrt.Class



type A_arbace_a2g_vh_class_handles_fn__331000062_A struct{ a2g_header uint64; F_env, F_out, F_n any }

var A_arbace_a2g_vh_class_handles_fn__331000062_A_fn_class *jrt.Class



type A_arbace_a2g_vh_eval331000004_A struct{ jrt.Object }

func A_arbace_a2g_vh_eval331000004_A_New() *A_arbace_a2g_vh_eval331000004_A { t := &A_arbace_a2g_vh_eval331000004_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_vh_eval331000004_A) Ctor() {}

func (t *A_arbace_a2g_vh_eval331000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_eval331000004_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_eval331000004_A_class }

func (t *A_arbace_a2g_vh_eval331000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_eval331000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_eval331000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_eval331000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_eval331000004_A); return ok }

func A_arbace_a2g_vh_eval331000004_A_Cast(x any) *A_arbace_a2g_vh_eval331000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_eval331000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_eval331000004_A_class)) }; return v }



type A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A struct{ a2g_header uint64 }

var A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_fn_class *jrt.Class



type A_arbace_a2g_vh_eval331000008_A struct{ jrt.Object }

func A_arbace_a2g_vh_eval331000008_A_New() *A_arbace_a2g_vh_eval331000008_A { t := &A_arbace_a2g_vh_eval331000008_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_vh_eval331000008_A) Ctor() {}

func (t *A_arbace_a2g_vh_eval331000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_eval331000008_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_eval331000008_A_class }

func (t *A_arbace_a2g_vh_eval331000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_eval331000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_eval331000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_eval331000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_eval331000008_A); return ok }

func A_arbace_a2g_vh_eval331000008_A_Cast(x any) *A_arbace_a2g_vh_eval331000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_eval331000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_eval331000008_A_class)) }; return v }



type A_arbace_a2g_vh_eval331000008_fn__331000009_A struct{ a2g_header uint64 }

var A_arbace_a2g_vh_eval331000008_fn__331000009_A_fn_class *jrt.Class



type A_arbace_a2g_vh_fence_QMARK__A struct{ a2g_header uint64 }

var A_arbace_a2g_vh_fence_QMARK__A_fn_class *jrt.Class



type A_arbace_a2g_vh_find_field_A struct{ a2g_header uint64 }

var A_arbace_a2g_vh_find_field_A_fn_class *jrt.Class



type A_arbace_a2g_vh_find_field_fn__331000018_A struct{ a2g_header uint64; F_fname any }

var A_arbace_a2g_vh_find_field_fn__331000018_A_fn_class *jrt.Class



type A_arbace_a2g_vh_handle_spec_A struct{ a2g_header uint64 }

var A_arbace_a2g_vh_handle_spec_A_fn_class *jrt.Class



type A_arbace_a2g_vh_handle_spec_field_spec__331000022_A struct{ a2g_header uint64 }

var A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_fn_class *jrt.Class



type A_arbace_a2g_vh_handles_A struct{ a2g_header uint64 }

var A_arbace_a2g_vh_handles_A_fn_class *jrt.Class



type A_arbace_a2g_vh_handles_iter__331000066__331000072_A struct{ a2g_header uint64 }

var A_arbace_a2g_vh_handles_iter__331000066__331000072_A_fn_class *jrt.Class



type A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A struct{ a2g_header uint64; F_iter__331000066, F_s__331000067 any }

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_fn_class *jrt.Class



type A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A struct{ a2g_header uint64 }

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_fn_class *jrt.Class



type A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A struct{ a2g_header uint64; F_n any }

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_fn_class *jrt.Class



type A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A struct{ a2g_header uint64 }

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_fn_class *jrt.Class



type A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A struct{ a2g_header uint64; F_s__331000069, F_iter__331000068 any }

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_fn_class *jrt.Class



type A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A struct{ a2g_header uint64; F_b__331000071 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_fn_class *jrt.Class



type A_arbace_a2g_vh_handles_iter__331000086__331000090_A struct{ a2g_header uint64 }

var A_arbace_a2g_vh_handles_iter__331000086__331000090_A_fn_class *jrt.Class



type A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A struct{ a2g_header uint64; F_iter__331000086, F_s__331000087 any }

var A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_fn_class *jrt.Class



type A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A struct{ a2g_header uint64; F_b__331000089 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_fn_class *jrt.Class



type A_arbace_a2g_vh_mode_A struct{ a2g_header uint64 }

var A_arbace_a2g_vh_mode_A_fn_class *jrt.Class



type A_arbace_a2g_vh_op_handle_A struct{ a2g_header uint64 }

var A_arbace_a2g_vh_op_handle_A_fn_class *jrt.Class



type A_arbace_a2g_vh_static_flag_QMARK__A struct{ a2g_header uint64 }

var A_arbace_a2g_vh_static_flag_QMARK__A_fn_class *jrt.Class



type A_arbace_a2g_vh_string_arg_A struct{ a2g_header uint64 }

var A_arbace_a2g_vh_string_arg_A_fn_class *jrt.Class
