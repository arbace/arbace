//line aot_arbace_a2g_vh.ae:1
package aot_arbace_a2g_vh

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_New() *A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A { A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_Init(); t := &A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp18 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp4 = A_arbace_a2g_vh_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_a2g_vh_A_Init(); tmp6 = A_arbace_a2g_vh_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp7 = A_arbace_a2g_vh_A_const_0; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_a2g_vh_A_Init(); tmp9 = A_arbace_a2g_vh_A_const_3; var tmp10 any = tmp9; var tmp11 any; A_arbace_a2g_vh_A_Init(); tmp11 = A_arbace_a2g_vh_A_const_4; var tmp12 any = tmp11; var tmp13 any; A_arbace_a2g_vh_A_Init(); tmp13 = A_arbace_a2g_vh_A_const_5; var tmp14 any = tmp13; var tmp15 any; A_arbace_a2g_vh_A_Init(); tmp15 = A_arbace_a2g_vh_A_const_6; var tmp16 any = tmp15; var tmp17 any; A_arbace_a2g_vh_A_Init(); tmp17 = A_arbace_a2g_vh_A_const_7; tmp3 = tmp8.Invoke_O_O_O_O_O__O(tmp10, tmp12, tmp14, tmp16, tmp17) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp18 != nil { panic(tmp18) }; return tmp3 }
//line :1:1
func A_arbace_a2g_vh_eval331000008_fn__331000009_A_New() *A_arbace_a2g_vh_eval331000008_fn__331000009_A { A_arbace_a2g_vh_eval331000008_fn__331000009_A_Init(); t := &A_arbace_a2g_vh_eval331000008_fn__331000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_vh_eval331000008_fn__331000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_vh_eval331000008_fn__331000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp1 = A_arbace_a2g_vh_A_const_8; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp3 = A_arbace_a2g_vh_A_const_9; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp5 = A_arbace_a2g_vh_A_const_12; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp7 = A_arbace_a2g_vh_A_const_10; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_a2g_vh_A_Init(); tmp9 = A_arbace_a2g_vh_A_const_11; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }
























func A_arbace_a2g_vh_class_arg_A_New() *A_arbace_a2g_vh_class_arg_A { A_arbace_a2g_vh_class_arg_A_Init(); t := &A_arbace_a2g_vh_class_arg_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_a2g_vh_class_arg_A) Ctor() {}
//line :26:1
func (t *A_arbace_a2g_vh_class_arg_A) Invoke_O_O_O__O(self, node__0, env__1 any) any { var node__3 any; var tmp1 *lang.Var;



	A_arbace_a2g_vh_A_Init(); tmp1 = A_arbace_a2g_vh_A_const_13; node__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(node__0); var G__331000012__4_ any; var tmp2 /*line :26:1*/*lang.Keyword;




	A_arbace_a2g_vh_A_Init(); tmp2 = A_arbace_a2g_vh_A_const_14; G__331000012__4_ = jrt.NN(tmp2).Invoke_O__O(node__3); switch lang.Util_Hash_O__I(G__331000012__4_) >> 6 & 3 { case 0: var tmp3 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp3 = A_arbace_a2g_vh_A_const_15; if any(G__331000012__4_) == any(tmp3.Ref()) {




		var tmp4 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp4 = A_arbace_a2g_vh_A_const_16; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp6 = A_arbace_a2g_vh_A_const_26; return tmp5.Invoke_O_O__O(jrt.NN(tmp6).Invoke_O__O(node__3), env__1) }
//line :31:1
	case 1: var tmp7 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp7 = A_arbace_a2g_vh_A_const_17; if any(G__331000012__4_) == any(tmp7.Ref()) {
		var tmp8 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp8 = A_arbace_a2g_vh_A_const_18; return jrt.NN(tmp8).Invoke_O__O(node__3) }
//line :31:1
	case 2: var tmp9 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp9 = A_arbace_a2g_vh_A_const_19; if any(G__331000012__4_) == any(tmp9.Ref()) { var f__5 any; var tmp10 *lang.Keyword

		A_arbace_a2g_vh_A_Init(); tmp10 = A_arbace_a2g_vh_A_const_20; f__5 = jrt.NN(tmp10).Invoke_O__O(node__3)
		var tmp11 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp11 = A_arbace_a2g_vh_A_const_21; if lang.Util_Equiv_O_O__Z(Lit_134, jrt.NN(tmp11).Invoke_O__O(f__5)) { var tmp12 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp12 = A_arbace_a2g_vh_A_const_22; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any; var or__1927000174__auto____6 any; var tmp15 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp15 = A_arbace_a2g_vh_A_const_27; or__1927000174__auto____6 = jrt.NN(tmp15).Invoke_O__O(f__5); if jrt.A2g_Truth(or__1927000174__auto____6) { tmp14 = or__1927000174__auto____6 } else { var tmp16 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp16 = A_arbace_a2g_vh_A_const_28; tmp14 = jrt.NN(tmp16).Invoke_O__O(f__5) }; return tmp13.Invoke_O__O(tmp14) } else { return nil } }
//line :31:1
	case 3: var tmp17 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp17 = A_arbace_a2g_vh_A_const_23; if any(G__331000012__4_) == any(tmp17.Ref()) { var temp__1927000414__auto____5 any; var tmp18 *lang.Keyword



		A_arbace_a2g_vh_A_Init(); tmp18 = A_arbace_a2g_vh_A_const_24; var tmp19 *lang.Keyword = tmp18; var tmp20 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp20 = A_arbace_a2g_vh_A_const_25; temp__1927000414__auto____5 = lang.RT_Get_O_O__O(env__1, jrt.NN(tmp19).Invoke_O__O(jrt.NN(tmp20).Invoke_O__O(node__3))); if jrt.A2g_Truth(temp__1927000414__auto____5) { var init__6 any = temp__1927000414__auto____5; var tmp21 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp21 = A_arbace_a2g_vh_A_const_16; return lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O_O__O(init__6, env__1) } else { return nil } }
//line :31:1
	default:}; return nil }







func A_arbace_a2g_vh_string_arg_A_New() *A_arbace_a2g_vh_string_arg_A { A_arbace_a2g_vh_string_arg_A_Init(); t := &A_arbace_a2g_vh_string_arg_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_a2g_vh_string_arg_A) Ctor() {}
//line :39:1
func (t *A_arbace_a2g_vh_string_arg_A) Invoke_O_O__O(self, node__0 any) any { var node__2 any; var tmp1 *lang.Var;
										A_arbace_a2g_vh_A_Init(); tmp1 = A_arbace_a2g_vh_A_const_13; node__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(node__0); var tmp2 any; var and__1927000168__auto____3 bool; var tmp3 /*line :41:1*/*lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp3 = A_arbace_a2g_vh_A_const_29; var tmp4 any = tmp3.Ref(); var tmp5 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp5 = A_arbace_a2g_vh_A_const_14; and__1927000168__auto____3 = lang.Util_Equiv_O_O__Z(tmp4, jrt.NN(tmp5).Invoke_O__O(node__2)); if and__1927000168__auto____3 { var tmp6 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp6 = A_arbace_a2g_vh_A_const_30; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp8 = A_arbace_a2g_vh_A_const_31; tmp2 = tmp7.Invoke_O__O(jrt.NN(tmp8).Invoke_O__O(node__2)) } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }; if jrt.A2g_Truth(tmp2) { var tmp9 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp9 = A_arbace_a2g_vh_A_const_31; return jrt.NN(tmp9).Invoke_O__O(node__2) } else { return nil } }

func A_arbace_a2g_vh_byte_order_arg_A_New() *A_arbace_a2g_vh_byte_order_arg_A { A_arbace_a2g_vh_byte_order_arg_A_Init(); t := &A_arbace_a2g_vh_byte_order_arg_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_a2g_vh_byte_order_arg_A) Ctor() {}
//line :43:1
func (t *A_arbace_a2g_vh_byte_order_arg_A) Invoke_O_O_O__O(self, node__0, env__1 any) any { var node__3 any; var tmp1 *lang.Var;



	A_arbace_a2g_vh_A_Init(); tmp1 = A_arbace_a2g_vh_A_const_13; node__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(node__0); var G__331000015__4_ any; var tmp2 /*line :43:1*/*lang.Keyword;




	A_arbace_a2g_vh_A_Init(); tmp2 = A_arbace_a2g_vh_A_const_14; G__331000015__4_ = jrt.NN(tmp2).Invoke_O__O(node__3); switch lang.Util_Hash_O__I(G__331000015__4_) >> 0 & 1 { case 0: var tmp3 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp3 = A_arbace_a2g_vh_A_const_19; if any(G__331000015__4_) == any(tmp3.Ref()) { var f__5 any; var tmp4 *lang.Keyword
		A_arbace_a2g_vh_A_Init(); tmp4 = A_arbace_a2g_vh_A_const_20; f__5 = jrt.NN(tmp4).Invoke_O__O(node__3)
		var tmp5 any; var or__1927000174__auto____6 any; var tmp6 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp6 = A_arbace_a2g_vh_A_const_27; or__1927000174__auto____6 = jrt.NN(tmp6).Invoke_O__O(f__5); if jrt.A2g_Truth(or__1927000174__auto____6) { tmp5 = or__1927000174__auto____6 } else { var tmp7 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp7 = A_arbace_a2g_vh_A_const_28; tmp5 = jrt.NN(tmp7).Invoke_O__O(f__5) }; if lang.Util_Equiv_O_O__Z(Lit_132, tmp5) {
			var tmp8 any; A_arbace_a2g_vh_A_Init(); tmp8 = A_arbace_a2g_vh_A_const_32; var tmp9 lang.IFn = lang.IFn_Cast(tmp8); var tmp10 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp10 = A_arbace_a2g_vh_A_const_21; return tmp9.Invoke_O__O(jrt.NN(tmp10).Invoke_O__O(f__5)) } else {
//line :50:1
				return nil } }
//line :48:1
	case 1: var tmp11 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp11 = A_arbace_a2g_vh_A_const_23; if any(G__331000015__4_) == any(tmp11.Ref()) { var temp__1927000414__auto____5 any; var tmp12 *lang.Keyword



		A_arbace_a2g_vh_A_Init(); tmp12 = A_arbace_a2g_vh_A_const_24; var tmp13 *lang.Keyword = tmp12; var tmp14 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp14 = A_arbace_a2g_vh_A_const_25; temp__1927000414__auto____5 = lang.RT_Get_O_O__O(env__1, jrt.NN(tmp13).Invoke_O__O(jrt.NN(tmp14).Invoke_O__O(node__3))); if jrt.A2g_Truth(temp__1927000414__auto____5) { var init__6 any = temp__1927000414__auto____5; var tmp15 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp15 = A_arbace_a2g_vh_A_const_33; return lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O_O__O(init__6, env__1) } else { return nil } }
//line :48:1
	default:}; return nil }






func A_arbace_a2g_vh_find_field_A_New() *A_arbace_a2g_vh_find_field_A { A_arbace_a2g_vh_find_field_A_Init(); t := &A_arbace_a2g_vh_find_field_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_a2g_vh_find_field_A) Ctor() {}
//line :55:1
func (t *A_arbace_a2g_vh_find_field_A) Invoke_O_O_O__O(self, n__0, fname__1 any) any { { var c__3 any = n__0; L1: for { var temp__1927000414__auto____4 any
											var and__1927000168__auto____4 any = c__3


	if jrt.A2g_Truth(and__1927000168__auto____4) { var tmp1 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp1 = A_arbace_a2g_vh_A_const_34; temp__1927000414__auto____4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(c__3) } else { temp__1927000414__auto____4 = and__1927000168__auto____4 }; if jrt.A2g_Truth(temp__1927000414__auto____4) { var d__5 any = temp__1927000414__auto____4; var or__1927000174__auto____6 any; var tmp2 *lang.Var
		A_arbace_a2g_vh_A_Init(); tmp2 = A_arbace_a2g_vh_A_const_35; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = A_arbace_a2g_vh_find_field_fn__331000018_A_New_O(fname__1); var tmp5 *jrt.Class; A_arbace_a2g_vh_find_field_fn__331000018_A_Init(); tmp5 = A_arbace_a2g_vh_find_field_fn__331000018_A_fn_class; var tmp6 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp7 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp7 = A_arbace_a2g_vh_A_const_36; or__1927000174__auto____6 = tmp3.Invoke_O_O__O(tmp6, jrt.NN(tmp7).Invoke_O__O(d__5)); if jrt.A2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else {
			var tmp8 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp8 = A_arbace_a2g_vh_A_const_37; c__3 = jrt.NN(tmp8).Invoke_O__O(d__5); continue L1 } } else {
//line :59:1
				return nil } } }; /*line :55:1*/panic("a2g: unreachable") }




func A_arbace_a2g_vh_find_field_fn__331000018_A_New_O(p0 any) *A_arbace_a2g_vh_find_field_fn__331000018_A { A_arbace_a2g_vh_find_field_fn__331000018_A_Init(); t := &A_arbace_a2g_vh_find_field_fn__331000018_A{}; t.Ctor_O(p0); return t }
//line :60:1
func (t *A_arbace_a2g_vh_find_field_fn__331000018_A) Ctor_O(c__fname any) { t.F_fname = c__fname }
//line :60:1
func (t *A_arbace_a2g_vh_find_field_fn__331000018_A) Invoke_O_O__O(self, p1__331000017_SHARP___1 any) any { var tmp1 any = t.F_fname; var tmp2 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp2 = A_arbace_a2g_vh_A_const_21; if lang.Util_Equiv_O_O__Z(tmp1, jrt.NN(tmp2).Invoke_O__O(p1__331000017_SHARP___1)) { return p1__331000017_SHARP___1 } else { return nil } }


func A_arbace_a2g_vh_static_flag_QMARK__A_New() *A_arbace_a2g_vh_static_flag_QMARK__A { A_arbace_a2g_vh_static_flag_QMARK__A_Init(); t := &A_arbace_a2g_vh_static_flag_QMARK__A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_a2g_vh_static_flag_QMARK__A) Ctor() {}
//line :63:1
func (t *A_arbace_a2g_vh_static_flag_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var tmp1 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp1 = A_arbace_a2g_vh_A_const_38; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; var or__1927000174__auto____2 any; var tmp4 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp4 = A_arbace_a2g_vh_A_const_39; or__1927000174__auto____2 = jrt.NN(tmp4).Invoke_O__O(f__0); if jrt.A2g_Truth(or__1927000174__auto____2) { tmp3 = or__1927000174__auto____2 } else { A_arbace_a2g_vh_A_Init(); tmp3 = A_arbace_a2g_vh_A_const_40 }; return tmp2.Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_J__Z(lang.Numbers_And_O_J__J(tmp3, 8))).Ref()) }

func A_arbace_a2g_vh_handle_spec_A_New() *A_arbace_a2g_vh_handle_spec_A { A_arbace_a2g_vh_handle_spec_A_Init(); t := &A_arbace_a2g_vh_handle_spec_A{}; t.Ctor(); return t }
//line :65:1
func (t *A_arbace_a2g_vh_handle_spec_A) Ctor() {}
//line :65:1
func (t *A_arbace_a2g_vh_handle_spec_A) Invoke_O_O_O_O__O(self, n__0, init__1, env__2 any) any { var init__4 any; var tmp1 *lang.Var;




	A_arbace_a2g_vh_A_Init(); tmp1 = A_arbace_a2g_vh_A_const_13; init__4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(init__1); var field_spec__5 any; var tmp2 any = /*line :65:1*/A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_New(); var tmp3 *jrt.Class;





	A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_Init(); tmp3 = A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_fn_class; field_spec__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 /*line :77:1*/*lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp4 = A_arbace_a2g_vh_A_const_47; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp6 = A_arbace_a2g_vh_A_const_14; if lang.Util_Equiv_O_O__Z(tmp5, jrt.NN(tmp6).Invoke_O__O(init__4)) { var map__331000024__6 any = init__4; var map__331000024__7 any
		if lang.ISeq_InstanceOf(map__331000024__6) { var tmp7 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp7 = A_arbace_a2g_vh_A_const_48; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(map__331000024__6)) { var tmp8 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp8 = A_arbace_a2g_vh_A_const_49; map__331000024__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(map__331000024__6), jrt.Object_class.ArrayClass())).Ref() } else { var tmp9 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp9 = A_arbace_a2g_vh_A_const_50; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(map__331000024__6)) { var tmp10 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp10 = A_arbace_a2g_vh_A_const_51; map__331000024__7 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(map__331000024__6) } else { lang.PersistentArrayMap_Init(); map__331000024__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__331000024__7 = map__331000024__6 }
//line :77:1
		var owner__8 any; var tmp11 *lang.Keyword
		A_arbace_a2g_vh_A_Init(); tmp11 = A_arbace_a2g_vh_A_const_28; owner__8 = lang.RT_Get_O_O__O(map__331000024__7, tmp11.Ref())
//line :77:1
		var name__9 any; var tmp12 *lang.Keyword
		A_arbace_a2g_vh_A_Init(); tmp12 = A_arbace_a2g_vh_A_const_21; name__9 = lang.RT_Get_O_O__O(map__331000024__7, tmp12.Ref())
//line :77:1
		var args__10 any; var tmp13 *lang.Keyword
		A_arbace_a2g_vh_A_Init(); tmp13 = A_arbace_a2g_vh_A_const_52; args__10 = lang.RT_Get_O_O__O(map__331000024__7, tmp13.Ref())
//line :77:1
		var kind__11 any; var tmp14 *lang.Keyword
		A_arbace_a2g_vh_A_Init(); tmp14 = A_arbace_a2g_vh_A_const_45; kind__11 = lang.RT_Get_O_O__O(map__331000024__7, tmp14.Ref())
		var tmp15 bool; var and__1927000168__auto____12 bool = lang.Util_Equiv_O_O__Z(owner__8, Lit_146)
		if and__1927000168__auto____12 { var and__1927000168__auto____13 bool = lang.Util_Equiv_O_O__Z(name__9, Lit_147); if and__1927000168__auto____13 { tmp15 = lang.Util_Equiv_J_J__Z(3, int64(lang.RT_Count_O__I(args__10))) } else { tmp15 = and__1927000168__auto____13 } } else { tmp15 = and__1927000168__auto____12 }
//line :79:1
		if tmp15 {

			var tmp16 lang.IFn = lang.IFn_Cast(field_spec__5); var tmp17 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp17 = A_arbace_a2g_vh_A_const_16; var tmp18 any = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O(args__10, lang.RT_IntCast_J__I(0)), env__2); var tmp19 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp19 = A_arbace_a2g_vh_A_const_65; var tmp20 any = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(args__10, lang.RT_IntCast_J__I(1))); var tmp21 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp21 = A_arbace_a2g_vh_A_const_16; return tmp16.Invoke_O_O_O__O(tmp18, tmp20, lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O(args__10, lang.RT_IntCast_J__I(2)), env__2)) } else {
//line :79:1
				var tmp22 bool; var and__1927000168__auto____12_2 bool = lang.Util_Equiv_O_O__Z(owner__8, Lit_148)



				if and__1927000168__auto____12_2 { var and__1927000168__auto____13_2 bool = lang.Util_Equiv_O_O__Z(name__9, Lit_147); if and__1927000168__auto____13_2 { var tmp23 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp23 = A_arbace_a2g_vh_A_const_53; tmp22 = lang.Util_Equiv_O_O__Z(kind__11, tmp23.Ref()) } else { tmp22 = and__1927000168__auto____13_2 } } else { tmp22 = and__1927000168__auto____12_2 }
//line :79:1
				if tmp22 { var G__331000026__12_ int32 = lang.RT_Count_O__I(args__10)




					switch G__331000026__12_ { case 3:

						var tmp24 lang.IFn = lang.IFn_Cast(field_spec__5); var tmp25 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_149, nil, Lit_150), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil)).Ref(); var tmp26 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp26 = A_arbace_a2g_vh_A_const_65; var tmp27 any = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(args__10, lang.RT_IntCast_J__I(1))); var tmp28 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp28 = A_arbace_a2g_vh_A_const_16; return tmp24.Invoke_O_O_O__O(tmp25, tmp27, lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O(args__10, lang.RT_IntCast_J__I(2)), env__2))
//line :84:1
					case 4:


						var tmp29 lang.IFn = lang.IFn_Cast(field_spec__5); var tmp30 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp30 = A_arbace_a2g_vh_A_const_16; var tmp31 any = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O(args__10, lang.RT_IntCast_J__I(1)), env__2); var tmp32 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp32 = A_arbace_a2g_vh_A_const_65; var tmp33 any = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(args__10, lang.RT_IntCast_J__I(2))); var tmp34 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp34 = A_arbace_a2g_vh_A_const_16; return tmp29.Invoke_O_O_O__O(tmp31, tmp33, lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O(args__10, lang.RT_IntCast_J__I(3)), env__2))
//line :84:1
					default:}; return nil } else {
//line :79:1
						var tmp35 bool; var and__1927000168__auto____12_3 bool = lang.Util_Equiv_O_O__Z(owner__8, Lit_151)










						if and__1927000168__auto____12_3 { var and__1927000168__auto____13_3 bool = lang.Util_Equiv_O_O__Z(name__9, Lit_152); if and__1927000168__auto____13_3 { var and__1927000168__auto____14 bool; var tmp36 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp36 = A_arbace_a2g_vh_A_const_53; and__1927000168__auto____14 = lang.Util_Equiv_O_O__Z(kind__11, tmp36.Ref()); if and__1927000168__auto____14 {
							tmp35 = lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(args__10))) } else {
//line :90:1
								tmp35 = and__1927000168__auto____14 } } else { tmp35 = and__1927000168__auto____13_3 } } else { tmp35 = and__1927000168__auto____12_3 }
//line :79:1
						if tmp35 { var d__12 any; var tmp37 *lang.Var












							A_arbace_a2g_vh_A_Init(); tmp37 = A_arbace_a2g_vh_A_const_16; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp39 = A_arbace_a2g_vh_A_const_51; d__12 = tmp38.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()).Invoke_O__O(args__10), env__2)
							var tmp40 any; var and__1927000168__auto____13_4 any = d__12; if jrt.A2g_Truth(and__1927000168__auto____13_4) { var tmp41 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp41 = A_arbace_a2g_vh_A_const_54; tmp40 = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()).Invoke_O__O(d__12) } else { tmp40 = and__1927000168__auto____13_4 }; if jrt.A2g_Truth(tmp40) { var tmp42 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp42 = A_arbace_a2g_vh_A_const_45; var tmp43 any = tmp42.Ref(); var tmp44 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp44 = A_arbace_a2g_vh_A_const_55; var tmp45 any = tmp44.Ref(); var tmp46 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp46 = A_arbace_a2g_vh_A_const_44; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp43, tmp45, tmp46.Ref(), d__12)) } else { return nil } } else {
//line :79:1
								var tmp47 bool; var and__1927000168__auto____12_4 bool = lang.Util_Equiv_O_O__Z(owner__8, Lit_151)



















								if and__1927000168__auto____12_4 { var and__1927000168__auto____13_5 bool = lang.Util_Equiv_O_O__Z(name__9, Lit_153); if and__1927000168__auto____13_5 { var and__1927000168__auto____14_2 bool; var tmp48 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp48 = A_arbace_a2g_vh_A_const_53; and__1927000168__auto____14_2 = lang.Util_Equiv_O_O__Z(kind__11, tmp48.Ref()); if and__1927000168__auto____14_2 {
									tmp47 = lang.Util_Equiv_J_J__Z(2, int64(lang.RT_Count_O__I(args__10))) } else {
//line :99:1
										tmp47 = and__1927000168__auto____14_2 } } else { tmp47 = and__1927000168__auto____13_5 } } else { tmp47 = and__1927000168__auto____12_4 }
//line :79:1
								if tmp47 { var d__12_2 any; var tmp49 *lang.Var





















									A_arbace_a2g_vh_A_Init(); tmp49 = A_arbace_a2g_vh_A_const_16; var tmp50 lang.IFn = lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()); var tmp51 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp51 = A_arbace_a2g_vh_A_const_51; d__12_2 = tmp50.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()).Invoke_O__O(args__10), env__2)
//line :79:1
									var o__13 any; var tmp52 *lang.Var






















									A_arbace_a2g_vh_A_Init(); tmp52 = A_arbace_a2g_vh_A_const_33; var tmp53 lang.IFn = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()); var tmp54 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp54 = A_arbace_a2g_vh_A_const_66; o__13 = tmp53.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp54).GetRawRoot__O()).Invoke_O__O(args__10), env__2)
									var tmp55 any; var and__1927000168__auto____14_3 any; var tmp56 any; A_arbace_a2g_vh_A_Init(); tmp56 = A_arbace_a2g_vh_A_const_56; and__1927000168__auto____14_3 = lang.IFn_Cast(tmp56).Invoke_O__O(d__12_2); if jrt.A2g_Truth(and__1927000168__auto____14_3) { tmp55 = o__13 } else { tmp55 = and__1927000168__auto____14_3 }; if jrt.A2g_Truth(tmp55) { var tmp57 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp57 = A_arbace_a2g_vh_A_const_45; var tmp58 any = tmp57.Ref(); var tmp59 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp59 = A_arbace_a2g_vh_A_const_57; var tmp60 any = tmp59.Ref(); var tmp61 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp61 = A_arbace_a2g_vh_A_const_44; var tmp62 any = tmp61.Ref(); var tmp63 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp63 = A_arbace_a2g_vh_A_const_58; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp58, tmp60, tmp62, d__12_2, tmp63.Ref(), o__13)) } else { return nil } } else {
//line :79:1
										var tmp64 any; var and__1927000168__auto____12_5 bool; var tmp65 *lang.Var

























										A_arbace_a2g_vh_A_Init(); tmp65 = A_arbace_a2g_vh_A_const_59; and__1927000168__auto____12_5 = lang.Util_Equiv_O_O__Z(owner__8, jrt.NN(tmp65).GetRawRoot__O()); if and__1927000168__auto____12_5 { var and__1927000168__auto____13_6 any; var tmp66 any; A_arbace_a2g_vh_A_Init(); tmp66 = A_arbace_a2g_vh_A_const_60; and__1927000168__auto____13_6 = lang.IFn_Cast(tmp66).Invoke_O__O(name__9); if jrt.A2g_Truth(and__1927000168__auto____13_6) { var and__1927000168__auto____14_4 any; var tmp67 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp67 = A_arbace_a2g_vh_A_const_61; and__1927000168__auto____14_4 = lang.IFn_Cast(jrt.NN(tmp67).GetRawRoot__O()).Invoke_O__O(args__10); if jrt.A2g_Truth(and__1927000168__auto____14_4) {
											var tmp68 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp68 = A_arbace_a2g_vh_A_const_62; var tmp69 lang.IFn = lang.IFn_Cast(jrt.NN(tmp68).GetRawRoot__O()); var tmp70 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp70 = A_arbace_a2g_vh_A_const_67; tmp64 = tmp69.Invoke_O__O(jrt.NN(tmp70).Invoke_O__O(init__4)) } else {
//line :105:1
												tmp64 = and__1927000168__auto____14_4 } } else { tmp64 = and__1927000168__auto____13_6 } } else { tmp64 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____12_5).Ref() }
//line :79:1
										if jrt.A2g_Truth(tmp64) {



























											var tmp71 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp71 = A_arbace_a2g_vh_A_const_63; var tmp72 lang.IFn = lang.IFn_Cast(jrt.NN(tmp71).GetRawRoot__O()); var tmp73 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp73 = A_arbace_a2g_vh_A_const_67; return tmp72.Invoke_O_O_O__O(n__0, jrt.NN(tmp73).Invoke_O__O(init__4), env__2) } else {
//line :79:1
												var tmp74 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp74 = A_arbace_a2g_vh_A_const_64; if tmp74 != nil { return nil } else { return nil } } } } } } } else {
//line :77:1
													return nil } }
//line :71:1
func A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_New() *A_arbace_a2g_vh_handle_spec_field_spec__331000022_A { A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_Init(); t := &A_arbace_a2g_vh_handle_spec_field_spec__331000022_A{}; t.Ctor(); return t }
//line :71:1
func (t *A_arbace_a2g_vh_handle_spec_field_spec__331000022_A) Ctor() {}
//line :71:1
func (t *A_arbace_a2g_vh_handle_spec_field_spec__331000022_A) Invoke_O_O_O_O__O(self, c__1, fname__2, tdesc__3 any) any {
	var tmp1 any; var and__1927000168__auto____4 any = c__1; if jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = fname__2; if jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = tdesc__3; if jrt.A2g_Truth(and__1927000168__auto____6) { var tmp2 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp2 = A_arbace_a2g_vh_A_const_41; tmp1 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(c__1) } else { tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.A2g_Truth(tmp1) { var cn__4 any; var tmp3 *lang.Var
		A_arbace_a2g_vh_A_Init(); tmp3 = A_arbace_a2g_vh_A_const_42; cn__4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(c__1)
//line :72:1
		var f__5 any; var tmp4 *lang.Var

		A_arbace_a2g_vh_A_Init(); tmp4 = A_arbace_a2g_vh_A_const_43; f__5 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(cn__4, fname__2)
		var tmp5 any; var and__1927000168__auto____6_2 any = f__5; if jrt.A2g_Truth(and__1927000168__auto____6_2) { var and__1927000168__auto____7 bool; var tmp6 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp6 = A_arbace_a2g_vh_A_const_44; and__1927000168__auto____7 = lang.Util_Equiv_O_O__Z(tdesc__3, jrt.NN(tmp6).Invoke_O__O(f__5)); if and__1927000168__auto____7 { var tmp7 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp7 = A_arbace_a2g_vh_A_const_38; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp9 = A_arbace_a2g_vh_A_const_46; tmp5 = tmp8.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(f__5)) } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____7).Ref() } } else { tmp5 = and__1927000168__auto____6_2 }; if jrt.A2g_Truth(tmp5) { var tmp10 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp10 = A_arbace_a2g_vh_A_const_45; var tmp11 any = tmp10.Ref(); var tmp12 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp12 = A_arbace_a2g_vh_A_const_20; var tmp13 any = tmp12.Ref(); var tmp14 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp14 = A_arbace_a2g_vh_A_const_18; var tmp15 any = tmp14.Ref(); var tmp16 any; var or__1927000174__auto____6 any; var tmp17 *lang.Keyword
			A_arbace_a2g_vh_A_Init(); tmp17 = A_arbace_a2g_vh_A_const_28; or__1927000174__auto____6 = jrt.NN(tmp17).Invoke_O__O(f__5); if jrt.A2g_Truth(or__1927000174__auto____6) { tmp16 = or__1927000174__auto____6 } else { tmp16 = cn__4 }
//line :75:1
			var tmp18 any = tmp16; var tmp19 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp19 = A_arbace_a2g_vh_A_const_21; var tmp20 any = tmp19.Ref(); var tmp21 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp21 = A_arbace_a2g_vh_A_const_44; var tmp22 any = tmp21.Ref(); var tmp23 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp23 = A_arbace_a2g_vh_A_const_20; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp11, tmp13, tmp15, tmp18, tmp20, fname__2, tmp22, tdesc__3, tmp23.Ref(), f__5)) } else { return nil } } else {
//line :72:1
				return nil
			}
}




































func A_arbace_a2g_vh_class_handles_A_New() *A_arbace_a2g_vh_class_handles_A { A_arbace_a2g_vh_class_handles_A_Init(); t := &A_arbace_a2g_vh_class_handles_A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_a2g_vh_class_handles_A) Ctor() {}
//line :111:1
func (t *A_arbace_a2g_vh_class_handles_A) Invoke_O_O__O(self, n__0 any) any { var st__2 any; var tmp1 *lang.Var;


	A_arbace_a2g_vh_A_Init(); tmp1 = A_arbace_a2g_vh_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp3 = A_arbace_a2g_vh_A_const_70; var tmp4 *lang.Keyword = tmp3; var tmp5 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp5 = A_arbace_a2g_vh_A_const_34; st__2 = tmp2.Invoke_O__O(jrt.NN(tmp4).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(n__0))); var code__3 any; var tmp6 /*line :111:1*/*lang.Keyword;



	A_arbace_a2g_vh_A_Init(); tmp6 = A_arbace_a2g_vh_A_const_68; code__3 = jrt.NN(tmp6).Invoke_O__O(st__2); var env__4 any; var tmp7 /*line :111:1*/*lang.Var;




	A_arbace_a2g_vh_A_Init(); tmp7 = A_arbace_a2g_vh_A_const_69; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp9 = lang.PersistentArrayMap_EMPTY; env__4 = tmp8.Invoke_O__O(tmp9.Ref()); var out__5 any; var tmp10 /*line :111:1*/*lang.Var;





	A_arbace_a2g_vh_A_Init(); tmp10 = A_arbace_a2g_vh_A_const_69; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp12 = lang.PersistentArrayMap_EMPTY; out__5 = tmp11.Invoke_O__O(tmp12.Ref()); var seq_331000028__6 any; var tmp13 /*line :111:1*/*lang.Var;






	A_arbace_a2g_vh_A_Init(); tmp13 = A_arbace_a2g_vh_A_const_50; seq_331000028__6 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(code__3); var chunk_331000029__7 any; var count_331000030__8 int64 = 0; var i_331000031__9 int64 = 0; L1:
//line :111:1
	for {






		if lang.Numbers_Lt_J_J__Z(i_331000031__9, count_331000030__8) { var nd__10 any = lang.Indexed_Cast(chunk_331000029__7).Nth_I__O(lang.RT_IntCast_J__I(i_331000031__9)); var tmp14 *lang.Var
			A_arbace_a2g_vh_A_Init(); tmp14 = A_arbace_a2g_vh_A_const_73; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 any = A_arbace_a2g_vh_class_handles_fn__331000032_A_New_O(env__4); var tmp17 *jrt.Class; A_arbace_a2g_vh_class_handles_fn__331000032_A_Init(); tmp17 = A_arbace_a2g_vh_class_handles_fn__331000032_A_fn_class; tmp15.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil), nd__10)
//line :118:1
			seq_331000028__6, chunk_331000029__7, count_331000030__8, i_331000031__9 = seq_331000028__6, chunk_331000029__7, count_331000030__8, lang.Numbers_Unchecked_inc_J__J(i_331000031__9); continue L1 } else { var temp__1927000414__auto____10 any; var tmp18 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp18 = A_arbace_a2g_vh_A_const_50; temp__1927000414__auto____10 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(seq_331000028__6); if jrt.A2g_Truth(temp__1927000414__auto____10) { var seq_331000028__11 any = temp__1927000414__auto____10; var tmp19 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp19 = A_arbace_a2g_vh_A_const_71; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(seq_331000028__11)) { var c__1927000678__auto____12 any; var tmp20 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp20 = A_arbace_a2g_vh_A_const_72; c__1927000678__auto____12 = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(seq_331000028__11); var tmp21 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp21 = A_arbace_a2g_vh_A_const_79; seq_331000028__6, chunk_331000029__7, count_331000030__8, i_331000031__9 = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(seq_331000028__11), c__1927000678__auto____12, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var nd__12 any; var tmp22 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp22 = A_arbace_a2g_vh_A_const_51; nd__12 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(seq_331000028__11)
				var tmp23 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp23 = A_arbace_a2g_vh_A_const_73; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 any = A_arbace_a2g_vh_class_handles_fn__331000044_A_New_O(env__4); var tmp26 *jrt.Class; A_arbace_a2g_vh_class_handles_fn__331000044_A_Init(); tmp26 = A_arbace_a2g_vh_class_handles_fn__331000044_A_fn_class; tmp24.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil), nd__12)
//line :118:1
				var tmp27 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp27 = A_arbace_a2g_vh_A_const_48; seq_331000028__6, chunk_331000029__7, count_331000030__8, i_331000031__9 = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(seq_331000028__11), nil, 0, 0; continue L1 } } }
//line :111:1
		break L1 }; var seq_331000056__6 any; var tmp28 *lang.Var;












	A_arbace_a2g_vh_A_Init(); tmp28 = A_arbace_a2g_vh_A_const_50; seq_331000056__6 = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(code__3); var chunk_331000057__7 any; var count_331000058__8 int64 = 0; var i_331000059__9 int64 = 0; L2:
//line :111:1
	for {












		if lang.Numbers_Lt_J_J__Z(i_331000059__9, count_331000058__8) { var nd__10_2 any = lang.Indexed_Cast(chunk_331000057__7).Nth_I__O(lang.RT_IntCast_J__I(i_331000059__9)); var tmp29 *lang.Var
			A_arbace_a2g_vh_A_Init(); tmp29 = A_arbace_a2g_vh_A_const_73; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 any = A_arbace_a2g_vh_class_handles_fn__331000060_A_New_O_O_O(env__4, out__5, n__0); var tmp32 *jrt.Class; A_arbace_a2g_vh_class_handles_fn__331000060_A_Init(); tmp32 = A_arbace_a2g_vh_class_handles_fn__331000060_A_fn_class; tmp30.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil), nd__10_2)
//line :124:1
			seq_331000056__6, chunk_331000057__7, count_331000058__8, i_331000059__9 = seq_331000056__6, chunk_331000057__7, count_331000058__8, lang.Numbers_Unchecked_inc_J__J(i_331000059__9); continue L2 } else { var temp__1927000414__auto____10_2 any; var tmp33 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp33 = A_arbace_a2g_vh_A_const_50; temp__1927000414__auto____10_2 = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()).Invoke_O__O(seq_331000056__6); if jrt.A2g_Truth(temp__1927000414__auto____10_2) { var seq_331000056__11 any = temp__1927000414__auto____10_2; var tmp34 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp34 = A_arbace_a2g_vh_A_const_71; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O__O(seq_331000056__11)) { var c__1927000678__auto____12_2 any; var tmp35 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp35 = A_arbace_a2g_vh_A_const_72; c__1927000678__auto____12_2 = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke_O__O(seq_331000056__11); var tmp36 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp36 = A_arbace_a2g_vh_A_const_79; seq_331000056__6, chunk_331000057__7, count_331000058__8, i_331000059__9 = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()).Invoke_O__O(seq_331000056__11), c__1927000678__auto____12_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____12_2))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var nd__12_2 any; var tmp37 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp37 = A_arbace_a2g_vh_A_const_51; nd__12_2 = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke_O__O(seq_331000056__11)
				var tmp38 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp38 = A_arbace_a2g_vh_A_const_73; var tmp39 lang.IFn = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()); var tmp40 any = A_arbace_a2g_vh_class_handles_fn__331000062_A_New_O_O_O(env__4, out__5, n__0); var tmp41 *jrt.Class; A_arbace_a2g_vh_class_handles_fn__331000062_A_Init(); tmp41 = A_arbace_a2g_vh_class_handles_fn__331000062_A_fn_class; tmp39.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp40, tmp41, nil), nd__12_2)
//line :124:1
				var tmp42 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp42 = A_arbace_a2g_vh_A_const_48; seq_331000056__6, chunk_331000057__7, count_331000058__8, i_331000059__9 = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O__O(seq_331000056__11), nil, 0, 0; continue L2 } } }
//line :111:1
		break L2 }; var tmp43 /*line :114:1*/*lang.Var; A_arbace_a2g_vh_A_Init(); tmp43 = A_arbace_a2g_vh_A_const_9; return lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()).Invoke_O__O(out__5) }




func A_arbace_a2g_vh_class_handles_fn__331000032_A_New_O(p0 any) *A_arbace_a2g_vh_class_handles_fn__331000032_A { A_arbace_a2g_vh_class_handles_fn__331000032_A_Init(); t := &A_arbace_a2g_vh_class_handles_fn__331000032_A{}; t.Ctor_O(p0); return t }
//line :119:1
func (t *A_arbace_a2g_vh_class_handles_fn__331000032_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :119:1
func (t *A_arbace_a2g_vh_class_handles_fn__331000032_A) Invoke_O_O__O(self, x__1 any) any {
	{ var tmp1 any; A_arbace_a2g_vh_A_Init(); tmp1 = A_arbace_a2g_vh_A_const_74; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp3 = A_arbace_a2g_vh_A_const_14; if jrt.A2g_Truth(tmp2.Invoke_O__O(jrt.NN(tmp3).Invoke_O__O(x__1))) { var seq_331000033__2 any; var tmp4 *lang.Var
		A_arbace_a2g_vh_A_Init(); tmp4 = A_arbace_a2g_vh_A_const_50; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp6 = A_arbace_a2g_vh_A_const_75; seq_331000033__2 = tmp5.Invoke_O__O(jrt.NN(tmp6).Invoke_O__O(x__1))
//line :120:1
		var chunk_331000034__3 any; var count_331000035__4 int64 = 0; var i_331000036__5 int64 = 0; L1: for {
			if lang.Numbers_Lt_J_J__Z(i_331000036__5, count_331000035__4) { var vec__331000037__6 any = lang.Indexed_Cast(chunk_331000034__3).Nth_I__O(lang.RT_IntCast_J__I(i_331000036__5)); var b__7 any = lang.RT_Nth_O_I_O__O(vec__331000037__6, lang.RT_IntCast_J__I(0), nil); var init__8 any = lang.RT_Nth_O_I_O__O(vec__331000037__6, lang.RT_IntCast_J__I(1), nil); var tmp7 any; var and__1927000168__auto____9 any; var tmp8 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp8 = A_arbace_a2g_vh_A_const_62; and__1927000168__auto____9 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(b__7); if jrt.A2g_Truth(and__1927000168__auto____9) { var tmp9 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp9 = A_arbace_a2g_vh_A_const_38; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp11 = A_arbace_a2g_vh_A_const_76; tmp7 = tmp10.Invoke_O__O(jrt.NN(tmp11).Invoke_O__O(b__7)) } else { tmp7 = and__1927000168__auto____9 }; if jrt.A2g_Truth(tmp7) {
				var tmp12 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp12 = A_arbace_a2g_vh_A_const_77; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any = t.F_env; var tmp15 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp15 = A_arbace_a2g_vh_A_const_78; var tmp16 any = jrt.NN(tmp15).GetRawRoot__O(); var tmp17 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp17 = A_arbace_a2g_vh_A_const_24; tmp13.Invoke_O_O_O_O__O(tmp14, tmp16, jrt.NN(tmp17).Invoke_O__O(b__7), init__8)
//line :121:1
				seq_331000033__2, chunk_331000034__3, count_331000035__4, i_331000036__5 = seq_331000033__2, chunk_331000034__3, count_331000035__4, lang.Numbers_Unchecked_inc_J__J(i_331000036__5); continue L1 } else { seq_331000033__2, chunk_331000034__3, count_331000035__4, i_331000036__5 = seq_331000033__2, chunk_331000034__3, count_331000035__4, lang.Numbers_Unchecked_inc_J__J(i_331000036__5); continue L1 } } else { var temp__1927000414__auto____6 any; var tmp18 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp18 = A_arbace_a2g_vh_A_const_50; temp__1927000414__auto____6 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(seq_331000033__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_331000033__7 any = temp__1927000414__auto____6; var tmp19 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp19 = A_arbace_a2g_vh_A_const_71; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(seq_331000033__7)) { var c__1927000678__auto____8 any; var tmp20 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp20 = A_arbace_a2g_vh_A_const_72; c__1927000678__auto____8 = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(seq_331000033__7); var tmp21 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp21 = A_arbace_a2g_vh_A_const_79; seq_331000033__2, chunk_331000034__3, count_331000035__4, i_331000036__5 = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(seq_331000033__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__331000040__8 any; var tmp22 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp22 = A_arbace_a2g_vh_A_const_51; vec__331000040__8 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(seq_331000033__7); var b__9 any = lang.RT_Nth_O_I_O__O(vec__331000040__8, lang.RT_IntCast_J__I(0), nil); var init__10 any = lang.RT_Nth_O_I_O__O(vec__331000040__8, lang.RT_IntCast_J__I(1), nil); var tmp23 any; var and__1927000168__auto____11 any; var tmp24 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp24 = A_arbace_a2g_vh_A_const_62; and__1927000168__auto____11 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(b__9); if jrt.A2g_Truth(and__1927000168__auto____11) { var tmp25 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp25 = A_arbace_a2g_vh_A_const_38; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp27 = A_arbace_a2g_vh_A_const_76; tmp23 = tmp26.Invoke_O__O(jrt.NN(tmp27).Invoke_O__O(b__9)) } else { tmp23 = and__1927000168__auto____11 }; if jrt.A2g_Truth(tmp23) {
					var tmp28 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp28 = A_arbace_a2g_vh_A_const_77; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 any = t.F_env; var tmp31 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp31 = A_arbace_a2g_vh_A_const_78; var tmp32 any = jrt.NN(tmp31).GetRawRoot__O(); var tmp33 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp33 = A_arbace_a2g_vh_A_const_24; tmp29.Invoke_O_O_O_O__O(tmp30, tmp32, jrt.NN(tmp33).Invoke_O__O(b__9), init__10)
//line :121:1
					var tmp34 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp34 = A_arbace_a2g_vh_A_const_48; seq_331000033__2, chunk_331000034__3, count_331000035__4, i_331000036__5 = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O__O(seq_331000033__7), nil, 0, 0; continue L1 } else { var tmp35 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp35 = A_arbace_a2g_vh_A_const_48; seq_331000033__2, chunk_331000034__3, count_331000035__4, i_331000036__5 = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke_O__O(seq_331000033__7), nil, 0, 0; continue L1 } } } else { return nil } } } } else {
//line :120:1
						return nil } }
//line :119:1
	panic("a2g: unreachable") }
//line :119:1
func A_arbace_a2g_vh_class_handles_fn__331000044_A_New_O(p0 any) *A_arbace_a2g_vh_class_handles_fn__331000044_A { A_arbace_a2g_vh_class_handles_fn__331000044_A_Init(); t := &A_arbace_a2g_vh_class_handles_fn__331000044_A{}; t.Ctor_O(p0); return t }
//line :119:1
func (t *A_arbace_a2g_vh_class_handles_fn__331000044_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :119:1
func (t *A_arbace_a2g_vh_class_handles_fn__331000044_A) Invoke_O_O__O(self, x__1 any) any {
	{ var tmp1 any; A_arbace_a2g_vh_A_Init(); tmp1 = A_arbace_a2g_vh_A_const_80; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp3 = A_arbace_a2g_vh_A_const_14; if jrt.A2g_Truth(tmp2.Invoke_O__O(jrt.NN(tmp3).Invoke_O__O(x__1))) { var seq_331000045__2 any; var tmp4 *lang.Var
		A_arbace_a2g_vh_A_Init(); tmp4 = A_arbace_a2g_vh_A_const_50; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp6 = A_arbace_a2g_vh_A_const_75; seq_331000045__2 = tmp5.Invoke_O__O(jrt.NN(tmp6).Invoke_O__O(x__1))
//line :120:1
		var chunk_331000046__3 any; var count_331000047__4 int64 = 0; var i_331000048__5 int64 = 0; L1: for {
			if lang.Numbers_Lt_J_J__Z(i_331000048__5, count_331000047__4) { var vec__331000049__6 any = lang.Indexed_Cast(chunk_331000046__3).Nth_I__O(lang.RT_IntCast_J__I(i_331000048__5)); var b__7 any = lang.RT_Nth_O_I_O__O(vec__331000049__6, lang.RT_IntCast_J__I(0), nil); var init__8 any = lang.RT_Nth_O_I_O__O(vec__331000049__6, lang.RT_IntCast_J__I(1), nil); var tmp7 any; var and__1927000168__auto____9 any; var tmp8 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp8 = A_arbace_a2g_vh_A_const_62; and__1927000168__auto____9 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(b__7); if jrt.A2g_Truth(and__1927000168__auto____9) { var tmp9 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp9 = A_arbace_a2g_vh_A_const_38; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp11 = A_arbace_a2g_vh_A_const_76; tmp7 = tmp10.Invoke_O__O(jrt.NN(tmp11).Invoke_O__O(b__7)) } else { tmp7 = and__1927000168__auto____9 }; if jrt.A2g_Truth(tmp7) {
				var tmp12 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp12 = A_arbace_a2g_vh_A_const_77; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any = t.F_env; var tmp15 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp15 = A_arbace_a2g_vh_A_const_78; var tmp16 any = jrt.NN(tmp15).GetRawRoot__O(); var tmp17 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp17 = A_arbace_a2g_vh_A_const_24; tmp13.Invoke_O_O_O_O__O(tmp14, tmp16, jrt.NN(tmp17).Invoke_O__O(b__7), init__8)
//line :121:1
				seq_331000045__2, chunk_331000046__3, count_331000047__4, i_331000048__5 = seq_331000045__2, chunk_331000046__3, count_331000047__4, lang.Numbers_Unchecked_inc_J__J(i_331000048__5); continue L1 } else { seq_331000045__2, chunk_331000046__3, count_331000047__4, i_331000048__5 = seq_331000045__2, chunk_331000046__3, count_331000047__4, lang.Numbers_Unchecked_inc_J__J(i_331000048__5); continue L1 } } else { var temp__1927000414__auto____6 any; var tmp18 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp18 = A_arbace_a2g_vh_A_const_50; temp__1927000414__auto____6 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(seq_331000045__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_331000045__7 any = temp__1927000414__auto____6; var tmp19 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp19 = A_arbace_a2g_vh_A_const_71; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(seq_331000045__7)) { var c__1927000678__auto____8 any; var tmp20 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp20 = A_arbace_a2g_vh_A_const_72; c__1927000678__auto____8 = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(seq_331000045__7); var tmp21 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp21 = A_arbace_a2g_vh_A_const_79; seq_331000045__2, chunk_331000046__3, count_331000047__4, i_331000048__5 = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(seq_331000045__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__331000052__8 any; var tmp22 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp22 = A_arbace_a2g_vh_A_const_51; vec__331000052__8 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(seq_331000045__7); var b__9 any = lang.RT_Nth_O_I_O__O(vec__331000052__8, lang.RT_IntCast_J__I(0), nil); var init__10 any = lang.RT_Nth_O_I_O__O(vec__331000052__8, lang.RT_IntCast_J__I(1), nil); var tmp23 any; var and__1927000168__auto____11 any; var tmp24 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp24 = A_arbace_a2g_vh_A_const_62; and__1927000168__auto____11 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(b__9); if jrt.A2g_Truth(and__1927000168__auto____11) { var tmp25 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp25 = A_arbace_a2g_vh_A_const_38; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp27 = A_arbace_a2g_vh_A_const_76; tmp23 = tmp26.Invoke_O__O(jrt.NN(tmp27).Invoke_O__O(b__9)) } else { tmp23 = and__1927000168__auto____11 }; if jrt.A2g_Truth(tmp23) {
					var tmp28 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp28 = A_arbace_a2g_vh_A_const_77; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 any = t.F_env; var tmp31 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp31 = A_arbace_a2g_vh_A_const_78; var tmp32 any = jrt.NN(tmp31).GetRawRoot__O(); var tmp33 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp33 = A_arbace_a2g_vh_A_const_24; tmp29.Invoke_O_O_O_O__O(tmp30, tmp32, jrt.NN(tmp33).Invoke_O__O(b__9), init__10)
//line :121:1
					var tmp34 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp34 = A_arbace_a2g_vh_A_const_48; seq_331000045__2, chunk_331000046__3, count_331000047__4, i_331000048__5 = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O__O(seq_331000045__7), nil, 0, 0; continue L1 } else { var tmp35 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp35 = A_arbace_a2g_vh_A_const_48; seq_331000045__2, chunk_331000046__3, count_331000047__4, i_331000048__5 = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke_O__O(seq_331000045__7), nil, 0, 0; continue L1 } } } else { return nil } } } } else {
//line :120:1
						return nil } }
//line :119:1
	panic("a2g: unreachable")
}




func A_arbace_a2g_vh_class_handles_fn__331000060_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_vh_class_handles_fn__331000060_A { A_arbace_a2g_vh_class_handles_fn__331000060_A_Init(); t := &A_arbace_a2g_vh_class_handles_fn__331000060_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :125:1
func (t *A_arbace_a2g_vh_class_handles_fn__331000060_A) Ctor_O_O_O(c__env, c__out, c__n any) { t.F_env = c__env; t.F_out = c__out; t.F_n = c__n }
//line :125:1
func (t *A_arbace_a2g_vh_class_handles_fn__331000060_A) Invoke_O_O__O(self, x__1 any) any {
	var tmp1 bool; var and__1927000168__auto____2 bool; var tmp2 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp2 = A_arbace_a2g_vh_A_const_81; var tmp3 any = tmp2.Ref(); var tmp4 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp4 = A_arbace_a2g_vh_A_const_14; and__1927000168__auto____2 = lang.Util_Equiv_O_O__Z(tmp3, jrt.NN(tmp4).Invoke_O__O(x__1)); if and__1927000168__auto____2 { var tmp5 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp5 = A_arbace_a2g_vh_A_const_82; var tmp6 any = jrt.NN(tmp5).GetRawRoot__O(); var tmp7 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp7 = A_arbace_a2g_vh_A_const_44; var tmp8 *lang.Keyword = tmp7; var tmp9 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp9 = A_arbace_a2g_vh_A_const_20; tmp1 = lang.Util_Equiv_O_O__Z(tmp6, jrt.NN(tmp8).Invoke_O__O(jrt.NN(tmp9).Invoke_O__O(x__1))) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { var f__2 any; var tmp10 *lang.Keyword
		A_arbace_a2g_vh_A_Init(); tmp10 = A_arbace_a2g_vh_A_const_20; f__2 = jrt.NN(tmp10).Invoke_O__O(x__1)
//line :126:1
		var o__3 any; var or__1927000174__auto____3 any; var tmp11 *lang.Keyword

		A_arbace_a2g_vh_A_Init(); tmp11 = A_arbace_a2g_vh_A_const_27; or__1927000174__auto____3 = jrt.NN(tmp11).Invoke_O__O(f__2); if jrt.A2g_Truth(or__1927000174__auto____3) { o__3 = or__1927000174__auto____3 } else { var tmp12 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp12 = A_arbace_a2g_vh_A_const_28; o__3 = jrt.NN(tmp12).Invoke_O__O(f__2) }
//line :126:1
		var temp__1927000414__auto____4 any; var tmp13 *lang.Var


		A_arbace_a2g_vh_A_Init(); tmp13 = A_arbace_a2g_vh_A_const_63; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 any = t.F_n; var tmp16 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp16 = A_arbace_a2g_vh_A_const_31; var tmp17 any = jrt.NN(tmp16).Invoke_O__O(x__1); var tmp18 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp18 = A_arbace_a2g_vh_A_const_9; temp__1927000414__auto____4 = tmp14.Invoke_O_O_O__O(tmp15, tmp17, lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(t.F_env)); if jrt.A2g_Truth(temp__1927000414__auto____4) { var spec__5 any = temp__1927000414__auto____4; var tmp19 *lang.Var
			A_arbace_a2g_vh_A_Init(); tmp19 = A_arbace_a2g_vh_A_const_77; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any = t.F_out; var tmp22 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp22 = A_arbace_a2g_vh_A_const_78; var tmp23 any = jrt.NN(tmp22).GetRawRoot__O(); var tmp24 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp24 = A_arbace_a2g_vh_A_const_21; return tmp20.Invoke_O_O_O_O__O(tmp21, tmp23, lang.Tuple_Create_O_O__IPersistentVector(o__3, jrt.NN(tmp24).Invoke_O__O(f__2)), spec__5) } else {
//line :129:1
				return nil } } else {
//line :126:1
					return nil } }
//line :125:1
func A_arbace_a2g_vh_class_handles_fn__331000062_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_vh_class_handles_fn__331000062_A { A_arbace_a2g_vh_class_handles_fn__331000062_A_Init(); t := &A_arbace_a2g_vh_class_handles_fn__331000062_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :125:1
func (t *A_arbace_a2g_vh_class_handles_fn__331000062_A) Ctor_O_O_O(c__env, c__out, c__n any) { t.F_env = c__env; t.F_out = c__out; t.F_n = c__n }
//line :125:1
func (t *A_arbace_a2g_vh_class_handles_fn__331000062_A) Invoke_O_O__O(self, x__1 any) any {
	var tmp1 bool; var and__1927000168__auto____2 bool; var tmp2 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp2 = A_arbace_a2g_vh_A_const_81; var tmp3 any = tmp2.Ref(); var tmp4 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp4 = A_arbace_a2g_vh_A_const_14; and__1927000168__auto____2 = lang.Util_Equiv_O_O__Z(tmp3, jrt.NN(tmp4).Invoke_O__O(x__1)); if and__1927000168__auto____2 { var tmp5 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp5 = A_arbace_a2g_vh_A_const_82; var tmp6 any = jrt.NN(tmp5).GetRawRoot__O(); var tmp7 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp7 = A_arbace_a2g_vh_A_const_44; var tmp8 *lang.Keyword = tmp7; var tmp9 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp9 = A_arbace_a2g_vh_A_const_20; tmp1 = lang.Util_Equiv_O_O__Z(tmp6, jrt.NN(tmp8).Invoke_O__O(jrt.NN(tmp9).Invoke_O__O(x__1))) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { var f__2 any; var tmp10 *lang.Keyword
		A_arbace_a2g_vh_A_Init(); tmp10 = A_arbace_a2g_vh_A_const_20; f__2 = jrt.NN(tmp10).Invoke_O__O(x__1)
//line :126:1
		var o__3 any; var or__1927000174__auto____3 any; var tmp11 *lang.Keyword

		A_arbace_a2g_vh_A_Init(); tmp11 = A_arbace_a2g_vh_A_const_27; or__1927000174__auto____3 = jrt.NN(tmp11).Invoke_O__O(f__2); if jrt.A2g_Truth(or__1927000174__auto____3) { o__3 = or__1927000174__auto____3 } else { var tmp12 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp12 = A_arbace_a2g_vh_A_const_28; o__3 = jrt.NN(tmp12).Invoke_O__O(f__2) }
//line :126:1
		var temp__1927000414__auto____4 any; var tmp13 *lang.Var


		A_arbace_a2g_vh_A_Init(); tmp13 = A_arbace_a2g_vh_A_const_63; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 any = t.F_n; var tmp16 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp16 = A_arbace_a2g_vh_A_const_31; var tmp17 any = jrt.NN(tmp16).Invoke_O__O(x__1); var tmp18 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp18 = A_arbace_a2g_vh_A_const_9; temp__1927000414__auto____4 = tmp14.Invoke_O_O_O__O(tmp15, tmp17, lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(t.F_env)); if jrt.A2g_Truth(temp__1927000414__auto____4) { var spec__5 any = temp__1927000414__auto____4; var tmp19 *lang.Var
			A_arbace_a2g_vh_A_Init(); tmp19 = A_arbace_a2g_vh_A_const_77; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any = t.F_out; var tmp22 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp22 = A_arbace_a2g_vh_A_const_78; var tmp23 any = jrt.NN(tmp22).GetRawRoot__O(); var tmp24 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp24 = A_arbace_a2g_vh_A_const_21; return tmp20.Invoke_O_O_O_O__O(tmp21, tmp23, lang.Tuple_Create_O_O__IPersistentVector(o__3, jrt.NN(tmp24).Invoke_O__O(f__2)), spec__5) } else {
//line :129:1
				return nil } } else {
//line :126:1
					return nil
				}
}





func A_arbace_a2g_vh_handles_A_New() *A_arbace_a2g_vh_handles_A { A_arbace_a2g_vh_handles_A_Init(); t := &A_arbace_a2g_vh_handles_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_a2g_vh_handles_A) Ctor() {}
//line :134:1
func (t *A_arbace_a2g_vh_handles_A) Invoke_O_O__O(self, class_names__0 any) any { var hs__2 any; var tmp1 *lang.Var;



	A_arbace_a2g_vh_A_Init(); tmp1 = A_arbace_a2g_vh_A_const_83; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; var tmp4 any = tmp3.Ref(); var tmp5 any; var iter__1927001039__auto____2 any; var tmp6 any = A_arbace_a2g_vh_handles_iter__331000066__331000072_A_New(); var tmp7 *jrt.Class; A_arbace_a2g_vh_handles_iter__331000066__331000072_A_Init(); tmp7 = A_arbace_a2g_vh_handles_iter__331000066__331000072_A_fn_class; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); tmp5 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(class_names__0); hs__2 = tmp2.Invoke_O_O__O(tmp4, tmp5); var tmp8 /*line :134:1*/*lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp8 = A_arbace_a2g_vh_A_const_84; var tmp9 any = tmp8.Ref(); var tmp10 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp10 = A_arbace_a2g_vh_A_const_36; var tmp11 any = tmp10.Ref(); var tmp12 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp12 = A_arbace_a2g_vh_A_const_85; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any; var iter__1927001039__auto____3 any; var tmp15 any = A_arbace_a2g_vh_handles_iter__331000086__331000090_A_New(); var tmp16 *jrt.Class;









	A_arbace_a2g_vh_handles_iter__331000086__331000090_A_Init(); tmp16 = A_arbace_a2g_vh_handles_iter__331000086__331000090_A_fn_class; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); tmp14 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(hs__2); return /*line :134:1*/ lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp9, hs__2, tmp11, tmp13.Invoke_O__O(tmp14))) }



func A_arbace_a2g_vh_handles_iter__331000066__331000072_A_New() *A_arbace_a2g_vh_handles_iter__331000066__331000072_A { A_arbace_a2g_vh_handles_iter__331000066__331000072_A_Init(); t := &A_arbace_a2g_vh_handles_iter__331000066__331000072_A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_A) Ctor() {}
//line :138:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_A) Invoke_O_O__O(self, s__331000067__1 any) any { var tmp1 any = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_New_O_O(self, s__331000067__1); var tmp2 *jrt.Class; A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_Init(); tmp2 = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :138:1
func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_New_O_O(p0, p1 any) *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A { A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_Init(); t := &A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A{}; t.Ctor_O_O(p0, p1); return t }
//line :138:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A) Ctor_O_O(c__iter__331000066, c__s__331000067 any) { t.F_iter__331000066 = c__iter__331000066; t.F_s__331000067 = c__s__331000067 }
//line :138:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A) Invoke_O__O(self any) any { { var s__331000067__1 any; var t_ any = t.F_s__331000067; t.F_s__331000067 = nil; s__331000067__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp1 = A_arbace_a2g_vh_A_const_50; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__331000067__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var n__4 any; var tmp2 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp2 = A_arbace_a2g_vh_A_const_51; n__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var d__5 any; var tmp3 *lang.Var
													A_arbace_a2g_vh_A_Init(); tmp3 = A_arbace_a2g_vh_A_const_34; d__5 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(n__4)
//line :138:1
	var tmp4 any
	var and__1927000168__auto____6 any = d__5
	if jrt.A2g_Truth(and__1927000168__auto____6) { var tmp5 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp5 = A_arbace_a2g_vh_A_const_35; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_New(); var tmp8 *jrt.Class; A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_Init(); tmp8 = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_fn_class; var tmp9 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp10 = A_arbace_a2g_vh_A_const_36; tmp4 = tmp6.Invoke_O_O__O(tmp9, jrt.NN(tmp10).Invoke_O__O(d__5)) } else { tmp4 = and__1927000168__auto____6 }
//line :138:1
	if jrt.A2g_Truth(tmp4) { var iterys__1927001035__auto____6 any; var tmp11 any = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_New(); var tmp12 *jrt.Class; A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_Init(); tmp12 = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_fn_class; iterys__1927001035__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var fs__1927001036__auto____7 any; var tmp13 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp13 = A_arbace_a2g_vh_A_const_50; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____6); var tmp16 any = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_New_O(n__4); var tmp17 *jrt.Class; A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_Init(); tmp17 = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_fn_class; fs__1927001036__auto____7 = tmp14.Invoke_O__O(tmp15.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil).Invoke__O())); if jrt.A2g_Truth(fs__1927001036__auto____7) { var tmp18 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp18 = A_arbace_a2g_vh_A_const_92; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 lang.IFn = lang.IFn_Cast(t.F_iter__331000066); var tmp21 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp21 = A_arbace_a2g_vh_A_const_91; return tmp19.Invoke_O_O__O(fs__1927001036__auto____7, tmp20.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(s__331000067__1))) } else { var tmp22 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp22 = A_arbace_a2g_vh_A_const_91; s__331000067__1 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(s__331000067__1); continue L1 } } else { var tmp23 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp23 = A_arbace_a2g_vh_A_const_91; s__331000067__1 = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(s__331000067__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :138:1
func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_New() *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A { A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_Init(); t := &A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A) Ctor() {}
//line :138:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A) Invoke_O_O__O(self, s__331000069__1 any) any { var tmp1 any = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_New_O_O(s__331000069__1, self); var tmp2 *jrt.Class; A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_Init(); tmp2 = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :138:1
func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_New_O_O(p0, p1 any) *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A { A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_Init(); t := &A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A{}; t.Ctor_O_O(p0, p1); return t }
//line :138:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A) Ctor_O_O(c__s__331000069, c__iter__331000068 any) { t.F_s__331000069 = c__s__331000069; t.F_iter__331000068 = c__iter__331000068 }
//line :138:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A) Invoke_O__O(self any) any { { var s__331000069__1 any; var t_ any = t.F_s__331000069; t.F_s__331000069 = nil; s__331000069__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp1 = A_arbace_a2g_vh_A_const_50; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__331000069__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__331000069__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp2 = A_arbace_a2g_vh_A_const_71; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__331000069__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp3 = A_arbace_a2g_vh_A_const_72; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__331000069__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__331000071__6 any; var tmp4 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp4 = A_arbace_a2g_vh_A_const_86; b__331000071__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_New_O_I_O(b__331000071__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_Init(); tmp6 = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp7 = A_arbace_a2g_vh_A_const_88; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp9 = A_arbace_a2g_vh_A_const_90; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__331000071__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__331000068); var tmp12 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp12 = A_arbace_a2g_vh_A_const_79; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__331000069__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp13 = A_arbace_a2g_vh_A_const_88; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp15 = A_arbace_a2g_vh_A_const_90; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__331000071__6), nil) } } else { var e__4 any; var tmp16 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp16 = A_arbace_a2g_vh_A_const_51; e__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__331000069__3); var tmp17 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp17 = A_arbace_a2g_vh_A_const_89; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 lang.IFn = lang.IFn_Cast(t.F_iter__331000068); var tmp20 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp20 = A_arbace_a2g_vh_A_const_91; return tmp18.Invoke_O_O__O(e__4, tmp19.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(s__331000069__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :138:1
func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A { A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_Init(); t := &A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :138:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A) Ctor_O_I_O(c__b__331000071 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__331000071 = c__b__331000071; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :138:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A) Invoke_O__O(self any) any { { var i__331000070__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__331000070__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__331000070__1)); var tmp2 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp2 = A_arbace_a2g_vh_A_const_87; lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(t.F_b__331000071, e__2); i__331000070__1 = lang.Numbers_Unchecked_inc_J__J(i__331000070__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_New() *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A { A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_Init(); t := &A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A{}; t.Ctor(); return t }
//line :140:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A) Ctor() {}
//line :140:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A) Invoke_O_O__O(self, p1__331000065_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp1 = A_arbace_a2g_vh_A_const_82; var tmp2 any = jrt.NN(tmp1).GetRawRoot__O(); var tmp3 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp3 = A_arbace_a2g_vh_A_const_44; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp2, jrt.NN(tmp3).Invoke_O__O(p1__331000065_SHARP___1))).Ref() }
func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_New_O(p0 any) *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A { A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_Init(); t := &A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A{}; t.Ctor_O(p0); return t }
//line :141:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :141:1
func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp2 = A_arbace_a2g_vh_A_const_93; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; var t_ any = t.F_n; t.F_n = nil; tmp4 = t_; tmp1 = tmp3.Invoke_O__O(tmp4) }; return nil }(); if tmp5 != nil { if true { var ___3 jrt.Throwable_I = tmp5; _ = ___3; tmp1 = nil } }; return tmp1 }


func A_arbace_a2g_vh_handles_iter__331000086__331000090_A_New() *A_arbace_a2g_vh_handles_iter__331000086__331000090_A { A_arbace_a2g_vh_handles_iter__331000086__331000090_A_Init(); t := &A_arbace_a2g_vh_handles_iter__331000086__331000090_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_A) Ctor() {}
//line :144:1
func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_A) Invoke_O_O__O(self, s__331000087__1 any) any { var tmp1 any = A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_New_O_O(self, s__331000087__1); var tmp2 *jrt.Class; A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_Init(); tmp2 = A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :144:1
func A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_New_O_O(p0, p1 any) *A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A { A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_Init(); t := &A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A{}; t.Ctor_O_O(p0, p1); return t }
//line :144:1
func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A) Ctor_O_O(c__iter__331000086, c__s__331000087 any) { t.F_iter__331000086 = c__iter__331000086; t.F_s__331000087 = c__s__331000087 }
//line :144:1
func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A) Invoke_O__O(self any) any { { var s__331000087__1 any; var t_ any = t.F_s__331000087; t.F_s__331000087 = nil; s__331000087__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp1 = A_arbace_a2g_vh_A_const_50; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__331000087__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__331000087__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp2 = A_arbace_a2g_vh_A_const_71; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__331000087__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp3 = A_arbace_a2g_vh_A_const_72; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__331000087__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__331000089__6 any; var tmp4 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp4 = A_arbace_a2g_vh_A_const_86; b__331000089__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_New_O_I_O(b__331000089__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_Init(); tmp6 = A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp7 = A_arbace_a2g_vh_A_const_88; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp9 = A_arbace_a2g_vh_A_const_90; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__331000089__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__331000086); var tmp12 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp12 = A_arbace_a2g_vh_A_const_79; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__331000087__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp13 = A_arbace_a2g_vh_A_const_88; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp15 = A_arbace_a2g_vh_A_const_90; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__331000089__6), nil) } } else { var vec__331000097__4 any; var tmp16 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp16 = A_arbace_a2g_vh_A_const_51; vec__331000097__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__331000087__3); var ___5 any = lang.RT_Nth_O_I_O__O(vec__331000097__4, lang.RT_IntCast_J__I(0), nil); var s__6 any = lang.RT_Nth_O_I_O__O(vec__331000097__4, lang.RT_IntCast_J__I(1), nil); var tmp17 *lang.Keyword; _ = ___5; A_arbace_a2g_vh_A_Init(); tmp17 = A_arbace_a2g_vh_A_const_20; var tmp18 any = tmp17.Ref(); var tmp19 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp19 = A_arbace_a2g_vh_A_const_45; if lang.Util_Equiv_O_O__Z(tmp18, jrt.NN(tmp19).Invoke_O__O(s__6)) { var tmp20 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp20 = A_arbace_a2g_vh_A_const_89; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp22 = A_arbace_a2g_vh_A_const_18; var tmp23 any = jrt.NN(tmp22).Invoke_O__O(s__6); var tmp24 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp24 = A_arbace_a2g_vh_A_const_21; var tmp25 any = lang.Tuple_Create_O_O__IPersistentVector(tmp23, jrt.NN(tmp24).Invoke_O__O(s__6)); var tmp26 lang.IFn = lang.IFn_Cast(t.F_iter__331000086); var tmp27 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp27 = A_arbace_a2g_vh_A_const_91; return tmp21.Invoke_O_O__O(tmp25, tmp26.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(s__331000087__3))) } else { var tmp28 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp28 = A_arbace_a2g_vh_A_const_91; s__331000087__1 = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(s__331000087__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :144:1
func A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A { A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_Init(); t := &A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :144:1
func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A) Ctor_O_I_O(c__b__331000089 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__331000089 = c__b__331000089; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :144:1
func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A) Invoke_O__O(self any) any { { var i__331000088__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__331000088__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__331000093__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__331000088__1)); var ___3 any = lang.RT_Nth_O_I_O__O(vec__331000093__2, lang.RT_IntCast_J__I(0), nil); var s__4 any = lang.RT_Nth_O_I_O__O(vec__331000093__2, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Keyword; _ = ___3; A_arbace_a2g_vh_A_Init(); tmp2 = A_arbace_a2g_vh_A_const_20; var tmp3 any = tmp2.Ref(); var tmp4 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp4 = A_arbace_a2g_vh_A_const_45; if lang.Util_Equiv_O_O__Z(tmp3, jrt.NN(tmp4).Invoke_O__O(s__4)) { var tmp5 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp5 = A_arbace_a2g_vh_A_const_87; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any = t.F_b__331000089; var tmp8 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp8 = A_arbace_a2g_vh_A_const_18; var tmp9 any = jrt.NN(tmp8).Invoke_O__O(s__4); var tmp10 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp10 = A_arbace_a2g_vh_A_const_21; tmp6.Invoke_O_O__O(tmp7, lang.Tuple_Create_O_O__IPersistentVector(tmp9, jrt.NN(tmp10).Invoke_O__O(s__4))); i__331000088__1 = lang.Numbers_Unchecked_inc_J__J(i__331000088__1); continue L1 } else { i__331000088__1 = lang.Numbers_Unchecked_inc_J__J(i__331000088__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }






func A_arbace_a2g_vh_mode_A_New() *A_arbace_a2g_vh_mode_A { A_arbace_a2g_vh_mode_A_Init(); t := &A_arbace_a2g_vh_mode_A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_a2g_vh_mode_A) Ctor() {}
//line :151:1
func (t *A_arbace_a2g_vh_mode_A) Invoke_O_O__O(self, name__0 any) any {


	var tmp1 any; A_arbace_a2g_vh_A_Init(); tmp1 = A_arbace_a2g_vh_A_const_94; if jrt.A2g_Truth(lang.IFn_Cast(tmp1).Invoke_O__O(name__0)) { A_arbace_a2g_vh_A_Init(); return A_arbace_a2g_vh_A_const_95.Ref() } else { var tmp2 any; A_arbace_a2g_vh_A_Init(); tmp2 = A_arbace_a2g_vh_A_const_96; if jrt.A2g_Truth(lang.IFn_Cast(tmp2).Invoke_O__O(name__0)) { A_arbace_a2g_vh_A_Init(); return A_arbace_a2g_vh_A_const_97.Ref() } else { var tmp3 any; A_arbace_a2g_vh_A_Init(); tmp3 = A_arbace_a2g_vh_A_const_98; if jrt.A2g_Truth(lang.IFn_Cast(tmp3).Invoke_O__O(name__0)) { A_arbace_a2g_vh_A_Init(); return A_arbace_a2g_vh_A_const_99.Ref() } else { var tmp4 any; A_arbace_a2g_vh_A_Init(); tmp4 = A_arbace_a2g_vh_A_const_100; if jrt.A2g_Truth(lang.IFn_Cast(tmp4).Invoke_O__O(name__0)) { A_arbace_a2g_vh_A_Init(); return A_arbace_a2g_vh_A_const_101.Ref() } else { var tmp5 any; A_arbace_a2g_vh_A_Init(); tmp5 = A_arbace_a2g_vh_A_const_102; if jrt.A2g_Truth(lang.IFn_Cast(tmp5).Invoke_O__O(name__0)) { A_arbace_a2g_vh_A_Init(); return A_arbace_a2g_vh_A_const_103.Ref() } else { var tmp6 any; A_arbace_a2g_vh_A_Init(); tmp6 = A_arbace_a2g_vh_A_const_104; if jrt.A2g_Truth(lang.IFn_Cast(tmp6).Invoke_O__O(name__0)) { A_arbace_a2g_vh_A_Init(); return A_arbace_a2g_vh_A_const_105.Ref() } else { var tmp7 any; A_arbace_a2g_vh_A_Init(); tmp7 = A_arbace_a2g_vh_A_const_106; if jrt.A2g_Truth(lang.IFn_Cast(tmp7).Invoke_O__O(name__0)) { A_arbace_a2g_vh_A_Init(); return A_arbace_a2g_vh_A_const_107.Ref() } else { var tmp8 any; A_arbace_a2g_vh_A_Init(); tmp8 = A_arbace_a2g_vh_A_const_108; if jrt.A2g_Truth(lang.IFn_Cast(tmp8).Invoke_O__O(name__0)) { A_arbace_a2g_vh_A_Init(); return A_arbace_a2g_vh_A_const_109.Ref() } else { var tmp9 any; A_arbace_a2g_vh_A_Init(); tmp9 = A_arbace_a2g_vh_A_const_110; if jrt.A2g_Truth(lang.IFn_Cast(tmp9).Invoke_O__O(name__0)) { A_arbace_a2g_vh_A_Init(); return A_arbace_a2g_vh_A_const_111.Ref() } else { var tmp10 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp10 = A_arbace_a2g_vh_A_const_64; if tmp10 != nil { return nil } else { return nil
	}
	}
	}
	}
	}
	}
	}
	}
	}
	}
}

func A_arbace_a2g_vh_fence_QMARK__A_New() *A_arbace_a2g_vh_fence_QMARK__A { A_arbace_a2g_vh_fence_QMARK__A_Init(); t := &A_arbace_a2g_vh_fence_QMARK__A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_a2g_vh_fence_QMARK__A) Ctor() {}
//line :167:1
func (t *A_arbace_a2g_vh_fence_QMARK__A) Invoke_O_O__O(self, node__0 any) any { var and__1927000168__auto____2 bool; var tmp1 *lang.Keyword;
										A_arbace_a2g_vh_A_Init(); tmp1 = A_arbace_a2g_vh_A_const_47; var tmp2 any = tmp1.Ref(); var tmp3 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp3 = A_arbace_a2g_vh_A_const_14; and__1927000168__auto____2 = lang.Util_Equiv_O_O__Z(tmp2, jrt.NN(tmp3).Invoke_O__O(node__0)); if and__1927000168__auto____2 { var and__1927000168__auto____3 bool; var tmp4 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp4 = A_arbace_a2g_vh_A_const_53; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp6 = A_arbace_a2g_vh_A_const_45; and__1927000168__auto____3 = lang.Util_Equiv_O_O__Z(tmp5, jrt.NN(tmp6).Invoke_O__O(node__0)); if and__1927000168__auto____3 { var and__1927000168__auto____4 bool; var tmp7 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp7 = A_arbace_a2g_vh_A_const_59; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp9 = A_arbace_a2g_vh_A_const_28; and__1927000168__auto____4 = lang.Util_Equiv_O_O__Z(tmp8, jrt.NN(tmp9).Invoke_O__O(node__0)); if and__1927000168__auto____4 { var tmp10 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp10 = A_arbace_a2g_vh_A_const_112; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp12 = A_arbace_a2g_vh_A_const_21; return tmp11.Invoke_O__O(jrt.NN(tmp12).Invoke_O__O(node__0)) } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() } }

func A_arbace_a2g_vh_op_handle_A_New() *A_arbace_a2g_vh_op_handle_A { A_arbace_a2g_vh_op_handle_A_Init(); t := &A_arbace_a2g_vh_op_handle_A{}; t.Ctor(); return t }
//line :170:1
func (t *A_arbace_a2g_vh_op_handle_A) Ctor() {}
//line :170:1
func (t *A_arbace_a2g_vh_op_handle_A) Invoke_O_O_O__O(self, hs__0, node__1 any) any {



	var tmp1 any; var and__1927000168__auto____3 bool; var tmp2 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp2 = A_arbace_a2g_vh_A_const_47; var tmp3 any = tmp2.Ref(); var tmp4 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp4 = A_arbace_a2g_vh_A_const_14; and__1927000168__auto____3 = lang.Util_Equiv_O_O__Z(tmp3, jrt.NN(tmp4).Invoke_O__O(node__1)); if and__1927000168__auto____3 { var and__1927000168__auto____4 bool; var tmp5 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp5 = A_arbace_a2g_vh_A_const_59; var tmp6 any = jrt.NN(tmp5).GetRawRoot__O(); var tmp7 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp7 = A_arbace_a2g_vh_A_const_28; and__1927000168__auto____4 = lang.Util_Equiv_O_O__Z(tmp6, jrt.NN(tmp7).Invoke_O__O(node__1)); if and__1927000168__auto____4 { var tmp8 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp8 = A_arbace_a2g_vh_A_const_113; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp10 = A_arbace_a2g_vh_A_const_53; var tmp11 any = tmp10.Ref(); var tmp12 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp12 = A_arbace_a2g_vh_A_const_45; tmp1 = tmp9.Invoke_O_O__O(tmp11, jrt.NN(tmp12).Invoke_O__O(node__1)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }; if jrt.A2g_Truth(tmp1) { var tg__3 any; var tmp13 *lang.Var
		A_arbace_a2g_vh_A_Init(); tmp13 = A_arbace_a2g_vh_A_const_13; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp15 = A_arbace_a2g_vh_A_const_67; tg__3 = tmp14.Invoke_O__O(jrt.NN(tmp15).Invoke_O__O(node__1))
		var tmp16 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp16 = A_arbace_a2g_vh_A_const_19; var tmp17 any = tmp16.Ref(); var tmp18 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp18 = A_arbace_a2g_vh_A_const_14; if lang.Util_Equiv_O_O__Z(tmp17, jrt.NN(tmp18).Invoke_O__O(tg__3)) { var f__4 any; var tmp19 *lang.Keyword
			A_arbace_a2g_vh_A_Init(); tmp19 = A_arbace_a2g_vh_A_const_20; f__4 = jrt.NN(tmp19).Invoke_O__O(tg__3)
//line :176:1
			var spec__5 any; var tmp20 any; var or__1927000174__auto____5 any; var tmp21 *lang.Keyword

			A_arbace_a2g_vh_A_Init(); tmp21 = A_arbace_a2g_vh_A_const_27; or__1927000174__auto____5 = jrt.NN(tmp21).Invoke_O__O(f__4); if jrt.A2g_Truth(or__1927000174__auto____5) { tmp20 = or__1927000174__auto____5 } else { var tmp22 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp22 = A_arbace_a2g_vh_A_const_28; tmp20 = jrt.NN(tmp22).Invoke_O__O(f__4) }; var tmp23 any = tmp20; var tmp24 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp24 = A_arbace_a2g_vh_A_const_21; spec__5 = lang.RT_Get_O_O__O(hs__0, lang.Tuple_Create_O_O__IPersistentVector(tmp23, jrt.NN(tmp24).Invoke_O__O(f__4)))
//line :176:1
			var m__6 any; var tmp25 *lang.Var


			A_arbace_a2g_vh_A_Init(); tmp25 = A_arbace_a2g_vh_A_const_114; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp27 = A_arbace_a2g_vh_A_const_21; m__6 = tmp26.Invoke_O__O(jrt.NN(tmp27).Invoke_O__O(node__1))
			var tmp28 any; var and__1927000168__auto____7 any = spec__5; if jrt.A2g_Truth(and__1927000168__auto____7) { tmp28 = m__6 } else { tmp28 = and__1927000168__auto____7 }; if jrt.A2g_Truth(tmp28) { var tmp29 *lang.Var; A_arbace_a2g_vh_A_Init(); tmp29 = A_arbace_a2g_vh_A_const_78; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Keyword; A_arbace_a2g_vh_A_Init(); tmp31 = A_arbace_a2g_vh_A_const_115; return tmp30.Invoke_O_O_O__O(spec__5, tmp31.Ref(), m__6) } else { return nil } } else {
//line :176:1
				return nil } } else {
//line :174:1
					return nil
				}
}




















































type A_arbace_a2g_vh_A struct{ jrt.Object }

var A_arbace_a2g_vh_A_const_0 *lang.Var

var A_arbace_a2g_vh_A_const_1 *lang.Var

var A_arbace_a2g_vh_A_const_2 any

var A_arbace_a2g_vh_A_const_3 any

var A_arbace_a2g_vh_A_const_4 any

var A_arbace_a2g_vh_A_const_5 any

var A_arbace_a2g_vh_A_const_6 any

var A_arbace_a2g_vh_A_const_7 any

var A_arbace_a2g_vh_A_const_8 *lang.Var

var A_arbace_a2g_vh_A_const_9 *lang.Var

var A_arbace_a2g_vh_A_const_10 *lang.Var

var A_arbace_a2g_vh_A_const_11 any

var A_arbace_a2g_vh_A_const_12 *lang.Var

var A_arbace_a2g_vh_A_const_13 *lang.Var

var A_arbace_a2g_vh_A_const_14 *lang.Keyword

var A_arbace_a2g_vh_A_const_15 *lang.Keyword

var A_arbace_a2g_vh_A_const_16 *lang.Var

var A_arbace_a2g_vh_A_const_17 *lang.Keyword

var A_arbace_a2g_vh_A_const_18 *lang.Keyword

var A_arbace_a2g_vh_A_const_19 *lang.Keyword

var A_arbace_a2g_vh_A_const_20 *lang.Keyword

var A_arbace_a2g_vh_A_const_21 *lang.Keyword

var A_arbace_a2g_vh_A_const_22 *lang.Var

var A_arbace_a2g_vh_A_const_23 *lang.Keyword

var A_arbace_a2g_vh_A_const_24 *lang.Keyword

var A_arbace_a2g_vh_A_const_25 *lang.Keyword

var A_arbace_a2g_vh_A_const_26 *lang.Keyword

var A_arbace_a2g_vh_A_const_27 *lang.Keyword

var A_arbace_a2g_vh_A_const_28 *lang.Keyword

var A_arbace_a2g_vh_A_const_29 *lang.Keyword

var A_arbace_a2g_vh_A_const_30 *lang.Var

var A_arbace_a2g_vh_A_const_31 *lang.Keyword

var A_arbace_a2g_vh_A_const_32 any

var A_arbace_a2g_vh_A_const_33 *lang.Var

var A_arbace_a2g_vh_A_const_34 *lang.Var

var A_arbace_a2g_vh_A_const_35 *lang.Var

var A_arbace_a2g_vh_A_const_36 *lang.Keyword

var A_arbace_a2g_vh_A_const_37 *lang.Keyword

var A_arbace_a2g_vh_A_const_38 *lang.Var

var A_arbace_a2g_vh_A_const_39 *lang.Keyword

var A_arbace_a2g_vh_A_const_40 any

var A_arbace_a2g_vh_A_const_41 *lang.Var

var A_arbace_a2g_vh_A_const_42 *lang.Var

var A_arbace_a2g_vh_A_const_43 *lang.Var

var A_arbace_a2g_vh_A_const_44 *lang.Keyword

var A_arbace_a2g_vh_A_const_45 *lang.Keyword

var A_arbace_a2g_vh_A_const_46 *lang.Var

var A_arbace_a2g_vh_A_const_47 *lang.Keyword

var A_arbace_a2g_vh_A_const_48 *lang.Var

var A_arbace_a2g_vh_A_const_49 *lang.Var

var A_arbace_a2g_vh_A_const_50 *lang.Var

var A_arbace_a2g_vh_A_const_51 *lang.Var

var A_arbace_a2g_vh_A_const_52 *lang.Keyword

var A_arbace_a2g_vh_A_const_53 *lang.Keyword

var A_arbace_a2g_vh_A_const_54 *lang.Var

var A_arbace_a2g_vh_A_const_55 *lang.Keyword

var A_arbace_a2g_vh_A_const_56 any

var A_arbace_a2g_vh_A_const_57 *lang.Keyword

var A_arbace_a2g_vh_A_const_58 *lang.Keyword

var A_arbace_a2g_vh_A_const_59 *lang.Var

var A_arbace_a2g_vh_A_const_60 any

var A_arbace_a2g_vh_A_const_61 *lang.Var

var A_arbace_a2g_vh_A_const_62 *lang.Var

var A_arbace_a2g_vh_A_const_63 *lang.Var

var A_arbace_a2g_vh_A_const_64 *lang.Keyword

var A_arbace_a2g_vh_A_const_65 *lang.Var

var A_arbace_a2g_vh_A_const_66 *lang.Var

var A_arbace_a2g_vh_A_const_67 *lang.Keyword

var A_arbace_a2g_vh_A_const_68 *lang.Keyword

var A_arbace_a2g_vh_A_const_69 *lang.Var

var A_arbace_a2g_vh_A_const_70 *lang.Keyword

var A_arbace_a2g_vh_A_const_71 *lang.Var

var A_arbace_a2g_vh_A_const_72 *lang.Var

var A_arbace_a2g_vh_A_const_73 *lang.Var

var A_arbace_a2g_vh_A_const_74 any

var A_arbace_a2g_vh_A_const_75 *lang.Keyword

var A_arbace_a2g_vh_A_const_76 *lang.Keyword

var A_arbace_a2g_vh_A_const_77 *lang.Var

var A_arbace_a2g_vh_A_const_78 *lang.Var

var A_arbace_a2g_vh_A_const_79 *lang.Var

var A_arbace_a2g_vh_A_const_80 any

var A_arbace_a2g_vh_A_const_81 *lang.Keyword

var A_arbace_a2g_vh_A_const_82 *lang.Var

var A_arbace_a2g_vh_A_const_83 *lang.Var

var A_arbace_a2g_vh_A_const_84 *lang.Keyword

var A_arbace_a2g_vh_A_const_85 *lang.Var

var A_arbace_a2g_vh_A_const_86 *lang.Var

var A_arbace_a2g_vh_A_const_87 *lang.Var

var A_arbace_a2g_vh_A_const_88 *lang.Var

var A_arbace_a2g_vh_A_const_89 *lang.Var

var A_arbace_a2g_vh_A_const_90 *lang.Var

var A_arbace_a2g_vh_A_const_91 *lang.Var

var A_arbace_a2g_vh_A_const_92 *lang.Var

var A_arbace_a2g_vh_A_const_93 *lang.Var

var A_arbace_a2g_vh_A_const_94 any

var A_arbace_a2g_vh_A_const_95 *lang.Keyword

var A_arbace_a2g_vh_A_const_96 any

var A_arbace_a2g_vh_A_const_97 *lang.Keyword

var A_arbace_a2g_vh_A_const_98 any

var A_arbace_a2g_vh_A_const_99 *lang.Keyword

var A_arbace_a2g_vh_A_const_100 any

var A_arbace_a2g_vh_A_const_101 *lang.Keyword

var A_arbace_a2g_vh_A_const_102 any

var A_arbace_a2g_vh_A_const_103 *lang.Keyword

var A_arbace_a2g_vh_A_const_104 any

var A_arbace_a2g_vh_A_const_105 *lang.Keyword

var A_arbace_a2g_vh_A_const_106 any

var A_arbace_a2g_vh_A_const_107 *lang.Keyword

var A_arbace_a2g_vh_A_const_108 any

var A_arbace_a2g_vh_A_const_109 *lang.Keyword

var A_arbace_a2g_vh_A_const_110 any

var A_arbace_a2g_vh_A_const_111 *lang.Keyword

var A_arbace_a2g_vh_A_const_112 *lang.Var

var A_arbace_a2g_vh_A_const_113 *lang.Var

var A_arbace_a2g_vh_A_const_114 *lang.Var

var A_arbace_a2g_vh_A_const_115 *lang.Keyword

var A_arbace_a2g_vh_A_init jrt.ClassInit

func A_arbace_a2g_vh_A_Init() { if !A_arbace_a2g_vh_A_init.Done() { A_arbace_a2g_vh_A_init.Run(A_arbace_a2g_vh_A_clinit) } }

func A_arbace_a2g_vh_A_clinit() { A_arbace_a2g_vh_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_a2g_vh_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_a2g_vh_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_a2g_vh_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_a2g_vh_A_const_4 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref()); A_arbace_a2g_vh_A_const_5 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_8).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref()); A_arbace_a2g_vh_A_const_6 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_10).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_11).Ref()); A_arbace_a2g_vh_A_const_7 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_12).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_13).Ref()); A_arbace_a2g_vh_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_a2g_vh_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_15); A_arbace_a2g_vh_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); A_arbace_a2g_vh_A_const_11 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_17)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_18).Ref(), Lit_19))); A_arbace_a2g_vh_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_a2g_vh_A_const_13 = lang.RT_Var_String_String__Var(Lit_10, Lit_21); A_arbace_a2g_vh_A_const_14 = lang.RT_Keyword_String_String__Keyword(nil, Lit_22); A_arbace_a2g_vh_A_const_15 = lang.RT_Keyword_String_String__Keyword(nil, Lit_23); A_arbace_a2g_vh_A_const_16 = lang.RT_Var_String_String__Var(Lit_17, Lit_24); A_arbace_a2g_vh_A_const_17 = lang.RT_Keyword_String_String__Keyword(nil, Lit_25); A_arbace_a2g_vh_A_const_18 = lang.RT_Keyword_String_String__Keyword(nil, Lit_26); A_arbace_a2g_vh_A_const_19 = lang.RT_Keyword_String_String__Keyword(nil, Lit_27); A_arbace_a2g_vh_A_const_20 = lang.RT_Keyword_String_String__Keyword(nil, Lit_28); A_arbace_a2g_vh_A_const_21 = lang.RT_Keyword_String_String__Keyword(nil, Lit_29); A_arbace_a2g_vh_A_const_22 = lang.RT_Var_String_String__Var(Lit_17, Lit_30); A_arbace_a2g_vh_A_const_23 = lang.RT_Keyword_String_String__Keyword(nil, Lit_31); A_arbace_a2g_vh_A_const_24 = lang.RT_Keyword_String_String__Keyword(nil, Lit_32); A_arbace_a2g_vh_A_const_25 = lang.RT_Keyword_String_String__Keyword(nil, Lit_33); A_arbace_a2g_vh_A_const_26 = lang.RT_Keyword_String_String__Keyword(nil, Lit_34); A_arbace_a2g_vh_A_const_27 = lang.RT_Keyword_String_String__Keyword(nil, Lit_35); A_arbace_a2g_vh_A_const_28 = lang.RT_Keyword_String_String__Keyword(nil, Lit_36); A_arbace_a2g_vh_A_const_29 = lang.RT_Keyword_String_String__Keyword(nil, Lit_37); A_arbace_a2g_vh_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_38); A_arbace_a2g_vh_A_const_31 = lang.RT_Keyword_String_String__Keyword(nil, Lit_39); A_arbace_a2g_vh_A_const_32 = lang.RT_Map_O1__IPersistentMap(jrt.ConstRefArray("[0,4,s10:BIG_ENDIANs2:BEs13:LITTLE_ENDIANs2:LE", []*jrt.Class{jrt.Object_class})); A_arbace_a2g_vh_A_const_33 = lang.RT_Var_String_String__Var(Lit_17, Lit_40); A_arbace_a2g_vh_A_const_34 = lang.RT_Var_String_String__Var(Lit_8, Lit_41); A_arbace_a2g_vh_A_const_35 = lang.RT_Var_String_String__Var(Lit_0, Lit_42); A_arbace_a2g_vh_A_const_36 = lang.RT_Keyword_String_String__Keyword(nil, Lit_43); A_arbace_a2g_vh_A_const_37 = lang.RT_Keyword_String_String__Keyword(nil, Lit_44); A_arbace_a2g_vh_A_const_38 = lang.RT_Var_String_String__Var(Lit_0, Lit_45); A_arbace_a2g_vh_A_const_39 = lang.RT_Keyword_String_String__Keyword(nil, Lit_46); A_arbace_a2g_vh_A_const_40 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_a2g_vh_A_const_41 = lang.RT_Var_String_String__Var(Lit_6, Lit_47); A_arbace_a2g_vh_A_const_42 = lang.RT_Var_String_String__Var(Lit_6, Lit_48); A_arbace_a2g_vh_A_const_43 = lang.RT_Var_String_String__Var(Lit_17, Lit_49); A_arbace_a2g_vh_A_const_44 = lang.RT_Keyword_String_String__Keyword(nil, Lit_50); A_arbace_a2g_vh_A_const_45 = lang.RT_Keyword_String_String__Keyword(nil, Lit_51); A_arbace_a2g_vh_A_const_46 = lang.RT_Var_String_String__Var(Lit_17, Lit_52); A_arbace_a2g_vh_A_const_47 = lang.RT_Keyword_String_String__Keyword(nil, Lit_53); A_arbace_a2g_vh_A_const_48 = lang.RT_Var_String_String__Var(Lit_0, Lit_54); A_arbace_a2g_vh_A_const_49 = lang.RT_Var_String_String__Var(Lit_0, Lit_55); A_arbace_a2g_vh_A_const_50 = lang.RT_Var_String_String__Var(Lit_0, Lit_56); A_arbace_a2g_vh_A_const_51 = lang.RT_Var_String_String__Var(Lit_0, Lit_57); A_arbace_a2g_vh_A_const_52 = lang.RT_Keyword_String_String__Keyword(nil, Lit_58); A_arbace_a2g_vh_A_const_53 = lang.RT_Keyword_String_String__Keyword(nil, Lit_59); A_arbace_a2g_vh_A_const_54 = lang.RT_Var_String_String__Var(Lit_6, Lit_60); A_arbace_a2g_vh_A_const_55 = lang.RT_Keyword_String_String__Keyword(nil, Lit_61); A_arbace_a2g_vh_A_const_56 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_62, Lit_63)).Ref(); A_arbace_a2g_vh_A_const_57 = lang.RT_Keyword_String_String__Keyword(nil, Lit_64); A_arbace_a2g_vh_A_const_58 = lang.RT_Keyword_String_String__Keyword(nil, Lit_65); A_arbace_a2g_vh_A_const_59 = lang.RT_Var_String_String__Var(Lit_17, Lit_66); A_arbace_a2g_vh_A_const_60 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_67, Lit_68)).Ref(); A_arbace_a2g_vh_A_const_61 = lang.RT_Var_String_String__Var(Lit_0, Lit_69); A_arbace_a2g_vh_A_const_62 = lang.RT_Var_String_String__Var(Lit_0, Lit_70); A_arbace_a2g_vh_A_const_63 = lang.RT_Var_String_String__Var(Lit_17, Lit_71); A_arbace_a2g_vh_A_const_64 = lang.RT_Keyword_String_String__Keyword(nil, Lit_72); A_arbace_a2g_vh_A_const_65 = lang.RT_Var_String_String__Var(Lit_17, Lit_73); A_arbace_a2g_vh_A_const_66 = lang.RT_Var_String_String__Var(Lit_0, Lit_74); A_arbace_a2g_vh_A_const_67 = lang.RT_Keyword_String_String__Keyword(nil, Lit_75); A_arbace_a2g_vh_A_const_68 = lang.RT_Keyword_String_String__Keyword(nil, Lit_76); A_arbace_a2g_vh_A_const_69 = lang.RT_Var_String_String__Var(Lit_0, Lit_77); A_arbace_a2g_vh_A_const_70 = lang.RT_Keyword_String_String__Keyword(nil, Lit_78); A_arbace_a2g_vh_A_const_71 = lang.RT_Var_String_String__Var(Lit_0, Lit_79); A_arbace_a2g_vh_A_const_72 = lang.RT_Var_String_String__Var(Lit_0, Lit_80); A_arbace_a2g_vh_A_const_73 = lang.RT_Var_String_String__Var(Lit_12, Lit_81); A_arbace_a2g_vh_A_const_74 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref())).Ref(); A_arbace_a2g_vh_A_const_75 = lang.RT_Keyword_String_String__Keyword(nil, Lit_84); A_arbace_a2g_vh_A_const_76 = lang.RT_Keyword_String_String__Keyword(nil, Lit_85); A_arbace_a2g_vh_A_const_77 = lang.RT_Var_String_String__Var(Lit_0, Lit_86); A_arbace_a2g_vh_A_const_78 = lang.RT_Var_String_String__Var(Lit_0, Lit_87); A_arbace_a2g_vh_A_const_79 = lang.RT_Var_String_String__Var(Lit_0, Lit_88); A_arbace_a2g_vh_A_const_80 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref())).Ref(); A_arbace_a2g_vh_A_const_81 = lang.RT_Keyword_String_String__Keyword(nil, Lit_89); A_arbace_a2g_vh_A_const_82 = lang.RT_Var_String_String__Var(Lit_17, Lit_90); A_arbace_a2g_vh_A_const_83 = lang.RT_Var_String_String__Var(Lit_0, Lit_91); A_arbace_a2g_vh_A_const_84 = lang.RT_Keyword_String_String__Keyword(nil, Lit_92); A_arbace_a2g_vh_A_const_85 = lang.RT_Var_String_String__Var(Lit_0, Lit_93); A_arbace_a2g_vh_A_const_86 = lang.RT_Var_String_String__Var(Lit_0, Lit_94); A_arbace_a2g_vh_A_const_87 = lang.RT_Var_String_String__Var(Lit_0, Lit_95); A_arbace_a2g_vh_A_const_88 = lang.RT_Var_String_String__Var(Lit_0, Lit_96); A_arbace_a2g_vh_A_const_89 = lang.RT_Var_String_String__Var(Lit_0, Lit_97); A_arbace_a2g_vh_A_const_90 = lang.RT_Var_String_String__Var(Lit_0, Lit_98); A_arbace_a2g_vh_A_const_91 = lang.RT_Var_String_String__Var(Lit_0, Lit_99); A_arbace_a2g_vh_A_const_92 = lang.RT_Var_String_String__Var(Lit_0, Lit_100); A_arbace_a2g_vh_A_const_93 = lang.RT_Var_String_String__Var(Lit_17, Lit_101); A_arbace_a2g_vh_A_const_94 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.ConstRefArray("[0,4,s9:getOpaques11:getVolatiles10:getAcquires3:get", []*jrt.Class{jrt.Object_class})).Ref(); A_arbace_a2g_vh_A_const_95 = lang.RT_Keyword_String_String__Keyword(nil, Lit_102); A_arbace_a2g_vh_A_const_96 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.ConstRefArray("[0,4,s9:setOpaques3:sets10:setReleases11:setVolatile", []*jrt.Class{jrt.Object_class})).Ref(); A_arbace_a2g_vh_A_const_97 = lang.RT_Keyword_String_String__Keyword(nil, Lit_93); A_arbace_a2g_vh_A_const_98 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.ConstRefArray("[0,5,s22:weakCompareAndSetPlains24:weakCompareAndSetAcquires24:weakCompareAndSetReleases17:weakCompareAndSets13:compareAndSet", []*jrt.Class{jrt.Object_class})).Ref(); A_arbace_a2g_vh_A_const_99 = lang.RT_Keyword_String_String__Keyword(nil, Lit_103); A_arbace_a2g_vh_A_const_100 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_104, Lit_105, Lit_106)).Ref(); A_arbace_a2g_vh_A_const_101 = lang.RT_Keyword_String_String__Keyword(nil, Lit_107); A_arbace_a2g_vh_A_const_102 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_108, Lit_109, Lit_110)).Ref(); A_arbace_a2g_vh_A_const_103 = lang.RT_Keyword_String_String__Keyword(nil, Lit_111); A_arbace_a2g_vh_A_const_104 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_112, Lit_113, Lit_114)).Ref(); A_arbace_a2g_vh_A_const_105 = lang.RT_Keyword_String_String__Keyword(nil, Lit_115); A_arbace_a2g_vh_A_const_106 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_116, Lit_117, Lit_118)).Ref(); A_arbace_a2g_vh_A_const_107 = lang.RT_Keyword_String_String__Keyword(nil, Lit_119); A_arbace_a2g_vh_A_const_108 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_120, Lit_121, Lit_122)).Ref(); A_arbace_a2g_vh_A_const_109 = lang.RT_Keyword_String_String__Keyword(nil, Lit_123); A_arbace_a2g_vh_A_const_110 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_124, Lit_125, Lit_126)).Ref(); A_arbace_a2g_vh_A_const_111 = lang.RT_Keyword_String_String__Keyword(nil, Lit_127); A_arbace_a2g_vh_A_const_112 = lang.RT_Var_String_String__Var(Lit_17, Lit_128); A_arbace_a2g_vh_A_const_113 = lang.RT_Var_String_String__Var(Lit_0, Lit_129); A_arbace_a2g_vh_A_const_114 = lang.RT_Var_String_String__Var(Lit_17, Lit_130); A_arbace_a2g_vh_A_const_115 = lang.RT_Keyword_String_String__Keyword(nil, Lit_130) }

func A_arbace_a2g_vh_A_New() *A_arbace_a2g_vh_A { A_arbace_a2g_vh_A_Init(); t := &A_arbace_a2g_vh_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_vh_A) Ctor() {}

func (t *A_arbace_a2g_vh_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_A_class }

func (t *A_arbace_a2g_vh_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_A); return ok }

func A_arbace_a2g_vh_A_Cast(x any) *A_arbace_a2g_vh_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_A_class)) }; return v }



type A_arbace_a2g_vh_byte_order_arg_A struct{ jrt.Object }

func (t *A_arbace_a2g_vh_byte_order_arg_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_vh_byte_order_arg_A_fn_class *jrt.Class

var A_arbace_a2g_vh_byte_order_arg_A_init jrt.ClassInit

func A_arbace_a2g_vh_byte_order_arg_A_Init() { if !A_arbace_a2g_vh_byte_order_arg_A_init.Done() { A_arbace_a2g_vh_byte_order_arg_A_init.Run(A_arbace_a2g_vh_byte_order_arg_A_clinit) } }

func A_arbace_a2g_vh_byte_order_arg_A_clinit() { A_arbace_a2g_vh_byte_order_arg_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_131, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_byte_order_arg_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_byte_order_arg_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_byte_order_arg_A_class }

func (t *A_arbace_a2g_vh_byte_order_arg_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_byte_order_arg_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_byte_order_arg_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_byte_order_arg_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_byte_order_arg_A); return ok }

func A_arbace_a2g_vh_byte_order_arg_A_Cast(x any) *A_arbace_a2g_vh_byte_order_arg_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_byte_order_arg_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_byte_order_arg_A_class)) }; return v }



type A_arbace_a2g_vh_class_arg_A struct{ jrt.Object }

func (t *A_arbace_a2g_vh_class_arg_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_vh_class_arg_A_fn_class *jrt.Class

var A_arbace_a2g_vh_class_arg_A_init jrt.ClassInit

func A_arbace_a2g_vh_class_arg_A_Init() { if !A_arbace_a2g_vh_class_arg_A_init.Done() { A_arbace_a2g_vh_class_arg_A_init.Run(A_arbace_a2g_vh_class_arg_A_clinit) } }

func A_arbace_a2g_vh_class_arg_A_clinit() { A_arbace_a2g_vh_class_arg_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_133, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_class_arg_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_class_arg_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_class_arg_A_class }

func (t *A_arbace_a2g_vh_class_arg_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_class_arg_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_class_arg_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_class_arg_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_class_arg_A); return ok }

func A_arbace_a2g_vh_class_arg_A_Cast(x any) *A_arbace_a2g_vh_class_arg_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_class_arg_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_class_arg_A_class)) }; return v }



type A_arbace_a2g_vh_class_handles_A struct{ jrt.Object }

func (t *A_arbace_a2g_vh_class_handles_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_vh_class_handles_A_fn_class *jrt.Class

var A_arbace_a2g_vh_class_handles_A_init jrt.ClassInit

func A_arbace_a2g_vh_class_handles_A_Init() { if !A_arbace_a2g_vh_class_handles_A_init.Done() { A_arbace_a2g_vh_class_handles_A_init.Run(A_arbace_a2g_vh_class_handles_A_clinit) } }

func A_arbace_a2g_vh_class_handles_A_clinit() { A_arbace_a2g_vh_class_handles_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_135, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_class_handles_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_class_handles_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_class_handles_A_class }

func (t *A_arbace_a2g_vh_class_handles_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_class_handles_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_class_handles_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_class_handles_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_class_handles_A); return ok }

func A_arbace_a2g_vh_class_handles_A_Cast(x any) *A_arbace_a2g_vh_class_handles_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_class_handles_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_class_handles_A_class)) }; return v }



type A_arbace_a2g_vh_class_handles_fn__331000032_A struct{ jrt.Object; F_env any }

func (t *A_arbace_a2g_vh_class_handles_fn__331000032_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_vh_class_handles_fn__331000032_A_fn_class *jrt.Class

var A_arbace_a2g_vh_class_handles_fn__331000032_A_init jrt.ClassInit

func A_arbace_a2g_vh_class_handles_fn__331000032_A_Init() { if !A_arbace_a2g_vh_class_handles_fn__331000032_A_init.Done() { A_arbace_a2g_vh_class_handles_fn__331000032_A_init.Run(A_arbace_a2g_vh_class_handles_fn__331000032_A_clinit) } }

func A_arbace_a2g_vh_class_handles_fn__331000032_A_clinit() { A_arbace_a2g_vh_class_handles_fn__331000032_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_136, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_class_handles_fn__331000032_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_class_handles_fn__331000032_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_class_handles_fn__331000032_A_class }

func (t *A_arbace_a2g_vh_class_handles_fn__331000032_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_class_handles_fn__331000032_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_class_handles_fn__331000032_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_class_handles_fn__331000032_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_class_handles_fn__331000032_A); return ok }

func A_arbace_a2g_vh_class_handles_fn__331000032_A_Cast(x any) *A_arbace_a2g_vh_class_handles_fn__331000032_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_class_handles_fn__331000032_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_class_handles_fn__331000032_A_class)) }; return v }



type A_arbace_a2g_vh_class_handles_fn__331000044_A struct{ jrt.Object; F_env any }

func (t *A_arbace_a2g_vh_class_handles_fn__331000044_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_vh_class_handles_fn__331000044_A_fn_class *jrt.Class

var A_arbace_a2g_vh_class_handles_fn__331000044_A_init jrt.ClassInit

func A_arbace_a2g_vh_class_handles_fn__331000044_A_Init() { if !A_arbace_a2g_vh_class_handles_fn__331000044_A_init.Done() { A_arbace_a2g_vh_class_handles_fn__331000044_A_init.Run(A_arbace_a2g_vh_class_handles_fn__331000044_A_clinit) } }

func A_arbace_a2g_vh_class_handles_fn__331000044_A_clinit() { A_arbace_a2g_vh_class_handles_fn__331000044_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_137, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_class_handles_fn__331000044_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_class_handles_fn__331000044_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_class_handles_fn__331000044_A_class }

func (t *A_arbace_a2g_vh_class_handles_fn__331000044_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_class_handles_fn__331000044_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_class_handles_fn__331000044_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_class_handles_fn__331000044_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_class_handles_fn__331000044_A); return ok }

func A_arbace_a2g_vh_class_handles_fn__331000044_A_Cast(x any) *A_arbace_a2g_vh_class_handles_fn__331000044_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_class_handles_fn__331000044_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_class_handles_fn__331000044_A_class)) }; return v }



type A_arbace_a2g_vh_class_handles_fn__331000060_A struct{ jrt.Object; F_env, F_out, F_n any }

func (t *A_arbace_a2g_vh_class_handles_fn__331000060_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_vh_class_handles_fn__331000060_A_fn_class *jrt.Class

var A_arbace_a2g_vh_class_handles_fn__331000060_A_init jrt.ClassInit

func A_arbace_a2g_vh_class_handles_fn__331000060_A_Init() { if !A_arbace_a2g_vh_class_handles_fn__331000060_A_init.Done() { A_arbace_a2g_vh_class_handles_fn__331000060_A_init.Run(A_arbace_a2g_vh_class_handles_fn__331000060_A_clinit) } }

func A_arbace_a2g_vh_class_handles_fn__331000060_A_clinit() { A_arbace_a2g_vh_class_handles_fn__331000060_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_138, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_class_handles_fn__331000060_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_class_handles_fn__331000060_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_class_handles_fn__331000060_A_class }

func (t *A_arbace_a2g_vh_class_handles_fn__331000060_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_class_handles_fn__331000060_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_class_handles_fn__331000060_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_class_handles_fn__331000060_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_class_handles_fn__331000060_A); return ok }

func A_arbace_a2g_vh_class_handles_fn__331000060_A_Cast(x any) *A_arbace_a2g_vh_class_handles_fn__331000060_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_class_handles_fn__331000060_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_class_handles_fn__331000060_A_class)) }; return v }



type A_arbace_a2g_vh_class_handles_fn__331000062_A struct{ jrt.Object; F_env, F_out, F_n any }

func (t *A_arbace_a2g_vh_class_handles_fn__331000062_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_vh_class_handles_fn__331000062_A_fn_class *jrt.Class

var A_arbace_a2g_vh_class_handles_fn__331000062_A_init jrt.ClassInit

func A_arbace_a2g_vh_class_handles_fn__331000062_A_Init() { if !A_arbace_a2g_vh_class_handles_fn__331000062_A_init.Done() { A_arbace_a2g_vh_class_handles_fn__331000062_A_init.Run(A_arbace_a2g_vh_class_handles_fn__331000062_A_clinit) } }

func A_arbace_a2g_vh_class_handles_fn__331000062_A_clinit() { A_arbace_a2g_vh_class_handles_fn__331000062_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_139, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_class_handles_fn__331000062_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_class_handles_fn__331000062_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_class_handles_fn__331000062_A_class }

func (t *A_arbace_a2g_vh_class_handles_fn__331000062_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_class_handles_fn__331000062_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_class_handles_fn__331000062_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_class_handles_fn__331000062_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_class_handles_fn__331000062_A); return ok }

func A_arbace_a2g_vh_class_handles_fn__331000062_A_Cast(x any) *A_arbace_a2g_vh_class_handles_fn__331000062_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_class_handles_fn__331000062_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_class_handles_fn__331000062_A_class)) }; return v }



type A_arbace_a2g_vh_eval331000004_A struct{ jrt.Object }

func A_arbace_a2g_vh_eval331000004_A_New() *A_arbace_a2g_vh_eval331000004_A { t := &A_arbace_a2g_vh_eval331000004_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_vh_eval331000004_A) Ctor() {}

func (t *A_arbace_a2g_vh_eval331000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_eval331000004_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_eval331000004_A_class }

func (t *A_arbace_a2g_vh_eval331000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_eval331000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_eval331000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_eval331000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_eval331000004_A); return ok }

func A_arbace_a2g_vh_eval331000004_A_Cast(x any) *A_arbace_a2g_vh_eval331000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_eval331000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_eval331000004_A_class)) }; return v }



type A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A struct{ jrt.Object }

func (t *A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_fn_class *jrt.Class

var A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_init jrt.ClassInit

func A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_Init() { if !A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_init.Done() { A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_init.Run(A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_clinit) } }

func A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_clinit() { A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_140, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_class }

func (t *A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A); return ok }

func A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_Cast(x any) *A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_class)) }; return v }



type A_arbace_a2g_vh_eval331000008_A struct{ jrt.Object }

func A_arbace_a2g_vh_eval331000008_A_New() *A_arbace_a2g_vh_eval331000008_A { t := &A_arbace_a2g_vh_eval331000008_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_vh_eval331000008_A) Ctor() {}

func (t *A_arbace_a2g_vh_eval331000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_eval331000008_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_eval331000008_A_class }

func (t *A_arbace_a2g_vh_eval331000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_eval331000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_eval331000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_eval331000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_eval331000008_A); return ok }

func A_arbace_a2g_vh_eval331000008_A_Cast(x any) *A_arbace_a2g_vh_eval331000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_eval331000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_eval331000008_A_class)) }; return v }



type A_arbace_a2g_vh_eval331000008_fn__331000009_A struct{ jrt.Object }

func (t *A_arbace_a2g_vh_eval331000008_fn__331000009_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_vh_eval331000008_fn__331000009_A_fn_class *jrt.Class

var A_arbace_a2g_vh_eval331000008_fn__331000009_A_init jrt.ClassInit

func A_arbace_a2g_vh_eval331000008_fn__331000009_A_Init() { if !A_arbace_a2g_vh_eval331000008_fn__331000009_A_init.Done() { A_arbace_a2g_vh_eval331000008_fn__331000009_A_init.Run(A_arbace_a2g_vh_eval331000008_fn__331000009_A_clinit) } }

func A_arbace_a2g_vh_eval331000008_fn__331000009_A_clinit() { A_arbace_a2g_vh_eval331000008_fn__331000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_141, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_eval331000008_fn__331000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_eval331000008_fn__331000009_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_eval331000008_fn__331000009_A_class }

func (t *A_arbace_a2g_vh_eval331000008_fn__331000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_eval331000008_fn__331000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_eval331000008_fn__331000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_eval331000008_fn__331000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_eval331000008_fn__331000009_A); return ok }

func A_arbace_a2g_vh_eval331000008_fn__331000009_A_Cast(x any) *A_arbace_a2g_vh_eval331000008_fn__331000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_eval331000008_fn__331000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_eval331000008_fn__331000009_A_class)) }; return v }



type A_arbace_a2g_vh_fence_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_vh_fence_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_vh_fence_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_vh_fence_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_vh_fence_QMARK__A_Init() { if !A_arbace_a2g_vh_fence_QMARK__A_init.Done() { A_arbace_a2g_vh_fence_QMARK__A_init.Run(A_arbace_a2g_vh_fence_QMARK__A_clinit) } }

func A_arbace_a2g_vh_fence_QMARK__A_clinit() { A_arbace_a2g_vh_fence_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_142, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_fence_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_fence_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_fence_QMARK__A_class }

func (t *A_arbace_a2g_vh_fence_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_fence_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_fence_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_fence_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_fence_QMARK__A); return ok }

func A_arbace_a2g_vh_fence_QMARK__A_Cast(x any) *A_arbace_a2g_vh_fence_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_fence_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_fence_QMARK__A_class)) }; return v }



type A_arbace_a2g_vh_find_field_A struct{ jrt.Object }

func (t *A_arbace_a2g_vh_find_field_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_vh_find_field_A_fn_class *jrt.Class

var A_arbace_a2g_vh_find_field_A_init jrt.ClassInit

func A_arbace_a2g_vh_find_field_A_Init() { if !A_arbace_a2g_vh_find_field_A_init.Done() { A_arbace_a2g_vh_find_field_A_init.Run(A_arbace_a2g_vh_find_field_A_clinit) } }

func A_arbace_a2g_vh_find_field_A_clinit() { A_arbace_a2g_vh_find_field_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_143, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_find_field_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_find_field_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_find_field_A_class }

func (t *A_arbace_a2g_vh_find_field_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_find_field_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_find_field_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_find_field_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_find_field_A); return ok }

func A_arbace_a2g_vh_find_field_A_Cast(x any) *A_arbace_a2g_vh_find_field_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_find_field_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_find_field_A_class)) }; return v }



type A_arbace_a2g_vh_find_field_fn__331000018_A struct{ jrt.Object; F_fname any }

func (t *A_arbace_a2g_vh_find_field_fn__331000018_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_vh_find_field_fn__331000018_A_fn_class *jrt.Class

var A_arbace_a2g_vh_find_field_fn__331000018_A_init jrt.ClassInit

func A_arbace_a2g_vh_find_field_fn__331000018_A_Init() { if !A_arbace_a2g_vh_find_field_fn__331000018_A_init.Done() { A_arbace_a2g_vh_find_field_fn__331000018_A_init.Run(A_arbace_a2g_vh_find_field_fn__331000018_A_clinit) } }

func A_arbace_a2g_vh_find_field_fn__331000018_A_clinit() { A_arbace_a2g_vh_find_field_fn__331000018_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_144, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_find_field_fn__331000018_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_find_field_fn__331000018_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_find_field_fn__331000018_A_class }

func (t *A_arbace_a2g_vh_find_field_fn__331000018_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_find_field_fn__331000018_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_find_field_fn__331000018_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_find_field_fn__331000018_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_find_field_fn__331000018_A); return ok }

func A_arbace_a2g_vh_find_field_fn__331000018_A_Cast(x any) *A_arbace_a2g_vh_find_field_fn__331000018_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_find_field_fn__331000018_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_find_field_fn__331000018_A_class)) }; return v }



type A_arbace_a2g_vh_handle_spec_A struct{ jrt.Object }

func (t *A_arbace_a2g_vh_handle_spec_A) Is_Compiler_AOTF3() {}

var A_arbace_a2g_vh_handle_spec_A_fn_class *jrt.Class

var A_arbace_a2g_vh_handle_spec_A_init jrt.ClassInit

func A_arbace_a2g_vh_handle_spec_A_Init() { if !A_arbace_a2g_vh_handle_spec_A_init.Done() { A_arbace_a2g_vh_handle_spec_A_init.Run(A_arbace_a2g_vh_handle_spec_A_clinit) } }

func A_arbace_a2g_vh_handle_spec_A_clinit() { A_arbace_a2g_vh_handle_spec_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_145, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_handle_spec_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_handle_spec_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_handle_spec_A_class }

func (t *A_arbace_a2g_vh_handle_spec_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_handle_spec_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_handle_spec_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_handle_spec_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_handle_spec_A); return ok }

func A_arbace_a2g_vh_handle_spec_A_Cast(x any) *A_arbace_a2g_vh_handle_spec_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_handle_spec_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_handle_spec_A_class)) }; return v }



type A_arbace_a2g_vh_handle_spec_field_spec__331000022_A struct{ jrt.Object }

func (t *A_arbace_a2g_vh_handle_spec_field_spec__331000022_A) Is_Compiler_AOTF3() {}

var A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_fn_class *jrt.Class

var A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_init jrt.ClassInit

func A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_Init() { if !A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_init.Done() { A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_init.Run(A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_clinit) } }

func A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_clinit() { A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_154, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_handle_spec_field_spec__331000022_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_handle_spec_field_spec__331000022_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_class }

func (t *A_arbace_a2g_vh_handle_spec_field_spec__331000022_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_handle_spec_field_spec__331000022_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_handle_spec_field_spec__331000022_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_handle_spec_field_spec__331000022_A); return ok }

func A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_Cast(x any) *A_arbace_a2g_vh_handle_spec_field_spec__331000022_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_handle_spec_field_spec__331000022_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_class)) }; return v }



type A_arbace_a2g_vh_handles_A struct{ jrt.Object }

func (t *A_arbace_a2g_vh_handles_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_vh_handles_A_fn_class *jrt.Class

var A_arbace_a2g_vh_handles_A_init jrt.ClassInit

func A_arbace_a2g_vh_handles_A_Init() { if !A_arbace_a2g_vh_handles_A_init.Done() { A_arbace_a2g_vh_handles_A_init.Run(A_arbace_a2g_vh_handles_A_clinit) } }

func A_arbace_a2g_vh_handles_A_clinit() { A_arbace_a2g_vh_handles_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_155, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_handles_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_handles_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_handles_A_class }

func (t *A_arbace_a2g_vh_handles_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_handles_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_handles_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_handles_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_handles_A); return ok }

func A_arbace_a2g_vh_handles_A_Cast(x any) *A_arbace_a2g_vh_handles_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_handles_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_handles_A_class)) }; return v }



type A_arbace_a2g_vh_handles_iter__331000066__331000072_A struct{ jrt.Object }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_vh_handles_iter__331000066__331000072_A_fn_class *jrt.Class

var A_arbace_a2g_vh_handles_iter__331000066__331000072_A_init jrt.ClassInit

func A_arbace_a2g_vh_handles_iter__331000066__331000072_A_Init() { if !A_arbace_a2g_vh_handles_iter__331000066__331000072_A_init.Done() { A_arbace_a2g_vh_handles_iter__331000066__331000072_A_init.Run(A_arbace_a2g_vh_handles_iter__331000066__331000072_A_clinit) } }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_A_clinit() { A_arbace_a2g_vh_handles_iter__331000066__331000072_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_156, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_handles_iter__331000066__331000072_A_class }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_handles_iter__331000066__331000072_A); return ok }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_A_Cast(x any) *A_arbace_a2g_vh_handles_iter__331000066__331000072_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_handles_iter__331000066__331000072_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_handles_iter__331000066__331000072_A_class)) }; return v }



type A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A struct{ jrt.Object; F_iter__331000066, F_s__331000067 any }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_fn_class *jrt.Class

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_init jrt.ClassInit

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_Init() { if !A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_init.Done() { A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_init.Run(A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_clinit) } }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_clinit() { A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_157, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_class }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A); return ok }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_Cast(x any) *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_class)) }; return v }



type A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A struct{ jrt.Object }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_fn_class *jrt.Class

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_init jrt.ClassInit

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_Init() { if !A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_init.Done() { A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_init.Run(A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_clinit) } }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_clinit() { A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_158, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_class }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A); return ok }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_Cast(x any) *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_class)) }; return v }



type A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A struct{ jrt.Object; F_n any }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_fn_class *jrt.Class

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_init jrt.ClassInit

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_Init() { if !A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_init.Done() { A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_init.Run(A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_clinit) } }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_clinit() { A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_159, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_class }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A); return ok }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_Cast(x any) *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_class)) }; return v }



type A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A struct{ jrt.Object }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_fn_class *jrt.Class

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_init jrt.ClassInit

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_Init() { if !A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_init.Done() { A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_init.Run(A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_clinit) } }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_clinit() { A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_160, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_class }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A); return ok }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_Cast(x any) *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_class)) }; return v }



type A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A struct{ jrt.Object; F_s__331000069, F_iter__331000068 any }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_fn_class *jrt.Class

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_init jrt.ClassInit

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_Init() { if !A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_init.Done() { A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_init.Run(A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_clinit) } }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_clinit() { A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_161, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_class }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A); return ok }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_Cast(x any) *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_class)) }; return v }



type A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A struct{ jrt.Object; F_b__331000071 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_fn_class *jrt.Class

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_init jrt.ClassInit

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_Init() { if !A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_init.Done() { A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_init.Run(A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_clinit) } }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_clinit() { A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_162, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_class }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A); return ok }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_Cast(x any) *A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_class)) }; return v }



type A_arbace_a2g_vh_handles_iter__331000086__331000090_A struct{ jrt.Object }

func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_vh_handles_iter__331000086__331000090_A_fn_class *jrt.Class

var A_arbace_a2g_vh_handles_iter__331000086__331000090_A_init jrt.ClassInit

func A_arbace_a2g_vh_handles_iter__331000086__331000090_A_Init() { if !A_arbace_a2g_vh_handles_iter__331000086__331000090_A_init.Done() { A_arbace_a2g_vh_handles_iter__331000086__331000090_A_init.Run(A_arbace_a2g_vh_handles_iter__331000086__331000090_A_clinit) } }

func A_arbace_a2g_vh_handles_iter__331000086__331000090_A_clinit() { A_arbace_a2g_vh_handles_iter__331000086__331000090_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_163, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_handles_iter__331000086__331000090_A_class }

func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_handles_iter__331000086__331000090_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_handles_iter__331000086__331000090_A); return ok }

func A_arbace_a2g_vh_handles_iter__331000086__331000090_A_Cast(x any) *A_arbace_a2g_vh_handles_iter__331000086__331000090_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_handles_iter__331000086__331000090_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_handles_iter__331000086__331000090_A_class)) }; return v }



type A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A struct{ jrt.Object; F_iter__331000086, F_s__331000087 any }

func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_fn_class *jrt.Class

var A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_init jrt.ClassInit

func A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_Init() { if !A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_init.Done() { A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_init.Run(A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_clinit) } }

func A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_clinit() { A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_164, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_class }

func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A); return ok }

func A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_Cast(x any) *A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_class)) }; return v }



type A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A struct{ jrt.Object; F_b__331000089 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_fn_class *jrt.Class

var A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_init jrt.ClassInit

func A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_Init() { if !A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_init.Done() { A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_init.Run(A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_clinit) } }

func A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_clinit() { A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_165, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_class }

func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A); return ok }

func A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_Cast(x any) *A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_class)) }; return v }



type A_arbace_a2g_vh_mode_A struct{ jrt.Object }

func (t *A_arbace_a2g_vh_mode_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_vh_mode_A_fn_class *jrt.Class

var A_arbace_a2g_vh_mode_A_init jrt.ClassInit

func A_arbace_a2g_vh_mode_A_Init() { if !A_arbace_a2g_vh_mode_A_init.Done() { A_arbace_a2g_vh_mode_A_init.Run(A_arbace_a2g_vh_mode_A_clinit) } }

func A_arbace_a2g_vh_mode_A_clinit() { A_arbace_a2g_vh_mode_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_166, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_mode_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_mode_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_mode_A_class }

func (t *A_arbace_a2g_vh_mode_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_mode_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_mode_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_mode_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_mode_A); return ok }

func A_arbace_a2g_vh_mode_A_Cast(x any) *A_arbace_a2g_vh_mode_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_mode_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_mode_A_class)) }; return v }



type A_arbace_a2g_vh_op_handle_A struct{ jrt.Object }

func (t *A_arbace_a2g_vh_op_handle_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_vh_op_handle_A_fn_class *jrt.Class

var A_arbace_a2g_vh_op_handle_A_init jrt.ClassInit

func A_arbace_a2g_vh_op_handle_A_Init() { if !A_arbace_a2g_vh_op_handle_A_init.Done() { A_arbace_a2g_vh_op_handle_A_init.Run(A_arbace_a2g_vh_op_handle_A_clinit) } }

func A_arbace_a2g_vh_op_handle_A_clinit() { A_arbace_a2g_vh_op_handle_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_167, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_op_handle_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_op_handle_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_op_handle_A_class }

func (t *A_arbace_a2g_vh_op_handle_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_op_handle_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_op_handle_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_op_handle_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_op_handle_A); return ok }

func A_arbace_a2g_vh_op_handle_A_Cast(x any) *A_arbace_a2g_vh_op_handle_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_op_handle_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_op_handle_A_class)) }; return v }



type A_arbace_a2g_vh_static_flag_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_vh_static_flag_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_vh_static_flag_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_vh_static_flag_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_vh_static_flag_QMARK__A_Init() { if !A_arbace_a2g_vh_static_flag_QMARK__A_init.Done() { A_arbace_a2g_vh_static_flag_QMARK__A_init.Run(A_arbace_a2g_vh_static_flag_QMARK__A_clinit) } }

func A_arbace_a2g_vh_static_flag_QMARK__A_clinit() { A_arbace_a2g_vh_static_flag_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_168, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_static_flag_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_static_flag_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_static_flag_QMARK__A_class }

func (t *A_arbace_a2g_vh_static_flag_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_static_flag_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_static_flag_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_static_flag_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_static_flag_QMARK__A); return ok }

func A_arbace_a2g_vh_static_flag_QMARK__A_Cast(x any) *A_arbace_a2g_vh_static_flag_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_static_flag_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_static_flag_QMARK__A_class)) }; return v }



type A_arbace_a2g_vh_string_arg_A struct{ jrt.Object }

func (t *A_arbace_a2g_vh_string_arg_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_vh_string_arg_A_fn_class *jrt.Class

var A_arbace_a2g_vh_string_arg_A_init jrt.ClassInit

func A_arbace_a2g_vh_string_arg_A_Init() { if !A_arbace_a2g_vh_string_arg_A_init.Done() { A_arbace_a2g_vh_string_arg_A_init.Run(A_arbace_a2g_vh_string_arg_A_clinit) } }

func A_arbace_a2g_vh_string_arg_A_clinit() { A_arbace_a2g_vh_string_arg_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_169, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_vh_string_arg_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh_string_arg_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh_string_arg_A_class }

func (t *A_arbace_a2g_vh_string_arg_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh_string_arg_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh_string_arg_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh_string_arg_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh_string_arg_A); return ok }

func A_arbace_a2g_vh_string_arg_A_Cast(x any) *A_arbace_a2g_vh_string_arg_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh_string_arg_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh_string_arg_A_class)) }; return v }
