//line aot_arbace_a2g_vh__init.ae:1
package aot_arbace_a2g_vh

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_vh__init_A_Unit0__O() any { A_arbace_a2g_vh__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_a2g_vh__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_vh__init_A_const_1) }
//line :1:1
func A_arbace_a2g_vh__init_A_Unit1__O() any { A_arbace_a2g_vh__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_a2g_vh__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_a2g_vh__init_A_const_2)) }
//line :1:1
func A_arbace_a2g_vh__init_A_Unit2__O() any { A_arbace_a2g_vh__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_New(); var tmp2 *jrt.Class; A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_Init(); tmp2 = A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_a2g_vh__init_A_Unit3__O() any { A_arbace_a2g_vh__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_a2g_vh__init_A_const_1)).Equals_O__Z(A_arbace_a2g_vh__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_a2g_vh_eval331000008_fn__331000009_A_New(); var tmp2 *jrt.Class; A_arbace_a2g_vh_eval331000008_fn__331000009_A_Init(); tmp2 = A_arbace_a2g_vh_eval331000008_fn__331000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_a2g_vh__init_A_Load__O() any { A_arbace_a2g_vh__init_A_Init(); A_arbace_a2g_vh__init_A_Unit0__O(); A_arbace_a2g_vh__init_A_Unit1__O(); A_arbace_a2g_vh__init_A_Unit2__O(); A_arbace_a2g_vh__init_A_Unit3__O(); A_arbace_a2g_vh__init_A_Unit4__O(); A_arbace_a2g_vh__init_A_Unit5__O(); A_arbace_a2g_vh__init_A_Unit6__O(); A_arbace_a2g_vh__init_A_Unit7__O(); A_arbace_a2g_vh__init_A_Unit8__O(); A_arbace_a2g_vh__init_A_Unit9__O(); A_arbace_a2g_vh__init_A_Unit10__O(); A_arbace_a2g_vh__init_A_Unit11__O(); A_arbace_a2g_vh__init_A_Unit12__O(); A_arbace_a2g_vh__init_A_Unit13__O(); A_arbace_a2g_vh__init_A_Unit14__O(); A_arbace_a2g_vh__init_A_Unit15__O(); A_arbace_a2g_vh__init_A_Unit16__O(); A_arbace_a2g_vh__init_A_Unit17__O(); A_arbace_a2g_vh__init_A_Unit18__O(); return nil }













func A_arbace_a2g_vh__init_A_Unit4__O() any { A_arbace_a2g_vh__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); jrt.NN(A_arbace_a2g_vh__init_A_const_4).BindRoot_O__V(Lit_195); var tmp1 *lang.Var = A_arbace_a2g_vh__init_A_const_4; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_vh__init_A_const_5)); return A_arbace_a2g_vh__init_A_const_4.Ref() }
func A_arbace_a2g_vh__init_A_Unit5__O() any { A_arbace_a2g_vh__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); jrt.NN(A_arbace_a2g_vh__init_A_const_6).BindRoot_O__V(Lit_196); var tmp1 *lang.Var = A_arbace_a2g_vh__init_A_const_6; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_vh__init_A_const_7)); return A_arbace_a2g_vh__init_A_const_6.Ref() }

func A_arbace_a2g_vh__init_A_Unit6__O() any { A_arbace_a2g_vh__init_A_Init(); lang.Compiler_AOT_At_I_I__V(22, 1); jrt.NN(A_arbace_a2g_vh__init_A_const_8).BindRoot_O__V(A_arbace_a2g_vh__init_A_const_9); var tmp1 *lang.Var = A_arbace_a2g_vh__init_A_const_8; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_vh__init_A_const_10)); return A_arbace_a2g_vh__init_A_const_8.Ref() }



func A_arbace_a2g_vh__init_A_Unit7__O() any { A_arbace_a2g_vh__init_A_Init(); lang.Compiler_AOT_At_I_I__V(26, 1); var tmp1 *lang.Var = A_arbace_a2g_vh__init_A_const_11; var tmp2 any = A_arbace_a2g_vh_class_arg_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_vh_class_arg_A_Init(); tmp3 = A_arbace_a2g_vh_class_arg_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_vh__init_A_const_11; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_vh__init_A_const_12)); return A_arbace_a2g_vh__init_A_const_11.Ref() }












func A_arbace_a2g_vh__init_A_Unit8__O() any { A_arbace_a2g_vh__init_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); var tmp1 *lang.Var = A_arbace_a2g_vh__init_A_const_13; var tmp2 any = A_arbace_a2g_vh_string_arg_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_vh_string_arg_A_Init(); tmp3 = A_arbace_a2g_vh_string_arg_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_vh__init_A_const_13; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_vh__init_A_const_14)); return A_arbace_a2g_vh__init_A_const_13.Ref() }



func A_arbace_a2g_vh__init_A_Unit9__O() any { A_arbace_a2g_vh__init_A_Init(); lang.Compiler_AOT_At_I_I__V(43, 1); var tmp1 *lang.Var = A_arbace_a2g_vh__init_A_const_15; var tmp2 any = A_arbace_a2g_vh_byte_order_arg_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_vh_byte_order_arg_A_Init(); tmp3 = A_arbace_a2g_vh_byte_order_arg_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_vh__init_A_const_15; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_vh__init_A_const_16)); return A_arbace_a2g_vh__init_A_const_15.Ref() }











func A_arbace_a2g_vh__init_A_Unit10__O() any { A_arbace_a2g_vh__init_A_Init(); lang.Compiler_AOT_At_I_I__V(55, 1); var tmp1 *lang.Var = A_arbace_a2g_vh__init_A_const_17; var tmp2 any = A_arbace_a2g_vh_find_field_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_vh_find_field_A_Init(); tmp3 = A_arbace_a2g_vh_find_field_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_vh__init_A_const_17; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_vh__init_A_const_18)); return A_arbace_a2g_vh__init_A_const_17.Ref() }







func A_arbace_a2g_vh__init_A_Unit11__O() any { A_arbace_a2g_vh__init_A_Init(); lang.Compiler_AOT_At_I_I__V(63, 1); var tmp1 *lang.Var = A_arbace_a2g_vh__init_A_const_19; var tmp2 any = A_arbace_a2g_vh_static_flag_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_vh_static_flag_QMARK__A_Init(); tmp3 = A_arbace_a2g_vh_static_flag_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_vh__init_A_const_19; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_vh__init_A_const_20)); return A_arbace_a2g_vh__init_A_const_19.Ref() }

func A_arbace_a2g_vh__init_A_Unit12__O() any { A_arbace_a2g_vh__init_A_Init(); lang.Compiler_AOT_At_I_I__V(65, 1); var tmp1 *lang.Var = A_arbace_a2g_vh__init_A_const_21; var tmp2 any = A_arbace_a2g_vh_handle_spec_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_vh_handle_spec_A_Init(); tmp3 = A_arbace_a2g_vh_handle_spec_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_vh__init_A_const_21; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_vh__init_A_const_22)); return A_arbace_a2g_vh__init_A_const_21.Ref() }













































func A_arbace_a2g_vh__init_A_Unit13__O() any { A_arbace_a2g_vh__init_A_Init(); lang.Compiler_AOT_At_I_I__V(111, 1); var tmp1 *lang.Var = A_arbace_a2g_vh__init_A_const_23; var tmp2 any = A_arbace_a2g_vh_class_handles_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_vh_class_handles_A_Init(); tmp3 = A_arbace_a2g_vh_class_handles_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_vh__init_A_const_23; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_vh__init_A_const_24)); return A_arbace_a2g_vh__init_A_const_23.Ref() }






















func A_arbace_a2g_vh__init_A_Unit14__O() any { A_arbace_a2g_vh__init_A_Init(); lang.Compiler_AOT_At_I_I__V(134, 1); var tmp1 *lang.Var = A_arbace_a2g_vh__init_A_const_25; var tmp2 any = A_arbace_a2g_vh_handles_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_vh_handles_A_Init(); tmp3 = A_arbace_a2g_vh_handles_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_vh__init_A_const_25; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_vh__init_A_const_26)); return A_arbace_a2g_vh__init_A_const_25.Ref() }














func A_arbace_a2g_vh__init_A_Unit15__O() any { A_arbace_a2g_vh__init_A_Init(); lang.Compiler_AOT_At_I_I__V(149, 1); jrt.NN(A_arbace_a2g_vh__init_A_const_27).BindRoot_O__V(A_arbace_a2g_vh__init_A_const_28); var tmp1 *lang.Var = A_arbace_a2g_vh__init_A_const_27; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_vh__init_A_const_29)); return A_arbace_a2g_vh__init_A_const_27.Ref() }

func A_arbace_a2g_vh__init_A_Unit16__O() any { A_arbace_a2g_vh__init_A_Init(); lang.Compiler_AOT_At_I_I__V(151, 1); var tmp1 *lang.Var = A_arbace_a2g_vh__init_A_const_30; var tmp2 any = A_arbace_a2g_vh_mode_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_vh_mode_A_Init(); tmp3 = A_arbace_a2g_vh_mode_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_vh__init_A_const_30; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_vh__init_A_const_31)); return A_arbace_a2g_vh__init_A_const_30.Ref() }















func A_arbace_a2g_vh__init_A_Unit17__O() any { A_arbace_a2g_vh__init_A_Init(); lang.Compiler_AOT_At_I_I__V(167, 1); var tmp1 *lang.Var = A_arbace_a2g_vh__init_A_const_32; var tmp2 any = A_arbace_a2g_vh_fence_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_vh_fence_QMARK__A_Init(); tmp3 = A_arbace_a2g_vh_fence_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_vh__init_A_const_32; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_vh__init_A_const_33)); return A_arbace_a2g_vh__init_A_const_32.Ref() }


func A_arbace_a2g_vh__init_A_Unit18__O() any { A_arbace_a2g_vh__init_A_Init(); lang.Compiler_AOT_At_I_I__V(170, 1); var tmp1 *lang.Var = A_arbace_a2g_vh__init_A_const_34; var tmp2 any = A_arbace_a2g_vh_op_handle_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_vh_op_handle_A_Init(); tmp3 = A_arbace_a2g_vh_op_handle_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_vh__init_A_const_34; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_vh__init_A_const_35)); return A_arbace_a2g_vh__init_A_const_34.Ref() }



type A_arbace_a2g_vh__init_A struct{ jrt.Object }

var A_arbace_a2g_vh__init_A_const_0 *lang.Var

var A_arbace_a2g_vh__init_A_const_1 any

var A_arbace_a2g_vh__init_A_const_2 any

var A_arbace_a2g_vh__init_A_const_3 any

var A_arbace_a2g_vh__init_A_const_4 *lang.Var

var A_arbace_a2g_vh__init_A_const_5 any

var A_arbace_a2g_vh__init_A_const_6 *lang.Var

var A_arbace_a2g_vh__init_A_const_7 any

var A_arbace_a2g_vh__init_A_const_8 *lang.Var

var A_arbace_a2g_vh__init_A_const_9 any

var A_arbace_a2g_vh__init_A_const_10 any

var A_arbace_a2g_vh__init_A_const_11 *lang.Var

var A_arbace_a2g_vh__init_A_const_12 any

var A_arbace_a2g_vh__init_A_const_13 *lang.Var

var A_arbace_a2g_vh__init_A_const_14 any

var A_arbace_a2g_vh__init_A_const_15 *lang.Var

var A_arbace_a2g_vh__init_A_const_16 any

var A_arbace_a2g_vh__init_A_const_17 *lang.Var

var A_arbace_a2g_vh__init_A_const_18 any

var A_arbace_a2g_vh__init_A_const_19 *lang.Var

var A_arbace_a2g_vh__init_A_const_20 any

var A_arbace_a2g_vh__init_A_const_21 *lang.Var

var A_arbace_a2g_vh__init_A_const_22 any

var A_arbace_a2g_vh__init_A_const_23 *lang.Var

var A_arbace_a2g_vh__init_A_const_24 any

var A_arbace_a2g_vh__init_A_const_25 *lang.Var

var A_arbace_a2g_vh__init_A_const_26 any

var A_arbace_a2g_vh__init_A_const_27 *lang.Var

var A_arbace_a2g_vh__init_A_const_28 any

var A_arbace_a2g_vh__init_A_const_29 any

var A_arbace_a2g_vh__init_A_const_30 *lang.Var

var A_arbace_a2g_vh__init_A_const_31 any

var A_arbace_a2g_vh__init_A_const_32 *lang.Var

var A_arbace_a2g_vh__init_A_const_33 any

var A_arbace_a2g_vh__init_A_const_34 *lang.Var

var A_arbace_a2g_vh__init_A_const_35 any

var A_arbace_a2g_vh__init_A_init jrt.ClassInit

func A_arbace_a2g_vh__init_A_Init() { if !A_arbace_a2g_vh__init_A_init.Done() { A_arbace_a2g_vh__init_A_init.Run(A_arbace_a2g_vh__init_A_clinit) } }

func A_arbace_a2g_vh__init_A_clinit() { A_arbace_a2g_vh__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_170); A_arbace_a2g_vh__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_17)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_18).Ref(), Lit_19))); A_arbace_a2g_vh__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_18).Ref(), Lit_19)); A_arbace_a2g_vh__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_a2g_vh__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_17, Lit_66); A_arbace_a2g_vh__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_171).Ref(), jrt.Integer_ValueOf_I__Integer(19).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_172).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_173).Ref(), Lit_174)); A_arbace_a2g_vh__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_17, Lit_90); A_arbace_a2g_vh__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_171).Ref(), jrt.Integer_ValueOf_I__Integer(20).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_172).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_173).Ref(), Lit_174)); A_arbace_a2g_vh__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_17, Lit_30); A_arbace_a2g_vh__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.ConstRefArray("[0,16,s17:java/lang/Booleans1:Zs14:java/lang/Bytes1:Bs19:java/lang/Characters1:Cs15:java/lang/Shorts1:Ss17:java/lang/Integers1:Is14:java/lang/Longs1:Js15:java/lang/Floats1:Fs16:java/lang/Doubles1:D", []*jrt.Class{jrt.Object_class})); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_175).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_a2g_vh__init_A_const_10 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_171).Ref(), jrt.Integer_ValueOf_I__Integer(22).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_172).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_173).Ref(), Lit_174)); A_arbace_a2g_vh__init_A_const_11 = lang.RT_Var_String_String__Var(Lit_17, Lit_24); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_175).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_a2g_vh__init_A_const_12 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_177).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_178).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_18).Ref(), Lit_179, lang.RT_Keyword_String_String__Keyword(nil, Lit_171).Ref(), jrt.Integer_ValueOf_I__Integer(26).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_172).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_173).Ref(), Lit_174)); A_arbace_a2g_vh__init_A_const_13 = lang.RT_Var_String_String__Var(Lit_17, Lit_73); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_175).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_a2g_vh__init_A_const_14 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_177).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_171).Ref(), jrt.Integer_ValueOf_I__Integer(39).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_172).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_173).Ref(), Lit_174)); A_arbace_a2g_vh__init_A_const_15 = lang.RT_Var_String_String__Var(Lit_17, Lit_40); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_175).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_a2g_vh__init_A_const_16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_177).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_178).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_18).Ref(), Lit_180, lang.RT_Keyword_String_String__Keyword(nil, Lit_171).Ref(), jrt.Integer_ValueOf_I__Integer(43).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_172).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_173).Ref(), Lit_174)); A_arbace_a2g_vh__init_A_const_17 = lang.RT_Var_String_String__Var(Lit_17, Lit_49); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_175).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_a2g_vh__init_A_const_18 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_181).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_182).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_18).Ref(), Lit_183, lang.RT_Keyword_String_String__Keyword(nil, Lit_171).Ref(), jrt.Integer_ValueOf_I__Integer(55).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_172).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_173).Ref(), Lit_174)); A_arbace_a2g_vh__init_A_const_19 = lang.RT_Var_String_String__Var(Lit_17, Lit_52); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_175).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_a2g_vh__init_A_const_20 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_184).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_171).Ref(), jrt.Integer_ValueOf_I__Integer(63).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_172).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_173).Ref(), Lit_174)); A_arbace_a2g_vh__init_A_const_21 = lang.RT_Var_String_String__Var(Lit_17, Lit_71); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_175).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_a2g_vh__init_A_const_22 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_181).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_185).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_178).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_18).Ref(), Lit_186, lang.RT_Keyword_String_String__Keyword(nil, Lit_171).Ref(), jrt.Integer_ValueOf_I__Integer(65).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_172).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_173).Ref(), Lit_174)); A_arbace_a2g_vh__init_A_const_23 = lang.RT_Var_String_String__Var(Lit_17, Lit_101); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_175).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_a2g_vh__init_A_const_24 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_181).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_18).Ref(), Lit_187, lang.RT_Keyword_String_String__Keyword(nil, Lit_171).Ref(), jrt.Integer_ValueOf_I__Integer(111).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_172).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_173).Ref(), Lit_174)); A_arbace_a2g_vh__init_A_const_25 = lang.RT_Var_String_String__Var(Lit_17, Lit_92); A_arbace_a2g_vh__init_A_const_26 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_188).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_18).Ref(), Lit_189, lang.RT_Keyword_String_String__Keyword(nil, Lit_171).Ref(), jrt.Integer_ValueOf_I__Integer(134).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_172).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_173).Ref(), Lit_174)); A_arbace_a2g_vh__init_A_const_27 = lang.RT_Var_String_String__Var(Lit_17, Lit_128); A_arbace_a2g_vh__init_A_const_28 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.ConstRefArray("[0,5,s9:fullFences13:loadLoadFences12:releaseFences15:storeStoreFences12:acquireFence", []*jrt.Class{jrt.Object_class})).Ref(); A_arbace_a2g_vh__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_171).Ref(), jrt.Integer_ValueOf_I__Integer(149).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_172).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_173).Ref(), Lit_174)); A_arbace_a2g_vh__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_17, Lit_130); A_arbace_a2g_vh__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_29).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_18).Ref(), Lit_190, lang.RT_Keyword_String_String__Keyword(nil, Lit_171).Ref(), jrt.Integer_ValueOf_I__Integer(151).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_172).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_173).Ref(), Lit_174)); A_arbace_a2g_vh__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_17, Lit_191); A_arbace_a2g_vh__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_177).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_171).Ref(), jrt.Integer_ValueOf_I__Integer(167).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_172).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_173).Ref(), Lit_174)); A_arbace_a2g_vh__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_17, Lit_192); A_arbace_a2g_vh__init_A_const_35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_193).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_177).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_18).Ref(), Lit_194, lang.RT_Keyword_String_String__Keyword(nil, Lit_171).Ref(), jrt.Integer_ValueOf_I__Integer(170).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_172).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_173).Ref(), Lit_174)) }

func A_arbace_a2g_vh__init_A_New() *A_arbace_a2g_vh__init_A { A_arbace_a2g_vh__init_A_Init(); t := &A_arbace_a2g_vh__init_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_vh__init_A) Ctor() {}

func (t *A_arbace_a2g_vh__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_vh__init_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_vh__init_A_class }

func (t *A_arbace_a2g_vh__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_vh__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_vh__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_vh__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_vh__init_A); return ok }

func A_arbace_a2g_vh__init_A_Cast(x any) *A_arbace_a2g_vh__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_vh__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_vh__init_A_class)) }; return v }
