//line a2g_strings.ae:1
package aot_arbace_a2g_vh

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("arbace.classes.types")

var Lit_7 *jrt.String = jrt.Intern("t")

var Lit_8 *jrt.String = jrt.Intern("arbace.classes.analyze")

var Lit_9 *jrt.String = jrt.Intern("a")

var Lit_10 *jrt.String = jrt.Intern("arbace.a2g.access")

var Lit_11 *jrt.String = jrt.Intern("acc")

var Lit_12 *jrt.String = jrt.Intern("arbace.a2g.reach")

var Lit_13 *jrt.String = jrt.Intern("r")

var Lit_14 *jrt.String = jrt.Intern("commute")

var Lit_15 *jrt.String = jrt.Intern("deref")

var Lit_16 *jrt.String = jrt.Intern("conj")

var Lit_17 *jrt.String = jrt.Intern("arbace.a2g.vh")

var Lit_18 *jrt.String = jrt.Intern("doc")

var Lit_19 *jrt.String = jrt.Intern("VarHandles compiled statically (A2G-SPEC §8.5, amendment JC1): the JDK's concurrent classes\n  make their VarHandles once, in static initializers, as static final fields\n  (MethodHandles.lookup().findVarHandle(C.class, \"f\", T.class), MhUtil.findVarHandle,\n  MethodHandles.arrayElementVarHandle(T[].class), MethodHandles.byteArrayViewVarHandle(int[].class\n  or long[].class, ByteOrder.X)), and use them only through those fields\n  (NEXT.compareAndSet(node, a, b)). a2g reads the initializers into a table of constant handles\n  and translates each access mode called on one of these fields into an atomic operation on the\n  field it names (or on the array element), as Go code; java.lang.invoke itself stays outside\n  the world (erased: the initializers' lookups are not run). Fields a handle names get the\n  volatile representation (§8.2), so that every access to them, plain or by the handle, is\n  atomic.")

var Lit_20 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_21 *jrt.String = jrt.Intern("unaccess")

var Lit_22 *jrt.String = jrt.Intern("op")

var Lit_23 *jrt.String = jrt.Intern("cast")

var Lit_24 *jrt.String = jrt.Intern("class-arg")

var Lit_25 *jrt.String = jrt.Intern("class-lit")

var Lit_26 *jrt.String = jrt.Intern("class")

var Lit_27 *jrt.String = jrt.Intern("get-static")

var Lit_28 *jrt.String = jrt.Intern("field")

var Lit_29 *jrt.String = jrt.Intern("name")

var Lit_30 *jrt.String = jrt.Intern("box-prims")

var Lit_31 *jrt.String = jrt.Intern("local")

var Lit_32 *jrt.String = jrt.Intern("id")

var Lit_33 *jrt.String = jrt.Intern("b")

var Lit_34 *jrt.String = jrt.Intern("expr")

var Lit_35 *jrt.String = jrt.Intern("declarer")

var Lit_36 *jrt.String = jrt.Intern("owner")

var Lit_37 *jrt.String = jrt.Intern("const")

var Lit_38 *jrt.String = jrt.Intern("string?")

var Lit_39 *jrt.String = jrt.Intern("val")

var Lit_40 *jrt.String = jrt.Intern("byte-order-arg")

var Lit_41 *jrt.String = jrt.Intern("decl")

var Lit_42 *jrt.String = jrt.Intern("some")

var Lit_43 *jrt.String = jrt.Intern("fields")

var Lit_44 *jrt.String = jrt.Intern("super")

var Lit_45 *jrt.String = jrt.Intern("not")

var Lit_46 *jrt.String = jrt.Intern("flags")

var Lit_47 *jrt.String = jrt.Intern("class-desc?")

var Lit_48 *jrt.String = jrt.Intern("desc->internal")

var Lit_49 *jrt.String = jrt.Intern("find-field")

var Lit_50 *jrt.String = jrt.Intern("desc")

var Lit_51 *jrt.String = jrt.Intern("kind")

var Lit_52 *jrt.String = jrt.Intern("static-flag?")

var Lit_53 *jrt.String = jrt.Intern("invoke")

var Lit_54 *jrt.String = jrt.Intern("next")

var Lit_55 *jrt.String = jrt.Intern("to-array")

var Lit_56 *jrt.String = jrt.Intern("seq")

var Lit_57 *jrt.String = jrt.Intern("first")

var Lit_58 *jrt.String = jrt.Intern("args")

var Lit_59 *jrt.String = jrt.Intern("static")

var Lit_60 *jrt.String = jrt.Intern("array?")

var Lit_61 *jrt.String = jrt.Intern("array")

var Lit_62 *jrt.String = jrt.Intern("[I")

var Lit_63 *jrt.String = jrt.Intern("[J")

var Lit_64 *jrt.String = jrt.Intern("view")

var Lit_65 *jrt.String = jrt.Intern("order")

var Lit_66 *jrt.String = jrt.Intern("varhandle")

var Lit_67 *jrt.String = jrt.Intern("withInvokeBehavior")

var Lit_68 *jrt.String = jrt.Intern("withInvokeExactBehavior")

var Lit_69 *jrt.String = jrt.Intern("empty?")

var Lit_70 *jrt.String = jrt.Intern("map?")

var Lit_71 *jrt.String = jrt.Intern("handle-spec")

var Lit_72 *jrt.String = jrt.Intern("else")

var Lit_73 *jrt.String = jrt.Intern("string-arg")

var Lit_74 *jrt.String = jrt.Intern("second")

var Lit_75 *jrt.String = jrt.Intern("target")

var Lit_76 *jrt.String = jrt.Intern("clinit")

var Lit_77 *jrt.String = jrt.Intern("atom")

var Lit_78 *jrt.String = jrt.Intern("state")

var Lit_79 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_80 *jrt.String = jrt.Intern("chunk-first")

var Lit_81 *jrt.String = jrt.Intern("walk-nodes")

var Lit_82 *jrt.String = jrt.Intern("let")

var Lit_83 *jrt.String = jrt.Intern("loop")

var Lit_84 *jrt.String = jrt.Intern("bindings")

var Lit_85 *jrt.String = jrt.Intern("mutable")

var Lit_86 *jrt.String = jrt.Intern("swap!")

var Lit_87 *jrt.String = jrt.Intern("assoc")

var Lit_88 *jrt.String = jrt.Intern("chunk-rest")

var Lit_89 *jrt.String = jrt.Intern("set-static")

var Lit_90 *jrt.String = jrt.Intern("vh-desc")

var Lit_91 *jrt.String = jrt.Intern("into")

var Lit_92 *jrt.String = jrt.Intern("handles")

var Lit_93 *jrt.String = jrt.Intern("set")

var Lit_94 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_95 *jrt.String = jrt.Intern("chunk-append")

var Lit_96 *jrt.String = jrt.Intern("chunk-cons")

var Lit_97 *jrt.String = jrt.Intern("cons")

var Lit_98 *jrt.String = jrt.Intern("chunk")

var Lit_99 *jrt.String = jrt.Intern("rest")

var Lit_100 *jrt.String = jrt.Intern("concat")

var Lit_101 *jrt.String = jrt.Intern("class-handles")

var Lit_102 *jrt.String = jrt.Intern("get")

var Lit_103 *jrt.String = jrt.Intern("cas")

var Lit_104 *jrt.String = jrt.Intern("compareAndExchange")

var Lit_105 *jrt.String = jrt.Intern("compareAndExchangeRelease")

var Lit_106 *jrt.String = jrt.Intern("compareAndExchangeAcquire")

var Lit_107 *jrt.String = jrt.Intern("cmpxchg")

var Lit_108 *jrt.String = jrt.Intern("getAndSet")

var Lit_109 *jrt.String = jrt.Intern("getAndSetAcquire")

var Lit_110 *jrt.String = jrt.Intern("getAndSetRelease")

var Lit_111 *jrt.String = jrt.Intern("swap")

var Lit_112 *jrt.String = jrt.Intern("getAndAdd")

var Lit_113 *jrt.String = jrt.Intern("getAndAddAcquire")

var Lit_114 *jrt.String = jrt.Intern("getAndAddRelease")

var Lit_115 *jrt.String = jrt.Intern("add")

var Lit_116 *jrt.String = jrt.Intern("getAndBitwiseOrRelease")

var Lit_117 *jrt.String = jrt.Intern("getAndBitwiseOr")

var Lit_118 *jrt.String = jrt.Intern("getAndBitwiseOrAcquire")

var Lit_119 *jrt.String = jrt.Intern("or")

var Lit_120 *jrt.String = jrt.Intern("getAndBitwiseAndAcquire")

var Lit_121 *jrt.String = jrt.Intern("getAndBitwiseAndRelease")

var Lit_122 *jrt.String = jrt.Intern("getAndBitwiseAnd")

var Lit_123 *jrt.String = jrt.Intern("and")

var Lit_124 *jrt.String = jrt.Intern("getAndBitwiseXorRelease")

var Lit_125 *jrt.String = jrt.Intern("getAndBitwiseXor")

var Lit_126 *jrt.String = jrt.Intern("getAndBitwiseXorAcquire")

var Lit_127 *jrt.String = jrt.Intern("xor")

var Lit_128 *jrt.String = jrt.Intern("fences")

var Lit_129 *jrt.String = jrt.Intern("not=")

var Lit_130 *jrt.String = jrt.Intern("mode")

var Lit_131 *jrt.String = jrt.Intern("arbace.a2g.vh$byte_order_arg")

var Lit_132 *jrt.String = jrt.Intern("java/nio/ByteOrder")

var Lit_133 *jrt.String = jrt.Intern("arbace.a2g.vh$class_arg")

var Lit_134 *jrt.String = jrt.Intern("TYPE")

var Lit_135 *jrt.String = jrt.Intern("arbace.a2g.vh$class_handles")

var Lit_136 *jrt.String = jrt.Intern("arbace.a2g.vh$class_handles$fn__331000032")

var Lit_137 *jrt.String = jrt.Intern("arbace.a2g.vh$class_handles$fn__331000044")

var Lit_138 *jrt.String = jrt.Intern("arbace.a2g.vh$class_handles$fn__331000060")

var Lit_139 *jrt.String = jrt.Intern("arbace.a2g.vh$class_handles$fn__331000062")

var Lit_140 *jrt.String = jrt.Intern("arbace.a2g.vh$eval331000004$loading__1927001464__auto____331000005")

var Lit_141 *jrt.String = jrt.Intern("arbace.a2g.vh$eval331000008$fn__331000009")

var Lit_142 *jrt.String = jrt.Intern("arbace.a2g.vh$fence_QMARK_")

var Lit_143 *jrt.String = jrt.Intern("arbace.a2g.vh$find_field")

var Lit_144 *jrt.String = jrt.Intern("arbace.a2g.vh$find_field$fn__331000018")

var Lit_145 *jrt.String = jrt.Intern("arbace.a2g.vh$handle_spec")

var Lit_146 *jrt.String = jrt.Intern("java/lang/invoke/MethodHandles$Lookup")

var Lit_147 *jrt.String = jrt.Intern("findVarHandle")

var Lit_148 *jrt.String = jrt.Intern("jdk/internal/invoke/MhUtil")

var Lit_149 *jrt.String = jrt.Intern("L")

var Lit_150 *jrt.String = jrt.Intern(";")

var Lit_151 *jrt.String = jrt.Intern("java/lang/invoke/MethodHandles")

var Lit_152 *jrt.String = jrt.Intern("arrayElementVarHandle")

var Lit_153 *jrt.String = jrt.Intern("byteArrayViewVarHandle")

var Lit_154 *jrt.String = jrt.Intern("arbace.a2g.vh$handle_spec$field_spec__331000022")

var Lit_155 *jrt.String = jrt.Intern("arbace.a2g.vh$handles")

var Lit_156 *jrt.String = jrt.Intern("arbace.a2g.vh$handles$iter__331000066__331000072")

var Lit_157 *jrt.String = jrt.Intern("arbace.a2g.vh$handles$iter__331000066__331000072$fn__331000073")

var Lit_158 *jrt.String = jrt.Intern("arbace.a2g.vh$handles$iter__331000066__331000072$fn__331000073$fn__331000074")

var Lit_159 *jrt.String = jrt.Intern("arbace.a2g.vh$handles$iter__331000066__331000072$fn__331000073$fn__331000082")

var Lit_160 *jrt.String = jrt.Intern("arbace.a2g.vh$handles$iter__331000066__331000072$fn__331000073$iter__331000068__331000076")

var Lit_161 *jrt.String = jrt.Intern("arbace.a2g.vh$handles$iter__331000066__331000072$fn__331000073$iter__331000068__331000076$fn__331000077")

var Lit_162 *jrt.String = jrt.Intern("arbace.a2g.vh$handles$iter__331000066__331000072$fn__331000073$iter__331000068__331000076$fn__331000077$fn__331000078")

var Lit_163 *jrt.String = jrt.Intern("arbace.a2g.vh$handles$iter__331000086__331000090")

var Lit_164 *jrt.String = jrt.Intern("arbace.a2g.vh$handles$iter__331000086__331000090$fn__331000091")

var Lit_165 *jrt.String = jrt.Intern("arbace.a2g.vh$handles$iter__331000086__331000090$fn__331000091$fn__331000092")

var Lit_166 *jrt.String = jrt.Intern("arbace.a2g.vh$mode")

var Lit_167 *jrt.String = jrt.Intern("arbace.a2g.vh$op_handle")

var Lit_168 *jrt.String = jrt.Intern("arbace.a2g.vh$static_flag_QMARK_")

var Lit_169 *jrt.String = jrt.Intern("arbace.a2g.vh$string_arg")

var Lit_170 *jrt.String = jrt.Intern("in-ns")

var Lit_171 *jrt.String = jrt.Intern("line")

var Lit_172 *jrt.String = jrt.Intern("column")

var Lit_173 *jrt.String = jrt.Intern("file")

var Lit_174 *jrt.String = jrt.Intern("arbace/a2g/vh.ae")

var Lit_175 *jrt.String = jrt.Intern("private")

var Lit_176 *jrt.String = jrt.Intern("arglists")

var Lit_177 *jrt.String = jrt.Intern("node")

var Lit_178 *jrt.String = jrt.Intern("env")

var Lit_179 *jrt.String = jrt.Intern("The descriptor a Class-valued node stands for (a class literal, Integer.TYPE and the like, or a\n  final local bound to one), or nil.")

var Lit_180 *jrt.String = jrt.Intern("\"BE\" or \"LE\" for a node reading ByteOrder.BIG_ENDIAN or LITTLE_ENDIAN (or a final local\n  bound to one), else nil.")

var Lit_181 *jrt.String = jrt.Intern("n")

var Lit_182 *jrt.String = jrt.Intern("fname")

var Lit_183 *jrt.String = jrt.Intern("The instance field `fname` of class n or a superclass (as findVarHandle resolves it).")

var Lit_184 *jrt.String = jrt.Intern("f")

var Lit_185 *jrt.String = jrt.Intern("init")

var Lit_186 *jrt.String = jrt.Intern("The handle the initializer node `init` makes in class n's static initializer, or nil:\n  {:kind :field :class C :name f :desc T :field field}, {:kind :array :desc \"[T\"} or {:kind\n  :view :desc \"[I\" or \"[J\" :order \"BE\" or \"LE\"} (a byte[] view).")

var Lit_187 *jrt.String = jrt.Intern("{[owner fieldname] spec} of the VarHandle constants class n's static initializer makes.")

var Lit_188 *jrt.String = jrt.Intern("class-names")

var Lit_189 *jrt.String = jrt.Intern("The VarHandle constants of every class of the world (run with the world bound): {:handles\n  {[owner fieldname] spec} :fields #{[owner fieldname]}}, the fields handles name.")

var Lit_190 *jrt.String = jrt.Intern("The operation of access mode `name`: :get :set :cas :cmpxchg :swap :add :or :and :xor, or nil.")

var Lit_191 *jrt.String = jrt.Intern("fence?")

var Lit_192 *jrt.String = jrt.Intern("op-handle")

var Lit_193 *jrt.String = jrt.Intern("hs")

var Lit_194 *jrt.String = jrt.Intern("The handle spec of a VarHandle access-mode call `node` on a constant handle of table hs\n  ({[owner name] spec}), with its operation: (assoc spec :mode m), or nil.")

var Lit_195 *jrt.String = jrt.Intern("java/lang/invoke/VarHandle")

var Lit_196 *jrt.String = jrt.Intern("Ljava/lang/invoke/VarHandle;")
