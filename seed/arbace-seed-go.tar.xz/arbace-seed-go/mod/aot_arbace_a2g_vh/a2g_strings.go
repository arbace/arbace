//line a2g_strings.ae:1
package aot_arbace_a2g_vh

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn20,arbace.classes.typesyn1,tyn22,arbace.classes.analyzeyn1,ayn17,arbace.a2g.accessyn3,accyn16,arbace.a2g.reachyn1,rkn3,dockn2,opkn4,castkn9,class-litkn5,classkn10,get-statickn5,fieldkn4,namekn5,localkn2,idkn1,bkn4,exprkn8,declarerkn5,ownerkn5,constkn3,valkn6,fieldskn5,superkn5,flagskn4,desckn4,kindkn6,invokekn4,argskn6,statickn5,arraykn4,viewkn5,orderkn4,elsekn6,targetkn6,clinitkn5,statekn3,letkn4,loopkn8,bindingskn7,mutablekn10,set-statickn7,handleskn3,getkn3,setkn3,caskn7,cmpxchgkn4,swapkn3,addkn2,orkn3,andkn3,xorkn4,modev11,arbace.core7,requirev11,arbace.core5,referR0,V3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn13,arbace.a2g.vhm2,R12,s904,VarHandles compiled statically (A2G-SPEC §8.5, amendment JC1): the JDK's concurrent classes\n  make their VarHandles once, in static initializers, as static final fields\n  (MethodHandles.lookup().findVarHandle(C.class, \"f\", T.class), MhUtil.findVarHandle,\n  MethodHandles.arrayElementVarHandle(T[].class), MethodHandles.byteArrayViewVarHandle(int[].class\n  or long[].class, ByteOrder.X)), and use them only through those fields\n  (NEXT.compareAndSet(node, a, b)). a2g reads the initializers into a table of constant handles\n  and translates each access mode called on one of these fields into an atomic operation on the\n  field it names (or on the array element), as Go code; java.lang.invoke itself stays outside\n  the world (erased: the initializers' lookups are not run). Fields a handle names get the\n  volatile representation (§8.2), so that every access to them, plain or by the handle, is\n  atomic.v11,arbace.core13,*loaded-libs*v17,arbace.a2g.access8,unaccessR13,R14,v13,arbace.a2g.vh9,class-argR15,R16,R17,R18,R19,v13,arbace.a2g.vh9,box-primsR20,R21,R22,R23,R24,R25,R26,v11,arbace.core7,string?R27,m4,s10,BIG_ENDIANs2,BEs13,LITTLE_ENDIANs2,LEv13,arbace.a2g.vh14,byte-order-argv22,arbace.classes.analyze4,declv11,arbace.core4,someR28,R29,v11,arbace.core3,notR30,l0,v20,arbace.classes.types11,class-desc?v20,arbace.classes.types14,desc->internalv13,arbace.a2g.vh10,find-fieldR31,R32,v13,arbace.a2g.vh12,static-flag?R33,v11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core3,seqv11,arbace.core5,firstR34,R35,v20,arbace.classes.types6,array?R36,S2,s2,[Is2,[JR37,R38,v13,arbace.a2g.vh9,varhandleS2,s18,withInvokeBehaviors23,withInvokeExactBehaviorv11,arbace.core6,empty?v11,arbace.core4,map?v13,arbace.a2g.vh11,handle-specR39,v13,arbace.a2g.vh10,string-argv11,arbace.core6,secondR40,R41,v11,arbace.core4,atomR42,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv16,arbace.a2g.reach10,walk-nodesS2,R43,R44,R45,R46,v11,arbace.core5,swap!v11,arbace.core5,assocv11,arbace.core10,chunk-restS2,R43,R44,R47,v13,arbace.a2g.vh7,vh-descv11,arbace.core4,intoR48,v11,arbace.core3,setv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core4,restv11,arbace.core6,concatv13,arbace.a2g.vh13,class-handlesS4,s9,getOpaques11,getVolatiles10,getAcquires3,getR49,S4,s9,setOpaques3,sets10,setReleases11,setVolatileR50,S5,s22,weakCompareAndSetPlains24,weakCompareAndSetAcquires24,weakCompareAndSetReleases17,weakCompareAndSets13,compareAndSetR51,S3,s18,compareAndExchanges25,compareAndExchangeReleases25,compareAndExchangeAcquireR52,S3,s9,getAndSets16,getAndSetAcquires16,getAndSetReleaseR53,S3,s9,getAndAdds16,getAndAddAcquires16,getAndAddReleaseR54,S3,s22,getAndBitwiseOrReleases15,getAndBitwiseOrs22,getAndBitwiseOrAcquireR55,S3,s23,getAndBitwiseAndAcquires23,getAndBitwiseAndReleases16,getAndBitwiseAndR56,S3,s23,getAndBitwiseXorReleases16,getAndBitwiseXors23,getAndBitwiseXorAcquireR57,v13,arbace.a2g.vh6,fencesv11,arbace.core4,not=v13,arbace.a2g.vh4,modeR58,")

var Lit_1 *jrt.String = jrt.Intern("java/nio/ByteOrder")

var Lit_2 *jrt.String = jrt.Intern("TYPE")

var Lit_3 *jrt.String = jrt.Intern("arbace.a2g.vh$class_handles$fn__331000032")

var Lit_4 *jrt.String = jrt.Intern("arbace.a2g.vh$class_handles$fn__331000044")

var Lit_5 *jrt.String = jrt.Intern("arbace.a2g.vh$class_handles$fn__331000060")

var Lit_6 *jrt.String = jrt.Intern("arbace.a2g.vh$class_handles$fn__331000062")

var Lit_7 *jrt.String = jrt.Intern("arbace.a2g.vh$find_field$fn__331000018")

var Lit_8 *jrt.String = jrt.Intern("arbace.a2g.vh$handle_spec$field_spec__331000022")

var Lit_9 *jrt.String = jrt.Intern("java/lang/invoke/MethodHandles$Lookup")

var Lit_10 *jrt.String = jrt.Intern("findVarHandle")

var Lit_11 *jrt.String = jrt.Intern("jdk/internal/invoke/MhUtil")

var Lit_12 *jrt.String = jrt.Intern("L")

var Lit_13 *jrt.String = jrt.Intern(";")

var Lit_14 *jrt.String = jrt.Intern("java/lang/invoke/MethodHandles")

var Lit_15 *jrt.String = jrt.Intern("arrayElementVarHandle")

var Lit_16 *jrt.String = jrt.Intern("byteArrayViewVarHandle")

var Lit_17 *jrt.String = jrt.Intern("arbace.a2g.vh$handles$iter__331000066__331000072")

var Lit_18 *jrt.String = jrt.Intern("arbace.a2g.vh$handles$iter__331000086__331000090")

var Lit_19 *jrt.String = jrt.Intern("arbace.a2g.vh$handles$iter__331000066__331000072$fn__331000073")

var Lit_20 *jrt.String = jrt.Intern("arbace.a2g.vh$handles$iter__331000066__331000072$fn__331000073$fn__331000074")

var Lit_21 *jrt.String = jrt.Intern("arbace.a2g.vh$handles$iter__331000066__331000072$fn__331000073$iter__331000068__331000076")

var Lit_22 *jrt.String = jrt.Intern("arbace.a2g.vh$handles$iter__331000066__331000072$fn__331000073$fn__331000082")

var Lit_23 *jrt.String = jrt.Intern("arbace.a2g.vh$handles$iter__331000066__331000072$fn__331000073$iter__331000068__331000076$fn__331000077")

var Lit_24 *jrt.String = jrt.Intern("arbace.a2g.vh$handles$iter__331000066__331000072$fn__331000073$iter__331000068__331000076$fn__331000077$fn__331000078")

var Lit_25 *jrt.String = jrt.Intern("arbace.a2g.vh$handles$iter__331000086__331000090$fn__331000091")

var Lit_26 *jrt.String = jrt.Intern("arbace.a2g.vh$handles$iter__331000086__331000090$fn__331000091$fn__331000092")

var Lit_27 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn4,linekn6,columnkn4,filekn7,privatekn8,arglistsyn4,nodeyn3,envyn1,nyn5,fnameyn1,fyn4,inityn11,class-namesyn4,nameyn2,hsv11,arbace.core5,in-nsMyn13,arbace.a2g.vhm2,R0,s904,VarHandles compiled statically (A2G-SPEC §8.5, amendment JC1): the JDK's concurrent classes\n  make their VarHandles once, in static initializers, as static final fields\n  (MethodHandles.lookup().findVarHandle(C.class, \"f\", T.class), MhUtil.findVarHandle,\n  MethodHandles.arrayElementVarHandle(T[].class), MethodHandles.byteArrayViewVarHandle(int[].class\n  or long[].class, ByteOrder.X)), and use them only through those fields\n  (NEXT.compareAndSet(node, a, b)). a2g reads the initializers into a table of constant handles\n  and translates each access mode called on one of these fields into an atomic operation on the\n  field it names (or on the array element), as Go code; java.lang.invoke itself stays outside\n  the world (erased: the initializers' lookups are not run). Fields a handle names get the\n  volatile representation (§8.2), so that every access to them, plain or by the handle, is\n  atomic.m2,R0,s904,VarHandles compiled statically (A2G-SPEC §8.5, amendment JC1): the JDK's concurrent classes\n  make their VarHandles once, in static initializers, as static final fields\n  (MethodHandles.lookup().findVarHandle(C.class, \"f\", T.class), MhUtil.findVarHandle,\n  MethodHandles.arrayElementVarHandle(T[].class), MethodHandles.byteArrayViewVarHandle(int[].class\n  or long[].class, ByteOrder.X)), and use them only through those fields\n  (NEXT.compareAndSet(node, a, b)). a2g reads the initializers into a table of constant handles\n  and translates each access mode called on one of these fields into an atomic operation on the\n  field it names (or on the array element), as Go code; java.lang.invoke itself stays outside\n  the world (erased: the initializers' lookups are not run). Fields a handle names get the\n  volatile representation (§8.2), so that every access to them, plain or by the handle, is\n  atomic.R1,v13,arbace.a2g.vh9,varhandlem6,R2,i19,R3,i1,R4,s16,arbace/a2g/vh.aev13,arbace.a2g.vh7,vh-descm6,R2,i20,R3,i1,R4,s16,arbace/a2g/vh.aev13,arbace.a2g.vh9,box-primsm16,s17,java/lang/Booleans1,Zs14,java/lang/Bytes1,Bs19,java/lang/Characters1,Cs15,java/lang/Shorts1,Ss17,java/lang/Integers1,Is14,java/lang/Longs1,Js15,java/lang/Floats1,Fs16,java/lang/Doubles1,Dm8,R5,TR2,i22,R3,i1,R4,s16,arbace/a2g/vh.aev13,arbace.a2g.vh9,class-argm12,R5,TR6,L1,V2,R7,R8,R0,s132,The descriptor a Class-valued node stands for (a class literal, Integer.TYPE and the like, or a\n  final local bound to one), or nil.R2,i26,R3,i1,R4,s16,arbace/a2g/vh.aev13,arbace.a2g.vh10,string-argm10,R5,TR6,L1,V1,R7,R2,i39,R3,i1,R4,s16,arbace/a2g/vh.aev13,arbace.a2g.vh14,byte-order-argm12,R5,TR6,L1,V2,R7,R8,R0,s114,\"BE\" or \"LE\" for a node reading ByteOrder.BIG_ENDIAN or LITTLE_ENDIAN (or a final local\n  bound to one), else nil.R2,i43,R3,i1,R4,s16,arbace/a2g/vh.aev13,arbace.a2g.vh10,find-fieldm12,R5,TR6,L1,V2,R9,R10,R0,s85,The instance field `fname` of class n or a superclass (as findVarHandle resolves it).R2,i55,R3,i1,R4,s16,arbace/a2g/vh.aev13,arbace.a2g.vh12,static-flag?m10,R5,TR6,L1,V1,R11,R2,i63,R3,i1,R4,s16,arbace/a2g/vh.aev13,arbace.a2g.vh11,handle-specm12,R5,TR6,L1,V3,R9,R12,R8,R0,s242,The handle the initializer node `init` makes in class n's static initializer, or nil:\n  {:kind :field :class C :name f :desc T :field field}, {:kind :array :desc \"[T\"} or {:kind\n  :view :desc \"[I\" or \"[J\" :order \"BE\" or \"LE\"} (a byte[] view).R2,i65,R3,i1,R4,s16,arbace/a2g/vh.aev13,arbace.a2g.vh13,class-handlesm12,R5,TR6,L1,V1,R9,R0,s87,{[owner fieldname] spec} of the VarHandle constants class n's static initializer makes.R2,i111,R3,i1,R4,s16,arbace/a2g/vh.aev13,arbace.a2g.vh7,handlesm10,R6,L1,V1,R13,R0,s172,The VarHandle constants of every class of the world (run with the world bound): {:handles\n  {[owner fieldname] spec} :fields #{[owner fieldname]}}, the fields handles name.R2,i134,R3,i1,R4,s16,arbace/a2g/vh.aev13,arbace.a2g.vh6,fencesS5,s9,fullFences13,loadLoadFences12,releaseFences15,storeStoreFences12,acquireFencem6,R2,i149,R3,i1,R4,s16,arbace/a2g/vh.aev13,arbace.a2g.vh4,modem10,R6,L1,V1,R14,R0,s94,The operation of access mode `name`: :get :set :cas :cmpxchg :swap :add :or :and :xor, or nil.R2,i151,R3,i1,R4,s16,arbace/a2g/vh.aev13,arbace.a2g.vh6,fence?m8,R6,L1,V1,R7,R2,i167,R3,i1,R4,s16,arbace/a2g/vh.aev13,arbace.a2g.vh9,op-handlem10,R6,L1,V2,R15,R7,R0,s162,The handle spec of a VarHandle access-mode call `node` on a constant handle of table hs\n  ({[owner name] spec}), with its operation: (assoc spec :mode m), or nil.R2,i170,R3,i1,R4,s16,arbace/a2g/vh.ae")

var Lit_28 *jrt.String = jrt.Intern("arbace.a2g.vh$eval331000004$loading__1927001464__auto____331000005")

var Lit_29 *jrt.String = jrt.Intern("arbace.a2g.vh$eval331000008$fn__331000009")

var Lit_30 *jrt.String = jrt.Intern("java/lang/invoke/VarHandle")

var Lit_31 *jrt.String = jrt.Intern("Ljava/lang/invoke/VarHandle;")

var Lit_32 *jrt.String = jrt.Intern("arbace.a2g.vh$class_arg")

var Lit_33 *jrt.String = jrt.Intern("arbace.a2g.vh$string_arg")

var Lit_34 *jrt.String = jrt.Intern("arbace.a2g.vh$byte_order_arg")

var Lit_35 *jrt.String = jrt.Intern("arbace.a2g.vh$find_field")

var Lit_36 *jrt.String = jrt.Intern("arbace.a2g.vh$static_flag_QMARK_")

var Lit_37 *jrt.String = jrt.Intern("arbace.a2g.vh$handle_spec")

var Lit_38 *jrt.String = jrt.Intern("arbace.a2g.vh$class_handles")

var Lit_39 *jrt.String = jrt.Intern("arbace.a2g.vh$handles")

var Lit_40 *jrt.String = jrt.Intern("arbace.a2g.vh$mode")

var Lit_41 *jrt.String = jrt.Intern("arbace.a2g.vh$fence_QMARK_")

var Lit_42 *jrt.String = jrt.Intern("arbace.a2g.vh$op_handle")
