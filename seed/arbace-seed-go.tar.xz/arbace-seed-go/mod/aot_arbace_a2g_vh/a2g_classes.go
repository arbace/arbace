//line a2g_classes.ae:1
package aot_arbace_a2g_vh

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_a2g_vh_byte_order_arg_A_class, Name: "arbace.a2g.vh$byte_order_arg", Modifiers: 25, Simple: "byte_order_arg", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_byte_order_arg_A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_class_arg_A_class, Name: "arbace.a2g.vh$class_arg", Modifiers: 25, Simple: "class_arg", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_class_arg_A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_class_handles_A_class, Name: "arbace.a2g.vh$class_handles", Modifiers: 25, Simple: "class_handles", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_class_handles_A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_class_handles_fn__331000032_A_class, Name: "arbace.a2g.vh$class_handles$fn__331000032", Modifiers: 25, Simple: "fn__331000032", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_class_handles_fn__331000032_A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_class_handles_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_class_handles_fn__331000044_A_class, Name: "arbace.a2g.vh$class_handles$fn__331000044", Modifiers: 25, Simple: "fn__331000044", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_class_handles_fn__331000044_A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_class_handles_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_class_handles_fn__331000060_A_class, Name: "arbace.a2g.vh$class_handles$fn__331000060", Modifiers: 25, Simple: "fn__331000060", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_class_handles_fn__331000060_A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_class_handles_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_class_handles_fn__331000062_A_class, Name: "arbace.a2g.vh$class_handles$fn__331000062", Modifiers: 25, Simple: "fn__331000062", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_class_handles_fn__331000062_A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_class_handles_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_class, Name: "arbace.a2g.vh$eval331000004$loading__1927001464__auto____331000005", Modifiers: 25, Simple: "loading__1927001464__auto____331000005", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_eval331000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_eval331000008_fn__331000009_A_class, Name: "arbace.a2g.vh$eval331000008$fn__331000009", Modifiers: 25, Simple: "fn__331000009", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_eval331000008_fn__331000009_A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_eval331000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_fence_QMARK__A_class, Name: "arbace.a2g.vh$fence_QMARK_", Modifiers: 25, Simple: "fence_QMARK_", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_fence_QMARK__A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_find_field_A_class, Name: "arbace.a2g.vh$find_field", Modifiers: 25, Simple: "find_field", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_find_field_A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_find_field_fn__331000018_A_class, Name: "arbace.a2g.vh$find_field$fn__331000018", Modifiers: 25, Simple: "fn__331000018", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_find_field_fn__331000018_A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_find_field_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_handle_spec_A_class, Name: "arbace.a2g.vh$handle_spec", Modifiers: 25, Simple: "handle_spec", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_handle_spec_A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_class, Name: "arbace.a2g.vh$handle_spec$field_spec__331000022", Modifiers: 25, Simple: "field_spec__331000022", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_handle_spec_field_spec__331000022_A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_handle_spec_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_handles_A_class, Name: "arbace.a2g.vh$handles", Modifiers: 25, Simple: "handles", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_handles_A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_handles_iter__331000066__331000072_A_class, Name: "arbace.a2g.vh$handles$iter__331000066__331000072", Modifiers: 25, Simple: "iter__331000066__331000072", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_handles_iter__331000066__331000072_A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_handles_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_class, Name: "arbace.a2g.vh$handles$iter__331000066__331000072$fn__331000073", Modifiers: 25, Simple: "fn__331000073", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_handles_iter__331000066__331000072_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_class, Name: "arbace.a2g.vh$handles$iter__331000066__331000072$fn__331000073$fn__331000074", Modifiers: 25, Simple: "fn__331000074", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_class, Name: "arbace.a2g.vh$handles$iter__331000066__331000072$fn__331000073$fn__331000082", Modifiers: 25, Simple: "fn__331000082", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_class, Name: "arbace.a2g.vh$handles$iter__331000066__331000072$fn__331000073$iter__331000068__331000076", Modifiers: 25, Simple: "iter__331000068__331000076", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_class, Name: "arbace.a2g.vh$handles$iter__331000066__331000072$fn__331000073$iter__331000068__331000076$fn__331000077", Modifiers: 25, Simple: "fn__331000077", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_class, Name: "arbace.a2g.vh$handles$iter__331000066__331000072$fn__331000073$iter__331000068__331000076$fn__331000077$fn__331000078", Modifiers: 25, Simple: "fn__331000078", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_handles_iter__331000086__331000090_A_class, Name: "arbace.a2g.vh$handles$iter__331000086__331000090", Modifiers: 25, Simple: "iter__331000086__331000090", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_handles_iter__331000086__331000090_A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_handles_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_class, Name: "arbace.a2g.vh$handles$iter__331000086__331000090$fn__331000091", Modifiers: 25, Simple: "fn__331000091", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_handles_iter__331000086__331000090_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_class, Name: "arbace.a2g.vh$handles$iter__331000086__331000090$fn__331000091$fn__331000092", Modifiers: 25, Simple: "fn__331000092", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_mode_A_class, Name: "arbace.a2g.vh$mode", Modifiers: 25, Simple: "mode", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_mode_A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_op_handle_A_class, Name: "arbace.a2g.vh$op_handle", Modifiers: 25, Simple: "op_handle", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_op_handle_A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_static_flag_QMARK__A_class, Name: "arbace.a2g.vh$static_flag_QMARK_", Modifiers: 25, Simple: "static_flag_QMARK_", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_static_flag_QMARK__A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_vh_string_arg_A_class, Name: "arbace.a2g.vh$string_arg", Modifiers: 25, Simple: "string_arg", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_string_arg_A", Source: "vh.ae", Declaring: &A_arbace_a2g_vh_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_a2g_vh_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_A_New()}; return nil }

var A_arbace_a2g_vh_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_vh_A_new}

var A_arbace_a2g_vh_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_A"})

func init() { i := A_arbace_a2g_vh_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_A_InstanceOf; i.Init = A_arbace_a2g_vh_A_Init; i.Table = A_arbace_a2g_vh_A_members }

var A_arbace_a2g_vh_byte_order_arg_A_class *jrt.Class

var A_arbace_a2g_vh_class_arg_A_class *jrt.Class

var A_arbace_a2g_vh_class_handles_A_class *jrt.Class

var A_arbace_a2g_vh_class_handles_fn__331000032_A_class *jrt.Class

var A_arbace_a2g_vh_class_handles_fn__331000044_A_class *jrt.Class

var A_arbace_a2g_vh_class_handles_fn__331000060_A_class *jrt.Class

var A_arbace_a2g_vh_class_handles_fn__331000062_A_class *jrt.Class

func A_arbace_a2g_vh_eval331000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_eval331000004_A_New()}; return nil }

var A_arbace_a2g_vh_eval331000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_vh_eval331000004_A_new}

var A_arbace_a2g_vh_eval331000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$eval331000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_vh_A_class, Simple: "eval331000004", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_eval331000004_A"})

func init() { i := A_arbace_a2g_vh_eval331000004_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_eval331000004_A_InstanceOf; i.Table = A_arbace_a2g_vh_eval331000004_A_members }

var A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_class *jrt.Class

func A_arbace_a2g_vh_eval331000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_eval331000008_A_New()}; return nil }

var A_arbace_a2g_vh_eval331000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_vh_eval331000008_A_new}

var A_arbace_a2g_vh_eval331000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$eval331000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_vh_A_class, Simple: "eval331000008", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_eval331000008_A"})

func init() { i := A_arbace_a2g_vh_eval331000008_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_eval331000008_A_InstanceOf; i.Table = A_arbace_a2g_vh_eval331000008_A_members }

var A_arbace_a2g_vh_eval331000008_fn__331000009_A_class *jrt.Class

var A_arbace_a2g_vh_fence_QMARK__A_class *jrt.Class

var A_arbace_a2g_vh_find_field_A_class *jrt.Class

var A_arbace_a2g_vh_find_field_fn__331000018_A_class *jrt.Class

var A_arbace_a2g_vh_handle_spec_A_class *jrt.Class

var A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_class *jrt.Class

var A_arbace_a2g_vh_handles_A_class *jrt.Class

var A_arbace_a2g_vh_handles_iter__331000066__331000072_A_class *jrt.Class

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_class *jrt.Class

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_class *jrt.Class

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_class *jrt.Class

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_class *jrt.Class

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_class *jrt.Class

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_class *jrt.Class

var A_arbace_a2g_vh_handles_iter__331000086__331000090_A_class *jrt.Class

var A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_class *jrt.Class

var A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_class *jrt.Class

var A_arbace_a2g_vh_mode_A_class *jrt.Class

var A_arbace_a2g_vh_op_handle_A_class *jrt.Class

var A_arbace_a2g_vh_static_flag_QMARK__A_class *jrt.Class

var A_arbace_a2g_vh_string_arg_A_class *jrt.Class

func A_arbace_a2g_vh__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_a2g_vh__init_A_Load__O()}; return nil }

func A_arbace_a2g_vh__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh__init_A_New()}; return nil }

var A_arbace_a2g_vh__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_a2g_vh__init_A_invoke, New: A_arbace_a2g_vh__init_A_new}

var A_arbace_a2g_vh__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh__init_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh__init_A_class.Info(); i.IsInstance = A_arbace_a2g_vh__init_A_InstanceOf; i.Init = A_arbace_a2g_vh__init_A_Init; i.Table = A_arbace_a2g_vh__init_A_members }
