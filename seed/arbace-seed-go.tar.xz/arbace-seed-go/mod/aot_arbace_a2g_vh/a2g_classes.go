//line a2g_classes.ae:1
package aot_arbace_a2g_vh

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_a2g_vh_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_A_New()}; return nil }

var A_arbace_a2g_vh_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_vh_A_new}

var A_arbace_a2g_vh_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_A"})

func init() { i := A_arbace_a2g_vh_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_A_InstanceOf; i.Init = A_arbace_a2g_vh_A_Init; i.Table = A_arbace_a2g_vh_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_A_class, reflect.TypeFor[A_arbace_a2g_vh_A]()) }

func A_arbace_a2g_vh_byte_order_arg_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_byte_order_arg_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_vh_byte_order_arg_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_byte_order_arg_A_New()}; return nil }

func A_arbace_a2g_vh_byte_order_arg_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_byte_order_arg_A_fn_class)}; return nil }

var A_arbace_a2g_vh_byte_order_arg_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_byte_order_arg_A_invoke, New: A_arbace_a2g_vh_byte_order_arg_A_new, Get: A_arbace_a2g_vh_byte_order_arg_A_get}

var A_arbace_a2g_vh_byte_order_arg_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$byte_order_arg", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_vh_A_class, Simple: "byte_order_arg", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_byte_order_arg_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_byte_order_arg_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_byte_order_arg_A_InstanceOf; i.Init = A_arbace_a2g_vh_byte_order_arg_A_Init; i.Table = A_arbace_a2g_vh_byte_order_arg_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_byte_order_arg_A_class, reflect.TypeFor[A_arbace_a2g_vh_byte_order_arg_A]()) }

func A_arbace_a2g_vh_class_arg_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_class_arg_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_vh_class_arg_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_class_arg_A_New()}; return nil }

func A_arbace_a2g_vh_class_arg_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_class_arg_A_fn_class)}; return nil }

var A_arbace_a2g_vh_class_arg_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_class_arg_A_invoke, New: A_arbace_a2g_vh_class_arg_A_new, Get: A_arbace_a2g_vh_class_arg_A_get}

var A_arbace_a2g_vh_class_arg_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$class_arg", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_vh_A_class, Simple: "class_arg", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_class_arg_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_class_arg_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_class_arg_A_InstanceOf; i.Init = A_arbace_a2g_vh_class_arg_A_Init; i.Table = A_arbace_a2g_vh_class_arg_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_class_arg_A_class, reflect.TypeFor[A_arbace_a2g_vh_class_arg_A]()) }

func A_arbace_a2g_vh_class_handles_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_class_handles_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_vh_class_handles_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_class_handles_A_New()}; return nil }

func A_arbace_a2g_vh_class_handles_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_class_handles_A_fn_class)}; return nil }

var A_arbace_a2g_vh_class_handles_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_class_handles_A_invoke, New: A_arbace_a2g_vh_class_handles_A_new, Get: A_arbace_a2g_vh_class_handles_A_get}

var A_arbace_a2g_vh_class_handles_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$class_handles", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_vh_A_class, Simple: "class_handles", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_class_handles_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_class_handles_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_class_handles_A_InstanceOf; i.Init = A_arbace_a2g_vh_class_handles_A_Init; i.Table = A_arbace_a2g_vh_class_handles_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_class_handles_A_class, reflect.TypeFor[A_arbace_a2g_vh_class_handles_A]()) }

func A_arbace_a2g_vh_class_handles_fn__331000032_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_class_handles_fn__331000032_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_vh_class_handles_fn__331000032_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_class_handles_fn__331000032_A_New_O(args[0])}; return nil }

func A_arbace_a2g_vh_class_handles_fn__331000032_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_class_handles_fn__331000032_A_fn_class)}; return nil }

var A_arbace_a2g_vh_class_handles_fn__331000032_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_class_handles_fn__331000032_A_invoke, New: A_arbace_a2g_vh_class_handles_fn__331000032_A_new, Get: A_arbace_a2g_vh_class_handles_fn__331000032_A_get}

var A_arbace_a2g_vh_class_handles_fn__331000032_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$class_handles$fn__331000032", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_vh_class_handles_A_class, Simple: "fn__331000032", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_class_handles_fn__331000032_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_class_handles_fn__331000032_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_class_handles_fn__331000032_A_InstanceOf; i.Init = A_arbace_a2g_vh_class_handles_fn__331000032_A_Init; i.Table = A_arbace_a2g_vh_class_handles_fn__331000032_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_class_handles_fn__331000032_A_class, reflect.TypeFor[A_arbace_a2g_vh_class_handles_fn__331000032_A]()) }

func A_arbace_a2g_vh_class_handles_fn__331000044_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_class_handles_fn__331000044_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_vh_class_handles_fn__331000044_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_class_handles_fn__331000044_A_New_O(args[0])}; return nil }

func A_arbace_a2g_vh_class_handles_fn__331000044_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_class_handles_fn__331000044_A_fn_class)}; return nil }

var A_arbace_a2g_vh_class_handles_fn__331000044_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_class_handles_fn__331000044_A_invoke, New: A_arbace_a2g_vh_class_handles_fn__331000044_A_new, Get: A_arbace_a2g_vh_class_handles_fn__331000044_A_get}

var A_arbace_a2g_vh_class_handles_fn__331000044_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$class_handles$fn__331000044", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_vh_class_handles_A_class, Simple: "fn__331000044", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_class_handles_fn__331000044_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_class_handles_fn__331000044_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_class_handles_fn__331000044_A_InstanceOf; i.Init = A_arbace_a2g_vh_class_handles_fn__331000044_A_Init; i.Table = A_arbace_a2g_vh_class_handles_fn__331000044_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_class_handles_fn__331000044_A_class, reflect.TypeFor[A_arbace_a2g_vh_class_handles_fn__331000044_A]()) }

func A_arbace_a2g_vh_class_handles_fn__331000060_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_class_handles_fn__331000060_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_vh_class_handles_fn__331000060_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_class_handles_fn__331000060_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_vh_class_handles_fn__331000060_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_class_handles_fn__331000060_A_fn_class)}; return nil }

var A_arbace_a2g_vh_class_handles_fn__331000060_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_class_handles_fn__331000060_A_invoke, New: A_arbace_a2g_vh_class_handles_fn__331000060_A_new, Get: A_arbace_a2g_vh_class_handles_fn__331000060_A_get}

var A_arbace_a2g_vh_class_handles_fn__331000060_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$class_handles$fn__331000060", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_vh_class_handles_A_class, Simple: "fn__331000060", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_class_handles_fn__331000060_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_class_handles_fn__331000060_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_class_handles_fn__331000060_A_InstanceOf; i.Init = A_arbace_a2g_vh_class_handles_fn__331000060_A_Init; i.Table = A_arbace_a2g_vh_class_handles_fn__331000060_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_class_handles_fn__331000060_A_class, reflect.TypeFor[A_arbace_a2g_vh_class_handles_fn__331000060_A]()) }

func A_arbace_a2g_vh_class_handles_fn__331000062_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_class_handles_fn__331000062_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_vh_class_handles_fn__331000062_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_class_handles_fn__331000062_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_vh_class_handles_fn__331000062_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_class_handles_fn__331000062_A_fn_class)}; return nil }

var A_arbace_a2g_vh_class_handles_fn__331000062_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_class_handles_fn__331000062_A_invoke, New: A_arbace_a2g_vh_class_handles_fn__331000062_A_new, Get: A_arbace_a2g_vh_class_handles_fn__331000062_A_get}

var A_arbace_a2g_vh_class_handles_fn__331000062_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$class_handles$fn__331000062", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_vh_class_handles_A_class, Simple: "fn__331000062", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_class_handles_fn__331000062_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_class_handles_fn__331000062_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_class_handles_fn__331000062_A_InstanceOf; i.Init = A_arbace_a2g_vh_class_handles_fn__331000062_A_Init; i.Table = A_arbace_a2g_vh_class_handles_fn__331000062_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_class_handles_fn__331000062_A_class, reflect.TypeFor[A_arbace_a2g_vh_class_handles_fn__331000062_A]()) }

func A_arbace_a2g_vh_eval331000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_eval331000004_A_New()}; return nil }

var A_arbace_a2g_vh_eval331000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_vh_eval331000004_A_new}

var A_arbace_a2g_vh_eval331000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$eval331000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_vh_A_class, Simple: "eval331000004", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_eval331000004_A"})

func init() { i := A_arbace_a2g_vh_eval331000004_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_eval331000004_A_InstanceOf; i.Table = A_arbace_a2g_vh_eval331000004_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_eval331000004_A_class, reflect.TypeFor[A_arbace_a2g_vh_eval331000004_A]()) }

func A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_New()}; return nil }

func A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_fn_class)}; return nil }

var A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_invoke, New: A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_new, Get: A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_get}

var A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$eval331000004$loading__1927001464__auto____331000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_vh_eval331000004_A_class, Simple: "loading__1927001464__auto____331000005", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_InstanceOf; i.Init = A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_Init; i.Table = A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A_class, reflect.TypeFor[A_arbace_a2g_vh_eval331000004_loading__1927001464__auto____331000005_A]()) }

func A_arbace_a2g_vh_eval331000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_eval331000008_A_New()}; return nil }

var A_arbace_a2g_vh_eval331000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_vh_eval331000008_A_new}

var A_arbace_a2g_vh_eval331000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$eval331000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_vh_A_class, Simple: "eval331000008", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_eval331000008_A"})

func init() { i := A_arbace_a2g_vh_eval331000008_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_eval331000008_A_InstanceOf; i.Table = A_arbace_a2g_vh_eval331000008_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_eval331000008_A_class, reflect.TypeFor[A_arbace_a2g_vh_eval331000008_A]()) }

func A_arbace_a2g_vh_eval331000008_fn__331000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_eval331000008_fn__331000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_vh_eval331000008_fn__331000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_eval331000008_fn__331000009_A_New()}; return nil }

func A_arbace_a2g_vh_eval331000008_fn__331000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_eval331000008_fn__331000009_A_fn_class)}; return nil }

var A_arbace_a2g_vh_eval331000008_fn__331000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_eval331000008_fn__331000009_A_invoke, New: A_arbace_a2g_vh_eval331000008_fn__331000009_A_new, Get: A_arbace_a2g_vh_eval331000008_fn__331000009_A_get}

var A_arbace_a2g_vh_eval331000008_fn__331000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$eval331000008$fn__331000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_vh_eval331000008_A_class, Simple: "fn__331000009", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_eval331000008_fn__331000009_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_eval331000008_fn__331000009_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_eval331000008_fn__331000009_A_InstanceOf; i.Init = A_arbace_a2g_vh_eval331000008_fn__331000009_A_Init; i.Table = A_arbace_a2g_vh_eval331000008_fn__331000009_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_eval331000008_fn__331000009_A_class, reflect.TypeFor[A_arbace_a2g_vh_eval331000008_fn__331000009_A]()) }

func A_arbace_a2g_vh_fence_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_fence_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_vh_fence_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_fence_QMARK__A_New()}; return nil }

func A_arbace_a2g_vh_fence_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_fence_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_vh_fence_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_fence_QMARK__A_invoke, New: A_arbace_a2g_vh_fence_QMARK__A_new, Get: A_arbace_a2g_vh_fence_QMARK__A_get}

var A_arbace_a2g_vh_fence_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$fence_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_vh_A_class, Simple: "fence_QMARK_", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_fence_QMARK__A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_fence_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_vh_fence_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_vh_fence_QMARK__A_Init; i.Table = A_arbace_a2g_vh_fence_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_vh_fence_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_vh_fence_QMARK__A]()) }

func A_arbace_a2g_vh_find_field_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_find_field_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_vh_find_field_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_find_field_A_New()}; return nil }

func A_arbace_a2g_vh_find_field_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_find_field_A_fn_class)}; return nil }

var A_arbace_a2g_vh_find_field_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_find_field_A_invoke, New: A_arbace_a2g_vh_find_field_A_new, Get: A_arbace_a2g_vh_find_field_A_get}

var A_arbace_a2g_vh_find_field_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$find_field", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_vh_A_class, Simple: "find_field", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_find_field_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_find_field_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_find_field_A_InstanceOf; i.Init = A_arbace_a2g_vh_find_field_A_Init; i.Table = A_arbace_a2g_vh_find_field_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_find_field_A_class, reflect.TypeFor[A_arbace_a2g_vh_find_field_A]()) }

func A_arbace_a2g_vh_find_field_fn__331000018_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_find_field_fn__331000018_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_vh_find_field_fn__331000018_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_find_field_fn__331000018_A_New_O(args[0])}; return nil }

func A_arbace_a2g_vh_find_field_fn__331000018_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_find_field_fn__331000018_A_fn_class)}; return nil }

var A_arbace_a2g_vh_find_field_fn__331000018_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_find_field_fn__331000018_A_invoke, New: A_arbace_a2g_vh_find_field_fn__331000018_A_new, Get: A_arbace_a2g_vh_find_field_fn__331000018_A_get}

var A_arbace_a2g_vh_find_field_fn__331000018_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$find_field$fn__331000018", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_vh_find_field_A_class, Simple: "fn__331000018", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_find_field_fn__331000018_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_find_field_fn__331000018_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_find_field_fn__331000018_A_InstanceOf; i.Init = A_arbace_a2g_vh_find_field_fn__331000018_A_Init; i.Table = A_arbace_a2g_vh_find_field_fn__331000018_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_find_field_fn__331000018_A_class, reflect.TypeFor[A_arbace_a2g_vh_find_field_fn__331000018_A]()) }

func A_arbace_a2g_vh_handle_spec_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_handle_spec_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_vh_handle_spec_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_handle_spec_A_New()}; return nil }

func A_arbace_a2g_vh_handle_spec_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_handle_spec_A_fn_class)}; return nil }

var A_arbace_a2g_vh_handle_spec_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_handle_spec_A_invoke, New: A_arbace_a2g_vh_handle_spec_A_new, Get: A_arbace_a2g_vh_handle_spec_A_get}

var A_arbace_a2g_vh_handle_spec_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$handle_spec", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_vh_A_class, Simple: "handle_spec", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_handle_spec_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_handle_spec_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_handle_spec_A_InstanceOf; i.Init = A_arbace_a2g_vh_handle_spec_A_Init; i.Table = A_arbace_a2g_vh_handle_spec_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_handle_spec_A_class, reflect.TypeFor[A_arbace_a2g_vh_handle_spec_A]()) }

func A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_handle_spec_field_spec__331000022_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_New()}; return nil }

func A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_fn_class)}; return nil }

var A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_invoke, New: A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_new, Get: A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_get}

var A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$handle_spec$field_spec__331000022", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_vh_handle_spec_A_class, Simple: "field_spec__331000022", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_handle_spec_field_spec__331000022_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_InstanceOf; i.Init = A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_Init; i.Table = A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_handle_spec_field_spec__331000022_A_class, reflect.TypeFor[A_arbace_a2g_vh_handle_spec_field_spec__331000022_A]()) }

func A_arbace_a2g_vh_handles_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_handles_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_vh_handles_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_handles_A_New()}; return nil }

func A_arbace_a2g_vh_handles_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_handles_A_fn_class)}; return nil }

var A_arbace_a2g_vh_handles_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_handles_A_invoke, New: A_arbace_a2g_vh_handles_A_new, Get: A_arbace_a2g_vh_handles_A_get}

var A_arbace_a2g_vh_handles_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$handles", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_vh_A_class, Simple: "handles", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_handles_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_handles_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_handles_A_InstanceOf; i.Init = A_arbace_a2g_vh_handles_A_Init; i.Table = A_arbace_a2g_vh_handles_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_handles_A_class, reflect.TypeFor[A_arbace_a2g_vh_handles_A]()) }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_handles_iter__331000066__331000072_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_handles_iter__331000066__331000072_A_New()}; return nil }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_handles_iter__331000066__331000072_A_fn_class)}; return nil }

var A_arbace_a2g_vh_handles_iter__331000066__331000072_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_handles_iter__331000066__331000072_A_invoke, New: A_arbace_a2g_vh_handles_iter__331000066__331000072_A_new, Get: A_arbace_a2g_vh_handles_iter__331000066__331000072_A_get}

var A_arbace_a2g_vh_handles_iter__331000066__331000072_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$handles$iter__331000066__331000072", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_vh_handles_A_class, Simple: "iter__331000066__331000072", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_handles_iter__331000066__331000072_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_handles_iter__331000066__331000072_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_handles_iter__331000066__331000072_A_InstanceOf; i.Init = A_arbace_a2g_vh_handles_iter__331000066__331000072_A_Init; i.Table = A_arbace_a2g_vh_handles_iter__331000066__331000072_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_handles_iter__331000066__331000072_A_class, reflect.TypeFor[A_arbace_a2g_vh_handles_iter__331000066__331000072_A]()) }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_fn_class)}; return nil }

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_invoke, New: A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_new, Get: A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_get}

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$handles$iter__331000066__331000072$fn__331000073", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_vh_handles_iter__331000066__331000072_A_class, Simple: "fn__331000073", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_InstanceOf; i.Init = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_Init; i.Table = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_class, reflect.TypeFor[A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A]()) }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_New()}; return nil }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_fn_class)}; return nil }

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_invoke, New: A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_new, Get: A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_get}

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$handles$iter__331000066__331000072$fn__331000073$fn__331000074", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_class, Simple: "fn__331000074", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_InstanceOf; i.Init = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_Init; i.Table = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A_class, reflect.TypeFor[A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000074_A]()) }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_New_O(args[0])}; return nil }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_fn_class)}; return nil }

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_invoke, New: A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_new, Get: A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_get}

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$handles$iter__331000066__331000072$fn__331000073$fn__331000082", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_class, Simple: "fn__331000082", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_InstanceOf; i.Init = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_Init; i.Table = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A_class, reflect.TypeFor[A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_fn__331000082_A]()) }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_New()}; return nil }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_fn_class)}; return nil }

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_invoke, New: A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_new, Get: A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_get}

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$handles$iter__331000066__331000072$fn__331000073$iter__331000068__331000076", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_A_class, Simple: "iter__331000068__331000076", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_InstanceOf; i.Init = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_Init; i.Table = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_class, reflect.TypeFor[A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A]()) }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_fn_class)}; return nil }

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_invoke, New: A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_new, Get: A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_get}

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$handles$iter__331000066__331000072$fn__331000073$iter__331000068__331000076$fn__331000077", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_A_class, Simple: "fn__331000077", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_InstanceOf; i.Init = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_Init; i.Table = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_class, reflect.TypeFor[A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A]()) }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_fn_class)}; return nil }

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_invoke, New: A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_new, Get: A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_get}

var A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$handles$iter__331000066__331000072$fn__331000073$iter__331000068__331000076$fn__331000077$fn__331000078", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_A_class, Simple: "fn__331000078", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_InstanceOf; i.Init = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_Init; i.Table = A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A_class, reflect.TypeFor[A_arbace_a2g_vh_handles_iter__331000066__331000072_fn__331000073_iter__331000068__331000076_fn__331000077_fn__331000078_A]()) }

func A_arbace_a2g_vh_handles_iter__331000086__331000090_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_handles_iter__331000086__331000090_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_vh_handles_iter__331000086__331000090_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_handles_iter__331000086__331000090_A_New()}; return nil }

func A_arbace_a2g_vh_handles_iter__331000086__331000090_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_handles_iter__331000086__331000090_A_fn_class)}; return nil }

var A_arbace_a2g_vh_handles_iter__331000086__331000090_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_handles_iter__331000086__331000090_A_invoke, New: A_arbace_a2g_vh_handles_iter__331000086__331000090_A_new, Get: A_arbace_a2g_vh_handles_iter__331000086__331000090_A_get}

var A_arbace_a2g_vh_handles_iter__331000086__331000090_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$handles$iter__331000086__331000090", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_vh_handles_A_class, Simple: "iter__331000086__331000090", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_handles_iter__331000086__331000090_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_handles_iter__331000086__331000090_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_handles_iter__331000086__331000090_A_InstanceOf; i.Init = A_arbace_a2g_vh_handles_iter__331000086__331000090_A_Init; i.Table = A_arbace_a2g_vh_handles_iter__331000086__331000090_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_handles_iter__331000086__331000090_A_class, reflect.TypeFor[A_arbace_a2g_vh_handles_iter__331000086__331000090_A]()) }

func A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_fn_class)}; return nil }

var A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_invoke, New: A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_new, Get: A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_get}

var A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$handles$iter__331000086__331000090$fn__331000091", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_vh_handles_iter__331000086__331000090_A_class, Simple: "fn__331000091", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_InstanceOf; i.Init = A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_Init; i.Table = A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_class, reflect.TypeFor[A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A]()) }

func A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_fn_class)}; return nil }

var A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_invoke, New: A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_new, Get: A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_get}

var A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$handles$iter__331000086__331000090$fn__331000091$fn__331000092", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_A_class, Simple: "fn__331000092", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_InstanceOf; i.Init = A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_Init; i.Table = A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A_class, reflect.TypeFor[A_arbace_a2g_vh_handles_iter__331000086__331000090_fn__331000091_fn__331000092_A]()) }

func A_arbace_a2g_vh_mode_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_mode_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_vh_mode_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_mode_A_New()}; return nil }

func A_arbace_a2g_vh_mode_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_mode_A_fn_class)}; return nil }

var A_arbace_a2g_vh_mode_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_mode_A_invoke, New: A_arbace_a2g_vh_mode_A_new, Get: A_arbace_a2g_vh_mode_A_get}

var A_arbace_a2g_vh_mode_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$mode", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_vh_A_class, Simple: "mode", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_mode_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_mode_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_mode_A_InstanceOf; i.Init = A_arbace_a2g_vh_mode_A_Init; i.Table = A_arbace_a2g_vh_mode_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_mode_A_class, reflect.TypeFor[A_arbace_a2g_vh_mode_A]()) }

func A_arbace_a2g_vh_op_handle_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_op_handle_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_vh_op_handle_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_op_handle_A_New()}; return nil }

func A_arbace_a2g_vh_op_handle_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_op_handle_A_fn_class)}; return nil }

var A_arbace_a2g_vh_op_handle_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_op_handle_A_invoke, New: A_arbace_a2g_vh_op_handle_A_new, Get: A_arbace_a2g_vh_op_handle_A_get}

var A_arbace_a2g_vh_op_handle_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$op_handle", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_vh_A_class, Simple: "op_handle", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_op_handle_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_op_handle_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_op_handle_A_InstanceOf; i.Init = A_arbace_a2g_vh_op_handle_A_Init; i.Table = A_arbace_a2g_vh_op_handle_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_op_handle_A_class, reflect.TypeFor[A_arbace_a2g_vh_op_handle_A]()) }

func A_arbace_a2g_vh_static_flag_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_static_flag_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_vh_static_flag_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_static_flag_QMARK__A_New()}; return nil }

func A_arbace_a2g_vh_static_flag_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_static_flag_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_vh_static_flag_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_static_flag_QMARK__A_invoke, New: A_arbace_a2g_vh_static_flag_QMARK__A_new, Get: A_arbace_a2g_vh_static_flag_QMARK__A_get}

var A_arbace_a2g_vh_static_flag_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$static_flag_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_vh_A_class, Simple: "static_flag_QMARK_", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_static_flag_QMARK__A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_static_flag_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_vh_static_flag_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_vh_static_flag_QMARK__A_Init; i.Table = A_arbace_a2g_vh_static_flag_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_vh_static_flag_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_vh_static_flag_QMARK__A]()) }

func A_arbace_a2g_vh_string_arg_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_vh_string_arg_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_vh_string_arg_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh_string_arg_A_New()}; return nil }

func A_arbace_a2g_vh_string_arg_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_vh_string_arg_A_fn_class)}; return nil }

var A_arbace_a2g_vh_string_arg_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_vh_string_arg_A_invoke, New: A_arbace_a2g_vh_string_arg_A_new, Get: A_arbace_a2g_vh_string_arg_A_get}

var A_arbace_a2g_vh_string_arg_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh$string_arg", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_vh_A_class, Simple: "string_arg", Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh_string_arg_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh_string_arg_A_class.Info(); i.IsInstance = A_arbace_a2g_vh_string_arg_A_InstanceOf; i.Init = A_arbace_a2g_vh_string_arg_A_Init; i.Table = A_arbace_a2g_vh_string_arg_A_members; jrt.RegisterGoType(A_arbace_a2g_vh_string_arg_A_class, reflect.TypeFor[A_arbace_a2g_vh_string_arg_A]()) }

func A_arbace_a2g_vh__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_a2g_vh__init_A_Load__O(); case 1: return A_arbace_a2g_vh__init_A_Unit0__O(); case 2: return A_arbace_a2g_vh__init_A_Unit1__O(); case 3: return A_arbace_a2g_vh__init_A_Unit10__O(); case 4: return A_arbace_a2g_vh__init_A_Unit11__O(); case 5: return A_arbace_a2g_vh__init_A_Unit12__O(); case 6: return A_arbace_a2g_vh__init_A_Unit13__O(); case 7: return A_arbace_a2g_vh__init_A_Unit14__O(); case 8: return A_arbace_a2g_vh__init_A_Unit15__O(); case 9: return A_arbace_a2g_vh__init_A_Unit16__O(); case 10: return A_arbace_a2g_vh__init_A_Unit17__O(); case 11: return A_arbace_a2g_vh__init_A_Unit18__O(); case 12: return A_arbace_a2g_vh__init_A_Unit2__O(); case 13: return A_arbace_a2g_vh__init_A_Unit3__O(); case 14: return A_arbace_a2g_vh__init_A_Unit4__O(); case 15: return A_arbace_a2g_vh__init_A_Unit5__O(); case 16: return A_arbace_a2g_vh__init_A_Unit6__O(); case 17: return A_arbace_a2g_vh__init_A_Unit7__O(); case 18: return A_arbace_a2g_vh__init_A_Unit8__O(); case 19: return A_arbace_a2g_vh__init_A_Unit9__O()}; return nil }

func A_arbace_a2g_vh__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_vh__init_A_New()}; return nil }

var A_arbace_a2g_vh__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_a2g_vh__init_A_invoke, New: A_arbace_a2g_vh__init_A_new}

var A_arbace_a2g_vh__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.vh__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_vh.A_arbace_a2g_vh__init_A", Source: "vh.ae"})

func init() { i := A_arbace_a2g_vh__init_A_class.Info(); i.IsInstance = A_arbace_a2g_vh__init_A_InstanceOf; i.Init = A_arbace_a2g_vh__init_A_Init; i.Table = A_arbace_a2g_vh__init_A_members; jrt.RegisterGoType(A_arbace_a2g_vh__init_A_class, reflect.TypeFor[A_arbace_a2g_vh__init_A]()) }
