//line aot_arbace_data.ae:1
package aot_arbace_data

import (
	"arbace/jrt"
	"arbace/lang"
)


func A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_New() *A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A { A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_Init(); t := &A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_data_A_Init(); tmp4 = A_arbace_data_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_data_A_Init(); tmp6 = A_arbace_data_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_data_A_Init(); tmp7 = A_arbace_data_A_const_0; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_data_A_Init(); tmp9 = A_arbace_data_A_const_3; tmp3 = tmp8.Invoke_O__O(tmp9) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp10 != nil { panic(tmp10) }; return tmp3 }
//line :9:1
func A_arbace_data_eval76000008_fn__76000009_A_New() *A_arbace_data_eval76000008_fn__76000009_A { A_arbace_data_eval76000008_fn__76000009_A_Init(); t := &A_arbace_data_eval76000008_fn__76000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_data_eval76000008_fn__76000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_data_eval76000008_fn__76000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_data_A_Init(); tmp1 = A_arbace_data_A_const_4; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_data_A_Init(); tmp3 = A_arbace_data_A_const_5; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_data_A_Init(); tmp5 = A_arbace_data_A_const_8; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_data_A_Init(); tmp7 = A_arbace_data_A_const_6; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_data_A_Init(); tmp9 = A_arbace_data_A_const_7; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }









func A_arbace_data_atom_diff_A_New() *A_arbace_data_atom_diff_A { A_arbace_data_atom_diff_A_Init(); t := &A_arbace_data_atom_diff_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_data_atom_diff_A) Ctor() {}
//line :19:1
func (t *A_arbace_data_atom_diff_A) Invoke_O_O_O__O(self, a__0, b__1 any) any {


	if lang.Util_Equiv_O_O__Z(a__0, b__1) { return lang.Tuple_Create_O_O_O__IPersistentVector(nil, nil, a__0) } else { return lang.Tuple_Create_O_O_O__IPersistentVector(a__0, b__1, nil)
	}
}
func A_arbace_data_vectorize_A_New() *A_arbace_data_vectorize_A { A_arbace_data_vectorize_A_Init(); t := &A_arbace_data_vectorize_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_data_vectorize_A) Ctor() {}
//line :25:1
func (t *A_arbace_data_vectorize_A) Invoke_O_O__O(self, m__0 any) any {



	var tmp1 *lang.Var; A_arbace_data_A_Init(); tmp1 = A_arbace_data_A_const_9; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(m__0)) {
		var tmp2 *lang.Var; A_arbace_data_A_Init(); tmp2 = A_arbace_data_A_const_10; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = A_arbace_data_vectorize_fn__76000016_A_New(); var tmp5 *jrt.Class; A_arbace_data_vectorize_fn__76000016_A_Init(); tmp5 = A_arbace_data_vectorize_fn__76000016_A_fn_class; var tmp6 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp7 *lang.Var; A_arbace_data_A_Init(); tmp7 = A_arbace_data_A_const_12; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_data_A_Init(); tmp9 = A_arbace_data_A_const_13; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_data_A_Init(); tmp11 = A_arbace_data_A_const_14; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_data_A_Init(); tmp13 = A_arbace_data_A_const_15; var tmp14 any = jrt.NN(tmp13).GetRawRoot__O(); var tmp15 *lang.Var; A_arbace_data_A_Init(); tmp15 = A_arbace_data_A_const_16; return tmp3.Invoke_O_O_O__O(tmp6, tmp8.Invoke_O__O(tmp10.Invoke_O_O__O(tmp12.Invoke_O_O__O(tmp14, lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(m__0)), nil)), m__0) } else {
//line :29:1
			return nil
		} }
func A_arbace_data_vectorize_fn__76000016_A_New() *A_arbace_data_vectorize_fn__76000016_A { A_arbace_data_vectorize_fn__76000016_A_Init(); t := &A_arbace_data_vectorize_fn__76000016_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_data_vectorize_fn__76000016_A) Ctor() {}
//line :31:1
func (t *A_arbace_data_vectorize_fn__76000016_A) Invoke_O_O_O__O(self, result__1, p__76000015__2 any) any { var vec__76000017__3 any = p__76000015__2; var k__4 any = lang.RT_Nth_O_I_O__O(vec__76000017__3, lang.RT_IntCast_J__I(0), nil); var v__5 any = lang.RT_Nth_O_I_O__O(vec__76000017__3, lang.RT_IntCast_J__I(1), nil); var tmp1 *lang.Var; A_arbace_data_A_Init(); tmp1 = A_arbace_data_A_const_11; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(result__1, k__4, v__5) }



func A_arbace_data_diff_associative_key_A_New() *A_arbace_data_diff_associative_key_A { A_arbace_data_diff_associative_key_A_Init(); t := &A_arbace_data_diff_associative_key_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_data_diff_associative_key_A) Ctor() {}
//line :35:1
func (t *A_arbace_data_diff_associative_key_A) Invoke_O_O_O_O__O(self, a__0, b__1, k__2 any) any { var va__4 any = lang.RT_Get_O_O__O(a__0, k__2); var vb__5 any = lang.RT_Get_O_O__O(b__1, k__2); var vec__76000022__6 any; var tmp1 *lang.Var;




	A_arbace_data_A_Init(); tmp1 = A_arbace_data_A_const_17; vec__76000022__6 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(va__4, vb__5); var a_STAR___7 any = /*line :35:1*/lang.RT_Nth_O_I_O__O(vec__76000022__6, lang.RT_IntCast_J__I(0), nil); var b_STAR___8 any = lang.RT_Nth_O_I_O__O(vec__76000022__6, lang.RT_IntCast_J__I(1), nil); var ab__9 any = lang.RT_Nth_O_I_O__O(vec__76000022__6, lang.RT_IntCast_J__I(2), nil); var in_a__10 any; var tmp2 *lang.Var;





	A_arbace_data_A_Init(); tmp2 = A_arbace_data_A_const_18; in_a__10 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(a__0, k__2); var in_b__11 any; var tmp3 /*line :35:1*/*lang.Var;






	A_arbace_data_A_Init(); tmp3 = A_arbace_data_A_const_18; in_b__11 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(b__1, k__2); var same__12 any; var and__1927000168__auto____12 any = in_a__10; if
	jrt.A2g_Truth(and__1927000168__auto____12) { var and__1927000168__auto____13 any = in_b__11; if jrt.A2g_Truth(and__1927000168__auto____13) { var or__1927000174__auto____14 any; var tmp4 *lang.Var
		A_arbace_data_A_Init(); tmp4 = A_arbace_data_A_const_19; or__1927000174__auto____14 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(ab__9, nil)).Ref()); if jrt.A2g_Truth(or__1927000174__auto____14) { same__12 = or__1927000174__auto____14 } else { var and__1927000168__auto____15 bool = lang.Util_Identical_O_O__Z(va__4, nil)
			if and__1927000168__auto____15 { same__12 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(vb__5, nil)).Ref() } else { same__12 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____15).Ref() } } } else {
//line :43:1
				same__12 = and__1927000168__auto____13 } } else { same__12 = and__1927000168__auto____12 }; var tmp5 lang.IPersistentMap; var tmp6 any; var and__1927000168__auto____13_2 any = in_a__10; if


	jrt.A2g_Truth(and__1927000168__auto____13_2) { var or__1927000174__auto____14_2 any; var tmp7 *lang.Var; A_arbace_data_A_Init(); tmp7 = A_arbace_data_A_const_19; or__1927000174__auto____14_2 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(a_STAR___7, nil)).Ref()); if jrt.A2g_Truth(or__1927000174__auto____14_2) { tmp6 = or__1927000174__auto____14_2 } else { var tmp8 *lang.Var; A_arbace_data_A_Init(); tmp8 = A_arbace_data_A_const_19; tmp6 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(same__12) } } else { tmp6 = and__1927000168__auto____13_2 }; if jrt.A2g_Truth(tmp6) { tmp5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, k__2, a_STAR___7)) } else { tmp5 = nil }; var tmp9 any = tmp5; var tmp10 lang.IPersistentMap; var tmp11 any; var and__1927000168__auto____13_3 any = in_b__11; if
	jrt.A2g_Truth(and__1927000168__auto____13_3) { var or__1927000174__auto____14_3 any; var tmp12 *lang.Var; A_arbace_data_A_Init(); tmp12 = A_arbace_data_A_const_19; or__1927000174__auto____14_3 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(b_STAR___8, nil)).Ref()); if jrt.A2g_Truth(or__1927000174__auto____14_3) { tmp11 = or__1927000174__auto____14_3 } else { var tmp13 *lang.Var; A_arbace_data_A_Init(); tmp13 = A_arbace_data_A_const_19; tmp11 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(same__12) } } else { tmp11 = and__1927000168__auto____13_3 }; if jrt.A2g_Truth(tmp11) { tmp10 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, k__2, b_STAR___8)) } else { tmp10 = nil }; var tmp14 any = tmp10; var tmp15 lang.IPersistentMap; if
	jrt.A2g_Truth(same__12) { tmp15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, k__2, ab__9)) } else { tmp15 = nil }; return /*line :35:1*/ lang.Tuple_Create_O_O_O__IPersistentVector(tmp9, tmp14, tmp15) }















func A_arbace_data_diff_associative_A_New() *A_arbace_data_diff_associative_A { A_arbace_data_diff_associative_A_Init(); t := &A_arbace_data_diff_associative_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_data_diff_associative_A) Ctor() {}
//line :51:1
func (t *A_arbace_data_diff_associative_A) Invoke_O_O_O_O__O(self, a__0, b__1, ks__2 any) any {


	var tmp1 *lang.Var; A_arbace_data_A_Init(); tmp1 = A_arbace_data_A_const_10; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_data_diff_associative_fn__76000026_A_New(); var tmp4 *jrt.Class; A_arbace_data_diff_associative_fn__76000026_A_Init(); tmp4 = A_arbace_data_diff_associative_fn__76000026_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 any; A_arbace_data_A_Init(); tmp6 = A_arbace_data_A_const_23; var tmp7 any = tmp6; var tmp8 *lang.Var; A_arbace_data_A_Init(); tmp8 = A_arbace_data_A_const_21; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_data_A_Init(); tmp10 = A_arbace_data_A_const_24; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_data_A_Init(); tmp12 = A_arbace_data_A_const_25; return tmp2.Invoke_O_O_O__O(tmp5, tmp7, tmp9.Invoke_O_O__O(tmp11.Invoke_O_O_O__O(jrt.NN(tmp12).GetRawRoot__O(), a__0, b__1), ks__2)) }
func A_arbace_data_diff_associative_fn__76000026_A_New() *A_arbace_data_diff_associative_fn__76000026_A { A_arbace_data_diff_associative_fn__76000026_A_Init(); t := &A_arbace_data_diff_associative_fn__76000026_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_data_diff_associative_fn__76000026_A) Ctor() {}
//line :55:1
func (t *A_arbace_data_diff_associative_fn__76000026_A) Invoke_O_O_O__O(self, diff1__1, diff2__2 any) any {
	var tmp1 *lang.Var; A_arbace_data_A_Init(); tmp1 = A_arbace_data_A_const_20; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_data_A_Init(); tmp3 = A_arbace_data_A_const_21; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_data_A_Init(); tmp5 = A_arbace_data_A_const_22; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(jrt.NN(tmp5).GetRawRoot__O(), diff1__1, diff2__2))
}




func A_arbace_data_diff_sequential_A_New() *A_arbace_data_diff_sequential_A { A_arbace_data_diff_sequential_A_Init(); t := &A_arbace_data_diff_sequential_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_data_diff_sequential_A) Ctor() {}
//line :62:1
func (t *A_arbace_data_diff_sequential_A) Invoke_O_O_O__O(self, a__0, b__1 any) any {

	var tmp1 *lang.Var; A_arbace_data_A_Init(); tmp1 = A_arbace_data_A_const_12; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_data_A_Init(); tmp3 = A_arbace_data_A_const_21; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_data_A_Init(); tmp5 = A_arbace_data_A_const_26; var tmp6 any = jrt.NN(tmp5).GetRawRoot__O(); var tmp7 *lang.Var; A_arbace_data_A_Init(); tmp7 = A_arbace_data_A_const_27; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; var tmp10 *lang.Var
	A_arbace_data_A_Init(); tmp10 = A_arbace_data_A_const_28; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(a__0)) { tmp9 = a__0 } else { var tmp11 *lang.Var; A_arbace_data_A_Init(); tmp11 = A_arbace_data_A_const_12; tmp9 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(a__0) }
//line :64:1
	var tmp12 any = tmp9; var tmp13 any; var tmp14 *lang.Var

	A_arbace_data_A_Init(); tmp14 = A_arbace_data_A_const_28; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(b__1)) { tmp13 = b__1 } else { var tmp15 *lang.Var; A_arbace_data_A_Init(); tmp15 = A_arbace_data_A_const_12; tmp13 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1) }
//line :64:1
	var tmp16 any = tmp13; var tmp17 *lang.Var; A_arbace_data_A_Init(); tmp17 = A_arbace_data_A_const_29; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, tmp8.Invoke_O_O_O__O(tmp12, tmp16, lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Max_J_J__J(int64(lang.RT_Count_O__I(a__0)), int64(lang.RT_Count_O__I(b__1)))).Ref()))))
}



func A_arbace_data_eval76000038_fn__76000039_A_New() *A_arbace_data_eval76000038_fn__76000039_A { A_arbace_data_eval76000038_fn__76000039_A_Init(); t := &A_arbace_data_eval76000038_fn__76000039_A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_data_eval76000038_fn__76000039_A) Ctor() {}
//line :69:1
func (t *A_arbace_data_eval76000038_fn__76000039_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__76000031__2_ any; var tmp1 any = A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_New(); var tmp2 *jrt.Class; A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_Init(); tmp2 = A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_fn_class; G__76000031__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_New_O(G__76000031__2_); var tmp4 *jrt.Class; A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_Init(); tmp4 = A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_fn_class; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :69:1
func A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_New_O(p0 any) *A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A { A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_Init(); t := &A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A{}; t.Ctor_O(p0); return t }
//line :69:1
func (t *A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A) Ctor_O(c__G__76000031 any) { t.F_G__76000031 = c__G__76000031 }
//line :69:1
func (t *A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A) Invoke_O_O__O(self, gf__x__76000043__1 any) any { var cache__231000236__auto____2 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____3 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____2)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class(gf__x__76000043__1)); if jrt.A2g_Truth(f__231000237__auto____3) { return lang.IFn_Cast(f__231000237__auto____3).Invoke_O__O(gf__x__76000043__1) } else { var tmp1 *lang.Var; A_arbace_data_A_Init(); tmp1 = A_arbace_data_A_const_30; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.Class; A_arbace_data_A_Init(); tmp3 = A_arbace_data_A_const_31; return lang.IFn_Cast(tmp2.Invoke_O_O_O_O__O(self, gf__x__76000043__1, tmp3.Ref(), t.F_G__76000031)).Invoke_O__O(gf__x__76000043__1) } }
//line :69:1
func A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_New() *A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A { A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_Init(); t := &A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A) Ctor() {}
//line :69:1
func (t *A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A) Invoke_O_O__O(self, gf__x__76000040__1 any) any { var target_1 any = gf__x__76000040__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_1 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_1) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_1, Lit_63, jrt.RefArrayOf(jrt.Object_class)) } else { return A_arbace_data_EqualityPartition_A_Cast(target_1).Equality_partition__O() } }



func A_arbace_data_eval76000060_fn__76000061_A_New() *A_arbace_data_eval76000060_fn__76000061_A { A_arbace_data_eval76000060_fn__76000061_A_Init(); t := &A_arbace_data_eval76000060_fn__76000061_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_data_eval76000060_fn__76000061_A) Ctor() {}
//line :73:1
func (t *A_arbace_data_eval76000060_fn__76000061_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__76000053__2_ any; var tmp1 any = A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_New(); var tmp2 *jrt.Class; A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_Init(); tmp2 = A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_fn_class; G__76000053__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_New_O(G__76000053__2_); var tmp4 *jrt.Class; A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_Init(); tmp4 = A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_fn_class; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :73:1
func A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_New_O(p0 any) *A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A { A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_Init(); t := &A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A{}; t.Ctor_O(p0); return t }
//line :73:1
func (t *A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A) Ctor_O(c__G__76000053 any) { t.F_G__76000053 = c__G__76000053 }
//line :73:1
func (t *A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A) Invoke_O_O_O__O(self, gf__a__76000066__1, gf__b__76000067__2 any) any { var cache__231000236__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class(gf__a__76000066__1)); if jrt.A2g_Truth(f__231000237__auto____4) { return lang.IFn_Cast(f__231000237__auto____4).Invoke_O_O__O(gf__a__76000066__1, gf__b__76000067__2) } else { var tmp1 *lang.Var; A_arbace_data_A_Init(); tmp1 = A_arbace_data_A_const_30; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.Class; A_arbace_data_A_Init(); tmp3 = A_arbace_data_A_const_32; return lang.IFn_Cast(tmp2.Invoke_O_O_O_O__O(self, gf__a__76000066__1, tmp3.Ref(), t.F_G__76000053)).Invoke_O_O__O(gf__a__76000066__1, gf__b__76000067__2) } }
//line :73:1
func A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_New() *A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A { A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_Init(); t := &A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A) Ctor() {}
//line :73:1
func (t *A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A) Invoke_O_O_O__O(self, gf__a__76000062__1, gf__b__76000063__2 any) any { var target_2 any = gf__a__76000062__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_2 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_2) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_2, Lit_67, jrt.RefArrayOf(jrt.Object_class, gf__b__76000063__2)) } else { return A_arbace_data_Diff_A_Cast(target_2).Diff_similar_O__O(gf__b__76000063__2) } }









func A_arbace_data_eval76000078_fn__76000079_A_New() *A_arbace_data_eval76000078_fn__76000079_A { A_arbace_data_eval76000078_fn__76000079_A_Init(); t := &A_arbace_data_eval76000078_fn__76000079_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_data_eval76000078_fn__76000079_A) Ctor() {}
//line :83:1
func (t *A_arbace_data_eval76000078_fn__76000079_A) Invoke_O_O_O__O(self, a__1, b__2 any) any {
	var tmp1 any; if jrt.NN(jrt.GetClass(a__1)).IsArray__Z() { var tmp2 *lang.Var; A_arbace_data_A_Init(); tmp2 = A_arbace_data_A_const_33; tmp1 = jrt.NN(tmp2).GetRawRoot__O() } else { var tmp3 *lang.Var; A_arbace_data_A_Init(); tmp3 = A_arbace_data_A_const_34; tmp1 = jrt.NN(tmp3).GetRawRoot__O() }; return lang.IFn_Cast(tmp1).Invoke_O_O__O(a__1, b__2)
}
func A_arbace_data_eval76000078_fn__76000081_A_New() *A_arbace_data_eval76000078_fn__76000081_A { A_arbace_data_eval76000078_fn__76000081_A_Init(); t := &A_arbace_data_eval76000078_fn__76000081_A{}; t.Ctor(); return t }
//line :86:1
func (t *A_arbace_data_eval76000078_fn__76000081_A) Ctor() {}
//line :86:1
func (t *A_arbace_data_eval76000078_fn__76000081_A) Invoke_O_O__O(self, x__1 any) any {
	if jrt.NN(jrt.GetClass(x__1)).IsArray__Z() { A_arbace_data_A_Init(); return A_arbace_data_A_const_35.Ref() } else { A_arbace_data_A_Init(); return A_arbace_data_A_const_36.Ref()
	} }
func A_arbace_data_eval76000084_fn__76000085_A_New() *A_arbace_data_eval76000084_fn__76000085_A { A_arbace_data_eval76000084_fn__76000085_A_Init(); t := &A_arbace_data_eval76000084_fn__76000085_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_data_eval76000084_fn__76000085_A) Ctor() {}
//line :89:1
func (t *A_arbace_data_eval76000084_fn__76000085_A) Invoke_O_O__O(self, x__1 any) any { A_arbace_data_A_Init(); return A_arbace_data_A_const_36.Ref() }
//line :89:1
func A_arbace_data_eval76000088_fn__76000089_A_New() *A_arbace_data_eval76000088_fn__76000089_A { A_arbace_data_eval76000088_fn__76000089_A_Init(); t := &A_arbace_data_eval76000088_fn__76000089_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_data_eval76000088_fn__76000089_A) Ctor() {}
//line :89:1
func (t *A_arbace_data_eval76000088_fn__76000089_A) Invoke_O_O__O(self, x__1 any) any { A_arbace_data_A_Init(); return A_arbace_data_A_const_37.Ref() }
//line :89:1
func A_arbace_data_eval76000092_fn__76000093_A_New() *A_arbace_data_eval76000092_fn__76000093_A { A_arbace_data_eval76000092_fn__76000093_A_Init(); t := &A_arbace_data_eval76000092_fn__76000093_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_data_eval76000092_fn__76000093_A) Ctor() {}
//line :89:1
func (t *A_arbace_data_eval76000092_fn__76000093_A) Invoke_O_O__O(self, x__1 any) any { A_arbace_data_A_Init(); return A_arbace_data_A_const_35.Ref() }
//line :89:1
func A_arbace_data_eval76000096_fn__76000097_A_New() *A_arbace_data_eval76000096_fn__76000097_A { A_arbace_data_eval76000096_fn__76000097_A_Init(); t := &A_arbace_data_eval76000096_fn__76000097_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_data_eval76000096_fn__76000097_A) Ctor() {}
//line :89:1
func (t *A_arbace_data_eval76000096_fn__76000097_A) Invoke_O_O__O(self, x__1 any) any { A_arbace_data_A_Init(); return A_arbace_data_A_const_38.Ref() }












func A_arbace_data_as_set_value_A_New() *A_arbace_data_as_set_value_A { A_arbace_data_as_set_value_A_Init(); t := &A_arbace_data_as_set_value_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_data_as_set_value_A) Ctor() {}
//line :102:1
func (t *A_arbace_data_as_set_value_A) Invoke_O_O__O(self, s__0 any) any {

	var tmp1 *lang.Var; A_arbace_data_A_Init(); tmp1 = A_arbace_data_A_const_39; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__0)) { return s__0 } else { var tmp2 *lang.Var; A_arbace_data_A_Init(); tmp2 = A_arbace_data_A_const_40; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp4 = lang.PersistentHashSet_EMPTY; return tmp3.Invoke_O_O__O(tmp4.Ref(), s__0)
	} }
func A_arbace_data_eval76000101_fn__76000102_A_New() *A_arbace_data_eval76000101_fn__76000102_A { A_arbace_data_eval76000101_fn__76000102_A_Init(); t := &A_arbace_data_eval76000101_fn__76000102_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_data_eval76000101_fn__76000102_A) Ctor() {}
//line :106:1
func (t *A_arbace_data_eval76000101_fn__76000102_A) Invoke_O_O_O__O(self, a__1, b__2 any) any { var aval__3 any; var tmp1 *lang.Var;



	A_arbace_data_A_Init(); tmp1 = A_arbace_data_A_const_41; aval__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(a__1); var bval__4 any; var tmp2 /*line :106:1*/*lang.Var;




	A_arbace_data_A_Init(); tmp2 = A_arbace_data_A_const_41; bval__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(b__2); var tmp3 /*line :106:1*/*lang.Var; A_arbace_data_A_Init(); tmp3 = A_arbace_data_A_const_42; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_data_A_Init(); tmp5 = A_arbace_data_A_const_43; var tmp6 any = tmp4.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O_O__O(aval__3, bval__4)); var tmp7 *lang.Var; A_arbace_data_A_Init(); tmp7 = A_arbace_data_A_const_42; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_data_A_Init(); tmp9 = A_arbace_data_A_const_43; var tmp10 any = tmp8.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O_O__O(bval__4, aval__3)); var tmp11 *lang.Var; A_arbace_data_A_Init(); tmp11 = A_arbace_data_A_const_42; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_data_A_Init(); tmp13 = A_arbace_data_A_const_44; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp6, tmp10, tmp12.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O_O__O(aval__3, bval__4))) }
//line :106:1
func A_arbace_data_eval76000105_fn__76000106_A_New() *A_arbace_data_eval76000105_fn__76000106_A { A_arbace_data_eval76000105_fn__76000106_A_Init(); t := &A_arbace_data_eval76000105_fn__76000106_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_data_eval76000105_fn__76000106_A) Ctor() {}
//line :106:1
func (t *A_arbace_data_eval76000105_fn__76000106_A) Invoke_O_O_O__O(self, a__1, b__2 any) any {











	var tmp1 *lang.Var; A_arbace_data_A_Init(); tmp1 = A_arbace_data_A_const_33; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(a__1, b__2) }
//line :106:1
func A_arbace_data_eval76000109_fn__76000110_A_New() *A_arbace_data_eval76000109_fn__76000110_A { A_arbace_data_eval76000109_fn__76000110_A_Init(); t := &A_arbace_data_eval76000109_fn__76000110_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_data_eval76000109_fn__76000110_A) Ctor() {}
//line :106:1
func (t *A_arbace_data_eval76000109_fn__76000110_A) Invoke_O_O_O__O(self, a__1, b__2 any) any {















	var tmp1 *lang.Var; A_arbace_data_A_Init(); tmp1 = A_arbace_data_A_const_27; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_data_A_Init(); tmp3 = A_arbace_data_A_const_45; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_data_A_Init(); tmp5 = A_arbace_data_A_const_16; var tmp6 any = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(a__1); var tmp7 *lang.Var; A_arbace_data_A_Init(); tmp7 = A_arbace_data_A_const_16; return tmp2.Invoke_O_O_O__O(a__1, b__2, tmp4.Invoke_O_O__O(tmp6, lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(b__2)))
}
func A_arbace_data_diff_A_New() *A_arbace_data_diff_A { A_arbace_data_diff_A_Init(); t := &A_arbace_data_diff_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_data_diff_A) Ctor() {}
//line :124:1
func (t *A_arbace_data_diff_A) Invoke_O_O_O__O(self, a__0, b__1 any) any {













	if lang.Util_Equiv_O_O__Z(a__0, b__1) { return lang.Tuple_Create_O_O_O__IPersistentVector(nil, nil, a__0) } else {

		var tmp1 any; var target_3 any = a__0; var tmp2 bool; var tmp3 bool; tmp3 = A_arbace_data_EqualityPartition_A_InstanceOf(target_3); if tmp3 { tmp3 = !lang.Compiler_AOT_IsDyn_O__Z(target_3) }; tmp2 = tmp3; if tmp2 { tmp1 = A_arbace_data_EqualityPartition_A_Cast(target_3).Equality_partition__O() } else { var tmp4 *lang.Var; A_arbace_data_A_Init(); tmp4 = A_arbace_data_A_const_46; tmp1 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(target_3) }; var tmp5 any = tmp1; var tmp6 any; var target_4 any = b__1; var tmp7 bool; var tmp8 bool; tmp8 = A_arbace_data_EqualityPartition_A_InstanceOf(target_4); if tmp8 { tmp8 = !lang.Compiler_AOT_IsDyn_O__Z(target_4) }; tmp7 = tmp8; if tmp7 { tmp6 = A_arbace_data_EqualityPartition_A_Cast(target_4).Equality_partition__O() } else { var tmp9 *lang.Var; A_arbace_data_A_Init(); tmp9 = A_arbace_data_A_const_46; tmp6 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(target_4) }; if lang.Util_Equiv_O_O__Z(tmp5, tmp6) {
			var target_5 any = a__0; var tmp10 bool; var tmp11 bool; tmp11 = A_arbace_data_Diff_A_InstanceOf(target_5); if tmp11 { tmp11 = !lang.Compiler_AOT_IsDyn_O__Z(target_5) }; tmp10 = tmp11; if tmp10 { return A_arbace_data_Diff_A_Cast(target_5).Diff_similar_O__O(b__1) } else { var tmp12 *lang.Var; A_arbace_data_A_Init(); tmp12 = A_arbace_data_A_const_47; return lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O_O__O(target_5, b__1) } } else {
				var tmp13 *lang.Var; A_arbace_data_A_Init(); tmp13 = A_arbace_data_A_const_34; return lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O_O__O(a__0, b__1)
			}
	}
}



























type A_arbace_data_A struct{ jrt.Object }

var A_arbace_data_A_const_0 *lang.Var

var A_arbace_data_A_const_1 *lang.Var

var A_arbace_data_A_const_2 any

var A_arbace_data_A_const_3 any

var A_arbace_data_A_const_4 *lang.Var

var A_arbace_data_A_const_5 *lang.Var

var A_arbace_data_A_const_6 *lang.Var

var A_arbace_data_A_const_7 any

var A_arbace_data_A_const_8 *lang.Var

var A_arbace_data_A_const_9 *lang.Var

var A_arbace_data_A_const_10 *lang.Var

var A_arbace_data_A_const_11 *lang.Var

var A_arbace_data_A_const_12 *lang.Var

var A_arbace_data_A_const_13 *lang.Var

var A_arbace_data_A_const_14 *lang.Var

var A_arbace_data_A_const_15 *lang.Var

var A_arbace_data_A_const_16 *lang.Var

var A_arbace_data_A_const_17 *lang.Var

var A_arbace_data_A_const_18 *lang.Var

var A_arbace_data_A_const_19 *lang.Var

var A_arbace_data_A_const_20 *lang.Var

var A_arbace_data_A_const_21 *lang.Var

var A_arbace_data_A_const_22 *lang.Var

var A_arbace_data_A_const_23 any

var A_arbace_data_A_const_24 *lang.Var

var A_arbace_data_A_const_25 *lang.Var

var A_arbace_data_A_const_26 *lang.Var

var A_arbace_data_A_const_27 *lang.Var

var A_arbace_data_A_const_28 *lang.Var

var A_arbace_data_A_const_29 *lang.Var

var A_arbace_data_A_const_30 *lang.Var

var A_arbace_data_A_const_31 *jrt.Class

var A_arbace_data_A_const_32 *jrt.Class

var A_arbace_data_A_const_33 *lang.Var

var A_arbace_data_A_const_34 *lang.Var

var A_arbace_data_A_const_35 *lang.Keyword

var A_arbace_data_A_const_36 *lang.Keyword

var A_arbace_data_A_const_37 *lang.Keyword

var A_arbace_data_A_const_38 *lang.Keyword

var A_arbace_data_A_const_39 *lang.Var

var A_arbace_data_A_const_40 *lang.Var

var A_arbace_data_A_const_41 *lang.Var

var A_arbace_data_A_const_42 *lang.Var

var A_arbace_data_A_const_43 *lang.Var

var A_arbace_data_A_const_44 *lang.Var

var A_arbace_data_A_const_45 *lang.Var

var A_arbace_data_A_const_46 *lang.Var

var A_arbace_data_A_const_47 *lang.Var

var A_arbace_data_A_init jrt.ClassInit

func A_arbace_data_A_Init() { if !A_arbace_data_A_init.Done() { A_arbace_data_A_init.Run(A_arbace_data_A_clinit) } }

func A_arbace_data_A_clinit() { A_arbace_data_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_data_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_data_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_data_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_data_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_6); A_arbace_data_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_7); A_arbace_data_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_data_A_const_7 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13))); A_arbace_data_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_data_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_15); A_arbace_data_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); A_arbace_data_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_data_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_data_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_19); A_arbace_data_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_data_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_data_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_data_A_const_17 = lang.RT_Var_String_String__Var(Lit_9, Lit_23); A_arbace_data_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_data_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); A_arbace_data_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_data_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_27); A_arbace_data_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_data_A_const_23 = lang.Tuple_Create_O_O_O__IPersistentVector(nil, nil, nil); A_arbace_data_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_data_A_const_25 = lang.RT_Var_String_String__Var(Lit_9, Lit_30); A_arbace_data_A_const_26 = lang.RT_Var_String_String__Var(Lit_9, Lit_31); A_arbace_data_A_const_27 = lang.RT_Var_String_String__Var(Lit_9, Lit_32); A_arbace_data_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); A_arbace_data_A_const_29 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_data_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_data_A_const_31 = lang.RT_ClassForNameNonLoading_String__Class(Lit_36); A_arbace_data_A_const_32 = lang.RT_ClassForNameNonLoading_String__Class(Lit_37); A_arbace_data_A_const_33 = lang.RT_Var_String_String__Var(Lit_9, Lit_38); A_arbace_data_A_const_34 = lang.RT_Var_String_String__Var(Lit_9, Lit_39); A_arbace_data_A_const_35 = lang.RT_Keyword_String_String__Keyword(nil, Lit_40); A_arbace_data_A_const_36 = lang.RT_Keyword_String_String__Keyword(nil, Lit_41); A_arbace_data_A_const_37 = lang.RT_Keyword_String_String__Keyword(nil, Lit_5); A_arbace_data_A_const_38 = lang.RT_Keyword_String_String__Keyword(nil, Lit_27); A_arbace_data_A_const_39 = lang.RT_Var_String_String__Var(Lit_0, Lit_42); A_arbace_data_A_const_40 = lang.RT_Var_String_String__Var(Lit_0, Lit_43); A_arbace_data_A_const_41 = lang.RT_Var_String_String__Var(Lit_9, Lit_44); A_arbace_data_A_const_42 = lang.RT_Var_String_String__Var(Lit_0, Lit_45); A_arbace_data_A_const_43 = lang.RT_Var_String_String__Var(Lit_3, Lit_46); A_arbace_data_A_const_44 = lang.RT_Var_String_String__Var(Lit_3, Lit_47); A_arbace_data_A_const_45 = lang.RT_Var_String_String__Var(Lit_3, Lit_48); A_arbace_data_A_const_46 = lang.RT_Var_String_String__Var(Lit_9, Lit_49); A_arbace_data_A_const_47 = lang.RT_Var_String_String__Var(Lit_9, Lit_50) }

func A_arbace_data_A_New() *A_arbace_data_A { A_arbace_data_A_Init(); t := &A_arbace_data_A{}; t.Ctor(); return t }

func (t *A_arbace_data_A) Ctor() {}

func (t *A_arbace_data_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_A) GetClass__Class() *jrt.Class { return A_arbace_data_A_class }

func (t *A_arbace_data_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_A); return ok }

func A_arbace_data_A_Cast(x any) *A_arbace_data_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_A_class)) }; return v }



type A_arbace_data_as_set_value_A struct{ jrt.Object }

func (t *A_arbace_data_as_set_value_A) Is_Compiler_AOTF1() {}

var A_arbace_data_as_set_value_A_fn_class *jrt.Class

var A_arbace_data_as_set_value_A_init jrt.ClassInit

func A_arbace_data_as_set_value_A_Init() { if !A_arbace_data_as_set_value_A_init.Done() { A_arbace_data_as_set_value_A_init.Run(A_arbace_data_as_set_value_A_clinit) } }

func A_arbace_data_as_set_value_A_clinit() { A_arbace_data_as_set_value_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_51, lang.Compiler_AOTFn_class) }

func (t *A_arbace_data_as_set_value_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_as_set_value_A) GetClass__Class() *jrt.Class { return A_arbace_data_as_set_value_A_class }

func (t *A_arbace_data_as_set_value_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_as_set_value_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_as_set_value_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_as_set_value_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_as_set_value_A); return ok }

func A_arbace_data_as_set_value_A_Cast(x any) *A_arbace_data_as_set_value_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_as_set_value_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_as_set_value_A_class)) }; return v }



type A_arbace_data_atom_diff_A struct{ jrt.Object }

func (t *A_arbace_data_atom_diff_A) Is_Compiler_AOTF2() {}

var A_arbace_data_atom_diff_A_fn_class *jrt.Class

var A_arbace_data_atom_diff_A_init jrt.ClassInit

func A_arbace_data_atom_diff_A_Init() { if !A_arbace_data_atom_diff_A_init.Done() { A_arbace_data_atom_diff_A_init.Run(A_arbace_data_atom_diff_A_clinit) } }

func A_arbace_data_atom_diff_A_clinit() { A_arbace_data_atom_diff_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_52, lang.Compiler_AOTFn_class) }

func (t *A_arbace_data_atom_diff_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_atom_diff_A) GetClass__Class() *jrt.Class { return A_arbace_data_atom_diff_A_class }

func (t *A_arbace_data_atom_diff_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_atom_diff_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_atom_diff_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_atom_diff_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_atom_diff_A); return ok }

func A_arbace_data_atom_diff_A_Cast(x any) *A_arbace_data_atom_diff_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_atom_diff_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_atom_diff_A_class)) }; return v }



type A_arbace_data_diff_A struct{ jrt.Object }

func (t *A_arbace_data_diff_A) Is_Compiler_AOTF2() {}

var A_arbace_data_diff_A_fn_class *jrt.Class

var A_arbace_data_diff_A_init jrt.ClassInit

func A_arbace_data_diff_A_Init() { if !A_arbace_data_diff_A_init.Done() { A_arbace_data_diff_A_init.Run(A_arbace_data_diff_A_clinit) } }

func A_arbace_data_diff_A_clinit() { A_arbace_data_diff_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_53, lang.Compiler_AOTFn_class) }

func (t *A_arbace_data_diff_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_diff_A) GetClass__Class() *jrt.Class { return A_arbace_data_diff_A_class }

func (t *A_arbace_data_diff_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_diff_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_diff_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_diff_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_diff_A); return ok }

func A_arbace_data_diff_A_Cast(x any) *A_arbace_data_diff_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_diff_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_diff_A_class)) }; return v }



type A_arbace_data_diff_associative_A struct{ jrt.Object }

func (t *A_arbace_data_diff_associative_A) Is_Compiler_AOTF3() {}

var A_arbace_data_diff_associative_A_fn_class *jrt.Class

var A_arbace_data_diff_associative_A_init jrt.ClassInit

func A_arbace_data_diff_associative_A_Init() { if !A_arbace_data_diff_associative_A_init.Done() { A_arbace_data_diff_associative_A_init.Run(A_arbace_data_diff_associative_A_clinit) } }

func A_arbace_data_diff_associative_A_clinit() { A_arbace_data_diff_associative_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_54, lang.Compiler_AOTFn_class) }

func (t *A_arbace_data_diff_associative_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_diff_associative_A) GetClass__Class() *jrt.Class { return A_arbace_data_diff_associative_A_class }

func (t *A_arbace_data_diff_associative_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_diff_associative_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_diff_associative_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_diff_associative_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_diff_associative_A); return ok }

func A_arbace_data_diff_associative_A_Cast(x any) *A_arbace_data_diff_associative_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_diff_associative_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_diff_associative_A_class)) }; return v }



type A_arbace_data_diff_associative_fn__76000026_A struct{ jrt.Object }

func (t *A_arbace_data_diff_associative_fn__76000026_A) Is_Compiler_AOTF2() {}

var A_arbace_data_diff_associative_fn__76000026_A_fn_class *jrt.Class

var A_arbace_data_diff_associative_fn__76000026_A_init jrt.ClassInit

func A_arbace_data_diff_associative_fn__76000026_A_Init() { if !A_arbace_data_diff_associative_fn__76000026_A_init.Done() { A_arbace_data_diff_associative_fn__76000026_A_init.Run(A_arbace_data_diff_associative_fn__76000026_A_clinit) } }

func A_arbace_data_diff_associative_fn__76000026_A_clinit() { A_arbace_data_diff_associative_fn__76000026_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_55, lang.Compiler_AOTFn_class) }

func (t *A_arbace_data_diff_associative_fn__76000026_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_diff_associative_fn__76000026_A) GetClass__Class() *jrt.Class { return A_arbace_data_diff_associative_fn__76000026_A_class }

func (t *A_arbace_data_diff_associative_fn__76000026_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_diff_associative_fn__76000026_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_diff_associative_fn__76000026_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_diff_associative_fn__76000026_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_diff_associative_fn__76000026_A); return ok }

func A_arbace_data_diff_associative_fn__76000026_A_Cast(x any) *A_arbace_data_diff_associative_fn__76000026_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_diff_associative_fn__76000026_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_diff_associative_fn__76000026_A_class)) }; return v }



type A_arbace_data_diff_associative_key_A struct{ jrt.Object }

func (t *A_arbace_data_diff_associative_key_A) Is_Compiler_AOTF3() {}

var A_arbace_data_diff_associative_key_A_fn_class *jrt.Class

var A_arbace_data_diff_associative_key_A_init jrt.ClassInit

func A_arbace_data_diff_associative_key_A_Init() { if !A_arbace_data_diff_associative_key_A_init.Done() { A_arbace_data_diff_associative_key_A_init.Run(A_arbace_data_diff_associative_key_A_clinit) } }

func A_arbace_data_diff_associative_key_A_clinit() { A_arbace_data_diff_associative_key_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_56, lang.Compiler_AOTFn_class) }

func (t *A_arbace_data_diff_associative_key_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_diff_associative_key_A) GetClass__Class() *jrt.Class { return A_arbace_data_diff_associative_key_A_class }

func (t *A_arbace_data_diff_associative_key_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_diff_associative_key_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_diff_associative_key_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_diff_associative_key_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_diff_associative_key_A); return ok }

func A_arbace_data_diff_associative_key_A_Cast(x any) *A_arbace_data_diff_associative_key_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_diff_associative_key_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_diff_associative_key_A_class)) }; return v }



type A_arbace_data_diff_sequential_A struct{ jrt.Object }

func (t *A_arbace_data_diff_sequential_A) Is_Compiler_AOTF2() {}

var A_arbace_data_diff_sequential_A_fn_class *jrt.Class

var A_arbace_data_diff_sequential_A_init jrt.ClassInit

func A_arbace_data_diff_sequential_A_Init() { if !A_arbace_data_diff_sequential_A_init.Done() { A_arbace_data_diff_sequential_A_init.Run(A_arbace_data_diff_sequential_A_clinit) } }

func A_arbace_data_diff_sequential_A_clinit() { A_arbace_data_diff_sequential_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_57, lang.Compiler_AOTFn_class) }

func (t *A_arbace_data_diff_sequential_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_diff_sequential_A) GetClass__Class() *jrt.Class { return A_arbace_data_diff_sequential_A_class }

func (t *A_arbace_data_diff_sequential_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_diff_sequential_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_diff_sequential_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_diff_sequential_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_diff_sequential_A); return ok }

func A_arbace_data_diff_sequential_A_Cast(x any) *A_arbace_data_diff_sequential_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_diff_sequential_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_diff_sequential_A_class)) }; return v }



type A_arbace_data_eval76000004_A struct{ jrt.Object }

func A_arbace_data_eval76000004_A_New() *A_arbace_data_eval76000004_A { t := &A_arbace_data_eval76000004_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000004_A) Ctor() {}

func (t *A_arbace_data_eval76000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000004_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000004_A_class }

func (t *A_arbace_data_eval76000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000004_A); return ok }

func A_arbace_data_eval76000004_A_Cast(x any) *A_arbace_data_eval76000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000004_A_class)) }; return v }



type A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A struct{ jrt.Object }

func (t *A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A) Is_Compiler_AOTF0() {}

var A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_fn_class *jrt.Class

var A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_init jrt.ClassInit

func A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_Init() { if !A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_init.Done() { A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_init.Run(A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_clinit) } }

func A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_clinit() { A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_58, lang.Compiler_AOTFn_class) }

func (t *A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_class }

func (t *A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A); return ok }

func A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_Cast(x any) *A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_class)) }; return v }



type A_arbace_data_eval76000008_A struct{ jrt.Object }

func A_arbace_data_eval76000008_A_New() *A_arbace_data_eval76000008_A { t := &A_arbace_data_eval76000008_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000008_A) Ctor() {}

func (t *A_arbace_data_eval76000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000008_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000008_A_class }

func (t *A_arbace_data_eval76000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000008_A); return ok }

func A_arbace_data_eval76000008_A_Cast(x any) *A_arbace_data_eval76000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000008_A_class)) }; return v }



type A_arbace_data_eval76000008_fn__76000009_A struct{ jrt.Object }

func (t *A_arbace_data_eval76000008_fn__76000009_A) Is_Compiler_AOTF0() {}

var A_arbace_data_eval76000008_fn__76000009_A_fn_class *jrt.Class

var A_arbace_data_eval76000008_fn__76000009_A_init jrt.ClassInit

func A_arbace_data_eval76000008_fn__76000009_A_Init() { if !A_arbace_data_eval76000008_fn__76000009_A_init.Done() { A_arbace_data_eval76000008_fn__76000009_A_init.Run(A_arbace_data_eval76000008_fn__76000009_A_clinit) } }

func A_arbace_data_eval76000008_fn__76000009_A_clinit() { A_arbace_data_eval76000008_fn__76000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_59, lang.Compiler_AOTFn_class) }

func (t *A_arbace_data_eval76000008_fn__76000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000008_fn__76000009_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000008_fn__76000009_A_class }

func (t *A_arbace_data_eval76000008_fn__76000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000008_fn__76000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000008_fn__76000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000008_fn__76000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000008_fn__76000009_A); return ok }

func A_arbace_data_eval76000008_fn__76000009_A_Cast(x any) *A_arbace_data_eval76000008_fn__76000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000008_fn__76000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000008_fn__76000009_A_class)) }; return v }



type A_arbace_data_eval76000038_A struct{ jrt.Object }

func A_arbace_data_eval76000038_A_New() *A_arbace_data_eval76000038_A { t := &A_arbace_data_eval76000038_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000038_A) Ctor() {}

func (t *A_arbace_data_eval76000038_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000038_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000038_A_class }

func (t *A_arbace_data_eval76000038_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000038_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000038_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000038_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000038_A); return ok }

func A_arbace_data_eval76000038_A_Cast(x any) *A_arbace_data_eval76000038_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000038_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000038_A_class)) }; return v }



type A_arbace_data_eval76000038_fn__76000039_A struct{ jrt.Object }

func (t *A_arbace_data_eval76000038_fn__76000039_A) Is_Compiler_AOTF1() {}

var A_arbace_data_eval76000038_fn__76000039_A_fn_class *jrt.Class

var A_arbace_data_eval76000038_fn__76000039_A_init jrt.ClassInit

func A_arbace_data_eval76000038_fn__76000039_A_Init() { if !A_arbace_data_eval76000038_fn__76000039_A_init.Done() { A_arbace_data_eval76000038_fn__76000039_A_init.Run(A_arbace_data_eval76000038_fn__76000039_A_clinit) } }

func A_arbace_data_eval76000038_fn__76000039_A_clinit() { A_arbace_data_eval76000038_fn__76000039_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_60, lang.Compiler_AOTFn_class) }

func (t *A_arbace_data_eval76000038_fn__76000039_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000038_fn__76000039_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000038_fn__76000039_A_class }

func (t *A_arbace_data_eval76000038_fn__76000039_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000038_fn__76000039_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000038_fn__76000039_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000038_fn__76000039_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000038_fn__76000039_A); return ok }

func A_arbace_data_eval76000038_fn__76000039_A_Cast(x any) *A_arbace_data_eval76000038_fn__76000039_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000038_fn__76000039_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000038_fn__76000039_A_class)) }; return v }



type A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A struct{ jrt.Object; F_G__76000031 any }

func (t *A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A) Is_Compiler_AOTF1() {}

var A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_fn_class *jrt.Class

var A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_init jrt.ClassInit

func A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_Init() { if !A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_init.Done() { A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_init.Run(A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_clinit) } }

func A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_clinit() { A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_61, lang.Compiler_AOTFn_class) }

func (t *A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_class }

func (t *A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A); return ok }

func A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_Cast(x any) *A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_class)) }; return v }



type A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A struct{ jrt.Object }

func (t *A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A) Is_Compiler_AOTF1() {}

var A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_fn_class *jrt.Class

var A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_init jrt.ClassInit

func A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_Init() { if !A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_init.Done() { A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_init.Run(A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_clinit) } }

func A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_clinit() { A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_62, lang.Compiler_AOTFn_class) }

func (t *A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_class }

func (t *A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A); return ok }

func A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_Cast(x any) *A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_class)) }; return v }



type A_arbace_data_eval76000060_A struct{ jrt.Object }

func A_arbace_data_eval76000060_A_New() *A_arbace_data_eval76000060_A { t := &A_arbace_data_eval76000060_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000060_A) Ctor() {}

func (t *A_arbace_data_eval76000060_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000060_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000060_A_class }

func (t *A_arbace_data_eval76000060_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000060_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000060_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000060_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000060_A); return ok }

func A_arbace_data_eval76000060_A_Cast(x any) *A_arbace_data_eval76000060_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000060_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000060_A_class)) }; return v }



type A_arbace_data_eval76000060_fn__76000061_A struct{ jrt.Object }

func (t *A_arbace_data_eval76000060_fn__76000061_A) Is_Compiler_AOTF1() {}

var A_arbace_data_eval76000060_fn__76000061_A_fn_class *jrt.Class

var A_arbace_data_eval76000060_fn__76000061_A_init jrt.ClassInit

func A_arbace_data_eval76000060_fn__76000061_A_Init() { if !A_arbace_data_eval76000060_fn__76000061_A_init.Done() { A_arbace_data_eval76000060_fn__76000061_A_init.Run(A_arbace_data_eval76000060_fn__76000061_A_clinit) } }

func A_arbace_data_eval76000060_fn__76000061_A_clinit() { A_arbace_data_eval76000060_fn__76000061_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_64, lang.Compiler_AOTFn_class) }

func (t *A_arbace_data_eval76000060_fn__76000061_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000060_fn__76000061_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000060_fn__76000061_A_class }

func (t *A_arbace_data_eval76000060_fn__76000061_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000060_fn__76000061_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000060_fn__76000061_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000060_fn__76000061_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000060_fn__76000061_A); return ok }

func A_arbace_data_eval76000060_fn__76000061_A_Cast(x any) *A_arbace_data_eval76000060_fn__76000061_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000060_fn__76000061_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000060_fn__76000061_A_class)) }; return v }



type A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A struct{ jrt.Object; F_G__76000053 any }

func (t *A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A) Is_Compiler_AOTF2() {}

var A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_fn_class *jrt.Class

var A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_init jrt.ClassInit

func A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_Init() { if !A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_init.Done() { A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_init.Run(A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_clinit) } }

func A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_clinit() { A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_65, lang.Compiler_AOTFn_class) }

func (t *A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_class }

func (t *A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A); return ok }

func A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_Cast(x any) *A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_class)) }; return v }



type A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A struct{ jrt.Object }

func (t *A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A) Is_Compiler_AOTF2() {}

var A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_fn_class *jrt.Class

var A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_init jrt.ClassInit

func A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_Init() { if !A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_init.Done() { A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_init.Run(A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_clinit) } }

func A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_clinit() { A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_66, lang.Compiler_AOTFn_class) }

func (t *A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_class }

func (t *A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A); return ok }

func A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_Cast(x any) *A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_class)) }; return v }



type A_arbace_data_eval76000078_A struct{ jrt.Object }

func A_arbace_data_eval76000078_A_New() *A_arbace_data_eval76000078_A { t := &A_arbace_data_eval76000078_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000078_A) Ctor() {}

func (t *A_arbace_data_eval76000078_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000078_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000078_A_class }

func (t *A_arbace_data_eval76000078_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000078_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000078_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000078_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000078_A); return ok }

func A_arbace_data_eval76000078_A_Cast(x any) *A_arbace_data_eval76000078_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000078_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000078_A_class)) }; return v }



type A_arbace_data_eval76000078_fn__76000079_A struct{ jrt.Object }

func (t *A_arbace_data_eval76000078_fn__76000079_A) Is_Compiler_AOTF2() {}

var A_arbace_data_eval76000078_fn__76000079_A_fn_class *jrt.Class

var A_arbace_data_eval76000078_fn__76000079_A_init jrt.ClassInit

func A_arbace_data_eval76000078_fn__76000079_A_Init() { if !A_arbace_data_eval76000078_fn__76000079_A_init.Done() { A_arbace_data_eval76000078_fn__76000079_A_init.Run(A_arbace_data_eval76000078_fn__76000079_A_clinit) } }

func A_arbace_data_eval76000078_fn__76000079_A_clinit() { A_arbace_data_eval76000078_fn__76000079_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_68, lang.Compiler_AOTFn_class) }

func (t *A_arbace_data_eval76000078_fn__76000079_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000078_fn__76000079_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000078_fn__76000079_A_class }

func (t *A_arbace_data_eval76000078_fn__76000079_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000078_fn__76000079_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000078_fn__76000079_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000078_fn__76000079_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000078_fn__76000079_A); return ok }

func A_arbace_data_eval76000078_fn__76000079_A_Cast(x any) *A_arbace_data_eval76000078_fn__76000079_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000078_fn__76000079_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000078_fn__76000079_A_class)) }; return v }



type A_arbace_data_eval76000078_fn__76000081_A struct{ jrt.Object }

func (t *A_arbace_data_eval76000078_fn__76000081_A) Is_Compiler_AOTF1() {}

var A_arbace_data_eval76000078_fn__76000081_A_fn_class *jrt.Class

var A_arbace_data_eval76000078_fn__76000081_A_init jrt.ClassInit

func A_arbace_data_eval76000078_fn__76000081_A_Init() { if !A_arbace_data_eval76000078_fn__76000081_A_init.Done() { A_arbace_data_eval76000078_fn__76000081_A_init.Run(A_arbace_data_eval76000078_fn__76000081_A_clinit) } }

func A_arbace_data_eval76000078_fn__76000081_A_clinit() { A_arbace_data_eval76000078_fn__76000081_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_69, lang.Compiler_AOTFn_class) }

func (t *A_arbace_data_eval76000078_fn__76000081_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000078_fn__76000081_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000078_fn__76000081_A_class }

func (t *A_arbace_data_eval76000078_fn__76000081_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000078_fn__76000081_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000078_fn__76000081_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000078_fn__76000081_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000078_fn__76000081_A); return ok }

func A_arbace_data_eval76000078_fn__76000081_A_Cast(x any) *A_arbace_data_eval76000078_fn__76000081_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000078_fn__76000081_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000078_fn__76000081_A_class)) }; return v }



type A_arbace_data_eval76000084_A struct{ jrt.Object }

func A_arbace_data_eval76000084_A_New() *A_arbace_data_eval76000084_A { t := &A_arbace_data_eval76000084_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000084_A) Ctor() {}

func (t *A_arbace_data_eval76000084_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000084_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000084_A_class }

func (t *A_arbace_data_eval76000084_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000084_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000084_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000084_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000084_A); return ok }

func A_arbace_data_eval76000084_A_Cast(x any) *A_arbace_data_eval76000084_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000084_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000084_A_class)) }; return v }



type A_arbace_data_eval76000084_fn__76000085_A struct{ jrt.Object }

func (t *A_arbace_data_eval76000084_fn__76000085_A) Is_Compiler_AOTF1() {}

var A_arbace_data_eval76000084_fn__76000085_A_fn_class *jrt.Class

var A_arbace_data_eval76000084_fn__76000085_A_init jrt.ClassInit

func A_arbace_data_eval76000084_fn__76000085_A_Init() { if !A_arbace_data_eval76000084_fn__76000085_A_init.Done() { A_arbace_data_eval76000084_fn__76000085_A_init.Run(A_arbace_data_eval76000084_fn__76000085_A_clinit) } }

func A_arbace_data_eval76000084_fn__76000085_A_clinit() { A_arbace_data_eval76000084_fn__76000085_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_70, lang.Compiler_AOTFn_class) }

func (t *A_arbace_data_eval76000084_fn__76000085_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000084_fn__76000085_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000084_fn__76000085_A_class }

func (t *A_arbace_data_eval76000084_fn__76000085_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000084_fn__76000085_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000084_fn__76000085_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000084_fn__76000085_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000084_fn__76000085_A); return ok }

func A_arbace_data_eval76000084_fn__76000085_A_Cast(x any) *A_arbace_data_eval76000084_fn__76000085_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000084_fn__76000085_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000084_fn__76000085_A_class)) }; return v }



type A_arbace_data_eval76000088_A struct{ jrt.Object }

func A_arbace_data_eval76000088_A_New() *A_arbace_data_eval76000088_A { t := &A_arbace_data_eval76000088_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000088_A) Ctor() {}

func (t *A_arbace_data_eval76000088_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000088_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000088_A_class }

func (t *A_arbace_data_eval76000088_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000088_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000088_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000088_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000088_A); return ok }

func A_arbace_data_eval76000088_A_Cast(x any) *A_arbace_data_eval76000088_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000088_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000088_A_class)) }; return v }



type A_arbace_data_eval76000088_fn__76000089_A struct{ jrt.Object }

func (t *A_arbace_data_eval76000088_fn__76000089_A) Is_Compiler_AOTF1() {}

var A_arbace_data_eval76000088_fn__76000089_A_fn_class *jrt.Class

var A_arbace_data_eval76000088_fn__76000089_A_init jrt.ClassInit

func A_arbace_data_eval76000088_fn__76000089_A_Init() { if !A_arbace_data_eval76000088_fn__76000089_A_init.Done() { A_arbace_data_eval76000088_fn__76000089_A_init.Run(A_arbace_data_eval76000088_fn__76000089_A_clinit) } }

func A_arbace_data_eval76000088_fn__76000089_A_clinit() { A_arbace_data_eval76000088_fn__76000089_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_71, lang.Compiler_AOTFn_class) }

func (t *A_arbace_data_eval76000088_fn__76000089_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000088_fn__76000089_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000088_fn__76000089_A_class }

func (t *A_arbace_data_eval76000088_fn__76000089_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000088_fn__76000089_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000088_fn__76000089_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000088_fn__76000089_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000088_fn__76000089_A); return ok }

func A_arbace_data_eval76000088_fn__76000089_A_Cast(x any) *A_arbace_data_eval76000088_fn__76000089_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000088_fn__76000089_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000088_fn__76000089_A_class)) }; return v }



type A_arbace_data_eval76000092_A struct{ jrt.Object }

func A_arbace_data_eval76000092_A_New() *A_arbace_data_eval76000092_A { t := &A_arbace_data_eval76000092_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000092_A) Ctor() {}

func (t *A_arbace_data_eval76000092_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000092_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000092_A_class }

func (t *A_arbace_data_eval76000092_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000092_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000092_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000092_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000092_A); return ok }

func A_arbace_data_eval76000092_A_Cast(x any) *A_arbace_data_eval76000092_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000092_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000092_A_class)) }; return v }



type A_arbace_data_eval76000092_fn__76000093_A struct{ jrt.Object }

func (t *A_arbace_data_eval76000092_fn__76000093_A) Is_Compiler_AOTF1() {}

var A_arbace_data_eval76000092_fn__76000093_A_fn_class *jrt.Class

var A_arbace_data_eval76000092_fn__76000093_A_init jrt.ClassInit

func A_arbace_data_eval76000092_fn__76000093_A_Init() { if !A_arbace_data_eval76000092_fn__76000093_A_init.Done() { A_arbace_data_eval76000092_fn__76000093_A_init.Run(A_arbace_data_eval76000092_fn__76000093_A_clinit) } }

func A_arbace_data_eval76000092_fn__76000093_A_clinit() { A_arbace_data_eval76000092_fn__76000093_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_72, lang.Compiler_AOTFn_class) }

func (t *A_arbace_data_eval76000092_fn__76000093_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000092_fn__76000093_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000092_fn__76000093_A_class }

func (t *A_arbace_data_eval76000092_fn__76000093_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000092_fn__76000093_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000092_fn__76000093_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000092_fn__76000093_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000092_fn__76000093_A); return ok }

func A_arbace_data_eval76000092_fn__76000093_A_Cast(x any) *A_arbace_data_eval76000092_fn__76000093_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000092_fn__76000093_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000092_fn__76000093_A_class)) }; return v }



type A_arbace_data_eval76000096_A struct{ jrt.Object }

func A_arbace_data_eval76000096_A_New() *A_arbace_data_eval76000096_A { t := &A_arbace_data_eval76000096_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000096_A) Ctor() {}

func (t *A_arbace_data_eval76000096_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000096_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000096_A_class }

func (t *A_arbace_data_eval76000096_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000096_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000096_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000096_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000096_A); return ok }

func A_arbace_data_eval76000096_A_Cast(x any) *A_arbace_data_eval76000096_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000096_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000096_A_class)) }; return v }



type A_arbace_data_eval76000096_fn__76000097_A struct{ jrt.Object }

func (t *A_arbace_data_eval76000096_fn__76000097_A) Is_Compiler_AOTF1() {}

var A_arbace_data_eval76000096_fn__76000097_A_fn_class *jrt.Class

var A_arbace_data_eval76000096_fn__76000097_A_init jrt.ClassInit

func A_arbace_data_eval76000096_fn__76000097_A_Init() { if !A_arbace_data_eval76000096_fn__76000097_A_init.Done() { A_arbace_data_eval76000096_fn__76000097_A_init.Run(A_arbace_data_eval76000096_fn__76000097_A_clinit) } }

func A_arbace_data_eval76000096_fn__76000097_A_clinit() { A_arbace_data_eval76000096_fn__76000097_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_73, lang.Compiler_AOTFn_class) }

func (t *A_arbace_data_eval76000096_fn__76000097_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000096_fn__76000097_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000096_fn__76000097_A_class }

func (t *A_arbace_data_eval76000096_fn__76000097_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000096_fn__76000097_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000096_fn__76000097_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000096_fn__76000097_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000096_fn__76000097_A); return ok }

func A_arbace_data_eval76000096_fn__76000097_A_Cast(x any) *A_arbace_data_eval76000096_fn__76000097_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000096_fn__76000097_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000096_fn__76000097_A_class)) }; return v }



type A_arbace_data_eval76000101_A struct{ jrt.Object }

func A_arbace_data_eval76000101_A_New() *A_arbace_data_eval76000101_A { t := &A_arbace_data_eval76000101_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000101_A) Ctor() {}

func (t *A_arbace_data_eval76000101_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000101_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000101_A_class }

func (t *A_arbace_data_eval76000101_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000101_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000101_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000101_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000101_A); return ok }

func A_arbace_data_eval76000101_A_Cast(x any) *A_arbace_data_eval76000101_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000101_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000101_A_class)) }; return v }



type A_arbace_data_eval76000101_fn__76000102_A struct{ jrt.Object }

func (t *A_arbace_data_eval76000101_fn__76000102_A) Is_Compiler_AOTF2() {}

var A_arbace_data_eval76000101_fn__76000102_A_fn_class *jrt.Class

var A_arbace_data_eval76000101_fn__76000102_A_init jrt.ClassInit

func A_arbace_data_eval76000101_fn__76000102_A_Init() { if !A_arbace_data_eval76000101_fn__76000102_A_init.Done() { A_arbace_data_eval76000101_fn__76000102_A_init.Run(A_arbace_data_eval76000101_fn__76000102_A_clinit) } }

func A_arbace_data_eval76000101_fn__76000102_A_clinit() { A_arbace_data_eval76000101_fn__76000102_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_74, lang.Compiler_AOTFn_class) }

func (t *A_arbace_data_eval76000101_fn__76000102_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000101_fn__76000102_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000101_fn__76000102_A_class }

func (t *A_arbace_data_eval76000101_fn__76000102_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000101_fn__76000102_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000101_fn__76000102_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000101_fn__76000102_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000101_fn__76000102_A); return ok }

func A_arbace_data_eval76000101_fn__76000102_A_Cast(x any) *A_arbace_data_eval76000101_fn__76000102_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000101_fn__76000102_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000101_fn__76000102_A_class)) }; return v }



type A_arbace_data_eval76000105_A struct{ jrt.Object }

func A_arbace_data_eval76000105_A_New() *A_arbace_data_eval76000105_A { t := &A_arbace_data_eval76000105_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000105_A) Ctor() {}

func (t *A_arbace_data_eval76000105_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000105_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000105_A_class }

func (t *A_arbace_data_eval76000105_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000105_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000105_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000105_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000105_A); return ok }

func A_arbace_data_eval76000105_A_Cast(x any) *A_arbace_data_eval76000105_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000105_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000105_A_class)) }; return v }



type A_arbace_data_eval76000105_fn__76000106_A struct{ jrt.Object }

func (t *A_arbace_data_eval76000105_fn__76000106_A) Is_Compiler_AOTF2() {}

var A_arbace_data_eval76000105_fn__76000106_A_fn_class *jrt.Class

var A_arbace_data_eval76000105_fn__76000106_A_init jrt.ClassInit

func A_arbace_data_eval76000105_fn__76000106_A_Init() { if !A_arbace_data_eval76000105_fn__76000106_A_init.Done() { A_arbace_data_eval76000105_fn__76000106_A_init.Run(A_arbace_data_eval76000105_fn__76000106_A_clinit) } }

func A_arbace_data_eval76000105_fn__76000106_A_clinit() { A_arbace_data_eval76000105_fn__76000106_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_75, lang.Compiler_AOTFn_class) }

func (t *A_arbace_data_eval76000105_fn__76000106_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000105_fn__76000106_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000105_fn__76000106_A_class }

func (t *A_arbace_data_eval76000105_fn__76000106_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000105_fn__76000106_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000105_fn__76000106_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000105_fn__76000106_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000105_fn__76000106_A); return ok }

func A_arbace_data_eval76000105_fn__76000106_A_Cast(x any) *A_arbace_data_eval76000105_fn__76000106_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000105_fn__76000106_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000105_fn__76000106_A_class)) }; return v }



type A_arbace_data_eval76000109_A struct{ jrt.Object }

func A_arbace_data_eval76000109_A_New() *A_arbace_data_eval76000109_A { t := &A_arbace_data_eval76000109_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000109_A) Ctor() {}

func (t *A_arbace_data_eval76000109_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000109_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000109_A_class }

func (t *A_arbace_data_eval76000109_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000109_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000109_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000109_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000109_A); return ok }

func A_arbace_data_eval76000109_A_Cast(x any) *A_arbace_data_eval76000109_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000109_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000109_A_class)) }; return v }



type A_arbace_data_eval76000109_fn__76000110_A struct{ jrt.Object }

func (t *A_arbace_data_eval76000109_fn__76000110_A) Is_Compiler_AOTF2() {}

var A_arbace_data_eval76000109_fn__76000110_A_fn_class *jrt.Class

var A_arbace_data_eval76000109_fn__76000110_A_init jrt.ClassInit

func A_arbace_data_eval76000109_fn__76000110_A_Init() { if !A_arbace_data_eval76000109_fn__76000110_A_init.Done() { A_arbace_data_eval76000109_fn__76000110_A_init.Run(A_arbace_data_eval76000109_fn__76000110_A_clinit) } }

func A_arbace_data_eval76000109_fn__76000110_A_clinit() { A_arbace_data_eval76000109_fn__76000110_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_76, lang.Compiler_AOTFn_class) }

func (t *A_arbace_data_eval76000109_fn__76000110_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000109_fn__76000110_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000109_fn__76000110_A_class }

func (t *A_arbace_data_eval76000109_fn__76000110_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000109_fn__76000110_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000109_fn__76000110_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000109_fn__76000110_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000109_fn__76000110_A); return ok }

func A_arbace_data_eval76000109_fn__76000110_A_Cast(x any) *A_arbace_data_eval76000109_fn__76000110_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000109_fn__76000110_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000109_fn__76000110_A_class)) }; return v }



type A_arbace_data_vectorize_A struct{ jrt.Object }

func (t *A_arbace_data_vectorize_A) Is_Compiler_AOTF1() {}

var A_arbace_data_vectorize_A_fn_class *jrt.Class

var A_arbace_data_vectorize_A_init jrt.ClassInit

func A_arbace_data_vectorize_A_Init() { if !A_arbace_data_vectorize_A_init.Done() { A_arbace_data_vectorize_A_init.Run(A_arbace_data_vectorize_A_clinit) } }

func A_arbace_data_vectorize_A_clinit() { A_arbace_data_vectorize_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_77, lang.Compiler_AOTFn_class) }

func (t *A_arbace_data_vectorize_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_vectorize_A) GetClass__Class() *jrt.Class { return A_arbace_data_vectorize_A_class }

func (t *A_arbace_data_vectorize_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_vectorize_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_vectorize_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_vectorize_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_vectorize_A); return ok }

func A_arbace_data_vectorize_A_Cast(x any) *A_arbace_data_vectorize_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_vectorize_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_vectorize_A_class)) }; return v }



type A_arbace_data_vectorize_fn__76000016_A struct{ jrt.Object }

func (t *A_arbace_data_vectorize_fn__76000016_A) Is_Compiler_AOTF2() {}

var A_arbace_data_vectorize_fn__76000016_A_fn_class *jrt.Class

var A_arbace_data_vectorize_fn__76000016_A_init jrt.ClassInit

func A_arbace_data_vectorize_fn__76000016_A_Init() { if !A_arbace_data_vectorize_fn__76000016_A_init.Done() { A_arbace_data_vectorize_fn__76000016_A_init.Run(A_arbace_data_vectorize_fn__76000016_A_clinit) } }

func A_arbace_data_vectorize_fn__76000016_A_clinit() { A_arbace_data_vectorize_fn__76000016_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_78, lang.Compiler_AOTFn_class) }

func (t *A_arbace_data_vectorize_fn__76000016_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_vectorize_fn__76000016_A) GetClass__Class() *jrt.Class { return A_arbace_data_vectorize_fn__76000016_A_class }

func (t *A_arbace_data_vectorize_fn__76000016_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_vectorize_fn__76000016_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data_vectorize_fn__76000016_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_vectorize_fn__76000016_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_vectorize_fn__76000016_A); return ok }

func A_arbace_data_vectorize_fn__76000016_A_Cast(x any) *A_arbace_data_vectorize_fn__76000016_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_vectorize_fn__76000016_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_vectorize_fn__76000016_A_class)) }; return v }
