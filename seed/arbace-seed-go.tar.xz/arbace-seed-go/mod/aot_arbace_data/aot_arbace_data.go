//line aot_arbace_data.ae:1
package aot_arbace_data

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_set"
	"arbace/jrt"
	"arbace/lang"
)
func A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_New() *A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_data_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_data_A_const_3); tmp2 = lang.IFn_Cast(A_arbace_data_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_data_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_data_eval76000008_fn__76000009_A_New() *A_arbace_data_eval76000008_fn__76000009_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000008_fn__76000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_data_eval76000008_fn__76000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_data_eval76000008_fn__76000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data_A_const_4.GetRawRoot__O()); var tmp2 any; var root_15 any = A_arbace_data_A_const_5.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = A_arbace_data_A_const_6; if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_15, arg_18) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_data_A_const_7.GetRawRoot__O(), A_arbace_data_A_const_8) }









func A_arbace_data_atom_diff_A_New() *A_arbace_data_atom_diff_A { A_arbace_data_A_Init(); t := &A_arbace_data_atom_diff_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_data_atom_diff_A) Ctor() {}
//line :19:1
func (t *A_arbace_data_atom_diff_A) Invoke_O_O_O__O(self, a__0, b__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(a__0, b__1) { return lang.Tuple_Create_O_O_O__IPersistentVector(nil, nil, a__0) } else { return lang.Tuple_Create_O_O_O__IPersistentVector(a__0, b__1, nil)
	}
}
func A_arbace_data_vectorize_A_New() *A_arbace_data_vectorize_A { A_arbace_data_A_Init(); t := &A_arbace_data_vectorize_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_data_vectorize_A) Ctor() {}
//line :25:1
func (t *A_arbace_data_vectorize_A) Invoke_O_O__O(self, m__0 any) any {



	var tmp1 any; var root_19 any = A_arbace_data_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = m__0; if linked_20 == nil { tmp1 = ifn_21.Invoke_O__O(arg_22) } else { tmp1 = linked_20.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_19, arg_22) }; if jrt.J2g_Truth(tmp1) {
		var root_23 any = A_arbace_data_A_const_10.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_25 lang.IFn; if linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any; var fnbody__36 any = A_arbace_data_vectorize_fn__76000016_A_New(); var tmp2 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_data_vectorize_fn__76000016_A_fn_class
		if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, nil); A_arbace_data_vectorize_fn__76000016_A_fn_class = fncls__35d; tmp2 = fncls__35d } else { tmp2 = fncls__35 }; arg_26 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp2, nil)
//line :30:1
		var arg_27 any; var root_37 any = A_arbace_data_A_const_12.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_39 lang.IFn

		if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any; var root_41 any = A_arbace_data_A_const_13.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any; var root_46 any = A_arbace_data_A_const_14.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_46, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = A_arbace_data_A_const_15.GetRawRoot__O(); var arg_50 any; var root_51 any = A_arbace_data_A_const_16.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = m__0; if linked_52 == nil { arg_50 = ifn_53.Invoke_O__O(arg_54) } else { arg_50 = linked_52.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_51, arg_54) }; if linked_47 == nil { arg_44 = ifn_48.Invoke_O_O__O(arg_49, arg_50) } else { arg_44 = linked_47.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_46, arg_49, arg_50) }; var arg_45 any; if linked_42 == nil { arg_40 = ifn_43.Invoke_O_O__O(arg_44, arg_45) } else { arg_40 = linked_42.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O_O__O(root_41, arg_44, arg_45) }; if linked_38 == nil { arg_27 = ifn_39.Invoke_O__O(arg_40) } else { arg_27 = linked_38.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_37, arg_40) }
//line :30:1
		var arg_28 any = m__0; if linked_24 == nil { return ifn_25.Invoke_O_O_O__O(arg_26, arg_27, arg_28) } else { return linked_24.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_23, arg_26, arg_27, arg_28) } } else {
//line :29:1
			return nil
		} }
func A_arbace_data_vectorize_fn__76000016_A_New() *A_arbace_data_vectorize_fn__76000016_A { A_arbace_data_A_Init(); t := &A_arbace_data_vectorize_fn__76000016_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_data_vectorize_fn__76000016_A) Ctor() {}
//line :31:1
func (t *A_arbace_data_vectorize_fn__76000016_A) Invoke_O_O_O__O(self, result__1, p__76000015__2 any) any { var vec__76000017__3 any = p__76000015__2; var k__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__76000017__3, lang.RT_IntCast_J__I_NoInit(0), nil); var v__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__76000017__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_29 any = A_arbace_data_A_const_11.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_29, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_31 lang.IFn; if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any = result__1; var arg_33 any = k__4; var arg_34 any = v__5; if linked_30 == nil { return ifn_31.Invoke_O_O_O__O(arg_32, arg_33, arg_34) } else { return linked_30.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_29, arg_32, arg_33, arg_34) } }



func A_arbace_data_diff_associative_key_A_New() *A_arbace_data_diff_associative_key_A { A_arbace_data_A_Init(); t := &A_arbace_data_diff_associative_key_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_data_diff_associative_key_A) Ctor() {}
//line :35:1
func (t *A_arbace_data_diff_associative_key_A) Invoke_O_O_O_O__O(self, a__0, b__1, k__2 any) any { var va__4 any = lang.RT_Get_O_O__O_NoInit(a__0, k__2); var vb__5 any = lang.RT_Get_O_O__O_NoInit(b__1, k__2); var vec__76000022__6 any; var root_55 any = A_arbace_data_A_const_17.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, A_arbace_data_diff_A_fn_class); var ifn_57 lang.IFn; if




	linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = va__4; var arg_59 any = vb__5; if linked_56 == nil { vec__76000022__6 = ifn_57.Invoke_O_O__O(arg_58, arg_59) } else { vec__76000022__6 = linked_56.(*A_arbace_data_diff_A).Invoke_O_O_O__O(root_55, arg_58, arg_59) }; var a_STAR___7 any = /*line :35:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__76000022__6, lang.RT_IntCast_J__I_NoInit(0), nil); var b_STAR___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__76000022__6, lang.RT_IntCast_J__I_NoInit(1), nil); var ab__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__76000022__6, lang.RT_IntCast_J__I_NoInit(2), nil); var in_a__10 any; var root_60 any = A_arbace_data_A_const_18.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_62 lang.IFn; if





	linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any = a__0; var arg_64 any = k__2; if linked_61 == nil { in_a__10 = ifn_62.Invoke_O_O__O(arg_63, arg_64) } else { in_a__10 = linked_61.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_60, arg_63, arg_64) }; var in_b__11 any; var root_65 any = /*line :35:1*/A_arbace_data_A_const_18.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_67 lang.IFn; if






	linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = b__1; var arg_69 any = k__2; if linked_66 == nil { in_b__11 = ifn_67.Invoke_O_O__O(arg_68, arg_69) } else { in_b__11 = linked_66.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_65, arg_68, arg_69) }; var same__12 any; var and__1927000168__auto____12 any = in_a__10; if
	jrt.J2g_Truth(and__1927000168__auto____12) { var and__1927000168__auto____13 any = in_b__11; if jrt.J2g_Truth(and__1927000168__auto____13) { var or__1927000174__auto____14 any; var root_70 any = A_arbace_data_A_const_19.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_72 lang.IFn
		if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(ab__9, nil)).Ref(); if linked_71 == nil { or__1927000174__auto____14 = ifn_72.Invoke_O__O(arg_73) } else { or__1927000174__auto____14 = linked_71.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_70, arg_73) }; if jrt.J2g_Truth(or__1927000174__auto____14) { same__12 = or__1927000174__auto____14 } else { var and__1927000168__auto____15 bool = lang.Util_Identical_O_O__Z_NoInit(va__4, nil)
			if and__1927000168__auto____15 { same__12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(vb__5, nil)).Ref() } else { same__12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____15).Ref() } } } else {
//line :43:1
				same__12 = and__1927000168__auto____13 } } else { same__12 = and__1927000168__auto____12 }; var tmp1 lang.IPersistentMap; var tmp2 any; var and__1927000168__auto____13_2 any = in_a__10; if


	jrt.J2g_Truth(and__1927000168__auto____13_2) { var or__1927000174__auto____14_2 any; var root_74 any = A_arbace_data_A_const_19.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_76 lang.IFn; if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(a_STAR___7, nil)).Ref(); if linked_75 == nil { or__1927000174__auto____14_2 = ifn_76.Invoke_O__O(arg_77) } else { or__1927000174__auto____14_2 = linked_75.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_74, arg_77) }; if jrt.J2g_Truth(or__1927000174__auto____14_2) { tmp2 = or__1927000174__auto____14_2 } else { var root_78 any = A_arbace_data_A_const_19.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = same__12; if linked_79 == nil { tmp2 = ifn_80.Invoke_O__O(arg_81) } else { tmp2 = linked_79.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_78, arg_81) } } } else { tmp2 = and__1927000168__auto____13_2 }; if jrt.J2g_Truth(tmp2) { tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, k__2, a_STAR___7)) } else { tmp1 = nil }; var tmp3 any = tmp1; var tmp4 lang.IPersistentMap; var tmp5 any; var and__1927000168__auto____13_3 any = in_b__11; if
	jrt.J2g_Truth(and__1927000168__auto____13_3) { var or__1927000174__auto____14_3 any; var root_82 any = A_arbace_data_A_const_19.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(b_STAR___8, nil)).Ref(); if linked_83 == nil { or__1927000174__auto____14_3 = ifn_84.Invoke_O__O(arg_85) } else { or__1927000174__auto____14_3 = linked_83.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_82, arg_85) }; if jrt.J2g_Truth(or__1927000174__auto____14_3) { tmp5 = or__1927000174__auto____14_3 } else { var root_86 any = A_arbace_data_A_const_19.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_88 lang.IFn; if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any = same__12; if linked_87 == nil { tmp5 = ifn_88.Invoke_O__O(arg_89) } else { tmp5 = linked_87.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_86, arg_89) } } } else { tmp5 = and__1927000168__auto____13_3 }; if jrt.J2g_Truth(tmp5) { tmp4 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, k__2, b_STAR___8)) } else { tmp4 = nil }; var tmp6 any = tmp4; var tmp7 lang.IPersistentMap; if
	jrt.J2g_Truth(same__12) { tmp7 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, k__2, ab__9)) } else { tmp7 = nil }; return /*line :35:1*/ lang.Tuple_Create_O_O_O__IPersistentVector(tmp3, tmp6, tmp7) }















func A_arbace_data_diff_associative_A_New() *A_arbace_data_diff_associative_A { A_arbace_data_A_Init(); t := &A_arbace_data_diff_associative_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_data_diff_associative_A) Ctor() {}
//line :51:1
func (t *A_arbace_data_diff_associative_A) Invoke_O_O_O_O__O(self, a__0, b__1, ks__2 any) any {


	var root_90 any = A_arbace_data_A_const_10.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any; var fnbody__107 any = A_arbace_data_diff_associative_fn__76000026_A_New(); var tmp1 *jrt.Class; var fncls__106 *jrt.Class = A_arbace_data_diff_associative_fn__76000026_A_fn_class
	if fncls__106 == nil { var fncls__106d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1, false, nil); A_arbace_data_diff_associative_fn__76000026_A_fn_class = fncls__106d; tmp1 = fncls__106d } else { tmp1 = fncls__106 }; arg_93 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__107, tmp1, nil)
//line :54:1
	var arg_94 any = A_arbace_data_A_const_23; var arg_95 any; var root_108 any = A_arbace_data_A_const_21.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_108, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_110 lang.IFn



	if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any; var root_113 any = A_arbace_data_A_const_24.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_113, aot_arbace_core.A_arbace_core_partial_A_fn_class); var ifn_115 lang.IFn
	if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = A_arbace_data_A_const_25.GetRawRoot__O(); var arg_117 any = a__0; var arg_118 any = b__1; if linked_114 == nil { arg_111 = ifn_115.Invoke_O_O_O__O(arg_116, arg_117, arg_118) } else { arg_111 = linked_114.(*aot_arbace_core.A_arbace_core_partial_A).Invoke_O_O_O_O__O(root_113, arg_116, arg_117, arg_118) }
//line :58:1
	var arg_112 any = ks__2; if linked_109 == nil { arg_95 = ifn_110.Invoke_O_O__O(arg_111, arg_112) } else { arg_95 = linked_109.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_108, arg_111, arg_112) }
//line :54:1
	if linked_91 == nil { return ifn_92.Invoke_O_O_O__O(arg_93, arg_94, arg_95) } else { return linked_91.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_90, arg_93, arg_94, arg_95) } }
func A_arbace_data_diff_associative_fn__76000026_A_New() *A_arbace_data_diff_associative_fn__76000026_A { A_arbace_data_A_Init(); t := &A_arbace_data_diff_associative_fn__76000026_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_data_diff_associative_fn__76000026_A) Ctor() {}
//line :55:1
func (t *A_arbace_data_diff_associative_fn__76000026_A) Invoke_O_O_O__O(self, diff1__1, diff2__2 any) any {
	var root_96 any = A_arbace_data_A_const_20.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any; var root_100 any = A_arbace_data_A_const_21.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = A_arbace_data_A_const_22.GetRawRoot__O(); var arg_104 any = diff1__1; var arg_105 any = diff2__2; if linked_101 == nil { arg_99 = ifn_102.Invoke_O_O_O__O(arg_103, arg_104, arg_105) } else { arg_99 = linked_101.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_100, arg_103, arg_104, arg_105) }; if linked_97 == nil { return ifn_98.Invoke_O__O(arg_99) } else { return linked_97.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_96, arg_99)
	}
}



func A_arbace_data_diff_sequential_A_New() *A_arbace_data_diff_sequential_A { A_arbace_data_A_Init(); t := &A_arbace_data_diff_sequential_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_data_diff_sequential_A) Ctor() {}
//line :62:1
func (t *A_arbace_data_diff_sequential_A) Invoke_O_O_O__O(self, a__0, b__1 any) any {

	var root_119 any = A_arbace_data_A_const_12.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any; var root_123 any = A_arbace_data_A_const_21.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = A_arbace_data_A_const_26.GetRawRoot__O(); var arg_127 any; var root_128 any = A_arbace_data_A_const_27.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, A_arbace_data_diff_associative_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any; var tmp1 any; var root_134 any = A_arbace_data_A_const_28.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_136 lang.IFn
	if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = a__0; if linked_135 == nil { tmp1 = ifn_136.Invoke_O__O(arg_137) } else { tmp1 = linked_135.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_134, arg_137) }; if jrt.J2g_Truth(tmp1) { arg_131 = a__0 } else { var root_138 any = A_arbace_data_A_const_12.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = a__0; if linked_139 == nil { arg_131 = ifn_140.Invoke_O__O(arg_141) } else { arg_131 = linked_139.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_138, arg_141) } }
//line :64:1
	var arg_132 any; var tmp2 any; var root_142 any = A_arbace_data_A_const_28.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_144 lang.IFn

	if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = b__1; if linked_143 == nil { tmp2 = ifn_144.Invoke_O__O(arg_145) } else { tmp2 = linked_143.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_142, arg_145) }; if jrt.J2g_Truth(tmp2) { arg_132 = b__1 } else { var root_146 any = A_arbace_data_A_const_12.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = b__1; if linked_147 == nil { arg_132 = ifn_148.Invoke_O__O(arg_149) } else { arg_132 = linked_147.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_146, arg_149) } }
//line :64:1
	var arg_133 any; var root_150 any = A_arbace_data_A_const_29.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_152 lang.IFn


	if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Max_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(a__0)), int64(lang.RT_Count_O__I_NoInit(b__1)))).Ref(); if linked_151 == nil { arg_133 = ifn_152.Invoke_O__O(arg_153) } else { arg_133 = linked_151.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_150, arg_153) }
//line :64:1
	if linked_129 == nil { arg_127 = ifn_130.Invoke_O_O_O__O(arg_131, arg_132, arg_133) } else { arg_127 = linked_129.(*A_arbace_data_diff_associative_A).Invoke_O_O_O_O__O(root_128, arg_131, arg_132, arg_133) }; if linked_124 == nil { arg_122 = ifn_125.Invoke_O_O__O(arg_126, arg_127) } else { arg_122 = linked_124.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_123, arg_126, arg_127) }; if linked_120 == nil { return ifn_121.Invoke_O__O(arg_122) } else { return linked_120.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_119, arg_122)
	}
}


func A_arbace_data_eval76000038_fn__76000039_A_New() *A_arbace_data_eval76000038_fn__76000039_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000038_fn__76000039_A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_data_eval76000038_fn__76000039_A) Ctor() {}
//line :69:1
func (t *A_arbace_data_eval76000038_fn__76000039_A) Invoke_O_O__O(self, cache__231000282__auto____1 any) any { var G__76000031__2_ any; var fnbody__156 any = A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_New(); var tmp1 *jrt.Class; var fncls__155 *jrt.Class = A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_fn_class; if fncls__155 == nil { var fncls__155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, nil); A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_fn_class = fncls__155d; tmp1 = fncls__155d } else { tmp1 = fncls__155 }; G__76000031__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__156, tmp1, nil); var f__231000283__auto____3 any; var fnbody__165 any = A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_New_O(G__76000031__2_); var tmp2 *jrt.Class; var fncls__164 *jrt.Class = A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_fn_class; if fncls__164 == nil { var fncls__164d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, fnbody__165); A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_fn_class = fncls__164d; tmp2 = fncls__164d } else { tmp2 = fncls__164 }; f__231000283__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__165, tmp2, nil); lang.AFunction_Cast(f__231000283__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000282__auto____1)); return f__231000283__auto____3 }
//line :69:1
func A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_New_O(p0 any) *A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A{}; t.Ctor_O(p0); return t }
//line :69:1
func (t *A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A) Ctor_O(c__G__76000031 any) { t.F_G__76000031 = c__G__76000031 }
//line :69:1
func (t *A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A) Invoke_O_O__O(self, gf__x__76000043__1 any) any { var cache__231000280__auto____2 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000281__auto____3 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000280__auto____2)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__x__76000043__1)); if jrt.J2g_Truth(f__231000281__auto____3) { return lang.IFn_Cast(f__231000281__auto____3).Invoke_O__O(gf__x__76000043__1) } else { var tmp1 any; var root_157 any = A_arbace_data_A_const_30.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_core.A_arbace_core__cache_protocol_fn_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any = self; var arg_161 any = gf__x__76000043__1; var arg_162 any = A_arbace_data_A_const_31; var arg_163 any = t.F_G__76000031; if linked_158 == nil { tmp1 = ifn_159.Invoke_O_O_O_O__O(arg_160, arg_161, arg_162, arg_163) } else { tmp1 = linked_158.(*aot_arbace_core.A_arbace_core__cache_protocol_fn_A).Invoke_O_O_O_O_O__O(root_157, arg_160, arg_161, arg_162, arg_163) }; return lang.IFn_Cast(tmp1).Invoke_O__O(gf__x__76000043__1) } }
//line :69:1
func A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_New() *A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A) Ctor() {}
//line :69:1
func (t *A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A) Invoke_O_O__O(self, gf__x__76000040__1 any) any { var target_154 any = gf__x__76000040__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_154 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_154) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_154, Lit_4, jrt.RefArrayOf(jrt.Object_class)) } else { return A_arbace_data_EqualityPartition_A_Cast(target_154).Equality_partition__O() } }



func A_arbace_data_eval76000060_fn__76000061_A_New() *A_arbace_data_eval76000060_fn__76000061_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000060_fn__76000061_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_data_eval76000060_fn__76000061_A) Ctor() {}
//line :73:1
func (t *A_arbace_data_eval76000060_fn__76000061_A) Invoke_O_O__O(self, cache__231000282__auto____1 any) any { var G__76000053__2_ any; var fnbody__168 any = A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_New(); var tmp1 *jrt.Class; var fncls__167 *jrt.Class = A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_fn_class; if fncls__167 == nil { var fncls__167d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, nil); A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_fn_class = fncls__167d; tmp1 = fncls__167d } else { tmp1 = fncls__167 }; G__76000053__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__168, tmp1, nil); var f__231000283__auto____3 any; var fnbody__177 any = A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_New_O(G__76000053__2_); var tmp2 *jrt.Class; var fncls__176 *jrt.Class = A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_fn_class; if fncls__176 == nil { var fncls__176d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, fnbody__177); A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_fn_class = fncls__176d; tmp2 = fncls__176d } else { tmp2 = fncls__176 }; f__231000283__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__177, tmp2, nil); lang.AFunction_Cast(f__231000283__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000282__auto____1)); return f__231000283__auto____3 }
//line :73:1
func A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_New_O(p0 any) *A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A{}; t.Ctor_O(p0); return t }
//line :73:1
func (t *A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A) Ctor_O(c__G__76000053 any) { t.F_G__76000053 = c__G__76000053 }
//line :73:1
func (t *A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A) Invoke_O_O_O__O(self, gf__a__76000066__1, gf__b__76000067__2 any) any { var cache__231000280__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000281__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000280__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__a__76000066__1)); if jrt.J2g_Truth(f__231000281__auto____4) { return lang.IFn_Cast(f__231000281__auto____4).Invoke_O_O__O(gf__a__76000066__1, gf__b__76000067__2) } else { var tmp1 any; var root_169 any = A_arbace_data_A_const_30.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core__cache_protocol_fn_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = self; var arg_173 any = gf__a__76000066__1; var arg_174 any = A_arbace_data_A_const_32; var arg_175 any = t.F_G__76000053; if linked_170 == nil { tmp1 = ifn_171.Invoke_O_O_O_O__O(arg_172, arg_173, arg_174, arg_175) } else { tmp1 = linked_170.(*aot_arbace_core.A_arbace_core__cache_protocol_fn_A).Invoke_O_O_O_O_O__O(root_169, arg_172, arg_173, arg_174, arg_175) }; return lang.IFn_Cast(tmp1).Invoke_O_O__O(gf__a__76000066__1, gf__b__76000067__2) } }
//line :73:1
func A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_New() *A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A) Ctor() {}
//line :73:1
func (t *A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A) Invoke_O_O_O__O(self, gf__a__76000062__1, gf__b__76000063__2 any) any { var target_166 any = gf__a__76000062__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_166 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_166) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_166, Lit_7, jrt.RefArrayOf(jrt.Object_class, gf__b__76000063__2)) } else { return A_arbace_data_Diff_A_Cast(target_166).Diff_similar_O__O(gf__b__76000063__2) } }









func A_arbace_data_eval76000078_fn__76000079_A_New() *A_arbace_data_eval76000078_fn__76000079_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000078_fn__76000079_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_data_eval76000078_fn__76000079_A) Ctor() {}
//line :83:1
func (t *A_arbace_data_eval76000078_fn__76000079_A) Invoke_O_O_O__O(self, a__1, b__2 any) any {
	var tmp1 any; if jrt.NN(jrt.GetClass(a__1)).IsArray__Z() { tmp1 = A_arbace_data_A_const_33.GetRawRoot__O() } else { tmp1 = A_arbace_data_A_const_34.GetRawRoot__O() }; return lang.IFn_Cast(tmp1).Invoke_O_O__O(a__1, b__2)
}
func A_arbace_data_eval76000078_fn__76000081_A_New() *A_arbace_data_eval76000078_fn__76000081_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000078_fn__76000081_A{}; t.Ctor(); return t }
//line :86:1
func (t *A_arbace_data_eval76000078_fn__76000081_A) Ctor() {}
//line :86:1
func (t *A_arbace_data_eval76000078_fn__76000081_A) Invoke_O_O__O(self, x__1 any) any {
	if jrt.NN(jrt.GetClass(x__1)).IsArray__Z() { return A_arbace_data_A_const_35 } else { return A_arbace_data_A_const_36
	} }
func A_arbace_data_eval76000084_fn__76000085_A_New() *A_arbace_data_eval76000084_fn__76000085_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000084_fn__76000085_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_data_eval76000084_fn__76000085_A) Ctor() {}
//line :89:1
func (t *A_arbace_data_eval76000084_fn__76000085_A) Invoke_O_O__O(self, x__1 any) any { return A_arbace_data_A_const_36 }
//line :89:1
func A_arbace_data_eval76000088_fn__76000089_A_New() *A_arbace_data_eval76000088_fn__76000089_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000088_fn__76000089_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_data_eval76000088_fn__76000089_A) Ctor() {}
//line :89:1
func (t *A_arbace_data_eval76000088_fn__76000089_A) Invoke_O_O__O(self, x__1 any) any { return A_arbace_data_A_const_37 }
//line :89:1
func A_arbace_data_eval76000092_fn__76000093_A_New() *A_arbace_data_eval76000092_fn__76000093_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000092_fn__76000093_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_data_eval76000092_fn__76000093_A) Ctor() {}
//line :89:1
func (t *A_arbace_data_eval76000092_fn__76000093_A) Invoke_O_O__O(self, x__1 any) any { return A_arbace_data_A_const_35 }
//line :89:1
func A_arbace_data_eval76000096_fn__76000097_A_New() *A_arbace_data_eval76000096_fn__76000097_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000096_fn__76000097_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_data_eval76000096_fn__76000097_A) Ctor() {}
//line :89:1
func (t *A_arbace_data_eval76000096_fn__76000097_A) Invoke_O_O__O(self, x__1 any) any { return A_arbace_data_A_const_38 }












func A_arbace_data_as_set_value_A_New() *A_arbace_data_as_set_value_A { A_arbace_data_A_Init(); t := &A_arbace_data_as_set_value_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_data_as_set_value_A) Ctor() {}
//line :102:1
func (t *A_arbace_data_as_set_value_A) Invoke_O_O__O(self, s__0 any) any {

	var tmp1 any; var root_178 any = A_arbace_data_A_const_39.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_set_QMARK__A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = s__0; if linked_179 == nil { tmp1 = ifn_180.Invoke_O__O(arg_181) } else { tmp1 = linked_179.(*aot_arbace_core.A_arbace_core_set_QMARK__A).Invoke_O_O__O(root_178, arg_181) }; if jrt.J2g_Truth(tmp1) { return s__0 } else { var root_182 any = A_arbace_data_A_const_40.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = lang.PersistentHashSet_EMPTY.Ref(); var arg_186 any = s__0; if linked_183 == nil { return ifn_184.Invoke_O_O__O(arg_185, arg_186) } else { return linked_183.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_182, arg_185, arg_186)
	} } }
func A_arbace_data_eval76000101_fn__76000102_A_New() *A_arbace_data_eval76000101_fn__76000102_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000101_fn__76000102_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_data_eval76000101_fn__76000102_A) Ctor() {}
//line :106:1
func (t *A_arbace_data_eval76000101_fn__76000102_A) Invoke_O_O_O__O(self, a__1, b__2 any) any { var aval__3 any; var root_187 any = A_arbace_data_A_const_41.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, A_arbace_data_as_set_value_A_fn_class); var ifn_189 lang.IFn; if



	linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any = a__1; if linked_188 == nil { aval__3 = ifn_189.Invoke_O__O(arg_190) } else { aval__3 = linked_188.(*A_arbace_data_as_set_value_A).Invoke_O_O__O(root_187, arg_190) }; var bval__4 any; var root_191 any = /*line :106:1*/A_arbace_data_A_const_41.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_191, A_arbace_data_as_set_value_A_fn_class); var ifn_193 lang.IFn; if




	linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any = b__2; if linked_192 == nil { bval__4 = ifn_193.Invoke_O__O(arg_194) } else { bval__4 = linked_192.(*A_arbace_data_as_set_value_A).Invoke_O_O__O(root_191, arg_194) }; var tmp1 any; var root_195 any = /*line :106:1*/A_arbace_data_A_const_42.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_not_empty_A_fn_class); var ifn_197 lang.IFn; if





	linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any; var root_199 any = A_arbace_data_A_const_43.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_199, aot_arbace_set.A_arbace_set_difference_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = aval__3; var arg_203 any = bval__4; if linked_200 == nil { arg_198 = ifn_201.Invoke_O_O__O(arg_202, arg_203) } else { arg_198 = linked_200.(*aot_arbace_set.A_arbace_set_difference_A).Invoke_O_O_O__O(root_199, arg_202, arg_203) }; if linked_196 == nil { tmp1 = ifn_197.Invoke_O__O(arg_198) } else { tmp1 = linked_196.(*aot_arbace_core.A_arbace_core_not_empty_A).Invoke_O_O__O(root_195, arg_198) }; var tmp2 any = tmp1; var tmp3 any; var root_204 any = /*line :106:1*/A_arbace_data_A_const_42.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_not_empty_A_fn_class); var ifn_206 lang.IFn; if






	linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any; var root_208 any = A_arbace_data_A_const_43.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_208, aot_arbace_set.A_arbace_set_difference_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = bval__4; var arg_212 any = aval__3; if linked_209 == nil { arg_207 = ifn_210.Invoke_O_O__O(arg_211, arg_212) } else { arg_207 = linked_209.(*aot_arbace_set.A_arbace_set_difference_A).Invoke_O_O_O__O(root_208, arg_211, arg_212) }; if linked_205 == nil { tmp3 = ifn_206.Invoke_O__O(arg_207) } else { tmp3 = linked_205.(*aot_arbace_core.A_arbace_core_not_empty_A).Invoke_O_O__O(root_204, arg_207) }; var tmp4 any = tmp3; var tmp5 any; var root_213 any = /*line :106:1*/A_arbace_data_A_const_42.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_not_empty_A_fn_class); var ifn_215 lang.IFn; if







	linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any; var root_217 any = A_arbace_data_A_const_44.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_217, aot_arbace_set.A_arbace_set_intersection_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = aval__3; var arg_221 any = bval__4; if linked_218 == nil { arg_216 = ifn_219.Invoke_O_O__O(arg_220, arg_221) } else { arg_216 = linked_218.(*aot_arbace_set.A_arbace_set_intersection_A).Invoke_O_O_O__O(root_217, arg_220, arg_221) }; if linked_214 == nil { tmp5 = ifn_215.Invoke_O__O(arg_216) } else { tmp5 = linked_214.(*aot_arbace_core.A_arbace_core_not_empty_A).Invoke_O_O__O(root_213, arg_216) }; return /*line :106:1*/ lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, tmp4, tmp5) }
//line :106:1
func A_arbace_data_eval76000105_fn__76000106_A_New() *A_arbace_data_eval76000105_fn__76000106_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000105_fn__76000106_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_data_eval76000105_fn__76000106_A) Ctor() {}
//line :106:1
func (t *A_arbace_data_eval76000105_fn__76000106_A) Invoke_O_O_O__O(self, a__1, b__2 any) any {











	var root_222 any = A_arbace_data_A_const_33.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, A_arbace_data_diff_sequential_A_fn_class); var ifn_224 lang.IFn; if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any = a__1; var arg_226 any = b__2; if linked_223 == nil { return ifn_224.Invoke_O_O__O(arg_225, arg_226) } else { return linked_223.(*A_arbace_data_diff_sequential_A).Invoke_O_O_O__O(root_222, arg_225, arg_226) } }
//line :106:1
func A_arbace_data_eval76000109_fn__76000110_A_New() *A_arbace_data_eval76000109_fn__76000110_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000109_fn__76000110_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_data_eval76000109_fn__76000110_A) Ctor() {}
//line :106:1
func (t *A_arbace_data_eval76000109_fn__76000110_A) Invoke_O_O_O__O(self, a__1, b__2 any) any {















	var root_227 any = A_arbace_data_A_const_27.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, A_arbace_data_diff_associative_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = a__1; var arg_231 any = b__2; var arg_232 any; var root_233 any = A_arbace_data_A_const_45.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_233, aot_arbace_set.A_arbace_set_union_A_fn_class); var ifn_235 lang.IFn; if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any; var root_238 any = A_arbace_data_A_const_16.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = a__1; if linked_239 == nil { arg_236 = ifn_240.Invoke_O__O(arg_241) } else { arg_236 = linked_239.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_238, arg_241) }; var arg_237 any; var root_242 any = A_arbace_data_A_const_16.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = b__2; if linked_243 == nil { arg_237 = ifn_244.Invoke_O__O(arg_245) } else { arg_237 = linked_243.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_242, arg_245) }; if linked_234 == nil { arg_232 = ifn_235.Invoke_O_O__O(arg_236, arg_237) } else { arg_232 = linked_234.(*aot_arbace_set.A_arbace_set_union_A).Invoke_O_O_O__O(root_233, arg_236, arg_237) }; if linked_228 == nil { return ifn_229.Invoke_O_O_O__O(arg_230, arg_231, arg_232) } else { return linked_228.(*A_arbace_data_diff_associative_A).Invoke_O_O_O_O__O(root_227, arg_230, arg_231, arg_232)
	} }
func A_arbace_data_diff_A_New() *A_arbace_data_diff_A { A_arbace_data_A_Init(); t := &A_arbace_data_diff_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_data_diff_A) Ctor() {}
//line :124:1
func (t *A_arbace_data_diff_A) Invoke_O_O_O__O(self, a__0, b__1 any) any {













	if lang.Util_Equiv_O_O__Z_NoInit(a__0, b__1) { return lang.Tuple_Create_O_O_O__IPersistentVector(nil, nil, a__0) } else {

		var tmp1 any; var target_246 any = a__0; var tmp2 bool; var tmp3 bool; tmp3 = A_arbace_data_EqualityPartition_A_InstanceOf(target_246); if tmp3 { tmp3 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_246) }; tmp2 = tmp3; if tmp2 { tmp1 = A_arbace_data_EqualityPartition_A_Cast(target_246).Equality_partition__O() } else { tmp1 = lang.IFn_Cast(A_arbace_data_A_const_46.GetRawRoot__O()).Invoke_O__O(target_246) }; var tmp4 any = tmp1; var tmp5 any; var target_247 any = b__1; var tmp6 bool; var tmp7 bool; tmp7 = A_arbace_data_EqualityPartition_A_InstanceOf(target_247); if tmp7 { tmp7 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_247) }; tmp6 = tmp7; if tmp6 { tmp5 = A_arbace_data_EqualityPartition_A_Cast(target_247).Equality_partition__O() } else { tmp5 = lang.IFn_Cast(A_arbace_data_A_const_46.GetRawRoot__O()).Invoke_O__O(target_247) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5) {
			var target_248 any = a__0; var tmp8 bool; var tmp9 bool; tmp9 = A_arbace_data_Diff_A_InstanceOf(target_248); if tmp9 { tmp9 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_248) }; tmp8 = tmp9; if tmp8 { return A_arbace_data_Diff_A_Cast(target_248).Diff_similar_O__O(b__1) } else { return lang.IFn_Cast(A_arbace_data_A_const_47.GetRawRoot__O()).Invoke_O_O__O(target_248, b__1) } } else {
				var root_249 any = A_arbace_data_A_const_34.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, A_arbace_data_atom_diff_A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = a__0; var arg_253 any = b__1; if linked_250 == nil { return ifn_251.Invoke_O_O__O(arg_252, arg_253) } else { return linked_250.(*A_arbace_data_atom_diff_A).Invoke_O_O_O__O(root_249, arg_252, arg_253)
				}
			}
	}
}


























type A_arbace_data_A struct{ jrt.Object }

var A_arbace_data_A_const_pool *jrt.RefArray

var A_arbace_data_A_const_0 *lang.Var

var A_arbace_data_A_const_1 any

var A_arbace_data_A_const_2 *lang.Var

var A_arbace_data_A_const_3 any

var A_arbace_data_A_const_4 *lang.Var

var A_arbace_data_A_const_5 *lang.Var

var A_arbace_data_A_const_6 *lang.Var

var A_arbace_data_A_const_7 *lang.Var

var A_arbace_data_A_const_8 any

var A_arbace_data_A_const_9 *lang.Var

var A_arbace_data_A_const_10 *lang.Var

var A_arbace_data_A_const_11 *lang.Var

var A_arbace_data_A_const_12 *lang.Var

var A_arbace_data_A_const_13 *lang.Var

var A_arbace_data_A_const_14 *lang.Var

var A_arbace_data_A_const_15 *lang.Var

var A_arbace_data_A_const_16 *lang.Var

var A_arbace_data_A_const_17 *lang.Var

var A_arbace_data_A_const_18 *lang.Var

var A_arbace_data_A_const_19 *lang.Var

var A_arbace_data_A_const_20 *lang.Var

var A_arbace_data_A_const_21 *lang.Var

var A_arbace_data_A_const_22 *lang.Var

var A_arbace_data_A_const_23 any

var A_arbace_data_A_const_24 *lang.Var

var A_arbace_data_A_const_25 *lang.Var

var A_arbace_data_A_const_26 *lang.Var

var A_arbace_data_A_const_27 *lang.Var

var A_arbace_data_A_const_28 *lang.Var

var A_arbace_data_A_const_29 *lang.Var

var A_arbace_data_A_const_30 *lang.Var

var A_arbace_data_A_const_31 *jrt.Class

var A_arbace_data_A_const_32 *jrt.Class

var A_arbace_data_A_const_33 *lang.Var

var A_arbace_data_A_const_34 *lang.Var

var A_arbace_data_A_const_35 *lang.Keyword

var A_arbace_data_A_const_36 *lang.Keyword

var A_arbace_data_A_const_37 *lang.Keyword

var A_arbace_data_A_const_38 *lang.Keyword

var A_arbace_data_A_const_39 *lang.Var

var A_arbace_data_A_const_40 *lang.Var

var A_arbace_data_A_const_41 *lang.Var

var A_arbace_data_A_const_42 *lang.Var

var A_arbace_data_A_const_43 *lang.Var

var A_arbace_data_A_const_44 *lang.Var

var A_arbace_data_A_const_45 *lang.Var

var A_arbace_data_A_const_46 *lang.Var

var A_arbace_data_A_const_47 *lang.Var

var A_arbace_data_A_init jrt.ClassInit

func A_arbace_data_A_Init() { if !A_arbace_data_A_init.Done() { A_arbace_data_A_init.Run(A_arbace_data_A_clinit) } }

func A_arbace_data_A_clinit() { A_arbace_data_A_clinit_p0(); A_arbace_data_A_clinit_p1(); A_arbace_data_A_clinit_p2(); A_arbace_data_A_clinit_p3() }

func A_arbace_data_A_clinit_p0() { jrt.StartCheck(); A_arbace_data_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 58); A_arbace_data_A_const_0 = lang.Var_Cast(A_arbace_data_A_const_pool.A[10]); A_arbace_data_A_const_1 = A_arbace_data_A_const_pool.A[11]; A_arbace_data_A_const_2 = lang.Var_Cast(A_arbace_data_A_const_pool.A[12]); A_arbace_data_A_const_3 = A_arbace_data_A_const_pool.A[13]; A_arbace_data_A_const_4 = lang.Var_Cast(A_arbace_data_A_const_pool.A[14]); A_arbace_data_A_const_5 = lang.Var_Cast(A_arbace_data_A_const_pool.A[15]); A_arbace_data_A_const_6 = lang.Var_Cast(A_arbace_data_A_const_pool.A[16]); A_arbace_data_A_const_7 = lang.Var_Cast(A_arbace_data_A_const_pool.A[17]); A_arbace_data_A_const_8 = A_arbace_data_A_const_pool.A[18]; A_arbace_data_A_const_9 = lang.Var_Cast(A_arbace_data_A_const_pool.A[19]); A_arbace_data_A_const_10 = lang.Var_Cast(A_arbace_data_A_const_pool.A[20]); A_arbace_data_A_const_11 = lang.Var_Cast(A_arbace_data_A_const_pool.A[21]) }

func A_arbace_data_A_clinit_p1() { A_arbace_data_A_const_12 = lang.Var_Cast(A_arbace_data_A_const_pool.A[22]); A_arbace_data_A_const_13 = lang.Var_Cast(A_arbace_data_A_const_pool.A[23]); A_arbace_data_A_const_14 = lang.Var_Cast(A_arbace_data_A_const_pool.A[24]); A_arbace_data_A_const_15 = lang.Var_Cast(A_arbace_data_A_const_pool.A[25]); A_arbace_data_A_const_16 = lang.Var_Cast(A_arbace_data_A_const_pool.A[26]); A_arbace_data_A_const_17 = lang.Var_Cast(A_arbace_data_A_const_pool.A[27]); A_arbace_data_A_const_18 = lang.Var_Cast(A_arbace_data_A_const_pool.A[28]); A_arbace_data_A_const_19 = lang.Var_Cast(A_arbace_data_A_const_pool.A[29]); A_arbace_data_A_const_20 = lang.Var_Cast(A_arbace_data_A_const_pool.A[30]); A_arbace_data_A_const_21 = lang.Var_Cast(A_arbace_data_A_const_pool.A[31]); A_arbace_data_A_const_22 = lang.Var_Cast(A_arbace_data_A_const_pool.A[32]); A_arbace_data_A_const_23 = A_arbace_data_A_const_pool.A[33] }

func A_arbace_data_A_clinit_p2() { A_arbace_data_A_const_24 = lang.Var_Cast(A_arbace_data_A_const_pool.A[34]); A_arbace_data_A_const_25 = lang.Var_Cast(A_arbace_data_A_const_pool.A[35]); A_arbace_data_A_const_26 = lang.Var_Cast(A_arbace_data_A_const_pool.A[36]); A_arbace_data_A_const_27 = lang.Var_Cast(A_arbace_data_A_const_pool.A[37]); A_arbace_data_A_const_28 = lang.Var_Cast(A_arbace_data_A_const_pool.A[38]); A_arbace_data_A_const_29 = lang.Var_Cast(A_arbace_data_A_const_pool.A[39]); A_arbace_data_A_const_30 = lang.Var_Cast(A_arbace_data_A_const_pool.A[40]); A_arbace_data_A_const_31 = jrt.Class_Cast(A_arbace_data_A_const_pool.A[41]); A_arbace_data_A_const_32 = jrt.Class_Cast(A_arbace_data_A_const_pool.A[42]); A_arbace_data_A_const_33 = lang.Var_Cast(A_arbace_data_A_const_pool.A[43]); A_arbace_data_A_const_34 = lang.Var_Cast(A_arbace_data_A_const_pool.A[44]); A_arbace_data_A_const_35 = lang.Keyword_Cast(A_arbace_data_A_const_pool.A[45]) }

func A_arbace_data_A_clinit_p3() { A_arbace_data_A_const_36 = lang.Keyword_Cast(A_arbace_data_A_const_pool.A[46]); A_arbace_data_A_const_37 = lang.Keyword_Cast(A_arbace_data_A_const_pool.A[47]); A_arbace_data_A_const_38 = lang.Keyword_Cast(A_arbace_data_A_const_pool.A[48]); A_arbace_data_A_const_39 = lang.Var_Cast(A_arbace_data_A_const_pool.A[49]); A_arbace_data_A_const_40 = lang.Var_Cast(A_arbace_data_A_const_pool.A[50]); A_arbace_data_A_const_41 = lang.Var_Cast(A_arbace_data_A_const_pool.A[51]); A_arbace_data_A_const_42 = lang.Var_Cast(A_arbace_data_A_const_pool.A[52]); A_arbace_data_A_const_43 = lang.Var_Cast(A_arbace_data_A_const_pool.A[53]); A_arbace_data_A_const_44 = lang.Var_Cast(A_arbace_data_A_const_pool.A[54]); A_arbace_data_A_const_45 = lang.Var_Cast(A_arbace_data_A_const_pool.A[55]); A_arbace_data_A_const_46 = lang.Var_Cast(A_arbace_data_A_const_pool.A[56]); A_arbace_data_A_const_47 = lang.Var_Cast(A_arbace_data_A_const_pool.A[57]) }

func A_arbace_data_A_New() *A_arbace_data_A { A_arbace_data_A_Init(); t := &A_arbace_data_A{}; t.Ctor(); return t }

func (t *A_arbace_data_A) Ctor() {}

func (t *A_arbace_data_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_A) GetClass__Class() *jrt.Class { return A_arbace_data_A_class }

func (t *A_arbace_data_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_A); return ok }

func A_arbace_data_A_Cast(x any) *A_arbace_data_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_A_class)) }; return v }



type A_arbace_data_as_set_value_A struct{ j2g_header uint64 }

var A_arbace_data_as_set_value_A_fn_class *jrt.Class



type A_arbace_data_atom_diff_A struct{ j2g_header uint64 }

var A_arbace_data_atom_diff_A_fn_class *jrt.Class



type A_arbace_data_diff_A struct{ j2g_header uint64 }

var A_arbace_data_diff_A_fn_class *jrt.Class



type A_arbace_data_diff_associative_A struct{ j2g_header uint64 }

var A_arbace_data_diff_associative_A_fn_class *jrt.Class



type A_arbace_data_diff_associative_fn__76000026_A struct{ j2g_header uint64 }

var A_arbace_data_diff_associative_fn__76000026_A_fn_class *jrt.Class



type A_arbace_data_diff_associative_key_A struct{ j2g_header uint64 }

var A_arbace_data_diff_associative_key_A_fn_class *jrt.Class



type A_arbace_data_diff_sequential_A struct{ j2g_header uint64 }

var A_arbace_data_diff_sequential_A_fn_class *jrt.Class



type A_arbace_data_eval76000004_A struct{ jrt.Object }

func A_arbace_data_eval76000004_A_New() *A_arbace_data_eval76000004_A { t := &A_arbace_data_eval76000004_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000004_A) Ctor() {}

func (t *A_arbace_data_eval76000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000004_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000004_A_class }

func (t *A_arbace_data_eval76000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000004_A); return ok }

func A_arbace_data_eval76000004_A_Cast(x any) *A_arbace_data_eval76000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000004_A_class)) }; return v }



type A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_fn_class *jrt.Class



type A_arbace_data_eval76000008_A struct{ jrt.Object }

func A_arbace_data_eval76000008_A_New() *A_arbace_data_eval76000008_A { t := &A_arbace_data_eval76000008_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000008_A) Ctor() {}

func (t *A_arbace_data_eval76000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000008_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000008_A_class }

func (t *A_arbace_data_eval76000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000008_A); return ok }

func A_arbace_data_eval76000008_A_Cast(x any) *A_arbace_data_eval76000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000008_A_class)) }; return v }



type A_arbace_data_eval76000008_fn__76000009_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000008_fn__76000009_A_fn_class *jrt.Class



type A_arbace_data_eval76000038_A struct{ jrt.Object }

func A_arbace_data_eval76000038_A_New() *A_arbace_data_eval76000038_A { t := &A_arbace_data_eval76000038_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000038_A) Ctor() {}

func (t *A_arbace_data_eval76000038_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000038_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000038_A_class }

func (t *A_arbace_data_eval76000038_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000038_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000038_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000038_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000038_A); return ok }

func A_arbace_data_eval76000038_A_Cast(x any) *A_arbace_data_eval76000038_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000038_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000038_A_class)) }; return v }



type A_arbace_data_eval76000038_fn__76000039_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000038_fn__76000039_A_fn_class *jrt.Class



type A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A struct{ j2g_header uint64; F_G__76000031 any }

var A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_fn_class *jrt.Class



type A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_fn_class *jrt.Class



type A_arbace_data_eval76000060_A struct{ jrt.Object }

func A_arbace_data_eval76000060_A_New() *A_arbace_data_eval76000060_A { t := &A_arbace_data_eval76000060_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000060_A) Ctor() {}

func (t *A_arbace_data_eval76000060_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000060_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000060_A_class }

func (t *A_arbace_data_eval76000060_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000060_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000060_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000060_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000060_A); return ok }

func A_arbace_data_eval76000060_A_Cast(x any) *A_arbace_data_eval76000060_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000060_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000060_A_class)) }; return v }



type A_arbace_data_eval76000060_fn__76000061_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000060_fn__76000061_A_fn_class *jrt.Class



type A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A struct{ j2g_header uint64; F_G__76000053 any }

var A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_fn_class *jrt.Class



type A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_fn_class *jrt.Class



type A_arbace_data_eval76000078_A struct{ jrt.Object }

func A_arbace_data_eval76000078_A_New() *A_arbace_data_eval76000078_A { t := &A_arbace_data_eval76000078_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000078_A) Ctor() {}

func (t *A_arbace_data_eval76000078_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000078_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000078_A_class }

func (t *A_arbace_data_eval76000078_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000078_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000078_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000078_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000078_A); return ok }

func A_arbace_data_eval76000078_A_Cast(x any) *A_arbace_data_eval76000078_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000078_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000078_A_class)) }; return v }



type A_arbace_data_eval76000078_fn__76000079_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000078_fn__76000079_A_fn_class *jrt.Class



type A_arbace_data_eval76000078_fn__76000081_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000078_fn__76000081_A_fn_class *jrt.Class



type A_arbace_data_eval76000084_A struct{ jrt.Object }

func A_arbace_data_eval76000084_A_New() *A_arbace_data_eval76000084_A { t := &A_arbace_data_eval76000084_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000084_A) Ctor() {}

func (t *A_arbace_data_eval76000084_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000084_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000084_A_class }

func (t *A_arbace_data_eval76000084_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000084_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000084_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000084_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000084_A); return ok }

func A_arbace_data_eval76000084_A_Cast(x any) *A_arbace_data_eval76000084_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000084_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000084_A_class)) }; return v }



type A_arbace_data_eval76000084_fn__76000085_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000084_fn__76000085_A_fn_class *jrt.Class



type A_arbace_data_eval76000088_A struct{ jrt.Object }

func A_arbace_data_eval76000088_A_New() *A_arbace_data_eval76000088_A { t := &A_arbace_data_eval76000088_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000088_A) Ctor() {}

func (t *A_arbace_data_eval76000088_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000088_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000088_A_class }

func (t *A_arbace_data_eval76000088_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000088_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000088_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000088_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000088_A); return ok }

func A_arbace_data_eval76000088_A_Cast(x any) *A_arbace_data_eval76000088_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000088_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000088_A_class)) }; return v }



type A_arbace_data_eval76000088_fn__76000089_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000088_fn__76000089_A_fn_class *jrt.Class



type A_arbace_data_eval76000092_A struct{ jrt.Object }

func A_arbace_data_eval76000092_A_New() *A_arbace_data_eval76000092_A { t := &A_arbace_data_eval76000092_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000092_A) Ctor() {}

func (t *A_arbace_data_eval76000092_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000092_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000092_A_class }

func (t *A_arbace_data_eval76000092_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000092_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000092_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000092_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000092_A); return ok }

func A_arbace_data_eval76000092_A_Cast(x any) *A_arbace_data_eval76000092_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000092_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000092_A_class)) }; return v }



type A_arbace_data_eval76000092_fn__76000093_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000092_fn__76000093_A_fn_class *jrt.Class



type A_arbace_data_eval76000096_A struct{ jrt.Object }

func A_arbace_data_eval76000096_A_New() *A_arbace_data_eval76000096_A { t := &A_arbace_data_eval76000096_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000096_A) Ctor() {}

func (t *A_arbace_data_eval76000096_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000096_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000096_A_class }

func (t *A_arbace_data_eval76000096_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000096_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000096_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000096_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000096_A); return ok }

func A_arbace_data_eval76000096_A_Cast(x any) *A_arbace_data_eval76000096_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000096_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000096_A_class)) }; return v }



type A_arbace_data_eval76000096_fn__76000097_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000096_fn__76000097_A_fn_class *jrt.Class



type A_arbace_data_eval76000101_A struct{ jrt.Object }

func A_arbace_data_eval76000101_A_New() *A_arbace_data_eval76000101_A { t := &A_arbace_data_eval76000101_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000101_A) Ctor() {}

func (t *A_arbace_data_eval76000101_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000101_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000101_A_class }

func (t *A_arbace_data_eval76000101_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000101_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000101_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000101_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000101_A); return ok }

func A_arbace_data_eval76000101_A_Cast(x any) *A_arbace_data_eval76000101_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000101_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000101_A_class)) }; return v }



type A_arbace_data_eval76000101_fn__76000102_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000101_fn__76000102_A_fn_class *jrt.Class



type A_arbace_data_eval76000105_A struct{ jrt.Object }

func A_arbace_data_eval76000105_A_New() *A_arbace_data_eval76000105_A { t := &A_arbace_data_eval76000105_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000105_A) Ctor() {}

func (t *A_arbace_data_eval76000105_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000105_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000105_A_class }

func (t *A_arbace_data_eval76000105_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000105_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000105_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000105_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000105_A); return ok }

func A_arbace_data_eval76000105_A_Cast(x any) *A_arbace_data_eval76000105_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000105_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000105_A_class)) }; return v }



type A_arbace_data_eval76000105_fn__76000106_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000105_fn__76000106_A_fn_class *jrt.Class



type A_arbace_data_eval76000109_A struct{ jrt.Object }

func A_arbace_data_eval76000109_A_New() *A_arbace_data_eval76000109_A { t := &A_arbace_data_eval76000109_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000109_A) Ctor() {}

func (t *A_arbace_data_eval76000109_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000109_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000109_A_class }

func (t *A_arbace_data_eval76000109_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000109_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000109_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000109_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000109_A); return ok }

func A_arbace_data_eval76000109_A_Cast(x any) *A_arbace_data_eval76000109_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000109_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000109_A_class)) }; return v }



type A_arbace_data_eval76000109_fn__76000110_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000109_fn__76000110_A_fn_class *jrt.Class



type A_arbace_data_vectorize_A struct{ j2g_header uint64 }

var A_arbace_data_vectorize_A_fn_class *jrt.Class



type A_arbace_data_vectorize_fn__76000016_A struct{ j2g_header uint64 }

var A_arbace_data_vectorize_fn__76000016_A_fn_class *jrt.Class
