//line aot_arbace_data.ae:1
package aot_arbace_data

import (
	"arbace/jrt"
	"arbace/lang"
)


func A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_New() *A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_data_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_data_A_const_2); tmp2 = lang.IFn_Cast(A_arbace_data_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_data_A_const_3); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_data_eval76000008_fn__76000009_A_New() *A_arbace_data_eval76000008_fn__76000009_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000008_fn__76000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_data_eval76000008_fn__76000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_data_eval76000008_fn__76000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_data_A_const_4.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_data_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_data_A_const_8), A_arbace_data_A_const_6.GetRawRoot__O(), A_arbace_data_A_const_7) }









func A_arbace_data_atom_diff_A_New() *A_arbace_data_atom_diff_A { A_arbace_data_A_Init(); t := &A_arbace_data_atom_diff_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_data_atom_diff_A) Ctor() {}
//line :19:1
func (t *A_arbace_data_atom_diff_A) Invoke_O_O_O__O(self, a__0, b__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(a__0, b__1) { return lang.Tuple_Create_O_O_O__IPersistentVector(nil, nil, a__0) } else { return lang.Tuple_Create_O_O_O__IPersistentVector(a__0, b__1, nil)
	}
}
func A_arbace_data_vectorize_A_New() *A_arbace_data_vectorize_A { A_arbace_data_A_Init(); t := &A_arbace_data_vectorize_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_data_vectorize_A) Ctor() {}
//line :25:1
func (t *A_arbace_data_vectorize_A) Invoke_O_O__O(self, m__0 any) any {



	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_data_A_const_9.GetRawRoot__O()).Invoke_O__O(m__0)) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data_A_const_10.GetRawRoot__O()); var tmp2 any = A_arbace_data_vectorize_fn__76000016_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_data_vectorize_fn__76000016_A_fn_class
		if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_data_vectorize_fn__76000016_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }
//line :30:1
		return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_data_A_const_12.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_data_A_const_13.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_data_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_data_A_const_15.GetRawRoot__O(), lang.IFn_Cast(A_arbace_data_A_const_16.GetRawRoot__O()).Invoke_O__O(m__0)), nil)), m__0) } else {
//line :29:1
			return nil
		} }
func A_arbace_data_vectorize_fn__76000016_A_New() *A_arbace_data_vectorize_fn__76000016_A { A_arbace_data_A_Init(); t := &A_arbace_data_vectorize_fn__76000016_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_data_vectorize_fn__76000016_A) Ctor() {}
//line :31:1
func (t *A_arbace_data_vectorize_fn__76000016_A) Invoke_O_O_O__O(self, result__1, p__76000015__2 any) any { var vec__76000017__3 any = p__76000015__2; var k__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__76000017__3, lang.RT_IntCast_J__I_NoInit(0), nil); var v__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__76000017__3, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.IFn_Cast(A_arbace_data_A_const_11.GetRawRoot__O()).Invoke_O_O_O__O(result__1, k__4, v__5) }



func A_arbace_data_diff_associative_key_A_New() *A_arbace_data_diff_associative_key_A { A_arbace_data_A_Init(); t := &A_arbace_data_diff_associative_key_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_data_diff_associative_key_A) Ctor() {}
//line :35:1
func (t *A_arbace_data_diff_associative_key_A) Invoke_O_O_O_O__O(self, a__0, b__1, k__2 any) any { var va__4 any = lang.RT_Get_O_O__O_NoInit(a__0, k__2); var vb__5 any = lang.RT_Get_O_O__O_NoInit(b__1, k__2); var vec__76000022__6 any = lang.IFn_Cast(A_arbace_data_A_const_17.GetRawRoot__O()).Invoke_O_O__O(va__4, vb__5); var a_STAR___7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__76000022__6, lang.RT_IntCast_J__I_NoInit(0), nil); var b_STAR___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__76000022__6, lang.RT_IntCast_J__I_NoInit(1), nil); var ab__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__76000022__6, lang.RT_IntCast_J__I_NoInit(2), nil); var in_a__10 any = lang.IFn_Cast(A_arbace_data_A_const_18.GetRawRoot__O()).Invoke_O_O__O(a__0, k__2); var in_b__11 any = lang.IFn_Cast(A_arbace_data_A_const_18.GetRawRoot__O()).Invoke_O_O__O(b__1, k__2); var same__12 any; var and__1927000168__auto____12 any = in_a__10; if







	jrt.J2g_Truth(and__1927000168__auto____12) { var and__1927000168__auto____13 any = in_b__11; if jrt.J2g_Truth(and__1927000168__auto____13) { var or__1927000174__auto____14 any = lang.IFn_Cast(A_arbace_data_A_const_19.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(ab__9, nil)).Ref())
		if jrt.J2g_Truth(or__1927000174__auto____14) { same__12 = or__1927000174__auto____14 } else { var and__1927000168__auto____15 bool = lang.Util_Identical_O_O__Z_NoInit(va__4, nil)
			if and__1927000168__auto____15 { same__12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(vb__5, nil)).Ref() } else { same__12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____15).Ref() } } } else {
//line :43:1
				same__12 = and__1927000168__auto____13 } } else { same__12 = and__1927000168__auto____12 }; var tmp1 lang.IPersistentMap; var tmp2 any; var and__1927000168__auto____13_2 any = in_a__10; if


	jrt.J2g_Truth(and__1927000168__auto____13_2) { var or__1927000174__auto____14_2 any = lang.IFn_Cast(A_arbace_data_A_const_19.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(a_STAR___7, nil)).Ref()); if jrt.J2g_Truth(or__1927000174__auto____14_2) { tmp2 = or__1927000174__auto____14_2 } else { tmp2 = lang.IFn_Cast(A_arbace_data_A_const_19.GetRawRoot__O()).Invoke_O__O(same__12) } } else { tmp2 = and__1927000168__auto____13_2 }; if jrt.J2g_Truth(tmp2) { tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, k__2, a_STAR___7)) } else { tmp1 = nil }; var tmp3 any = tmp1; var tmp4 lang.IPersistentMap; var tmp5 any; var and__1927000168__auto____13_3 any = in_b__11; if
	jrt.J2g_Truth(and__1927000168__auto____13_3) { var or__1927000174__auto____14_3 any = lang.IFn_Cast(A_arbace_data_A_const_19.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(b_STAR___8, nil)).Ref()); if jrt.J2g_Truth(or__1927000174__auto____14_3) { tmp5 = or__1927000174__auto____14_3 } else { tmp5 = lang.IFn_Cast(A_arbace_data_A_const_19.GetRawRoot__O()).Invoke_O__O(same__12) } } else { tmp5 = and__1927000168__auto____13_3 }; if jrt.J2g_Truth(tmp5) { tmp4 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, k__2, b_STAR___8)) } else { tmp4 = nil }; var tmp6 any = tmp4; var tmp7 lang.IPersistentMap; if
	jrt.J2g_Truth(same__12) { tmp7 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, k__2, ab__9)) } else { tmp7 = nil }; return /*line :35:1*/ lang.Tuple_Create_O_O_O__IPersistentVector(tmp3, tmp6, tmp7) }















func A_arbace_data_diff_associative_A_New() *A_arbace_data_diff_associative_A { A_arbace_data_A_Init(); t := &A_arbace_data_diff_associative_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_data_diff_associative_A) Ctor() {}
//line :51:1
func (t *A_arbace_data_diff_associative_A) Invoke_O_O_O_O__O(self, a__0, b__1, ks__2 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data_A_const_10.GetRawRoot__O()); var tmp2 any = A_arbace_data_diff_associative_fn__76000026_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_data_diff_associative_fn__76000026_A_fn_class
	if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_data_diff_associative_fn__76000026_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }
//line :54:1
	var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 any = A_arbace_data_A_const_23; return tmp1.Invoke_O_O_O__O(tmp4, tmp5, lang.IFn_Cast(A_arbace_data_A_const_21.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_data_A_const_24.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_data_A_const_25.GetRawRoot__O(), a__0, b__1), ks__2)) }
func A_arbace_data_diff_associative_fn__76000026_A_New() *A_arbace_data_diff_associative_fn__76000026_A { A_arbace_data_A_Init(); t := &A_arbace_data_diff_associative_fn__76000026_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_data_diff_associative_fn__76000026_A) Ctor() {}
//line :55:1
func (t *A_arbace_data_diff_associative_fn__76000026_A) Invoke_O_O_O__O(self, diff1__1, diff2__2 any) any {
	return lang.IFn_Cast(A_arbace_data_A_const_20.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_data_A_const_21.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_data_A_const_22.GetRawRoot__O(), diff1__1, diff2__2))
}




func A_arbace_data_diff_sequential_A_New() *A_arbace_data_diff_sequential_A { A_arbace_data_A_Init(); t := &A_arbace_data_diff_sequential_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_data_diff_sequential_A) Ctor() {}
//line :62:1
func (t *A_arbace_data_diff_sequential_A) Invoke_O_O_O__O(self, a__0, b__1 any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data_A_const_12.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_data_A_const_21.GetRawRoot__O()); var tmp3 any = A_arbace_data_A_const_26.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_data_A_const_27.GetRawRoot__O()); var tmp5 any
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_data_A_const_28.GetRawRoot__O()).Invoke_O__O(a__0)) { tmp5 = a__0 } else { tmp5 = lang.IFn_Cast(A_arbace_data_A_const_12.GetRawRoot__O()).Invoke_O__O(a__0) }
//line :64:1
	var tmp6 any = tmp5; var tmp7 any

	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_data_A_const_28.GetRawRoot__O()).Invoke_O__O(b__1)) { tmp7 = b__1 } else { tmp7 = lang.IFn_Cast(A_arbace_data_A_const_12.GetRawRoot__O()).Invoke_O__O(b__1) }
//line :64:1
	return tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O__O(tmp6, tmp7, lang.IFn_Cast(A_arbace_data_A_const_29.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Max_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(a__0)), int64(lang.RT_Count_O__I_NoInit(b__1)))).Ref()))))
}



func A_arbace_data_eval76000038_fn__76000039_A_New() *A_arbace_data_eval76000038_fn__76000039_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000038_fn__76000039_A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_data_eval76000038_fn__76000039_A) Ctor() {}
//line :69:1
func (t *A_arbace_data_eval76000038_fn__76000039_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__76000031__2_ any; var tmp1 any = A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_New(); var tmp2 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_fn_class = fncls__4d; tmp2 = fncls__4d } else { tmp2 = fncls__4 }; G__76000031__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_New_O(G__76000031__2_); var tmp4 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_fn_class = fncls__5d; tmp4 = fncls__5d } else { tmp4 = fncls__5 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :69:1
func A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_New_O(p0 any) *A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A{}; t.Ctor_O(p0); return t }
//line :69:1
func (t *A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A) Ctor_O(c__G__76000031 any) { t.F_G__76000031 = c__G__76000031 }
//line :69:1
func (t *A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A) Invoke_O_O__O(self, gf__x__76000043__1 any) any { var cache__231000236__auto____2 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____3 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____2)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__x__76000043__1)); if jrt.J2g_Truth(f__231000237__auto____3) { return lang.IFn_Cast(f__231000237__auto____3).Invoke_O__O(gf__x__76000043__1) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_data_A_const_30.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__x__76000043__1, A_arbace_data_A_const_31, t.F_G__76000031)).Invoke_O__O(gf__x__76000043__1) } }
//line :69:1
func A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_New() *A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A) Ctor() {}
//line :69:1
func (t *A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A) Invoke_O_O__O(self, gf__x__76000040__1 any) any { var target_3 any = gf__x__76000040__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_3 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_3) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_3, Lit_4, jrt.RefArrayOf(jrt.Object_class)) } else { return A_arbace_data_EqualityPartition_A_Cast(target_3).Equality_partition__O() } }



func A_arbace_data_eval76000060_fn__76000061_A_New() *A_arbace_data_eval76000060_fn__76000061_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000060_fn__76000061_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_data_eval76000060_fn__76000061_A) Ctor() {}
//line :73:1
func (t *A_arbace_data_eval76000060_fn__76000061_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__76000053__2_ any; var tmp1 any = A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_New(); var tmp2 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_fn_class = fncls__7d; tmp2 = fncls__7d } else { tmp2 = fncls__7 }; G__76000053__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_New_O(G__76000053__2_); var tmp4 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_fn_class = fncls__8d; tmp4 = fncls__8d } else { tmp4 = fncls__8 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :73:1
func A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_New_O(p0 any) *A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A{}; t.Ctor_O(p0); return t }
//line :73:1
func (t *A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A) Ctor_O(c__G__76000053 any) { t.F_G__76000053 = c__G__76000053 }
//line :73:1
func (t *A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A) Invoke_O_O_O__O(self, gf__a__76000066__1, gf__b__76000067__2 any) any { var cache__231000236__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__a__76000066__1)); if jrt.J2g_Truth(f__231000237__auto____4) { return lang.IFn_Cast(f__231000237__auto____4).Invoke_O_O__O(gf__a__76000066__1, gf__b__76000067__2) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_data_A_const_30.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__a__76000066__1, A_arbace_data_A_const_32, t.F_G__76000053)).Invoke_O_O__O(gf__a__76000066__1, gf__b__76000067__2) } }
//line :73:1
func A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_New() *A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A) Ctor() {}
//line :73:1
func (t *A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A) Invoke_O_O_O__O(self, gf__a__76000062__1, gf__b__76000063__2 any) any { var target_6 any = gf__a__76000062__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_6 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_6) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_6, Lit_7, jrt.RefArrayOf(jrt.Object_class, gf__b__76000063__2)) } else { return A_arbace_data_Diff_A_Cast(target_6).Diff_similar_O__O(gf__b__76000063__2) } }









func A_arbace_data_eval76000078_fn__76000079_A_New() *A_arbace_data_eval76000078_fn__76000079_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000078_fn__76000079_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_data_eval76000078_fn__76000079_A) Ctor() {}
//line :83:1
func (t *A_arbace_data_eval76000078_fn__76000079_A) Invoke_O_O_O__O(self, a__1, b__2 any) any {
	var tmp1 any; if jrt.NN(jrt.GetClass(a__1)).IsArray__Z() { tmp1 = A_arbace_data_A_const_33.GetRawRoot__O() } else { tmp1 = A_arbace_data_A_const_34.GetRawRoot__O() }; return lang.IFn_Cast(tmp1).Invoke_O_O__O(a__1, b__2)
}
func A_arbace_data_eval76000078_fn__76000081_A_New() *A_arbace_data_eval76000078_fn__76000081_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000078_fn__76000081_A{}; t.Ctor(); return t }
//line :86:1
func (t *A_arbace_data_eval76000078_fn__76000081_A) Ctor() {}
//line :86:1
func (t *A_arbace_data_eval76000078_fn__76000081_A) Invoke_O_O__O(self, x__1 any) any {
	if jrt.NN(jrt.GetClass(x__1)).IsArray__Z() { return A_arbace_data_A_const_35 } else { return A_arbace_data_A_const_36
	} }
func A_arbace_data_eval76000084_fn__76000085_A_New() *A_arbace_data_eval76000084_fn__76000085_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000084_fn__76000085_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_data_eval76000084_fn__76000085_A) Ctor() {}
//line :89:1
func (t *A_arbace_data_eval76000084_fn__76000085_A) Invoke_O_O__O(self, x__1 any) any { return A_arbace_data_A_const_36 }
//line :89:1
func A_arbace_data_eval76000088_fn__76000089_A_New() *A_arbace_data_eval76000088_fn__76000089_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000088_fn__76000089_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_data_eval76000088_fn__76000089_A) Ctor() {}
//line :89:1
func (t *A_arbace_data_eval76000088_fn__76000089_A) Invoke_O_O__O(self, x__1 any) any { return A_arbace_data_A_const_37 }
//line :89:1
func A_arbace_data_eval76000092_fn__76000093_A_New() *A_arbace_data_eval76000092_fn__76000093_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000092_fn__76000093_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_data_eval76000092_fn__76000093_A) Ctor() {}
//line :89:1
func (t *A_arbace_data_eval76000092_fn__76000093_A) Invoke_O_O__O(self, x__1 any) any { return A_arbace_data_A_const_35 }
//line :89:1
func A_arbace_data_eval76000096_fn__76000097_A_New() *A_arbace_data_eval76000096_fn__76000097_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000096_fn__76000097_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_data_eval76000096_fn__76000097_A) Ctor() {}
//line :89:1
func (t *A_arbace_data_eval76000096_fn__76000097_A) Invoke_O_O__O(self, x__1 any) any { return A_arbace_data_A_const_38 }












func A_arbace_data_as_set_value_A_New() *A_arbace_data_as_set_value_A { A_arbace_data_A_Init(); t := &A_arbace_data_as_set_value_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_data_as_set_value_A) Ctor() {}
//line :102:1
func (t *A_arbace_data_as_set_value_A) Invoke_O_O__O(self, s__0 any) any {

	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_data_A_const_39.GetRawRoot__O()).Invoke_O__O(s__0)) { return s__0 } else { return lang.IFn_Cast(A_arbace_data_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.PersistentHashSet_EMPTY.Ref(), s__0)
	} }
func A_arbace_data_eval76000101_fn__76000102_A_New() *A_arbace_data_eval76000101_fn__76000102_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000101_fn__76000102_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_data_eval76000101_fn__76000102_A) Ctor() {}
//line :106:1
func (t *A_arbace_data_eval76000101_fn__76000102_A) Invoke_O_O_O__O(self, a__1, b__2 any) any { var aval__3 any = lang.IFn_Cast(A_arbace_data_A_const_41.GetRawRoot__O()).Invoke_O__O(a__1); var bval__4 any = lang.IFn_Cast(A_arbace_data_A_const_41.GetRawRoot__O()).Invoke_O__O(b__2); return lang.Tuple_Create_O_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_data_A_const_42.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_data_A_const_43.GetRawRoot__O()).Invoke_O_O__O(aval__3, bval__4)), lang.IFn_Cast(A_arbace_data_A_const_42.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_data_A_const_43.GetRawRoot__O()).Invoke_O_O__O(bval__4, aval__3)), lang.IFn_Cast(A_arbace_data_A_const_42.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_data_A_const_44.GetRawRoot__O()).Invoke_O_O__O(aval__3, bval__4))) }
//line :106:1
func A_arbace_data_eval76000105_fn__76000106_A_New() *A_arbace_data_eval76000105_fn__76000106_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000105_fn__76000106_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_data_eval76000105_fn__76000106_A) Ctor() {}
//line :106:1
func (t *A_arbace_data_eval76000105_fn__76000106_A) Invoke_O_O_O__O(self, a__1, b__2 any) any {











	return lang.IFn_Cast(A_arbace_data_A_const_33.GetRawRoot__O()).Invoke_O_O__O(a__1, b__2) }
//line :106:1
func A_arbace_data_eval76000109_fn__76000110_A_New() *A_arbace_data_eval76000109_fn__76000110_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000109_fn__76000110_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_data_eval76000109_fn__76000110_A) Ctor() {}
//line :106:1
func (t *A_arbace_data_eval76000109_fn__76000110_A) Invoke_O_O_O__O(self, a__1, b__2 any) any {















	return lang.IFn_Cast(A_arbace_data_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(a__1, b__2, lang.IFn_Cast(A_arbace_data_A_const_45.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_data_A_const_16.GetRawRoot__O()).Invoke_O__O(a__1), lang.IFn_Cast(A_arbace_data_A_const_16.GetRawRoot__O()).Invoke_O__O(b__2)))
}
func A_arbace_data_diff_A_New() *A_arbace_data_diff_A { A_arbace_data_A_Init(); t := &A_arbace_data_diff_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_data_diff_A) Ctor() {}
//line :124:1
func (t *A_arbace_data_diff_A) Invoke_O_O_O__O(self, a__0, b__1 any) any {













	if lang.Util_Equiv_O_O__Z_NoInit(a__0, b__1) { return lang.Tuple_Create_O_O_O__IPersistentVector(nil, nil, a__0) } else {

		var tmp1 any; var target_9 any = a__0; var tmp2 bool; var tmp3 bool; tmp3 = A_arbace_data_EqualityPartition_A_InstanceOf(target_9); if tmp3 { tmp3 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_9) }; tmp2 = tmp3; if tmp2 { tmp1 = A_arbace_data_EqualityPartition_A_Cast(target_9).Equality_partition__O() } else { tmp1 = lang.IFn_Cast(A_arbace_data_A_const_46.GetRawRoot__O()).Invoke_O__O(target_9) }; var tmp4 any = tmp1; var tmp5 any; var target_10 any = b__1; var tmp6 bool; var tmp7 bool; tmp7 = A_arbace_data_EqualityPartition_A_InstanceOf(target_10); if tmp7 { tmp7 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_10) }; tmp6 = tmp7; if tmp6 { tmp5 = A_arbace_data_EqualityPartition_A_Cast(target_10).Equality_partition__O() } else { tmp5 = lang.IFn_Cast(A_arbace_data_A_const_46.GetRawRoot__O()).Invoke_O__O(target_10) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5) {
			var target_11 any = a__0; var tmp8 bool; var tmp9 bool; tmp9 = A_arbace_data_Diff_A_InstanceOf(target_11); if tmp9 { tmp9 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_11) }; tmp8 = tmp9; if tmp8 { return A_arbace_data_Diff_A_Cast(target_11).Diff_similar_O__O(b__1) } else { return lang.IFn_Cast(A_arbace_data_A_const_47.GetRawRoot__O()).Invoke_O_O__O(target_11, b__1) } } else {
				return lang.IFn_Cast(A_arbace_data_A_const_34.GetRawRoot__O()).Invoke_O_O__O(a__0, b__1)
			}
	}
}



























type A_arbace_data_A struct{ jrt.Object }

var A_arbace_data_A_const_pool *jrt.RefArray

var A_arbace_data_A_const_0 *lang.Var

var A_arbace_data_A_const_1 *lang.Var

var A_arbace_data_A_const_2 any

var A_arbace_data_A_const_3 any

var A_arbace_data_A_const_4 *lang.Var

var A_arbace_data_A_const_5 *lang.Var

var A_arbace_data_A_const_6 *lang.Var

var A_arbace_data_A_const_7 any

var A_arbace_data_A_const_8 *lang.Var

var A_arbace_data_A_const_9 *lang.Var

var A_arbace_data_A_const_10 *lang.Var

var A_arbace_data_A_const_11 *lang.Var

var A_arbace_data_A_const_12 *lang.Var

var A_arbace_data_A_const_13 *lang.Var

var A_arbace_data_A_const_14 *lang.Var

var A_arbace_data_A_const_15 *lang.Var

var A_arbace_data_A_const_16 *lang.Var

var A_arbace_data_A_const_17 *lang.Var

var A_arbace_data_A_const_18 *lang.Var

var A_arbace_data_A_const_19 *lang.Var

var A_arbace_data_A_const_20 *lang.Var

var A_arbace_data_A_const_21 *lang.Var

var A_arbace_data_A_const_22 *lang.Var

var A_arbace_data_A_const_23 any

var A_arbace_data_A_const_24 *lang.Var

var A_arbace_data_A_const_25 *lang.Var

var A_arbace_data_A_const_26 *lang.Var

var A_arbace_data_A_const_27 *lang.Var

var A_arbace_data_A_const_28 *lang.Var

var A_arbace_data_A_const_29 *lang.Var

var A_arbace_data_A_const_30 *lang.Var

var A_arbace_data_A_const_31 *jrt.Class

var A_arbace_data_A_const_32 *jrt.Class

var A_arbace_data_A_const_33 *lang.Var

var A_arbace_data_A_const_34 *lang.Var

var A_arbace_data_A_const_35 *lang.Keyword

var A_arbace_data_A_const_36 *lang.Keyword

var A_arbace_data_A_const_37 *lang.Keyword

var A_arbace_data_A_const_38 *lang.Keyword

var A_arbace_data_A_const_39 *lang.Var

var A_arbace_data_A_const_40 *lang.Var

var A_arbace_data_A_const_41 *lang.Var

var A_arbace_data_A_const_42 *lang.Var

var A_arbace_data_A_const_43 *lang.Var

var A_arbace_data_A_const_44 *lang.Var

var A_arbace_data_A_const_45 *lang.Var

var A_arbace_data_A_const_46 *lang.Var

var A_arbace_data_A_const_47 *lang.Var

var A_arbace_data_A_init jrt.ClassInit

func A_arbace_data_A_Init() { if !A_arbace_data_A_init.Done() { A_arbace_data_A_init.Run(A_arbace_data_A_clinit) } }

func A_arbace_data_A_clinit() { A_arbace_data_A_clinit_p0(); A_arbace_data_A_clinit_p1(); A_arbace_data_A_clinit_p2(); A_arbace_data_A_clinit_p3() }

func A_arbace_data_A_clinit_p0() { jrt.StartCheck(); A_arbace_data_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 58); A_arbace_data_A_const_0 = lang.Var_Cast(A_arbace_data_A_const_pool.A[10]); A_arbace_data_A_const_1 = lang.Var_Cast(A_arbace_data_A_const_pool.A[11]); A_arbace_data_A_const_2 = A_arbace_data_A_const_pool.A[12]; A_arbace_data_A_const_3 = A_arbace_data_A_const_pool.A[13]; A_arbace_data_A_const_4 = lang.Var_Cast(A_arbace_data_A_const_pool.A[14]); A_arbace_data_A_const_5 = lang.Var_Cast(A_arbace_data_A_const_pool.A[15]); A_arbace_data_A_const_6 = lang.Var_Cast(A_arbace_data_A_const_pool.A[16]); A_arbace_data_A_const_7 = A_arbace_data_A_const_pool.A[17]; A_arbace_data_A_const_8 = lang.Var_Cast(A_arbace_data_A_const_pool.A[18]); A_arbace_data_A_const_9 = lang.Var_Cast(A_arbace_data_A_const_pool.A[19]); A_arbace_data_A_const_10 = lang.Var_Cast(A_arbace_data_A_const_pool.A[20]); A_arbace_data_A_const_11 = lang.Var_Cast(A_arbace_data_A_const_pool.A[21]) }

func A_arbace_data_A_clinit_p1() { A_arbace_data_A_const_12 = lang.Var_Cast(A_arbace_data_A_const_pool.A[22]); A_arbace_data_A_const_13 = lang.Var_Cast(A_arbace_data_A_const_pool.A[23]); A_arbace_data_A_const_14 = lang.Var_Cast(A_arbace_data_A_const_pool.A[24]); A_arbace_data_A_const_15 = lang.Var_Cast(A_arbace_data_A_const_pool.A[25]); A_arbace_data_A_const_16 = lang.Var_Cast(A_arbace_data_A_const_pool.A[26]); A_arbace_data_A_const_17 = lang.Var_Cast(A_arbace_data_A_const_pool.A[27]); A_arbace_data_A_const_18 = lang.Var_Cast(A_arbace_data_A_const_pool.A[28]); A_arbace_data_A_const_19 = lang.Var_Cast(A_arbace_data_A_const_pool.A[29]); A_arbace_data_A_const_20 = lang.Var_Cast(A_arbace_data_A_const_pool.A[30]); A_arbace_data_A_const_21 = lang.Var_Cast(A_arbace_data_A_const_pool.A[31]); A_arbace_data_A_const_22 = lang.Var_Cast(A_arbace_data_A_const_pool.A[32]); A_arbace_data_A_const_23 = A_arbace_data_A_const_pool.A[33] }

func A_arbace_data_A_clinit_p2() { A_arbace_data_A_const_24 = lang.Var_Cast(A_arbace_data_A_const_pool.A[34]); A_arbace_data_A_const_25 = lang.Var_Cast(A_arbace_data_A_const_pool.A[35]); A_arbace_data_A_const_26 = lang.Var_Cast(A_arbace_data_A_const_pool.A[36]); A_arbace_data_A_const_27 = lang.Var_Cast(A_arbace_data_A_const_pool.A[37]); A_arbace_data_A_const_28 = lang.Var_Cast(A_arbace_data_A_const_pool.A[38]); A_arbace_data_A_const_29 = lang.Var_Cast(A_arbace_data_A_const_pool.A[39]); A_arbace_data_A_const_30 = lang.Var_Cast(A_arbace_data_A_const_pool.A[40]); A_arbace_data_A_const_31 = jrt.Class_Cast(A_arbace_data_A_const_pool.A[41]); A_arbace_data_A_const_32 = jrt.Class_Cast(A_arbace_data_A_const_pool.A[42]); A_arbace_data_A_const_33 = lang.Var_Cast(A_arbace_data_A_const_pool.A[43]); A_arbace_data_A_const_34 = lang.Var_Cast(A_arbace_data_A_const_pool.A[44]); A_arbace_data_A_const_35 = lang.Keyword_Cast(A_arbace_data_A_const_pool.A[45]) }

func A_arbace_data_A_clinit_p3() { A_arbace_data_A_const_36 = lang.Keyword_Cast(A_arbace_data_A_const_pool.A[46]); A_arbace_data_A_const_37 = lang.Keyword_Cast(A_arbace_data_A_const_pool.A[47]); A_arbace_data_A_const_38 = lang.Keyword_Cast(A_arbace_data_A_const_pool.A[48]); A_arbace_data_A_const_39 = lang.Var_Cast(A_arbace_data_A_const_pool.A[49]); A_arbace_data_A_const_40 = lang.Var_Cast(A_arbace_data_A_const_pool.A[50]); A_arbace_data_A_const_41 = lang.Var_Cast(A_arbace_data_A_const_pool.A[51]); A_arbace_data_A_const_42 = lang.Var_Cast(A_arbace_data_A_const_pool.A[52]); A_arbace_data_A_const_43 = lang.Var_Cast(A_arbace_data_A_const_pool.A[53]); A_arbace_data_A_const_44 = lang.Var_Cast(A_arbace_data_A_const_pool.A[54]); A_arbace_data_A_const_45 = lang.Var_Cast(A_arbace_data_A_const_pool.A[55]); A_arbace_data_A_const_46 = lang.Var_Cast(A_arbace_data_A_const_pool.A[56]); A_arbace_data_A_const_47 = lang.Var_Cast(A_arbace_data_A_const_pool.A[57]) }

func A_arbace_data_A_New() *A_arbace_data_A { A_arbace_data_A_Init(); t := &A_arbace_data_A{}; t.Ctor(); return t }

func (t *A_arbace_data_A) Ctor() {}

func (t *A_arbace_data_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_A) GetClass__Class() *jrt.Class { return A_arbace_data_A_class }

func (t *A_arbace_data_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_A); return ok }

func A_arbace_data_A_Cast(x any) *A_arbace_data_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_A_class)) }; return v }



type A_arbace_data_as_set_value_A struct{ j2g_header uint64 }

var A_arbace_data_as_set_value_A_fn_class *jrt.Class



type A_arbace_data_atom_diff_A struct{ j2g_header uint64 }

var A_arbace_data_atom_diff_A_fn_class *jrt.Class



type A_arbace_data_diff_A struct{ j2g_header uint64 }

var A_arbace_data_diff_A_fn_class *jrt.Class



type A_arbace_data_diff_associative_A struct{ j2g_header uint64 }

var A_arbace_data_diff_associative_A_fn_class *jrt.Class



type A_arbace_data_diff_associative_fn__76000026_A struct{ j2g_header uint64 }

var A_arbace_data_diff_associative_fn__76000026_A_fn_class *jrt.Class



type A_arbace_data_diff_associative_key_A struct{ j2g_header uint64 }

var A_arbace_data_diff_associative_key_A_fn_class *jrt.Class



type A_arbace_data_diff_sequential_A struct{ j2g_header uint64 }

var A_arbace_data_diff_sequential_A_fn_class *jrt.Class



type A_arbace_data_eval76000004_A struct{ jrt.Object }

func A_arbace_data_eval76000004_A_New() *A_arbace_data_eval76000004_A { t := &A_arbace_data_eval76000004_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000004_A) Ctor() {}

func (t *A_arbace_data_eval76000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000004_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000004_A_class }

func (t *A_arbace_data_eval76000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000004_A); return ok }

func A_arbace_data_eval76000004_A_Cast(x any) *A_arbace_data_eval76000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000004_A_class)) }; return v }



type A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_fn_class *jrt.Class



type A_arbace_data_eval76000008_A struct{ jrt.Object }

func A_arbace_data_eval76000008_A_New() *A_arbace_data_eval76000008_A { t := &A_arbace_data_eval76000008_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000008_A) Ctor() {}

func (t *A_arbace_data_eval76000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000008_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000008_A_class }

func (t *A_arbace_data_eval76000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000008_A); return ok }

func A_arbace_data_eval76000008_A_Cast(x any) *A_arbace_data_eval76000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000008_A_class)) }; return v }



type A_arbace_data_eval76000008_fn__76000009_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000008_fn__76000009_A_fn_class *jrt.Class



type A_arbace_data_eval76000038_A struct{ jrt.Object }

func A_arbace_data_eval76000038_A_New() *A_arbace_data_eval76000038_A { t := &A_arbace_data_eval76000038_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000038_A) Ctor() {}

func (t *A_arbace_data_eval76000038_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000038_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000038_A_class }

func (t *A_arbace_data_eval76000038_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000038_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000038_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000038_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000038_A); return ok }

func A_arbace_data_eval76000038_A_Cast(x any) *A_arbace_data_eval76000038_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000038_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000038_A_class)) }; return v }



type A_arbace_data_eval76000038_fn__76000039_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000038_fn__76000039_A_fn_class *jrt.Class



type A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A struct{ j2g_header uint64; F_G__76000031 any }

var A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_fn_class *jrt.Class



type A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_fn_class *jrt.Class



type A_arbace_data_eval76000060_A struct{ jrt.Object }

func A_arbace_data_eval76000060_A_New() *A_arbace_data_eval76000060_A { t := &A_arbace_data_eval76000060_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000060_A) Ctor() {}

func (t *A_arbace_data_eval76000060_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000060_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000060_A_class }

func (t *A_arbace_data_eval76000060_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000060_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000060_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000060_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000060_A); return ok }

func A_arbace_data_eval76000060_A_Cast(x any) *A_arbace_data_eval76000060_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000060_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000060_A_class)) }; return v }



type A_arbace_data_eval76000060_fn__76000061_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000060_fn__76000061_A_fn_class *jrt.Class



type A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A struct{ j2g_header uint64; F_G__76000053 any }

var A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_fn_class *jrt.Class



type A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_fn_class *jrt.Class



type A_arbace_data_eval76000078_A struct{ jrt.Object }

func A_arbace_data_eval76000078_A_New() *A_arbace_data_eval76000078_A { t := &A_arbace_data_eval76000078_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000078_A) Ctor() {}

func (t *A_arbace_data_eval76000078_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000078_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000078_A_class }

func (t *A_arbace_data_eval76000078_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000078_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000078_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000078_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000078_A); return ok }

func A_arbace_data_eval76000078_A_Cast(x any) *A_arbace_data_eval76000078_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000078_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000078_A_class)) }; return v }



type A_arbace_data_eval76000078_fn__76000079_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000078_fn__76000079_A_fn_class *jrt.Class



type A_arbace_data_eval76000078_fn__76000081_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000078_fn__76000081_A_fn_class *jrt.Class



type A_arbace_data_eval76000084_A struct{ jrt.Object }

func A_arbace_data_eval76000084_A_New() *A_arbace_data_eval76000084_A { t := &A_arbace_data_eval76000084_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000084_A) Ctor() {}

func (t *A_arbace_data_eval76000084_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000084_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000084_A_class }

func (t *A_arbace_data_eval76000084_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000084_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000084_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000084_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000084_A); return ok }

func A_arbace_data_eval76000084_A_Cast(x any) *A_arbace_data_eval76000084_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000084_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000084_A_class)) }; return v }



type A_arbace_data_eval76000084_fn__76000085_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000084_fn__76000085_A_fn_class *jrt.Class



type A_arbace_data_eval76000088_A struct{ jrt.Object }

func A_arbace_data_eval76000088_A_New() *A_arbace_data_eval76000088_A { t := &A_arbace_data_eval76000088_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000088_A) Ctor() {}

func (t *A_arbace_data_eval76000088_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000088_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000088_A_class }

func (t *A_arbace_data_eval76000088_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000088_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000088_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000088_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000088_A); return ok }

func A_arbace_data_eval76000088_A_Cast(x any) *A_arbace_data_eval76000088_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000088_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000088_A_class)) }; return v }



type A_arbace_data_eval76000088_fn__76000089_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000088_fn__76000089_A_fn_class *jrt.Class



type A_arbace_data_eval76000092_A struct{ jrt.Object }

func A_arbace_data_eval76000092_A_New() *A_arbace_data_eval76000092_A { t := &A_arbace_data_eval76000092_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000092_A) Ctor() {}

func (t *A_arbace_data_eval76000092_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000092_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000092_A_class }

func (t *A_arbace_data_eval76000092_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000092_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000092_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000092_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000092_A); return ok }

func A_arbace_data_eval76000092_A_Cast(x any) *A_arbace_data_eval76000092_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000092_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000092_A_class)) }; return v }



type A_arbace_data_eval76000092_fn__76000093_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000092_fn__76000093_A_fn_class *jrt.Class



type A_arbace_data_eval76000096_A struct{ jrt.Object }

func A_arbace_data_eval76000096_A_New() *A_arbace_data_eval76000096_A { t := &A_arbace_data_eval76000096_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000096_A) Ctor() {}

func (t *A_arbace_data_eval76000096_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000096_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000096_A_class }

func (t *A_arbace_data_eval76000096_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000096_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000096_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000096_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000096_A); return ok }

func A_arbace_data_eval76000096_A_Cast(x any) *A_arbace_data_eval76000096_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000096_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000096_A_class)) }; return v }



type A_arbace_data_eval76000096_fn__76000097_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000096_fn__76000097_A_fn_class *jrt.Class



type A_arbace_data_eval76000101_A struct{ jrt.Object }

func A_arbace_data_eval76000101_A_New() *A_arbace_data_eval76000101_A { t := &A_arbace_data_eval76000101_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000101_A) Ctor() {}

func (t *A_arbace_data_eval76000101_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000101_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000101_A_class }

func (t *A_arbace_data_eval76000101_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000101_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000101_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000101_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000101_A); return ok }

func A_arbace_data_eval76000101_A_Cast(x any) *A_arbace_data_eval76000101_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000101_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000101_A_class)) }; return v }



type A_arbace_data_eval76000101_fn__76000102_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000101_fn__76000102_A_fn_class *jrt.Class



type A_arbace_data_eval76000105_A struct{ jrt.Object }

func A_arbace_data_eval76000105_A_New() *A_arbace_data_eval76000105_A { t := &A_arbace_data_eval76000105_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000105_A) Ctor() {}

func (t *A_arbace_data_eval76000105_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000105_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000105_A_class }

func (t *A_arbace_data_eval76000105_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000105_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000105_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000105_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000105_A); return ok }

func A_arbace_data_eval76000105_A_Cast(x any) *A_arbace_data_eval76000105_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000105_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000105_A_class)) }; return v }



type A_arbace_data_eval76000105_fn__76000106_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000105_fn__76000106_A_fn_class *jrt.Class



type A_arbace_data_eval76000109_A struct{ jrt.Object }

func A_arbace_data_eval76000109_A_New() *A_arbace_data_eval76000109_A { t := &A_arbace_data_eval76000109_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000109_A) Ctor() {}

func (t *A_arbace_data_eval76000109_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000109_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000109_A_class }

func (t *A_arbace_data_eval76000109_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000109_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000109_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000109_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000109_A); return ok }

func A_arbace_data_eval76000109_A_Cast(x any) *A_arbace_data_eval76000109_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000109_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000109_A_class)) }; return v }



type A_arbace_data_eval76000109_fn__76000110_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000109_fn__76000110_A_fn_class *jrt.Class



type A_arbace_data_vectorize_A struct{ j2g_header uint64 }

var A_arbace_data_vectorize_A_fn_class *jrt.Class



type A_arbace_data_vectorize_fn__76000016_A struct{ j2g_header uint64 }

var A_arbace_data_vectorize_fn__76000016_A_fn_class *jrt.Class
