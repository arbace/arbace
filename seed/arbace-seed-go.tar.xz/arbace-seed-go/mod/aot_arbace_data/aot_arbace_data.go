//line aot_arbace_data.ae:1
package aot_arbace_data

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_set"
	"arbace/jrt"
	"arbace/lang"
)
func A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_New() *A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_data_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_data_A_const_3); tmp2 = lang.IFn_Cast(A_arbace_data_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_data_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_data_eval76000008_fn__76000009_A_New() *A_arbace_data_eval76000008_fn__76000009_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000008_fn__76000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_data_eval76000008_fn__76000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_data_eval76000008_fn__76000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data_A_const_4.GetRawRoot__O()); var tmp2 any; var root_9 any = A_arbace_data_A_const_5.GetRawRoot__O(); var linked_10 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_9, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_11 lang.IFn; if linked_10 == nil { ifn_11 = lang.IFn_Cast(root_9) } else { ifn_11 = nil }; var arg_12 any = A_arbace_data_A_const_6; if linked_10 == nil { tmp2 = ifn_11.Invoke_O__O(arg_12) } else { tmp2 = linked_10.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_9, arg_12) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_data_A_const_7.GetRawRoot__O(), A_arbace_data_A_const_8) }









func A_arbace_data_atom_diff_A_New() *A_arbace_data_atom_diff_A { A_arbace_data_A_Init(); t := &A_arbace_data_atom_diff_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_data_atom_diff_A) Ctor() {}
//line :19:1
func (t *A_arbace_data_atom_diff_A) Invoke_O_O_O__O(self, a__0, b__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(a__0, b__1) { return lang.Tuple_Create_O_O_O__IPersistentVector(nil, nil, a__0) } else { return lang.Tuple_Create_O_O_O__IPersistentVector(a__0, b__1, nil)
	}
}
func A_arbace_data_vectorize_A_New() *A_arbace_data_vectorize_A { A_arbace_data_A_Init(); t := &A_arbace_data_vectorize_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_data_vectorize_A) Ctor() {}
//line :25:1
func (t *A_arbace_data_vectorize_A) Invoke_O_O__O(self, m__0 any) any {



	var tmp1 any; var root_19 any = A_arbace_data_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = m__0; if linked_20 == nil { tmp1 = ifn_21.Invoke_O__O(arg_22) } else { tmp1 = linked_20.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_19, arg_22) }; if jrt.J2g_Truth(tmp1) {
		var root_48 any = A_arbace_data_A_const_10.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_50 lang.IFn; if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any; var tmp2 any = A_arbace_data_vectorize_fn__76000016_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_data_vectorize_fn__76000016_A_fn_class
		if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_data_vectorize_fn__76000016_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; arg_51 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)
//line :30:1
		var arg_52 any; var root_44 any = A_arbace_data_A_const_12.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_44, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_46 lang.IFn

		if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any; var root_39 any = A_arbace_data_A_const_13.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any; var root_34 any = A_arbace_data_A_const_14.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any = A_arbace_data_A_const_15.GetRawRoot__O(); var arg_38 any; var root_30 any = A_arbace_data_A_const_16.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_32 lang.IFn; if linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any = m__0; if linked_31 == nil { arg_38 = ifn_32.Invoke_O__O(arg_33) } else { arg_38 = linked_31.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_30, arg_33) }; if linked_35 == nil { arg_42 = ifn_36.Invoke_O_O__O(arg_37, arg_38) } else { arg_42 = linked_35.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_34, arg_37, arg_38) }; var arg_43 any; if linked_40 == nil { arg_47 = ifn_41.Invoke_O_O__O(arg_42, arg_43) } else { arg_47 = linked_40.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O_O__O(root_39, arg_42, arg_43) }; if linked_45 == nil { arg_52 = ifn_46.Invoke_O__O(arg_47) } else { arg_52 = linked_45.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_44, arg_47) }
//line :30:1
		var arg_53 any = m__0; if linked_49 == nil { return ifn_50.Invoke_O_O_O__O(arg_51, arg_52, arg_53) } else { return linked_49.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_48, arg_51, arg_52, arg_53) } } else {
//line :29:1
			return nil
		} }
func A_arbace_data_vectorize_fn__76000016_A_New() *A_arbace_data_vectorize_fn__76000016_A { A_arbace_data_A_Init(); t := &A_arbace_data_vectorize_fn__76000016_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_data_vectorize_fn__76000016_A) Ctor() {}
//line :31:1
func (t *A_arbace_data_vectorize_fn__76000016_A) Invoke_O_O_O__O(self, result__1, p__76000015__2 any) any { var vec__76000017__3 any = p__76000015__2; var k__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__76000017__3, lang.RT_IntCast_J__I_NoInit(0), nil); var v__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__76000017__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_23 any = A_arbace_data_A_const_11.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_23, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_25 lang.IFn; if linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = result__1; var arg_27 any = k__4; var arg_28 any = v__5; if linked_24 == nil { return ifn_25.Invoke_O_O_O__O(arg_26, arg_27, arg_28) } else { return linked_24.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_23, arg_26, arg_27, arg_28) } }



func A_arbace_data_diff_associative_key_A_New() *A_arbace_data_diff_associative_key_A { A_arbace_data_A_Init(); t := &A_arbace_data_diff_associative_key_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_data_diff_associative_key_A) Ctor() {}
//line :35:1
func (t *A_arbace_data_diff_associative_key_A) Invoke_O_O_O_O__O(self, a__0, b__1, k__2 any) any { var va__4 any = lang.RT_Get_O_O__O_NoInit(a__0, k__2); var vb__5 any = lang.RT_Get_O_O__O_NoInit(b__1, k__2); var vec__76000022__6 any; var root_54 any = A_arbace_data_A_const_17.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, A_arbace_data_diff_A_fn_class); var ifn_56 lang.IFn; if




	linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = va__4; var arg_58 any = vb__5; if linked_55 == nil { vec__76000022__6 = ifn_56.Invoke_O_O__O(arg_57, arg_58) } else { vec__76000022__6 = linked_55.(*A_arbace_data_diff_A).Invoke_O_O_O__O(root_54, arg_57, arg_58) }; var a_STAR___7 any = /*line :35:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__76000022__6, lang.RT_IntCast_J__I_NoInit(0), nil); var b_STAR___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__76000022__6, lang.RT_IntCast_J__I_NoInit(1), nil); var ab__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__76000022__6, lang.RT_IntCast_J__I_NoInit(2), nil); var in_a__10 any; var root_59 any = A_arbace_data_A_const_18.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_61 lang.IFn; if





	linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = a__0; var arg_63 any = k__2; if linked_60 == nil { in_a__10 = ifn_61.Invoke_O_O__O(arg_62, arg_63) } else { in_a__10 = linked_60.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_59, arg_62, arg_63) }; var in_b__11 any; var root_64 any = /*line :35:1*/A_arbace_data_A_const_18.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_66 lang.IFn; if






	linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = b__1; var arg_68 any = k__2; if linked_65 == nil { in_b__11 = ifn_66.Invoke_O_O__O(arg_67, arg_68) } else { in_b__11 = linked_65.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_64, arg_67, arg_68) }; var same__12 any; var and__1927000168__auto____12 any = in_a__10; if
	jrt.J2g_Truth(and__1927000168__auto____12) { var and__1927000168__auto____13 any = in_b__11; if jrt.J2g_Truth(and__1927000168__auto____13) { var or__1927000174__auto____14 any; var root_69 any = A_arbace_data_A_const_19.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_71 lang.IFn
		if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(ab__9, nil)).Ref(); if linked_70 == nil { or__1927000174__auto____14 = ifn_71.Invoke_O__O(arg_72) } else { or__1927000174__auto____14 = linked_70.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_69, arg_72) }; if jrt.J2g_Truth(or__1927000174__auto____14) { same__12 = or__1927000174__auto____14 } else { var and__1927000168__auto____15 bool = lang.Util_Identical_O_O__Z_NoInit(va__4, nil)
			if and__1927000168__auto____15 { same__12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(vb__5, nil)).Ref() } else { same__12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____15).Ref() } } } else {
//line :43:1
				same__12 = and__1927000168__auto____13 } } else { same__12 = and__1927000168__auto____12 }; var tmp1 lang.IPersistentMap; var tmp2 any; var and__1927000168__auto____13_2 any = in_a__10; if


	jrt.J2g_Truth(and__1927000168__auto____13_2) { var or__1927000174__auto____14_2 any; var root_73 any = A_arbace_data_A_const_19.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(a_STAR___7, nil)).Ref(); if linked_74 == nil { or__1927000174__auto____14_2 = ifn_75.Invoke_O__O(arg_76) } else { or__1927000174__auto____14_2 = linked_74.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_73, arg_76) }; if jrt.J2g_Truth(or__1927000174__auto____14_2) { tmp2 = or__1927000174__auto____14_2 } else { var root_77 any = A_arbace_data_A_const_19.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = same__12; if linked_78 == nil { tmp2 = ifn_79.Invoke_O__O(arg_80) } else { tmp2 = linked_78.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_77, arg_80) } } } else { tmp2 = and__1927000168__auto____13_2 }; if jrt.J2g_Truth(tmp2) { tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, k__2, a_STAR___7)) } else { tmp1 = nil }; var tmp3 any = tmp1; var tmp4 lang.IPersistentMap; var tmp5 any; var and__1927000168__auto____13_3 any = in_b__11; if
	jrt.J2g_Truth(and__1927000168__auto____13_3) { var or__1927000174__auto____14_3 any; var root_81 any = A_arbace_data_A_const_19.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(b_STAR___8, nil)).Ref(); if linked_82 == nil { or__1927000174__auto____14_3 = ifn_83.Invoke_O__O(arg_84) } else { or__1927000174__auto____14_3 = linked_82.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_81, arg_84) }; if jrt.J2g_Truth(or__1927000174__auto____14_3) { tmp5 = or__1927000174__auto____14_3 } else { var root_85 any = A_arbace_data_A_const_19.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = same__12; if linked_86 == nil { tmp5 = ifn_87.Invoke_O__O(arg_88) } else { tmp5 = linked_86.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_85, arg_88) } } } else { tmp5 = and__1927000168__auto____13_3 }; if jrt.J2g_Truth(tmp5) { tmp4 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, k__2, b_STAR___8)) } else { tmp4 = nil }; var tmp6 any = tmp4; var tmp7 lang.IPersistentMap; if
	jrt.J2g_Truth(same__12) { tmp7 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, k__2, ab__9)) } else { tmp7 = nil }; return /*line :35:1*/ lang.Tuple_Create_O_O_O__IPersistentVector(tmp3, tmp6, tmp7) }















func A_arbace_data_diff_associative_A_New() *A_arbace_data_diff_associative_A { A_arbace_data_A_Init(); t := &A_arbace_data_diff_associative_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_data_diff_associative_A) Ctor() {}
//line :51:1
func (t *A_arbace_data_diff_associative_A) Invoke_O_O_O_O__O(self, a__0, b__1, ks__2 any) any {


	var root_111 any = A_arbace_data_A_const_10.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any; var tmp1 any = A_arbace_data_diff_associative_fn__76000026_A_New(); var tmp2 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_data_diff_associative_fn__76000026_A_fn_class
	if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_data_diff_associative_fn__76000026_A_fn_class = fncls__99d; tmp2 = fncls__99d } else { tmp2 = fncls__99 }; arg_114 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :54:1
	var arg_115 any = A_arbace_data_A_const_23; var arg_116 any; var root_106 any = A_arbace_data_A_const_21.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_108 lang.IFn



	if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any; var root_100 any = A_arbace_data_A_const_24.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_partial_A_fn_class); var ifn_102 lang.IFn
	if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = A_arbace_data_A_const_25.GetRawRoot__O(); var arg_104 any = a__0; var arg_105 any = b__1; if linked_101 == nil { arg_109 = ifn_102.Invoke_O_O_O__O(arg_103, arg_104, arg_105) } else { arg_109 = linked_101.(*aot_arbace_core.A_arbace_core_partial_A).Invoke_O_O_O_O__O(root_100, arg_103, arg_104, arg_105) }
//line :58:1
	var arg_110 any = ks__2; if linked_107 == nil { arg_116 = ifn_108.Invoke_O_O__O(arg_109, arg_110) } else { arg_116 = linked_107.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_106, arg_109, arg_110) }
//line :54:1
	if linked_112 == nil { return ifn_113.Invoke_O_O_O__O(arg_114, arg_115, arg_116) } else { return linked_112.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_111, arg_114, arg_115, arg_116) } }
func A_arbace_data_diff_associative_fn__76000026_A_New() *A_arbace_data_diff_associative_fn__76000026_A { A_arbace_data_A_Init(); t := &A_arbace_data_diff_associative_fn__76000026_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_data_diff_associative_fn__76000026_A) Ctor() {}
//line :55:1
func (t *A_arbace_data_diff_associative_fn__76000026_A) Invoke_O_O_O__O(self, diff1__1, diff2__2 any) any {
	var root_95 any = A_arbace_data_A_const_20.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any; var root_89 any = A_arbace_data_A_const_21.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = A_arbace_data_A_const_22.GetRawRoot__O(); var arg_93 any = diff1__1; var arg_94 any = diff2__2; if linked_90 == nil { arg_98 = ifn_91.Invoke_O_O_O__O(arg_92, arg_93, arg_94) } else { arg_98 = linked_90.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_89, arg_92, arg_93, arg_94) }; if linked_96 == nil { return ifn_97.Invoke_O__O(arg_98) } else { return linked_96.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_95, arg_98)
	}
}



func A_arbace_data_diff_sequential_A_New() *A_arbace_data_diff_sequential_A { A_arbace_data_A_Init(); t := &A_arbace_data_diff_sequential_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_data_diff_sequential_A) Ctor() {}
//line :62:1
func (t *A_arbace_data_diff_sequential_A) Invoke_O_O_O__O(self, a__0, b__1 any) any {

	var root_148 any = A_arbace_data_A_const_12.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any; var root_143 any = A_arbace_data_A_const_21.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_143, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_145 lang.IFn; if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = A_arbace_data_A_const_26.GetRawRoot__O(); var arg_147 any; var root_137 any = A_arbace_data_A_const_27.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, A_arbace_data_diff_associative_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any; var tmp1 any; var root_117 any = A_arbace_data_A_const_28.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_119 lang.IFn
	if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = a__0; if linked_118 == nil { tmp1 = ifn_119.Invoke_O__O(arg_120) } else { tmp1 = linked_118.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_117, arg_120) }; if jrt.J2g_Truth(tmp1) { arg_140 = a__0 } else { var root_121 any = A_arbace_data_A_const_12.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = a__0; if linked_122 == nil { arg_140 = ifn_123.Invoke_O__O(arg_124) } else { arg_140 = linked_122.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_121, arg_124) } }
//line :64:1
	var arg_141 any; var tmp2 any; var root_125 any = A_arbace_data_A_const_28.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_127 lang.IFn

	if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = b__1; if linked_126 == nil { tmp2 = ifn_127.Invoke_O__O(arg_128) } else { tmp2 = linked_126.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_125, arg_128) }; if jrt.J2g_Truth(tmp2) { arg_141 = b__1 } else { var root_129 any = A_arbace_data_A_const_12.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = b__1; if linked_130 == nil { arg_141 = ifn_131.Invoke_O__O(arg_132) } else { arg_141 = linked_130.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_129, arg_132) } }
//line :64:1
	var arg_142 any; var root_133 any = A_arbace_data_A_const_29.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_135 lang.IFn


	if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Max_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(a__0)), int64(lang.RT_Count_O__I_NoInit(b__1)))).Ref(); if linked_134 == nil { arg_142 = ifn_135.Invoke_O__O(arg_136) } else { arg_142 = linked_134.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_133, arg_136) }
//line :64:1
	if linked_138 == nil { arg_147 = ifn_139.Invoke_O_O_O__O(arg_140, arg_141, arg_142) } else { arg_147 = linked_138.(*A_arbace_data_diff_associative_A).Invoke_O_O_O_O__O(root_137, arg_140, arg_141, arg_142) }; if linked_144 == nil { arg_151 = ifn_145.Invoke_O_O__O(arg_146, arg_147) } else { arg_151 = linked_144.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_143, arg_146, arg_147) }; if linked_149 == nil { return ifn_150.Invoke_O__O(arg_151) } else { return linked_149.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_148, arg_151)
	}
}


func A_arbace_data_eval76000038_fn__76000039_A_New() *A_arbace_data_eval76000038_fn__76000039_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000038_fn__76000039_A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_data_eval76000038_fn__76000039_A) Ctor() {}
//line :69:1
func (t *A_arbace_data_eval76000038_fn__76000039_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__76000031__2_ any; var tmp1 any = A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_New(); var tmp2 *jrt.Class; var fncls__153 *jrt.Class = A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_fn_class; if fncls__153 == nil { var fncls__153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_fn_class = fncls__153d; tmp2 = fncls__153d } else { tmp2 = fncls__153 }; G__76000031__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_New_O(G__76000031__2_); var tmp4 *jrt.Class; var fncls__161 *jrt.Class = A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_fn_class; if fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_fn_class = fncls__161d; tmp4 = fncls__161d } else { tmp4 = fncls__161 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :69:1
func A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_New_O(p0 any) *A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A{}; t.Ctor_O(p0); return t }
//line :69:1
func (t *A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A) Ctor_O(c__G__76000031 any) { t.F_G__76000031 = c__G__76000031 }
//line :69:1
func (t *A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A) Invoke_O_O__O(self, gf__x__76000043__1 any) any { var cache__231000236__auto____2 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____3 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____2)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__x__76000043__1)); if jrt.J2g_Truth(f__231000237__auto____3) { return lang.IFn_Cast(f__231000237__auto____3).Invoke_O__O(gf__x__76000043__1) } else { var tmp1 any; var root_154 any = A_arbace_data_A_const_30.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core__cache_protocol_fn_A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = self; var arg_158 any = gf__x__76000043__1; var arg_159 any = A_arbace_data_A_const_31; var arg_160 any = t.F_G__76000031; if linked_155 == nil { tmp1 = ifn_156.Invoke_O_O_O_O__O(arg_157, arg_158, arg_159, arg_160) } else { tmp1 = linked_155.(*aot_arbace_core.A_arbace_core__cache_protocol_fn_A).Invoke_O_O_O_O_O__O(root_154, arg_157, arg_158, arg_159, arg_160) }; return lang.IFn_Cast(tmp1).Invoke_O__O(gf__x__76000043__1) } }
//line :69:1
func A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_New() *A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A) Ctor() {}
//line :69:1
func (t *A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A) Invoke_O_O__O(self, gf__x__76000040__1 any) any { var target_152 any = gf__x__76000040__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_152 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_152) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_152, Lit_4, jrt.RefArrayOf(jrt.Object_class)) } else { return A_arbace_data_EqualityPartition_A_Cast(target_152).Equality_partition__O() } }



func A_arbace_data_eval76000060_fn__76000061_A_New() *A_arbace_data_eval76000060_fn__76000061_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000060_fn__76000061_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_data_eval76000060_fn__76000061_A) Ctor() {}
//line :73:1
func (t *A_arbace_data_eval76000060_fn__76000061_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__76000053__2_ any; var tmp1 any = A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_New(); var tmp2 *jrt.Class; var fncls__163 *jrt.Class = A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_fn_class; if fncls__163 == nil { var fncls__163d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_fn_class = fncls__163d; tmp2 = fncls__163d } else { tmp2 = fncls__163 }; G__76000053__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_New_O(G__76000053__2_); var tmp4 *jrt.Class; var fncls__171 *jrt.Class = A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_fn_class; if fncls__171 == nil { var fncls__171d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_fn_class = fncls__171d; tmp4 = fncls__171d } else { tmp4 = fncls__171 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :73:1
func A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_New_O(p0 any) *A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A{}; t.Ctor_O(p0); return t }
//line :73:1
func (t *A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A) Ctor_O(c__G__76000053 any) { t.F_G__76000053 = c__G__76000053 }
//line :73:1
func (t *A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A) Invoke_O_O_O__O(self, gf__a__76000066__1, gf__b__76000067__2 any) any { var cache__231000236__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__a__76000066__1)); if jrt.J2g_Truth(f__231000237__auto____4) { return lang.IFn_Cast(f__231000237__auto____4).Invoke_O_O__O(gf__a__76000066__1, gf__b__76000067__2) } else { var tmp1 any; var root_164 any = A_arbace_data_A_const_30.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core__cache_protocol_fn_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = self; var arg_168 any = gf__a__76000066__1; var arg_169 any = A_arbace_data_A_const_32; var arg_170 any = t.F_G__76000053; if linked_165 == nil { tmp1 = ifn_166.Invoke_O_O_O_O__O(arg_167, arg_168, arg_169, arg_170) } else { tmp1 = linked_165.(*aot_arbace_core.A_arbace_core__cache_protocol_fn_A).Invoke_O_O_O_O_O__O(root_164, arg_167, arg_168, arg_169, arg_170) }; return lang.IFn_Cast(tmp1).Invoke_O_O__O(gf__a__76000066__1, gf__b__76000067__2) } }
//line :73:1
func A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_New() *A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A) Ctor() {}
//line :73:1
func (t *A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A) Invoke_O_O_O__O(self, gf__a__76000062__1, gf__b__76000063__2 any) any { var target_162 any = gf__a__76000062__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_162 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_162) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_162, Lit_7, jrt.RefArrayOf(jrt.Object_class, gf__b__76000063__2)) } else { return A_arbace_data_Diff_A_Cast(target_162).Diff_similar_O__O(gf__b__76000063__2) } }









func A_arbace_data_eval76000078_fn__76000079_A_New() *A_arbace_data_eval76000078_fn__76000079_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000078_fn__76000079_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_data_eval76000078_fn__76000079_A) Ctor() {}
//line :83:1
func (t *A_arbace_data_eval76000078_fn__76000079_A) Invoke_O_O_O__O(self, a__1, b__2 any) any {
	var tmp1 any; if jrt.NN(jrt.GetClass(a__1)).IsArray__Z() { tmp1 = A_arbace_data_A_const_33.GetRawRoot__O() } else { tmp1 = A_arbace_data_A_const_34.GetRawRoot__O() }; return lang.IFn_Cast(tmp1).Invoke_O_O__O(a__1, b__2)
}
func A_arbace_data_eval76000078_fn__76000081_A_New() *A_arbace_data_eval76000078_fn__76000081_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000078_fn__76000081_A{}; t.Ctor(); return t }
//line :86:1
func (t *A_arbace_data_eval76000078_fn__76000081_A) Ctor() {}
//line :86:1
func (t *A_arbace_data_eval76000078_fn__76000081_A) Invoke_O_O__O(self, x__1 any) any {
	if jrt.NN(jrt.GetClass(x__1)).IsArray__Z() { return A_arbace_data_A_const_35 } else { return A_arbace_data_A_const_36
	} }
func A_arbace_data_eval76000084_fn__76000085_A_New() *A_arbace_data_eval76000084_fn__76000085_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000084_fn__76000085_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_data_eval76000084_fn__76000085_A) Ctor() {}
//line :89:1
func (t *A_arbace_data_eval76000084_fn__76000085_A) Invoke_O_O__O(self, x__1 any) any { return A_arbace_data_A_const_36 }
//line :89:1
func A_arbace_data_eval76000088_fn__76000089_A_New() *A_arbace_data_eval76000088_fn__76000089_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000088_fn__76000089_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_data_eval76000088_fn__76000089_A) Ctor() {}
//line :89:1
func (t *A_arbace_data_eval76000088_fn__76000089_A) Invoke_O_O__O(self, x__1 any) any { return A_arbace_data_A_const_37 }
//line :89:1
func A_arbace_data_eval76000092_fn__76000093_A_New() *A_arbace_data_eval76000092_fn__76000093_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000092_fn__76000093_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_data_eval76000092_fn__76000093_A) Ctor() {}
//line :89:1
func (t *A_arbace_data_eval76000092_fn__76000093_A) Invoke_O_O__O(self, x__1 any) any { return A_arbace_data_A_const_35 }
//line :89:1
func A_arbace_data_eval76000096_fn__76000097_A_New() *A_arbace_data_eval76000096_fn__76000097_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000096_fn__76000097_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_data_eval76000096_fn__76000097_A) Ctor() {}
//line :89:1
func (t *A_arbace_data_eval76000096_fn__76000097_A) Invoke_O_O__O(self, x__1 any) any { return A_arbace_data_A_const_38 }












func A_arbace_data_as_set_value_A_New() *A_arbace_data_as_set_value_A { A_arbace_data_A_Init(); t := &A_arbace_data_as_set_value_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_data_as_set_value_A) Ctor() {}
//line :102:1
func (t *A_arbace_data_as_set_value_A) Invoke_O_O__O(self, s__0 any) any {

	var tmp1 any; var root_172 any = A_arbace_data_A_const_39.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_set_QMARK__A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = s__0; if linked_173 == nil { tmp1 = ifn_174.Invoke_O__O(arg_175) } else { tmp1 = linked_173.(*aot_arbace_core.A_arbace_core_set_QMARK__A).Invoke_O_O__O(root_172, arg_175) }; if jrt.J2g_Truth(tmp1) { return s__0 } else { var root_176 any = A_arbace_data_A_const_40.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = lang.PersistentHashSet_EMPTY.Ref(); var arg_180 any = s__0; if linked_177 == nil { return ifn_178.Invoke_O_O__O(arg_179, arg_180) } else { return linked_177.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_176, arg_179, arg_180)
	} } }
func A_arbace_data_eval76000101_fn__76000102_A_New() *A_arbace_data_eval76000101_fn__76000102_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000101_fn__76000102_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_data_eval76000101_fn__76000102_A) Ctor() {}
//line :106:1
func (t *A_arbace_data_eval76000101_fn__76000102_A) Invoke_O_O_O__O(self, a__1, b__2 any) any { var aval__3 any; var root_181 any = A_arbace_data_A_const_41.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, A_arbace_data_as_set_value_A_fn_class); var ifn_183 lang.IFn; if



	linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = a__1; if linked_182 == nil { aval__3 = ifn_183.Invoke_O__O(arg_184) } else { aval__3 = linked_182.(*A_arbace_data_as_set_value_A).Invoke_O_O__O(root_181, arg_184) }; var bval__4 any; var root_185 any = /*line :106:1*/A_arbace_data_A_const_41.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, A_arbace_data_as_set_value_A_fn_class); var ifn_187 lang.IFn; if




	linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = b__2; if linked_186 == nil { bval__4 = ifn_187.Invoke_O__O(arg_188) } else { bval__4 = linked_186.(*A_arbace_data_as_set_value_A).Invoke_O_O__O(root_185, arg_188) }; var tmp1 any; var root_194 any = /*line :106:1*/A_arbace_data_A_const_42.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_not_empty_A_fn_class); var ifn_196 lang.IFn; if





	linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any; var root_189 any = A_arbace_data_A_const_43.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_189, aot_arbace_set.A_arbace_set_difference_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = aval__3; var arg_193 any = bval__4; if linked_190 == nil { arg_197 = ifn_191.Invoke_O_O__O(arg_192, arg_193) } else { arg_197 = linked_190.(*aot_arbace_set.A_arbace_set_difference_A).Invoke_O_O_O__O(root_189, arg_192, arg_193) }; if linked_195 == nil { tmp1 = ifn_196.Invoke_O__O(arg_197) } else { tmp1 = linked_195.(*aot_arbace_core.A_arbace_core_not_empty_A).Invoke_O_O__O(root_194, arg_197) }; var tmp2 any = tmp1; var tmp3 any; var root_203 any = /*line :106:1*/A_arbace_data_A_const_42.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, aot_arbace_core.A_arbace_core_not_empty_A_fn_class); var ifn_205 lang.IFn; if






	linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any; var root_198 any = A_arbace_data_A_const_43.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_198, aot_arbace_set.A_arbace_set_difference_A_fn_class); var ifn_200 lang.IFn; if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = bval__4; var arg_202 any = aval__3; if linked_199 == nil { arg_206 = ifn_200.Invoke_O_O__O(arg_201, arg_202) } else { arg_206 = linked_199.(*aot_arbace_set.A_arbace_set_difference_A).Invoke_O_O_O__O(root_198, arg_201, arg_202) }; if linked_204 == nil { tmp3 = ifn_205.Invoke_O__O(arg_206) } else { tmp3 = linked_204.(*aot_arbace_core.A_arbace_core_not_empty_A).Invoke_O_O__O(root_203, arg_206) }; var tmp4 any = tmp3; var tmp5 any; var root_212 any = /*line :106:1*/A_arbace_data_A_const_42.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core_not_empty_A_fn_class); var ifn_214 lang.IFn; if







	linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any; var root_207 any = A_arbace_data_A_const_44.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_207, aot_arbace_set.A_arbace_set_intersection_A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = aval__3; var arg_211 any = bval__4; if linked_208 == nil { arg_215 = ifn_209.Invoke_O_O__O(arg_210, arg_211) } else { arg_215 = linked_208.(*aot_arbace_set.A_arbace_set_intersection_A).Invoke_O_O_O__O(root_207, arg_210, arg_211) }; if linked_213 == nil { tmp5 = ifn_214.Invoke_O__O(arg_215) } else { tmp5 = linked_213.(*aot_arbace_core.A_arbace_core_not_empty_A).Invoke_O_O__O(root_212, arg_215) }; return /*line :106:1*/ lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, tmp4, tmp5) }
//line :106:1
func A_arbace_data_eval76000105_fn__76000106_A_New() *A_arbace_data_eval76000105_fn__76000106_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000105_fn__76000106_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_data_eval76000105_fn__76000106_A) Ctor() {}
//line :106:1
func (t *A_arbace_data_eval76000105_fn__76000106_A) Invoke_O_O_O__O(self, a__1, b__2 any) any {











	var root_216 any = A_arbace_data_A_const_33.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, A_arbace_data_diff_sequential_A_fn_class); var ifn_218 lang.IFn; if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = a__1; var arg_220 any = b__2; if linked_217 == nil { return ifn_218.Invoke_O_O__O(arg_219, arg_220) } else { return linked_217.(*A_arbace_data_diff_sequential_A).Invoke_O_O_O__O(root_216, arg_219, arg_220) } }
//line :106:1
func A_arbace_data_eval76000109_fn__76000110_A_New() *A_arbace_data_eval76000109_fn__76000110_A { A_arbace_data_A_Init(); t := &A_arbace_data_eval76000109_fn__76000110_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_data_eval76000109_fn__76000110_A) Ctor() {}
//line :106:1
func (t *A_arbace_data_eval76000109_fn__76000110_A) Invoke_O_O_O__O(self, a__1, b__2 any) any {















	var root_234 any = A_arbace_data_A_const_27.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, A_arbace_data_diff_associative_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = a__1; var arg_238 any = b__2; var arg_239 any; var root_229 any = A_arbace_data_A_const_45.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_229, aot_arbace_set.A_arbace_set_union_A_fn_class); var ifn_231 lang.IFn; if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any; var root_221 any = A_arbace_data_A_const_16.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = a__1; if linked_222 == nil { arg_232 = ifn_223.Invoke_O__O(arg_224) } else { arg_232 = linked_222.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_221, arg_224) }; var arg_233 any; var root_225 any = A_arbace_data_A_const_16.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any = b__2; if linked_226 == nil { arg_233 = ifn_227.Invoke_O__O(arg_228) } else { arg_233 = linked_226.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_225, arg_228) }; if linked_230 == nil { arg_239 = ifn_231.Invoke_O_O__O(arg_232, arg_233) } else { arg_239 = linked_230.(*aot_arbace_set.A_arbace_set_union_A).Invoke_O_O_O__O(root_229, arg_232, arg_233) }; if linked_235 == nil { return ifn_236.Invoke_O_O_O__O(arg_237, arg_238, arg_239) } else { return linked_235.(*A_arbace_data_diff_associative_A).Invoke_O_O_O_O__O(root_234, arg_237, arg_238, arg_239)
	} }
func A_arbace_data_diff_A_New() *A_arbace_data_diff_A { A_arbace_data_A_Init(); t := &A_arbace_data_diff_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_data_diff_A) Ctor() {}
//line :124:1
func (t *A_arbace_data_diff_A) Invoke_O_O_O__O(self, a__0, b__1 any) any {













	if lang.Util_Equiv_O_O__Z_NoInit(a__0, b__1) { return lang.Tuple_Create_O_O_O__IPersistentVector(nil, nil, a__0) } else {

		var tmp1 any; var target_240 any = a__0; var tmp2 bool; var tmp3 bool; tmp3 = A_arbace_data_EqualityPartition_A_InstanceOf(target_240); if tmp3 { tmp3 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_240) }; tmp2 = tmp3; if tmp2 { tmp1 = A_arbace_data_EqualityPartition_A_Cast(target_240).Equality_partition__O() } else { tmp1 = lang.IFn_Cast(A_arbace_data_A_const_46.GetRawRoot__O()).Invoke_O__O(target_240) }; var tmp4 any = tmp1; var tmp5 any; var target_241 any = b__1; var tmp6 bool; var tmp7 bool; tmp7 = A_arbace_data_EqualityPartition_A_InstanceOf(target_241); if tmp7 { tmp7 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_241) }; tmp6 = tmp7; if tmp6 { tmp5 = A_arbace_data_EqualityPartition_A_Cast(target_241).Equality_partition__O() } else { tmp5 = lang.IFn_Cast(A_arbace_data_A_const_46.GetRawRoot__O()).Invoke_O__O(target_241) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5) {
			var target_242 any = a__0; var tmp8 bool; var tmp9 bool; tmp9 = A_arbace_data_Diff_A_InstanceOf(target_242); if tmp9 { tmp9 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_242) }; tmp8 = tmp9; if tmp8 { return A_arbace_data_Diff_A_Cast(target_242).Diff_similar_O__O(b__1) } else { return lang.IFn_Cast(A_arbace_data_A_const_47.GetRawRoot__O()).Invoke_O_O__O(target_242, b__1) } } else {
				var root_243 any = A_arbace_data_A_const_34.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_243, A_arbace_data_atom_diff_A_fn_class); var ifn_245 lang.IFn; if linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any = a__0; var arg_247 any = b__1; if linked_244 == nil { return ifn_245.Invoke_O_O__O(arg_246, arg_247) } else { return linked_244.(*A_arbace_data_atom_diff_A).Invoke_O_O_O__O(root_243, arg_246, arg_247)
				}
			}
	}
}


























type A_arbace_data_A struct{ jrt.Object }

var A_arbace_data_A_const_pool *jrt.RefArray

var A_arbace_data_A_const_0 *lang.Var

var A_arbace_data_A_const_1 any

var A_arbace_data_A_const_2 *lang.Var

var A_arbace_data_A_const_3 any

var A_arbace_data_A_const_4 *lang.Var

var A_arbace_data_A_const_5 *lang.Var

var A_arbace_data_A_const_6 *lang.Var

var A_arbace_data_A_const_7 *lang.Var

var A_arbace_data_A_const_8 any

var A_arbace_data_A_const_9 *lang.Var

var A_arbace_data_A_const_10 *lang.Var

var A_arbace_data_A_const_11 *lang.Var

var A_arbace_data_A_const_12 *lang.Var

var A_arbace_data_A_const_13 *lang.Var

var A_arbace_data_A_const_14 *lang.Var

var A_arbace_data_A_const_15 *lang.Var

var A_arbace_data_A_const_16 *lang.Var

var A_arbace_data_A_const_17 *lang.Var

var A_arbace_data_A_const_18 *lang.Var

var A_arbace_data_A_const_19 *lang.Var

var A_arbace_data_A_const_20 *lang.Var

var A_arbace_data_A_const_21 *lang.Var

var A_arbace_data_A_const_22 *lang.Var

var A_arbace_data_A_const_23 any

var A_arbace_data_A_const_24 *lang.Var

var A_arbace_data_A_const_25 *lang.Var

var A_arbace_data_A_const_26 *lang.Var

var A_arbace_data_A_const_27 *lang.Var

var A_arbace_data_A_const_28 *lang.Var

var A_arbace_data_A_const_29 *lang.Var

var A_arbace_data_A_const_30 *lang.Var

var A_arbace_data_A_const_31 *jrt.Class

var A_arbace_data_A_const_32 *jrt.Class

var A_arbace_data_A_const_33 *lang.Var

var A_arbace_data_A_const_34 *lang.Var

var A_arbace_data_A_const_35 *lang.Keyword

var A_arbace_data_A_const_36 *lang.Keyword

var A_arbace_data_A_const_37 *lang.Keyword

var A_arbace_data_A_const_38 *lang.Keyword

var A_arbace_data_A_const_39 *lang.Var

var A_arbace_data_A_const_40 *lang.Var

var A_arbace_data_A_const_41 *lang.Var

var A_arbace_data_A_const_42 *lang.Var

var A_arbace_data_A_const_43 *lang.Var

var A_arbace_data_A_const_44 *lang.Var

var A_arbace_data_A_const_45 *lang.Var

var A_arbace_data_A_const_46 *lang.Var

var A_arbace_data_A_const_47 *lang.Var

var A_arbace_data_A_init jrt.ClassInit

func A_arbace_data_A_Init() { if !A_arbace_data_A_init.Done() { A_arbace_data_A_init.Run(A_arbace_data_A_clinit) } }

func A_arbace_data_A_clinit() { A_arbace_data_A_clinit_p0(); A_arbace_data_A_clinit_p1(); A_arbace_data_A_clinit_p2(); A_arbace_data_A_clinit_p3() }

func A_arbace_data_A_clinit_p0() { jrt.StartCheck(); A_arbace_data_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 58); A_arbace_data_A_const_0 = lang.Var_Cast(A_arbace_data_A_const_pool.A[10]); A_arbace_data_A_const_1 = A_arbace_data_A_const_pool.A[11]; A_arbace_data_A_const_2 = lang.Var_Cast(A_arbace_data_A_const_pool.A[12]); A_arbace_data_A_const_3 = A_arbace_data_A_const_pool.A[13]; A_arbace_data_A_const_4 = lang.Var_Cast(A_arbace_data_A_const_pool.A[14]); A_arbace_data_A_const_5 = lang.Var_Cast(A_arbace_data_A_const_pool.A[15]); A_arbace_data_A_const_6 = lang.Var_Cast(A_arbace_data_A_const_pool.A[16]); A_arbace_data_A_const_7 = lang.Var_Cast(A_arbace_data_A_const_pool.A[17]); A_arbace_data_A_const_8 = A_arbace_data_A_const_pool.A[18]; A_arbace_data_A_const_9 = lang.Var_Cast(A_arbace_data_A_const_pool.A[19]); A_arbace_data_A_const_10 = lang.Var_Cast(A_arbace_data_A_const_pool.A[20]); A_arbace_data_A_const_11 = lang.Var_Cast(A_arbace_data_A_const_pool.A[21]) }

func A_arbace_data_A_clinit_p1() { A_arbace_data_A_const_12 = lang.Var_Cast(A_arbace_data_A_const_pool.A[22]); A_arbace_data_A_const_13 = lang.Var_Cast(A_arbace_data_A_const_pool.A[23]); A_arbace_data_A_const_14 = lang.Var_Cast(A_arbace_data_A_const_pool.A[24]); A_arbace_data_A_const_15 = lang.Var_Cast(A_arbace_data_A_const_pool.A[25]); A_arbace_data_A_const_16 = lang.Var_Cast(A_arbace_data_A_const_pool.A[26]); A_arbace_data_A_const_17 = lang.Var_Cast(A_arbace_data_A_const_pool.A[27]); A_arbace_data_A_const_18 = lang.Var_Cast(A_arbace_data_A_const_pool.A[28]); A_arbace_data_A_const_19 = lang.Var_Cast(A_arbace_data_A_const_pool.A[29]); A_arbace_data_A_const_20 = lang.Var_Cast(A_arbace_data_A_const_pool.A[30]); A_arbace_data_A_const_21 = lang.Var_Cast(A_arbace_data_A_const_pool.A[31]); A_arbace_data_A_const_22 = lang.Var_Cast(A_arbace_data_A_const_pool.A[32]); A_arbace_data_A_const_23 = A_arbace_data_A_const_pool.A[33] }

func A_arbace_data_A_clinit_p2() { A_arbace_data_A_const_24 = lang.Var_Cast(A_arbace_data_A_const_pool.A[34]); A_arbace_data_A_const_25 = lang.Var_Cast(A_arbace_data_A_const_pool.A[35]); A_arbace_data_A_const_26 = lang.Var_Cast(A_arbace_data_A_const_pool.A[36]); A_arbace_data_A_const_27 = lang.Var_Cast(A_arbace_data_A_const_pool.A[37]); A_arbace_data_A_const_28 = lang.Var_Cast(A_arbace_data_A_const_pool.A[38]); A_arbace_data_A_const_29 = lang.Var_Cast(A_arbace_data_A_const_pool.A[39]); A_arbace_data_A_const_30 = lang.Var_Cast(A_arbace_data_A_const_pool.A[40]); A_arbace_data_A_const_31 = jrt.Class_Cast(A_arbace_data_A_const_pool.A[41]); A_arbace_data_A_const_32 = jrt.Class_Cast(A_arbace_data_A_const_pool.A[42]); A_arbace_data_A_const_33 = lang.Var_Cast(A_arbace_data_A_const_pool.A[43]); A_arbace_data_A_const_34 = lang.Var_Cast(A_arbace_data_A_const_pool.A[44]); A_arbace_data_A_const_35 = lang.Keyword_Cast(A_arbace_data_A_const_pool.A[45]) }

func A_arbace_data_A_clinit_p3() { A_arbace_data_A_const_36 = lang.Keyword_Cast(A_arbace_data_A_const_pool.A[46]); A_arbace_data_A_const_37 = lang.Keyword_Cast(A_arbace_data_A_const_pool.A[47]); A_arbace_data_A_const_38 = lang.Keyword_Cast(A_arbace_data_A_const_pool.A[48]); A_arbace_data_A_const_39 = lang.Var_Cast(A_arbace_data_A_const_pool.A[49]); A_arbace_data_A_const_40 = lang.Var_Cast(A_arbace_data_A_const_pool.A[50]); A_arbace_data_A_const_41 = lang.Var_Cast(A_arbace_data_A_const_pool.A[51]); A_arbace_data_A_const_42 = lang.Var_Cast(A_arbace_data_A_const_pool.A[52]); A_arbace_data_A_const_43 = lang.Var_Cast(A_arbace_data_A_const_pool.A[53]); A_arbace_data_A_const_44 = lang.Var_Cast(A_arbace_data_A_const_pool.A[54]); A_arbace_data_A_const_45 = lang.Var_Cast(A_arbace_data_A_const_pool.A[55]); A_arbace_data_A_const_46 = lang.Var_Cast(A_arbace_data_A_const_pool.A[56]); A_arbace_data_A_const_47 = lang.Var_Cast(A_arbace_data_A_const_pool.A[57]) }

func A_arbace_data_A_New() *A_arbace_data_A { A_arbace_data_A_Init(); t := &A_arbace_data_A{}; t.Ctor(); return t }

func (t *A_arbace_data_A) Ctor() {}

func (t *A_arbace_data_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_A) GetClass__Class() *jrt.Class { return A_arbace_data_A_class }

func (t *A_arbace_data_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_A); return ok }

func A_arbace_data_A_Cast(x any) *A_arbace_data_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_A_class)) }; return v }



type A_arbace_data_as_set_value_A struct{ j2g_header uint64 }

var A_arbace_data_as_set_value_A_fn_class *jrt.Class



type A_arbace_data_atom_diff_A struct{ j2g_header uint64 }

var A_arbace_data_atom_diff_A_fn_class *jrt.Class



type A_arbace_data_diff_A struct{ j2g_header uint64 }

var A_arbace_data_diff_A_fn_class *jrt.Class



type A_arbace_data_diff_associative_A struct{ j2g_header uint64 }

var A_arbace_data_diff_associative_A_fn_class *jrt.Class



type A_arbace_data_diff_associative_fn__76000026_A struct{ j2g_header uint64 }

var A_arbace_data_diff_associative_fn__76000026_A_fn_class *jrt.Class



type A_arbace_data_diff_associative_key_A struct{ j2g_header uint64 }

var A_arbace_data_diff_associative_key_A_fn_class *jrt.Class



type A_arbace_data_diff_sequential_A struct{ j2g_header uint64 }

var A_arbace_data_diff_sequential_A_fn_class *jrt.Class



type A_arbace_data_eval76000004_A struct{ jrt.Object }

func A_arbace_data_eval76000004_A_New() *A_arbace_data_eval76000004_A { t := &A_arbace_data_eval76000004_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000004_A) Ctor() {}

func (t *A_arbace_data_eval76000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000004_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000004_A_class }

func (t *A_arbace_data_eval76000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000004_A); return ok }

func A_arbace_data_eval76000004_A_Cast(x any) *A_arbace_data_eval76000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000004_A_class)) }; return v }



type A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_fn_class *jrt.Class



type A_arbace_data_eval76000008_A struct{ jrt.Object }

func A_arbace_data_eval76000008_A_New() *A_arbace_data_eval76000008_A { t := &A_arbace_data_eval76000008_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000008_A) Ctor() {}

func (t *A_arbace_data_eval76000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000008_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000008_A_class }

func (t *A_arbace_data_eval76000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000008_A); return ok }

func A_arbace_data_eval76000008_A_Cast(x any) *A_arbace_data_eval76000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000008_A_class)) }; return v }



type A_arbace_data_eval76000008_fn__76000009_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000008_fn__76000009_A_fn_class *jrt.Class



type A_arbace_data_eval76000038_A struct{ jrt.Object }

func A_arbace_data_eval76000038_A_New() *A_arbace_data_eval76000038_A { t := &A_arbace_data_eval76000038_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000038_A) Ctor() {}

func (t *A_arbace_data_eval76000038_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000038_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000038_A_class }

func (t *A_arbace_data_eval76000038_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000038_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000038_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000038_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000038_A); return ok }

func A_arbace_data_eval76000038_A_Cast(x any) *A_arbace_data_eval76000038_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000038_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000038_A_class)) }; return v }



type A_arbace_data_eval76000038_fn__76000039_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000038_fn__76000039_A_fn_class *jrt.Class



type A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A struct{ j2g_header uint64; F_G__76000031 any }

var A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_fn_class *jrt.Class



type A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_fn_class *jrt.Class



type A_arbace_data_eval76000060_A struct{ jrt.Object }

func A_arbace_data_eval76000060_A_New() *A_arbace_data_eval76000060_A { t := &A_arbace_data_eval76000060_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000060_A) Ctor() {}

func (t *A_arbace_data_eval76000060_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000060_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000060_A_class }

func (t *A_arbace_data_eval76000060_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000060_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000060_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000060_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000060_A); return ok }

func A_arbace_data_eval76000060_A_Cast(x any) *A_arbace_data_eval76000060_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000060_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000060_A_class)) }; return v }



type A_arbace_data_eval76000060_fn__76000061_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000060_fn__76000061_A_fn_class *jrt.Class



type A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A struct{ j2g_header uint64; F_G__76000053 any }

var A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_fn_class *jrt.Class



type A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_fn_class *jrt.Class



type A_arbace_data_eval76000078_A struct{ jrt.Object }

func A_arbace_data_eval76000078_A_New() *A_arbace_data_eval76000078_A { t := &A_arbace_data_eval76000078_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000078_A) Ctor() {}

func (t *A_arbace_data_eval76000078_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000078_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000078_A_class }

func (t *A_arbace_data_eval76000078_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000078_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000078_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000078_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000078_A); return ok }

func A_arbace_data_eval76000078_A_Cast(x any) *A_arbace_data_eval76000078_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000078_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000078_A_class)) }; return v }



type A_arbace_data_eval76000078_fn__76000079_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000078_fn__76000079_A_fn_class *jrt.Class



type A_arbace_data_eval76000078_fn__76000081_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000078_fn__76000081_A_fn_class *jrt.Class



type A_arbace_data_eval76000084_A struct{ jrt.Object }

func A_arbace_data_eval76000084_A_New() *A_arbace_data_eval76000084_A { t := &A_arbace_data_eval76000084_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000084_A) Ctor() {}

func (t *A_arbace_data_eval76000084_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000084_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000084_A_class }

func (t *A_arbace_data_eval76000084_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000084_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000084_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000084_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000084_A); return ok }

func A_arbace_data_eval76000084_A_Cast(x any) *A_arbace_data_eval76000084_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000084_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000084_A_class)) }; return v }



type A_arbace_data_eval76000084_fn__76000085_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000084_fn__76000085_A_fn_class *jrt.Class



type A_arbace_data_eval76000088_A struct{ jrt.Object }

func A_arbace_data_eval76000088_A_New() *A_arbace_data_eval76000088_A { t := &A_arbace_data_eval76000088_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000088_A) Ctor() {}

func (t *A_arbace_data_eval76000088_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000088_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000088_A_class }

func (t *A_arbace_data_eval76000088_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000088_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000088_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000088_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000088_A); return ok }

func A_arbace_data_eval76000088_A_Cast(x any) *A_arbace_data_eval76000088_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000088_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000088_A_class)) }; return v }



type A_arbace_data_eval76000088_fn__76000089_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000088_fn__76000089_A_fn_class *jrt.Class



type A_arbace_data_eval76000092_A struct{ jrt.Object }

func A_arbace_data_eval76000092_A_New() *A_arbace_data_eval76000092_A { t := &A_arbace_data_eval76000092_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000092_A) Ctor() {}

func (t *A_arbace_data_eval76000092_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000092_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000092_A_class }

func (t *A_arbace_data_eval76000092_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000092_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000092_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000092_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000092_A); return ok }

func A_arbace_data_eval76000092_A_Cast(x any) *A_arbace_data_eval76000092_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000092_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000092_A_class)) }; return v }



type A_arbace_data_eval76000092_fn__76000093_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000092_fn__76000093_A_fn_class *jrt.Class



type A_arbace_data_eval76000096_A struct{ jrt.Object }

func A_arbace_data_eval76000096_A_New() *A_arbace_data_eval76000096_A { t := &A_arbace_data_eval76000096_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000096_A) Ctor() {}

func (t *A_arbace_data_eval76000096_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000096_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000096_A_class }

func (t *A_arbace_data_eval76000096_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000096_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000096_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000096_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000096_A); return ok }

func A_arbace_data_eval76000096_A_Cast(x any) *A_arbace_data_eval76000096_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000096_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000096_A_class)) }; return v }



type A_arbace_data_eval76000096_fn__76000097_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000096_fn__76000097_A_fn_class *jrt.Class



type A_arbace_data_eval76000101_A struct{ jrt.Object }

func A_arbace_data_eval76000101_A_New() *A_arbace_data_eval76000101_A { t := &A_arbace_data_eval76000101_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000101_A) Ctor() {}

func (t *A_arbace_data_eval76000101_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000101_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000101_A_class }

func (t *A_arbace_data_eval76000101_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000101_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000101_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000101_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000101_A); return ok }

func A_arbace_data_eval76000101_A_Cast(x any) *A_arbace_data_eval76000101_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000101_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000101_A_class)) }; return v }



type A_arbace_data_eval76000101_fn__76000102_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000101_fn__76000102_A_fn_class *jrt.Class



type A_arbace_data_eval76000105_A struct{ jrt.Object }

func A_arbace_data_eval76000105_A_New() *A_arbace_data_eval76000105_A { t := &A_arbace_data_eval76000105_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000105_A) Ctor() {}

func (t *A_arbace_data_eval76000105_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000105_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000105_A_class }

func (t *A_arbace_data_eval76000105_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000105_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000105_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000105_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000105_A); return ok }

func A_arbace_data_eval76000105_A_Cast(x any) *A_arbace_data_eval76000105_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000105_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000105_A_class)) }; return v }



type A_arbace_data_eval76000105_fn__76000106_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000105_fn__76000106_A_fn_class *jrt.Class



type A_arbace_data_eval76000109_A struct{ jrt.Object }

func A_arbace_data_eval76000109_A_New() *A_arbace_data_eval76000109_A { t := &A_arbace_data_eval76000109_A{}; t.Ctor(); return t }

func (t *A_arbace_data_eval76000109_A) Ctor() {}

func (t *A_arbace_data_eval76000109_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data_eval76000109_A) GetClass__Class() *jrt.Class { return A_arbace_data_eval76000109_A_class }

func (t *A_arbace_data_eval76000109_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data_eval76000109_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data_eval76000109_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data_eval76000109_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data_eval76000109_A); return ok }

func A_arbace_data_eval76000109_A_Cast(x any) *A_arbace_data_eval76000109_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data_eval76000109_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data_eval76000109_A_class)) }; return v }



type A_arbace_data_eval76000109_fn__76000110_A struct{ j2g_header uint64 }

var A_arbace_data_eval76000109_fn__76000110_A_fn_class *jrt.Class



type A_arbace_data_vectorize_A struct{ j2g_header uint64 }

var A_arbace_data_vectorize_A_fn_class *jrt.Class



type A_arbace_data_vectorize_fn__76000016_A struct{ j2g_header uint64 }

var A_arbace_data_vectorize_fn__76000016_A_fn_class *jrt.Class
