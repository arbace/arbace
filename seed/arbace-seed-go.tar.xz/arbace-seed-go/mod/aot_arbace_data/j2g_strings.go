//line j2g_strings.ae:1
package aot_arbace_data

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn10,arbace.setkn2,asyn3,setyn11,arbace.corekn6,authorkn3,dockn10,sequentialkn4,atomkn3,setkn3,mapv11,arbace.core7,requireV3,R0,R1,R2,v11,arbace.core5,referR3,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn11,arbace.datam4,R4,s15,Stuart HallowayR5,s24,Non-core data functions.v11,arbace.core3,seqv11,arbace.core6,reducev11,arbace.core5,assocv11,arbace.core3,vecv11,arbace.core6,repeatv11,arbace.core5,applyv11,arbace.core3,maxv11,arbace.core4,keysv11,arbace.data4,diffv11,arbace.core9,contains?v11,arbace.core3,notv11,arbace.core5,doallv11,arbace.core3,mapv11,arbace.core5,mergeV3,nnnv11,arbace.core7,partialv11,arbace.data20,diff-associative-keyv11,arbace.data9,vectorizev11,arbace.data16,diff-associativev11,arbace.core7,vector?v11,arbace.core5,rangev11,arbace.core18,-cache-protocol-fnC29,arbace.data.EqualityPartitionC16,arbace.data.Diffv11,arbace.data15,diff-sequentialv11,arbace.data9,atom-diffR6,R7,R8,R9,v11,arbace.core4,set?v11,arbace.core4,intov11,arbace.data12,as-set-valuev11,arbace.core9,not-emptyv10,arbace.set10,differencev10,arbace.set12,intersectionv10,arbace.set5,unionv11,arbace.data18,equality-partitionv11,arbace.data12,diff-similar")

var Lit_1 *jrt.String = jrt.Intern("arbace.data$diff_associative$fn__76000026")

var Lit_2 *jrt.String = jrt.Intern("arbace.data$eval76000038$fn__76000039$G__76000031__76000041")

var Lit_3 *jrt.String = jrt.Intern("arbace.data$eval76000038$fn__76000039$G__76000030__76000044")

var Lit_4 *jrt.String = jrt.Intern("equality_partition")

var Lit_5 *jrt.String = jrt.Intern("arbace.data$eval76000060$fn__76000061$G__76000053__76000064")

var Lit_6 *jrt.String = jrt.Intern("arbace.data$eval76000060$fn__76000061$G__76000052__76000068")

var Lit_7 *jrt.String = jrt.Intern("diff_similar")

var Lit_8 *jrt.String = jrt.Intern("arbace.data$vectorize$fn__76000016")

var Lit_9 *jrt.String = jrt.Intern("kn6,authorkn3,docyn11,arbace.corekn8,declaredkn4,linekn6,columnkn4,filekn7,privatekn8,arglistsyn1,ayn1,byn1,myn1,kyn2,kskn5,addedyn1,xkn2,onyn29,arbace.data.EqualityPartitionkn12,on-interfacekn4,sigskn18,equality-partitionkn3,tagkn4,namekn3,varkn10,method-mapkn15,method-builderskn8,protocolyn16,arbace.data.Diffkn12,diff-similaryn1,sv11,arbace.core5,in-nsMyn11,arbace.datam4,R0,s15,Stuart HallowayR1,s24,Non-core data functions.m4,R0,s15,Stuart HallowayR1,s24,Non-core data functions.R2,v11,arbace.core20,*warn-on-reflection*v11,arbace.data4,diffm8,R3,TR4,i17,R5,i1,R6,s14,arbace/data.aev11,arbace.data9,atom-diffm12,R7,TR8,L1,V2,R9,R10,R1,s25,Internal helper for diff.R4,i19,R5,i1,R6,s14,arbace/data.aev11,arbace.data9,vectorizem12,R7,TR8,L1,V1,R11,R1,s110,Convert an associative-by-numeric-index collection into\n   an equivalent vector, with nil for any missing keysR4,i25,R5,i1,R6,s14,arbace/data.aev11,arbace.data20,diff-associative-keym12,R7,TR8,L1,V3,R9,R10,R12,R1,s58,Diff associative things a and b, comparing only the key k.R4,i35,R5,i1,R6,s14,arbace/data.aev11,arbace.data16,diff-associativem12,R7,TR8,L1,V3,R9,R10,R13,R1,s59,Diff associative things a and b, comparing only keys in ks.R4,i51,R5,i1,R6,s14,arbace/data.aev11,arbace.data15,diff-sequentialm10,R7,TR8,L1,V2,R9,R10,R4,i62,R5,i1,R6,s14,arbace/data.aev11,arbace.data17,EqualityPartitionm8,R14,s3,1.3R4,i69,R5,i1,R6,s14,arbace/data.aem8,R14,s3,1.3R4,i69,R5,i1,R6,s14,arbace/data.aeC29,arbace.data.EqualityPartitionv11,arbace.core11,alter-meta!v11,arbace.core5,assocR1,v11,arbace.core20,assert-same-protocolL1,Myn18,equality-partitionm4,R1,s41,Implementation detail. Subject to change.R8,L1,V1,R15,v11,arbace.core14,alter-var-rootv11,arbace.core5,mergem6,R16,R17,R18,C29,arbace.data.EqualityPartitionR1,s41,Implementation detail. Subject to change.R19,m2,R20,m10,R14,s3,1.3R21,nR22,Myn18,equality-partitionm4,R1,s41,Implementation detail. Subject to change.R8,L1,V1,R15,R8,L1,V1,R15,R1,s41,Implementation detail. Subject to change.R23,R24,m2,R20,R20,R25,v11,arbace.core6,internv11,arbace.core4,*ns*v11,arbace.core9,with-metaMyn18,equality-partitionm4,R1,s41,Implementation detail. Subject to change.R8,L1,V1,R15,m10,R14,s3,1.3R21,nR22,Myn18,equality-partitionm4,R1,s41,Implementation detail. Subject to change.R8,L1,V1,R15,R8,L1,V1,R15,R1,s41,Implementation detail. Subject to change.R26,v11,arbace.core14,-reset-methodsMyn17,EqualityPartitionm2,R14,s3,1.3v11,arbace.data4,Diffm8,R14,s3,1.3R4,i73,R5,i1,R6,s14,arbace/data.aem8,R14,s3,1.3R4,i73,R5,i1,R6,s14,arbace/data.aeC16,arbace.data.DiffL1,Myn12,diff-similarm4,R1,s41,Implementation detail. Subject to change.R8,L1,V2,R9,R10,m6,R16,R27,R18,C16,arbace.data.DiffR1,s41,Implementation detail. Subject to change.m2,R28,m10,R14,s3,1.3R21,nR22,Myn12,diff-similarm4,R1,s41,Implementation detail. Subject to change.R8,L1,V2,R9,R10,R8,L1,V2,R9,R10,R1,s41,Implementation detail. Subject to change.m2,R28,R28,Myn12,diff-similarm4,R1,s41,Implementation detail. Subject to change.R8,L1,V2,R9,R10,m10,R14,s3,1.3R21,nR22,Myn12,diff-similarm4,R1,s41,Implementation detail. Subject to change.R8,L1,V2,R9,R10,R8,L1,V2,R9,R10,R1,s41,Implementation detail. Subject to change.Myn4,Diffm2,R14,s3,1.3v11,arbace.core6,extendR28,C16,java.lang.ObjectR20,C13,java.util.SetC14,java.util.ListC13,java.util.Mapv11,arbace.data12,as-set-valuem10,R7,TR8,L1,V1,R29,R4,i102,R5,i1,R6,s14,arbace/data.aem12,R8,L1,V2,R9,R10,R1,s472,Recursively compares a and b, returning a tuple of\n  [things-only-in-a things-only-in-b things-in-both].\n  Comparison rules:\n\n  * For equal a and b, return [nil nil a].\n  * Maps are subdiffed where keys match and values differ.\n  * Sets are never subdiffed.\n  * All sequential things are treated as associative collections\n    by their indexes, with results returned as vectors.\n  * Everything else (including strings!) is treated as\n    an atom and compared for equality.R14,s3,1.3R4,i124,R5,i1,R6,s14,arbace/data.ae")

var Lit_10 *jrt.String = jrt.Intern("arbace.data$eval76000004$loading__1927001464__auto____76000005")

var Lit_11 *jrt.String = jrt.Intern("arbace.data$eval76000008$fn__76000009")

var Lit_12 *jrt.String = jrt.Intern("arbace.data$atom_diff")

var Lit_13 *jrt.String = jrt.Intern("arbace.data$vectorize")

var Lit_14 *jrt.String = jrt.Intern("arbace.data$diff_associative_key")

var Lit_15 *jrt.String = jrt.Intern("arbace.data$diff_associative")

var Lit_16 *jrt.String = jrt.Intern("arbace.data$diff_sequential")

var Lit_17 *jrt.String = jrt.Intern("Implementation detail. Subject to change.")

var Lit_18 *jrt.String = jrt.Intern("arbace.data$eval76000038$fn__76000039")

var Lit_19 *jrt.String = jrt.Intern("arbace.data$eval76000060$fn__76000061")

var Lit_20 *jrt.String = jrt.Intern("arbace.data$eval76000078$fn__76000079")

var Lit_21 *jrt.String = jrt.Intern("arbace.data$eval76000078$fn__76000081")

var Lit_22 *jrt.String = jrt.Intern("arbace.data$eval76000084$fn__76000085")

var Lit_23 *jrt.String = jrt.Intern("arbace.data$eval76000088$fn__76000089")

var Lit_24 *jrt.String = jrt.Intern("arbace.data$eval76000092$fn__76000093")

var Lit_25 *jrt.String = jrt.Intern("arbace.data$eval76000096$fn__76000097")

var Lit_26 *jrt.String = jrt.Intern("arbace.data$as_set_value")

var Lit_27 *jrt.String = jrt.Intern("arbace.data$eval76000101$fn__76000102")

var Lit_28 *jrt.String = jrt.Intern("arbace.data$eval76000105$fn__76000106")

var Lit_29 *jrt.String = jrt.Intern("arbace.data$eval76000109$fn__76000110")

var Lit_30 *jrt.String = jrt.Intern("arbace.data$diff")
