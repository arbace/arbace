//line a2g_strings.ae:1
package aot_arbace_data

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.set")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("set")

var Lit_6 *jrt.String = jrt.Intern("commute")

var Lit_7 *jrt.String = jrt.Intern("deref")

var Lit_8 *jrt.String = jrt.Intern("conj")

var Lit_9 *jrt.String = jrt.Intern("arbace.data")

var Lit_10 *jrt.String = jrt.Intern("author")

var Lit_11 *jrt.String = jrt.Intern("Stuart Halloway")

var Lit_12 *jrt.String = jrt.Intern("doc")

var Lit_13 *jrt.String = jrt.Intern("Non-core data functions.")

var Lit_14 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_15 *jrt.String = jrt.Intern("seq")

var Lit_16 *jrt.String = jrt.Intern("reduce")

var Lit_17 *jrt.String = jrt.Intern("assoc")

var Lit_18 *jrt.String = jrt.Intern("vec")

var Lit_19 *jrt.String = jrt.Intern("repeat")

var Lit_20 *jrt.String = jrt.Intern("apply")

var Lit_21 *jrt.String = jrt.Intern("max")

var Lit_22 *jrt.String = jrt.Intern("keys")

var Lit_23 *jrt.String = jrt.Intern("diff")

var Lit_24 *jrt.String = jrt.Intern("contains?")

var Lit_25 *jrt.String = jrt.Intern("not")

var Lit_26 *jrt.String = jrt.Intern("doall")

var Lit_27 *jrt.String = jrt.Intern("map")

var Lit_28 *jrt.String = jrt.Intern("merge")

var Lit_29 *jrt.String = jrt.Intern("partial")

var Lit_30 *jrt.String = jrt.Intern("diff-associative-key")

var Lit_31 *jrt.String = jrt.Intern("vectorize")

var Lit_32 *jrt.String = jrt.Intern("diff-associative")

var Lit_33 *jrt.String = jrt.Intern("vector?")

var Lit_34 *jrt.String = jrt.Intern("range")

var Lit_35 *jrt.String = jrt.Intern("-cache-protocol-fn")

var Lit_36 *jrt.String = jrt.Intern("arbace.data.EqualityPartition")

var Lit_37 *jrt.String = jrt.Intern("arbace.data.Diff")

var Lit_38 *jrt.String = jrt.Intern("diff-sequential")

var Lit_39 *jrt.String = jrt.Intern("atom-diff")

var Lit_40 *jrt.String = jrt.Intern("sequential")

var Lit_41 *jrt.String = jrt.Intern("atom")

var Lit_42 *jrt.String = jrt.Intern("set?")

var Lit_43 *jrt.String = jrt.Intern("into")

var Lit_44 *jrt.String = jrt.Intern("as-set-value")

var Lit_45 *jrt.String = jrt.Intern("not-empty")

var Lit_46 *jrt.String = jrt.Intern("difference")

var Lit_47 *jrt.String = jrt.Intern("intersection")

var Lit_48 *jrt.String = jrt.Intern("union")

var Lit_49 *jrt.String = jrt.Intern("equality-partition")

var Lit_50 *jrt.String = jrt.Intern("diff-similar")

var Lit_51 *jrt.String = jrt.Intern("arbace.data$as_set_value")

var Lit_52 *jrt.String = jrt.Intern("arbace.data$atom_diff")

var Lit_53 *jrt.String = jrt.Intern("arbace.data$diff")

var Lit_54 *jrt.String = jrt.Intern("arbace.data$diff_associative")

var Lit_55 *jrt.String = jrt.Intern("arbace.data$diff_associative$fn__76000026")

var Lit_56 *jrt.String = jrt.Intern("arbace.data$diff_associative_key")

var Lit_57 *jrt.String = jrt.Intern("arbace.data$diff_sequential")

var Lit_58 *jrt.String = jrt.Intern("arbace.data$eval76000004$loading__1927001464__auto____76000005")

var Lit_59 *jrt.String = jrt.Intern("arbace.data$eval76000008$fn__76000009")

var Lit_60 *jrt.String = jrt.Intern("arbace.data$eval76000038$fn__76000039")

var Lit_61 *jrt.String = jrt.Intern("arbace.data$eval76000038$fn__76000039$G__76000030__76000044")

var Lit_62 *jrt.String = jrt.Intern("arbace.data$eval76000038$fn__76000039$G__76000031__76000041")

var Lit_63 *jrt.String = jrt.Intern("equality_partition")

var Lit_64 *jrt.String = jrt.Intern("arbace.data$eval76000060$fn__76000061")

var Lit_65 *jrt.String = jrt.Intern("arbace.data$eval76000060$fn__76000061$G__76000052__76000068")

var Lit_66 *jrt.String = jrt.Intern("arbace.data$eval76000060$fn__76000061$G__76000053__76000064")

var Lit_67 *jrt.String = jrt.Intern("diff_similar")

var Lit_68 *jrt.String = jrt.Intern("arbace.data$eval76000078$fn__76000079")

var Lit_69 *jrt.String = jrt.Intern("arbace.data$eval76000078$fn__76000081")

var Lit_70 *jrt.String = jrt.Intern("arbace.data$eval76000084$fn__76000085")

var Lit_71 *jrt.String = jrt.Intern("arbace.data$eval76000088$fn__76000089")

var Lit_72 *jrt.String = jrt.Intern("arbace.data$eval76000092$fn__76000093")

var Lit_73 *jrt.String = jrt.Intern("arbace.data$eval76000096$fn__76000097")

var Lit_74 *jrt.String = jrt.Intern("arbace.data$eval76000101$fn__76000102")

var Lit_75 *jrt.String = jrt.Intern("arbace.data$eval76000105$fn__76000106")

var Lit_76 *jrt.String = jrt.Intern("arbace.data$eval76000109$fn__76000110")

var Lit_77 *jrt.String = jrt.Intern("arbace.data$vectorize")

var Lit_78 *jrt.String = jrt.Intern("arbace.data$vectorize$fn__76000016")

var Lit_79 *jrt.String = jrt.Intern("in-ns")

var Lit_80 *jrt.String = jrt.Intern("*warn-on-reflection*")

var Lit_81 *jrt.String = jrt.Intern("declared")

var Lit_82 *jrt.String = jrt.Intern("line")

var Lit_83 *jrt.String = jrt.Intern("column")

var Lit_84 *jrt.String = jrt.Intern("file")

var Lit_85 *jrt.String = jrt.Intern("arbace/data.ae")

var Lit_86 *jrt.String = jrt.Intern("private")

var Lit_87 *jrt.String = jrt.Intern("arglists")

var Lit_88 *jrt.String = jrt.Intern("a")

var Lit_89 *jrt.String = jrt.Intern("b")

var Lit_90 *jrt.String = jrt.Intern("Internal helper for diff.")

var Lit_91 *jrt.String = jrt.Intern("m")

var Lit_92 *jrt.String = jrt.Intern("Convert an associative-by-numeric-index collection into\n   an equivalent vector, with nil for any missing keys")

var Lit_93 *jrt.String = jrt.Intern("k")

var Lit_94 *jrt.String = jrt.Intern("Diff associative things a and b, comparing only the key k.")

var Lit_95 *jrt.String = jrt.Intern("ks")

var Lit_96 *jrt.String = jrt.Intern("Diff associative things a and b, comparing only keys in ks.")

var Lit_97 *jrt.String = jrt.Intern("EqualityPartition")

var Lit_98 *jrt.String = jrt.Intern("added")

var Lit_99 *jrt.String = jrt.Intern("1.3")

var Lit_100 *jrt.String = jrt.Intern("alter-meta!")

var Lit_101 *jrt.String = jrt.Intern("assert-same-protocol")

var Lit_102 *jrt.String = jrt.Intern("Implementation detail. Subject to change.")

var Lit_103 *jrt.String = jrt.Intern("x")

var Lit_104 *jrt.String = jrt.Intern("alter-var-root")

var Lit_105 *jrt.String = jrt.Intern("on")

var Lit_106 *jrt.String = jrt.Intern("on-interface")

var Lit_107 *jrt.String = jrt.Intern("sigs")

var Lit_108 *jrt.String = jrt.Intern("tag")

var Lit_109 *jrt.String = jrt.Intern("name")

var Lit_110 *jrt.String = jrt.Intern("var")

var Lit_111 *jrt.String = jrt.Intern("method-map")

var Lit_112 *jrt.String = jrt.Intern("method-builders")

var Lit_113 *jrt.String = jrt.Intern("intern")

var Lit_114 *jrt.String = jrt.Intern("*ns*")

var Lit_115 *jrt.String = jrt.Intern("with-meta")

var Lit_116 *jrt.String = jrt.Intern("protocol")

var Lit_117 *jrt.String = jrt.Intern("-reset-methods")

var Lit_118 *jrt.String = jrt.Intern("Diff")

var Lit_119 *jrt.String = jrt.Intern("extend")

var Lit_120 *jrt.String = jrt.Intern("java.lang.Object")

var Lit_121 *jrt.String = jrt.Intern("java.util.Set")

var Lit_122 *jrt.String = jrt.Intern("java.util.List")

var Lit_123 *jrt.String = jrt.Intern("java.util.Map")

var Lit_124 *jrt.String = jrt.Intern("s")

var Lit_125 *jrt.String = jrt.Intern("Recursively compares a and b, returning a tuple of\n  [things-only-in-a things-only-in-b things-in-both].\n  Comparison rules:\n\n  * For equal a and b, return [nil nil a].\n  * Maps are subdiffed where keys match and values differ.\n  * Sets are never subdiffed.\n  * All sequential things are treated as associative collections\n    by their indexes, with results returned as vectors.\n  * Everything else (including strings!) is treated as\n    an atom and compared for equality.")
