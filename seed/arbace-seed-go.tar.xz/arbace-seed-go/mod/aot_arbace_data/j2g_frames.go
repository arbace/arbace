//line j2g_frames.ae:1
package aot_arbace_data

import "arbace/jrt"


func init() { jrt.RegisterFrames([]jrt.FrameInfo{{"arbace/aot_arbace_data.A_arbace_data_Diff_A_Diff_similar_O__O", "arbace.data.Diff", "diff_similar", 0}, {"arbace/aot_arbace_data.A_arbace_data_EqualityPartition_A_Equality_partition__O", "arbace.data.EqualityPartition", "equality_partition", 0}}) }
