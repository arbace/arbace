//line a2g_classes.ae:1
package aot_arbace_data

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_data_as_set_value_A_class, Name: "arbace.data$as_set_value", Modifiers: 25, Simple: "as_set_value", Go: "arbace/aot_arbace_data.A_arbace_data_as_set_value_A", Source: "data.ae", Declaring: &A_arbace_data_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_data_atom_diff_A_class, Name: "arbace.data$atom_diff", Modifiers: 25, Simple: "atom_diff", Go: "arbace/aot_arbace_data.A_arbace_data_atom_diff_A", Source: "data.ae", Declaring: &A_arbace_data_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_data_diff_A_class, Name: "arbace.data$diff", Modifiers: 25, Simple: "diff", Go: "arbace/aot_arbace_data.A_arbace_data_diff_A", Source: "data.ae", Declaring: &A_arbace_data_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_data_diff_associative_A_class, Name: "arbace.data$diff_associative", Modifiers: 25, Simple: "diff_associative", Go: "arbace/aot_arbace_data.A_arbace_data_diff_associative_A", Source: "data.ae", Declaring: &A_arbace_data_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_data_diff_associative_fn__76000026_A_class, Name: "arbace.data$diff_associative$fn__76000026", Modifiers: 25, Simple: "fn__76000026", Go: "arbace/aot_arbace_data.A_arbace_data_diff_associative_fn__76000026_A", Source: "data.ae", Declaring: &A_arbace_data_diff_associative_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_data_diff_associative_key_A_class, Name: "arbace.data$diff_associative_key", Modifiers: 25, Simple: "diff_associative_key", Go: "arbace/aot_arbace_data.A_arbace_data_diff_associative_key_A", Source: "data.ae", Declaring: &A_arbace_data_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_data_diff_sequential_A_class, Name: "arbace.data$diff_sequential", Modifiers: 25, Simple: "diff_sequential", Go: "arbace/aot_arbace_data.A_arbace_data_diff_sequential_A", Source: "data.ae", Declaring: &A_arbace_data_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_class, Name: "arbace.data$eval76000004$loading__1927001464__auto____76000005", Modifiers: 25, Simple: "loading__1927001464__auto____76000005", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A", Source: "data.ae", Declaring: &A_arbace_data_eval76000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_data_eval76000008_fn__76000009_A_class, Name: "arbace.data$eval76000008$fn__76000009", Modifiers: 25, Simple: "fn__76000009", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000008_fn__76000009_A", Source: "data.ae", Declaring: &A_arbace_data_eval76000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_data_eval76000038_fn__76000039_A_class, Name: "arbace.data$eval76000038$fn__76000039", Modifiers: 25, Simple: "fn__76000039", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000038_fn__76000039_A", Source: "data.ae", Declaring: &A_arbace_data_eval76000038_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_class, Name: "arbace.data$eval76000038$fn__76000039$G__76000030__76000044", Modifiers: 25, Simple: "G__76000030__76000044", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A", Source: "data.ae", Declaring: &A_arbace_data_eval76000038_fn__76000039_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_class, Name: "arbace.data$eval76000038$fn__76000039$G__76000031__76000041", Modifiers: 25, Simple: "G__76000031__76000041", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A", Source: "data.ae", Declaring: &A_arbace_data_eval76000038_fn__76000039_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_data_eval76000060_fn__76000061_A_class, Name: "arbace.data$eval76000060$fn__76000061", Modifiers: 25, Simple: "fn__76000061", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000060_fn__76000061_A", Source: "data.ae", Declaring: &A_arbace_data_eval76000060_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_class, Name: "arbace.data$eval76000060$fn__76000061$G__76000052__76000068", Modifiers: 25, Simple: "G__76000052__76000068", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A", Source: "data.ae", Declaring: &A_arbace_data_eval76000060_fn__76000061_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_class, Name: "arbace.data$eval76000060$fn__76000061$G__76000053__76000064", Modifiers: 25, Simple: "G__76000053__76000064", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A", Source: "data.ae", Declaring: &A_arbace_data_eval76000060_fn__76000061_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_data_eval76000078_fn__76000079_A_class, Name: "arbace.data$eval76000078$fn__76000079", Modifiers: 25, Simple: "fn__76000079", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000078_fn__76000079_A", Source: "data.ae", Declaring: &A_arbace_data_eval76000078_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_data_eval76000078_fn__76000081_A_class, Name: "arbace.data$eval76000078$fn__76000081", Modifiers: 25, Simple: "fn__76000081", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000078_fn__76000081_A", Source: "data.ae", Declaring: &A_arbace_data_eval76000078_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_data_eval76000084_fn__76000085_A_class, Name: "arbace.data$eval76000084$fn__76000085", Modifiers: 25, Simple: "fn__76000085", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000084_fn__76000085_A", Source: "data.ae", Declaring: &A_arbace_data_eval76000084_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_data_eval76000088_fn__76000089_A_class, Name: "arbace.data$eval76000088$fn__76000089", Modifiers: 25, Simple: "fn__76000089", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000088_fn__76000089_A", Source: "data.ae", Declaring: &A_arbace_data_eval76000088_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_data_eval76000092_fn__76000093_A_class, Name: "arbace.data$eval76000092$fn__76000093", Modifiers: 25, Simple: "fn__76000093", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000092_fn__76000093_A", Source: "data.ae", Declaring: &A_arbace_data_eval76000092_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_data_eval76000096_fn__76000097_A_class, Name: "arbace.data$eval76000096$fn__76000097", Modifiers: 25, Simple: "fn__76000097", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000096_fn__76000097_A", Source: "data.ae", Declaring: &A_arbace_data_eval76000096_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_data_eval76000101_fn__76000102_A_class, Name: "arbace.data$eval76000101$fn__76000102", Modifiers: 25, Simple: "fn__76000102", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000101_fn__76000102_A", Source: "data.ae", Declaring: &A_arbace_data_eval76000101_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_data_eval76000105_fn__76000106_A_class, Name: "arbace.data$eval76000105$fn__76000106", Modifiers: 25, Simple: "fn__76000106", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000105_fn__76000106_A", Source: "data.ae", Declaring: &A_arbace_data_eval76000105_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_data_eval76000109_fn__76000110_A_class, Name: "arbace.data$eval76000109$fn__76000110", Modifiers: 25, Simple: "fn__76000110", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000109_fn__76000110_A", Source: "data.ae", Declaring: &A_arbace_data_eval76000109_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_data_vectorize_A_class, Name: "arbace.data$vectorize", Modifiers: 25, Simple: "vectorize", Go: "arbace/aot_arbace_data.A_arbace_data_vectorize_A", Source: "data.ae", Declaring: &A_arbace_data_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_data_vectorize_fn__76000016_A_class, Name: "arbace.data$vectorize$fn__76000016", Modifiers: 25, Simple: "fn__76000016", Go: "arbace/aot_arbace_data.A_arbace_data_vectorize_fn__76000016_A", Source: "data.ae", Declaring: &A_arbace_data_vectorize_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_data_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_A_New()}; return nil }

var A_arbace_data_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_data_A_new}

var A_arbace_data_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_data.A_arbace_data_A"})

func init() { i := A_arbace_data_A_class.Info(); i.IsInstance = A_arbace_data_A_InstanceOf; i.Init = A_arbace_data_A_Init; i.Table = A_arbace_data_A_members }

var A_arbace_data_as_set_value_A_class *jrt.Class

var A_arbace_data_atom_diff_A_class *jrt.Class

var A_arbace_data_diff_A_class *jrt.Class

var A_arbace_data_diff_associative_A_class *jrt.Class

var A_arbace_data_diff_associative_fn__76000026_A_class *jrt.Class

var A_arbace_data_diff_associative_key_A_class *jrt.Class

var A_arbace_data_diff_sequential_A_class *jrt.Class

func A_arbace_data_eval76000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000004_A_New()}; return nil }

var A_arbace_data_eval76000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_data_eval76000004_A_new}

var A_arbace_data_eval76000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_data_A_class, Simple: "eval76000004", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000004_A"})

func init() { i := A_arbace_data_eval76000004_A_class.Info(); i.IsInstance = A_arbace_data_eval76000004_A_InstanceOf; i.Table = A_arbace_data_eval76000004_A_members }

var A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_class *jrt.Class

func A_arbace_data_eval76000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000008_A_New()}; return nil }

var A_arbace_data_eval76000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_data_eval76000008_A_new}

var A_arbace_data_eval76000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_data_A_class, Simple: "eval76000008", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000008_A"})

func init() { i := A_arbace_data_eval76000008_A_class.Info(); i.IsInstance = A_arbace_data_eval76000008_A_InstanceOf; i.Table = A_arbace_data_eval76000008_A_members }

var A_arbace_data_eval76000008_fn__76000009_A_class *jrt.Class

func A_arbace_data_eval76000038_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000038_A_New()}; return nil }

var A_arbace_data_eval76000038_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_data_eval76000038_A_new}

var A_arbace_data_eval76000038_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000038", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_data_A_class, Simple: "eval76000038", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000038_A"})

func init() { i := A_arbace_data_eval76000038_A_class.Info(); i.IsInstance = A_arbace_data_eval76000038_A_InstanceOf; i.Table = A_arbace_data_eval76000038_A_members }

var A_arbace_data_eval76000038_fn__76000039_A_class *jrt.Class

var A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_class *jrt.Class

var A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_class *jrt.Class

func A_arbace_data_eval76000060_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000060_A_New()}; return nil }

var A_arbace_data_eval76000060_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_data_eval76000060_A_new}

var A_arbace_data_eval76000060_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000060", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_data_A_class, Simple: "eval76000060", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000060_A"})

func init() { i := A_arbace_data_eval76000060_A_class.Info(); i.IsInstance = A_arbace_data_eval76000060_A_InstanceOf; i.Table = A_arbace_data_eval76000060_A_members }

var A_arbace_data_eval76000060_fn__76000061_A_class *jrt.Class

var A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_class *jrt.Class

var A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_class *jrt.Class

func A_arbace_data_eval76000078_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000078_A_New()}; return nil }

var A_arbace_data_eval76000078_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_data_eval76000078_A_new}

var A_arbace_data_eval76000078_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000078", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_data_A_class, Simple: "eval76000078", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000078_A"})

func init() { i := A_arbace_data_eval76000078_A_class.Info(); i.IsInstance = A_arbace_data_eval76000078_A_InstanceOf; i.Table = A_arbace_data_eval76000078_A_members }

var A_arbace_data_eval76000078_fn__76000079_A_class *jrt.Class

var A_arbace_data_eval76000078_fn__76000081_A_class *jrt.Class

func A_arbace_data_eval76000084_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000084_A_New()}; return nil }

var A_arbace_data_eval76000084_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_data_eval76000084_A_new}

var A_arbace_data_eval76000084_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000084", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_data_A_class, Simple: "eval76000084", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000084_A"})

func init() { i := A_arbace_data_eval76000084_A_class.Info(); i.IsInstance = A_arbace_data_eval76000084_A_InstanceOf; i.Table = A_arbace_data_eval76000084_A_members }

var A_arbace_data_eval76000084_fn__76000085_A_class *jrt.Class

func A_arbace_data_eval76000088_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000088_A_New()}; return nil }

var A_arbace_data_eval76000088_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_data_eval76000088_A_new}

var A_arbace_data_eval76000088_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000088", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_data_A_class, Simple: "eval76000088", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000088_A"})

func init() { i := A_arbace_data_eval76000088_A_class.Info(); i.IsInstance = A_arbace_data_eval76000088_A_InstanceOf; i.Table = A_arbace_data_eval76000088_A_members }

var A_arbace_data_eval76000088_fn__76000089_A_class *jrt.Class

func A_arbace_data_eval76000092_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000092_A_New()}; return nil }

var A_arbace_data_eval76000092_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_data_eval76000092_A_new}

var A_arbace_data_eval76000092_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000092", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_data_A_class, Simple: "eval76000092", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000092_A"})

func init() { i := A_arbace_data_eval76000092_A_class.Info(); i.IsInstance = A_arbace_data_eval76000092_A_InstanceOf; i.Table = A_arbace_data_eval76000092_A_members }

var A_arbace_data_eval76000092_fn__76000093_A_class *jrt.Class

func A_arbace_data_eval76000096_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000096_A_New()}; return nil }

var A_arbace_data_eval76000096_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_data_eval76000096_A_new}

var A_arbace_data_eval76000096_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000096", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_data_A_class, Simple: "eval76000096", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000096_A"})

func init() { i := A_arbace_data_eval76000096_A_class.Info(); i.IsInstance = A_arbace_data_eval76000096_A_InstanceOf; i.Table = A_arbace_data_eval76000096_A_members }

var A_arbace_data_eval76000096_fn__76000097_A_class *jrt.Class

func A_arbace_data_eval76000101_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000101_A_New()}; return nil }

var A_arbace_data_eval76000101_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_data_eval76000101_A_new}

var A_arbace_data_eval76000101_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000101", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_data_A_class, Simple: "eval76000101", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000101_A"})

func init() { i := A_arbace_data_eval76000101_A_class.Info(); i.IsInstance = A_arbace_data_eval76000101_A_InstanceOf; i.Table = A_arbace_data_eval76000101_A_members }

var A_arbace_data_eval76000101_fn__76000102_A_class *jrt.Class

func A_arbace_data_eval76000105_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000105_A_New()}; return nil }

var A_arbace_data_eval76000105_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_data_eval76000105_A_new}

var A_arbace_data_eval76000105_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000105", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_data_A_class, Simple: "eval76000105", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000105_A"})

func init() { i := A_arbace_data_eval76000105_A_class.Info(); i.IsInstance = A_arbace_data_eval76000105_A_InstanceOf; i.Table = A_arbace_data_eval76000105_A_members }

var A_arbace_data_eval76000105_fn__76000106_A_class *jrt.Class

func A_arbace_data_eval76000109_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000109_A_New()}; return nil }

var A_arbace_data_eval76000109_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_data_eval76000109_A_new}

var A_arbace_data_eval76000109_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000109", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_data_A_class, Simple: "eval76000109", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000109_A"})

func init() { i := A_arbace_data_eval76000109_A_class.Info(); i.IsInstance = A_arbace_data_eval76000109_A_InstanceOf; i.Table = A_arbace_data_eval76000109_A_members }

var A_arbace_data_eval76000109_fn__76000110_A_class *jrt.Class

var A_arbace_data_vectorize_A_class *jrt.Class

var A_arbace_data_vectorize_fn__76000016_A_class *jrt.Class

func A_arbace_data_Diff_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(A_arbace_data_Diff_A).Diff_similar_O__O(args[0])}; return nil }

var A_arbace_data_Diff_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1025 diff_similar (Ljava.lang.Object;)Ljava.lang.Object;", Invoke: A_arbace_data_Diff_A_invoke}

var A_arbace_data_Diff_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data.Diff", Modifiers: 1537, Kind: jrt.KindInterface, Go: "arbace/aot_arbace_data.A_arbace_data_Diff_A"})

func init() { i := A_arbace_data_Diff_A_class.Info(); i.IsInstance = A_arbace_data_Diff_A_InstanceOf; i.Table = A_arbace_data_Diff_A_members }

func A_arbace_data_EqualityPartition_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(A_arbace_data_EqualityPartition_A).Equality_partition__O()}; return nil }

var A_arbace_data_EqualityPartition_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1025 equality_partition ()Ljava.lang.Object;", Invoke: A_arbace_data_EqualityPartition_A_invoke}

var A_arbace_data_EqualityPartition_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data.EqualityPartition", Modifiers: 1537, Kind: jrt.KindInterface, Go: "arbace/aot_arbace_data.A_arbace_data_EqualityPartition_A"})

func init() { i := A_arbace_data_EqualityPartition_A_class.Info(); i.IsInstance = A_arbace_data_EqualityPartition_A_InstanceOf; i.Table = A_arbace_data_EqualityPartition_A_members }

func A_arbace_data__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_data__init_A_Load__O()}; return nil }

func A_arbace_data__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data__init_A_New()}; return nil }

var A_arbace_data__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_data__init_A_invoke, New: A_arbace_data__init_A_new}

var A_arbace_data__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_data.A_arbace_data__init_A", Source: "data.ae"})

func init() { i := A_arbace_data__init_A_class.Info(); i.IsInstance = A_arbace_data__init_A_InstanceOf; i.Init = A_arbace_data__init_A_Init; i.Table = A_arbace_data__init_A_members }
