//line a2g_classes.ae:1
package aot_arbace_data

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_data_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_A_New()}; return nil }

var A_arbace_data_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_data_A_new}

var A_arbace_data_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_data.A_arbace_data_A"})

func init() { i := A_arbace_data_A_class.Info(); i.IsInstance = A_arbace_data_A_InstanceOf; i.Init = A_arbace_data_A_Init; i.Table = A_arbace_data_A_members; jrt.RegisterGoType(A_arbace_data_A_class, reflect.TypeFor[A_arbace_data_A]()) }

func A_arbace_data_as_set_value_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_data_as_set_value_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_data_as_set_value_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_as_set_value_A_New()}; return nil }

func A_arbace_data_as_set_value_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_data_as_set_value_A_fn_class)}; return nil }

var A_arbace_data_as_set_value_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_data_as_set_value_A_invoke, New: A_arbace_data_as_set_value_A_new, Get: A_arbace_data_as_set_value_A_get}

var A_arbace_data_as_set_value_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$as_set_value", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_data_A_class, Simple: "as_set_value", Go: "arbace/aot_arbace_data.A_arbace_data_as_set_value_A", Source: "data.ae"})

func init() { i := A_arbace_data_as_set_value_A_class.Info(); i.IsInstance = A_arbace_data_as_set_value_A_InstanceOf; i.Init = A_arbace_data_as_set_value_A_Init; i.Table = A_arbace_data_as_set_value_A_members; jrt.RegisterGoType(A_arbace_data_as_set_value_A_class, reflect.TypeFor[A_arbace_data_as_set_value_A]()) }

func A_arbace_data_atom_diff_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_data_atom_diff_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_data_atom_diff_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_atom_diff_A_New()}; return nil }

func A_arbace_data_atom_diff_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_data_atom_diff_A_fn_class)}; return nil }

var A_arbace_data_atom_diff_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_data_atom_diff_A_invoke, New: A_arbace_data_atom_diff_A_new, Get: A_arbace_data_atom_diff_A_get}

var A_arbace_data_atom_diff_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$atom_diff", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_data_A_class, Simple: "atom_diff", Go: "arbace/aot_arbace_data.A_arbace_data_atom_diff_A", Source: "data.ae"})

func init() { i := A_arbace_data_atom_diff_A_class.Info(); i.IsInstance = A_arbace_data_atom_diff_A_InstanceOf; i.Init = A_arbace_data_atom_diff_A_Init; i.Table = A_arbace_data_atom_diff_A_members; jrt.RegisterGoType(A_arbace_data_atom_diff_A_class, reflect.TypeFor[A_arbace_data_atom_diff_A]()) }

func A_arbace_data_diff_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_data_diff_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_data_diff_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_diff_A_New()}; return nil }

func A_arbace_data_diff_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_data_diff_A_fn_class)}; return nil }

var A_arbace_data_diff_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_data_diff_A_invoke, New: A_arbace_data_diff_A_new, Get: A_arbace_data_diff_A_get}

var A_arbace_data_diff_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$diff", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_data_A_class, Simple: "diff", Go: "arbace/aot_arbace_data.A_arbace_data_diff_A", Source: "data.ae"})

func init() { i := A_arbace_data_diff_A_class.Info(); i.IsInstance = A_arbace_data_diff_A_InstanceOf; i.Init = A_arbace_data_diff_A_Init; i.Table = A_arbace_data_diff_A_members; jrt.RegisterGoType(A_arbace_data_diff_A_class, reflect.TypeFor[A_arbace_data_diff_A]()) }

func A_arbace_data_diff_associative_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_data_diff_associative_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_data_diff_associative_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_diff_associative_A_New()}; return nil }

func A_arbace_data_diff_associative_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_data_diff_associative_A_fn_class)}; return nil }

var A_arbace_data_diff_associative_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_data_diff_associative_A_invoke, New: A_arbace_data_diff_associative_A_new, Get: A_arbace_data_diff_associative_A_get}

var A_arbace_data_diff_associative_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$diff_associative", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_data_A_class, Simple: "diff_associative", Go: "arbace/aot_arbace_data.A_arbace_data_diff_associative_A", Source: "data.ae"})

func init() { i := A_arbace_data_diff_associative_A_class.Info(); i.IsInstance = A_arbace_data_diff_associative_A_InstanceOf; i.Init = A_arbace_data_diff_associative_A_Init; i.Table = A_arbace_data_diff_associative_A_members; jrt.RegisterGoType(A_arbace_data_diff_associative_A_class, reflect.TypeFor[A_arbace_data_diff_associative_A]()) }

func A_arbace_data_diff_associative_fn__76000026_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_data_diff_associative_fn__76000026_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_data_diff_associative_fn__76000026_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_diff_associative_fn__76000026_A_New()}; return nil }

func A_arbace_data_diff_associative_fn__76000026_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_data_diff_associative_fn__76000026_A_fn_class)}; return nil }

var A_arbace_data_diff_associative_fn__76000026_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_data_diff_associative_fn__76000026_A_invoke, New: A_arbace_data_diff_associative_fn__76000026_A_new, Get: A_arbace_data_diff_associative_fn__76000026_A_get}

var A_arbace_data_diff_associative_fn__76000026_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$diff_associative$fn__76000026", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_data_diff_associative_A_class, Simple: "fn__76000026", Go: "arbace/aot_arbace_data.A_arbace_data_diff_associative_fn__76000026_A", Source: "data.ae"})

func init() { i := A_arbace_data_diff_associative_fn__76000026_A_class.Info(); i.IsInstance = A_arbace_data_diff_associative_fn__76000026_A_InstanceOf; i.Init = A_arbace_data_diff_associative_fn__76000026_A_Init; i.Table = A_arbace_data_diff_associative_fn__76000026_A_members; jrt.RegisterGoType(A_arbace_data_diff_associative_fn__76000026_A_class, reflect.TypeFor[A_arbace_data_diff_associative_fn__76000026_A]()) }

func A_arbace_data_diff_associative_key_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_data_diff_associative_key_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_data_diff_associative_key_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_diff_associative_key_A_New()}; return nil }

func A_arbace_data_diff_associative_key_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_data_diff_associative_key_A_fn_class)}; return nil }

var A_arbace_data_diff_associative_key_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_data_diff_associative_key_A_invoke, New: A_arbace_data_diff_associative_key_A_new, Get: A_arbace_data_diff_associative_key_A_get}

var A_arbace_data_diff_associative_key_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$diff_associative_key", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_data_A_class, Simple: "diff_associative_key", Go: "arbace/aot_arbace_data.A_arbace_data_diff_associative_key_A", Source: "data.ae"})

func init() { i := A_arbace_data_diff_associative_key_A_class.Info(); i.IsInstance = A_arbace_data_diff_associative_key_A_InstanceOf; i.Init = A_arbace_data_diff_associative_key_A_Init; i.Table = A_arbace_data_diff_associative_key_A_members; jrt.RegisterGoType(A_arbace_data_diff_associative_key_A_class, reflect.TypeFor[A_arbace_data_diff_associative_key_A]()) }

func A_arbace_data_diff_sequential_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_data_diff_sequential_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_data_diff_sequential_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_diff_sequential_A_New()}; return nil }

func A_arbace_data_diff_sequential_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_data_diff_sequential_A_fn_class)}; return nil }

var A_arbace_data_diff_sequential_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_data_diff_sequential_A_invoke, New: A_arbace_data_diff_sequential_A_new, Get: A_arbace_data_diff_sequential_A_get}

var A_arbace_data_diff_sequential_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$diff_sequential", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_data_A_class, Simple: "diff_sequential", Go: "arbace/aot_arbace_data.A_arbace_data_diff_sequential_A", Source: "data.ae"})

func init() { i := A_arbace_data_diff_sequential_A_class.Info(); i.IsInstance = A_arbace_data_diff_sequential_A_InstanceOf; i.Init = A_arbace_data_diff_sequential_A_Init; i.Table = A_arbace_data_diff_sequential_A_members; jrt.RegisterGoType(A_arbace_data_diff_sequential_A_class, reflect.TypeFor[A_arbace_data_diff_sequential_A]()) }

func A_arbace_data_eval76000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000004_A_New()}; return nil }

var A_arbace_data_eval76000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_data_eval76000004_A_new}

var A_arbace_data_eval76000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_data_A_class, Simple: "eval76000004", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000004_A"})

func init() { i := A_arbace_data_eval76000004_A_class.Info(); i.IsInstance = A_arbace_data_eval76000004_A_InstanceOf; i.Table = A_arbace_data_eval76000004_A_members; jrt.RegisterGoType(A_arbace_data_eval76000004_A_class, reflect.TypeFor[A_arbace_data_eval76000004_A]()) }

func A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_New()}; return nil }

func A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_fn_class)}; return nil }

var A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_invoke, New: A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_new, Get: A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_get}

var A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000004$loading__1927001464__auto____76000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_data_eval76000004_A_class, Simple: "loading__1927001464__auto____76000005", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A", Source: "data.ae"})

func init() { i := A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_class.Info(); i.IsInstance = A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_InstanceOf; i.Init = A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_Init; i.Table = A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_members; jrt.RegisterGoType(A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_class, reflect.TypeFor[A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A]()) }

func A_arbace_data_eval76000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000008_A_New()}; return nil }

var A_arbace_data_eval76000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_data_eval76000008_A_new}

var A_arbace_data_eval76000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_data_A_class, Simple: "eval76000008", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000008_A"})

func init() { i := A_arbace_data_eval76000008_A_class.Info(); i.IsInstance = A_arbace_data_eval76000008_A_InstanceOf; i.Table = A_arbace_data_eval76000008_A_members; jrt.RegisterGoType(A_arbace_data_eval76000008_A_class, reflect.TypeFor[A_arbace_data_eval76000008_A]()) }

func A_arbace_data_eval76000008_fn__76000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_data_eval76000008_fn__76000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_data_eval76000008_fn__76000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000008_fn__76000009_A_New()}; return nil }

func A_arbace_data_eval76000008_fn__76000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_data_eval76000008_fn__76000009_A_fn_class)}; return nil }

var A_arbace_data_eval76000008_fn__76000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_data_eval76000008_fn__76000009_A_invoke, New: A_arbace_data_eval76000008_fn__76000009_A_new, Get: A_arbace_data_eval76000008_fn__76000009_A_get}

var A_arbace_data_eval76000008_fn__76000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000008$fn__76000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_data_eval76000008_A_class, Simple: "fn__76000009", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000008_fn__76000009_A", Source: "data.ae"})

func init() { i := A_arbace_data_eval76000008_fn__76000009_A_class.Info(); i.IsInstance = A_arbace_data_eval76000008_fn__76000009_A_InstanceOf; i.Init = A_arbace_data_eval76000008_fn__76000009_A_Init; i.Table = A_arbace_data_eval76000008_fn__76000009_A_members; jrt.RegisterGoType(A_arbace_data_eval76000008_fn__76000009_A_class, reflect.TypeFor[A_arbace_data_eval76000008_fn__76000009_A]()) }

func A_arbace_data_eval76000038_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000038_A_New()}; return nil }

var A_arbace_data_eval76000038_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_data_eval76000038_A_new}

var A_arbace_data_eval76000038_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000038", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_data_A_class, Simple: "eval76000038", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000038_A"})

func init() { i := A_arbace_data_eval76000038_A_class.Info(); i.IsInstance = A_arbace_data_eval76000038_A_InstanceOf; i.Table = A_arbace_data_eval76000038_A_members; jrt.RegisterGoType(A_arbace_data_eval76000038_A_class, reflect.TypeFor[A_arbace_data_eval76000038_A]()) }

func A_arbace_data_eval76000038_fn__76000039_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_data_eval76000038_fn__76000039_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_data_eval76000038_fn__76000039_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000038_fn__76000039_A_New()}; return nil }

func A_arbace_data_eval76000038_fn__76000039_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_data_eval76000038_fn__76000039_A_fn_class)}; return nil }

var A_arbace_data_eval76000038_fn__76000039_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_data_eval76000038_fn__76000039_A_invoke, New: A_arbace_data_eval76000038_fn__76000039_A_new, Get: A_arbace_data_eval76000038_fn__76000039_A_get}

var A_arbace_data_eval76000038_fn__76000039_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000038$fn__76000039", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_data_eval76000038_A_class, Simple: "fn__76000039", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000038_fn__76000039_A", Source: "data.ae"})

func init() { i := A_arbace_data_eval76000038_fn__76000039_A_class.Info(); i.IsInstance = A_arbace_data_eval76000038_fn__76000039_A_InstanceOf; i.Init = A_arbace_data_eval76000038_fn__76000039_A_Init; i.Table = A_arbace_data_eval76000038_fn__76000039_A_members; jrt.RegisterGoType(A_arbace_data_eval76000038_fn__76000039_A_class, reflect.TypeFor[A_arbace_data_eval76000038_fn__76000039_A]()) }

func A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_New_O(args[0])}; return nil }

func A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_fn_class)}; return nil }

var A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_invoke, New: A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_new, Get: A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_get}

var A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000038$fn__76000039$G__76000030__76000044", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_data_eval76000038_fn__76000039_A_class, Simple: "G__76000030__76000044", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A", Source: "data.ae"})

func init() { i := A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_class.Info(); i.IsInstance = A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_InstanceOf; i.Init = A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_Init; i.Table = A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_members; jrt.RegisterGoType(A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A_class, reflect.TypeFor[A_arbace_data_eval76000038_fn__76000039_G__76000030__76000044_A]()) }

func A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_New()}; return nil }

func A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_fn_class)}; return nil }

var A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_invoke, New: A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_new, Get: A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_get}

var A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000038$fn__76000039$G__76000031__76000041", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_data_eval76000038_fn__76000039_A_class, Simple: "G__76000031__76000041", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A", Source: "data.ae"})

func init() { i := A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_class.Info(); i.IsInstance = A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_InstanceOf; i.Init = A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_Init; i.Table = A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_members; jrt.RegisterGoType(A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A_class, reflect.TypeFor[A_arbace_data_eval76000038_fn__76000039_G__76000031__76000041_A]()) }

func A_arbace_data_eval76000060_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000060_A_New()}; return nil }

var A_arbace_data_eval76000060_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_data_eval76000060_A_new}

var A_arbace_data_eval76000060_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000060", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_data_A_class, Simple: "eval76000060", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000060_A"})

func init() { i := A_arbace_data_eval76000060_A_class.Info(); i.IsInstance = A_arbace_data_eval76000060_A_InstanceOf; i.Table = A_arbace_data_eval76000060_A_members; jrt.RegisterGoType(A_arbace_data_eval76000060_A_class, reflect.TypeFor[A_arbace_data_eval76000060_A]()) }

func A_arbace_data_eval76000060_fn__76000061_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_data_eval76000060_fn__76000061_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_data_eval76000060_fn__76000061_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000060_fn__76000061_A_New()}; return nil }

func A_arbace_data_eval76000060_fn__76000061_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_data_eval76000060_fn__76000061_A_fn_class)}; return nil }

var A_arbace_data_eval76000060_fn__76000061_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_data_eval76000060_fn__76000061_A_invoke, New: A_arbace_data_eval76000060_fn__76000061_A_new, Get: A_arbace_data_eval76000060_fn__76000061_A_get}

var A_arbace_data_eval76000060_fn__76000061_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000060$fn__76000061", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_data_eval76000060_A_class, Simple: "fn__76000061", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000060_fn__76000061_A", Source: "data.ae"})

func init() { i := A_arbace_data_eval76000060_fn__76000061_A_class.Info(); i.IsInstance = A_arbace_data_eval76000060_fn__76000061_A_InstanceOf; i.Init = A_arbace_data_eval76000060_fn__76000061_A_Init; i.Table = A_arbace_data_eval76000060_fn__76000061_A_members; jrt.RegisterGoType(A_arbace_data_eval76000060_fn__76000061_A_class, reflect.TypeFor[A_arbace_data_eval76000060_fn__76000061_A]()) }

func A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_New_O(args[0])}; return nil }

func A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_fn_class)}; return nil }

var A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_invoke, New: A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_new, Get: A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_get}

var A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000060$fn__76000061$G__76000052__76000068", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_data_eval76000060_fn__76000061_A_class, Simple: "G__76000052__76000068", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A", Source: "data.ae"})

func init() { i := A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_class.Info(); i.IsInstance = A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_InstanceOf; i.Init = A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_Init; i.Table = A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_members; jrt.RegisterGoType(A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A_class, reflect.TypeFor[A_arbace_data_eval76000060_fn__76000061_G__76000052__76000068_A]()) }

func A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_New()}; return nil }

func A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_fn_class)}; return nil }

var A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_invoke, New: A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_new, Get: A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_get}

var A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000060$fn__76000061$G__76000053__76000064", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_data_eval76000060_fn__76000061_A_class, Simple: "G__76000053__76000064", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A", Source: "data.ae"})

func init() { i := A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_class.Info(); i.IsInstance = A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_InstanceOf; i.Init = A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_Init; i.Table = A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_members; jrt.RegisterGoType(A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A_class, reflect.TypeFor[A_arbace_data_eval76000060_fn__76000061_G__76000053__76000064_A]()) }

func A_arbace_data_eval76000078_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000078_A_New()}; return nil }

var A_arbace_data_eval76000078_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_data_eval76000078_A_new}

var A_arbace_data_eval76000078_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000078", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_data_A_class, Simple: "eval76000078", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000078_A"})

func init() { i := A_arbace_data_eval76000078_A_class.Info(); i.IsInstance = A_arbace_data_eval76000078_A_InstanceOf; i.Table = A_arbace_data_eval76000078_A_members; jrt.RegisterGoType(A_arbace_data_eval76000078_A_class, reflect.TypeFor[A_arbace_data_eval76000078_A]()) }

func A_arbace_data_eval76000078_fn__76000079_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_data_eval76000078_fn__76000079_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_data_eval76000078_fn__76000079_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000078_fn__76000079_A_New()}; return nil }

func A_arbace_data_eval76000078_fn__76000079_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_data_eval76000078_fn__76000079_A_fn_class)}; return nil }

var A_arbace_data_eval76000078_fn__76000079_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_data_eval76000078_fn__76000079_A_invoke, New: A_arbace_data_eval76000078_fn__76000079_A_new, Get: A_arbace_data_eval76000078_fn__76000079_A_get}

var A_arbace_data_eval76000078_fn__76000079_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000078$fn__76000079", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_data_eval76000078_A_class, Simple: "fn__76000079", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000078_fn__76000079_A", Source: "data.ae"})

func init() { i := A_arbace_data_eval76000078_fn__76000079_A_class.Info(); i.IsInstance = A_arbace_data_eval76000078_fn__76000079_A_InstanceOf; i.Init = A_arbace_data_eval76000078_fn__76000079_A_Init; i.Table = A_arbace_data_eval76000078_fn__76000079_A_members; jrt.RegisterGoType(A_arbace_data_eval76000078_fn__76000079_A_class, reflect.TypeFor[A_arbace_data_eval76000078_fn__76000079_A]()) }

func A_arbace_data_eval76000078_fn__76000081_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_data_eval76000078_fn__76000081_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_data_eval76000078_fn__76000081_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000078_fn__76000081_A_New()}; return nil }

func A_arbace_data_eval76000078_fn__76000081_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_data_eval76000078_fn__76000081_A_fn_class)}; return nil }

var A_arbace_data_eval76000078_fn__76000081_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_data_eval76000078_fn__76000081_A_invoke, New: A_arbace_data_eval76000078_fn__76000081_A_new, Get: A_arbace_data_eval76000078_fn__76000081_A_get}

var A_arbace_data_eval76000078_fn__76000081_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000078$fn__76000081", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_data_eval76000078_A_class, Simple: "fn__76000081", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000078_fn__76000081_A", Source: "data.ae"})

func init() { i := A_arbace_data_eval76000078_fn__76000081_A_class.Info(); i.IsInstance = A_arbace_data_eval76000078_fn__76000081_A_InstanceOf; i.Init = A_arbace_data_eval76000078_fn__76000081_A_Init; i.Table = A_arbace_data_eval76000078_fn__76000081_A_members; jrt.RegisterGoType(A_arbace_data_eval76000078_fn__76000081_A_class, reflect.TypeFor[A_arbace_data_eval76000078_fn__76000081_A]()) }

func A_arbace_data_eval76000084_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000084_A_New()}; return nil }

var A_arbace_data_eval76000084_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_data_eval76000084_A_new}

var A_arbace_data_eval76000084_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000084", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_data_A_class, Simple: "eval76000084", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000084_A"})

func init() { i := A_arbace_data_eval76000084_A_class.Info(); i.IsInstance = A_arbace_data_eval76000084_A_InstanceOf; i.Table = A_arbace_data_eval76000084_A_members; jrt.RegisterGoType(A_arbace_data_eval76000084_A_class, reflect.TypeFor[A_arbace_data_eval76000084_A]()) }

func A_arbace_data_eval76000084_fn__76000085_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_data_eval76000084_fn__76000085_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_data_eval76000084_fn__76000085_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000084_fn__76000085_A_New()}; return nil }

func A_arbace_data_eval76000084_fn__76000085_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_data_eval76000084_fn__76000085_A_fn_class)}; return nil }

var A_arbace_data_eval76000084_fn__76000085_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_data_eval76000084_fn__76000085_A_invoke, New: A_arbace_data_eval76000084_fn__76000085_A_new, Get: A_arbace_data_eval76000084_fn__76000085_A_get}

var A_arbace_data_eval76000084_fn__76000085_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000084$fn__76000085", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_data_eval76000084_A_class, Simple: "fn__76000085", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000084_fn__76000085_A", Source: "data.ae"})

func init() { i := A_arbace_data_eval76000084_fn__76000085_A_class.Info(); i.IsInstance = A_arbace_data_eval76000084_fn__76000085_A_InstanceOf; i.Init = A_arbace_data_eval76000084_fn__76000085_A_Init; i.Table = A_arbace_data_eval76000084_fn__76000085_A_members; jrt.RegisterGoType(A_arbace_data_eval76000084_fn__76000085_A_class, reflect.TypeFor[A_arbace_data_eval76000084_fn__76000085_A]()) }

func A_arbace_data_eval76000088_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000088_A_New()}; return nil }

var A_arbace_data_eval76000088_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_data_eval76000088_A_new}

var A_arbace_data_eval76000088_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000088", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_data_A_class, Simple: "eval76000088", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000088_A"})

func init() { i := A_arbace_data_eval76000088_A_class.Info(); i.IsInstance = A_arbace_data_eval76000088_A_InstanceOf; i.Table = A_arbace_data_eval76000088_A_members; jrt.RegisterGoType(A_arbace_data_eval76000088_A_class, reflect.TypeFor[A_arbace_data_eval76000088_A]()) }

func A_arbace_data_eval76000088_fn__76000089_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_data_eval76000088_fn__76000089_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_data_eval76000088_fn__76000089_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000088_fn__76000089_A_New()}; return nil }

func A_arbace_data_eval76000088_fn__76000089_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_data_eval76000088_fn__76000089_A_fn_class)}; return nil }

var A_arbace_data_eval76000088_fn__76000089_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_data_eval76000088_fn__76000089_A_invoke, New: A_arbace_data_eval76000088_fn__76000089_A_new, Get: A_arbace_data_eval76000088_fn__76000089_A_get}

var A_arbace_data_eval76000088_fn__76000089_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000088$fn__76000089", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_data_eval76000088_A_class, Simple: "fn__76000089", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000088_fn__76000089_A", Source: "data.ae"})

func init() { i := A_arbace_data_eval76000088_fn__76000089_A_class.Info(); i.IsInstance = A_arbace_data_eval76000088_fn__76000089_A_InstanceOf; i.Init = A_arbace_data_eval76000088_fn__76000089_A_Init; i.Table = A_arbace_data_eval76000088_fn__76000089_A_members; jrt.RegisterGoType(A_arbace_data_eval76000088_fn__76000089_A_class, reflect.TypeFor[A_arbace_data_eval76000088_fn__76000089_A]()) }

func A_arbace_data_eval76000092_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000092_A_New()}; return nil }

var A_arbace_data_eval76000092_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_data_eval76000092_A_new}

var A_arbace_data_eval76000092_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000092", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_data_A_class, Simple: "eval76000092", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000092_A"})

func init() { i := A_arbace_data_eval76000092_A_class.Info(); i.IsInstance = A_arbace_data_eval76000092_A_InstanceOf; i.Table = A_arbace_data_eval76000092_A_members; jrt.RegisterGoType(A_arbace_data_eval76000092_A_class, reflect.TypeFor[A_arbace_data_eval76000092_A]()) }

func A_arbace_data_eval76000092_fn__76000093_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_data_eval76000092_fn__76000093_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_data_eval76000092_fn__76000093_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000092_fn__76000093_A_New()}; return nil }

func A_arbace_data_eval76000092_fn__76000093_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_data_eval76000092_fn__76000093_A_fn_class)}; return nil }

var A_arbace_data_eval76000092_fn__76000093_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_data_eval76000092_fn__76000093_A_invoke, New: A_arbace_data_eval76000092_fn__76000093_A_new, Get: A_arbace_data_eval76000092_fn__76000093_A_get}

var A_arbace_data_eval76000092_fn__76000093_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000092$fn__76000093", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_data_eval76000092_A_class, Simple: "fn__76000093", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000092_fn__76000093_A", Source: "data.ae"})

func init() { i := A_arbace_data_eval76000092_fn__76000093_A_class.Info(); i.IsInstance = A_arbace_data_eval76000092_fn__76000093_A_InstanceOf; i.Init = A_arbace_data_eval76000092_fn__76000093_A_Init; i.Table = A_arbace_data_eval76000092_fn__76000093_A_members; jrt.RegisterGoType(A_arbace_data_eval76000092_fn__76000093_A_class, reflect.TypeFor[A_arbace_data_eval76000092_fn__76000093_A]()) }

func A_arbace_data_eval76000096_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000096_A_New()}; return nil }

var A_arbace_data_eval76000096_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_data_eval76000096_A_new}

var A_arbace_data_eval76000096_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000096", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_data_A_class, Simple: "eval76000096", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000096_A"})

func init() { i := A_arbace_data_eval76000096_A_class.Info(); i.IsInstance = A_arbace_data_eval76000096_A_InstanceOf; i.Table = A_arbace_data_eval76000096_A_members; jrt.RegisterGoType(A_arbace_data_eval76000096_A_class, reflect.TypeFor[A_arbace_data_eval76000096_A]()) }

func A_arbace_data_eval76000096_fn__76000097_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_data_eval76000096_fn__76000097_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_data_eval76000096_fn__76000097_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000096_fn__76000097_A_New()}; return nil }

func A_arbace_data_eval76000096_fn__76000097_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_data_eval76000096_fn__76000097_A_fn_class)}; return nil }

var A_arbace_data_eval76000096_fn__76000097_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_data_eval76000096_fn__76000097_A_invoke, New: A_arbace_data_eval76000096_fn__76000097_A_new, Get: A_arbace_data_eval76000096_fn__76000097_A_get}

var A_arbace_data_eval76000096_fn__76000097_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000096$fn__76000097", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_data_eval76000096_A_class, Simple: "fn__76000097", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000096_fn__76000097_A", Source: "data.ae"})

func init() { i := A_arbace_data_eval76000096_fn__76000097_A_class.Info(); i.IsInstance = A_arbace_data_eval76000096_fn__76000097_A_InstanceOf; i.Init = A_arbace_data_eval76000096_fn__76000097_A_Init; i.Table = A_arbace_data_eval76000096_fn__76000097_A_members; jrt.RegisterGoType(A_arbace_data_eval76000096_fn__76000097_A_class, reflect.TypeFor[A_arbace_data_eval76000096_fn__76000097_A]()) }

func A_arbace_data_eval76000101_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000101_A_New()}; return nil }

var A_arbace_data_eval76000101_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_data_eval76000101_A_new}

var A_arbace_data_eval76000101_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000101", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_data_A_class, Simple: "eval76000101", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000101_A"})

func init() { i := A_arbace_data_eval76000101_A_class.Info(); i.IsInstance = A_arbace_data_eval76000101_A_InstanceOf; i.Table = A_arbace_data_eval76000101_A_members; jrt.RegisterGoType(A_arbace_data_eval76000101_A_class, reflect.TypeFor[A_arbace_data_eval76000101_A]()) }

func A_arbace_data_eval76000101_fn__76000102_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_data_eval76000101_fn__76000102_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_data_eval76000101_fn__76000102_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000101_fn__76000102_A_New()}; return nil }

func A_arbace_data_eval76000101_fn__76000102_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_data_eval76000101_fn__76000102_A_fn_class)}; return nil }

var A_arbace_data_eval76000101_fn__76000102_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_data_eval76000101_fn__76000102_A_invoke, New: A_arbace_data_eval76000101_fn__76000102_A_new, Get: A_arbace_data_eval76000101_fn__76000102_A_get}

var A_arbace_data_eval76000101_fn__76000102_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000101$fn__76000102", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_data_eval76000101_A_class, Simple: "fn__76000102", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000101_fn__76000102_A", Source: "data.ae"})

func init() { i := A_arbace_data_eval76000101_fn__76000102_A_class.Info(); i.IsInstance = A_arbace_data_eval76000101_fn__76000102_A_InstanceOf; i.Init = A_arbace_data_eval76000101_fn__76000102_A_Init; i.Table = A_arbace_data_eval76000101_fn__76000102_A_members; jrt.RegisterGoType(A_arbace_data_eval76000101_fn__76000102_A_class, reflect.TypeFor[A_arbace_data_eval76000101_fn__76000102_A]()) }

func A_arbace_data_eval76000105_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000105_A_New()}; return nil }

var A_arbace_data_eval76000105_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_data_eval76000105_A_new}

var A_arbace_data_eval76000105_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000105", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_data_A_class, Simple: "eval76000105", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000105_A"})

func init() { i := A_arbace_data_eval76000105_A_class.Info(); i.IsInstance = A_arbace_data_eval76000105_A_InstanceOf; i.Table = A_arbace_data_eval76000105_A_members; jrt.RegisterGoType(A_arbace_data_eval76000105_A_class, reflect.TypeFor[A_arbace_data_eval76000105_A]()) }

func A_arbace_data_eval76000105_fn__76000106_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_data_eval76000105_fn__76000106_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_data_eval76000105_fn__76000106_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000105_fn__76000106_A_New()}; return nil }

func A_arbace_data_eval76000105_fn__76000106_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_data_eval76000105_fn__76000106_A_fn_class)}; return nil }

var A_arbace_data_eval76000105_fn__76000106_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_data_eval76000105_fn__76000106_A_invoke, New: A_arbace_data_eval76000105_fn__76000106_A_new, Get: A_arbace_data_eval76000105_fn__76000106_A_get}

var A_arbace_data_eval76000105_fn__76000106_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000105$fn__76000106", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_data_eval76000105_A_class, Simple: "fn__76000106", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000105_fn__76000106_A", Source: "data.ae"})

func init() { i := A_arbace_data_eval76000105_fn__76000106_A_class.Info(); i.IsInstance = A_arbace_data_eval76000105_fn__76000106_A_InstanceOf; i.Init = A_arbace_data_eval76000105_fn__76000106_A_Init; i.Table = A_arbace_data_eval76000105_fn__76000106_A_members; jrt.RegisterGoType(A_arbace_data_eval76000105_fn__76000106_A_class, reflect.TypeFor[A_arbace_data_eval76000105_fn__76000106_A]()) }

func A_arbace_data_eval76000109_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000109_A_New()}; return nil }

var A_arbace_data_eval76000109_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_data_eval76000109_A_new}

var A_arbace_data_eval76000109_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000109", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_data_A_class, Simple: "eval76000109", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000109_A"})

func init() { i := A_arbace_data_eval76000109_A_class.Info(); i.IsInstance = A_arbace_data_eval76000109_A_InstanceOf; i.Table = A_arbace_data_eval76000109_A_members; jrt.RegisterGoType(A_arbace_data_eval76000109_A_class, reflect.TypeFor[A_arbace_data_eval76000109_A]()) }

func A_arbace_data_eval76000109_fn__76000110_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_data_eval76000109_fn__76000110_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_data_eval76000109_fn__76000110_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_eval76000109_fn__76000110_A_New()}; return nil }

func A_arbace_data_eval76000109_fn__76000110_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_data_eval76000109_fn__76000110_A_fn_class)}; return nil }

var A_arbace_data_eval76000109_fn__76000110_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_data_eval76000109_fn__76000110_A_invoke, New: A_arbace_data_eval76000109_fn__76000110_A_new, Get: A_arbace_data_eval76000109_fn__76000110_A_get}

var A_arbace_data_eval76000109_fn__76000110_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$eval76000109$fn__76000110", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_data_eval76000109_A_class, Simple: "fn__76000110", Go: "arbace/aot_arbace_data.A_arbace_data_eval76000109_fn__76000110_A", Source: "data.ae"})

func init() { i := A_arbace_data_eval76000109_fn__76000110_A_class.Info(); i.IsInstance = A_arbace_data_eval76000109_fn__76000110_A_InstanceOf; i.Init = A_arbace_data_eval76000109_fn__76000110_A_Init; i.Table = A_arbace_data_eval76000109_fn__76000110_A_members; jrt.RegisterGoType(A_arbace_data_eval76000109_fn__76000110_A_class, reflect.TypeFor[A_arbace_data_eval76000109_fn__76000110_A]()) }

func A_arbace_data_vectorize_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_data_vectorize_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_data_vectorize_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_vectorize_A_New()}; return nil }

func A_arbace_data_vectorize_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_data_vectorize_A_fn_class)}; return nil }

var A_arbace_data_vectorize_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_data_vectorize_A_invoke, New: A_arbace_data_vectorize_A_new, Get: A_arbace_data_vectorize_A_get}

var A_arbace_data_vectorize_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$vectorize", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_data_A_class, Simple: "vectorize", Go: "arbace/aot_arbace_data.A_arbace_data_vectorize_A", Source: "data.ae"})

func init() { i := A_arbace_data_vectorize_A_class.Info(); i.IsInstance = A_arbace_data_vectorize_A_InstanceOf; i.Init = A_arbace_data_vectorize_A_Init; i.Table = A_arbace_data_vectorize_A_members; jrt.RegisterGoType(A_arbace_data_vectorize_A_class, reflect.TypeFor[A_arbace_data_vectorize_A]()) }

func A_arbace_data_vectorize_fn__76000016_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_data_vectorize_fn__76000016_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_data_vectorize_fn__76000016_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data_vectorize_fn__76000016_A_New()}; return nil }

func A_arbace_data_vectorize_fn__76000016_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_data_vectorize_fn__76000016_A_fn_class)}; return nil }

var A_arbace_data_vectorize_fn__76000016_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_data_vectorize_fn__76000016_A_invoke, New: A_arbace_data_vectorize_fn__76000016_A_new, Get: A_arbace_data_vectorize_fn__76000016_A_get}

var A_arbace_data_vectorize_fn__76000016_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data$vectorize$fn__76000016", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_data_vectorize_A_class, Simple: "fn__76000016", Go: "arbace/aot_arbace_data.A_arbace_data_vectorize_fn__76000016_A", Source: "data.ae"})

func init() { i := A_arbace_data_vectorize_fn__76000016_A_class.Info(); i.IsInstance = A_arbace_data_vectorize_fn__76000016_A_InstanceOf; i.Init = A_arbace_data_vectorize_fn__76000016_A_Init; i.Table = A_arbace_data_vectorize_fn__76000016_A_members; jrt.RegisterGoType(A_arbace_data_vectorize_fn__76000016_A_class, reflect.TypeFor[A_arbace_data_vectorize_fn__76000016_A]()) }

func A_arbace_data_Diff_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(A_arbace_data_Diff_A).Diff_similar_O__O(args[0])}; return nil }

var A_arbace_data_Diff_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1025 diff_similar (Ljava.lang.Object;)Ljava.lang.Object;", Invoke: A_arbace_data_Diff_A_invoke}

var A_arbace_data_Diff_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data.Diff", Modifiers: 1537, Kind: jrt.KindInterface, Go: "arbace/aot_arbace_data.A_arbace_data_Diff_A"})

func init() { i := A_arbace_data_Diff_A_class.Info(); i.IsInstance = A_arbace_data_Diff_A_InstanceOf; i.Table = A_arbace_data_Diff_A_members }

func A_arbace_data_EqualityPartition_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(A_arbace_data_EqualityPartition_A).Equality_partition__O()}; return nil }

var A_arbace_data_EqualityPartition_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1025 equality_partition ()Ljava.lang.Object;", Invoke: A_arbace_data_EqualityPartition_A_invoke}

var A_arbace_data_EqualityPartition_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data.EqualityPartition", Modifiers: 1537, Kind: jrt.KindInterface, Go: "arbace/aot_arbace_data.A_arbace_data_EqualityPartition_A"})

func init() { i := A_arbace_data_EqualityPartition_A_class.Info(); i.IsInstance = A_arbace_data_EqualityPartition_A_InstanceOf; i.Table = A_arbace_data_EqualityPartition_A_members }

func A_arbace_data__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_data__init_A_Load__O(); case 1: return A_arbace_data__init_A_Unit0__O(); case 2: return A_arbace_data__init_A_Unit1__O(); case 3: return A_arbace_data__init_A_Unit10__O(); case 4: return A_arbace_data__init_A_Unit11__O(); case 5: return A_arbace_data__init_A_Unit12__O(); case 6: return A_arbace_data__init_A_Unit13__O(); case 7: return A_arbace_data__init_A_Unit14__O(); case 8: return A_arbace_data__init_A_Unit15__O(); case 9: return A_arbace_data__init_A_Unit16__O(); case 10: return A_arbace_data__init_A_Unit17__O(); case 11: return A_arbace_data__init_A_Unit18__O(); case 12: return A_arbace_data__init_A_Unit19__O(); case 13: return A_arbace_data__init_A_Unit2__O(); case 14: return A_arbace_data__init_A_Unit20__O(); case 15: return A_arbace_data__init_A_Unit21__O(); case 16: return A_arbace_data__init_A_Unit22__O(); case 17: return A_arbace_data__init_A_Unit23__O(); case 18: return A_arbace_data__init_A_Unit24__O(); case 19: return A_arbace_data__init_A_Unit25__O(); case 20: return A_arbace_data__init_A_Unit26__O(); case 21: return A_arbace_data__init_A_Unit27__O(); case 22: return A_arbace_data__init_A_Unit28__O(); case 23: return A_arbace_data__init_A_Unit29__O(); case 24: return A_arbace_data__init_A_Unit3__O(); case 25: return A_arbace_data__init_A_Unit30__O(); case 26: return A_arbace_data__init_A_Unit31__O(); case 27: return A_arbace_data__init_A_Unit32__O(); case 28: return A_arbace_data__init_A_Unit33__O(); case 29: return A_arbace_data__init_A_Unit34__O(); case 30: return A_arbace_data__init_A_Unit35__O(); case 31: return A_arbace_data__init_A_Unit4__O(); case 32: return A_arbace_data__init_A_Unit5__O(); case 33: return A_arbace_data__init_A_Unit6__O(); case 34: return A_arbace_data__init_A_Unit7__O(); case 35: return A_arbace_data__init_A_Unit8__O(); case 36: return A_arbace_data__init_A_Unit9__O()}; return nil }

func A_arbace_data__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_data__init_A_New()}; return nil }

var A_arbace_data__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit34 ()Ljava.lang.Object;\nM9 unit35 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_data__init_A_invoke, New: A_arbace_data__init_A_new}

var A_arbace_data__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.data__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_data.A_arbace_data__init_A", Source: "data.ae"})

func init() { i := A_arbace_data__init_A_class.Info(); i.IsInstance = A_arbace_data__init_A_InstanceOf; i.Init = A_arbace_data__init_A_Init; i.Table = A_arbace_data__init_A_members; jrt.RegisterGoType(A_arbace_data__init_A_class, reflect.TypeFor[A_arbace_data__init_A]()) }
