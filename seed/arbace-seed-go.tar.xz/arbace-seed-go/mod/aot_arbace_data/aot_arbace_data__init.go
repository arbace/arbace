//line aot_arbace_data__init.ae:1
package aot_arbace_data

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_data__init_A_Load__O() any { A_arbace_data__init_A_Init(); A_arbace_data__init_A_Unit0__O(); A_arbace_data__init_A_Unit1__O(); A_arbace_data__init_A_Unit2__O(); A_arbace_data__init_A_Unit3__O(); A_arbace_data__init_A_Unit4__O(); A_arbace_data__init_A_Unit5__O(); A_arbace_data__init_A_Unit6__O(); A_arbace_data__init_A_Unit7__O(); A_arbace_data__init_A_Unit8__O(); A_arbace_data__init_A_Unit9__O(); A_arbace_data__init_A_Unit10__O(); A_arbace_data__init_A_Unit11__O(); A_arbace_data__init_A_Unit12__O(); A_arbace_data__init_A_Unit13__O(); A_arbace_data__init_A_Unit14__O(); A_arbace_data__init_A_Unit15__O(); A_arbace_data__init_A_Unit16__O(); A_arbace_data__init_A_Unit17__O(); A_arbace_data__init_A_Unit18__O(); A_arbace_data__init_A_Unit19__O(); A_arbace_data__init_A_Unit20__O(); A_arbace_data__init_A_Unit21__O(); A_arbace_data__init_A_Unit22__O(); A_arbace_data__init_A_Unit23__O(); A_arbace_data__init_A_Unit24__O(); A_arbace_data__init_A_Unit25__O(); A_arbace_data__init_A_Unit26__O(); A_arbace_data__init_A_Unit27__O(); A_arbace_data__init_A_Unit28__O(); A_arbace_data__init_A_Unit29__O(); A_arbace_data__init_A_Unit30__O(); A_arbace_data__init_A_Unit31__O(); A_arbace_data__init_A_Unit32__O(); A_arbace_data__init_A_Unit33__O(); A_arbace_data__init_A_Unit34__O(); A_arbace_data__init_A_Unit35__O(); return nil }



func A_arbace_data__init_A_Unit0__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return lang.IFn_Cast(jrt.NN(A_arbace_data__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_data__init_A_const_1) }
//line :9:1
func A_arbace_data__init_A_Unit1__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_data__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_2)) }
//line :9:1
func A_arbace_data__init_A_Unit2__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); var tmp1 any = A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_New(); var tmp2 *jrt.Class; A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_Init(); tmp2 = A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :9:1
func A_arbace_data__init_A_Unit3__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_data__init_A_const_1)).Equals_O__Z(A_arbace_data__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_data_eval76000008_fn__76000009_A_New(); var tmp2 *jrt.Class; A_arbace_data_eval76000008_fn__76000009_A_Init(); tmp2 = A_arbace_data_eval76000008_fn__76000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }





func A_arbace_data__init_A_Unit4__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(15, 1); var tmp1 *lang.Var = A_arbace_data__init_A_const_4; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; return jrt.NN(tmp1).Set_O__O(tmp2.Ref()) }

func A_arbace_data__init_A_Unit5__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(17, 1); var tmp1 *lang.Var = A_arbace_data__init_A_const_5; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_6)); return A_arbace_data__init_A_const_5.Ref() }

func A_arbace_data__init_A_Unit6__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); var tmp1 *lang.Var = A_arbace_data__init_A_const_7; var tmp2 any = A_arbace_data_atom_diff_A_New(); var tmp3 *jrt.Class; A_arbace_data_atom_diff_A_Init(); tmp3 = A_arbace_data_atom_diff_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_data__init_A_const_7; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_8)); return A_arbace_data__init_A_const_7.Ref() }





func A_arbace_data__init_A_Unit7__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(25, 1); var tmp1 *lang.Var = A_arbace_data__init_A_const_9; var tmp2 any = A_arbace_data_vectorize_A_New(); var tmp3 *jrt.Class; A_arbace_data_vectorize_A_Init(); tmp3 = A_arbace_data_vectorize_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_data__init_A_const_9; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_10)); return A_arbace_data__init_A_const_9.Ref() }









func A_arbace_data__init_A_Unit8__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(35, 1); var tmp1 *lang.Var = A_arbace_data__init_A_const_11; var tmp2 any = A_arbace_data_diff_associative_key_A_New(); var tmp3 *jrt.Class; A_arbace_data_diff_associative_key_A_Init(); tmp3 = A_arbace_data_diff_associative_key_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_data__init_A_const_11; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_12)); return A_arbace_data__init_A_const_11.Ref() }















func A_arbace_data__init_A_Unit9__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(51, 1); var tmp1 *lang.Var = A_arbace_data__init_A_const_13; var tmp2 any = A_arbace_data_diff_associative_A_New(); var tmp3 *jrt.Class; A_arbace_data_diff_associative_A_Init(); tmp3 = A_arbace_data_diff_associative_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_data__init_A_const_13; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_14)); return A_arbace_data__init_A_const_13.Ref() }










func A_arbace_data__init_A_Unit10__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(62, 1); var tmp1 *lang.Var = A_arbace_data__init_A_const_15; var tmp2 any = A_arbace_data_diff_sequential_A_New(); var tmp3 *jrt.Class; A_arbace_data_diff_sequential_A_Init(); tmp3 = A_arbace_data_diff_sequential_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_data__init_A_const_15; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_16)); return A_arbace_data__init_A_const_15.Ref() }






func A_arbace_data__init_A_Unit11__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(69, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_data__init_A_const_17; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_18)); v__1927001498__auto____1 = A_arbace_data__init_A_const_17.Ref(); if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_data__init_A_const_17; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_19)); var tmp3 *lang.Var = A_arbace_data__init_A_const_17; var tmp4 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; jrt.NN(tmp3).BindRoot_O__V(tmp4.Ref()); return A_arbace_data__init_A_const_17.Ref() } }
//line :69:1
func A_arbace_data__init_A_Unit12__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(69, 1); return A_arbace_data__init_A_const_20.Ref() }
//line :69:1
func A_arbace_data__init_A_Unit13__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(69, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_data__init_A_const_21).GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_17.Ref(); return tmp1.Invoke_O_O_O_O__O(tmp2, jrt.NN(A_arbace_data__init_A_const_22).GetRawRoot__O(), A_arbace_data__init_A_const_23.Ref(), Lit_102) }
//line :69:1
func A_arbace_data__init_A_Unit14__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(69, 1); return Up_Var_IFn(A_arbace_data__init_A_const_24).Invoke_O_O__O(A_arbace_data__init_A_const_17.Ref(), A_arbace_data__init_A_const_25) }
//line :69:1
func A_arbace_data__init_A_Unit15__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(69, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_data__init_A_const_26).GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_17.Ref(); var tmp3 any = jrt.NN(A_arbace_data__init_A_const_27).GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_data__init_A_const_22).GetRawRoot__O()); var tmp5 any = A_arbace_data__init_A_const_28; var tmp6 any = A_arbace_data__init_A_const_29.Ref(); var tmp7 any = A_arbace_data__init_A_const_30; var tmp8 any = A_arbace_data__init_A_const_31.Ref(); var tmp9 any = A_arbace_data__init_A_const_17.Ref(); var tmp10 any = A_arbace_data__init_A_const_32.Ref(); var tmp11 any = A_arbace_data__init_A_const_33; var tmp12 any = A_arbace_data__init_A_const_34.Ref(); var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_data__init_A_const_37).GetRawRoot__O()); var tmp14 any = A_arbace_data__init_A_const_38; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_data__init_A_const_27).GetRawRoot__O()); var tmp16 any = A_arbace_data__init_A_const_39; var tmp17 any = lang.IFn_Cast(jrt.NN(A_arbace_data__init_A_const_35).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(A_arbace_data__init_A_const_36).Get__O(), tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_data__init_A_const_40.Ref(), A_arbace_data__init_A_const_17.Ref()))))); var tmp18 any = A_arbace_data_eval76000038_fn__76000039_A_New(); var tmp19 *jrt.Class; A_arbace_data_eval76000038_fn__76000039_A_Init(); tmp19 = A_arbace_data_eval76000038_fn__76000039_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp17, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil))))) }
//line :69:1
func A_arbace_data__init_A_Unit16__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(69, 1); return lang.IFn_Cast(jrt.NN(A_arbace_data__init_A_const_41).GetRawRoot__O()).Invoke_O__O(jrt.NN(A_arbace_data__init_A_const_17).GetRawRoot__O()) }
//line :69:1
func A_arbace_data__init_A_Unit17__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(69, 1); return A_arbace_data__init_A_const_42 }



func A_arbace_data__init_A_Unit18__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(73, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_data__init_A_const_43; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_44)); v__1927001498__auto____1 = A_arbace_data__init_A_const_43.Ref(); if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_data__init_A_const_43; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_45)); var tmp3 *lang.Var = A_arbace_data__init_A_const_43; var tmp4 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; jrt.NN(tmp3).BindRoot_O__V(tmp4.Ref()); return A_arbace_data__init_A_const_43.Ref() } }
//line :73:1
func A_arbace_data__init_A_Unit19__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(73, 1); return A_arbace_data__init_A_const_46.Ref() }
//line :73:1
func A_arbace_data__init_A_Unit20__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(73, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_data__init_A_const_21).GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_43.Ref(); return tmp1.Invoke_O_O_O_O__O(tmp2, jrt.NN(A_arbace_data__init_A_const_22).GetRawRoot__O(), A_arbace_data__init_A_const_23.Ref(), Lit_102) }
//line :73:1
func A_arbace_data__init_A_Unit21__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(73, 1); return Up_Var_IFn(A_arbace_data__init_A_const_24).Invoke_O_O__O(A_arbace_data__init_A_const_43.Ref(), A_arbace_data__init_A_const_47) }
//line :73:1
func A_arbace_data__init_A_Unit22__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(73, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_data__init_A_const_26).GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_43.Ref(); var tmp3 any = jrt.NN(A_arbace_data__init_A_const_27).GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_data__init_A_const_22).GetRawRoot__O()); var tmp5 any = A_arbace_data__init_A_const_48; var tmp6 any = A_arbace_data__init_A_const_29.Ref(); var tmp7 any = A_arbace_data__init_A_const_49; var tmp8 any = A_arbace_data__init_A_const_31.Ref(); var tmp9 any = A_arbace_data__init_A_const_43.Ref(); var tmp10 any = A_arbace_data__init_A_const_32.Ref(); var tmp11 any = A_arbace_data__init_A_const_50; var tmp12 any = A_arbace_data__init_A_const_34.Ref(); var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_data__init_A_const_37).GetRawRoot__O()); var tmp14 any = A_arbace_data__init_A_const_51; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_data__init_A_const_27).GetRawRoot__O()); var tmp16 any = A_arbace_data__init_A_const_52; var tmp17 any = lang.IFn_Cast(jrt.NN(A_arbace_data__init_A_const_35).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(A_arbace_data__init_A_const_36).Get__O(), tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_data__init_A_const_40.Ref(), A_arbace_data__init_A_const_43.Ref()))))); var tmp18 any = A_arbace_data_eval76000060_fn__76000061_A_New(); var tmp19 *jrt.Class; A_arbace_data_eval76000060_fn__76000061_A_Init(); tmp19 = A_arbace_data_eval76000060_fn__76000061_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp17, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil))))) }
//line :73:1
func A_arbace_data__init_A_Unit23__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(73, 1); return lang.IFn_Cast(jrt.NN(A_arbace_data__init_A_const_41).GetRawRoot__O()).Invoke_O__O(jrt.NN(A_arbace_data__init_A_const_43).GetRawRoot__O()) }
//line :73:1
func A_arbace_data__init_A_Unit24__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(73, 1); return A_arbace_data__init_A_const_53 }



func A_arbace_data__init_A_Unit25__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(77, 1); var tmp1 any = A_arbace_data__init_A_const_55.Ref(); return lang.IFn_Cast(jrt.NN(A_arbace_data__init_A_const_54).GetRawRoot__O()).Invoke_O_O_O__O(nil, jrt.NN(A_arbace_data__init_A_const_43).GetRawRoot__O(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(A_arbace_data__init_A_const_7).GetRawRoot__O()))) }



func A_arbace_data__init_A_Unit26__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(81, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_data__init_A_const_54).GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_56.Ref(); var tmp3 any = jrt.NN(A_arbace_data__init_A_const_43).GetRawRoot__O(); var tmp4 any = A_arbace_data__init_A_const_55.Ref(); var tmp5 any = A_arbace_data_eval76000078_fn__76000079_A_New(); var tmp6 *jrt.Class; A_arbace_data_eval76000078_fn__76000079_A_Init(); tmp6 = A_arbace_data_eval76000078_fn__76000079_A_fn_class; var tmp7 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil))); var tmp8 any = jrt.NN(A_arbace_data__init_A_const_17).GetRawRoot__O(); var tmp9 any = A_arbace_data__init_A_const_57.Ref(); var tmp10 any = A_arbace_data_eval76000078_fn__76000081_A_New(); var tmp11 *jrt.Class; A_arbace_data_eval76000078_fn__76000081_A_Init(); tmp11 = A_arbace_data_eval76000078_fn__76000081_A_fn_class; return tmp1.Invoke_O_O_O_O_O__O(tmp2, tmp3, tmp7, tmp8, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp9, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)))) }







func A_arbace_data__init_A_Unit27__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(89, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_data__init_A_const_54).GetRawRoot__O()); var tmp2 any = jrt.NN(A_arbace_data__init_A_const_17).GetRawRoot__O(); var tmp3 any = A_arbace_data__init_A_const_57.Ref(); var tmp4 any = A_arbace_data_eval76000084_fn__76000085_A_New(); var tmp5 *jrt.Class; A_arbace_data_eval76000084_fn__76000085_A_Init(); tmp5 = A_arbace_data_eval76000084_fn__76000085_A_fn_class; return tmp1.Invoke_O_O_O__O(nil, tmp2, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)))) }
//line :89:1
func A_arbace_data__init_A_Unit28__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(89, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_data__init_A_const_54).GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_58.Ref(); var tmp3 any = jrt.NN(A_arbace_data__init_A_const_17).GetRawRoot__O(); var tmp4 any = A_arbace_data__init_A_const_57.Ref(); var tmp5 any = A_arbace_data_eval76000088_fn__76000089_A_New(); var tmp6 *jrt.Class; A_arbace_data_eval76000088_fn__76000089_A_Init(); tmp6 = A_arbace_data_eval76000088_fn__76000089_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :89:1
func A_arbace_data__init_A_Unit29__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(89, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_data__init_A_const_54).GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_59.Ref(); var tmp3 any = jrt.NN(A_arbace_data__init_A_const_17).GetRawRoot__O(); var tmp4 any = A_arbace_data__init_A_const_57.Ref(); var tmp5 any = A_arbace_data_eval76000092_fn__76000093_A_New(); var tmp6 *jrt.Class; A_arbace_data_eval76000092_fn__76000093_A_Init(); tmp6 = A_arbace_data_eval76000092_fn__76000093_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :89:1
func A_arbace_data__init_A_Unit30__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(89, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_data__init_A_const_54).GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_60.Ref(); var tmp3 any = jrt.NN(A_arbace_data__init_A_const_17).GetRawRoot__O(); var tmp4 any = A_arbace_data__init_A_const_57.Ref(); var tmp5 any = A_arbace_data_eval76000096_fn__76000097_A_New(); var tmp6 *jrt.Class; A_arbace_data_eval76000096_fn__76000097_A_Init(); tmp6 = A_arbace_data_eval76000096_fn__76000097_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }












func A_arbace_data__init_A_Unit31__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(102, 1); var tmp1 *lang.Var = A_arbace_data__init_A_const_61; var tmp2 any = A_arbace_data_as_set_value_A_New(); var tmp3 *jrt.Class; A_arbace_data_as_set_value_A_Init(); tmp3 = A_arbace_data_as_set_value_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_data__init_A_const_61; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_62)); return A_arbace_data__init_A_const_61.Ref() }



func A_arbace_data__init_A_Unit32__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(106, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_data__init_A_const_54).GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_58.Ref(); var tmp3 any = jrt.NN(A_arbace_data__init_A_const_43).GetRawRoot__O(); var tmp4 any = A_arbace_data__init_A_const_55.Ref(); var tmp5 any = A_arbace_data_eval76000101_fn__76000102_A_New(); var tmp6 *jrt.Class; A_arbace_data_eval76000101_fn__76000102_A_Init(); tmp6 = A_arbace_data_eval76000101_fn__76000102_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :106:1
func A_arbace_data__init_A_Unit33__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(106, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_data__init_A_const_54).GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_59.Ref(); var tmp3 any = jrt.NN(A_arbace_data__init_A_const_43).GetRawRoot__O(); var tmp4 any = A_arbace_data__init_A_const_55.Ref(); var tmp5 any = A_arbace_data_eval76000105_fn__76000106_A_New(); var tmp6 *jrt.Class; A_arbace_data_eval76000105_fn__76000106_A_Init(); tmp6 = A_arbace_data_eval76000105_fn__76000106_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :106:1
func A_arbace_data__init_A_Unit34__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(106, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_data__init_A_const_54).GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_60.Ref(); var tmp3 any = jrt.NN(A_arbace_data__init_A_const_43).GetRawRoot__O(); var tmp4 any = A_arbace_data__init_A_const_55.Ref(); var tmp5 any = A_arbace_data_eval76000109_fn__76000110_A_New(); var tmp6 *jrt.Class; A_arbace_data_eval76000109_fn__76000110_A_Init(); tmp6 = A_arbace_data_eval76000109_fn__76000110_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }

















func A_arbace_data__init_A_Unit35__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(124, 1); var tmp1 *lang.Var = A_arbace_data__init_A_const_5; var tmp2 any = A_arbace_data_diff_A_New(); var tmp3 *jrt.Class; A_arbace_data_diff_A_Init(); tmp3 = A_arbace_data_diff_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_data__init_A_const_5; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_63)); return A_arbace_data__init_A_const_5.Ref() }



type A_arbace_data__init_A struct{ jrt.Object }

var A_arbace_data__init_A_const_0 *lang.Var

var A_arbace_data__init_A_const_1 any

var A_arbace_data__init_A_const_2 any

var A_arbace_data__init_A_const_3 any

var A_arbace_data__init_A_const_4 *lang.Var

var A_arbace_data__init_A_const_5 *lang.Var

var A_arbace_data__init_A_const_6 any

var A_arbace_data__init_A_const_7 *lang.Var

var A_arbace_data__init_A_const_8 any

var A_arbace_data__init_A_const_9 *lang.Var

var A_arbace_data__init_A_const_10 any

var A_arbace_data__init_A_const_11 *lang.Var

var A_arbace_data__init_A_const_12 any

var A_arbace_data__init_A_const_13 *lang.Var

var A_arbace_data__init_A_const_14 any

var A_arbace_data__init_A_const_15 *lang.Var

var A_arbace_data__init_A_const_16 any

var A_arbace_data__init_A_const_17 *lang.Var

var A_arbace_data__init_A_const_18 any

var A_arbace_data__init_A_const_19 any

var A_arbace_data__init_A_const_20 *jrt.Class

var A_arbace_data__init_A_const_21 *lang.Var

var A_arbace_data__init_A_const_22 *lang.Var

var A_arbace_data__init_A_const_23 *lang.Keyword

var A_arbace_data__init_A_const_24 *lang.Var

var A_arbace_data__init_A_const_25 any

var A_arbace_data__init_A_const_26 *lang.Var

var A_arbace_data__init_A_const_27 *lang.Var

var A_arbace_data__init_A_const_28 any

var A_arbace_data__init_A_const_29 *lang.Keyword

var A_arbace_data__init_A_const_30 any

var A_arbace_data__init_A_const_31 *lang.Keyword

var A_arbace_data__init_A_const_32 *lang.Keyword

var A_arbace_data__init_A_const_33 any

var A_arbace_data__init_A_const_34 *lang.Keyword

var A_arbace_data__init_A_const_35 *lang.Var

var A_arbace_data__init_A_const_36 *lang.Var

var A_arbace_data__init_A_const_37 *lang.Var

var A_arbace_data__init_A_const_38 any

var A_arbace_data__init_A_const_39 any

var A_arbace_data__init_A_const_40 *lang.Keyword

var A_arbace_data__init_A_const_41 *lang.Var

var A_arbace_data__init_A_const_42 any

var A_arbace_data__init_A_const_43 *lang.Var

var A_arbace_data__init_A_const_44 any

var A_arbace_data__init_A_const_45 any

var A_arbace_data__init_A_const_46 *jrt.Class

var A_arbace_data__init_A_const_47 any

var A_arbace_data__init_A_const_48 any

var A_arbace_data__init_A_const_49 any

var A_arbace_data__init_A_const_50 any

var A_arbace_data__init_A_const_51 any

var A_arbace_data__init_A_const_52 any

var A_arbace_data__init_A_const_53 any

var A_arbace_data__init_A_const_54 *lang.Var

var A_arbace_data__init_A_const_55 *lang.Keyword

var A_arbace_data__init_A_const_56 *jrt.Class

var A_arbace_data__init_A_const_57 *lang.Keyword

var A_arbace_data__init_A_const_58 *jrt.Class

var A_arbace_data__init_A_const_59 *jrt.Class

var A_arbace_data__init_A_const_60 *jrt.Class

var A_arbace_data__init_A_const_61 *lang.Var

var A_arbace_data__init_A_const_62 any

var A_arbace_data__init_A_const_63 any

var A_arbace_data__init_A_init jrt.ClassInit

func A_arbace_data__init_A_Init() { if !A_arbace_data__init_A_init.Done() { A_arbace_data__init_A_init.Run(A_arbace_data__init_A_clinit) } }

func A_arbace_data__init_A_clinit() { A_arbace_data__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_79); A_arbace_data__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13))); A_arbace_data__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_data__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_data__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_80); A_arbace_data__init_A_const_5 = lang.RT_Var_String_String__Var(Lit_9, Lit_23); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_data__init_A_const_6 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(17).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_84).Ref(), Lit_85)); A_arbace_data__init_A_const_7 = lang.RT_Var_String_String__Var(Lit_9, Lit_39); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_86).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_data__init_A_const_8 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_89).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_90, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(19).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_84).Ref(), Lit_85)); A_arbace_data__init_A_const_9 = lang.RT_Var_String_String__Var(Lit_9, Lit_31); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_86).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_data__init_A_const_10 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_91).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_92, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(25).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_84).Ref(), Lit_85)); A_arbace_data__init_A_const_11 = lang.RT_Var_String_String__Var(Lit_9, Lit_30); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_86).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_data__init_A_const_12 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_89).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_93).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_94, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(35).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_84).Ref(), Lit_85)); A_arbace_data__init_A_const_13 = lang.RT_Var_String_String__Var(Lit_9, Lit_32); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_86).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_data__init_A_const_14 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_89).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_96, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(51).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_84).Ref(), Lit_85)); A_arbace_data__init_A_const_15 = lang.RT_Var_String_String__Var(Lit_9, Lit_38); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_86).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_data__init_A_const_16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_89).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(62).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_84).Ref(), Lit_85)); A_arbace_data__init_A_const_17 = lang.RT_Var_String_String__Var(Lit_9, Lit_97); A_arbace_data__init_A_const_18 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(69).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_84).Ref(), Lit_85)); A_arbace_data__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(69).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_84).Ref(), Lit_85)); A_arbace_data__init_A_const_20 = lang.RT_ClassForNameNonLoading_String__Class(Lit_36); A_arbace_data__init_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_100); A_arbace_data__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_data__init_A_const_23 = lang.RT_Keyword_String_String__Keyword(nil, Lit_12); A_arbace_data__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_101); A_arbace_data__init_A_const_25 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_49)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_102, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_103).Ref())))))))))); A_arbace_data__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_104); A_arbace_data__init_A_const_27 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_data__init_A_const_28 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_105).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_36).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_106).Ref(), lang.RT_ClassForNameNonLoading_String__Class(Lit_36).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_102)); A_arbace_data__init_A_const_29 = lang.RT_Keyword_String_String__Keyword(nil, Lit_107); A_arbace_data__init_A_const_30 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_49).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99, lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_49)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_102, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_103).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_103).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_102)))); A_arbace_data__init_A_const_31 = lang.RT_Keyword_String_String__Keyword(nil, Lit_110); A_arbace_data__init_A_const_32 = lang.RT_Keyword_String_String__Keyword(nil, Lit_111); A_arbace_data__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_49).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_49).Ref())); A_arbace_data__init_A_const_34 = lang.RT_Keyword_String_String__Keyword(nil, Lit_112); A_arbace_data__init_A_const_35 = lang.RT_Var_String_String__Var(Lit_0, Lit_113); A_arbace_data__init_A_const_36 = lang.RT_Var_String_String__Var(Lit_0, Lit_114); A_arbace_data__init_A_const_37 = lang.RT_Var_String_String__Var(Lit_0, Lit_115); A_arbace_data__init_A_const_38 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_49)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_102, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_103).Ref()))))))); A_arbace_data__init_A_const_39 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99, lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_49)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_102, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_103).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_103).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_102)); A_arbace_data__init_A_const_40 = lang.RT_Keyword_String_String__Keyword(nil, Lit_116); A_arbace_data__init_A_const_41 = lang.RT_Var_String_String__Var(Lit_0, Lit_117); A_arbace_data__init_A_const_42 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_97)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99))); A_arbace_data__init_A_const_43 = lang.RT_Var_String_String__Var(Lit_9, Lit_118); A_arbace_data__init_A_const_44 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(73).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_84).Ref(), Lit_85)); A_arbace_data__init_A_const_45 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(73).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_84).Ref(), Lit_85)); A_arbace_data__init_A_const_46 = lang.RT_ClassForNameNonLoading_String__Class(Lit_37); A_arbace_data__init_A_const_47 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_50)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_102, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_89).Ref())))))))))); A_arbace_data__init_A_const_48 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_105).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_37).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_106).Ref(), lang.RT_ClassForNameNonLoading_String__Class(Lit_37).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_102)); A_arbace_data__init_A_const_49 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99, lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_50)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_102, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_89).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_89).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_102)))); A_arbace_data__init_A_const_50 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref())); A_arbace_data__init_A_const_51 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_50)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_102, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_89).Ref()))))))); A_arbace_data__init_A_const_52 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99, lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_50)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_102, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_89).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_89).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_102)); A_arbace_data__init_A_const_53 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_118)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99))); A_arbace_data__init_A_const_54 = lang.RT_Var_String_String__Var(Lit_0, Lit_119); A_arbace_data__init_A_const_55 = lang.RT_Keyword_String_String__Keyword(nil, Lit_50); A_arbace_data__init_A_const_56 = lang.RT_ClassForNameNonLoading_String__Class(Lit_120); A_arbace_data__init_A_const_57 = lang.RT_Keyword_String_String__Keyword(nil, Lit_49); A_arbace_data__init_A_const_58 = lang.RT_ClassForNameNonLoading_String__Class(Lit_121); A_arbace_data__init_A_const_59 = lang.RT_ClassForNameNonLoading_String__Class(Lit_122); A_arbace_data__init_A_const_60 = lang.RT_ClassForNameNonLoading_String__Class(Lit_123); A_arbace_data__init_A_const_61 = lang.RT_Var_String_String__Var(Lit_9, Lit_44); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_86).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_data__init_A_const_62 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_124).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(102).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_84).Ref(), Lit_85)); A_arbace_data__init_A_const_63 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_89).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_125, lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(124).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_84).Ref(), Lit_85)) }

func A_arbace_data__init_A_New() *A_arbace_data__init_A { A_arbace_data__init_A_Init(); t := &A_arbace_data__init_A{}; t.Ctor(); return t }

func (t *A_arbace_data__init_A) Ctor() {}

func (t *A_arbace_data__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data__init_A) GetClass__Class() *jrt.Class { return A_arbace_data__init_A_class }

func (t *A_arbace_data__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data__init_A); return ok }

func A_arbace_data__init_A_Cast(x any) *A_arbace_data__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data__init_A_class)) }; return v }
