//line aot_arbace_data__init.ae:1
package aot_arbace_data

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_data__init_A_Load__O() any { A_arbace_data__init_A_Init(); A_arbace_data__init_A_Unit0__O(); A_arbace_data__init_A_Unit1__O(); A_arbace_data__init_A_Unit2__O(); A_arbace_data__init_A_Unit3__O(); A_arbace_data__init_A_Unit4__O(); A_arbace_data__init_A_Unit5__O(); A_arbace_data__init_A_Unit6__O(); A_arbace_data__init_A_Unit7__O(); A_arbace_data__init_A_Unit8__O(); A_arbace_data__init_A_Unit9__O(); A_arbace_data__init_A_Unit10__O(); A_arbace_data__init_A_Unit11__O(); A_arbace_data__init_A_Unit12__O(); A_arbace_data__init_A_Unit13__O(); A_arbace_data__init_A_Unit14__O(); A_arbace_data__init_A_Unit15__O(); A_arbace_data__init_A_Unit16__O(); A_arbace_data__init_A_Unit17__O(); A_arbace_data__init_A_Unit18__O(); A_arbace_data__init_A_Unit19__O(); A_arbace_data__init_A_Unit20__O(); A_arbace_data__init_A_Unit21__O(); A_arbace_data__init_A_Unit22__O(); A_arbace_data__init_A_Unit23__O(); A_arbace_data__init_A_Unit24__O(); A_arbace_data__init_A_Unit25__O(); A_arbace_data__init_A_Unit26__O(); A_arbace_data__init_A_Unit27__O(); A_arbace_data__init_A_Unit28__O(); A_arbace_data__init_A_Unit29__O(); A_arbace_data__init_A_Unit30__O(); A_arbace_data__init_A_Unit31__O(); A_arbace_data__init_A_Unit32__O(); A_arbace_data__init_A_Unit33__O(); A_arbace_data__init_A_Unit34__O(); A_arbace_data__init_A_Unit35__O(); return nil }



func A_arbace_data__init_A_Unit0__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return lang.IFn_Cast(A_arbace_data__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_data__init_A_const_1) }
//line :9:1
func A_arbace_data__init_A_Unit1__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_data__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_2)) }
//line :9:1
func A_arbace_data__init_A_Unit2__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); var tmp1 any = A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_10, false); A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :9:1
func A_arbace_data__init_A_Unit3__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_data__init_A_const_1)).Equals_O__Z(A_arbace_data__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_data_eval76000008_fn__76000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_data_eval76000008_fn__76000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_11, false); A_arbace_data_eval76000008_fn__76000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }





func A_arbace_data__init_A_Unit4__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(15, 1); var tmp1 *lang.Var = A_arbace_data__init_A_const_4; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; return tmp1.Set_O__O(tmp2.Ref()) }

func A_arbace_data__init_A_Unit5__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(17, 1); var tmp1 *lang.Var = A_arbace_data__init_A_const_5; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_6)); return A_arbace_data__init_A_const_5 }

func A_arbace_data__init_A_Unit6__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); var tmp1 *lang.Var = A_arbace_data__init_A_const_7; var tmp2 any = A_arbace_data_atom_diff_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_data_atom_diff_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_12, false); A_arbace_data_atom_diff_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_data__init_A_const_7; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_8)); return A_arbace_data__init_A_const_7 }





func A_arbace_data__init_A_Unit7__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(25, 1); var tmp1 *lang.Var = A_arbace_data__init_A_const_9; var tmp2 any = A_arbace_data_vectorize_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_data_vectorize_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_13, false); A_arbace_data_vectorize_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_data__init_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_10)); return A_arbace_data__init_A_const_9 }









func A_arbace_data__init_A_Unit8__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(35, 1); var tmp1 *lang.Var = A_arbace_data__init_A_const_11; var tmp2 any = A_arbace_data_diff_associative_key_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_data_diff_associative_key_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_14, false); A_arbace_data_diff_associative_key_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_data__init_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_12)); return A_arbace_data__init_A_const_11 }















func A_arbace_data__init_A_Unit9__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(51, 1); var tmp1 *lang.Var = A_arbace_data__init_A_const_13; var tmp2 any = A_arbace_data_diff_associative_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_data_diff_associative_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_15, false); A_arbace_data_diff_associative_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_data__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_14)); return A_arbace_data__init_A_const_13 }










func A_arbace_data__init_A_Unit10__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(62, 1); var tmp1 *lang.Var = A_arbace_data__init_A_const_15; var tmp2 any = A_arbace_data_diff_sequential_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_data_diff_sequential_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_16, false); A_arbace_data_diff_sequential_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_data__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_16)); return A_arbace_data__init_A_const_15 }






func A_arbace_data__init_A_Unit11__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(69, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_data__init_A_const_17; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_18)); v__1927001498__auto____1 = A_arbace_data__init_A_const_17; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_data__init_A_const_17; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_19)); var tmp3 *lang.Var = A_arbace_data__init_A_const_17; var tmp4 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; tmp3.BindRoot_O__V(tmp4.Ref()); return A_arbace_data__init_A_const_17 } }
//line :69:1
func A_arbace_data__init_A_Unit12__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(69, 1); return A_arbace_data__init_A_const_20 }
//line :69:1
func A_arbace_data__init_A_Unit13__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(69, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_21.GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_17; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_data__init_A_const_22.GetRawRoot__O(), A_arbace_data__init_A_const_23, Lit_17) }
//line :69:1
func A_arbace_data__init_A_Unit14__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(69, 1); return A_arbace_data__init_A_const_24.Invoke_O_O__O(A_arbace_data__init_A_const_17, A_arbace_data__init_A_const_25) }
//line :69:1
func A_arbace_data__init_A_Unit15__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(69, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_26.GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_17; var tmp3 any = A_arbace_data__init_A_const_27.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_22.GetRawRoot__O()); var tmp5 any = A_arbace_data__init_A_const_28; var tmp6 any = A_arbace_data__init_A_const_29; var tmp7 any = A_arbace_data__init_A_const_30; var tmp8 any = A_arbace_data__init_A_const_31; var tmp9 any = A_arbace_data__init_A_const_17; var tmp10 any = A_arbace_data__init_A_const_32; var tmp11 any = A_arbace_data__init_A_const_33; var tmp12 any = A_arbace_data__init_A_const_34; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_37.GetRawRoot__O()); var tmp14 any = A_arbace_data__init_A_const_38; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_27.GetRawRoot__O()); var tmp16 any = A_arbace_data__init_A_const_39; var tmp17 any = lang.IFn_Cast(A_arbace_data__init_A_const_35.GetRawRoot__O()).Invoke_O_O__O(A_arbace_data__init_A_const_36.Get__O(), tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_data__init_A_const_40, A_arbace_data__init_A_const_17))))); var tmp18 any = A_arbace_data_eval76000038_fn__76000039_A_New(); var tmp19 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_data_eval76000038_fn__76000039_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); A_arbace_data_eval76000038_fn__76000039_A_fn_class = fncls__8d; tmp19 = fncls__8d } else { tmp19 = fncls__8 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp17, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil))))) }
//line :69:1
func A_arbace_data__init_A_Unit16__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(69, 1); return lang.IFn_Cast(A_arbace_data__init_A_const_41.GetRawRoot__O()).Invoke_O__O(A_arbace_data__init_A_const_17.GetRawRoot__O()) }
//line :69:1
func A_arbace_data__init_A_Unit17__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(69, 1); return A_arbace_data__init_A_const_42 }



func A_arbace_data__init_A_Unit18__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(73, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_data__init_A_const_43; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_44)); v__1927001498__auto____1 = A_arbace_data__init_A_const_43; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_data__init_A_const_43; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_45)); var tmp3 *lang.Var = A_arbace_data__init_A_const_43; var tmp4 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; tmp3.BindRoot_O__V(tmp4.Ref()); return A_arbace_data__init_A_const_43 } }
//line :73:1
func A_arbace_data__init_A_Unit19__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(73, 1); return A_arbace_data__init_A_const_46 }
//line :73:1
func A_arbace_data__init_A_Unit20__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(73, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_21.GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_43; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_data__init_A_const_22.GetRawRoot__O(), A_arbace_data__init_A_const_23, Lit_17) }
//line :73:1
func A_arbace_data__init_A_Unit21__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(73, 1); return A_arbace_data__init_A_const_24.Invoke_O_O__O(A_arbace_data__init_A_const_43, A_arbace_data__init_A_const_47) }
//line :73:1
func A_arbace_data__init_A_Unit22__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(73, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_26.GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_43; var tmp3 any = A_arbace_data__init_A_const_27.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_22.GetRawRoot__O()); var tmp5 any = A_arbace_data__init_A_const_48; var tmp6 any = A_arbace_data__init_A_const_29; var tmp7 any = A_arbace_data__init_A_const_49; var tmp8 any = A_arbace_data__init_A_const_31; var tmp9 any = A_arbace_data__init_A_const_43; var tmp10 any = A_arbace_data__init_A_const_32; var tmp11 any = A_arbace_data__init_A_const_50; var tmp12 any = A_arbace_data__init_A_const_34; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_37.GetRawRoot__O()); var tmp14 any = A_arbace_data__init_A_const_51; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_27.GetRawRoot__O()); var tmp16 any = A_arbace_data__init_A_const_52; var tmp17 any = lang.IFn_Cast(A_arbace_data__init_A_const_35.GetRawRoot__O()).Invoke_O_O__O(A_arbace_data__init_A_const_36.Get__O(), tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_data__init_A_const_40, A_arbace_data__init_A_const_43))))); var tmp18 any = A_arbace_data_eval76000060_fn__76000061_A_New(); var tmp19 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_data_eval76000060_fn__76000061_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_19, false); A_arbace_data_eval76000060_fn__76000061_A_fn_class = fncls__9d; tmp19 = fncls__9d } else { tmp19 = fncls__9 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp17, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil))))) }
//line :73:1
func A_arbace_data__init_A_Unit23__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(73, 1); return lang.IFn_Cast(A_arbace_data__init_A_const_41.GetRawRoot__O()).Invoke_O__O(A_arbace_data__init_A_const_43.GetRawRoot__O()) }
//line :73:1
func A_arbace_data__init_A_Unit24__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(73, 1); return A_arbace_data__init_A_const_53 }



func A_arbace_data__init_A_Unit25__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(77, 1); var tmp1 any = A_arbace_data__init_A_const_55; return lang.IFn_Cast(A_arbace_data__init_A_const_54.GetRawRoot__O()).Invoke_O_O_O__O(nil, A_arbace_data__init_A_const_43.GetRawRoot__O(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, A_arbace_data__init_A_const_7.GetRawRoot__O()))) }



func A_arbace_data__init_A_Unit26__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(81, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_56; var tmp3 any = A_arbace_data__init_A_const_43.GetRawRoot__O(); var tmp4 any = A_arbace_data__init_A_const_55; var tmp5 any = A_arbace_data_eval76000078_fn__76000079_A_New(); var tmp6 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_data_eval76000078_fn__76000079_A_fn_class; if

	fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_20, false); A_arbace_data_eval76000078_fn__76000079_A_fn_class = fncls__10d; tmp6 = fncls__10d } else { tmp6 = fncls__10 }; var tmp7 any = /*line :81:1*/lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil))); var tmp8 any = A_arbace_data__init_A_const_17.GetRawRoot__O(); var tmp9 any = A_arbace_data__init_A_const_57; var tmp10 any = A_arbace_data_eval76000078_fn__76000081_A_New(); var tmp11 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_data_eval76000078_fn__76000081_A_fn_class; if




	fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_21, false); A_arbace_data_eval76000078_fn__76000081_A_fn_class = fncls__11d; tmp11 = fncls__11d } else { tmp11 = fncls__11 }; return /*line :81:1*/ tmp1.Invoke_O_O_O_O_O__O(tmp2, tmp3, tmp7, tmp8, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp9, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)))) }







func A_arbace_data__init_A_Unit27__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(89, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_17.GetRawRoot__O(); var tmp3 any = A_arbace_data__init_A_const_57; var tmp4 any = A_arbace_data_eval76000084_fn__76000085_A_New(); var tmp5 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_data_eval76000084_fn__76000085_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_22, false); A_arbace_data_eval76000084_fn__76000085_A_fn_class = fncls__12d; tmp5 = fncls__12d } else { tmp5 = fncls__12 }; return tmp1.Invoke_O_O_O__O(nil, tmp2, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)))) }
//line :89:1
func A_arbace_data__init_A_Unit28__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(89, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_58; var tmp3 any = A_arbace_data__init_A_const_17.GetRawRoot__O(); var tmp4 any = A_arbace_data__init_A_const_57; var tmp5 any = A_arbace_data_eval76000088_fn__76000089_A_New(); var tmp6 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_data_eval76000088_fn__76000089_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_23, false); A_arbace_data_eval76000088_fn__76000089_A_fn_class = fncls__13d; tmp6 = fncls__13d } else { tmp6 = fncls__13 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :89:1
func A_arbace_data__init_A_Unit29__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(89, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_59; var tmp3 any = A_arbace_data__init_A_const_17.GetRawRoot__O(); var tmp4 any = A_arbace_data__init_A_const_57; var tmp5 any = A_arbace_data_eval76000092_fn__76000093_A_New(); var tmp6 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_data_eval76000092_fn__76000093_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_24, false); A_arbace_data_eval76000092_fn__76000093_A_fn_class = fncls__14d; tmp6 = fncls__14d } else { tmp6 = fncls__14 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :89:1
func A_arbace_data__init_A_Unit30__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(89, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_60; var tmp3 any = A_arbace_data__init_A_const_17.GetRawRoot__O(); var tmp4 any = A_arbace_data__init_A_const_57; var tmp5 any = A_arbace_data_eval76000096_fn__76000097_A_New(); var tmp6 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_data_eval76000096_fn__76000097_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_25, false); A_arbace_data_eval76000096_fn__76000097_A_fn_class = fncls__15d; tmp6 = fncls__15d } else { tmp6 = fncls__15 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }












func A_arbace_data__init_A_Unit31__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(102, 1); var tmp1 *lang.Var = A_arbace_data__init_A_const_61; var tmp2 any = A_arbace_data_as_set_value_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_data_as_set_value_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_26, false); A_arbace_data_as_set_value_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_data__init_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_62)); return A_arbace_data__init_A_const_61 }



func A_arbace_data__init_A_Unit32__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(106, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_58; var tmp3 any = A_arbace_data__init_A_const_43.GetRawRoot__O(); var tmp4 any = A_arbace_data__init_A_const_55; var tmp5 any = A_arbace_data_eval76000101_fn__76000102_A_New(); var tmp6 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_data_eval76000101_fn__76000102_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_27, false); A_arbace_data_eval76000101_fn__76000102_A_fn_class = fncls__17d; tmp6 = fncls__17d } else { tmp6 = fncls__17 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :106:1
func A_arbace_data__init_A_Unit33__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(106, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_59; var tmp3 any = A_arbace_data__init_A_const_43.GetRawRoot__O(); var tmp4 any = A_arbace_data__init_A_const_55; var tmp5 any = A_arbace_data_eval76000105_fn__76000106_A_New(); var tmp6 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_data_eval76000105_fn__76000106_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_28, false); A_arbace_data_eval76000105_fn__76000106_A_fn_class = fncls__18d; tmp6 = fncls__18d } else { tmp6 = fncls__18 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :106:1
func A_arbace_data__init_A_Unit34__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(106, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_60; var tmp3 any = A_arbace_data__init_A_const_43.GetRawRoot__O(); var tmp4 any = A_arbace_data__init_A_const_55; var tmp5 any = A_arbace_data_eval76000109_fn__76000110_A_New(); var tmp6 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_data_eval76000109_fn__76000110_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_29, false); A_arbace_data_eval76000109_fn__76000110_A_fn_class = fncls__19d; tmp6 = fncls__19d } else { tmp6 = fncls__19 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }

















func A_arbace_data__init_A_Unit35__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V(124, 1); var tmp1 *lang.Var = A_arbace_data__init_A_const_5; var tmp2 any = A_arbace_data_diff_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_data_diff_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_30, false); A_arbace_data_diff_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_data__init_A_const_5; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_63)); return A_arbace_data__init_A_const_5 }



type A_arbace_data__init_A struct{ jrt.Object }

var A_arbace_data__init_A_const_pool *jrt.RefArray

var A_arbace_data__init_A_const_0 *lang.Var

var A_arbace_data__init_A_const_1 any

var A_arbace_data__init_A_const_2 any

var A_arbace_data__init_A_const_3 any

var A_arbace_data__init_A_const_4 *lang.Var

var A_arbace_data__init_A_const_5 *lang.Var

var A_arbace_data__init_A_const_6 any

var A_arbace_data__init_A_const_7 *lang.Var

var A_arbace_data__init_A_const_8 any

var A_arbace_data__init_A_const_9 *lang.Var

var A_arbace_data__init_A_const_10 any

var A_arbace_data__init_A_const_11 *lang.Var

var A_arbace_data__init_A_const_12 any

var A_arbace_data__init_A_const_13 *lang.Var

var A_arbace_data__init_A_const_14 any

var A_arbace_data__init_A_const_15 *lang.Var

var A_arbace_data__init_A_const_16 any

var A_arbace_data__init_A_const_17 *lang.Var

var A_arbace_data__init_A_const_18 any

var A_arbace_data__init_A_const_19 any

var A_arbace_data__init_A_const_20 *jrt.Class

var A_arbace_data__init_A_const_21 *lang.Var

var A_arbace_data__init_A_const_22 *lang.Var

var A_arbace_data__init_A_const_23 *lang.Keyword

var A_arbace_data__init_A_const_24 *lang.Var

var A_arbace_data__init_A_const_25 any

var A_arbace_data__init_A_const_26 *lang.Var

var A_arbace_data__init_A_const_27 *lang.Var

var A_arbace_data__init_A_const_28 any

var A_arbace_data__init_A_const_29 *lang.Keyword

var A_arbace_data__init_A_const_30 any

var A_arbace_data__init_A_const_31 *lang.Keyword

var A_arbace_data__init_A_const_32 *lang.Keyword

var A_arbace_data__init_A_const_33 any

var A_arbace_data__init_A_const_34 *lang.Keyword

var A_arbace_data__init_A_const_35 *lang.Var

var A_arbace_data__init_A_const_36 *lang.Var

var A_arbace_data__init_A_const_37 *lang.Var

var A_arbace_data__init_A_const_38 any

var A_arbace_data__init_A_const_39 any

var A_arbace_data__init_A_const_40 *lang.Keyword

var A_arbace_data__init_A_const_41 *lang.Var

var A_arbace_data__init_A_const_42 any

var A_arbace_data__init_A_const_43 *lang.Var

var A_arbace_data__init_A_const_44 any

var A_arbace_data__init_A_const_45 any

var A_arbace_data__init_A_const_46 *jrt.Class

var A_arbace_data__init_A_const_47 any

var A_arbace_data__init_A_const_48 any

var A_arbace_data__init_A_const_49 any

var A_arbace_data__init_A_const_50 any

var A_arbace_data__init_A_const_51 any

var A_arbace_data__init_A_const_52 any

var A_arbace_data__init_A_const_53 any

var A_arbace_data__init_A_const_54 *lang.Var

var A_arbace_data__init_A_const_55 *lang.Keyword

var A_arbace_data__init_A_const_56 *jrt.Class

var A_arbace_data__init_A_const_57 *lang.Keyword

var A_arbace_data__init_A_const_58 *jrt.Class

var A_arbace_data__init_A_const_59 *jrt.Class

var A_arbace_data__init_A_const_60 *jrt.Class

var A_arbace_data__init_A_const_61 *lang.Var

var A_arbace_data__init_A_const_62 any

var A_arbace_data__init_A_const_63 any

var A_arbace_data__init_A_init jrt.ClassInit

func A_arbace_data__init_A_Init() { if !A_arbace_data__init_A_init.Done() { A_arbace_data__init_A_init.Run(A_arbace_data__init_A_clinit) } }

func A_arbace_data__init_A_clinit() { A_arbace_data__init_A_clinit_p0(); A_arbace_data__init_A_clinit_p1(); A_arbace_data__init_A_clinit_p2(); A_arbace_data__init_A_clinit_p3(); A_arbace_data__init_A_clinit_p4() }

func A_arbace_data__init_A_clinit_p0() { A_arbace_data__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_9, 94); A_arbace_data__init_A_const_0 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[30]); A_arbace_data__init_A_const_1 = A_arbace_data__init_A_const_pool.A[31]; A_arbace_data__init_A_const_2 = A_arbace_data__init_A_const_pool.A[32]; A_arbace_data__init_A_const_3 = A_arbace_data__init_A_const_pool.A[33]; A_arbace_data__init_A_const_4 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[34]); A_arbace_data__init_A_const_5 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[35]); A_arbace_data__init_A_const_6 = A_arbace_data__init_A_const_pool.A[36]; A_arbace_data__init_A_const_7 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[37]); A_arbace_data__init_A_const_8 = A_arbace_data__init_A_const_pool.A[38]; A_arbace_data__init_A_const_9 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[39]); A_arbace_data__init_A_const_10 = A_arbace_data__init_A_const_pool.A[40]; A_arbace_data__init_A_const_11 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[41]); A_arbace_data__init_A_const_12 = A_arbace_data__init_A_const_pool.A[42] }

func A_arbace_data__init_A_clinit_p1() { A_arbace_data__init_A_const_13 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[43]); A_arbace_data__init_A_const_14 = A_arbace_data__init_A_const_pool.A[44]; A_arbace_data__init_A_const_15 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[45]); A_arbace_data__init_A_const_16 = A_arbace_data__init_A_const_pool.A[46]; A_arbace_data__init_A_const_17 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[47]); A_arbace_data__init_A_const_18 = A_arbace_data__init_A_const_pool.A[48]; A_arbace_data__init_A_const_19 = A_arbace_data__init_A_const_pool.A[49]; A_arbace_data__init_A_const_20 = jrt.Class_Cast(A_arbace_data__init_A_const_pool.A[50]); A_arbace_data__init_A_const_21 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[51]); A_arbace_data__init_A_const_22 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[52]); A_arbace_data__init_A_const_23 = lang.Keyword_Cast(A_arbace_data__init_A_const_pool.A[53]); A_arbace_data__init_A_const_24 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[54]); A_arbace_data__init_A_const_25 = A_arbace_data__init_A_const_pool.A[55] }

func A_arbace_data__init_A_clinit_p2() { A_arbace_data__init_A_const_26 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[56]); A_arbace_data__init_A_const_27 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[57]); A_arbace_data__init_A_const_28 = A_arbace_data__init_A_const_pool.A[58]; A_arbace_data__init_A_const_29 = lang.Keyword_Cast(A_arbace_data__init_A_const_pool.A[59]); A_arbace_data__init_A_const_30 = A_arbace_data__init_A_const_pool.A[60]; A_arbace_data__init_A_const_31 = lang.Keyword_Cast(A_arbace_data__init_A_const_pool.A[61]); A_arbace_data__init_A_const_32 = lang.Keyword_Cast(A_arbace_data__init_A_const_pool.A[62]); A_arbace_data__init_A_const_33 = A_arbace_data__init_A_const_pool.A[63]; A_arbace_data__init_A_const_34 = lang.Keyword_Cast(A_arbace_data__init_A_const_pool.A[64]); A_arbace_data__init_A_const_35 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[65]); A_arbace_data__init_A_const_36 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[66]); A_arbace_data__init_A_const_37 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[67]); A_arbace_data__init_A_const_38 = A_arbace_data__init_A_const_pool.A[68] }

func A_arbace_data__init_A_clinit_p3() { A_arbace_data__init_A_const_39 = A_arbace_data__init_A_const_pool.A[69]; A_arbace_data__init_A_const_40 = lang.Keyword_Cast(A_arbace_data__init_A_const_pool.A[70]); A_arbace_data__init_A_const_41 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[71]); A_arbace_data__init_A_const_42 = A_arbace_data__init_A_const_pool.A[72]; A_arbace_data__init_A_const_43 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[73]); A_arbace_data__init_A_const_44 = A_arbace_data__init_A_const_pool.A[74]; A_arbace_data__init_A_const_45 = A_arbace_data__init_A_const_pool.A[75]; A_arbace_data__init_A_const_46 = jrt.Class_Cast(A_arbace_data__init_A_const_pool.A[76]); A_arbace_data__init_A_const_47 = A_arbace_data__init_A_const_pool.A[77]; A_arbace_data__init_A_const_48 = A_arbace_data__init_A_const_pool.A[78]; A_arbace_data__init_A_const_49 = A_arbace_data__init_A_const_pool.A[79]; A_arbace_data__init_A_const_50 = A_arbace_data__init_A_const_pool.A[80]; A_arbace_data__init_A_const_51 = A_arbace_data__init_A_const_pool.A[81]; A_arbace_data__init_A_const_52 = A_arbace_data__init_A_const_pool.A[82] }

func A_arbace_data__init_A_clinit_p4() { A_arbace_data__init_A_const_53 = A_arbace_data__init_A_const_pool.A[83]; A_arbace_data__init_A_const_54 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[84]); A_arbace_data__init_A_const_55 = lang.Keyword_Cast(A_arbace_data__init_A_const_pool.A[85]); A_arbace_data__init_A_const_56 = jrt.Class_Cast(A_arbace_data__init_A_const_pool.A[86]); A_arbace_data__init_A_const_57 = lang.Keyword_Cast(A_arbace_data__init_A_const_pool.A[87]); A_arbace_data__init_A_const_58 = jrt.Class_Cast(A_arbace_data__init_A_const_pool.A[88]); A_arbace_data__init_A_const_59 = jrt.Class_Cast(A_arbace_data__init_A_const_pool.A[89]); A_arbace_data__init_A_const_60 = jrt.Class_Cast(A_arbace_data__init_A_const_pool.A[90]); A_arbace_data__init_A_const_61 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[91]); A_arbace_data__init_A_const_62 = A_arbace_data__init_A_const_pool.A[92]; A_arbace_data__init_A_const_63 = A_arbace_data__init_A_const_pool.A[93] }

func A_arbace_data__init_A_New() *A_arbace_data__init_A { A_arbace_data__init_A_Init(); t := &A_arbace_data__init_A{}; t.Ctor(); return t }

func (t *A_arbace_data__init_A) Ctor() {}

func (t *A_arbace_data__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data__init_A) GetClass__Class() *jrt.Class { return A_arbace_data__init_A_class }

func (t *A_arbace_data__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_data__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data__init_A); return ok }

func A_arbace_data__init_A_Cast(x any) *A_arbace_data__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data__init_A_class)) }; return v }
