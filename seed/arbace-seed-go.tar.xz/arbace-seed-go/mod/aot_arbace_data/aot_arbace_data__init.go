//line aot_arbace_data__init.ae:1
package aot_arbace_data

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_data__init_A_Load__O() any { A_arbace_data__init_A_Init(); jrt.StartCheck(); A_arbace_data__init_A_Unit0__O(); A_arbace_data__init_A_Unit1__O(); A_arbace_data__init_A_Unit2__O(); A_arbace_data__init_A_Unit3__O(); A_arbace_data__init_A_Unit4__O(); A_arbace_data__init_A_Unit5__O(); A_arbace_data__init_A_Unit6__O(); A_arbace_data__init_A_Unit7__O(); A_arbace_data__init_A_Unit8__O(); A_arbace_data__init_A_Unit9__O(); A_arbace_data__init_A_Unit10__O(); A_arbace_data__init_A_Unit11__O(); A_arbace_data__init_A_Unit12__O(); A_arbace_data__init_A_Unit13__O(); A_arbace_data__init_A_Unit14__O(); A_arbace_data__init_A_Unit15__O(); A_arbace_data__init_A_Unit16__O(); A_arbace_data__init_A_Unit17__O(); A_arbace_data__init_A_Unit18__O(); A_arbace_data__init_A_Unit19__O(); A_arbace_data__init_A_Unit20__O(); A_arbace_data__init_A_Unit21__O(); A_arbace_data__init_A_Unit22__O(); A_arbace_data__init_A_Unit23__O(); A_arbace_data__init_A_Unit24__O(); A_arbace_data__init_A_Unit25__O(); A_arbace_data__init_A_Unit26__O(); A_arbace_data__init_A_Unit27__O(); A_arbace_data__init_A_Unit28__O(); A_arbace_data__init_A_Unit29__O(); A_arbace_data__init_A_Unit30__O(); A_arbace_data__init_A_Unit31__O(); A_arbace_data__init_A_Unit32__O(); A_arbace_data__init_A_Unit33__O(); A_arbace_data__init_A_Unit34__O(); A_arbace_data__init_A_Unit35__O(); return nil }



func A_arbace_data__init_A_Unit0__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); return lang.IFn_Cast(A_arbace_data__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_data__init_A_const_1) }
//line :9:1
func A_arbace_data__init_A_Unit1__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_data__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_2)) }
//line :9:1
func A_arbace_data__init_A_Unit2__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); var tmp1 any = A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_data_eval76000004_loading__1927001464__auto____76000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :9:1
func A_arbace_data__init_A_Unit3__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_data__init_A_const_1)).Equals_O__Z(A_arbace_data__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_data_eval76000008_fn__76000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_data_eval76000008_fn__76000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_data_eval76000008_fn__76000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }





func A_arbace_data__init_A_Unit4__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(15, 1); return A_arbace_data__init_A_const_4.Set_O__O(jrt.Boolean_TRUE.Ref()) }

func A_arbace_data__init_A_Unit5__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); var tmp1 *lang.Var = A_arbace_data__init_A_const_5; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_6)); return A_arbace_data__init_A_const_5 }

func A_arbace_data__init_A_Unit6__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(19, 1); var tmp1 *lang.Var = A_arbace_data__init_A_const_7; var tmp2 any = A_arbace_data_atom_diff_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_data_atom_diff_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_data_atom_diff_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_data__init_A_const_7; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_8)); return A_arbace_data__init_A_const_7 }





func A_arbace_data__init_A_Unit7__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(25, 1); var tmp1 *lang.Var = A_arbace_data__init_A_const_9; var tmp2 any = A_arbace_data_vectorize_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_data_vectorize_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_data_vectorize_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_data__init_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_10)); return A_arbace_data__init_A_const_9 }









func A_arbace_data__init_A_Unit8__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(35, 1); var tmp1 *lang.Var = A_arbace_data__init_A_const_11; var tmp2 any = A_arbace_data_diff_associative_key_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_data_diff_associative_key_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_data_diff_associative_key_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_data__init_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_12)); return A_arbace_data__init_A_const_11 }















func A_arbace_data__init_A_Unit9__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(51, 1); var tmp1 *lang.Var = A_arbace_data__init_A_const_13; var tmp2 any = A_arbace_data_diff_associative_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_data_diff_associative_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_data_diff_associative_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_data__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_14)); return A_arbace_data__init_A_const_13 }










func A_arbace_data__init_A_Unit10__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(62, 1); var tmp1 *lang.Var = A_arbace_data__init_A_const_15; var tmp2 any = A_arbace_data_diff_sequential_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_data_diff_sequential_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_data_diff_sequential_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_data__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_16)); return A_arbace_data__init_A_const_15 }






func A_arbace_data__init_A_Unit11__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(69, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_data__init_A_const_17; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_18)); v__1927001498__auto____1 = A_arbace_data__init_A_const_17; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_data__init_A_const_17; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_19)); A_arbace_data__init_A_const_17.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); return A_arbace_data__init_A_const_17 } }
//line :69:1
func A_arbace_data__init_A_Unit12__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(69, 1); return A_arbace_data__init_A_const_20 }
//line :69:1
func A_arbace_data__init_A_Unit13__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(69, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_21.GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_17; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_data__init_A_const_22.GetRawRoot__O(), A_arbace_data__init_A_const_23, Lit_17) }
//line :69:1
func A_arbace_data__init_A_Unit14__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(69, 1); return A_arbace_data__init_A_const_24.Invoke_O_O__O(A_arbace_data__init_A_const_17, A_arbace_data__init_A_const_25) }
//line :69:1
func A_arbace_data__init_A_Unit15__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(69, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_26.GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_17; var tmp3 any = A_arbace_data__init_A_const_27.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_22.GetRawRoot__O()); var tmp5 any = A_arbace_data__init_A_const_28; var tmp6 any = A_arbace_data__init_A_const_29; var tmp7 any = A_arbace_data__init_A_const_30; var tmp8 any = A_arbace_data__init_A_const_31; var tmp9 any = A_arbace_data__init_A_const_17; var tmp10 any = A_arbace_data__init_A_const_32; var tmp11 any = A_arbace_data__init_A_const_33; var tmp12 any = A_arbace_data__init_A_const_34; var tmp13 any; var root_25 any = A_arbace_data__init_A_const_35.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = A_arbace_data__init_A_const_36.Get__O(); var arg_29 any; var root_20 any = A_arbace_data__init_A_const_37.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = A_arbace_data__init_A_const_38; var arg_24 any; var root_15 any = A_arbace_data__init_A_const_27.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = A_arbace_data__init_A_const_39; var arg_19 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_data__init_A_const_40, A_arbace_data__init_A_const_17)); if linked_16 == nil { arg_24 = ifn_17.Invoke_O_O__O(arg_18, arg_19) } else { arg_24 = linked_16.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_15, arg_18, arg_19) }; if linked_21 == nil { arg_29 = ifn_22.Invoke_O_O__O(arg_23, arg_24) } else { arg_29 = linked_21.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_20, arg_23, arg_24) }; if linked_26 == nil { tmp13 = ifn_27.Invoke_O_O__O(arg_28, arg_29) } else { tmp13 = linked_26.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_25, arg_28, arg_29) }; var tmp14 any = tmp13; var tmp15 any = A_arbace_data_eval76000038_fn__76000039_A_New(); var tmp16 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_data_eval76000038_fn__76000039_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_data_eval76000038_fn__76000039_A_fn_class = fncls__30d; tmp16 = fncls__30d } else { tmp16 = fncls__30 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil))))) }
//line :69:1
func A_arbace_data__init_A_Unit16__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(69, 1); var root_49 any = A_arbace_data__init_A_const_41.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core__reset_methods_A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = A_arbace_data__init_A_const_17.GetRawRoot__O(); if linked_50 == nil { return ifn_51.Invoke_O__O(arg_52) } else { return linked_50.(*aot_arbace_core.A_arbace_core__reset_methods_A).Invoke_O_O__O(root_49, arg_52) } }
//line :69:1
func A_arbace_data__init_A_Unit17__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(69, 1); return A_arbace_data__init_A_const_42 }



func A_arbace_data__init_A_Unit18__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(73, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_data__init_A_const_43; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_44)); v__1927001498__auto____1 = A_arbace_data__init_A_const_43; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_data__init_A_const_43; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_45)); A_arbace_data__init_A_const_43.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); return A_arbace_data__init_A_const_43 } }
//line :73:1
func A_arbace_data__init_A_Unit19__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(73, 1); return A_arbace_data__init_A_const_46 }
//line :73:1
func A_arbace_data__init_A_Unit20__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(73, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_21.GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_43; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_data__init_A_const_22.GetRawRoot__O(), A_arbace_data__init_A_const_23, Lit_17) }
//line :73:1
func A_arbace_data__init_A_Unit21__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(73, 1); return A_arbace_data__init_A_const_24.Invoke_O_O__O(A_arbace_data__init_A_const_43, A_arbace_data__init_A_const_47) }
//line :73:1
func A_arbace_data__init_A_Unit22__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(73, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_26.GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_43; var tmp3 any = A_arbace_data__init_A_const_27.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_22.GetRawRoot__O()); var tmp5 any = A_arbace_data__init_A_const_48; var tmp6 any = A_arbace_data__init_A_const_29; var tmp7 any = A_arbace_data__init_A_const_49; var tmp8 any = A_arbace_data__init_A_const_31; var tmp9 any = A_arbace_data__init_A_const_43; var tmp10 any = A_arbace_data__init_A_const_32; var tmp11 any = A_arbace_data__init_A_const_50; var tmp12 any = A_arbace_data__init_A_const_34; var tmp13 any; var root_70 any = A_arbace_data__init_A_const_35.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = A_arbace_data__init_A_const_36.Get__O(); var arg_74 any; var root_65 any = A_arbace_data__init_A_const_37.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_67 lang.IFn; if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = A_arbace_data__init_A_const_51; var arg_69 any; var root_60 any = A_arbace_data__init_A_const_27.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_62 lang.IFn; if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any = A_arbace_data__init_A_const_52; var arg_64 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_data__init_A_const_40, A_arbace_data__init_A_const_43)); if linked_61 == nil { arg_69 = ifn_62.Invoke_O_O__O(arg_63, arg_64) } else { arg_69 = linked_61.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_60, arg_63, arg_64) }; if linked_66 == nil { arg_74 = ifn_67.Invoke_O_O__O(arg_68, arg_69) } else { arg_74 = linked_66.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_65, arg_68, arg_69) }; if linked_71 == nil { tmp13 = ifn_72.Invoke_O_O__O(arg_73, arg_74) } else { tmp13 = linked_71.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_70, arg_73, arg_74) }; var tmp14 any = tmp13; var tmp15 any = A_arbace_data_eval76000060_fn__76000061_A_New(); var tmp16 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_data_eval76000060_fn__76000061_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_data_eval76000060_fn__76000061_A_fn_class = fncls__75d; tmp16 = fncls__75d } else { tmp16 = fncls__75 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil))))) }
//line :73:1
func A_arbace_data__init_A_Unit23__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(73, 1); var root_94 any = A_arbace_data__init_A_const_41.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core__reset_methods_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = A_arbace_data__init_A_const_43.GetRawRoot__O(); if linked_95 == nil { return ifn_96.Invoke_O__O(arg_97) } else { return linked_95.(*aot_arbace_core.A_arbace_core__reset_methods_A).Invoke_O_O__O(root_94, arg_97) } }
//line :73:1
func A_arbace_data__init_A_Unit24__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(73, 1); return A_arbace_data__init_A_const_53 }



func A_arbace_data__init_A_Unit25__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(77, 1); var tmp1 any = A_arbace_data__init_A_const_55; return lang.IFn_Cast(A_arbace_data__init_A_const_54.GetRawRoot__O()).Invoke_O_O_O__O(nil, A_arbace_data__init_A_const_43.GetRawRoot__O(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, A_arbace_data__init_A_const_7.GetRawRoot__O()))) }



func A_arbace_data__init_A_Unit26__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(81, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_56; var tmp3 any = A_arbace_data__init_A_const_43.GetRawRoot__O(); var tmp4 any = A_arbace_data__init_A_const_55; var tmp5 any = A_arbace_data_eval76000078_fn__76000079_A_New(); var tmp6 *jrt.Class; var fncls__104 *jrt.Class = A_arbace_data_eval76000078_fn__76000079_A_fn_class; if

	fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_data_eval76000078_fn__76000079_A_fn_class = fncls__104d; tmp6 = fncls__104d } else { tmp6 = fncls__104 }; var tmp7 any = /*line :81:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil))); var tmp8 any = A_arbace_data__init_A_const_17.GetRawRoot__O(); var tmp9 any = A_arbace_data__init_A_const_57; var tmp10 any = A_arbace_data_eval76000078_fn__76000081_A_New(); var tmp11 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_data_eval76000078_fn__76000081_A_fn_class; if




	fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_data_eval76000078_fn__76000081_A_fn_class = fncls__105d; tmp11 = fncls__105d } else { tmp11 = fncls__105 }; return /*line :81:1*/ tmp1.Invoke_O_O_O_O_O__O(tmp2, tmp3, tmp7, tmp8, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)))) }







func A_arbace_data__init_A_Unit27__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(89, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_17.GetRawRoot__O(); var tmp3 any = A_arbace_data__init_A_const_57; var tmp4 any = A_arbace_data_eval76000084_fn__76000085_A_New(); var tmp5 *jrt.Class; var fncls__114 *jrt.Class = A_arbace_data_eval76000084_fn__76000085_A_fn_class; if fncls__114 == nil { var fncls__114d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_data_eval76000084_fn__76000085_A_fn_class = fncls__114d; tmp5 = fncls__114d } else { tmp5 = fncls__114 }; return tmp1.Invoke_O_O_O__O(nil, tmp2, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)))) }
//line :89:1
func A_arbace_data__init_A_Unit28__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(89, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_58; var tmp3 any = A_arbace_data__init_A_const_17.GetRawRoot__O(); var tmp4 any = A_arbace_data__init_A_const_57; var tmp5 any = A_arbace_data_eval76000088_fn__76000089_A_New(); var tmp6 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_data_eval76000088_fn__76000089_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_data_eval76000088_fn__76000089_A_fn_class = fncls__121d; tmp6 = fncls__121d } else { tmp6 = fncls__121 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :89:1
func A_arbace_data__init_A_Unit29__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(89, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_59; var tmp3 any = A_arbace_data__init_A_const_17.GetRawRoot__O(); var tmp4 any = A_arbace_data__init_A_const_57; var tmp5 any = A_arbace_data_eval76000092_fn__76000093_A_New(); var tmp6 *jrt.Class; var fncls__128 *jrt.Class = A_arbace_data_eval76000092_fn__76000093_A_fn_class; if fncls__128 == nil { var fncls__128d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_data_eval76000092_fn__76000093_A_fn_class = fncls__128d; tmp6 = fncls__128d } else { tmp6 = fncls__128 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :89:1
func A_arbace_data__init_A_Unit30__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(89, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_60; var tmp3 any = A_arbace_data__init_A_const_17.GetRawRoot__O(); var tmp4 any = A_arbace_data__init_A_const_57; var tmp5 any = A_arbace_data_eval76000096_fn__76000097_A_New(); var tmp6 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_data_eval76000096_fn__76000097_A_fn_class; if fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_data_eval76000096_fn__76000097_A_fn_class = fncls__135d; tmp6 = fncls__135d } else { tmp6 = fncls__135 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }












func A_arbace_data__init_A_Unit31__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(102, 1); var tmp1 *lang.Var = A_arbace_data__init_A_const_61; var tmp2 any = A_arbace_data_as_set_value_A_New(); var tmp3 *jrt.Class; var fncls__142 *jrt.Class = A_arbace_data_as_set_value_A_fn_class; if fncls__142 == nil { var fncls__142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_data_as_set_value_A_fn_class = fncls__142d; tmp3 = fncls__142d } else { tmp3 = fncls__142 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_data__init_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_62)); return A_arbace_data__init_A_const_61 }



func A_arbace_data__init_A_Unit32__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(106, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_58; var tmp3 any = A_arbace_data__init_A_const_43.GetRawRoot__O(); var tmp4 any = A_arbace_data__init_A_const_55; var tmp5 any = A_arbace_data_eval76000101_fn__76000102_A_New(); var tmp6 *jrt.Class; var fncls__143 *jrt.Class = A_arbace_data_eval76000101_fn__76000102_A_fn_class; if fncls__143 == nil { var fncls__143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_data_eval76000101_fn__76000102_A_fn_class = fncls__143d; tmp6 = fncls__143d } else { tmp6 = fncls__143 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :106:1
func A_arbace_data__init_A_Unit33__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(106, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_59; var tmp3 any = A_arbace_data__init_A_const_43.GetRawRoot__O(); var tmp4 any = A_arbace_data__init_A_const_55; var tmp5 any = A_arbace_data_eval76000105_fn__76000106_A_New(); var tmp6 *jrt.Class; var fncls__150 *jrt.Class = A_arbace_data_eval76000105_fn__76000106_A_fn_class; if fncls__150 == nil { var fncls__150d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_data_eval76000105_fn__76000106_A_fn_class = fncls__150d; tmp6 = fncls__150d } else { tmp6 = fncls__150 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :106:1
func A_arbace_data__init_A_Unit34__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(106, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_data__init_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_data__init_A_const_60; var tmp3 any = A_arbace_data__init_A_const_43.GetRawRoot__O(); var tmp4 any = A_arbace_data__init_A_const_55; var tmp5 any = A_arbace_data_eval76000109_fn__76000110_A_New(); var tmp6 *jrt.Class; var fncls__157 *jrt.Class = A_arbace_data_eval76000109_fn__76000110_A_fn_class; if fncls__157 == nil { var fncls__157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_data_eval76000109_fn__76000110_A_fn_class = fncls__157d; tmp6 = fncls__157d } else { tmp6 = fncls__157 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }

















func A_arbace_data__init_A_Unit35__O() any { A_arbace_data__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var tmp1 *lang.Var = A_arbace_data__init_A_const_5; var tmp2 any = A_arbace_data_diff_A_New(); var tmp3 *jrt.Class; var fncls__164 *jrt.Class = A_arbace_data_diff_A_fn_class; if fncls__164 == nil { var fncls__164d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_data_diff_A_fn_class = fncls__164d; tmp3 = fncls__164d } else { tmp3 = fncls__164 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_data__init_A_const_5; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_data__init_A_const_63)); return A_arbace_data__init_A_const_5 }



type A_arbace_data__init_A struct{ jrt.Object }

var A_arbace_data__init_A_const_pool *jrt.RefArray

var A_arbace_data__init_A_const_0 *lang.Var

var A_arbace_data__init_A_const_1 any

var A_arbace_data__init_A_const_2 any

var A_arbace_data__init_A_const_3 any

var A_arbace_data__init_A_const_4 *lang.Var

var A_arbace_data__init_A_const_5 *lang.Var

var A_arbace_data__init_A_const_6 any

var A_arbace_data__init_A_const_7 *lang.Var

var A_arbace_data__init_A_const_8 any

var A_arbace_data__init_A_const_9 *lang.Var

var A_arbace_data__init_A_const_10 any

var A_arbace_data__init_A_const_11 *lang.Var

var A_arbace_data__init_A_const_12 any

var A_arbace_data__init_A_const_13 *lang.Var

var A_arbace_data__init_A_const_14 any

var A_arbace_data__init_A_const_15 *lang.Var

var A_arbace_data__init_A_const_16 any

var A_arbace_data__init_A_const_17 *lang.Var

var A_arbace_data__init_A_const_18 any

var A_arbace_data__init_A_const_19 any

var A_arbace_data__init_A_const_20 *jrt.Class

var A_arbace_data__init_A_const_21 *lang.Var

var A_arbace_data__init_A_const_22 *lang.Var

var A_arbace_data__init_A_const_23 *lang.Keyword

var A_arbace_data__init_A_const_24 *lang.Var

var A_arbace_data__init_A_const_25 any

var A_arbace_data__init_A_const_26 *lang.Var

var A_arbace_data__init_A_const_27 *lang.Var

var A_arbace_data__init_A_const_28 any

var A_arbace_data__init_A_const_29 *lang.Keyword

var A_arbace_data__init_A_const_30 any

var A_arbace_data__init_A_const_31 *lang.Keyword

var A_arbace_data__init_A_const_32 *lang.Keyword

var A_arbace_data__init_A_const_33 any

var A_arbace_data__init_A_const_34 *lang.Keyword

var A_arbace_data__init_A_const_35 *lang.Var

var A_arbace_data__init_A_const_36 *lang.Var

var A_arbace_data__init_A_const_37 *lang.Var

var A_arbace_data__init_A_const_38 any

var A_arbace_data__init_A_const_39 any

var A_arbace_data__init_A_const_40 *lang.Keyword

var A_arbace_data__init_A_const_41 *lang.Var

var A_arbace_data__init_A_const_42 any

var A_arbace_data__init_A_const_43 *lang.Var

var A_arbace_data__init_A_const_44 any

var A_arbace_data__init_A_const_45 any

var A_arbace_data__init_A_const_46 *jrt.Class

var A_arbace_data__init_A_const_47 any

var A_arbace_data__init_A_const_48 any

var A_arbace_data__init_A_const_49 any

var A_arbace_data__init_A_const_50 any

var A_arbace_data__init_A_const_51 any

var A_arbace_data__init_A_const_52 any

var A_arbace_data__init_A_const_53 any

var A_arbace_data__init_A_const_54 *lang.Var

var A_arbace_data__init_A_const_55 *lang.Keyword

var A_arbace_data__init_A_const_56 *jrt.Class

var A_arbace_data__init_A_const_57 *lang.Keyword

var A_arbace_data__init_A_const_58 *jrt.Class

var A_arbace_data__init_A_const_59 *jrt.Class

var A_arbace_data__init_A_const_60 *jrt.Class

var A_arbace_data__init_A_const_61 *lang.Var

var A_arbace_data__init_A_const_62 any

var A_arbace_data__init_A_const_63 any

var A_arbace_data__init_A_init jrt.ClassInit

func A_arbace_data__init_A_Init() { if !A_arbace_data__init_A_init.Done() { A_arbace_data__init_A_init.Run(A_arbace_data__init_A_clinit) } }

func A_arbace_data__init_A_clinit() { A_arbace_data__init_A_clinit_p0(); A_arbace_data__init_A_clinit_p1(); A_arbace_data__init_A_clinit_p2(); A_arbace_data__init_A_clinit_p3(); A_arbace_data__init_A_clinit_p4() }

func A_arbace_data__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_data__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_9, 94); A_arbace_data__init_A_const_0 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[30]); A_arbace_data__init_A_const_1 = A_arbace_data__init_A_const_pool.A[31]; A_arbace_data__init_A_const_2 = A_arbace_data__init_A_const_pool.A[32]; A_arbace_data__init_A_const_3 = A_arbace_data__init_A_const_pool.A[33]; A_arbace_data__init_A_const_4 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[34]); A_arbace_data__init_A_const_5 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[35]); A_arbace_data__init_A_const_6 = A_arbace_data__init_A_const_pool.A[36]; A_arbace_data__init_A_const_7 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[37]); A_arbace_data__init_A_const_8 = A_arbace_data__init_A_const_pool.A[38]; A_arbace_data__init_A_const_9 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[39]); A_arbace_data__init_A_const_10 = A_arbace_data__init_A_const_pool.A[40]; A_arbace_data__init_A_const_11 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[41]); A_arbace_data__init_A_const_12 = A_arbace_data__init_A_const_pool.A[42] }

func A_arbace_data__init_A_clinit_p1() { A_arbace_data__init_A_const_13 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[43]); A_arbace_data__init_A_const_14 = A_arbace_data__init_A_const_pool.A[44]; A_arbace_data__init_A_const_15 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[45]); A_arbace_data__init_A_const_16 = A_arbace_data__init_A_const_pool.A[46]; A_arbace_data__init_A_const_17 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[47]); A_arbace_data__init_A_const_18 = A_arbace_data__init_A_const_pool.A[48]; A_arbace_data__init_A_const_19 = A_arbace_data__init_A_const_pool.A[49]; A_arbace_data__init_A_const_20 = jrt.Class_Cast(A_arbace_data__init_A_const_pool.A[50]); A_arbace_data__init_A_const_21 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[51]); A_arbace_data__init_A_const_22 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[52]); A_arbace_data__init_A_const_23 = lang.Keyword_Cast(A_arbace_data__init_A_const_pool.A[53]); A_arbace_data__init_A_const_24 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[54]); A_arbace_data__init_A_const_25 = A_arbace_data__init_A_const_pool.A[55] }

func A_arbace_data__init_A_clinit_p2() { A_arbace_data__init_A_const_26 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[56]); A_arbace_data__init_A_const_27 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[57]); A_arbace_data__init_A_const_28 = A_arbace_data__init_A_const_pool.A[58]; A_arbace_data__init_A_const_29 = lang.Keyword_Cast(A_arbace_data__init_A_const_pool.A[59]); A_arbace_data__init_A_const_30 = A_arbace_data__init_A_const_pool.A[60]; A_arbace_data__init_A_const_31 = lang.Keyword_Cast(A_arbace_data__init_A_const_pool.A[61]); A_arbace_data__init_A_const_32 = lang.Keyword_Cast(A_arbace_data__init_A_const_pool.A[62]); A_arbace_data__init_A_const_33 = A_arbace_data__init_A_const_pool.A[63]; A_arbace_data__init_A_const_34 = lang.Keyword_Cast(A_arbace_data__init_A_const_pool.A[64]); A_arbace_data__init_A_const_35 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[65]); A_arbace_data__init_A_const_36 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[66]); A_arbace_data__init_A_const_37 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[67]); A_arbace_data__init_A_const_38 = A_arbace_data__init_A_const_pool.A[68] }

func A_arbace_data__init_A_clinit_p3() { A_arbace_data__init_A_const_39 = A_arbace_data__init_A_const_pool.A[69]; A_arbace_data__init_A_const_40 = lang.Keyword_Cast(A_arbace_data__init_A_const_pool.A[70]); A_arbace_data__init_A_const_41 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[71]); A_arbace_data__init_A_const_42 = A_arbace_data__init_A_const_pool.A[72]; A_arbace_data__init_A_const_43 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[73]); A_arbace_data__init_A_const_44 = A_arbace_data__init_A_const_pool.A[74]; A_arbace_data__init_A_const_45 = A_arbace_data__init_A_const_pool.A[75]; A_arbace_data__init_A_const_46 = jrt.Class_Cast(A_arbace_data__init_A_const_pool.A[76]); A_arbace_data__init_A_const_47 = A_arbace_data__init_A_const_pool.A[77]; A_arbace_data__init_A_const_48 = A_arbace_data__init_A_const_pool.A[78]; A_arbace_data__init_A_const_49 = A_arbace_data__init_A_const_pool.A[79]; A_arbace_data__init_A_const_50 = A_arbace_data__init_A_const_pool.A[80]; A_arbace_data__init_A_const_51 = A_arbace_data__init_A_const_pool.A[81]; A_arbace_data__init_A_const_52 = A_arbace_data__init_A_const_pool.A[82] }

func A_arbace_data__init_A_clinit_p4() { A_arbace_data__init_A_const_53 = A_arbace_data__init_A_const_pool.A[83]; A_arbace_data__init_A_const_54 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[84]); A_arbace_data__init_A_const_55 = lang.Keyword_Cast(A_arbace_data__init_A_const_pool.A[85]); A_arbace_data__init_A_const_56 = jrt.Class_Cast(A_arbace_data__init_A_const_pool.A[86]); A_arbace_data__init_A_const_57 = lang.Keyword_Cast(A_arbace_data__init_A_const_pool.A[87]); A_arbace_data__init_A_const_58 = jrt.Class_Cast(A_arbace_data__init_A_const_pool.A[88]); A_arbace_data__init_A_const_59 = jrt.Class_Cast(A_arbace_data__init_A_const_pool.A[89]); A_arbace_data__init_A_const_60 = jrt.Class_Cast(A_arbace_data__init_A_const_pool.A[90]); A_arbace_data__init_A_const_61 = lang.Var_Cast(A_arbace_data__init_A_const_pool.A[91]); A_arbace_data__init_A_const_62 = A_arbace_data__init_A_const_pool.A[92]; A_arbace_data__init_A_const_63 = A_arbace_data__init_A_const_pool.A[93] }

func A_arbace_data__init_A_New() *A_arbace_data__init_A { A_arbace_data__init_A_Init(); t := &A_arbace_data__init_A{}; t.Ctor(); return t }

func (t *A_arbace_data__init_A) Ctor() {}

func (t *A_arbace_data__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_data__init_A) GetClass__Class() *jrt.Class { return A_arbace_data__init_A_class }

func (t *A_arbace_data__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_data__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_data__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_data__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_data__init_A); return ok }

func A_arbace_data__init_A_Cast(x any) *A_arbace_data__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_data__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_data__init_A_class)) }; return v }
