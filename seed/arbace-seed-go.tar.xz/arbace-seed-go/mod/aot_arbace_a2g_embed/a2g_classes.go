//line a2g_classes.ae:1
package aot_arbace_a2g_embed

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_a2g_embed_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_A_New()}; return nil }

var A_arbace_a2g_embed_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_embed_A_new}

var A_arbace_a2g_embed_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_A"})

func init() { i := A_arbace_a2g_embed_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_A_InstanceOf; i.Init = A_arbace_a2g_embed_A_Init; i.Table = A_arbace_a2g_embed_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_A_class, reflect.TypeFor[A_arbace_a2g_embed_A]()) }

func A_arbace_a2g_embed_class_like_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_class_like_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_class_like_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_class_like_QMARK__A_New()}; return nil }

func A_arbace_a2g_embed_class_like_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_class_like_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_embed_class_like_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_class_like_QMARK__A_invoke, New: A_arbace_a2g_embed_class_like_QMARK__A_new, Get: A_arbace_a2g_embed_class_like_QMARK__A_get}

var A_arbace_a2g_embed_class_like_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$class_like_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_A_class, Simple: "class_like_QMARK_", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_class_like_QMARK__A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_class_like_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_embed_class_like_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_embed_class_like_QMARK__A_Init; i.Table = A_arbace_a2g_embed_class_like_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_embed_class_like_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_embed_class_like_QMARK__A]()) }

func A_arbace_a2g_embed_cut_candidates_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_cut_candidates_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_cut_candidates_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_cut_candidates_A_New()}; return nil }

func A_arbace_a2g_embed_cut_candidates_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_cut_candidates_A_fn_class)}; return nil }

var A_arbace_a2g_embed_cut_candidates_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_cut_candidates_A_invoke, New: A_arbace_a2g_embed_cut_candidates_A_new, Get: A_arbace_a2g_embed_cut_candidates_A_get}

var A_arbace_a2g_embed_cut_candidates_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$cut_candidates", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_A_class, Simple: "cut_candidates", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_cut_candidates_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_cut_candidates_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_cut_candidates_A_InstanceOf; i.Init = A_arbace_a2g_embed_cut_candidates_A_Init; i.Table = A_arbace_a2g_embed_cut_candidates_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_cut_candidates_A_class, reflect.TypeFor[A_arbace_a2g_embed_cut_candidates_A]()) }

func A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_cut_candidates_fn__1520000103_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_New()}; return nil }

func A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_fn_class)}; return nil }

var A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_invoke, New: A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_new, Get: A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_get}

var A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$cut_candidates$fn__1520000103", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_cut_candidates_A_class, Simple: "fn__1520000103", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_cut_candidates_fn__1520000103_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_InstanceOf; i.Init = A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_Init; i.Table = A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_class, reflect.TypeFor[A_arbace_a2g_embed_cut_candidates_fn__1520000103_A]()) }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_New()}; return nil }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_fn_class)}; return nil }

var A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_invoke, New: A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_new, Get: A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_get}

var A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$cut_candidates$iter__1520000088__1520000092", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_cut_candidates_A_class, Simple: "iter__1520000088__1520000092", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_InstanceOf; i.Init = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_Init; i.Table = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_class, reflect.TypeFor[A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A]()) }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_fn_class)}; return nil }

var A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_invoke, New: A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_new, Get: A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_get}

var A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$cut_candidates$iter__1520000088__1520000092$fn__1520000093", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_class, Simple: "fn__1520000093", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_InstanceOf; i.Init = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_Init; i.Table = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_class, reflect.TypeFor[A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A]()) }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_fn_class)}; return nil }

var A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_invoke, New: A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_new, Get: A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_get}

var A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$cut_candidates$iter__1520000088__1520000092$fn__1520000093$fn__1520000094", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_class, Simple: "fn__1520000094", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_InstanceOf; i.Init = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_Init; i.Table = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_class, reflect.TypeFor[A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A]()) }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_New_O(args[0])}; return nil }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_fn_class)}; return nil }

var A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_invoke, New: A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_new, Get: A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_get}

var A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$cut_candidates$iter__1520000088__1520000092$fn__1520000093$fn__1520000094$fn__1520000095", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_class, Simple: "fn__1520000095", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_InstanceOf; i.Init = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_Init; i.Table = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_class, reflect.TypeFor[A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A]()) }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_New_O(args[0])}; return nil }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_fn_class)}; return nil }

var A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_invoke, New: A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_new, Get: A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_get}

var A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$cut_candidates$iter__1520000088__1520000092$fn__1520000093$fn__1520000098", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_class, Simple: "fn__1520000098", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_InstanceOf; i.Init = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_Init; i.Table = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_class, reflect.TypeFor[A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A]()) }

func A_arbace_a2g_embed_data_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_data_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_data_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_data_A_New()}; return nil }

func A_arbace_a2g_embed_data_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_data_A_fn_class)}; return nil }

var A_arbace_a2g_embed_data_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_data_A_invoke, New: A_arbace_a2g_embed_data_A_new, Get: A_arbace_a2g_embed_data_A_get}

var A_arbace_a2g_embed_data_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$data", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_A_class, Simple: "data", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_data_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_data_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_data_A_InstanceOf; i.Init = A_arbace_a2g_embed_data_A_Init; i.Table = A_arbace_a2g_embed_data_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_data_A_class, reflect.TypeFor[A_arbace_a2g_embed_data_A]()) }

func A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_data_iter__1520000152__1520000156_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_New_O(args[0])}; return nil }

func A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_fn_class)}; return nil }

var A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_invoke, New: A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_new, Get: A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_get}

var A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$data$iter__1520000152__1520000156", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_data_A_class, Simple: "iter__1520000152__1520000156", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_data_iter__1520000152__1520000156_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_InstanceOf; i.Init = A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_Init; i.Table = A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_class, reflect.TypeFor[A_arbace_a2g_embed_data_iter__1520000152__1520000156_A]()) }

func A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_fn_class)}; return nil }

var A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_invoke, New: A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_new, Get: A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_get}

var A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$data$iter__1520000152__1520000156$fn__1520000157", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_class, Simple: "fn__1520000157", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_InstanceOf; i.Init = A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_Init; i.Table = A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_class, reflect.TypeFor[A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A]()) }

func A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_New_O_I_O_O(args[0], args[1].(int32), args[2], args[3])}; return nil }

func A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_fn_class)}; return nil }

var A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_invoke, New: A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_new, Get: A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_get}

var A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$data$iter__1520000152__1520000156$fn__1520000157$fn__1520000158", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_class, Simple: "fn__1520000158", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_InstanceOf; i.Init = A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_Init; i.Table = A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_class, reflect.TypeFor[A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A]()) }

func A_arbace_a2g_embed_eval1520000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_eval1520000004_A_New()}; return nil }

var A_arbace_a2g_embed_eval1520000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_embed_eval1520000004_A_new}

var A_arbace_a2g_embed_eval1520000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$eval1520000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_embed_A_class, Simple: "eval1520000004", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_eval1520000004_A"})

func init() { i := A_arbace_a2g_embed_eval1520000004_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_eval1520000004_A_InstanceOf; i.Table = A_arbace_a2g_embed_eval1520000004_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_eval1520000004_A_class, reflect.TypeFor[A_arbace_a2g_embed_eval1520000004_A]()) }

func A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_New()}; return nil }

func A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_fn_class)}; return nil }

var A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_invoke, New: A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_new, Get: A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_get}

var A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$eval1520000004$loading__1927001464__auto____1520000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_embed_eval1520000004_A_class, Simple: "loading__1927001464__auto____1520000005", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_InstanceOf; i.Init = A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_Init; i.Table = A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_class, reflect.TypeFor[A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A]()) }

func A_arbace_a2g_embed_eval1520000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_eval1520000008_A_New()}; return nil }

var A_arbace_a2g_embed_eval1520000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_embed_eval1520000008_A_new}

var A_arbace_a2g_embed_eval1520000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$eval1520000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_embed_A_class, Simple: "eval1520000008", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_eval1520000008_A"})

func init() { i := A_arbace_a2g_embed_eval1520000008_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_eval1520000008_A_InstanceOf; i.Table = A_arbace_a2g_embed_eval1520000008_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_eval1520000008_A_class, reflect.TypeFor[A_arbace_a2g_embed_eval1520000008_A]()) }

func A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_eval1520000008_fn__1520000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_New()}; return nil }

func A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_fn_class)}; return nil }

var A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_invoke, New: A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_new, Get: A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_get}

var A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$eval1520000008$fn__1520000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_embed_eval1520000008_A_class, Simple: "fn__1520000009", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_eval1520000008_fn__1520000009_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_InstanceOf; i.Init = A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_Init; i.Table = A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_class, reflect.TypeFor[A_arbace_a2g_embed_eval1520000008_fn__1520000009_A]()) }

func A_arbace_a2g_embed_image_type_forms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_image_type_forms_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_image_type_forms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_image_type_forms_A_New()}; return nil }

func A_arbace_a2g_embed_image_type_forms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_image_type_forms_A_fn_class)}; return nil }

var A_arbace_a2g_embed_image_type_forms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_image_type_forms_A_invoke, New: A_arbace_a2g_embed_image_type_forms_A_new, Get: A_arbace_a2g_embed_image_type_forms_A_get}

var A_arbace_a2g_embed_image_type_forms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$image_type_forms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_A_class, Simple: "image_type_forms", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_image_type_forms_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_image_type_forms_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_image_type_forms_A_InstanceOf; i.Init = A_arbace_a2g_embed_image_type_forms_A_Init; i.Table = A_arbace_a2g_embed_image_type_forms_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_image_type_forms_A_class, reflect.TypeFor[A_arbace_a2g_embed_image_type_forms_A]()) }

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_image_type_forms_fn__1520000183_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_New_O(args[0])}; return nil }

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_fn_class)}; return nil }

var A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_invoke, New: A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_new, Get: A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_get}

var A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$image_type_forms$fn__1520000183", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_image_type_forms_A_class, Simple: "fn__1520000183", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_image_type_forms_fn__1520000183_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_InstanceOf; i.Init = A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_Init; i.Table = A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_class, reflect.TypeFor[A_arbace_a2g_embed_image_type_forms_fn__1520000183_A]()) }

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_New_O(args[0])}; return nil }

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_fn_class)}; return nil }

var A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_invoke, New: A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_new, Get: A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_get}

var A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$image_type_forms$fn__1520000183$iter__1520000187__1520000191", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_class, Simple: "iter__1520000187__1520000191", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_InstanceOf; i.Init = A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_Init; i.Table = A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_class, reflect.TypeFor[A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A]()) }

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_fn_class)}; return nil }

var A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_invoke, New: A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_new, Get: A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_get}

var A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$image_type_forms$fn__1520000183$iter__1520000187__1520000191$fn__1520000192", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_class, Simple: "fn__1520000192", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_InstanceOf; i.Init = A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_Init; i.Table = A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_class, reflect.TypeFor[A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A]()) }

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_fn_class)}; return nil }

var A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_invoke, New: A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_new, Get: A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_get}

var A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$image_type_forms$fn__1520000183$iter__1520000187__1520000191$fn__1520000192$fn__1520000193", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_class, Simple: "fn__1520000193", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_InstanceOf; i.Init = A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_Init; i.Table = A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_class, reflect.TypeFor[A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A]()) }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_New_O(args[0])}; return nil }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_fn_class)}; return nil }

var A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_invoke, New: A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_new, Get: A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_get}

var A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$image_type_forms$iter__1520000163__1520000169", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_image_type_forms_A_class, Simple: "iter__1520000163__1520000169", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_InstanceOf; i.Init = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_Init; i.Table = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_class, reflect.TypeFor[A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A]()) }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_fn_class)}; return nil }

var A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_invoke, New: A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_new, Get: A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_get}

var A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$image_type_forms$iter__1520000163__1520000169$fn__1520000170", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_class, Simple: "fn__1520000170", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_InstanceOf; i.Init = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_Init; i.Table = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_class, reflect.TypeFor[A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A]()) }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_New_O(args[0])}; return nil }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_fn_class)}; return nil }

var A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_invoke, New: A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_new, Get: A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_get}

var A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$image_type_forms$iter__1520000163__1520000169$fn__1520000170$iter__1520000165__1520000174", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_class, Simple: "iter__1520000165__1520000174", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_InstanceOf; i.Init = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_Init; i.Table = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_class, reflect.TypeFor[A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A]()) }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_fn_class)}; return nil }

var A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_invoke, New: A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_new, Get: A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_get}

var A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$image_type_forms$iter__1520000163__1520000169$fn__1520000170$iter__1520000165__1520000174$fn__1520000175", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_class, Simple: "fn__1520000175", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_InstanceOf; i.Init = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_Init; i.Table = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_class, reflect.TypeFor[A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A]()) }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_fn_class)}; return nil }

var A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_invoke, New: A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_new, Get: A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_get}

var A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$image_type_forms$iter__1520000163__1520000169$fn__1520000170$iter__1520000165__1520000174$fn__1520000175$fn__1520000176", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_class, Simple: "fn__1520000176", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_InstanceOf; i.Init = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_Init; i.Table = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_class, reflect.TypeFor[A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A]()) }

func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_New()}; return nil }

func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_fn_class)}; return nil }

var A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_invoke, New: A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_new, Get: A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_get}

var A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$image_type_forms$iter__1520000204__1520000208", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_image_type_forms_A_class, Simple: "iter__1520000204__1520000208", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_InstanceOf; i.Init = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_Init; i.Table = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_class, reflect.TypeFor[A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A]()) }

func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_fn_class)}; return nil }

var A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_invoke, New: A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_new, Get: A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_get}

var A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$image_type_forms$iter__1520000204__1520000208$fn__1520000209", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_class, Simple: "fn__1520000209", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_InstanceOf; i.Init = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_Init; i.Table = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_class, reflect.TypeFor[A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A]()) }

func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_fn_class)}; return nil }

var A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_invoke, New: A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_new, Get: A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_get}

var A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$image_type_forms$iter__1520000204__1520000208$fn__1520000209$fn__1520000210", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_class, Simple: "fn__1520000210", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_InstanceOf; i.Init = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_Init; i.Table = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_class, reflect.TypeFor[A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A]()) }

func A_arbace_a2g_embed_names_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_names_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_names_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_names_A_New()}; return nil }

func A_arbace_a2g_embed_names_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_names_A_fn_class)}; return nil }

var A_arbace_a2g_embed_names_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_names_A_invoke, New: A_arbace_a2g_embed_names_A_new, Get: A_arbace_a2g_embed_names_A_get}

var A_arbace_a2g_embed_names_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$names", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_A_class, Simple: "names", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_names_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_names_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_names_A_InstanceOf; i.Init = A_arbace_a2g_embed_names_A_Init; i.Table = A_arbace_a2g_embed_names_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_names_A_class, reflect.TypeFor[A_arbace_a2g_embed_names_A]()) }

func A_arbace_a2g_embed_names_walk__1520000059_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_names_walk__1520000059_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_names_walk__1520000059_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_names_walk__1520000059_A_New_O(args[0])}; return nil }

func A_arbace_a2g_embed_names_walk__1520000059_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_names_walk__1520000059_A_fn_class)}; return nil }

var A_arbace_a2g_embed_names_walk__1520000059_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_names_walk__1520000059_A_invoke, New: A_arbace_a2g_embed_names_walk__1520000059_A_new, Get: A_arbace_a2g_embed_names_walk__1520000059_A_get}

var A_arbace_a2g_embed_names_walk__1520000059_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$names$walk__1520000059", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_names_A_class, Simple: "walk__1520000059", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_names_walk__1520000059_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_names_walk__1520000059_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_names_walk__1520000059_A_InstanceOf; i.Init = A_arbace_a2g_embed_names_walk__1520000059_A_Init; i.Table = A_arbace_a2g_embed_names_walk__1520000059_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_names_walk__1520000059_A_class, reflect.TypeFor[A_arbace_a2g_embed_names_walk__1520000059_A]()) }

func A_arbace_a2g_embed_package_like_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_package_like_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_package_like_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_package_like_QMARK__A_New()}; return nil }

func A_arbace_a2g_embed_package_like_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_package_like_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_embed_package_like_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_package_like_QMARK__A_invoke, New: A_arbace_a2g_embed_package_like_QMARK__A_new, Get: A_arbace_a2g_embed_package_like_QMARK__A_get}

var A_arbace_a2g_embed_package_like_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$package_like_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_A_class, Simple: "package_like_QMARK_", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_package_like_QMARK__A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_package_like_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_embed_package_like_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_embed_package_like_QMARK__A_Init; i.Table = A_arbace_a2g_embed_package_like_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_embed_package_like_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_embed_package_like_QMARK__A]()) }

func A_arbace_a2g_embed_read_all_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_read_all_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_read_all_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_read_all_A_New()}; return nil }

func A_arbace_a2g_embed_read_all_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_read_all_A_fn_class)}; return nil }

var A_arbace_a2g_embed_read_all_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_read_all_A_invoke, New: A_arbace_a2g_embed_read_all_A_new, Get: A_arbace_a2g_embed_read_all_A_get}

var A_arbace_a2g_embed_read_all_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$read_all", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_A_class, Simple: "read_all", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_read_all_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_read_all_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_read_all_A_InstanceOf; i.Init = A_arbace_a2g_embed_read_all_A_Init; i.Table = A_arbace_a2g_embed_read_all_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_read_all_A_class, reflect.TypeFor[A_arbace_a2g_embed_read_all_A]()) }

func A_arbace_a2g_embed_read_all_fn__1520000054_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_read_all_fn__1520000054_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_embed_read_all_fn__1520000054_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_read_all_fn__1520000054_A_New()}; return nil }

func A_arbace_a2g_embed_read_all_fn__1520000054_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_read_all_fn__1520000054_A_fn_class)}; return nil }

var A_arbace_a2g_embed_read_all_fn__1520000054_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_read_all_fn__1520000054_A_invoke, New: A_arbace_a2g_embed_read_all_fn__1520000054_A_new, Get: A_arbace_a2g_embed_read_all_fn__1520000054_A_get}

var A_arbace_a2g_embed_read_all_fn__1520000054_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$read_all$fn__1520000054", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_embed_read_all_A_class, Simple: "fn__1520000054", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_read_all_fn__1520000054_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_read_all_fn__1520000054_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_read_all_fn__1520000054_A_InstanceOf; i.Init = A_arbace_a2g_embed_read_all_fn__1520000054_A_Init; i.Table = A_arbace_a2g_embed_read_all_fn__1520000054_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_read_all_fn__1520000054_A_class, reflect.TypeFor[A_arbace_a2g_embed_read_all_fn__1520000054_A]()) }

func A_arbace_a2g_embed_reify__1520000052_A_invoke(i int32, this any, args []any) any { switch i { case 0: return jrt.A2g_RefP(this.(*A_arbace_a2g_embed_reify__1520000052_A).CurrentNS__Symbol()); case 1: return this.(*A_arbace_a2g_embed_reify__1520000052_A).Meta__IPersistentMap(); case 2: return jrt.A2g_RefP(this.(*A_arbace_a2g_embed_reify__1520000052_A).ResolveAlias_Symbol__Symbol(jrt.As[*lang.Symbol](args[0]))); case 3: return jrt.A2g_RefP(this.(*A_arbace_a2g_embed_reify__1520000052_A).ResolveClass_Symbol__Symbol(jrt.As[*lang.Symbol](args[0]))); case 4: return jrt.A2g_RefP(this.(*A_arbace_a2g_embed_reify__1520000052_A).ResolveVar_Symbol__Symbol(jrt.As[*lang.Symbol](args[0]))); case 5: return this.(*A_arbace_a2g_embed_reify__1520000052_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_a2g_embed_reify__1520000052_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_reify__1520000052_A_New_IPersistentMap(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

var A_arbace_a2g_embed_reify__1520000052_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 currentNS ()Larbace.lang.Symbol;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 resolveAlias (Larbace.lang.Symbol;)Larbace.lang.Symbol;\nM1 resolveClass (Larbace.lang.Symbol;)Larbace.lang.Symbol;\nM1 resolveVar (Larbace.lang.Symbol;)Larbace.lang.Symbol;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;)V", Invoke: A_arbace_a2g_embed_reify__1520000052_A_invoke, New: A_arbace_a2g_embed_reify__1520000052_A_new}

var A_arbace_a2g_embed_reify__1520000052_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$reify__1520000052", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.LispReader_Resolver_class, lang.IObj_class}, Declaring: A_arbace_a2g_embed_A_class, Simple: "reify__1520000052", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_reify__1520000052_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_reify__1520000052_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_reify__1520000052_A_InstanceOf; i.Table = A_arbace_a2g_embed_reify__1520000052_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_reify__1520000052_A_class, reflect.TypeFor[A_arbace_a2g_embed_reify__1520000052_A]()) }

func A_arbace_a2g_embed_sources_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_sources_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_sources_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_sources_A_New()}; return nil }

func A_arbace_a2g_embed_sources_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_sources_A_fn_class)}; return nil }

var A_arbace_a2g_embed_sources_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_sources_A_invoke, New: A_arbace_a2g_embed_sources_A_new, Get: A_arbace_a2g_embed_sources_A_get}

var A_arbace_a2g_embed_sources_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$sources", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_A_class, Simple: "sources", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_sources_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_sources_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_sources_A_InstanceOf; i.Init = A_arbace_a2g_embed_sources_A_Init; i.Table = A_arbace_a2g_embed_sources_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_sources_A_class, reflect.TypeFor[A_arbace_a2g_embed_sources_A]()) }

func A_arbace_a2g_embed_sources_fn__1520000038_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_sources_fn__1520000038_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_embed_sources_fn__1520000038_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_sources_fn__1520000038_A_New()}; return nil }

func A_arbace_a2g_embed_sources_fn__1520000038_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_sources_fn__1520000038_A_fn_class)}; return nil }

var A_arbace_a2g_embed_sources_fn__1520000038_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_sources_fn__1520000038_A_invoke, New: A_arbace_a2g_embed_sources_fn__1520000038_A_new, Get: A_arbace_a2g_embed_sources_fn__1520000038_A_get}

var A_arbace_a2g_embed_sources_fn__1520000038_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$sources$fn__1520000038", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_embed_sources_A_class, Simple: "fn__1520000038", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_sources_fn__1520000038_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_sources_fn__1520000038_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_sources_fn__1520000038_A_InstanceOf; i.Init = A_arbace_a2g_embed_sources_fn__1520000038_A_Init; i.Table = A_arbace_a2g_embed_sources_fn__1520000038_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_sources_fn__1520000038_A_class, reflect.TypeFor[A_arbace_a2g_embed_sources_fn__1520000038_A]()) }

func A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_fn_class)}; return nil }

var A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_invoke, New: A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_new, Get: A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_get}

var A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$sources$fn__1520000038$fn__1520000042", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_sources_fn__1520000038_A_class, Simple: "fn__1520000042", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_InstanceOf; i.Init = A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_Init; i.Table = A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_class, reflect.TypeFor[A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A]()) }

func A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_fn_class)}; return nil }

var A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_invoke, New: A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_new, Get: A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_get}

var A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$sources$fn__1520000038$fn__1520000042$fn__1520000044", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_class, Simple: "fn__1520000044", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_InstanceOf; i.Init = A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_Init; i.Table = A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_class, reflect.TypeFor[A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A]()) }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_New_O(args[0])}; return nil }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_fn_class)}; return nil }

var A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_invoke, New: A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_new, Get: A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_get}

var A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$sources$iter__1520000013__1520000017", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_sources_A_class, Simple: "iter__1520000013__1520000017", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_InstanceOf; i.Init = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_Init; i.Table = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_class, reflect.TypeFor[A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A]()) }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_fn_class)}; return nil }

var A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_invoke, New: A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_new, Get: A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_get}

var A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$sources$iter__1520000013__1520000017$fn__1520000018", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_class, Simple: "fn__1520000018", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_InstanceOf; i.Init = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_Init; i.Table = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_class, reflect.TypeFor[A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A]()) }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_fn_class)}; return nil }

var A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_invoke, New: A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_new, Get: A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_get}

var A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$sources$iter__1520000013__1520000017$fn__1520000018$fn__1520000019", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_class, Simple: "fn__1520000019", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_InstanceOf; i.Init = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_Init; i.Table = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_class, reflect.TypeFor[A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A]()) }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_New_O(args[0])}; return nil }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_fn_class)}; return nil }

var A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_invoke, New: A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_new, Get: A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_get}

var A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$sources$iter__1520000013__1520000017$fn__1520000018$fn__1520000019$fn__1520000020", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_class, Simple: "fn__1520000020", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_InstanceOf; i.Init = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_Init; i.Table = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_class, reflect.TypeFor[A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A]()) }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_New_O(args[0])}; return nil }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_fn_class)}; return nil }

var A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_invoke, New: A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_new, Get: A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_get}

var A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$sources$iter__1520000013__1520000017$fn__1520000018$fn__1520000023", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_class, Simple: "fn__1520000023", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_InstanceOf; i.Init = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_Init; i.Table = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_class, reflect.TypeFor[A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A]()) }

func A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_New_O(args[0])}; return nil }

func A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_fn_class)}; return nil }

var A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_invoke, New: A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_new, Get: A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_get}

var A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$sources$iter__1520000027__1520000031", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_sources_A_class, Simple: "iter__1520000027__1520000031", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_InstanceOf; i.Init = A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_Init; i.Table = A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_class, reflect.TypeFor[A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A]()) }

func A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_fn_class)}; return nil }

var A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_invoke, New: A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_new, Get: A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_get}

var A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$sources$iter__1520000027__1520000031$fn__1520000032", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_class, Simple: "fn__1520000032", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_InstanceOf; i.Init = A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_Init; i.Table = A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_class, reflect.TypeFor[A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A]()) }

func A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_fn_class)}; return nil }

var A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_invoke, New: A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_new, Get: A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_get}

var A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$sources$iter__1520000027__1520000031$fn__1520000032$fn__1520000033", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_class, Simple: "fn__1520000033", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_InstanceOf; i.Init = A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_Init; i.Table = A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_class, reflect.TypeFor[A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A]()) }

func A_arbace_a2g_embed_with_member_types_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_with_member_types_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_embed_with_member_types_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_with_member_types_A_New()}; return nil }

func A_arbace_a2g_embed_with_member_types_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_with_member_types_A_fn_class)}; return nil }

var A_arbace_a2g_embed_with_member_types_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_with_member_types_A_invoke, New: A_arbace_a2g_embed_with_member_types_A_new, Get: A_arbace_a2g_embed_with_member_types_A_get}

var A_arbace_a2g_embed_with_member_types_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$with_member_types", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_embed_A_class, Simple: "with_member_types", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_with_member_types_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_with_member_types_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_with_member_types_A_InstanceOf; i.Init = A_arbace_a2g_embed_with_member_types_A_Init; i.Table = A_arbace_a2g_embed_with_member_types_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_with_member_types_A_class, reflect.TypeFor[A_arbace_a2g_embed_with_member_types_A]()) }

func A_arbace_a2g_embed_with_member_types_elem__1520000117_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_with_member_types_elem__1520000117_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_with_member_types_elem__1520000117_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_with_member_types_elem__1520000117_A_New()}; return nil }

func A_arbace_a2g_embed_with_member_types_elem__1520000117_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_with_member_types_elem__1520000117_A_fn_class)}; return nil }

var A_arbace_a2g_embed_with_member_types_elem__1520000117_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_with_member_types_elem__1520000117_A_invoke, New: A_arbace_a2g_embed_with_member_types_elem__1520000117_A_new, Get: A_arbace_a2g_embed_with_member_types_elem__1520000117_A_get}

var A_arbace_a2g_embed_with_member_types_elem__1520000117_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$with_member_types$elem__1520000117", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_with_member_types_A_class, Simple: "elem__1520000117", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_with_member_types_elem__1520000117_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_with_member_types_elem__1520000117_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_with_member_types_elem__1520000117_A_InstanceOf; i.Init = A_arbace_a2g_embed_with_member_types_elem__1520000117_A_Init; i.Table = A_arbace_a2g_embed_with_member_types_elem__1520000117_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_with_member_types_elem__1520000117_A_class, reflect.TypeFor[A_arbace_a2g_embed_with_member_types_elem__1520000117_A]()) }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_fn_class)}; return nil }

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_invoke, New: A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_new, Get: A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_get}

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$with_member_types$iter__1520000133__1520000139", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_with_member_types_A_class, Simple: "iter__1520000133__1520000139", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_InstanceOf; i.Init = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_Init; i.Table = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_class, reflect.TypeFor[A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A]()) }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_fn_class)}; return nil }

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_invoke, New: A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_new, Get: A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_get}

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$with_member_types$iter__1520000133__1520000139$fn__1520000140", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_class, Simple: "fn__1520000140", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_InstanceOf; i.Init = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_Init; i.Table = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_class, reflect.TypeFor[A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A]()) }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_fn_class)}; return nil }

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_invoke, New: A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_new, Get: A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_get}

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$with_member_types$iter__1520000133__1520000139$fn__1520000140$fn__1520000147", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_class, Simple: "fn__1520000147", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_InstanceOf; i.Init = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_Init; i.Table = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_class, reflect.TypeFor[A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A]()) }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_New_O(args[0])}; return nil }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_fn_class)}; return nil }

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_invoke, New: A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_new, Get: A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_get}

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$with_member_types$iter__1520000133__1520000139$fn__1520000140$iter__1520000135__1520000141", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_class, Simple: "iter__1520000135__1520000141", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_InstanceOf; i.Init = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_Init; i.Table = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_class, reflect.TypeFor[A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A]()) }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_fn_class)}; return nil }

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_invoke, New: A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_new, Get: A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_get}

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$with_member_types$iter__1520000133__1520000139$fn__1520000140$iter__1520000135__1520000141$fn__1520000142", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_class, Simple: "fn__1520000142", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_InstanceOf; i.Init = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_Init; i.Table = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_class, reflect.TypeFor[A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A]()) }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_fn_class)}; return nil }

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_invoke, New: A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_new, Get: A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_get}

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$with_member_types$iter__1520000133__1520000139$fn__1520000140$iter__1520000135__1520000141$fn__1520000142$fn__1520000143", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_class, Simple: "fn__1520000143", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_InstanceOf; i.Init = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_Init; i.Table = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_class, reflect.TypeFor[A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A]()) }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_with_member_types_member_types__1520000119_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_fn_class)}; return nil }

var A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_invoke, New: A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_new, Get: A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_get}

var A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$with_member_types$member_types__1520000119", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_with_member_types_A_class, Simple: "member_types__1520000119", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_with_member_types_member_types__1520000119_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_InstanceOf; i.Init = A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_Init; i.Table = A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_class, reflect.TypeFor[A_arbace_a2g_embed_with_member_types_member_types__1520000119_A]()) }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_New_O(args[0])}; return nil }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_fn_class)}; return nil }

var A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_invoke, New: A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_new, Get: A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_get}

var A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$with_member_types$member_types__1520000119$fn__1520000120", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_class, Simple: "fn__1520000120", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_InstanceOf; i.Init = A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_Init; i.Table = A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_class, reflect.TypeFor[A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A]()) }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_New()}; return nil }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_fn_class)}; return nil }

var A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_invoke, New: A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_new, Get: A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_get}

var A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$with_member_types$member_types__1520000119$iter__1520000122__1520000126", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_class, Simple: "iter__1520000122__1520000126", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_InstanceOf; i.Init = A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_Init; i.Table = A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_class, reflect.TypeFor[A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A]()) }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_fn_class)}; return nil }

var A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_invoke, New: A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_new, Get: A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_get}

var A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$with_member_types$member_types__1520000119$iter__1520000122__1520000126$fn__1520000127", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_class, Simple: "fn__1520000127", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_InstanceOf; i.Init = A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_Init; i.Table = A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_class, reflect.TypeFor[A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A]()) }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_fn_class)}; return nil }

var A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_invoke, New: A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_new, Get: A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_get}

var A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$with_member_types$member_types__1520000119$iter__1520000122__1520000126$fn__1520000127$fn__1520000128", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_class, Simple: "fn__1520000128", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_InstanceOf; i.Init = A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_Init; i.Table = A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_class, reflect.TypeFor[A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A]()) }

func A_arbace_a2g_embed_with_member_types_types__1520000109_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_with_member_types_types__1520000109_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_with_member_types_types__1520000109_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_with_member_types_types__1520000109_A_New()}; return nil }

func A_arbace_a2g_embed_with_member_types_types__1520000109_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_with_member_types_types__1520000109_A_fn_class)}; return nil }

var A_arbace_a2g_embed_with_member_types_types__1520000109_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_with_member_types_types__1520000109_A_invoke, New: A_arbace_a2g_embed_with_member_types_types__1520000109_A_new, Get: A_arbace_a2g_embed_with_member_types_types__1520000109_A_get}

var A_arbace_a2g_embed_with_member_types_types__1520000109_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$with_member_types$types__1520000109", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_with_member_types_A_class, Simple: "types__1520000109", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_with_member_types_types__1520000109_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_with_member_types_types__1520000109_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_with_member_types_types__1520000109_A_InstanceOf; i.Init = A_arbace_a2g_embed_with_member_types_types__1520000109_A_Init; i.Table = A_arbace_a2g_embed_with_member_types_types__1520000109_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_with_member_types_types__1520000109_A_class, reflect.TypeFor[A_arbace_a2g_embed_with_member_types_types__1520000109_A]()) }

func A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_New()}; return nil }

func A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_fn_class)}; return nil }

var A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_invoke, New: A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_new, Get: A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_get}

var A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$with_member_types$types__1520000109$fn__1520000110", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_with_member_types_types__1520000109_A_class, Simple: "fn__1520000110", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_InstanceOf; i.Init = A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_Init; i.Table = A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_class, reflect.TypeFor[A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A]()) }

func A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_New()}; return nil }

func A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_fn_class)}; return nil }

var A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_invoke, New: A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_new, Get: A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_get}

var A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$with_member_types$types__1520000109$fn__1520000112", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_with_member_types_types__1520000109_A_class, Simple: "fn__1520000112", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_InstanceOf; i.Init = A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_Init; i.Table = A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_class, reflect.TypeFor[A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A]()) }

func A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_New()}; return nil }

func A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_fn_class)}; return nil }

var A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_invoke, New: A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_new, Get: A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_get}

var A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed$with_member_types$types__1520000109$fn__1520000114", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_embed_with_member_types_types__1520000109_A_class, Simple: "fn__1520000114", Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_class.Info(); i.IsInstance = A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_InstanceOf; i.Init = A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_Init; i.Table = A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_members; jrt.RegisterGoType(A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_class, reflect.TypeFor[A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A]()) }

func A_arbace_a2g_embed__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_a2g_embed__init_A_Load__O(); case 1: return A_arbace_a2g_embed__init_A_Unit0__O(); case 2: return A_arbace_a2g_embed__init_A_Unit1__O(); case 3: return A_arbace_a2g_embed__init_A_Unit10__O(); case 4: return A_arbace_a2g_embed__init_A_Unit11__O(); case 5: return A_arbace_a2g_embed__init_A_Unit12__O(); case 6: return A_arbace_a2g_embed__init_A_Unit13__O(); case 7: return A_arbace_a2g_embed__init_A_Unit14__O(); case 8: return A_arbace_a2g_embed__init_A_Unit15__O(); case 9: return A_arbace_a2g_embed__init_A_Unit16__O(); case 10: return A_arbace_a2g_embed__init_A_Unit17__O(); case 11: return A_arbace_a2g_embed__init_A_Unit18__O(); case 12: return A_arbace_a2g_embed__init_A_Unit2__O(); case 13: return A_arbace_a2g_embed__init_A_Unit3__O(); case 14: return A_arbace_a2g_embed__init_A_Unit4__O(); case 15: return A_arbace_a2g_embed__init_A_Unit5__O(); case 16: return A_arbace_a2g_embed__init_A_Unit6__O(); case 17: return A_arbace_a2g_embed__init_A_Unit7__O(); case 18: return A_arbace_a2g_embed__init_A_Unit8__O(); case 19: return A_arbace_a2g_embed__init_A_Unit9__O()}; return nil }

func A_arbace_a2g_embed__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_embed__init_A_New()}; return nil }

var A_arbace_a2g_embed__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_a2g_embed__init_A_invoke, New: A_arbace_a2g_embed__init_A_new}

var A_arbace_a2g_embed__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.embed__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_embed.A_arbace_a2g_embed__init_A", Source: "embed.ae"})

func init() { i := A_arbace_a2g_embed__init_A_class.Info(); i.IsInstance = A_arbace_a2g_embed__init_A_InstanceOf; i.Init = A_arbace_a2g_embed__init_A_Init; i.Table = A_arbace_a2g_embed__init_A_members; jrt.RegisterGoType(A_arbace_a2g_embed__init_A_class, reflect.TypeFor[A_arbace_a2g_embed__init_A]()) }
